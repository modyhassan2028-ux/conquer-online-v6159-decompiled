// ==== CMsgTeamDice::helper_1402eb8c0  @1402eb8c0  [medium:callgraph-r0]  (orig: FUN_1402eb8c0)
undefined1 FUN_1402eb8c0(longlong param_1,undefined4 param_2,uint param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined1 uVar5;
  char cVar6;
  undefined8 *puVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *local_38;
  undefined8 *local_30;
  longlong *local_28;
  longlong *plStack_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar6 = *(char *)((longlong)puVar9 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  while (cVar6 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_3) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar6 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_30 = puVar4;
  local_38 = *(longlong **)(param_1 + 0x10);
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_3 < *(uint *)(puVar4 + 3))) {
    plStack_20 = (longlong *)*(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong **)(param_1 + 0x10);
    pplVar8 = &local_28;
  }
  else {
    pplVar8 = &local_38;
  }
  plVar1 = *pplVar8;
  plVar2 = pplVar8[1];
  plVar3 = *(longlong **)(param_1 + 0x40);
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (plVar2 == plVar3) {
    uVar5 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar2 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar10 = plVar2[4];
    if (lVar10 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_1404804f0(lVar10,param_2);
      cVar6 = FUN_14047e1c0(lVar10);
      if (cVar6 == '\0') {
        FUN_14047ef60(lVar10);
        local_28 = plVar1;
        plStack_20 = plVar2;
        FUN_1402eae00(param_1 + 0x10,&local_38,&local_28);
      }
    }
  }
  return uVar5;
}

// ==== CMsgTeamDice::helper_1402eba40  @1402eba40  [medium:callgraph-r0]  (orig: FUN_1402eba40)
undefined1 FUN_1402eba40(longlong param_1,undefined4 param_2,uint param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined1 uVar5;
  char cVar6;
  undefined8 *puVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *local_38;
  undefined8 *local_30;
  longlong *local_28;
  longlong *plStack_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar6 = *(char *)((longlong)puVar9 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  while (cVar6 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_3) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar6 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_30 = puVar4;
  local_38 = *(longlong **)(param_1 + 0x10);
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_3 < *(uint *)(puVar4 + 3))) {
    plStack_20 = (longlong *)*(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong **)(param_1 + 0x10);
    pplVar8 = &local_28;
  }
  else {
    pplVar8 = &local_38;
  }
  plVar1 = *pplVar8;
  plVar2 = pplVar8[1];
  plVar3 = *(longlong **)(param_1 + 0x40);
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (plVar2 == plVar3) {
    uVar5 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar2 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar10 = plVar2[4];
    if (lVar10 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = FUN_1404801a0(lVar10,param_2);
      cVar6 = FUN_14047e1c0(lVar10);
      if (cVar6 == '\0') {
        FUN_14047ef60(lVar10);
        local_28 = plVar1;
        plStack_20 = plVar2;
        FUN_1402eae00(param_1 + 0x10,&local_38,&local_28);
      }
    }
  }
  return uVar5;
}

// ==== CMsgTeamDice::ctor_or_dtor  @140455550  [high:vtable-assign]  (orig: FUN_140455550)
undefined8 * FUN_140455550(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTeamDice::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTeamDice::ctor_or_dtor  @1404555a0  [high:vtable-assign]  (orig: FUN_1404555a0)
void FUN_1404555a0(undefined8 *param_1)

{
  *param_1 = CMsgTeamDice::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTeamDice::vfunc_1  @1404555d0  [high:rtti-vtable]  (orig: FUN_1404555d0)
ulonglong FUN_1404555d0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x413);
}

// ==== CMsgTeamDice::ctor_or_dtor  @140455660  [high:vtable-assign]  (orig: FUN_140455660)
undefined8 * FUN_140455660(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTeamDice::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTeamDice::vfunc_3  @1404556b0  [high:rtti-vtable]  (orig: FUN_1404556b0)
void FUN_1404556b0(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  if (param_2 != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                       (*(longlong **)(lVar3 + 0x90),param_1);
    if (plVar4 != (longlong *)0x0) {
      puVar1 = *(undefined4 **)(param_1 + 0x428);
      if (puVar1[2] != 5) {
        if (puVar1[2] == 6) {
          uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087920(uVar5);
          FUN_1402eba40(uVar5,uVar2,*puVar1);
          return;
        }
                    /* WARNING: Could not recover jumptable at 0x00014045575b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        log_InlineLogERROR("CMsgTeamDice::Process, error action: %d");
        return;
      }
      uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar5 = FUN_140087920(uVar5);
      FUN_1402eb8c0(uVar5,uVar2,*puVar1);
    }
  }
  return;
}

// ==== CMsgTeamDice::helper_14047dfa0  @14047dfa0  [medium:callgraph-r2]  (orig: FUN_14047dfa0)
int FUN_14047dfa0(void)

{
  int iVar1;
  
  iVar1 = tq::RandGet(100);
  return iVar1 + 1;
}

// ==== CMsgTeamDice::helper_14047e1e0  @14047e1e0  [medium:callgraph-r3]  (orig: FUN_14047e1e0)
undefined8 FUN_14047e1e0(longlong param_1,longlong *param_2,longlong *param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar2 = FUN_140102870(param_3);
  if (cVar2 == '\0') {
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    cVar2 = FUN_140340de0(param_2,uVar3,1);
    if (cVar2 == '\0') {
      (**(code **)(*param_3 + 8))(param_3);
      (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/teamdice"," CTeamDice::AwardDiceItem, user(%u) can not award item(%u)");
      return 0;
    }
  }
  else {
    uVar3 = FUN_1400fda10(param_3,0x1a,1);
    uVar4 = FUN_1400fda10(param_3,0x6e,1);
    uVar3 = FUN_14033f6b0(param_2,*(undefined4 *)(param_1 + 0x20),uVar3,uVar4,1,1,0);
    plVar5 = (longlong *)FUN_140087d40();
    lVar1 = *plVar5;
    uVar4 = (**(code **)(*param_3 + 8))(param_3);
    (**(code **)(lVar1 + 0x30))(plVar5,uVar4,1,0);
    plVar5 = (longlong *)FUN_140087d40();
    param_3 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,uVar3);
    if (param_3 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
  }
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar6 = FUN_140087920(uVar6);
  FUN_1402e9b10(uVar6,param_2,param_3);
  return 1;
}

// ==== CMsgTeamDice::helper_14047e440  @14047e440  [medium:callgraph-r3]  (orig: FUN_14047e440)
void FUN_14047e440(longlong param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puVar7;
  
  puVar7 = (undefined4 *)(param_1 + 4);
  uVar6 = 2;
  do {
    if (puVar7 == param_2) {
      return;
    }
    uVar5 = 0x7fff;
    uVar3 = rand();
    uVar3 = uVar3 & 0x7fff;
    if (0x7fff < uVar6) {
      do {
        if (uVar5 == 0xffffffff) break;
        uVar4 = rand();
        uVar5 = uVar5 << 0xf | 0x7fff;
        uVar3 = uVar4 & 0x7fff | uVar3 << 0xf;
      } while (uVar5 < uVar6);
    }
    puVar1 = (undefined4 *)(param_1 + ((ulonglong)uVar3 % (ulonglong)uVar6) * 4);
    if (puVar7 != puVar1) {
      uVar2 = *puVar7;
      *puVar7 = *puVar1;
      *puVar1 = uVar2;
    }
    puVar7 = puVar7 + 1;
    uVar6 = uVar6 + 1;
  } while( true );
}

// ==== CMsgTeamDice::helper_14047e900  @14047e900  [medium:callgraph-r2]  (orig: FUN_14047e900)
void FUN_14047e900(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar2 = *(longlong **)(param_1 + 0x28);
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x58);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar4;
          plVar4 = *(longlong **)(param_1 + 0x58);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x28))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar4) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar7 = plVar6[3];
          lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          if (*(longlong *)(lVar3 + 0x90) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar4 = (longlong *)
                   (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))
                             (*(longlong **)(lVar3 + 0x90),(int)lVar7);
          if (plVar4 != (longlong *)0x0) {
            (**(code **)(*plVar4 + 0x150))(plVar4,0x7d3,param_2);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x21) == '\0') break;
          _invalid_parameter_noinfo();
          plVar4 = plVar6;
        }
        plVar4 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar4 + 0x21) != '\0') break;
        cVar1 = *(char *)(*plVar4 + 0x21);
        plVar6 = (longlong *)*plVar4;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x21);
          plVar4 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar4 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar4 + 0x21) != '\0');
    do {
      plVar5 = plVar4;
      plVar4 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar4 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar4 + 0x21) == '\0');
  } while( true );
}

// ==== CMsgTeamDice::helper_14047f5b0  @14047f5b0  [medium:callgraph-r2]  (orig: FUN_14047f5b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14047f5b0(longlong *param_1,char param_2)

{
  undefined8 *puVar1;
  int *piVar2;
  int *piVar3;
  longlong *plVar4;
  char cVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  IStringManager *pIVar9;
  char *pcVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  int iVar15;
  int iVar16;
  bool bVar17;
  undefined1 auStack_a08 [32];
  undefined8 local_9e8;
  int local_9e0;
  char local_9d8;
  int local_9d4;
  int local_9d0;
  longlong local_9c8;
  uint local_9c0;
  longlong *local_9b8 [3];
  int *local_9a0;
  int *local_998;
  undefined8 local_990;
  undefined8 *local_988;
  longlong *local_980;
  undefined4 local_978;
  undefined4 uStack_974;
  undefined4 uStack_970;
  undefined4 uStack_96c;
  undefined8 local_968;
  undefined8 uStack_960;
  undefined8 local_958;
  undefined8 uStack_950;
  undefined4 local_948;
  undefined4 local_944;
  undefined4 local_940;
  undefined4 local_93c;
  undefined4 local_938;
  int local_934;
  undefined8 local_928;
  undefined8 uStack_920;
  undefined8 local_918;
  undefined8 uStack_910;
  longlong *local_908;
  undefined8 local_8f8;
  undefined8 uStack_8f0;
  longlong *local_8e8;
  longlong *local_8e0;
  undefined8 *local_8d8;
  longlong *local_8c8;
  undefined8 local_8b8;
  undefined8 *local_8b0;
  undefined8 *local_8a0;
  undefined4 local_888;
  undefined4 uStack_884;
  undefined4 uStack_880;
  undefined4 uStack_87c;
  undefined4 local_878;
  undefined4 uStack_874;
  undefined4 uStack_870;
  undefined4 uStack_86c;
  undefined1 local_868 [1072];
  char local_438;
  undefined1 local_437 [254];
  undefined1 local_339;
  char local_338;
  undefined1 local_337 [254];
  undefined1 local_239;
  char local_238;
  undefined1 local_237 [254];
  undefined1 local_139;
  char local_138;
  undefined1 local_137 [254];
  undefined1 local_39;
  ulonglong local_38;
  
  local_8b8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_a08;
  plVar14 = DAT_140975b60;
  local_9d8 = param_2;
  local_968 = param_1;
  if (DAT_140975b60 == (longlong *)0x0) {
    local_9e8 = CONCAT44(local_9e8._4_4_,0x3c0);
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar14 = (longlong *)0x0;
  }
  plVar13 = (longlong *)0x0;
  local_9c8 = (**(code **)(*plVar14 + 0x60))();
  if (local_9c8 == 0) {
    return;
  }
  if (param_1[0xc] == 0) {
    FUN_14047eba0(param_1);
    return;
  }
  if (*(int *)((longlong)param_1 + 0x14) == 0) {
    return;
  }
  if (*(int *)((longlong)param_1 + 0x1c) == 0) {
    return;
  }
  local_9d4 = 0;
  local_9d0 = 0;
  local_988 = (undefined8 *)0x0;
  plVar14 = *(longlong **)param_1[0xb];
  puVar1 = (undefined8 *)param_1[5];
  local_958._0_4_ = SUB84(puVar1,0);
  local_958._4_4_ = (undefined4)((ulonglong)puVar1 >> 0x20);
  uStack_950._0_4_ = SUB84(plVar14,0);
  uStack_950._4_4_ = (undefined4)((ulonglong)plVar14 >> 0x20);
  local_978 = (undefined4)local_958;
  uStack_974 = local_958._4_4_;
  uStack_970 = (undefined4)uStack_950;
  uStack_96c = uStack_950._4_4_;
  local_958 = puVar1;
  uStack_950 = plVar14;
  do {
    plVar7 = (longlong *)param_1[0xb];
    local_8d8 = (undefined8 *)param_1[5];
    if ((puVar1 == (undefined8 *)0x0) || (puVar1 != local_8d8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar14 == plVar7) {
      plVar14 = *(longlong **)param_1[0xb];
      puVar1 = (undefined8 *)param_1[5];
      local_928._0_4_ = SUB84(puVar1,0);
      local_928._4_4_ = (undefined4)((ulonglong)puVar1 >> 0x20);
      uStack_920._0_4_ = SUB84(plVar14,0);
      uStack_920._4_4_ = (undefined4)((ulonglong)plVar14 >> 0x20);
      local_978 = (undefined4)local_928;
      uStack_974 = local_928._4_4_;
      uStack_970 = (undefined4)uStack_920;
      uStack_96c = uStack_920._4_4_;
      local_9c0 = 0;
      plVar7 = plVar13;
      local_928 = puVar1;
      uStack_920 = plVar14;
      break;
    }
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar7 = plVar13;
    }
    else {
      plVar7 = (longlong *)*puVar1;
    }
    if (plVar14 == (longlong *)plVar7[6]) {
      _invalid_parameter_noinfo();
    }
    lVar12 = plVar14[3];
    local_980 = (longlong *)CONCAT44(local_980._4_4_,(int)lVar12);
    uVar6 = FUN_140008520((int)param_1[1]);
    plVar7 = (longlong *)FUN_140087650(uVar6);
    puVar8 = (undefined8 *)(**(code **)(*plVar7 + 0x98))(plVar7);
    local_958 = puVar8;
    if (puVar8 != (undefined8 *)0x0) {
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar7 = plVar13;
      }
      else {
        plVar7 = (longlong *)*puVar1;
      }
      if (plVar14 == (longlong *)plVar7[6]) {
        _invalid_parameter_noinfo();
      }
      iVar16 = *(int *)((longlong)plVar14 + 0x1c);
      iVar15 = (int)lVar12;
      if (iVar16 == 0) {
        if (local_9d8 == '\0') {
          return;
        }
        local_138 = '\0';
        memset(local_137,0,0xff);
        pIVar9 = theInstance();
        uVar6 = FUN_140100430(local_9c8,0x65);
        (**(code **)(puVar8[2] + 0x18))(puVar8 + 2);
        pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_TEAM_DICE_ABANDOM");
        local_9e8 = uVar6;
        _snprintf(&local_138,0x100,pcVar10);
        param_1 = local_968;
        local_39 = 0;
        FUN_14047e900(local_968);
        puVar8 = local_958;
        iVar15 = (int)local_980;
      }
      if (local_9d4 < iVar16) {
        local_9d4 = iVar16;
        local_9d0 = iVar15;
        local_988 = puVar8;
      }
    }
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar14 + 0x21) == '\0') {
      plVar7 = plVar14;
      plVar11 = (longlong *)plVar14[2];
      if (*(char *)(plVar14[2] + 0x21) == '\0') {
        do {
          plVar14 = plVar11;
          plVar11 = (longlong *)*plVar14;
          local_8e0 = plVar14;
        } while (*(char *)(*plVar14 + 0x21) == '\0');
      }
      else {
        do {
          plVar14 = (longlong *)plVar7[1];
          if (*(char *)((longlong)plVar14 + 0x21) != '\0') break;
          bVar17 = plVar7 == (longlong *)plVar14[2];
          plVar7 = plVar14;
        } while (bVar17);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
LAB_14047f920:
  plVar11 = (longlong *)param_1[0xb];
  local_8a0 = (undefined8 *)param_1[5];
  if ((puVar1 == (undefined8 *)0x0) || (puVar1 != local_8a0)) {
    _invalid_parameter_noinfo();
  }
  if (plVar14 != plVar11) {
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar13;
    }
    else {
      plVar11 = (longlong *)*puVar1;
    }
    if (plVar14 == (longlong *)plVar11[6]) {
      _invalid_parameter_noinfo();
    }
    uVar6 = FUN_140008520((int)param_1[1]);
    plVar11 = (longlong *)FUN_140087650(uVar6);
    lVar12 = (**(code **)(*plVar11 + 0x98))(plVar11);
    if (lVar12 != 0) {
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar11 = plVar13;
      }
      else {
        plVar11 = (longlong *)*puVar1;
      }
      if (plVar14 == (longlong *)plVar11[6]) {
        _invalid_parameter_noinfo();
      }
      iVar16 = *(int *)((longlong)plVar14 + 0x1c);
      if (iVar16 != 0) {
        local_438 = '\0';
        memset(local_437,0,0xff);
        pIVar9 = theInstance();
        uVar6 = FUN_140100430(local_9c8,0x65);
        (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x18))(lVar12 + 0x10);
        pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_TEAM_DICE_POINT");
        local_9e8 = uVar6;
        local_9e0 = iVar16;
        _snprintf(&local_438,0x100,pcVar10);
        param_1 = local_968;
        local_339 = 0;
        FUN_14047e900(local_968);
        local_9c0 = local_9c0 + 1;
        plVar7 = (longlong *)(ulonglong)local_9c0;
      }
    }
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar14 + 0x21) == '\0') {
      plVar11 = plVar14;
      plVar4 = (longlong *)plVar14[2];
      if (*(char *)(plVar14[2] + 0x21) == '\0') {
        do {
          plVar14 = plVar4;
          plVar4 = (longlong *)*plVar14;
          local_8e8 = plVar14;
        } while (*(char *)(*plVar14 + 0x21) == '\0');
      }
      else {
        do {
          plVar14 = (longlong *)plVar11[1];
          if (*(char *)((longlong)plVar14 + 0x21) != '\0') break;
          bVar17 = plVar11 == (longlong *)plVar14[2];
          plVar11 = plVar14;
        } while (bVar17);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    goto LAB_14047f920;
  }
  if ((int)plVar7 == 0) {
    local_238 = (char)plVar7;
    memset(local_237,0,0xff);
    pIVar9 = theInstance();
    FUN_140100430(local_9c8,0x65);
    pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_TEAM_DICE_ALL_GIVEUP");
    _snprintf(&local_238,0x100,pcVar10);
    local_139 = 0;
    FUN_14047e900(param_1,&local_238);
  }
  iVar16 = local_9d0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  if (local_9d0 != 0) {
    local_980 = operator_new(8);
    plVar14 = local_968;
    local_9b8[0] = plVar13;
    if (local_980 != (longlong *)0x0) {
      *local_980 = (longlong)local_9b8;
      local_9b8[0] = local_980;
    }
    local_9a0 = (int *)0x0;
    local_998 = (int *)0x0;
    local_990 = 0;
    plVar7 = *(longlong **)param_1[0xb];
    puVar1 = (undefined8 *)param_1[5];
    local_918._0_4_ = SUB84(puVar1,0);
    local_918._4_4_ = (undefined4)((ulonglong)puVar1 >> 0x20);
    uStack_910._0_4_ = SUB84(plVar7,0);
    uStack_910._4_4_ = (undefined4)((ulonglong)plVar7 >> 0x20);
    local_978 = (undefined4)local_918;
    uStack_974 = local_918._4_4_;
    uStack_970 = (undefined4)uStack_910;
    uStack_96c = uStack_910._4_4_;
    local_958 = local_980;
    local_918 = puVar1;
    uStack_910 = plVar7;
LAB_14047fc11:
    plVar11 = (longlong *)plVar14[0xb];
    local_8b0 = (undefined8 *)plVar14[5];
    if ((puVar1 == (undefined8 *)0x0) || (puVar1 != local_8b0)) {
      _invalid_parameter_noinfo();
    }
    piVar3 = local_998;
    if (plVar7 != plVar11) {
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar11 = plVar13;
      }
      else {
        plVar11 = (longlong *)*puVar1;
      }
      if (plVar7 == (longlong *)plVar11[6]) {
        _invalid_parameter_noinfo();
      }
      lVar12 = plVar7[3];
      local_980 = (longlong *)CONCAT44(local_980._4_4_,(int)lVar12);
      uVar6 = FUN_140008520((int)plVar14[1]);
      plVar11 = (longlong *)FUN_140087650(uVar6);
      lVar12 = (**(code **)(*plVar11 + 0x98))(plVar11,(int)lVar12);
      if (lVar12 != 0) {
        if (puVar1 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar11 = plVar13;
        }
        else {
          plVar11 = (longlong *)*puVar1;
        }
        if (plVar7 == (longlong *)plVar11[6]) {
          _invalid_parameter_noinfo();
        }
        if (local_9d4 == *(int *)((longlong)plVar7 + 0x1c)) {
          FUN_140037fe0(local_9b8,&local_980);
        }
      }
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x21) == '\0') {
        plVar11 = plVar7;
        plVar4 = (longlong *)plVar7[2];
        if (*(char *)(plVar7[2] + 0x21) == '\0') {
          do {
            plVar7 = plVar4;
            plVar4 = (longlong *)*plVar7;
            local_908 = plVar7;
          } while (*(char *)(*plVar7 + 0x21) == '\0');
        }
        else {
          do {
            plVar7 = (longlong *)plVar11[1];
            if (*(char *)((longlong)plVar7 + 0x21) != '\0') break;
            bVar17 = plVar11 == (longlong *)plVar7[2];
            plVar11 = plVar7;
          } while (bVar17);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_14047fc11;
    }
    if (1 < (ulonglong)((longlong)local_998 - (longlong)local_9a0 >> 2)) {
      local_968 = (longlong *)0x0;
      if (local_998 < local_9a0) {
        _invalid_parameter_noinfo();
      }
      piVar2 = local_9a0;
      plVar7 = local_9b8[0];
      local_968 = local_9b8[0];
      uStack_960 = piVar3;
      local_968._0_4_ = SUB84(local_9b8[0],0);
      local_968._4_4_ = (undefined4)((ulonglong)local_9b8[0] >> 0x20);
      uStack_960._0_4_ = SUB84(piVar3,0);
      uStack_960._4_4_ = (undefined4)((ulonglong)piVar3 >> 0x20);
      local_888 = (undefined4)local_968;
      uStack_884 = local_968._4_4_;
      uStack_880 = (undefined4)uStack_960;
      uStack_87c = uStack_960._4_4_;
      local_8f8 = (longlong *)0x0;
      local_968 = plVar7;
      uStack_960 = piVar3;
      if (local_998 < local_9a0) {
        _invalid_parameter_noinfo();
      }
      local_8f8 = local_9b8[0];
      plVar11 = local_8f8;
      uStack_8f0 = piVar2;
      local_8f8._0_4_ = SUB84(local_9b8[0],0);
      local_8f8._4_4_ = (undefined4)((ulonglong)local_9b8[0] >> 0x20);
      uStack_8f0._0_4_ = SUB84(piVar2,0);
      uStack_8f0._4_4_ = (undefined4)((ulonglong)piVar2 >> 0x20);
      local_878 = (undefined4)local_8f8;
      uStack_874 = local_8f8._4_4_;
      uStack_870 = (undefined4)uStack_8f0;
      uStack_86c = uStack_8f0._4_4_;
      local_8f8 = plVar11;
      uStack_8f0 = piVar2;
      if ((local_9b8[0] == (longlong *)0x0) || (local_9b8[0] != plVar7)) {
        _invalid_parameter_noinfo();
      }
      if (piVar2 != piVar3) {
        FUN_14047e440(piVar2,piVar3,0);
      }
      piVar3 = local_9a0;
      local_8c8 = (longlong *)0x0;
      if (local_998 < local_9a0) {
        _invalid_parameter_noinfo();
      }
      local_8c8 = local_9b8[0];
      if (local_9b8[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        plVar13 = (longlong *)*local_9b8[0];
      }
      if ((int *)plVar13[4] <= piVar3) {
        _invalid_parameter_noinfo();
      }
      iVar16 = *piVar3;
      local_9d0 = iVar16;
      uVar6 = FUN_140008520((int)plVar14[1]);
      plVar13 = (longlong *)FUN_140087650(uVar6);
      local_988 = (undefined8 *)(**(code **)(*plVar13 + 0x98))(plVar13,iVar16);
      if (local_988 == (undefined8 *)0x0) {
        local_9e8 = CONCAT44(local_9e8._4_4_,0x1da);
        log_InlineLogERROR(&DAT_1406d9c10);
        if (local_9a0 != (int *)0x0) {
          operator_delete(local_9a0);
        }
        local_9a0 = (int *)0x0;
        local_998 = (int *)0x0;
        local_990 = 0;
        operator_delete(local_9b8[0]);
        return;
      }
    }
    puVar1 = local_988;
    local_93c = 0;
    local_938 = 0;
    local_948 = *(undefined4 *)((longlong)plVar14 + 0x1c);
    local_944 = (undefined4)plVar14[3];
    local_940 = 4;
    local_934 = iVar16;
    FUN_140455550(local_868);
    cVar5 = FUN_140455600(local_868);
    if (cVar5 != '\0') {
      FUN_14047e580(plVar14);
    }
    local_338 = '\0';
    memset(local_337,0,0xff);
    pIVar9 = theInstance();
    plVar13 = puVar1 + 2;
    uVar6 = FUN_140100430(local_9c8,0x65);
    (**(code **)(*plVar13 + 0x18))(plVar13);
    pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_TEAM_DICE_RESULT");
    local_9e8 = uVar6;
    _snprintf(&local_338,0x100,pcVar10);
    local_239 = 0;
    FUN_14047e900(plVar14,&local_338);
    cVar5 = FUN_14047e1e0(plVar14,local_988,local_9c8);
    if (cVar5 == '\0') {
      (**(code **)(*plVar13 + 0x18))(plVar13);
      log_InlineLogERROR("CTeamDice::Final, user:%s(%u) can not award item");
    }
    *(undefined4 *)((longlong)plVar14 + 0x1c) = 0;
    FUN_1404555a0(local_868);
    if (local_9a0 != (int *)0x0) {
      operator_delete(local_9a0);
    }
    local_9a0 = (int *)0x0;
    local_998 = (int *)0x0;
    local_990 = 0;
    operator_delete(local_9b8[0]);
  }
  return;
}

// ==== CMsgTeamDice::helper_1404804f0  @1404804f0  [medium:callgraph-r1]  (orig: FUN_1404804f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1404804f0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  ulong uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 *puVar8;
  IStringManager *pIVar9;
  char *_Format;
  undefined1 auStack_5e8 [32];
  undefined8 local_5c8;
  undefined4 local_5b8 [2];
  undefined4 local_5b0;
  undefined4 local_5ac;
  undefined4 local_5a8;
  undefined4 local_5a4;
  undefined4 local_5a0;
  undefined4 local_59c;
  ulonglong local_598;
  longlong local_590;
  ulonglong local_588;
  undefined8 local_578;
  undefined1 local_568 [1072];
  char local_138;
  undefined1 local_137 [254];
  undefined1 local_39;
  ulonglong local_38;
  
  local_578 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5e8;
  local_5b8[0] = param_2;
  uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar5 = (longlong *)FUN_140087650(uVar4);
  lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
  if (((lVar6 == 0) || (*(int *)(param_1 + 0x14) == 0)) ||
     (uVar2 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 0x10)) <= uVar2 / 1000)) {
    return 0;
  }
  plVar5 = (longlong *)FUN_140118320();
  if (plVar5 == (longlong *)0x0) {
    return 0;
  }
  cVar1 = (**(code **)(*plVar5 + 0x58))(plVar5,*(undefined4 *)(param_1 + 0x18),param_2);
  if (cVar1 != '\0') {
    FUN_14025cee0(param_1 + 0x28,&local_598,local_5b8);
    lVar7 = *(longlong *)(param_1 + 0x58);
    local_588 = *(ulonglong *)(param_1 + 0x28);
    if ((local_598 == 0) || (local_598 != local_588)) {
      _invalid_parameter_noinfo();
    }
    if (local_590 != lVar7) {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_5c8 = CONCAT44(local_5c8._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = (longlong *)0x0;
      }
      lVar7 = (**(code **)(*plVar5 + 0x60))(plVar5,*(undefined4 *)(param_1 + 0x1c));
      if (lVar7 != 0) {
        uVar3 = FUN_14047dfa0(param_1);
        puVar8 = (undefined4 *)FUN_14047f020(param_1 + 0x28);
        *puVar8 = uVar3;
        local_138 = '\0';
        memset(local_137,0,0xff);
        pIVar9 = theInstance();
        uVar4 = FUN_140100430(lVar7,0x65);
        (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x18))(lVar6 + 0x10);
        _Format = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_TEAM_DICE_ACCEPT");
        local_5c8 = uVar4;
        _snprintf(&local_138,0x100,_Format);
        local_39 = 0;
        FUN_14047e900(param_1,&local_138);
        local_5a0 = 0;
        local_59c = 0;
        local_5b0 = *(undefined4 *)(param_1 + 0x1c);
        local_5ac = *(undefined4 *)(param_1 + 0x18);
        local_5a8 = 3;
        local_5a4 = uVar3;
        FUN_140455550(local_568);
        cVar1 = FUN_140455600(local_568,&local_5b0);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))(lVar6 + 0x10,local_568);
        }
        FUN_14047f5b0(param_1,0);
        FUN_1404555a0(local_568);
        return 1;
      }
      return 0;
    }
    return 0;
  }
  return 0;
}

