// ==== CMailMgr::DeleteItemAndStatus  @1400d6670  [high:log-string]  (orig: FUN_1400d6670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400d6670(void)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_448 [32];
  undefined8 local_428;
  char local_418;
  undefined1 local_417 [1022];
  undefined1 local_19;
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  plVar2 = (longlong *)InstanceGet();
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  _snprintf(&local_418,0x3ff,"DELETE FROM cq_item WHERE id=%u LIMIT 1");
  local_19 = 0;
  cVar1 = (**(code **)(*plVar2 + 0x30))(plVar2,&local_418,1);
  if (cVar1 == '\0') {
    log_InlineLogERROR("CMailMgr::DeleteItemAndStatus(),Delete Mail Item[%d] Failed");
  }
  memset(&local_418,0,0x400);
  _snprintf(&local_418,0x3ff,"DELETE FROM cq_itemstatus WHERE iditem=%u LIMIT 1");
  local_19 = 0;
  cVar1 = (**(code **)(*plVar2 + 0x30))(plVar2,&local_418,1);
  if (cVar1 == '\0') {
    log_InlineLogERROR("CMailMgr::DeleteItemAndStatus(),Delete Mail Item[%d] Status Failed");
  }
  return;
}

// ==== CMailMgr::helper_1400d6790  @1400d6790  [medium:callgraph-r0]  (orig: FUN_1400d6790)
int FUN_1400d6790(void)

{
  tm *ptVar1;
  __time64_t local_res10 [3];
  
  local_res10[0] = _time64((__time64_t *)0x0);
  ptVar1 = _localtime64(local_res10);
  if (ptVar1 == (tm *)0x0) {
    return 0;
  }
  return (((((ptVar1->tm_year + 0x76c) % 100) * 100 + 1 + ptVar1->tm_mon) * 100 + ptVar1->tm_mday) *
          100 + ptVar1->tm_hour) * 100 + ptVar1->tm_min;
}

// ==== CMailMgr::DestroyMailItem  @1400d7030  [high:log-string]  (orig: FUN_1400d7030)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1400d7030(undefined8 param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar4 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_2);
  uVar3 = 0;
  if (lVar2 != 0) {
    FUN_1400fda10(lVar2,0xc,1);
    FUN_1400fda10(lVar2,0x13,1);
    FUN_1400ffda0(lVar2);
    FUN_1400fda10(lVar2,0xf,1);
    FUN_1400fda10(lVar2,0xe,1);
    FUN_1400fda10(lVar2,0x10,1);
    FUN_1400fda10(lVar2,5,1);
    FUN_1400fda10(lVar2,4,1);
    FUN_1400fda10(lVar2,9,1);
    FUN_1400fda10(lVar2,8,1);
    FUN_1400fda10(lVar2,1,1);
    uVar3 = FUN_140100430(lVar2,0x65);
    tq::MyLogSave("gmlog/mail",
                  "Delete Item Because of Mail Expiration Date, item id[%d] name[%s] type[%u] gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%u], dec_dmg[%u] add_life[%u] accumulate[%d] specialflag[%d]"
                  ,(ulonglong)param_2,uVar3);
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar4 = (longlong *)0x0;
    }
    cVar1 = (**(code **)(*plVar4 + 0x30))(plVar4,param_2,1,0);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","ItemMgr()->DestroyItem(idItem)",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mail\\src\\mailmgr.cpp"
                        );
      log_InlineLogERROR("CMailMgr::DestroyMailItem(), Destroy Mail Item[%d] Failed",
                         (ulonglong)param_2);
      uVar3 = 0;
    }
    else {
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CMailMgr::helper_1400d75d0  @1400d75d0  [medium:callgraph-r1]  (orig: FUN_1400d75d0)
void FUN_1400d75d0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x61) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMailMgr::helper_1400d7740  @1400d7740  [medium:callgraph-r1]  (orig: FUN_1400d7740)
void FUN_1400d7740(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMailMgr::helper_1400d7a10  @1400d7a10  [medium:callgraph-r1]  (orig: FUN_1400d7a10)
void FUN_1400d7a10(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x61) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x61) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x61);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x61);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x61);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x61);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400d7a34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMailMgr::helper_1400d7b10  @1400d7b10  [medium:callgraph-r1]  (orig: FUN_1400d7b10)
void FUN_1400d7b10(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400d7b34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMailMgr::helper_1400d8cb0  @1400d8cb0  [medium:callgraph-r1]  (orig: FUN_1400d8cb0)
void FUN_1400d8cb0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x61) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMailMgr::helper_1400d8d90  @1400d8d90  [medium:callgraph-r1]  (orig: FUN_1400d8d90)
void FUN_1400d8d90(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMailMgr::helper_1400db220  @1400db220  [medium:callgraph-r0]  (orig: FUN_1400db220)
longlong * FUN_1400db220(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x61) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x61) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMailMgr::helper_1400db4a0  @1400db4a0  [medium:callgraph-r0]  (orig: FUN_1400db4a0)
undefined8 * FUN_1400db4a0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400d7b10(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400db68c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400db68c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1400d8d90(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1400d7740(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1400d8d90(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1400d7740(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1400d8d90(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1400d7740(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMailMgr::helper_1400db860  @1400db860  [medium:callgraph-r0]  (orig: FUN_1400db860)
longlong * FUN_1400db860(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMailMgr::helper_1400dbab0  @1400dbab0  [medium:callgraph-r1]  (orig: FUN_1400dbab0)
longlong * FUN_1400dbab0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400d9e60(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400db4a0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMailMgr::Init  @1400dd970  [high:log-string]  (orig: FUN_1400dd970)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1400dd970(longlong param_1)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  ulong uVar6;
  longlong *plVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *plVar16;
  ulonglong uVar17;
  longlong lVar18;
  longlong *local_res10;
  longlong *local_res18;
  longlong *local_res20;
  uint local_a8;
  longlong *local_98 [3];
  longlong *local_80;
  longlong *local_78;
  undefined8 local_70;
  longlong *local_68;
  longlong *local_60;
  longlong *local_58;
  longlong *local_50;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  local_res10 = operator_new(8);
  if (local_res10 == (longlong *)0x0) {
    local_98[0] = (longlong *)0x0;
  }
  else {
    *local_res10 = (longlong)local_98;
    local_98[0] = local_res10;
  }
  local_80 = (longlong *)0x0;
  local_78 = (longlong *)0x0;
  local_70 = 0;
  local_res18 = local_res10;
  plVar7 = (longlong *)InstanceGet();
  plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,"SELECT * FROM cq_mail",2);
  local_res18 = plVar7;
  if (plVar7 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",&DAT_1406efba4,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mail\\src\\mailmgr.cpp"
                      );
    if (local_80 != (longlong *)0x0) {
      operator_delete(local_80);
    }
    local_80 = (longlong *)0x0;
    local_78 = (longlong *)0x0;
    local_70 = 0;
    operator_delete(local_98[0]);
    uVar8 = 0;
  }
  else {
    local_a8 = 0;
    while( true ) {
      uVar9 = (**(code **)(*plVar7 + 0x40))(plVar7);
      if (uVar9 <= local_a8) break;
      (**(code **)(*plVar7 + 0x30))(plVar7,(ulonglong)local_a8);
      plVar10 = (longlong *)(**(code **)(*plVar7 + 0x38))(plVar7);
      local_res10 = plVar10;
      if (plVar10 != (longlong *)0x0) {
        plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,8);
        uVar2 = (**(code **)(*plVar11 + 0x50))(plVar11);
        if (uVar2 == 0) {
          log_InlineLogERROR("CMailMgr::Init(),unExpirationDate is wrong data");
          (**(code **)*plVar10)(plVar10,1);
          local_res10 = (longlong *)0x0;
        }
        else {
          uVar3 = FUN_1400d6790(param_1);
          if (uVar3 == 0) {
            log_InlineLogERROR("CMailMgr::Init(),unCurrentDate is wrong data");
            (**(code **)*plVar10)(plVar10,1);
            local_res10 = (longlong *)0x0;
          }
          else if (uVar3 < uVar2) {
            (**(code **)*plVar10)(plVar10,1);
            local_res10 = (longlong *)0x0;
          }
          else {
            FUN_140019370(local_98,&local_res10);
          }
        }
      }
      local_a8 = local_a8 + 1;
    }
    (**(code **)*plVar7)();
    plVar7 = local_80;
    local_58 = local_80;
    local_68 = (longlong *)0x0;
    if (local_78 < local_80) {
      _invalid_parameter_noinfo();
    }
    local_68 = local_98[0];
    plVar10 = local_98[0];
    while( true ) {
      plVar11 = local_78;
      lVar18 = 0;
      local_50 = (longlong *)0x0;
      local_60 = plVar7;
      if (local_78 < local_80) {
        _invalid_parameter_noinfo();
      }
      local_50 = local_98[0];
      if ((plVar10 == (longlong *)0x0) || (plVar10 != local_98[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar11) break;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar18 = *plVar10;
      }
      if (*(longlong **)(lVar18 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar11 = (longlong *)*plVar7;
      if (plVar11 != (longlong *)0x0) {
        plVar7 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,9);
        iVar4 = (**(code **)(*plVar7 + 0x40))(plVar7);
        if (iVar4 != 0) {
          FUN_1400d6670(param_1,iVar4);
        }
        local_res10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,10);
        local_res18 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,9);
        local_res20 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,8);
        plVar7 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,7);
        plVar10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,6);
        plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,5);
        plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,4);
        plVar14 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,3);
        plVar15 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,2);
        plVar16 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,1);
        local_50 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,0);
        bVar1 = (**(code **)(*local_res10 + 0x20))(local_res10);
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,(uint)bVar1);
        uVar5 = (**(code **)(*local_res18 + 0x50))(local_res18);
        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar5);
        uVar5 = (**(code **)(*local_res20 + 0x50))(local_res20);
        local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar5);
        (**(code **)(*plVar7 + 0x40))(plVar7);
        (**(code **)(*plVar10 + 0x50))(plVar10);
        (**(code **)(*plVar12 + 0x50))(plVar12);
        (**(code **)(*plVar13 + 0x78))(plVar13);
        (**(code **)(*plVar14 + 0x78))(plVar14);
        (**(code **)(*plVar15 + 0x78))(plVar15);
        uVar9 = (**(code **)(*plVar16 + 0x50))(plVar16);
        uVar17 = (**(code **)(*local_50 + 0x50))(local_50);
        tq::MyLogSave("gmlog/mail",
                      "Delete Expired Mail Success| idMial[%u] idReceiver[%u] szSenderName[%s] szTitle[%s] szContent[%s] unMoney[%u]  unEMoney[%u] Action[%u] ExpData[%u] idItem[%u] RcdType[%u]"
                      ,uVar17 & 0xffffffff,uVar9 & 0xffffffff);
        (**(code **)(*plVar11 + 0x40))(plVar11,1);
        (**(code **)*plVar11)(plVar11,1);
        plVar7 = local_58;
        plVar10 = local_68;
      }
      lVar18 = 0;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar18 = *plVar10;
      }
      if (*(longlong **)(lVar18 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar7 = plVar7 + 1;
      local_58 = plVar7;
    }
    *(undefined4 *)(param_1 + 0x44) = 0x3c;
    uVar6 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x48) = uVar6 / 1000;
    if (local_80 != (longlong *)0x0) {
      operator_delete(local_80);
    }
    local_80 = (longlong *)0x0;
    local_78 = (longlong *)0x0;
    local_70 = 0;
    operator_delete(local_98[0]);
    uVar8 = 1;
  }
  return uVar8;
}

// ==== CMailMgr::helper_1400de830  @1400de830  [medium:callgraph-r0]  (orig: FUN_1400de830)
undefined8 * FUN_1400de830(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong local_b8;
  undefined8 uStack_b0;
  longlong local_a8;
  undefined8 *puStack_a0;
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  undefined1 local_50 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x61) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400d7a10(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x61) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xc;
        plVar8 = plVar8 + 0xc;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400dea1d;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x61);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x61);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400dea1d:
  if ((char)plVar2[0xc] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xc] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1400d8cb0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(*plVar9 + 0x60) != '\x01') || (*(char *)(plVar9[2] + 0x60) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x60) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1400d75d0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(plVar9[2] + 0x60) = 1;
              FUN_1400d8cb0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        else {
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1400d75d0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(plVar9[2] + 0x60) != '\x01') || (*(char *)(*plVar9 + 0x60) != '\x01')) {
              if (*(char *)(*plVar9 + 0x60) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1400d8cb0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(*plVar9 + 0x60) = 1;
              FUN_1400d75d0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xc) = 1;
  }
  plVar9 = plVar2 + 4;
  puStack_a0 = (undefined8 *)plVar2[10];
  local_b8 = *plVar9;
  uStack_b0 = *puStack_a0;
  local_a8 = local_b8;
  FUN_1400dbab0(plVar9,local_50,&local_b8,&local_a8);
  operator_delete((void *)plVar2[10]);
  plVar2[10] = 0;
  plVar2[0xb] = 0;
  operator_delete((void *)*plVar9);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMailMgr::DelExpirationDateMail  @1400df530  [high:log-string]  (orig: FUN_1400df530)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400df530(longlong *param_1,int param_2,int param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong lVar13;
  longlong lVar14;
  undefined1 auStack_568 [32];
  undefined8 local_548;
  undefined8 local_540;
  undefined8 local_538;
  undefined4 local_530;
  undefined4 local_528;
  undefined4 local_520;
  undefined4 local_518;
  int local_510;
  int local_508;
  int local_4f8;
  int local_4f4;
  int local_4f0;
  int local_4ec;
  undefined4 local_4e8;
  longlong *local_4d8;
  longlong lStack_4d0;
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  longlong *local_4b8;
  longlong *local_4a8;
  longlong *local_498;
  longlong lStack_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  local_4f8 = param_2;
  local_4f4 = param_3;
  local_4f0 = param_2;
  local_4ec = param_3;
  local_4a8 = param_1;
  if (param_2 == 0) {
    local_548 = CONCAT44(local_548._4_4_,0x18d);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_548 = CONCAT44(local_548._4_4_,0x191);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400db220(param_1,&local_4c8,&local_4f8);
    lVar13 = param_1[6];
    lVar14 = 0;
    local_4d8 = (longlong *)*param_1;
    plVar1 = (longlong *)CONCAT44(uStack_4c4,local_4c8);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_4d8)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = CONCAT44(uStack_4bc,uStack_4c0);
    if (lVar2 != lVar13) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = lVar14;
      }
      else {
        lVar13 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1400db860(lVar2 + 0x20,&local_4d8,&local_4f4);
      plVar1 = local_4d8;
      lVar13 = *(longlong *)(lVar2 + 0x50);
      local_4b8 = *(longlong **)(lVar2 + 0x20);
      if ((local_4d8 == (longlong *)0x0) || (local_4d8 != local_4b8)) {
        _invalid_parameter_noinfo();
      }
      lVar2 = lStack_4d0;
      if (lStack_4d0 != lVar13) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar14 = *plVar1;
        }
        if (lVar2 == *(longlong *)(lVar14 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar13 = *(longlong *)(lVar2 + 0x20);
        local_4b8 = (longlong *)lVar13;
        if (lVar13 == 0) {
          local_548 = CONCAT44(local_548._4_4_,0x19d);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar5 = FUN_14035ad90(lVar13,9);
          if (iVar5 != 0) {
            cVar4 = FUN_1400d7030(param_1,iVar5);
            if (cVar4 == '\0') {
              log_InlineLogERROR("CMailMgr::DelExpirationDateMail(), Destroy Mail Item[%d] Failed");
            }
          }
          local_4f4 = FUN_14035ad90(lVar13,10);
          local_4f8 = FUN_14035ad90(lVar13,9);
          local_4e8 = FUN_14035ad90(lVar13,8);
          uVar6 = FUN_14035ad90(lVar13,7);
          uVar7 = FUN_14035ad90(lVar13,6);
          uVar8 = FUN_14035ad90(lVar13,5);
          uVar9 = FUN_14035ae90(lVar13,4);
          uVar10 = FUN_14035ae90(lVar13,3);
          uVar11 = FUN_14035ae90(lVar13,2);
          FUN_14035ad90(lVar13,1);
          FUN_14035ad90(local_4b8,0);
          local_508 = local_4f4;
          local_510 = local_4f8;
          local_518 = local_4e8;
          local_548 = uVar11;
          local_540 = uVar10;
          local_538 = uVar9;
          local_530 = uVar8;
          local_528 = uVar7;
          local_520 = uVar6;
          tq::MyLogSave("gmlog/mail",
                        "Delete Expired Mail Success| idMial[%u] idReceiver[%u] szSenderName[%s] szTitle[%s] szContent[%s] unMoney[%u]  unEMoney[%u] Action[%u] ExpData[%u] idItem[%u] RcdType[%u]"
                       );
          plVar1 = local_4b8;
          FUN_14035b730(local_4b8);
          local_498 = local_4d8;
          lStack_490 = lStack_4d0;
          FUN_1400db4a0(CONCAT44(uStack_4bc,uStack_4c0) + 0x20,&local_4d8,&local_498);
          plVar3 = local_4a8;
          uVar9 = FUN_140008520((int)local_4a8[8]);
          plVar12 = (longlong *)FUN_140087650(uVar9);
          lVar13 = (**(code **)(*plVar12 + 0x98))(plVar12,local_4f0);
          if (lVar13 != 0) {
            FUN_14035c460(local_478);
            cVar4 = FUN_14035c520(local_478,local_4ec,2);
            if (cVar4 != '\0') {
              (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x350))
                        ((longlong *)(lVar13 + 0x10),local_478);
            }
            FUN_14035c4b0(local_478);
          }
          if (*(longlong *)(CONCAT44(uStack_4bc,uStack_4c0) + 0x58) == 0) {
            FUN_1400de830(plVar3,&local_498,&local_4c8);
            if (lVar13 != 0) {
              FUN_14035c930(local_478);
              cVar4 = FUN_14035c9f0(local_478,2);
              if (cVar4 != '\0') {
                (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x350))
                          ((longlong *)(lVar13 + 0x10),local_478);
              }
              FUN_14035c980(local_478);
            }
          }
          FUN_14035b7a0(plVar1);
        }
      }
    }
  }
  return;
}

// ==== CMailMgr::helper_14035ad90  @14035ad90  [medium:callgraph-r0]  (orig: FUN_14035ad90)
undefined8 FUN_14035ad90(longlong *param_1,uint param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (param_2 < 0xb) {
    if ((longlong *)*param_1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*(longlong *)*param_1 + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x00014035ade2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
      return uVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMailMgr::helper_14035ae90  @14035ae90  [medium:callgraph-r0]  (orig: FUN_14035ae90)
undefined1 * FUN_14035ae90(longlong *param_1,uint param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  if (param_2 < 0xb) {
    if ((longlong *)*param_1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*(longlong *)*param_1 + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x00014035aee7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x78))(plVar1);
      return puVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return &DAT_1406dd892;
}

// ==== CMailMgr::helper_14035b730  @14035b730  [medium:callgraph-r0]  (orig: FUN_14035b730)
undefined8 FUN_14035b730(longlong *param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)*param_1;
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    (**(code **)(*plVar1 + 0x40))(plVar1,0);
    puVar2 = (undefined8 *)*param_1;
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
      *param_1 = 0;
    }
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CMailMgr::helper_14035b7a0  @14035b7a0  [medium:callgraph-r0]  (orig: FUN_14035b7a0)
undefined8 FUN_14035b7a0(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  
  plVar1 = (longlong *)*param_1;
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x38))(plVar1,0,param_3,param_4,0xfffffffffffffffe);
    puVar2 = (undefined8 *)*param_1;
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
      *param_1 = 0;
    }
  }
  if ((DAT_140976060 & 1) == 0) {
    DAT_140976060 = DAT_140976060 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976058,"CMail");
    atexit((_func_5014 *)&LAB_1406d6a90);
  }
  CMyHeap::Free((CMyHeap *)&DAT_140976058,param_1);
  return 0;
}

// ==== CMailMgr::helper_14035c460  @14035c460  [medium:callgraph-r0]  (orig: FUN_14035c460)
undefined8 * FUN_14035c460(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = mail::CMsgMailOperation::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMailMgr::helper_14035c4b0  @14035c4b0  [medium:callgraph-r0]  (orig: FUN_14035c4b0)
void FUN_14035c4b0(undefined8 *param_1)

{
  *param_1 = mail::CMsgMailOperation::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMailMgr::helper_14035c520  @14035c520  [medium:callgraph-r0]  (orig: FUN_14035c520)
undefined8 FUN_14035c520(longlong param_1,undefined4 param_2,undefined2 param_3)

{
  undefined2 *puVar1;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0xc) = 8;
  *(undefined4 *)(param_1 + 8) = 0x415;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *puVar1 = param_3;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMailMgr::helper_14035c930  @14035c930  [medium:callgraph-r0]  (orig: FUN_14035c930)
undefined8 * FUN_14035c930(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = mail::CMsgMailNotify::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMailMgr::helper_14035c980  @14035c980  [medium:callgraph-r0]  (orig: FUN_14035c980)
void FUN_14035c980(undefined8 *param_1)

{
  *param_1 = mail::CMsgMailNotify::vftable;
  FUN_1402b55f0();
  return;
}

