// ==== CMsgIPad::ctor_or_dtor  @1403865d0  [high:vtable-assign]  (orig: FUN_1403865d0)
undefined8 * FUN_1403865d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgIPad::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgIPad::ctor_or_dtor  @140386620  [high:vtable-assign]  (orig: FUN_140386620)
void FUN_140386620(undefined8 *param_1)

{
  *param_1 = CMsgIPad::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgIPad::vfunc_1  @1403866f0  [high:rtti-vtable]  (orig: FUN_1403866f0)
ulonglong FUN_1403866f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x42d);
}

// ==== CMsgIPad::vfunc_3  @140386720  [high:rtti-vtable]  (orig: FUN_140386720)
void FUN_140386720(void)

{
  return;
}

// ==== CMsgIPad::ctor_or_dtor  @140386730  [high:vtable-assign]  (orig: FUN_140386730)
undefined8 * FUN_140386730(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgIPad::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

