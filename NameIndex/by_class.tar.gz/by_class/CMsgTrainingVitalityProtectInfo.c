// ==== CMsgTrainingVitalityProtectInfo::ctor_or_dtor  @1404f6350  [high:vtable-assign]  (orig: FUN_1404f6350)
undefined8 * FUN_1404f6350(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitalityProtectInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitalityProtectInfo::ctor_or_dtor  @1404f63a0  [high:vtable-assign]  (orig: FUN_1404f63a0)
void FUN_1404f63a0(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitalityProtectInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitalityProtectInfo::vfunc_1  @1404f63d0  [high:rtti-vtable]  (orig: FUN_1404f63d0)
bool FUN_1404f63d0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9e9;
    }
  }
  return false;
}

// ==== CMsgTrainingVitalityProtectInfo::vfunc_3  @1404f6550  [high:rtti-vtable]  (orig: FUN_1404f6550)
void FUN_1404f6550(void)

{
  return;
}

// ==== CMsgTrainingVitalityProtectInfo::ctor_or_dtor  @1404f6560  [high:vtable-assign]  (orig: FUN_1404f6560)
undefined8 * FUN_1404f6560(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitalityProtectInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

