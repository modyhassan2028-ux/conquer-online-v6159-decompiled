// ==== CEventPack::ctor_or_dtor  @1403688d0  [high:vtable-assign]  (orig: FUN_1403688d0)
undefined8 * FUN_1403688d0(undefined8 *param_1,uint param_2,undefined4 param_3,uint param_4)

{
  *param_1 = CEventPack::vftable;
  if (0xfffe < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (0xfffe < param_4) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  *(short *)(param_1 + 1) = (short)param_2;
  param_1[0x83] = param_1 + 2;
  *(undefined4 *)((longlong)param_1 + 0xc) = param_3;
  *(short *)((longlong)param_1 + 10) = (short)param_4;
  *(undefined1 *)(param_1 + 0x82) = 0;
  return param_1;
}

// ==== CEventPack::ctor_or_dtor  @1403689a0  [high:vtable-assign]  (orig: FUN_1403689a0)
undefined8 * FUN_1403689a0(undefined8 *param_1,void *param_2,int param_3)

{
  *param_1 = CEventPack::vftable;
  memset(param_1 + 1,0,0x408);
  if (param_3 - 1U < 0x408) {
    memcpy(param_1 + 1,param_2,(longlong)param_3);
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  param_1[0x83] = param_1 + 2;
  *(undefined1 *)(param_1 + 0x82) = 1;
  return param_1;
}

// ==== CEventPack::ctor_or_dtor  @140368a50  [high:vtable-assign]  (orig: FUN_140368a50)
void FUN_140368a50(undefined8 *param_1)

{
  *param_1 = CEventPack::vftable;
  return;
}

// ==== CEventPack::ctor_or_dtor  @140368df0  [high:vtable-assign]  (orig: FUN_140368df0)
undefined8 * FUN_140368df0(undefined8 *param_1,byte param_2)

{
  *param_1 = CEventPack::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

