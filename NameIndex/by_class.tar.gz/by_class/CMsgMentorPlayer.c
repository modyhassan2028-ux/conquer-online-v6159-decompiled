// ==== CMsgMentorPlayer::helper_140185af0  @140185af0  [medium:callgraph-r1]  (orig: FUN_140185af0)
undefined8 FUN_140185af0(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  longlong *plVar14;
  
  lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar9 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar10 = (longlong *)
            (**(code **)(**(longlong **)(lVar9 + 0x90) + 0x98))
                      (*(longlong **)(lVar9 + 0x90),param_2);
  if ((plVar10 != (longlong *)0x0) &&
     ((uVar5 = (**(code **)(*plVar10 + 8))(plVar10), uVar5 < 0xee69a15f ||
      (*(int *)((longlong)plVar10 + 0x12fc) == 0)))) {
    plVar1 = (longlong *)(param_1 + 0x10);
    uVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(plVar1);
    if (0x59 < uVar5) {
      plVar2 = plVar10 + 2;
      iVar6 = (**(code **)(plVar10[2] + 0x70))(plVar2);
      uVar5 = (**(code **)(*plVar1 + 0x70))(plVar1);
      if ((iVar6 + 0x14U <= uVar5) && (uVar4 = FUN_140371940(param_1 + 0xe78), 99 < uVar4)) {
        cVar3 = FUN_140178c90(param_1);
        if ((cVar3 == '\0') && (cVar3 = FUN_140178c90(plVar10), cVar3 == '\0')) {
          uVar4 = FUN_140371ac0(plVar10 + 0x1cf);
          if ((uint)uVar4 % 10 < 5) {
            iVar6 = 0;
            uVar7 = (**(code **)(*plVar2 + 0x70))(plVar2);
            uVar12 = FUN_140118150();
            plVar14 = (longlong *)FUN_14014de60(uVar12,0,uVar7);
            if (plVar14 != (longlong *)0x0) {
              iVar6 = (**(code **)(*plVar14 + 0x10))(plVar14,3);
            }
            uVar5 = FUN_1403719c0(plVar10 + 0x1cf);
            if ((int)(uVar5 & 0xffff) < iVar6) {
              iVar6 = (**(code **)(*plVar1 + 0x40))(plVar1);
              iVar8 = (**(code **)(*plVar2 + 0x40))(plVar2);
              uVar5 = iVar8 - iVar6 >> 0x1f;
              if ((int)((iVar8 - iVar6 ^ uVar5) - uVar5) < 10) {
                iVar6 = (**(code **)(*plVar1 + 0x48))(plVar1);
                iVar8 = (**(code **)(*plVar2 + 0x48))(plVar2);
                uVar5 = iVar8 - iVar6 >> 0x1f;
                if ((((int)((iVar8 - iVar6 ^ uVar5) - uVar5) < 10) &&
                    (cVar3 = (**(code **)(*plVar2 + 0x220))(plVar2), cVar3 != '\0')) &&
                   (cVar3 = (**(code **)(*plVar1 + 0x220))(plVar1), cVar3 != '\0')) {
                  return 1;
                }
              }
            }
          }
          else {
            pIVar11 = theInstance();
            lVar9 = *plVar1;
            uVar12 = (**(code **)(*plVar2 + 0x18))(plVar2);
            uVar13 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_MENTOR_TIMES_EXCESS");
            (**(code **)(lVar9 + 0x358))(plVar1,uVar13,uVar12);
            pIVar11 = theInstance();
            lVar9 = *plVar2;
            uVar12 = (**(code **)(*plVar1 + 0x18))(plVar1);
            uVar13 = (*(code *)**(undefined8 **)pIVar11)
                               (pIVar11,"STR_MENTOR_TIMES_EXCESS_TO_TARGET");
            (**(code **)(lVar9 + 0x358))(plVar2,uVar13,uVar12);
          }
        }
        else {
          pIVar11 = theInstance();
          lVar9 = *plVar1;
          uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_MENTOR_DISABLE_AT_NO_EXP_MAP");
          (**(code **)(lVar9 + 0x358))(plVar1,uVar12);
        }
      }
    }
    return 0;
  }
  return 0;
}

// ==== CMsgMentorPlayer::helper_1401b8fc0  @1401b8fc0  [medium:callgraph-r1]  (orig: FUN_1401b8fc0)
ulonglong FUN_1401b8fc0(longlong param_1)

{
  ushort uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  ulong uVar5;
  longlong *plVar6;
  ulonglong uVar7;
  longlong lVar8;
  uint uVar9;
  
  iVar2 = FUN_140371ac0(param_1 + 0xe78);
  FUN_140163490(param_1,iVar2 + 1,0);
  lVar8 = DAT_140975be0;
  if (DAT_140975be0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar8 = 0;
  }
  uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
  plVar6 = (longlong *)FUN_14014de60(lVar8,0,uVar3);
  uVar7 = 0;
  if (plVar6 != (longlong *)0x0) {
    uVar7 = (**(code **)(*plVar6 + 0x10))(plVar6,3);
    uVar4 = (uint)uVar7;
    if (0 < (int)uVar4) {
      FUN_1401aa230(param_1,(double)((int)(uVar4 * 4) / 5),0);
      lVar8 = DAT_140975be0;
      if (DAT_140975be0 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar8 = 0;
      }
      uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
      plVar6 = (longlong *)FUN_14014de60(lVar8,0,uVar3);
      if (plVar6 != (longlong *)0x0) {
        uVar4 = (**(code **)(*plVar6 + 0x10))(plVar6,3);
      }
      uVar7 = (ulonglong)(uint)-((int)uVar4 >> 0x1f);
      if (0 < (int)uVar4 / 5) {
        uVar1 = FUN_1403719c0(param_1 + 0xe78);
        uVar9 = (uint)uVar1 + (int)uVar4 / 5;
        if ((int)uVar4 < (int)uVar9) {
          uVar9 = uVar4;
        }
        uVar7 = FUN_1403719d0(param_1 + 0xe78,uVar9 & 0xffff,0);
        if (*(int *)(param_1 + 0xb44) == 0) {
          *(undefined4 *)(param_1 + 0xb40) = 0x4b0;
          uVar5 = tq::TimeGet(0);
          uVar7 = (ulonglong)uVar5 * 0x10624dd3 & 0xffffffff;
          *(uint *)(param_1 + 0xb44) = uVar5 / 1000;
        }
      }
    }
  }
  return uVar7;
}

// ==== CMsgMentorPlayer::helper_1401c2ba0  @1401c2ba0  [medium:callgraph-r0]  (orig: FUN_1401c2ba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401c2ba0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_4b8 [32];
  uint local_498;
  int local_490;
  int local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  cVar1 = FUN_140185af0();
  if (cVar1 != '\0') {
    lVar8 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar8 + 0x90) == 0) {
      local_498 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar9 = (longlong *)
             (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))
                       (*(longlong **)(lVar8 + 0x90),param_2);
    if (plVar9 != (longlong *)0x0) {
      iVar2 = FUN_140371a40(param_1 + 0x1cf);
      FUN_140371a50(param_1 + 0x1cf,iVar2 + 1,0);
      iVar2 = FUN_140371940(param_1 + 0x1cf);
      FUN_140371950(param_1 + 0x1cf,iVar2 + -100,0);
      FUN_1403f33e0(local_468);
      iVar2 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      iVar3 = (**(code **)(plVar9[2] + 0x48))(plVar9 + 2);
      iVar4 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      iVar5 = (**(code **)(plVar9[2] + 0x40))(plVar9 + 2);
      uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      local_498 = local_498 & 0xffff0000;
      local_490 = iVar5 - iVar4;
      local_488 = iVar3 - iVar2;
      cVar1 = FUN_1403f3460(local_468,0,uVar7,uVar6);
      if (cVar1 != '\0') {
        (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,1);
      }
      FUN_1401b8fc0(plVar9);
      lVar10 = FUN_140008520((int)param_1[0x246]);
      lVar8 = *(longlong *)(lVar10 + 0x1f8);
      if (*(longlong *)(lVar10 + 0x1f8) == 0) {
        local_498 = 0x163;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar8 = 0;
      }
      FUN_140261810(lVar8,param_1,0xc);
      lVar10 = FUN_140008520((int)param_1[0x246]);
      lVar8 = *(longlong *)(lVar10 + 0x200);
      if (*(longlong *)(lVar10 + 0x200) == 0) {
        local_498 = 0x164;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar8 = 0;
      }
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      local_498 = 0;
      FUN_140269300(lVar8,uVar6,0x1f);
      FUN_1403f3430(local_468);
    }
  }
  return;
}

// ==== CMsgMentorPlayer::helper_140371a40  @140371a40  [medium:callgraph-r1]  (orig: FUN_140371a40)
undefined2 FUN_140371a40(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x170);
}

// ==== CMsgMentorPlayer::helper_140371a50  @140371a50  [medium:callgraph-r1]  (orig: FUN_140371a50)
void FUN_140371a50(longlong param_1,undefined2 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined2 *)(param_1 + 0x170) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"mentor_achieve");
    (**(code **)(*plVar1 + 200))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgMentorPlayer::ctor_or_dtor  @1403f33e0  [high:vtable-assign]  (orig: FUN_1403f33e0)
undefined8 * FUN_1403f33e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMentorPlayer::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMentorPlayer::ctor_or_dtor  @1403f3430  [high:vtable-assign]  (orig: FUN_1403f3430)
void FUN_1403f3430(undefined8 *param_1)

{
  *param_1 = CMsgMentorPlayer::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMentorPlayer::ctor_or_dtor  @1403f3510  [high:vtable-assign]  (orig: FUN_1403f3510)
undefined8 * FUN_1403f3510(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMentorPlayer::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMentorPlayer::vfunc_3  @1403f3560  [high:rtti-vtable]  (orig: FUN_1403f3560)
void FUN_1403f3560(longlong param_1)

{
  short sVar1;
  undefined4 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar4,(int)lVar3,*puVar2);
    sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 4);
    if (sVar1 == 0) {
      FUN_1401c2ba0(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
    }
    else if (sVar1 == 1) {
      uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar6 = (longlong *)FUN_140087650(uVar8);
      lVar5 = (**(code **)(*plVar6 + 0x98))
                        (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
      if (lVar5 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403f367c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x350))((longlong *)(lVar5 + 0x10),param_1);
        return;
      }
    }
  }
  return;
}

