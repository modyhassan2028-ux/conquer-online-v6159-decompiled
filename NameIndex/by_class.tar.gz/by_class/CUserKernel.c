// ==== CUserKernel::helper_14002dc30  @14002dc30  [medium:callgraph-r1]  (orig: FUN_14002dc30)
undefined8 FUN_14002dc30(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  int local_res10 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined1 local_38 [16];
  CSingleLock local_28 [32];
  
  local_res10[0] = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    CSingleLock::CSingleLock(local_28,(CSyncObject *)(param_1 + 0x50),1);
    if (*(int *)(param_1 + 0xc) == 1) {
      CSingleLock::Unlock(local_28);
      uVar4 = 0;
    }
    else if (*(int *)(param_1 + 8) < 1) {
      CSingleLock::Unlock(local_28);
      uVar4 = 0;
    }
    else {
      plVar1 = (longlong *)(param_1 + 0x10);
      FUN_14002d940(plVar1,&local_48,local_res10);
      lVar5 = *(longlong *)(param_1 + 0x40);
      plVar2 = (longlong *)CONCAT44(uStack_44,local_48);
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      lVar3 = CONCAT44(uStack_3c,uStack_40);
      if (lVar3 == lVar5) {
        CSingleLock::Unlock(local_28);
        uVar4 = 0;
      }
      else {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar2;
        }
        if (lVar3 == *(longlong *)(lVar5 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar4 = *(undefined8 *)(lVar3 + 0x20);
        FUN_14002d580(plVar1,local_38,&local_48);
        CSingleLock::Unlock(local_28);
      }
    }
  }
  return uVar4;
}

// ==== CUserKernel::helper_14002dd80  @14002dd80  [medium:callgraph-r2]  (orig: FUN_14002dd80)
int FUN_14002dd80(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  int iVar2;
  undefined8 uVar3;
  longlong local_30;
  longlong local_28;
  CSingleLock local_20 [24];
  
  uVar3 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0x50),1);
  if (*(int *)(param_1 + 0x88) == -1) {
    *(undefined4 *)(param_1 + 0x88) = 1;
    *(undefined1 *)(param_1 + 0x8c) = 1;
  }
  iVar2 = 0;
  while( true ) {
    if (*(char *)(param_1 + 0x8c) == '\0') {
      iVar2 = *(int *)(param_1 + 0x88);
      *(int *)(param_1 + 0x88) = iVar2 + 1;
      CSingleLock::Unlock(local_20);
      return iVar2;
    }
    FUN_14002d940(param_1 + 0x10,&local_30,param_1 + 0x88,param_4,uVar3);
    lVar1 = *(longlong *)(param_1 + 0x40);
    if ((local_30 == 0) || (local_30 != *(longlong *)(param_1 + 0x10))) {
      _invalid_parameter_noinfo();
    }
    if (local_28 == lVar1) break;
    *(int *)(param_1 + 0x88) = *(int *)(param_1 + 0x88) + 1;
    iVar2 = iVar2 + 1;
    if (10000 < iVar2) {
      CSingleLock::Unlock(local_20);
      return 0;
    }
  }
  iVar2 = *(int *)(param_1 + 0x88);
  *(int *)(param_1 + 0x88) = iVar2 + 1;
  CSingleLock::Unlock(local_20);
  return iVar2;
}

// ==== CUserKernel::helper_14002df50  @14002df50  [medium:callgraph-r1]  (orig: FUN_14002df50)
int FUN_14002df50(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined8 *puVar2;
  undefined8 local_50;
  longlong local_48;
  undefined8 local_40;
  CSingleLock local_38 [24];
  undefined1 local_20 [24];
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar1 = 0;
  }
  else {
    CSingleLock::CSingleLock(local_38,(CSyncObject *)(param_1 + 0x50),1);
    if (*(int *)(param_1 + 0xc) == 1) {
      CSingleLock::Unlock(local_38);
      iVar1 = 0;
    }
    else {
      iVar1 = FUN_14002dd80(param_1);
      if (iVar1 == 0) {
        CSingleLock::Unlock(local_38);
        iVar1 = 0;
      }
      else {
        local_50 = CONCAT44(local_50._4_4_,iVar1);
        local_48 = param_2;
        puVar2 = (undefined8 *)FUN_14002d3d0(param_1 + 0x10,local_20,&local_50);
        local_50 = *puVar2;
        local_48 = puVar2[1];
        local_40 = puVar2[2];
        if ((char)local_40 == '\0') {
          CSingleLock::Unlock(local_38);
          iVar1 = 0;
        }
        else {
          *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
          CSingleLock::Unlock(local_38);
        }
      }
    }
  }
  return iVar1;
}

// ==== CUserKernel::vfunc_4  @1400f3630  [high:rtti-vtable]  (orig: FUN_1400f3630)
undefined8 FUN_1400f3630(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return 1;
}

// ==== CUserKernel::helper_1400f37d0  @1400f37d0  [medium:callgraph-r1]  (orig: FUN_1400f37d0)
void FUN_1400f37d0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x61) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserKernel::helper_1400f3900  @1400f3900  [medium:callgraph-r1]  (orig: FUN_1400f3900)
void FUN_1400f3900(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x61) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x61) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x61);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x61);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x61);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x61);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400f3924. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserKernel::helper_1400f3990  @1400f3990  [medium:callgraph-r2]  (orig: FUN_1400f3990)
void FUN_1400f3990(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"deque<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CUserKernel::helper_1400f3a30  @1400f3a30  [medium:callgraph-r2]  (orig: FUN_1400f3a30)
undefined8 FUN_1400f3a30(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  
  plVar1 = (longlong *)*param_1;
  uVar5 = param_1[1];
  lVar3 = 0;
  lVar2 = lVar3;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar4 = lVar3;
    if (plVar1 == (longlong *)0x0) goto LAB_1400f3a71;
  }
  lVar4 = *plVar1;
  if (plVar1 != (longlong *)0x0) {
    lVar2 = lVar4;
  }
LAB_1400f3a71:
  if ((ulonglong)(*(longlong *)(lVar2 + 0x38) + *(longlong *)(lVar4 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar2 = lVar3;
  if (param_1 != (longlong *)0x0) {
    lVar2 = *param_1;
  }
  if (*(ulonglong *)(lVar2 + 0x28) <= uVar5) {
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    uVar5 = uVar5 - *(longlong *)(lVar3 + 0x28);
  }
  lVar3 = lRam0000000000000020;
  if (param_1 != (longlong *)0x0) {
    lVar3 = *(longlong *)(*param_1 + 0x20);
  }
  return *(undefined8 *)(lVar3 + uVar5 * 8);
}

// ==== CUserKernel::helper_1400f3e30  @1400f3e30  [medium:callgraph-r2]  (orig: FUN_1400f3e30)
longlong * FUN_1400f3e30(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)*param_1;
  lVar3 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar2 = lVar3;
    if (plVar1 == (longlong *)0x0) goto LAB_1400f3e63;
  }
  lVar2 = *plVar1;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = lVar2;
  }
LAB_1400f3e63:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar2 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1[1] = param_1[1] + 1;
  return param_1;
}

// ==== CUserKernel::helper_1400f4170  @1400f4170  [medium:callgraph-r0]  (orig: FUN_1400f4170)
void FUN_1400f4170(void *param_1)

{
  if ((DAT_140975cb8 & 1) == 0) {
    DAT_140975cb8 = DAT_140975cb8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975cb0,"CUserKernel");
    atexit((_func_5014 *)&LAB_1406d66b0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001400f41c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975cb0,param_1);
  return;
}

// ==== CUserKernel::helper_1400f4230  @1400f4230  [medium:callgraph-r0]  (orig: FUN_1400f4230)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f4230(longlong param_1,longlong param_2)

{
  uint uVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  IStringManager *pIVar13;
  char *pcVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong *plVar19;
  longlong *plVar20;
  longlong *plVar21;
  undefined8 uVar22;
  bool bVar23;
  undefined1 auStack_258 [32];
  longlong local_238;
  undefined4 local_230;
  undefined4 local_228;
  undefined4 local_220;
  undefined4 local_218;
  undefined4 local_210;
  int local_208;
  undefined1 local_1f8;
  int local_1f4;
  longlong *local_1f0;
  longlong *local_1e8;
  longlong *local_1e0;
  longlong *local_1d8;
  longlong local_1d0;
  longlong local_1c8;
  longlong *local_1c0;
  undefined8 *local_1b8;
  longlong *local_1b0;
  longlong *local_1a8;
  undefined8 local_1a0;
  uint local_198;
  char local_194 [320];
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined1 local_40;
  ulonglong local_38;
  
  local_1a0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_258;
  local_1d0 = param_2;
  local_1c8 = param_1;
  if (param_2 == 0) {
    local_238 = CONCAT44(local_238._4_4_,0xe2);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar1 = *(uint *)(param_2 + 8);
    local_1f0 = (longlong *)CONCAT44(local_1f0._4_4_,uVar1);
    iVar11 = *(int *)(param_2 + 0xc);
    bVar23 = *(int *)(param_2 + 0x10) != 0;
    local_1f8 = bVar23;
    local_1f4 = iVar11;
    if (uVar1 == 0) {
      local_238 = CONCAT44(local_238._4_4_,0xe8);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else if (iVar11 == 0) {
      local_238 = CONCAT44(local_238._4_4_,0xe9);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      local_198 = 0;
      local_194[0] = '\0';
      local_194[1] = '\0';
      local_194[2] = '\0';
      local_194[3] = '\0';
      local_194[4] = '\0';
      local_194[5] = '\0';
      local_194[6] = '\0';
      local_194[7] = '\0';
      local_194[8] = '\0';
      local_194[9] = '\0';
      local_194[10] = '\0';
      local_194[0xb] = '\0';
      local_194[0xc] = '\0';
      local_194[0xd] = '\0';
      local_194[0xe] = '\0';
      local_194[0xf] = '\0';
      local_194[0x10] = '\0';
      local_194[0x11] = '\0';
      local_194[0x12] = '\0';
      local_194[0x13] = '\0';
      local_194[0x14] = '\0';
      local_194[0x15] = '\0';
      local_194[0x16] = '\0';
      local_194[0x17] = '\0';
      local_194[0x18] = '\0';
      local_194[0x19] = '\0';
      local_194[0x1a] = '\0';
      local_194[0x1b] = '\0';
      local_194[0x1c] = '\0';
      local_194[0x1d] = '\0';
      local_194[0x1e] = '\0';
      local_194[0x1f] = '\0';
      local_194[0x20] = '\0';
      local_194[0x21] = '\0';
      local_194[0x22] = '\0';
      local_194[0x23] = '\0';
      local_194[0x24] = '\0';
      local_194[0x25] = '\0';
      local_194[0x26] = '\0';
      local_194[0x27] = '\0';
      local_194[0x28] = '\0';
      local_194[0x29] = '\0';
      local_194[0x2a] = '\0';
      local_194[0x2b] = '\0';
      local_194[0x2c] = '\0';
      local_194[0x2d] = '\0';
      local_194[0x2e] = '\0';
      local_194[0x2f] = '\0';
      local_194[0x30] = '\0';
      local_194[0x31] = '\0';
      local_194[0x32] = '\0';
      local_194[0x33] = '\0';
      local_194[0x34] = '\0';
      local_194[0x35] = '\0';
      local_194[0x36] = '\0';
      local_194[0x37] = '\0';
      local_194[0x38] = '\0';
      local_194[0x39] = '\0';
      local_194[0x3a] = '\0';
      local_194[0x3b] = '\0';
      local_194[0x3c] = '\0';
      local_194[0x3d] = '\0';
      local_194[0x3e] = '\0';
      local_194[0x3f] = '\0';
      memset(local_194 + 0x40,0,0xff);
      local_54 = 0;
      local_50 = 0;
      local_4c = 0;
      local_48 = 0;
      local_40 = 0;
      local_44 = 0x1e;
      local_198 = uVar1;
      pIVar13 = theInstance();
      pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                  (pIVar13,"STR_OPERATING_PRIZE_MAIL_CONTENT");
      tq::StrCopy(local_194 + 0x40,pcVar14,0xff);
      pIVar13 = theInstance();
      pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                  (pIVar13,"STR_OPERATING_PRIZE_MAIL_TITILE");
      tq::StrCopy(local_194 + 0x20,pcVar14,0xff);
      pIVar13 = theInstance();
      pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                  (pIVar13,"STR_OPERATING_PRIZE_MAIL_SENDER_NAME");
      tq::StrCopy(local_194,pcVar14,0xff);
      local_50 = 0;
      local_54 = 0;
      local_4c = 0;
      local_238 = CONCAT71(local_238._1_7_,bVar23);
      plVar15 = (longlong *)FUN_1400fdcf0(iVar11,local_198,0,0xce);
      local_1e8 = plVar15;
      if (plVar15 == (longlong *)0x0) {
        log_InlineLogERROR(
                          "CUserKernel::ProcessOperatingMailAsyn CItem::GetItemRecord failed, user id:%u, item type:%u, mono:%d."
                          );
      }
      else {
        plVar16 = (longlong *)FUN_14035b1a0(&local_198);
        local_1d8 = plVar16;
        if (plVar16 == (longlong *)0x0) {
          (**(code **)*plVar15)(plVar15,1);
          log_InlineLogERROR(
                            "CUserKernel::ProcessOperatingMailAsyn CMail::GetMailRecord failed, user id:%u, item type:%u, mono:%d."
                            );
        }
        else {
          cVar2 = (**(code **)(*plVar15 + 0x50))(plVar15,1);
          if (cVar2 == '\0') {
            log_InlineLogERROR("CUserKernel::ProcessOperatingMailAsyn pRecItem->Insert failed.");
          }
          else {
            local_1e0 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0x10);
            local_1f0 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0xf);
            local_1a8 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0xe);
            plVar16 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0xc);
            plVar17 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0xb);
            plVar18 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,10);
            plVar19 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,9);
            plVar20 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,8);
            plVar15 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,1);
            plVar21 = (longlong *)(**(code **)(*local_1e8 + 0x10))(local_1e8,3);
            local_1b0 = (longlong *)(**(code **)(*local_1e8 + 0x10))(local_1e8,0);
            local_1c0 = (longlong *)(**(code **)(*local_1e8 + 0x10))(local_1e8,0x11);
            local_1b8 = (undefined8 *)(*local_1c0 + 0xb8);
            local_1f4 = (**(code **)(*local_1e0 + 0x40))(local_1e0);
            uVar3 = (**(code **)(*local_1f0 + 0x40))(local_1f0);
            local_1f0 = (longlong *)CONCAT44(local_1f0._4_4_,uVar3);
            uVar3 = (**(code **)(*local_1a8 + 0x40))(local_1a8);
            local_1e0 = (longlong *)CONCAT44(local_1e0._4_4_,uVar3);
            uVar3 = (**(code **)(*plVar16 + 0x40))(plVar16);
            uVar4 = (**(code **)(*plVar17 + 0x40))(plVar17);
            uVar5 = (**(code **)(*plVar18 + 0x40))(plVar18);
            uVar6 = (**(code **)(*plVar19 + 0x40))(plVar19);
            uVar7 = (**(code **)(*plVar20 + 0x40))(plVar20);
            uVar8 = (**(code **)(*plVar15 + 0x40))(plVar15);
            uVar9 = (**(code **)(*plVar21 + 0x40))(plVar21);
            uVar10 = (**(code **)(*local_1b0 + 0x40))(local_1b0);
            local_208 = local_1f4;
            local_210 = local_1f0._0_4_;
            local_218 = local_1e0._0_4_;
            local_238 = CONCAT44(local_238._4_4_,uVar6);
            local_230 = uVar5;
            local_228 = uVar4;
            local_220 = uVar3;
            uVar3 = FUN_1400fe140(uVar10,uVar9,uVar8,uVar7);
            (*(code *)*local_1b8)(local_1c0,uVar3);
            plVar15 = local_1e8;
            (**(code **)(*local_1e8 + 0x38))(local_1e8,0);
            plVar16 = (longlong *)(**(code **)(*plVar15 + 0x10))(plVar15,0);
            uVar3 = (**(code **)(*plVar16 + 0x40))(plVar16);
            plVar16 = local_1d8;
            plVar17 = (longlong *)(**(code **)(*local_1d8 + 0x10))(local_1d8,9);
            (**(code **)(*plVar17 + 0xb8))(plVar17,uVar3);
            cVar2 = (**(code **)(*plVar16 + 0x50))(plVar16,1);
            if (cVar2 == '\0') {
              (**(code **)(*plVar15 + 0x40))(plVar15,1);
              param_2 = local_1d0;
              *(undefined4 *)(local_1d0 + 0x20) = 0;
              log_InlineLogERROR("CUserKernel::ProcessOperatingMailAsyn pRecMail->Insert failed.");
              param_1 = local_1c8;
            }
            else {
              *(undefined4 *)(local_1d0 + 0x20) = 1;
              param_2 = local_1d0;
              param_1 = local_1c8;
            }
          }
          if (*(int *)(param_2 + 0x20) == 0) {
            (**(code **)*plVar15)(plVar15,1);
            (**(code **)*local_1d8)(local_1d8,1);
          }
          else {
            uVar22 = FUN_14002e300();
            iVar11 = FUN_14002df50(uVar22,plVar15);
            if (iVar11 == 0) {
              log_InlineLogERROR("CUserKernel::ProcessOperatingMailAsyn push pRecItem failed.");
              (**(code **)*plVar15)(plVar15,1);
              (**(code **)*local_1d8)(local_1d8,1);
            }
            else {
              uVar22 = FUN_14002e300();
              iVar12 = FUN_14002df50(uVar22,plVar16);
              if (iVar12 == 0) {
                log_InlineLogERROR("CUserKernel::ProcessOperatingMailAsyn push pRecItem failed.");
                (**(code **)*plVar16)(plVar16,1);
              }
              else {
                *(int *)(param_2 + 8) = iVar11;
                *(int *)(param_2 + 0xc) = iVar12;
                local_238 = param_2;
                (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                          (*(longlong **)(param_1 + 0x10),0xe,0x2742,0x30);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CUserKernel::helper_1400f48e0  @1400f48e0  [medium:callgraph-r0]  (orig: FUN_1400f48e0)
void FUN_1400f48e0(longlong param_1,longlong param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_14002e300();
    plVar4 = (longlong *)FUN_14002dc30(uVar3,*(undefined4 *)(param_2 + 8));
    if (plVar4 == (longlong *)0x0) {
      log_InlineLogERROR("CUserKernel::ProcessCommonMailAsyn pRec is null at %s, %d.");
    }
    else {
      cVar1 = (**(code **)(*plVar4 + 0x50))(plVar4,1);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CUserKernel::ProcessCommonMailAsyn pRec insert failed at %s, %d.");
        (**(code **)*plVar4)(plVar4,1);
      }
      else {
        uVar3 = FUN_14002e300();
        iVar2 = FUN_14002df50(uVar3,plVar4);
        if (iVar2 == 0) {
          log_InlineLogERROR("CUserKernel::ProcessCommonMailAsyn push pRec failed at %s, %d.");
          (**(code **)*plVar4)(plVar4,1);
        }
        else {
          *(int *)(param_2 + 8) = iVar2;
          *(undefined4 *)(param_2 + 0x20) = 1;
          (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                    (*(longlong **)(param_1 + 0x10),0xe,0x2742,0x30,param_2);
        }
      }
    }
  }
  return;
}

// ==== CUserKernel::helper_1400f4a20  @1400f4a20  [medium:callgraph-r0]  (orig: FUN_1400f4a20)
void FUN_1400f4a20(longlong param_1,longlong param_2)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (((*(int *)(param_2 + 8) == 0) || (*(int *)(param_2 + 0xc) == 0)) ||
          (*(char *)(param_2 + 0x10) == '\0')) {
    log_InlineLogERROR(
                      "CUserKernel::ProcessOperatingUserInfo param fault, user id:%u, act id:%u, type:%u."
                      );
  }
  else {
    plVar3 = (longlong *)
             FUN_140329f30(*(int *)(param_2 + 8),*(int *)(param_2 + 0xc),*(char *)(param_2 + 0x10));
    if (plVar3 == (longlong *)0x0) {
      log_InlineLogERROR(
                        "CUserKernel::ProcessOperatingUserInfo pRec is null, user id:%u, act id:%u."
                        );
    }
    else {
      cVar1 = (**(code **)(*plVar3 + 0x50))(plVar3,1);
      if (cVar1 == '\0') {
        log_InlineLogERROR(
                          "CUserKernel::ProcessOperatingUserInfo pRec insert failed, user id:%u, act id:%u."
                          );
        (**(code **)*plVar3)(plVar3,1);
      }
      else {
        uVar4 = FUN_14002e300();
        iVar2 = FUN_14002df50(uVar4,plVar3);
        if (iVar2 == 0) {
          log_InlineLogERROR(
                            "CUserKernel::ProcessOperatingUserInfo push pRec failed, user id:%u, act id:%u."
                            );
          (**(code **)*plVar3)(plVar3,1);
        }
        else {
          *(int *)(param_2 + 8) = iVar2;
          *(undefined4 *)(param_2 + 0x20) = 1;
          (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                    (*(longlong **)(param_1 + 0x10),0xe,0x2742,0x30,param_2);
        }
      }
    }
  }
  return;
}

// ==== CUserKernel::helper_1400f4ba0  @1400f4ba0  [medium:callgraph-r0]  (orig: FUN_1400f4ba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f4ba0(longlong param_1,int *param_2)

{
  char cVar1;
  char cVar2;
  longlong *plVar3;
  longlong lVar4;
  char *pcVar5;
  undefined1 auStack_478 [32];
  int *local_458;
  int *local_448;
  longlong local_440;
  undefined8 local_438;
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  
  local_438 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_448 = param_2;
  local_440 = param_1;
  if (param_2 == (int *)0x0) {
    local_458 = (int *)CONCAT44(local_458._4_4_,0x1a3);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    if (((*param_2 != 0) && (param_2[1] != 0)) &&
       ((cVar2 = (char)param_2[2], cVar2 == '\x01' || (cVar2 == '\x02')))) {
      lVar4 = -1;
      pcVar5 = (char *)((longlong)param_2 + 9);
      do {
        if (lVar4 == 0) break;
        lVar4 = lVar4 + -1;
        cVar1 = *pcVar5;
        pcVar5 = pcVar5 + 1;
      } while (cVar1 != '\0');
      if (lVar4 != -2) {
        local_428 = '\0';
        memset(local_427,0,0x3ff);
        if (cVar2 == '\x01') {
          _snprintf(&local_428,0x400,"SELECT id FROM family WHERE `family_name`=\'%s\'");
        }
        else {
          if (cVar2 != '\x02') {
            return;
          }
          _snprintf(&local_428,0x400,"SELECT id FROM cq_syndicate WHERE `name`=\'%s\'");
        }
        local_29 = 0;
        plVar3 = (longlong *)InstanceGet();
        plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,&local_428,1);
        if (plVar3 == (longlong *)0x0) {
          local_458 = (int *)CONCAT44(local_458._4_4_,0x1c1);
          log_InlineLogERROR(&DAT_1406d9c10);
          return;
        }
        lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3);
        *(bool *)(param_2 + 0xe) = lVar4 != 0;
        (**(code **)*plVar3)(plVar3);
        local_458 = param_2;
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                  (*(longlong **)(param_1 + 0x10),0xe,0x2746,0x3c);
        return;
      }
    }
    log_InlineLogERROR(
                      "CUserKernel::ProcessSelectNameAsyn param fault, user_id:%u, type:%u, szName:%s."
                      );
  }
  return;
}

// ==== CUserKernel::helper_1400f4da0  @1400f4da0  [medium:callgraph-r0]  (orig: FUN_1400f4da0)
undefined8 FUN_1400f4da0(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    lVar2 = FUN_140008520(0xe);
    uVar1 = 0;
    if (lVar2 != 0) {
      plVar3 = (longlong *)FUN_140087650(lVar2);
      uVar1 = 0;
      if (plVar3 != (longlong *)0x0) {
        lVar2 = (**(code **)(*plVar3 + 0x30))
                          (plVar3,*(undefined4 *)(param_2 + 4),*(undefined4 *)(param_2 + 8),
                           *(undefined4 *)(param_2 + 0x14));
        if (*(longlong *)(param_1 + 0x10) == 0) {
          uVar1 = 0;
        }
        else if (lVar2 == 0) {
          (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                    (*(longlong **)(param_1 + 0x10),1,0x7538,0xea65,(undefined4 *)(param_2 + 4));
          uVar1 = 0;
        }
        else {
          (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                    (*(longlong **)(param_1 + 0x10),0xe,0x2726,0x5c,param_2);
          uVar1 = 1;
        }
      }
    }
  }
  return uVar1;
}

// ==== CUserKernel::helper_1400f4e80  @1400f4e80  [medium:callgraph-r1]  (orig: FUN_1400f4e80)
void FUN_1400f4e80(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x61) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserKernel::helper_1400f50b0  @1400f50b0  [medium:callgraph-r2]  (orig: FUN_1400f50b0)
void FUN_1400f50b0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CUserKernel::vfunc_1  @1400f5300  [high:rtti-vtable]  (orig: FUN_1400f5300)
ulonglong FUN_1400f5300(longlong param_1,longlong *param_2)

{
  undefined4 uVar1;
  ulong uVar2;
  ulonglong uVar3;
  
  *(longlong **)(param_1 + 0x10) = param_2;
  uVar1 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 8) = uVar1;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))();
  uVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))(*(longlong **)(param_1 + 0x10),3);
  if (*(int *)(param_1 + 8) != 4) {
    return uVar3 & 0xffffffffffffff00;
  }
  *(undefined4 *)(param_1 + 0x18) = 10;
  uVar2 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1c) = uVar2 / 1000;
  return CONCAT71((uint7)((ulonglong)uVar2 * 0x10624dd3 >> 8) & 0xffffff,1);
}

// ==== CUserKernel::vfunc_3  @1400f5370  [high:rtti-vtable]  (orig: FUN_1400f5370)
undefined8 FUN_1400f5370(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined4 local_res8 [8];
  
  uVar2 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x1c) + *(int *)(param_1 + 0x18)) <= uVar2 / 1000) {
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x1c) = uVar2 / 1000;
    lVar3 = FUN_140008520(0xe);
    if (lVar3 != 0) {
      FUN_140008520(0xe);
      lVar3 = InstanceGet();
      if (lVar3 != 0) {
        if (DAT_140975cbc < 3) {
          FUN_140008520(0xe);
          plVar4 = (longlong *)InstanceGet();
          cVar1 = (**(code **)(*plVar4 + 0x28))(plVar4);
          if (cVar1 == '\0') {
            DAT_140975cbc = DAT_140975cbc + 1;
            if (2 < DAT_140975cbc) {
              log_InlineLogWARNING("The connection of database is broken at %s, %d");
              return 1;
            }
          }
        }
        else {
          plVar4 = (longlong *)InstanceGet();
          cVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
          if (cVar1 != '\0') {
            log_InlineLogMessage("UserKernel reconnect database success.");
            local_res8[0] = 1;
            (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                      (*(longlong **)(param_1 + 0x10),0xe,0x272f,0xea65,local_res8);
            (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                      (*(longlong **)(param_1 + 0x10),2,0x4e2b,0xea65,local_res8);
            DAT_140975cbc = 0;
          }
        }
      }
    }
  }
  return 1;
}

// ==== CUserKernel::helper_1400f55b0  @1400f55b0  [medium:callgraph-r0]  (orig: FUN_1400f55b0)
void FUN_1400f55b0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  while (lVar1 != 0) {
    if ((*(longlong *)(param_1 + 0x38) != 0) &&
       (lVar1 = *(longlong *)(param_1 + 0x38) + -1, *(longlong *)(param_1 + 0x38) = lVar1,
       lVar1 == 0)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    lVar1 = *(longlong *)(param_1 + 0x38);
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  while (lVar1 != 0) {
    lVar1 = lVar1 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar1 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar1 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  return;
}

// ==== CUserKernel::helper_1400f56e0  @1400f56e0  [medium:callgraph-r1]  (orig: FUN_1400f56e0)
void FUN_1400f56e0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x68);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0xc) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x61) = 0;
  return;
}

// ==== CUserKernel::helper_1400f5ba0  @1400f5ba0  [medium:callgraph-r3]  (orig: FUN_1400f5ba0)
undefined8 FUN_1400f5ba0(longlong *param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  plVar1 = (longlong *)*param_1;
  lVar3 = param_1[1];
  lVar2 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *plVar1;
  }
  uVar4 = param_2 + lVar3;
  if (uVar4 <= (ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30))) {
    lVar3 = lVar2;
    if (plVar1 != (longlong *)0x0) {
      lVar3 = *plVar1;
    }
    if (*(ulonglong *)(lVar3 + 0x30) <= uVar4) goto LAB_1400f5c13;
  }
  _invalid_parameter_noinfo();
LAB_1400f5c13:
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar3 = lVar2;
  }
  else {
    lVar3 = *plVar1;
  }
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar3 + 0x30)) <= uVar4) {
    _invalid_parameter_noinfo();
  }
  lVar3 = lVar2;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = *plVar1;
  }
  if (*(ulonglong *)(lVar3 + 0x28) <= uVar4) {
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    uVar4 = uVar4 - *(longlong *)(lVar2 + 0x28);
  }
  lVar3 = lRam0000000000000020;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = *(longlong *)(*plVar1 + 0x20);
  }
  return *(undefined8 *)(lVar3 + uVar4 * 8);
}

// ==== CUserKernel::helper_1400f5cb0  @1400f5cb0  [medium:callgraph-r0]  (orig: FUN_1400f5cb0)
undefined8 * FUN_1400f5cb0(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = operator_new(8);
  puVar2 = (void *)0x0;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1;
    puVar2 = puVar1;
  }
  *param_1 = puVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  return param_1;
}

// ==== CUserKernel::helper_1400f5ee0  @1400f5ee0  [medium:callgraph-r2]  (orig: FUN_1400f5ee0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f5ee0(undefined8 *param_1,longlong param_2,longlong param_3)

{
  ulonglong uVar1;
  void *_Src;
  void *_Src_00;
  undefined1 auStack_b8 [32];
  undefined8 local_98;
  ulonglong local_90;
  undefined1 local_88 [96];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  uVar1 = param_1[6];
  if (param_1[7] + uVar1 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_98 = *param_1;
  local_90 = uVar1;
  if (param_2 != param_3) {
    do {
      param_3 = param_3 + -1;
      if (param_2 == param_3) {
        return;
      }
      _Src = (void *)FUN_1400f5ba0(&local_98,param_3);
      _Src_00 = (void *)FUN_1400f5ba0(&local_98,param_2);
      if (_Src_00 != _Src) {
        memcpy(local_88,_Src_00,0x5c);
        memcpy(_Src_00,_Src,0x5c);
        memcpy(_Src,local_88,0x5c);
      }
      param_2 = param_2 + 1;
    } while (param_2 != param_3);
  }
  return;
}

// ==== CUserKernel::helper_1400f6010  @1400f6010  [medium:callgraph-r0]  (orig: FUN_1400f6010)
longlong * FUN_1400f6010(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x61) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x61) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserKernel::helper_1400f60e0  @1400f60e0  [medium:callgraph-r0]  (orig: FUN_1400f60e0)
undefined8 FUN_1400f60e0(longlong *param_1)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  uVar3 = param_1[6];
  if (uVar3 + param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar2 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = lVar2;
  }
  else {
    lVar1 = *param_1;
  }
  if ((ulonglong)(*(longlong *)(lVar1 + 0x38) + *(longlong *)(lVar1 + 0x30)) <= uVar3) {
    _invalid_parameter_noinfo();
  }
  lVar1 = lVar2;
  if (param_1 != (longlong *)0x0) {
    lVar1 = *param_1;
  }
  if (*(ulonglong *)(lVar1 + 0x28) <= uVar3) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    uVar3 = uVar3 - *(longlong *)(lVar2 + 0x28);
  }
  lVar2 = lRam0000000000000020;
  if (param_1 != (longlong *)0x0) {
    lVar2 = *(longlong *)(*param_1 + 0x20);
  }
  return *(undefined8 *)(lVar2 + uVar3 * 8);
}

// ==== CUserKernel::helper_1400f61b0  @1400f61b0  [medium:callgraph-r1]  (orig: FUN_1400f61b0)
void FUN_1400f61b0(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0x2c8590b21642c85 - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1400f3990();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0x2c8590b21642c85 - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30);
  _Dst_00 = (void *)FUN_1400f50b0(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CUserKernel::helper_1400f6400  @1400f6400  [medium:callgraph-r2]  (orig: FUN_1400f6400)
void FUN_1400f6400(longlong param_1,void *param_2)

{
  void *pvVar1;
  longlong lVar2;
  
  if (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 1U) {
    FUN_1400f61b0(param_1,1);
  }
  lVar2 = *(longlong *)(param_1 + 0x30);
  if (lVar2 == 0) {
    lVar2 = *(longlong *)(param_1 + 0x28);
  }
  lVar2 = lVar2 + -1;
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar2 * 8) == 0) {
    pvVar1 = operator_new(0x5c);
    *(void **)(*(longlong *)(param_1 + 0x20) + lVar2 * 8) = pvVar1;
  }
  pvVar1 = *(void **)(*(longlong *)(param_1 + 0x20) + lVar2 * 8);
  if (pvVar1 != (void *)0x0) {
    memcpy(pvVar1,param_2,0x5c);
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  *(longlong *)(param_1 + 0x30) = lVar2;
  return;
}

// ==== CUserKernel::helper_1400f6490  @1400f6490  [medium:callgraph-r0]  (orig: FUN_1400f6490)
void FUN_1400f6490(longlong param_1,void *param_2)

{
  void *pvVar1;
  ulonglong uVar2;
  
  if (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 1U) {
    FUN_1400f61b0(param_1,1);
  }
  uVar2 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  if (*(ulonglong *)(param_1 + 0x28) <= uVar2) {
    uVar2 = uVar2 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar2 * 8) == 0) {
    pvVar1 = operator_new(0x5c);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar2 * 8) = pvVar1;
  }
  pvVar1 = *(void **)(*(longlong *)(param_1 + 0x20) + uVar2 * 8);
  if (pvVar1 != (void *)0x0) {
    memcpy(pvVar1,param_2,0x5c);
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CUserKernel::helper_1400f6610  @1400f6610  [medium:callgraph-r1]  (orig: FUN_1400f6610)
void FUN_1400f6610(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  ulonglong uVar1;
  void *pvVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined1 local_90 [104];
  
  uVar4 = param_1[6];
  if (uVar4 + param_1[7] < uVar4) {
    _invalid_parameter_noinfo();
  }
  if ((*param_2 == 0) || (*param_2 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  uVar4 = param_2[1] - uVar4;
  uVar1 = param_1[7];
  if ((*param_3 == 0) || (*param_3 != *param_4)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] != param_4[1]) {
    if (uVar4 < uVar1 - uVar4) {
      while( true ) {
        if ((*param_3 == 0) || (*param_3 != *param_4)) {
          _invalid_parameter_noinfo();
        }
        if (param_3[1] == param_4[1]) break;
        pvVar2 = (void *)FUN_1400f3a30(param_3);
        memcpy(local_90,pvVar2,0x5c);
        FUN_1400f6400(param_1);
        FUN_1400f3e30(param_3);
      }
      lVar3 = param_1[7] - uVar1;
      if (uVar4 == 0) {
        FUN_1400f5ee0(param_1,0,lVar3);
      }
      else {
        FUN_1400f5ee0(param_1,lVar3,lVar3 + uVar4);
        FUN_1400f5ee0(param_1,0,lVar3 + uVar4);
      }
    }
    else {
      while( true ) {
        if ((*param_3 == 0) || (*param_3 != *param_4)) {
          _invalid_parameter_noinfo();
        }
        if (param_3[1] == param_4[1]) break;
        pvVar2 = (void *)FUN_1400f3a30(param_3);
        memcpy(local_90,pvVar2,0x5c);
        FUN_1400f6490(param_1,local_90);
        FUN_1400f3e30(param_3);
      }
      if (uVar4 < uVar1) {
        FUN_1400f5ee0(param_1,uVar4,uVar1);
        FUN_1400f5ee0(param_1,uVar1,param_1[7]);
        FUN_1400f5ee0(param_1,uVar4,param_1[7]);
      }
    }
  }
  return;
}

// ==== CUserKernel::helper_1400f68d0  @1400f68d0  [medium:callgraph-r0]  (orig: FUN_1400f68d0)
undefined8 * FUN_1400f68d0(undefined8 *param_1,undefined8 *param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined1 local_res18;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  ulonglong uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  puVar6 = operator_new(8);
  if (puVar6 == (undefined8 *)0x0) {
    puVar7 = (undefined8 *)0x0;
  }
  else {
    *puVar6 = param_1;
    puVar7 = puVar6;
  }
  *param_1 = puVar7;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  uVar2 = param_1[6];
  if (uVar2 + param_1[7] < uVar2) {
    _invalid_parameter_noinfo();
  }
  uVar3 = *param_1;
  uVar1 = param_2[6] + param_2[7];
  if (uVar1 < (ulonglong)param_2[6]) {
    _invalid_parameter_noinfo();
  }
  uVar4 = *param_2;
  uVar5 = param_2[6];
  if (uVar5 + param_2[7] < uVar5) {
    _invalid_parameter_noinfo();
  }
  local_68 = (undefined4)*param_2;
  uStack_64 = (undefined4)((ulonglong)*param_2 >> 0x20);
  uStack_60 = (undefined4)uVar5;
  uStack_5c = (undefined4)(uVar5 >> 0x20);
  local_38 = local_68;
  uStack_34 = uStack_64;
  uStack_30 = uStack_60;
  uStack_2c = uStack_5c;
  local_58 = (undefined4)uVar3;
  uStack_54 = (undefined4)((ulonglong)uVar3 >> 0x20);
  uStack_50 = (undefined4)uVar2;
  uStack_4c = (undefined4)(uVar2 >> 0x20);
  local_28 = local_58;
  uStack_24 = uStack_54;
  uStack_20 = uStack_50;
  uStack_1c = uStack_4c;
  local_res18 = SUB81(puVar6,0);
  local_48 = uVar4;
  uStack_40 = uVar1;
  FUN_1400f6610(param_1,&local_28,&local_38,&local_48,local_res18);
  return param_1;
}

// ==== CUserKernel::helper_1400f6a60  @1400f6a60  [medium:callgraph-r2]  (orig: FUN_1400f6a60)
void FUN_1400f6a60(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x61);
  while (cVar1 == '\0') {
    FUN_1400f6a60(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    FUN_1400f55b0(param_2 + 4);
    operator_delete((void *)param_2[4]);
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x61);
  }
  return;
}

// ==== CUserKernel::helper_1400f6af0  @1400f6af0  [medium:callgraph-r0]  (orig: FUN_1400f6af0)
undefined8 * FUN_1400f6af0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x61) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400f3900(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x61) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xc;
        plVar8 = plVar8 + 0xc;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400f6cdc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x61);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x61) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x61);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x61);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400f6cdc:
  if ((char)plVar2[0xc] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xc] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1400f4e80(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(*plVar9 + 0x60) != '\x01') || (*(char *)(plVar9[2] + 0x60) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x60) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1400f37d0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(plVar9[2] + 0x60) = 1;
              FUN_1400f4e80(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        else {
          if ((char)plVar9[0xc] == '\0') {
            *(undefined1 *)(plVar9 + 0xc) = 1;
            *(undefined1 *)(plVar8 + 0xc) = 0;
            FUN_1400f37d0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
            if ((*(char *)(plVar9[2] + 0x60) != '\x01') || (*(char *)(*plVar9 + 0x60) != '\x01')) {
              if (*(char *)(*plVar9 + 0x60) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x60) = 1;
                *(undefined1 *)(plVar9 + 0xc) = 0;
                FUN_1400f4e80(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xc) = (char)plVar8[0xc];
              *(undefined1 *)(plVar8 + 0xc) = 1;
              *(undefined1 *)(*plVar9 + 0x60) = 1;
              FUN_1400f37d0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xc) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xc) = 1;
  }
  FUN_1400f55b0(plVar2 + 4);
  operator_delete((void *)plVar2[4]);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CUserKernel::helper_1400f6fa0  @1400f6fa0  [medium:callgraph-r1]  (orig: FUN_1400f6fa0)
longlong * FUN_1400f6fa0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400f6a60(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x61) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x61) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x61);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x61);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x61);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x61);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400f6af0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CUserKernel::helper_1400f7180  @1400f7180  [medium:callgraph-r2]  (orig: FUN_1400f7180)
undefined8 *
FUN_1400f7180(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x68);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    FUN_1400f68d0(puVar1 + 4,param_5 + 2);
    *(undefined1 *)(puVar1 + 0xc) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x61) = 0;
  }
  return puVar1;
}

// ==== CUserKernel::helper_1400f7220  @1400f7220  [medium:callgraph-r1]  (orig: FUN_1400f7220)
undefined8 *
FUN_1400f7220(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x38e38e38e38e38c < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1400f7180(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x60);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x60) == '\0') {
        *(undefined1 *)(plVar2 + 0xc) = 1;
        *(undefined1 *)(lVar4 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x61) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x61) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x60) == '\0') {
        *(undefined1 *)(plVar2 + 0xc) = 1;
        *(undefined1 *)(lVar4 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x61) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x61) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x60);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x60) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserKernel::helper_1400f7560  @1400f7560  [medium:callgraph-r0]  (orig: FUN_1400f7560)
void FUN_1400f7560(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400f6fa0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CUserKernel::helper_1400f7600  @1400f7600  [medium:callgraph-r0]  (orig: FUN_1400f7600)
longlong * FUN_1400f7600(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x61) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x61) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1400f775d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1400f778c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x61) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x61) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x61);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x61);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x61);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x61);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x61) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x61) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1400f775d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1400f7220(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1400f778c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserKernel::ctor_or_dtor  @1400f77e0  [high:vtable-assign]  (orig: FUN_1400f77e0)
void FUN_1400f77e0(undefined8 *param_1)

{
  *param_1 = CUserKernel::vftable;
  FUN_1400f7560(param_1 + 5);
  operator_delete((void *)param_1[5]);
  *param_1 = IUser::vftable;
  return;
}

// ==== CUserKernel::ProcessMsg  @1400f7840  [high:log-string]  (orig: FUN_1400f7840)
undefined8 FUN_1400f7840(longlong param_1,int param_2,int *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  int *piVar8;
  undefined8 uVar9;
  void *pvVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 local_118;
  undefined8 uStack_110;
  longlong *local_108;
  undefined4 uStack_100;
  undefined4 uStack_fc;
  longlong local_e8;
  void *local_d8 [4];
  void *local_b8;
  longlong local_b0;
  longlong local_a8;
  longlong local_a0;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  longlong *local_88;
  undefined8 local_78;
  int local_70 [2];
  void *local_68 [8];
  
  local_78 = 0xfffffffffffffffe;
  if (param_2 == 0xc351) {
    if ((param_3 != (int *)0x0) && (param_3[1] != -1)) {
      puVar3 = (undefined8 *)(param_1 + 0x28);
      FUN_1400f6010(puVar3,&local_118,param_3 + 2);
      lVar11 = *(longlong *)(param_1 + 0x58);
      lVar12 = 0;
      local_108 = (longlong *)*puVar3;
      if ((local_118 == (void **)0x0) || (local_118 != (void **)local_108)) {
        _invalid_parameter_noinfo();
      }
      if (uStack_110 == lVar11) {
        cVar7 = FUN_1400f4da0(param_1,param_3);
        if (cVar7 != '\0') {
          FUN_1400f5cb0(local_d8);
          FUN_1400f6490(local_d8,param_3);
          local_70[0] = param_3[2];
          FUN_1400f68d0(local_68,local_d8);
          FUN_1400f7600(puVar3,&local_108,local_70);
          local_118 = local_68;
          FUN_1400f55b0(local_68);
          operator_delete(local_68[0]);
          while (local_a0 != 0) {
            local_a0 = local_a0 + -1;
            if (local_a0 == 0) {
              local_a8 = lVar12;
            }
          }
          local_e8 = local_b0;
          pvVar10 = local_b8;
          lVar11 = local_b0;
          while (lVar11 != 0) {
            lVar11 = lVar11 + -1;
            local_e8 = lVar11;
            if (*(longlong *)((longlong)pvVar10 + lVar11 * 8) != 0) {
              operator_delete(*(void **)((longlong)pvVar10 + lVar11 * 8));
              pvVar10 = local_b8;
            }
          }
          if (pvVar10 != (void *)0x0) {
            operator_delete(pvVar10);
          }
          local_b0 = 0;
          local_b8 = (void *)0x0;
          operator_delete(local_d8[0]);
        }
      }
      else {
        if (local_118 == (void **)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar12 = (longlong)*local_118;
        }
        if (uStack_110 == *(longlong *)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_1400f6490(uStack_110 + 0x20,param_3);
      }
    }
  }
  else if (param_2 == 0xc353) {
    iVar4 = param_3[1];
    if (iVar4 == 0) {
      FUN_1400f4a20(param_1,param_3);
    }
    else if (iVar4 == 1) {
      FUN_1400f4230(param_1,param_3);
    }
    else if (iVar4 == 2) {
      FUN_1400f48e0(param_1,param_3);
    }
  }
  else if (param_2 == 0xc354) {
    FUN_1400f4ba0(param_1,param_3);
  }
  else if (param_2 == 0xc355) {
    if (param_3 != (int *)0x0) {
      plVar1 = (longlong *)(param_1 + 0x28);
      FUN_1400f6010(plVar1,&local_118,param_3 + 2);
      plVar5 = (longlong *)local_118;
      lVar11 = *(longlong *)(param_1 + 0x58);
      lVar12 = 0;
      local_88 = (longlong *)*plVar1;
      if ((local_118 == (void **)0x0) || (local_118 != (void **)local_88)) {
        _invalid_parameter_noinfo();
      }
      lVar6 = uStack_110;
      if (uStack_110 == lVar11) {
        log_InlineLogERROR("CUserKernel::ProcessMsg USERLOGIN_LOGINOVER. User[%u] Map is not found")
        ;
      }
      else {
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar12;
        }
        else {
          lVar11 = *plVar5;
        }
        if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lVar6 + 0x58) == 0) {
          log_InlineLogERROR("CUserKernel::ProcessMsg USERLOGIN_LOGINOVER. User[%u] Deque is empty")
          ;
          FUN_1400f6af0(plVar1,&local_108,&local_118);
        }
        else {
          if (plVar5 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar12;
          }
          else {
            lVar11 = *plVar5;
          }
          if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          piVar8 = (int *)FUN_1400f60e0(lVar6 + 0x20);
          if (*param_3 != *piVar8) {
            log_InlineLogERROR(
                              "CUserKernel::ProcessMsg USERLOGIN_LOGINOVER. User[%u] Serial not match"
                              );
          }
          if (plVar5 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar12;
          }
          else {
            lVar11 = *plVar5;
          }
          if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(longlong *)(lVar6 + 0x58) != 0) {
            *(longlong *)(lVar6 + 0x50) = *(longlong *)(lVar6 + 0x50) + 1;
            if (*(ulonglong *)(lVar6 + 0x48) <= *(ulonglong *)(lVar6 + 0x50)) {
              *(undefined8 *)(lVar6 + 0x50) = 0;
            }
            plVar2 = (longlong *)(lVar6 + 0x58);
            *plVar2 = *plVar2 + -1;
            if (*plVar2 == 0) {
              *(undefined8 *)(lVar6 + 0x50) = 0;
            }
          }
          if (plVar5 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar12;
          }
          else {
            lVar11 = *plVar5;
          }
          if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(longlong *)(lVar6 + 0x58) == 0) {
            local_98 = (undefined4)local_118;
            uStack_94 = local_118._4_4_;
            uStack_90 = (undefined4)uStack_110;
            uStack_8c = uStack_110._4_4_;
            FUN_1400f6af0(plVar1,&local_108,&local_98);
          }
          else {
            do {
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = lVar12;
              }
              else {
                lVar11 = *plVar5;
              }
              if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (*(longlong *)(lVar6 + 0x58) == 0) {
                return 1;
              }
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = lVar12;
              }
              else {
                lVar11 = *plVar5;
              }
              if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              uVar9 = FUN_1400f60e0(lVar6 + 0x20);
              cVar7 = FUN_1400f4da0(param_1,uVar9);
              if (cVar7 != '\0') {
                return 1;
              }
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = lVar12;
              }
              else {
                lVar11 = *plVar5;
              }
              if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (*(longlong *)(lVar6 + 0x58) != 0) {
                *(longlong *)(lVar6 + 0x50) = *(longlong *)(lVar6 + 0x50) + 1;
                if (*(ulonglong *)(lVar6 + 0x48) <= *(ulonglong *)(lVar6 + 0x50)) {
                  *(undefined8 *)(lVar6 + 0x50) = 0;
                }
                plVar1 = (longlong *)(lVar6 + 0x58);
                *plVar1 = *plVar1 + -1;
                if (*plVar1 == 0) {
                  *(undefined8 *)(lVar6 + 0x50) = 0;
                }
              }
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = lVar12;
              }
              else {
                lVar11 = *plVar5;
              }
              if (lVar6 == *(longlong *)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
            } while (*(longlong *)(lVar6 + 0x58) != 0);
            uStack_100 = (undefined4)uStack_110;
            uStack_fc = uStack_110._4_4_;
            FUN_1400f6af0(param_1 + 0x28,&local_98,&local_108);
          }
        }
      }
    }
  }
  else {
    log_InlineLogERROR("CUserKernel::ProcessMsg() idPacket:%u,nType:%d,nFrom:%d at %s,%d");
  }
  return 1;
}

// ==== CUserKernel::helper_1400f7d90  @1400f7d90  [medium:callgraph-r0]  (orig: FUN_1400f7d90)
undefined8 * FUN_1400f7d90(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1400f56e0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x61) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CUserKernel::ctor_or_dtor  @1400f7e10  [high:vtable-assign]  (orig: FUN_1400f7e10)
undefined8 * FUN_1400f7e10(undefined8 *param_1)

{
  *param_1 = IUser::vftable;
  *param_1 = CUserKernel::vftable;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  FUN_1400f7d90(param_1 + 5);
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined1 *)((longlong)param_1 + 0x24) = 0;
  return param_1;
}

// ==== CUserKernel::ctor_or_dtor  @1400f7e70  [high:vtable-assign]  (orig: FUN_1400f7e70)
undefined8 * FUN_1400f7e70(undefined8 *param_1,uint param_2)

{
  *param_1 = CUserKernel::vftable;
  FUN_1400f7560(param_1 + 5);
  operator_delete((void *)param_1[5]);
  *param_1 = IUser::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1400f4170(param_1);
  }
  return param_1;
}

// ==== CUserKernel::helper_1400fdcf0  @1400fdcf0  [medium:callgraph-r1]  (orig: FUN_1400fdcf0)
longlong *
FUN_1400fdcf0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,char param_5)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  if (param_1 != 0) {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    lVar2 = (**(code **)(*plVar3 + 0x70))(plVar3,param_1);
    if (lVar2 == 0) {
      log_InlineLogERROR("Create GetItemRecord(idPlyer=%u, idOwner=%u, idType=%u) fail at %s, %d");
      plVar3 = (longlong *)0x0;
    }
    else {
      plVar3 = (longlong *)InstanceGet();
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_item");
      if (plVar3 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = (longlong *)0x0;
      }
      else {
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
        (**(code **)(*plVar4 + 0xb8))(plVar4,param_1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,2);
        (**(code **)(*plVar4 + 0xb8))(plVar4,param_3);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,3);
        (**(code **)(*plVar4 + 0xb8))(plVar4,param_2);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x15);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,5);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x16);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,6);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x17);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,7);
        (**(code **)(*plVar4 + 0xb0))(plVar4,param_4);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,8);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x18);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,9);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x19);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,10);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x1a);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0xb);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x1b);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0xc);
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),0x1c);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        (**(code **)(*plVar4 + 0xb0))(plVar4,uVar1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x14);
        (**(code **)(*plVar4 + 0xb0))(plVar4,3);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x1a);
        (**(code **)(*plVar4 + 0xb0))(plVar4,1);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x19);
        (**(code **)(*plVar4 + 0xb0))(plVar4,0);
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x18);
        (**(code **)(*plVar4 + 0xb0))(plVar4,0);
        if (param_5 == '\0') {
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x16);
        }
        else {
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x16);
        }
        (**(code **)(*plVar4 + 0xb0))(plVar4,param_5 != '\0');
      }
    }
    return plVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return (longlong *)0x0;
}

// ==== CUserKernel::helper_140329f30  @140329f30  [medium:callgraph-r1]  (orig: FUN_140329f30)
longlong * FUN_140329f30(undefined4 param_1,undefined4 param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = (longlong *)InstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"cq_operating_user_info");
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
  else {
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,1);
    (**(code **)(*plVar2 + 0xb8))(plVar2,param_1);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
    (**(code **)(*plVar2 + 0xb8))(plVar2,param_2);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,3);
    (**(code **)(*plVar2 + 0xd8))(plVar2,param_3);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    (**(code **)(*plVar2 + 0xb0))(plVar2,0);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,5);
    (**(code **)(*plVar2 + 0xb0))(plVar2,0);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,6);
    (**(code **)(*plVar2 + 0xb0))(plVar2,0);
  }
  return plVar1;
}

// ==== CUserKernel::helper_14035ac90  @14035ac90  [medium:callgraph-r2]  (orig: FUN_14035ac90)
int FUN_14035ac90(uint param_1)

{
  tm *ptVar1;
  __time64_t local_res10;
  __time64_t local_res18 [2];
  
  local_res10 = _time64((__time64_t *)0x0);
  ptVar1 = _localtime64(&local_res10);
  if (ptVar1 != (tm *)0x0) {
    if ((param_1 == 0) || (0x1e < param_1)) {
      param_1 = 0x1e;
    }
    ptVar1->tm_mday = ptVar1->tm_mday + param_1;
    local_res18[0] = _mktime64(ptVar1);
    if (local_res18[0] != -1) {
      ptVar1 = _localtime64(local_res18);
      if (ptVar1 != (tm *)0x0) {
        return (((((ptVar1->tm_year + 0x76c) % 100) * 100 + 1 + ptVar1->tm_mon) * 100 +
                ptVar1->tm_mday) * 100 + ptVar1->tm_hour) * 100 + ptVar1->tm_min;
      }
    }
  }
  return 0;
}

// ==== CUserKernel::helper_14035b1a0  @14035b1a0  [medium:callgraph-r1]  (orig: FUN_14035b1a0)
longlong * FUN_14035b1a0(int *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  if (*param_1 == 0) {
    plVar2 = (longlong *)0x0;
  }
  else {
    plVar2 = (longlong *)InstanceGet();
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,"cq_mail",*plVar2,param_4,uVar4);
    if (plVar2 != (longlong *)0x0) {
      iVar1 = FUN_14035ac90(param_1[0x55]);
      if (iVar1 == 0) {
        (**(code **)*plVar2)(plVar2,1);
        plVar2 = (longlong *)0x0;
      }
      else {
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,1);
        (**(code **)(*plVar3 + 0xb8))(plVar3,*param_1);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
        (**(code **)(*plVar3 + 0x80))(plVar3,param_1 + 1);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,3);
        (**(code **)(*plVar3 + 0x80))(plVar3,param_1 + 9);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
        (**(code **)(*plVar3 + 0x80))(plVar3,param_1 + 0x11);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,5);
        (**(code **)(*plVar3 + 0xa8))(plVar3,param_1[0x51]);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,6);
        (**(code **)(*plVar3 + 0xa8))(plVar3,param_1[0x52]);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,7);
        (**(code **)(*plVar3 + 0xb8))(plVar3,param_1[0x53]);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,8);
        (**(code **)(*plVar3 + 0xa8))(plVar3,iVar1);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,9);
        (**(code **)(*plVar3 + 0xb8))(plVar3,param_1[0x54]);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,10);
        (**(code **)(*plVar3 + 0xd8))(plVar3,(char)param_1[0x56]);
      }
    }
  }
  return plVar2;
}

