// ==== CMsgNpcServerLogin::ctor_or_dtor  @14045b790  [high:vtable-assign]  (orig: FUN_14045b790)
undefined8 * FUN_14045b790(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNpcServerLogin::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgNpcServerLogin::ctor_or_dtor  @14045b7e0  [high:vtable-assign]  (orig: FUN_14045b7e0)
void FUN_14045b7e0(undefined8 *param_1)

{
  *param_1 = CMsgNpcServerLogin::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgNpcServerLogin::vfunc_1  @14045b910  [high:rtti-vtable]  (orig: FUN_14045b910)
ulonglong FUN_14045b910(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3ea);
}

// ==== CMsgNpcServerLogin::ctor_or_dtor  @14045b940  [high:vtable-assign]  (orig: FUN_14045b940)
undefined8 * FUN_14045b940(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNpcServerLogin::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgNpcServerLogin::helper_14045b990  @14045b990  [medium:callgraph-r0]  (orig: FUN_14045b990)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14045b990(longlong param_1,undefined8 param_2,char param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  char *pcVar7;
  char *pcVar8;
  undefined1 uVar9;
  bool bVar10;
  undefined1 auStack_4e8 [32];
  char *local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  uVar9 = *(longlong **)(lVar3 + 0x80) == (longlong *)0x0;
  plVar5 = *(longlong **)(lVar3 + 0x80);
  if ((bool)uVar9) {
    local_4c8 = (char *)CONCAT44(local_4c8._4_4_,0x140);
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  lVar3 = *(longlong *)(param_1 + 0x428);
  lVar6 = 0x10;
  pcVar7 = (char *)(lVar3 + 4);
  pcVar8 = "NpcServer Tqdig";
  do {
    if (lVar6 == 0) break;
    lVar6 = lVar6 + -1;
    uVar9 = *pcVar7 == *pcVar8;
    pcVar7 = pcVar7 + 1;
    pcVar8 = pcVar8 + 1;
  } while ((bool)uVar9);
  if ((bool)uVar9) {
    lVar6 = 0x10;
    bVar10 = true;
    pcVar7 = (char *)(lVar3 + 0x14);
    pcVar8 = "skl8934##VJICW ";
    do {
      if (lVar6 == 0) break;
      lVar6 = lVar6 + -1;
      bVar10 = *pcVar7 == *pcVar8;
      pcVar7 = pcVar7 + 1;
      pcVar8 = pcVar8 + 1;
    } while (bVar10);
    if (bVar10) {
      if (param_3 != '\0') {
        local_4c8 = (char *)lVar3;
        (**(code **)(*plVar5 + 0x50))(plVar5,0xe,0x2720,0xea65);
      }
      local_4c8 = *(char **)(param_1 + 0x428);
      (**(code **)(*plVar5 + 0x50))(plVar5,0xe,0x2722,0xea65);
      FUN_14015b240(local_478);
      local_498 = 1;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = 0;
      local_4b8 = 0x835;
      local_4c0 = 0xffffff;
      local_4c8 = (char *)0x0;
      iVar2 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS","ANSWER_OK");
      if (iVar2 != 0) {
        plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        (**(code **)(*plVar4 + 0x30))(plVar4,0,local_478);
      }
      FUN_14015b2c0();
      lVar3 = -1;
      pcVar7 = "NPC server login OK.";
      do {
        if (lVar3 == 0) break;
        lVar3 = lVar3 + -1;
        cVar1 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar1 != '\0');
      local_4c8 = "NPC server login OK.";
      (**(code **)(*plVar5 + 0x50))(plVar5,0,0x9c41,~(uint)lVar3);
      return 1;
    }
  }
  FUN_14015b240(local_478);
  local_498 = 1;
  local_4a0 = 0;
  local_4a8 = 0;
  local_4b0 = 0;
  local_4b8 = 0x835;
  local_4c0 = 0xffffff;
  local_4c8 = (char *)0x0;
  iVar2 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS","ERROR: login refuse!");
  if (iVar2 != 0) {
    plVar5 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    (**(code **)(*plVar5 + 0x30))(plVar5,0,local_478);
  }
  FUN_14015b2c0(local_478);
  return 0;
}

// ==== CMsgNpcServerLogin::vfunc_3  @14045bc00  [high:rtti-vtable]  (orig: FUN_14045bc00)
void FUN_14045bc00(longlong param_1,undefined8 param_2)

{
  int iVar1;
  
  iVar1 = **(int **)(param_1 + 0x428);
  if ((iVar1 == 0x3ade68b1) || (iVar1 == 0x3ade68b2)) {
    FUN_14045b990(param_1,param_2,CONCAT31((int3)((uint)iVar1 >> 8),iVar1 == 0x3ade68b1));
  }
  return;
}

