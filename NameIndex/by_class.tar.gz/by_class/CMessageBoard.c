// ==== CMessageBoard::helper_1401097a0  @1401097a0  [medium:callgraph-r0]  (orig: FUN_1401097a0)
void FUN_1401097a0(void *param_1)

{
  if ((DAT_140975d00 & 1) == 0) {
    DAT_140975d00 = DAT_140975d00 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975cf8,"CMessageBoard");
    atexit((_func_5014 *)&LAB_1406d66d0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001401097f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975cf8,param_1);
  return;
}

// ==== CMessageBoard::helper_140109c00  @140109c00  [medium:callgraph-r0]  (orig: FUN_140109c00)
void FUN_140109c00(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  while (lVar1 != 0) {
    if ((*(longlong *)(param_1 + 0x38) != 0) &&
       (lVar1 = *(longlong *)(param_1 + 0x38) + -1, *(longlong *)(param_1 + 0x38) = lVar1,
       lVar1 == 0)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    lVar1 = *(longlong *)(param_1 + 0x38);
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  while (lVar1 != 0) {
    lVar1 = lVar1 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar1 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar1 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  return;
}

// ==== CMessageBoard::ctor_or_dtor  @14010a1c0  [high:vtable-assign]  (orig: FUN_14010a1c0)
void FUN_14010a1c0(undefined8 *param_1)

{
  *param_1 = CMessageBoard::vftable;
  FUN_140109c00(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CMessageBoard::ctor_or_dtor  @14010a8e0  [high:vtable-assign]  (orig: FUN_14010a8e0)
undefined8 * FUN_14010a8e0(undefined8 *param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CMessageBoard::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  *(undefined4 *)(param_1 + 9) = param_2;
  *(undefined4 *)((longlong)param_1 + 0x4c) = param_3;
  return param_1;
}

// ==== CMessageBoard::ctor_or_dtor  @14010a970  [high:vtable-assign]  (orig: FUN_14010a970)
undefined8 * FUN_14010a970(undefined8 *param_1,uint param_2)

{
  *param_1 = CMessageBoard::vftable;
  FUN_140109c00(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_1401097a0(param_1);
  }
  return param_1;
}

