// ==== CMsgInstance::helper_140247ff0  @140247ff0  [medium:callgraph-r0]  (orig: FUN_140247ff0)
void FUN_140247ff0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_1402467e0(param_1,param_3);
  if (lVar1 != 0) {
    FUN_140422340(lVar1,param_2);
  }
  return;
}

// ==== CMsgInstance::helper_140248900  @140248900  [medium:callgraph-r0]  (orig: FUN_140248900)
void FUN_140248900(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  char *pcVar14;
  undefined8 *puVar15;
  uint in_stack_ffffffffffffffc8;
  
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
  if (*(longlong *)(lVar7 + 0x90) == 0) {
    in_stack_ffffffffffffffc8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x98))(*(longlong **)(lVar7 + 0x90),param_2)
  ;
  if (plVar8 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar1 = (**(code **)(plVar8[2] + 0x220))(plVar8 + 2);
  if ((cVar1 != '\0') && (iVar2 = FUN_140166ec0(plVar8), iVar2 == 0)) {
    lVar7 = (**(code **)(plVar8[2] + 0x160))(plVar8 + 2);
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    cVar1 = FUN_14016cc60(lVar7);
    if ((cVar1 == '\0') && (lVar7 = FUN_1402464b0(param_1,param_2), lVar7 == 0)) {
      lVar7 = FUN_1402467e0(param_1,param_3);
      if (lVar7 == 0) {
        pIVar9 = theInstance();
        lVar7 = plVar8[2];
        pcVar14 = "STR_INSTANCE_FAIL";
        puVar15 = *(undefined8 **)pIVar9;
      }
      else {
        cVar1 = FUN_140421390(lVar7);
        if (cVar1 == '\0') {
          iVar2 = FUN_140421c00(lVar7);
          if (iVar2 == 0) {
            return;
          }
          uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
          plVar11 = (longlong *)FUN_140087650(uVar10);
          plVar11 = (longlong *)(**(code **)(*plVar11 + 0x98))(plVar11,iVar2);
          if (plVar11 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            return;
          }
          plVar12 = (longlong *)FUN_140118320();
          if (plVar12 != (longlong *)0x0) {
            lVar13 = *plVar12;
            uVar3 = (**(code **)(*plVar11 + 8))(plVar11);
            uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
            cVar1 = (**(code **)(lVar13 + 0x20))(plVar12,uVar4,uVar3);
            if (cVar1 != '\0') {
              uVar3 = FUN_140421020(lVar7);
              uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
              plVar11 = (longlong *)FUN_1400876b0(uVar10);
              lVar13 = (**(code **)(*plVar11 + 0x10))(plVar11,uVar3,1);
              if (lVar13 != 0) {
                uVar4 = FUN_140421080(lVar7,0);
                uVar5 = (**(code **)(**(longlong **)(lVar13 + 0x58) + 0x10))
                                  (*(longlong **)(lVar13 + 0x58),0xb);
                uVar6 = (**(code **)(**(longlong **)(lVar13 + 0x58) + 0x10))
                                  (*(longlong **)(lVar13 + 0x58),0xc);
                iVar2 = FUN_1401c55b0(plVar8,uVar3,uVar5,uVar6,
                                      in_stack_ffffffffffffffc8 & 0xffffff00);
                if (iVar2 != 0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                  return;
                }
                lVar13 = FUN_140248020(param_1,param_2,param_3,uVar4);
                if (lVar13 == 0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                  return;
                }
                FUN_140422340(lVar7,param_2);
                return;
              }
            }
          }
          pIVar9 = theInstance();
          lVar7 = plVar8[2];
          uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INSTANCE_FAIL");
          (**(code **)(lVar7 + 0x358))(plVar8 + 2,uVar10);
          return;
        }
        pIVar9 = theInstance();
        lVar7 = plVar8[2];
        pcVar14 = "STR_INSTANCE_INVITE_TIME_OUT";
        puVar15 = *(undefined8 **)pIVar9;
      }
      uVar10 = (*(code *)*puVar15)(pIVar9,pcVar14);
      (**(code **)(lVar7 + 0x358))(plVar8 + 2,uVar10);
    }
  }
  return;
}

// ==== CMsgInstance::helper_140421390  @140421390  [medium:callgraph-r1]  (orig: FUN_140421390)
bool FUN_140421390(longlong param_1)

{
  return *(int *)(param_1 + 0xac) == 0;
}

// ==== CMsgInstance::helper_140422340  @140422340  [medium:callgraph-r1]  (orig: FUN_140422340)
void FUN_140422340(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_14000d630(param_1 + 0x68,local_res10);
  return;
}

// ==== CMsgInstance::ctor_or_dtor  @140422f50  [high:vtable-assign]  (orig: FUN_140422f50)
undefined8 * FUN_140422f50(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInstance::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf((CStringPacker *)(param_1 + 0x86),(char *)(param_1 + 5),0x3e5,true);
  return param_1;
}

// ==== CMsgInstance::ctor_or_dtor  @140422fd0  [high:vtable-assign]  (orig: FUN_140422fd0)
void FUN_140422fd0(undefined8 *param_1)

{
  *param_1 = CMsgInstance::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgInstance::vfunc_1  @140423010  [high:rtti-vtable]  (orig: FUN_140423010)
ulonglong FUN_140423010(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x961);
}

// ==== CMsgInstance::ctor_or_dtor  @140423140  [high:vtable-assign]  (orig: FUN_140423140)
undefined8 * FUN_140423140(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInstance::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgInstance::vfunc_3  @1404231a0  [high:rtti-vtable]  (orig: FUN_1404231a0)
void FUN_1404231a0(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1)
  ;
  if (plVar4 != (longlong *)0x0) {
    if (**(short **)(param_1 + 0x428) == 1) {
      lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar3 = *(longlong *)(lVar3 + 0x120);
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar1 = *(longlong *)(param_1 + 0x428);
      uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
      FUN_140248900(lVar3,uVar2,*(undefined4 *)(lVar1 + 4));
    }
    else if (**(short **)(param_1 + 0x428) == 2) {
      lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar3 = *(longlong *)(lVar3 + 0x120);
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar1 = *(longlong *)(param_1 + 0x428);
      uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
      FUN_140247ff0(lVar3,uVar2,*(undefined4 *)(lVar1 + 4));
      return;
    }
  }
  return;
}

