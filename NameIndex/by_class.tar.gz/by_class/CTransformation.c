// ==== CTransformation::ctor_or_dtor  @1403b3100  [high:vtable-assign]  (orig: FUN_1403b3100)
undefined8 * FUN_1403b3100(undefined8 *param_1,undefined4 param_2)

{
  *(undefined4 *)((longlong)param_1 + 0x1c) = param_2;
  *param_1 = CTransformation::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  return param_1;
}

// ==== CTransformation::helper_1403b31f0  @1403b31f0  [medium:callgraph-r0]  (orig: FUN_1403b31f0)
void FUN_1403b31f0(void *param_1)

{
  if ((DAT_140976240 & 1) == 0) {
    DAT_140976240 = DAT_140976240 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976238,"CTransformation");
    atexit((_func_5014 *)&LAB_1406d6c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b3245. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976238,param_1);
  return;
}

// ==== CTransformation::ctor_or_dtor  @1403b32b0  [high:vtable-assign]  (orig: FUN_1403b32b0)
undefined8 * FUN_1403b32b0(undefined8 *param_1,byte param_2)

{
  *param_1 = CTransformation::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403b31f0();
  }
  return param_1;
}

