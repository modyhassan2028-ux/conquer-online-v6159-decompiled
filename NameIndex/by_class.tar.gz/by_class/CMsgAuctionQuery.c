// ==== CMsgAuctionQuery::helper_1400327c0  @1400327c0  [medium:callgraph-r1]  (orig: FUN_1400327c0)
void FUN_1400327c0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMsgAuctionQuery::helper_140033620  @140033620  [medium:callgraph-r1]  (orig: FUN_140033620)
void FUN_140033620(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 4)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 4);
  return;
}

// ==== CMsgAuctionQuery::helper_14022c740  @14022c740  [medium:callgraph-r3]  (orig: FUN_14022c740)
void FUN_14022c740(longlong param_1,longlong param_2,longlong *param_3,longlong *param_4)

{
  ulonglong uVar1;
  undefined8 uVar2;
  void *_Dst;
  void *pvVar3;
  longlong lVar4;
  rsize_t rVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  longlong local_48;
  void *local_40;
  longlong local_38;
  longlong local_30;
  
  local_48 = *param_4;
  local_40 = (void *)param_4[1];
  local_38 = *param_3;
  local_30 = param_3[1];
  if ((local_48 == 0) || (local_48 != local_38)) {
    _invalid_parameter_noinfo();
  }
  uVar8 = (longlong)local_40 - local_30 >> 3;
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar9 = 0;
  }
  else {
    uVar9 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  if (uVar8 != 0) {
    lVar4 = (longlong)*(void **)(param_1 + 0x20) - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < uVar8) {
                    /* WARNING: Subroutine does not return */
      FUN_140227e10();
    }
    uVar1 = lVar4 + uVar8;
    if (uVar9 < uVar1) {
      if (0x1fffffffffffffff - (uVar9 >> 1) < uVar9) {
        uVar9 = 0;
      }
      else {
        uVar9 = uVar9 + (uVar9 >> 1);
      }
      if (uVar9 < uVar1) {
        uVar9 = uVar1;
      }
      _Dst = (void *)FUN_1402291c0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      rVar5 = lVar4 * 8;
      if (lVar4 != 0) {
        memmove_s(_Dst,rVar5,*(void **)(param_1 + 0x18),rVar5);
      }
      local_38 = *param_4;
      local_30 = param_4[1];
      local_48 = *param_3;
      local_40 = (void *)param_3[1];
      pvVar3 = (void *)FUN_14022af60(param_1,&local_48,&local_38,(void *)((longlong)_Dst + rVar5));
      lVar4 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar4 != 0) {
        rVar5 = lVar4 << 3;
        memmove_s(pvVar3,rVar5,*(void **)(param_2 + 8),rVar5);
      }
      pvVar3 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar3 != (void *)0x0) {
        operator_delete(pvVar3);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (uVar8 + (lVar4 - (longlong)pvVar3 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else {
      local_38 = *param_4;
      local_30 = param_4[1];
      local_48 = *param_3;
      local_40 = (void *)param_3[1];
      lVar4 = local_30 - (longlong)local_40 >> 3;
      if (lVar4 != 0) {
        rVar5 = lVar4 << 3;
        memmove_s(*(void **)(param_1 + 0x20),rVar5,local_40,rVar5);
      }
      puVar7 = *(undefined8 **)(param_1 + 0x20);
      puVar6 = *(undefined8 **)(param_2 + 8);
      if (puVar6 != puVar7) {
        do {
          puVar7 = puVar7 + -1;
          if (puVar6 == puVar7) break;
          uVar2 = *puVar6;
          *puVar6 = *puVar7;
          *puVar7 = uVar2;
          puVar6 = puVar6 + 1;
        } while (puVar6 != puVar7);
      }
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      puVar7 = puVar6 + uVar8;
      if (puVar6 != puVar7) {
        do {
          puVar7 = puVar7 + -1;
          if (puVar6 == puVar7) break;
          uVar2 = *puVar6;
          *puVar6 = *puVar7;
          *puVar7 = uVar2;
          puVar6 = puVar6 + 1;
        } while (puVar6 != puVar7);
      }
      puVar7 = (undefined8 *)(uVar8 * 8 + *(longlong *)(param_1 + 0x20));
      puVar6 = *(undefined8 **)(param_2 + 8);
      if (puVar6 != puVar7) {
        do {
          puVar7 = puVar7 + -1;
          if (puVar6 == puVar7) break;
          uVar2 = *puVar6;
          *puVar6 = *puVar7;
          *puVar7 = uVar2;
          puVar6 = puVar6 + 1;
        } while (puVar6 != puVar7);
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + uVar8 * 8;
    }
  }
  return;
}

// ==== CMsgAuctionQuery::helper_14022d0e0  @14022d0e0  [medium:callgraph-r2]  (orig: FUN_14022d0e0)
void FUN_14022d0e0(longlong *param_1,undefined8 *param_2,undefined8 *param_3)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  ulonglong uVar1;
  longlong lVar2;
  undefined1 local_res8;
  longlong local_48;
  ulonglong uStack_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar2 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar2 * 8;
    if (0 < lVar2) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_48 = *param_1;
  local_38 = *param_3;
  local_30 = param_3[1];
  local_28 = *param_2;
  local_20 = param_2[1];
  uStack_40 = uVar1;
  FUN_14022c740(param_1,&local_48,&local_28,&local_38,local_res8);
  return;
}

// ==== CMsgAuctionQuery::helper_14022e520  @14022e520  [medium:callgraph-r1]  (orig: FUN_14022e520)
undefined8 FUN_14022e520(longlong param_1,uint param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  undefined1 local_res8;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  ulonglong uStack_30;
  longlong *local_28;
  ulonglong uStack_20;
  
  FUN_14022bf20(param_3);
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x51);
  puVar5 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar5 = puVar9;
    puVar9 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x51);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x80);
  local_40 = puVar5;
  local_48 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar9) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar8 = &local_38;
    uStack_30 = *(undefined8 *)(param_1 + 0x80);
    local_38 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar8 = &local_48;
  }
  plVar2 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x80);
  local_28 = plVar2;
  uStack_20 = plVar8[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  uVar6 = uStack_20;
  if (uStack_20 != lVar10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (uVar6 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar3 = *(ulonglong *)(uVar6 + 0x40);
    if (uVar3 < *(ulonglong *)(uVar6 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    local_28 = *(longlong **)(uVar6 + 0x20);
    uVar4 = *(ulonglong *)(uVar6 + 0x38);
    uStack_20 = uVar3;
    if (*(ulonglong *)(uVar6 + 0x40) < uVar4) {
      _invalid_parameter_noinfo();
    }
    local_38 = *(longlong *)(uVar6 + 0x20);
    uStack_30 = uVar4;
    FUN_14022d0e0(param_3,&local_38,&local_28,local_res8);
  }
  return 1;
}

// ==== CMsgAuctionQuery::helper_14022ea70  @14022ea70  [medium:callgraph-r0]  (orig: FUN_14022ea70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14022ea70(undefined8 param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined1 auStack_568 [32];
  undefined4 local_548;
  longlong *local_538 [3];
  longlong *local_520;
  longlong *local_518;
  undefined8 local_510;
  longlong *local_508;
  undefined8 local_500;
  longlong *local_4f8;
  ulonglong local_4f0;
  undefined8 local_4e8;
  longlong *local_4e0;
  longlong *local_4d0;
  undefined4 local_4b8;
  undefined2 local_4b4;
  undefined4 local_4b0;
  undefined4 local_4ac;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined1 local_49c;
  undefined4 local_498;
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined4 local_480;
  undefined4 local_47c;
  undefined4 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_4e8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  local_500 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_548 = 0x651;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_508 = operator_new(8);
    if (local_508 == (longlong *)0x0) {
      local_538[0] = (longlong *)0x0;
    }
    else {
      *local_508 = (longlong)local_538;
      local_538[0] = local_508;
    }
    plVar7 = (longlong *)0x0;
    local_520 = (longlong *)0x0;
    local_518 = (longlong *)0x0;
    local_510 = 0;
    local_4f8 = local_508;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    cVar3 = FUN_14022e390(param_1,uVar4,local_538);
    if (cVar3 == '\0') {
      if (local_520 != (longlong *)0x0) {
        operator_delete(local_520);
      }
      local_520 = (longlong *)0x0;
      local_518 = (longlong *)0x0;
      local_510 = 0;
      operator_delete(local_538[0]);
    }
    else if (((longlong)local_518 - (longlong)local_520 & 0xfffffffffffffff8U) == 0) {
      if (local_520 != (longlong *)0x0) {
        operator_delete(local_520);
      }
      local_520 = (longlong *)0x0;
      local_518 = (longlong *)0x0;
      local_510 = 0;
      operator_delete(local_538[0]);
    }
    else {
      FUN_14041fbd0(local_468);
      local_4f8 = (longlong *)((longlong)local_518 - (longlong)local_520 >> 3);
      cVar3 = FUN_14041fc80(local_468,0,(ulonglong)local_4f8 & 0xffff);
      if (cVar3 == '\0') {
        FUN_14041fc20(local_468);
        if (local_520 != (longlong *)0x0) {
          operator_delete(local_520);
        }
        local_520 = (longlong *)0x0;
        local_518 = (longlong *)0x0;
        local_510 = 0;
        operator_delete(local_538[0]);
      }
      else {
        plVar5 = (longlong *)_time64((__time64_t *)0x0);
        plVar9 = local_520;
        local_4e0 = (longlong *)0x0;
        local_508 = plVar5;
        if (local_518 < local_520) {
          _invalid_parameter_noinfo();
        }
        plVar2 = local_538[0];
        local_4e0 = local_538[0];
        while( true ) {
          plVar8 = local_518;
          local_4d0 = (longlong *)0x0;
          if (local_518 < local_520) {
            _invalid_parameter_noinfo();
          }
          local_4d0 = local_538[0];
          if ((plVar2 == (longlong *)0x0) || (plVar2 != local_538[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar8) break;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar7;
          }
          else {
            plVar8 = (longlong *)*plVar2;
          }
          if ((longlong *)plVar8[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          lVar1 = *plVar9;
          if ((lVar1 != 0) && (cVar3 = FUN_14041e650(lVar1,plVar5), cVar3 == '\0')) {
            plVar5 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_548 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar5 = plVar7;
            }
            lVar6 = *plVar5;
            uVar4 = FUN_14041e8c0(lVar1);
            lVar6 = (**(code **)(lVar6 + 0x60))(plVar5,uVar4);
            plVar5 = local_508;
            if (lVar6 != 0) {
              local_4b8 = 0;
              local_4b4 = 0;
              local_4b0 = 0;
              local_49c = 1;
              local_498 = 0;
              local_494 = 0;
              local_490 = 0;
              local_48c = 0;
              local_488 = 0;
              local_4ac = 0;
              local_4a8 = 0;
              local_4a4 = 0;
              local_4a0 = 0;
              local_484 = 0;
              local_480 = 0;
              local_47c = 0;
              local_478 = 0;
              cVar3 = FUN_14041f330(lVar1,&local_4b8);
              plVar5 = local_508;
              if (cVar3 != '\0') {
                FUN_14022b560(local_500,param_2,lVar6);
                cVar3 = FUN_14041fd00(local_468,&local_4b8);
                plVar5 = local_508;
                if (cVar3 == '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
                  local_4f0 = (longlong)local_518 - (longlong)local_520 >> 3;
                  cVar3 = FUN_14041fc80(local_468,0,local_4f0 & 0xffff);
                  plVar5 = local_508;
                  if (cVar3 != '\0') {
                    FUN_14041fd00(local_468,&local_4b8);
                    plVar5 = local_508;
                  }
                }
              }
            }
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar7;
          }
          else {
            plVar8 = (longlong *)*plVar2;
          }
          if ((longlong *)plVar8[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          plVar9 = plVar9 + 1;
        }
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
        FUN_14041fc20(local_468);
        if (local_520 != (longlong *)0x0) {
          operator_delete(local_520);
        }
        local_520 = (longlong *)0x0;
        local_518 = (longlong *)0x0;
        local_510 = 0;
        operator_delete(local_538[0]);
      }
    }
  }
  return;
}

// ==== CMsgAuctionQuery::helper_14022ef00  @14022ef00  [medium:callgraph-r0]  (orig: FUN_14022ef00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14022ef00(undefined8 param_1,longlong *param_2,longlong *param_3)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  longlong lVar3;
  longlong *plVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined4 *puVar13;
  undefined1 auStack_598 [32];
  undefined4 local_578;
  longlong *local_568 [3];
  longlong *local_550;
  longlong *local_548;
  undefined8 local_540;
  longlong *local_538;
  undefined8 local_530;
  longlong *local_528;
  undefined8 *local_520;
  longlong *local_510;
  longlong *local_500;
  undefined8 local_4f0;
  ulonglong local_4e8;
  ulonglong local_4e0;
  undefined8 *local_4d8;
  undefined4 local_4c8;
  undefined2 local_4c4;
  undefined4 local_4c0;
  undefined4 local_4bc;
  undefined4 local_4b8;
  undefined4 local_4b4;
  undefined4 local_4b0;
  undefined1 local_4ac;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined4 local_49c;
  undefined4 local_498;
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4f0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  local_530 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_578 = 0x690;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_538 = operator_new(8);
    if (local_538 == (longlong *)0x0) {
      local_568[0] = (longlong *)0x0;
    }
    else {
      *local_538 = (longlong)local_568;
      local_568[0] = local_538;
    }
    plVar11 = (longlong *)0x0;
    local_550 = (longlong *)0x0;
    local_548 = (longlong *)0x0;
    local_540 = 0;
    local_528 = local_538;
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    cVar5 = FUN_14022e520(param_1,uVar6,local_568);
    if (cVar5 == '\0') {
      if (local_550 != (longlong *)0x0) {
        operator_delete(local_550);
      }
      local_550 = (longlong *)0x0;
      local_548 = (longlong *)0x0;
      local_540 = 0;
      operator_delete(local_568[0]);
    }
    else {
      local_538 = (longlong *)_time64((__time64_t *)0x0);
      puVar13 = (undefined4 *)param_3[3];
      local_520 = (undefined8 *)0x0;
      if ((undefined4 *)param_3[4] < puVar13) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (undefined8 *)*param_3;
      local_520 = puVar1;
      while( true ) {
        puVar2 = (undefined4 *)param_3[4];
        local_4d8 = (undefined8 *)0x0;
        if (puVar2 < (undefined4 *)param_3[3]) {
          _invalid_parameter_noinfo();
        }
        local_4d8 = (undefined8 *)*param_3;
        if ((puVar1 == (undefined8 *)0x0) || (puVar1 != local_4d8)) {
          _invalid_parameter_noinfo();
        }
        if (puVar13 == puVar2) break;
        if (puVar1 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = plVar11;
        }
        else {
          plVar9 = (longlong *)*puVar1;
        }
        if ((undefined4 *)plVar9[4] <= puVar13) {
          _invalid_parameter_noinfo();
        }
        plVar9 = (longlong *)FUN_14022b140(param_1,*puVar13);
        local_528 = plVar9;
        if ((plVar9 != (longlong *)0x0) && (cVar5 = FUN_14041e650(plVar9,local_538), cVar5 == '\0'))
        {
          iVar7 = (**(code **)(*param_2 + 8))(param_2);
          iVar8 = FUN_14041e710(plVar9,10);
          if (iVar8 != iVar7) {
            FUN_14022ce90(local_568,&local_528);
          }
        }
        if (puVar1 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = plVar11;
        }
        else {
          plVar9 = (longlong *)*puVar1;
        }
        if ((undefined4 *)plVar9[4] <= puVar13) {
          _invalid_parameter_noinfo();
        }
        puVar13 = puVar13 + 1;
        param_1 = local_530;
      }
      FUN_14041fbd0(local_478);
      local_4e8 = (longlong)local_548 - (longlong)local_550 >> 3;
      cVar5 = FUN_14041fc80(local_478,1,local_4e8 & 0xffff);
      plVar9 = local_550;
      if (cVar5 == '\0') {
        FUN_14041fc20(local_478);
        if (local_550 != (longlong *)0x0) {
          operator_delete(local_550);
        }
        local_550 = (longlong *)0x0;
        local_548 = (longlong *)0x0;
        local_540 = 0;
        operator_delete(local_568[0]);
      }
      else {
        local_510 = (longlong *)0x0;
        if (local_548 < local_550) {
          _invalid_parameter_noinfo();
        }
        plVar4 = local_568[0];
        local_510 = local_568[0];
        while( true ) {
          plVar12 = local_548;
          local_500 = (longlong *)0x0;
          if (local_548 < local_550) {
            _invalid_parameter_noinfo();
          }
          local_500 = local_568[0];
          if ((plVar4 == (longlong *)0x0) || (plVar4 != local_568[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar12) break;
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar12 = plVar11;
          }
          else {
            plVar12 = (longlong *)*plVar4;
          }
          if ((longlong *)plVar12[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          lVar3 = *plVar9;
          if ((lVar3 != 0) && (cVar5 = FUN_14041e650(lVar3,local_538), cVar5 == '\0')) {
            plVar12 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_578 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar12 = plVar11;
            }
            lVar10 = *plVar12;
            uVar6 = FUN_14041e8c0(lVar3);
            lVar10 = (**(code **)(lVar10 + 0x60))(plVar12,uVar6);
            if (lVar10 != 0) {
              local_4c8 = 0;
              local_4c4 = 0;
              local_4c0 = 0;
              local_4ac = 1;
              local_4a8 = 0;
              local_4a4 = 0;
              local_4a0 = 0;
              local_49c = 0;
              local_498 = 0;
              local_4bc = 0;
              local_4b8 = 0;
              local_4b4 = 0;
              local_4b0 = 0;
              local_494 = 0;
              local_490 = 0;
              local_48c = 0;
              local_488 = 0;
              cVar5 = FUN_14041f330(lVar3,&local_4c8);
              if (cVar5 != '\0') {
                FUN_14022b560(local_530,param_2,lVar10);
                cVar5 = FUN_14041fd00(local_478,&local_4c8);
                if (cVar5 == '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                  local_4e0 = (longlong)local_548 - (longlong)local_550 >> 3;
                  cVar5 = FUN_14041fc80(local_478,1,local_4e0 & 0xffff);
                  if (cVar5 != '\0') {
                    FUN_14041fd00(local_478,&local_4c8);
                  }
                }
              }
            }
          }
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar12 = plVar11;
          }
          else {
            plVar12 = (longlong *)*plVar4;
          }
          if ((longlong *)plVar12[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          plVar9 = plVar9 + 1;
        }
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
        FUN_14041fc20(local_478);
        if (local_550 != (longlong *)0x0) {
          operator_delete(local_550);
        }
        local_550 = (longlong *)0x0;
        local_548 = (longlong *)0x0;
        local_540 = 0;
        operator_delete(local_568[0]);
      }
    }
  }
  return;
}

// ==== CMsgAuctionQuery::ctor_or_dtor  @14041fbd0  [high:vtable-assign]  (orig: FUN_14041fbd0)
undefined8 * FUN_14041fbd0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAuctionQuery::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAuctionQuery::ctor_or_dtor  @14041fc20  [high:vtable-assign]  (orig: FUN_14041fc20)
void FUN_14041fc20(undefined8 *param_1)

{
  *param_1 = CMsgAuctionQuery::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAuctionQuery::vfunc_1  @14041fc50  [high:rtti-vtable]  (orig: FUN_14041fc50)
ulonglong FUN_14041fc50(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x52a);
}

// ==== CMsgAuctionQuery::helper_14041fc80  @14041fc80  [medium:callgraph-r1]  (orig: FUN_14041fc80)
undefined8 FUN_14041fc80(longlong param_1,undefined2 param_2,undefined2 param_3)

{
  longlong lVar1;
  ulong uVar2;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x52a;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  uVar2 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 8) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgAuctionQuery::helper_14041fd00  @14041fd00  [medium:callgraph-r1]  (orig: FUN_14041fd00)
ulonglong FUN_14041fd00(longlong param_1,void *param_2)

{
  short *psVar1;
  ulonglong uVar2;
  
  uVar2 = (longlong)*(int *)(param_1 + 0xc) + 0x44;
  if (0x3ff < uVar2) {
    return uVar2 & 0xffffffffffffff00;
  }
  memcpy((void *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 8) * 0x44 + 0x10 +
                 *(longlong *)(param_1 + 0x428)),param_2,0x44);
  psVar1 = (short *)(*(longlong *)(param_1 + 0x428) + 8);
  *psVar1 = *psVar1 + 1;
  *(uint *)(param_1 + 0xc) = (uint)*(ushort *)(*(longlong *)(param_1 + 0x428) + 8) * 0x44 + 0x10;
  return CONCAT71((int7)((ulonglong)*(longlong *)(param_1 + 0x428) >> 8),1);
}

// ==== CMsgAuctionQuery::ctor_or_dtor  @14041fd70  [high:vtable-assign]  (orig: FUN_14041fd70)
undefined8 * FUN_14041fd70(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAuctionQuery::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAuctionQuery::helper_14041fe00  @14041fe00  [medium:callgraph-r1]  (orig: FUN_14041fe00)
void * FUN_14041fe00(undefined8 param_1,longlong param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_3 + 8) - (longlong)*(void **)(param_2 + 8) >> 2;
  _DstSize = lVar1 * 4;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,*(void **)(param_2 + 8),_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CMsgAuctionQuery::helper_14041fe70  @14041fe70  [medium:callgraph-r0]  (orig: FUN_14041fe70)
void FUN_14041fe70(undefined8 *param_1,ulonglong param_2)

{
  void *pvVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 local_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if (0x3fffffffffffffff < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1400327c0();
  }
  if (param_1[3] == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - param_1[3]) >> 2;
  }
  if (uVar3 < param_2) {
    lVar4 = FUN_140033620(param_1 + 2);
    uVar3 = param_1[4];
    if (uVar3 < (ulonglong)param_1[3]) {
      _invalid_parameter_noinfo();
    }
    local_48 = (undefined4)*param_1;
    uStack_44 = (undefined4)((ulonglong)*param_1 >> 0x20);
    uStack_40 = (undefined4)uVar3;
    uStack_3c = (undefined4)(uVar3 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uVar3 = param_1[3];
    if ((ulonglong)param_1[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    local_38 = (undefined4)*param_1;
    uStack_34 = (undefined4)((ulonglong)*param_1 >> 0x20);
    uStack_30 = (undefined4)uVar3;
    uStack_2c = (undefined4)(uVar3 >> 0x20);
    local_18 = local_38;
    uStack_14 = uStack_34;
    uStack_10 = uStack_30;
    uStack_c = uStack_2c;
    FUN_14041fe00(param_1,&local_18,&local_28,lVar4);
    pvVar1 = (void *)param_1[3];
    lVar2 = param_1[4];
    if (pvVar1 != (void *)0x0) {
      operator_delete(pvVar1);
    }
    param_1[5] = lVar4 + param_2 * 4;
    param_1[4] = lVar4 + (lVar2 - (longlong)pvVar1 >> 2) * 4;
    param_1[3] = lVar4;
  }
  return;
}

// ==== CMsgAuctionQuery::vfunc_3  @14041ffa0  [high:rtti-vtable]  (orig: FUN_14041ffa0)
void FUN_14041ffa0(longlong param_1,longlong param_2)

{
  short sVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  uint uVar10;
  longlong *local_60 [3];
  void *local_48;
  undefined8 local_40;
  undefined8 local_38;
  longlong *plVar11;
  
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar4 = FUN_14008a710(uVar6);
  if ((cVar4 == '\0') && (param_2 != 0)) {
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_140087650(uVar6);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x88))(plVar7,param_1);
    if (plVar7 != (longlong *)0x0) {
      plVar8 = (longlong *)FUN_1400e1e60();
      lVar3 = plVar7[0x1e2];
      lVar9 = *plVar8;
      puVar2 = *(undefined4 **)(param_1 + 0x428);
      uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
      (**(code **)(lVar9 + 0x108))(plVar8,uVar5,(int)lVar3,*puVar2);
      sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 4);
      if (sVar1 == 0) {
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087a10(uVar6);
        FUN_14022ea70(uVar6,plVar7);
      }
      else if ((sVar1 == 1) &&
              ((int)((uint)*(ushort *)(*(longlong *)(param_1 + 0x428) + 8) * 4 + 0xc) <=
               *(int *)(param_1 + 0xc))) {
        plVar8 = operator_new(8);
        plVar11 = (longlong *)0x0;
        local_60[0] = plVar11;
        if (plVar8 != (longlong *)0x0) {
          *plVar8 = (longlong)local_60;
          local_60[0] = plVar8;
        }
        local_48 = (void *)0x0;
        local_40 = 0;
        local_38 = 0;
        sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 8);
        if (sVar1 != 0) {
          FUN_14041fe70(local_60,sVar1);
          lVar9 = *(longlong *)(param_1 + 0x428);
          if (*(short *)(lVar9 + 8) != 0) {
            do {
              FUN_140037fe0(local_60,lVar9 + 0xc + (longlong)(int)plVar11 * 4);
              uVar10 = (int)plVar11 + 1;
              plVar11 = (longlong *)(ulonglong)uVar10;
              lVar9 = *(longlong *)(param_1 + 0x428);
            } while ((int)uVar10 < (int)(uint)*(ushort *)(lVar9 + 8));
          }
        }
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140087a10(uVar6);
        FUN_14022ef00(uVar6,plVar7,local_60);
        if (local_48 != (void *)0x0) {
          operator_delete(local_48);
        }
        local_48 = (void *)0x0;
        local_40 = 0;
        local_38 = 0;
        operator_delete(local_60[0]);
      }
    }
  }
  return;
}

