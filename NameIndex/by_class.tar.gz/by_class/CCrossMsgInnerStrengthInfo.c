// ==== CCrossMsgInnerStrengthInfo::helper_1401f5620  @1401f5620  [medium:callgraph-r1]  (orig: FUN_1401f5620)
longlong * FUN_1401f5620(longlong *param_1,longlong *param_2,ushort *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x139) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(ushort *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x139) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(ushort *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CCrossMsgInnerStrengthInfo::helper_1401f5ea0  @1401f5ea0  [medium:callgraph-r0]  (orig: FUN_1401f5ea0)
void FUN_1401f5ea0(longlong param_1,longlong *param_2,longlong param_3,ushort param_4)

{
  longlong lVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_78;
  int local_74;
  undefined8 local_70;
  longlong *local_68;
  longlong local_60;
  longlong *local_58;
  longlong *local_48;
  
  local_70 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 < 0xcd) {
    local_78 = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401f5550(param_1 + 0x18,&local_68,&local_78);
    plVar3 = local_68;
    lVar1 = *(longlong *)(param_1 + 0x48);
    local_58 = *(longlong **)(param_1 + 0x18);
    if ((local_68 == (longlong *)0x0) || (local_68 != local_58)) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_60;
    if (local_60 == lVar1) {
      (**(code **)(*param_2 + 0x38))(param_2);
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR(
                        "CInnerStrengthMgr::LoadOSUserData not found user data, idUser:%u, idOSUser:%u."
                        );
    }
    else {
      local_74 = 0;
      while (iVar2 = local_74, local_74 < (int)(uint)param_4) {
        lVar1 = param_3 + (longlong)local_74 * 5;
        FUN_1401f5620(param_1 + 0x58,&local_68,lVar1);
        lVar5 = *(longlong *)(param_1 + 0x88);
        local_48 = *(longlong **)(param_1 + 0x58);
        if ((local_68 == (longlong *)0x0) || (local_68 != local_48)) {
          _invalid_parameter_noinfo();
        }
        if (local_60 == lVar5) {
          (**(code **)(*param_2 + 0x38))(param_2);
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CInnerStrengthMgr::LoadOSUserData not found type info, idUser:%u, idOSUser:%u, type:%u."
                            );
        }
        else {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar3;
          }
          if (lVar4 == *(longlong *)(lVar5 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_140405a20(*(undefined8 *)(lVar4 + 0x20),lVar1);
        }
        local_74 = iVar2 + 1;
      }
    }
  }
  return;
}

// ==== CCrossMsgInnerStrengthInfo::helper_1401f60d0  @1401f60d0  [medium:callgraph-r0]  (orig: FUN_1401f60d0)
void FUN_1401f60d0(longlong param_1,longlong *param_2,longlong param_3,ushort param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined4 local_res10 [2];
  longlong *local_28;
  longlong local_20;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (param_3 != 0) {
    if (param_4 < 0x93) {
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401f5550(param_1 + 0x18,&local_28,local_res10);
      lVar2 = *(longlong *)(param_1 + 0x48);
      if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0x18))) {
        _invalid_parameter_noinfo();
      }
      if (local_20 == lVar2) {
        (**(code **)(*param_2 + 0x38))(param_2);
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CInnerStrengthMgr::AppendOSUserAttrib not found user data, idUser:%u, idOSUser:%u."
                          );
      }
      else {
        uVar1 = (ulonglong)param_4;
        if (param_4 != 0) {
          do {
            if (local_28 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar2 = 0;
            }
            else {
              lVar2 = *local_28;
            }
            if (local_20 == *(longlong *)(lVar2 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140405c30(*(undefined8 *)(local_20 + 0x20),param_3);
            param_3 = param_3 + 7;
            uVar1 = uVar1 - 1;
          } while (uVar1 != 0);
        }
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CCrossMsgInnerStrengthInfo::helper_140405a20  @140405a20  [medium:callgraph-r1]  (orig: FUN_140405a20)
void FUN_140405a20(longlong param_1,undefined2 *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined2 local_50 [4];
  longlong local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined1 local_28 [32];
  
  plVar1 = (longlong *)InstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"cq_inner_strength_player");
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,0);
    (**(code **)(*plVar2 + 0xb8))(plVar2,*(undefined4 *)(param_1 + 0xd8));
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,1);
    (**(code **)(*plVar2 + 0xb8))(plVar2,*(undefined4 *)(param_1 + 0xd0));
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
    (**(code **)(*plVar2 + 200))(plVar2,*param_2);
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,3);
    (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)(param_2 + 1));
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)((longlong)param_2 + 3));
    plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,6);
    (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)(param_2 + 2));
    (**(code **)(*plVar1 + 0x58))(plVar1);
    *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + 1;
    lVar3 = FUN_1404dbf30(*(undefined4 *)(param_1 + 0xd0),plVar1,1);
    if (lVar3 == 0) {
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::AppendOSUserData CreateNew failed, idUser:%u, type:%u."
                        );
    }
    else {
      local_40 = 0;
      local_50[0] = FUN_1404db500(lVar3);
      local_48 = lVar3;
      puVar4 = (undefined8 *)FUN_140404dd0(param_1 + 0x50,local_28,local_50);
      local_40 = *puVar4;
      local_38 = puVar4[1];
      local_30 = puVar4[2];
      if ((char)local_30 == '\0') {
        FUN_1404db500(lVar3);
        log_InlineLogERROR("CInnerStrengthPlayer::AppendOSUserData type repeat, idUser:%u, type:%d."
                          );
        FUN_1404dbee0(lVar3);
      }
      else {
        *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + (uint)*(byte *)((longlong)param_2 + 3)
        ;
      }
    }
  }
  return;
}

// ==== CCrossMsgInnerStrengthInfo::helper_140405c30  @140405c30  [medium:callgraph-r1]  (orig: FUN_140405c30)
void FUN_140405c30(longlong param_1,longlong param_2,undefined8 param_3,undefined1 param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong *local_38;
  longlong lStack_30;
  longlong *local_28 [2];
  
  FUN_140405340(param_1 + 0x50,&local_38,param_2,param_4,0xfffffffffffffffe);
  lVar1 = *(longlong *)(param_1 + 0x80);
  lVar2 = 0;
  local_28[0] = *(longlong **)(param_1 + 0x50);
  if ((local_38 == (longlong *)0x0) || (local_38 != local_28[0])) {
    _invalid_parameter_noinfo();
  }
  if (lStack_30 == lVar1) {
    log_InlineLogERROR(
                      "CInnerStrengthPlayer::AppendOSUserAttrib not found inner strength data, idUser:%u, type:%u."
                      );
  }
  else {
    if (local_38 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = lVar2;
    }
    else {
      lVar1 = *local_38;
    }
    if (lStack_30 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lStack_30 + 0x20) == 0) {
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::AppendOSUserAttrib data is null, idUser:%u, type:%u."
                        );
      FUN_140404f80(param_1 + 0x50,local_28,&local_38);
    }
    else {
      if (local_38 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar2 = *local_38;
      }
      if (lStack_30 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1404db730(*(undefined8 *)(lStack_30 + 0x20),*(byte *)(param_2 + 2) + 7,
                    *(undefined4 *)(param_2 + 3),1);
    }
  }
  return;
}

// ==== CCrossMsgInnerStrengthInfo::ctor_or_dtor  @14045d010  [high:vtable-assign]  (orig: FUN_14045d010)
undefined8 * FUN_14045d010(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgInnerStrengthInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  param_1[0x86] = 0;
  return param_1;
}

// ==== CCrossMsgInnerStrengthInfo::ctor_or_dtor  @14045d060  [high:vtable-assign]  (orig: FUN_14045d060)
void FUN_14045d060(undefined8 *param_1)

{
  *param_1 = CCrossMsgInnerStrengthInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgInnerStrengthInfo::vfunc_5  @14045d090  [high:rtti-vtable]  (orig: FUN_14045d090)
bool FUN_14045d090(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c5a;
    }
  }
  return false;
}

// ==== CCrossMsgInnerStrengthInfo::ctor_or_dtor  @14045d4e0  [high:vtable-assign]  (orig: FUN_14045d4e0)
undefined8 * FUN_14045d4e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgInnerStrengthInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgInnerStrengthInfo::vfunc_3  @14045d530  [high:rtti-vtable]  (orig: FUN_14045d530)
void FUN_14045d530(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_1402af110(*(undefined8 *)(lVar3 + 0x90),uVar2,uVar1);
  if (lVar3 == 0) {
    log_InlineLogOSWARNING
              (
              "CCrossMsgInnerStrengthInfo::Process UserManager GetCreatedOSUser failed. server id:%u, os user id:%u."
              );
  }
  else {
    *(ulonglong *)(param_1 + 0x430) =
         (ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 4 + (longlong)*(ushort **)(param_1 + 0x428)
    ;
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar5 = *(longlong *)(lVar4 + 0x1d0);
    if (*(longlong *)(lVar4 + 0x1d0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    FUN_1401f5ea0(lVar5,lVar3,*(undefined2 **)(param_1 + 0x428) + 2,
                  **(undefined2 **)(param_1 + 0x428));
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar5 = *(longlong *)(lVar5 + 0x1d0);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    FUN_1401f60d0(lVar5,lVar3,*(undefined8 *)(param_1 + 0x430),
                  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2));
  }
  return;
}

