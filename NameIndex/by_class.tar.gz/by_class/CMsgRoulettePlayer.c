// ==== CMsgRoulettePlayer::ctor_or_dtor  @1404dddf0  [high:vtable-assign]  (orig: FUN_1404dddf0)
undefined8 * FUN_1404dddf0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRoulettePlayer::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRoulettePlayer::ctor_or_dtor  @1404dde40  [high:vtable-assign]  (orig: FUN_1404dde40)
void FUN_1404dde40(undefined8 *param_1)

{
  *param_1 = CMsgRoulettePlayer::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRoulettePlayer::vfunc_1  @1404dde70  [high:rtti-vtable]  (orig: FUN_1404dde70)
ulonglong FUN_1404dde70(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf9);
}

// ==== CMsgRoulettePlayer::vfunc_3  @1404ddf70  [high:rtti-vtable]  (orig: FUN_1404ddf70)
void FUN_1404ddf70(void)

{
  return;
}

// ==== CMsgRoulettePlayer::ctor_or_dtor  @1404ddf80  [high:vtable-assign]  (orig: FUN_1404ddf80)
undefined8 * FUN_1404ddf80(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRoulettePlayer::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

