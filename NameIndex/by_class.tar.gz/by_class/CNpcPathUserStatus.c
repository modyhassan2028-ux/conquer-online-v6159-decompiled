// ==== CNpcPathUserStatus::helper_1403a0450  @1403a0450  [medium:callgraph-r0]  (orig: FUN_1403a0450)
void FUN_1403a0450(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CNpcPathUserStatus::vfunc_0  @1403a0580  [high:rtti-vtable]  (orig: FUN_1403a0580)
void * FUN_1403a0580(void *param_1,uint param_2)

{
  FUN_1404d9ec0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CNpcPathUserStatus::helper_1403a0840  @1403a0840  [medium:callgraph-r1]  (orig: FUN_1403a0840)
longlong FUN_1403a0840(longlong param_1,longlong param_2,longlong param_3)

{
  for (; param_1 != param_2; param_2 = param_2 + -0x40) {
    *(undefined1 *)(param_3 + -0x38) = *(undefined1 *)(param_2 + -0x38);
    *(undefined4 *)(param_3 + -0x34) = *(undefined4 *)(param_2 + -0x34);
    *(undefined4 *)(param_3 + -0x30) = *(undefined4 *)(param_2 + -0x30);
    *(undefined4 *)(param_3 + -0x2c) = *(undefined4 *)(param_2 + -0x2c);
    *(undefined4 *)(param_3 + -0x28) = *(undefined4 *)(param_2 + -0x28);
    *(undefined4 *)(param_3 + -0x24) = *(undefined4 *)(param_2 + -0x24);
    *(undefined4 *)(param_3 + -0x20) = *(undefined4 *)(param_2 + -0x20);
    *(undefined8 *)(param_3 + -0x1c) = *(undefined8 *)(param_2 + -0x1c);
    *(undefined1 *)(param_3 + -0x14) = *(undefined1 *)(param_2 + -0x14);
    *(undefined4 *)(param_3 + -0x10) = *(undefined4 *)(param_2 + -0x10);
    *(undefined1 *)(param_3 + -0xc) = *(undefined1 *)(param_2 + -0xc);
    *(undefined8 *)(param_3 + -8) = *(undefined8 *)(param_2 + -8);
    param_3 = param_3 + -0x40;
  }
  return param_3;
}

// ==== CNpcPathUserStatus::helper_1403a10b0  @1403a10b0  [medium:callgraph-r0]  (orig: FUN_1403a10b0)
void FUN_1403a10b0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x40)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 << 6);
  return;
}

// ==== CNpcPathUserStatus::ctor_or_dtor  @1403a1280  [high:vtable-assign]  (orig: FUN_1403a1280)
void FUN_1403a1280(undefined8 param_1,undefined8 *param_2,longlong param_3)

{
  if (param_2 != (undefined8 *)0x0) {
    *param_2 = CNpcPathUserStatus::vftable;
    *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_3 + 8);
    *(undefined4 *)((longlong)param_2 + 0xc) = *(undefined4 *)(param_3 + 0xc);
    *(undefined4 *)(param_2 + 2) = *(undefined4 *)(param_3 + 0x10);
    *(undefined4 *)((longlong)param_2 + 0x14) = *(undefined4 *)(param_3 + 0x14);
    *(undefined4 *)(param_2 + 3) = *(undefined4 *)(param_3 + 0x18);
    *(undefined4 *)((longlong)param_2 + 0x1c) = *(undefined4 *)(param_3 + 0x1c);
    *(undefined4 *)(param_2 + 4) = *(undefined4 *)(param_3 + 0x20);
    *(undefined8 *)((longlong)param_2 + 0x24) = *(undefined8 *)(param_3 + 0x24);
    *(undefined1 *)((longlong)param_2 + 0x2c) = *(undefined1 *)(param_3 + 0x2c);
    *(undefined4 *)(param_2 + 6) = *(undefined4 *)(param_3 + 0x30);
    *(undefined1 *)((longlong)param_2 + 0x34) = *(undefined1 *)(param_3 + 0x34);
    param_2[7] = *(undefined8 *)(param_3 + 0x38);
  }
  return;
}

// ==== CNpcPathUserStatus::helper_1403a1350  @1403a1350  [medium:callgraph-r0]  (orig: FUN_1403a1350)
longlong FUN_1403a1350(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x40) {
    FUN_1403a1280(param_4,param_3,param_1);
    param_3 = param_3 + 0x40;
  }
  return param_3;
}

// ==== CNpcPathUserStatus::helper_1403a1790  @1403a1790  [medium:callgraph-r0]  (orig: FUN_1403a1790)
void FUN_1403a1790(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    FUN_1403a1280(param_4,param_1,param_3);
    param_1 = param_1 + 0x40;
  }
  return;
}

// ==== CNpcPathUserStatus::helper_1403a1a20  @1403a1a20  [medium:callgraph-r0]  (orig: FUN_1403a1a20)
longlong FUN_1403a1a20(longlong param_1,longlong param_2,longlong param_3)

{
  undefined1 local_res8;
  
  FUN_1403a0840(param_1,param_2,param_3,local_res8,0,0);
  return param_3 - (param_2 - param_1 & 0xffffffffffffffc0U);
}

// ==== CNpcPathUserStatus::helper_1403a27c0  @1403a27c0  [medium:callgraph-r0]  (orig: FUN_1403a27c0)
void FUN_1403a27c0(undefined8 param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_2 != param_3; param_2 = param_2 + 8) {
    (**(code **)*param_2)(param_2,0);
  }
  return;
}

// ==== CNpcPathUserStatus::ctor_or_dtor  @1403a3d80  [high:vtable-assign]  (orig: FUN_1403a3d80)
void FUN_1403a3d80(longlong param_1,longlong param_2,ulonglong param_3,longlong param_4)

{
  undefined4 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined4 *puVar5;
  longlong lVar6;
  undefined4 *puVar7;
  ulonglong uVar8;
  longlong lVar9;
  undefined1 local_res8;
  undefined **local_78;
  undefined1 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined8 local_54;
  undefined1 local_4c;
  undefined4 local_48;
  undefined1 local_44;
  undefined8 local_40;
  
  lVar6 = *(longlong *)(param_1 + 0x18);
  if (lVar6 == 0) {
    uVar8 = 0;
  }
  else {
    uVar8 = *(longlong *)(param_1 + 0x28) - lVar6 >> 6;
  }
  if (param_3 != 0) {
    lVar6 = *(longlong *)(param_1 + 0x20) - lVar6 >> 6;
    if (0x3ffffffffffffffU - lVar6 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1403a0450();
    }
    uVar2 = lVar6 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar8 < uVar2) {
      if (0x3ffffffffffffff - (uVar8 >> 1) < uVar8) {
        uVar8 = 0;
      }
      else {
        uVar8 = uVar8 + (uVar8 >> 1);
      }
      if (uVar8 < uVar2) {
        uVar8 = uVar2;
      }
      lVar3 = FUN_1403a10b0(param_1 + 0x10,uVar8);
      lVar6 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 6;
      FUN_1403a1790(lVar6 * 0x40 + lVar3,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar3,lVar6);
      FUN_1403a1350(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1403a1350(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar6 + param_3) * 0x40 + lVar3,param_1 + 0x10,local_res8,0,2);
      lVar6 = *(longlong *)(param_1 + 0x18);
      lVar9 = *(longlong *)(param_1 + 0x20);
      if (lVar6 != 0) {
        FUN_1403a27c0(param_1,lVar6,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar8 * 0x40 + lVar3;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar9 - lVar6 >> 6)) * 0x40 + lVar3;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)(*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 6) < param_3)
    {
      local_78 = CNpcPathUserStatus::vftable;
      local_70 = *(undefined1 *)(param_4 + 8);
      local_6c = *(undefined4 *)(param_4 + 0xc);
      local_68 = *(undefined4 *)(param_4 + 0x10);
      local_64 = *(undefined4 *)(param_4 + 0x14);
      local_60 = *(undefined4 *)(param_4 + 0x18);
      local_5c = *(undefined4 *)(param_4 + 0x1c);
      local_58 = *(undefined4 *)(param_4 + 0x20);
      local_54 = *(undefined8 *)(param_4 + 0x24);
      local_4c = *(undefined1 *)(param_4 + 0x2c);
      local_48 = *(undefined4 *)(param_4 + 0x30);
      local_44 = *(undefined1 *)(param_4 + 0x34);
      local_40 = *(undefined8 *)(param_4 + 0x38);
      FUN_1403a1350(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x40,param_1 + 0x10,local_res8,0);
      FUN_1403a1790(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 6),
                    &local_78,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x40;
      puVar7 = (undefined4 *)(*(longlong *)(param_1 + 0x20) + param_3 * -0x40);
      if (*(undefined4 **)(param_2 + 8) != puVar7) {
        puVar5 = *(undefined4 **)(param_2 + 8) + 3;
        do {
          *(undefined1 *)(puVar5 + -1) = local_70;
          *puVar5 = local_6c;
          puVar5[1] = local_68;
          puVar5[2] = local_64;
          puVar5[3] = local_60;
          puVar5[4] = local_5c;
          puVar5[5] = local_58;
          *(undefined8 *)(puVar5 + 6) = local_54;
          *(undefined1 *)(puVar5 + 8) = local_4c;
          puVar5[9] = local_48;
          *(undefined1 *)(puVar5 + 10) = local_44;
          *(undefined8 *)(puVar5 + 0xb) = local_40;
          puVar1 = puVar5 + 0xd;
          puVar5 = puVar5 + 0x10;
        } while (puVar1 != puVar7);
      }
      FUN_1404d9ec0(&local_78);
    }
    else {
      local_78 = CNpcPathUserStatus::vftable;
      local_70 = *(undefined1 *)(param_4 + 8);
      local_6c = *(undefined4 *)(param_4 + 0xc);
      local_68 = *(undefined4 *)(param_4 + 0x10);
      local_64 = *(undefined4 *)(param_4 + 0x14);
      local_60 = *(undefined4 *)(param_4 + 0x18);
      local_5c = *(undefined4 *)(param_4 + 0x1c);
      local_58 = *(undefined4 *)(param_4 + 0x20);
      local_54 = *(undefined8 *)(param_4 + 0x24);
      local_4c = *(undefined1 *)(param_4 + 0x2c);
      local_48 = *(undefined4 *)(param_4 + 0x30);
      local_44 = *(undefined1 *)(param_4 + 0x34);
      local_40 = *(undefined8 *)(param_4 + 0x38);
      lVar6 = *(longlong *)(param_1 + 0x20);
      lVar9 = lVar6 + param_3 * -0x40;
      uVar4 = FUN_1403a1350(lVar9,lVar6,lVar6,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      FUN_1403a1a20(*(undefined8 *)(param_2 + 8),lVar9,lVar6);
      puVar7 = *(undefined4 **)(param_2 + 8);
      if (puVar7 != puVar7 + param_3 * 0x10) {
        puVar5 = puVar7 + 3;
        do {
          *(undefined1 *)(puVar5 + -1) = local_70;
          *puVar5 = local_6c;
          puVar5[1] = local_68;
          puVar5[2] = local_64;
          puVar5[3] = local_60;
          puVar5[4] = local_5c;
          puVar5[5] = local_58;
          *(undefined8 *)(puVar5 + 6) = local_54;
          *(undefined1 *)(puVar5 + 8) = local_4c;
          puVar5[9] = local_48;
          *(undefined1 *)(puVar5 + 10) = local_44;
          *(undefined8 *)(puVar5 + 0xb) = local_40;
          puVar1 = puVar5 + 0xd;
          puVar5 = puVar5 + 0x10;
        } while (puVar1 != puVar7 + param_3 * 0x10);
      }
      FUN_1404d9ec0(&local_78);
    }
  }
  return;
}

// ==== CNpcPathUserStatus::ctor_or_dtor  @1404d9ec0  [high:vtable-assign]  (orig: FUN_1404d9ec0)
void FUN_1404d9ec0(undefined8 *param_1)

{
  *param_1 = CNpcPathUserStatus::vftable;
  return;
}

// ==== CNpcPathUserStatus::helper_1404da070  @1404da070  [medium:callgraph-r1]  (orig: FUN_1404da070)
undefined8 FUN_1404da070(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (*(int *)(param_1 + 0x18) == 0) {
    return 0;
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x30));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404da0e2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))
                    (*(longlong **)(lVar1 + 0x90),*(undefined4 *)(param_1 + 0x18));
  return uVar2;
}

// ==== CNpcPathUserStatus::helper_1404da0f0  @1404da0f0  [medium:callgraph-r0]  (orig: FUN_1404da0f0)
void FUN_1404da0f0(longlong param_1)

{
  longlong lVar1;
  
  if (*(longlong *)(param_1 + 0x38) != 0) {
    lVar1 = FUN_1404da070();
    if (lVar1 != 0) {
      if (*(longlong *)(lVar1 + 0x1118) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_1403bb5f0(*(longlong *)(lVar1 + 0x1118),*(undefined4 *)(param_1 + 0x20),0);
      }
    }
  }
  return;
}

// ==== CNpcPathUserStatus::ctor_or_dtor  @1404da350  [high:vtable-assign]  (orig: FUN_1404da350)
undefined8 * FUN_1404da350(undefined8 *param_1,undefined4 param_2)

{
  *(undefined1 *)(param_1 + 1) = 0;
  *param_1 = CNpcPathUserStatus::vftable;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  *(undefined1 *)((longlong)param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 6) = param_2;
  *(undefined1 *)((longlong)param_1 + 0x34) = 0;
  param_1[7] = 0;
  FUN_1404da0f0();
  return param_1;
}

