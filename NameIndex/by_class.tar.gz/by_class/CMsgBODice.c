// ==== CMsgBODice::ctor_or_dtor  @140455ef0  [high:vtable-assign]  (orig: FUN_140455ef0)
undefined8 * FUN_140455ef0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgBODice::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgBODice::ctor_or_dtor  @140455f40  [high:vtable-assign]  (orig: FUN_140455f40)
void FUN_140455f40(undefined8 *param_1)

{
  *param_1 = CMsgBODice::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgBODice::vfunc_1  @140456140  [high:rtti-vtable]  (orig: FUN_140456140)
ulonglong FUN_140456140(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x459);
}

// ==== CMsgBODice::ctor_or_dtor  @140456170  [high:vtable-assign]  (orig: FUN_140456170)
undefined8 * FUN_140456170(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgBODice::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgBODice::vfunc_3  @1404561c0  [high:rtti-vtable]  (orig: FUN_1404561c0)
void FUN_1404561c0(longlong param_1)

{
  undefined1 uVar1;
  char *pcVar2;
  longlong lVar3;
  char cVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined4 uVar8;
  longlong *local_res8;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1);
  if (lVar5 == 0) {
    return;
  }
  pcVar2 = *(char **)(param_1 + 0x428);
  if (*pcVar2 == '\0') {
    plVar6 = (longlong *)
             (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2a8))
                       (lVar5 + 0x10,*(undefined4 *)(pcVar2 + 4));
    if (plVar6 == (longlong *)0x0) {
      return;
    }
    cVar4 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_res8);
    if (cVar4 == '\0') {
      return;
    }
    cVar4 = (**(code **)(*local_res8 + 0xa8))();
    if (cVar4 == '\0') {
      return;
    }
    lVar3 = *(longlong *)(param_1 + 0x428);
    if (*(int *)(lVar3 + 0xc) == 0) {
      return;
    }
    uVar1 = *(undefined1 *)(lVar3 + 8);
    uVar7 = (**(code **)(*local_res8 + 0xb0))();
    uVar8 = *(undefined4 *)(lVar3 + 0xc);
  }
  else {
    if (*pcVar2 != '\x02') {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar6 = (longlong *)
             (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2a8))
                       (lVar5 + 0x10,*(undefined4 *)(pcVar2 + 4));
    if (plVar6 == (longlong *)0x0) {
      return;
    }
    cVar4 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_res8);
    if (cVar4 == '\0') {
      return;
    }
    cVar4 = (**(code **)(*local_res8 + 0xa8))();
    if (cVar4 == '\0') {
      return;
    }
    uVar1 = *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 8);
    uVar7 = (**(code **)(*local_res8 + 0xb0))();
    uVar8 = 0;
  }
  FUN_140468e30(uVar7,lVar5,uVar1,uVar8);
  return;
}

// ==== CMsgBODice::helper_140464610  @140464610  [medium:callgraph-r1]  (orig: FUN_140464610)
void FUN_140464610(__uint64 param_1)

{
  if ((DAT_140976428 & 1) == 0) {
    DAT_140976428 = DAT_140976428 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976420,"CBet");
    atexit((_func_5014 *)&LAB_1406d6e30);
  }
                    /* WARNING: Could not recover jumptable at 0x000140464665. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976420,param_1);
  return;
}

// ==== CMsgBODice::helper_140468e30  @140468e30  [medium:callgraph-r0]  (orig: FUN_140468e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140468e30(longlong *param_1,longlong *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  char *_Format;
  undefined8 uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  int *piVar10;
  ulonglong uVar11;
  longlong *plVar12;
  longlong *plVar13;
  int iVar14;
  uint uVar15;
  ulonglong uVar16;
  undefined1 auStack_938 [32];
  undefined8 local_918;
  undefined4 local_910;
  undefined2 local_908;
  undefined2 local_900;
  undefined4 local_8f8;
  undefined4 local_8f0;
  undefined1 local_8e8;
  int local_8d8;
  uint local_8d4;
  int local_8d0;
  int local_8cc;
  undefined8 local_8c8;
  int local_8c0;
  uint local_8bc;
  longlong *local_8b8;
  longlong *local_8b0;
  longlong *local_8a8;
  undefined8 local_8a0;
  undefined1 local_898 [1104];
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_8a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_938;
  if (param_2 != (longlong *)0x0) {
    local_8d4 = param_3;
    local_8d0 = param_4;
    local_8c0 = param_4;
    local_8bc = param_3;
    local_8b8 = param_1;
    local_8b0 = param_1;
    local_8a8 = param_2;
    (**(code **)(*param_2 + 8))(param_2);
    lVar5 = FUN_140464b50(param_1 + 1);
    if (lVar5 != 0) {
      lVar5 = *param_1;
      if ((int)lVar5 == 0) {
        local_918 = CONCAT44(local_918._4_4_,0xd4);
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      if (param_4 == 0) {
        if (param_3 == 0x16) {
LAB_140468f63:
          local_448 = '\0';
          memset(local_447,0,0x3ff);
          if ((int)lVar5 != 1) {
            pIVar6 = theInstance();
            _Format = (char *)(*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_MISS_BET");
            _snprintf(&local_448,0x3ff,_Format);
            FUN_14015b240(local_898);
            lVar5 = param_1[0xb];
            uVar7 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            uVar8 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x18))(lVar5 + 0x10);
            local_8e8 = 1;
            local_8f0 = 0;
            local_8f8 = 0;
            local_900 = 0;
            local_908 = 2000;
            local_910 = 0xffffff;
            local_918 = 0;
            iVar1 = FUN_14015b300(local_898,uVar8,uVar7,&local_448);
            if (iVar1 != 0) {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_898);
            }
            FUN_14015b2c0(local_898);
            return 0;
          }
          iVar1 = 0;
          local_8c8 = (ulonglong)local_8c8._4_4_ << 0x20;
          local_8d8 = 0;
          local_8cc = 0;
          uVar16 = 0;
          plVar13 = param_1 + 8;
          plVar9 = (longlong *)FUN_140463d30(plVar13);
          lVar5 = (**(code **)(*plVar9 + 0x10))(plVar9);
          iVar14 = iVar1;
          if (lVar5 != 0) {
            do {
              plVar9 = (longlong *)FUN_140463d30(plVar13);
              piVar10 = (int *)(**(code **)(*plVar9 + 0x18))(plVar9,uVar16);
              if (piVar10 == (int *)0x0) {
                local_918 = CONCAT44(local_918._4_4_,0xeb);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                iVar4 = *piVar10;
                iVar2 = (**(code **)(*param_2 + 8))(param_2);
                iVar14 = (int)local_8c8;
                if (iVar4 == iVar2) {
                  iVar4 = piVar10[2];
                  iVar14 = (int)local_8c8 + iVar4;
                  local_8c8 = CONCAT44(local_8c8._4_4_,iVar14);
                  local_8cc = iVar1;
                  if (piVar10[1] == param_3) {
                    iVar1 = iVar4;
                    local_8cc = iVar4;
                  }
                }
              }
              uVar16 = uVar16 + 1;
              plVar9 = (longlong *)FUN_140463d30(plVar13);
              uVar11 = (**(code **)(*plVar9 + 0x10))(plVar9);
              param_1 = local_8b8;
              param_4 = local_8d0;
            } while (uVar16 < uVar11);
            local_8d8 = iVar1;
            if (iVar14 < 0) {
              local_918 = CONCAT44(local_918._4_4_,0xf4);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            if (local_8d8 < 0) {
              local_918 = CONCAT44(local_918._4_4_,0xf5);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
          }
          if (((param_4 < 1) || (lVar5 = (**(code **)(*param_2 + 0x60))(param_2), param_4 <= lVar5))
             && (iVar1 = local_8d8, param_4 + iVar14 < 0x7531)) {
            iVar14 = param_4 + local_8d8;
            if (iVar14 < 0) {
              local_918 = CONCAT44(local_918._4_4_,0xfe);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            uVar15 = local_8d4;
            if (param_4 < 1) {
              if (local_8d4 == 0x16) {
                plVar13 = (longlong *)FUN_140463d30(plVar13);
                uVar16 = (**(code **)(*plVar13 + 0x10))(plVar13);
                while( true ) {
                  uVar16 = uVar16 - 1;
                  local_8c8 = uVar16;
                  plVar13 = (longlong *)FUN_140463d30(param_1 + 8);
                  uVar11 = (**(code **)(*plVar13 + 0x10))(plVar13);
                  uVar15 = local_8d4;
                  if (uVar11 <= uVar16) break;
                  plVar13 = (longlong *)FUN_140463d30(param_1 + 8);
                  piVar10 = (int *)(**(code **)(*plVar13 + 0x18))(plVar13,uVar16);
                  if (piVar10 == (int *)0x0) {
                    local_918 = CONCAT44(local_918._4_4_,0x116);
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  else {
                    iVar14 = *piVar10;
                    iVar4 = (**(code **)(*param_2 + 8))(param_2);
                    iVar1 = local_8d8;
                    if (iVar14 == iVar4) {
                      FUN_140455ef0(local_898);
                      uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
                      iVar1 = FUN_140455f70(local_898,2,uVar3);
                      if ((iVar1 != 0) &&
                         (iVar1 = FUN_140455ff0(local_898,piVar10[1],piVar10[2]), iVar1 != 0)) {
                        FUN_140467d50(param_1,local_898,param_2);
                      }
                      uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
                      iVar1 = FUN_140455f70(local_898,3,uVar3);
                      if ((iVar1 != 0) &&
                         (iVar1 = FUN_140455ff0(local_898,piVar10[1],piVar10[2]), iVar1 != 0)) {
                        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_898);
                      }
                      iVar14 = piVar10[2];
                      local_8d0 = iVar14;
                      if (iVar14 < 1) {
                        local_918 = CONCAT44(local_918._4_4_,0x120);
                        log_InlineLogERROR(&DAT_1406d9c10);
                      }
                      if (param_1[8] == 0) {
                        local_918 = CONCAT44(local_918._4_4_,0x1c);
                        log_InlineLogERROR(&DAT_1406d9c10);
                      }
                      local_8b8 = (longlong *)param_1[8];
                      iVar1 = piVar10[1];
                      lVar5 = *local_8b8;
                      uVar3 = (**(code **)(*param_2 + 8))(param_2);
                      (**(code **)(lVar5 + 0x30))(local_8b8,uVar3,iVar1);
                      (**(code **)(*param_2 + 0x180))(param_2,(longlong)iVar14,1);
                      iVar1 = local_8d8;
                      *(int *)(param_1 + 0xc) = (int)param_1[0xc] - iVar14;
                      FUN_140455f40(local_898);
                    }
                  }
                }
              }
              else {
                plVar13 = (longlong *)FUN_140463d30(plVar13);
                lVar5 = *plVar13;
                uVar3 = (**(code **)(*param_2 + 8))(param_2);
                (**(code **)(lVar5 + 0x30))(plVar13,uVar3,uVar15,1);
                iVar1 = local_8d8;
              }
            }
            else {
              plVar9 = (longlong *)FUN_140464610(0xc);
              local_8b8 = plVar9;
              if (plVar9 == (longlong *)0x0) {
                plVar9 = (longlong *)0x0;
              }
              else {
                iVar1 = (**(code **)(*param_2 + 8))(param_2);
                *(int *)plVar9 = iVar1;
                *(uint *)((longlong)plVar9 + 4) = local_8d4;
                *(int *)(plVar9 + 1) = iVar14;
              }
              if (plVar9 == (longlong *)0x0) {
                local_918 = CONCAT44(local_918._4_4_,0x103);
                log_InlineLogERROR(&DAT_1406d9c10);
                return 0;
              }
              plVar12 = (longlong *)FUN_140463d30(plVar13);
              lVar5 = *plVar12;
              uVar3 = (**(code **)(*param_2 + 8))(param_2);
              (**(code **)(lVar5 + 0x30))(plVar12,uVar3,local_8d4,1);
              (**(code **)(*param_2 + 0x178))(param_2,(longlong)param_4,1);
              if (*plVar13 == 0) {
                local_918 = CONCAT44(local_918._4_4_,0x1c);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              (**(code **)(*(longlong *)*plVar13 + 0x28))((longlong *)*plVar13,plVar9,0);
              *(int *)(param_1 + 0xc) = (int)param_1[0xc] + param_4;
              iVar1 = local_8d8;
              uVar15 = local_8d4;
            }
            if (param_4 < 1) {
              FUN_140455ef0(local_898);
              uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
              iVar14 = FUN_140455f70(local_898,3,uVar3);
              if ((iVar14 != 0) && (iVar14 = FUN_140455ff0(local_898,uVar15,param_4), iVar14 != 0))
              {
                (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_898);
              }
              uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
              iVar14 = FUN_140455f70(local_898,2,uVar3);
              if ((iVar14 != 0) && (iVar1 = FUN_140455ff0(local_898,uVar15,iVar1), iVar1 != 0)) {
                FUN_140467d50(param_1,local_898,param_2);
              }
              FUN_140455f40(local_898);
            }
            else {
              FUN_140455ef0(local_898);
              uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
              iVar1 = FUN_140455f70(local_898,1,uVar3);
              if ((iVar1 != 0) && (iVar1 = FUN_140455ff0(local_898,uVar15,param_4), iVar1 != 0)) {
                (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_898);
              }
              uVar3 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
              iVar1 = FUN_140455f70(local_898,0,uVar3,0);
              if ((iVar1 != 0) && (iVar1 = FUN_140455ff0(local_898,uVar15,param_4), iVar1 != 0)) {
                FUN_140467d50(param_1,local_898,param_2);
              }
              FUN_140455f40(local_898);
            }
            return 1;
          }
          return 0;
        }
      }
      else if ((0 < param_4) && (param_3 < 0x16)) {
        if ((param_4 != 100) && ((param_4 != 1000 && (param_4 != 10000)))) {
          local_918 = CONCAT44(local_918._4_4_,0xd6);
          log_InlineLogERROR(&DAT_1406d9c10);
          return 0;
        }
        goto LAB_140468f63;
      }
      local_918 = CONCAT44(local_918._4_4_,0xd5);
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
  }
  return 0;
}

