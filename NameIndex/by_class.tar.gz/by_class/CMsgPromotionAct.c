// ==== CMsgPromotionAct::helper_140009e80  @140009e80  [medium:callgraph-r1]  (orig: FUN_140009e80)
void FUN_140009e80(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x20);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x1c) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x1d) = 0;
  return;
}

// ==== CMsgPromotionAct::helper_1402d6fd0  @1402d6fd0  [medium:callgraph-r1]  (orig: FUN_1402d6fd0)
undefined8 FUN_1402d6fd0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),2);
                    /* WARNING: Could not recover jumptable at 0x0001402d7025. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CMsgPromotionAct::helper_1402d7030  @1402d7030  [medium:callgraph-r1]  (orig: FUN_1402d7030)
undefined8 FUN_1402d7030(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
                    /* WARNING: Could not recover jumptable at 0x0001402d7085. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CMsgPromotionAct::helper_1402d91a0  @1402d91a0  [medium:callgraph-r3]  (orig: FUN_1402d91a0)
undefined8 *
FUN_1402d91a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CMsgPromotionAct::helper_1402dbbe0  @1402dbbe0  [medium:callgraph-r2]  (orig: FUN_1402dbbe0)
undefined8 *
FUN_1402dbbe0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402d91a0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dca30  @1402dca30  [medium:callgraph-r1]  (orig: FUN_1402dca30)
longlong * FUN_1402dca30(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dccb0  @1402dccb0  [medium:callgraph-r1]  (orig: FUN_1402dccb0)
longlong * FUN_1402dccb0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dcf40  @1402dcf40  [medium:callgraph-r1]  (orig: FUN_1402dcf40)
longlong * FUN_1402dcf40(longlong *param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar2 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar2[1] + 0x29) == '\0') {
    puVar3 = (undefined8 *)puVar2[1];
    do {
      if ((*(uint *)(puVar3 + 3) < *param_3) ||
         ((*(uint *)(puVar3 + 3) <= *param_3 && (*(uint *)((longlong)puVar3 + 0x1c) < param_3[1]))))
      {
        puVar4 = (undefined8 *)puVar3[2];
      }
      else {
        puVar4 = (undefined8 *)*puVar3;
        puVar2 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x29) == '\0');
  }
  puVar3 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar2 == puVar3) || (*param_3 < *(uint *)(puVar2 + 3))) ||
     ((*param_3 <= *(uint *)(puVar2 + 3) && (param_3[1] < *(uint *)((longlong)puVar2 + 0x1c))))) {
    plVar1 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar1 = &local_28;
  }
  *param_2 = *plVar1;
  param_2[1] = plVar1[1];
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dd030  @1402dd030  [medium:callgraph-r1]  (orig: FUN_1402dd030)
longlong * FUN_1402dd030(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402dd18d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402dd1bc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402dd18d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402dbbe0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402dd1bc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dd1e0  @1402dd1e0  [medium:callgraph-r1]  (orig: FUN_1402dd1e0)
longlong * FUN_1402dd1e0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgPromotionAct::helper_1402dde10  @1402dde10  [medium:callgraph-r0]  (orig: FUN_1402dde10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402dde10(longlong param_1,longlong *param_2,int param_3,int param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  char cVar4;
  undefined2 uVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong lVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong *plVar16;
  undefined1 auStack_528 [32];
  undefined8 local_508;
  uint local_500;
  undefined4 local_4f8;
  undefined4 local_4f0;
  int local_4e8;
  int local_4d8;
  int local_4d4;
  longlong *local_4d0;
  longlong *local_4c0;
  int local_4b0;
  int iStack_4ac;
  longlong local_4a8;
  undefined8 *local_4a0;
  longlong local_498;
  undefined8 local_490;
  undefined8 *local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_490 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_528;
  local_4d8 = param_4;
  local_4d4 = param_3;
  local_4d0 = (longlong *)param_1;
  if (param_2 == (longlong *)0x0) {
    local_508 = CONCAT44(local_508._4_4_,0x215);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(char *)((longlong)param_2 + 0x51c) != '\0') {
    if ((param_3 == 0) || (param_4 == 0)) {
      log_InlineLogERROR(
                        "CPromotionActivityMgr::ProcessBuyGoods parameter fault, activity:%u, goods:%u"
                        );
    }
    else {
      FUN_1402dca30(param_1 + 8,&local_4a0,&local_4d4);
      puVar1 = local_4a0;
      local_4c0 = *(longlong **)(param_1 + 0x38);
      plVar13 = (longlong *)0x0;
      local_488 = *(undefined8 **)(param_1 + 8);
      if ((local_4a0 == (undefined8 *)0x0) || (local_4a0 != local_488)) {
        _invalid_parameter_noinfo();
      }
      lVar12 = local_498;
      if ((longlong *)local_498 == local_4c0) {
        pIVar10 = theInstance();
        lVar12 = param_2[2];
        uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_PROMOTION_ACTIVITY_IS_NOT_EXIST");
        (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
      }
      else {
        if (puVar1 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar15 = plVar13;
        }
        else {
          plVar15 = (longlong *)*puVar1;
        }
        if (lVar12 == plVar15[6]) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lVar12 + 0x20) == 0) {
          log_InlineLogERROR(
                            "CPromotionActivityMgr::ProcessBuyGoods iterActivity->second is null, activity:%u, goods:%u"
                            );
        }
        else {
          if (puVar1 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar13;
          }
          else {
            plVar15 = (longlong *)*puVar1;
          }
          if (lVar12 == plVar15[6]) {
            _invalid_parameter_noinfo();
          }
          if (*(short *)(*(longlong *)(lVar12 + 0x20) + 0x10) == 2) {
            pIVar10 = theInstance();
            lVar12 = param_2[2];
            uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_PROMOTION_ACTIVITY_IS_END");
            (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
          }
          else {
            if (puVar1 == (undefined8 *)0x0) {
              _invalid_parameter_noinfo();
              plVar15 = plVar13;
            }
            else {
              plVar15 = (longlong *)*puVar1;
            }
            if (lVar12 == plVar15[6]) {
              _invalid_parameter_noinfo();
            }
            if (*(short *)(*(longlong *)(lVar12 + 0x20) + 0x10) == 0) {
              pIVar10 = theInstance();
              lVar12 = param_2[2];
              uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                 (pIVar10,"STR_PROMOTION_ACTIVITY_IS_INACTIVE");
              (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
            }
            else {
              local_4b0 = param_3;
              iStack_4ac = param_4;
              FUN_1402dcf40((undefined8 *)(param_1 + 0x88),&local_4a0,&local_4b0);
              lVar12 = *(longlong *)(param_1 + 0xb8);
              local_4c0 = *(longlong **)(param_1 + 0x88);
              if ((local_4a0 == (undefined8 *)0x0) || (local_4a0 != local_4c0)) {
                _invalid_parameter_noinfo();
              }
              if (local_498 == lVar12) {
                log_InlineLogERROR(
                                  "CPromotionActivityMgr::ProcessSignUp m_mapPromotionInfo not found. activity:%u, goods:%u"
                                  );
              }
              else {
                if (local_4a0 == (undefined8 *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar15 = plVar13;
                }
                else {
                  plVar15 = (longlong *)*local_4a0;
                }
                if (local_498 == plVar15[6]) {
                  _invalid_parameter_noinfo();
                }
                puVar1 = *(undefined8 **)(local_498 + 0x20);
                local_4a0 = puVar1;
                if (puVar1 == (undefined8 *)0x0) {
                  log_InlineLogERROR(
                                    "CPromotionActivityMgr::ProcessBuyGoods pPromotionInfo is null, activity:%u, goods:%u"
                                    );
                }
                else {
                  iVar6 = FUN_1404730a0(puVar1);
                  plVar15 = local_4d0;
                  if (iVar6 == 2) {
                    FUN_1402dccb0((longlong)local_4d0 + 0x48,&local_4b0,&local_4d8);
                    local_4c0 = *(longlong **)((longlong)plVar15 + 0x78);
                    local_4d0 = *(longlong **)((longlong)plVar15 + 0x48);
                    puVar2 = (undefined8 *)CONCAT44(iStack_4ac,local_4b0);
                    if ((puVar2 == (undefined8 *)0x0) || (puVar2 != local_4d0)) {
                      _invalid_parameter_noinfo();
                    }
                    if ((longlong *)local_4a8 == local_4c0) {
                      log_InlineLogERROR(
                                        "CPromotionActivityMgr::ProcessBuyGoods not found goods, goods id:%u."
                                        );
                    }
                    else {
                      if (puVar2 == (undefined8 *)0x0) {
                        _invalid_parameter_noinfo();
                        plVar15 = plVar13;
                      }
                      else {
                        plVar15 = (longlong *)*puVar2;
                      }
                      if (local_4a8 == plVar15[6]) {
                        _invalid_parameter_noinfo();
                      }
                      if (*(longlong *)(local_4a8 + 0x20) == 0) {
                        log_InlineLogERROR(
                                          "CPromotionActivityMgr::ProcessBuyGoods iterGoods->second is null, activity:%u, goods:%u"
                                          );
                      }
                      else {
                        if (puVar2 == (undefined8 *)0x0) {
                          _invalid_parameter_noinfo();
                          plVar15 = plVar13;
                        }
                        else {
                          plVar15 = (longlong *)*puVar2;
                        }
                        if (local_4a8 == plVar15[6]) {
                          _invalid_parameter_noinfo();
                        }
                        local_4d0 = (longlong *)
                                    CONCAT44(local_4d0._4_4_,
                                             *(undefined4 *)(*(longlong *)(local_4a8 + 0x20) + 8));
                        if (puVar2 == (undefined8 *)0x0) {
                          _invalid_parameter_noinfo();
                          plVar15 = plVar13;
                        }
                        else {
                          plVar15 = (longlong *)*puVar2;
                        }
                        if (local_4a8 == plVar15[6]) {
                          _invalid_parameter_noinfo();
                        }
                        iVar6 = *(int *)(*(longlong *)(local_4a8 + 0x20) + 0x10);
                        local_4b0 = iVar6;
                        if (iVar6 < 1) {
                          log_InlineLogERROR(
                                            "CPromotionActivityMgr::ProcessBuyGoods goods emoney price <= 0, goods id:%u."
                                            );
                        }
                        else {
                          local_508 = CONCAT71(local_508._1_7_,1);
                          cVar4 = FUN_140339ec0(param_2,(ulonglong)local_4d0 & 0xffffffff,1);
                          if (cVar4 == '\0') {
                            pIVar10 = theInstance();
                            lVar12 = param_2[2];
                            uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                               (pIVar10,"STR_FULLBAG_NO_MORE");
                            (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
                          }
                          else if (*(int *)((longlong)param_2 + 0xfa4) < iVar6) {
                            pIVar10 = theInstance();
                            lVar12 = param_2[2];
                            uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                               (pIVar10,"STR_NOT_SO_MUCH_MONEY");
                            (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
                          }
                          else {
                            iVar7 = tq::RandGet(3);
                            FUN_140473690(puVar1,iVar7 + 1);
                            plVar15 = param_2 + 2;
                            local_508 = 0;
                            cVar4 = (**(code **)(*plVar15 + 0x2e0))(plVar15,0x1d,(longlong)-iVar6,1)
                            ;
                            if (cVar4 == '\0') {
                              local_508 = CONCAT44(local_508._4_4_,0x274);
                              log_InlineLogERROR(&DAT_1406d9c10);
                            }
                            else {
                              uVar8 = (**(code **)(*param_2 + 8))(param_2);
                              local_508._0_4_ = iVar6;
                              FUN_1401742b0(param_2,0x3a,uVar8);
                              local_4c0 = DAT_140975b60;
                              if (DAT_140975b60 == (longlong *)0x0) {
                                local_508._0_4_ = 0x3c0;
                                log_InlineLogERROR(&DAT_1406d9c10);
                                local_4c0 = (longlong *)0x0;
                              }
                              lVar12 = *local_4c0;
                              uVar8 = FUN_140167b40(param_2);
                              uVar9 = (**(code **)(*param_2 + 8))(param_2);
                              local_500 = local_500 & 0xffffff00;
                              local_508._0_4_ = uVar8;
                              local_4d0 = (longlong *)
                                          (**(code **)(lVar12 + 0x18))
                                                    (local_4c0,(ulonglong)local_4d0 & 0xffffffff,
                                                     uVar9,0);
                              if (local_4d0 == (longlong *)0x0) {
                                (**(code **)(*param_2 + 8))(param_2);
                                log_InlineLogERROR(
                                                  "CPromotionActivityMgr::ProcessBuyGoods. CreateItem fail goods ItemType[%u] User[%u]"
                                                  );
                                pIVar10 = theInstance();
                                lVar12 = *plVar15;
                                uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                                   (pIVar10,"STR_FAILED_GENERATE_ITEM");
                                (**(code **)(lVar12 + 0x358))(plVar15,uVar11);
                              }
                              else {
                                uVar8 = FUN_1400fda10(local_4d0,1,1);
                                uVar9 = FUN_1400fda10(local_4d0,0,1);
                                FUN_1400fda10(local_4d0,3,1);
                                local_4e8 = local_4b0;
                                local_4f0 = 1;
                                local_500 = uVar9;
                                local_4f8 = uVar8;
                                local_508._0_4_ = param_4;
                                tq::MyLogSave("gmlog/promotion_buy","%u\t%u\t%u\t%u\t%u\t%u\t%u\t");
                                plVar3 = local_4d0;
                                uVar8 = (**(code **)(*local_4d0 + 8))(local_4d0);
                                local_508 = (ulonglong)local_508._4_4_ << 0x20;
                                FUN_14033cce0(param_2,uVar8,1);
                                plVar16 = DAT_140975b60;
                                if (DAT_140975b60 == (longlong *)0x0) {
                                  local_508 = CONCAT44(local_508._4_4_,0x3c0);
                                  log_InlineLogERROR(&DAT_1406d9c10);
                                  plVar16 = plVar13;
                                }
                                lVar12 = *plVar16;
                                uVar8 = FUN_1400fda10(plVar3,1,1);
                                lVar12 = (**(code **)(lVar12 + 0x70))(plVar16,uVar8);
                                if (lVar12 != 0) {
                                  pIVar10 = theInstance();
                                  plVar13 = (longlong *)
                                            (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))
                                                      (*(longlong **)(lVar12 + 8),1);
                                  uVar11 = (**(code **)(*plVar13 + 0x78))(plVar13);
                                  lVar12 = *plVar15;
                                  uVar14 = (*(code *)**(undefined8 **)pIVar10)
                                                     (pIVar10,"STR_PROMOTION_BUY_GOODS_SUCCESS");
                                  (**(code **)(lVar12 + 0x358))(plVar15,uVar14,uVar11);
                                }
                                FUN_140454ef0(local_478);
                                uVar5 = FUN_140473000(local_4a0,3);
                                local_508 = CONCAT62(local_508._2_6_,uVar5);
                                cVar4 = FUN_140454fa0(local_478,param_3,param_4,2);
                                if (cVar4 == '\0') {
                                  log_InlineLogERROR(
                                                  "CPromotionActivityMgr::ProcessBuyGoods msgPromotionAct Create failed."
                                                  );
                                  FUN_140454f40(local_478);
                                }
                                else {
                                  (**(code **)(*plVar15 + 0x350))(plVar15,local_478);
                                  FUN_140454f40(local_478);
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                  else {
                    pIVar10 = theInstance();
                    lVar12 = param_2[2];
                    uVar11 = (*(code *)**(undefined8 **)pIVar10)
                                       (pIVar10,"STR_PROMOTION_ACTIVITY_CAN_NOT_BUY");
                    (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgPromotionAct::helper_1402dfde0  @1402dfde0  [medium:callgraph-r0]  (orig: FUN_1402dfde0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402dfde0(longlong param_1,longlong param_2,uint *param_3,ushort param_4)

{
  char cVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  int iVar13;
  longlong **pplVar14;
  longlong lVar15;
  uint *puVar16;
  undefined1 auStack_568 [32];
  undefined4 local_548;
  longlong *local_538;
  longlong *plStack_530;
  longlong *local_528;
  longlong *plStack_520;
  int local_518;
  longlong local_510;
  longlong *local_508 [6];
  longlong *local_4d8;
  undefined8 local_4d0;
  longlong *local_4c8;
  longlong *local_4c0;
  longlong *local_4b8;
  longlong *local_4b0;
  uint *local_4a8;
  undefined8 local_4a0;
  undefined1 local_498 [32];
  undefined1 local_478 [12];
  int local_46c;
  ulonglong local_48;
  
  local_4a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  local_510 = param_2;
  local_4a8 = param_3;
  if (param_2 == 0) {
    local_548 = 0x174;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == (uint *)0x0) {
    local_548 = 0x175;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 == 0) {
    local_548 = 0x176;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1404552d0(local_478);
    FUN_140455380(local_478);
    local_4c8 = operator_new(8);
    if (local_4c8 == (longlong *)0x0) {
      local_508[0] = (longlong *)0x0;
    }
    else {
      *local_4c8 = (longlong)local_508;
      local_508[0] = local_4c8;
    }
    local_4c0 = local_4c8;
    plVar8 = (longlong *)FUN_140009e80(local_508);
    local_4d8 = plVar8;
    *(undefined1 *)((longlong)plVar8 + 0x1d) = 1;
    plVar8[1] = (longlong)plVar8;
    *plVar8 = (longlong)plVar8;
    plVar8[2] = (longlong)plVar8;
    local_4d0 = 0;
    iVar4 = 0;
    local_518 = 0;
    uVar5 = (uint)param_4;
    local_4c0 = (longlong *)CONCAT44(local_4c0._4_4_,(uint)param_4);
    plVar11 = local_508[0];
    puVar16 = param_3;
    if (param_4 != 0) {
      while( true ) {
        iVar13 = local_518;
        local_4c8 = (longlong *)CONCAT44(local_4c8._4_4_,iVar4 + 1U);
        if (1000 < iVar4 + 1U) break;
        plVar12 = plVar8;
        if (*(char *)(plVar8[1] + 0x1d) == '\0') {
          plVar9 = (longlong *)plVar8[1];
          do {
            if (*(uint *)(plVar9 + 3) < *puVar16) {
              plVar10 = (longlong *)plVar9[2];
            }
            else {
              plVar10 = (longlong *)*plVar9;
              plVar12 = plVar9;
            }
            plVar9 = plVar10;
          } while (*(char *)((longlong)plVar10 + 0x1d) == '\0');
        }
        local_4b0 = plVar12;
        local_4b8 = plVar11;
        plVar9 = plVar8;
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = local_4d8;
          plVar11 = local_508[0];
        }
        if ((plVar12 == plVar8) || (*puVar16 < *(uint *)(plVar12 + 3))) {
          plStack_520 = plVar9;
          local_528 = plVar11;
          pplVar14 = &local_528;
        }
        else {
          pplVar14 = &local_4b8;
        }
        local_538 = *pplVar14;
        plStack_530 = pplVar14[1];
        if ((local_538 == (longlong *)0x0) || (plVar8 = plVar9, local_538 != plVar11)) {
          _invalid_parameter_noinfo();
          plVar8 = local_4d8;
          plVar11 = local_508[0];
        }
        if (plStack_530 == plVar9) {
          FUN_14000d480(local_508,local_498,param_3 + iVar13);
          plVar8 = (longlong *)**(undefined8 **)(param_1 + 0xb8);
          plVar11 = *(longlong **)(param_1 + 0x88);
          while( true ) {
            plVar12 = *(longlong **)(param_1 + 0xb8);
            if ((plVar11 == (longlong *)0x0) || (plVar11 != *(longlong **)(param_1 + 0x88))) {
              _invalid_parameter_noinfo();
            }
            if (plVar8 == plVar12) break;
            if (plVar11 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar15 = 0;
            }
            else {
              lVar15 = *plVar11;
            }
            if (plVar8 == *(longlong **)(lVar15 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar15 = plVar8[4];
            if ((lVar15 != 0) && (uVar5 = FUN_1402d7030(lVar15), uVar5 == *puVar16)) {
              if ((longlong)local_46c + 0xcU < 0x401) {
                uVar2 = FUN_1404730a0(lVar15);
                uVar3 = FUN_140473000(lVar15,3);
                uVar6 = FUN_1402d6fd0(lVar15);
                uVar7 = FUN_1402d7030(lVar15);
                local_548 = CONCAT22(local_548._2_2_,uVar2);
                FUN_1404553a0(local_478,uVar7,uVar6,uVar3);
              }
              else {
                (**(code **)(*(longlong *)(local_510 + 0x10) + 0x350))
                          ((longlong *)(local_510 + 0x10),local_478);
                cVar1 = FUN_140455380(local_478);
                if (cVar1 == '\0') {
                  local_548 = 0x195;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  plStack_520 = (longlong *)*local_4d8;
                  local_538 = local_508[0];
                  plStack_530 = local_4d8;
                  local_528 = local_508[0];
                  FUN_14000bd50(local_508,&local_4b8,&local_528,&local_538);
                  operator_delete(local_4d8);
                  local_4d8 = (longlong *)0x0;
                  local_4d0 = 0;
                  operator_delete(local_508[0]);
                  FUN_140455320(local_478);
                  return;
                }
                uVar2 = FUN_1404730a0(lVar15);
                uVar3 = FUN_140473000(lVar15,3);
                uVar6 = FUN_1402d6fd0(lVar15);
                uVar7 = FUN_1402d7030(lVar15);
                local_548 = CONCAT22(local_548._2_2_,uVar2);
                FUN_1404553a0(local_478,uVar7,uVar6,uVar3);
              }
            }
            if (plVar11 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              plVar12 = (longlong *)plVar8[2];
              if (*(char *)((longlong)plVar12 + 0x29) == '\0') {
                cVar1 = *(char *)(*plVar12 + 0x29);
                plVar8 = plVar12;
                plVar12 = (longlong *)*plVar12;
                while (cVar1 == '\0') {
                  cVar1 = *(char *)(*plVar12 + 0x29);
                  plVar8 = plVar12;
                  plVar12 = (longlong *)*plVar12;
                }
              }
              else {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar9 = (longlong *)plVar8[1];
                plVar12 = plVar8;
                while ((plVar8 = plVar9, cVar1 == '\0' && (plVar12 == (longlong *)plVar8[2]))) {
                  cVar1 = *(char *)(plVar8[1] + 0x29);
                  plVar9 = (longlong *)plVar8[1];
                  plVar12 = plVar8;
                }
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
          }
          plVar8 = local_4d8;
          plVar11 = local_508[0];
          param_3 = local_4a8;
          iVar13 = local_518;
          uVar5 = (uint)local_4c0;
        }
        local_518 = iVar13 + 1;
        param_2 = local_510;
        if ((int)uVar5 <= iVar13 + 1) goto LAB_1402e0374;
        puVar16 = puVar16 + 1;
        iVar4 = (int)local_4c8;
      }
      local_548 = 0x17e;
      log_InlineLogERROR(&DAT_1406d9c10);
      param_2 = local_510;
    }
LAB_1402e0374:
    (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478);
    plStack_520 = (longlong *)*local_4d8;
    local_538 = local_508[0];
    plStack_530 = local_4d8;
    local_528 = local_508[0];
    FUN_14000bd50(local_508,&local_4b8,&local_528,&local_538);
    operator_delete(local_4d8);
    local_4d8 = (longlong *)0x0;
    local_4d0 = 0;
    operator_delete(local_508[0]);
    FUN_140455320(local_478);
  }
  return;
}

// ==== CMsgPromotionAct::helper_1402e0450  @1402e0450  [medium:callgraph-r0]  (orig: FUN_1402e0450)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e0450(longlong param_1,longlong *param_2,int param_3,int param_4)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  char cVar5;
  undefined2 uVar6;
  int iVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  void *pvVar10;
  void *pvVar11;
  void *pvVar12;
  void *pvVar13;
  undefined1 auStack_538 [32];
  undefined4 local_518;
  undefined4 local_508;
  int local_504;
  int local_500;
  undefined4 uStack_4fc;
  void *local_4f8;
  int local_4f0 [2];
  undefined8 local_4e8;
  longlong local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d4;
  undefined8 *local_4d0;
  longlong local_4c0 [3];
  undefined8 *local_4a8;
  undefined8 local_498;
  undefined8 *local_490;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  local_504 = param_3;
  local_4f0[0] = param_4;
  local_4d0 = (undefined8 *)param_1;
  if (param_2 == (longlong *)0x0) {
    local_518 = 0x1a8;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((param_3 == 0) || (param_4 == 0)) {
    log_InlineLogERROR("CPromotionActivityMgr::ProcessSignUp parameter fault, activity:%u, goods:%u"
                      );
  }
  else {
    FUN_1402dca30((longlong *)(param_1 + 8),&local_4e8,&local_504);
    lVar1 = *(longlong *)(param_1 + 0x38);
    pvVar12 = (void *)0x0;
    local_4a8 = *(undefined8 **)(param_1 + 8);
    if ((local_4e8 == (undefined8 *)0x0) || (local_4e8 != local_4a8)) {
      _invalid_parameter_noinfo();
    }
    if (local_4e0 == lVar1) {
      pIVar8 = theInstance();
      lVar1 = param_2[2];
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_PROMOTION_ACTIVITY_IS_NOT_EXIST");
      (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
    }
    else {
      if (local_4e8 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        pvVar10 = pvVar12;
      }
      else {
        pvVar10 = (void *)*local_4e8;
      }
      if (local_4e0 == *(longlong *)((longlong)pvVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(local_4e0 + 0x20) == 0) {
        log_InlineLogERROR(
                          "CPromotionActivityMgr::ProcessSignUp iterActivity->second is null, activity:%u, goods:%u"
                          );
      }
      else {
        if (local_4e8 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          pvVar10 = pvVar12;
        }
        else {
          pvVar10 = (void *)*local_4e8;
        }
        if (local_4e0 == *(longlong *)((longlong)pvVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(short *)(*(longlong *)(local_4e0 + 0x20) + 0x10) == 2) {
          pIVar8 = theInstance();
          lVar1 = param_2[2];
          uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_PROMOTION_ACTIVITY_IS_END");
          (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
        }
        else {
          if (local_4e8 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            pvVar10 = pvVar12;
          }
          else {
            pvVar10 = (void *)*local_4e8;
          }
          if (local_4e0 == *(longlong *)((longlong)pvVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          puVar4 = local_4d0;
          if (*(short *)(*(longlong *)(local_4e0 + 0x20) + 0x10) == 0) {
            pIVar8 = theInstance();
            lVar1 = param_2[2];
            uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_PROMOTION_ACTIVITY_IS_INACTIVE");
            (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
          }
          else {
            FUN_1402dd1e0((longlong)local_4d0 + 200,&local_500,local_4f0);
            local_4e8 = *(undefined8 **)((longlong)puVar4 + 0xf8);
            local_490 = *(undefined8 **)((longlong)puVar4 + 200);
            puVar3 = (undefined8 *)CONCAT44(uStack_4fc,local_500);
            if ((puVar3 == (undefined8 *)0x0) || (puVar3 != local_490)) {
              _invalid_parameter_noinfo();
            }
            pvVar10 = local_4f8;
            if (local_4f8 == local_4e8) {
              local_4e8 = operator_new(0x40);
              pvVar10 = pvVar12;
              if (local_4e8 != (void *)0x0) {
                pvVar10 = (void *)FUN_14000ef40(local_4e8);
              }
              if (pvVar10 == (void *)0x0) {
                local_518 = 0x1ce;
                log_InlineLogERROR(&DAT_1406d9c10);
                return;
              }
              local_4d8 = (**(code **)(*param_2 + 8))(param_2);
              FUN_14000d480(pvVar10,local_4c0,&local_4d8);
              local_500 = param_4;
              local_4f8 = pvVar10;
              FUN_1402dd030((longlong)puVar4 + 200,local_4c0,&local_500);
            }
            else {
              if (puVar3 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                pvVar11 = pvVar12;
              }
              else {
                pvVar11 = (void *)*puVar3;
              }
              if (pvVar10 == *(void **)((longlong)pvVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              plVar2 = *(longlong **)((longlong)pvVar10 + 0x20);
              if (puVar3 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                pvVar11 = pvVar12;
              }
              else {
                pvVar11 = (void *)*puVar3;
              }
              if (pvVar10 == *(void **)((longlong)pvVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              if (*(longlong *)((longlong)pvVar10 + 0x20) == 0) {
                local_4e8 = operator_new(0x40);
                pvVar11 = pvVar12;
                if (local_4e8 != (void *)0x0) {
                  pvVar11 = (void *)FUN_14000ef40(local_4e8);
                }
                if (pvVar11 == (void *)0x0) {
                  local_518 = 0x1d8;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  return;
                }
                if (puVar3 == (undefined8 *)0x0) {
                  _invalid_parameter_noinfo();
                  pvVar13 = pvVar12;
                }
                else {
                  pvVar13 = (void *)*puVar3;
                }
                if (pvVar10 == *(void **)((longlong)pvVar13 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                *(void **)((longlong)pvVar10 + 0x20) = pvVar11;
              }
              else {
                local_4d4 = (**(code **)(*param_2 + 8))(param_2);
                FUN_140077480(plVar2,&local_500,&local_4d4);
                pvVar10 = (void *)plVar2[6];
                local_4c0[0] = *plVar2;
                if ((CONCAT44(uStack_4fc,local_500) == 0) ||
                   (CONCAT44(uStack_4fc,local_500) != local_4c0[0])) {
                  _invalid_parameter_noinfo();
                }
                if (local_4f8 != pvVar10) {
                  pIVar8 = theInstance();
                  lVar1 = param_2[2];
                  uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_PROMOTION_SIGN_UP_REPEAT");
                  (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
                  return;
                }
                local_508 = (**(code **)(*param_2 + 8))(param_2);
                FUN_14000d480(plVar2,local_4c0,&local_508);
              }
            }
            iVar7 = tq::RandGet(3);
            puVar4 = local_4d0;
            local_508 = CONCAT22((short)((uint)iVar7 >> 0x10),(short)iVar7 + 1);
            local_4e8 = (undefined8 *)CONCAT44(param_4,param_3);
            FUN_1402dcf40((longlong)local_4d0 + 0x88,&local_500,&local_4e8);
            pvVar10 = *(void **)((longlong)puVar4 + 0xb8);
            local_4d0 = *(undefined8 **)((longlong)puVar4 + 0x88);
            puVar4 = (undefined8 *)CONCAT44(uStack_4fc,local_500);
            if ((puVar4 == (undefined8 *)0x0) || (puVar4 != local_4d0)) {
              _invalid_parameter_noinfo();
            }
            pvVar11 = local_4f8;
            if (local_4f8 == pvVar10) {
              log_InlineLogERROR(
                                "CPromotionActivityMgr::ProcessSignUp m_mapPromotionInfo not found. activity:%u, goods:%u"
                                );
            }
            else {
              if (puVar4 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                pvVar12 = (void *)*puVar4;
              }
              if (pvVar11 == *(void **)((longlong)pvVar12 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              lVar1 = *(longlong *)((longlong)pvVar11 + 0x20);
              if (lVar1 == 0) {
                log_InlineLogERROR(
                                  "CPromotionActivityMgr::ProcessSignUp pPromotionInfo is null. activity:%u, goods:%u"
                                  );
              }
              else {
                iVar7 = FUN_1404730a0(lVar1);
                if ((iVar7 == 2) || (iVar7 = FUN_1404730a0(lVar1), iVar7 == 1)) {
                  FUN_140473690(lVar1,(undefined2)local_508);
                  FUN_140454ef0(local_478);
                  uVar6 = FUN_140473000(lVar1,3);
                  local_518 = CONCAT22(local_518._2_2_,uVar6);
                  cVar5 = FUN_140454fa0(local_478,param_3,param_4,1);
                  if (cVar5 == '\0') {
                    log_InlineLogERROR(
                                      "CPromotionActivityMgr::ProcessSignUp msgPromotionAct Create failed."
                                      );
                    FUN_140454f40(local_478);
                  }
                  else {
                    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                    pIVar8 = theInstance();
                    lVar1 = param_2[2];
                    uVar9 = (*(code *)**(undefined8 **)pIVar8)
                                      (pIVar8,"STR_PROMOTION_SIGN_UP_SUCCESS");
                    (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
                    FUN_140454f40(local_478);
                  }
                }
                else {
                  pIVar8 = theInstance();
                  lVar1 = param_2[2];
                  uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_PROMOTION_ACTIVITY_IS_END")
                  ;
                  (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgPromotionAct::ctor_or_dtor  @140454ef0  [high:vtable-assign]  (orig: FUN_140454ef0)
undefined8 * FUN_140454ef0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPromotionAct::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPromotionAct::ctor_or_dtor  @140454f40  [high:vtable-assign]  (orig: FUN_140454f40)
void FUN_140454f40(undefined8 *param_1)

{
  *param_1 = CMsgPromotionAct::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPromotionAct::vfunc_1  @140454f70  [high:rtti-vtable]  (orig: FUN_140454f70)
ulonglong FUN_140454f70(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x52b);
}

// ==== CMsgPromotionAct::helper_140454fa0  @140454fa0  [medium:callgraph-r1]  (orig: FUN_140454fa0)
undefined8
FUN_140454fa0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
             undefined2 param_5)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 0xe;
  *(undefined4 *)(param_1 + 8) = 0x52b;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 10) = param_2;
  **(undefined4 **)(param_1 + 0x428) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = param_5;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 6) = 1;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgPromotionAct::ctor_or_dtor  @140455000  [high:vtable-assign]  (orig: FUN_140455000)
undefined8 * FUN_140455000(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPromotionAct::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgPromotionAct::vfunc_3  @140455050  [high:rtti-vtable]  (orig: FUN_140455050)
void FUN_140455050(longlong param_1)

{
  ushort uVar1;
  short sVar2;
  char cVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))
                      (*(longlong **)(lVar4 + 0x90),param_1);
    if (lVar4 != 0) {
      uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 6);
      if ((uVar1 == 0) || ((longlong)(int)(uVar1 - 1) * 4 + 0xeU < 0x3fd)) {
        cVar3 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10);
        if (cVar3 == '\0') {
          pIVar5 = theInstance();
          lVar7 = *(longlong *)(lVar4 + 0x10);
          uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
          (**(code **)(lVar7 + 0x358))(lVar4 + 0x10,uVar6);
        }
        else {
          sVar2 = *(short *)(*(longlong *)(param_1 + 0x428) + 4);
          if (sVar2 == 0) {
            lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            if (*(longlong *)(lVar7 + 0x1b0) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar6 = 0;
            }
            else {
              uVar6 = *(undefined8 *)(lVar7 + 0x1b0);
            }
            FUN_1402dfde0(uVar6,lVar4,*(longlong *)(param_1 + 0x428) + 10,
                          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6));
          }
          else if (sVar2 == 1) {
            lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            if (*(longlong *)(lVar7 + 0x1b0) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar6 = 0;
            }
            else {
              uVar6 = *(undefined8 *)(lVar7 + 0x1b0);
            }
            FUN_1402e0450(uVar6,lVar4,
                          *(undefined4 *)((longlong)*(undefined4 **)(param_1 + 0x428) + 10),
                          **(undefined4 **)(param_1 + 0x428));
          }
          else if (sVar2 == 2) {
            lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            if (*(longlong *)(lVar7 + 0x1b0) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar6 = 0;
            }
            else {
              uVar6 = *(undefined8 *)(lVar7 + 0x1b0);
            }
            FUN_1402dde10(uVar6,lVar4,
                          *(undefined4 *)((longlong)*(undefined4 **)(param_1 + 0x428) + 10),
                          **(undefined4 **)(param_1 + 0x428));
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgPromotionAct::helper_140455380  @140455380  [medium:callgraph-r1]  (orig: FUN_140455380)
undefined8 FUN_140455380(longlong param_1)

{
  undefined2 *puVar1;
  
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 0xe;
  *(undefined4 *)(param_1 + 8) = 0x52c;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgPromotionAct::helper_1404553a0  @1404553a0  [medium:callgraph-r1]  (orig: FUN_1404553a0)
ulonglong FUN_1404553a0(longlong param_1,undefined4 param_2,undefined4 param_3,ushort param_4,
                       ushort param_5)

{
  ushort *puVar1;
  short *psVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 0xcU) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar1 = *(ushort **)(param_1 + 0x428);
  if (puVar1 == (ushort *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  if (*puVar1 != 0) {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0xc;
  }
  *(undefined4 *)(puVar1 + (ulonglong)*puVar1 * 6 + 1) = param_2;
  *(undefined4 *)(*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 6 + 3)
       = param_3;
  (*(ushort **)(param_1 + 0x428))[(ulonglong)**(ushort **)(param_1 + 0x428) * 6 + 5] = param_4;
  (*(ushort **)(param_1 + 0x428))[((ulonglong)**(ushort **)(param_1 + 0x428) * 3 + 3) * 2] = param_5
  ;
  psVar2 = *(short **)(param_1 + 0x428);
  *psVar2 = *psVar2 + 1;
  return CONCAT71((int7)((ulonglong)psVar2 >> 8),1);
}

// ==== CMsgPromotionAct::helper_140473000  @140473000  [medium:callgraph-r1]  (orig: FUN_140473000)
undefined8 FUN_140473000(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (4 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x000140473086. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  return uVar2;
}

// ==== CMsgPromotionAct::helper_1404730a0  @1404730a0  [medium:callgraph-r1]  (orig: FUN_1404730a0)
undefined8 FUN_1404730a0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
                    /* WARNING: Could not recover jumptable at 0x0001404730f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  return uVar2;
}

// ==== CMsgPromotionAct::helper_140473690  @140473690  [medium:callgraph-r1]  (orig: FUN_140473690)
void FUN_140473690(longlong param_1,short param_2)

{
  short sVar1;
  int iVar2;
  longlong *plVar3;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4)
    ;
    iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar2 == 1) goto LAB_14047374e;
  }
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar2 != 2) {
    return;
  }
LAB_14047374e:
  if (*(longlong *)(param_1 + 0x10) != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),3)
    ;
    sVar1 = (**(code **)(*plVar3 + 0x30))(plVar3);
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),3)
    ;
    (**(code **)(*plVar3 + 200))(plVar3,param_2 + sVar1);
    iVar2 = FUN_1404730a0(param_1);
    if ((iVar2 == 1) && (*(int *)(param_1 + 8) <= (int)(uint)(ushort)(param_2 + sVar1))) {
      FUN_140473100(param_1,2);
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

