// ==== CMsgOSConnectInfo::ctor_or_dtor  @1402c3180  [high:vtable-assign]  (orig: FUN_1402c3180)
undefined8 * FUN_1402c3180(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgOSConnectInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgOSConnectInfo::ctor_or_dtor  @1402c31d0  [high:vtable-assign]  (orig: FUN_1402c31d0)
void FUN_1402c31d0(undefined8 *param_1)

{
  *param_1 = CMsgOSConnectInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgOSConnectInfo::vfunc_1  @1402c3200  [high:rtti-vtable]  (orig: FUN_1402c3200)
ulonglong FUN_1402c3200(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xb55);
}

// ==== CMsgOSConnectInfo::vfunc_3  @1402c3370  [high:rtti-vtable]  (orig: FUN_1402c3370)
void FUN_1402c3370(void)

{
  return;
}

// ==== CMsgOSConnectInfo::ctor_or_dtor  @1402c3380  [high:vtable-assign]  (orig: FUN_1402c3380)
undefined8 * FUN_1402c3380(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgOSConnectInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

