// ==== CActivityMgr::helper_140260080  @140260080  [medium:callgraph-r1]  (orig: FUN_140260080)
void FUN_140260080(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140260080(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CActivityMgr::helper_1402601b0  @1402601b0  [medium:callgraph-r1]  (orig: FUN_1402601b0)
void FUN_1402601b0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CActivityMgr::helper_140260260  @140260260  [medium:callgraph-r2]  (orig: FUN_140260260)
void FUN_140260260(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140260080(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CActivityMgr::helper_140260850  @140260850  [medium:callgraph-r0]  (orig: FUN_140260850)
void FUN_140260850(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = *(longlong **)param_1[9];
  plVar2 = (longlong *)param_1[3];
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = (longlong *)param_1[9];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[3])) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_1404288c0();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[9] + 8) + 0x29);
  plVar4 = *(longlong **)(param_1[9] + 8);
  while (cVar1 == '\0') {
    FUN_140260080(param_1 + 3,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[9] + 8) = param_1[9];
  param_1[10] = 0;
  *(undefined8 *)param_1[9] = param_1[9];
  *(undefined8 *)(param_1[9] + 0x10) = param_1[9];
  if (param_1[1] != 0) {
    FUN_140425e50(param_1[1]);
    param_1[1] = 0;
  }
  if (param_1[2] != 0) {
    FUN_1404252f0(param_1[2]);
    param_1[2] = 0;
  }
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CActivityMgr::helper_140261080  @140261080  [medium:callgraph-r1]  (orig: FUN_140261080)
longlong * FUN_140261080(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140260260(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140260bd0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CActivityMgr::helper_140261920  @140261920  [medium:callgraph-r0]  (orig: FUN_140261920)
void FUN_140261920(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140261080((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CActivityMgr::ctor_or_dtor  @140261ef0  [high:vtable-assign]  (orig: FUN_140261ef0)
void FUN_140261ef0(undefined8 *param_1)

{
  *param_1 = CActivityMgr::vftable;
  FUN_140261920(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CActivityMgr::helper_140261f30  @140261f30  [medium:callgraph-r0]  (orig: FUN_140261f30)
undefined8 * FUN_140261f30(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402601b0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CActivityMgr::ctor_or_dtor  @140261fb0  [high:vtable-assign]  (orig: FUN_140261fb0)
undefined8 * FUN_140261fb0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CActivityMgr::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_140261f30(param_1 + 3);
  *(undefined4 *)(param_1 + 0xb) = 0;
  *(undefined4 *)((longlong)param_1 + 0x5c) = param_2;
  return param_1;
}

// ==== CActivityMgr::ctor_or_dtor  @140262010  [high:vtable-assign]  (orig: FUN_140262010)
undefined8 * FUN_140262010(undefined8 *param_1,uint param_2)

{
  *param_1 = CActivityMgr::vftable;
  FUN_140261920(param_1 + 3);
  operator_delete((void *)param_1[3]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CActivityMgr::ctor_or_dtor  @140262080  [high:vtable-assign]  (orig: FUN_140262080)
undefined8 * FUN_140262080(undefined4 param_1)

{
  int iVar1;
  undefined8 *puVar2;
  longlong lVar3;
  
  puVar2 = operator_new(0x60);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CActivityMgr::vftable;
    puVar2[1] = 0;
    puVar2[2] = 0;
    FUN_140261f30(puVar2 + 3);
    *(undefined4 *)(puVar2 + 0xb) = 0;
    *(undefined4 *)((longlong)puVar2 + 0x5c) = param_1;
  }
  if (puVar2 != (undefined8 *)0x0) {
    lVar3 = FUN_140426170(*(undefined4 *)((longlong)puVar2 + 0x5c));
    puVar2[1] = lVar3;
    if (lVar3 != 0) {
      lVar3 = FUN_140425620(*(undefined4 *)((longlong)puVar2 + 0x5c));
      puVar2[2] = lVar3;
      if (lVar3 != 0) {
        iVar1 = tq::DateStamp(0);
        *(int *)(puVar2 + 0xb) = iVar1;
        return puVar2;
      }
    }
    FUN_140260850(puVar2);
  }
  return (undefined8 *)0x0;
}

// ==== CActivityMgr::LoadActivityRewardType  @140425020  [high:log-string]  (orig: FUN_140425020)
undefined8 FUN_140425020(longlong param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  int iVar9;
  undefined4 local_res10 [2];
  longlong *local_res18;
  void **local_res20;
  longlong *local_d0 [3];
  void *local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  longlong *local_a0;
  longlong local_98;
  longlong *local_90 [3];
  undefined4 local_78 [2];
  void *local_70 [3];
  void *local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)
           (**(code **)(*plVar5 + 0x10))
                     (plVar5,
                      "SELECT * FROM cq_activity_reward_type ORDER BY metempsychosis, reward_grade;;"
                      ,1);
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR("CActivityMgr::LoadActivityRewardType(), CreateRecordset() error.");
    uVar6 = 0;
  }
  else {
    lVar7 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar7 == 0) {
      log_InlineLogDBERROR("table:cq_activity_reward_type not config data.");
      (**(code **)*plVar5)(plVar5);
      uVar6 = 1;
    }
    else {
      for (iVar9 = 0; iVar3 = (**(code **)(*plVar5 + 0x40))(plVar5), iVar9 < iVar3;
          iVar9 = iVar9 + 1) {
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar9);
        local_res18 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        if (local_res18 != (longlong *)0x0) {
          plVar8 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,1);
          uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
          puVar1 = (undefined8 *)(param_1 + 8);
          local_res10[0] = uVar4;
          FUN_140267440(puVar1,&local_a0,local_res10);
          plVar8 = local_a0;
          lVar7 = *(longlong *)(param_1 + 0x38);
          local_90[0] = (longlong *)*puVar1;
          if ((local_a0 == (longlong *)0x0) || (local_a0 != local_90[0])) {
            _invalid_parameter_noinfo();
          }
          lVar2 = local_98;
          if (local_98 == lVar7) {
            local_res20 = operator_new(8);
            if (local_res20 == (void **)0x0) {
              local_d0[0] = (longlong *)0x0;
            }
            else {
              *local_res20 = local_d0;
              local_d0[0] = (longlong *)local_res20;
            }
            local_b8 = (void *)0x0;
            local_b0 = 0;
            local_a8 = 0;
            local_90[0] = (longlong *)local_res20;
            FUN_140019370(local_d0,&local_res18);
            local_78[0] = uVar4;
            FUN_140267b90(local_70,local_d0);
            FUN_140269d60(puVar1,local_90,local_78);
            local_res20 = local_70;
            if (local_58 != (void *)0x0) {
              operator_delete(local_58);
            }
            local_58 = (void *)0x0;
            local_50 = 0;
            local_48 = 0;
            operator_delete(local_70[0]);
            if (local_b8 != (void *)0x0) {
              operator_delete(local_b8);
            }
            local_b8 = (void *)0x0;
            local_b0 = 0;
            local_a8 = 0;
            operator_delete(local_d0[0]);
          }
          else {
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar8;
            }
            if (lVar2 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140019370(lVar2 + 0x20,&local_res18);
          }
        }
      }
      (**(code **)*plVar5)(plVar5);
      uVar6 = 1;
    }
  }
  return uVar6;
}

// ==== CActivityMgr::helper_1404288c0  @1404288c0  [medium:callgraph-r1]  (orig: FUN_1404288c0)
void FUN_1404288c0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = *(longlong **)param_1[7];
  plVar2 = (longlong *)param_1[1];
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = (longlong *)param_1[7];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_1404ddff0();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar4 = *(longlong **)(param_1[7] + 8);
  while (cVar1 == '\0') {
    FUN_140427340(param_1 + 1,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

