// ==== CNormalFile@?A0x16c71dd6::vfunc_1  @1405738e0  [high:rtti-vtable]  (orig: FUN_1405738e0)
bool FUN_1405738e0(longlong param_1)

{
  return *(longlong *)(param_1 + 8) != 0;
}

// ==== CNormalFile@?A0x16c71dd6::vfunc_2  @1405738f0  [high:rtti-vtable]  (orig: FUN_1405738f0)
ulonglong FUN_1405738f0(longlong param_1,void *param_2,int param_3,int param_4)

{
  int iVar1;
  size_t sVar2;
  uint uVar3;
  
  if (param_2 != (void *)0x0) {
    sVar2 = fread(param_2,(longlong)param_3,(longlong)param_4,*(FILE **)(param_1 + 8));
    return sVar2 * (longlong)param_3;
  }
  iVar1 = fseek(*(FILE **)(param_1 + 8),param_3 * param_4,1);
  uVar3 = 0;
  if (iVar1 == 0) {
    uVar3 = param_3 * param_4;
  }
  return (ulonglong)uVar3;
}

// ==== CNormalFile@?A0x16c71dd6::vfunc_0  @140573e30  [high:rtti-vtable]  (orig: FUN_140573e30)
undefined8 * FUN_140573e30(undefined8 *param_1,uint param_2)

{
  *param_1 = _anon_16C71DD6::CNormalFile::vftable;
  if ((FILE *)param_1[1] != (FILE *)0x0) {
    fclose((FILE *)param_1[1]);
  }
  *param_1 = IFile::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

