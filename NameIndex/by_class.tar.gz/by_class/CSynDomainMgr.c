// ==== CSynDomainMgr::helper_14024c450  @14024c450  [medium:callgraph-r0]  (orig: FUN_14024c450)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14024c450(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  undefined1 auStack_458 [32];
  undefined4 local_438 [2];
  undefined1 local_430 [24];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  memset(local_418,0,0x400);
  _snprintf(local_418,0x400,"SELECT * FROM cq_npc WHERE mapid = %u");
  local_19 = 0;
  FUN_140008520(0xe);
  plVar2 = (longlong *)InstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,local_418,1);
  if (plVar2 != (longlong *)0x0) {
    iVar5 = 0;
    iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (0 < iVar1) {
      do {
        (**(code **)(*plVar2 + 0x30))(plVar2,(longlong)iVar5);
        plVar3 = (longlong *)(**(code **)(*plVar2 + 0x38))(plVar2);
        if (plVar3 != (longlong *)0x0) {
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0);
          local_438[0] = (**(code **)(*plVar4 + 0x40))(plVar4);
          FUN_14000d480(param_1 + 8,local_430,local_438);
          (**(code **)*plVar3)(plVar3,1);
        }
        iVar5 = iVar5 + 1;
        iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
      } while (iVar5 < iVar1);
    }
    (**(code **)*plVar2)(plVar2);
  }
  return 1;
}

// ==== CSynDomainMgr::ctor_or_dtor  @14024c5a0  [high:vtable-assign]  (orig: FUN_14024c5a0)
void FUN_14024c5a0(undefined8 *param_1)

{
  *param_1 = CSynDomainMgr::vftable;
  FUN_14000c310(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CSynDomainMgr::ctor_or_dtor  @14024c5e0  [high:vtable-assign]  (orig: FUN_14024c5e0)
undefined8 * FUN_14024c5e0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CSynDomainMgr::vftable;
  FUN_14000ef40(param_1 + 1);
  *(undefined4 *)(param_1 + 9) = param_2;
  return param_1;
}

// ==== CSynDomainMgr::ctor_or_dtor  @14024c630  [high:vtable-assign]  (orig: FUN_14024c630)
undefined8 * FUN_14024c630(undefined8 *param_1,uint param_2)

{
  *param_1 = CSynDomainMgr::vftable;
  FUN_14000c310(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSynDomainMgr::ctor_or_dtor  @14024c6a0  [high:vtable-assign]  (orig: FUN_14024c6a0)
undefined8 * FUN_14024c6a0(undefined4 param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x50);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CSynDomainMgr::vftable;
    FUN_14000ef40(puVar2 + 1);
    *(undefined4 *)(puVar2 + 9) = param_1;
  }
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_14024c450(puVar2);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

