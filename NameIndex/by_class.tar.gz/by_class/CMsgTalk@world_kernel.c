// ==== CMsgTalk@world_kernel::helper_14006c7c0  @14006c7c0  [medium:callgraph-r2]  (orig: FUN_14006c7c0)
undefined8 * FUN_14006c7c0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x49) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x49) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x49) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x49) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x49) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x49) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgTalk@world_kernel::helper_14006f090  @14006f090  [medium:callgraph-r1]  (orig: FUN_14006f090)
longlong FUN_14006f090(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14006c7c0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x49) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x49) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x49);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x49);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x49);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x49);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14006d760(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgTalk@world_kernel::helper_14006feb0  @14006feb0  [medium:callgraph-r0]  (orig: FUN_14006feb0)
void FUN_14006feb0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa0))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x49);
  puVar3 = *(undefined8 **)(param_1 + 0xa0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x49);
  }
  puVar7 = *(undefined8 **)(param_1 + 0xa0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x70);
  if (*(longlong *)(param_1 + 0x70) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xa0);
    local_28 = *(longlong *)(param_1 + 0x70);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0xa0);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x70))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)(lVar4 + 0x20) = 200;
  }
  return;
}

// ==== CMsgTalk@world_kernel::helper_14006ffc0  @14006ffc0  [medium:callgraph-r0]  (orig: FUN_14006ffc0)
void FUN_14006ffc0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_14006f090(param_1 + 0x70,local_res10);
  return;
}

// ==== CMsgTalk@world_kernel::vfunc_1  @14007a7f0  [high:rtti-vtable]  (orig: FUN_14007a7f0)
undefined8 FUN_14007a7f0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgTalk@world_kernel::vfunc_0  @14007a820  [high:rtti-vtable]  (orig: FUN_14007a820)
undefined8 * FUN_14007a820(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTalk@world_kernel::vfunc_3  @14007a880  [high:rtti-vtable]  (orig: FUN_14007a880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14007a880(longlong param_1,longlong param_2)

{
  char cVar1;
  ulong *puVar2;
  int iVar3;
  ulong uVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined8 ****ppppuVar7;
  longlong *plVar8;
  ulonglong uVar9;
  char ****_Str;
  longlong *plVar10;
  int iVar11;
  ulong *puVar12;
  longlong *plVar13;
  char *pcVar14;
  ulonglong uVar15;
  longlong *plVar16;
  undefined1 auStack_358 [32];
  undefined4 local_338;
  longlong *local_328 [3];
  ulong *local_310;
  ulong *local_308;
  longlong local_300;
  longlong *local_2f8 [2];
  undefined8 local_2e8;
  undefined8 uStack_2e0;
  undefined4 local_2d8;
  undefined4 uStack_2d4;
  undefined4 uStack_2d0;
  undefined4 uStack_2cc;
  undefined8 local_2c8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_2c0 [8];
  undefined8 ***local_2b8 [2];
  ulonglong local_2a8;
  ulonglong local_2a0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_298 [8];
  char ***local_290 [3];
  ulonglong local_278;
  char local_270 [16];
  char local_260 [16];
  char local_250 [24];
  char local_238 [256];
  char local_138 [256];
  ulonglong local_38;
  
  local_2c8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_358;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),0,local_260,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),1,local_270,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),2,local_250,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),3,local_138,0x100);
  uVar5 = FUN_140054e10();
  lVar6 = FUN_140070520(uVar5);
  if ((lVar6 == 0) && (*(short *)(*(longlong *)(param_1 + 0x420) + 8) != 0x89e)) {
    local_338 = 0x67;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pUser || m_pInfo->unTxtAttribute==_TXTATR_MSG_SYSTEM"
                       ,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\worldkernel\\network2\\msgtalk.cpp"
                      );
  }
  else if (*(short *)(*(longlong *)(param_1 + 0x420) + 8) == 0x7db) {
    local_238[0] = '\0';
    memset(local_238 + 1,0,0xff);
    sscanf(local_138,"%s",local_238);
    iVar3 = _stricmp(local_238,"/lock");
    if (iVar3 == 0) {
      uVar9 = 0xffffffffffffffff;
      pcVar14 = local_238;
      do {
        if (uVar9 == 0) break;
        uVar9 = uVar9 - 1;
        cVar1 = *pcVar14;
        pcVar14 = pcVar14 + 1;
      } while (cVar1 != '\0');
      uVar4 = strtoul(local_138 + ~uVar9,(char **)0x0,10);
      uVar5 = FUN_140054e10();
      FUN_14006feb0(uVar5,uVar4);
    }
    else {
      iVar3 = _stricmp(local_238,"/unlock");
      if (iVar3 == 0) {
        uVar9 = 0xffffffffffffffff;
        pcVar14 = local_238;
        do {
          if (uVar9 == 0) break;
          uVar9 = uVar9 - 1;
          cVar1 = *pcVar14;
          pcVar14 = pcVar14 + 1;
        } while (cVar1 != '\0');
        uVar4 = strtoul(local_138 + ~uVar9,(char **)0x0,10);
        uVar5 = FUN_140054e10();
        FUN_14006ffc0(uVar5,uVar4);
      }
      else {
        iVar3 = _stricmp(local_238,"/uncongealAccount");
        if (iVar3 == 0) {
          local_2f8[0] = operator_new(8);
          plVar16 = (longlong *)0x0;
          local_328[0] = plVar16;
          if (local_2f8[0] != (longlong *)0x0) {
            *local_2f8[0] = (longlong)local_328;
            local_328[0] = local_2f8[0];
          }
          local_310 = (ulong *)0x0;
          local_308 = (ulong *)0x0;
          local_300 = 0;
          local_2e8 = local_2f8[0];
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_2c0,local_138);
          iVar3 = 0x11;
          uVar15 = 0x11;
          uVar9 = local_2a8;
          if (0x11 < (int)local_2a8) {
            do {
              if (uVar9 < uVar15) {
                _invalid_parameter_noinfo();
                uVar9 = local_2a8;
              }
              ppppuVar7 = local_2b8;
              if (0xf < local_2a0) {
                ppppuVar7 = (undefined8 ****)local_2b8[0];
              }
              iVar11 = iVar3;
              if (*(char *)(uVar15 + (longlong)ppppuVar7) != ' ') {
                do {
                  iVar11 = iVar11 + 1;
                  uVar15 = uVar15 + 1;
                  if (uVar9 < uVar15) {
                    _invalid_parameter_noinfo();
                    uVar9 = local_2a8;
                  }
                  ppppuVar7 = local_2b8;
                  if (0xf < local_2a0) {
                    ppppuVar7 = (undefined8 ****)local_2b8[0];
                  }
                } while ((*(char *)(uVar15 + (longlong)ppppuVar7) != ' ') && (iVar11 < (int)uVar9));
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::substr
                          (local_2c0,(__uint64)local_298,(longlong)iVar3);
                _Str = local_290;
                if (0xf < local_278) {
                  _Str = (char ****)local_290[0];
                }
                uVar4 = strtoul((char *)_Str,(char **)0x0,10);
                puVar12 = local_308;
                local_2f8[0] = (longlong *)CONCAT44(local_2f8[0]._4_4_,uVar4);
                plVar10 = plVar16;
                if (local_310 != (ulong *)0x0) {
                  plVar10 = (longlong *)(local_300 - (longlong)local_310 >> 2);
                }
                if ((longlong *)((longlong)local_308 - (longlong)local_310 >> 2) < plVar10) {
                  *local_308 = uVar4;
                  local_308 = local_308 + 1;
                }
                else {
                  if (local_308 < local_310) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_310;
                  plVar10 = local_328[0];
                  local_2e8 = local_328[0];
                  uStack_2e0 = puVar12;
                  plVar13 = plVar16;
                  if (((longlong)local_308 - (longlong)local_310 & 0xfffffffffffffffcU) != 0) {
                    if (local_308 < local_310) {
                      _invalid_parameter_noinfo();
                    }
                    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_328[0])) {
                      _invalid_parameter_noinfo();
                    }
                    plVar13 = (longlong *)((longlong)puVar12 - (longlong)puVar2 >> 2);
                  }
                  local_2d8 = (undefined4)local_2e8;
                  uStack_2d4 = local_2e8._4_4_;
                  uStack_2d0 = (undefined4)uStack_2e0;
                  uStack_2cc = uStack_2e0._4_4_;
                  FUN_140036c20(local_328,&local_2d8,1,local_2f8);
                  puVar12 = local_310;
                  if (local_308 < local_310) {
                    _invalid_parameter_noinfo();
                  }
                  plVar10 = local_328[0];
                  if (local_328[0] == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    plVar8 = plVar16;
                  }
                  else {
                    plVar8 = (longlong *)*local_328[0];
                  }
                  if (puVar12 + (longlong)plVar13 <= (ulong *)plVar8[4]) {
                    plVar8 = plVar16;
                    if (plVar10 != (longlong *)0x0) {
                      plVar8 = (longlong *)*plVar10;
                    }
                    if ((ulong *)plVar8[3] <= puVar12 + (longlong)plVar13) goto LAB_14007acf7;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_14007acf7:
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_298);
                uVar9 = local_2a8;
              }
              iVar3 = iVar11 + 1;
              uVar15 = uVar15 + 1;
            } while (iVar3 < (int)uVar9);
          }
          puVar12 = local_310;
          if (*(int *)(param_2 + 0xf8) == 3) {
            plVar10 = local_328[0];
            if (local_308 < local_310) {
              _invalid_parameter_noinfo();
              plVar10 = local_328[0];
            }
            while( true ) {
              puVar2 = local_308;
              if (local_308 < local_310) {
                _invalid_parameter_noinfo();
              }
              if ((plVar10 == (longlong *)0x0) || (plVar10 != local_328[0])) {
                _invalid_parameter_noinfo();
              }
              if (puVar12 == puVar2) break;
              if (plVar10 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar13 = plVar16;
              }
              else {
                plVar13 = (longlong *)*plVar10;
              }
              if ((ulong *)plVar13[4] <= puVar12) {
                _invalid_parameter_noinfo();
              }
              local_338 = 0x7a;
              FUN_1400558e0(param_2,*puVar12,0,0);
              if (plVar10 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar13 = plVar16;
              }
              else {
                plVar13 = (longlong *)*plVar10;
              }
              if ((ulong *)plVar13[4] <= puVar12) {
                _invalid_parameter_noinfo();
              }
              puVar12 = puVar12 + 1;
            }
          }
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_2c0);
          if (local_310 != (ulong *)0x0) {
            operator_delete(local_310);
          }
          local_310 = (ulong *)0x0;
          local_308 = (ulong *)0x0;
          local_300 = 0;
          operator_delete(local_328[0]);
        }
      }
    }
  }
  return;
}

