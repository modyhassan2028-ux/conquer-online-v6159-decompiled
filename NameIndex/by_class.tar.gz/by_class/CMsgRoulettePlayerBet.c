// ==== CMsgRoulettePlayerBet::ctor_or_dtor  @1404dda80  [high:vtable-assign]  (orig: FUN_1404dda80)
undefined8 * FUN_1404dda80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRoulettePlayerBet::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRoulettePlayerBet::ctor_or_dtor  @1404ddad0  [high:vtable-assign]  (orig: FUN_1404ddad0)
void FUN_1404ddad0(undefined8 *param_1)

{
  *param_1 = CMsgRoulettePlayerBet::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRoulettePlayerBet::vfunc_1  @1404ddb00  [high:rtti-vtable]  (orig: FUN_1404ddb00)
ulonglong FUN_1404ddb00(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xafa);
}

// ==== CMsgRoulettePlayerBet::vfunc_3  @1404ddc60  [high:rtti-vtable]  (orig: FUN_1404ddc60)
void FUN_1404ddc60(void)

{
  return;
}

// ==== CMsgRoulettePlayerBet::ctor_or_dtor  @1404ddc70  [high:vtable-assign]  (orig: FUN_1404ddc70)
undefined8 * FUN_1404ddc70(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRoulettePlayerBet::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

