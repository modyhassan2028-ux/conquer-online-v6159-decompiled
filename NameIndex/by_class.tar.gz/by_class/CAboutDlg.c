// ==== CAboutDlg::ctor_or_dtor  @14001e420  [high:vtable-assign]  (orig: FUN_14001e420)
CDialog * FUN_14001e420(CDialog *param_1)

{
  CDialog::CDialog(param_1,100,(CWnd *)0x0);
  *(undefined ***)param_1 = CAboutDlg::vftable;
  return param_1;
}

// ==== CAboutDlg::vfunc_66  @14001fc70  [high:rtti-vtable]  (orig: FUN_14001fc70)
void FUN_14001fc70(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014001fc76. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EnableWindow(*(undefined8 *)(param_1 + 0x40),0);
  return;
}

// ==== CAboutDlg::vfunc_67  @14001fc80  [high:rtti-vtable]  (orig: FUN_14001fc80)
void FUN_14001fc80(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014001fc89. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  EnableWindow(*(undefined8 *)(param_1 + 0x40),1);
  return;
}

// ==== CAboutDlg::vfunc_81  @14001fd10  [high:rtti-vtable]  (orig: FUN_14001fd10)
void FUN_14001fd10(CDialog *param_1,ushort param_2,CWnd *param_3)

{
  CDialog::Create(param_1,(char *)(ulonglong)param_2,param_3);
  return;
}

// ==== CAboutDlg::vfunc_1  @140021910  [high:rtti-vtable]  (orig: FUN_140021910)
CDialog * FUN_140021910(CDialog *param_1,uint param_2)

{
  CDialog::~CDialog(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAboutDlg::vfunc_65  @140021960  [high:rtti-vtable]  (orig: FUN_140021960)
void FUN_140021960(void)

{
  return;
}

// ==== CAboutDlg::vfunc_12  @140021970  [high:rtti-vtable]  (orig: FUN_140021970)
undefined ** FUN_140021970(void)

{
  return &PTR_LAB_1406e09a8;
}

// ==== CAboutDlg::ctor_or_dtor  @1400219f0  [high:vtable-assign]  (orig: FUN_1400219f0)
void FUN_1400219f0(CWnd *param_1,uint param_2)

{
  undefined **local_f8 [31];
  
  if ((param_2 & 0xfff0) == 0x10) {
    CDialog::CDialog((CDialog *)local_f8,100,(CWnd *)0x0);
    local_f8[0] = CAboutDlg::vftable;
    CDialog::DoModal((CDialog *)local_f8);
    CDialog::~CDialog((CDialog *)local_f8);
  }
  else if ((param_2 & 0xfff0) == 0xf060) {
    PostMessageA(*(HWND *)(param_1 + 0x40),0x111,2,0);
  }
  else {
    CWnd::Default(param_1);
  }
  return;
}

