// ==== CVexillumArenicActor@adapter::helper_1402ba6c0  @1402ba6c0  [medium:callgraph-r0]  (orig: FUN_1402ba6c0)
undefined8 FUN_1402ba6c0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  if (iVar1 != 0x2e) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
    if (iVar1 != 0x2f) {
      return 0;
    }
  }
  return 1;
}

// ==== CVexillumArenicActor@adapter::helper_14055e760  @14055e760  [medium:callgraph-r2]  (orig: FUN_14055e760)
void FUN_14055e760(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<bool> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CVexillumArenicActor@adapter::helper_14055fa30  @14055fa30  [medium:callgraph-r2]  (orig: FUN_14055fa30)
bool FUN_14055fa30(longlong param_1,longlong param_2)

{
  bool bVar1;
  
  if ((*(longlong *)(param_1 + 8) != *(longlong *)(param_2 + 8)) ||
     (bVar1 = true, *(longlong *)(param_1 + 0x10) != *(longlong *)(param_2 + 0x10))) {
    bVar1 = false;
  }
  return !bVar1;
}

// ==== CVexillumArenicActor@adapter::helper_140562b40  @140562b40  [medium:callgraph-r1]  (orig: FUN_140562b40)
longlong FUN_140562b40(longlong *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  lVar1 = param_1[2];
  if ((longlong *)*param_1 == (longlong *)0x0) {
    lVar3 = 0;
  }
  else {
    lVar3 = *(longlong *)*param_1;
  }
  uVar2 = *(ulonglong *)(lVar3 + 0x30);
  if (*(ulonglong *)(lVar3 + 0x38) < uVar2) {
    _invalid_parameter_noinfo();
  }
  return ((longlong)(param_1[1] - uVar2) >> 2) * 0x20 + lVar1;
}

// ==== CVexillumArenicActor@adapter::helper_140562ba0  @140562ba0  [medium:callgraph-r0]  (orig: FUN_140562ba0)
longlong * FUN_140562ba0(longlong *param_1,longlong param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  if (param_2 != 0) {
    if ((*param_1 == 0) || (param_1[1] == 0)) {
      _invalid_parameter_noinfo();
    }
    if (param_2 < 0) {
      uVar1 = FUN_140562b40(param_1);
      if (uVar1 < (ulonglong)-param_2) {
        _invalid_parameter_noinfo();
      }
    }
    else {
      if ((longlong *)*param_1 == (longlong *)0x0) {
        lVar3 = 0;
      }
      else {
        lVar3 = *(longlong *)*param_1;
      }
      lVar2 = FUN_140562b40(param_1);
      if (*(ulonglong *)(lVar3 + 0x10) < (ulonglong)(lVar2 + param_2)) {
        _invalid_parameter_noinfo();
      }
    }
    if ((param_2 < 0) && ((ulonglong)param_1[2] < (ulonglong)-param_2)) {
      param_2 = param_1[2] + param_2;
      param_1[1] = param_1[1] + (-param_2 - 1U >> 5) * -4 + -4;
      param_1[2] = (ulonglong)((uint)param_2 & 0x1f);
      return param_1;
    }
    param_1[1] = param_1[1] + ((ulonglong)(param_1[2] + param_2) >> 5) * 4;
    param_1[2] = (ulonglong)((uint)(param_1[2] + param_2) & 0x1f);
  }
  return param_1;
}

// ==== CVexillumArenicActor@adapter::helper_140562de0  @140562de0  [medium:callgraph-r2]  (orig: FUN_140562de0)
void FUN_140562de0(longlong *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  if ((*param_1 == 0) || (param_1[1] == 0)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = param_1[2];
  if ((longlong *)*param_1 == (longlong *)0x0) {
    lVar3 = 0;
  }
  else {
    lVar3 = *(longlong *)*param_1;
  }
  uVar2 = *(ulonglong *)(lVar3 + 0x30);
  if (*(ulonglong *)(lVar3 + 0x38) < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((longlong *)*param_1 == (longlong *)0x0) {
    lVar3 = 0;
  }
  else {
    lVar3 = *(longlong *)*param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x10) <
      (ulonglong)(lVar1 + 1 + ((longlong)(param_1[1] - uVar2) >> 2) * 0x20)) {
    _invalid_parameter_noinfo();
  }
  if ((ulonglong)param_1[2] < 0x1f) {
    param_1[2] = param_1[2] + 1;
    return;
  }
  param_1[1] = param_1[1] + 4;
  param_1[2] = 0;
  return;
}

// ==== CVexillumArenicActor@adapter::helper_140563ec0  @140563ec0  [medium:callgraph-r2]  (orig: FUN_140563ec0)
void FUN_140563ec0(longlong *param_1,ulonglong param_2,undefined4 param_3)

{
  rsize_t _DstSize;
  void *_Src;
  void *pvVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_res18 [2];
  longlong local_28;
  void *pvStack_20;
  
  _Src = (void *)param_1[4];
  pvVar1 = (void *)param_1[3];
  uVar3 = (longlong)_Src - (longlong)pvVar1 >> 2;
  local_res18[0] = param_3;
  if (uVar3 < param_2) {
    if (_Src < pvVar1) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    pvStack_20 = _Src;
    FUN_140274790(param_1,&local_28,param_2 - (param_1[4] - param_1[3] >> 2),local_res18);
    return;
  }
  if (uVar3 <= param_2) {
    return;
  }
  if (_Src < pvVar1) {
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar4 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar4;
  }
  else {
    lVar5 = *plVar2;
  }
  pvVar1 = (void *)(uVar3 + param_2 * 4);
  if (pvVar1 <= *(void **)(lVar5 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar4 = *plVar2;
    }
    if (*(void **)(lVar4 + 0x18) <= pvVar1) goto LAB_140563fa7;
  }
  _invalid_parameter_noinfo();
LAB_140563fa7:
  if ((pvVar1 < (void *)param_1[3]) || ((void *)param_1[4] < pvVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (pvVar1 != _Src) {
    lVar4 = param_1[4] - (longlong)_Src >> 2;
    _DstSize = lVar4 * 4;
    if (0 < lVar4) {
      memmove_s(pvVar1,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)pvVar1);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::helper_140564890  @140564890  [medium:callgraph-r1]  (orig: FUN_140564890)
void FUN_140564890(longlong *param_1,undefined8 param_2,char *param_3)

{
  uint *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  char cVar4;
  longlong lVar5;
  longlong *plVar6;
  
  cVar4 = FUN_14055fa30();
  while (cVar4 != '\0') {
    if ((undefined8 *)*param_1 == (undefined8 *)0x0) {
      plVar6 = (longlong *)0x0;
    }
    else {
      plVar6 = *(longlong **)*param_1;
    }
    puVar1 = (uint *)param_1[1];
    lVar2 = param_1[2];
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar6 = (longlong *)*plVar6;
    if (*param_3 == '\0') {
      if ((plVar6 == (longlong *)0x0) || (puVar1 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar6;
      }
      uVar3 = *(ulonglong *)(lVar5 + 0x30);
      if (*(ulonglong *)(lVar5 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar6;
      }
      if (*(ulonglong *)(lVar5 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar1 - uVar3) >> 2) * 0x20 + lVar2)) {
        _invalid_parameter_noinfo();
      }
      *puVar1 = *puVar1 & ~(1 << ((byte)lVar2 & 0x1f));
    }
    else {
      if ((plVar6 == (longlong *)0x0) || (puVar1 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar6;
      }
      uVar3 = *(ulonglong *)(lVar5 + 0x30);
      if (*(ulonglong *)(lVar5 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar6;
      }
      if (*(ulonglong *)(lVar5 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar1 - uVar3) >> 2) * 0x20 + lVar2)) {
        _invalid_parameter_noinfo();
      }
      *puVar1 = *puVar1 | 1 << ((byte)lVar2 & 0x1f);
    }
    FUN_140562de0(param_1);
    cVar4 = FUN_14055fa30(param_1,param_2);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::helper_140564d40  @140564d40  [medium:callgraph-r3]  (orig: FUN_140564d40)
longlong * FUN_140564d40(longlong *param_1,undefined8 param_2,longlong *param_3,longlong *param_4)

{
  uint *puVar1;
  uint *puVar2;
  ulonglong uVar3;
  char cVar4;
  longlong lVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  cVar4 = FUN_14055fa30(param_2,param_3);
  while (cVar4 != '\0') {
    if (param_3[2] == 0) {
      if ((*param_3 == 0) || (param_3[1] == 0)) {
        _invalid_parameter_noinfo();
      }
      if ((longlong *)*param_3 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *(longlong *)*param_3;
      }
      uVar3 = *(ulonglong *)(lVar5 + 0x30);
      if (*(ulonglong *)(lVar5 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if ((ulonglong)param_3[1] <= uVar3) {
        _invalid_parameter_noinfo();
      }
      param_3[1] = param_3[1] + -4;
      param_3[2] = 0x1f;
    }
    else {
      param_3[2] = param_3[2] + -1;
    }
    if ((undefined8 *)*param_3 == (undefined8 *)0x0) {
      plVar8 = (longlong *)0x0;
    }
    else {
      plVar8 = *(longlong **)*param_3;
    }
    lVar5 = param_3[2];
    puVar1 = (uint *)param_3[1];
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar8 = (longlong *)*plVar8;
    if (param_4[2] == 0) {
      if ((*param_4 == 0) || (param_4[1] == 0)) {
        _invalid_parameter_noinfo();
      }
      if ((longlong *)*param_4 == (longlong *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = *(longlong *)*param_4;
      }
      uVar3 = *(ulonglong *)(lVar6 + 0x30);
      if (*(ulonglong *)(lVar6 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if ((ulonglong)param_4[1] <= uVar3) {
        _invalid_parameter_noinfo();
      }
      param_4[1] = param_4[1] + -4;
      param_4[2] = 0x1f;
    }
    else {
      param_4[2] = param_4[2] + -1;
    }
    if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
      plVar9 = (longlong *)0x0;
    }
    else {
      plVar9 = *(longlong **)*param_4;
    }
    puVar2 = (uint *)param_4[1];
    lVar6 = param_4[2];
    if (plVar9 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)*plVar9;
    if ((plVar8 == (longlong *)0x0) || (puVar1 == (uint *)0x0)) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 == (longlong *)0x0) {
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar8;
    }
    uVar3 = *(ulonglong *)(lVar7 + 0x30);
    if (*(ulonglong *)(lVar7 + 0x38) < uVar3) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 == (longlong *)0x0) {
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar8;
    }
    if (*(ulonglong *)(lVar7 + 0x10) <=
        (ulonglong)(((longlong)((longlong)puVar1 - uVar3) >> 2) * 0x20 + lVar5)) {
      _invalid_parameter_noinfo();
    }
    if ((*puVar1 & 1 << ((byte)lVar5 & 0x1f)) == 0) {
      if ((plVar9 == (longlong *)0x0) || (puVar2 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar9;
      }
      uVar3 = *(ulonglong *)(lVar5 + 0x30);
      if (*(ulonglong *)(lVar5 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar9;
      }
      if (*(ulonglong *)(lVar5 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar2 - uVar3) >> 2) * 0x20 + lVar6)) {
        _invalid_parameter_noinfo();
      }
      *puVar2 = *puVar2 & ~(1 << ((byte)lVar6 & 0x1f));
    }
    else {
      if ((plVar9 == (longlong *)0x0) || (puVar2 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar9;
      }
      uVar3 = *(ulonglong *)(lVar5 + 0x30);
      if (*(ulonglong *)(lVar5 + 0x38) < uVar3) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar9;
      }
      if (*(ulonglong *)(lVar5 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar2 - uVar3) >> 2) * 0x20 + lVar6)) {
        _invalid_parameter_noinfo();
      }
      *puVar2 = *puVar2 | 1 << ((byte)lVar6 & 0x1f);
    }
    cVar4 = FUN_14055fa30(param_2,param_3);
  }
  *param_1 = *param_4;
  param_1[1] = param_4[1];
  param_1[2] = param_4[2];
  return param_1;
}

// ==== CVexillumArenicActor@adapter::helper_140567150  @140567150  [medium:callgraph-r2]  (orig: FUN_140567150)
undefined8 *
FUN_140567150(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined1 local_res8;
  undefined8 local_88;
  longlong local_80;
  longlong local_78;
  undefined8 local_68;
  longlong local_60;
  longlong local_58;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_28;
  longlong local_20;
  longlong local_18;
  
  local_28 = *param_4;
  local_20 = param_4[1];
  local_18 = param_4[2];
  local_88 = *param_3;
  local_80 = param_3[1];
  local_78 = param_3[2];
  local_68 = *param_2;
  local_60 = param_2[1];
  local_58 = param_2[2];
  local_48 = *param_4;
  local_40 = param_4[1];
  local_38 = param_4[2];
  FUN_140562ba0(&local_48,(local_58 + (local_80 - local_60 >> 2) * -0x20) - local_78);
  *param_1 = local_48;
  param_1[1] = local_40;
  param_1[2] = local_38;
  local_48 = local_28;
  local_40 = local_20;
  local_38 = local_18;
  local_28 = local_88;
  local_20 = local_80;
  local_18 = local_78;
  local_88 = local_68;
  local_80 = local_60;
  local_78 = local_58;
  FUN_140564d40(&local_68,&local_88,&local_28,&local_48,local_res8,0,0);
  return param_1;
}

// ==== CVexillumArenicActor@adapter::helper_140567750  @140567750  [medium:callgraph-r1]  (orig: FUN_140567750)
longlong FUN_140567750(undefined8 *param_1,longlong param_2,ulonglong param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 local_98;
  ulonglong local_90;
  undefined8 local_88;
  undefined8 local_78;
  ulonglong local_70;
  undefined8 local_68;
  undefined8 local_58;
  ulonglong local_50;
  undefined8 local_48;
  undefined8 local_38;
  ulonglong local_30;
  undefined8 local_28;
  
  uVar1 = param_1[6];
  if ((ulonglong)param_1[7] < uVar1) {
    _invalid_parameter_noinfo();
  }
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = ((longlong)(*(longlong *)(param_2 + 8) - uVar1) >> 2) * 0x20 +
          *(longlong *)(param_2 + 0x10);
  if (param_3 != 0) {
    if (-param_1[2] - 1 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14055e760(param_1);
    }
    FUN_140563ec0(param_1 + 3,param_1[2] + 0x1f + param_3 >> 5,0);
    if (param_1[2] == 0) {
      param_1[2] = param_3;
    }
    else {
      uVar1 = param_1[6];
      if ((ulonglong)param_1[7] < uVar1) {
        _invalid_parameter_noinfo();
      }
      local_78 = *param_1;
      local_68 = 0;
      local_70 = uVar1;
      if (param_1[2] != 0) {
        FUN_140562ba0(&local_78);
      }
      param_1[2] = param_1[2] + param_3;
      uVar1 = param_1[6];
      if ((ulonglong)param_1[7] < uVar1) {
        _invalid_parameter_noinfo();
      }
      local_98 = *param_1;
      local_88 = 0;
      local_90 = uVar1;
      if (param_1[2] != 0) {
        FUN_140562ba0(&local_98);
      }
      uVar1 = param_1[6];
      local_58 = local_98;
      local_50 = local_90;
      local_48 = local_88;
      local_38 = local_78;
      local_30 = local_70;
      local_28 = local_68;
      if ((ulonglong)param_1[7] < uVar1) {
        _invalid_parameter_noinfo();
      }
      local_98 = *param_1;
      local_68 = 0;
      local_88 = 0;
      local_90 = uVar1;
      local_78 = local_98;
      local_70 = uVar1;
      FUN_140562ba0(&local_98,lVar2);
      local_78 = local_98;
      local_70 = local_90;
      local_68 = local_88;
      FUN_140567150(&local_98,&local_78,&local_38,&local_58);
    }
  }
  return lVar2;
}

// ==== CVexillumArenicActor@adapter::helper_140567b20  @140567b20  [medium:callgraph-r0]  (orig: FUN_140567b20)
void FUN_140567b20(undefined8 *param_1,undefined8 *param_2,longlong param_3,undefined1 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined1 local_res20 [8];
  undefined8 local_68;
  ulonglong local_60;
  undefined8 local_58;
  undefined8 local_48;
  ulonglong local_40;
  undefined8 local_38;
  undefined8 local_28;
  ulonglong local_20;
  undefined8 local_18;
  
  local_28 = *param_2;
  local_20 = param_2[1];
  local_18 = param_2[2];
  local_res20[0] = param_4;
  lVar2 = FUN_140567750(param_1,&local_28);
  local_60 = param_1[6];
  if ((ulonglong)param_1[7] < local_60) {
    _invalid_parameter_noinfo();
  }
  local_58 = 0;
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  local_68 = *param_1;
  local_40 = local_60;
  local_38 = local_58;
  local_48 = local_68;
  FUN_140562ba0(&local_48,param_3 + lVar2);
  uVar1 = param_1[6];
  if ((ulonglong)param_1[7] < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_68 = *param_1;
  local_58 = 0;
  local_18 = 0;
  local_60 = uVar1;
  local_28 = local_68;
  local_20 = uVar1;
  FUN_140562ba0(&local_28,lVar2);
  local_68 = local_48;
  local_60 = local_40;
  local_58 = local_38;
  local_48 = local_28;
  local_40 = local_20;
  local_38 = local_18;
  FUN_140564890(&local_48,&local_68,local_res20);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_1  @14058f010  [high:rtti-vtable]  (orig: FUN_14058f010)
void FUN_14058f010(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_0  @14058f080  [high:rtti-vtable]  (orig: FUN_14058f080)
bool FUN_14058f080(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_1  @14058f0a0  [high:rtti-vtable]  (orig: FUN_14058f0a0)
undefined8 FUN_14058f0a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058f0c2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_2  @14058f0d0  [high:rtti-vtable]  (orig: FUN_14058f0d0)
undefined1 * FUN_14058f0d0(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f128. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_3  @14058f130  [high:rtti-vtable]  (orig: FUN_14058f130)
undefined8 FUN_14058f130(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f183. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_4  @14058f190  [high:rtti-vtable]  (orig: FUN_14058f190)
undefined8 FUN_14058f190(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f1e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_5  @14058f1f0  [high:rtti-vtable]  (orig: FUN_14058f1f0)
undefined8 FUN_14058f1f0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058f212. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_6  @14058f220  [high:rtti-vtable]  (orig: FUN_14058f220)
undefined8 FUN_14058f220(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058f242. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_7  @14058f250  [high:rtti-vtable]  (orig: FUN_14058f250)
undefined8 FUN_14058f250(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_8  @14058f2b0  [high:rtti-vtable]  (orig: FUN_14058f2b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14058f2b0(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == 0) {
    local_498 = 0x7e;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar2 == 0) {
      local_498 = 0x82;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_140161fa0(lVar2,param_3);
      FUN_140362560(local_478);
      cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
      }
      FUN_1403625e0(local_478);
    }
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_9  @14058f3c0  [high:rtti-vtable]  (orig: FUN_14058f3c0)
undefined8 FUN_14058f3c0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    plVar4 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar4;
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    uVar5 = (**(code **)(lVar1 + 8))(plVar4,uVar2,0x73,0,param_3,0,0,0,0,0,0);
    return uVar5;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_10  @14058f470  [high:rtti-vtable]  (orig: FUN_14058f470)
undefined8 FUN_14058f470(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    plVar4 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar4;
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    (**(code **)(lVar1 + 0x10))(plVar4,uVar2,0x73);
    return 1;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_11  @14058f4e0  [high:rtti-vtable]  (orig: FUN_14058f4e0)
undefined8 FUN_14058f4e0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2d8))((longlong *)(lVar2 + 0x10),0x73);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_12  @14058f520  [high:rtti-vtable]  (orig: FUN_14058f520)
undefined8 FUN_14058f520(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2d8))((longlong *)(lVar2 + 0x10),0x73);
    if (cVar1 != '\0') {
      plVar3 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2,0x73);
    }
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_13  @14058f580  [high:rtti-vtable]  (orig: FUN_14058f580)
void FUN_14058f580(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140170e90(lVar1,param_3);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_14  @14058f5e0  [high:rtti-vtable]  (orig: FUN_14058f5e0)
undefined1 * FUN_14058f5e0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f681. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_15  @14058f690  [high:rtti-vtable]  (orig: FUN_14058f690)
ulonglong FUN_14058f690(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f740. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1,param_2,param_3);
  return uVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_16  @14058f750  [high:rtti-vtable]  (orig: FUN_14058f750)
ulonglong FUN_14058f750(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058f7e7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x248))(plVar1,param_2);
  return uVar2;
}

// ==== CVexillumArenicActor@adapter::vfunc_17  @14058f7f0  [high:rtti-vtable]  (orig: FUN_14058f7f0)
undefined8 FUN_14058f7f0(undefined8 param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(*plVar1 + 0x158))(plVar1,param_2,param_3);
  return 1;
}

// ==== CVexillumArenicActor@adapter::vfunc_18  @14058f8f0  [high:rtti-vtable]  (orig: FUN_14058f8f0)
void FUN_14058f8f0(undefined8 param_1,int param_2,undefined4 param_3,undefined8 param_4,
                  undefined8 param_5)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)CurrentInstanceGet();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x3c8))(plVar1,param_2,param_3,param_4,param_5);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_19  @14058f9e0  [high:rtti-vtable]  (orig: FUN_14058f9e0)
void FUN_14058f9e0(undefined8 param_1,int param_2)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)CurrentInstanceGet();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x3d0))(plVar1,param_2,2);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_20  @14058fa90  [high:rtti-vtable]  (orig: FUN_14058fa90)
void FUN_14058fa90(void)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058fb1f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x398))(plVar1,1);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_21  @14058fb30  [high:rtti-vtable]  (orig: FUN_14058fb30)
void FUN_14058fb30(void)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058fbbf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x3e0))(plVar1,1);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_25  @14058fbd0  [high:rtti-vtable]  (orig: FUN_14058fbd0)
bool FUN_14058fbd0(undefined8 param_1,int param_2,longlong param_3,undefined2 *param_4,
                  longlong param_5,longlong param_6)

{
  undefined2 uVar1;
  int iVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  int iVar7;
  
  iVar7 = 0;
  uVar6 = 0;
  lVar5 = 0;
  param_5 = param_5 - (longlong)param_4;
  param_3 = param_3 - (longlong)param_4;
  param_6 = param_6 - (longlong)param_4;
  while( true ) {
    plVar4 = DAT_140975bc0;
    if (DAT_140975bc0 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    uVar3 = (**(code **)(*plVar4 + 0x18))();
    if (uVar3 <= uVar6) break;
    plVar4 = DAT_140975bc0;
    if (DAT_140975bc0 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,uVar6);
    if (((plVar4 != (longlong *)0x0) &&
        (iVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,1), iVar2 == param_2)) &&
       (iVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,2), iVar2 == 0x19)) {
      if (2 < lVar5) {
        log_InlineLogERROR("CVexillumArenicMgr::GetVlmTarRang. nIndex > 2");
        return false;
      }
      uVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,3);
      *(undefined2 *)(param_3 + (longlong)param_4) = uVar1;
      uVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,4);
      *param_4 = uVar1;
      uVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,5);
      *(undefined2 *)(param_5 + (longlong)param_4) = uVar1;
      uVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,6);
      iVar7 = iVar7 + 1;
      *(undefined2 *)(param_6 + (longlong)param_4) = uVar1;
      lVar5 = lVar5 + 1;
      param_4 = param_4 + 1;
    }
    uVar6 = uVar6 + 1;
  }
  return iVar7 == 3;
}

// ==== CVexillumArenicActor@adapter::vfunc_36  @14058fd70  [high:rtti-vtable]  (orig: FUN_14058fd70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14058fd70(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x29c);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CVexillumArenicActor@adapter::vfunc_42  @14058fed0  [high:rtti-vtable]  (orig: FUN_14058fed0)
void FUN_14058fed0(undefined8 param_1,undefined4 param_2)

{
  FUN_140006ad0(param_2,0);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_0  @14058fee0  [high:rtti-vtable]  (orig: FUN_14058fee0)
void FUN_14058fee0(longlong param_1)

{
  FUN_14058ff40(param_1 + -8);
  return;
}

// ==== CVexillumArenicActor@adapter::helper_14058ff40  @14058ff40  [medium:callgraph-r0]  (orig: FUN_14058ff40)
undefined8 * FUN_14058ff40(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CVexillumArenicActor::vftable;
  param_1[1] = adapter::CVexillumArenicActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CVexillumArenicActor@adapter::vfunc_22  @14058ff90  [high:rtti-vtable]  (orig: FUN_14058ff90)
undefined8 FUN_14058ff90(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      FUN_1402be990(local_res8,param_3);
      FUN_1402bda30(local_res8);
      return 1;
    }
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_26  @140590060  [high:rtti-vtable]  (orig: FUN_140590060)
ulonglong FUN_140590060(longlong param_1,undefined8 param_2,undefined4 param_3,short *param_4,
                       short *param_5)

{
  short sVar1;
  short sVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  undefined8 uVar9;
  int iVar10;
  longlong local_res8;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x88) + 0x20))(*(longlong **)(lVar6 + 0x88),param_3)
  ;
  iVar10 = 0;
  local_res8 = 0;
  uVar8 = 0;
  if (plVar7 != (longlong *)0x0) {
    uVar8 = (**(code **)(*plVar7 + 0x298))(plVar7,0x1040,&local_res8);
  }
  if ((lVar5 != 0) && (local_res8 != 0)) {
    plVar7 = (longlong *)(lVar5 + 0x10);
    sVar2 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x40))(plVar7);
    *param_4 = sVar2;
    sVar2 = (**(code **)(*plVar7 + 0x48))(plVar7);
    *param_5 = sVar2;
    do {
      iVar3 = tq::RandGet(2);
      *param_4 = *param_4 + (short)iVar3;
      iVar3 = tq::RandGet(2);
      *param_5 = *param_5 + (short)iVar3;
      sVar2 = *param_5;
      sVar1 = *param_4;
      uVar9 = (**(code **)(*plVar7 + 0x160))(plVar7);
      uVar8 = FUN_1402c3cc0(uVar9,sVar1,sVar2);
      if ((char)uVar8 != '\0') {
        sVar2 = *param_5;
        sVar1 = *param_4;
        uVar4 = (**(code **)(*plVar7 + 0x168))(plVar7);
        uVar8 = FUN_1402bf7a0(local_res8,uVar4,sVar1,sVar2);
        return uVar8;
      }
      iVar10 = iVar10 + 1;
    } while (iVar10 < 1000);
  }
  return uVar8 & 0xffffffffffffff00;
}

// ==== CVexillumArenicActor@adapter::vfunc_29  @1405901e0  [high:rtti-vtable]  (orig: FUN_1405901e0)
undefined8 FUN_1405901e0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  local_res8 = 0;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      FUN_1402bf7a0(local_res8,5000,0x50);
      return 1;
    }
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_30  @1405902a0  [high:rtti-vtable]  (orig: FUN_1405902a0)
undefined8
FUN_1405902a0(longlong param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))(*(longlong **)(lVar3 + 0x88),param_2)
  ;
  local_res8 = 0;
  if ((plVar4 != (longlong *)0x0) &&
     (cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8), cVar1 != '\0')) {
    uVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x40))(local_res8 + 0x10);
    *param_3 = uVar2;
    uVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x48))();
    *param_4 = uVar2;
    return 1;
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_33  @140590380  [high:rtti-vtable]  (orig: FUN_140590380)
void FUN_140590380(longlong param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong local_res8;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar4 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(lVar4 + 0x88) + 0x20))(*(longlong **)(lVar4 + 0x88),param_2)
  ;
  local_res8 = 0;
  if (plVar5 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,&local_res8);
    if (cVar1 != '\0') {
      lVar4 = *(longlong *)(local_res8 + 0x10);
      plVar5 = (longlong *)(local_res8 + 0x10);
      iVar2 = (**(code **)(lVar4 + 0x80))(plVar5);
      iVar3 = (**(code **)(*plVar5 + 0x78))(plVar5);
      (**(code **)(lVar4 + 0x2e0))(local_res8 + 0x10,0,iVar2 - iVar3,1,0);
      return;
    }
  }
  log_InlineLogERROR("CVexillumArenicActor::SetTarFullLive. Npc id invalid!(%u)");
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_34  @140590480  [high:rtti-vtable]  (orig: FUN_140590480)
void FUN_140590480(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  local_res8 = 0;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      plVar3 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar3 + 0x18))(plVar3,param_2);
      return;
    }
  }
  log_InlineLogERROR("CVexillumArenicActor::DeleteTarAllStatus. Npc id invalid!(%u)");
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_35  @140590540  [high:rtti-vtable]  (orig: FUN_140590540)
void FUN_140590540(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_38  @140590600  [high:rtti-vtable]  (orig: FUN_140590600)
void FUN_140590600(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  uint uVar5;
  
  uVar5 = (uint)*(ushort *)(param_3 + 8);
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,uVar5,0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x98) == 0) {
      uVar5 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                       (*(longlong **)(lVar2 + 0x98),param_2,1);
    if (plVar3 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                        (*(longlong **)(param_1 + 0x10),param_4);
      (**(code **)(*plVar3 + 0x38))(plVar3,puVar1,uVar4,*plVar3,uVar5);
    }
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_37  @140590730  [high:rtti-vtable]  (orig: FUN_140590730)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140590730(longlong param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4,
                  undefined2 param_5,undefined4 param_6)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  FUN_14015b240();
  local_4a8 = 1;
  local_4b0 = 0;
  local_4b8 = 0;
  local_4c0 = 0;
  local_4c8 = param_5;
  local_4d8 = 0;
  local_4d0 = param_4;
  iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_3);
  if (iVar1 != 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x98) == 0) {
      local_4d8 = CONCAT44(local_4d8._4_4_,0x131);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                       (*(longlong **)(lVar2 + 0x98),param_2,1);
    if (plVar3 == (longlong *)0x0) {
      local_4d8 = CONCAT44(local_4d8._4_4_,0x2c7);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                        (*(longlong **)(param_1 + 0x10),param_6);
      (**(code **)(*plVar3 + 0x38))(plVar3,local_488,uVar4);
    }
  }
  FUN_14015b2c0(local_488);
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_39  @140590890  [high:rtti-vtable]  (orig: FUN_140590890)
void FUN_140590890(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  puVar2 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
  if (puVar2 != (undefined8 *)0x0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                       (*(longlong **)(lVar3 + 0x98),param_2,1);
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_4);
    if ((plVar4 == (longlong *)0x0) || (lVar3 == 0)) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar1 = *plVar4;
      uVar5 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x2a0))();
      (**(code **)(lVar1 + 0x30))(plVar4,uVar5,puVar2,param_5);
    }
    (**(code **)*puVar2)(puVar2,1);
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_28  @1405909e0  [high:rtti-vtable]  (orig: FUN_1405909e0)
undefined1
FUN_1405909e0(longlong param_1,undefined4 param_2,undefined4 param_3,ushort *param_4,ushort *param_5
             )

{
  longlong *plVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 uVar8;
  int iVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *local_88;
  int local_80;
  longlong *local_78;
  longlong *local_70 [3];
  longlong *local_58;
  longlong *local_50;
  undefined8 local_48;
  undefined8 local_40;
  uint local_38;
  uint uStack_34;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x88) + 0x20))(*(longlong **)(lVar6 + 0x88),param_2)
  ;
  iVar9 = 0;
  local_40 = 0;
  if ((plVar7 == (longlong *)0x0) ||
     (cVar2 = (**(code **)(*plVar7 + 0x298))(plVar7,0x1040,&local_40), cVar2 == '\0')) {
    return 0;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar7 = (longlong *)FUN_1400876b0(uVar8);
  lVar6 = (**(code **)(*plVar7 + 0x10))(plVar7,param_3,1);
  if (lVar6 == 0) {
    return 0;
  }
  iVar4 = (**(code **)(**(longlong **)(lVar6 + 0x60) + 0x28))();
  iVar5 = (**(code **)(**(longlong **)(lVar6 + 0x60) + 0x20))();
  local_80 = iVar4 + 1;
LAB_140590af1:
  plVar7 = (longlong *)0x0;
  iVar4 = tq::RandGet(local_80);
  *param_4 = (ushort)iVar4;
  iVar4 = tq::RandGet(iVar5 + 1);
  *param_5 = (ushort)iVar4;
  cVar2 = FUN_1402c3cc0(lVar6,*param_4,(ushort)iVar4);
  if (((cVar2 != '\0') && (cVar2 = FUN_1402c68a0(lVar6,0x18,*param_4,*param_5), cVar2 == '\0')) &&
     (cVar2 = FUN_1402c68a0(lVar6,0x19,*param_4,*param_5), cVar2 == '\0')) {
    local_88 = operator_new(8);
    if (local_88 != (longlong *)0x0) {
      *local_88 = (longlong)local_70;
      plVar7 = local_88;
    }
    local_58 = (longlong *)0x0;
    local_50 = (longlong *)0x0;
    local_48 = 0;
    local_38 = (uint)*param_4;
    uStack_34 = (uint)*param_5;
    local_78 = local_88;
    local_70[0] = plVar7;
    FUN_1402d2470(lVar6,local_70,(ulonglong)CONCAT24(*param_5,local_38),0x19,0x1040);
    plVar11 = local_58;
    plVar7 = local_70[0];
    if (local_50 < local_58) {
      _invalid_parameter_noinfo();
      plVar7 = local_70[0];
    }
    do {
      plVar1 = local_50;
      if (local_50 < local_58) {
        _invalid_parameter_noinfo();
      }
      if ((plVar7 == (longlong *)0x0) || (plVar7 != local_70[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar11 == plVar1) {
        uVar3 = FUN_1402bf7a0(local_40,param_3,*param_4,*param_5);
        if (local_58 != (longlong *)0x0) {
          operator_delete(local_58);
        }
        local_58 = (longlong *)0x0;
        local_50 = (longlong *)0x0;
        local_48 = 0;
        operator_delete(local_70[0]);
        return uVar3;
      }
      lVar10 = 0;
      local_78 = (longlong *)0x0;
      local_88 = (longlong *)0x0;
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar10;
      }
      else {
        lVar12 = *plVar7;
      }
      if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
        _invalid_parameter_noinfo();
      }
      if (*plVar11 != 0) {
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = lVar10;
        }
        else {
          lVar12 = *plVar7;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        cVar2 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_78);
        if (((cVar2 != '\0') &&
            (cVar2 = (**(code **)(*local_78 + 0x298))(local_78,0x1040,&local_88), cVar2 != '\0')) &&
           (cVar2 = FUN_1402ba6c0(local_88), cVar2 != '\0')) goto LAB_140590cd0;
      }
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar10 = *plVar7;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar11) {
        _invalid_parameter_noinfo();
      }
      plVar11 = plVar11 + 1;
    } while( true );
  }
  goto LAB_140590cff;
LAB_140590cd0:
  if (local_58 != (longlong *)0x0) {
    operator_delete(local_58);
  }
  local_58 = (longlong *)0x0;
  local_50 = (longlong *)0x0;
  local_48 = 0;
  operator_delete(local_70[0]);
LAB_140590cff:
  iVar9 = iVar9 + 1;
  if (2999 < iVar9) {
    log_InlineLogERROR("CVexillumArenicActor::RefreshNpc. fail");
    return 0;
  }
  goto LAB_140590af1;
}

// ==== CVexillumArenicActor@adapter::vfunc_31  @140590d90  [high:rtti-vtable]  (orig: FUN_140590d90)
undefined8
FUN_140590d90(longlong param_1,int param_2,int param_3,undefined4 *param_4,undefined4 *param_5,
             undefined4 *param_6)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *local_res8;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)(**(code **)(**(longlong **)(lVar5 + 0x88) + 0x30))();
  if (plVar6 != (longlong *)0x0) {
    local_res8 = (longlong *)0x0;
    (**(code **)(*plVar6 + 0x10))(plVar6,&local_48);
    while( true ) {
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x18))(plVar6,local_28);
      if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar7)) {
        _invalid_parameter_noinfo();
      }
      if (uStack_40 == (longlong *)plVar7[1]) break;
      local_38 = local_48;
      uStack_34 = uStack_44;
      uStack_30 = (undefined4)uStack_40;
      uStack_2c = uStack_40._4_4_;
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,&local_38);
      if (((plVar7 != (longlong *)0x0) &&
          (cVar2 = (**(code **)(*plVar7 + 0x298))(plVar7,0x1040,&local_res8), cVar2 != '\0')) &&
         ((char)local_res8[0xd] != '\0')) {
        if (local_res8[0xc] == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          iVar3 = 0;
        }
        else {
          iVar3 = (**(code **)(*(longlong *)local_res8[0xc] + 8))();
        }
        if ((iVar3 == param_2) &&
           (iVar3 = (**(code **)(*(longlong *)local_res8[0xc] + 0x10))
                              ((longlong *)local_res8[0xc],4), iVar3 == param_3)) {
          uVar4 = (**(code **)(*local_res8 + 8))();
          *param_4 = uVar4;
          uVar4 = (**(code **)(local_res8[2] + 0x40))();
          *param_5 = uVar4;
          uVar4 = (**(code **)(local_res8[2] + 0x48))(local_res8 + 2);
          *param_6 = uVar4;
          return 1;
        }
      }
      if (CONCAT44(uStack_44,local_48) == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
        plVar7 = (longlong *)uStack_40[2];
        if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
          cVar2 = *(char *)(*plVar7 + 0x29);
          uStack_40 = plVar7;
          plVar7 = (longlong *)*plVar7;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*plVar7 + 0x29);
            uStack_40 = plVar7;
            plVar7 = (longlong *)*plVar7;
          }
        }
        else {
          cVar2 = *(char *)(uStack_40[1] + 0x29);
          plVar1 = (longlong *)uStack_40[1];
          plVar7 = uStack_40;
          while ((uStack_40 = plVar1, cVar2 == '\0' && (plVar7 == (longlong *)uStack_40[2]))) {
            cVar2 = *(char *)(uStack_40[1] + 0x29);
            plVar1 = (longlong *)uStack_40[1];
            plVar7 = uStack_40;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return 0;
}

// ==== CVexillumArenicActor@adapter::vfunc_23  @140590ff0  [high:rtti-vtable]  (orig: FUN_140590ff0)
void FUN_140590ff0(longlong param_1,int param_2,undefined8 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined4 local_res8 [2];
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined1 local_48 [16];
  undefined1 local_38 [8];
  undefined1 local_30 [24];
  longlong *local_18;
  longlong *local_10;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_38);
  do {
    cVar3 = FUN_1400ce310(local_30);
    while( true ) {
      if (cVar3 == '\0') {
        return;
      }
      cVar3 = (**(code **)(*local_18 + 0x298))(local_18,0x1001,&local_10);
      if (cVar3 != '\0') break;
      cVar3 = FUN_1400ce310(local_30);
    }
    if ((local_10 != (longlong *)0x0) &&
       (iVar4 = (**(code **)(local_10[2] + 0x168))(local_10 + 2), iVar4 == param_2)) {
      if (local_10 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(local_10[2] + 0x168))(local_10 + 2);
      if (iVar4 == param_2) {
        if (local_10 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        local_res8[0] = (**(code **)(*local_10 + 8))();
        puVar1 = (undefined4 *)param_3[3];
        if (puVar1 == (undefined4 *)0x0) {
          uVar6 = 0;
        }
        else {
          uVar6 = param_3[5] - (longlong)puVar1 >> 2;
        }
        puVar2 = (undefined4 *)param_3[4];
        if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2) < uVar6) {
          *puVar2 = local_res8[0];
          param_3[4] = puVar2 + 1;
        }
        else {
          if (puVar2 < puVar1) {
            _invalid_parameter_noinfo();
          }
          local_68 = (undefined4)*param_3;
          uStack_64 = (undefined4)((ulonglong)*param_3 >> 0x20);
          uStack_60 = SUB84(puVar2,0);
          uStack_5c = (undefined4)((ulonglong)puVar2 >> 0x20);
          local_58 = local_68;
          uStack_54 = uStack_64;
          uStack_50 = uStack_60;
          uStack_4c = uStack_5c;
          FUN_1400375c0(param_3,local_48,&local_58,local_res8);
        }
      }
    }
  } while( true );
}

// ==== CVexillumArenicActor@adapter::vfunc_24  @140591200  [high:rtti-vtable]  (orig: FUN_140591200)
undefined8
FUN_140591200(longlong param_1,int param_2,int param_3,ushort param_4,ushort param_5,ushort param_6,
             ushort param_7,undefined8 param_8)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined1 local_58 [8];
  undefined1 local_50 [24];
  longlong *local_38;
  longlong *local_30;
  
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_58);
  lVar6 = CONCAT44(param_8._4_4_,(undefined4)param_8);
  do {
    cVar3 = FUN_1400ce310(local_50);
    while( true ) {
      if (cVar3 == '\0') {
        lVar6 = *(longlong *)(lVar6 + 0x20) - *(longlong *)(lVar6 + 0x18);
        return CONCAT71((int7)(lVar6 >> 10),lVar6 >> 2 != 0);
      }
      cVar3 = (**(code **)(*local_38 + 0x298))(local_38,0x1001,&local_30);
      if (cVar3 != '\0') break;
      cVar3 = FUN_1400ce310(local_50);
    }
    if ((local_30 != (longlong *)0x0) &&
       (iVar4 = (**(code **)(local_30[2] + 0x168))(local_30 + 2), iVar4 == param_3)) {
      if (local_30 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(local_30[2] + 0x170))(local_30 + 2);
      if (iVar4 == param_2) {
        if (local_30 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar2 = local_30;
        plVar7 = (longlong *)FUN_1401181a0();
        lVar1 = *plVar7;
        uVar5 = (**(code **)(*plVar2 + 8))(plVar2);
        cVar3 = (**(code **)(lVar1 + 0x60))(plVar7,uVar5,0x73);
        if (cVar3 != '\0') {
          if (local_30 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(local_30[2] + 0x40))(local_30 + 2);
          if ((int)(uint)param_4 <= iVar4) {
            if (local_30 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            iVar4 = (**(code **)(local_30[2] + 0x40))(local_30 + 2);
            if (iVar4 < (int)((uint)param_6 + (uint)param_4)) {
              if (local_30 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              iVar4 = (**(code **)(local_30[2] + 0x48))(local_30 + 2);
              if ((int)(uint)param_5 <= iVar4) {
                if (local_30 == (longlong *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                iVar4 = (**(code **)(local_30[2] + 0x48))(local_30 + 2);
                if (iVar4 < (int)((uint)param_7 + (uint)param_5)) {
                  if (local_30 == (longlong *)0x0) {
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  param_8._0_4_ = (**(code **)(*local_30 + 8))();
                  FUN_140037fe0(lVar6,&param_8);
                }
              }
            }
          }
        }
      }
    }
  } while( true );
}

// ==== CVexillumArenicActor@adapter::vfunc_27  @140591580  [high:rtti-vtable]  (orig: FUN_140591580)
void FUN_140591580(longlong param_1,int param_2,undefined8 param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 local_res8 [2];
  longlong *local_res20;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar4 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x88) + 0x30))();
  if (plVar5 != (longlong *)0x0) {
    local_res20 = (longlong *)0x0;
    (**(code **)(*plVar5 + 0x10))(plVar5,&local_48);
    while( true ) {
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x18))(plVar5,local_28);
      if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar6)) {
        _invalid_parameter_noinfo();
      }
      if (uStack_40 == (longlong *)plVar6[1]) break;
      local_38 = local_48;
      uStack_34 = uStack_44;
      uStack_30 = (undefined4)uStack_40;
      uStack_2c = uStack_40._4_4_;
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,&local_38);
      if ((((plVar6 != (longlong *)0x0) &&
           (cVar2 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_res20), cVar2 != '\0')) &&
          ((char)local_res20[0xd] != '\0')) &&
         (iVar3 = (**(code **)(*(longlong *)local_res20[0xc] + 0x10))
                            ((longlong *)local_res20[0xc],4), iVar3 == param_2)) {
        local_res8[0] = (**(code **)(*local_res20 + 8))();
        FUN_140037fe0(param_3,local_res8);
      }
      if (CONCAT44(uStack_44,local_48) == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
        plVar6 = (longlong *)uStack_40[2];
        if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
          cVar2 = *(char *)(*plVar6 + 0x29);
          uStack_40 = plVar6;
          plVar6 = (longlong *)*plVar6;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*plVar6 + 0x29);
            uStack_40 = plVar6;
            plVar6 = (longlong *)*plVar6;
          }
        }
        else {
          cVar2 = *(char *)(uStack_40[1] + 0x29);
          plVar1 = (longlong *)uStack_40[1];
          plVar6 = uStack_40;
          while ((uStack_40 = plVar1, cVar2 == '\0' && (plVar6 == (longlong *)uStack_40[2]))) {
            cVar2 = *(char *)(uStack_40[1] + 0x29);
            plVar1 = (longlong *)uStack_40[1];
            plVar6 = uStack_40;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return;
}

// ==== CVexillumArenicActor@adapter::vfunc_40  @140591760  [high:rtti-vtable]  (orig: FUN_140591760)
void FUN_140591760(longlong param_1,int param_2,undefined8 param_3,ushort param_4,ushort param_5,
                  ushort param_6,ushort param_7)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  longlong lVar8;
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  longlong *local_98;
  undefined1 local_90 [8];
  undefined1 local_88 [24];
  longlong *local_70;
  longlong local_68 [2];
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_48 = 0xfffffffffffffffe;
  local_98 = operator_new(8);
  if (local_98 == (longlong *)0x0) {
    local_c8[0] = (longlong *)0x0;
  }
  else {
    *local_98 = (longlong)local_c8;
    local_c8[0] = local_98;
  }
  local_b0 = (undefined4 *)0x0;
  local_a8 = (undefined4 *)0x0;
  local_a0 = 0;
  local_58 = local_98;
  FUN_1402ac340(*(undefined8 *)(param_1 + 0x10),local_90);
LAB_140591801:
  while( true ) {
    do {
      do {
        do {
          do {
            do {
              cVar3 = FUN_1400ce310(local_88);
              while( true ) {
                if (cVar3 == '\0') {
                  local_68[0] = 0;
                  plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
                  (**(code **)(*plVar6 + 0x38))(plVar6,local_c8,param_3);
                  if (local_b0 != (undefined4 *)0x0) {
                    operator_delete(local_b0);
                  }
                  local_b0 = (undefined4 *)0x0;
                  local_a8 = (undefined4 *)0x0;
                  local_a0 = 0;
                  operator_delete(local_c8[0]);
                  return;
                }
                cVar3 = (**(code **)(*local_70 + 0x298))(local_70,0x1001,local_68);
                if (cVar3 != '\0') break;
                cVar3 = FUN_1400ce310(local_88);
              }
              if (local_68[0] == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              iVar4 = (**(code **)(*(longlong *)(local_68[0] + 0x10) + 0x168))();
            } while (iVar4 != param_2);
            if (local_68[0] == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            iVar4 = (**(code **)(*(longlong *)(local_68[0] + 0x10) + 0x40))();
          } while (iVar4 < (int)(uint)param_4);
          if (local_68[0] == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(*(longlong *)(local_68[0] + 0x10) + 0x40))();
        } while ((int)((uint)param_6 + (uint)param_4) <= iVar4);
        if (local_68[0] == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        iVar4 = (**(code **)(*(longlong *)(local_68[0] + 0x10) + 0x48))();
      } while (iVar4 < (int)(uint)param_5);
      if (local_68[0] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(*(longlong *)(local_68[0] + 0x10) + 0x48))();
    } while ((int)((uint)param_7 + (uint)param_5) <= iVar4);
    if (local_68[0] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    puVar2 = local_a8;
    local_98 = (longlong *)CONCAT44(local_98._4_4_,*(undefined4 *)(local_68[0] + 0x122c));
    if (local_b0 == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = local_a0 - (longlong)local_b0 >> 2;
    }
    if (uVar7 <= (ulonglong)((longlong)local_a8 - (longlong)local_b0 >> 2)) break;
    *local_a8 = *(undefined4 *)(local_68[0] + 0x122c);
    local_a8 = local_a8 + 1;
  }
  if (local_a8 < local_b0) {
    _invalid_parameter_noinfo();
  }
  puVar1 = local_b0;
  plVar6 = local_c8[0];
  local_58 = local_c8[0];
  uStack_50 = puVar2;
  if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) == 0) {
    lVar8 = 0;
  }
  else {
    if (local_a8 < local_b0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar6 == (longlong *)0x0) || (plVar6 != local_c8[0])) {
      _invalid_parameter_noinfo();
    }
    lVar8 = (longlong)puVar2 - (longlong)puVar1 >> 2;
  }
  local_38 = (undefined4)local_58;
  uStack_34 = local_58._4_4_;
  uStack_30 = (undefined4)uStack_50;
  uStack_2c = uStack_50._4_4_;
  FUN_140036c20(local_c8,&local_38,1,&local_98);
  puVar2 = local_b0;
  if (local_a8 < local_b0) {
    _invalid_parameter_noinfo();
  }
  plVar6 = local_c8[0];
  if (local_c8[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = 0;
  }
  else {
    lVar5 = *local_c8[0];
  }
  if (puVar2 + lVar8 <= *(undefined4 **)(lVar5 + 0x20)) goto code_r0x000140591b4e;
  goto LAB_140591b64;
code_r0x000140591b4e:
  if (plVar6 == (longlong *)0x0) {
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar6;
  }
  if (puVar2 + lVar8 < *(undefined4 **)(lVar5 + 0x18)) {
LAB_140591b64:
    _invalid_parameter_noinfo();
  }
  goto LAB_140591801;
}

// ==== CVexillumArenicActor@adapter::vfunc_41  @140591c00  [high:rtti-vtable]  (orig: FUN_140591c00)
void FUN_140591c00(longlong param_1,int param_2,int param_3,undefined8 param_4,int param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  longlong *local_98;
  undefined1 local_90 [8];
  undefined1 local_88 [24];
  longlong *local_70;
  longlong *local_68 [2];
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 local_48;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_48 = 0xfffffffffffffffe;
  local_98 = operator_new(8);
  if (local_98 == (longlong *)0x0) {
    local_c8[0] = (longlong *)0x0;
  }
  else {
    *local_98 = (longlong)local_c8;
    local_c8[0] = local_98;
  }
  local_b0 = (undefined4 *)0x0;
  local_a8 = (undefined4 *)0x0;
  local_a0 = 0;
  local_58 = local_98;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_90);
LAB_140591ce0:
  while( true ) {
    do {
      do {
        do {
          do {
            cVar3 = FUN_1400ce310(local_88);
            while( true ) {
              if (cVar3 == '\0') {
                local_68[0] = (longlong *)0x0;
                plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
                (**(code **)(*plVar7 + 0x38))(plVar7,local_c8,param_4);
                if (local_b0 != (undefined4 *)0x0) {
                  operator_delete(local_b0);
                }
                local_b0 = (undefined4 *)0x0;
                local_a8 = (undefined4 *)0x0;
                local_a0 = 0;
                operator_delete(local_c8[0]);
                return;
              }
              cVar3 = (**(code **)(*local_70 + 0x298))(local_70,0x1001,local_68);
              if (cVar3 != '\0') break;
              cVar3 = FUN_1400ce310(local_88);
            }
          } while ((local_68[0] == (longlong *)0x0) ||
                  (cVar3 = (**(code **)(local_68[0][2] + 0x280))(), cVar3 != '\0'));
          if (local_68[0] == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(*local_68[0] + 8))();
        } while (iVar4 == param_5);
        if (local_68[0] == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        iVar4 = (**(code **)(local_68[0][2] + 0x170))();
      } while (iVar4 != param_3);
      if (local_68[0] == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(local_68[0][2] + 0x168))();
    } while (iVar4 != param_2);
    if (local_68[0] == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    puVar2 = local_a8;
    local_98 = (longlong *)CONCAT44(local_98._4_4_,*(undefined4 *)((longlong)local_68[0] + 0x122c));
    if (local_b0 == (undefined4 *)0x0) {
      uVar8 = 0;
    }
    else {
      uVar8 = local_a0 - (longlong)local_b0 >> 2;
    }
    if (uVar8 <= (ulonglong)((longlong)local_a8 - (longlong)local_b0 >> 2)) break;
    *local_a8 = *(undefined4 *)((longlong)local_68[0] + 0x122c);
    local_a8 = local_a8 + 1;
  }
  if (local_a8 < local_b0) {
    _invalid_parameter_noinfo();
  }
  puVar1 = local_b0;
  plVar7 = local_c8[0];
  local_58 = local_c8[0];
  uStack_50 = puVar2;
  if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) == 0) {
    lVar5 = 0;
  }
  else {
    if (local_a8 < local_b0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar7 == (longlong *)0x0) || (plVar7 != local_c8[0])) {
      _invalid_parameter_noinfo();
    }
    lVar5 = (longlong)puVar2 - (longlong)puVar1 >> 2;
  }
  local_38 = (undefined4)local_58;
  uStack_34 = local_58._4_4_;
  uStack_30 = (undefined4)uStack_50;
  uStack_2c = uStack_50._4_4_;
  FUN_140036c20(local_c8,&local_38,1,&local_98);
  puVar2 = local_b0;
  if (local_a8 < local_b0) {
    _invalid_parameter_noinfo();
  }
  plVar7 = local_c8[0];
  if (local_c8[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *local_c8[0];
  }
  if (puVar2 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) goto code_r0x000140591f92;
  goto LAB_140591fa8;
code_r0x000140591f92:
  if (plVar7 == (longlong *)0x0) {
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar7;
  }
  if (puVar2 + lVar5 < *(undefined4 **)(lVar6 + 0x18)) {
LAB_140591fa8:
    _invalid_parameter_noinfo();
  }
  goto LAB_140591ce0;
}

// ==== CVexillumArenicActor@adapter::vfunc_32  @140592200  [high:rtti-vtable]  (orig: FUN_140592200)
void FUN_140592200(undefined8 param_1,longlong param_2)

{
  void *pvVar1;
  longlong lVar2;
  void *pvVar3;
  void *pvVar4;
  longlong *plVar5;
  uint uVar6;
  longlong *local_e8;
  void *local_e0;
  longlong local_d8;
  longlong *local_c8 [2];
  longlong local_b8;
  longlong *local_b0 [3];
  void *local_98;
  void *local_90;
  undefined8 local_88;
  undefined8 local_78;
  longlong *local_70;
  longlong *local_68;
  void *local_60;
  longlong local_58;
  longlong *local_48;
  void *local_40;
  undefined8 local_38;
  longlong *plVar7;
  
  local_78 = 0xfffffffffffffffe;
  plVar5 = operator_new(8);
  plVar7 = (longlong *)0x0;
  local_c8[0] = plVar7;
  if (plVar5 != (longlong *)0x0) {
    *plVar5 = (longlong)local_c8;
    local_c8[0] = plVar5;
  }
  local_b8 = 0;
  local_70 = operator_new(8);
  local_b0[0] = plVar7;
  if (local_70 != (longlong *)0x0) {
    *local_70 = (longlong)local_b0;
    local_b0[0] = local_70;
  }
  local_98 = (void *)0x0;
  local_90 = (void *)0x0;
  local_88 = 0;
  if (0 < (int)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2)) {
    do {
      pvVar1 = local_98;
      if (local_90 < local_98) {
        _invalid_parameter_noinfo();
      }
      local_e0 = pvVar1;
      local_d8 = 0;
      local_e8 = local_c8[0];
      if (local_b8 != 0) {
        FUN_140562ba0(&local_e8);
      }
      pvVar3 = local_98;
      lVar2 = local_d8;
      pvVar1 = local_e0;
      if (local_90 < local_98) {
        _invalid_parameter_noinfo();
      }
      local_68 = local_e8;
      local_60 = local_e0;
      local_58 = local_d8;
      FUN_140567b20(local_c8,&local_68,1);
      pvVar4 = local_98;
      if (local_90 < local_98) {
        _invalid_parameter_noinfo();
      }
      local_e0 = pvVar4;
      local_d8 = 0;
      local_e8 = local_c8[0];
      local_48 = local_c8[0];
      local_40 = pvVar4;
      local_38 = 0;
      FUN_140562ba0(&local_48,((longlong)pvVar1 - (longlong)pvVar3 >> 2) * 0x20 + lVar2);
      uVar6 = (int)plVar7 + 1;
      plVar7 = (longlong *)(ulonglong)uVar6;
    } while ((int)uVar6 < (int)(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 2))
    ;
  }
  if ((DAT_140975c58 & 1) == 0) {
    DAT_140975c58 = DAT_140975c58 | 1;
    plVar5 = (longlong *)CurrentInstanceGet();
    DAT_140975c50 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x16);
  }
  if (DAT_140975c50 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  (**(code **)(*DAT_140975c50 + 0x3c0))(DAT_140975c50,param_2,local_c8,0);
  local_b8 = 0;
  if (local_98 != (void *)0x0) {
    operator_delete(local_98);
  }
  local_98 = (void *)0x0;
  local_90 = (void *)0x0;
  local_88 = 0;
  operator_delete(local_b0[0]);
  operator_delete(local_c8[0]);
  return;
}

