// ==== CCrossMsgEnterConfirm::helper_140160320  @140160320  [medium:callgraph-r1]  (orig: FUN_140160320)
longlong FUN_140160320(void)

{
  longlong *plVar1;
  
  if ((DAT_140975e78 & 1) == 0) {
    DAT_140975e78 = DAT_140975e78 | 1;
    plVar1 = (longlong *)CurrentInstanceGet();
    DAT_140975e70 = (**(code **)(*plVar1 + 0x20))(plVar1,5);
  }
  if (DAT_140975e70 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return DAT_140975e70;
}

// ==== CCrossMsgEnterConfirm::helper_1401789a0  @1401789a0  [medium:callgraph-r0]  (orig: FUN_1401789a0)
void FUN_1401789a0(longlong *param_1)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  (**(code **)(*param_1 + 8))();
  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  tq::SysLogSave("crossuser","Enter Cross Server OK: user:%s(%u)");
  if ((char)param_1[0x259] != '\0') {
    *(undefined1 *)((longlong)param_1 + 0x12c9) = 0;
    *(undefined4 *)(param_1 + 0x25a) = 0;
    *(undefined4 *)((longlong)param_1 + 0x12cc) = 0;
    *(undefined4 *)(param_1 + 0x25b) = 0;
    *(undefined4 *)((longlong)param_1 + 0x12d4) = 0;
    *(undefined4 *)((longlong)param_1 + 0x135c) = 0;
    *(undefined4 *)(param_1 + 0x26c) = 0;
    *(undefined4 *)((longlong)param_1 + 0x1364) = 0;
    *(undefined4 *)(param_1 + 0x26d) = 0;
    plVar2 = (longlong *)FUN_1400e1e60();
    lVar3 = *plVar2;
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar3 + 0x18))(plVar2,uVar1);
    plVar2 = (longlong *)FUN_140160320();
    lVar3 = *plVar2;
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar3 + 0x18))(plVar2,uVar1);
    plVar2 = (longlong *)CurrentInstanceGet();
    if (plVar2 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar3 = FUN_140008520((int)param_1[0x246]);
      lVar3 = *(longlong *)(lVar3 + 400);
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar3 = 0;
      }
      FUN_140238210(lVar3,param_1);
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,8);
      if (plVar2 != (longlong *)0x0) {
        lVar3 = *plVar2;
        uVar1 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar3 + 0x1f0))(plVar2,uVar1);
      }
      uVar4 = FUN_140008520((int)param_1[0x246]);
      uVar4 = FUN_140087650(uVar4);
      FUN_1402a80e0(uVar4,1);
    }
  }
  return;
}

// ==== CCrossMsgEnterConfirm::helper_140238210  @140238210  [medium:callgraph-r1]  (orig: FUN_140238210)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140238210(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  char cVar5;
  uint uVar6;
  undefined8 *puVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong lVar11;
  undefined1 auStack_4c8 [32];
  longlong *local_4a8;
  undefined8 local_4a0;
  longlong *local_498;
  longlong *local_490;
  longlong *local_488;
  longlong *local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != (longlong *)0x0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar5 = *(char *)((longlong)puVar9 + 0x61);
    puVar10 = *(undefined8 **)(param_1 + 0x38);
    while (cVar5 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar6) {
        puVar7 = (undefined8 *)puVar9[2];
        puVar9 = puVar10;
      }
      else {
        puVar7 = (undefined8 *)*puVar9;
      }
      puVar10 = puVar9;
      puVar9 = puVar7;
      cVar5 = *(char *)((longlong)puVar7 + 0x61);
    }
    local_480 = puVar10;
    local_488 = *(longlong **)(param_1 + 8);
    puVar9 = *(undefined8 **)(param_1 + 0x38);
    if (*(longlong **)(param_1 + 8) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar10 == puVar9) || (uVar6 < *(uint *)(puVar10 + 3))) {
      local_4a0 = *(undefined8 *)(param_1 + 0x38);
      local_4a8 = *(longlong **)(param_1 + 8);
      pplVar8 = &local_4a8;
    }
    else {
      pplVar8 = &local_488;
    }
    plVar1 = *pplVar8;
    local_498 = plVar1;
    local_490 = pplVar8[1];
    plVar2 = *(longlong **)(param_1 + 0x38);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    plVar3 = local_490;
    if (local_490 != plVar2) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (plVar3 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3[0xb] != 0) {
        FUN_1404201a0(local_468);
        cVar5 = FUN_140420250(local_468,1,uVar6);
        if (cVar5 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
        }
        FUN_1404201f0(local_468);
      }
    }
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar5 = *(char *)((longlong)puVar9 + 0x61);
    puVar10 = *(undefined8 **)(param_1 + 0x78);
    while (cVar5 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar6) {
        puVar7 = (undefined8 *)puVar9[2];
        puVar9 = puVar10;
      }
      else {
        puVar7 = (undefined8 *)*puVar9;
      }
      puVar10 = puVar9;
      puVar9 = puVar7;
      cVar5 = *(char *)((longlong)puVar7 + 0x61);
    }
    local_490 = puVar10;
    local_498 = *(longlong **)(param_1 + 0x48);
    puVar9 = *(undefined8 **)(param_1 + 0x78);
    if (*(longlong **)(param_1 + 0x48) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar10 == puVar9) || (uVar6 < *(uint *)(puVar10 + 3))) {
      local_4a0 = *(undefined8 *)(param_1 + 0x78);
      local_4a8 = *(longlong **)(param_1 + 0x48);
      pplVar8 = &local_4a8;
    }
    else {
      pplVar8 = &local_498;
    }
    plVar1 = *pplVar8;
    local_488 = plVar1;
    local_480 = pplVar8[1];
    plVar2 = *(longlong **)(param_1 + 0x78);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    plVar3 = local_480;
    if (local_480 != plVar2) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (plVar3 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar9 = (undefined8 *)plVar3[10];
      puVar10 = (undefined8 *)*puVar9;
      plVar1 = (longlong *)plVar3[4];
      while( true ) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar10 == puVar9) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar1;
        }
        if (puVar10 == *(undefined8 **)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_1404201a0(local_468);
        cVar5 = FUN_140420250(local_468,1,*(undefined4 *)((longlong)puVar10 + 0x1c));
        if (cVar5 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
        }
        FUN_1404201f0(local_468);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar10 + 0x2d) == '\0') {
          puVar7 = (undefined8 *)puVar10[2];
          if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
            cVar5 = *(char *)((longlong)*puVar7 + 0x2d);
            puVar10 = puVar7;
            puVar7 = (undefined8 *)*puVar7;
            while (cVar5 == '\0') {
              cVar5 = *(char *)((longlong)*puVar7 + 0x2d);
              puVar10 = puVar7;
              puVar7 = (undefined8 *)*puVar7;
            }
          }
          else {
            cVar5 = *(char *)((longlong)puVar10[1] + 0x2d);
            puVar4 = (undefined8 *)puVar10[1];
            puVar7 = puVar10;
            while ((puVar10 = puVar4, cVar5 == '\0' && (puVar7 == (undefined8 *)puVar10[2]))) {
              cVar5 = *(char *)((longlong)puVar10[1] + 0x2d);
              puVar4 = (undefined8 *)puVar10[1];
              puVar7 = puVar10;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
  }
  return;
}

// ==== CCrossMsgEnterConfirm::ctor_or_dtor  @1403f1310  [high:vtable-assign]  (orig: FUN_1403f1310)
undefined8 * FUN_1403f1310(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgEnterConfirm::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgEnterConfirm::ctor_or_dtor  @1403f1360  [high:vtable-assign]  (orig: FUN_1403f1360)
void FUN_1403f1360(undefined8 *param_1)

{
  *param_1 = CCrossMsgEnterConfirm::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgEnterConfirm::vfunc_1  @1403f1390  [high:rtti-vtable]  (orig: FUN_1403f1390)
undefined8 FUN_1403f1390(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgEnterConfirm::ctor_or_dtor  @1403f1420  [high:vtable-assign]  (orig: FUN_1403f1420)
undefined8 * FUN_1403f1420(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgEnterConfirm::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgEnterConfirm::vfunc_3  @1403f1470  [high:rtti-vtable]  (orig: FUN_1403f1470)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403f1470(longlong param_1)

{
  short sVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined1 auStack_488 [32];
  uint local_468;
  undefined1 local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 != 0) {
    if (sVar1 == 1) {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar6 = (longlong *)FUN_140087650(uVar5);
      plVar6 = (longlong *)
               (**(code **)(*plVar6 + 0xa0))
                         (plVar6,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c));
      if (plVar6 == (longlong *)0x0) {
        return;
      }
      FUN_140368e20(local_448);
      uVar3 = *(undefined4 *)(param_1 + 0x41c);
      uVar4 = (**(code **)(*plVar6 + 0x38))(plVar6);
      cVar2 = FUN_140368ed0(local_448,2,uVar4,uVar3);
      if (cVar2 != '\0') {
        (**(code **)(*plVar6 + 0x130))(plVar6,local_448);
      }
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar7 = (longlong *)FUN_140087650(uVar5);
      lVar8 = *plVar7;
      uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
      local_460 = 1;
      local_468 = local_468 & 0xffffff00;
      (**(code **)(lVar8 + 0x40))(plVar7,4200000000,uVar3,1);
      FUN_140368e70(local_448);
      return;
    }
    if (sVar1 != 3) {
      if (sVar1 != 4) {
        return;
      }
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar6 = (longlong *)FUN_140087650(uVar5);
      plVar6 = (longlong *)
               (**(code **)(*plVar6 + 0xa0))
                         (plVar6,*(undefined4 *)(param_1 + 0x420),
                          *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (plVar6 == (longlong *)0x0) {
        return;
      }
      FUN_140368e20(local_448);
      uVar3 = (**(code **)(*plVar6 + 0x38))(plVar6);
      cVar2 = FUN_140368ed0(local_448,4,uVar3,0);
      if (cVar2 != '\0') {
        (**(code **)(*plVar6 + 0x130))(plVar6,local_448);
      }
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar7 = (longlong *)FUN_140087650(uVar5);
      lVar8 = *plVar7;
      uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
      local_460 = 1;
      local_468 = local_468 & 0xffffff00;
      (**(code **)(lVar8 + 0x40))(plVar7,4200000000,uVar3,1);
      FUN_140368e70(local_448);
      return;
    }
  }
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    local_468 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))
                    (*(longlong **)(lVar8 + 0x90),
                     *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (lVar8 != 0) {
    FUN_1401789a0(lVar8);
  }
  return;
}

