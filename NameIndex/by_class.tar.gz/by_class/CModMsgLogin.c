// ==== CModMsgLogin::ctor_or_dtor  @140368570  [high:vtable-assign]  (orig: FUN_140368570)
CMsg * FUN_140368570(CMsg *param_1)

{
  *(undefined ***)param_1 = tq::CMsg::vftable;
  tq::CMsg::Init(param_1);
  *(undefined ***)param_1 = gs::CMsg::vftable;
  *(undefined ***)param_1 = CModMsgLogin::vftable;
  tq::CMsg::Init(param_1);
  *(CMsg **)(param_1 + 0x408) = param_1 + 8;
  return param_1;
}

// ==== CModMsgLogin::ctor_or_dtor  @1403685d0  [high:vtable-assign]  (orig: FUN_1403685d0)
void FUN_1403685d0(undefined8 *param_1)

{
  *param_1 = CModMsgLogin::vftable;
  *param_1 = gs::CMsg::vftable;
  *param_1 = tq::CMsg::vftable;
  return;
}

// ==== CModMsgLogin::vfunc_6  @140368650  [high:rtti-vtable]  (orig: FUN_140368650)
bool FUN_140368650(CMsg *param_1,char *param_2,ushort param_3)

{
  bool bVar1;
  
  bVar1 = tq::CMsg::Create(param_1,param_2,param_3);
  if (!bVar1) {
    return bVar1;
  }
  return *(short *)(param_1 + 10) == 0x3ea;
}

// ==== CModMsgLogin::ctor_or_dtor  @140368680  [high:vtable-assign]  (orig: FUN_140368680)
undefined8 * FUN_140368680(undefined8 *param_1,byte param_2)

{
  *param_1 = CModMsgLogin::vftable;
  *param_1 = gs::CMsg::vftable;
  *param_1 = tq::CMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

