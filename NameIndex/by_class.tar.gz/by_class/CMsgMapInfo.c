// ==== CMsgMapInfo::ctor_or_dtor  @140456380  [high:vtable-assign]  (orig: FUN_140456380)
undefined8 * FUN_140456380(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMapInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMapInfo::ctor_or_dtor  @1404563d0  [high:vtable-assign]  (orig: FUN_1404563d0)
void FUN_1404563d0(undefined8 *param_1)

{
  *param_1 = CMsgMapInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMapInfo::vfunc_1  @140456400  [high:rtti-vtable]  (orig: FUN_140456400)
ulonglong FUN_140456400(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x456);
}

// ==== CMsgMapInfo::vfunc_3  @140456430  [high:rtti-vtable]  (orig: FUN_140456430)
void FUN_140456430(void)

{
  return;
}

// ==== CMsgMapInfo::ctor_or_dtor  @140456440  [high:vtable-assign]  (orig: FUN_140456440)
undefined8 * FUN_140456440(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMapInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

