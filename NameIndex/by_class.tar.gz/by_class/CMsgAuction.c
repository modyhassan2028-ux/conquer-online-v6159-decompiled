// ==== CMsgAuction::helper_140227600  @140227600  [medium:callgraph-r1]  (orig: FUN_140227600)
ulonglong FUN_140227600(undefined8 param_1,undefined4 param_2,uint param_3,int param_4,uint *param_5
                       )

{
  uint uVar1;
  int iVar2;
  longlong *plVar3;
  ulonglong uVar4;
  longlong *plVar5;
  
  plVar5 = (longlong *)0x0;
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = plVar5;
  }
  uVar1 = (**(code **)(*plVar3 + 200))(plVar3,param_2);
  uVar4 = (ulonglong)uVar1 * 0xcccccccd;
  *param_5 = uVar1 / 5;
  if (param_4 == 1) {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = plVar5;
    }
    iVar2 = (**(code **)(*plVar3 + 0xe8))();
    if (iVar2 < 1) {
      uVar4 = 1;
    }
    else {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = plVar5;
      }
      uVar1 = (**(code **)(*plVar3 + 0xe8))(plVar3);
      uVar4 = (ulonglong)uVar1;
    }
    uVar4 = param_3 / uVar4;
    param_3 = (uint)uVar4;
  }
  return CONCAT71((int7)(uVar4 >> 8),param_3 < *param_5) & 0xffffffff;
}

// ==== CMsgAuction::helper_140227740  @140227740  [medium:callgraph-r1]  (orig: FUN_140227740)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_140227740(undefined8 param_1,longlong param_2,char *param_3)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pItem",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\auction\\auctionmgr.cpp"
                      );
    return 0;
  }
  if (param_3 == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","szDescript",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\auction\\auctionmgr.cpp"
                      );
    return 0;
  }
  cVar2 = FUN_140102870(param_2);
  if (cVar2 != '\0') {
    iVar3 = FUN_1400ffda0(param_2);
    if (1 < iVar3) {
      FUN_1400ffda0(param_2);
      uVar1 = FUN_140100430(param_2,0x65);
      _snprintf(param_3,0x20,"%s x %d",uVar1);
      param_3[0x1f] = '\0';
      return 1;
    }
  }
  uVar1 = FUN_140100430(param_2,0x65);
  _snprintf(param_3,0x20,"%s",uVar1);
  param_3[0x1f] = '\0';
  return 1;
}

// ==== CMsgAuction::helper_140228800  @140228800  [medium:callgraph-r1]  (orig: FUN_140228800)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8
FUN_140228800(longlong param_1,uint param_2,ulonglong param_3,undefined8 param_4,longlong *param_5,
             undefined4 *param_6)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  plVar6 = (longlong *)0x0;
  uVar2 = 0;
  if (param_5 != (longlong *)0x0) {
    uVar2 = (**(code **)(*param_5 + 8))(param_5);
    FUN_1400fda10(param_5,1,1);
  }
  tq::MyLogSave("gmlog/auction","send mail to user(%u), money: %d, emoney:%d, item:%u, type:%u",
                (ulonglong)param_2,param_3 & 0xffffffff);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0x180) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar5 = plVar6;
  }
  else {
    plVar5 = *(longlong **)(lVar3 + 0x180);
  }
  cVar1 = FUN_1400df9c0(plVar5,param_6);
  if (cVar1 == '\0') {
    if (param_6[0x54] != 0) {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar5 = plVar6;
      }
      (**(code **)(*plVar5 + 0x58))(plVar5,param_6[0x54],4);
    }
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    plVar5 = (longlong *)FUN_140087650(uVar4);
    lVar3 = (**(code **)(*plVar5 + 0x98))(plVar5,*param_6);
    if (lVar3 == 0) {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar5 = plVar6;
      }
      (**(code **)(*plVar5 + 0x58))(plVar5,uVar2,3);
    }
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgAuction::helper_140228c00  @140228c00  [medium:callgraph-r2]  (orig: FUN_140228c00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140228c00(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  undefined1 auStack_68 [32];
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined1 local_3c;
  undefined8 local_3b;
  undefined8 local_33;
  undefined1 local_2b;
  undefined1 local_2a;
  undefined1 local_29;
  undefined2 local_28;
  undefined2 local_26;
  undefined2 local_24;
  undefined4 local_20;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  local_44 = 0;
  local_40 = 0;
  local_3c = 0;
  local_2b = 0;
  local_2a = 0;
  local_29 = 0;
  local_28 = 0;
  local_26 = 0;
  local_24 = 0x8c;
  local_20 = 0;
  local_3b = 0;
  local_33 = 0;
  local_48 = param_2;
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  FUN_14008aba0(uVar1,0x1637a,&local_48);
  return;
}

// ==== CMsgAuction::helper_140228c90  @140228c90  [medium:callgraph-r1]  (orig: FUN_140228c90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140228c90(longlong param_1,longlong param_2,undefined2 param_3)

{
  undefined8 uVar1;
  undefined1 auStack_88 [32];
  undefined4 local_68;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined1 local_4c;
  undefined8 local_4b;
  undefined8 local_43;
  undefined1 local_3b;
  undefined1 local_3a;
  undefined1 local_39;
  undefined2 local_38;
  undefined2 local_36;
  undefined2 local_34;
  undefined4 local_30;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  if (param_2 == 0) {
    local_68 = 0x5a8;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_34 = 0x8c;
    local_58 = 0;
    local_54 = 0;
    local_50 = 0;
    local_4c = 0;
    local_3b = 0;
    local_3a = 0;
    local_39 = 0;
    local_38 = 0;
    local_36 = 0;
    local_30 = 0;
    local_4b = 0;
    local_43 = 0;
    local_58 = FUN_14041e8c0(param_2);
    local_30 = FUN_14041e920(param_2);
    local_38 = param_3;
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    FUN_14008aba0(uVar1,0x1637c,&local_58);
  }
  return;
}

// ==== CMsgAuction::helper_140228d70  @140228d70  [medium:callgraph-r1]  (orig: FUN_140228d70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140228d70(longlong param_1,longlong param_2,undefined2 param_3)

{
  undefined8 uVar1;
  undefined1 auStack_88 [32];
  undefined4 local_68;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined1 local_4c;
  undefined8 local_4b;
  undefined8 local_43;
  undefined1 local_3b;
  undefined1 local_3a;
  undefined1 local_39;
  undefined2 local_38;
  undefined2 local_36;
  undefined2 local_34;
  undefined4 local_30;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  if (param_2 == 0) {
    local_68 = 0x5b3;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_34 = 0x8c;
    local_58 = 0;
    local_54 = 0;
    local_50 = 0;
    local_4c = 0;
    local_3b = 0;
    local_3a = 0;
    local_39 = 0;
    local_38 = 0;
    local_36 = 0;
    local_30 = 0;
    local_4b = 0;
    local_43 = 0;
    local_58 = FUN_14041e8c0(param_2);
    local_50 = FUN_14041e710(param_2,6);
    local_38 = param_3;
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    FUN_14008aba0(uVar1,0x1637d,&local_58);
  }
  return;
}

// ==== CMsgAuction::helper_14022b360  @14022b360  [medium:callgraph-r1]  (orig: FUN_14022b360)
void FUN_14022b360(undefined8 param_1,longlong param_2,longlong *param_3,undefined4 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *local_58 [3];
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar3 = operator_new(8);
    plVar5 = (longlong *)0x0;
    local_58[0] = plVar5;
    if (plVar3 != (longlong *)0x0) {
      *plVar3 = (longlong)local_58;
      local_58[0] = plVar3;
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    FUN_140109210(param_3,local_58);
    plVar3 = local_40;
    if (0 < (int)((longlong)local_38 - (longlong)local_40 >> 3)) {
      plVar1 = local_58[0];
      if (local_38 < local_40) {
        _invalid_parameter_noinfo();
        plVar1 = local_58[0];
      }
      while( true ) {
        plVar4 = local_38;
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar3 == plVar4) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar4 = plVar5;
        }
        else {
          plVar4 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar4[4] <= plVar3) {
          _invalid_parameter_noinfo();
        }
        plVar4 = (longlong *)*plVar3;
        if (plVar4 != (longlong *)0x0) {
          (**(code **)(*plVar4 + 0x38))(plVar4,2,param_4);
          (**(code **)(*plVar4 + 0x38))(plVar4,9);
          (**(code **)(*plVar4 + 0x50))(plVar4);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar4 = plVar5;
        }
        else {
          plVar4 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar4[4] <= plVar3) {
          _invalid_parameter_noinfo();
        }
        plVar3 = plVar3 + 1;
      }
      if (param_2 != 0) {
        uVar2 = (**(code **)(*param_3 + 8))(param_3);
        FUN_14019a030(param_2,uVar2,0,0);
      }
    }
    if (local_40 != (longlong *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
  }
  return;
}

// ==== CMsgAuction::helper_14022bcf0  @14022bcf0  [medium:callgraph-r2]  (orig: FUN_14022bcf0)
longlong * FUN_14022bcf0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgAuction::helper_14022bdc0  @14022bdc0  [medium:callgraph-r2]  (orig: FUN_14022bdc0)
longlong * FUN_14022bdc0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgAuction::helper_14022be90  @14022be90  [medium:callgraph-r2]  (orig: FUN_14022be90)
undefined8 * FUN_14022be90(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  void *_Src;
  ulonglong uVar1;
  undefined8 uVar2;
  longlong lVar3;
  rsize_t _DstSize;
  
  _Src = (void *)((longlong)*(void **)(param_3 + 8) + 8);
  lVar3 = param_1[4] - (longlong)_Src >> 3;
  if (0 < lVar3) {
    _DstSize = lVar3 << 3;
    memmove_s(*(void **)(param_3 + 8),_DstSize,_Src,_DstSize);
  }
  param_1[4] = param_1[4] + -8;
  uVar1 = *(ulonglong *)(param_3 + 8);
  *param_2 = 0;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  uVar2 = *param_1;
  param_2[1] = uVar1;
  *param_2 = uVar2;
  return param_2;
}

// ==== CMsgAuction::helper_14022c020  @14022c020  [medium:callgraph-r3]  (orig: FUN_14022c020)
undefined8 * FUN_14022c020(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar4 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  uVar3 = (longlong)(param_2[4] - param_2[3]) >> 3;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar3 != 0) {
    if (0x1fffffffffffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_140227e10();
    }
    lVar2 = FUN_1402291c0(param_1 + 2,uVar3);
    param_1[3] = lVar2;
    param_1[4] = lVar2;
    param_1[5] = lVar2 + uVar3 * 8;
    uVar3 = param_2[4];
    if (uVar3 < (ulonglong)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_58 = (undefined4)*param_2;
    uStack_54 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_50 = (undefined4)uVar3;
    uStack_4c = (undefined4)(uVar3 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uVar3 = param_2[3];
    if ((ulonglong)param_2[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    local_48 = (undefined4)*param_2;
    uStack_44 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_40 = (undefined4)uVar3;
    uStack_3c = (undefined4)(uVar3 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uVar4 = FUN_14022ae30(param_1,&local_28,&local_38,param_1[3],uVar4);
    param_1[4] = uVar4;
  }
  return param_1;
}

// ==== CMsgAuction::helper_14022c3d0  @14022c3d0  [medium:callgraph-r3]  (orig: FUN_14022c3d0)
void FUN_14022c3d0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140227e10();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_1402291c0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14022aed0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14022aed0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140229cb0(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CMsgAuction::helper_14022dfc0  @14022dfc0  [medium:callgraph-r3]  (orig: FUN_14022dfc0)
undefined8 *
FUN_14022dfc0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x492492492492490 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14022cf90(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x50);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x51) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x51) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x50);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x50) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgAuction::helper_14022e6a0  @14022e6a0  [medium:callgraph-r2]  (orig: FUN_14022e6a0)
void FUN_14022e6a0(longlong param_1,undefined4 param_2,int param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58;
  longlong *local_48 [2];
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_res10[0] = param_2;
  FUN_14022bdc0(param_1 + 0x90,&local_68,local_res10,param_4,0xfffffffffffffffe);
  lVar6 = *(longlong *)(param_1 + 0xc0);
  lVar7 = 0;
  local_58 = *(longlong **)(param_1 + 0x90);
  plVar5 = (longlong *)CONCAT44(uStack_64,local_68);
  if ((plVar5 == (longlong *)0x0) || (plVar5 != local_58)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = CONCAT44(uStack_5c,uStack_60);
  if (lVar3 != lVar6) {
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar7;
    }
    else {
      lVar6 = *plVar5;
    }
    if (lVar3 == *(longlong *)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar5 = *(longlong **)(lVar3 + 0x38);
    if (*(longlong **)(lVar3 + 0x40) < plVar5) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(lVar3 + 0x20);
    while( true ) {
      plVar2 = *(longlong **)(lVar3 + 0x40);
      local_48[0] = (longlong *)0x0;
      if (plVar2 < *(longlong **)(lVar3 + 0x38)) {
        _invalid_parameter_noinfo();
      }
      local_48[0] = *(longlong **)(lVar3 + 0x20);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_48[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar5 == plVar2) {
        return;
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
        _invalid_parameter_noinfo();
      }
      if ((*plVar5 != 0) && (iVar4 = FUN_14041e8c0(), iVar4 == param_3)) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar5 + 1;
    }
    local_78 = SUB84(plVar1,0);
    uStack_74 = (undefined4)((ulonglong)plVar1 >> 0x20);
    uStack_70 = SUB84(plVar5,0);
    uStack_6c = (undefined4)((ulonglong)plVar5 >> 0x20);
    local_38 = local_78;
    uStack_34 = uStack_74;
    uStack_30 = uStack_70;
    uStack_2c = uStack_6c;
    FUN_14022be90(lVar3 + 0x20,local_48,&local_38);
    if ((*(longlong *)(lVar3 + 0x40) - *(longlong *)(lVar3 + 0x38) & 0xfffffffffffffff8U) == 0) {
      FUN_14022dbd0(param_1 + 0x90,&local_38,&local_68);
    }
  }
  return;
}

// ==== CMsgAuction::helper_14022e890  @14022e890  [medium:callgraph-r1]  (orig: FUN_14022e890)
void FUN_14022e890(longlong param_1,undefined4 param_2,int param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58;
  longlong *local_48 [2];
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_res10[0] = param_2;
  FUN_14022bdc0(param_1 + 0x50,&local_68,local_res10,param_4,0xfffffffffffffffe);
  lVar6 = *(longlong *)(param_1 + 0x80);
  lVar7 = 0;
  local_58 = *(longlong **)(param_1 + 0x50);
  plVar5 = (longlong *)CONCAT44(uStack_64,local_68);
  if ((plVar5 == (longlong *)0x0) || (plVar5 != local_58)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = CONCAT44(uStack_5c,uStack_60);
  if (lVar3 != lVar6) {
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar7;
    }
    else {
      lVar6 = *plVar5;
    }
    if (lVar3 == *(longlong *)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar5 = *(longlong **)(lVar3 + 0x38);
    if (*(longlong **)(lVar3 + 0x40) < plVar5) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(lVar3 + 0x20);
    while( true ) {
      plVar2 = *(longlong **)(lVar3 + 0x40);
      local_48[0] = (longlong *)0x0;
      if (plVar2 < *(longlong **)(lVar3 + 0x38)) {
        _invalid_parameter_noinfo();
      }
      local_48[0] = *(longlong **)(lVar3 + 0x20);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_48[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar5 == plVar2) {
        return;
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
        _invalid_parameter_noinfo();
      }
      if ((*plVar5 != 0) && (iVar4 = FUN_14041e8c0(), iVar4 == param_3)) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar7;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar5) {
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar5 + 1;
    }
    local_78 = SUB84(plVar1,0);
    uStack_74 = (undefined4)((ulonglong)plVar1 >> 0x20);
    uStack_70 = SUB84(plVar5,0);
    uStack_6c = (undefined4)((ulonglong)plVar5 >> 0x20);
    local_38 = local_78;
    uStack_34 = uStack_74;
    uStack_30 = uStack_70;
    uStack_2c = uStack_6c;
    FUN_14022be90(lVar3 + 0x20,local_48,&local_38);
    if ((*(longlong *)(lVar3 + 0x40) - *(longlong *)(lVar3 + 0x38) & 0xfffffffffffffff8U) == 0) {
      FUN_14022dbd0(param_1 + 0x50,&local_38,&local_68);
    }
  }
  return;
}

// ==== CMsgAuction::helper_14022f690  @14022f690  [medium:callgraph-r1]  (orig: FUN_14022f690)
void FUN_14022f690(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined4 local_res10 [2];
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  longlong *local_48 [2];
  undefined1 local_38 [16];
  
  local_res10[0] = param_2;
  FUN_14022bcf0(param_1 + 0x10,&local_58,local_res10,param_4,0xfffffffffffffffe);
  lVar1 = *(longlong *)(param_1 + 0x40);
  lVar5 = 0;
  local_48[0] = *(longlong **)(param_1 + 0x10);
  plVar2 = (longlong *)CONCAT44(uStack_54,local_58);
  if ((plVar2 == (longlong *)0x0) || (plVar2 != local_48[0])) {
    _invalid_parameter_noinfo();
  }
  lVar3 = CONCAT44(uStack_4c,uStack_50);
  if (lVar3 != lVar1) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar5 = *plVar2;
    }
    if (lVar3 == *(longlong *)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *(longlong *)(lVar3 + 0x20);
    if (lVar1 == 0) {
      FUN_14022b930(param_1 + 0x10,local_38,&local_58);
    }
    else {
      FUN_140228c00(param_1,param_2);
      uVar4 = FUN_14041e710(lVar1,10);
      FUN_14022e890(param_1,uVar4,param_2);
      uVar4 = FUN_14041e710(lVar1,2);
      FUN_14022e6a0(param_1,uVar4,param_2);
      FUN_14022b930(param_1 + 0x10,local_48,local_38);
      FUN_14041e870(lVar1);
      FUN_14041eef0(lVar1);
    }
  }
  return;
}

// ==== CMsgAuction::helper_14022f7e0  @14022f7e0  [medium:callgraph-r0]  (orig: FUN_14022f7e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_14022f7e0(undefined8 param_1,longlong *param_2,undefined4 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  char *pcVar8;
  longlong *plVar9;
  undefined8 uVar10;
  undefined1 auStack_378 [32];
  ulonglong local_358;
  int *local_350;
  ulonglong local_348;
  undefined8 local_340;
  undefined8 local_338;
  int local_328;
  char local_324 [60];
  uint local_2e8;
  undefined1 local_2e4 [256];
  undefined4 local_1e4;
  undefined4 local_1e0;
  undefined4 local_1dc;
  undefined4 local_1d8;
  undefined4 local_1d4;
  undefined1 local_1d0;
  undefined4 local_1c8;
  char local_1c4 [60];
  uint local_188;
  undefined1 local_184 [256];
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined1 local_70;
  undefined1 local_68;
  undefined8 local_67;
  undefined8 local_5f;
  undefined8 local_57;
  undefined4 local_4f;
  undefined2 local_4b;
  undefined1 local_49;
  ulonglong local_48;
  
  local_338 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_378;
  local_340 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_358 = CONCAT44(local_358._4_4_,0x1e0);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    uVar4 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
    if ((char)uVar4 != '\0') {
      plVar9 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_358 = CONCAT44(local_358._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar9 = (longlong *)0x0;
      }
      lVar5 = (**(code **)(*plVar9 + 0x60))(plVar9,param_3);
      uVar4 = 0;
      if (lVar5 != 0) {
        local_348 = lVar5;
        lVar6 = FUN_14022b140(param_1,param_3);
        uVar4 = 0;
        if (lVar6 != 0) {
          iVar1 = (**(code **)(*param_2 + 8))(param_2);
          uVar4 = FUN_14041e710(lVar6,2);
          if ((int)uVar4 == iVar1) {
            uVar2 = FUN_1400fda10(lVar5,1,1);
            (**(code **)(*param_2 + 8))(param_2);
            (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            local_350 = (int *)CONCAT44(local_350._4_4_,uVar2);
            local_358 = CONCAT44(local_358._4_4_,param_3);
            tq::MyLogSave("gmlog/auction","user(%s,%u) cancel sell item(%u, type:%u)");
            uVar10 = local_340;
            uVar4 = local_348;
            local_68 = 0;
            local_67 = 0;
            local_5f = 0;
            local_57 = 0;
            local_4f = 0;
            local_4b = 0;
            local_49 = 0;
            FUN_140227740(local_340,local_348,&local_68);
            iVar1 = FUN_14041e710(lVar6);
            local_348 = CONCAT44(local_348._4_4_,iVar1);
            uVar2 = 0;
            if (iVar1 != 0) {
              local_328 = 0;
              local_324[0] = '\0';
              local_324[1] = '\0';
              local_324[2] = '\0';
              local_324[3] = '\0';
              local_324[4] = '\0';
              local_324[5] = '\0';
              local_324[6] = '\0';
              local_324[7] = '\0';
              local_324[8] = '\0';
              local_324[9] = '\0';
              local_324[10] = '\0';
              local_324[0xb] = '\0';
              local_324[0xc] = '\0';
              local_324[0xd] = '\0';
              local_324[0xe] = '\0';
              local_324[0xf] = '\0';
              local_324[0x10] = '\0';
              local_324[0x11] = '\0';
              local_324[0x12] = '\0';
              local_324[0x13] = '\0';
              local_324[0x14] = '\0';
              local_324[0x15] = '\0';
              local_324[0x16] = '\0';
              local_324[0x17] = '\0';
              local_324[0x18] = '\0';
              local_324[0x19] = '\0';
              local_324[0x1a] = '\0';
              local_324[0x1b] = '\0';
              local_324[0x1c] = '\0';
              local_324[0x1d] = '\0';
              local_324[0x1e] = '\0';
              local_324[0x1f] = '\0';
              local_324[0x20] = '\0';
              local_324[0x21] = '\0';
              local_324[0x22] = '\0';
              local_324[0x23] = '\0';
              local_324[0x24] = '\0';
              local_324[0x25] = '\0';
              local_324[0x26] = '\0';
              local_324[0x27] = '\0';
              local_324[0x28] = '\0';
              local_324[0x29] = '\0';
              local_324[0x2a] = '\0';
              local_324[0x2b] = '\0';
              local_324[0x2c] = '\0';
              local_324[0x2d] = '\0';
              local_324[0x2e] = '\0';
              local_324[0x2f] = '\0';
              local_324[0x30] = '\0';
              local_324[0x31] = '\0';
              local_324[0x32] = '\0';
              local_324[0x33] = '\0';
              local_324[0x34] = '\0';
              local_324[0x35] = '\0';
              local_324[0x36] = '\0';
              local_324[0x37] = '\0';
              local_324[0x38] = '\0';
              local_324[0x39] = '\0';
              local_324[0x3a] = '\0';
              local_324[0x3b] = '\0';
              local_2e8 = 0;
              memset(local_2e4,0,0xff);
              local_1e4 = 0;
              local_1e0 = 0;
              local_1dc = 0;
              local_1d8 = 0;
              local_1d4 = 0x1e;
              local_1d0 = 0;
              uVar3 = 0;
              local_328 = iVar1;
              iVar1 = FUN_14041e710(lVar6,5);
              if (iVar1 == 2) {
                uVar3 = FUN_14041e710(lVar6,6);
                local_1e0 = uVar3;
              }
              else {
                uVar2 = FUN_14041e710(lVar6,6);
                local_1e4 = uVar2;
              }
              pIVar7 = theInstance();
              pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_BID_SYSTEM_NAME");
              strncpy(local_324,pcVar8,0x10);
              pIVar7 = theInstance();
              pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)
                                         (pIVar7,"STR_BID_CANCEL_MAIL_TITLE");
              _snprintf(local_324 + 0x20,0x20,pcVar8);
              uVar10 = local_340;
              local_2e8 = local_2e8 & 0xffffff;
              local_350 = &local_328;
              local_358 = 0;
              FUN_140228800(local_340,local_348 & 0xffffffff,uVar2,uVar3);
            }
            FUN_14022f690(uVar10,param_3);
            local_358 = local_358 & 0xffffffff00000000;
            FUN_14022b360(uVar10,param_2,uVar4,0);
            local_1c8 = 0;
            local_1c4[0] = '\0';
            local_1c4[1] = '\0';
            local_1c4[2] = '\0';
            local_1c4[3] = '\0';
            local_1c4[4] = '\0';
            local_1c4[5] = '\0';
            local_1c4[6] = '\0';
            local_1c4[7] = '\0';
            local_1c4[8] = '\0';
            local_1c4[9] = '\0';
            local_1c4[10] = '\0';
            local_1c4[0xb] = '\0';
            local_1c4[0xc] = '\0';
            local_1c4[0xd] = '\0';
            local_1c4[0xe] = '\0';
            local_1c4[0xf] = '\0';
            local_1c4[0x10] = '\0';
            local_1c4[0x11] = '\0';
            local_1c4[0x12] = '\0';
            local_1c4[0x13] = '\0';
            local_1c4[0x14] = '\0';
            local_1c4[0x15] = '\0';
            local_1c4[0x16] = '\0';
            local_1c4[0x17] = '\0';
            local_1c4[0x18] = '\0';
            local_1c4[0x19] = '\0';
            local_1c4[0x1a] = '\0';
            local_1c4[0x1b] = '\0';
            local_1c4[0x1c] = '\0';
            local_1c4[0x1d] = '\0';
            local_1c4[0x1e] = '\0';
            local_1c4[0x1f] = '\0';
            local_1c4[0x20] = '\0';
            local_1c4[0x21] = '\0';
            local_1c4[0x22] = '\0';
            local_1c4[0x23] = '\0';
            local_1c4[0x24] = '\0';
            local_1c4[0x25] = '\0';
            local_1c4[0x26] = '\0';
            local_1c4[0x27] = '\0';
            local_1c4[0x28] = '\0';
            local_1c4[0x29] = '\0';
            local_1c4[0x2a] = '\0';
            local_1c4[0x2b] = '\0';
            local_1c4[0x2c] = '\0';
            local_1c4[0x2d] = '\0';
            local_1c4[0x2e] = '\0';
            local_1c4[0x2f] = '\0';
            local_1c4[0x30] = '\0';
            local_1c4[0x31] = '\0';
            local_1c4[0x32] = '\0';
            local_1c4[0x33] = '\0';
            local_1c4[0x34] = '\0';
            local_1c4[0x35] = '\0';
            local_1c4[0x36] = '\0';
            local_1c4[0x37] = '\0';
            local_1c4[0x38] = '\0';
            local_1c4[0x39] = '\0';
            local_1c4[0x3a] = '\0';
            local_1c4[0x3b] = '\0';
            local_188 = 0;
            memset(local_184,0,0xff);
            local_84 = 0;
            local_80 = 0;
            local_7c = 0;
            local_78 = 0;
            local_74 = 0x1e;
            local_70 = 0;
            local_1c8 = (**(code **)(*param_2 + 8))(param_2);
            local_78 = param_3;
            pIVar7 = theInstance();
            pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_BID_SYSTEM_NAME");
            strncpy(local_1c4,pcVar8,0x10);
            pIVar7 = theInstance();
            pcVar8 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_BID_CANCEL_MAIL_TITLE");
            _snprintf(local_1c4 + 0x20,0x20,pcVar8);
            local_188 = local_188 & 0xffffff;
            uVar2 = (**(code **)(*param_2 + 8))(param_2);
            local_350 = &local_1c8;
            local_358 = uVar4;
            uVar4 = FUN_140228800(uVar10,uVar2,0,0);
          }
          else {
            uVar4 = uVar4 & 0xffffffffffffff00;
          }
        }
      }
    }
  }
  return uVar4;
}

// ==== CMsgAuction::helper_14022fce0  @14022fce0  [medium:callgraph-r1]  (orig: FUN_14022fce0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14022fce0(longlong param_1,longlong param_2)

{
  ulonglong uVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  ulonglong uVar11;
  IStringManager *pIVar12;
  char *pcVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong lVar16;
  longlong *plVar17;
  longlong lVar18;
  undefined1 auStack_818 [32];
  longlong *local_7f8;
  int *local_7f0;
  undefined8 local_7e8;
  char *local_7e0;
  undefined4 local_7d8;
  char *local_7d0;
  uint local_7c8;
  char *local_7c0;
  int local_7b8;
  char *local_7b0;
  int local_7a8;
  undefined4 local_7a0;
  undefined4 local_798;
  undefined4 local_790;
  undefined4 local_788;
  undefined4 local_780;
  undefined4 local_778;
  int local_768;
  int local_764;
  ulonglong local_760;
  int local_758;
  undefined4 local_754;
  longlong local_750;
  int local_748;
  undefined4 local_744;
  undefined4 local_740;
  undefined4 local_73c;
  undefined4 local_738;
  undefined4 local_734;
  int local_730;
  longlong *local_728;
  undefined4 local_720;
  undefined4 local_71c;
  undefined8 local_718;
  undefined4 local_708;
  char local_704 [60];
  uint local_6c8;
  char local_6c4 [254];
  undefined1 local_5c6;
  int local_5c4;
  int local_5c0;
  undefined4 local_5bc;
  undefined4 local_5b8;
  undefined4 local_5b4;
  undefined1 local_5b0;
  undefined4 local_5a8;
  char local_5a4 [60];
  uint local_568;
  char local_564 [254];
  undefined1 local_466;
  int local_464;
  undefined4 local_460;
  undefined4 local_45c;
  undefined4 local_458;
  undefined4 local_454;
  undefined1 local_450;
  int local_448;
  char local_444 [60];
  uint local_408;
  char local_404 [254];
  undefined1 local_306;
  undefined4 local_304;
  undefined4 local_300;
  undefined4 local_2fc;
  undefined4 local_2f8;
  undefined4 local_2f4;
  undefined1 local_2f0;
  undefined1 local_2e8;
  undefined8 local_2e7;
  undefined8 local_2df;
  undefined8 local_2d7;
  undefined4 local_2cf;
  undefined2 local_2cb;
  undefined1 local_2c9;
  char local_2c8 [399];
  undefined1 local_139;
  char local_138;
  undefined1 local_137 [254];
  undefined1 local_39;
  ulonglong local_38;
  
  local_718 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_818;
  local_760 = param_2;
  local_750 = param_1;
  if (param_2 == 0) {
    local_7f8 = (longlong *)CONCAT44(local_7f8._4_4_,0x455);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_14041e8c0(param_2);
    plVar17 = DAT_140975b60;
    local_754 = uVar3;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_7f8 = (longlong *)CONCAT44(local_7f8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar17 = (longlong *)0x0;
    }
    local_728 = (longlong *)(**(code **)(*plVar17 + 0x60))(plVar17,uVar3);
    if (local_728 == (longlong *)0x0) {
      log_InlineLogERROR("CAuctionMgr::OnBidSuccessfully, can not found auction item: %u");
    }
    else {
      local_758 = FUN_14041e710(param_2,10);
      if (local_758 == 0) {
        log_InlineLogERROR("CAuctionMgr::OnBidSuccessfully, none bidder");
      }
      else {
        local_73c = FUN_14041e710(param_2,2);
        plVar17 = local_728;
        local_744 = FUN_1400fda10(local_728,0xc,1);
        local_764 = FUN_140100410(plVar17);
        local_768 = FUN_140100340(plVar17);
        local_734 = FUN_1401003f0(plVar17);
        local_71c = FUN_1401003d0(plVar17);
        local_720 = FUN_1400fda10(plVar17,0x13,1);
        local_740 = FUN_1400ffda0(plVar17);
        local_730 = FUN_1400fda10(plVar17,0xf,1);
        local_738 = FUN_1400fda10(plVar17,0xe,1);
        local_748 = FUN_1400fda10(plVar17,0x10,1);
        uVar3 = FUN_1400fda10(plVar17,5,1);
        uVar4 = FUN_1400fda10(plVar17,4,1);
        uVar5 = FUN_1400fda10(plVar17,9,1);
        uVar6 = FUN_1400fda10(plVar17,8,1);
        uVar7 = FUN_1400fda10(plVar17,1,1);
        uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
        uVar11 = FUN_140100430(plVar17,0x65);
        FUN_14041e6b0(local_760,0xb);
        local_778 = local_764;
        local_780 = local_768;
        local_788 = local_734;
        local_790 = local_71c;
        local_798 = local_720;
        local_7a0 = local_740;
        local_7a8 = local_730;
        local_7b0 = (char *)CONCAT44(local_7b0._4_4_,local_738);
        local_7b8 = local_748;
        local_7c0 = (char *)CONCAT44(local_7c0._4_4_,uVar3);
        local_7d0 = (char *)CONCAT44(local_7d0._4_4_,local_744);
        local_7e0 = (char *)CONCAT44(local_7e0._4_4_,uVar6);
        local_7f0 = (int *)CONCAT44(local_7f0._4_4_,uVar8);
        local_7f8 = (longlong *)uVar11;
        local_7d8 = uVar5;
        local_7c8 = uVar4;
        local_7e8._0_4_ = uVar7;
        tq::MyLogSave("gmlog/auction",
                      "user(%s,%u) bid item(%s,%u,type:%d)gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%d], dec_dmg[%d] add_life[%d] accumulate[%d]specialflag[%d] quenchtype[%d] quenchlev[%d] forgetype[%d] forgelev[%d] successfully"
                     );
        local_2c8[0x50] = 0;
        local_2c8[0x51] = '\0';
        local_2c8[0x52] = '\0';
        local_2c8[0x53] = '\0';
        local_2c8[0x54] = '\0';
        local_2c8[0x55] = '\0';
        local_2c8[0x56] = '\0';
        local_2c8[0x57] = '\0';
        local_2c8[0x58] = '\0';
        local_2c8[0x59] = '\0';
        local_2c8[0x5a] = '\0';
        local_2c8[0x5b] = '\0';
        local_2c8[0x5c] = '\0';
        local_2c8[0x5d] = '\0';
        local_2c8[0x5e] = '\0';
        local_2c8[0x5f] = '\0';
        local_2c8[0x60] = '\0';
        local_2c8[0x61] = '\0';
        local_2c8[0x62] = '\0';
        local_2c8[99] = '\0';
        local_2c8[100] = '\0';
        local_2c8[0x65] = '\0';
        local_2c8[0x66] = '\0';
        local_2c8[0x67] = '\0';
        local_2c8[0x68] = '\0';
        local_2c8[0x69] = '\0';
        local_2c8[0x6a] = '\0';
        local_2c8[0x6b] = '\0';
        local_2c8[0x6c] = '\0';
        local_2c8[0x6d] = '\0';
        local_2c8[0x6e] = '\0';
        local_2c8[0x6f] = 0;
        pIVar12 = theInstance();
        pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_MONEY_NAME");
        strncpy(local_2c8 + 0x50,pcVar13,0x20);
        uVar11 = local_760;
        iVar9 = FUN_14041e710(local_760,5);
        if (iVar9 == 2) {
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_EMONEY_NAME");
          strncpy(local_2c8 + 0x50,pcVar13,0x20);
        }
        plVar17 = local_728;
        lVar18 = local_750;
        local_2e8 = 0;
        local_2e7 = 0;
        local_2df = 0;
        local_2d7 = 0;
        local_2cf = 0;
        local_2cb = 0;
        local_2c9 = 0;
        FUN_140227740(local_750,local_728,&local_2e8);
        uVar14 = FUN_140008520(*(undefined4 *)(lVar18 + 8));
        plVar15 = (longlong *)FUN_140087650(uVar14);
        lVar16 = (**(code **)(*plVar15 + 0x98))(plVar15);
        if (lVar16 != 0) {
          local_2c8[0x90] = 0;
          memset(local_2c8 + 0x91,0,0xff);
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_SUCCESSFULLY");
          _snprintf(local_2c8 + 0x90,0x100,pcVar13);
          local_139 = 0;
          (**(code **)(*(longlong *)(lVar16 + 0x10) + 0x358))
                    ((longlong *)(lVar16 + 0x10),local_2c8 + 0x90);
        }
        uVar14 = FUN_140008520(*(undefined4 *)(lVar18 + 8));
        plVar15 = (longlong *)FUN_140087650(uVar14);
        lVar16 = (**(code **)(*plVar15 + 0x98))(plVar15);
        if (lVar16 != 0) {
          local_138 = '\0';
          memset(local_137,0,0xff);
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_SELL_OK");
          _snprintf(&local_138,0x100,pcVar13);
          local_39 = 0;
          (**(code **)(*(longlong *)(lVar16 + 0x10) + 0x358))
                    ((longlong *)(lVar16 + 0x10),&local_138);
        }
        uVar4 = FUN_14041e710(uVar11,6);
        local_768 = FUN_14041e710(uVar11,8);
        uVar1 = (longlong)((longlong)*(int *)(lVar18 + 0xd0) * (ulonglong)uVar4) / 10000;
        uVar7 = (uint)uVar1;
        iVar9 = uVar4 - uVar7;
        if (uVar4 < uVar7) {
          iVar9 = 0;
        }
        local_764 = iVar9;
        local_760 = uVar1;
        iVar10 = FUN_14041e710(uVar11,5);
        if (iVar10 == 1) {
          local_2c8[0x10] = 0;
          local_2c8[0x11] = '\0';
          local_2c8[0x12] = '\0';
          local_2c8[0x13] = '\0';
          local_2c8[0x14] = '\0';
          local_2c8[0x15] = '\0';
          local_2c8[0x16] = '\0';
          local_2c8[0x17] = '\0';
          local_2c8[0x18] = '\0';
          local_2c8[0x19] = '\0';
          local_2c8[0x1a] = '\0';
          local_2c8[0x1b] = '\0';
          local_2c8[0x1c] = '\0';
          local_2c8[0x1d] = '\0';
          local_2c8[0x1e] = '\0';
          local_2c8[0x1f] = '\0';
          local_2c8[0x20] = '\0';
          local_2c8[0x21] = '\0';
          local_2c8[0x22] = '\0';
          local_2c8[0x23] = '\0';
          local_2c8[0x24] = '\0';
          local_2c8[0x25] = '\0';
          local_2c8[0x26] = '\0';
          local_2c8[0x27] = '\0';
          local_2c8[0x28] = '\0';
          local_2c8[0x29] = '\0';
          local_2c8[0x2a] = '\0';
          local_2c8[0x2b] = '\0';
          local_2c8[0x2c] = '\0';
          local_2c8[0x2d] = '\0';
          local_2c8[0x2e] = '\0';
          local_2c8[0x2f] = 0;
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_MONEY_NAME");
          strncpy(local_2c8 + 0x10,pcVar13,0x20);
          local_5a8 = 0;
          local_5a4[0] = '\0';
          local_5a4[1] = '\0';
          local_5a4[2] = '\0';
          local_5a4[3] = '\0';
          local_5a4[4] = '\0';
          local_5a4[5] = '\0';
          local_5a4[6] = '\0';
          local_5a4[7] = '\0';
          local_5a4[8] = '\0';
          local_5a4[9] = '\0';
          local_5a4[10] = '\0';
          local_5a4[0xb] = '\0';
          local_5a4[0xc] = '\0';
          local_5a4[0xd] = '\0';
          local_5a4[0xe] = '\0';
          local_5a4[0xf] = '\0';
          local_5a4[0x10] = '\0';
          local_5a4[0x11] = '\0';
          local_5a4[0x12] = '\0';
          local_5a4[0x13] = '\0';
          local_5a4[0x14] = '\0';
          local_5a4[0x15] = '\0';
          local_5a4[0x16] = '\0';
          local_5a4[0x17] = '\0';
          local_5a4[0x18] = '\0';
          local_5a4[0x19] = '\0';
          local_5a4[0x1a] = '\0';
          local_5a4[0x1b] = '\0';
          local_5a4[0x1c] = '\0';
          local_5a4[0x1d] = '\0';
          local_5a4[0x1e] = '\0';
          local_5a4[0x1f] = '\0';
          local_5a4[0x20] = '\0';
          local_5a4[0x21] = '\0';
          local_5a4[0x22] = '\0';
          local_5a4[0x23] = '\0';
          local_5a4[0x24] = '\0';
          local_5a4[0x25] = '\0';
          local_5a4[0x26] = '\0';
          local_5a4[0x27] = '\0';
          local_5a4[0x28] = '\0';
          local_5a4[0x29] = '\0';
          local_5a4[0x2a] = '\0';
          local_5a4[0x2b] = '\0';
          local_5a4[0x2c] = '\0';
          local_5a4[0x2d] = '\0';
          local_5a4[0x2e] = '\0';
          local_5a4[0x2f] = '\0';
          local_5a4[0x30] = '\0';
          local_5a4[0x31] = '\0';
          local_5a4[0x32] = '\0';
          local_5a4[0x33] = '\0';
          local_5a4[0x34] = '\0';
          local_5a4[0x35] = '\0';
          local_5a4[0x36] = '\0';
          local_5a4[0x37] = '\0';
          local_5a4[0x38] = '\0';
          local_5a4[0x39] = '\0';
          local_5a4[0x3a] = '\0';
          local_5a4[0x3b] = '\0';
          local_568 = 0;
          memset(local_564,0,0xff);
          local_464 = 0;
          local_460 = 0;
          local_45c = 0;
          local_458 = 0;
          local_454 = 0x1e;
          local_450 = 0;
          local_5a8 = FUN_14041e710(uVar11,2);
          iVar9 = iVar9 + local_768;
          local_464 = iVar9;
          uVar3 = FUN_1400fda10(plVar17,1,1);
          (**(code **)(*plVar17 + 8))(plVar17);
          FUN_140100430(plVar17,0x65);
          local_7e8._0_4_ = (uint)local_760;
          local_7f0 = (int *)CONCAT44(local_7f0._4_4_,uVar4);
          local_7f8 = (longlong *)CONCAT44(local_7f8._4_4_,uVar3);
          tq::MyLogSave("gmlog/auction",
                        "Auctin item(%s, %u, type:%u), money price:%u, money tax fee: %u, ");
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_SYSTEM_NAME");
          strncpy(local_5a4,pcVar13,0x10);
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                      (pIVar12,"STR_BID_SELL_SUCCESSFULLY_MAIL_TITLE");
          _snprintf(local_5a4 + 0x20,0x20,pcVar13);
          local_568 = local_568 & 0xffffff;
          pIVar12 = theInstance();
          uVar3 = FUN_14041e710(uVar11,8);
          uVar4 = FUN_14041e710(uVar11,6);
          uVar14 = FUN_14041e6b0(uVar11,0xb);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                      (pIVar12,"STR_BID_SELL_SUCCESSFULLY_MAIL_CONTENT");
          local_7a8 = local_768;
          local_7b0 = local_2c8 + 0x10;
          local_7b8 = local_764;
          local_7c0 = local_2c8 + 0x10;
          local_7c8 = (uint)local_760;
          local_7d0 = local_2c8 + 0x10;
          local_7e0 = local_2c8 + 0x10;
          local_7f0 = (int *)(local_2c8 + 0x10);
          local_7f8 = (longlong *)uVar14;
          local_7d8 = uVar3;
          local_7e8._0_4_ = uVar4;
          _snprintf(local_564,0xff,pcVar13);
          lVar18 = local_750;
          local_466 = 0;
          local_7f0 = &local_5a8;
          local_7f8 = (longlong *)0x0;
          FUN_140228800(local_750,local_5a8,iVar9,0);
        }
        else if (iVar10 == 2) {
          local_2c8[0x70] = 0;
          local_2c8[0x71] = '\0';
          local_2c8[0x72] = '\0';
          local_2c8[0x73] = '\0';
          local_2c8[0x74] = '\0';
          local_2c8[0x75] = '\0';
          local_2c8[0x76] = '\0';
          local_2c8[0x77] = '\0';
          local_2c8[0x78] = '\0';
          local_2c8[0x79] = '\0';
          local_2c8[0x7a] = '\0';
          local_2c8[0x7b] = '\0';
          local_2c8[0x7c] = '\0';
          local_2c8[0x7d] = '\0';
          local_2c8[0x7e] = '\0';
          local_2c8[0x7f] = '\0';
          local_2c8[0x80] = '\0';
          local_2c8[0x81] = '\0';
          local_2c8[0x82] = '\0';
          local_2c8[0x83] = '\0';
          local_2c8[0x84] = '\0';
          local_2c8[0x85] = '\0';
          local_2c8[0x86] = '\0';
          local_2c8[0x87] = '\0';
          local_2c8[0x88] = '\0';
          local_2c8[0x89] = '\0';
          local_2c8[0x8a] = '\0';
          local_2c8[0x8b] = '\0';
          local_2c8[0x8c] = '\0';
          local_2c8[0x8d] = '\0';
          local_2c8[0x8e] = '\0';
          local_2c8[0x8f] = 0;
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_MONEY_NAME");
          strncpy(local_2c8 + 0x70,pcVar13,0x20);
          local_2c8[0x30] = 0;
          local_2c8[0x31] = '\0';
          local_2c8[0x32] = '\0';
          local_2c8[0x33] = '\0';
          local_2c8[0x34] = '\0';
          local_2c8[0x35] = '\0';
          local_2c8[0x36] = '\0';
          local_2c8[0x37] = '\0';
          local_2c8[0x38] = '\0';
          local_2c8[0x39] = '\0';
          local_2c8[0x3a] = '\0';
          local_2c8[0x3b] = '\0';
          local_2c8[0x3c] = '\0';
          local_2c8[0x3d] = '\0';
          local_2c8[0x3e] = '\0';
          local_2c8[0x3f] = '\0';
          local_2c8[0x40] = '\0';
          local_2c8[0x41] = '\0';
          local_2c8[0x42] = '\0';
          local_2c8[0x43] = '\0';
          local_2c8[0x44] = '\0';
          local_2c8[0x45] = '\0';
          local_2c8[0x46] = '\0';
          local_2c8[0x47] = '\0';
          local_2c8[0x48] = '\0';
          local_2c8[0x49] = '\0';
          local_2c8[0x4a] = '\0';
          local_2c8[0x4b] = '\0';
          local_2c8[0x4c] = '\0';
          local_2c8[0x4d] = '\0';
          local_2c8[0x4e] = '\0';
          local_2c8[0x4f] = 0;
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_EMONEY_NAME");
          strncpy(local_2c8 + 0x30,pcVar13,0x20);
          local_708 = 0;
          local_704[0] = '\0';
          local_704[1] = '\0';
          local_704[2] = '\0';
          local_704[3] = '\0';
          local_704[4] = '\0';
          local_704[5] = '\0';
          local_704[6] = '\0';
          local_704[7] = '\0';
          local_704[8] = '\0';
          local_704[9] = '\0';
          local_704[10] = '\0';
          local_704[0xb] = '\0';
          local_704[0xc] = '\0';
          local_704[0xd] = '\0';
          local_704[0xe] = '\0';
          local_704[0xf] = '\0';
          local_704[0x10] = '\0';
          local_704[0x11] = '\0';
          local_704[0x12] = '\0';
          local_704[0x13] = '\0';
          local_704[0x14] = '\0';
          local_704[0x15] = '\0';
          local_704[0x16] = '\0';
          local_704[0x17] = '\0';
          local_704[0x18] = '\0';
          local_704[0x19] = '\0';
          local_704[0x1a] = '\0';
          local_704[0x1b] = '\0';
          local_704[0x1c] = '\0';
          local_704[0x1d] = '\0';
          local_704[0x1e] = '\0';
          local_704[0x1f] = '\0';
          local_704[0x20] = '\0';
          local_704[0x21] = '\0';
          local_704[0x22] = '\0';
          local_704[0x23] = '\0';
          local_704[0x24] = '\0';
          local_704[0x25] = '\0';
          local_704[0x26] = '\0';
          local_704[0x27] = '\0';
          local_704[0x28] = '\0';
          local_704[0x29] = '\0';
          local_704[0x2a] = '\0';
          local_704[0x2b] = '\0';
          local_704[0x2c] = '\0';
          local_704[0x2d] = '\0';
          local_704[0x2e] = '\0';
          local_704[0x2f] = '\0';
          local_704[0x30] = '\0';
          local_704[0x31] = '\0';
          local_704[0x32] = '\0';
          local_704[0x33] = '\0';
          local_704[0x34] = '\0';
          local_704[0x35] = '\0';
          local_704[0x36] = '\0';
          local_704[0x37] = '\0';
          local_704[0x38] = '\0';
          local_704[0x39] = '\0';
          local_704[0x3a] = '\0';
          local_704[0x3b] = '\0';
          local_6c8 = 0;
          memset(local_6c4,0,0xff);
          local_5c4 = 0;
          local_5c0 = 0;
          local_5bc = 0;
          local_5b8 = 0;
          local_5b4 = 0x1e;
          local_5b0 = 0;
          local_708 = FUN_14041e710(uVar11,2);
          local_5c4 = local_768;
          local_5c0 = iVar9;
          uVar14 = FUN_140008520(*(undefined4 *)(lVar18 + 8));
          plVar15 = (longlong *)FUN_140087650(uVar14);
          local_760 = (**(code **)(*plVar15 + 0x98))(plVar15,local_708);
          uVar3 = 0;
          if (local_760 != 0) {
            uVar3 = *(undefined4 *)(local_760 + 0xfa4);
          }
          local_7e8 = InstanceGet();
          local_7f0 = (int *)((ulonglong)local_7f0 & 0xffffffff00000000);
          local_7f8._0_4_ = uVar3;
          FUN_1401667d0(0x30,local_708,0,uVar1 & 0xffffffff);
          uVar3 = FUN_1400fda10(plVar17,1,1);
          (**(code **)(*plVar17 + 8))(plVar17);
          FUN_140100430(plVar17,0x65);
          local_7f0 = (int *)CONCAT44(local_7f0._4_4_,uVar4);
          local_7f8 = (longlong *)CONCAT44(local_7f8._4_4_,uVar3);
          local_7e8._0_4_ = uVar7;
          tq::MyLogSave("gmlog/auction",
                        "Auctin item(%s, %u, type:%u), emoney price:%u, emoney tax fee: %u, ");
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_SYSTEM_NAME");
          strncpy(local_704,pcVar13,0x10);
          pIVar12 = theInstance();
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                      (pIVar12,"STR_BID_SELL_SUCCESSFULLY_MAIL_TITLE");
          _snprintf(local_704 + 0x20,0x20,pcVar13);
          local_6c8 = local_6c8 & 0xffffff;
          pIVar12 = theInstance();
          uVar3 = FUN_14041e710(uVar11,8);
          uVar4 = FUN_14041e710(uVar11,6);
          uVar14 = FUN_14041e6b0(uVar11,0xb);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                      (pIVar12,"STR_BID_SELL_SUCCESSFULLY_MAIL_CONTENT");
          local_7a8 = local_768;
          local_7b0 = local_2c8 + 0x70;
          local_7b8 = local_764;
          local_7c0 = local_2c8 + 0x30;
          local_7d0 = local_2c8 + 0x30;
          local_7e0 = local_2c8 + 0x70;
          local_7f0 = (int *)(local_2c8 + 0x30);
          local_7f8 = (longlong *)uVar14;
          local_7d8 = uVar3;
          local_7c8 = uVar7;
          local_7e8._0_4_ = uVar4;
          _snprintf(local_6c4,0xff,pcVar13);
          local_5c6 = 0;
          if (uVar7 != 0) {
            uVar3 = 0;
            if (local_760 != 0) {
              uVar3 = *(undefined4 *)(local_760 + 0xf10);
            }
            FUN_14041e6b0(uVar11,3);
            FUN_14041e710(uVar11,2);
            local_7f0 = (int *)CONCAT44(local_7f0._4_4_,uVar7);
            local_7f8 = (longlong *)CONCAT44(local_7f8._4_4_,uVar3);
            local_7e8._0_4_ = uVar7;
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t700\t709\t%d\t%d\t1\t");
          }
          lVar18 = local_750;
          local_7f0 = &local_708;
          local_7f8 = (longlong *)0x0;
          FUN_140228800(local_750,local_708,local_768,local_764);
        }
        else {
          log_InlineLogERROR(&DAT_14072f758);
        }
        uVar5 = FUN_14041e710(uVar11,6);
        local_2c8[0] = '\0';
        local_2c8[1] = '\0';
        local_2c8[2] = '\0';
        local_2c8[3] = '\0';
        local_2c8[4] = '\0';
        local_2c8[5] = '\0';
        local_2c8[6] = '\0';
        local_2c8[7] = '\0';
        local_2c8[8] = '\0';
        local_2c8[9] = '\0';
        local_2c8[10] = '\0';
        local_2c8[0xb] = '\0';
        local_2c8[0xc] = '\0';
        local_2c8[0xd] = '\0';
        local_2c8[0xe] = '\0';
        local_2c8[0xf] = 0;
        FUN_14041e6b0(uVar11,3);
        _snprintf(local_2c8,0xf,"%s");
        uVar3 = local_754;
        local_2c8[0xf] = 0;
        FUN_14022f690(lVar18);
        plVar17 = local_728;
        local_7f8 = (longlong *)((ulonglong)local_7f8 & 0xffffffff00000000);
        FUN_14022b360(lVar18,0,local_728,0);
        local_448 = 0;
        local_444[0] = '\0';
        local_444[1] = '\0';
        local_444[2] = '\0';
        local_444[3] = '\0';
        local_444[4] = '\0';
        local_444[5] = '\0';
        local_444[6] = '\0';
        local_444[7] = '\0';
        local_444[8] = '\0';
        local_444[9] = '\0';
        local_444[10] = '\0';
        local_444[0xb] = '\0';
        local_444[0xc] = '\0';
        local_444[0xd] = '\0';
        local_444[0xe] = '\0';
        local_444[0xf] = '\0';
        local_444[0x10] = '\0';
        local_444[0x11] = '\0';
        local_444[0x12] = '\0';
        local_444[0x13] = '\0';
        local_444[0x14] = '\0';
        local_444[0x15] = '\0';
        local_444[0x16] = '\0';
        local_444[0x17] = '\0';
        local_444[0x18] = '\0';
        local_444[0x19] = '\0';
        local_444[0x1a] = '\0';
        local_444[0x1b] = '\0';
        local_444[0x1c] = '\0';
        local_444[0x1d] = '\0';
        local_444[0x1e] = '\0';
        local_444[0x1f] = '\0';
        local_444[0x20] = '\0';
        local_444[0x21] = '\0';
        local_444[0x22] = '\0';
        local_444[0x23] = '\0';
        local_444[0x24] = '\0';
        local_444[0x25] = '\0';
        local_444[0x26] = '\0';
        local_444[0x27] = '\0';
        local_444[0x28] = '\0';
        local_444[0x29] = '\0';
        local_444[0x2a] = '\0';
        local_444[0x2b] = '\0';
        local_444[0x2c] = '\0';
        local_444[0x2d] = '\0';
        local_444[0x2e] = '\0';
        local_444[0x2f] = '\0';
        local_444[0x30] = '\0';
        local_444[0x31] = '\0';
        local_444[0x32] = '\0';
        local_444[0x33] = '\0';
        local_444[0x34] = '\0';
        local_444[0x35] = '\0';
        local_444[0x36] = '\0';
        local_444[0x37] = '\0';
        local_444[0x38] = '\0';
        local_444[0x39] = '\0';
        local_444[0x3a] = '\0';
        local_444[0x3b] = '\0';
        local_408 = 0;
        memset(local_404,0,0xff);
        iVar9 = local_758;
        local_304 = 0;
        local_300 = 0;
        local_2fc = 0;
        local_2f4 = 0x1e;
        local_2f0 = 0;
        local_448 = local_758;
        local_2f8 = uVar3;
        pIVar12 = theInstance();
        pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_BID_SYSTEM_NAME");
        strncpy(local_444,pcVar13,0x10);
        pIVar12 = theInstance();
        pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                    (pIVar12,"STR_BID_SUCCESSFULLY_MAIL_TITLE");
        _snprintf(local_444 + 0x20,0x20,pcVar13);
        local_408 = local_408 & 0xffffff;
        pIVar12 = theInstance();
        pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar12)
                                    (pIVar12,"STR_BID_SUCCESSFULLY_MAIL_CONTENT");
        local_7e8 = CONCAT44(local_7e8._4_4_,uVar5);
        local_7f0 = (int *)(local_2c8 + 0x50);
        local_7f8 = (longlong *)local_2c8;
        _snprintf(local_404,0xff,pcVar13);
        local_306 = 0;
        local_7f0 = &local_448;
        local_7f8 = plVar17;
        cVar2 = FUN_140228800(lVar18,iVar9,0,0);
        if (cVar2 == '\0') {
          log_InlineLogERROR(
                            "CAuctionMgr::OnBidSuccessfully, failed in sending item(%u) mail to user(%u)"
                            );
        }
      }
    }
  }
  return;
}

// ==== CMsgAuction::helper_140231660  @140231660  [medium:callgraph-r0]  (orig: FUN_140231660)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140231660(longlong param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong lVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong lVar12;
  int *piVar13;
  char *pcVar14;
  longlong lVar15;
  undefined1 auStack_918 [32];
  undefined8 local_8f8;
  int *local_8f0;
  undefined4 local_8e8;
  undefined4 local_8e0;
  undefined4 local_8d8;
  int local_8d4;
  uint local_8d0;
  undefined4 local_8cc;
  longlong local_8c8;
  longlong *local_8c0;
  undefined8 local_8b8;
  undefined4 local_8a8;
  undefined2 local_8a4;
  undefined4 local_8a0;
  undefined4 local_89c;
  undefined4 local_898;
  undefined4 local_894;
  undefined4 local_890;
  undefined1 local_88c;
  undefined4 local_888;
  undefined4 local_884;
  undefined4 local_880;
  undefined4 local_87c;
  undefined4 local_878;
  undefined4 local_874;
  undefined4 local_870;
  undefined4 local_86c;
  undefined4 local_868;
  int local_858;
  char local_854 [60];
  uint local_818;
  undefined1 local_814 [256];
  undefined4 local_714;
  undefined4 local_710;
  undefined4 local_70c;
  undefined4 local_708;
  undefined4 local_704;
  undefined1 local_700;
  int local_6f8;
  char local_6f4 [60];
  uint local_6b8;
  undefined1 local_6b4 [256];
  undefined4 local_5b4;
  undefined4 local_5b0;
  undefined4 local_5ac;
  undefined4 local_5a8;
  undefined4 local_5a4;
  undefined1 local_5a0;
  undefined1 local_598 [1072];
  undefined1 local_168;
  undefined8 local_167;
  undefined8 local_15f;
  undefined8 local_157;
  undefined4 local_14f;
  undefined2 local_14b;
  undefined1 local_149;
  char local_148;
  undefined1 local_147 [254];
  undefined1 local_49;
  ulonglong local_48;
  
  local_8b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_918;
  local_8cc = param_3;
  local_8c8 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_8f8 = CONCAT44(local_8f8._4_4_,0x3b5);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    cVar1 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
    uVar2 = 0;
    if (cVar1 != '\0') {
      plVar8 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_8f8 = CONCAT44(local_8f8._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_3);
      uVar2 = 0;
      if (plVar8 != (longlong *)0x0) {
        local_8c0 = plVar8;
        lVar9 = FUN_14022b140(param_1,param_3);
        if (lVar9 == 0) {
          pIVar10 = theInstance();
          lVar9 = param_2[2];
          uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_BID_ITEM_NO_EXISIT");
          (**(code **)(lVar9 + 0x358))(param_2 + 2,uVar11);
          uVar2 = 0;
        }
        else if ((*(char *)((longlong)param_2 + 0x51c) == '\0') &&
                (iVar3 = FUN_14041e710(lVar9,5), iVar3 == 2)) {
          uVar2 = 0;
        }
        else {
          iVar3 = (**(code **)(*param_2 + 8))(param_2);
          iVar4 = FUN_14041e710(lVar9,2);
          if (iVar3 == iVar4) {
            uVar2 = 0;
          }
          else {
            cVar1 = FUN_14041e670(lVar9);
            if (cVar1 == '\0') {
              uVar5 = FUN_14041e710(lVar9,7);
              uVar2 = 0;
              if (uVar5 != 0) {
                local_168 = 0;
                local_167 = 0;
                local_15f = 0;
                local_157 = 0;
                local_14f = 0;
                local_14b = 0;
                local_149 = 0;
                local_8d0 = uVar5;
                FUN_140227740(param_1,plVar8,&local_168);
                local_8d4 = FUN_14041e710(lVar9,10);
                local_8d8 = FUN_14041e710(lVar9,6);
                iVar3 = FUN_14041e710(lVar9,5);
                if (iVar3 == 1) {
                  lVar12 = (**(code **)(*param_2 + 0x60))(param_2);
                  if (lVar12 < (longlong)(ulonglong)uVar5) {
                    return 0;
                  }
                  cVar1 = (**(code **)(*param_2 + 0x178))(param_2,(ulonglong)uVar5,1);
                  if (cVar1 == '\0') {
                    return 0;
                  }
                  uVar6 = FUN_1400fda10(plVar8,1,1);
                  plVar8 = local_8c0;
                  uVar7 = (**(code **)(*local_8c0 + 8))(local_8c0);
                  piVar13 = (int *)FUN_140100430(plVar8,0x65);
                  (**(code **)(*param_2 + 8))(param_2);
                  (**(code **)(param_2[2] + 0x18))();
                  uVar5 = local_8d0;
                  local_8f8 = CONCAT44(local_8f8._4_4_,local_8d0);
                  local_8f0 = piVar13;
                  local_8e8 = uVar7;
                  local_8e0 = uVar6;
                  tq::MyLogSave("gmlog/auction",
                                "user(%s,%u) spend money(%d) for fix bidding auction item(%s,%u,type:%u)"
                               );
                  iVar3 = local_8d4;
                  lVar12 = local_8c8;
                  if (local_8d4 != 0) {
                    local_858 = 0;
                    local_854[0] = '\0';
                    local_854[1] = '\0';
                    local_854[2] = '\0';
                    local_854[3] = '\0';
                    local_854[4] = '\0';
                    local_854[5] = '\0';
                    local_854[6] = '\0';
                    local_854[7] = '\0';
                    local_854[8] = '\0';
                    local_854[9] = '\0';
                    local_854[10] = '\0';
                    local_854[0xb] = '\0';
                    local_854[0xc] = '\0';
                    local_854[0xd] = '\0';
                    local_854[0xe] = '\0';
                    local_854[0xf] = '\0';
                    local_854[0x10] = '\0';
                    local_854[0x11] = '\0';
                    local_854[0x12] = '\0';
                    local_854[0x13] = '\0';
                    local_854[0x14] = '\0';
                    local_854[0x15] = '\0';
                    local_854[0x16] = '\0';
                    local_854[0x17] = '\0';
                    local_854[0x18] = '\0';
                    local_854[0x19] = '\0';
                    local_854[0x1a] = '\0';
                    local_854[0x1b] = '\0';
                    local_854[0x1c] = '\0';
                    local_854[0x1d] = '\0';
                    local_854[0x1e] = '\0';
                    local_854[0x1f] = '\0';
                    local_854[0x20] = '\0';
                    local_854[0x21] = '\0';
                    local_854[0x22] = '\0';
                    local_854[0x23] = '\0';
                    local_854[0x24] = '\0';
                    local_854[0x25] = '\0';
                    local_854[0x26] = '\0';
                    local_854[0x27] = '\0';
                    local_854[0x28] = '\0';
                    local_854[0x29] = '\0';
                    local_854[0x2a] = '\0';
                    local_854[0x2b] = '\0';
                    local_854[0x2c] = '\0';
                    local_854[0x2d] = '\0';
                    local_854[0x2e] = '\0';
                    local_854[0x2f] = '\0';
                    local_854[0x30] = '\0';
                    local_854[0x31] = '\0';
                    local_854[0x32] = '\0';
                    local_854[0x33] = '\0';
                    local_854[0x34] = '\0';
                    local_854[0x35] = '\0';
                    local_854[0x36] = '\0';
                    local_854[0x37] = '\0';
                    local_854[0x38] = '\0';
                    local_854[0x39] = '\0';
                    local_854[0x3a] = '\0';
                    local_854[0x3b] = '\0';
                    local_818 = 0;
                    memset(local_814,0,0xff);
                    uVar6 = local_8d8;
                    local_710 = 0;
                    local_70c = 0;
                    local_708 = 0;
                    local_704 = 0x1e;
                    local_700 = 0;
                    local_858 = iVar3;
                    local_714 = local_8d8;
                    pIVar10 = theInstance();
                    pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                                (pIVar10,"STR_BID_SYSTEM_NAME");
                    strncpy(local_854,pcVar14,0x10);
                    pIVar10 = theInstance();
                    pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                                (pIVar10,"STR_BID_FAILED_MAIL_TITLE");
                    _snprintf(local_854 + 0x20,0x20,pcVar14);
                    lVar12 = local_8c8;
                    local_818 = local_818 & 0xffffff;
                    local_8f0 = &local_858;
                    local_8f8 = 0;
                    FUN_140228800(local_8c8,iVar3,uVar6,0);
                  }
                }
                else {
                  if (*(uint *)((longlong)param_2 + 0xfa4) < uVar5) {
                    return 0;
                  }
                  local_8f8 = 0;
                  cVar1 = (**(code **)(param_2[2] + 0x2e0))
                                    (param_2 + 2,0x1d,(longlong)(int)-uVar5,1);
                  if (cVar1 == '\0') {
                    return 0;
                  }
                  uVar6 = (**(code **)(*param_2 + 8))(param_2);
                  local_8f8._0_4_ = uVar5;
                  FUN_1401742b0(param_2,0x2f,uVar6);
                  uVar6 = FUN_1400fda10(plVar8,1,1);
                  plVar8 = local_8c0;
                  uVar7 = (**(code **)(*local_8c0 + 8))(local_8c0);
                  piVar13 = (int *)FUN_140100430(plVar8,0x65);
                  (**(code **)(*param_2 + 8))(param_2);
                  (**(code **)(param_2[2] + 0x18))();
                  uVar5 = local_8d0;
                  local_8f8 = CONCAT44(local_8f8._4_4_,local_8d0);
                  local_8f0 = piVar13;
                  local_8e8 = uVar7;
                  local_8e0 = uVar6;
                  tq::MyLogSave("gmlog/auction",
                                "user(%s,%u) spend money(%d) for fix bidding auction item(%s,%u,type:%u)"
                               );
                  iVar3 = local_8d4;
                  lVar12 = local_8c8;
                  if (local_8d4 != 0) {
                    local_6f8 = 0;
                    local_6f4[0] = '\0';
                    local_6f4[1] = '\0';
                    local_6f4[2] = '\0';
                    local_6f4[3] = '\0';
                    local_6f4[4] = '\0';
                    local_6f4[5] = '\0';
                    local_6f4[6] = '\0';
                    local_6f4[7] = '\0';
                    local_6f4[8] = '\0';
                    local_6f4[9] = '\0';
                    local_6f4[10] = '\0';
                    local_6f4[0xb] = '\0';
                    local_6f4[0xc] = '\0';
                    local_6f4[0xd] = '\0';
                    local_6f4[0xe] = '\0';
                    local_6f4[0xf] = '\0';
                    local_6f4[0x10] = '\0';
                    local_6f4[0x11] = '\0';
                    local_6f4[0x12] = '\0';
                    local_6f4[0x13] = '\0';
                    local_6f4[0x14] = '\0';
                    local_6f4[0x15] = '\0';
                    local_6f4[0x16] = '\0';
                    local_6f4[0x17] = '\0';
                    local_6f4[0x18] = '\0';
                    local_6f4[0x19] = '\0';
                    local_6f4[0x1a] = '\0';
                    local_6f4[0x1b] = '\0';
                    local_6f4[0x1c] = '\0';
                    local_6f4[0x1d] = '\0';
                    local_6f4[0x1e] = '\0';
                    local_6f4[0x1f] = '\0';
                    local_6f4[0x20] = '\0';
                    local_6f4[0x21] = '\0';
                    local_6f4[0x22] = '\0';
                    local_6f4[0x23] = '\0';
                    local_6f4[0x24] = '\0';
                    local_6f4[0x25] = '\0';
                    local_6f4[0x26] = '\0';
                    local_6f4[0x27] = '\0';
                    local_6f4[0x28] = '\0';
                    local_6f4[0x29] = '\0';
                    local_6f4[0x2a] = '\0';
                    local_6f4[0x2b] = '\0';
                    local_6f4[0x2c] = '\0';
                    local_6f4[0x2d] = '\0';
                    local_6f4[0x2e] = '\0';
                    local_6f4[0x2f] = '\0';
                    local_6f4[0x30] = '\0';
                    local_6f4[0x31] = '\0';
                    local_6f4[0x32] = '\0';
                    local_6f4[0x33] = '\0';
                    local_6f4[0x34] = '\0';
                    local_6f4[0x35] = '\0';
                    local_6f4[0x36] = '\0';
                    local_6f4[0x37] = '\0';
                    local_6f4[0x38] = '\0';
                    local_6f4[0x39] = '\0';
                    local_6f4[0x3a] = '\0';
                    local_6f4[0x3b] = '\0';
                    local_6b8 = 0;
                    memset(local_6b4,0,0xff);
                    uVar6 = local_8d8;
                    local_5b4 = 0;
                    local_5ac = 0;
                    local_5a8 = 0;
                    local_5a4 = 0x1e;
                    local_5a0 = 0;
                    local_6f8 = iVar3;
                    local_5b0 = local_8d8;
                    pIVar10 = theInstance();
                    pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                                (pIVar10,"STR_BID_SYSTEM_NAME");
                    strncpy(local_6f4,pcVar14,0x10);
                    pIVar10 = theInstance();
                    pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                                (pIVar10,"STR_BID_FAILED_MAIL_TITLE");
                    _snprintf(local_6f4 + 0x20,0x20,pcVar14);
                    lVar12 = local_8c8;
                    local_6b8 = local_6b8 & 0xffffff;
                    local_8f0 = &local_6f8;
                    local_8f8 = 0;
                    FUN_140228800(local_8c8,iVar3,0,uVar6);
                  }
                }
                FUN_14041e810(lVar9,6,uVar5);
                uVar6 = (**(code **)(*param_2 + 8))(param_2);
                FUN_14041e810(lVar9,10,uVar6);
                uVar11 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                FUN_14041e770(lVar9,0xb,uVar11);
                FUN_14041e930(lVar9);
                uVar6 = FUN_14041e8c0(lVar9);
                FUN_14022e890(lVar12,iVar3,uVar6);
                FUN_14041f890(local_598);
                cVar1 = FUN_14041f940(local_598,2,1);
                if (cVar1 != '\0') {
                  FUN_14022b560(lVar12,param_2,local_8c0);
                  local_8a8 = 0;
                  local_8a4 = 0;
                  local_8a0 = 0;
                  local_88c = 1;
                  local_888 = 0;
                  local_884 = 0;
                  local_880 = 0;
                  local_87c = 0;
                  local_878 = 0;
                  local_89c = 0;
                  local_898 = 0;
                  local_894 = 0;
                  local_890 = 0;
                  local_874 = 0;
                  local_870 = 0;
                  local_86c = 0;
                  local_868 = 0;
                  cVar1 = FUN_14041f330(lVar9,&local_8a8);
                  if ((cVar1 != '\0') &&
                     (cVar1 = FUN_14041f9d0(local_598,&local_8a8), cVar1 != '\0')) {
                    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_598);
                  }
                }
                uVar11 = FUN_140008520(*(undefined4 *)(lVar12 + 8));
                plVar8 = (longlong *)FUN_140087650(uVar11);
                lVar15 = (**(code **)(*plVar8 + 0x98))(plVar8,iVar3);
                if ((lVar15 != 0) && (iVar4 = (**(code **)(*param_2 + 8))(param_2), iVar3 != iVar4))
                {
                  local_148 = '\0';
                  memset(local_147,0,0xff);
                  pIVar10 = theInstance();
                  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                              (pIVar10,"STR_BID_OTHER_FIX_BUY");
                  _snprintf(&local_148,0x100,pcVar14);
                  local_49 = 0;
                  (**(code **)(*(longlong *)(lVar15 + 0x10) + 0x358))
                            ((longlong *)(lVar15 + 0x10),&local_148);
                }
                FUN_14022fce0(lVar12,lVar9);
                FUN_14041f8e0(local_598);
                uVar2 = 1;
              }
            }
            else {
              uVar2 = 0;
            }
          }
        }
      }
    }
  }
  return uVar2;
}

// ==== CMsgAuction::helper_140232240  @140232240  [medium:callgraph-r2]  (orig: FUN_140232240)
/* WARNING: Removing unreachable block (ram,0x00014023236f) */
/* WARNING: Removing unreachable block (ram,0x000140232336) */
/* WARNING: Removing unreachable block (ram,0x000140232356) */
/* WARNING: Removing unreachable block (ram,0x0001402323a4) */
/* WARNING: Removing unreachable block (ram,0x0001402323a9) */
/* WARNING: Removing unreachable block (ram,0x0001402323b4) */
/* WARNING: Removing unreachable block (ram,0x0001402323b9) */
/* WARNING: Removing unreachable block (ram,0x0001402323be) */
/* WARNING: Removing unreachable block (ram,0x0001402323c4) */

undefined8 FUN_140232240(longlong param_1,uint param_2,void **param_3)

{
  longlong *plVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  void *pvVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong *plVar10;
  bool bVar11;
  uint local_res10 [2];
  void **local_res18;
  longlong *local_res20;
  longlong *local_a8;
  longlong lStack_a0;
  longlong *local_98 [3];
  void *local_80;
  void *local_78;
  undefined8 local_70;
  uint local_68 [2];
  void *local_60 [3];
  void *local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  local_res18 = param_3;
  if (param_3 == (void **)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(param_1 + 0x50);
  FUN_14022bdc0(plVar1,&local_a8,local_res10);
  lVar9 = *(longlong *)(param_1 + 0x80);
  if ((local_a8 == (longlong *)0x0) || (local_a8 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  if (lStack_a0 != lVar9) {
    if (local_a8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *local_a8;
    }
    if (lStack_a0 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14022ce90(lStack_a0 + 0x20,&local_res18);
    return 1;
  }
  local_res20 = operator_new(8);
  plVar7 = (longlong *)0x0;
  local_a8 = plVar7;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_98;
    local_a8 = local_res20;
  }
  local_70 = 0;
  local_78 = (void *)0x0;
  local_80 = (void *)0x0;
  lStack_a0 = 0;
  local_98[0] = local_a8;
  FUN_14022c3d0(local_98,&local_a8,1,&local_res18);
  pvVar6 = local_80;
  if (local_78 < local_80) {
    _invalid_parameter_noinfo();
  }
  plVar5 = local_98[0];
  if (local_98[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar10 = plVar7;
  }
  else {
    plVar10 = (longlong *)*local_98[0];
  }
  if (pvVar6 <= (void *)plVar10[4]) {
    if (plVar5 != (longlong *)0x0) {
      plVar7 = (longlong *)*plVar5;
    }
    if ((void *)plVar7[3] <= pvVar6) goto LAB_140232441;
  }
  _invalid_parameter_noinfo();
LAB_140232441:
  local_68[0] = param_2;
  FUN_14022c020(local_60,local_98);
  puVar3 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  bVar11 = true;
  cVar2 = *(char *)((longlong)puVar3 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x80);
  while (cVar2 == '\0') {
    bVar11 = local_68[0] < *(uint *)(puVar3 + 3);
    if (bVar11) {
      puVar8 = (undefined8 *)*puVar3;
    }
    else {
      puVar8 = (undefined8 *)puVar3[2];
    }
    puVar4 = puVar3;
    puVar3 = puVar8;
    cVar2 = *(char *)((longlong)puVar8 + 0x51);
  }
  FUN_14022dfc0(plVar1,&local_a8,bVar11,puVar4,local_68);
  local_res18 = local_60;
  if (local_48 != (void *)0x0) {
    operator_delete(local_48);
  }
  local_48 = (void *)0x0;
  local_40 = 0;
  local_38 = 0;
  operator_delete(local_60[0]);
  if (local_80 != (void *)0x0) {
    operator_delete(local_80);
  }
  local_80 = (void *)0x0;
  local_78 = (void *)0x0;
  local_70 = 0;
  operator_delete(local_98[0]);
  return 1;
}

// ==== CMsgAuction::helper_140232560  @140232560  [medium:callgraph-r1]  (orig: FUN_140232560)
void FUN_140232560(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  undefined4 uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 != param_4) {
    uVar1 = FUN_14041e8c0(param_2);
    FUN_14022e890(param_1,param_4,uVar1);
    FUN_140232240(param_1,param_3,param_2);
  }
  return;
}

// ==== CMsgAuction::helper_1402328d0  @1402328d0  [medium:callgraph-r0]  (orig: FUN_1402328d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_1402328d0(longlong param_1,longlong *param_2,uint param_3,char param_4,uint param_5,uint param_6
             ,int param_7)

{
  longlong *plVar1;
  uint uVar2;
  longlong lVar3;
  char cVar4;
  undefined1 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong lVar15;
  IStringManager *pIVar16;
  ulonglong uVar17;
  char *_Source;
  longlong *plVar18;
  undefined4 uVar19;
  undefined1 auStack_1c8 [32];
  undefined4 *local_1a8;
  undefined8 local_1a0;
  undefined4 local_198;
  undefined4 local_190;
  undefined4 local_188;
  undefined4 local_180;
  undefined4 local_178;
  undefined4 local_170;
  undefined4 local_168;
  undefined4 local_160;
  undefined4 local_158;
  undefined4 local_150;
  undefined4 local_148;
  undefined4 local_140;
  undefined4 local_138;
  undefined4 local_130;
  undefined4 local_128;
  undefined4 local_120;
  char local_118;
  undefined4 local_114;
  uint local_110;
  ulonglong local_108;
  ulonglong local_100;
  undefined4 local_f8;
  uint local_f4;
  undefined4 local_f0;
  undefined4 local_ec;
  undefined4 local_e8;
  longlong *local_e0;
  undefined4 local_d8;
  undefined4 local_d4;
  undefined4 local_d0;
  undefined4 local_cc;
  uint local_c8;
  undefined4 local_c4;
  longlong *local_c0;
  longlong *local_b8;
  longlong *local_b0;
  longlong local_a8;
  undefined8 local_a0;
  uint local_98;
  undefined2 local_94;
  undefined4 local_90;
  char local_8c [20];
  uint local_78;
  uint local_74;
  undefined4 local_70;
  int local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  ulonglong local_48;
  
  local_a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1c8;
  local_118 = param_4;
  local_f4 = param_3;
  local_c8 = param_3;
  local_c0 = param_2;
  local_b8 = param_2;
  local_a8 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_1a8 = (undefined4 *)CONCAT44(local_1a8._4_4_,0xfc);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    plVar1 = param_2 + 2;
    local_b0 = plVar1;
    cVar4 = (**(code **)(*plVar1 + 0x220))(plVar1);
    uVar5 = 0;
    if (cVar4 != '\0') {
      plVar13 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_1a8 = (undefined4 *)CONCAT44(local_1a8._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar13 = (longlong *)0x0;
      }
      plVar13 = (longlong *)(**(code **)(*plVar13 + 0x60))(plVar13,param_3);
      uVar5 = 0;
      if (plVar13 != (longlong *)0x0) {
        local_e0 = plVar13;
        uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 8));
        cVar4 = FUN_14008abf0(uVar14);
        local_110 = param_5;
        if (cVar4 != '\0') {
          if (0x3b9ac9fe < param_6 - 1) {
            return 0;
          }
          local_110 = param_6;
          if (param_7 != 0x18) {
            return 0;
          }
        }
        uVar5 = 0;
        if (local_110 != 0) {
          if (local_110 < 1000000000) {
            if ((param_6 == 0) || (local_110 <= param_6)) {
              lVar15 = FUN_14022b140(param_1,param_3);
              if (lVar15 == 0) {
                local_100 = *(undefined8 *)(param_1 + 0x48);
                if ((int)local_100 < *(int *)(param_1 + 0xd4)) {
                  uVar6 = (**(code **)(*param_2 + 8))(param_2);
                  iVar7 = FUN_14022b240(param_1,uVar6);
                  if (iVar7 < *(int *)(param_1 + 0xd8)) {
                    cVar4 = FUN_140332fe0(param_2,param_3);
                    uVar5 = 0;
                    if (cVar4 != '\0') {
                      plVar18 = DAT_140975b60;
                      if (DAT_140975b60 == (longlong *)0x0) {
                        local_1a8 = (undefined4 *)CONCAT44(local_1a8._4_4_,0x3c0);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        plVar18 = (longlong *)0x0;
                      }
                      cVar4 = (**(code **)(*plVar18 + 0x170))(plVar18,param_3);
                      if (cVar4 == '\0') {
                        iVar7 = FUN_1400fda10(plVar13,3,1);
                        iVar8 = (**(code **)(*param_2 + 8))(param_2);
                        if (iVar7 == iVar8) {
                          uVar17 = FUN_1400fda10(plVar13,0x6e,1);
                          if ((((uVar17 ^ 0xff) & 1) == 0) ||
                             (cVar4 = FUN_1400ffcb0(plVar13), cVar4 == '\0')) {
                            uVar5 = 0;
                          }
                          else {
                            cVar4 = FUN_1400ffc20(plVar13);
                            if (((cVar4 == '\0') && (cVar4 = FUN_1400ffbe0(plVar13), cVar4 == '\0'))
                               && (iVar7 = FUN_1400fda10(plVar13,0x17,1), iVar7 == 0)) {
                              cVar4 = FUN_1400ff650(plVar13,2);
                              if ((cVar4 == '\0') &&
                                 (cVar4 = FUN_1400ff650(plVar13,1), cVar4 == '\0')) {
                                cVar4 = FUN_1403380a0(param_2,param_3);
                                if ((cVar4 == '\0') &&
                                   (cVar4 = FUN_14032d730(param_2,param_3), cVar4 == '\0')) {
                                  if ((local_118 == '\x01') || (local_118 == '\x02')) {
                                    local_114 = 0;
                                    local_1a8 = &local_114;
                                    cVar4 = FUN_140227600(param_1,param_3,local_110,local_118);
                                    if (cVar4 == '\0') {
                                      uVar17 = FUN_1400fda10(plVar13,0xa0,1);
                                      local_108 = uVar17 & 0xffffffff;
                                      local_100 = local_108;
                                      if (param_7 != 0xc) {
                                        if (param_7 == 0x18) {
                                          local_108 = ((uVar17 & 0xffffffff) * 0x16) / 10;
                                          local_100 = local_108 & 0xffffffff;
                                        }
                                        else {
                                          if (param_7 != 0x30) {
                                            return 0;
                                          }
                                          local_108 = ((uVar17 & 0xffffffff) * 0x2d) / 10;
                                          local_100 = local_108;
                                        }
                                      }
                                      if ((int)local_100 == 0) {
                                        FUN_1400fda10(plVar13,1,1);
                                        log_InlineLogDBERROR
                                                  (
                                                  "table:cq_itemtype, item type(id = %u), auction_deposit filed config <= 0"
                                                  );
                                        uVar5 = 0;
                                      }
                                      else {
                                        uVar17 = local_100 & 0xffffffff;
                                        lVar15 = (**(code **)(*param_2 + 0x60))(param_2);
                                        if (lVar15 < (longlong)uVar17) {
                                          uVar5 = 0;
                                        }
                                        else {
                                          cVar4 = (**(code **)(*param_2 + 0x178))(param_2,uVar17,1);
                                          uVar5 = 0;
                                          if (cVar4 != '\0') {
                                            uVar6 = FUN_1400fda10(plVar13,0xc,1);
                                            local_108 = CONCAT44(local_108._4_4_,uVar6);
                                            local_114 = FUN_140100410(plVar13);
                                            local_c4 = FUN_140100340(plVar13);
                                            local_d0 = FUN_1401003f0(plVar13);
                                            local_ec = FUN_1401003d0(plVar13);
                                            local_f0 = FUN_1400fda10(plVar13,0x13,1);
                                            local_d4 = FUN_1400ffda0(plVar13);
                                            local_e8 = FUN_1400fda10(plVar13,0xf,1);
                                            local_cc = FUN_1400fda10(plVar13,0xe,1);
                                            local_d8 = FUN_1400fda10(plVar13,0x10,1);
                                            local_f8 = FUN_1400fda10(plVar13,5,1);
                                            uVar6 = FUN_1400fda10(plVar13,4,1);
                                            uVar9 = FUN_1400fda10(plVar13,9,1);
                                            uVar10 = FUN_1400fda10(plVar13,8,1);
                                            uVar11 = FUN_1400fda10(plVar13,1,1);
                                            uVar12 = (**(code **)(*plVar13 + 8))(plVar13);
                                            uVar14 = FUN_140100430(local_e0,0x65);
                                            (**(code **)(*local_c0 + 8))();
                                            (**(code **)(*local_b0 + 0x18))();
                                            local_120 = local_114;
                                            local_128 = local_c4;
                                            local_130 = local_d0;
                                            local_138 = local_ec;
                                            local_140 = local_f0;
                                            local_148 = local_d4;
                                            local_150 = local_e8;
                                            local_158 = local_cc;
                                            local_160 = local_d8;
                                            local_168 = local_f8;
                                            local_178 = (undefined4)local_108;
                                            uVar19 = (undefined4)local_100;
                                            local_1a8 = (undefined4 *)
                                                        CONCAT44(local_1a8._4_4_,uVar19);
                                            local_1a0 = uVar14;
                                            local_198 = uVar12;
                                            local_190 = uVar11;
                                            local_188 = uVar10;
                                            local_180 = uVar9;
                                            local_170 = uVar6;
                                            tq::MyLogSave("gmlog/auction",
                                                                                                                    
                                                  "user(%s,%u) spend deposit(%u) for selling auction item(%s,%u,type:%d)gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%d], dec_dmg[%d] add_life[%d] accumulate[%d]specialflag[%d] quenchtype[%d] quenchlev[%d] forgetype[%d] forgelev[%d]"
                                                  );
                                            plVar18 = local_c0;
                                            uVar2 = local_c8;
                                            local_94 = 0;
                                            local_90 = 0;
                                            local_6c = 0;
                                            local_68 = 0;
                                            local_8c[0] = '\0';
                                            local_8c[1] = '\0';
                                            local_8c[2] = '\0';
                                            local_8c[3] = '\0';
                                            local_8c[4] = '\0';
                                            local_8c[5] = '\0';
                                            local_8c[6] = '\0';
                                            local_8c[7] = '\0';
                                            local_8c[8] = '\0';
                                            local_8c[9] = '\0';
                                            local_8c[10] = '\0';
                                            local_8c[0xb] = '\0';
                                            local_8c[0xc] = '\0';
                                            local_8c[0xd] = '\0';
                                            local_8c[0xe] = '\0';
                                            local_8c[0xf] = '\0';
                                            local_64 = 0;
                                            local_60 = 0;
                                            local_5c = 0;
                                            local_58 = 0;
                                            local_74 = param_6;
                                            local_78 = local_110;
                                            local_8c[0x10] = local_118;
                                            local_98 = local_c8;
                                            local_70 = uVar19;
                                            local_90 = (**(code **)(*local_c0 + 8))(local_c0);
                                            local_6c = param_7;
                                            plVar1 = plVar18 + 2;
                                            _Source = (char *)(**(code **)(*plVar1 + 0x18))(plVar1);
                                            strncpy(local_8c,_Source,0x10);
                                            lVar15 = FUN_14041f7d0(&local_98);
                                            plVar13 = local_e0;
                                            if (lVar15 == 0) {
                                              uVar6 = FUN_1400fda10(local_e0,1,1);
                                              uVar9 = (**(code **)(*plVar13 + 8))(plVar13);
                                              uVar14 = FUN_140100430(plVar13,0x65);
                                              (**(code **)(*plVar18 + 8))(plVar18);
                                              (**(code **)(*plVar1 + 0x18))(plVar1);
                                              local_1a0 = CONCAT44(local_1a0._4_4_,uVar9);
                                              local_1a8 = (undefined4 *)uVar14;
                                              local_198 = uVar6;
                                              tq::MyLogSave("gmlog/auction",
                                                                                                                        
                                                  "user(%s,%u) failed in creating auction item object(%s, %u, type:%u)"
                                                  );
                                              uVar5 = 0;
                                            }
                                            else {
                                              local_1a8 = (undefined4 *)CONCAT71(local_1a8._1_7_,1);
                                              iVar7 = FUN_1403368a0(plVar18,uVar2,1);
                                              lVar3 = local_a8;
                                              plVar1 = local_e0;
                                              if (iVar7 == 0) {
                                                (**(code **)(*plVar18 + 8))(plVar18);
                                                log_InlineLogERROR(
                                                  "AuctionMgr::Sell, user(%u) failed in pop item(%u)"
                                                  );
                                                uVar5 = 0;
                                              }
                                              else {
                                                local_1a8 = (undefined4 *)
                                                            CONCAT44(local_1a8._4_4_,0xcf);
                                                FUN_14022b360(local_a8,plVar18,local_e0,0);
                                                FUN_140104140(plVar1,7,0xcf);
                                                FUN_140104080(plVar1,0);
                                                cVar4 = FUN_1402326f0(lVar3,lVar15);
                                                uVar5 = 0;
                                                if (cVar4 != '\0') {
                                                  uVar5 = 1;
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                    else {
                                      pIVar16 = theInstance();
                                      lVar15 = *plVar1;
                                      uVar14 = (*(code *)**(undefined8 **)pIVar16)
                                                         (pIVar16,"STR_BOOTH_LOW_PRICE");
                                      (**(code **)(lVar15 + 0x358))(plVar1,uVar14,local_114);
                                      uVar5 = 0;
                                    }
                                  }
                                  else {
                                    uVar5 = 0;
                                  }
                                }
                                else {
                                  uVar5 = 0;
                                }
                              }
                              else {
                                uVar5 = 0;
                              }
                            }
                            else {
                              uVar5 = 0;
                            }
                          }
                        }
                        else {
                          uVar5 = 0;
                        }
                      }
                      else {
                        uVar5 = 0;
                      }
                    }
                  }
                  else {
                    pIVar16 = theInstance();
                    lVar15 = *plVar1;
                    uVar14 = (*(code *)**(undefined8 **)pIVar16)
                                       (pIVar16,"STR_BID_USER_TOO_MANY_ITEM");
                    (**(code **)(lVar15 + 0x358))(plVar1,uVar14,*(undefined4 *)(param_1 + 0xd8));
                    uVar5 = 0;
                  }
                }
                else {
                  pIVar16 = theInstance();
                  lVar15 = *plVar1;
                  uVar14 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_BID_SYS_TOO_MANY_ITEM");
                  (**(code **)(lVar15 + 0x358))(plVar1,uVar14,*(undefined4 *)(param_1 + 0xd4));
                  uVar5 = 0;
                }
              }
              else {
                uVar5 = 0;
              }
            }
            else {
              uVar5 = 0;
            }
          }
          else {
            uVar5 = 0;
          }
        }
      }
    }
  }
  return uVar5;
}

// ==== CMsgAuction::helper_1402335a0  @1402335a0  [medium:callgraph-r0]  (orig: FUN_1402335a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1402335a0(longlong param_1,longlong *param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong lVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  int *piVar13;
  char *pcVar14;
  longlong lVar15;
  undefined1 auStack_928 [32];
  undefined8 local_908;
  int *local_900;
  undefined4 local_8f8;
  undefined4 local_8f0;
  uint local_8e8;
  uint local_8e4;
  int local_8e0;
  longlong *local_8d8;
  undefined4 local_8d0;
  longlong local_8c8;
  longlong *local_8c0;
  undefined8 local_8b8;
  undefined4 local_8a8;
  undefined2 local_8a4;
  undefined4 local_8a0;
  undefined4 local_89c;
  undefined4 local_898;
  undefined4 local_894;
  undefined4 local_890;
  undefined1 local_88c;
  undefined4 local_888;
  undefined4 local_884;
  undefined4 local_880;
  undefined4 local_87c;
  undefined4 local_878;
  undefined4 local_874;
  undefined4 local_870;
  undefined4 local_86c;
  undefined4 local_868;
  int local_858;
  char local_854 [60];
  uint local_818;
  undefined1 local_814 [256];
  uint local_714;
  undefined4 local_710;
  undefined4 local_70c;
  undefined4 local_708;
  undefined4 local_704;
  undefined1 local_700;
  int local_6f8;
  char local_6f4 [60];
  uint local_6b8;
  undefined1 local_6b4 [256];
  undefined4 local_5b4;
  uint local_5b0;
  undefined4 local_5ac;
  undefined4 local_5a8;
  undefined4 local_5a4;
  undefined1 local_5a0;
  undefined1 local_598 [1072];
  undefined1 local_168;
  undefined8 local_167;
  undefined8 local_15f;
  undefined8 local_157;
  undefined4 local_14f;
  undefined2 local_14b;
  undefined1 local_149;
  char local_148;
  undefined1 local_147 [254];
  undefined1 local_49;
  ulonglong local_48;
  
  local_8b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_928;
  local_8e8 = param_3;
  local_8e4 = param_4;
  local_8d0 = param_3;
  local_8c8 = param_1;
  local_8c0 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_908 = CONCAT44(local_908._4_4_,0x2f4);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    cVar2 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
    uVar3 = 0;
    if (cVar2 != '\0') {
      plVar9 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_908 = CONCAT44(local_908._4_4_,0x3c0);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar9 = (longlong *)0x0;
      }
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_3);
      uVar3 = 0;
      if (plVar9 != (longlong *)0x0) {
        local_8d8 = plVar9;
        lVar10 = FUN_14022b140(param_1,param_3);
        if (lVar10 == 0) {
          pIVar11 = theInstance();
          lVar10 = param_2[2];
          uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BID_ITEM_NO_EXISIT");
          (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar12);
          uVar3 = 0;
        }
        else if ((*(char *)((longlong)param_2 + 0x51c) == '\0') &&
                (iVar4 = FUN_14041e710(lVar10,5), iVar4 == 2)) {
          uVar3 = 0;
        }
        else {
          iVar4 = (**(code **)(*param_2 + 8))(param_2);
          iVar5 = FUN_14041e710(lVar10,2);
          if (iVar4 == iVar5) {
            uVar3 = 0;
          }
          else {
            iVar4 = (**(code **)(*param_2 + 8))(param_2);
            iVar5 = FUN_14041e710(lVar10,10);
            if (iVar4 == iVar5) {
              uVar3 = 0;
            }
            else {
              cVar2 = FUN_14041e670(lVar10);
              if (cVar2 == '\0') {
                uVar6 = FUN_14041e710(lVar10,7);
                if ((uVar6 == 0) || (param_4 < uVar6)) {
                  local_168 = 0;
                  local_167 = 0;
                  local_15f = 0;
                  local_157 = 0;
                  local_14f = 0;
                  local_14b = 0;
                  local_149 = 0;
                  FUN_140227740(param_1,plVar9,&local_168);
                  iVar4 = FUN_14041e710(lVar10,10);
                  local_8e0 = iVar4;
                  local_8e8 = FUN_14041e710(lVar10,6);
                  uVar6 = local_8e8;
                  if ((iVar4 != 0) &&
                     (lVar15 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) *
                                      SEXT816((longlong)((ulonglong)local_8e8 * 0x69)),8) +
                               (ulonglong)local_8e8 * 0x69,
                     uVar6 = (int)(lVar15 >> 6) - (int)(lVar15 >> 0x3f), uVar6 <= local_8e8)) {
                    uVar6 = local_8e8 + 1;
                  }
                  if (param_4 < uVar6) {
                    pIVar11 = theInstance();
                    lVar10 = param_2[2];
                    uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BID_PRICE_TOO_LOW");
                    (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar12);
                    uVar3 = 0;
                  }
                  else {
                    iVar4 = FUN_14041e710(lVar10,5);
                    if (iVar4 == 1) {
                      lVar15 = (**(code **)(*param_2 + 0x60))(param_2);
                      if (lVar15 < (longlong)(ulonglong)param_4) {
                        return 0;
                      }
                      cVar2 = (**(code **)(*param_2 + 0x178))(param_2,(ulonglong)param_4,1);
                      if (cVar2 == '\0') {
                        return 0;
                      }
                      uVar7 = FUN_1400fda10(plVar9,1,1);
                      uVar8 = (**(code **)(*plVar9 + 8))(plVar9);
                      piVar13 = (int *)FUN_140100430(local_8d8,0x65);
                      (**(code **)(*param_2 + 8))(param_2);
                      (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                      uVar6 = local_8e4;
                      local_908 = CONCAT44(local_908._4_4_,local_8e4);
                      local_900 = piVar13;
                      local_8f8 = uVar8;
                      local_8f0 = uVar7;
                      tq::MyLogSave("gmlog/auction",
                                    "user(%s,%u) spend money(%d) for bidding auction item(%s,%u,type:%u)"
                                   );
                      iVar4 = local_8e0;
                      if (local_8e0 != 0) {
                        local_858 = 0;
                        local_854[0] = '\0';
                        local_854[1] = '\0';
                        local_854[2] = '\0';
                        local_854[3] = '\0';
                        local_854[4] = '\0';
                        local_854[5] = '\0';
                        local_854[6] = '\0';
                        local_854[7] = '\0';
                        local_854[8] = '\0';
                        local_854[9] = '\0';
                        local_854[10] = '\0';
                        local_854[0xb] = '\0';
                        local_854[0xc] = '\0';
                        local_854[0xd] = '\0';
                        local_854[0xe] = '\0';
                        local_854[0xf] = '\0';
                        local_854[0x10] = '\0';
                        local_854[0x11] = '\0';
                        local_854[0x12] = '\0';
                        local_854[0x13] = '\0';
                        local_854[0x14] = '\0';
                        local_854[0x15] = '\0';
                        local_854[0x16] = '\0';
                        local_854[0x17] = '\0';
                        local_854[0x18] = '\0';
                        local_854[0x19] = '\0';
                        local_854[0x1a] = '\0';
                        local_854[0x1b] = '\0';
                        local_854[0x1c] = '\0';
                        local_854[0x1d] = '\0';
                        local_854[0x1e] = '\0';
                        local_854[0x1f] = '\0';
                        local_854[0x20] = '\0';
                        local_854[0x21] = '\0';
                        local_854[0x22] = '\0';
                        local_854[0x23] = '\0';
                        local_854[0x24] = '\0';
                        local_854[0x25] = '\0';
                        local_854[0x26] = '\0';
                        local_854[0x27] = '\0';
                        local_854[0x28] = '\0';
                        local_854[0x29] = '\0';
                        local_854[0x2a] = '\0';
                        local_854[0x2b] = '\0';
                        local_854[0x2c] = '\0';
                        local_854[0x2d] = '\0';
                        local_854[0x2e] = '\0';
                        local_854[0x2f] = '\0';
                        local_854[0x30] = '\0';
                        local_854[0x31] = '\0';
                        local_854[0x32] = '\0';
                        local_854[0x33] = '\0';
                        local_854[0x34] = '\0';
                        local_854[0x35] = '\0';
                        local_854[0x36] = '\0';
                        local_854[0x37] = '\0';
                        local_854[0x38] = '\0';
                        local_854[0x39] = '\0';
                        local_854[0x3a] = '\0';
                        local_854[0x3b] = '\0';
                        local_818 = 0;
                        memset(local_814,0,0xff);
                        uVar1 = local_8e8;
                        local_710 = 0;
                        local_70c = 0;
                        local_708 = 0;
                        local_704 = 0x1e;
                        local_700 = 0;
                        local_858 = iVar4;
                        local_714 = local_8e8;
                        pIVar11 = theInstance();
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                                    (pIVar11,"STR_BID_SYSTEM_NAME");
                        strncpy(local_854,pcVar14,0x10);
                        pIVar11 = theInstance();
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                                    (pIVar11,"STR_BID_FAILED_MAIL_TITLE");
                        _snprintf(local_854 + 0x20,0x20,pcVar14);
                        local_818 = local_818 & 0xffffff;
                        local_900 = &local_858;
                        local_908 = 0;
                        FUN_140228800(local_8c8,iVar4,uVar1,0);
                      }
                    }
                    else {
                      if (*(uint *)((longlong)param_2 + 0xfa4) < param_4) {
                        return 0;
                      }
                      local_908 = 0;
                      cVar2 = (**(code **)(param_2[2] + 0x2e0))
                                        (param_2 + 2,0x1d,(longlong)(int)-param_4,1);
                      if (cVar2 == '\0') {
                        return 0;
                      }
                      uVar7 = (**(code **)(*param_2 + 8))(param_2);
                      local_908._0_4_ = param_4;
                      FUN_1401742b0(param_2,0x2f,uVar7);
                      uVar7 = FUN_1400fda10(plVar9,1,1);
                      uVar8 = (**(code **)(*plVar9 + 8))(plVar9);
                      piVar13 = (int *)FUN_140100430(local_8d8,0x65);
                      (**(code **)(*param_2 + 8))(param_2);
                      (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                      uVar6 = local_8e4;
                      local_908 = CONCAT44(local_908._4_4_,local_8e4);
                      local_900 = piVar13;
                      local_8f8 = uVar8;
                      local_8f0 = uVar7;
                      tq::MyLogSave("gmlog/auction",
                                    "user(%s,%u) spend emoney(%d) for bidding auction item(%s,%u,type:%u)"
                                   );
                      iVar4 = local_8e0;
                      if (local_8e0 != 0) {
                        local_6f8 = 0;
                        local_6f4[0] = '\0';
                        local_6f4[1] = '\0';
                        local_6f4[2] = '\0';
                        local_6f4[3] = '\0';
                        local_6f4[4] = '\0';
                        local_6f4[5] = '\0';
                        local_6f4[6] = '\0';
                        local_6f4[7] = '\0';
                        local_6f4[8] = '\0';
                        local_6f4[9] = '\0';
                        local_6f4[10] = '\0';
                        local_6f4[0xb] = '\0';
                        local_6f4[0xc] = '\0';
                        local_6f4[0xd] = '\0';
                        local_6f4[0xe] = '\0';
                        local_6f4[0xf] = '\0';
                        local_6f4[0x10] = '\0';
                        local_6f4[0x11] = '\0';
                        local_6f4[0x12] = '\0';
                        local_6f4[0x13] = '\0';
                        local_6f4[0x14] = '\0';
                        local_6f4[0x15] = '\0';
                        local_6f4[0x16] = '\0';
                        local_6f4[0x17] = '\0';
                        local_6f4[0x18] = '\0';
                        local_6f4[0x19] = '\0';
                        local_6f4[0x1a] = '\0';
                        local_6f4[0x1b] = '\0';
                        local_6f4[0x1c] = '\0';
                        local_6f4[0x1d] = '\0';
                        local_6f4[0x1e] = '\0';
                        local_6f4[0x1f] = '\0';
                        local_6f4[0x20] = '\0';
                        local_6f4[0x21] = '\0';
                        local_6f4[0x22] = '\0';
                        local_6f4[0x23] = '\0';
                        local_6f4[0x24] = '\0';
                        local_6f4[0x25] = '\0';
                        local_6f4[0x26] = '\0';
                        local_6f4[0x27] = '\0';
                        local_6f4[0x28] = '\0';
                        local_6f4[0x29] = '\0';
                        local_6f4[0x2a] = '\0';
                        local_6f4[0x2b] = '\0';
                        local_6f4[0x2c] = '\0';
                        local_6f4[0x2d] = '\0';
                        local_6f4[0x2e] = '\0';
                        local_6f4[0x2f] = '\0';
                        local_6f4[0x30] = '\0';
                        local_6f4[0x31] = '\0';
                        local_6f4[0x32] = '\0';
                        local_6f4[0x33] = '\0';
                        local_6f4[0x34] = '\0';
                        local_6f4[0x35] = '\0';
                        local_6f4[0x36] = '\0';
                        local_6f4[0x37] = '\0';
                        local_6f4[0x38] = '\0';
                        local_6f4[0x39] = '\0';
                        local_6f4[0x3a] = '\0';
                        local_6f4[0x3b] = '\0';
                        local_6b8 = 0;
                        memset(local_6b4,0,0xff);
                        uVar1 = local_8e8;
                        local_5b4 = 0;
                        local_5ac = 0;
                        local_5a8 = 0;
                        local_5a4 = 0x1e;
                        local_5a0 = 0;
                        local_6f8 = iVar4;
                        local_5b0 = local_8e8;
                        pIVar11 = theInstance();
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                                    (pIVar11,"STR_BID_SYSTEM_NAME");
                        strncpy(local_6f4,pcVar14,0x10);
                        pIVar11 = theInstance();
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                                    (pIVar11,"STR_BID_FAILED_MAIL_TITLE");
                        _snprintf(local_6f4 + 0x20,0x20,pcVar14);
                        local_6b8 = local_6b8 & 0xffffff;
                        local_900 = &local_6f8;
                        local_908 = 0;
                        FUN_140228800(local_8c8,iVar4,0,uVar1);
                      }
                    }
                    FUN_14041e810(lVar10,6,uVar6);
                    uVar7 = (**(code **)(*param_2 + 8))(param_2);
                    FUN_14041e810(lVar10,10,uVar7);
                    uVar12 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                    FUN_14041e770(lVar10,0xb,uVar12);
                    FUN_14041e930(lVar10);
                    pIVar11 = theInstance();
                    lVar15 = param_2[2];
                    uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_BID_ACCEPT");
                    (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
                    uVar7 = (**(code **)(*param_2 + 8))(param_2);
                    lVar15 = local_8c8;
                    FUN_140232560(local_8c8,lVar10,uVar7,iVar4);
                    cVar2 = FUN_14041f2c0(lVar10);
                    plVar9 = local_8d8;
                    if (cVar2 != '\0') {
                      uVar7 = FUN_1400fda10(local_8d8,0x9f,1);
                      FUN_140228c90(lVar15,lVar10,uVar7);
                    }
                    uVar7 = FUN_1400fda10(plVar9,0x9f,1);
                    FUN_140228d70(lVar15,lVar10,uVar7);
                    FUN_14041f890(local_598);
                    cVar2 = FUN_14041f940(local_598,1,1,0);
                    if (cVar2 != '\0') {
                      FUN_14022b560(lVar15,param_2,plVar9);
                      local_8a8 = 0;
                      local_8a4 = 0;
                      local_8a0 = 0;
                      local_88c = 1;
                      local_888 = 0;
                      local_884 = 0;
                      local_880 = 0;
                      local_87c = 0;
                      local_878 = 0;
                      local_89c = 0;
                      local_898 = 0;
                      local_894 = 0;
                      local_890 = 0;
                      local_874 = 0;
                      local_870 = 0;
                      local_86c = 0;
                      local_868 = 0;
                      cVar2 = FUN_14041f330(lVar10,&local_8a8);
                      if ((cVar2 != '\0') &&
                         (cVar2 = FUN_14041f9d0(local_598,&local_8a8), cVar2 != '\0')) {
                        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_598);
                      }
                    }
                    uVar12 = FUN_140008520(*(undefined4 *)(lVar15 + 8));
                    plVar9 = (longlong *)FUN_140087650(uVar12);
                    lVar10 = (**(code **)(*plVar9 + 0x98))(plVar9);
                    if (lVar10 != 0) {
                      local_148 = '\0';
                      memset(local_147,0,0xff);
                      pIVar11 = theInstance();
                      pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                                  (pIVar11,"STR_BID_OVERTAKE");
                      _snprintf(&local_148,0x100,pcVar14);
                      local_49 = 0;
                      (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x358))
                                ((longlong *)(lVar10 + 0x10),&local_148);
                    }
                    FUN_14041f8e0(local_598);
                    uVar3 = 1;
                  }
                }
                else {
                  uVar3 = FUN_140231660(param_1,param_2,local_8e8);
                }
              }
              else {
                uVar3 = 0;
              }
            }
          }
        }
      }
    }
  }
  return uVar3;
}

// ==== CMsgAuction::helper_14041e670  @14041e670  [medium:callgraph-r1]  (orig: FUN_14041e670)
bool FUN_14041e670(longlong param_1)

{
  __time64_t _Var1;
  
  _Var1 = _time64((__time64_t *)0x0);
  if (*(int *)(param_1 + 0x10) == 0) {
    return true;
  }
  return *(int *)(param_1 + 0x10) <= _Var1;
}

// ==== CMsgAuction::helper_14041e6b0  @14041e6b0  [medium:callgraph-r2]  (orig: FUN_14041e6b0)
undefined8 FUN_14041e6b0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x00014041e700. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x78))(plVar1);
  return uVar2;
}

// ==== CMsgAuction::helper_14041e770  @14041e770  [medium:callgraph-r1]  (orig: FUN_14041e770)
void FUN_14041e770(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x00014041e7fd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x80))(plVar1,param_3);
  return;
}

// ==== CMsgAuction::helper_14041e810  @14041e810  [medium:callgraph-r1]  (orig: FUN_14041e810)
void FUN_14041e810(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x00014041e867. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_3);
  return;
}

// ==== CMsgAuction::helper_14041e920  @14041e920  [medium:callgraph-r2]  (orig: FUN_14041e920)
undefined4 FUN_14041e920(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CMsgAuction::helper_14041e930  @14041e930  [medium:callgraph-r1]  (orig: FUN_14041e930)
void FUN_14041e930(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014041e977. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  return;
}

// ==== CMsgAuction::helper_14041f160  @14041f160  [medium:callgraph-r2]  (orig: FUN_14041f160)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14041f160(longlong param_1,__time32_t param_2)

{
  tm *ptVar1;
  longlong *plVar2;
  undefined1 auStack_78 [32];
  int local_58;
  int local_50;
  int local_48;
  int local_40;
  int local_38;
  __time32_t local_28 [2];
  char local_20 [16];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  *(__time32_t *)(param_1 + 0x10) = param_2;
  local_20[0] = '\0';
  local_20[1] = '\0';
  local_20[2] = '\0';
  local_20[3] = '\0';
  local_20[4] = '\0';
  local_20[5] = '\0';
  local_20[6] = '\0';
  local_20[7] = '\0';
  local_20[8] = '\0';
  local_20[9] = '\0';
  local_20[10] = '\0';
  local_20[0xb] = '\0';
  local_20[0xc] = 0;
  local_28[0] = param_2;
  ptVar1 = _localtime32(local_28);
  if (ptVar1 != (tm *)0x0) {
    local_20[0] = '\0';
    local_20[1] = '\0';
    local_20[2] = '\0';
    local_20[3] = '\0';
    local_20[4] = '\0';
    local_20[5] = '\0';
    local_20[6] = '\0';
    local_20[7] = '\0';
    local_20[8] = '\0';
    local_20[9] = '\0';
    local_20[10] = '\0';
    local_20[0xb] = '\0';
    local_20[0xc] = 0;
    local_50 = ptVar1->tm_mday;
    local_40 = ptVar1->tm_min + 1;
    local_48 = ptVar1->tm_hour + 1;
    local_58 = ptVar1->tm_mon + 1;
    local_38 = ptVar1->tm_sec + 1;
    _snprintf(local_20,0xd,"%02d%02d%02d%02d%02d%02d");
    plVar2 = *(longlong **)(param_1 + 8);
    local_20[0xc] = 0;
    if (plVar2 == (longlong *)0x0) {
      local_58 = 0xc9;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,9);
      (**(code **)(*plVar2 + 0x80))(plVar2,local_20);
    }
    plVar2 = *(longlong **)(param_1 + 8);
    if (plVar2 == (longlong *)0x0) {
      local_58 = 0x11b;
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar2 + 0x38))(plVar2,0);
  }
  return;
}

// ==== CMsgAuction::helper_14041f2c0  @14041f2c0  [medium:callgraph-r1]  (orig: FUN_14041f2c0)
undefined8 FUN_14041f2c0(longlong param_1)

{
  int iVar1;
  __time32_t _Var2;
  
  _Var2 = _time32((__time32_t *)0x0);
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 < _Var2) {
    return 0;
  }
  if (iVar1 - _Var2 < 0x1195) {
    FUN_14041f160(param_1,iVar1 + 900);
    return 1;
  }
  if (iVar1 - _Var2 < 0x1518) {
    FUN_14041f160(param_1,_Var2 + 0x1518);
  }
  return 1;
}

// ==== CMsgAuction::ctor_or_dtor  @14045a4c0  [high:vtable-assign]  (orig: FUN_14045a4c0)
undefined8 * FUN_14045a4c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAuction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAuction::ctor_or_dtor  @14045a510  [high:vtable-assign]  (orig: FUN_14045a510)
void FUN_14045a510(undefined8 *param_1)

{
  *param_1 = CMsgAuction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAuction::vfunc_1  @14045a540  [high:rtti-vtable]  (orig: FUN_14045a540)
ulonglong FUN_14045a540(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x528);
}

// ==== CMsgAuction::ctor_or_dtor  @14045a5f0  [high:vtable-assign]  (orig: FUN_14045a5f0)
undefined8 * FUN_14045a5f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAuction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAuction::vfunc_3  @14045a640  [high:rtti-vtable]  (orig: FUN_14045a640)
void FUN_14045a640(longlong param_1,longlong param_2)

{
  short sVar1;
  longlong lVar2;
  undefined4 *puVar3;
  longlong lVar4;
  char cVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar5 = FUN_14008a710(uVar7);
  if (cVar5 != '\0') {
    return;
  }
  if (param_2 == 0) {
    return;
  }
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar8 = (longlong *)FUN_140087650(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x88))(plVar8,param_1);
  if (plVar8 == (longlong *)0x0) {
    return;
  }
  if (*(char *)((longlong)plVar8 + 0x51c) == '\0') {
    return;
  }
  plVar9 = (longlong *)FUN_1400e1e60();
  lVar4 = plVar8[0x1e2];
  lVar2 = *plVar9;
  puVar3 = *(undefined4 **)(param_1 + 0x428);
  uVar6 = (**(code **)(*plVar8 + 8))(plVar8);
  (**(code **)(lVar2 + 0x108))(plVar9,uVar6,(int)lVar4,*puVar3);
  lVar2 = *(longlong *)(param_1 + 0x428);
  sVar1 = *(short *)(lVar2 + 4);
  if (sVar1 == 0) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar7 = FUN_140087a10(uVar7);
    cVar5 = FUN_1402328d0(uVar7,plVar8,*(undefined4 *)(lVar2 + 8),*(undefined1 *)(lVar2 + 0xc),
                          *(undefined4 *)(lVar2 + 0x10),*(undefined4 *)(lVar2 + 0x14),
                          *(undefined4 *)(lVar2 + 0x18));
    if (cVar5 != '\0') {
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 1;
      goto LAB_14045a843;
    }
  }
  else if (sVar1 == 1) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar7 = FUN_140087a10(uVar7);
    cVar5 = FUN_14022f7e0(uVar7,plVar8,*(undefined4 *)(lVar2 + 8));
    if (cVar5 != '\0') {
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 1;
      goto LAB_14045a843;
    }
  }
  else if (sVar1 == 2) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar7 = FUN_140087a10(uVar7);
    cVar5 = FUN_1402335a0(uVar7,plVar8,*(undefined4 *)(lVar2 + 8),*(undefined4 *)(lVar2 + 0x10));
    if (cVar5 != '\0') {
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 1;
      goto LAB_14045a843;
    }
  }
  else {
    if (sVar1 != 3) {
      return;
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar7 = FUN_140087a10(uVar7);
    cVar5 = FUN_140231660(uVar7,plVar8,*(undefined4 *)(lVar2 + 8));
    if (cVar5 != '\0') {
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 1;
      goto LAB_14045a843;
    }
  }
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 0;
LAB_14045a843:
  (**(code **)(plVar8[2] + 0x350))(plVar8 + 2,param_1);
  return;
}

