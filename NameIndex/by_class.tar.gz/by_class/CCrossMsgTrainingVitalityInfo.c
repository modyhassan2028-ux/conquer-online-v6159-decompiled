// ==== CCrossMsgTrainingVitalityInfo::helper_1402e8ac0  @1402e8ac0  [medium:callgraph-r0]  (orig: FUN_1402e8ac0)
void FUN_1402e8ac0(longlong param_1,longlong *param_2,undefined4 param_3,int param_4,
                  undefined8 param_5)

{
  char cVar1;
  int iVar2;
  int local_30 [2];
  longlong local_28;
  undefined1 local_20 [24];
  
  if ((((param_2 != (longlong *)0x0) && (param_4 != 0)) && (*(longlong *)(param_1 + 0x98) != 0)) &&
     (iVar2 = (**(code **)(*param_2 + 8))(param_2), iVar2 != 0)) {
    local_28 = FUN_140478740(*(undefined4 *)(param_1 + 0x88),param_2,*(undefined8 *)(param_1 + 0x98)
                            );
    if (local_28 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar1 = FUN_140478800(local_28,param_3,param_4,param_5);
      if (cVar1 == '\0') {
        FUN_1404795e0(local_28);
      }
      else {
        local_30[0] = iVar2;
        FUN_1402e5330(param_1 + 8,local_20,local_30);
      }
    }
  }
  return;
}

// ==== CCrossMsgTrainingVitalityInfo::ctor_or_dtor  @14045d6c0  [high:vtable-assign]  (orig: FUN_14045d6c0)
undefined8 * FUN_14045d6c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgTrainingVitalityInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgTrainingVitalityInfo::ctor_or_dtor  @14045d710  [high:vtable-assign]  (orig: FUN_14045d710)
void FUN_14045d710(undefined8 *param_1)

{
  *param_1 = CCrossMsgTrainingVitalityInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgTrainingVitalityInfo::vfunc_1  @14045d740  [high:rtti-vtable]  (orig: FUN_14045d740)
undefined8 FUN_14045d740(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgTrainingVitalityInfo::ctor_or_dtor  @14045d920  [high:vtable-assign]  (orig: FUN_14045d920)
undefined8 * FUN_14045d920(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgTrainingVitalityInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgTrainingVitalityInfo::vfunc_3  @14045d970  [high:rtti-vtable]  (orig: FUN_14045d970)
void FUN_14045d970(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = FUN_1402af110(*(undefined8 *)(lVar4 + 0x90),uVar2,uVar1);
  if (lVar4 == 0) {
    log_InlineLogOSWARNING
              (
              "CCrossMsgTrainingVitalityInfo::Process UserManager GetCreatedOSUser failed. server id:%u, os user id:%u."
              );
  }
  else {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar5 = *(longlong *)(lVar5 + 0x1a8);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    puVar3 = *(undefined4 **)(param_1 + 0x428);
    FUN_1402e8ac0(lVar5,lVar4,*puVar3,puVar3[1],puVar3 + 2);
  }
  return;
}

// ==== CCrossMsgTrainingVitalityInfo::helper_140478800  @140478800  [medium:callgraph-r1]  (orig: FUN_140478800)
undefined8 FUN_140478800(longlong param_1,undefined4 param_2,uint param_3,longlong param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  ulonglong uVar5;
  
  *(undefined1 *)(param_1 + 0x30) = 1;
  plVar2 = *(longlong **)(param_1 + 0x20);
  uVar5 = (ulonglong)param_3;
  if (plVar2 != (longlong *)0x0) {
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,0x12);
    (**(code **)(*plVar2 + 0xa8))(plVar2,param_2);
    if (*(char *)(param_1 + 0x30) == '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  plVar2 = (longlong *)InstanceGet();
  uVar3 = (**(code **)(*plVar2 + 0x20))(plVar2,"cq_fate_player");
  *(undefined8 *)(param_1 + 0x20) = uVar3;
  plVar2 = (longlong *)InstanceGet();
  uVar3 = (**(code **)(*plVar2 + 0x20))(plVar2,"cq_fate_player");
  *(undefined8 *)(param_1 + 0x28) = uVar3;
  if (param_3 != 0) {
    puVar4 = (undefined4 *)(param_4 + 8);
    do {
      cVar1 = *(char *)(puVar4 + -2);
      if (cVar1 == '\x01') {
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),2);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[-1]);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),3);
        (**(code **)(*plVar2 + 0xa8))(plVar2,*puVar4);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),4);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[1]);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                           (*(longlong **)(param_1 + 0x20),5);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[2]);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),2);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[3]);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),3);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[4]);
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),4);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[5]);
        uVar3 = 5;
LAB_140478c4b:
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                           (*(longlong **)(param_1 + 0x28),uVar3);
        (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[6]);
      }
      else {
        if (cVar1 == '\x02') {
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),6);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[-1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),7);
          (**(code **)(*plVar2 + 0xa8))(plVar2,*puVar4);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),8);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),9);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[2]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),6);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[3]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),7);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[4]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),8);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[5]);
          uVar3 = 9;
          goto LAB_140478c4b;
        }
        if (cVar1 == '\x03') {
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),10);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[-1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xb);
          (**(code **)(*plVar2 + 0xa8))(plVar2,*puVar4);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xc);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xd);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[2]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),10);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[3]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xb);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[4]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xc);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[5]);
          uVar3 = 0xd;
          goto LAB_140478c4b;
        }
        if (cVar1 == '\x04') {
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xe);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[-1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0xf);
          (**(code **)(*plVar2 + 0xa8))(plVar2,*puVar4);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0x10);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[1]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                             (*(longlong **)(param_1 + 0x20),0x11);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[2]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xe);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[3]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0xf);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[4]);
          plVar2 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 0x28) + 0x10))
                             (*(longlong **)(param_1 + 0x28),0x10);
          (**(code **)(*plVar2 + 0xa8))(plVar2,puVar4[5]);
          uVar3 = 0x11;
          goto LAB_140478c4b;
        }
      }
      puVar4 = puVar4 + 9;
      uVar5 = uVar5 - 1;
    } while (uVar5 != 0);
  }
  return 1;
}

