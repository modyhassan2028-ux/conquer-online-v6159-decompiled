// ==== CRecordPoolMgr::helper_14027d5d0  @14027d5d0  [medium:callgraph-r3]  (orig: FUN_14027d5d0)
void FUN_14027d5d0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x69) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CRecordPoolMgr::helper_14027d630  @14027d630  [medium:callgraph-r3]  (orig: FUN_14027d630)
void FUN_14027d630(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x69) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CRecordPoolMgr::helper_14027d730  @14027d730  [medium:callgraph-r3]  (orig: FUN_14027d730)
void FUN_14027d730(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x69) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x69) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x69);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x69);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x69);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x69);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014027d754. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CRecordPoolMgr::helper_14027ea40  @14027ea40  [medium:callgraph-r1]  (orig: FUN_14027ea40)
void FUN_14027ea40(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x70);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0xd) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x69) = 0;
  return;
}

// ==== CRecordPoolMgr::helper_140280450  @140280450  [medium:callgraph-r2]  (orig: FUN_140280450)
undefined8 * FUN_140280450(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x69) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14027d730(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x69) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xd;
        plVar8 = plVar8 + 0xd;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14028063c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x69);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x69);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x69) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x69);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x69);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14028063c:
  if ((char)plVar2[0xd] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xd] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xd] == '\0') {
            *(undefined1 *)(plVar9 + 0xd) = 1;
            *(undefined1 *)(plVar8 + 0xd) = 0;
            FUN_14027d5d0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
            if ((*(char *)(*plVar9 + 0x68) != '\x01') || (*(char *)(plVar9[2] + 0x68) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x68) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x68) = 1;
                *(undefined1 *)(plVar9 + 0xd) = 0;
                FUN_14027d630(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xd) = (char)plVar8[0xd];
              *(undefined1 *)(plVar8 + 0xd) = 1;
              *(undefined1 *)(plVar9[2] + 0x68) = 1;
              FUN_14027d5d0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xd) = 0;
          }
        }
        else {
          if ((char)plVar9[0xd] == '\0') {
            *(undefined1 *)(plVar9 + 0xd) = 1;
            *(undefined1 *)(plVar8 + 0xd) = 0;
            FUN_14027d630(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x69) == '\0') {
            if ((*(char *)(plVar9[2] + 0x68) != '\x01') || (*(char *)(*plVar9 + 0x68) != '\x01')) {
              if (*(char *)(*plVar9 + 0x68) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x68) = 1;
                *(undefined1 *)(plVar9 + 0xd) = 0;
                FUN_14027d5d0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xd) = (char)plVar8[0xd];
              *(undefined1 *)(plVar8 + 0xd) = 1;
              *(undefined1 *)(*plVar9 + 0x68) = 1;
              FUN_14027d630(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xd) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xd) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 8));
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CRecordPoolMgr::helper_140283090  @140283090  [medium:callgraph-r1]  (orig: FUN_140283090)
longlong * FUN_140283090(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402810c0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x69) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x69) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x69);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x69);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x69);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x69);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140280450(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CRecordPoolMgr::helper_140284080  @140284080  [medium:callgraph-r0]  (orig: FUN_140284080)
void FUN_140284080(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140283090((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CRecordPoolMgr::helper_140284fc0  @140284fc0  [medium:callgraph-r0]  (orig: FUN_140284fc0)
undefined8 * FUN_140284fc0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14027ea40(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x69) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRecordPoolMgr::helper_140287760  @140287760  [medium:callgraph-r3]  (orig: FUN_140287760)
void FUN_140287760(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x49) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x49) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x49);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x49);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x49);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x49);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140287784. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CRecordPoolMgr::helper_140288060  @140288060  [medium:callgraph-r3]  (orig: FUN_140288060)
void FUN_140288060(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x49) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CRecordPoolMgr::helper_1402880c0  @1402880c0  [medium:callgraph-r3]  (orig: FUN_1402880c0)
void FUN_1402880c0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x49) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CRecordPoolMgr::helper_1402881a0  @1402881a0  [medium:callgraph-r3]  (orig: FUN_1402881a0)
void FUN_1402881a0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x81) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CRecordPoolMgr::helper_140288200  @140288200  [medium:callgraph-r3]  (orig: FUN_140288200)
void FUN_140288200(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x81) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CRecordPoolMgr::helper_1402882e0  @1402882e0  [medium:callgraph-r3]  (orig: FUN_1402882e0)
void FUN_1402882e0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x49) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CRecordPoolMgr::helper_140288340  @140288340  [medium:callgraph-r3]  (orig: FUN_140288340)
void FUN_140288340(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x49) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CRecordPoolMgr::helper_1402883b0  @1402883b0  [medium:callgraph-r3]  (orig: FUN_1402883b0)
void FUN_1402883b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x49) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x49) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x49);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x49);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x49);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x49);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402883d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CRecordPoolMgr::helper_140288440  @140288440  [medium:callgraph-r2]  (orig: FUN_140288440)
void FUN_140288440(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x81) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x81) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x81);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x81);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x81);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x81);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140288467. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CRecordPoolMgr::helper_140288e70  @140288e70  [medium:callgraph-r3]  (orig: FUN_140288e70)
void FUN_140288e70(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  while (lVar1 != 0) {
    if ((*(longlong *)(param_1 + 0x38) != 0) &&
       (lVar1 = *(longlong *)(param_1 + 0x38) + -1, *(longlong *)(param_1 + 0x38) = lVar1,
       lVar1 == 0)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    lVar1 = *(longlong *)(param_1 + 0x38);
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  while (lVar1 != 0) {
    lVar1 = lVar1 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar1 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar1 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  return;
}

// ==== CRecordPoolMgr::helper_140289210  @140289210  [medium:callgraph-r1]  (orig: FUN_140289210)
void FUN_140289210(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 9) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x49) = 0;
  return;
}

// ==== CRecordPoolMgr::helper_140289270  @140289270  [medium:callgraph-r1]  (orig: FUN_140289270)
void FUN_140289270(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x88);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0x10) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x81) = 0;
  return;
}

// ==== CRecordPoolMgr::helper_1402892e0  @1402892e0  [medium:callgraph-r1]  (orig: FUN_1402892e0)
void FUN_1402892e0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 9) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x49) = 0;
  return;
}

// ==== CRecordPoolMgr::helper_140289bc0  @140289bc0  [medium:callgraph-r2]  (orig: FUN_140289bc0)
undefined8 * FUN_140289bc0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x49) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402883b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x49) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 9;
        plVar8 = plVar8 + 9;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_140289dac;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x49);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x49);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_140289dac:
  if ((char)plVar2[9] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[9] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_140288060(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(*plVar9 + 0x48) != '\x01') || (*(char *)(plVar9[2] + 0x48) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x48) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_1402880c0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(plVar9[2] + 0x48) = 1;
              FUN_140288060(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        else {
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_1402880c0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(plVar9[2] + 0x48) != '\x01') || (*(char *)(*plVar9 + 0x48) != '\x01')) {
              if (*(char *)(*plVar9 + 0x48) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_140288060(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(*plVar9 + 0x48) = 1;
              FUN_1402880c0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 9) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028a030  @14028a030  [medium:callgraph-r2]  (orig: FUN_14028a030)
undefined8 * FUN_14028a030(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x49) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140287760(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x49) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 9;
        plVar8 = plVar8 + 9;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14028a21c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x49);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x49);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14028a21c:
  if ((char)plVar2[9] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[9] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_1402882e0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(*plVar9 + 0x48) != '\x01') || (*(char *)(plVar9[2] + 0x48) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x48) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_140288340(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(plVar9[2] + 0x48) = 1;
              FUN_1402882e0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        else {
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_140288340(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(plVar9[2] + 0x48) != '\x01') || (*(char *)(*plVar9 + 0x48) != '\x01')) {
              if (*(char *)(*plVar9 + 0x48) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_1402882e0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(*plVar9 + 0x48) = 1;
              FUN_140288340(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 9) = 1;
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028a940  @14028a940  [medium:callgraph-r2]  (orig: FUN_14028a940)
void FUN_14028a940(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x49);
  while (cVar1 == '\0') {
    FUN_14028a940(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x49);
  }
  return;
}

// ==== CRecordPoolMgr::helper_14028ae30  @14028ae30  [medium:callgraph-r2]  (orig: FUN_14028ae30)
void FUN_14028ae30(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x49);
  while (cVar1 == '\0') {
    FUN_14028ae30(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x49);
  }
  return;
}

// ==== CRecordPoolMgr::helper_14028c0a0  @14028c0a0  [medium:callgraph-r1]  (orig: FUN_14028c0a0)
longlong * FUN_14028c0a0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14028a940(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x49) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x49) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x49);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x49);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x49);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x49);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140289bc0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028c320  @14028c320  [medium:callgraph-r1]  (orig: FUN_14028c320)
longlong * FUN_14028c320(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14028ae30(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x49) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x49) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x49);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x49);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x49);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x49);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14028a030(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028d400  @14028d400  [medium:callgraph-r0]  (orig: FUN_14028d400)
void FUN_14028d400(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14028c0a0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CRecordPoolMgr::helper_14028d570  @14028d570  [medium:callgraph-r0]  (orig: FUN_14028d570)
void FUN_14028d570(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14028c320((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CRecordPoolMgr::helper_14028e740  @14028e740  [medium:callgraph-r0]  (orig: FUN_14028e740)
undefined8 * FUN_14028e740(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140289210(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x49) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRecordPoolMgr::helper_14028e7c0  @14028e7c0  [medium:callgraph-r0]  (orig: FUN_14028e7c0)
undefined8 * FUN_14028e7c0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402892e0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x49) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRecordPoolMgr::helper_14028e9e0  @14028e9e0  [medium:callgraph-r2]  (orig: FUN_14028e9e0)
undefined8 * FUN_14028e9e0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x81) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_50,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_50);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140288440(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x81) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x81) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x81) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0x10;
        plVar8 = plVar8 + 0x10;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14028ebeb;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x81) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x81) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x81);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x81);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x81) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x81);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x81);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14028ebeb:
  if ((char)plVar2[0x10] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0x10] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0x10] == '\0') {
            *(undefined1 *)(plVar9 + 0x10) = 1;
            *(undefined1 *)(plVar8 + 0x10) = 0;
            FUN_1402881a0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x81) == '\0') {
            if ((*(char *)(*plVar9 + 0x80) != '\x01') || (*(char *)(plVar9[2] + 0x80) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x80) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x80) = 1;
                *(undefined1 *)(plVar9 + 0x10) = 0;
                FUN_140288200(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0x10) = (char)plVar8[0x10];
              *(undefined1 *)(plVar8 + 0x10) = 1;
              *(undefined1 *)(plVar9[2] + 0x80) = 1;
              FUN_1402881a0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x10) = 0;
          }
        }
        else {
          if ((char)plVar9[0x10] == '\0') {
            *(undefined1 *)(plVar9 + 0x10) = 1;
            *(undefined1 *)(plVar8 + 0x10) = 0;
            FUN_140288200(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x81) == '\0') {
            if ((*(char *)(plVar9[2] + 0x80) != '\x01') || (*(char *)(*plVar9 + 0x80) != '\x01')) {
              if (*(char *)(*plVar9 + 0x80) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x80) = 1;
                *(undefined1 *)(plVar9 + 0x10) = 0;
                FUN_1402881a0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0x10) = (char)plVar8[0x10];
              *(undefined1 *)(plVar8 + 0x10) = 1;
              *(undefined1 *)(*plVar9 + 0x80) = 1;
              FUN_140288200(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x10) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0x10) = 1;
  }
  FUN_140288e70(plVar2 + 8);
  operator_delete((void *)plVar2[8]);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(plVar2 + 3));
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028eee0  @14028eee0  [medium:callgraph-r2]  (orig: FUN_14028eee0)
void FUN_14028eee0(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x81);
  while (cVar1 == '\0') {
    FUN_14028eee0(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    FUN_140288e70(param_2 + 8);
    operator_delete((void *)param_2[8]);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x81);
  }
  return;
}

// ==== CRecordPoolMgr::helper_14028f040  @14028f040  [medium:callgraph-r1]  (orig: FUN_14028f040)
longlong * FUN_14028f040(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar1 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar1) {
    lVar1 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar1) {
      FUN_14028eee0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar1 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar2 = param_3[1];
    FUN_140288440(param_3);
    local_28 = lVar1;
    lStack_20 = lVar2;
    FUN_14028e9e0(param_1,local_18,&local_28);
  }
  lVar1 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar1;
  return param_2;
}

// ==== CRecordPoolMgr::helper_14028f8f0  @14028f8f0  [medium:callgraph-r0]  (orig: FUN_14028f8f0)
void FUN_14028f8f0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14028f040((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CRecordPoolMgr::ctor_or_dtor  @14028fc00  [high:vtable-assign]  (orig: FUN_14028fc00)
void FUN_14028fc00(undefined8 *param_1)

{
  *param_1 = CRecordPoolMgr::vftable;
  tq::CMyCriticalSection::~CMyCriticalSection((CMyCriticalSection *)(param_1 + 0x33));
  FUN_14002de90(param_1 + 0x2a);
  operator_delete((void *)param_1[0x2a]);
  FUN_140284080(param_1 + 0x22);
  operator_delete((void *)param_1[0x22]);
  FUN_140284080(param_1 + 0x1a);
  operator_delete((void *)param_1[0x1a]);
  FUN_14028d570(param_1 + 0x12);
  operator_delete((void *)param_1[0x12]);
  FUN_14028f8f0(param_1 + 10);
  operator_delete((void *)param_1[10]);
  FUN_14028d400(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CRecordPoolMgr::helper_1402901f0  @1402901f0  [medium:callgraph-r0]  (orig: FUN_1402901f0)
undefined8 * FUN_1402901f0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140289270(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x81) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRecordPoolMgr::ctor_or_dtor  @140290270  [high:vtable-assign]  (orig: FUN_140290270)
undefined8 * FUN_140290270(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CRecordPoolMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_14028e740(param_1 + 2);
  FUN_1402901f0(param_1 + 10);
  FUN_14028e7c0(param_1 + 0x12);
  FUN_140284fc0(param_1 + 0x1a);
  FUN_140284fc0(param_1 + 0x22);
  FUN_14002e1c0(param_1 + 0x2a);
  *(undefined4 *)(param_1 + 0x32) = 0;
  tq::CMyCriticalSection::CMyCriticalSection((CMyCriticalSection *)(param_1 + 0x33),2000);
  return param_1;
}

// ==== CRecordPoolMgr::vfunc_0  @140290310  [high:rtti-vtable]  (orig: FUN_140290310)
void * FUN_140290310(void *param_1,uint param_2)

{
  FUN_14028fc00();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

