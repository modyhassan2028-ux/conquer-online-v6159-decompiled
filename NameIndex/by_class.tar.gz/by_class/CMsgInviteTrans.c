// ==== CMsgInviteTrans::helper_140380610  @140380610  [medium:callgraph-r0]  (orig: FUN_140380610)
undefined4 FUN_140380610(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x88);
}

// ==== CMsgInviteTrans::helper_1403806e0  @1403806e0  [medium:callgraph-r0]  (orig: FUN_1403806e0)
bool FUN_1403806e0(longlong param_1)

{
  return *(int *)(param_1 + 0x94) == 1;
}

// ==== CMsgInviteTrans::helper_140380910  @140380910  [medium:callgraph-r0]  (orig: FUN_140380910)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140380910(longlong param_1,longlong param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    local_468 = 0x188;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar2 = *(int *)(param_1 + 0x98);
    if (iVar2 != 0) {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x9c));
      uVar3 = FUN_140087730(uVar3);
      local_460 = 0;
      local_468 = 0;
      cVar1 = FUN_140145f60(uVar3,iVar2,param_2,0);
      if (cVar1 != '\0') {
        FUN_140455a10(local_448);
        local_468 = 0;
        iVar2 = FUN_140455ac0(local_448,2,*(undefined4 *)(param_1 + 0x40));
        if (iVar2 == 0) {
          local_468 = 0x195;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                    ((longlong *)(param_2 + 0x10),local_448);
        }
        FUN_140455a60(local_448);
      }
    }
  }
  return;
}

// ==== CMsgInviteTrans::helper_140380ce0  @140380ce0  [medium:callgraph-r0]  (orig: FUN_140380ce0)
undefined8 FUN_140380ce0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined8 *puVar4;
  longlong lVar5;
  
  puVar4 = *(undefined8 **)(param_1 + 0x20);
  if (*(undefined8 **)(param_1 + 0x28) < puVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 8);
  while( true ) {
    puVar2 = *(undefined8 **)(param_1 + 0x28);
    if (puVar2 < *(undefined8 **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    iVar3 = (**(code **)(*(longlong *)*puVar4 + 8))();
    if (iVar3 == param_2) {
      return 1;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  return 0;
}

// ==== CMsgInviteTrans::helper_140380db0  @140380db0  [medium:callgraph-r0]  (orig: FUN_140380db0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140380db0(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  int iVar11;
  longlong lVar12;
  undefined1 auStack_908 [32];
  uint local_8e8;
  undefined2 local_8e0;
  undefined4 local_8d8;
  undefined4 local_8d0;
  undefined8 local_8c8;
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_8c8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  if (param_2 == (longlong *)0x0) {
    local_8e8 = 0x75;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_2 + 8))(param_2);
    cVar1 = FUN_140380ce0();
    if (cVar1 != '\0') {
      iVar11 = 0;
      lVar10 = 0;
      piVar6 = (int *)(param_1 + 0x68);
      do {
        if ((piVar6[-8] == -1) || (*piVar6 == -1)) break;
        iVar11 = iVar11 + 1;
        lVar10 = lVar10 + 1;
        piVar6 = piVar6 + 1;
      } while (lVar10 < 8);
      if (iVar11 - 1U < 8) {
        iVar11 = tq::RandGet(iVar11);
        lVar12 = (longlong)iVar11;
        lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x9c));
        if (*(longlong *)(lVar10 + 0x98) == 0) {
          local_8e8 = 0x131;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar10 = (**(code **)(**(longlong **)(lVar10 + 0x98) + 0x10))
                           (*(longlong **)(lVar10 + 0x98),*(undefined4 *)(param_1 + 0x38),1);
        if ((lVar10 != 0) &&
           (cVar1 = FUN_1402c3cc0(lVar10,*(undefined4 *)(param_1 + 0x48 + lVar12 * 4),
                                  *(undefined4 *)(param_1 + 0x68 + lVar12 * 4)), cVar1 != '\0')) {
          cVar1 = FUN_1401a4030(param_2,*(undefined4 *)(param_1 + 0x38));
          if (cVar1 == '\0') {
            FUN_140179040(param_2,*(undefined4 *)(param_1 + 0x38));
          }
          else {
            iVar11 = (**(code **)(**(longlong **)(lVar10 + 0x58) + 0x10))
                               (*(longlong **)(lVar10 + 0x58),3);
            if ((iVar11 == 0x814) && (cVar1 = FUN_1401a4030(param_2,900000), cVar1 == '\0')) {
              FUN_140179040(param_2,900000);
              return;
            }
            lVar10 = (**(code **)(param_2[2] + 0x160))(param_2 + 2);
            if (lVar10 != 0) {
              uVar3 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
              uVar4 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
              cVar1 = FUN_1402c3cc0(lVar10,uVar4,uVar3);
              if (cVar1 == '\0') {
                pIVar7 = theInstance();
                lVar12 = param_2[2];
                uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_INVALID_COORDINATE");
                (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar8);
                cVar1 = FUN_14016cbd0(lVar10);
                if (cVar1 == '\0') {
                  uVar3 = (**(code **)(**(longlong **)(lVar10 + 0x58) + 0x10))
                                    (*(longlong **)(lVar10 + 0x58),0xb);
                  uVar4 = (**(code **)(**(longlong **)(lVar10 + 0x58) + 0x10))
                                    (*(longlong **)(lVar10 + 0x58),0xc);
                  cVar1 = FUN_1402c3cc0(lVar10,uVar3,uVar4);
                  if (cVar1 != '\0') {
                    uVar5 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
                    local_8e8 = 0;
                    FUN_1401732e0(param_2,uVar5,uVar3,uVar4);
                  }
                }
                pIVar7 = theInstance();
                uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x9c));
                plVar9 = (longlong *)FUN_140087650(uVar8);
                lVar10 = *plVar9;
                uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_INVALID_COORDINATE");
                (**(code **)(lVar10 + 0x50))(plVar9,param_2,uVar8);
              }
              else {
                cVar1 = FUN_14016cbd0(lVar10);
                if (cVar1 == '\0') {
                  uVar3 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
                  uVar4 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
                  uVar5 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
                  local_8e8 = 1;
                  FUN_1401732e0(param_2,uVar5,uVar4,uVar3);
                }
                local_8e8 = local_8e8 & 0xffffff00;
                iVar11 = FUN_1401c55b0(param_2,*(undefined4 *)(param_1 + 0x38),
                                       *(undefined4 *)(param_1 + 0x48 + lVar12 * 4),
                                       *(undefined4 *)(param_1 + 0x68 + lVar12 * 4));
                if (iVar11 == 0) {
                  FUN_140455a10(local_8b8);
                  local_8e8 = 0;
                  iVar11 = FUN_140455ac0(local_8b8,2,*(undefined4 *)(param_1 + 0x40));
                  if (iVar11 == 0) {
                    local_8e8 = 0xd2;
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  else {
                    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8b8);
                  }
                  FUN_140362560(local_488);
                  uVar2 = (**(code **)(param_2[2] + 0x50))(param_2 + 2);
                  uVar3 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
                  uVar4 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
                  uVar5 = (**(code **)(*param_2 + 8))(param_2);
                  local_8d0 = 0;
                  local_8d8 = 1;
                  local_8e0 = 1000;
                  local_8e8 = CONCAT22(local_8e8._2_2_,uVar2);
                  iVar11 = FUN_140362620(local_488,uVar5,uVar4,uVar3);
                  if (iVar11 != 0) {
                    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_488);
                  }
                  FUN_1403625e0(local_488);
                  FUN_140455a60(local_8b8);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgInviteTrans::ctor_or_dtor  @140455a10  [high:vtable-assign]  (orig: FUN_140455a10)
undefined8 * FUN_140455a10(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInviteTrans::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgInviteTrans::ctor_or_dtor  @140455a60  [high:vtable-assign]  (orig: FUN_140455a60)
void FUN_140455a60(undefined8 *param_1)

{
  *param_1 = CMsgInviteTrans::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgInviteTrans::vfunc_1  @140455a90  [high:rtti-vtable]  (orig: FUN_140455a90)
ulonglong FUN_140455a90(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x466);
}

// ==== CMsgInviteTrans::ctor_or_dtor  @140455b40  [high:vtable-assign]  (orig: FUN_140455b40)
undefined8 * FUN_140455b40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInviteTrans::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgInviteTrans::vfunc_3  @140455b90  [high:rtti-vtable]  (orig: FUN_140455b90)
void FUN_140455b90(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = *(longlong **)(lVar4 + 0x90);
  if (plVar5 != (longlong *)0x0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0xb8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = *(longlong *)(lVar4 + 0xb8);
    if (((lVar4 != 0) &&
        (plVar5 = (longlong *)(**(code **)(*plVar5 + 0x88))(plVar5,param_1),
        plVar5 != (longlong *)0x0)) &&
       (lVar4 = FUN_14021b560(lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8)), lVar4 != 0
       )) {
      uVar2 = (**(code **)(*plVar5 + 8))(plVar5);
      cVar1 = FUN_140380ce0(lVar4,uVar2);
      if (((cVar1 != '\0') && (**(char **)(param_1 + 0x428) == '\x01')) &&
         (iVar3 = FUN_140380610(lVar4), *(int *)(*(longlong *)(param_1 + 0x428) + 8) == iVar3)) {
        cVar1 = FUN_1403806e0(lVar4);
        if (cVar1 != '\0') {
          FUN_140380910(lVar4,plVar5);
          return;
        }
        FUN_140380db0(lVar4,plVar5);
      }
    }
  }
  return;
}

