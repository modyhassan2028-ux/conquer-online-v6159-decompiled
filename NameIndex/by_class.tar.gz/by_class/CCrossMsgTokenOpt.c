// ==== CCrossMsgTokenOpt::ctor_or_dtor  @140460a10  [high:vtable-assign]  (orig: FUN_140460a10)
undefined8 * FUN_140460a10(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgTokenOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgTokenOpt::ctor_or_dtor  @140460a60  [high:vtable-assign]  (orig: FUN_140460a60)
void FUN_140460a60(undefined8 *param_1)

{
  *param_1 = CCrossMsgTokenOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgTokenOpt::vfunc_1  @140460a90  [high:rtti-vtable]  (orig: FUN_140460a90)
ulonglong FUN_140460a90(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c67);
}

// ==== CCrossMsgTokenOpt::ctor_or_dtor  @140460b20  [high:vtable-assign]  (orig: FUN_140460b20)
undefined8 * FUN_140460b20(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgTokenOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgTokenOpt::vfunc_3  @140460b70  [high:rtti-vtable]  (orig: FUN_140460b70)
void FUN_140460b70(longlong param_1)

{
  int iVar1;
  undefined1 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  
  if (((*(longlong *)(param_1 + 0x428) != 0) && (iVar1 = *(int *)(param_1 + 0x420), iVar1 != 0)) &&
     (plVar3 = (longlong *)FUN_140087ed0(), plVar3 != (longlong *)0x0)) {
    puVar2 = *(undefined1 **)(param_1 + 0x428);
    switch(*puVar2) {
    case 0:
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar5 = (longlong *)FUN_140087650(uVar4);
      lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,iVar1);
      if (lVar6 != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140460c1c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(*plVar3 + 0x578))(plVar3,iVar1);
        return;
      }
      break;
    case 1:
                    /* WARNING: Could not recover jumptable at 0x000140460c3a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5b0))(plVar3,iVar1);
      return;
    case 2:
                    /* WARNING: Could not recover jumptable at 0x000140460c60. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5c0))
                (plVar3,iVar1,*(undefined4 *)(puVar2 + 4),*(undefined4 *)(puVar2 + 8));
      return;
    case 3:
                    /* WARNING: Could not recover jumptable at 0x000140460c86. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5c8))
                (plVar3,iVar1,*(undefined4 *)(puVar2 + 4),*(undefined4 *)(puVar2 + 8));
      return;
    case 4:
                    /* WARNING: Could not recover jumptable at 0x000140460cac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5d0))
                (plVar3,iVar1,*(undefined4 *)(puVar2 + 4),*(undefined4 *)(puVar2 + 8));
      return;
    case 5:
                    /* WARNING: Could not recover jumptable at 0x000140460cce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5b8))(plVar3,iVar1,*(undefined4 *)(puVar2 + 8));
      return;
    case 6:
                    /* WARNING: Could not recover jumptable at 0x000140460cf0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5d8))(plVar3,iVar1,*(undefined4 *)(puVar2 + 8));
      return;
    case 7:
                    /* WARNING: Could not recover jumptable at 0x000140460d0e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5e0))(plVar3,iVar1);
      return;
    case 8:
                    /* WARNING: Could not recover jumptable at 0x000140460d2c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5e8))(plVar3,iVar1);
      return;
    case 9:
                    /* WARNING: Could not recover jumptable at 0x000140460d4a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar3 + 0x5f8))(plVar3,iVar1);
      return;
    case 10:
      (**(code **)(*plVar3 + 0x5f0))(plVar3,iVar1,puVar2[8]);
    }
  }
  return;
}

