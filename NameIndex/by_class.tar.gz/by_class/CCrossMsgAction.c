// ==== CCrossMsgAction::ctor_or_dtor  @14045fbe0  [high:vtable-assign]  (orig: FUN_14045fbe0)
undefined8 * FUN_14045fbe0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgAction::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x35),0x3db,true);
  return param_1;
}

// ==== CCrossMsgAction::ctor_or_dtor  @14045fc60  [high:vtable-assign]  (orig: FUN_14045fc60)
void FUN_14045fc60(undefined8 *param_1)

{
  *param_1 = CCrossMsgAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CCrossMsgAction::vfunc_1  @140460000  [high:rtti-vtable]  (orig: FUN_140460000)
ulonglong FUN_140460000(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x271a);
}

// ==== CCrossMsgAction::ctor_or_dtor  @140460030  [high:vtable-assign]  (orig: FUN_140460030)
undefined8 * FUN_140460030(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgAction::vfunc_3  @140460090  [high:rtti-vtable]  (orig: FUN_140460090)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140460090(longlong *param_1)

{
  short sVar1;
  ushort uVar2;
  longlong lVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  undefined1 auStack_4d8 [32];
  uint local_4b8;
  undefined2 local_4b0;
  undefined8 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_480 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  local_488 = param_1;
  lVar6 = FUN_140008520((int)param_1[0x82]);
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    local_4b8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x98))
                     (*(longlong **)(lVar6 + 0x90),(int)param_1[0x84]);
  if (plVar7 == (longlong *)0x0) {
    return;
  }
  sVar1 = *(short *)(param_1[0x85] + 0x14);
  if ((sVar1 != 0x5d) && (sVar1 != 0xae)) {
    *(int *)(param_1[0x85] + 4) = (int)param_1[0x84];
  }
  uVar2 = *(ushort *)(param_1[0x85] + 0x14);
  if (uVar2 < 0x19b) {
    if (uVar2 == 0x19a) goto switchD_140460191_caseD_5d;
    switch(uVar2) {
    case 0x5d:
    case 0x66:
    case 0x6a:
    case 0x73:
    case 0x75:
    case 0x7b:
    case 0x7f:
    case 0x81:
    case 0x83:
    case 0x85:
    case 0x88:
    case 0x8b:
    case 0x8d:
    case 0x8e:
    case 0x90:
    case 0x94:
    case 0x95:
    case 0x96:
    case 0xcd:
    case 0xce:
      goto switchD_140460191_caseD_5d;
    }
  }
  else if (uVar2 == 0x1a4) goto switchD_140460191_caseD_5d;
  (**(code **)(plVar7[2] + 0x380))();
switchD_140460191_caseD_5d:
  switch(*(undefined2 *)(param_1[0x85] + 0x14)) {
  case 0x4c:
    FUN_140362560(local_478);
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    local_490 = 0;
    local_498 = 0;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = 0x4c;
    local_4b8 = local_4b8 & 0xffff0000;
    iVar5 = FUN_140362700(local_478,uVar4,0,0);
    if (iVar5 != 0) {
      (**(code **)(*param_1 + 0x20))(param_1,local_478);
    }
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x180))(plVar11,uVar4);
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0xd0))(plVar11,uVar4);
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x1d8))(plVar11,uVar4);
    plVar11 = (longlong *)FUN_1400e1de0();
    lVar6 = *plVar11;
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x10))(plVar11,uVar4);
    FUN_1403625e0(local_478);
    break;
  case 0x75:
    uVar10 = FUN_140008520((int)param_1[0x82]);
    plVar11 = (longlong *)FUN_140087650(uVar10);
    lVar6 = (**(code **)(*plVar11 + 0x98))(plVar11,*(undefined4 *)(param_1[0x85] + 8));
    if (lVar6 != 0) {
      FUN_14032b2e0(lVar6,plVar7);
      pIVar8 = theInstance();
      lVar3 = *(longlong *)(lVar6 + 0x10);
      uVar10 = (**(code **)(plVar7[2] + 0x18))();
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_QUERYEQUIPMENT_HINT");
      (**(code **)(lVar3 + 0x358))(lVar6 + 0x10,uVar9,uVar10);
    }
    break;
  case 0x7b:
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    lVar3 = param_1[0x85];
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x1e0))(plVar11,uVar4,*(undefined4 *)(lVar3 + 8));
    break;
  case 0x94:
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    lVar3 = param_1[0x85];
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 400))(plVar11,uVar4,*(undefined4 *)(lVar3 + 8));
    break;
  case 0x95:
    plVar11 = (longlong *)FUN_1400e1de0();
    lVar6 = *plVar11;
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x10))(plVar11,uVar4);
    break;
  case 0x98:
    plVar11 = (longlong *)FUN_1401183a0();
    lVar6 = *plVar11;
    lVar3 = param_1[0x85];
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0xd8))(plVar11,uVar4,*(undefined4 *)(lVar3 + 8));
    break;
  case 0x136:
    uVar10 = FUN_140008520((int)param_1[0x82]);
    plVar11 = (longlong *)FUN_140087650(uVar10);
    lVar6 = (**(code **)(*plVar11 + 0x98))(plVar11,*(undefined4 *)(param_1[0x85] + 8));
    if (lVar6 != 0) {
      FUN_14039ed70(local_478);
      iVar5 = FUN_14039eef0(local_478,lVar6 + 0x10,1);
      if (iVar5 != 0) {
        (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,local_478);
      }
      FUN_14039edf0(local_478);
    }
  }
  return;
}

