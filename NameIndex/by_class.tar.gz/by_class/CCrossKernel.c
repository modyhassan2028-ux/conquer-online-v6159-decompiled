// ==== CCrossKernel::helper_14004e700  @14004e700  [medium:callgraph-r1]  (orig: FUN_14004e700)
void FUN_14004e700(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x24) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  return;
}

// ==== CCrossKernel::helper_140051fb0  @140051fb0  [medium:callgraph-r1]  (orig: FUN_140051fb0)
longlong * FUN_140051fb0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14004ec50(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x25) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x25);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x25);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x25);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x25);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140050ff0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CCrossKernel::helper_140052160  @140052160  [medium:callgraph-r0]  (orig: FUN_140052160)
void FUN_140052160(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140051fb0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CCrossKernel::ctor_or_dtor  @140053c30  [high:vtable-assign]  (orig: FUN_140053c30)
void FUN_140053c30(undefined8 *param_1)

{
  *param_1 = CCrossKernel::vftable;
  FUN_1400526a0(param_1 + 0x13);
  operator_delete((void *)param_1[0x13]);
  FUN_140052160(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_140050610(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CCrossKernel::vfunc_0  @140054010  [high:rtti-vtable]  (orig: FUN_140054010)
void * FUN_140054010(void *param_1,uint param_2)

{
  FUN_140053c30();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossKernel::helper_140054760  @140054760  [medium:callgraph-r0]  (orig: FUN_140054760)
undefined8 * FUN_140054760(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14004e700(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CCrossKernel::ctor_or_dtor  @140054860  [high:vtable-assign]  (orig: FUN_140054860)
undefined8 * FUN_140054860(undefined8 *param_1)

{
  *param_1 = CCrossKernel::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  FUN_1400546e0(param_1 + 3);
  FUN_140054760(param_1 + 0xb);
  FUN_1400547e0(param_1 + 0x13);
  return param_1;
}

// ==== CCrossKernel::ctor_or_dtor  @1400548c0  [high:vtable-assign]  (orig: FUN_1400548c0)
undefined8 * FUN_1400548c0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0xd8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CCrossKernel::vftable;
    puVar1[1] = 0;
    puVar1[2] = 0;
    FUN_1400546e0(puVar1 + 3);
    FUN_140054760(puVar1 + 0xb);
    FUN_1400547e0(puVar1 + 0x13);
  }
  return puVar1;
}

