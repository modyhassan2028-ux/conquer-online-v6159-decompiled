// ==== CMsgNpc::helper_1402bbb70  @1402bbb70  [medium:callgraph-r0]  (orig: FUN_1402bbb70)
ulonglong FUN_1402bbb70(longlong *param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  undefined8 local_res8;
  
  local_res8 = 0;
  cVar1 = (**(code **)(*param_1 + 0x60))();
  if (cVar1 == '\0') {
    iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
    if (iVar2 != 0x20) {
      iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
      if (iVar2 != 0x21) {
        iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
        if (iVar2 != 0x22) {
          iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
          if (iVar2 != 0x23) {
            iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
            if (iVar2 != 0x24) {
              iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
              if (iVar2 != 0x25) {
                cVar1 = FUN_1402ba6c0(param_1);
                if (cVar1 == '\0') {
                  uVar4 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))
                                    ((longlong *)param_1[0xc],4);
                  if ((int)uVar4 != 0x71) goto LAB_1402bbca4;
                }
              }
            }
          }
        }
      }
    }
  }
  uVar4 = (**(code **)(param_1[2] + 0x220))(param_1 + 2);
  if ((char)uVar4 != '\0') {
    uVar4 = (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_res8);
    if ((char)uVar4 != '\0') {
      cVar1 = FUN_140167b70(local_res8);
      if (cVar1 != '\0') {
        uVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x1b);
        uVar4 = (ulonglong)(uVar3 >> 7);
        if ((uVar3 >> 7 & 1) == 0) goto LAB_1402bbca4;
      }
      uVar5 = (**(code **)(*param_1 + 0x68))(param_1);
      uVar4 = FUN_140470df0(uVar5,local_res8);
      return uVar4;
    }
  }
LAB_1402bbca4:
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMsgNpc::helper_1402bbfe0  @1402bbfe0  [medium:callgraph-r0]  (orig: FUN_1402bbfe0)
undefined8 FUN_1402bbfe0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  undefined8 uVar9;
  
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),0x1b)
  ;
  if ((uVar2 >> 1 & 1) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                      (*(longlong **)(param_1 + 0x60),0x1c);
    if (iVar3 != 0) {
      if (*(char *)(param_1 + 0x68) != '\0') {
        plVar8 = (longlong *)(param_1 + 0x10);
        iVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x80))(plVar8);
        if (iVar4 != 0) {
          uVar2 = (**(code **)(*plVar8 + 0x80))(plVar8);
          uVar5 = (**(code **)(*plVar8 + 0x78))(plVar8);
          if (uVar5 < uVar2) {
            return 0;
          }
        }
      }
      if (param_2 != (longlong *)0x0) {
        plVar8 = (longlong *)FUN_140087d40();
        lVar1 = *plVar8;
        uVar6 = FUN_140167b40(param_2);
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        plVar8 = (longlong *)(**(code **)(lVar1 + 0x18))(plVar8,iVar3,uVar7,0,uVar6,0);
        if (plVar8 != (longlong *)0x0) {
          uVar9 = (**(code **)(*plVar8 + 8))(plVar8);
          return uVar9;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    }
  }
  return 0;
}

// ==== CMsgNpc::helper_1402bc170  @1402bc170  [medium:callgraph-r0]  (orig: FUN_1402bc170)
longlong FUN_1402bc170(longlong param_1,longlong *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar1 = 0;
  }
  else {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),5);
  }
  iVar1 = iVar1 / 10 + 0xb13f0;
  if ((iVar1 != 0) && (param_2 != (longlong *)0x0)) {
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    lVar4 = *plVar5;
    uVar2 = FUN_140167b40(param_2);
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    lVar4 = (**(code **)(lVar4 + 0x18))(plVar5,iVar1,uVar3,0,uVar2,0);
    if (lVar4 != 0) {
      return lVar4;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgNpc::helper_1402bc540  @1402bc540  [medium:callgraph-r0]  (orig: FUN_1402bc540)
undefined8 FUN_1402bc540(longlong *param_1)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  longlong *plVar5;
  
  uVar4 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x1b);
  if ((uVar4 & 0x20) == 0) {
    return 0;
  }
  cVar2 = (**(code **)(*param_1 + 0x78))(param_1);
  if (cVar2 != '\0') {
    plVar5 = (longlong *)(**(code **)(*param_1 + 0x80))(param_1);
    lVar1 = *plVar5;
    uVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],1);
    cVar2 = (**(code **)(lVar1 + 0x58))(plVar5,uVar3,(int)param_1[0xb],0x14);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  return 1;
}

// ==== CMsgNpc::helper_1402c6150  @1402c6150  [medium:callgraph-r0]  (orig: FUN_1402c6150)
longlong FUN_1402c6150(longlong param_1,int param_2,int param_3,int param_4,int param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  uint uVar6;
  uint uVar7;
  longlong local_18 [2];
  
  if (param_4 != 0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x74));
    if (*(longlong *)(lVar4 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x88) + 0x20))
                       (*(longlong **)(lVar4 + 0x88),param_4);
    if (plVar5 != (longlong *)0x0) {
      local_18[0] = 0;
      cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,local_18);
      if (((cVar1 != '\0') &&
          (lVar4 = (**(code **)(*(longlong *)(local_18[0] + 0x10) + 0x160))(local_18[0] + 0x10),
          lVar4 != 0)) && (lVar4 == param_1)) {
        iVar2 = (**(code **)(*(longlong *)(local_18[0] + 0x10) + 0x40))(local_18[0] + 0x10);
        iVar3 = (**(code **)(*(longlong *)(local_18[0] + 0x10) + 0x48))(local_18[0] + 0x10);
        uVar7 = iVar2 / 0x12 - param_2 / 0x12;
        uVar6 = (int)uVar7 >> 0x1f;
        if (((int)((uVar7 ^ uVar6) - uVar6) < 2) &&
           (uVar7 = iVar3 / 0x12 - param_3 / 0x12, uVar6 = (int)uVar7 >> 0x1f,
           (int)((uVar7 ^ uVar6) - uVar6) < 2)) {
          iVar2 = (**(code **)(*(longlong *)(local_18[0] + 0x10) + 0x40))(local_18[0] + 0x10);
          uVar6 = param_2 - iVar2 >> 0x1f;
          iVar3 = (param_2 - iVar2 ^ uVar6) - uVar6;
          iVar2 = (**(code **)(*(longlong *)(local_18[0] + 0x10) + 0x48))();
          uVar6 = param_3 - iVar2 >> 0x1f;
          iVar2 = (param_3 - iVar2 ^ uVar6) - uVar6;
          if (param_5 < 1) {
            return local_18[0];
          }
          if (iVar2 < iVar3) {
            iVar2 = iVar3;
          }
          if (iVar2 <= param_5) {
            return local_18[0];
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgNpc::helper_14037d410  @14037d410  [medium:callgraph-r0]  (orig: FUN_14037d410)
void FUN_14037d410(longlong param_1,int param_2)

{
  int iVar1;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x30))(param_1 + 0x10);
                    /* WARNING: Could not recover jumptable at 0x00014037d48f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
            (*(longlong **)(param_1 + 0x60),5,(param_2 % 10) % 10 + (iVar1 / 10) * 10);
  return;
}

// ==== CMsgNpc::ctor_or_dtor  @14037d4a0  [high:vtable-assign]  (orig: FUN_14037d4a0)
undefined8 * FUN_14037d4a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNpc::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgNpc::ctor_or_dtor  @14037d4f0  [high:vtable-assign]  (orig: FUN_14037d4f0)
void FUN_14037d4f0(undefined8 *param_1)

{
  *param_1 = CMsgNpc::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgNpc::vfunc_1  @14037d5b0  [high:rtti-vtable]  (orig: FUN_14037d5b0)
undefined8 FUN_14037d5b0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgNpc::ctor_or_dtor  @14037d5e0  [high:vtable-assign]  (orig: FUN_14037d5e0)
undefined8 * FUN_14037d5e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNpc::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgNpc::vfunc_3  @14037d630  [high:rtti-vtable]  (orig: FUN_14037d630)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14037d630(longlong param_1,longlong param_2)

{
  short sVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  undefined8 uVar14;
  char *_Source;
  undefined8 uVar15;
  undefined1 auStack_68 [32];
  undefined4 local_48;
  longlong *local_38;
  longlong *local_30;
  undefined8 local_28;
  ulonglong local_20;
  
  if (param_2 == 0) {
    return;
  }
  local_20 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar10 + 0x90) == 0) {
    local_48 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(lVar10 + 0x90) + 0x88))
                      (*(longlong **)(lVar10 + 0x90),param_1);
  if (plVar11 == (longlong *)0x0) {
    return;
  }
  plVar12 = (longlong *)FUN_1400e1e60();
  lVar3 = plVar11[0x1e2];
  lVar10 = *plVar12;
  puVar2 = *(undefined4 **)(param_1 + 0x428);
  uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
  (**(code **)(lVar10 + 0x108))(plVar12,uVar5,(int)lVar3,*puVar2);
  cVar4 = (**(code **)(plVar11[2] + 0x220))(plVar11 + 2);
  if (cVar4 == '\0') {
    pIVar13 = theInstance();
    lVar10 = plVar11[2];
    uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_DIE");
    (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14);
    return;
  }
  cVar4 = FUN_140167b70(plVar11);
  if (cVar4 != '\0') {
    local_30 = (longlong *)0x0;
    uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar12 = (longlong *)FUN_1400875f0(uVar14);
    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
    plVar12 = (longlong *)
              (**(code **)(*plVar12 + 0x40))
                        (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (plVar12 == (longlong *)0x0) {
      return;
    }
    cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_30);
    if (cVar4 == '\0') {
      return;
    }
    uVar6 = (**(code **)(*(longlong *)local_30[0xc] + 0x10))((longlong *)local_30[0xc],0x1b);
    if ((uVar6 >> 7 & 1) == 0) {
      return;
    }
  }
  lVar10 = *(longlong *)(param_1 + 0x428);
  sVar1 = *(short *)(lVar10 + 0xc);
  if (sVar1 != 0) {
    if (sVar1 == 3) {
      uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar12 = (longlong *)FUN_1400875f0(uVar14);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)
                (**(code **)(*plVar12 + 0x40))
                          (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (plVar12 == (longlong *)0x0) {
        return;
      }
      cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_38);
      if (cVar4 == '\0') {
        return;
      }
      iVar7 = (**(code **)(local_38[2] + 0x168))(local_38 + 2);
      iVar8 = (**(code **)(plVar11[2] + 0x168))(plVar11 + 2);
      if (iVar8 != iVar7) {
        return;
      }
      if (*(int *)((longlong)local_38 + 0xb4) != 0) {
        return;
      }
      cVar4 = FUN_1402bc540();
      if (cVar4 == '\0') {
        return;
      }
      cVar4 = FUN_1402be0d0(local_38,plVar11,0);
      if (cVar4 == '\0') {
        return;
      }
      uVar6 = (**(code **)(*(longlong *)local_38[0xc] + 0x10))((longlong *)local_38[0xc],0x1b);
      if ((uVar6 >> 1 & 1) != 0) {
        if (0x27 < (ulonglong)(plVar11[0x185] - plVar11[0x184] >> 2)) goto LAB_14037dbfb;
        iVar7 = FUN_1402bbfe0(local_38,plVar11);
        if (iVar7 == 0) {
          pIVar13 = theInstance();
          lVar10 = plVar11[2];
          uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_ITEM_DAMAGED");
          (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14);
        }
        else {
          plVar12 = (longlong *)FUN_140087d40();
          plVar12 = (longlong *)(**(code **)(*plVar12 + 0x60))(plVar12,iVar7);
          if (plVar12 != (longlong *)0x0) {
            uVar5 = (**(code **)(*plVar12 + 8))(plVar12);
            FUN_140340de0(plVar11,uVar5,1);
            pIVar13 = theInstance();
            lVar10 = plVar11[2];
            uVar14 = FUN_140100430(plVar12,0x65);
            uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_GOT_ITEM");
            (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar15,uVar14);
          }
        }
      }
      cVar4 = FUN_1402bf900(local_38);
      if (cVar4 != '\0') {
        return;
      }
    }
    else {
      if (sVar1 == 4) {
        uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar12 = (longlong *)FUN_1400875f0(uVar14);
        plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
        plVar12 = (longlong *)
                  (**(code **)(*plVar12 + 0x40))
                            (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        if (plVar12 == (longlong *)0x0) {
          return;
        }
        cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_38);
        if (cVar4 == '\0') {
          return;
        }
        iVar7 = (**(code **)(local_38[2] + 0x168))(local_38 + 2);
        iVar8 = (**(code **)(plVar11[2] + 0x168))(plVar11 + 2);
        if (iVar8 != iVar7) {
          return;
        }
        uVar6 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 0xe) / 10;
        iVar7 = (**(code **)(local_38[2] + 0x30))(local_38 + 2);
        if (iVar7 / 10 == uVar6) {
          FUN_14037d410(local_38,uVar6);
        }
        (**(code **)(local_38[2] + 0x370))
                  (local_38 + 2,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8),
                   *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10));
        return;
      }
      if (sVar1 != 6) {
        log_InlineLogERROR(&DAT_14075bfc8);
        return;
      }
      uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar12 = (longlong *)FUN_1400875f0(uVar14);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)
                (**(code **)(*plVar12 + 0x40))
                          (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (plVar12 == (longlong *)0x0) {
        return;
      }
      cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_38);
      if (cVar4 == '\0') {
        return;
      }
      iVar7 = (**(code **)(local_38[2] + 0x168))(local_38 + 2);
      iVar8 = (**(code **)(plVar11[2] + 0x168))(plVar11 + 2);
      if (iVar8 != iVar7) {
        return;
      }
      if (*(int *)((longlong)local_38 + 0xb4) != 0) {
        return;
      }
      iVar7 = (**(code **)(*(longlong *)local_38[0xc] + 0x10))((longlong *)local_38[0xc],4);
      if (((iVar7 != 0x19) &&
          (iVar7 = (**(code **)(*(longlong *)local_38[0xc] + 0x10))((longlong *)local_38[0xc],4),
          iVar7 != 0x33)) &&
         (iVar7 = (**(code **)(*(longlong *)local_38[0xc] + 0x10))((longlong *)local_38[0xc],4),
         iVar7 != 0x65)) {
        return;
      }
      cVar4 = FUN_1402be0d0(local_38,plVar11,0);
      if (cVar4 == '\0') {
        pIVar13 = theInstance();
        lVar10 = plVar11[2];
        uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_PUSHAWAY_NPC_ERROR");
        (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14);
        return;
      }
      if (0x27 < (ulonglong)(plVar11[0x185] - plVar11[0x184] >> 2)) {
LAB_14037dbfb:
        pIVar13 = theInstance();
        lVar10 = plVar11[2];
        uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_YOUR_BAG_FULL");
        (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14);
        return;
      }
      plVar12 = (longlong *)FUN_1402bc170(local_38,plVar11);
      if (plVar12 == (longlong *)0x0) {
        return;
      }
      local_30 = (longlong *)0x0;
      local_28 = 0;
      _Source = (char *)(**(code **)(local_38[2] + 0x18))();
      strncpy((char *)&local_30,_Source,0x10);
      cVar4 = FUN_1402bf900(local_38);
      if (cVar4 != '\0') {
        uVar5 = (**(code **)(*plVar12 + 8))(plVar12);
        FUN_140340de0(plVar11,uVar5,1);
        pIVar13 = theInstance();
        lVar10 = plVar11[2];
        uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_PUSHAWAY_NPC");
        (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14,&local_30);
        return;
      }
    }
    pIVar13 = theInstance();
    lVar10 = plVar11[2];
    uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_DELETE_FAILED");
    (**(code **)(lVar10 + 0x358))(plVar11 + 2,uVar14);
    return;
  }
  local_38 = (longlong *)0x0;
  if (*(short *)(lVar10 + 0xe) == 0) {
    uVar5 = (**(code **)(plVar11[2] + 0x48))(plVar11 + 2);
    uVar9 = (**(code **)(plVar11[2] + 0x40))(plVar11 + 2);
    uVar14 = (**(code **)(plVar11[2] + 0x160))(plVar11 + 2);
    local_48 = 0x14;
    lVar10 = FUN_1402c6150(uVar14,uVar9,uVar5,*(undefined4 *)(lVar10 + 4));
    if (lVar10 != 0) {
      uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar12 = (longlong *)FUN_1400875f0(uVar14);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)
                (**(code **)(*plVar12 + 0x40))
                          (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (plVar12 == (longlong *)0x0) {
        return;
      }
      cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_38);
      if (cVar4 == '\0') {
        return;
      }
      iVar7 = (**(code **)(local_38[2] + 0x168))(local_38 + 2);
      iVar8 = (**(code **)(plVar11[2] + 0x168))(plVar11 + 2);
      plVar12 = local_38;
      if (iVar8 != iVar7) {
        return;
      }
      goto LAB_14037df46;
    }
    plVar12 = (longlong *)CurrentInstanceGet();
    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x12);
    if (plVar12 == (longlong *)0x0) {
      return;
    }
    lVar10 = *plVar12;
    lVar3 = *(longlong *)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
    cVar4 = (**(code **)(lVar10 + 0x68))(plVar12,uVar5,*(undefined4 *)(lVar3 + 4));
    if (cVar4 == '\0') {
      lVar10 = *plVar12;
      lVar3 = *(longlong *)(param_1 + 0x428);
      uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
      cVar4 = (**(code **)(lVar10 + 0x70))(plVar12,uVar5,*(undefined4 *)(lVar3 + 4));
      if (cVar4 == '\0') {
        return;
      }
    }
    local_30 = (longlong *)0x0;
    uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar12 = (longlong *)FUN_1400875f0(uVar14);
    plVar12 = (longlong *)
              (**(code **)(*plVar12 + 0x20))
                        (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (plVar12 == (longlong *)0x0) {
      return;
    }
    cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_30);
    if (cVar4 == '\0') {
      return;
    }
    cVar4 = (**(code **)(*local_30 + 0x70))();
    plVar12 = local_30;
  }
  else {
    if (*(short *)(lVar10 + 0xe) != 1) {
      return;
    }
    uVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar12 = (longlong *)FUN_1400875f0(uVar14);
    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x30))(plVar12);
    plVar12 = (longlong *)
              (**(code **)(*plVar12 + 0x40))
                        (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (plVar12 == (longlong *)0x0) {
      return;
    }
    cVar4 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1040,&local_38);
    plVar12 = local_38;
  }
  if (cVar4 == '\0') {
    return;
  }
LAB_14037df46:
  FUN_1402bbb70(plVar12,plVar11 + 2,0);
  return;
}

// ==== CMsgNpc::helper_140470df0  @140470df0  [medium:callgraph-r1]  (orig: FUN_140470df0)
undefined8 FUN_140470df0(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_140142c90(param_2 + 0x9d0);
  FUN_140036640(param_2 + 0xa00);
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x18) + 8))();
  uVar8 = 0;
  *(undefined4 *)(param_2 + 0xa30) = uVar2;
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x18))();
  if (lVar3 != 0) {
    do {
      puVar4 = (undefined8 *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                         (*(longlong **)(param_1 + 0x10),uVar8);
      if ((puVar4 != (undefined8 *)0x0) && (cVar1 = FUN_14039afd0(param_2,puVar4), cVar1 != '\0')) {
        if (*(longlong *)(param_1 + 0x18) == 0) {
          lVar3 = 0;
        }
        else {
          lVar3 = *(longlong *)(param_1 + 0x18) + 0x10;
        }
        plVar6 = (longlong *)(**(code **)(*(longlong *)*puVar4 + 0x10))((longlong *)*puVar4,1);
        uVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
        lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
        if (*(longlong *)(lVar7 + 0xa8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        FUN_140145f60(*(undefined8 *)(lVar7 + 0xa8),uVar2,param_2,lVar3,0,0);
        return 1;
      }
      uVar8 = uVar8 + 1;
      uVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x18))();
    } while (uVar8 < uVar5);
  }
  return 0;
}

