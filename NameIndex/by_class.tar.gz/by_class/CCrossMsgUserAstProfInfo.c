// ==== CCrossMsgUserAstProfInfo::helper_140158b60  @140158b60  [medium:callgraph-r0]  (orig: FUN_140158b60)
void FUN_140158b60(longlong param_1,int param_2,uint param_3,undefined1 *param_4)

{
  longlong *plVar1;
  ulonglong uVar2;
  longlong lVar3;
  int local_res10 [2];
  int local_58;
  undefined4 uStack_54;
  longlong local_50;
  undefined1 local_48 [32];
  
  if ((param_2 != 0) && (uVar2 = (ulonglong)param_3, param_3 != 0)) {
    local_res10[0] = param_2;
    FUN_140156a60(param_1 + 8,&local_58,local_res10);
    plVar1 = (longlong *)CONCAT44(uStack_54,local_58);
    lVar3 = *(longlong *)(param_1 + 0x38);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (local_50 == lVar3) {
      local_50 = FUN_1403b0320(*(undefined4 *)(param_1 + 0x48),param_2,1);
      if (local_50 != 0) {
        if (param_3 != 0) {
          do {
            FUN_1403afef0(local_50,*param_4,*(undefined4 *)(param_4 + 4));
            param_4 = param_4 + 8;
            uVar2 = uVar2 - 1;
          } while (uVar2 != 0);
        }
        local_58 = param_2;
        FUN_1401564f0(param_1 + 8,local_48,&local_58);
      }
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (local_50 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar3 = *(longlong *)(local_50 + 0x20);
      if ((lVar3 == 0) || (*(char *)(lVar3 + 0x50) == '\0')) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else if (param_3 != 0) {
        do {
          FUN_1403afef0(lVar3,*param_4,*(undefined4 *)(param_4 + 4));
          param_4 = param_4 + 8;
          uVar2 = uVar2 - 1;
        } while (uVar2 != 0);
      }
    }
  }
  return;
}

// ==== CCrossMsgUserAstProfInfo::ctor_or_dtor  @14045da90  [high:vtable-assign]  (orig: FUN_14045da90)
undefined8 * FUN_14045da90(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgUserAstProfInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgUserAstProfInfo::ctor_or_dtor  @14045dae0  [high:vtable-assign]  (orig: FUN_14045dae0)
void FUN_14045dae0(undefined8 *param_1)

{
  *param_1 = CCrossMsgUserAstProfInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgUserAstProfInfo::vfunc_1  @14045db10  [high:rtti-vtable]  (orig: FUN_14045db10)
undefined8 FUN_14045db10(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgUserAstProfInfo::ctor_or_dtor  @14045dc30  [high:vtable-assign]  (orig: FUN_14045dc30)
undefined8 * FUN_14045dc30(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgUserAstProfInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgUserAstProfInfo::vfunc_3  @14045dc80  [high:rtti-vtable]  (orig: FUN_14045dc80)
void FUN_14045dc80(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar3 = FUN_1402aef00(*(undefined8 *)(lVar4 + 0x90),uVar2,uVar1);
  if (iVar3 == 0) {
    log_InlineLogOSWARNING
              (
              "CCrossMsgUserAstProfInfo::Process UserManager GetNewOSUserID failed. server id:%u, os user id:%u."
              );
  }
  else {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar4 = *(longlong *)(lVar4 + 0xf8);
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar4 = 0;
    }
    FUN_140158b60(lVar4,iVar3,**(undefined4 **)(param_1 + 0x428),
                  *(undefined4 **)(param_1 + 0x428) + 1);
  }
  return;
}

