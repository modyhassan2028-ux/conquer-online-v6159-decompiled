// ==== CMessagePort::helper_14050b710  @14050b710  [medium:callgraph-r0]  (orig: FUN_14050b710)
uint FUN_14050b710(uint param_1)

{
  uint local_28 [10];
  
  if (param_1 < 60000) {
    return param_1;
  }
  if (param_1 == 0xea65) {
    return 4;
  }
  local_28[0] = 1;
  local_28[1] = 1;
  local_28[2] = 2;
  local_28[3] = 2;
  local_28[4] = 4;
  local_28[5] = 4;
  local_28[6] = 4;
  local_28[7] = 8;
  if (param_1 - 0xea61 < 8) {
    return local_28[(int)(param_1 - 0xea61)];
  }
  log_InlineLogERROR("IMessagePort::SIZE_OF_TYPE() has a bad type=%d");
  return 0;
}

// ==== CMessagePort::vfunc_1  @14050b7c0  [high:rtti-vtable]  (orig: FUN_14050b7c0)
undefined4 FUN_14050b7c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CMessagePort::vfunc_2  @14050b7e0  [high:rtti-vtable]  (orig: FUN_14050b7e0)
undefined4 FUN_14050b7e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CMessagePort::vfunc_4  @14050b7f0  [high:rtti-vtable]  (orig: FUN_14050b7f0)
bool FUN_14050b7f0(longlong param_1)

{
  return *(int *)(param_1 + 0x14) == 0;
}

// ==== CMessagePort::vfunc_8  @14050b800  [high:rtti-vtable]  (orig: FUN_14050b800)
void FUN_14050b800(longlong param_1,int param_2)

{
  if (param_2 < 1) {
    param_2 = 1;
  }
  *(int *)(param_1 + 0x18) = param_2;
  return;
}

// ==== CMessagePort::helper_14050b8c0  @14050b8c0  [medium:callgraph-r1]  (orig: FUN_14050b8c0)
longlong FUN_14050b8c0(longlong *param_1)

{
  ulonglong uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  uVar1 = param_1[1];
  plVar2 = (longlong *)*param_1;
  lVar5 = 0;
  uVar6 = uVar1 >> 1;
  lVar3 = lVar5;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar2 = (longlong *)*param_1;
    lVar4 = lVar5;
    if (plVar2 == (longlong *)0x0) goto LAB_14050b90f;
  }
  lVar4 = *plVar2;
  if (plVar2 != (longlong *)0x0) {
    lVar3 = lVar4;
  }
LAB_14050b90f:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar4 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = lVar5;
  if (param_1 != (longlong *)0x0) {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x28) <= uVar6) {
    lVar3 = lVar5;
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    uVar6 = uVar6 - *(longlong *)(lVar3 + 0x28);
  }
  if (param_1 != (longlong *)0x0) {
    lVar5 = *param_1;
  }
  return *(longlong *)(*(longlong *)(lVar5 + 0x20) + uVar6 * 8) + (ulonglong)((uint)uVar1 & 1) * 8;
}

// ==== CMessagePort::helper_14050bae0  @14050bae0  [medium:callgraph-r2]  (orig: FUN_14050bae0)
void FUN_14050bae0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"deque<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMessagePort::helper_14050bb80  @14050bb80  [medium:callgraph-r1]  (orig: FUN_14050bb80)
void FUN_14050bb80(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMessagePort::vfunc_6  @14050c300  [high:rtti-vtable]  (orig: FUN_14050c300)
undefined4 FUN_14050c300(longlong param_1)

{
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0x68),1);
  *(undefined4 *)(param_1 + 0x14) = 1;
  CSingleLock::Unlock(local_20);
  return 1;
}

// ==== CMessagePort::vfunc_3  @14050c3f0  [high:rtti-vtable]  (orig: FUN_14050c3f0)
longlong FUN_14050c3f0(void)

{
  return DAT_140976748 - DAT_140976740 >> 3;
}

// ==== CMessagePort::Init  @14050c410  [high:log-string]  (orig: FUN_14050c410)
bool FUN_14050c410(longlong param_1)

{
  HANDLE pvVar1;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0x68),1);
  pvVar1 = CreateEventA((LPSECURITY_ATTRIBUTES)0x0,0,0,(LPCSTR)0x0);
  *(HANDLE *)(param_1 + 0x20) = pvVar1;
  if (pvVar1 != (HANDLE)0x0) {
    CSingleLock::Unlock(local_20);
  }
  else {
    GetLastError();
    log_InlineLogERROR("CMessagePort::Init() failed with m_id=%d, error=%u");
    CSingleLock::Unlock(local_20);
  }
  return pvVar1 != (HANDLE)0x0;
}

// ==== CMessagePort::vfunc_11  @14050c490  [high:rtti-vtable]  (orig: FUN_14050c490)
ulonglong FUN_14050c490(longlong *param_1,DWORD param_2)

{
  int iVar1;
  DWORD DVar2;
  undefined4 extraout_var;
  ulonglong uVar3;
  undefined4 extraout_var_00;
  undefined4 extraout_var_01;
  undefined4 extraout_var_02;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0xd),1);
  if (*(int *)((longlong)param_1 + 0x14) == 1) {
    iVar1 = CSingleLock::Unlock(local_20);
    uVar3 = CONCAT44(extraout_var,iVar1) & 0xffffffffffffff00;
  }
  else if ((int)param_1[2] == 0) {
    ResetEvent((HANDLE)param_1[4]);
    CSingleLock::Unlock(local_20);
    DVar2 = WaitForSingleObject((HANDLE)param_1[4],param_2);
    if (DVar2 == 0) {
      iVar1 = CSingleLock::Unlock(local_20);
      uVar3 = CONCAT71((int7)(CONCAT44(extraout_var_02,iVar1) >> 8),1);
    }
    else {
      if (DVar2 == 0x80) {
        (**(code **)(*param_1 + 0x30))(param_1);
      }
      iVar1 = CSingleLock::Unlock(local_20);
      uVar3 = CONCAT44(extraout_var_01,iVar1) & 0xffffffffffffff00;
    }
  }
  else {
    iVar1 = CSingleLock::Unlock(local_20);
    uVar3 = CONCAT71((int7)(CONCAT44(extraout_var_00,iVar1) >> 8),1);
  }
  return uVar3;
}

// ==== CMessagePort::helper_14050c840  @14050c840  [medium:callgraph-r2]  (orig: FUN_14050c840)
void FUN_14050c840(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMessagePort::helper_14050c8d0  @14050c8d0  [medium:callgraph-r1]  (orig: FUN_14050c8d0)
void FUN_14050c8d0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMessagePort::helper_14050d050  @14050d050  [medium:callgraph-r1]  (orig: FUN_14050d050)
void * FUN_14050d050(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CMessagePort::helper_14050d290  @14050d290  [medium:callgraph-r0]  (orig: FUN_14050d290)
void FUN_14050d290(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  while (lVar1 != 0) {
    if ((*(longlong *)(param_1 + 0x38) != 0) &&
       (lVar1 = *(longlong *)(param_1 + 0x38) + -1, *(longlong *)(param_1 + 0x38) = lVar1,
       lVar1 == 0)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    lVar1 = *(longlong *)(param_1 + 0x38);
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  while (lVar1 != 0) {
    lVar1 = lVar1 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar1 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar1 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  return;
}

// ==== CMessagePort::helper_14050d740  @14050d740  [medium:callgraph-r0]  (orig: FUN_14050d740)
undefined8 FUN_14050d740(undefined8 *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 local_18;
  ulonglong local_10;
  
  if (param_1[7] == 0) {
    uVar4 = 0;
  }
  else {
    uVar2 = param_1[6];
    if (param_1[7] + uVar2 < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_18 = *param_1;
    local_10 = uVar2;
    puVar3 = (undefined8 *)FUN_14050b8c0(&local_18);
    uVar4 = *puVar3;
    if (param_1[7] != 0) {
      param_1[6] = param_1[6] + 1;
      if ((ulonglong)(param_1[5] * 2) <= (ulonglong)param_1[6]) {
        param_1[6] = 0;
      }
      lVar1 = param_1[7] + -1;
      param_1[7] = lVar1;
      if (lVar1 == 0) {
        param_1[6] = 0;
        return uVar4;
      }
    }
  }
  return uVar4;
}

// ==== CMessagePort::helper_14050dab0  @14050dab0  [medium:callgraph-r1]  (orig: FUN_14050dab0)
void * FUN_14050dab0(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CMessagePort::vfunc_5  @14050db60  [high:rtti-vtable]  (orig: FUN_14050db60)
void FUN_14050db60(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  void *pvVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  longlong lVar6;
  CSingleLock local_30 [24];
  
  CSingleLock::CSingleLock(local_30,(CSyncObject *)(param_1 + 0x68),1);
  uVar4 = *(ulonglong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x60) + uVar4 < uVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x28);
  lVar6 = 0;
  while( true ) {
    uVar5 = *(ulonglong *)(param_1 + 0x58) + *(longlong *)(param_1 + 0x60);
    if (uVar5 < *(ulonglong *)(param_1 + 0x58)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (uVar4 == uVar5) break;
    uVar5 = uVar4 >> 1;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar2 = lVar6;
    }
    else {
      lVar2 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar2 + 0x38) + *(longlong *)(lVar2 + 0x30)) <= uVar4) {
      _invalid_parameter_noinfo();
    }
    lVar2 = lVar6;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    if (*(ulonglong *)(lVar2 + 0x28) <= uVar5) {
      lVar2 = lVar6;
      if (plVar1 != (longlong *)0x0) {
        lVar2 = *plVar1;
      }
      uVar5 = uVar5 - *(longlong *)(lVar2 + 0x28);
    }
    lVar2 = lVar6;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    operator_delete(*(void **)(*(longlong *)(*(longlong *)(lVar2 + 0x20) + uVar5 * 8) +
                              (ulonglong)((uint)uVar4 & 1) * 8));
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar2 = lVar6;
    }
    else {
      lVar2 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar2 + 0x38) + *(longlong *)(lVar2 + 0x30)) <= uVar4) {
      _invalid_parameter_noinfo();
    }
    uVar4 = uVar4 + 1;
  }
  FUN_14050d290(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x10) = 0;
  lVar2 = *(longlong *)(param_1 + 0xd8);
  while (lVar2 != 0) {
    if (*(longlong *)(param_1 + 0xd8) == 0) {
      pvVar3 = (void *)0x0;
    }
    else {
      uVar4 = *(ulonglong *)(param_1 + 0xd0);
      if (*(longlong *)(param_1 + 0xd8) + uVar4 < uVar4) {
        _invalid_parameter_noinfo();
      }
      plVar1 = *(longlong **)(param_1 + 0xa0);
      uVar5 = uVar4 >> 1;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar6;
      }
      else {
        lVar2 = *plVar1;
      }
      if ((ulonglong)(*(longlong *)(lVar2 + 0x38) + *(longlong *)(lVar2 + 0x30)) <= uVar4) {
        _invalid_parameter_noinfo();
      }
      lVar2 = lVar6;
      if (plVar1 != (longlong *)0x0) {
        lVar2 = *plVar1;
      }
      if (*(ulonglong *)(lVar2 + 0x28) <= uVar5) {
        lVar2 = lVar6;
        if (plVar1 != (longlong *)0x0) {
          lVar2 = *plVar1;
        }
        uVar5 = uVar5 - *(longlong *)(lVar2 + 0x28);
      }
      lVar2 = lVar6;
      if (plVar1 != (longlong *)0x0) {
        lVar2 = *plVar1;
      }
      pvVar3 = *(void **)(*(longlong *)(*(longlong *)(lVar2 + 0x20) + uVar5 * 8) +
                         (ulonglong)((uint)uVar4 & 1) * 8);
      if (*(longlong *)(param_1 + 0xd8) != 0) {
        *(longlong *)(param_1 + 0xd0) = *(longlong *)(param_1 + 0xd0) + 1;
        if ((ulonglong)(*(longlong *)(param_1 + 200) * 2) <= *(ulonglong *)(param_1 + 0xd0)) {
          *(undefined8 *)(param_1 + 0xd0) = 0;
        }
        lVar2 = *(longlong *)(param_1 + 0xd8) + -1;
        *(longlong *)(param_1 + 0xd8) = lVar2;
        if (lVar2 == 0) {
          *(undefined8 *)(param_1 + 0xd0) = 0;
        }
      }
    }
    operator_delete(pvVar3);
    lVar2 = *(longlong *)(param_1 + 0xd8);
  }
  if (*(HANDLE *)(param_1 + 0x20) != (HANDLE)0x0) {
    CloseHandle(*(HANDLE *)(param_1 + 0x20));
    *(undefined8 *)(param_1 + 0x20) = 0;
  }
  CSingleLock::Unlock(local_30);
  return;
}

// ==== CMessagePort::helper_14050df20  @14050df20  [medium:callgraph-r1]  (orig: FUN_14050df20)
void FUN_14050df20(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0xfffffffffffffff - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_14050bae0();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0xfffffffffffffff - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30) >> 1;
  _Dst_00 = (void *)FUN_14050c840(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CMessagePort::helper_14050e110  @14050e110  [medium:callgraph-r0]  (orig: FUN_14050e110)
void FUN_14050e110(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14050bb80();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14050c8d0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14050dab0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14050dab0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14050d050(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CMessagePort::helper_14050e400  @14050e400  [medium:callgraph-r3]  (orig: FUN_14050e400)
undefined8 FUN_14050e400(undefined8 param_1,longlong param_2,longlong *param_3,longlong *param_4)

{
  longlong *plVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  
  FUN_14050caf0(param_4,param_1,param_3[1] - *(longlong *)(param_2 + 8));
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = *(longlong **)*param_4;
  }
  plVar3 = (longlong *)*plVar3;
  uVar8 = param_4[1];
  plVar1 = (longlong *)*param_3;
  uVar6 = param_3[1];
  uVar2 = *(ulonglong *)(param_2 + 8);
  while (uVar2 != uVar6) {
    uVar6 = uVar6 - 1;
    uVar7 = uVar6 >> 1;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar6) {
      _invalid_parameter_noinfo();
    }
    if (plVar1 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar7) {
      if (plVar1 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar1;
      }
      uVar7 = uVar7 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar1 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    uVar8 = uVar8 - 1;
    lVar4 = *(longlong *)(*(longlong *)(lVar4 + 0x20) + uVar7 * 8);
    uVar7 = uVar8 >> 1;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    if ((ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30)) <= uVar8) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    if (*(ulonglong *)(lVar5 + 0x28) <= uVar7) {
      if (plVar3 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar3;
      }
      uVar7 = uVar7 - *(longlong *)(lVar5 + 0x28);
    }
    if (plVar3 == (longlong *)0x0) {
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    *(undefined8 *)
     (*(longlong *)(*(longlong *)(lVar5 + 0x20) + uVar7 * 8) + (ulonglong)((uint)uVar8 & 1) * 8) =
         *(undefined8 *)(lVar4 + (ulonglong)((uint)uVar6 & 1) * 8);
  }
  return param_1;
}

// ==== CMessagePort::helper_14050e5e0  @14050e5e0  [medium:callgraph-r3]  (orig: FUN_14050e5e0)
undefined8 FUN_14050e5e0(undefined8 param_1,longlong *param_2,longlong param_3,longlong *param_4)

{
  ulonglong uVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  
  FUN_14050c940(param_4,param_1,*(longlong *)(param_3 + 8) - param_2[1]);
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = *(longlong **)*param_4;
  }
  plVar3 = (longlong *)*plVar3;
  uVar9 = param_4[1];
  uVar1 = *(ulonglong *)(param_3 + 8);
  plVar2 = (longlong *)*param_2;
  for (uVar6 = param_2[1]; uVar6 != uVar1; uVar6 = uVar6 + 1) {
    uVar7 = uVar6 >> 1;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar6) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar7) {
      if (plVar2 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar2;
      }
      uVar7 = uVar7 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    lVar4 = *(longlong *)(*(longlong *)(lVar4 + 0x20) + uVar7 * 8);
    uVar8 = (uint)uVar9;
    uVar7 = uVar9 >> 1;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    if ((ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30)) <= uVar9) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    if (*(ulonglong *)(lVar5 + 0x28) <= uVar7) {
      if (plVar3 == (longlong *)0x0) {
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar3;
      }
      uVar7 = uVar7 - *(longlong *)(lVar5 + 0x28);
    }
    if (plVar3 == (longlong *)0x0) {
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar3;
    }
    uVar9 = uVar9 + 1;
    *(undefined8 *)
     (*(longlong *)(*(longlong *)(lVar5 + 0x20) + uVar7 * 8) + (ulonglong)(uVar8 & 1) * 8) =
         *(undefined8 *)(lVar4 + (ulonglong)((uint)uVar6 & 1) * 8);
  }
  return param_1;
}

// ==== CMessagePort::ctor_or_dtor  @14050e820  [high:vtable-assign]  (orig: FUN_14050e820)
void FUN_14050e820(undefined8 *param_1)

{
  *param_1 = CMessagePort::vftable;
  FUN_14050db60();
  FUN_14050d290(param_1 + 0x14);
  operator_delete((void *)param_1[0x14]);
  *(undefined ***)(param_1 + 0xd) = CCriticalSection::vftable;
  DeleteCriticalSection((LPCRITICAL_SECTION)(param_1 + 0xf));
  CSyncObject::~CSyncObject((CSyncObject *)(param_1 + 0xd));
  FUN_14050d290(param_1 + 5);
  operator_delete((void *)param_1[5]);
  *param_1 = IMessagePort::vftable;
  return;
}

// ==== CMessagePort::helper_14050e9a0  @14050e9a0  [medium:callgraph-r0]  (orig: FUN_14050e9a0)
void FUN_14050e9a0(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (((*(char *)(param_1 + 0x30) + (char)*(longlong *)(param_1 + 0x38) & 1U) == 0) &&
     (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 2U >> 1)) {
    FUN_14050df20(param_1,1);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  uVar4 = uVar3 >> 1;
  if (*(ulonglong *)(param_1 + 0x28) <= uVar4) {
    uVar4 = uVar4 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) == 0) {
    pvVar2 = operator_new(0x10);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) = pvVar2;
  }
  puVar1 = (undefined8 *)
           (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) +
           (ulonglong)((uint)uVar3 & 1) * 8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = *param_2;
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CMessagePort::ctor_or_dtor  @14050ed20  [high:vtable-assign]  (orig: FUN_14050ed20)
undefined8 * FUN_14050ed20(undefined8 *param_1,undefined4 param_2)

{
  CSyncObject *this;
  int iVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  *param_1 = IMessagePort::vftable;
  *param_1 = CMessagePort::vftable;
  *(undefined4 *)((longlong)param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 3) = 1;
  plVar2 = operator_new(8);
  plVar4 = (longlong *)0x0;
  plVar3 = plVar4;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 5);
    plVar3 = plVar2;
  }
  param_1[5] = plVar3;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  this = (CSyncObject *)(param_1 + 0xd);
  CSyncObject::CSyncObject(this,(char *)0x0);
  *(undefined ***)this = CCriticalSection::vftable;
  iVar1 = CCriticalSection::Init((CCriticalSection *)this);
  if (iVar1 == 0) {
    AfxThrowMemoryException();
  }
  plVar3 = operator_new(8);
  if (plVar3 != (longlong *)0x0) {
    *plVar3 = (longlong)(param_1 + 0x14);
    plVar4 = plVar3;
  }
  param_1[0x14] = plVar4;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 1;
  param_1[4] = 0;
  return param_1;
}

// ==== CMessagePort::vfunc_0  @14050ee30  [high:rtti-vtable]  (orig: FUN_14050ee30)
void * FUN_14050ee30(void *param_1,uint param_2)

{
  FUN_14050e820();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMessagePort::vfunc_7  @14050ee60  [high:rtti-vtable]  (orig: FUN_14050ee60)
undefined8 FUN_14050ee60(longlong param_1)

{
  longlong *plVar1;
  int iVar2;
  longlong lVar3;
  undefined4 extraout_var;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined8 local_res8;
  CSingleLock local_30 [24];
  
  CSingleLock::CSingleLock(local_30,(CSyncObject *)(param_1 + 0x68),1);
  *(undefined4 *)(param_1 + 0x14) = 0;
  uVar4 = *(ulonglong *)(param_1 + 0x58);
  if (uVar4 + *(longlong *)(param_1 + 0x60) < uVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x28);
  while( true ) {
    uVar5 = *(ulonglong *)(param_1 + 0x58) + *(longlong *)(param_1 + 0x60);
    if (uVar5 < *(ulonglong *)(param_1 + 0x58)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (uVar4 == uVar5) break;
    if (*(int *)(param_1 + 0xd8) < *(int *)(param_1 + 0x18)) {
      uVar5 = uVar4 >> 1;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar3 + 0x30)) <= uVar4) {
        _invalid_parameter_noinfo();
      }
      if (plVar1 == (longlong *)0x0) {
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(ulonglong *)(lVar3 + 0x28) <= uVar5) {
        if (plVar1 == (longlong *)0x0) {
          lVar3 = 0;
        }
        else {
          lVar3 = *plVar1;
        }
        uVar5 = uVar5 - *(longlong *)(lVar3 + 0x28);
      }
      if (plVar1 == (longlong *)0x0) {
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      local_res8 = *(undefined8 *)
                    (*(longlong *)(*(longlong *)(lVar3 + 0x20) + uVar5 * 8) +
                    (ulonglong)((uint)uVar4 & 1) * 8);
      FUN_14050e9a0(param_1 + 0xa0,&local_res8);
    }
    else {
      uVar5 = uVar4 >> 1;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar3 + 0x30)) <= uVar4) {
        _invalid_parameter_noinfo();
      }
      if (plVar1 == (longlong *)0x0) {
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      if (*(ulonglong *)(lVar3 + 0x28) <= uVar5) {
        if (plVar1 == (longlong *)0x0) {
          lVar3 = 0;
        }
        else {
          lVar3 = *plVar1;
        }
        uVar5 = uVar5 - *(longlong *)(lVar3 + 0x28);
      }
      if (plVar1 == (longlong *)0x0) {
        lVar3 = 0;
      }
      else {
        lVar3 = *plVar1;
      }
      operator_delete(*(void **)(*(longlong *)(*(longlong *)(lVar3 + 0x20) + uVar5 * 8) +
                                (ulonglong)((uint)uVar4 & 1) * 8));
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar3 + 0x30)) <= uVar4) {
      _invalid_parameter_noinfo();
    }
    uVar4 = uVar4 + 1;
  }
  FUN_14050d290(param_1 + 0x28);
  *(undefined4 *)(param_1 + 0x10) = 0;
  ResetEvent(*(HANDLE *)(param_1 + 0x20));
  iVar2 = CSingleLock::Unlock(local_30);
  return CONCAT71((int7)(CONCAT44(extraout_var,iVar2) >> 8),1);
}

// ==== CMessagePort::PushMsg  @14050f080  [high:log-string]  (orig: FUN_14050f080)
ulonglong FUN_14050f080(longlong param_1,uint param_2,uint param_3,uint param_4,void *param_5)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  undefined4 extraout_var;
  undefined4 extraout_var_00;
  longlong lVar5;
  undefined4 extraout_var_01;
  undefined4 extraout_var_02;
  undefined4 extraout_var_03;
  uint *local_58;
  undefined8 local_50;
  CSingleLock local_48 [24];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  local_50 = 0xfffffffffffffffe;
  if (param_5 == (void *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_1406e5ca4,
                       "f:\\version\\cqserver-78.0.11-1204\\comm\\source\\messageport.cpp",300);
    uVar4 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    CSingleLock::CSingleLock(local_48,(CSyncObject *)(param_1 + 0x68),1);
    if (*(int *)(param_1 + 0x14) == 0) {
      if (((int)param_2 < 0) || ((int)(DAT_140976748 - DAT_140976740 >> 3) <= (int)param_2)) {
        log_InlineLogERROR("CMessagePort::PushMsg() with bad port=%d",(ulonglong)param_2);
        iVar1 = CSingleLock::Unlock(local_48);
        uVar4 = CONCAT44(extraout_var_03,iVar1) & 0xffffffffffffff00;
      }
      else {
        uVar2 = FUN_14050b710(param_4);
        if (uVar2 - 1 < 0x800) {
          local_58 = (uint *)FUN_14050d740(param_1 + 0xa0);
          if ((local_58 == (uint *)0x0) && (local_58 = operator_new(0x80c), local_58 == (uint *)0x0)
             ) {
            log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT",
                               "!\"CMessagePort::PushMsg() failed to new CMessagePacket\"",
                               "f:\\version\\cqserver-78.0.11-1204\\comm\\source\\messageport.cpp",
                               0x14d);
            iVar1 = CSingleLock::Unlock(local_48);
            uVar4 = CONCAT44(extraout_var_00,iVar1) & 0xffffffffffffff00;
          }
          else {
            *local_58 = param_2;
            local_58[1] = param_3;
            local_58[2] = param_4;
            memcpy(local_58 + 3,param_5,(longlong)(int)uVar2);
            FUN_14050e9a0(param_1 + 0x28,&local_58);
            *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
            SetEvent(*(HANDLE *)(param_1 + 0x20));
            iVar1 = *(int *)(param_1 + 0x10);
            if ((4999 < iVar1) &&
               ((iVar1 == (iVar1 / 1000) * 1000 && (iVar1 != *(int *)(param_1 + 8))))) {
              *(int *)(param_1 + 8) = iVar1;
              lVar5 = tq::DumpBuffer((char *)local_30,(int)param_5);
              if (*(ulonglong *)(lVar5 + 0x20) < 0x10) {
                lVar5 = lVar5 + 8;
              }
              else {
                lVar5 = *(longlong *)(lVar5 + 8);
              }
              log_InlineLogERROR(&DAT_14079c1c0,(ulonglong)*(uint *)(param_1 + 0xc),
                                 (ulonglong)*(uint *)(param_1 + 0x10),(ulonglong)param_2,param_3,
                                 lVar5);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
            }
            iVar1 = *(int *)(param_1 + 0x10);
            iVar3 = CSingleLock::Unlock(local_48);
            uVar4 = CONCAT71((int7)(CONCAT44(extraout_var_01,iVar3) >> 8),iVar1 < 0x3e9);
          }
        }
        else {
          log_InlineLogERROR("CMessagePort::PushMsg() with bad packet size=%d",(ulonglong)uVar2);
          iVar1 = CSingleLock::Unlock(local_48);
          uVar4 = CONCAT44(extraout_var_02,iVar1) & 0xffffffffffffff00;
        }
      }
    }
    else {
      iVar1 = CSingleLock::Unlock(local_48);
      uVar4 = CONCAT44(extraout_var,iVar1) & 0xffffffffffffff00;
    }
  }
  return uVar4;
}

// ==== CMessagePort::Send  @14050f300  [high:log-string]  (orig: FUN_14050f300)
ulonglong FUN_14050f300(longlong *param_1,int param_2,undefined4 param_3,undefined4 param_4,
                       longlong param_5)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  undefined4 extraout_var;
  undefined4 extraout_var_00;
  undefined4 extraout_var_01;
  undefined4 extraout_var_02;
  CSingleLock local_20 [24];
  
  if (param_5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0xd),1);
    cVar1 = (**(code **)(*param_1 + 0x20))(param_1);
    if (cVar1 == '\0') {
      iVar3 = CSingleLock::Unlock(local_20);
      uVar4 = CONCAT44(extraout_var,iVar3) & 0xffffffffffffff00;
    }
    else if (param_2 == 60000) {
      iVar3 = CSingleLock::Unlock(local_20);
      uVar4 = CONCAT71((int7)(CONCAT44(extraout_var_00,iVar3) >> 8),1);
    }
    else if ((param_2 < 0) || ((int)(DAT_140976748 - DAT_140976740 >> 3) <= param_2)) {
      log_InlineLogERROR("CMessagePort::Send() with bad port %d");
      iVar3 = CSingleLock::Unlock(local_20);
      uVar4 = CONCAT44(extraout_var_02,iVar3) & 0xffffffffffffff00;
    }
    else {
      CSingleLock::Unlock(local_20);
      if ((ulonglong)(DAT_140976748 - DAT_140976740 >> 3) <= (ulonglong)(longlong)param_2) {
        _invalid_parameter_noinfo();
      }
      uVar2 = FUN_14050f080(*(undefined8 *)(DAT_140976740 + (longlong)param_2 * 8),
                            *(undefined4 *)((longlong)param_1 + 0xc),param_3,param_4,param_5);
      iVar3 = CSingleLock::Unlock(local_20);
      uVar4 = CONCAT71((int7)(CONCAT44(extraout_var_01,iVar3) >> 8),uVar2);
    }
  }
  return uVar4;
}

// ==== CMessagePort::helper_14050f520  @14050f520  [medium:callgraph-r2]  (orig: FUN_14050f520)
longlong *
FUN_14050f520(longlong *param_1,longlong *param_2,undefined8 *param_3,undefined8 *param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  ulonglong uVar8;
  undefined1 local_res10;
  longlong *local_68;
  ulonglong uStack_60;
  longlong *local_58;
  ulonglong uStack_50;
  longlong *local_48;
  ulonglong uStack_40;
  undefined1 local_38 [16];
  
  local_58 = (longlong *)*param_3;
  uVar2 = param_3[1];
  if (((param_1 == (longlong *)0x0) || (uVar2 < (ulonglong)param_1[6])) ||
     ((ulonglong)(param_1[6] + param_1[7]) < uVar2)) {
    uStack_50 = uVar2;
    _invalid_parameter_noinfo();
  }
  local_68 = (longlong *)*param_4;
  plVar5 = (longlong *)*param_1;
  uVar8 = param_4[1];
  local_58 = plVar5;
  if ((uVar8 < (ulonglong)param_1[6]) ||
     (uStack_50 = uVar2, (ulonglong)(param_1[6] + param_1[7]) < uVar8)) {
    uStack_60 = uVar8;
    uStack_50 = uVar2;
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[6];
  plVar4 = (longlong *)*param_1;
  local_68 = plVar4;
  uStack_60 = uVar8;
  if (uVar3 + param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)*param_1)) {
    _invalid_parameter_noinfo();
  }
  if ((plVar4 == (longlong *)0x0) || (plVar4 != plVar5)) {
    _invalid_parameter_noinfo();
  }
  uVar1 = param_1[6] + param_1[7];
  lVar7 = uVar8 - uVar2;
  if (uVar1 < (ulonglong)param_1[6]) {
    _invalid_parameter_noinfo();
  }
  if (((longlong *)*param_1 == (longlong *)0x0) || ((longlong *)*param_1 != plVar4)) {
    _invalid_parameter_noinfo();
  }
  local_res10 = SUB81(param_2,0);
  if (uVar2 - uVar3 < uVar1 - uVar8) {
    uVar8 = param_1[6];
    if (uVar8 + param_1[7] < uVar8) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)0x0;
    local_58 = local_68;
    uStack_50 = uStack_60;
    local_48 = plVar4;
    if (plVar5 != (longlong *)0x0) {
      local_48 = (longlong *)*plVar5;
    }
    local_48 = (longlong *)*local_48;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      plVar4 = *(longlong **)*param_1;
    }
    local_68 = (longlong *)*plVar4;
    uStack_60 = uVar8;
    uStack_40 = uVar2;
    FUN_14050e400(local_38,&local_68,&local_48,&local_58,local_res10,local_res10,0);
    if (lVar7 != 0) {
      lVar6 = param_1[7];
      do {
        if (lVar6 != 0) {
          param_1[6] = param_1[6] + 1;
          if ((ulonglong)(param_1[5] * 2) <= (ulonglong)param_1[6]) {
            param_1[6] = 0;
          }
          lVar6 = lVar6 + -1;
          if (lVar6 == 0) {
            param_1[6] = 0;
          }
        }
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
      param_1[7] = lVar6;
    }
  }
  else {
    uVar1 = param_1[6] + param_1[7];
    if (uVar1 < (ulonglong)param_1[6]) {
      _invalid_parameter_noinfo();
    }
    plVar5 = (longlong *)0x0;
    local_48 = local_58;
    uStack_40 = uStack_50;
    local_68 = plVar5;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      local_68 = *(longlong **)*param_1;
    }
    local_68 = (longlong *)*local_68;
    if (plVar4 != (longlong *)0x0) {
      plVar5 = (longlong *)*plVar4;
    }
    local_58 = (longlong *)*plVar5;
    uStack_60 = uVar1;
    uStack_50 = uVar8;
    FUN_14050e5e0(local_38,&local_58,&local_68,&local_48,local_res10,local_res10,0);
    if (lVar7 != 0) {
      lVar6 = param_1[7];
      do {
        if ((lVar6 != 0) && (lVar6 = lVar6 + -1, lVar6 == 0)) {
          param_1[6] = 0;
        }
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
      param_1[7] = lVar6;
    }
  }
  lVar7 = 0;
  uVar8 = param_1[6];
  if (uVar8 + param_1[7] < uVar8) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_58 = param_1;
  uStack_50 = uVar8;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = lVar7;
  }
  else {
    lVar6 = *param_1;
  }
  uVar8 = uVar8 + (uVar2 - uVar3);
  if (uVar8 <= (ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30))) {
    if (param_1 != (longlong *)0x0) {
      lVar7 = *param_1;
    }
    if (*(ulonglong *)(lVar7 + 0x30) <= uVar8) goto LAB_14050f85d;
  }
  _invalid_parameter_noinfo();
LAB_14050f85d:
  *param_2 = (longlong)local_58;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMessagePort::Init  @14050f8b0  [high:log-string]  (orig: FUN_14050f8b0)
undefined8 FUN_14050f8b0(int param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  void *pvVar4;
  longlong lVar5;
  HANDLE pvVar6;
  ulonglong uVar7;
  longlong lVar8;
  int iVar9;
  void *local_res10;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  CSingleLock local_38 [32];
  
  if (param_1 < 1) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar9 = 0;
  if (0 < param_1) {
    do {
      local_res10 = operator_new(0xe0);
      if (local_res10 == (void *)0x0) {
        pvVar4 = (void *)0x0;
      }
      else {
        pvVar4 = (void *)FUN_14050ed20(local_res10);
      }
      plVar3 = DAT_140976748;
      if (pvVar4 == (void *)0x0) {
        return 0;
      }
      if (DAT_140976740 == (longlong *)0x0) {
        uVar7 = 0;
      }
      else {
        uVar7 = DAT_140976750 - (longlong)DAT_140976740 >> 3;
      }
      local_res10 = pvVar4;
      if ((ulonglong)((longlong)DAT_140976748 - (longlong)DAT_140976740 >> 3) < uVar7) {
        *DAT_140976748 = (longlong)pvVar4;
        DAT_140976748 = DAT_140976748 + 1;
      }
      else {
        if (DAT_140976748 < DAT_140976740) {
          _invalid_parameter_noinfo();
        }
        plVar2 = DAT_140976740;
        plVar1 = DAT_140976728;
        if (((longlong)DAT_140976748 - (longlong)DAT_140976740 & 0xfffffffffffffff8U) == 0) {
          lVar8 = 0;
        }
        else {
          if (DAT_140976748 < DAT_140976740) {
            _invalid_parameter_noinfo();
          }
          if ((plVar1 == (longlong *)0x0) || (plVar1 != DAT_140976728)) {
            _invalid_parameter_noinfo();
          }
          lVar8 = (longlong)plVar3 - (longlong)plVar2 >> 3;
        }
        local_58 = SUB84(plVar1,0);
        uStack_54 = (undefined4)((ulonglong)plVar1 >> 0x20);
        uStack_50 = SUB84(plVar3,0);
        uStack_4c = (undefined4)((ulonglong)plVar3 >> 0x20);
        local_48 = local_58;
        uStack_44 = uStack_54;
        uStack_40 = uStack_50;
        uStack_3c = uStack_4c;
        FUN_14050e110(&DAT_140976728,&local_48,1,&local_res10);
        plVar3 = DAT_140976740;
        if (DAT_140976748 < DAT_140976740) {
          _invalid_parameter_noinfo();
        }
        plVar1 = DAT_140976728;
        if (DAT_140976728 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *DAT_140976728;
        }
        if (plVar3 + lVar8 <= *(longlong **)(lVar5 + 0x20)) {
          if (plVar1 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar1;
          }
          if (*(longlong **)(lVar5 + 0x18) <= plVar3 + lVar8) goto LAB_14050fa79;
        }
        _invalid_parameter_noinfo();
      }
LAB_14050fa79:
      CSingleLock::CSingleLock(local_38,(CSyncObject *)((longlong)pvVar4 + 0x68),1);
      pvVar6 = CreateEventA((LPSECURITY_ATTRIBUTES)0x0,0,0,(LPCSTR)0x0);
      *(HANDLE *)((longlong)pvVar4 + 0x20) = pvVar6;
      if (pvVar6 == (HANDLE)0x0) {
        GetLastError();
        log_InlineLogERROR("CMessagePort::Init() failed with m_id=%d, error=%u");
        CSingleLock::Unlock(local_38);
        return 0;
      }
      CSingleLock::Unlock(local_38);
      iVar9 = iVar9 + 1;
    } while (iVar9 < param_1);
  }
  return 1;
}

// ==== CMessagePort::helper_14050fb10  @14050fb10  [medium:callgraph-r1]  (orig: FUN_14050fb10)
undefined8 FUN_14050fb10(undefined8 param_1,undefined8 param_2,longlong *param_3)

{
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong *local_38;
  ulonglong uStack_30;
  longlong local_28;
  longlong local_20;
  
  plVar1 = (longlong *)*param_3;
  uStack_30 = param_3[1];
  lVar2 = 0;
  local_38 = plVar1;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *plVar1;
  }
  uVar3 = uStack_30 + 1;
  if (uVar3 <= (ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30))) {
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    if (*(ulonglong *)(lVar2 + 0x30) <= uVar3) goto LAB_14050fb8d;
  }
  _invalid_parameter_noinfo();
LAB_14050fb8d:
  local_28 = *param_3;
  local_20 = param_3[1];
  uStack_30 = uVar3;
  FUN_14050f520(param_1,param_2,&local_28,&local_38);
  return param_2;
}

// ==== CMessagePort::helper_14050fbf0  @14050fbf0  [medium:callgraph-r0]  (orig: FUN_14050fbf0)
undefined8
FUN_14050fbf0(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
             void *param_5)

{
  ulonglong uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined4 *local_res10;
  undefined8 local_38;
  ulonglong uStack_30;
  undefined1 local_28 [16];
  
  if ((((param_2 == (undefined4 *)0x0) || (param_3 == (undefined4 *)0x0)) ||
      (param_4 == (undefined4 *)0x0)) || (param_5 == (void *)0x0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((*(int *)(param_1 + 0x14) == 0) && (0 < *(int *)(param_1 + 0x10))) {
    uVar1 = *(ulonglong *)(param_1 + 0x58);
    if (uVar1 + *(longlong *)(param_1 + 0x60) < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_38 = *(undefined8 *)(param_1 + 0x28);
    uStack_30 = uVar1;
    puVar4 = (undefined8 *)FUN_14050b8c0(&local_38);
    puVar2 = (undefined4 *)*puVar4;
    *param_2 = *puVar2;
    *param_3 = puVar2[1];
    *param_4 = puVar2[2];
    iVar3 = FUN_14050b710();
    if (iVar3 != 0) {
      memcpy(param_5,puVar2 + 3,(longlong)iVar3);
    }
    if (*(int *)(param_1 + 0xd8) < *(int *)(param_1 + 0x18)) {
      local_res10 = puVar2;
      FUN_14050e9a0(param_1 + 0xa0,&local_res10);
    }
    else {
      operator_delete(puVar2);
    }
    FUN_14050fb10(param_1 + 0x28,local_28,&local_38);
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + -1;
    return 1;
  }
  return 0;
}

// ==== CMessagePort::vfunc_9  @14050fd70  [high:rtti-vtable]  (orig: FUN_14050fd70)
ulonglong FUN_14050fd70(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                       longlong param_5,undefined4 *param_6)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 extraout_var;
  ulonglong uVar5;
  undefined4 extraout_var_00;
  undefined4 extraout_var_01;
  undefined4 extraout_var_02;
  undefined4 local_res8 [2];
  undefined4 local_48 [2];
  undefined8 local_40;
  CSingleLock local_38 [32];
  
  lVar1 = param_5;
  local_40 = 0xfffffffffffffffe;
  if (param_5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  CSingleLock::CSingleLock(local_38,(CSyncObject *)(param_1 + 0x68),1);
  if (*(int *)(param_1 + 0x14) == 1) {
    if (param_6 != (undefined4 *)0x0) {
      param_6[3] = 1;
    }
    iVar3 = CSingleLock::Unlock(local_38);
    uVar5 = CONCAT44(extraout_var,iVar3) & 0xffffffffffffff00;
  }
  else {
    local_res8[0] = param_3;
    param_5._0_4_ = param_2;
    cVar2 = FUN_14050fbf0(param_1,&param_5,local_res8,local_48,lVar1);
    if (cVar2 == '\0') {
      if (param_6 != (undefined4 *)0x0) {
        param_6[3] = 0;
      }
      iVar3 = CSingleLock::Unlock(local_38);
      uVar5 = CONCAT44(extraout_var_02,iVar3) & 0xffffffffffffff00;
    }
    else {
      iVar3 = FUN_14050b710(local_48[0]);
      iVar4 = FUN_14050b710(param_4);
      if (iVar4 < iVar3) {
        log_InlineLogERROR(&DAT_1406d9c10);
        if (param_6 != (undefined4 *)0x0) {
          param_6[3] = 2;
        }
        iVar3 = CSingleLock::Unlock(local_38);
        uVar5 = CONCAT44(extraout_var_00,iVar3) & 0xffffffffffffff00;
      }
      else {
        if (param_6 != (undefined4 *)0x0) {
          *param_6 = (undefined4)param_5;
          param_6[1] = local_res8[0];
          param_6[2] = local_48[0];
          param_6[3] = 0;
        }
        iVar3 = CSingleLock::Unlock(local_38);
        uVar5 = CONCAT71((int7)(CONCAT44(extraout_var_01,iVar3) >> 8),1);
      }
    }
  }
  return uVar5;
}

