// ==== CLeaveWordActor@adapter::vfunc_1  @14058e870  [high:rtti-vtable]  (orig: FUN_14058e870)
void FUN_14058e870(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_1  @14058e890  [high:rtti-vtable]  (orig: FUN_14058e890)
bool FUN_14058e890(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CLeaveWordActor@adapter::vfunc_0  @14058e8b0  [high:rtti-vtable]  (orig: FUN_14058e8b0)
bool FUN_14058e8b0(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x90))
                    (*(longlong **)(param_1 + 0x10),param_2,0);
  return lVar1 != 0;
}

// ==== CLeaveWordActor@adapter::vfunc_2  @14058e8d0  [high:rtti-vtable]  (orig: FUN_14058e8d0)
undefined1 * FUN_14058e8d0(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058e928. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CLeaveWordActor@adapter::vfunc_4  @14058e930  [high:rtti-vtable]  (orig: FUN_14058e930)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14058e930(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  undefined8 param_5,undefined8 param_6,undefined4 param_7,undefined2 param_8,
                  undefined2 param_9,undefined4 param_10)

{
  int iVar1;
  longlong lVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = param_10;
    local_4c0 = param_9;
    local_4c8 = param_8;
    local_4d0 = param_7;
    local_4d8 = param_6;
    iVar1 = FUN_14015b300(local_488,param_3,param_4,param_5);
    if (iVar1 == 0) {
      FUN_14015b2c0(local_488);
    }
    else {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_488);
      FUN_14015b2c0(local_488);
    }
  }
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_6  @14058ea40  [high:rtti-vtable]  (orig: FUN_14058ea40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14058ea40(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 local_res20;
  undefined1 auStack_438 [32];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  if (param_3 == (char *)0x0) {
    return false;
  }
  local_res20 = param_4;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    _vsnprintf(local_418,0x400,param_3,(va_list)&local_res20);
    local_19 = 0;
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),local_418);
  }
  return lVar1 != 0;
}

// ==== CLeaveWordActor@adapter::vfunc_5  @14058eb00  [high:rtti-vtable]  (orig: FUN_14058eb00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14058eb00(longlong param_1,undefined8 param_2,undefined4 param_3,char *param_4)

{
  undefined8 uVar1;
  longlong *plVar2;
  undefined1 auStack_448 [32];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar1 = 0;
    if (plVar2 != (longlong *)0x0) {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      (**(code **)(*plVar2 + 0x150))(plVar2,param_3,local_428);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CLeaveWordActor@adapter::vfunc_8  @14058ebb0  [high:rtti-vtable]  (orig: FUN_14058ebb0)
void FUN_14058ebb0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058ebd7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_9  @14058ebe0  [high:rtti-vtable]  (orig: FUN_14058ebe0)
void FUN_14058ebe0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1401649c0(lVar1);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_10  @14058ec10  [high:rtti-vtable]  (orig: FUN_14058ec10)
void FUN_14058ec10(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058ec37. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_11  @14058ec40  [high:rtti-vtable]  (orig: FUN_14058ec40)
void FUN_14058ec40(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x90))
                     (*(longlong **)(param_1 + 0x10),param_2,0);
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058ec68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 8))(plVar1);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_12  @14058ec70  [high:rtti-vtable]  (orig: FUN_14058ec70)
void FUN_14058ec70(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058ec8a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x148))(plVar1,param_2);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_13  @14058eca0  [high:rtti-vtable]  (orig: FUN_14058eca0)
void FUN_14058eca0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058ecc9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x160))(plVar1,param_2,param_3);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_14  @14058ecd0  [high:rtti-vtable]  (orig: FUN_14058ecd0)
void FUN_14058ecd0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058ecf9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x168))(plVar1,param_2,param_3);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_15  @14058ed00  [high:rtti-vtable]  (orig: FUN_14058ed00)
bool FUN_14058ed00(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CLeaveWordActor@adapter::vfunc_16  @14058ed20  [high:rtti-vtable]  (orig: FUN_14058ed20)
void FUN_14058ed20(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058ed3a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xf0))(plVar1,param_2);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_17  @14058ed50  [high:rtti-vtable]  (orig: FUN_14058ed50)
void FUN_14058ed50(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058ed79. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xc0))(plVar1,param_2,param_3);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_18  @14058ed80  [high:rtti-vtable]  (orig: FUN_14058ed80)
void FUN_14058ed80(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014058eda9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 200))(plVar1,param_2,param_3);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_19  @14058edb0  [high:rtti-vtable]  (orig: FUN_14058edb0)
bool FUN_14058edb0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CLeaveWordActor@adapter::vfunc_0  @14058edd0  [high:rtti-vtable]  (orig: FUN_14058edd0)
void FUN_14058edd0(longlong param_1)

{
  FUN_14058ee30(param_1 + -8);
  return;
}

// ==== CLeaveWordActor@adapter::helper_14058ee30  @14058ee30  [medium:callgraph-r0]  (orig: FUN_14058ee30)
undefined8 * FUN_14058ee30(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CLeaveWordActor::vftable;
  param_1[1] = adapter::CLeaveWordActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CLeaveWordActor@adapter::vfunc_3  @14058ee80  [high:rtti-vtable]  (orig: FUN_14058ee80)
void FUN_14058ee80(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_7  @14058ef40  [high:rtti-vtable]  (orig: FUN_14058ef40)
void FUN_14058ef40(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a1d0(uVar1,param_2,0);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_20  @14058ef70  [high:rtti-vtable]  (orig: FUN_14058ef70)
void FUN_14058ef70(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CLeaveWordActor@adapter::vfunc_21  @14058eff0  [high:rtti-vtable]  (orig: FUN_14058eff0)
undefined4 FUN_14058eff0(void)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(0xe);
  return *(undefined4 *)(lVar1 + 0x2a8);
}

