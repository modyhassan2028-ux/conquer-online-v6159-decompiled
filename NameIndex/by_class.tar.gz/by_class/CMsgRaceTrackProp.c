// ==== CMsgRaceTrackProp::helper_140165c80  @140165c80  [medium:callgraph-r0]  (orig: FUN_140165c80)
char FUN_140165c80(void)

{
  int iVar1;
  
  iVar1 = FUN_140160850();
  if (iVar1 - 9U < 4) {
    return '\x05';
  }
  if (iVar1 - 6U < 3) {
    return '\x04';
  }
  if (iVar1 - 4U < 2) {
    return '\x03';
  }
  return (iVar1 - 1U < 3) + '\x01';
}

// ==== CMsgRaceTrackProp::helper_140165e90  @140165e90  [medium:callgraph-r0]  (orig: FUN_140165e90)
undefined8 FUN_140165e90(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b18a0();
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140165ee0  @140165ee0  [medium:callgraph-r0]  (orig: FUN_140165ee0)
undefined8 FUN_140165ee0(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,1);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140165f30  @140165f30  [medium:callgraph-r0]  (orig: FUN_140165f30)
undefined8 FUN_140165f30(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,3);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140165f80  @140165f80  [medium:callgraph-r0]  (orig: FUN_140165f80)
undefined8 FUN_140165f80(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,2);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140165fd0  @140165fd0  [medium:callgraph-r0]  (orig: FUN_140165fd0)
undefined8 FUN_140165fd0(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,4);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166020  @140166020  [medium:callgraph-r0]  (orig: FUN_140166020)
undefined8 FUN_140166020(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,6);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166070  @140166070  [medium:callgraph-r0]  (orig: FUN_140166070)
undefined8 FUN_140166070(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,5);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166110  @140166110  [medium:callgraph-r0]  (orig: FUN_140166110)
undefined8 FUN_140166110(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b09e0(*(longlong *)(param_1 + 0x1260),param_2,8);
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166160  @140166160  [medium:callgraph-r0]  (orig: FUN_140166160)
undefined1 FUN_140166160(longlong param_1)

{
  undefined1 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b1cc0();
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_1401661b0  @1401661b0  [medium:callgraph-r0]  (orig: FUN_1401661b0)
undefined1 FUN_1401661b0(longlong param_1)

{
  undefined1 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b2740();
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166200  @140166200  [medium:callgraph-r0]  (orig: FUN_140166200)
undefined8 FUN_140166200(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b1e00();
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_140166250  @140166250  [medium:callgraph-r0]  (orig: FUN_140166250)
undefined8 FUN_140166250(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1260) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = FUN_1403b1f20();
  return uVar1;
}

// ==== CMsgRaceTrackProp::helper_1401662d0  @1401662d0  [medium:callgraph-r0]  (orig: FUN_1401662d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401662d0(longlong *param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined1 auStack_488 [32];
  undefined2 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    uVar3 = 0;
  }
  else {
    FUN_1403b5b50(local_448);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    local_468 = *(undefined2 *)(param_2 + 0x22);
    cVar1 = FUN_1403b5c00(local_448,uVar2,*(undefined2 *)(param_2 + 4),
                          *(undefined2 *)(param_2 + 0x20));
    if (cVar1 != '\0') {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,1);
    }
    FUN_1403b5ba0(local_448);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CMsgRaceTrackProp::helper_1401776f0  @1401776f0  [medium:callgraph-r0]  (orig: FUN_1401776f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401776f0(longlong *param_1,longlong param_2)

{
  int iVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  undefined2 local_480;
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 == 0) {
    uVar6 = 0;
  }
  else {
    cVar3 = (**(code **)(param_1[2] + 0x2d8))(param_1 + 2,0x36);
    if (cVar3 != '\0') {
      plVar5 = (longlong *)FUN_1401181a0();
      cVar3 = (**(code **)(*plVar5 + 0xd0))(plVar5,*(undefined4 *)(param_2 + 0x10));
      if (cVar3 != '\0') {
        return 0;
      }
    }
    FUN_1403b5b50(local_458);
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    local_4a8 = (uint)local_4a8._2_2_ << 0x10;
    cVar3 = FUN_1403b5c00(local_458,uVar4,*(undefined2 *)(param_2 + 4),0);
    if (cVar3 != '\0') {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_458,1);
      plVar5 = (longlong *)FUN_1401181a0();
      lVar2 = *plVar5;
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      local_478 = 0;
      local_480 = 0;
      local_488 = 0;
      local_490 = 0;
      local_498 = 0;
      local_4a0 = CONCAT44(local_4a0._4_4_,*(undefined4 *)(param_2 + 0x14));
      local_4a8 = *(int *)(param_2 + 0x18);
      (**(code **)(lVar2 + 8))
                (plVar5,uVar4,*(undefined4 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x1c));
    }
    iVar1 = *(int *)(param_2 + 0x24);
    if (0 < iVar1) {
      uVar6 = FUN_140008520((int)param_1[0x246]);
      uVar6 = FUN_140087730(uVar6);
      local_4a0 = 0;
      local_4a8 = 0;
      FUN_140145f60(uVar6,iVar1,param_1,0);
    }
    FUN_1403b5ba0(local_458);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgRaceTrackProp::helper_140177870  @140177870  [medium:callgraph-r0]  (orig: FUN_140177870)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140177870(longlong *param_1,longlong param_2,longlong *param_3)

{
  int iVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined8 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined2 local_490;
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (((param_2 != 0) && (param_3 != (longlong *)0x0)) &&
     (cVar3 = (**(code **)(param_3[2] + 0x220))(param_3 + 2), cVar3 != '\0')) {
    cVar3 = (**(code **)(param_3[2] + 0x2d8))(param_3 + 2,0x36);
    if (cVar3 != '\0') {
      plVar5 = (longlong *)FUN_1401181a0();
      cVar3 = (**(code **)(*plVar5 + 0xd0))(plVar5,*(undefined4 *)(param_2 + 0x10));
      if (cVar3 != '\0') {
        return 0;
      }
    }
    FUN_1403b5b50(local_468);
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    local_4b8 = (uint)local_4b8._2_2_ << 0x10;
    cVar3 = FUN_1403b5c00(local_468,uVar4,*(undefined2 *)(param_2 + 4),0);
    if (cVar3 != '\0') {
      uVar4 = (**(code **)(*param_3 + 8))(param_3);
      FUN_1403b5c90(local_468,uVar4);
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,1);
      plVar5 = (longlong *)FUN_1401181a0();
      lVar2 = *plVar5;
      uVar4 = (**(code **)(*param_3 + 8))(param_3);
      local_488 = 0;
      local_490 = 0;
      local_498 = 0;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = CONCAT44(local_4b0._4_4_,*(undefined4 *)(param_2 + 0x14));
      local_4b8 = *(int *)(param_2 + 0x18);
      (**(code **)(lVar2 + 8))
                (plVar5,uVar4,*(undefined4 *)(param_2 + 0x10),*(undefined4 *)(param_2 + 0x1c));
    }
    iVar1 = *(int *)(param_2 + 0x24);
    if (0 < iVar1) {
      uVar6 = FUN_140008520((int)param_1[0x246]);
      uVar6 = FUN_140087730(uVar6);
      local_4b0 = 0;
      local_4b8 = 0;
      FUN_140145f60(uVar6,iVar1,param_3,0);
    }
    FUN_1403b5ba0(local_468);
    return 1;
  }
  return 0;
}

// ==== CMsgRaceTrackProp::helper_140177a30  @140177a30  [medium:callgraph-r0]  (orig: FUN_140177a30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140177a30(longlong *param_1,undefined4 *param_2)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_490;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == (undefined4 *)0x0) {
    uVar7 = 0;
  }
  else {
    lVar9 = param_1[0x24d];
    if ((int)lVar9 < 2) {
      uVar7 = 0;
    }
    else {
      FUN_1403b2b70(param_1[0x24c],*param_2,0);
      FUN_1403b5b50(local_478);
      plVar12 = (longlong *)0x0;
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      local_498 = (uint)local_498._2_2_ << 0x10;
      cVar2 = FUN_1403b5c00(local_478,uVar3,*(undefined2 *)(param_2 + 1),0);
      if (cVar2 != '\0') {
        (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_478,1);
      }
      iVar4 = FUN_1403b09d0(param_1[0x24c]);
      uVar5 = _time32((__time32_t *)0x0);
      srand(uVar5);
      iVar1 = (int)lVar9 + -1;
      plVar11 = plVar12;
      if (0 < iVar1) {
        do {
          iVar6 = tq::RandGet(iVar4 + -1);
          plVar8 = DAT_140975bc8;
          if (DAT_140975bc8 == (longlong *)0x0) {
            local_498 = 0x3cb;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar8 = plVar12;
          }
          for (plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,(longlong)iVar6);
              plVar8 != (longlong *)0x0; plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))()) {
            iVar6 = (**(code **)(*plVar8 + 0x10))(plVar8,0);
            if (iVar6 != param_2[1]) {
              local_488 = operator_new(0x10);
              plVar10 = plVar12;
              if (local_488 != (longlong *)0x0) {
                *(undefined4 *)local_488 = 0;
                *(undefined4 *)((longlong)local_488 + 4) = 0;
                *(undefined4 *)(local_488 + 1) = 0;
                *(undefined4 *)((longlong)local_488 + 0xc) = 0;
                plVar10 = local_488;
              }
              if (plVar10 == (longlong *)0x0) {
                FUN_1403b5ba0(local_478);
                return 0;
              }
              *(undefined4 *)plVar10 = 0;
              uVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,0);
              *(undefined4 *)((longlong)plVar10 + 4) = uVar3;
              uVar3 = (**(code **)(*param_1 + 8))(param_1);
              *(undefined4 *)(plVar10 + 1) = uVar3;
              uVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,9);
              *(undefined4 *)((longlong)plVar10 + 0xc) = uVar3;
              FUN_140165e10(param_1,plVar10);
              break;
            }
            tq::RandGet(iVar4 + -1);
            plVar8 = DAT_140975bc8;
            if (DAT_140975bc8 == (longlong *)0x0) {
              local_498 = 0x3cb;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar8 = plVar12;
            }
          }
          uVar5 = (int)plVar11 + 1;
          plVar11 = (longlong *)(ulonglong)uVar5;
        } while ((int)uVar5 < iVar1);
      }
      if (0 < (int)param_2[9]) {
        lVar9 = FUN_140008520((int)param_1[0x246]);
        if (*(longlong *)(lVar9 + 0xa8) == 0) {
          local_498 = 0x137;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        local_490 = 0;
        local_498 = 0;
        FUN_140145f60(*(undefined8 *)(lVar9 + 0xa8),param_2[9],param_1,0);
      }
      FUN_1403b5ba0(local_478);
      uVar7 = 1;
    }
  }
  return uVar7;
}

// ==== CMsgRaceTrackProp::helper_1401bad20  @1401bad20  [medium:callgraph-r0]  (orig: FUN_1401bad20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1401bad20(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined1 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  longlong lVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong lVar15;
  ulonglong uVar16;
  longlong *plVar17;
  undefined8 uVar18;
  ulonglong uVar19;
  longlong *plVar20;
  longlong lVar21;
  longlong *plVar22;
  undefined1 auStack_598 [32];
  undefined4 local_578;
  undefined8 local_570;
  undefined4 local_568;
  undefined4 local_560;
  undefined1 local_558;
  undefined2 local_550;
  undefined4 local_548;
  longlong *local_538;
  undefined8 local_530;
  longlong *local_528 [3];
  longlong *local_510;
  longlong *local_508;
  longlong local_500;
  longlong *local_4f8;
  longlong *local_4f0;
  longlong *local_4e8 [3];
  longlong *local_4d0;
  longlong *local_4c8;
  undefined8 local_4c0;
  undefined8 local_4b8;
  undefined8 uStack_4b0;
  longlong *local_4a8;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  plVar14 = param_1 + 2;
  local_538 = param_2;
  local_4f8 = plVar14;
  local_4a8 = param_1;
  cVar3 = (**(code **)(*plVar14 + 0x220))(plVar14);
  uVar4 = 0;
  if (cVar3 != '\0') {
    iVar5 = (**(code **)(*plVar14 + 0x40))(plVar14);
    local_530 = (longlong *)CONCAT44(local_530._4_4_,iVar5);
    iVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
    local_530 = (longlong *)CONCAT44(iVar6,(undefined4)local_530);
    local_4f0 = operator_new(8);
    local_528[0] = (longlong *)0x0;
    local_4e8[0] = local_528[0];
    if (local_4f0 != (longlong *)0x0) {
      *local_4f0 = (longlong)local_4e8;
      local_4e8[0] = local_4f0;
    }
    local_4d0 = (longlong *)0x0;
    local_4c8 = (longlong *)0x0;
    local_4c0 = 0;
    local_4b8 = local_4f0;
    local_4f0 = operator_new(8);
    if (local_4f0 != (longlong *)0x0) {
      *local_4f0 = (longlong)local_528;
      local_528[0] = local_4f0;
    }
    local_510 = (longlong *)0x0;
    local_508 = (longlong *)0x0;
    local_500 = 0;
    local_4b8 = local_4f0;
    FUN_1403b5b50(local_478);
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    local_578 = (uint)local_578._2_2_ << 0x10;
    cVar3 = FUN_1403b5c00(local_478,uVar7,*(undefined2 *)((longlong)param_2 + 4),0);
    if (cVar3 == '\0') {
      FUN_1403b5ba0(local_478);
      if (local_510 != (longlong *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (longlong *)0x0;
      local_508 = (longlong *)0x0;
      local_500 = 0;
      operator_delete(local_528[0]);
      if (local_4d0 != (longlong *)0x0) {
        operator_delete(local_4d0);
      }
      local_4d0 = (longlong *)0x0;
      local_4c8 = (longlong *)0x0;
      local_4c0 = 0;
      operator_delete(local_4e8[0]);
      uVar4 = 0;
    }
    else {
      lVar12 = (**(code **)(*plVar14 + 0x160))(plVar14);
      plVar14 = local_4f8;
      if (lVar12 == 0) {
        log_InlineLogERROR("Can\'t Get GameMap at %s, %d");
        FUN_1403b5ba0(local_478);
        if (local_510 != (longlong *)0x0) {
          operator_delete(local_510);
        }
        local_510 = (longlong *)0x0;
        local_508 = (longlong *)0x0;
        local_500 = 0;
        operator_delete(local_528[0]);
        if (local_4d0 != (longlong *)0x0) {
          operator_delete(local_4d0);
        }
        local_4d0 = (longlong *)0x0;
        local_4c8 = (longlong *)0x0;
        local_4c0 = 0;
        operator_delete(local_4e8[0]);
        uVar4 = 0;
      }
      else {
        if ((int)param_2[1] == 1) {
          iVar5 = (**(code **)(*local_4f8 + 0x40))(local_4f8);
          if (iVar5 / 0x12 + -1 < 1) {
            iVar5 = 0;
          }
          else {
            iVar5 = (**(code **)(*plVar14 + 0x40))(plVar14);
            iVar5 = iVar5 / 0x12 + -1;
          }
          iVar6 = (**(code **)(*plVar14 + 0x40))(plVar14);
          plVar22 = local_538;
          if (iVar5 <= iVar6 / 0x12 + 1) {
            do {
              iVar6 = (**(code **)(**(longlong **)(lVar12 + 0x60) + 0x28))();
              plVar22 = local_538;
              if ((iVar6 + -1) / 0x12 + 1 <= iVar5) break;
              iVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
              if (iVar6 / 0x12 + -1 < 1) {
                iVar6 = 0;
              }
              else {
                iVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
                iVar6 = iVar6 / 0x12 + -1;
              }
              iVar8 = (**(code **)(*plVar14 + 0x48))(plVar14);
              if (iVar6 <= iVar8 / 0x12 + 1) {
                do {
                  uVar19 = 0;
                  iVar8 = (**(code **)(**(longlong **)(lVar12 + 0x60) + 0x20))();
                  if ((iVar8 + -1) / 0x12 + 1 <= iVar6) break;
                  lVar13 = FUN_14017eea0(lVar12,iVar5,iVar6);
                  lVar13 = (**(code **)(**(longlong **)(lVar13 + 8) + 0x10))();
                  if (lVar13 != 0) {
                    do {
                      uVar16 = 0;
                      local_4f0 = (longlong *)0x0;
                      lVar13 = FUN_14017eea0(lVar12,iVar5,iVar6);
                      plVar14 = (longlong *)
                                (**(code **)(**(longlong **)(lVar13 + 8) + 0x18))
                                          (*(longlong **)(lVar13 + 8),uVar19);
                      if (((plVar14 != (longlong *)0x0) &&
                          (cVar3 = (**(code **)(*plVar14 + 0x40))(plVar14,&local_4f0), cVar3 != '\0'
                          )) && (cVar3 = (**(code **)(*local_4f0 + 0x220))(), cVar3 != '\0')) {
                        local_530 = (longlong *)0x0;
                        (**(code **)(*local_4f0 + 0x298))(local_4f0,0x1001,&local_530);
                        if (local_530 != (longlong *)0x0) {
                          cVar3 = (**(code **)(local_530[2] + 0x2d8))(local_530 + 2,0x36);
                          if (cVar3 != '\0') {
                            plVar14 = (longlong *)FUN_1401181a0();
                            cVar3 = (**(code **)(*plVar14 + 0xd0))(plVar14,(int)param_2[2]);
                            if (cVar3 != '\0') goto LAB_1401bb364;
                          }
                          uVar7 = (**(code **)(*local_530 + 8))();
                          FUN_1403b5c90(local_478,uVar7);
                          plVar14 = local_508;
                          if (local_510 != (longlong *)0x0) {
                            uVar16 = local_500 - (longlong)local_510 >> 3;
                          }
                          if ((ulonglong)((longlong)local_508 - (longlong)local_510 >> 3) < uVar16)
                          {
                            *local_508 = (longlong)local_4f0;
                            local_508 = local_508 + 1;
                            param_2 = local_538;
                          }
                          else {
                            if (local_508 < local_510) {
                              _invalid_parameter_noinfo();
                            }
                            plVar22 = local_510;
                            plVar2 = local_528[0];
                            local_4b8 = local_528[0];
                            uStack_4b0 = plVar14;
                            if (((longlong)local_508 - (longlong)local_510 & 0xfffffffffffffff8U) ==
                                0) {
                              lVar13 = 0;
                            }
                            else {
                              if (local_508 < local_510) {
                                _invalid_parameter_noinfo();
                              }
                              if ((plVar2 == (longlong *)0x0) || (plVar2 != local_528[0])) {
                                _invalid_parameter_noinfo();
                              }
                              lVar13 = (longlong)plVar14 - (longlong)plVar22 >> 3;
                            }
                            lVar15 = 0;
                            local_498 = (undefined4)local_4b8;
                            uStack_494 = local_4b8._4_4_;
                            uStack_490 = (undefined4)uStack_4b0;
                            uStack_48c = uStack_4b0._4_4_;
                            FUN_1401a0cb0(local_528,&local_498,1,&local_4f0);
                            plVar14 = local_510;
                            if (local_508 < local_510) {
                              _invalid_parameter_noinfo();
                            }
                            plVar2 = local_528[0];
                            if (local_528[0] == (longlong *)0x0) {
                              _invalid_parameter_noinfo();
                              lVar21 = lVar15;
                            }
                            else {
                              lVar21 = *local_528[0];
                            }
                            if (plVar14 + lVar13 <= *(longlong **)(lVar21 + 0x20)) {
                              if (plVar2 != (longlong *)0x0) {
                                lVar15 = *plVar2;
                              }
                              param_2 = local_538;
                              if (*(longlong **)(lVar15 + 0x18) <= plVar14 + lVar13)
                              goto LAB_1401bb364;
                            }
                            _invalid_parameter_noinfo();
                            param_2 = local_538;
                          }
                        }
                      }
LAB_1401bb364:
                      uVar19 = uVar19 + 1;
                      lVar13 = FUN_14017eea0(lVar12,iVar5,iVar6);
                      uVar16 = (**(code **)(**(longlong **)(lVar13 + 8) + 0x10))();
                      plVar14 = local_4f8;
                    } while (uVar19 < uVar16);
                  }
                  iVar6 = iVar6 + 1;
                  iVar8 = (**(code **)(*plVar14 + 0x48))(plVar14);
                } while (iVar6 <= iVar8 / 0x12 + 1);
              }
              iVar5 = iVar5 + 1;
              iVar6 = (**(code **)(*plVar14 + 0x40))(plVar14);
              plVar22 = local_538;
            } while (iVar5 <= iVar6 / 0x12 + 1);
          }
        }
        else {
          local_578 = 0x1001;
          FUN_1402d0e40(lVar12,local_4e8,local_530,*(undefined4 *)((longlong)param_2 + 0xc));
          plVar20 = local_4d0;
          plVar2 = local_4e8[0];
          plVar22 = local_538;
          if (local_4c8 < local_4d0) {
            _invalid_parameter_noinfo();
            plVar2 = local_4e8[0];
            plVar22 = local_538;
          }
          while( true ) {
            plVar1 = local_4c8;
            if (local_4c8 < local_4d0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar2 == (longlong *)0x0) || (plVar2 != local_4e8[0])) {
              _invalid_parameter_noinfo();
            }
            plVar14 = local_4f8;
            if (plVar20 == plVar1) break;
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = 0;
            }
            else {
              lVar12 = *plVar2;
            }
            lVar13 = 0;
            if (*(longlong **)(lVar12 + 0x20) <= plVar20) {
              _invalid_parameter_noinfo();
            }
            if (*plVar20 != 0) {
              local_538 = (longlong *)0x0;
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                lVar13 = *plVar2;
              }
              if (*(longlong **)(lVar13 + 0x20) <= plVar20) {
                _invalid_parameter_noinfo();
              }
              cVar3 = (**(code **)(*(longlong *)*plVar20 + 0x40))((longlong *)*plVar20,&local_538);
              if (cVar3 != '\0') {
                iVar8 = (**(code **)(*local_538 + 0x40))();
                iVar9 = (**(code **)(*local_538 + 0x48))();
                iVar10 = (**(code **)(*local_538 + 0x10))();
                iVar11 = (**(code **)(*local_4a8 + 8))(local_4a8);
                if (((iVar10 != iVar11) &&
                    (iVar10 = *(int *)((longlong)plVar22 + 0xc) + 1,
                    (iVar5 - iVar8) * (iVar5 - iVar8) + (iVar6 - iVar9) * (iVar6 - iVar9) <=
                    iVar10 * iVar10)) &&
                   (cVar3 = (**(code **)(*local_538 + 0x220))(), cVar3 != '\0')) {
                  uVar19 = 0;
                  local_530 = (longlong *)0x0;
                  (**(code **)(*local_538 + 0x298))(local_538,0x1001,&local_530);
                  if (local_530 != (longlong *)0x0) {
                    cVar3 = (**(code **)(local_530[2] + 0x2d8))(local_530 + 2,0x36);
                    if (cVar3 != '\0') {
                      plVar14 = (longlong *)FUN_1401181a0();
                      cVar3 = (**(code **)(*plVar14 + 0xd0))(plVar14,(int)plVar22[2]);
                      if (cVar3 != '\0') goto LAB_1401bb729;
                    }
                    uVar7 = (**(code **)(*local_530 + 8))();
                    FUN_1403b5c90(local_478,uVar7);
                    plVar14 = local_508;
                    if (local_510 != (longlong *)0x0) {
                      uVar19 = local_500 - (longlong)local_510 >> 3;
                    }
                    if ((ulonglong)((longlong)local_508 - (longlong)local_510 >> 3) < uVar19) {
                      *local_508 = (longlong)local_538;
                      local_508 = local_508 + 1;
                    }
                    else {
                      if (local_508 < local_510) {
                        _invalid_parameter_noinfo();
                      }
                      plVar17 = local_510;
                      plVar1 = local_528[0];
                      local_4b8 = local_528[0];
                      uStack_4b0 = plVar14;
                      if (((longlong)local_508 - (longlong)local_510 & 0xfffffffffffffff8U) == 0) {
                        lVar12 = 0;
                      }
                      else {
                        if (local_508 < local_510) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_528[0])) {
                          _invalid_parameter_noinfo();
                        }
                        lVar12 = (longlong)plVar14 - (longlong)plVar17 >> 3;
                      }
                      local_498 = (undefined4)local_4b8;
                      uStack_494 = local_4b8._4_4_;
                      uStack_490 = (undefined4)uStack_4b0;
                      uStack_48c = uStack_4b0._4_4_;
                      FUN_1401a0cb0(local_528,&local_498,1,&local_538);
                      plVar14 = local_510;
                      if (local_508 < local_510) {
                        _invalid_parameter_noinfo();
                      }
                      plVar1 = local_528[0];
                      if (local_528[0] == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar13 = 0;
                      }
                      else {
                        lVar13 = *local_528[0];
                      }
                      if (plVar14 + lVar12 <= *(longlong **)(lVar13 + 0x20)) {
                        if (plVar1 == (longlong *)0x0) {
                          lVar13 = 0;
                        }
                        else {
                          lVar13 = *plVar1;
                        }
                        if (*(longlong **)(lVar13 + 0x18) <= plVar14 + lVar12) goto LAB_1401bb729;
                      }
                      _invalid_parameter_noinfo();
                    }
                  }
                }
              }
            }
LAB_1401bb729:
            lVar12 = 0;
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar12 = *plVar2;
            }
            if (*(longlong **)(lVar12 + 0x20) <= plVar20) {
              _invalid_parameter_noinfo();
            }
            plVar20 = plVar20 + 1;
          }
        }
        (**(code **)(*plVar14 + 0x348))(plVar14,local_478,1);
        plVar20 = local_510;
        plVar14 = local_4a8;
        plVar2 = local_528[0];
        if (local_508 < local_510) {
          _invalid_parameter_noinfo();
          plVar14 = local_4a8;
          plVar2 = local_528[0];
        }
        while( true ) {
          plVar1 = local_508;
          if (local_508 < local_510) {
            _invalid_parameter_noinfo();
          }
          if ((plVar2 == (longlong *)0x0) || (plVar2 != local_528[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar20 == plVar1) break;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar2;
          }
          lVar13 = 0;
          if (*(longlong **)(lVar12 + 0x20) <= plVar20) {
            _invalid_parameter_noinfo();
          }
          if (*plVar20 != 0) {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar2;
            }
            if (*(longlong **)(lVar12 + 0x20) <= plVar20) {
              _invalid_parameter_noinfo();
            }
            plVar1 = (longlong *)*plVar20;
            if (plVar1 != (longlong *)0x0) {
              plVar17 = (longlong *)FUN_1401181a0();
              lVar12 = *plVar17;
              uVar7 = (**(code **)(*plVar1 + 0x10))(plVar1);
              local_548 = 0;
              local_550 = 0;
              local_558 = 0;
              local_560 = 0;
              local_568 = 0;
              local_570 = CONCAT44(local_570._4_4_,*(undefined4 *)((longlong)plVar22 + 0x14));
              local_578 = (int)plVar22[3];
              (**(code **)(lVar12 + 8))
                        (plVar17,uVar7,(int)plVar22[2],*(undefined4 *)((longlong)plVar22 + 0x1c));
              local_4f8 = (longlong *)0x0;
              (**(code **)(*plVar1 + 0x298))(plVar1,0x1001,&local_4f8);
              if ((local_4f8 != (longlong *)0x0) &&
                 (iVar5 = *(int *)((longlong)plVar22 + 0x24), 0 < iVar5)) {
                uVar18 = FUN_140008520((int)plVar14[0x246]);
                uVar18 = FUN_140087730(uVar18);
                local_570 = 0;
                local_578 = 0;
                FUN_140145f60(uVar18,iVar5,local_4f8,0);
              }
            }
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar13 = *plVar2;
          }
          if (*(longlong **)(lVar13 + 0x20) <= plVar20) {
            _invalid_parameter_noinfo();
          }
          plVar20 = plVar20 + 1;
        }
        FUN_1403b5ba0(local_478);
        if (local_510 != (longlong *)0x0) {
          operator_delete(local_510);
        }
        local_510 = (longlong *)0x0;
        local_508 = (longlong *)0x0;
        local_500 = 0;
        operator_delete(local_528[0]);
        if (local_4d0 != (longlong *)0x0) {
          operator_delete(local_4d0);
        }
        local_4d0 = (longlong *)0x0;
        local_4c8 = (longlong *)0x0;
        local_4c0 = 0;
        operator_delete(local_4e8[0]);
        uVar4 = 1;
      }
    }
  }
  return uVar4;
}

// ==== CMsgRaceTrackProp::helper_1403b09d0  @1403b09d0  [medium:callgraph-r1]  (orig: FUN_1403b09d0)
void FUN_1403b09d0(undefined8 *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403b09d6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)*param_1 + 0x18))();
  return;
}

// ==== CMsgRaceTrackProp::helper_1403b09e0  @1403b09e0  [medium:callgraph-r1]  (orig: FUN_1403b09e0)
undefined8 FUN_1403b09e0(undefined8 *param_1,int param_2,uint param_3)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  
  if ((param_2 < 0) || (9 < param_3)) {
    return 0;
  }
  uVar6 = 0;
  lVar2 = (**(code **)(*(longlong *)*param_1 + 0x18))();
  if (lVar2 != 0) {
    do {
      plVar3 = (longlong *)(**(code **)(*(longlong *)*param_1 + 0x20))((longlong *)*param_1,uVar6);
      if ((plVar3 != (longlong *)0x0) &&
         (iVar1 = (**(code **)(*plVar3 + 0x10))(plVar3,0), param_2 == iVar1)) {
        uVar5 = (**(code **)(*plVar3 + 0x10))(plVar3,param_3);
        return uVar5;
      }
      uVar6 = uVar6 + 1;
      uVar4 = (**(code **)(*(longlong *)*param_1 + 0x18))();
    } while (uVar6 < uVar4);
  }
  return 0;
}

// ==== CMsgRaceTrackProp::helper_1403b0aa0  @1403b0aa0  [medium:callgraph-r2]  (orig: FUN_1403b0aa0)
undefined8 FUN_1403b0aa0(undefined8 *param_1)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  
  uVar6 = 0;
  lVar2 = (**(code **)(*(longlong *)*param_1 + 0x18))();
  if (lVar2 != 0) {
    do {
      plVar3 = (longlong *)(**(code **)(*(longlong *)*param_1 + 0x20))((longlong *)*param_1,uVar6);
      if (plVar3 != (longlong *)0x0) {
        iVar1 = (**(code **)(*plVar3 + 0x10))(plVar3,4);
        if (iVar1 == 0x3a) {
                    /* WARNING: Could not recover jumptable at 0x0001403b0b24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          uVar5 = (**(code **)(*plVar3 + 0x10))(plVar3,0);
          return uVar5;
        }
      }
      uVar6 = uVar6 + 1;
      uVar4 = (**(code **)(*(longlong *)*param_1 + 0x18))();
    } while (uVar6 < uVar4);
  }
  return 0;
}

// ==== CMsgRaceTrackProp::helper_1403b18a0  @1403b18a0  [medium:callgraph-r1]  (orig: FUN_1403b18a0)
undefined4 FUN_1403b18a0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  if (param_2 < 0) {
    return 0;
  }
  plVar3 = *(longlong **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x48) < plVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x28);
  lVar4 = 0;
  do {
    plVar2 = *(longlong **)(param_1 + 0x48);
    if (plVar2 < *(longlong **)(param_1 + 0x40)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar2) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    if (*plVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
        _invalid_parameter_noinfo();
      }
      if (param_2 == *(int *)*plVar3) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar4 = *plVar1;
        }
        if (*(longlong **)(lVar4 + 0x20) <= plVar3) {
          _invalid_parameter_noinfo();
        }
        return *(undefined4 *)(*plVar3 + 0xc);
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar3 + 1;
  } while( true );
}

// ==== CMsgRaceTrackProp::helper_1403b1cc0  @1403b1cc0  [medium:callgraph-r1]  (orig: FUN_1403b1cc0)
bool FUN_1403b1cc0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  if (param_2 < 0) {
    return false;
  }
  plVar3 = *(longlong **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x48) < plVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x28);
  lVar4 = 0;
  do {
    plVar2 = *(longlong **)(param_1 + 0x48);
    if (plVar2 < *(longlong **)(param_1 + 0x40)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar2) {
      return false;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    if (*plVar3 != 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
        _invalid_parameter_noinfo();
      }
      if (param_2 == *(int *)*plVar3) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar4 = *plVar1;
        }
        if (*(longlong **)(lVar4 + 0x20) <= plVar3) {
          _invalid_parameter_noinfo();
        }
        return *(int *)(*plVar3 + 0xc) != 0;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar3 + 1;
  } while( true );
}

// ==== CMsgRaceTrackProp::helper_1403b1e00  @1403b1e00  [medium:callgraph-r1]  (orig: FUN_1403b1e00)
undefined4 FUN_1403b1e00(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  plVar3 = *(longlong **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x48) < plVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x28);
  lVar4 = 0;
  do {
    plVar2 = *(longlong **)(param_1 + 0x48);
    if (plVar2 < *(longlong **)(param_1 + 0x40)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar2) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    if (*plVar3 != 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = lVar4;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
        _invalid_parameter_noinfo();
      }
      if (param_2 == *(int *)*plVar3) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar4 = *plVar1;
        }
        if (*(longlong **)(lVar4 + 0x20) <= plVar3) {
          _invalid_parameter_noinfo();
        }
        return *(undefined4 *)(*plVar3 + 4);
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar4;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar3 + 1;
  } while( true );
}

// ==== CMsgRaceTrackProp::helper_1403b1f20  @1403b1f20  [medium:callgraph-r1]  (orig: FUN_1403b1f20)
int FUN_1403b1f20(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  
  iVar4 = -1;
  if (-1 < param_2) {
    plVar3 = *(longlong **)(param_1 + 0x40);
    if (*(longlong **)(param_1 + 0x48) < plVar3) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(param_1 + 0x28);
    while( true ) {
      plVar2 = *(longlong **)(param_1 + 0x48);
      if (plVar2 < *(longlong **)(param_1 + 0x40)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x28))) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == plVar2) break;
      iVar4 = iVar4 + 1;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
        _invalid_parameter_noinfo();
      }
      if (*plVar3 != 0) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar1;
        }
        if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
          _invalid_parameter_noinfo();
        }
        if (*(int *)*plVar3 == param_2) {
          return iVar4;
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar3) {
        _invalid_parameter_noinfo();
      }
      plVar3 = plVar3 + 1;
    }
  }
  return iVar4;
}

// ==== CMsgRaceTrackProp::helper_1403b2740  @1403b2740  [medium:callgraph-r1]  (orig: FUN_1403b2740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403b2740(longlong param_1,int param_2)

{
  uint uVar1;
  longlong *plVar2;
  longlong *plVar3;
  void *pvVar4;
  char cVar5;
  int iVar6;
  longlong *plVar7;
  longlong lVar8;
  rsize_t _DstSize;
  uint uVar9;
  longlong lVar10;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 < 0) {
    return 0;
  }
  plVar7 = *(longlong **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x48) < plVar7) {
    _invalid_parameter_noinfo();
  }
  plVar2 = *(longlong **)(param_1 + 0x28);
  lVar8 = 0;
  do {
    plVar3 = *(longlong **)(param_1 + 0x48);
    if (plVar3 < *(longlong **)(param_1 + 0x40)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar3) {
      return 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar8;
    }
    else {
      lVar10 = *plVar2;
    }
    if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    if (*plVar7 != 0) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = lVar8;
      }
      else {
        lVar10 = *plVar2;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
        _invalid_parameter_noinfo();
      }
      if (param_2 == *(int *)*plVar7) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar8;
        }
        else {
          lVar10 = *plVar2;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        iVar6 = *(int *)(*plVar7 + 0xc);
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar8;
        }
        else {
          lVar10 = *plVar2;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        uVar1 = *(uint *)(*plVar7 + 4);
        uVar9 = iVar6 - 1;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar8;
        }
        else {
          lVar10 = *plVar2;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        *(int *)(*plVar7 + 0xc) = *(int *)(*plVar7 + 0xc) + -1;
        if (uVar9 == 0) {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar8 = *plVar2;
          }
          if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = (void *)*plVar7;
          iVar6 = FUN_140165d70(*(undefined8 *)(param_1 + 0x18));
          FUN_140165ce0(*(undefined8 *)(param_1 + 0x18),iVar6 + -1);
          lVar8 = *(longlong *)(param_1 + 0x48) - (longlong)(plVar7 + 1) >> 3;
          if (0 < lVar8) {
            _DstSize = lVar8 << 3;
            memmove_s(plVar7,_DstSize,plVar7 + 1,_DstSize);
          }
          *(longlong *)(param_1 + 0x48) = *(longlong *)(param_1 + 0x48) + -8;
          if ((plVar7 < *(longlong **)(param_1 + 0x40)) || (*(longlong **)(param_1 + 0x48) < plVar7)
             ) {
            _invalid_parameter_noinfo();
          }
          if (pvVar4 != (void *)0x0) {
            operator_delete(pvVar4);
          }
        }
        FUN_140452560(local_468);
        cVar5 = FUN_140452610(local_468,param_2,uVar9 & 0xffff,uVar1 & 0xffff);
        if (cVar5 == '\0') {
          FUN_1404525b0(local_468);
          return 0;
        }
        plVar7 = (longlong *)(*(longlong *)(param_1 + 0x18) + 0x10);
        (**(code **)(*plVar7 + 0x350))(plVar7,local_468);
        FUN_1404525b0(local_468);
        return 1;
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar8;
    }
    else {
      lVar10 = *plVar2;
    }
    if (*(longlong **)(lVar10 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  } while( true );
}

// ==== CMsgRaceTrackProp::helper_1403b2b70  @1403b2b70  [medium:callgraph-r1]  (orig: FUN_1403b2b70)
void FUN_1403b2b70(longlong param_1,int param_2,char param_3)

{
  longlong *plVar1;
  void *pvVar2;
  int iVar3;
  longlong lVar4;
  rsize_t _DstSize;
  longlong *_Dst;
  longlong *plVar5;
  
  if ((*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40) & 0xfffffffffffffff8U) == 0) {
    return;
  }
  iVar3 = FUN_1403b0aa0();
  if (iVar3 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403b2bcb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("Can\'t Get ConvProp at %s, %d");
    return;
  }
  _Dst = *(longlong **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x48) < _Dst) {
    _invalid_parameter_noinfo();
  }
  plVar5 = *(longlong **)(param_1 + 0x28);
  do {
    while( true ) {
      plVar1 = *(longlong **)(param_1 + 0x48);
      if (plVar1 < *(longlong **)(param_1 + 0x40)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar5 == (longlong *)0x0) || (plVar5 != *(longlong **)(param_1 + 0x28))) {
        _invalid_parameter_noinfo();
      }
      if (_Dst == plVar1) {
        FUN_140165ce0(*(undefined8 *)(param_1 + 0x18),
                      *(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40) >> 3);
        return;
      }
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar5;
      }
      if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      if (*_Dst == 0) {
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar4 = 0;
        }
        else {
          lVar4 = *plVar5;
        }
        if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
          _invalid_parameter_noinfo();
        }
        _Dst = _Dst + 1;
      }
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar5;
      }
      if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      if ((*(int *)(*_Dst + 4) == iVar3) && (param_3 == '\0')) break;
LAB_1403b2ce3:
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar5;
      }
      if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      pvVar2 = (void *)*_Dst;
      lVar4 = *(longlong *)(param_1 + 0x48) - (longlong)(_Dst + 1) >> 3;
      if (0 < lVar4) {
        _DstSize = lVar4 << 3;
        memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
      }
      *(longlong *)(param_1 + 0x48) = *(longlong *)(param_1 + 0x48) + -8;
      if ((_Dst < *(longlong **)(param_1 + 0x40)) || (*(longlong **)(param_1 + 0x48) < _Dst)) {
        _invalid_parameter_noinfo();
      }
      plVar5 = *(longlong **)(param_1 + 0x28);
      operator_delete(pvVar2);
    }
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar5;
    }
    if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)*_Dst != param_2) goto LAB_1403b2ce3;
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar5;
    }
    if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    _Dst = _Dst + 1;
  } while( true );
}

// ==== CMsgRaceTrackProp::helper_1403b5c00  @1403b5c00  [medium:callgraph-r1]  (orig: FUN_1403b5c00)
undefined8
FUN_1403b5c00(longlong param_1,undefined4 param_2,undefined2 param_3,undefined2 param_4,
             undefined2 param_5)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  *(undefined4 *)(param_1 + 8) = 0x819;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_2;
  **(undefined2 **)(param_1 + 0x428) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = 0;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6) = param_5;
  return CONCAT71((uint7)(byte)((ushort)param_5 >> 8),1);
}

// ==== CMsgRaceTrackProp::helper_1403b5c90  @1403b5c90  [medium:callgraph-r1]  (orig: FUN_1403b5c90)
ulonglong FUN_1403b5c90(longlong param_1,int param_2)

{
  short *psVar1;
  longlong lVar2;
  ulonglong in_RAX;
  
  if (param_2 != 0) {
    in_RAX = (longlong)*(int *)(param_1 + 0xc) + 4;
    if (in_RAX < 0x400) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 4;
      *(int *)(*(longlong *)(param_1 + 0x428) + 0xc +
              (ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 4) = param_2;
      lVar2 = *(longlong *)(param_1 + 0x428);
      psVar1 = (short *)(lVar2 + 2);
      *psVar1 = *psVar1 + 1;
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgRaceTrackProp::ctor_or_dtor  @140452560  [high:vtable-assign]  (orig: FUN_140452560)
undefined8 * FUN_140452560(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRaceTrackProp::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRaceTrackProp::ctor_or_dtor  @1404525b0  [high:vtable-assign]  (orig: FUN_1404525b0)
void FUN_1404525b0(undefined8 *param_1)

{
  *param_1 = CMsgRaceTrackProp::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRaceTrackProp::vfunc_1  @1404525e0  [high:rtti-vtable]  (orig: FUN_1404525e0)
undefined8 FUN_1404525e0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgRaceTrackProp::ctor_or_dtor  @140452690  [high:vtable-assign]  (orig: FUN_140452690)
undefined8 * FUN_140452690(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRaceTrackProp::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRaceTrackProp::vfunc_3  @1404526e0  [high:rtti-vtable]  (orig: FUN_1404526e0)
void FUN_1404526e0(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong *plVar12;
  undefined4 local_58;
  undefined4 local_54;
  int local_50;
  int local_4c;
  int local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined2 local_38;
  undefined2 local_36;
  undefined4 local_34;
  
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar9 = (longlong *)
           (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x88))(*(longlong **)(lVar8 + 0x90),param_1)
  ;
  if (plVar9 != (longlong *)0x0) {
    cVar1 = (**(code **)(plVar9[2] + 0x220))(plVar9 + 2);
    if (cVar1 == '\0') {
      pIVar10 = theInstance();
      lVar8 = plVar9[2];
      uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_DIE");
      (**(code **)(lVar8 + 0x358))(plVar9 + 2,uVar11);
      return;
    }
    cVar1 = FUN_140166160(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if ((((cVar1 != '\0') &&
         (cVar1 = (**(code **)(plVar9[2] + 0x2d8))(plVar9 + 2,0x38), cVar1 == '\0')) &&
        (cVar1 = (**(code **)(plVar9[2] + 0x2d8))(plVar9 + 2,0x37), cVar1 == '\0')) &&
       ((cVar1 = (**(code **)(plVar9[2] + 0x2d8))(plVar9 + 2,0x18), cVar1 == '\0' &&
        (cVar1 = (**(code **)(plVar9[2] + 0x2d8))(plVar9 + 2,0x6e), cVar1 == '\0')))) {
      iVar2 = FUN_140165c80(plVar9);
      iVar3 = FUN_140166250(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if ((-1 < iVar3) && (iVar3 <= iVar2 + -1)) {
        uVar4 = FUN_140166200(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        iVar2 = FUN_140165ee0(plVar9,uVar4);
        iVar3 = FUN_140165f30(plVar9,uVar4);
        iVar5 = FUN_140165f80(plVar9,uVar4);
        iVar6 = FUN_140165fd0(plVar9,uVar4);
        uVar7 = FUN_140166110(plVar9,uVar4);
        local_58 = *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4);
        local_54 = uVar4;
        local_50 = iVar3;
        local_4c = iVar5;
        local_3c = FUN_140166070(plVar9,uVar4);
        lVar8 = *(longlong *)(param_1 + 0x428);
        local_38 = *(undefined2 *)(lVar8 + 8);
        local_36 = *(undefined2 *)(lVar8 + 10);
        local_48 = iVar6;
        local_44 = FUN_140165e90(plVar9,*(undefined4 *)(lVar8 + 4));
        local_40 = FUN_140166020(plVar9,uVar4);
        local_34 = uVar7;
        if (iVar2 == 1) {
          if (iVar6 == 0x3a) {
            cVar1 = FUN_140177a30(plVar9,&local_58);
          }
          else {
            cVar1 = FUN_1401776f0(plVar9,&local_58);
          }
        }
        else if (iVar2 == 2) {
          if (*(int *)(*(longlong *)(param_1 + 0x428) + 8) == 0) {
            return;
          }
          lVar8 = (**(code **)(plVar9[2] + 0x160))(plVar9 + 2);
          if (lVar8 == 0) {
            log_InlineLogERROR("Can\'t Get GameMap at %s, %d");
            return;
          }
          uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          plVar12 = (longlong *)FUN_140087650(uVar11);
          plVar12 = (longlong *)
                    (**(code **)(*plVar12 + 0x98))
                              (plVar12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
          if (plVar12 == (longlong *)0x0) {
            return;
          }
          cVar1 = (**(code **)(plVar12[2] + 0x220))(plVar12 + 2);
          if (cVar1 == '\0') {
            return;
          }
          if (iVar3 == 1) {
            lVar8 = *plVar9;
            uVar4 = (**(code **)(*plVar12 + 8))(plVar12);
            lVar8 = (**(code **)(lVar8 + 0x28))(plVar9,uVar4);
            if (lVar8 == 0) {
              return;
            }
            cVar1 = FUN_140177870(plVar9,&local_58,plVar12);
          }
          else {
            uVar4 = (**(code **)(plVar12[2] + 0x40))(plVar12 + 2);
            uVar7 = (**(code **)(plVar12[2] + 0x48))(plVar12 + 2);
            iVar2 = (**(code **)(plVar9[2] + 0x158))(plVar9 + 2,uVar4,uVar7);
            if (iVar5 < iVar2) {
              return;
            }
            cVar1 = FUN_140177870(plVar9,&local_58,plVar12);
          }
        }
        else if (iVar2 == 3) {
          cVar1 = FUN_1401bad20(plVar9,&local_58);
        }
        else {
          if (iVar2 != 4) {
            return;
          }
          lVar8 = (**(code **)(plVar9[2] + 0x160))(plVar9 + 2);
          if (lVar8 == 0) {
            log_InlineLogERROR("Can\'t Get GameMap at %s, %d");
            return;
          }
          cVar1 = FUN_1402c3cc0(lVar8,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8),
                                *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10));
          if (cVar1 == '\0') {
            return;
          }
          cVar1 = FUN_1401662d0(plVar9,&local_58);
        }
        if (cVar1 != '\0') {
          FUN_1401661b0(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        }
      }
    }
  }
  return;
}

