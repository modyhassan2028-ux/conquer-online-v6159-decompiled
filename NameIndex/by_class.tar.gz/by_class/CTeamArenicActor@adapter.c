// ==== CTeamArenicActor@adapter::helper_140165890  @140165890  [medium:callgraph-r0]  (orig: FUN_140165890)
void FUN_140165890(longlong param_1)

{
  FUN_140373550(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658a0  @1401658a0  [medium:callgraph-r0]  (orig: FUN_1401658a0)
void FUN_1401658a0(longlong param_1)

{
  FUN_140373560(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658b0  @1401658b0  [medium:callgraph-r0]  (orig: FUN_1401658b0)
void FUN_1401658b0(longlong param_1)

{
  FUN_1403735d0(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658c0  @1401658c0  [medium:callgraph-r0]  (orig: FUN_1401658c0)
void FUN_1401658c0(longlong param_1)

{
  FUN_1403735e0(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658d0  @1401658d0  [medium:callgraph-r0]  (orig: FUN_1401658d0)
void FUN_1401658d0(longlong param_1)

{
  FUN_140373650(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658e0  @1401658e0  [medium:callgraph-r0]  (orig: FUN_1401658e0)
void FUN_1401658e0(longlong param_1)

{
  FUN_140373660(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_1401658f0  @1401658f0  [medium:callgraph-r0]  (orig: FUN_1401658f0)
void FUN_1401658f0(longlong param_1)

{
  FUN_1403736d0(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140165900  @140165900  [medium:callgraph-r0]  (orig: FUN_140165900)
void FUN_140165900(longlong param_1)

{
  FUN_1403736e0(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140165910  @140165910  [medium:callgraph-r0]  (orig: FUN_140165910)
void FUN_140165910(longlong param_1)

{
  FUN_140373750(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140165920  @140165920  [medium:callgraph-r0]  (orig: FUN_140165920)
void FUN_140165920(longlong param_1)

{
  FUN_140373760(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140165990  @140165990  [medium:callgraph-r0]  (orig: FUN_140165990)
undefined1 FUN_140165990(longlong param_1)

{
  undefined1 uVar1;
  
  uVar1 = FUN_1403738d0(param_1 + 0xe78);
  return uVar1;
}

// ==== CTeamArenicActor@adapter::helper_1401659b0  @1401659b0  [medium:callgraph-r0]  (orig: FUN_1401659b0)
void FUN_1401659b0(longlong param_1)

{
  FUN_1403738e0(param_1 + 0xe78);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140373550  @140373550  [medium:callgraph-r1]  (orig: FUN_140373550)
undefined4 FUN_140373550(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x198);
}

// ==== CTeamArenicActor@adapter::helper_140373560  @140373560  [medium:callgraph-r1]  (orig: FUN_140373560)
void FUN_140373560(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x198) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"team_athlete_point");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::helper_1403735d0  @1403735d0  [medium:callgraph-r1]  (orig: FUN_1403735d0)
undefined4 FUN_1403735d0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x19c);
}

// ==== CTeamArenicActor@adapter::helper_1403735e0  @1403735e0  [medium:callgraph-r1]  (orig: FUN_1403735e0)
void FUN_1403735e0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x19c) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"team_athlete_win");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::helper_140373650  @140373650  [medium:callgraph-r1]  (orig: FUN_140373650)
undefined4 FUN_140373650(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a0);
}

// ==== CTeamArenicActor@adapter::helper_140373660  @140373660  [medium:callgraph-r1]  (orig: FUN_140373660)
void FUN_140373660(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1a0) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"team_athlete_lost");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::helper_1403736d0  @1403736d0  [medium:callgraph-r1]  (orig: FUN_1403736d0)
undefined4 FUN_1403736d0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a4);
}

// ==== CTeamArenicActor@adapter::helper_1403736e0  @1403736e0  [medium:callgraph-r1]  (orig: FUN_1403736e0)
void FUN_1403736e0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1a4) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"team_athlete_season_win");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::helper_140373750  @140373750  [medium:callgraph-r1]  (orig: FUN_140373750)
undefined4 FUN_140373750(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a8);
}

// ==== CTeamArenicActor@adapter::helper_140373760  @140373760  [medium:callgraph-r1]  (orig: FUN_140373760)
void FUN_140373760(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1a8) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"team_athlete_season_lost");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::helper_1403738d0  @1403738d0  [medium:callgraph-r1]  (orig: FUN_1403738d0)
undefined1 FUN_1403738d0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x1ac);
}

// ==== CTeamArenicActor@adapter::helper_1403738e0  @1403738e0  [medium:callgraph-r1]  (orig: FUN_1403738e0)
void FUN_1403738e0(longlong param_1,undefined1 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined1 *)(param_1 + 0x1ac) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"family_arenic");
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_1  @14057ff60  [high:rtti-vtable]  (orig: FUN_14057ff60)
void FUN_14057ff60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_6  @14057ff80  [high:rtti-vtable]  (orig: FUN_14057ff80)
undefined8 FUN_14057ff80(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165970(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_7  @14057ffe0  [high:rtti-vtable]  (orig: FUN_14057ffe0)
undefined8 FUN_14057ffe0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580033. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_8  @140580040  [high:rtti-vtable]  (orig: FUN_140580040)
undefined8 FUN_140580040(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580093. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_61  @1405800a0  [high:rtti-vtable]  (orig: FUN_1405800a0)
void FUN_1405800a0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401659b0(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_63  @140580100  [high:rtti-vtable]  (orig: FUN_140580100)
void FUN_140580100(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165950(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_64  @140580160  [high:rtti-vtable]  (orig: FUN_140580160)
void FUN_140580160(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140177500(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_62  @1405801c0  [high:rtti-vtable]  (orig: FUN_1405801c0)
undefined8 FUN_1405801c0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165990(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_65  @140580220  [high:rtti-vtable]  (orig: FUN_140580220)
undefined8 FUN_140580220(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165940(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_66  @140580280  [high:rtti-vtable]  (orig: FUN_140580280)
undefined8 FUN_140580280(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165930(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_4  @1405802e0  [high:rtti-vtable]  (orig: FUN_1405802e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405802e0(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0xa4);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xffff00;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CTeamArenicActor@adapter::vfunc_5  @140580440  [high:rtti-vtable]  (orig: FUN_140580440)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140580440(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0xbe);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CTeamArenicActor@adapter::vfunc_21  @1405805a0  [high:rtti-vtable]  (orig: FUN_1405805a0)
bool FUN_1405805a0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_140166ec0(lVar2);
  return iVar1 != 0;
}

// ==== CTeamArenicActor@adapter::vfunc_43  @140580600  [high:rtti-vtable]  (orig: FUN_140580600)
undefined8 FUN_140580600(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580653. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_19  @140580660  [high:rtti-vtable]  (orig: FUN_140580660)
undefined8 FUN_140580660(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14018eb30(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_20  @1405806c0  [high:rtti-vtable]  (orig: FUN_1405806c0)
ulonglong FUN_1405806c0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580731. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_11  @140580740  [high:rtti-vtable]  (orig: FUN_140580740)
undefined1 * FUN_140580740(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580798. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_12  @1405807a0  [high:rtti-vtable]  (orig: FUN_1405807a0)
undefined8 FUN_1405807a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405807f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_13  @140580800  [high:rtti-vtable]  (orig: FUN_140580800)
undefined1 FUN_140580800(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CTeamArenicActor@adapter::vfunc_16  @140580860  [high:rtti-vtable]  (orig: FUN_140580860)
bool FUN_140580860(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CTeamArenicActor@adapter::vfunc_17  @140580880  [high:rtti-vtable]  (orig: FUN_140580880)
ulonglong FUN_140580880(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    in_RAX = 0;
    if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405808ad. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x250))(lVar1 + 0x10);
      return uVar2;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CTeamArenicActor@adapter::vfunc_18  @1405808c0  [high:rtti-vtable]  (orig: FUN_1405808c0)
void FUN_1405808c0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401732e0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_14  @140580940  [high:rtti-vtable]  (orig: FUN_140580940)
undefined8 FUN_140580940(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580993. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_15  @1405809a0  [high:rtti-vtable]  (orig: FUN_1405809a0)
undefined8 FUN_1405809a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405809f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_22  @140580a00  [high:rtti-vtable]  (orig: FUN_140580a00)
ulonglong FUN_140580a00(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7e10(lVar1,param_3);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_24  @140580a60  [high:rtti-vtable]  (orig: FUN_140580a60)
ulonglong FUN_140580a60(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR("CTeamArenicActor::IsUserAlive. User[%u]");
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580a9e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_25  @140580ab0  [high:rtti-vtable]  (orig: FUN_140580ab0)
void FUN_140580ab0(longlong param_1,undefined8 param_2,undefined1 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x000140580af3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CTeamArenicActor::RebornUser. User[%u]");
    return;
  }
  FUN_1401c6d40(lVar1,param_3,param_4,param_5,0);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_26  @140580b30  [high:rtti-vtable]  (orig: FUN_140580b30)
undefined8 FUN_140580b30(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_27  @140580b90  [high:rtti-vtable]  (orig: FUN_140580b90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140580b90(longlong param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR("CTeamArenicActor::SetUserPkMode. User[%u]");
  }
  else {
    FUN_140161fa0(lVar2,param_3);
    FUN_140362560(local_478);
    cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
    }
    FUN_1403625e0(local_478);
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_28  @140580c50  [high:rtti-vtable]  (orig: FUN_140580c50)
void FUN_140580c50(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401a6420(lVar1,param_3,param_4,param_5);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_29  @140580cd0  [high:rtti-vtable]  (orig: FUN_140580cd0)
void FUN_140580cd0(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140162110(lVar1,2,param_3);
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_30  @140580d10  [high:rtti-vtable]  (orig: FUN_140580d10)
undefined8 FUN_140580d10(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580d63. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_31  @140580d70  [high:rtti-vtable]  (orig: FUN_140580d70)
undefined8 FUN_140580d70(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140580dc1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x88))(plVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_32  @140580dd0  [high:rtti-vtable]  (orig: FUN_140580dd0)
undefined8 FUN_140580dd0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1403837b0(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_37  @140580e30  [high:rtti-vtable]  (orig: FUN_140580e30)
ulonglong FUN_140580e30(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_38  @140580eb0  [high:rtti-vtable]  (orig: FUN_140580eb0)
undefined8
FUN_140580eb0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
             undefined1 param_5,undefined1 param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140340e50(lVar1,param_3,param_4,param_5,1,0,param_6);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_57  @140580f50  [high:rtti-vtable]  (orig: FUN_140580f50)
undefined1 FUN_140580f50(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140580f7e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar2 + 0x20))(plVar2,param_2,param_3);
    return uVar1;
  }
  return 0;
}

// ==== CTeamArenicActor@adapter::vfunc_58  @140580f90  [high:rtti-vtable]  (orig: FUN_140580f90)
bool FUN_140580f90(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
    iVar1 = (**(code **)(*plVar2 + 0x30))(plVar2,param_2);
    return iVar1 != 0;
  }
  return false;
}

// ==== CTeamArenicActor@adapter::vfunc_59  @140580fd0  [high:rtti-vtable]  (orig: FUN_140580fd0)
undefined8 FUN_140580fd0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)FUN_140118320();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140580fef. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x28))(plVar1,param_2);
    return uVar2;
  }
  return 0;
}

// ==== CTeamArenicActor@adapter::vfunc_53  @140581000  [high:rtti-vtable]  (orig: FUN_140581000)
ulonglong FUN_140581000(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR("CTeamArenicActor::IsUserInArenic, not found arenic module interface");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058107a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_54  @140581080  [high:rtti-vtable]  (orig: FUN_140581080)
ulonglong FUN_140581080(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  undefined8 *puVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar2 = (undefined8 *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR("CTeamArenicActor::IsArenicWitness, not found arenic module interface");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405810fa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)*puVar2)(puVar2,param_2);
  return uVar3;
}

// ==== CTeamArenicActor@adapter::vfunc_55  @140581100  [high:rtti-vtable]  (orig: FUN_140581100)
void FUN_140581100(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140581177. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CTeamArenicActor::ExitArenicWitness, not found arenic module interface");
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581191. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_2,param_3);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_39  @1405811a0  [high:rtti-vtable]  (orig: FUN_1405811a0)
void FUN_1405811a0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140581205. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR(
                      "CTeamArenicActor::OnUserArenicHornorChange, not found arenic module interface"
                      );
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581216. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x110))(plVar1,param_2);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_40  @140581220  [high:rtti-vtable]  (orig: FUN_140581220)
void FUN_140581220(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x00014058123a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_80  @140581240  [high:rtti-vtable]  (orig: FUN_140581240)
ulonglong FUN_140581240(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405812d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x248))(plVar1,param_2);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_81  @1405812e0  [high:rtti-vtable]  (orig: FUN_1405812e0)
undefined1 * FUN_1405812e0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581381. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_67  @140581390  [high:rtti-vtable]  (orig: FUN_140581390)
void FUN_140581390(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401658a0(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_68  @1405813f0  [high:rtti-vtable]  (orig: FUN_1405813f0)
undefined8 FUN_1405813f0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR("CTeamArenicActor::GetTeamAthletePoint. User[%u]");
    return 0;
  }
  uVar2 = FUN_140165890(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_69  @140581430  [high:rtti-vtable]  (orig: FUN_140581430)
void FUN_140581430(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401658c0(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_70  @140581490  [high:rtti-vtable]  (orig: FUN_140581490)
undefined8 FUN_140581490(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401658b0(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_71  @1405814f0  [high:rtti-vtable]  (orig: FUN_1405814f0)
void FUN_1405814f0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401658e0(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_72  @140581550  [high:rtti-vtable]  (orig: FUN_140581550)
undefined8 FUN_140581550(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401658d0(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_73  @1405815b0  [high:rtti-vtable]  (orig: FUN_1405815b0)
void FUN_1405815b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165900(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_74  @140581610  [high:rtti-vtable]  (orig: FUN_140581610)
undefined8 FUN_140581610(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401658f0(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_75  @140581670  [high:rtti-vtable]  (orig: FUN_140581670)
void FUN_140581670(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165920(lVar1,param_3,1);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_76  @1405816d0  [high:rtti-vtable]  (orig: FUN_1405816d0)
undefined8 FUN_1405816d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165910(lVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_77  @140581730  [high:rtti-vtable]  (orig: FUN_140581730)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140581730(undefined8 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_148 [32];
  undefined4 local_128;
  undefined8 local_120;
  char local_118;
  undefined1 local_117 [254];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    local_118 = '\0';
    memset(local_117,0,0xff);
    local_128 = param_3;
    _snprintf(&local_118,0x100,"</F>TeamArenicWins</N>%lu</N>%u");
    local_19 = 0;
    lVar3 = DAT_140975bf0;
    if (DAT_140975bf0 == 0) {
      local_128 = 0x3cd;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    local_120 = 0;
    local_128 = 0;
    cVar1 = FUN_140286530(lVar3,&local_118,param_2,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                ("Lua return fault, Call From:CTeamArenicActor::OnTeamerWin, lua function:%s.");
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_78  @140581830  [high:rtti-vtable]  (orig: FUN_140581830)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140581830(undefined8 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_148 [32];
  undefined4 local_128;
  undefined8 local_120;
  char local_118;
  undefined1 local_117 [254];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    local_118 = '\0';
    memset(local_117,0,0xff);
    local_128 = param_3;
    _snprintf(&local_118,0x100,"</F>TeamArenicCompetes</N>%lu</N>%u");
    local_19 = 0;
    lVar3 = DAT_140975bf0;
    if (DAT_140975bf0 == 0) {
      local_128 = 0x3cd;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    local_120 = 0;
    local_128 = 0;
    cVar1 = FUN_140286530(lVar3,&local_118,param_2,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                ("Lua return fault, Call From:CTeamArenicActor::OnTeamerCompete, lua function:%s.");
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_82  @140581930  [high:rtti-vtable]  (orig: FUN_140581930)
undefined8 FUN_140581930(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581983. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_60  @140581990  [high:rtti-vtable]  (orig: FUN_140581990)
undefined8 FUN_140581990(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  plVar2 = (longlong *)FUN_140118320();
  if (plVar2 != (longlong *)0x0) {
    iVar1 = (**(code **)(*plVar2 + 0x28))(plVar2,param_2);
    if (iVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405819ce. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2,iVar1,0);
      return uVar3;
    }
  }
  return 0;
}

// ==== CTeamArenicActor@adapter::vfunc_9  @1405819e0  [high:rtti-vtable]  (orig: FUN_1405819e0)
undefined8 FUN_1405819e0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581a31. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_10  @140581a40  [high:rtti-vtable]  (orig: FUN_140581a40)
int FUN_140581a40(undefined8 param_1,ulonglong param_2)

{
  ulonglong uVar1;
  
  uVar1 = (param_2 & 0xffffffff) / 1000;
  return (int)uVar1 + (int)(uVar1 / 10) * -10;
}

// ==== CTeamArenicActor@adapter::vfunc_33  @140581a70  [high:rtti-vtable]  (orig: FUN_140581a70)
undefined8 FUN_140581a70(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140581ac1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x60))(plVar1);
  return uVar2;
}

// ==== CTeamArenicActor@adapter::vfunc_34  @140581ad0  [high:rtti-vtable]  (orig: FUN_140581ad0)
undefined8 FUN_140581ad0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140581b35. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x120))(plVar1,param_2);
      return uVar2;
    }
  }
  return 0;
}

// ==== CTeamArenicActor@adapter::vfunc_41  @140581b40  [high:rtti-vtable]  (orig: FUN_140581b40)
void FUN_140581b40(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
                    /* WARNING: Could not recover jumptable at 0x000140581b68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CTeamArenicActor::DetachKeepGhostStatus. User[%u]");
    return;
  }
  plVar3 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2,0x6a);
  if (cVar1 != '\0') {
    plVar3 = (longlong *)FUN_1401181a0();
    (**(code **)(*plVar3 + 0x10))(plVar3,param_2,0x6a);
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_83  @140581bb0  [high:rtti-vtable]  (orig: FUN_140581bb0)
void FUN_140581bb0(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_23  @140581bc0  [high:rtti-vtable]  (orig: FUN_140581bc0)
undefined8 FUN_140581bc0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_1401a4030(lVar2,param_3);
  if (cVar1 == '\0') {
    FUN_140179040(lVar2,param_3);
    return 0;
  }
  return 1;
}

// ==== CTeamArenicActor@adapter::vfunc_35  @140581c50  [high:rtti-vtable]  (orig: FUN_140581c50)
undefined1 FUN_140581c50(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x12c8);
}

// ==== CTeamArenicActor@adapter::vfunc_0  @140581cb0  [high:rtti-vtable]  (orig: FUN_140581cb0)
void FUN_140581cb0(longlong param_1)

{
  FUN_140581d40(param_1 + -8);
  return;
}

// ==== CTeamArenicActor@adapter::helper_140581d40  @140581d40  [medium:callgraph-r0]  (orig: FUN_140581d40)
undefined8 * FUN_140581d40(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTeamArenicActor::vftable;
  param_1[1] = adapter::CTeamArenicActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTeamArenicActor@adapter::vfunc_3  @140581e40  [high:rtti-vtable]  (orig: FUN_140581e40)
void FUN_140581e40(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_45  @140581f00  [high:rtti-vtable]  (orig: FUN_140581f00)
bool FUN_140581f00(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CTeamArenicActor@adapter::vfunc_46  @140581f80  [high:rtti-vtable]  (orig: FUN_140581f80)
ulonglong FUN_140581f80(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x14) & 1);
}

// ==== CTeamArenicActor@adapter::vfunc_47  @140582050  [high:rtti-vtable]  (orig: FUN_140582050)
ulonglong FUN_140582050(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1e) & 1);
}

// ==== CTeamArenicActor@adapter::vfunc_48  @140582120  [high:rtti-vtable]  (orig: FUN_140582120)
ulonglong FUN_140582120(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 2) & 1);
}

// ==== CTeamArenicActor@adapter::vfunc_49  @1405821f0  [high:rtti-vtable]  (orig: FUN_1405821f0)
void FUN_1405821f0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140582251. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x168))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_51  @140582260  [high:rtti-vtable]  (orig: FUN_140582260)
ulonglong FUN_140582260(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  uint extraout_var;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)(extraout_var >> 5 & 1);
}

// ==== CTeamArenicActor@adapter::vfunc_50  @140582330  [high:rtti-vtable]  (orig: FUN_140582330)
ulonglong FUN_140582330(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x15) & 1);
}

// ==== CTeamArenicActor@adapter::vfunc_52  @140582400  [high:rtti-vtable]  (orig: FUN_140582400)
void FUN_140582400(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140582454. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x160))();
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_36  @140582460  [high:rtti-vtable]  (orig: FUN_140582460)
undefined8 FUN_140582460(longlong param_1)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint in_stack_ffffffffffffffd8;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = *(undefined2 *)(lVar5 + 0xf0e);
  uVar2 = *(undefined2 *)(lVar5 + 0xf0c);
  uVar3 = FUN_140161f50(lVar5);
  in_stack_ffffffffffffffd8 = in_stack_ffffffffffffffd8 & 0xffffff00;
  iVar4 = FUN_1401c55b0(lVar5,uVar3,uVar2,uVar1,in_stack_ffffffffffffffd8);
  if (iVar4 != 0) {
    local_18 = 0;
    local_14 = 0;
    local_10 = 0;
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar6 = FUN_1400d6610(uVar6);
    FUN_140006c50(uVar6,&local_18);
    FUN_1401c55b0(lVar5,local_18,local_14,local_10,in_stack_ffffffffffffffd8 & 0xffffff00);
  }
  return 1;
}

// ==== CTeamArenicActor@adapter::vfunc_1  @140582550  [high:rtti-vtable]  (orig: FUN_140582550)
void FUN_140582550(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar4);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_0  @140582640  [high:rtti-vtable]  (orig: FUN_140582640)
void FUN_140582640(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar1 + 0x60))(plVar1,param_2,0xffffffff,0,param_3,param_4);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_44  @140582690  [high:rtti-vtable]  (orig: FUN_140582690)
ulonglong FUN_140582690(longlong param_1)

{
  uint extraout_var;
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(lVar1 + 0x10);
    uVar2 = 0;
    if (lVar1 != 0) {
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
      (**(code **)(*plVar3 + 0x58))(plVar3);
      return (ulonglong)(extraout_var & 1);
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CTeamArenicActor@adapter::vfunc_79  @140582720  [high:rtti-vtable]  (orig: FUN_140582720)
void FUN_140582720(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140261720(lVar1,param_2,6);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_84  @140582780  [high:rtti-vtable]  (orig: FUN_140582780)
void FUN_140582780(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,0,0);
  return;
}

// ==== CTeamArenicActor@adapter::vfunc_42  @1405827f0  [high:rtti-vtable]  (orig: FUN_1405827f0)
undefined1 FUN_1405827f0(longlong *param_1,undefined4 param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined1 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *local_res20;
  longlong *local_a8 [3];
  longlong *local_90;
  longlong *local_88;
  undefined8 local_80;
  longlong *local_78;
  longlong *local_70;
  longlong *local_68;
  longlong *local_60;
  longlong *local_58;
  longlong *local_50;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  lVar4 = FUN_140008520((int)param_1[3]);
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x98) + 0x10))
                    (*(longlong **)(lVar4 + 0x98),param_2,1);
  if (lVar4 != 0) {
    local_res20 = operator_new(8);
    local_a8[0] = (longlong *)0x0;
    if (local_res20 != (longlong *)0x0) {
      *local_res20 = (longlong)local_a8;
      local_a8[0] = local_res20;
    }
    local_90 = (longlong *)0x0;
    local_88 = (longlong *)0x0;
    local_80 = 0;
    FUN_1402d2100(lVar4,local_a8);
    plVar9 = local_90;
    local_68 = local_88;
    if (((longlong)local_88 - (longlong)local_90 & 0xfffffffffffffff8U) != 0) {
      local_60 = local_90;
      if (local_88 < local_90) {
        _invalid_parameter_noinfo();
      }
      plVar8 = local_88;
      plVar6 = local_a8[0];
      local_78 = local_a8[0];
      local_50 = local_a8[0];
      local_68 = local_88;
      if (local_88 < local_90) {
        _invalid_parameter_noinfo();
      }
      uVar7 = 0;
      local_78 = local_a8[0];
      while( true ) {
        lVar4 = 0;
        if ((plVar6 == (longlong *)0x0) || (plVar6 != local_78)) {
          _invalid_parameter_noinfo();
        }
        if (plVar9 == plVar8) break;
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar4 = *plVar6;
        }
        if (*(longlong **)(lVar4 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar5 = (longlong *)*plVar9;
        if (plVar5 != (longlong *)0x0) {
          local_70 = (longlong *)0x0;
          cVar2 = (**(code **)(*plVar5 + 0x40))(plVar5,&local_70);
          if ((cVar2 != '\0') && (local_70 != (longlong *)0x0)) {
            local_res20 = (longlong *)0x0;
            cVar2 = (**(code **)(*local_70 + 0x298))(local_70,0x1001,&local_res20);
            if ((cVar2 != '\0') && (local_res20 != (longlong *)0x0)) {
              plVar5 = (longlong *)CurrentInstanceGet();
              if (plVar5 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                if (local_90 != (longlong *)0x0) {
                  operator_delete(local_90);
                }
                local_90 = (longlong *)0x0;
                local_88 = (longlong *)0x0;
                local_80 = 0;
                operator_delete(local_a8[0]);
                return 0;
              }
              plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x22);
              local_58 = plVar5;
              if (plVar5 != (longlong *)0x0) {
                lVar4 = *plVar5;
                lVar1 = *param_1;
                plVar9 = local_res20 + 2;
                uVar3 = (**(code **)(*local_res20 + 8))();
                (**(code **)(lVar4 + 0x130))(plVar5,uVar3);
                uVar3 = (**(code **)(*local_res20 + 8))();
                (**(code **)(lVar4 + 0x128))(plVar5,uVar3);
                uVar3 = (**(code **)(*local_res20 + 8))();
                (**(code **)(lVar1 + 0x1a8))(param_1,uVar3);
                uVar3 = (**(code **)(*local_res20 + 8))();
                (**(code **)(lVar1 + 0x1b0))(param_1,uVar3);
                uVar3 = (**(code **)(*local_res20 + 8))();
                (**(code **)(lVar4 + 0x110))(local_58,uVar3);
                (**(code **)(*plVar9 + 0x168))(plVar9);
                (**(code **)(*local_res20 + 8))();
                log_InlineLogERROR(
                                  "CTeamArenicActor::ClearArenicMap, kick out user: %u, map: %u, teamwitness: %d, witness: %d, in arenic: %d, join team arenic: %d, team arenic status: %d"
                                  );
                plVar6 = local_50;
                plVar8 = local_68;
                plVar9 = local_60;
              }
              (**(code **)(*(longlong *)param_1[2] + 0x50))
                        ((longlong *)param_1[2],local_res20,
                         "CTeamArenicActor::ClearArenicMap, invalid stay in team arenic");
              uVar7 = 1;
            }
          }
        }
        lVar4 = 0;
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar4 = *plVar6;
        }
        if (*(longlong **)(lVar4 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar9 = plVar9 + 1;
        local_60 = plVar9;
      }
      if (local_90 != (longlong *)0x0) {
        operator_delete(local_90);
      }
      local_90 = (longlong *)0x0;
      local_88 = (longlong *)0x0;
      local_80 = 0;
      operator_delete(local_a8[0]);
      return uVar7;
    }
    if (local_90 != (longlong *)0x0) {
      operator_delete(local_90);
    }
    local_90 = (longlong *)0x0;
    local_88 = (longlong *)0x0;
    local_80 = 0;
    operator_delete(local_a8[0]);
  }
  return 0;
}

// ==== CTeamArenicActor@adapter::vfunc_56  @140582c50  [high:rtti-vtable]  (orig: FUN_140582c50)
undefined8 FUN_140582c50(undefined8 param_1,undefined4 param_2,longlong param_3)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  FUN_140036640(param_3);
  plVar1 = (longlong *)FUN_140118320();
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x38))(plVar1,param_2,param_3);
  }
  uVar2 = *(longlong *)(param_3 + 0x20) - *(longlong *)(param_3 + 0x18);
  return CONCAT71((int7)(uVar2 >> 8),(uVar2 & 0xfffffffffffffffc) != 0);
}

// ==== CTeamArenicActor@adapter::vfunc_2  @140582ca0  [high:rtti-vtable]  (orig: FUN_140582ca0)
void FUN_140582ca0(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  local_res20 = operator_new(8);
  local_68[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_68;
    local_68[0] = local_res20;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar6 + 0x38))(plVar6,local_68,param_3);
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      if ((void *)param_2[3] != (void *)0x0) {
        operator_delete((void *)param_2[3]);
      }
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      operator_delete((void *)*param_2);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),*puVar9);
    puVar2 = local_48;
    if (lVar4 != 0) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar4 + 0x122c));
      if (local_50 != (undefined4 *)0x0) {
        uVar7 = local_40 - (longlong)local_50 >> 2;
      }
      if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar7) {
        *local_48 = *(undefined4 *)(lVar4 + 0x122c);
        local_48 = local_48 + 1;
      }
      else {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_50;
        plVar6 = local_68[0];
        if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
          lVar4 = 0;
        }
        else {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
            _invalid_parameter_noinfo();
          }
          lVar4 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_88 = SUB84(plVar6,0);
        uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_80 = SUB84(puVar2,0);
        uStack_7c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_78 = local_88;
        uStack_74 = uStack_84;
        uStack_70 = uStack_80;
        uStack_6c = uStack_7c;
        FUN_140036c20(local_68,&local_78,1,&local_res20);
        puVar2 = local_50;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_68[0];
        if (local_68[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_68[0];
        }
        if (puVar2 + lVar4 <= *(undefined4 **)(lVar5 + 0x20)) {
          if (plVar6 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar6;
          }
          if (*(undefined4 **)(lVar5 + 0x18) <= puVar2 + lVar4) goto LAB_140582eb0;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_140582eb0:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

