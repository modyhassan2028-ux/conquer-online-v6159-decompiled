// ==== CTeamDice::helper_14025acd0  @14025acd0  [medium:callgraph-r1]  (orig: FUN_14025acd0)
void FUN_14025acd0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_14025acd0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CTeamDice::helper_14025bc00  @14025bc00  [medium:callgraph-r0]  (orig: FUN_14025bc00)
void FUN_14025bc00(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x21);
  while (cVar1 == '\0') {
    FUN_14025acd0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CTeamDice::helper_14047e0c0  @14047e0c0  [medium:callgraph-r0]  (orig: FUN_14047e0c0)
void FUN_14047e0c0(void *param_1)

{
  if ((DAT_1409764b8 & 1) == 0) {
    DAT_1409764b8 = DAT_1409764b8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764b0,"CTeamDice");
    atexit((_func_5014 *)&LAB_1406d6ec0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014047e115. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409764b0,param_1);
  return;
}

// ==== CTeamDice::ctor_or_dtor  @14047f560  [high:vtable-assign]  (orig: FUN_14047f560)
void FUN_14047f560(undefined8 *param_1)

{
  *param_1 = CTeamDice::vftable;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  param_1 = param_1 + 5;
  FUN_14025bc00(param_1);
  FUN_14025d200(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CTeamDice::ctor_or_dtor  @1404800b0  [high:vtable-assign]  (orig: FUN_1404800b0)
undefined8 * FUN_1404800b0(undefined8 *param_1)

{
  *param_1 = CTeamDice::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  FUN_14025ea30(param_1 + 5);
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  return param_1;
}

// ==== CTeamDice::ctor_or_dtor  @140480110  [high:vtable-assign]  (orig: FUN_140480110)
undefined8 * FUN_140480110(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CTeamDice::vftable;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  puVar1 = param_1 + 5;
  FUN_14025bc00(puVar1);
  FUN_14025d200(puVar1);
  operator_delete((void *)*puVar1);
  if ((param_2 & 1) != 0) {
    FUN_14047e0c0(param_1);
  }
  return param_1;
}

