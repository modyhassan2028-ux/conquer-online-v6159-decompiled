// ==== CMsgJiangHuOpt::helper_1401d8980  @1401d8980  [medium:callgraph-r1]  (orig: FUN_1401d8980)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1401d8980(undefined8 param_1,longlong *param_2,uint param_3)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  int iVar8;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                      );
    return 0;
  }
  uVar3 = FUN_140371860(param_2 + 0x1cf);
  if (uVar3 + *(int *)((longlong)param_2 + 0xfa4) < param_3) {
    pIVar5 = theInstance();
    lVar1 = param_2[2];
    uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_TRAINING_GONGFU_EMONEY_NOT_ENOUGH");
    (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar6);
LAB_1401d8a24:
    uVar6 = 0;
  }
  else {
    if (param_3 < uVar3) {
      iVar8 = 0;
      uVar3 = param_3;
    }
    else {
      iVar8 = param_3 - uVar3;
    }
    if (0 < (int)uVar3) {
      cVar2 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x2d,(longlong)(int)-uVar3,1);
      if (cVar2 == '\0') goto LAB_1401d8a24;
    }
    if (0 < iVar8) {
      cVar2 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,(longlong)-iVar8,1);
      if (cVar2 == '\0') goto LAB_1401d8a24;
    }
    if (0 < (int)uVar3) {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      FUN_140174470(param_2,0x3b,uVar4);
      uVar6 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4227\t%d\t%d\t1\t",uVar7 & 0xffffffff,uVar6
                   );
    }
    if (0 < iVar8) {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401742b0(param_2,0x3b,uVar4);
      uVar6 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4228\t%d\t%d\t1\t",uVar7 & 0xffffffff,uVar6
                   );
    }
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgJiangHuOpt::helper_1401db390  @1401db390  [medium:callgraph-r1]  (orig: FUN_1401db390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401db390(longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  byte bVar1;
  char cVar2;
  ulong uVar3;
  int iVar4;
  IStringManager *pIVar5;
  char *_Format;
  longlong *plVar6;
  undefined1 auStack_a58 [32];
  undefined8 local_a38;
  undefined4 local_a30;
  undefined2 local_a28;
  undefined2 local_a20;
  undefined4 local_a18;
  undefined4 local_a10;
  undefined1 local_a08;
  longlong local_9f8;
  undefined8 local_9f0;
  undefined1 local_9e8 [1104];
  undefined1 local_598 [1104];
  char local_148;
  undefined1 local_147 [254];
  undefined1 local_49;
  ulonglong local_48;
  
  if (param_2 != 0) {
    local_9f0 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_a58;
    if (((param_3 != 0) && (param_4 != 0)) &&
       (local_9f8 = param_2, bVar1 = FUN_1403fd740(param_3,4), bVar1 < 9)) {
      uVar3 = tq::TimeGet(0);
      iVar4 = rand();
      srand(iVar4 + uVar3);
      iVar4 = tq::RandGet(10000);
      if (iVar4 == 0) {
        bVar1 = bVar1 + 1;
        cVar2 = FUN_140400400(param_4,bVar1);
        if (cVar2 == '\0') {
          log_InlineLogERROR("PowerLevel:%u, CreatePlayerPowerLevelData error,at %s, %d");
        }
        FUN_1403fd7d0(param_3,4,bVar1,1);
        FUN_140400920(local_9e8);
        cVar2 = FUN_140400a20(local_9e8);
        if (cVar2 != '\0') {
          (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))();
        }
        local_148 = '\0';
        memset(local_147,0,0xff);
        pIVar5 = theInstance();
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))();
        _Format = (char *)(*(code *)**(undefined8 **)pIVar5)
                                    (pIVar5,"STR_TRAINING_GONGFU_RAND_OPEN_NEXT_POWER_LEVEL");
        local_a38 = CONCAT44(local_a38._4_4_,(uint)bVar1);
        _snprintf(&local_148,0x100,_Format);
        local_49 = 0;
        FUN_14015b240();
        local_a08 = 1;
        local_a10 = 0;
        local_a18 = 0;
        local_a20 = 0;
        local_a28 = 0x7ea;
        local_a30 = 0xffff00;
        local_a38 = 0;
        iVar4 = FUN_14015b300(local_598,"SYSTEM","ALLUSERS",&local_148);
        if (iVar4 != 0) {
          plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
          (**(code **)(*plVar6 + 0x68))(plVar6,local_598,0xffffffff);
        }
        FUN_14015b2c0(local_598);
        FUN_1404009a0(local_9e8);
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401de330  @1401de330  [medium:callgraph-r3]  (orig: FUN_1401de330)
void FUN_1401de330(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_1401dd390(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMsgJiangHuOpt::helper_1401e1fe0  @1401e1fe0  [medium:callgraph-r3]  (orig: FUN_1401e1fe0)
longlong * FUN_1401e1fe0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1401de330(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x25) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x25);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x25);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x25);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x25);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1401df670(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMsgJiangHuOpt::helper_1401e3db0  @1401e3db0  [medium:callgraph-r3]  (orig: FUN_1401e3db0)
longlong * FUN_1401e3db0(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(byte *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgJiangHuOpt::helper_1401e3f50  @1401e3f50  [medium:callgraph-r3]  (orig: FUN_1401e3f50)
longlong * FUN_1401e3f50(longlong *param_1,longlong *param_2,byte *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x25) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(byte *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x25) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1401e40ad:
    local_30 = puVar4;
    if (*param_3 <= *(byte *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1401e40dd;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x25) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x25) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x25);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x25);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x25);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x25) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1401e40ad;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1401e18f0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1401e40dd:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgJiangHuOpt::helper_1401e69c0  @1401e69c0  [medium:callgraph-r0]  (orig: FUN_1401e69c0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401e69c0(longlong param_1,longlong *param_2,byte param_3,char param_4)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  ulonglong uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  byte local_res18 [8];
  longlong *local_48;
  longlong local_40;
  
  if (((param_2 != (longlong *)0x0) && ((byte)(param_3 - 1) < 9)) && ((byte)(param_4 - 1U) < 9)) {
    local_res18[0] = param_3;
    local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401e3b30(param_1 + 0x150,&local_48,local_res10);
    plVar5 = local_48;
    lVar6 = *(longlong *)(param_1 + 0x180);
    if ((local_48 == (longlong *)0x0) || (local_48 != *(longlong **)(param_1 + 0x150))) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_40;
    if (local_40 != lVar6) {
      lVar6 = 0;
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar6;
      }
      else {
        lVar7 = *plVar5;
      }
      if (lVar1 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar1 = *(longlong *)(lVar1 + 0x20);
      if ((lVar1 != 0) && (cVar2 = FUN_1403fee20(lVar1,param_3,param_4), cVar2 != '\0')) {
        FUN_140156ce0((undefined8 *)(param_1 + 0x110),&local_48,local_res18);
        lVar7 = *(longlong *)(param_1 + 0x140);
        if ((local_48 == (longlong *)0x0) || (local_48 != *(longlong **)(param_1 + 0x110))) {
          _invalid_parameter_noinfo();
        }
        if (local_40 == lVar7) {
          uVar4 = (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogDBERROR
                    ("table:cq_jianghu_caltivate_condition, user(%u), PowerLevel(%u), Can Not Find Cultivate Condition Data, at %s, %d"
                     ,uVar4 & 0xffffffff,(ulonglong)param_3,
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                    );
        }
        else {
          if (local_48 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar6 = *local_48;
          }
          if (local_40 == *(longlong *)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar5 = *(longlong **)(local_40 + 0x20);
          if (plVar5 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pConditionRecord",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                              );
          }
          else {
            plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,6);
            iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
            if ((iVar3 < 1) || (cVar2 = FUN_1401d8980(param_1,param_2,iVar3), cVar2 != '\0')) {
              FUN_1404005b0(lVar1,param_3,param_4);
              lVar6 = param_2[0x1e2];
              uVar4 = (**(code **)(*param_2 + 8))(param_2);
              tq::MyLogSave("gmlog/TrainingKungFu",
                            "Use EMoney Keep, user(id:%u, account:%u) Keep Power(Level:%u, Order:%u) Cost(%d)."
                            ,uVar4 & 0xffffffff,(int)lVar6);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401e6c20  @1401e6c20  [medium:callgraph-r0]  (orig: FUN_1401e6c20)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401e6c20(longlong param_1,longlong *param_2,undefined4 param_3,char param_4,char param_5)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined4 local_res10 [2];
  longlong *local_38;
  longlong local_30;
  
  if ((((param_2 != (longlong *)0x0) && ((byte)(param_4 - 1U) < 9)) && ((byte)(param_5 - 1U) < 9))
     && (cVar1 = FUN_140332fe0(param_2,param_3), cVar1 != '\0')) {
    plVar3 = (longlong *)FUN_140087d40();
    lVar4 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
    if ((lVar4 != 0) &&
       ((iVar2 = FUN_1400fda10(lVar4,1,1), iVar2 == 0x2dcead || (iVar2 == 0x2dceae)))) {
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401e3b30(param_1 + 0x150,&local_38,local_res10);
      lVar4 = *(longlong *)(param_1 + 0x180);
      if ((local_38 == (longlong *)0x0) || (local_38 != *(longlong **)(param_1 + 0x150))) {
        _invalid_parameter_noinfo();
      }
      if (local_30 != lVar4) {
        if (local_38 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar4 = 0;
        }
        else {
          lVar4 = *local_38;
        }
        if (local_30 == *(longlong *)(lVar4 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar4 = *(longlong *)(local_30 + 0x20);
        if (((lVar4 != 0) && (cVar1 = FUN_1403fee20(lVar4,param_4,param_5), cVar1 != '\0')) &&
           (cVar1 = FUN_140340190(param_2,param_3,1,1), cVar1 != '\0')) {
          FUN_1404005b0(lVar4,param_4,param_5);
          lVar4 = param_2[0x1e2];
          uVar5 = (**(code **)(*param_2 + 8))(param_2);
          tq::MyLogSave("gmlog/TrainingKungFu",
                        "Use Item Keep, user(id:%u, account:%u) Keep Power(Level:%u, Order:%u) Use Item Type(%u)."
                        ,uVar5 & 0xffffffff,(int)lVar4);
        }
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401e7c80  @1401e7c80  [medium:callgraph-r0]  (orig: FUN_1401e7c80)
void FUN_1401e7c80(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0xc0);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar7 + 3) < uVar5) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar3 = puVar7;
      puVar7 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x29);
    }
    puVar7 = *(undefined8 **)(param_1 + 0xc0);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 0x90);
    if (*(longlong *)(param_1 + 0x90) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar7) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar6 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0xc0);
      local_28 = *(longlong *)(param_1 + 0x90);
    }
    else {
      plVar6 = &local_38;
    }
    plVar2 = (longlong *)*plVar6;
    lVar9 = *(longlong *)(param_1 + 0xc0);
    local_18 = plVar2;
    local_10 = plVar6[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x90))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 != 0) {
        FUN_1403fdaa0(lVar9,param_2);
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401e7dc0  @1401e7dc0  [medium:callgraph-r0]  (orig: FUN_1401e7dc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401e7dc0(longlong param_1,longlong *param_2)

{
  byte bVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 unaff_RBP;
  undefined1 auStack_8f8 [32];
  undefined8 local_8d8;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_8d8 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8f8;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    lVar5 = FUN_1401e6030(param_1,uVar4);
    if (lVar5 != 0) {
      bVar1 = FUN_1403fd740(lVar5,5);
      if ((bVar1 < 5) &&
         (cVar2 = FUN_1401d8980(param_1,param_2,*(undefined4 *)(param_1 + 0x44)), cVar2 != '\0')) {
        FUN_140400920(local_478);
        cVar2 = FUN_140400a20(local_478,0x11);
        if (cVar2 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
        }
        FUN_1403fd7d0(lVar5,5,(int)CONCAT71((int7)((ulonglong)unaff_RBP >> 8),bVar1) + 1,1);
        FUN_140400920(local_8c8);
        uVar3 = FUN_1403fd740(lVar5,5);
        uVar4 = (**(code **)(*param_2 + 8))(param_2);
        cVar2 = FUN_140400ce0(local_8c8,5,uVar4,uVar3);
        if (cVar2 != '\0') {
          (**(code **)(param_2[2] + 0x348))(param_2 + 2,local_8c8,1);
        }
        FUN_1404009a0(local_8c8);
        FUN_1404009a0(local_478);
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401e8950  @1401e8950  [medium:callgraph-r0]  (orig: FUN_1401e8950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1401e8950(longlong param_1,longlong *param_2,char *param_3)

{
  int iVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  undefined1 auStack_958 [32];
  undefined8 local_938;
  int local_930;
  int local_928;
  undefined4 local_918 [2];
  longlong *local_910;
  longlong local_908;
  longlong *local_900;
  undefined8 local_8f0;
  undefined1 local_8e8 [1104];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_8f0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  if (((param_2 != (longlong *)0x0) && (param_3 != (char *)0x0)) &&
     (*(char *)((longlong)param_2 + 0x51c) != '\0')) {
    local_918[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401e2eb0(param_1 + 0x90,&local_910,local_918);
    lVar7 = *(longlong *)(param_1 + 0xc0);
    local_900 = *(longlong **)(param_1 + 0x90);
    if ((local_910 == (longlong *)0x0) || (local_910 != local_900)) {
      _invalid_parameter_noinfo();
    }
    if (local_908 != lVar7) {
      if (local_910 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *local_910;
      }
      if (local_908 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = *(longlong *)(local_908 + 0x20);
      if (lVar7 == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR("ProcessRenameGongFu::user(%u), pJiangHuPlayer == NULL, at %s, %d");
      }
      else {
        iVar1 = *(int *)(param_1 + 0x4c);
        if (iVar1 <= *(int *)((longlong)param_2 + 0xfa4)) {
          iVar4 = tq::NameStrCheck(param_3,false);
          if (iVar4 != 0) {
            uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            cVar3 = FUN_14008a1d0(uVar6,param_3,0);
            if (cVar3 == '\0') {
              local_938 = 0;
              cVar3 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,(longlong)-iVar1,1);
              if (cVar3 != '\0') {
                uVar5 = (**(code **)(*param_2 + 8))(param_2);
                local_938._0_4_ = iVar1;
                FUN_1401742b0(param_2,0x3e,uVar5);
                lVar2 = param_2[0x1e2];
                (**(code **)(param_2[2] + 0x18))(param_2 + 2);
                (**(code **)(*param_2 + 8))(param_2);
                local_938 = CONCAT44(local_938._4_4_,(int)lVar2);
                local_930 = iVar1;
                local_928 = iVar1;
                tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4281\t%d\t%d\t1\t");
                FUN_1403fd910(lVar7,3,param_3);
                FUN_140400920(local_8e8);
                cVar3 = FUN_140400b40(local_8e8,0x12,param_3);
                if (cVar3 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8e8);
                }
                FUN_1404009a0(local_8e8);
                return 1;
              }
              return 0;
            }
          }
          FUN_140400920(local_498);
          cVar3 = FUN_140400a80(local_498,0x13,0);
          if (cVar3 != '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_498);
          }
          FUN_1404009a0(local_498);
        }
      }
    }
  }
  return 0;
}

// ==== CMsgJiangHuOpt::helper_1401e93b0  @1401e93b0  [medium:callgraph-r0]  (orig: FUN_1401e93b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401e93b0(longlong param_1,longlong *param_2,char *param_3)

{
  char cVar1;
  undefined1 uVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  IStringManager *pIVar10;
  char *_Format;
  longlong lVar11;
  undefined1 auStack_ee8 [32];
  char *local_ec8;
  undefined8 local_ec0;
  undefined2 local_eb8;
  undefined2 local_eb0;
  undefined4 local_ea8;
  undefined4 local_ea0;
  undefined1 local_e98;
  undefined4 local_e88 [2];
  undefined4 local_e80;
  undefined4 uStack_e7c;
  longlong local_e78;
  longlong *local_e70;
  longlong local_e68;
  longlong local_e60 [3];
  undefined8 local_e48;
  undefined1 local_e38 [1104];
  undefined1 local_9e8 [1104];
  undefined1 local_598 [1104];
  char local_148;
  undefined1 local_147 [254];
  undefined1 local_49;
  ulonglong local_48;
  
  local_e48 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_ee8;
  if ((param_2 != (longlong *)0x0) && (param_3 != (char *)0x0)) {
    local_e70 = param_2;
    local_e88[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401e2eb0(param_1 + 0x90,&local_e80,local_e88);
    lVar9 = *(longlong *)(param_1 + 0xc0);
    local_e60[0] = *(longlong *)(param_1 + 0x90);
    if ((CONCAT44(uStack_e7c,local_e80) == 0) || (CONCAT44(uStack_e7c,local_e80) != local_e60[0])) {
      _invalid_parameter_noinfo();
    }
    if (local_e78 == lVar9) {
      uVar3 = (**(code **)(*param_2 + 0x108))(param_2);
      if (uVar3 < 2) {
        FUN_140400920(local_e38);
        cVar1 = FUN_140400a80(local_e38,8,1);
        if (cVar1 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_e38);
        }
        FUN_1404009a0(local_e38);
      }
      else {
        iVar4 = (**(code **)(*param_2 + 0x108))(param_2);
        if ((iVar4 == 2) && (uVar3 = (**(code **)(param_2[2] + 0x70))(param_2 + 2), uVar3 < 0x1e)) {
          FUN_140400920(local_e38);
          cVar1 = FUN_140400a80(local_e38,8,1);
          if (cVar1 != '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_e38);
          }
          FUN_1404009a0(local_e38);
          return 0;
        }
        iVar4 = tq::NameStrCheck(param_3,false);
        if (iVar4 != 0) {
          uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          cVar1 = FUN_14008a1d0(uVar6,param_3,0);
          if (cVar1 == '\0') {
            plVar7 = (longlong *)InstanceGet();
            plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,"cq_jianghu_player");
            if (plVar7 == (longlong *)0x0) {
              return 0;
            }
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,1);
            lVar9 = *plVar8;
            uVar5 = (**(code **)(*param_2 + 8))(param_2);
            (**(code **)(lVar9 + 0xb8))(plVar8,uVar5);
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
            (**(code **)(*plVar8 + 0xb0))(plVar8,1);
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
            (**(code **)(*plVar8 + 0x80))(plVar8,param_3);
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
            (**(code **)(*plVar8 + 0xb0))(plVar8,1);
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,5);
            (**(code **)(*plVar8 + 0xb0))(plVar8,1);
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,6);
            (**(code **)(*plVar8 + 0xb0))(plVar8,0);
            cVar1 = (**(code **)(*plVar7 + 0x50))(plVar7,1);
            if (cVar1 == '\0') {
              local_ec8._0_4_ = 0x34d;
              log_InlineLogERROR(&DAT_1406d9c10);
              (**(code **)(*param_2 + 8))(param_2);
              local_ec8 = (char *)CONCAT44(local_ec8._4_4_,0x34f);
              log_InlineLogERROR(
                                "CJiangHuMgr::ProcessCreateGongfu Error, user:%u, gong fu name:%s ,at %s, %d"
                                );
              (**(code **)*plVar7)(plVar7,1);
              return 0;
            }
            uVar5 = (**(code **)(*param_2 + 8))(param_2);
            lVar9 = FUN_1403fdd90(*(undefined4 *)(param_1 + 8),uVar5,plVar7,0);
            if (lVar9 == 0) {
              local_ec8 = (char *)CONCAT44(local_ec8._4_4_,0x354);
              log_InlineLogERROR(&DAT_1406d9c10);
              (**(code **)*plVar7)(plVar7,1);
              return 0;
            }
            cVar1 = FUN_1403fe5c0(lVar9,0);
            if (cVar1 != '\0') {
              local_e80 = (**(code **)(*param_2 + 8))(param_2);
              local_e78 = lVar9;
              FUN_1401e2940(param_1 + 0x90,local_e60,&local_e80);
              FUN_140400920(local_598);
              uVar2 = FUN_1403fd740(lVar9,5);
              uVar5 = (**(code **)(*param_2 + 8))(param_2);
              local_ec8 = (char *)CONCAT71(local_ec8._1_7_,1);
              cVar1 = FUN_140400df0(local_598,0xe,uVar5,uVar2);
              if (cVar1 != '\0') {
                (**(code **)(param_2[2] + 0x348))(param_2 + 2,local_598,1);
              }
              pIVar10 = theInstance();
              lVar11 = param_2[2];
              (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_JIANG_HU_CREATE_GONGFU1");
              (**(code **)(lVar11 + 0x358))(param_2 + 2);
              local_148 = '\0';
              memset(local_147,0,0xff);
              pIVar10 = theInstance();
              (**(code **)(param_2[2] + 0x18))(param_2 + 2);
              _Format = (char *)(*(code *)**(undefined8 **)pIVar10)
                                          (pIVar10,"STR_JIANG_HU_CREATE_GONGFU2");
              local_ec8 = param_3;
              _snprintf(&local_148,0x100,_Format);
              local_49 = 0;
              FUN_14015b240(local_9e8);
              local_e98 = 1;
              local_ea0 = 0;
              local_ea8 = 0;
              local_eb0 = 0;
              local_eb8 = 0x7ea;
              local_ec0 = CONCAT44(local_ec0._4_4_,0xffff00);
              local_ec8 = (char *)0x0;
              iVar4 = FUN_14015b300(local_9e8,"SYSTEM","ALLUSERS",&local_148);
              if (iVar4 != 0) {
                plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
                (**(code **)(*plVar7 + 0x68))(plVar7,local_9e8,0xffffffff);
              }
              uVar5 = (**(code **)(*param_2 + 8))(param_2);
              lVar11 = FUN_140400820(*(undefined4 *)(param_1 + 8),uVar5,0);
              if (lVar11 != 0) {
                cVar1 = FUN_140400400(lVar11,1);
                if (cVar1 != '\0') {
                  local_ec8 = (char *)((ulonglong)local_ec8 & 0xffffffffffffff00);
                  FUN_1401e6e00(param_1,param_2,lVar9,lVar11);
                  uVar5 = (**(code **)(*param_2 + 8))(param_2);
                  local_e70 = (longlong *)CONCAT44(local_e70._4_4_,uVar5);
                  local_e68 = lVar11;
                  FUN_1401e35c0(param_1 + 0x150,local_e60,&local_e70);
                  FUN_1401e7880(param_1,param_2,param_2);
                  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
                  uVar6 = FUN_140087730(uVar6);
                  local_ec0 = 0;
                  local_ec8 = (char *)((ulonglong)local_ec8 & 0xffffffff00000000);
                  FUN_140145f60(uVar6,0x55f1838,param_2,0);
                  FUN_14015b2c0(local_9e8);
                  FUN_1404009a0(local_598);
                  return 1;
                }
                FUN_1403ff130(lVar11);
                (**(code **)(*param_2 + 8))(param_2);
                log_InlineLogERROR("user(%u), CreatePlayerPowerLevelData error at %s, %d");
                FUN_14015b2c0(local_9e8);
                FUN_1404009a0(local_598);
                return 0;
              }
              local_ec8 = (char *)CONCAT44(local_ec8._4_4_,0x377);
              log_InlineLogERROR(&DAT_1406d9c10);
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR("user(%u), NULL == pJiangHuPlayerPower. at %s, %d");
              FUN_14015b2c0(local_9e8);
              FUN_1404009a0(local_598);
              return 0;
            }
            FUN_1403fdeb0(lVar9);
            return 0;
          }
        }
        FUN_140400920(local_e38);
        cVar1 = FUN_140400a80(local_e38,8,2);
        if (cVar1 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_e38);
        }
        FUN_1404009a0(local_e38);
      }
    }
    else {
      FUN_140400920(local_e38);
      cVar1 = FUN_140400a80(local_e38,8,0);
      if (cVar1 != '\0') {
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_e38);
      }
      FUN_1404009a0(local_e38);
    }
  }
  return 0;
}

// ==== CMsgJiangHuOpt::helper_1401eb6d0  @1401eb6d0  [medium:callgraph-r0]  (orig: FUN_1401eb6d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401eb6d0(longlong param_1,longlong param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_2 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_498 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                      (*(longlong **)(lVar2 + 0x90),param_3);
    if ((lVar2 != 0) && (cVar1 = FUN_1401e7880(param_1,param_2,lVar2), cVar1 == '\0')) {
      FUN_140400920(local_478);
      cVar1 = FUN_140400a80(local_478,8,3);
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478)
        ;
      }
      FUN_1404009a0(local_478);
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1401eba30  @1401eba30  [medium:callgraph-r3]  (orig: FUN_1401eba30)
undefined8 * FUN_1401eba30(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1401ddd00(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMsgJiangHuOpt::helper_1401ec8b0  @1401ec8b0  [medium:callgraph-r2]  (orig: FUN_1401ec8b0)
int FUN_1401ec8b0(longlong param_1,longlong *param_2,longlong param_3,char param_4)

{
  char cVar1;
  longlong lVar2;
  ulonglong *puVar3;
  undefined8 uVar4;
  int iVar5;
  byte bVar6;
  ulonglong *puVar7;
  longlong *plVar8;
  ulonglong *puVar9;
  int iVar10;
  ulonglong **ppuVar11;
  ulonglong *puVar12;
  uint uVar13;
  int iVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  byte local_res20 [8];
  int local_158;
  ulonglong *local_150;
  ulonglong *local_148;
  ulonglong *local_138;
  ulonglong *puStack_130;
  ulonglong *local_128 [6];
  ulonglong *local_f8;
  undefined8 local_f0;
  undefined8 local_e8;
  ulonglong *local_e0;
  ulonglong *local_d8;
  ulonglong *local_d0;
  undefined8 local_c8;
  undefined4 local_c0;
  undefined4 uStack_bc;
  ulonglong *local_b8;
  ulonglong *puStack_b0;
  uint local_98 [10];
  ulonglong *local_70;
  ulonglong *local_68;
  ulonglong *local_60;
  ulonglong *local_58;
  ulonglong *local_50;
  ulonglong *local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  if ((byte)(param_4 - 1U) < 9) {
    if ((param_2 == (longlong *)0x0) || (param_3 == 0)) {
      local_158 = 0;
    }
    else {
      puVar7 = (ulonglong *)FUN_140400600(param_3,param_4);
      local_158 = 0;
      if (puVar7 != (ulonglong *)0x0) {
        local_158 = 0;
        local_150 = puVar7;
        FUN_1401eba30(local_128);
        FUN_1401de330(local_128);
        uVar13 = 1;
        do {
          plVar8 = (longlong *)(**(code **)(*puVar7 + 0x10))(puVar7,uVar13 * 2 + 1);
          bVar6 = (**(code **)(*plVar8 + 0x20))(plVar8);
          plVar8 = (longlong *)(**(code **)(*puVar7 + 0x10))(puVar7,uVar13 * 2 + 2);
          local_res20[0] = (**(code **)(*plVar8 + 0x20))(plVar8);
          if ((bVar6 != 0) && (local_res20[0] != 0)) {
            if (bVar6 < 0x10) {
              if (local_res20[0] < 7) {
                FUN_1401e3db0((longlong *)(param_1 + 0x1d0),&local_d8,local_res20);
                puVar7 = local_d8;
                lVar2 = *(longlong *)(param_1 + 0x200);
                if ((local_d8 == (ulonglong *)0x0) || (local_d8 != *(ulonglong **)(param_1 + 0x1d0))
                   ) {
                  _invalid_parameter_noinfo();
                }
                puVar9 = local_d0;
                if (local_d0 == (ulonglong *)lVar2) {
                  (**(code **)(*param_2 + 8))(param_2);
                  log_InlineLogERROR(
                                    "User(%u), PowerQuality(%u), can not find power value,at %s, %d"
                                    );
                  puVar7 = local_150;
                }
                else {
                  if (puVar7 == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar16 = 0;
                  }
                  else {
                    uVar16 = *puVar7;
                  }
                  if (puVar9 == (ulonglong *)*(longlong *)(uVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  local_c0 = *(undefined4 *)((longlong)puVar9 + 0x1c);
                  local_c8._4_4_ = (uint)CONCAT11((char)((ulonglong)local_e8 >> 8),bVar6);
                  local_e8 = (ulonglong *)CONCAT44(local_c0,local_c8._4_4_);
                  local_c8._0_4_ = CONCAT31(local_c8._1_3_,(char)uVar13);
                  FUN_1401e3f50(local_128,&local_b8,&local_c8);
                  puVar7 = local_150;
                }
              }
              else {
                (**(code **)(*param_2 + 8))(param_2);
                log_InlineLogERROR("User(%u), PowerLevel(%u), PowerQuality(%u) error,at %s, %d");
                puVar7 = local_150;
              }
            }
            else {
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR("User(%u), PowerLevel(%u), PowerAttribType(%u) error,at %s, %d");
              puVar7 = local_150;
            }
          }
          bVar6 = (char)uVar13 + 1;
          uVar13 = (uint)bVar6;
        } while (bVar6 < 10);
        iVar14 = 1;
        puVar7 = local_f8;
        do {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
          puVar9 = (ulonglong *)puVar7[1];
          puVar3 = puVar7;
          while (puVar12 = puVar9, cVar1 == '\0') {
            if ((byte)puVar12[3] < (byte)iVar14) {
              puVar9 = (ulonglong *)puVar12[2];
              puVar12 = puVar3;
            }
            else {
              puVar9 = (ulonglong *)*puVar12;
            }
            cVar1 = *(char *)((longlong)puVar9 + 0x25);
            puVar3 = puVar12;
          }
          local_d0 = puVar3;
          local_d8 = local_128[0];
          puVar9 = puVar7;
          if (local_128[0] == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            puVar9 = local_f8;
          }
          if ((puVar3 == puVar7) || ((byte)iVar14 < (byte)puVar3[3])) {
            local_c0 = SUB84(puVar9,0);
            uStack_bc = (undefined4)((ulonglong)puVar9 >> 0x20);
            local_c8._0_4_ = SUB84(local_128[0],0);
            local_c8._4_4_ = (uint)((ulonglong)local_128[0] >> 0x20);
            ppuVar11 = (ulonglong **)&local_c8;
          }
          else {
            ppuVar11 = &local_d8;
          }
          puVar3 = *ppuVar11;
          local_e8 = puVar3;
          local_e0 = ppuVar11[1];
          if ((puVar3 == (ulonglong *)0x0) || (puVar7 = puVar9, puVar3 != local_128[0])) {
            _invalid_parameter_noinfo();
            puVar7 = local_f8;
          }
          puVar12 = local_e0;
          if (local_e0 != puVar9) {
            if (puVar3 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar16 = 0;
              puVar7 = local_f8;
            }
            else {
              uVar16 = *puVar3;
            }
            uVar17 = 0;
            if (puVar12 == *(ulonglong **)(uVar16 + 0x30)) {
              _invalid_parameter_noinfo();
              puVar7 = local_f8;
            }
            uVar4 = *(undefined8 *)((longlong)puVar12 + 0x1c);
            uVar16 = uVar17;
            iVar5 = iVar14;
            while (iVar5 = iVar5 + 1, iVar5 < 10) {
              cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
              puVar9 = (ulonglong *)puVar7[1];
              puVar3 = puVar7;
              while (puVar12 = puVar9, cVar1 == '\0') {
                if ((byte)puVar12[3] < (byte)iVar5) {
                  puVar9 = (ulonglong *)puVar12[2];
                  puVar12 = puVar3;
                }
                else {
                  puVar9 = (ulonglong *)*puVar12;
                }
                cVar1 = *(char *)((longlong)puVar9 + 0x25);
                puVar3 = puVar12;
              }
              local_148 = puVar3;
              local_150 = local_128[0];
              puVar9 = puVar7;
              if (local_128[0] == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                puVar9 = local_f8;
              }
              if ((puVar3 == puVar7) || ((byte)iVar5 < (byte)puVar3[3])) {
                local_58 = puVar9;
                local_60 = local_128[0];
                ppuVar11 = &local_60;
              }
              else {
                ppuVar11 = &local_150;
              }
              puVar3 = *ppuVar11;
              local_50 = puVar3;
              local_48 = ppuVar11[1];
              if ((puVar3 == (ulonglong *)0x0) || (puVar7 = puVar9, puVar3 != local_128[0])) {
                _invalid_parameter_noinfo();
                puVar7 = local_f8;
              }
              puVar12 = local_48;
              if (local_48 == puVar9) break;
              if (puVar3 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                puVar7 = local_f8;
                uVar15 = uVar17;
              }
              else {
                uVar15 = *puVar3;
              }
              if (puVar12 == *(ulonglong **)(uVar15 + 0x30)) {
                _invalid_parameter_noinfo();
                puVar7 = local_f8;
              }
              if ((char)uVar4 != *(char *)((longlong)puVar12 + 0x1c)) break;
              uVar16 = uVar16 + 1;
            }
            if ((longlong)uVar16 < 9) {
              local_98[0] = 0;
              local_98[1] = 10;
              local_98[2] = 0x14;
              local_98[3] = 0x1e;
              local_98[4] = 0x28;
              local_98[5] = 0x32;
              local_98[6] = 0x3c;
              local_98[7] = 0x50;
              local_98[8] = 100;
              uVar17 = (ulonglong)local_98[uVar16];
            }
            iVar10 = 0;
            uVar16 = 0;
            for (; iVar14 < iVar5; iVar14 = iVar14 + 1) {
              cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
              puVar9 = (ulonglong *)puVar7[1];
              puVar3 = puVar7;
              while (puVar12 = puVar9, cVar1 == '\0') {
                if ((byte)puVar12[3] < (byte)iVar14) {
                  puVar9 = (ulonglong *)puVar12[2];
                  puVar12 = puVar3;
                }
                else {
                  puVar9 = (ulonglong *)*puVar12;
                }
                cVar1 = *(char *)((longlong)puVar9 + 0x25);
                puVar3 = puVar12;
              }
              local_68 = puVar3;
              local_70 = local_128[0];
              puVar9 = puVar7;
              if (local_128[0] == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                puVar9 = local_f8;
              }
              if ((puVar3 == puVar7) || ((byte)iVar14 < (byte)puVar3[3])) {
                puStack_130 = puVar9;
                local_138 = local_128[0];
                ppuVar11 = &local_138;
              }
              else {
                ppuVar11 = &local_70;
              }
              puVar3 = *ppuVar11;
              local_b8 = puVar3;
              puStack_b0 = ppuVar11[1];
              if ((puVar3 == (ulonglong *)0x0) || (puVar7 = puVar9, puVar3 != local_128[0])) {
                _invalid_parameter_noinfo();
                puVar7 = local_f8;
              }
              puVar12 = puStack_b0;
              if (puStack_b0 != puVar9) {
                if (puVar3 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  puVar7 = local_f8;
                  uVar15 = 0;
                }
                else {
                  uVar15 = *puVar3;
                }
                if (puVar12 == *(ulonglong **)(uVar15 + 0x30)) {
                  _invalid_parameter_noinfo();
                  puVar7 = local_f8;
                }
                iVar10 = (int)((ulonglong)*(undefined8 *)((longlong)puVar12 + 0x1c) >> 0x20);
                uVar16 = (ulonglong)(uint)((int)uVar16 + iVar10 + (iVar10 * (int)uVar17) / 100);
              }
              iVar10 = (int)uVar16;
            }
            iVar14 = iVar14 + -1;
            local_158 = local_158 + iVar10;
          }
          iVar14 = iVar14 + 1;
        } while (iVar14 < 10);
        puStack_130 = (ulonglong *)*local_f8;
        FUN_1401e1fe0(local_128,&local_70,&local_138,&local_b8);
        operator_delete(local_f8);
        local_f8 = (ulonglong *)0x0;
        local_f0 = 0;
        operator_delete(local_128[0]);
      }
    }
  }
  else {
    local_158 = 0;
  }
  return local_158;
}

// ==== CMsgJiangHuOpt::helper_1401ed000  @1401ed000  [medium:callgraph-r1]  (orig: FUN_1401ed000)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1401ed000(longlong param_1,longlong param_2,longlong param_3,longlong param_4,byte param_5,
             char param_6)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  longlong lVar4;
  longlong *plVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  char cVar8;
  undefined1 auStack_4f8 [32];
  uint local_4d8;
  longlong local_4d0;
  longlong local_4c8;
  longlong *local_4c0;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (((param_2 == 0) || (param_3 == 0)) || (param_4 == 0)) {
    uVar7 = 0;
  }
  else {
    local_4c8 = param_2;
    bVar1 = FUN_1403fd740(param_3,4);
    if (bVar1 < 9) {
      if (param_5 == bVar1) {
        local_4d8 = FUN_1401ec8b0(param_1,param_2,param_4,param_5);
        FUN_140156ce0(param_1 + 0x110,&local_4c0,&param_5);
        local_4d0 = *(longlong *)(param_1 + 0x140);
        local_4a8 = *(longlong **)(param_1 + 0x110);
        if ((local_4c0 == (longlong *)0x0) || (local_4c0 != local_4a8)) {
          _invalid_parameter_noinfo();
        }
        if (local_4b8 == local_4d0) {
          log_InlineLogDBERROR
                    (
                    "table:cq_jianghu_caltivate_condition, PowerLevel(%u) can not find cultivate condition,at %s, %d"
                    );
          uVar7 = 0;
        }
        else {
          if (local_4c0 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar4 = 0;
          }
          else {
            lVar4 = *local_4c0;
          }
          if (local_4b8 == *(longlong *)(lVar4 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar5 = *(longlong **)(local_4b8 + 0x20);
          if (plVar5 == (longlong *)0x0) {
            log_InlineLogDBERROR
                      (
                      "table:cq_jianghu_caltivate_condition, PowerLevel(%u) can not find cultivate condition,at %s, %d"
                      );
            uVar7 = 0;
          }
          else {
            plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,2);
            uVar3 = (**(code **)(*plVar5 + 0x50))(plVar5);
            if (local_4d8 < uVar3) {
              uVar7 = 0;
            }
            else {
              cVar8 = bVar1 + 1;
              cVar2 = FUN_140400400(param_4,cVar8);
              if (cVar2 == '\0') {
                log_InlineLogERROR("PowerLevel:%u, CreatePlayerPowerLevelData error,at %s, %d");
                uVar7 = 0;
              }
              else {
                FUN_1403fd7d0(param_3,4,cVar8,1);
                if (param_6 == '\0') {
                  FUN_140400920(local_498);
                  cVar2 = FUN_140400a20(local_498,0xc);
                  if (cVar2 != '\0') {
                    (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                              ((longlong *)(param_2 + 0x10),local_498);
                  }
                  pIVar6 = theInstance();
                  lVar4 = *(longlong *)(param_2 + 0x10);
                  uVar7 = (*(code *)**(undefined8 **)pIVar6)
                                    (pIVar6,"STR_TRAINING_GONGFU_OPEN_NEXT_POWER_LEVEL");
                  (**(code **)(lVar4 + 0x358))(param_2 + 0x10,uVar7,cVar8);
                  FUN_1404009a0(local_498);
                }
                uVar7 = 1;
              }
            }
          }
        }
      }
      else {
        uVar7 = 0;
      }
    }
    else {
      uVar7 = 0;
    }
  }
  return uVar7;
}

// ==== CMsgJiangHuOpt::helper_1401f1230  @1401f1230  [medium:callgraph-r0]  (orig: FUN_1401f1230)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401f1230(longlong param_1,longlong *param_2,char param_3,char param_4)

{
  char cVar1;
  int iVar2;
  IStringManager *pIVar3;
  char *_Format;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  undefined1 auStack_628 [32];
  char *local_608;
  uint local_600;
  undefined2 local_5f8;
  undefined2 local_5f0;
  undefined4 local_5e8;
  undefined4 local_5e0;
  undefined1 local_5d8;
  char local_5c8;
  char local_5c7;
  char local_5c6;
  char local_5c5;
  undefined4 local_5c4;
  longlong *local_5c0;
  longlong local_5b8;
  undefined8 local_5b0;
  undefined1 local_5a8 [1104];
  char local_158;
  undefined1 local_157 [254];
  undefined1 local_59;
  ulonglong local_58;
  
  if (param_2 != (longlong *)0x0) {
    local_5b0 = 0xfffffffffffffffe;
    local_58 = DAT_1409707c0 ^ (ulonglong)auStack_628;
    if (((byte)(param_3 - 1U) < 9) && ((byte)(param_4 - 1U) < 9)) {
      local_5c4 = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401e2eb0(param_1 + 0x90,&local_5c0,&local_5c4);
      plVar4 = local_5c0;
      lVar5 = *(longlong *)(param_1 + 0xc0);
      if ((local_5c0 == (longlong *)0x0) || (local_5c0 != *(longlong **)(param_1 + 0x90))) {
        _invalid_parameter_noinfo();
      }
      lVar6 = local_5b8;
      if (local_5b8 != lVar5) {
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar4;
        }
        if (lVar6 == *(longlong *)(lVar5 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar5 = *(longlong *)(lVar6 + 0x20);
        if (lVar5 != 0) {
          local_5c4 = (**(code **)(*param_2 + 8))(param_2);
          FUN_1401e3b30(param_1 + 0x150,&local_5c0,&local_5c4);
          lVar6 = *(longlong *)(param_1 + 0x180);
          if ((local_5c0 == (longlong *)0x0) || (local_5c0 != *(longlong **)(param_1 + 0x150))) {
            _invalid_parameter_noinfo();
          }
          if (local_5b8 != lVar6) {
            if (local_5c0 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *local_5c0;
            }
            if (local_5b8 == *(longlong *)(lVar6 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar6 = *(longlong *)(local_5b8 + 0x20);
            if (lVar6 != 0) {
              local_5c5 = '\0';
              local_5c7 = '\0';
              local_608 = &local_5c7;
              cVar1 = FUN_1403fee70(lVar6,param_3,param_4,&local_5c5);
              if ((cVar1 != '\0') && (cVar1 = FUN_1403ff0b0(lVar6,param_3,param_4), cVar1 != '\0'))
              {
                local_5c6 = '\0';
                local_5c8 = '\0';
                local_608 = &local_5c8;
                FUN_140400270(lVar6,param_3,param_4,&local_5c6);
                local_600 = local_600 & 0xffffff00;
                local_608 = (char *)CONCAT71(local_608._1_7_,param_3);
                cVar1 = FUN_1401ed000(param_1,param_2,lVar5,lVar6);
                if (cVar1 == '\0') {
                  FUN_1401db390(param_1,param_2,lVar5,lVar6);
                }
                local_608 = (char *)((ulonglong)local_608 & 0xffffffffffffff00);
                FUN_1401e6e00(param_1,param_2,lVar5,lVar6);
                if ((local_5c7 != local_5c8) || (local_5c5 != local_5c6)) {
                  local_608 = (char *)((ulonglong)local_608 & 0xffffffffffffff00);
                  FUN_1401ef6d0(param_1,param_2,lVar5,lVar6);
                }
                if (local_5c8 == '\x06') {
                  local_158 = '\0';
                  memset(local_157,0,0xff);
                  pIVar3 = theInstance();
                  (**(code **)(param_2[2] + 0x18))();
                  _Format = (char *)(*(code *)**(undefined8 **)pIVar3)
                                              (pIVar3,"STR_TRAINING_GONGFU_POWER_QUALITY_EVIL");
                  _snprintf(&local_158,0x100,_Format);
                  local_59 = 0;
                  FUN_14015b240(local_5a8);
                  local_5d8 = 1;
                  local_5e0 = 0;
                  local_5e8 = 0;
                  local_5f0 = 0;
                  local_5f8 = 0x7ea;
                  local_600 = 0xffff00;
                  local_608 = (char *)0x0;
                  iVar2 = FUN_14015b300(local_5a8,"SYSTEM","ALLUSERS",&local_158);
                  if (iVar2 != 0) {
                    plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
                    (**(code **)(*plVar4 + 0x68))(plVar4,local_5a8,0xffffffff);
                  }
                  FUN_14015b2c0(local_5a8);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1403fd910  @1403fd910  [medium:callgraph-r1]  (orig: FUN_1403fd910)
void FUN_1403fd910(longlong param_1,int param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (7 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
  (**(code **)(*plVar1 + 0x80))(plVar1,param_3);
  if (*(char *)(param_1 + 0x30) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_1403fee20  @1403fee20  [medium:callgraph-r1]  (orig: FUN_1403fee20)
undefined1 FUN_1403fee20(longlong param_1,byte param_2,byte param_3)

{
  if ((((param_2 < 10) && (param_3 < 10)) && (*(byte *)(param_1 + 0x50) == param_2)) &&
     (*(byte *)(param_1 + 0x51) == param_3)) {
    return 1;
  }
  return 0;
}

// ==== CMsgJiangHuOpt::helper_1403fee70  @1403fee70  [medium:callgraph-r1]  (orig: FUN_1403fee70)
undefined8
FUN_1403fee70(longlong param_1,byte param_2,byte param_3,undefined1 *param_4,undefined1 *param_5)

{
  if ((((param_2 < 10) && (param_3 < 10)) && (*(byte *)(param_1 + 0x50) == param_2)) &&
     (*(byte *)(param_1 + 0x51) == param_3)) {
    *param_4 = *(undefined1 *)(param_1 + 0x52);
    *param_5 = *(undefined1 *)(param_1 + 0x53);
    return 1;
  }
  return 0;
}

// ==== CMsgJiangHuOpt::helper_1403ff0b0  @1403ff0b0  [medium:callgraph-r1]  (orig: FUN_1403ff0b0)
undefined1 FUN_1403ff0b0(longlong param_1,byte param_2,byte param_3)

{
  if ((((param_2 < 10) && (param_3 < 10)) && (*(byte *)(param_1 + 0x50) == param_2)) &&
     (*(byte *)(param_1 + 0x51) == param_3)) {
    *(undefined1 *)(param_1 + 0x50) = 0;
    *(undefined1 *)(param_1 + 0x51) = 0;
    *(undefined1 *)(param_1 + 0x52) = 0;
    *(undefined1 *)(param_1 + 0x53) = 0;
    return 1;
  }
  return 0;
}

// ==== CMsgJiangHuOpt::helper_140400120  @140400120  [medium:callgraph-r2]  (orig: FUN_140400120)
void FUN_140400120(longlong param_1,char param_2,byte param_3,undefined1 param_4,undefined1 param_5)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong lVar4;
  char local_res10 [8];
  longlong *local_28;
  longlong local_20;
  
  local_res10[0] = param_2;
  if (((byte)(param_2 - 1U) < 9) && ((byte)(param_3 - 1) < 9)) {
    FUN_140156ce0(param_1 + 0x10,&local_28,local_res10);
    lVar4 = *(longlong *)(param_1 + 0x40);
    if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0x10))) {
      _invalid_parameter_noinfo();
    }
    if (local_20 != lVar4) {
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *local_28;
      }
      if (local_20 == *(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar1 = *(longlong **)(local_20 + 0x20);
      if (plVar1 != (longlong *)0x0) {
        iVar3 = (param_3 - 2) + (uint)param_3;
        plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,iVar3 + 3);
        (**(code **)(*plVar2 + 0xd8))(plVar2,param_4);
        plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,iVar3 + 4);
        (**(code **)(*plVar2 + 0xd8))(plVar2,param_5);
        if (*(char *)(param_1 + 0x54) == '\0') {
          (**(code **)(*plVar1 + 0x38))(plVar1,0);
        }
      }
    }
    return;
  }
  log_InlineLogERROR("PowerLevel(%u), PowerOrder:%u, error,at %s, %d");
  return;
}

// ==== CMsgJiangHuOpt::helper_140400270  @140400270  [medium:callgraph-r1]  (orig: FUN_140400270)
void FUN_140400270(longlong param_1,char param_2,byte param_3,undefined1 *param_4,
                  undefined1 *param_5)

{
  undefined1 uVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  longlong lVar5;
  char local_res10 [8];
  longlong *local_28;
  longlong local_20;
  
  local_res10[0] = param_2;
  if (((byte)(param_2 - 1U) < 9) && ((byte)(param_3 - 1) < 9)) {
    FUN_140156ce0((longlong *)(param_1 + 0x10),&local_28,local_res10);
    lVar5 = *(longlong *)(param_1 + 0x40);
    if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0x10))) {
      _invalid_parameter_noinfo();
    }
    if (local_20 != lVar5) {
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *local_28;
      }
      if (local_20 == *(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar3 = *(longlong **)(local_20 + 0x20);
      if (plVar3 != (longlong *)0x0) {
        iVar4 = (param_3 - 2) + (uint)param_3;
        plVar2 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,iVar4 + 3);
        uVar1 = (**(code **)(*plVar2 + 0x20))(plVar2);
        *param_4 = uVar1;
        plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,iVar4 + 4);
        uVar1 = (**(code **)(*plVar3 + 0x20))(plVar3);
        *param_5 = uVar1;
      }
    }
    return;
  }
  log_InlineLogERROR("PowerLevel(%u), PowerOrder:%u, error,at %s, %d");
  return;
}

// ==== CMsgJiangHuOpt::helper_140400400  @140400400  [medium:callgraph-r1]  (orig: FUN_140400400)
BADSPACEBASE * FUN_140400400(longlong param_1,byte param_2)

{
  longlong lVar1;
  char cVar2;
  longlong *plVar3;
  byte local_res10 [8];
  byte local_30;
  undefined7 uStack_2f;
  longlong *local_28;
  undefined1 local_20 [24];
  
  if (*(char *)(param_1 + 0x54) == '\0') {
    local_res10[0] = param_2;
    if (param_2 < 10) {
      FUN_140156ce0(param_1 + 0x10,&local_30,local_res10);
      lVar1 = *(longlong *)(param_1 + 0x40);
      if ((CONCAT71(uStack_2f,local_30) == 0) ||
         (CONCAT71(uStack_2f,local_30) != *(longlong *)(param_1 + 0x10))) {
        _invalid_parameter_noinfo();
      }
      if (local_28 == (longlong *)lVar1) {
        plVar3 = (longlong *)InstanceGet();
        local_28 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_jianghu_player_power");
        if (local_28 == (longlong *)0x0) {
          log_InlineLogERROR("user:%u, create gongfu power(level:%u) error,at %s, %d");
          register0x00000020 = (BADSPACEBASE *)0x0;
        }
        else {
          plVar3 = (longlong *)(**(code **)(*local_28 + 0x10))(local_28,1);
          (**(code **)(*plVar3 + 0xb8))(plVar3,*(undefined4 *)(param_1 + 0xc));
          plVar3 = (longlong *)(**(code **)(*local_28 + 0x10))(local_28,2);
          (**(code **)(*plVar3 + 0xd8))(plVar3,param_2);
          cVar2 = (**(code **)(*local_28 + 0x50))(local_28,1);
          if (cVar2 == '\0') {
            log_InlineLogERROR("user:%u, insert gongfu power(level:%u) error,at %s, %d");
            (**(code **)*local_28)(local_28,1);
            register0x00000020 = (BADSPACEBASE *)0x0;
          }
          else {
            local_30 = param_2;
            FUN_140156b30(param_1 + 0x10,local_20,&local_30);
            register0x00000020 = (BADSPACEBASE *)0x1;
          }
        }
      }
      else {
        log_InlineLogERROR(
                          "CJiangHuPlayerPower::CreatePlayerPowerLevelData, user[%u]\'s level[%d] power already exists."
                          );
        register0x00000020 = (BADSPACEBASE *)0x0;
      }
    }
    else {
      log_InlineLogERROR("user:%u, create gongfu power(level:%u) error,at %s, %d");
      register0x00000020 = (BADSPACEBASE *)0x0;
    }
  }
  return register0x00000020;
}

// ==== CMsgJiangHuOpt::helper_1404005b0  @1404005b0  [medium:callgraph-r1]  (orig: FUN_1404005b0)
void FUN_1404005b0(longlong param_1,byte param_2,byte param_3)

{
  if ((((param_2 < 10) && (param_3 < 10)) && (*(byte *)(param_1 + 0x50) == param_2)) &&
     (*(byte *)(param_1 + 0x51) == param_3)) {
    FUN_140400120();
    *(undefined1 *)(param_1 + 0x50) = 0;
    *(undefined1 *)(param_1 + 0x51) = 0;
    *(undefined1 *)(param_1 + 0x52) = 0;
    *(undefined1 *)(param_1 + 0x53) = 0;
  }
  return;
}

// ==== CMsgJiangHuOpt::helper_140400600  @140400600  [medium:callgraph-r3]  (orig: FUN_140400600)
undefined8 FUN_140400600(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgJiangHuOpt::ctor_or_dtor  @140400920  [high:vtable-assign]  (orig: FUN_140400920)
undefined8 * FUN_140400920(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgJiangHuOpt::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x11),0x3ff,true);
  return param_1;
}

// ==== CMsgJiangHuOpt::ctor_or_dtor  @1404009a0  [high:vtable-assign]  (orig: FUN_1404009a0)
void FUN_1404009a0(undefined8 *param_1)

{
  *param_1 = CMsgJiangHuOpt::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgJiangHuOpt::vfunc_5  @1404009e0  [high:rtti-vtable]  (orig: FUN_1404009e0)
bool FUN_1404009e0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa8c;
    }
  }
  return false;
}

// ==== CMsgJiangHuOpt::helper_140400a20  @140400a20  [medium:callgraph-r1]  (orig: FUN_140400a20)
undefined1 FUN_140400a20(longlong param_1,undefined1 param_2)

{
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return 0;
  }
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0xa8c;
  return 1;
}

// ==== CMsgJiangHuOpt::helper_140400a80  @140400a80  [medium:callgraph-r1]  (orig: FUN_140400a80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140400a80(longlong param_1,undefined1 param_2,ulonglong param_3)

{
  bool bVar1;
  uint uVar2;
  undefined1 auStack_58 [32];
  char local_38 [9];
  ushort local_2f;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    local_38[0] = '\0';
    local_38[1] = '\0';
    local_38[2] = '\0';
    local_38[3] = '\0';
    local_38[4] = '\0';
    local_38[5] = '\0';
    local_38[6] = '\0';
    local_38[7] = '\0';
    local_38[8] = '\0';
    local_2f = 0;
    _snprintf(local_38,0xb,"%d",param_3 & 0xffffffff);
    local_2f = local_2f & 0xff;
    bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_38);
    **(undefined1 **)(param_1 + 0x428) = param_2;
    uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(undefined4 *)(param_1 + 8) = 0xa8c;
    *(uint *)(param_1 + 0xc) = uVar2 + 1;
    local_28 = (ulonglong)CONCAT31((int3)(uVar2 + 1 >> 8),bVar1);
  }
  return local_28;
}

// ==== CMsgJiangHuOpt::helper_140400b40  @140400b40  [medium:callgraph-r1]  (orig: FUN_140400b40)
ulonglong FUN_140400b40(longlong param_1,undefined1 param_2,char *param_3)

{
  bool bVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_3);
  **(undefined1 **)(param_1 + 0x428) = param_2;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(undefined4 *)(param_1 + 8) = 0xa8c;
  *(uint *)(param_1 + 0xc) = uVar2 + 1;
  return (ulonglong)CONCAT31((int3)(uVar2 + 1 >> 8),bVar1);
}

// ==== CMsgJiangHuOpt::helper_140400df0  @140400df0  [medium:callgraph-r1]  (orig: FUN_140400df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140400df0(longlong param_1,undefined1 param_2,ulonglong param_3,ulonglong param_4,
                       byte param_5)

{
  bool bVar1;
  bool bVar2;
  bool bVar3;
  uint uVar4;
  undefined1 auStack_78 [32];
  char local_58 [9];
  ushort local_4f;
  char local_48 [9];
  ushort local_3f;
  char local_38 [9];
  ushort local_2f;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    local_48[0] = '\0';
    local_48[1] = '\0';
    local_48[2] = '\0';
    local_48[3] = '\0';
    local_48[4] = '\0';
    local_48[5] = '\0';
    local_48[6] = '\0';
    local_48[7] = '\0';
    local_48[8] = '\0';
    local_3f = 0;
    _snprintf(local_48,0xb,"%u",param_3 & 0xffffffff);
    local_3f = local_3f & 0xff;
    local_58[0] = '\0';
    local_58[1] = '\0';
    local_58[2] = '\0';
    local_58[3] = '\0';
    local_58[4] = '\0';
    local_58[5] = '\0';
    local_58[6] = '\0';
    local_58[7] = '\0';
    local_58[8] = '\0';
    local_4f = 0;
    _snprintf(local_58,0xb,"%u",param_4 & 0xff);
    local_4f = local_4f & 0xff;
    local_38[0] = '\0';
    local_38[1] = '\0';
    local_38[2] = '\0';
    local_38[3] = '\0';
    local_38[4] = '\0';
    local_38[5] = '\0';
    local_38[6] = '\0';
    local_38[7] = '\0';
    local_38[8] = '\0';
    local_2f = 0;
    _snprintf(local_38,0xb,"%u",(ulonglong)param_5);
    local_2f = local_2f & 0xff;
    bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_48);
    bVar2 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_58);
    bVar3 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_38);
    **(undefined1 **)(param_1 + 0x428) = param_2;
    uVar4 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(undefined4 *)(param_1 + 8) = 0xa8c;
    *(uint *)(param_1 + 0xc) = uVar4 + 1;
    local_28 = (ulonglong)CONCAT31((int3)(uVar4 + 1 >> 8),(bVar1 && bVar2) && bVar3);
  }
  return local_28;
}

// ==== CMsgJiangHuOpt::ctor_or_dtor  @140401120  [high:vtable-assign]  (orig: FUN_140401120)
undefined8 * FUN_140401120(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgJiangHuOpt::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgJiangHuOpt::vfunc_3  @140401180  [high:rtti-vtable]  (orig: FUN_140401180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140401180(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  ulong uVar3;
  ulong uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  char local_88 [24];
  longlong local_70;
  undefined8 local_68;
  char local_60 [16];
  char local_50 [16];
  char local_40 [32];
  ulonglong local_20;
  
  local_68 = 0xfffffffffffffffe;
  local_20 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  if (*(longlong *)(param_1 + 0x428) != 0) {
    local_70 = param_1;
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar5);
    lVar7 = (**(code **)(*plVar6 + 0x88))(plVar6,param_1);
    if (((lVar7 != 0) &&
        (cVar1 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x220))(), cVar1 != '\0')) &&
       ((cVar1 = FUN_140167b70(lVar7), cVar1 == '\0' || (**(char **)(param_1 + 0x428) == '\t')))) {
      switch(**(undefined1 **)(param_1 + 0x428)) {
      case 1:
        local_40[0] = '\0';
        local_40[1] = '\0';
        local_40[2] = '\0';
        local_40[3] = '\0';
        local_40[4] = '\0';
        local_40[5] = '\0';
        local_40[6] = '\0';
        local_40[7] = '\0';
        local_40[8] = '\0';
        local_40[9] = '\0';
        local_40[10] = '\0';
        local_40[0xb] = '\0';
        local_40[0xc] = '\0';
        local_40[0xd] = '\0';
        local_40[0xe] = '\0';
        local_40[0xf] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_40,0x10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401e93b0(uVar5,lVar7,local_40);
        break;
      case 9:
        local_50[0] = '\0';
        local_50[1] = '\0';
        local_50[2] = '\0';
        local_50[3] = '\0';
        local_50[4] = '\0';
        local_50[5] = '\0';
        local_50[6] = '\0';
        local_50[7] = '\0';
        local_50[8] = '\0';
        local_50[9] = '\0';
        local_50[10] = '\0';
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_50,0xb);
        uVar2 = strtoul(local_50,(char **)0x0,10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401eb6d0(uVar5,lVar7,uVar2);
        break;
      case 10:
        local_88[0x14] = 0;
        local_88[0x15] = '\0';
        local_88[0x16] = '\0';
        local_88[0x17] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_88 + 0x14,4);
        local_88[8] = 0;
        local_88[9] = '\0';
        local_88[10] = '\0';
        local_88[0xb] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_88 + 8,4);
        uVar2 = strtoul(local_88 + 0x14,(char **)0x0,10);
        uVar3 = strtoul(local_88 + 8,(char **)0x0,10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401e69c0(uVar5,lVar7,uVar2 & 0xff,uVar3 & 0xff);
        break;
      case 0xb:
        local_88[0xc] = 0;
        local_88[0xd] = '\0';
        local_88[0xe] = '\0';
        local_88[0xf] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_88 + 0xc,4);
        local_88[0] = '\0';
        local_88[1] = '\0';
        local_88[2] = '\0';
        local_88[3] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_88,4);
        uVar2 = strtoul(local_88 + 0xc,(char **)0x0,10);
        uVar3 = strtoul(local_88,(char **)0x0,10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401f1230(uVar5,lVar7,uVar2 & 0xff,uVar3 & 0xff);
        break;
      case 0xd:
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401e7c80(uVar5,lVar7);
        break;
      case 0x10:
        local_88[0x10] = 0;
        local_88[0x11] = '\0';
        local_88[0x12] = '\0';
        local_88[0x13] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_88 + 0x10,4);
        local_88[4] = 0;
        local_88[5] = '\0';
        local_88[6] = '\0';
        local_88[7] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_88 + 4,4);
        local_60[0] = '\0';
        local_60[1] = '\0';
        local_60[2] = '\0';
        local_60[3] = '\0';
        local_60[4] = '\0';
        local_60[5] = '\0';
        local_60[6] = '\0';
        local_60[7] = '\0';
        local_60[8] = '\0';
        local_60[9] = '\0';
        local_60[10] = '\0';
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),2,local_60,0xb);
        uVar2 = strtoul(local_88 + 0x10,(char **)0x0,10);
        uVar3 = strtoul(local_88 + 4,(char **)0x0,10);
        uVar4 = strtoul(local_60,(char **)0x0,10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        local_98 = CONCAT31(local_98._1_3_,(char)uVar3);
        FUN_1401e6c20(uVar5,lVar7,uVar4,uVar2 & 0xff);
        break;
      case 0x11:
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401e7dc0(uVar5,lVar7);
        break;
      case 0x12:
        local_40[0x10] = 0;
        local_40[0x11] = '\0';
        local_40[0x12] = '\0';
        local_40[0x13] = '\0';
        local_40[0x14] = '\0';
        local_40[0x15] = '\0';
        local_40[0x16] = '\0';
        local_40[0x17] = '\0';
        local_40[0x18] = '\0';
        local_40[0x19] = '\0';
        local_40[0x1a] = '\0';
        local_40[0x1b] = '\0';
        local_40[0x1c] = '\0';
        local_40[0x1d] = '\0';
        local_40[0x1e] = '\0';
        local_40[0x1f] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_40 + 0x10,0x10);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x1c0) == 0) {
          local_98 = 0x15c;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x1c0);
        }
        FUN_1401e8950(uVar5,lVar7,local_40 + 0x10);
      }
    }
  }
  return;
}

