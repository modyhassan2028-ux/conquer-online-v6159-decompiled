// ==== CCrossMsgLeagueBrick::ctor_or_dtor  @14045c830  [high:vtable-assign]  (orig: FUN_14045c830)
undefined8 * FUN_14045c830(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueBrick::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLeagueBrick::ctor_or_dtor  @14045c880  [high:vtable-assign]  (orig: FUN_14045c880)
void FUN_14045c880(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueBrick::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLeagueBrick::vfunc_1  @14045c8b0  [high:rtti-vtable]  (orig: FUN_14045c8b0)
undefined8 FUN_14045c8b0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLeagueBrick::vfunc_3  @14045c8e0  [high:rtti-vtable]  (orig: FUN_14045c8e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14045c8e0(longlong param_1)

{
  longlong lVar1;
  ushort uVar2;
  int iVar3;
  longlong *plVar4;
  IStringManager *pIVar5;
  char *_Format;
  ulonglong uVar6;
  undefined1 auStack_278 [32];
  undefined4 local_258;
  ushort local_248;
  ushort local_244;
  ushort local_240;
  ushort local_23c;
  undefined8 local_238;
  char local_228;
  undefined1 local_227 [511];
  ulonglong local_28;
  
  local_238 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_278;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_258 = 0x21;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar4 = (longlong *)FUN_140087ed0();
    if (plVar4 == (longlong *)0x0) {
      local_258 = 0x26;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      switch(**(short **)(param_1 + 0x428)) {
      case 1:
        local_23c = 0;
        while (uVar2 = local_23c, lVar1 = *(longlong *)(param_1 + 0x428),
              local_23c < *(ushort *)(lVar1 + 0xc)) {
          (**(code **)(*plVar4 + 0x448))
                    (plVar4,*(undefined4 *)(lVar1 + 0x10 + (ulonglong)local_23c * 8),
                     *(undefined4 *)(lVar1 + 0x14 + (ulonglong)local_23c * 8));
          local_23c = uVar2 + 1;
        }
        (**(code **)(*plVar4 + 0x4b8))(plVar4);
        (**(code **)(*plVar4 + 0x428))
                  (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                   *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        break;
      case 2:
      case 7:
        local_240 = 0;
        while (uVar2 = local_240, lVar1 = *(longlong *)(param_1 + 0x428),
              local_240 < *(ushort *)(lVar1 + 0xc)) {
          (**(code **)(*plVar4 + 0x448))
                    (plVar4,*(undefined4 *)(lVar1 + 0x10 + (ulonglong)local_240 * 8),
                     *(undefined4 *)(lVar1 + 0x14 + (ulonglong)local_240 * 8));
          local_240 = uVar2 + 1;
        }
        (**(code **)(*plVar4 + 0x4b8))(plVar4);
        break;
      case 3:
        local_248 = 0;
        while (uVar2 = local_248, local_248 < *(ushort *)(*(longlong *)(param_1 + 0x428) + 0xc)) {
          uVar6 = (ulonglong)local_248;
          iVar3 = (**(code **)(*plVar4 + 0x430))
                            (plVar4,*(undefined4 *)
                                     (*(longlong *)(param_1 + 0x428) + 0x10 + uVar6 * 8));
          (**(code **)(*plVar4 + 0x448))
                    (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10 + uVar6 * 8),
                     *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14 + uVar6 * 8));
          if (iVar3 <= *(int *)(*(longlong *)(param_1 + 0x428) + 0x14 + uVar6 * 8)) {
            return;
          }
          local_228 = '\0';
          memset(local_227,0,0x1ff);
          pIVar5 = theInstance();
          _Format = (char *)(*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NOTIFY_REDUCE_BRICK");
          _snprintf(&local_228,0x200,_Format);
          local_258 = CONCAT22(local_258._2_2_,0x7ec);
          (**(code **)(*plVar4 + 0x4d8))
                    (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10 + uVar6 * 8),
                     &local_228,0);
          local_248 = uVar2 + 1;
        }
        (**(code **)(*plVar4 + 0x4b8))(plVar4);
        break;
      case 4:
      case 5:
        lVar1 = *(longlong *)(param_1 + 0x428);
        local_258 = CONCAT31(local_258._1_3_,**(short **)(param_1 + 0x428) == 5);
        (**(code **)(*plVar4 + 0x420))
                  (plVar4,*(undefined4 *)(lVar1 + 0x10),*(undefined4 *)(lVar1 + 0x14),
                   *(undefined4 *)(lVar1 + 8));
        break;
      case 6:
        local_244 = 0;
        while (uVar2 = local_244, local_244 < *(ushort *)(*(longlong *)(param_1 + 0x428) + 0xc)) {
          lVar1 = *(longlong *)(param_1 + 0x428);
          (**(code **)(*plVar4 + 0x4b0))
                    (plVar4,*(undefined4 *)(lVar1 + 4),
                     *(undefined4 *)(lVar1 + 0x10 + (ulonglong)local_244 * 8),
                     *(undefined4 *)(lVar1 + 0x14 + (ulonglong)local_244 * 8));
          local_244 = uVar2 + 1;
        }
      }
    }
  }
  return;
}

// ==== CCrossMsgLeagueBrick::ctor_or_dtor  @14045cc30  [high:vtable-assign]  (orig: FUN_14045cc30)
undefined8 * FUN_14045cc30(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueBrick::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

