// ==== CInnerStrengthData::helper_1404dbdf0  @1404dbdf0  [medium:callgraph-r0]  (orig: FUN_1404dbdf0)
void FUN_1404dbdf0(void *param_1)

{
  if ((DAT_140976528 & 1) == 0) {
    DAT_140976528 = DAT_140976528 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976520,"CInnerStrengthData");
    atexit((_func_5014 *)&LAB_1406d6f30);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404dbe45. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976520,param_1);
  return;
}

// ==== CInnerStrengthData::ctor_or_dtor  @1404dbeb0  [high:vtable-assign]  (orig: FUN_1404dbeb0)
undefined8 * FUN_1404dbeb0(undefined8 *param_1,byte param_2)

{
  *param_1 = CInnerStrengthData::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1404dbdf0();
  }
  return param_1;
}

// ==== CInnerStrengthData::helper_1404dbee0  @1404dbee0  [medium:callgraph-r0]  (orig: FUN_1404dbee0)
void FUN_1404dbee0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  if (param_1[1] != 0) {
    (*(code *)**(undefined8 **)param_1[1])
              ((undefined8 *)param_1[1],1,param_3,param_4,0xfffffffffffffffe);
    param_1[1] = 0;
  }
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CInnerStrengthData::ctor_or_dtor  @1404dbf30  [high:vtable-assign]  (orig: FUN_1404dbf30)
undefined8 * FUN_1404dbf30(uint param_1,undefined8 *param_2,undefined1 param_3)

{
  undefined8 *puVar1;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","idUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\innerstrength\\innerstrengthdata.cpp"
                       ,0x15);
    if (param_2 != (undefined8 *)0x0) {
      (**(code **)*param_2)(param_2,1);
    }
    puVar1 = (undefined8 *)0x0;
  }
  else {
    if ((DAT_140976528 & 1) == 0) {
      DAT_140976528 = DAT_140976528 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140976520,"CInnerStrengthData");
      atexit((_func_5014 *)&LAB_1406d6f30);
    }
    puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976520,0x18);
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = CInnerStrengthData::vftable;
      *(undefined1 *)(puVar1 + 2) = 0;
      puVar1[1] = 0;
    }
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pInnerStrengthData",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\innerstrength\\innerstrengthdata.cpp"
                         ,0x1b);
      if (param_2 != (undefined8 *)0x0) {
        (**(code **)*param_2)(param_2,1);
      }
      puVar1 = (undefined8 *)0x0;
    }
    else if (param_2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_1406e5370,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\innerstrength\\innerstrengthdata.cpp"
                         ,0x38);
      log_InlineLogERROR("CInnerStrengthData::CreateNew create failed, idUser:%u.",
                         (ulonglong)param_1);
      FUN_1404dbee0(puVar1);
      puVar1 = (undefined8 *)0x0;
    }
    else {
      puVar1[1] = param_2;
      *(undefined1 *)(puVar1 + 2) = param_3;
    }
  }
  return puVar1;
}

