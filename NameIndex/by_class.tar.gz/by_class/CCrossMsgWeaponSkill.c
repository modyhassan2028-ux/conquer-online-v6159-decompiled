// ==== CCrossMsgWeaponSkill::helper_140168850  @140168850  [medium:callgraph-r1]  (orig: FUN_140168850)
void FUN_140168850(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined1 param_6,undefined1 param_7,undefined1 param_8)

{
  longlong lVar1;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined1 local_18;
  undefined1 local_17;
  undefined1 local_16;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x30))();
  if (lVar1 == 0) {
    local_1c = param_5;
    local_18 = param_6;
    local_17 = param_7;
    local_16 = param_8;
    local_28 = param_2;
    local_24 = param_3;
    local_20 = param_4;
    lVar1 = FUN_14039dc70(&local_28,1);
    if (lVar1 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x20))
                (*(longlong **)(param_1 + 0x1110),lVar1);
    }
  }
  else {
    FUN_14039da00(lVar1,param_3,0);
    FUN_14039d770(lVar1,param_4,0);
    FUN_14039d870(lVar1,param_5,0);
    FUN_14039d7f0(lVar1,param_6,0);
    FUN_14039d960(lVar1,param_7,0);
    FUN_14039d8f0(lVar1,param_8,0);
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14018a220  @14018a220  [medium:callgraph-r0]  (orig: FUN_14018a220)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14018a220(longlong *param_1,int param_2,undefined4 param_3,undefined4 param_4,int param_5,
                  undefined4 param_6,undefined1 param_7,undefined1 param_8,undefined1 param_9)

{
  undefined1 uVar1;
  ulonglong uVar2;
  undefined1 uVar3;
  undefined1 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined1 local_4b0;
  undefined1 local_4a8;
  undefined1 local_4a0;
  ulonglong local_498;
  longlong *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  local_490 = param_1;
  if (param_2 == 0) {
    local_4a0 = param_9;
    local_4a8 = param_8;
    local_4b0 = param_7;
    local_4b8 = param_6;
    FUN_140168850(param_1,param_3,param_4,param_5);
  }
  else if (param_2 == 1) {
    lVar11 = (**(code **)(*(longlong *)param_1[0x222] + 0x30))((longlong *)param_1[0x222],param_3);
    if (lVar11 != 0) {
      FUN_14039da00(lVar11,param_4,0);
      FUN_14039d770(lVar11,param_5,0);
      FUN_14039d870(lVar11,param_6,0);
      FUN_14039d7f0(lVar11,param_7,0);
      FUN_14039d960(lVar11,param_8,0);
      FUN_14039d8f0(lVar11,param_9,0);
      FUN_14039da70(lVar11);
    }
  }
  else {
    if (param_2 == 2) {
      FUN_140183e30(param_1,param_5,param_6,1);
    }
    else if (param_2 == 3) {
      FUN_140170ae0(param_1,param_5,param_7);
    }
    else {
      if (param_2 == 5) {
        FUN_140162620();
        return;
      }
      if ((param_2 != 2) && (param_2 != 3)) {
        return;
      }
    }
    uVar10 = (**(code **)(*(longlong *)param_1[0x222] + 0x10))();
    local_498 = 0;
    while (uVar2 = local_498, local_498 < uVar10) {
      lVar11 = (**(code **)(*(longlong *)param_1[0x222] + 0x18))
                         ((longlong *)param_1[0x222],local_498,
                          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp",
                          0x674e);
      if ((lVar11 != 0) && (iVar5 = FUN_14039d760(lVar11), iVar5 == param_5)) {
        FUN_1403f0130(local_478);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        FUN_1403f01e0(local_478,uVar6,0);
        uVar1 = *(undefined1 *)(lVar11 + 0x1a);
        uVar3 = FUN_14039d8e0(lVar11);
        uVar4 = FUN_14039d7e0(lVar11);
        uVar6 = FUN_14039d860(lVar11);
        uVar7 = FUN_14039d760(lVar11);
        uVar8 = FUN_14039d9f0(lVar11);
        uVar9 = FUN_14039d9d0(lVar11);
        local_4b8 = uVar6;
        local_4b0 = uVar4;
        local_4a8 = uVar3;
        local_4a0 = uVar1;
        FUN_1403f0220(local_478,uVar9,uVar8,uVar7);
        (**(code **)(*local_490 + 0x130))(local_490,local_478);
        FUN_1403f0180(local_478);
        return;
      }
      local_498 = uVar2 + 1;
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14039d770  @14039d770  [medium:callgraph-r1]  (orig: FUN_14039d770)
void FUN_14039d770(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x10) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x20);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,&DAT_1406de6d4);
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if ((param_3 != '\0') && (*(char *)(param_1 + 0x28) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14039d870  @14039d870  [medium:callgraph-r1]  (orig: FUN_14039d870)
void FUN_14039d870(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x14) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x20);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,&DAT_14070eeb8);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if ((param_3 != '\0') && (*(char *)(param_1 + 0x28) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14039d8f0  @14039d8f0  [medium:callgraph-r1]  (orig: FUN_14039d8f0)
void FUN_14039d8f0(longlong param_1,undefined1 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined1 *)(param_1 + 0x1a) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x20);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"unlearn");
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if ((param_3 != '\0') && (*(char *)(param_1 + 0x28) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14039d960  @14039d960  [medium:callgraph-r1]  (orig: FUN_14039d960)
void FUN_14039d960(longlong param_1,undefined1 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined1 *)(param_1 + 0x19) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x20);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"old_level");
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if ((param_3 != '\0') && (*(char *)(param_1 + 0x28) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::helper_14039da00  @14039da00  [medium:callgraph-r1]  (orig: FUN_14039da00)
void FUN_14039da00(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0xc) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x20);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"owner_id");
    (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
    if ((param_3 != '\0') && (*(char *)(param_1 + 0x28) == '\0')) {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CCrossMsgWeaponSkill::ctor_or_dtor  @1403f0130  [high:vtable-assign]  (orig: FUN_1403f0130)
undefined8 * FUN_1403f0130(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgWeaponSkill::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgWeaponSkill::ctor_or_dtor  @1403f0180  [high:vtable-assign]  (orig: FUN_1403f0180)
void FUN_1403f0180(undefined8 *param_1)

{
  *param_1 = CCrossMsgWeaponSkill::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgWeaponSkill::vfunc_1  @1403f01b0  [high:rtti-vtable]  (orig: FUN_1403f01b0)
ulonglong FUN_1403f01b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c4c);
}

// ==== CCrossMsgWeaponSkill::ctor_or_dtor  @1403f0300  [high:vtable-assign]  (orig: FUN_1403f0300)
undefined8 * FUN_1403f0300(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgWeaponSkill::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgWeaponSkill::vfunc_3  @1403f0350  [high:rtti-vtable]  (orig: FUN_1403f0350)
void FUN_1403f0350(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  uint uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  if (*(int *)(*(longlong *)(param_1 + 0x428) + 4) == 0) {
    uVar1 = *(undefined4 *)(param_1 + 0x420);
    uVar2 = *(undefined4 *)(param_1 + 0x41c);
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = FUN_1402af110(*(undefined8 *)(lVar4 + 0x90),uVar2,uVar1);
  }
  else {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x98))
                      (*(longlong **)(lVar4 + 0x90),**(undefined4 **)(param_1 + 0x428));
  }
  if ((lVar4 != 0) && (uVar6 = 0, uVar7 = uVar6, *(int *)(*(longlong *)(param_1 + 0x428) + 8) != 0))
  {
    do {
      lVar3 = *(longlong *)(param_1 + 0x428);
      FUN_14018a220(lVar4,*(undefined4 *)(lVar3 + 4),*(undefined4 *)(uVar7 + 0xc + lVar3),
                    *(undefined4 *)(uVar7 + 0x10 + lVar3),*(undefined4 *)(uVar7 + 0x14 + lVar3),
                    *(undefined4 *)(uVar7 + 0x18 + lVar3),*(undefined1 *)(uVar7 + 0x1c + lVar3),
                    *(undefined1 *)(uVar7 + 0x1d + lVar3),*(undefined1 *)(uVar7 + 0x1e + lVar3));
      uVar5 = (int)uVar6 + 1;
      uVar6 = (ulonglong)uVar5;
      uVar7 = uVar7 + 0x14;
    } while (uVar5 < *(uint *)(*(longlong *)(param_1 + 0x428) + 8));
  }
  return;
}

