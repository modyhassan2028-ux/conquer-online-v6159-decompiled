// ==== CMsgUserIPInfo::ctor_or_dtor  @14007d5f0  [high:vtable-assign]  (orig: FUN_14007d5f0)
undefined8 * FUN_14007d5f0(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgUserIPInfo::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgUserIPInfo::ctor_or_dtor  @14007d640  [high:vtable-assign]  (orig: FUN_14007d640)
void FUN_14007d640(undefined8 *param_1)

{
  *param_1 = CMsgUserIPInfo::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgUserIPInfo::vfunc_1  @14007d6e0  [high:rtti-vtable]  (orig: FUN_14007d6e0)
ulonglong FUN_14007d6e0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x81e);
}

// ==== CMsgUserIPInfo::vfunc_3  @14007d710  [high:rtti-vtable]  (orig: FUN_14007d710)
void FUN_14007d710(void)

{
  return;
}

// ==== CMsgUserIPInfo::ctor_or_dtor  @14007d720  [high:vtable-assign]  (orig: FUN_14007d720)
undefined8 * FUN_14007d720(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgUserIPInfo::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

