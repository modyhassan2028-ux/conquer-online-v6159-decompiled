// ==== CMsgExchangeInnerStrength::ctor_or_dtor  @14040a430  [high:vtable-assign]  (orig: FUN_14040a430)
undefined8 * FUN_14040a430(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgExchangeInnerStrength::vftable;
  FUN_140577a70(param_1 + 0x85);
  FUN_1402b5600(param_1);
  return param_1;
}

// ==== CMsgExchangeInnerStrength::ctor_or_dtor  @14040a480  [high:vtable-assign]  (orig: FUN_14040a480)
void FUN_14040a480(undefined8 *param_1)

{
  *param_1 = CMsgExchangeInnerStrength::vftable;
  FUN_140577b60(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgExchangeInnerStrength::ctor_or_dtor  @14040a5f0  [high:vtable-assign]  (orig: FUN_14040a5f0)
undefined8 * FUN_14040a5f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgExchangeInnerStrength::vftable;
  FUN_140577b60(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

