// ==== CHttpService::ctor_or_dtor  @1400c6fd0  [high:vtable-assign]  (orig: FUN_1400c6fd0)
undefined8 * FUN_1400c6fd0(undefined8 *param_1)

{
  *param_1 = CHttpService::vftable;
  FUN_140329c60(param_1 + 1);
  param_1[0x183] = 0;
  param_1[0x184] = 0;
  return param_1;
}

// ==== CHttpService::ctor_or_dtor  @1400c7020  [high:vtable-assign]  (orig: FUN_1400c7020)
void FUN_1400c7020(undefined8 *param_1)

{
  *param_1 = CHttpService::vftable;
  if (param_1[0x184] != 0) {
    InternetCloseHandle();
  }
  if (param_1[0x183] != 0) {
    InternetCloseHandle();
  }
  FUN_140329cc0(param_1 + 1);
  return;
}

// ==== CHttpService::ctor_or_dtor  @1400c75f0  [high:vtable-assign]  (orig: FUN_1400c75f0)
undefined8 * FUN_1400c75f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CHttpService::vftable;
  if (param_1[0x184] != 0) {
    InternetCloseHandle();
  }
  if (param_1[0x183] != 0) {
    InternetCloseHandle();
  }
  FUN_140329cc0(param_1 + 1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

