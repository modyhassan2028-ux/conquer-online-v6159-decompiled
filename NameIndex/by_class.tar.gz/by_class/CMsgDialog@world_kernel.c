// ==== CMsgDialog@world_kernel::vfunc_1  @140082a60  [high:rtti-vtable]  (orig: FUN_140082a60)
undefined8 FUN_140082a60(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgDialog@world_kernel::vfunc_3  @140082a90  [high:rtti-vtable]  (orig: FUN_140082a90)
void FUN_140082a90(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgDialog@world_kernel::vfunc_0  @140082ad0  [high:rtti-vtable]  (orig: FUN_140082ad0)
undefined8 * FUN_140082ad0(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgDialog::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

