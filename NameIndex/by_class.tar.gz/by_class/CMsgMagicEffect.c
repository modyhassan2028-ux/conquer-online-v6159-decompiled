// ==== CMsgMagicEffect::ctor_or_dtor  @140386780  [high:vtable-assign]  (orig: FUN_140386780)
undefined8 * FUN_140386780(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMagicEffect::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMagicEffect::ctor_or_dtor  @1403867d0  [high:vtable-assign]  (orig: FUN_1403867d0)
void FUN_1403867d0(undefined8 *param_1)

{
  *param_1 = CMsgMagicEffect::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMagicEffect::vfunc_1  @140387290  [high:rtti-vtable]  (orig: FUN_140387290)
ulonglong FUN_140387290(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x451);
}

// ==== CMsgMagicEffect::vfunc_3  @1403872c0  [high:rtti-vtable]  (orig: FUN_1403872c0)
void FUN_1403872c0(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001403872c7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("invalid msg CMsgMagicEffect.");
  return;
}

// ==== CMsgMagicEffect::ctor_or_dtor  @1403872d0  [high:vtable-assign]  (orig: FUN_1403872d0)
undefined8 * FUN_1403872d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMagicEffect::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

