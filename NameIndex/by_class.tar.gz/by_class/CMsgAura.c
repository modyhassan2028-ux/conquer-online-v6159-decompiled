// ==== CMsgAura::helper_1400878d0  @1400878d0  [medium:callgraph-r0]  (orig: FUN_1400878d0)
longlong FUN_1400878d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x140);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgAura::helper_14024ecf0  @14024ecf0  [medium:callgraph-r0]  (orig: FUN_14024ecf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14024ecf0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar7 = FUN_14024e590(param_1,param_3);
  if (lVar7 != 0) {
    uVar2 = FUN_14041db90(param_4);
    lVar7 = FUN_14041b530(lVar7,uVar2);
    if (lVar7 != 0) {
      uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
      plVar9 = (longlong *)FUN_140087650(uVar8);
      lVar10 = (**(code **)(*plVar9 + 0x98))(plVar9,param_2);
      if (lVar10 == 0) {
        local_4a8 = 0x93;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140423310(local_478);
        uVar2 = FUN_14041dae0(lVar7);
        uVar3 = FUN_14041dab0(lVar7);
        uVar4 = FUN_14041dac0(lVar7);
        uVar5 = FUN_14041da90(lVar7);
        uVar6 = FUN_14041daa0(lVar7);
        local_4a8 = uVar4;
        local_4a0 = uVar3;
        local_498 = uVar2;
        cVar1 = FUN_1404233c0(local_478,4,uVar6,uVar5);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x350))((longlong *)(lVar10 + 0x10),local_478)
          ;
        }
        FUN_140423360(local_478);
      }
    }
  }
  return;
}

// ==== CMsgAura::helper_14024eeb0  @14024eeb0  [medium:callgraph-r0]  (orig: FUN_14024eeb0)
bool FUN_14024eeb0(longlong param_1,int param_2,int param_3,undefined4 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong *plVar15;
  undefined8 uVar16;
  longlong *plVar17;
  longlong lVar18;
  
  lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
  if (*(longlong *)(lVar14 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar15 = (longlong *)
            (**(code **)(**(longlong **)(lVar14 + 0x90) + 0x98))
                      (*(longlong **)(lVar14 + 0x90),param_2);
  if (plVar15 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  cVar2 = (**(code **)(plVar15[2] + 0x220))(plVar15 + 2);
  if (cVar2 != '\0') {
    uVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
    plVar17 = (longlong *)FUN_140087650(uVar16);
    lVar14 = (**(code **)(*plVar17 + 0x98))(plVar17,param_3);
    if (lVar14 != 0) {
      plVar17 = (longlong *)(lVar14 + 0x10);
      cVar2 = (**(code **)(*(longlong *)(lVar14 + 0x10) + 0x220))(plVar17);
      if (cVar2 != '\0') {
        lVar14 = FUN_14024e590(param_1,param_2);
        if (lVar14 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          return false;
        }
        lVar18 = FUN_14024e590(param_1,param_3);
        if (lVar18 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          return false;
        }
        uVar3 = FUN_14041db90(param_4);
        lVar18 = FUN_14041b530(lVar18,uVar3);
        if (lVar18 != 0) {
          if (param_2 == param_3) {
LAB_14024f1ab:
            cVar2 = FUN_14041c230(lVar14,lVar18);
            return cVar2 != '\0';
          }
          iVar4 = FUN_14041dab0(lVar18);
          iVar5 = (**(code **)(plVar15[2] + 0x168))(plVar15 + 2);
          iVar6 = (**(code **)(*plVar17 + 0x168))(plVar17);
          if (iVar5 == iVar6) {
            iVar5 = (**(code **)(plVar15[2] + 0x48))(plVar15 + 2);
            iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
            iVar7 = (**(code **)(plVar15[2] + 0x48))(plVar15 + 2);
            iVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
            iVar9 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
            iVar10 = (**(code **)(*plVar17 + 0x40))(plVar17);
            iVar11 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
            iVar12 = (**(code **)(*plVar17 + 0x40))(plVar17);
            if ((iVar11 - iVar12) * (iVar9 - iVar10) + (iVar7 - iVar8) * (iVar5 - iVar6) <=
                iVar4 * iVar4) {
              plVar17 = (longlong *)FUN_140118320();
              if (plVar17 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                cVar2 = FUN_140167b70(plVar15);
                if (cVar2 == '\0') {
                  iVar4 = (**(code **)(*plVar17 + 0x28))(plVar17,param_2);
                }
                else {
                  lVar1 = *plVar17;
                  uVar3 = (**(code **)(*plVar15 + 0x38))(plVar15);
                  uVar13 = FUN_140167b40(plVar15);
                  iVar4 = (**(code **)(lVar1 + 0xe8))(plVar17,uVar13,uVar3);
                }
                if ((iVar4 != 0) &&
                   (cVar2 = (**(code **)(*plVar17 + 0x20))(plVar17,param_2,param_3), cVar2 != '\0'))
                goto LAB_14024f1ab;
              }
            }
          }
        }
      }
      return false;
    }
  }
  return false;
}

// ==== CMsgAura::helper_14041a850  @14041a850  [medium:callgraph-r3]  (orig: FUN_14041a850)
undefined8 *
FUN_14041a850(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140419b20(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgAura::helper_14041b100  @14041b100  [medium:callgraph-r2]  (orig: FUN_14041b100)
longlong * FUN_14041b100(longlong *param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < *(int *)(puVar8 + 3);
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_14041b25d:
    local_30 = puVar4;
    if (*param_3 <= *(int *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14041b28c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x29);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14041b25d;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_14041a850(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14041b28c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgAura::helper_14041b530  @14041b530  [medium:callgraph-r1]  (orig: FUN_14041b530)
undefined8 FUN_14041b530(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgAura::helper_14041b630  @14041b630  [medium:callgraph-r2]  (orig: FUN_14041b630)
undefined8 FUN_14041b630(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x80);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgAura::helper_14041c230  @14041c230  [medium:callgraph-r1]  (orig: FUN_14041c230)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14041c230(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined1 auStack_518 [32];
  undefined4 local_4f8;
  undefined4 local_4f0;
  undefined4 local_4e8;
  undefined4 local_4e0;
  undefined1 local_4d8;
  undefined2 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4b8;
  undefined4 local_4b4;
  undefined4 local_4b0 [2];
  longlong local_4a8;
  undefined8 local_4a0;
  undefined1 local_498 [32];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x90));
  if (*(longlong *)(lVar10 + 0x90) == 0) {
    local_4f8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar10 = (**(code **)(**(longlong **)(lVar10 + 0x90) + 0x98))
                     (*(longlong **)(lVar10 + 0x90),*(undefined4 *)(param_1 + 8));
  if (lVar10 == 0) {
    local_4f8 = 0xe9;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    plVar1 = (longlong *)(lVar10 + 0x10);
    cVar2 = (**(code **)(*plVar1 + 0x220))(plVar1);
    uVar3 = 0;
    if (cVar2 != '\0') {
      if (param_2 == 0) {
        local_4f8 = 0xef;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = 0;
      }
      else {
        uVar4 = FUN_14041dac0(param_2);
        uVar5 = FUN_14041da90(param_2);
        uVar6 = FUN_14041db20(uVar5);
        iVar7 = FUN_14041dbd0(uVar5);
        local_4b4 = FUN_14041de90(param_2);
        uVar8 = FUN_14041dae0(param_2);
        local_4b8 = FUN_14041daa0(param_2);
        if (iVar7 == -1) {
          local_4f8 = 0xf7;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar3 = 0;
        }
        else {
          lVar10 = FUN_14041b630(param_1,uVar6);
          if (lVar10 != 0) {
            uVar9 = FUN_14041da90(lVar10);
            FUN_14041b950(param_1,uVar9);
          }
          FUN_14041df20(param_2,*(undefined4 *)(param_1 + 8));
          local_4b0[0] = uVar6;
          local_4a8 = param_2;
          FUN_14041b100(param_1 + 0x50,local_498,local_4b0);
          plVar11 = (longlong *)FUN_1401181a0();
          local_4c8 = 0;
          local_4d0 = 0;
          local_4d8 = 0;
          local_4e0 = 0;
          local_4e8 = 0;
          local_4f0 = 0;
          local_4f8 = local_4b4;
          (**(code **)(*plVar11 + 8))(plVar11,*(undefined4 *)(param_1 + 8),iVar7,uVar8);
          FUN_140423310(local_478);
          local_4f0 = FUN_14041dab0(param_2);
          local_4f8 = uVar4;
          local_4e8 = uVar8;
          cVar2 = FUN_1404233c0(local_478,3,local_4b8,uVar5);
          if (cVar2 != '\0') {
            (**(code **)(*plVar1 + 0x350))(plVar1,local_478);
          }
          FUN_140423360(local_478);
          uVar3 = 1;
        }
      }
    }
  }
  return uVar3;
}

// ==== CMsgAura::helper_14041da90  @14041da90  [medium:callgraph-r1]  (orig: FUN_14041da90)
undefined4 FUN_14041da90(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMsgAura::helper_14041daa0  @14041daa0  [medium:callgraph-r1]  (orig: FUN_14041daa0)
undefined4 FUN_14041daa0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CMsgAura::helper_14041dab0  @14041dab0  [medium:callgraph-r1]  (orig: FUN_14041dab0)
undefined4 FUN_14041dab0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x60);
}

// ==== CMsgAura::helper_14041dac0  @14041dac0  [medium:callgraph-r1]  (orig: FUN_14041dac0)
undefined4 FUN_14041dac0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CMsgAura::helper_14041dae0  @14041dae0  [medium:callgraph-r1]  (orig: FUN_14041dae0)
undefined4 FUN_14041dae0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

// ==== CMsgAura::helper_14041db20  @14041db20  [medium:callgraph-r2]  (orig: FUN_14041db20)
undefined8 FUN_14041db20(undefined4 param_1)

{
  switch(param_1) {
  case 1:
    return 1;
  case 2:
    return 2;
  case 3:
    return 3;
  case 4:
    return 4;
  case 5:
    return 5;
  case 6:
    return 6;
  case 7:
    return 7;
  case 8:
    return 8;
  default:
    return 0;
  }
}

// ==== CMsgAura::helper_14041db90  @14041db90  [medium:callgraph-r1]  (orig: FUN_14041db90)
undefined8 FUN_14041db90(int param_1)

{
  if (0 < param_1) {
    if (param_1 < 8) {
      return 1;
    }
    if (param_1 == 8) {
      return 2;
    }
  }
  return 0;
}

// ==== CMsgAura::helper_14041dbd0  @14041dbd0  [medium:callgraph-r2]  (orig: FUN_14041dbd0)
undefined8 FUN_14041dbd0(undefined4 param_1)

{
  switch(param_1) {
  case 1:
    return 0x5d;
  case 2:
    return 0x5f;
  case 3:
    return 0x61;
  case 4:
    return 99;
  case 5:
    return 0x65;
  case 6:
    return 0x67;
  case 7:
    return 0x69;
  case 8:
    return 0x7f;
  default:
    return 0xffffffff;
  }
}

// ==== CMsgAura::helper_14041de90  @14041de90  [medium:callgraph-r2]  (orig: FUN_14041de90)
void FUN_14041de90(longlong param_1)

{
  FUN_14016b120(param_1 + 100);
  return;
}

// ==== CMsgAura::helper_14041df20  @14041df20  [medium:callgraph-r2]  (orig: FUN_14041df20)
undefined1 FUN_14041df20(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0x20,local_28,local_res10);
  return 1;
}

// ==== CMsgAura::ctor_or_dtor  @140423310  [high:vtable-assign]  (orig: FUN_140423310)
undefined8 * FUN_140423310(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAura::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAura::ctor_or_dtor  @140423360  [high:vtable-assign]  (orig: FUN_140423360)
void FUN_140423360(undefined8 *param_1)

{
  *param_1 = CMsgAura::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAura::vfunc_1  @140423390  [high:rtti-vtable]  (orig: FUN_140423390)
ulonglong FUN_140423390(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x96a);
}

// ==== CMsgAura::helper_1404233c0  @1404233c0  [medium:callgraph-r1]  (orig: FUN_1404233c0)
undefined8
FUN_1404233c0(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ulong uVar1;
  undefined4 extraout_var;
  
  FUN_1402b5600();
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_6;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_7;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0x96a;
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  return CONCAT71((int7)(CONCAT44(extraout_var,uVar1) >> 8),1);
}

// ==== CMsgAura::ctor_or_dtor  @140423470  [high:vtable-assign]  (orig: FUN_140423470)
undefined8 * FUN_140423470(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAura::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAura::vfunc_3  @1404234c0  [high:rtti-vtable]  (orig: FUN_1404234c0)
void FUN_1404234c0(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar4,(int)lVar2,*puVar1);
    if (*(short *)(*(longlong *)(param_1 + 0x428) + 4) == 2) {
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar5 = *(longlong *)(lVar5 + 0x140);
      if (lVar5 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
      cVar3 = FUN_14024eeb0(lVar5,uVar4,*(undefined4 *)(lVar2 + 8),*(undefined4 *)(lVar2 + 0xc));
      if (cVar3 == '\0') {
        lVar5 = *(longlong *)(param_1 + 0x428);
        uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar8 = FUN_1400878d0(uVar8);
        FUN_14024ecf0(uVar8,uVar4,*(undefined4 *)(lVar5 + 8),*(undefined4 *)(lVar5 + 0xc));
      }
    }
  }
  return;
}

