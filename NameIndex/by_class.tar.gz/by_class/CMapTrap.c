// ==== CMapTrap::helper_1402f2fb0  @1402f2fb0  [medium:callgraph-r1]  (orig: FUN_1402f2fb0)
undefined1
FUN_1402f2fb0(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
             undefined4 param_5)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_1404bc180(lVar2,param_3,param_4,param_5);
    return uVar1;
  }
  return 0;
}

// ==== CMapTrap::helper_1403a5a30  @1403a5a30  [medium:callgraph-r0]  (orig: FUN_1403a5a30)
undefined8 FUN_1403a5a30(longlong param_1,int param_2,longlong *param_3)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  __time32_t _Var5;
  ulong uVar6;
  char *pcVar7;
  longlong *plVar8;
  tm *ptVar9;
  int local_res18 [4];
  
  if ((param_3 != (longlong *)0x0) && (param_2 != 0)) {
    FUN_1402b5600();
    *(char *)(*(longlong *)(param_1 + 0x428) + 0x12) = (char)param_2;
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar3;
    uVar2 = (**(code **)(param_3[2] + 0x30))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar2;
    uVar2 = (**(code **)(param_3[2] + 0x40))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar2;
    uVar2 = (**(code **)(param_3[2] + 0x48))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = uVar2;
    uVar2 = (**(code **)(param_3[2] + 0x80))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar2;
    uVar3 = (**(code **)(param_3[2] + 0x78))(param_3 + 2);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x13) = uVar3;
    uVar1 = FUN_1403a7410(param_3);
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x17) = uVar1;
    uVar3 = (**(code **)(param_3[2] + 0x170))(param_3 + 2);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = uVar3;
    uVar1 = (**(code **)(*param_3 + 0x38))(param_3);
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x20) = uVar1;
    uVar3 = (**(code **)(*param_3 + 0x40))(param_3);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x21) = uVar3;
    uVar3 = (**(code **)(*param_3 + 0x48))(param_3);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x25) = uVar3;
    pcVar7 = (char *)(**(code **)(param_3[2] + 0x18))(param_3 + 2);
    tq::SafeCopy((char *)(*(longlong *)(param_1 + 0x428) + 0x31),pcVar7,0xf);
    plVar8 = (longlong *)(**(code **)(param_3[2] + 0x2b0))(param_3 + 2);
    if (plVar8 != (longlong *)0x0) {
      uVar3 = (**(code **)(*plVar8 + 8))(plVar8);
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = uVar3;
    }
    iVar4 = FUN_1403a7410(param_3);
    if (iVar4 == 0xc) {
      uVar2 = FUN_1403a73f0(param_3);
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar2;
    }
    iVar4 = FUN_1403a7410(param_3);
    if (iVar4 == 0xd) {
      iVar4 = FUN_1403a83d0(param_3);
      _Var5 = _time32((__time32_t *)0x0);
      local_res18[0] = _Var5 + iVar4 / 1000;
      ptVar9 = _localtime32(local_res18);
      if (ptVar9 == (tm *)0x0) {
        return 0;
      }
      *(longlong *)(*(longlong *)(param_1 + 0x428) + 0x29) =
           ((((((longlong)ptVar9->tm_year * 100 + (longlong)ptVar9->tm_mon) * 1000 +
              (longlong)ptVar9->tm_yday) * 100 + (longlong)ptVar9->tm_mday) * 100 +
            (longlong)ptVar9->tm_hour) * 100 + (longlong)ptVar9->tm_min) * 100 +
           (longlong)ptVar9->tm_sec;
    }
    uVar6 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar6;
    *(undefined4 *)(param_1 + 8) = 0x44d;
    *(undefined4 *)(param_1 + 0xc) = 0x41;
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapTrap::vfunc_6  @1403a6eb0  [high:rtti-vtable]  (orig: FUN_1403a6eb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a6eb0(longlong param_1,longlong *param_2)

{
  int iVar1;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  FUN_1403a5840(local_448);
  iVar1 = FUN_1403a5a30(local_448,0xb,param_1 + -0x18);
  if (iVar1 == 0) {
    local_468 = 300;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_2 + 0x350))(param_2,local_448);
  }
  FUN_1403a5890(local_448);
  return;
}

// ==== CMapTrap::vfunc_105  @1403a6f70  [high:rtti-vtable]  (orig: FUN_1403a6f70)
void FUN_1403a6f70(longlong *param_1,longlong param_2,undefined1 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = (**(code **)(*param_1 + 0x160))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar2 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
  lVar1 = *plVar2;
  uVar3 = (**(code **)(*param_1 + 0x2a0))(param_1);
                    /* WARNING: Could not recover jumptable at 0x0001403a7066. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(lVar1 + 0x30))(plVar2,uVar3,param_2,param_3);
  return;
}

// ==== CMapTrap::vfunc_104  @1403a7070  [high:rtti-vtable]  (orig: FUN_1403a7070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a7070(longlong *param_1,longlong param_2,undefined1 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_2 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x13c);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14015b240(local_488);
    uVar2 = (**(code **)(*param_1 + 0x18))(param_1);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = 0x7d5;
    local_4d0 = 0xff0000;
    local_4d8 = 0;
    iVar1 = FUN_14015b300(local_488,uVar2,"ALLUSERS",param_2);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0x348))(param_1,local_488,param_3);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CMapTrap::vfunc_103  @1403a7170  [high:rtti-vtable]  (orig: FUN_1403a7170)
void FUN_1403a7170(void)

{
  return;
}

// ==== CMapTrap::helper_1403a7180  @1403a7180  [medium:callgraph-r0]  (orig: FUN_1403a7180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403a7180(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (*(char *)(param_1 + 0x74) == '\0') {
    FUN_1403a5840(local_448);
    iVar1 = FUN_1403a5a30(local_448,0xc,param_1);
    if (iVar1 == 0) {
      local_468 = 0x173;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x348))((longlong *)(param_1 + 0x10),local_448,0)
      ;
    }
    *(undefined1 *)(param_1 + 0x74) = 1;
    FUN_1403a5890(local_448);
    uVar2 = 1;
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CMapTrap::vfunc_123  @1403a72d0  [high:rtti-vtable]  (orig: FUN_1403a72d0)
undefined8 FUN_1403a72d0(longlong *param_1,longlong *param_2,char param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  
  if (param_2 != (longlong *)0x0) {
    cVar1 = (**(code **)(*param_1 + 0x220))();
    if (cVar1 == '\0') {
      if (param_3 != '\0') {
        pIVar4 = theInstance();
        lVar6 = *param_1;
        uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_DIE_FORGIVE");
        (**(code **)(lVar6 + 0x358))(param_1,uVar5);
      }
    }
    else {
      cVar1 = (**(code **)(*param_2 + 0x220))(param_2);
      if (cVar1 != '\0') {
        iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
        iVar3 = (**(code **)(*param_2 + 0x10))(param_2);
        if (iVar2 != iVar3) {
          cVar1 = (**(code **)(*param_2 + 0x3e0))(param_2);
          if (cVar1 != '\0') {
            lVar6 = (**(code **)(*param_1 + 0x160))(param_1);
            if (lVar6 != 0) {
              lVar6 = (**(code **)(*param_2 + 0x160))(param_2);
              if (lVar6 != 0) {
                lVar6 = (**(code **)(*param_2 + 0x160))(param_2);
                lVar7 = (**(code **)(*param_1 + 0x160))(param_1);
                if (lVar7 == lVar6) {
                  return 1;
                }
              }
            }
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMapTrap::helper_1403a73f0  @1403a73f0  [medium:callgraph-r1]  (orig: FUN_1403a73f0)
undefined4 FUN_1403a73f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x38);
}

// ==== CMapTrap::helper_1403a7410  @1403a7410  [medium:callgraph-r0]  (orig: FUN_1403a7410)
undefined8 FUN_1403a7410(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0xb0) == 0) {
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001403a742c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),1);
  return uVar1;
}

// ==== CMapTrap::helper_1403a7430  @1403a7430  [medium:callgraph-r3]  (orig: FUN_1403a7430)
undefined8 FUN_1403a7430(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(param_1 + 0xc0);
  *(undefined8 *)(param_1 + 0xc0) = 0;
  return uVar1;
}

// ==== CMapTrap::helper_1403a7460  @1403a7460  [medium:callgraph-r3]  (orig: FUN_1403a7460)
void FUN_1403a7460(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x80) = param_2;
  return;
}

// ==== CMapTrap::vfunc_124  @1403a7470  [high:rtti-vtable]  (orig: FUN_1403a7470)
undefined8 FUN_1403a7470(longlong param_1)

{
  int iVar1;
  
  if (*(longlong *)(param_1 + 0xa0) != 0) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),1);
    if (iVar1 == 0xd) {
      return 1;
    }
  }
  return 0;
}

// ==== CMapTrap::vfunc_75  @1403a74b0  [high:rtti-vtable]  (orig: FUN_1403a74b0)
undefined8 FUN_1403a74b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  
  cVar1 = (**(code **)(*param_1 + 0x3e0))();
  if (cVar1 != '\0') {
    lVar2 = (**(code **)(*param_1 + 0x2b0))(param_1);
    if (lVar2 != 0) {
      lVar2 = (**(code **)(*param_1 + 0x2b0))(param_1);
      cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 600))(lVar2 + 0x10);
      if (cVar1 != '\0') {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMapTrap::vfunc_92  @1403a7510  [high:rtti-vtable]  (orig: FUN_1403a7510)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403a7510(longlong *param_1,uint param_2,longlong param_3,int param_4,uint *param_5)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  ulonglong uVar5;
  uint uVar6;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  uVar1 = param_2;
  if (param_5 != (uint *)0x0) {
    uVar1 = *param_5;
  }
  uVar5 = (ulonglong)uVar1;
  if (param_3 != 0) {
    if (param_2 != 0) {
      return uVar5 & 0xffffffffffffff00;
    }
    uVar5 = (**(code **)(*param_1 + 0x3e0))();
    if ((char)uVar5 == '\0') {
      return uVar5;
    }
    iVar4 = (int)param_3;
    if (iVar4 != -1) {
      iVar4 = -1;
    }
    uVar1 = (**(code **)(*param_1 + 0x80))(param_1);
    iVar2 = (**(code **)(*param_1 + 0x78))(param_1);
    uVar6 = iVar2 + iVar4;
    uVar5 = 0;
    if (((uVar6 == 0) || (uVar6 <= uVar1)) && (uVar1 = 0, uVar6 != 0)) {
      uVar1 = uVar6;
    }
    *(uint *)((longlong)param_1 + 0x34) = uVar1;
  }
  if ((param_4 == 0) || ((uint)uVar5 == 0)) {
    if (param_5 != (uint *)0x0) {
      *param_5 = (uint)uVar5;
    }
    uVar5 = CONCAT71((int7)(uVar5 >> 8),1);
  }
  else {
    FUN_14039e680(local_458);
    uVar3 = (**(code **)(param_1[-2] + 8))();
    iVar4 = FUN_14039e700(local_458,uVar3,0xffffffff,0xffffffffffffffff);
    if (iVar4 == 0) {
      uVar5 = FUN_14039e6d0(local_458);
      uVar5 = uVar5 & 0xffffffffffffff00;
    }
    else {
      uVar5 = FUN_14039e6d0(local_458);
      uVar5 = uVar5 & 0xffffffffffffff00;
    }
  }
  return uVar5;
}

// ==== CMapTrap::vfunc_122  @1403a7650  [high:rtti-vtable]  (orig: FUN_1403a7650)
void FUN_1403a7650(longlong *param_1,longlong param_2)

{
  char cVar1;
  
  if (((param_2 != 0) && (cVar1 = (**(code **)(*param_1 + 0x3e0))(), cVar1 != '\0')) &&
     (*(char *)((longlong)param_1 + 100) == '\0')) {
    FUN_1403a7180(param_1 + -2);
  }
  return;
}

// ==== CMapTrap::helper_1403a7bb0  @1403a7bb0  [medium:callgraph-r0]  (orig: FUN_1403a7bb0)
void FUN_1403a7bb0(void *param_1)

{
  if ((DAT_1409761f0 & 1) == 0) {
    DAT_1409761f0 = DAT_1409761f0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761e8,"CMapTrap");
    atexit((_func_5014 *)&LAB_1406d6bc0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403a7c05. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409761e8,param_1);
  return;
}

// ==== CMapTrap::helper_1403a7c70  @1403a7c70  [medium:callgraph-r0]  (orig: FUN_1403a7c70)
void FUN_1403a7c70(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  
  puVar1 = (undefined8 *)param_1[0x17];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1,param_3,param_4,0xfffffffffffffffe);
    param_1[0x17] = 0;
  }
  if ((longlong *)param_1[0x14] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x14] + 8))();
    param_1[0x14] = 0;
  }
  if (param_1[0x15] != 0) {
    uVar5 = (**(code **)(param_1[2] + 0x2a0))();
    FUN_1402c9300(param_1[0x15],uVar5,0);
  }
  iVar3 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar3 - 0xdbba1U < 89999) {
    uVar5 = FUN_140008520((int)param_1[4]);
    plVar6 = (longlong *)FUN_1400876b0(uVar5);
    lVar2 = *plVar6;
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar2 + 0xe0))(plVar6,uVar4);
  }
  return;
}

// ==== CMapTrap::vfunc_117  @1403a7d50  [high:rtti-vtable]  (orig: FUN_1403a7d50)
int FUN_1403a7d50(longlong *param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  int iVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  ulonglong in_stack_ffffffffffffffa8;
  
  if (param_2 != (longlong *)0x0) {
    plVar11 = (longlong *)0x0;
    plVar12 = (longlong *)0x0;
    cVar1 = (**(code **)(*param_1 + 0x188))();
    if (cVar1 == '\0') {
      plVar10 = plVar11;
      if (param_1 != (longlong *)&DAT_00000010) {
        plVar10 = param_1;
      }
      uVar2 = FUN_1403ec0a0(plVar10,param_2,0,0,in_stack_ffffffffffffffa8 & 0xffffffff00000000,0,0,0
                            ,0);
    }
    else {
      plVar12 = plVar11;
      if (param_1 != (longlong *)&DAT_00000010) {
        plVar12 = param_1;
      }
      lVar7 = FUN_140008520((int)param_1[2]);
      plVar10 = *(longlong **)(lVar7 + 0x100);
      if (*(longlong **)(lVar7 + 0x100) == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar10 = plVar11;
      }
      uVar2 = (**(code **)(*param_1 + 0x98))(param_1);
      uVar2 = FUN_1402f3100(plVar10,plVar12,param_2,uVar2,0);
      plVar12 = plVar11;
      if (param_1[0x14] != 0) {
        if (param_1 != (longlong *)&DAT_00000010) {
          plVar12 = param_1;
        }
        uVar3 = (**(code **)(*(longlong *)param_1[0x14] + 0x10))((longlong *)param_1[0x14],10);
        uVar8 = FUN_140008520((int)param_1[2]);
        uVar8 = FUN_1400877e0(uVar8);
        uVar4 = FUN_1402f12a0(uVar8,plVar12,param_2,uVar3);
        plVar12 = (longlong *)(ulonglong)uVar4;
      }
    }
    if (param_1 != (longlong *)&DAT_00000010) {
      plVar11 = param_1;
    }
    iVar5 = (**(code **)(*param_2 + 0x3b0))(param_2,plVar11,uVar2,1);
    iVar6 = (**(code **)(*param_2 + 0x78))(param_2);
    iVar9 = (int)plVar12 + iVar5;
    if (iVar9 <= iVar6) {
      iVar6 = iVar9;
    }
    if (0 < iVar6) {
      (**(code **)(*param_2 + 0x2e0))(param_2,0,(longlong)-iVar6,1,0);
    }
    return iVar5;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapTrap::vfunc_127  @1403a7f70  [high:rtti-vtable]  (orig: FUN_1403a7f70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a7f70(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  char cVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined1 auStack_518 [32];
  uint local_4f8;
  undefined4 local_4f0;
  undefined4 local_4e8;
  undefined4 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined1 local_4b8;
  undefined4 local_4a8 [2];
  undefined8 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1072];
  ulonglong local_58;
  
  local_498 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_4a8[0] = param_4;
  cVar1 = (**(code **)(*param_1 + 0x188))();
  local_4e8 = param_3;
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*param_1 + 0x260))(param_1);
    if ((cVar1 == '\0') && (cVar1 = (**(code **)(*param_1 + 0x268))(param_1), cVar1 == '\0')) {
      FUN_14035f2f0(local_488);
      uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
      uVar3 = (**(code **)(*param_1 + 0x40))(param_1);
      uVar4 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
      local_4d8 = param_5;
      local_4e0 = 0;
      local_4f0 = CONCAT22(local_4f0._2_2_,uVar2);
      local_4f8 = CONCAT22(local_4f8._2_2_,uVar3);
      iVar8 = FUN_14035f3a0(local_488,2,uVar4,param_2);
      if (iVar8 == 0) {
        local_4f8 = 0x24e;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
      }
      FUN_14035f340(local_488);
    }
    else {
      FUN_14035f2f0(local_488);
      uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
      uVar3 = (**(code **)(*param_1 + 0x40))(param_1);
      uVar4 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
      local_4d8 = param_5;
      local_4e0 = 0;
      local_4f0 = CONCAT22(local_4f0._2_2_,uVar2);
      local_4f8 = CONCAT22(local_4f8._2_2_,uVar3);
      iVar8 = FUN_14035f3a0(local_488,0x1c,uVar4,param_2);
      if (iVar8 == 0) {
        local_4f8 = 0x248;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
      }
      FUN_14035f340(local_488);
    }
  }
  else {
    plVar13 = (longlong *)0x0;
    uVar7 = 0;
    uVar4 = (**(code **)(*(longlong *)param_1[0x14] + 0x10))((longlong *)param_1[0x14],10);
    lVar9 = FUN_140008520((int)param_1[2]);
    plVar10 = *(longlong **)(lVar9 + 0x100);
    if (*(longlong **)(lVar9 + 0x100) == (longlong *)0x0) {
      local_4f8 = 0x144;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = plVar13;
    }
    plVar10 = (longlong *)FUN_1402f0fe0(plVar10,uVar4,0);
    if (plVar10 != (longlong *)0x0) {
      plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,0x26);
      uVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
      lVar9 = FUN_140008520((int)param_1[2]);
      plVar11 = *(longlong **)(lVar9 + 0x100);
      if (*(longlong **)(lVar9 + 0x100) == (longlong *)0x0) {
        local_4f8 = 0x144;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar11 = plVar13;
      }
      cVar1 = FUN_1402ec490(plVar11,uVar5);
      if (cVar1 != '\0') {
        plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,0x27);
        uVar6 = (**(code **)(*plVar10 + 0x48))(plVar10);
        uVar12 = FUN_140008520((int)param_1[2]);
        plVar10 = (longlong *)FUN_1400875f0(uVar12);
        local_4a0 = (**(code **)(*plVar10 + 0x20))(plVar10,param_2);
        if (param_1 != (longlong *)&DAT_00000010) {
          plVar13 = param_1;
        }
        uVar12 = FUN_140008520((int)param_1[2]);
        uVar12 = FUN_1400877e0(uVar12);
        local_4f8 = uVar6;
        uVar7 = FUN_1402ec380(uVar12,plVar13,local_4a0,uVar5);
        uVar12 = FUN_140008520((int)param_1[2]);
        uVar12 = FUN_1400877e0(uVar12);
        FUN_1402ecf10(uVar12,local_4a8,uVar5);
      }
    }
    FUN_140386780(local_488);
    uVar5 = (**(code **)(param_1[-2] + 8))();
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = param_5;
    local_4d8 = local_4a8[0];
    local_4e0 = 0;
    local_4f8 = local_4f8 & 0xffffff00;
    local_4f0 = param_2;
    local_4d0 = uVar7;
    iVar8 = FUN_140386e00(local_488,uVar5,uVar4,0);
    if (iVar8 == 0) {
      local_4f8 = 0x240;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
    }
    FUN_1403867d0(local_488);
  }
  return;
}

// ==== CMapTrap::helper_1403a83d0  @1403a83d0  [medium:callgraph-r1]  (orig: FUN_1403a83d0)
int FUN_1403a83d0(longlong param_1)

{
  ulong uVar1;
  int iVar2;
  int iVar3;
  
  if ((*(int *)(param_1 + 0x70) != 0) && (0 < *(int *)(param_1 + 0x70))) {
    iVar3 = *(int *)(param_1 + 0x6c);
    uVar1 = tq::TimeGet(0);
    if (*(uint *)(param_1 + 0x70) < uVar1) {
      uVar1 = tq::TimeGet(0);
      iVar3 = iVar3 + (*(int *)(param_1 + 0x70) - uVar1);
    }
    iVar2 = 0;
    if (0 < iVar3) {
      iVar2 = iVar3;
    }
    return iVar2;
  }
  return 0;
}

// ==== CMapTrap::helper_1403a8430  @1403a8430  [medium:callgraph-r3]  (orig: FUN_1403a8430)
void FUN_1403a8430(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(0);
  *(ulong *)(param_1 + 0x70) = uVar1;
  return;
}

// ==== CMapTrap::vfunc_1  @1403a86a0  [high:rtti-vtable]  (orig: FUN_1403a86a0)
void FUN_1403a86a0(longlong param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(param_1 + -0x10);
  FUN_1403a7c70(puVar1);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CMapTrap::vfunc_121  @1403a8950  [high:rtti-vtable]  (orig: FUN_1403a8950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a8950(longlong param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined1 auStack_4f8 [32];
  uint local_4d8;
  undefined2 local_4d0;
  uint local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined8 local_4a8 [2];
  undefined4 local_498;
  longlong local_490;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_498 = param_3;
  local_490 = param_1;
  local_488 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_4d8 = 0x256;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_1 + 0x78) == 0) {
    FUN_14035f2f0(local_478);
    plVar8 = (longlong *)(param_1 + -0x10);
    uVar2 = (**(code **)(*param_2 + 0x48))(param_2);
    uVar3 = (**(code **)(*param_2 + 0x40))(param_2);
    uVar4 = (**(code **)(*param_2 + 0x10))(param_2);
    uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
    local_4b8 = 0;
    local_4c0 = 0;
    local_4d8 = CONCAT22(local_4d8._2_2_,uVar3);
    local_4d0 = uVar2;
    local_4c8 = param_3;
    iVar6 = FUN_14035f3a0(local_478,0xe,uVar5,uVar4);
    if (iVar6 == 0) {
      local_4d8 = 0x26f;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_2 + 0x348))(param_2,local_478,1);
    }
    local_4a8[0] = 0;
    cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1001,local_4a8);
    if (cVar1 == '\0') {
      lVar7 = 0;
      if (plVar8 != (longlong *)0x0) {
        lVar7 = param_1;
      }
      (**(code **)(*param_2 + 0x3d0))(param_2,lVar7,1);
    }
    else {
      lVar7 = 0;
      if (plVar8 != (longlong *)0x0) {
        lVar7 = param_1;
      }
      FUN_1401cc6c0(local_4a8[0],lVar7,1);
    }
    FUN_14035f340(local_478);
  }
  else {
    if (*(longlong *)(param_1 + 0x78) == 0) {
      local_4d8 = 0x22;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    cVar1 = FUN_14016e3f0(*(undefined8 *)(param_1 + 0x78));
    if ((((cVar1 != '\0') && (lVar7 = (**(code **)(*param_2 + 0x2b0))(param_2), lVar7 != 0)) &&
        ((longlong *)(lVar7 + 0x10) == param_2)) && (lVar7 = FUN_14016e430(lVar7), lVar7 != 0)) {
      if (*(longlong *)(param_1 + 0x78) == 0) {
        local_4d8 = 0x22;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar8 = (longlong *)(*(longlong *)(param_1 + 0x78) + 0x10);
      local_4c0 = 14000000;
      local_4c8 = local_4c8 & 0xffff0000;
      local_4d0 = 0;
      local_4d8 = local_4d8 & 0xffffff00;
      (**(code **)(*plVar8 + 0x3c8))(plVar8,lVar7 + 0x10,param_3,0);
    }
    if (*(longlong *)(param_1 + 0x78) == 0) {
      local_4d8 = 0x22;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar8 = (longlong *)(*(longlong *)(param_1 + 0x78) + 0x10);
    local_4c0 = 15000000;
    local_4c8 = local_4c8 & 0xffff0000;
    local_4d0 = 0;
    local_4d8 = local_4d8 & 0xffffff00;
    (**(code **)(*plVar8 + 0x3c8))(plVar8,param_2,param_3,0);
  }
  return;
}

// ==== CMapTrap::helper_1403a8c90  @1403a8c90  [medium:callgraph-r1]  (orig: FUN_1403a8c90)
void FUN_1403a8c90(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  if (*(longlong *)(param_1 + 0x88) != 0) {
    if (*(longlong *)(param_1 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    cVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x88) + 0x10) + 0x220))
                      (*(longlong *)(param_1 + 0x88) + 0x10);
    if (cVar2 != '\0') {
      if (*(longlong *)(param_1 + 0x88) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar1 = *(longlong *)(param_1 + 0x88);
      iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
      iVar4 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
      if (iVar4 == iVar3) {
        plVar6 = (longlong *)FUN_14038c750(param_1 + 0x88);
        uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
        uVar7 = FUN_1400877e0(uVar7);
        FUN_1402f2fb0(uVar7,uVar5,0x2d50,param_1,0);
        return;
      }
    }
  }
  FUN_1403a7180(param_1);
  return;
}

// ==== CMapTrap::helper_1403a8de0  @1403a8de0  [medium:callgraph-r0]  (orig: FUN_1403a8de0)
void FUN_1403a8de0(longlong param_1,char param_2)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  if (*(longlong *)(param_1 + 0x88) != 0) {
    if (*(longlong *)(param_1 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    cVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x88) + 0x10) + 0x220))
                      (*(longlong *)(param_1 + 0x88) + 0x10);
    if (cVar2 != '\0') {
      if (*(longlong *)(param_1 + 0x88) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar1 = *(longlong *)(param_1 + 0x88);
      iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
      iVar4 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
      if (iVar4 == iVar3) {
        iVar3 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))
                          (*(longlong **)(param_1 + 0xb0),10);
        if (iVar3 == 0) {
          return;
        }
        plVar6 = (longlong *)FUN_14038c750(param_1 + 0x88);
        uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
        uVar7 = FUN_1400877e0(uVar7);
        FUN_1402f2fb0(uVar7,uVar5,iVar3,param_1,param_2 != '\0');
        return;
      }
    }
  }
  FUN_1403a7180(param_1);
  return;
}

// ==== CMapTrap::ctor_or_dtor  @1403a91f0  [high:vtable-assign]  (orig: FUN_1403a91f0)
undefined8 * FUN_1403a91f0(undefined8 *param_1)

{
  FUN_1402b5540();
  param_1[2] = IRole::vftable;
  param_1[3] = IMapThing::vftable;
  *param_1 = CMapTrap::vftable;
  param_1[2] = CMapTrap::vftable;
  param_1[3] = CMapTrap::vftable;
  memset((void *)((longlong)param_1 + 0x24),0,0x48);
  *(undefined4 *)((longlong)param_1 + 0x6c) = 0;
  *(undefined4 *)(param_1 + 0xe) = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  *(undefined4 *)(param_1 + 1) = 0x1400;
  memset((void *)((longlong)param_1 + 0x24),0,0x48);
  *(undefined1 *)((longlong)param_1 + 0x74) = 0;
  *(undefined4 *)(param_1 + 0xf) = 0;
  param_1[0x15] = 0;
  param_1[0x14] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  *(undefined4 *)((longlong)param_1 + 0x7c) = 0;
  param_1[0x18] = 0;
  *(undefined1 *)(param_1 + 0x10) = 1;
  return param_1;
}

// ==== CMapTrap::vfunc_4  @1403a92e0  [high:rtti-vtable]  (orig: FUN_1403a92e0)
void FUN_1403a92e0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(plVar1);
  uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar4 = (**(code **)(*plVar1 + 0x160))(plVar1);
  FUN_1402c84c0(uVar4,uVar3,uVar2,param_2,param_3,param_4);
  return;
}

// ==== CMapTrap::vfunc_1  @1403a9360  [high:rtti-vtable]  (orig: FUN_1403a9360)
undefined4 FUN_1403a9360(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x24);
}

// ==== CMapTrap::vfunc_2  @1403a9370  [high:rtti-vtable]  (orig: FUN_1403a9370)
undefined4 FUN_1403a9370(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMapTrap::vfunc_8  @1403a9380  [high:rtti-vtable]  (orig: FUN_1403a9380)
undefined2 FUN_1403a9380(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x24);
}

// ==== CMapTrap::vfunc_9  @1403a9390  [high:rtti-vtable]  (orig: FUN_1403a9390)
undefined2 FUN_1403a9390(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x26);
}

// ==== CMapTrap::vfunc_5  @1403a93a0  [high:rtti-vtable]  (orig: FUN_1403a93a0)
undefined4 FUN_1403a93a0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x2c);
}

// ==== CMapTrap::vfunc_6  @1403a93b0  [high:rtti-vtable]  (orig: FUN_1403a93b0)
undefined4 FUN_1403a93b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x48);
}

// ==== CMapTrap::vfunc_46  @1403a93c0  [high:rtti-vtable]  (orig: FUN_1403a93c0)
undefined4 FUN_1403a93c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x3c);
}

// ==== CMapTrap::vfunc_7  @1403a93d0  [high:rtti-vtable]  (orig: FUN_1403a93d0)
undefined1 FUN_1403a93d0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x58);
}

// ==== CMapTrap::vfunc_8  @1403a93e0  [high:rtti-vtable]  (orig: FUN_1403a93e0)
undefined4 FUN_1403a93e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x50);
}

// ==== CMapTrap::vfunc_9  @1403a93f0  [high:rtti-vtable]  (orig: FUN_1403a93f0)
undefined4 FUN_1403a93f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x54);
}

// ==== CMapTrap::vfunc_3  @1403a9400  [high:rtti-vtable]  (orig: FUN_1403a9400)
longlong FUN_1403a9400(longlong param_1)

{
  return param_1 + 0x49;
}

// ==== CMapTrap::vfunc_4  @1403a9410  [high:rtti-vtable]  (orig: FUN_1403a9410)
undefined8 FUN_1403a9410(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_5  @1403a9420  [high:rtti-vtable]  (orig: FUN_1403a9420)
undefined8 FUN_1403a9420(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_6  @1403a9430  [high:rtti-vtable]  (orig: FUN_1403a9430)
undefined2 FUN_1403a9430(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x1a);
}

// ==== CMapTrap::vfunc_7  @1403a9440  [high:rtti-vtable]  (orig: FUN_1403a9440)
undefined8 FUN_1403a9440(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_10  @1403a9450  [high:rtti-vtable]  (orig: FUN_1403a9450)
uint FUN_1403a9450(longlong *param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x30))();
  return uVar1 & 7;
}

// ==== CMapTrap::vfunc_12  @1403a9470  [high:rtti-vtable]  (orig: FUN_1403a9470)
undefined8 FUN_1403a9470(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_13  @1403a9480  [high:rtti-vtable]  (orig: FUN_1403a9480)
undefined8 FUN_1403a9480(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_14  @1403a9490  [high:rtti-vtable]  (orig: FUN_1403a9490)
void FUN_1403a9490(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a949f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),4);
  return;
}

// ==== CMapTrap::vfunc_15  @1403a94b0  [high:rtti-vtable]  (orig: FUN_1403a94b0)
undefined4 FUN_1403a94b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CMapTrap::vfunc_16  @1403a94c0  [high:rtti-vtable]  (orig: FUN_1403a94c0)
undefined4 FUN_1403a94c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x30);
}

// ==== CMapTrap::vfunc_17  @1403a94d0  [high:rtti-vtable]  (orig: FUN_1403a94d0)
void FUN_1403a94d0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a94df. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),6);
  return;
}

// ==== CMapTrap::vfunc_18  @1403a94f0  [high:rtti-vtable]  (orig: FUN_1403a94f0)
void FUN_1403a94f0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a94ff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),5);
  return;
}

// ==== CMapTrap::vfunc_19  @1403a9510  [high:rtti-vtable]  (orig: FUN_1403a9510)
int FUN_1403a9510(longlong *param_1)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(*param_1 + 0x90))();
  iVar2 = (**(code **)(*param_1 + 0x88))(param_1);
  iVar1 = tq::RandGet(iVar1 - iVar2);
  iVar2 = (**(code **)(*param_1 + 0x88))(param_1);
  return iVar2 + iVar1;
}

// ==== CMapTrap::vfunc_20  @1403a9560  [high:rtti-vtable]  (orig: FUN_1403a9560)
undefined8 FUN_1403a9560(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_21  @1403a9570  [high:rtti-vtable]  (orig: FUN_1403a9570)
undefined8 FUN_1403a9570(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_22  @1403a9580  [high:rtti-vtable]  (orig: FUN_1403a9580)
undefined8 FUN_1403a9580(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_23  @1403a9590  [high:rtti-vtable]  (orig: FUN_1403a9590)
undefined8 FUN_1403a9590(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_24  @1403a95a0  [high:rtti-vtable]  (orig: FUN_1403a95a0)
void FUN_1403a95a0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a95af. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),7);
  return;
}

// ==== CMapTrap::vfunc_25  @1403a95c0  [high:rtti-vtable]  (orig: FUN_1403a95c0)
void FUN_1403a95c0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a95cf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),7);
  return;
}

// ==== CMapTrap::vfunc_26  @1403a95e0  [high:rtti-vtable]  (orig: FUN_1403a95e0)
undefined8 FUN_1403a95e0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_27  @1403a95f0  [high:rtti-vtable]  (orig: FUN_1403a95f0)
undefined8 FUN_1403a95f0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_28  @1403a9600  [high:rtti-vtable]  (orig: FUN_1403a9600)
undefined8 FUN_1403a9600(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_29  @1403a9610  [high:rtti-vtable]  (orig: FUN_1403a9610)
void FUN_1403a9610(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a961f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),8);
  return;
}

// ==== CMapTrap::vfunc_30  @1403a9630  [high:rtti-vtable]  (orig: FUN_1403a9630)
void FUN_1403a9630(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a963f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),8);
  return;
}

// ==== CMapTrap::vfunc_31  @1403a9650  [high:rtti-vtable]  (orig: FUN_1403a9650)
undefined8 FUN_1403a9650(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_32  @1403a9660  [high:rtti-vtable]  (orig: FUN_1403a9660)
undefined8 FUN_1403a9660(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_33  @1403a9670  [high:rtti-vtable]  (orig: FUN_1403a9670)
undefined8 FUN_1403a9670(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_34  @1403a9680  [high:rtti-vtable]  (orig: FUN_1403a9680)
undefined8 FUN_1403a9680(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_35  @1403a9690  [high:rtti-vtable]  (orig: FUN_1403a9690)
undefined8 FUN_1403a9690(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_36  @1403a96a0  [high:rtti-vtable]  (orig: FUN_1403a96a0)
undefined8 FUN_1403a96a0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_37  @1403a96b0  [high:rtti-vtable]  (orig: FUN_1403a96b0)
undefined8 FUN_1403a96b0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_38  @1403a96c0  [high:rtti-vtable]  (orig: FUN_1403a96c0)
undefined8 FUN_1403a96c0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_39  @1403a96d0  [high:rtti-vtable]  (orig: FUN_1403a96d0)
undefined8 FUN_1403a96d0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_40  @1403a96e0  [high:rtti-vtable]  (orig: FUN_1403a96e0)
undefined8 FUN_1403a96e0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_41  @1403a96f0  [high:rtti-vtable]  (orig: FUN_1403a96f0)
undefined8 FUN_1403a96f0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_43  @1403a9700  [high:rtti-vtable]  (orig: FUN_1403a9700)
int FUN_1403a9700(longlong *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = (**(code **)(*param_1 + 0x40))();
  uVar3 = iVar1 - param_2 >> 0x1f;
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar4 = iVar2 - param_3 >> 0x1f;
  if ((int)((iVar2 - param_3 ^ uVar4) - uVar4) < (int)((iVar1 - param_2 ^ uVar3) - uVar3)) {
    iVar1 = (**(code **)(*param_1 + 0x40))();
    uVar3 = iVar1 - param_2;
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    uVar3 = iVar1 - param_3;
  }
  return (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f);
}

// ==== CMapTrap::vfunc_42  @1403a9770  [high:rtti-vtable]  (orig: FUN_1403a9770)
int FUN_1403a9770(longlong *param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar5 = iVar2 - iVar1 >> 0x1f;
  iVar3 = (**(code **)(*param_2 + 0x20))(param_2);
  iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar6 = iVar4 - iVar3 >> 0x1f;
  if ((int)((iVar2 - iVar1 ^ uVar5) - uVar5) < (int)((iVar4 - iVar3 ^ uVar6) - uVar6)) {
    iVar1 = (**(code **)(*param_2 + 0x20))();
    iVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  }
  else {
    iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
    iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  }
  uVar5 = iVar2 - iVar1 >> 0x1f;
  return (iVar2 - iVar1 ^ uVar5) - uVar5;
}

// ==== CMapTrap::vfunc_44  @1403a9810  [high:rtti-vtable]  (orig: FUN_1403a9810)
longlong FUN_1403a9810(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x98);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapTrap::vfunc_45  @1403a9860  [high:rtti-vtable]  (orig: FUN_1403a9860)
undefined8 FUN_1403a9860(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x98) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403a9874. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x98) + 8))();
    return uVar1;
  }
  return 0;
}

// ==== CMapTrap::vfunc_51  @1403a9880  [high:rtti-vtable]  (orig: FUN_1403a9880)
undefined8 FUN_1403a9880(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_52  @1403a9890  [high:rtti-vtable]  (orig: FUN_1403a9890)
undefined8 FUN_1403a9890(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_53  @1403a98a0  [high:rtti-vtable]  (orig: FUN_1403a98a0)
undefined8 FUN_1403a98a0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_47  @1403a98b0  [high:rtti-vtable]  (orig: FUN_1403a98b0)
undefined8 FUN_1403a98b0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_48  @1403a98c0  [high:rtti-vtable]  (orig: FUN_1403a98c0)
undefined1 FUN_1403a98c0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_49  @1403a98d0  [high:rtti-vtable]  (orig: FUN_1403a98d0)
bool FUN_1403a98d0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),10);
  return iVar1 != 0;
}

// ==== CMapTrap::vfunc_50  @1403a98f0  [high:rtti-vtable]  (orig: FUN_1403a98f0)
void FUN_1403a98f0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403a98ff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0xa0) + 0x10))(*(longlong **)(param_1 + 0xa0),0xb);
  return;
}

// ==== CMapTrap::vfunc_54  @1403a9910  [high:rtti-vtable]  (orig: FUN_1403a9910)
undefined8 FUN_1403a9910(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_55  @1403a9920  [high:rtti-vtable]  (orig: FUN_1403a9920)
undefined8 FUN_1403a9920(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_56  @1403a9930  [high:rtti-vtable]  (orig: FUN_1403a9930)
undefined8 FUN_1403a9930(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_57  @1403a9940  [high:rtti-vtable]  (orig: FUN_1403a9940)
undefined1 FUN_1403a9940(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_58  @1403a9950  [high:rtti-vtable]  (orig: FUN_1403a9950)
undefined1 FUN_1403a9950(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_59  @1403a9960  [high:rtti-vtable]  (orig: FUN_1403a9960)
undefined8 FUN_1403a9960(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_80  @1403a9970  [high:rtti-vtable]  (orig: FUN_1403a9970)
undefined1 FUN_1403a9970(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_60  @1403a9980  [high:rtti-vtable]  (orig: FUN_1403a9980)
undefined8 FUN_1403a9980(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_61  @1403a9990  [high:rtti-vtable]  (orig: FUN_1403a9990)
undefined8 FUN_1403a9990(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_62  @1403a99a0  [high:rtti-vtable]  (orig: FUN_1403a99a0)
undefined8 FUN_1403a99a0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_63  @1403a99b0  [high:rtti-vtable]  (orig: FUN_1403a99b0)
undefined8 FUN_1403a99b0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_64  @1403a99c0  [high:rtti-vtable]  (orig: FUN_1403a99c0)
undefined8 FUN_1403a99c0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_65  @1403a99d0  [high:rtti-vtable]  (orig: FUN_1403a99d0)
undefined8 FUN_1403a99d0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_66  @1403a99e0  [high:rtti-vtable]  (orig: FUN_1403a99e0)
undefined8 FUN_1403a99e0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_67  @1403a99f0  [high:rtti-vtable]  (orig: FUN_1403a99f0)
undefined8 FUN_1403a99f0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_68  @1403a9a00  [high:rtti-vtable]  (orig: FUN_1403a9a00)
bool FUN_1403a9a00(longlong param_1)

{
  return *(char *)(param_1 + 100) == '\0';
}

// ==== CMapTrap::vfunc_69  @1403a9a10  [high:rtti-vtable]  (orig: FUN_1403a9a10)
undefined1 FUN_1403a9a10(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_70  @1403a9a20  [high:rtti-vtable]  (orig: FUN_1403a9a20)
undefined1 FUN_1403a9a20(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_71  @1403a9a30  [high:rtti-vtable]  (orig: FUN_1403a9a30)
undefined1 FUN_1403a9a30(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_72  @1403a9a40  [high:rtti-vtable]  (orig: FUN_1403a9a40)
undefined1 FUN_1403a9a40(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_73  @1403a9a50  [high:rtti-vtable]  (orig: FUN_1403a9a50)
undefined1 FUN_1403a9a50(longlong param_1)

{
  return *(undefined1 *)(param_1 + 100);
}

// ==== CMapTrap::vfunc_74  @1403a9a60  [high:rtti-vtable]  (orig: FUN_1403a9a60)
undefined1 FUN_1403a9a60(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_76  @1403a9a70  [high:rtti-vtable]  (orig: FUN_1403a9a70)
undefined1 FUN_1403a9a70(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_77  @1403a9a80  [high:rtti-vtable]  (orig: FUN_1403a9a80)
undefined1 FUN_1403a9a80(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_78  @1403a9a90  [high:rtti-vtable]  (orig: FUN_1403a9a90)
undefined1 FUN_1403a9a90(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_79  @1403a9aa0  [high:rtti-vtable]  (orig: FUN_1403a9aa0)
undefined1 FUN_1403a9aa0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_81  @1403a9ab0  [high:rtti-vtable]  (orig: FUN_1403a9ab0)
undefined1 FUN_1403a9ab0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_82  @1403a9ac0  [high:rtti-vtable]  (orig: FUN_1403a9ac0)
undefined1 FUN_1403a9ac0(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_83  @1403a9ad0  [high:rtti-vtable]  (orig: FUN_1403a9ad0)
ulonglong FUN_1403a9ad0(longlong param_1,int param_2,longlong *param_3)

{
  ulonglong in_RAX;
  
  if (param_2 == 0x1400) {
    *param_3 = param_1 + -0x10;
    return CONCAT71((int7)((ulonglong)(param_1 + -0x10) >> 8),1);
  }
  *param_3 = 0;
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapTrap::vfunc_84  @1403a9af0  [high:rtti-vtable]  (orig: FUN_1403a9af0)
longlong FUN_1403a9af0(longlong param_1)

{
  if (param_1 != 0x10) {
    return param_1 + 8;
  }
  return 0;
}

// ==== CMapTrap::vfunc_85  @1403a9b10  [high:rtti-vtable]  (orig: FUN_1403a9b10)
void FUN_1403a9b10(longlong *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = (**(code **)(*param_1 + 0x48))();
  uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar3 = (**(code **)(*param_1 + 0x160))(param_1);
  FUN_1402c8700(uVar3,uVar2,uVar1,param_2);
  return;
}

// ==== CMapTrap::vfunc_8  @1403a9b70  [high:rtti-vtable]  (orig: FUN_1403a9b70)
undefined8 FUN_1403a9b70(longlong param_1,longlong *param_2)

{
  if (param_1 != 0x18) {
    *param_2 = param_1 + -8;
    return CONCAT71((int7)((ulonglong)(param_1 + -8) >> 8),1);
  }
  *param_2 = 0;
  return 1;
}

// ==== CMapTrap::vfunc_87  @1403a9b90  [high:rtti-vtable]  (orig: FUN_1403a9b90)
void FUN_1403a9b90(void)

{
  return;
}

// ==== CMapTrap::vfunc_88  @1403a9ba0  [high:rtti-vtable]  (orig: FUN_1403a9ba0)
void FUN_1403a9ba0(void)

{
  return;
}

// ==== CMapTrap::vfunc_89  @1403a9bb0  [high:rtti-vtable]  (orig: FUN_1403a9bb0)
void FUN_1403a9bb0(void)

{
  return;
}

// ==== CMapTrap::vfunc_90  @1403a9bc0  [high:rtti-vtable]  (orig: FUN_1403a9bc0)
void FUN_1403a9bc0(void)

{
  return;
}

// ==== CMapTrap::vfunc_93  @1403a9bd0  [high:rtti-vtable]  (orig: FUN_1403a9bd0)
void FUN_1403a9bd0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMapTrap::vfunc_91  @1403a9c10  [high:rtti-vtable]  (orig: FUN_1403a9c10)
undefined1 FUN_1403a9c10(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_95  @1403a9c20  [high:rtti-vtable]  (orig: FUN_1403a9c20)
undefined8 FUN_1403a9c20(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_96  @1403a9c30  [high:rtti-vtable]  (orig: FUN_1403a9c30)
undefined4 FUN_1403a9c30(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CMapTrap::vfunc_10  @1403a9c40  [high:rtti-vtable]  (orig: FUN_1403a9c40)
undefined4 FUN_1403a9c40(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CMapTrap::vfunc_97  @1403a9c50  [high:rtti-vtable]  (orig: FUN_1403a9c50)
undefined4 FUN_1403a9c50(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CMapTrap::vfunc_98  @1403a9c60  [high:rtti-vtable]  (orig: FUN_1403a9c60)
undefined4 FUN_1403a9c60(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CMapTrap::vfunc_99  @1403a9c70  [high:rtti-vtable]  (orig: FUN_1403a9c70)
undefined4 FUN_1403a9c70(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CMapTrap::vfunc_100  @1403a9c80  [high:rtti-vtable]  (orig: FUN_1403a9c80)
undefined4 FUN_1403a9c80(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  return param_3;
}

// ==== CMapTrap::vfunc_101  @1403a9c90  [high:rtti-vtable]  (orig: FUN_1403a9c90)
undefined4 FUN_1403a9c90(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  return param_3;
}

// ==== CMapTrap::vfunc_102  @1403a9ca0  [high:rtti-vtable]  (orig: FUN_1403a9ca0)
void FUN_1403a9ca0(void)

{
  return;
}

// ==== CMapTrap::vfunc_106  @1403a9cb0  [high:rtti-vtable]  (orig: FUN_1403a9cb0)
undefined1 FUN_1403a9cb0(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_107  @1403a9cc0  [high:rtti-vtable]  (orig: FUN_1403a9cc0)
undefined1 FUN_1403a9cc0(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_109  @1403a9cd0  [high:rtti-vtable]  (orig: FUN_1403a9cd0)
undefined1 FUN_1403a9cd0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_110  @1403a9ce0  [high:rtti-vtable]  (orig: FUN_1403a9ce0)
void FUN_1403a9ce0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMapTrap::vfunc_111  @1403a9d20  [high:rtti-vtable]  (orig: FUN_1403a9d20)
void FUN_1403a9d20(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMapTrap::vfunc_94  @1403a9d60  [high:rtti-vtable]  (orig: FUN_1403a9d60)
void FUN_1403a9d60(longlong *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x40))();
  *param_2 = uVar1;
  uVar1 = (**(code **)(*param_1 + 0x48))(param_1);
  *param_3 = uVar1;
  return;
}

// ==== CMapTrap::vfunc_112  @1403a9da0  [high:rtti-vtable]  (orig: FUN_1403a9da0)
void FUN_1403a9da0(void)

{
  return;
}

// ==== CMapTrap::vfunc_113  @1403a9db0  [high:rtti-vtable]  (orig: FUN_1403a9db0)
undefined1 FUN_1403a9db0(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_114  @1403a9dc0  [high:rtti-vtable]  (orig: FUN_1403a9dc0)
undefined1 FUN_1403a9dc0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_115  @1403a9dd0  [high:rtti-vtable]  (orig: FUN_1403a9dd0)
undefined1 FUN_1403a9dd0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_116  @1403a9de0  [high:rtti-vtable]  (orig: FUN_1403a9de0)
undefined1 FUN_1403a9de0(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_118  @1403a9df0  [high:rtti-vtable]  (orig: FUN_1403a9df0)
undefined8 FUN_1403a9df0(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_119  @1403a9e00  [high:rtti-vtable]  (orig: FUN_1403a9e00)
undefined8 FUN_1403a9e00(void)

{
  return 1;
}

// ==== CMapTrap::vfunc_120  @1403a9e10  [high:rtti-vtable]  (orig: FUN_1403a9e10)
undefined1 FUN_1403a9e10(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapTrap::vfunc_125  @1403a9e50  [high:rtti-vtable]  (orig: FUN_1403a9e50)
undefined8 FUN_1403a9e50(void)

{
  return 999;
}

// ==== CMapTrap::vfunc_126  @1403a9e60  [high:rtti-vtable]  (orig: FUN_1403a9e60)
undefined8 FUN_1403a9e60(void)

{
  return 0;
}

// ==== CMapTrap::vfunc_2  @1403a9e70  [high:rtti-vtable]  (orig: FUN_1403a9e70)
void FUN_1403a9e70(longlong param_1)

{
  FUN_1403a9360(param_1 + -0x10);
  return;
}

// ==== CMapTrap::vfunc_0  @1403a9e80  [high:rtti-vtable]  (orig: FUN_1403a9e80)
void FUN_1403a9e80(longlong param_1)

{
  FUN_1403aa5e0(param_1 + -0x10);
  return;
}

// ==== CMapTrap::vfunc_4  @1403a9e90  [high:rtti-vtable]  (orig: FUN_1403a9e90)
void FUN_1403a9e90(longlong param_1)

{
  FUN_1403a9380(param_1 + -8);
  return;
}

// ==== CMapTrap::vfunc_2  @1403a9ea0  [high:rtti-vtable]  (orig: FUN_1403a9ea0)
void FUN_1403a9ea0(longlong param_1)

{
  FUN_1403a9360(param_1 + -0x18);
  return;
}

// ==== CMapTrap::vfunc_0  @1403a9eb0  [high:rtti-vtable]  (orig: FUN_1403a9eb0)
void FUN_1403a9eb0(longlong param_1)

{
  FUN_1403aa5e0(param_1 + -0x18);
  return;
}

// ==== CMapTrap::vfunc_7  @1403a9ec0  [high:rtti-vtable]  (orig: FUN_1403a9ec0)
void FUN_1403a9ec0(longlong param_1)

{
  FUN_1403a9ad0(param_1 + -8);
  return;
}

// ==== CMapTrap::vfunc_3  @1403a9ed0  [high:rtti-vtable]  (orig: FUN_1403a9ed0)
void FUN_1403a9ed0(longlong param_1)

{
  FUN_1403a9370(param_1 + -0x18);
  return;
}

// ==== CMapTrap::vfunc_5  @1403a9ee0  [high:rtti-vtable]  (orig: FUN_1403a9ee0)
void FUN_1403a9ee0(longlong param_1)

{
  FUN_1403a9390(param_1 + -8);
  return;
}

// ==== CMapTrap::vfunc_86  @1403a9ef0  [high:rtti-vtable]  (orig: FUN_1403a9ef0)
undefined8 FUN_1403a9ef0(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x78);
}

// ==== CMapTrap::vfunc_1  @1403a9f00  [high:rtti-vtable]  (orig: FUN_1403a9f00)
void FUN_1403a9f00(longlong param_1)

{
  FUN_1403a86a0(param_1 + -8);
  return;
}

// ==== CMapTrap::ctor_or_dtor  @1403a9f10  [high:vtable-assign]  (orig: FUN_1403a9f10)
void FUN_1403a9f10(undefined8 *param_1)

{
  *param_1 = CMapTrap::vftable;
  param_1[2] = CMapTrap::vftable;
  param_1[3] = CMapTrap::vftable;
  FUN_140097920(param_1 + 0x11);
  param_1[3] = IMapThing::vftable;
  param_1[2] = IRole::vftable;
  FUN_1402b55a0(param_1);
  return;
}

// ==== CMapTrap::helper_1403a9f80  @1403a9f80  [medium:callgraph-r1]  (orig: FUN_1403a9f80)
/* WARNING: Removing unreachable block (ram,0x0001403aa28a) */
/* WARNING: Removing unreachable block (ram,0x0001403aa2a4) */

void FUN_1403a9f80(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined8 uVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  longlong *local_res18;
  undefined1 local_res20 [8];
  
  iVar2 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),0xc);
  lVar8 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x160))(param_1 + 0x10);
  iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x40))(param_1 + 0x10);
  if (iVar3 / 0x12 + -1 < 1) {
    iVar3 = 0;
  }
  else {
    iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x40))(param_1 + 0x10);
    iVar3 = iVar3 / 0x12 + -1;
  }
  iVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x40))(param_1 + 0x10);
  if (iVar3 <= iVar4 / 0x12 + 1) {
    do {
      iVar4 = (**(code **)(**(longlong **)(lVar8 + 0x60) + 0x28))();
      if ((iVar4 + -1) / 0x12 + 1 <= iVar3) {
        return;
      }
      iVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
      if (iVar4 / 0x12 + -1 < 1) {
        iVar4 = 0;
      }
      else {
        iVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
        iVar4 = iVar4 / 0x12 + -1;
      }
      iVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
      if (iVar4 <= iVar5 / 0x12 + 1) {
        do {
          iVar5 = (**(code **)(**(longlong **)(lVar8 + 0x60) + 0x20))();
          if ((iVar5 + -1) / 0x12 + 1 <= iVar4) break;
          uVar13 = 0;
          lVar9 = FUN_14017eea0(lVar8,iVar3,iVar4);
          lVar9 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))();
          if (lVar9 != 0) {
            do {
              lVar9 = FUN_14017eea0(lVar8,iVar3,iVar4);
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(lVar9 + 8) + 0x18))
                                  (*(longlong **)(lVar9 + 8),uVar13);
              local_res18 = (longlong *)0x0;
              if (((((plVar10 != (longlong *)0x0) &&
                    (iVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x150))
                                       (param_1 + 0x10,plVar10), iVar5 < iVar2 / 2)) &&
                   (cVar1 = (**(code **)(*plVar10 + 0x40))(plVar10,&local_res18), cVar1 != '\0')) &&
                  ((cVar1 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1400,local_res20),
                   cVar1 == '\0' &&
                   (cVar1 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1040,local_res20),
                   cVar1 == '\0')))) &&
                 (cVar1 = (**(code **)(*local_res18 + 0x3e0))(), cVar1 != '\0')) {
                if (*(longlong *)(param_1 + 0x88) != 0) {
                  if (*(longlong *)(param_1 + 0x88) == 0) {
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  cVar1 = FUN_140186200(*(undefined8 *)(param_1 + 0x88),local_res18);
                  if (cVar1 != '\0') goto LAB_1403aa35a;
                }
                iVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
                iVar6 = (**(code **)(*plVar10 + 0x28))(plVar10);
                if (iVar6 == iVar5) {
                  if ((*(longlong *)(param_1 + 0x88) != 0) &&
                     (cVar1 = (**(code **)(*local_res18 + 600))(), cVar1 == '\0')) {
                    uVar11 = FUN_14038c750(param_1 + 0x88);
                    FUN_1401ab480(uVar11,1,0xf);
                  }
                  uVar7 = (**(code **)(*plVar10 + 0x10))(plVar10);
                  FUN_1403e8cd0(*(undefined8 *)(param_1 + 0xb8),uVar7);
                  FUN_1403ec920(*(undefined8 *)(param_1 + 0xb8),0);
                }
              }
LAB_1403aa35a:
              uVar13 = uVar13 + 1;
              lVar9 = FUN_14017eea0(lVar8,iVar3,iVar4);
              uVar12 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))();
            } while (uVar13 < uVar12);
          }
          iVar4 = iVar4 + 1;
          iVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
        } while (iVar4 <= iVar5 / 0x12 + 1);
      }
      iVar3 = iVar3 + 1;
      iVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x40))(param_1 + 0x10);
    } while (iVar3 <= iVar4 / 0x12 + 1);
  }
  return;
}

// ==== CMapTrap::vfunc_11  @1403aa400  [high:rtti-vtable]  (orig: FUN_1403aa400)
longlong FUN_1403aa400(undefined8 param_1,longlong param_2)

{
  longlong lVar1;
  
  lVar1 = 5;
  do {
    *(undefined4 *)(param_2 + lVar1 * 4) = 0;
    lVar1 = lVar1 + -1;
  } while (-1 < lVar1);
  return param_2;
}

// ==== CMapTrap::vfunc_0  @1403aa5e0  [high:rtti-vtable]  (orig: FUN_1403aa5e0)
undefined8 FUN_1403aa5e0(undefined8 param_1,uint param_2)

{
  FUN_1403a9f10();
  if ((param_2 & 1) != 0) {
    FUN_1403a7bb0(param_1);
  }
  return param_1;
}

// ==== CMapTrap::helper_1403ab6c0  @1403ab6c0  [medium:callgraph-r3]  (orig: FUN_1403ab6c0)
void FUN_1403ab6c0(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_1403aaaa0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMapTrap::helper_1403ab860  @1403ab860  [medium:callgraph-r2]  (orig: FUN_1403ab860)
undefined8 FUN_1403ab860(longlong param_1)

{
  ulonglong *puVar1;
  longlong *plVar2;
  uint uVar3;
  longlong *plVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong local_res10;
  ulonglong *local_res18;
  ulonglong *local_48 [3];
  longlong *local_30;
  longlong *local_28;
  undefined8 local_20;
  ulonglong uVar4;
  
  local_res18 = operator_new(8);
  if (local_res18 == (ulonglong *)0x0) {
    local_48[0] = (ulonglong *)0x0;
  }
  else {
    *local_res18 = (ulonglong)local_48;
    local_48[0] = local_res18;
  }
  uVar6 = 0;
  local_30 = (longlong *)0x0;
  local_28 = (longlong *)0x0;
  local_20 = 0;
  lVar7 = *(longlong *)(param_1 + 0xc0);
  *(undefined8 *)(param_1 + 0xc0) = 0;
  uVar4 = uVar6;
  do {
    local_res10 = lVar7;
    if (lVar7 == 0) {
LAB_1403ab94d:
      plVar5 = local_30;
      puVar1 = local_48[0];
      if (local_28 < local_30) {
        _invalid_parameter_noinfo();
        puVar1 = local_48[0];
      }
      while( true ) {
        plVar2 = local_28;
        if (local_28 < local_30) {
          _invalid_parameter_noinfo();
        }
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_48[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar2) break;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar4 = uVar6;
        }
        else {
          uVar4 = *puVar1;
        }
        if (*(longlong **)(uVar4 + 0x20) <= plVar5) {
          _invalid_parameter_noinfo();
        }
        if (*plVar5 != 0) {
          FUN_1403a7180();
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar4 = uVar6;
        }
        else {
          uVar4 = *puVar1;
        }
        if (*(longlong **)(uVar4 + 0x20) <= plVar5) {
          _invalid_parameter_noinfo();
        }
        plVar5 = plVar5 + 1;
      }
      if (local_30 != (longlong *)0x0) {
        operator_delete(local_30);
      }
      local_30 = (longlong *)0x0;
      local_28 = (longlong *)0x0;
      local_20 = 0;
      operator_delete(local_48[0]);
      return 1;
    }
    uVar3 = (int)uVar4 + 1;
    uVar4 = (ulonglong)uVar3;
    if (10 < uVar3) {
      log_InlineLogERROR(&DAT_1406d9c10);
      goto LAB_1403ab94d;
    }
    FUN_1403ab6c0(local_48,&local_res10);
    plVar5 = (longlong *)(lVar7 + 0xc0);
    lVar7 = *plVar5;
    *plVar5 = 0;
  } while( true );
}

// ==== CMapTrap::helper_1403aba50  @1403aba50  [medium:callgraph-r1]  (orig: FUN_1403aba50)
void FUN_1403aba50(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  if (*(longlong *)(param_1 + 0x88) != 0) {
    if (*(longlong *)(param_1 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    cVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x88) + 0x10) + 0x220))
                      (*(longlong *)(param_1 + 0x88) + 0x10);
    if (cVar2 != '\0') {
      if (*(longlong *)(param_1 + 0x88) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar1 = *(longlong *)(param_1 + 0x88);
      iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
      iVar4 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
      if (iVar4 == iVar3) {
        plVar6 = (longlong *)FUN_14038c750(param_1 + 0x88);
        uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
        uVar7 = FUN_1400877e0(uVar7);
        FUN_1402f2fb0(uVar7,uVar5,0x2f26,param_1,0);
        return;
      }
    }
  }
  FUN_1403ab860(param_1);
  FUN_1403a7180(param_1);
  return;
}

// ==== CMapTrap::helper_1403abba0  @1403abba0  [medium:callgraph-r0]  (orig: FUN_1403abba0)
void FUN_1403abba0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),1);
  if (iVar1 < 10) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),1);
  if (iVar1 == 10) {
    FUN_1403a9f80(param_1);
  }
  else {
    if (iVar1 == 0xb) {
      FUN_1403a8c90(param_1);
      return;
    }
    if (iVar1 == 0xc) {
      FUN_1403aba50(param_1);
      return;
    }
    if (iVar1 == 0xd) {
      FUN_1403a8de0(param_1,0);
      return;
    }
  }
  return;
}

// ==== CMapTrap::vfunc_108  @1403abc50  [high:rtti-vtable]  (orig: FUN_1403abc50)
void FUN_1403abc50(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  int iVar2;
  
  if (param_1[0x14] != 0) {
    iVar2 = (**(code **)(*(longlong *)param_1[0x14] + 0x10))
                      ((longlong *)param_1[0x14],1,param_3,param_4,0xfffffffffffffffe);
    if (((iVar2 == 0xd) && (cVar1 = (**(code **)(*param_1 + 0x220))(param_1), cVar1 != '\0')) &&
       (iVar2 = (**(code **)(*param_1 + 0x78))(param_1), iVar2 == 0)) {
      FUN_1403a8de0(param_1 + -2,1);
      FUN_1403a7180(param_1 + -2);
    }
  }
  cVar1 = (**(code **)(*param_1 + 0x220))(param_1);
  if (((cVar1 != '\0') &&
      (iVar2 = (**(code **)(*(longlong *)param_1[0x14] + 0x10))((longlong *)param_1[0x14],1),
      9 < iVar2)) &&
     ((cVar1 = FUN_14016b190((longlong)param_1 + 0x5c,*(undefined4 *)((longlong)param_1 + 0x6c)),
      cVar1 != '\0' && ((char)param_1[0xe] != '\0')))) {
    FUN_1403abba0(param_1 + -2);
    iVar2 = (**(code **)(*(longlong *)param_1[0x14] + 0x10))((longlong *)param_1[0x14],9);
    if (((iVar2 == 0) && (iVar2 = FUN_1403a7410(param_1 + -2), iVar2 != 0xc)) &&
       (iVar2 = FUN_1403a7410(param_1 + -2), iVar2 != 0xd)) {
      return;
    }
    if ((int)param_1[0xd] < 1) {
      FUN_1403a7180(param_1 + -2);
    }
    else {
      *(int *)(param_1 + 0xd) = (int)param_1[0xd] + -1;
    }
  }
  return;
}

// ==== CMapTrap::helper_14048e730  @14048e730  [medium:callgraph-r3]  (orig: FUN_14048e730)
longlong * FUN_14048e730(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMapTrap::helper_1404b3350  @1404b3350  [medium:callgraph-r3]  (orig: FUN_1404b3350)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404b3350(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined8 uVar12;
  longlong lVar13;
  undefined8 uVar14;
  longlong *plVar15;
  undefined1 auStack_5f8 [32];
  longlong **local_5d8;
  longlong **local_5d0;
  uint local_5c8;
  undefined8 local_5c0;
  undefined4 local_5b8;
  undefined1 local_5b0;
  longlong *local_5a8;
  undefined8 local_5a0;
  longlong local_598;
  undefined4 local_590;
  undefined4 uStack_58c;
  longlong *local_588 [3];
  longlong *local_570;
  longlong *local_568;
  undefined8 local_560;
  longlong *local_558 [3];
  void *local_540;
  longlong local_538;
  undefined8 local_530;
  longlong *local_528 [3];
  void *local_510;
  undefined8 local_508;
  undefined8 local_500;
  longlong *local_4f8 [3];
  void *local_4e0;
  undefined8 local_4d8;
  undefined8 local_4d0;
  longlong *local_4c8 [3];
  void *local_4b0;
  undefined8 local_4a8;
  undefined8 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5f8;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    local_5d8 = (longlong **)CONCAT44(local_5d8._4_4_,0x336b);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else if (*(longlong *)(param_1 + 0x1c8) == 0) {
    local_5d8 = (longlong **)CONCAT44(local_5d8._4_4_,0x336c);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else {
    uVar10 = *(undefined4 *)(param_1 + 0x9c);
    uVar11 = *(undefined4 *)(param_1 + 0xa0);
    local_590 = uVar10;
    uStack_58c = uVar11;
    iVar6 = FUN_140418c50(*(longlong *)(param_1 + 0x90),0x88);
    iVar9 = *(int *)(param_1 + 0xf8);
    iVar7 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x72);
    iVar7 = iVar7 - iVar6 * (iVar9 + -1);
    if (iVar7 < 0) {
      iVar7 = 0;
    }
    lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
    lVar13 = *(longlong *)(lVar13 + 0x100);
    if (lVar13 == 0) {
      local_5d8 = (longlong **)CONCAT44(local_5d8._4_4_,0x144);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar13 = 0;
    }
    cVar3 = FUN_1402ec4a0(lVar13);
    if (cVar3 != '\0') {
      FUN_140362560(local_488);
      uVar8 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
      local_5c0 = (ulonglong)local_5c0._4_4_ << 0x20;
      local_5c8 = *(uint *)(param_1 + 0xf8);
      local_5d0 = (longlong **)CONCAT62(local_5d0._2_6_,0x1b1);
      local_5d8 = (longlong **)CONCAT62(local_5d8._2_6_,(short)iVar7);
      iVar9 = FUN_140362620(local_488,uVar8,uVar10,uVar11);
      if (iVar9 != 0) {
        plVar15 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
        (**(code **)(*plVar15 + 0x350))(plVar15,local_488);
      }
      FUN_1403625e0(local_488);
    }
    local_5a8 = operator_new(8);
    if (local_5a8 == (longlong *)0x0) {
      local_588[0] = (longlong *)0x0;
    }
    else {
      *local_5a8 = (longlong)local_588;
      local_588[0] = local_5a8;
    }
    local_570 = (longlong *)0x0;
    local_568 = (longlong *)0x0;
    local_560 = 0;
    local_5a0 = local_5a8;
    uVar14 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))();
    local_5d8 = (longlong **)CONCAT44(local_5d8._4_4_,0x1443);
    uVar12 = CONCAT44(uStack_58c,local_590);
    FUN_1402d2470(uVar14,local_588,uVar12,iVar7);
    local_5a8 = operator_new(8);
    if (local_5a8 == (longlong *)0x0) {
      local_558[0] = (longlong *)0x0;
    }
    else {
      *local_5a8 = (longlong)local_558;
      local_558[0] = local_5a8;
    }
    local_540 = (void *)0x0;
    local_538 = 0;
    local_530 = 0;
    local_5a0 = local_5a8;
    local_5a8 = operator_new(8);
    if (local_5a8 == (longlong *)0x0) {
      local_4c8[0] = (longlong *)0x0;
    }
    else {
      *local_5a8 = (longlong)local_4c8;
      local_4c8[0] = local_5a8;
    }
    local_4b0 = (void *)0x0;
    local_4a8 = 0;
    local_4a0 = 0;
    local_5a0 = local_5a8;
    local_5a8 = operator_new(8);
    if (local_5a8 == (longlong *)0x0) {
      local_4f8[0] = (longlong *)0x0;
    }
    else {
      *local_5a8 = (longlong)local_4f8;
      local_4f8[0] = local_5a8;
    }
    local_4e0 = (void *)0x0;
    local_4d8 = 0;
    local_4d0 = 0;
    local_5a0 = local_5a8;
    local_5a8 = operator_new(8);
    plVar15 = local_570;
    if (local_5a8 == (longlong *)0x0) {
      local_528[0] = (longlong *)0x0;
    }
    else {
      *local_5a8 = (longlong)local_528;
      local_528[0] = local_5a8;
    }
    local_510 = (void *)0x0;
    local_508 = 0;
    local_500 = 0;
    local_5a0 = local_5a8;
    plVar1 = local_588[0];
    if (local_568 < local_570) {
      _invalid_parameter_noinfo();
      plVar1 = local_588[0];
    }
    while( true ) {
      plVar2 = local_568;
      if (local_568 < local_570) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_588[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar15 == plVar2) break;
      local_5a8 = (longlong *)0x0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar1;
      }
      if (*(longlong **)(lVar13 + 0x20) <= plVar15) {
        _invalid_parameter_noinfo();
      }
      if (*plVar15 != 0) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar13 = 0;
        }
        else {
          lVar13 = *plVar1;
        }
        if (*(longlong **)(lVar13 + 0x20) <= plVar15) {
          _invalid_parameter_noinfo();
        }
        cVar3 = (**(code **)(*(longlong *)*plVar15 + 0x40))((longlong *)*plVar15,&local_5a8);
        if (cVar3 != '\0') {
          uVar10 = (**(code **)(*local_5a8 + 0x40))();
          local_5a0 = (longlong *)CONCAT44(local_5a0._4_4_,uVar10);
          uVar10 = (**(code **)(*local_5a8 + 0x48))();
          local_5a0 = (longlong *)CONCAT44(uVar10,(undefined4)local_5a0);
          cVar3 = FUN_1401671e0(local_5a0,uVar12,iVar7);
          if (cVar3 != '\0') {
            local_5c8 = 0;
            local_5d0 = local_528;
            local_5d8 = local_4f8;
            FUN_1404a1f70(param_1,local_5a8,local_558,local_4c8);
          }
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar1;
      }
      if (*(longlong **)(lVar13 + 0x20) <= plVar15) {
        _invalid_parameter_noinfo();
      }
      plVar15 = plVar15 + 1;
    }
    lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
    if (*(longlong *)(lVar13 + 0x88) == 0) {
      local_5d8 = (longlong **)CONCAT44(local_5d8._4_4_,0x12f);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar15 = (longlong *)
              (**(code **)(**(longlong **)(lVar13 + 0x88) + 0x20))
                        (*(longlong **)(lVar13 + 0x88),*(undefined4 *)(param_1 + 0xfc));
    local_598 = 0;
    if ((plVar15 != (longlong *)0x0) &&
       (cVar3 = (**(code **)(*plVar15 + 0x298))(plVar15,0x1400,&local_598), cVar3 != '\0')) {
      FUN_140362560(local_488);
      plVar15 = (longlong *)(local_598 + 0x10);
      uVar10 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),7);
      uVar4 = (**(code **)(*plVar15 + 0x48))(plVar15);
      uVar5 = (**(code **)(*plVar15 + 0x40))(plVar15);
      uVar11 = FUN_1403a73e0(local_598);
      uVar8 = FUN_1403a73d0(local_598);
      local_5b0 = 0;
      local_5c0 = CONCAT62(local_5c0._2_6_,uVar4);
      local_5c8 = CONCAT22(local_5c8._2_2_,uVar5);
      local_5d0 = (longlong **)CONCAT62(local_5d0._2_6_,0x1b2);
      local_5d8 = (longlong **)((ulonglong)local_5d8 & 0xffffffffffff0000);
      local_5b8 = uVar10;
      FUN_140362810(local_488,*(undefined4 *)(param_1 + 0xfc),uVar8,uVar11);
      (**(code **)(*(longlong *)(local_598 + 0x10) + 0x348))
                ((longlong *)(local_598 + 0x10),local_488,1);
      FUN_1403625e0(local_488);
    }
    if ((local_538 - (longlong)local_540 & 0xfffffffffffffff8U) == 0) {
      if (local_510 != (void *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (void *)0x0;
      local_508 = 0;
      local_500 = 0;
      operator_delete(local_528[0]);
      if (local_4e0 != (void *)0x0) {
        operator_delete(local_4e0);
      }
      local_4e0 = (void *)0x0;
      local_4d8 = 0;
      local_4d0 = 0;
      operator_delete(local_4f8[0]);
      if (local_4b0 != (void *)0x0) {
        operator_delete(local_4b0);
      }
      local_4b0 = (void *)0x0;
      local_4a8 = 0;
      local_4a0 = 0;
      operator_delete(local_4c8[0]);
      if (local_540 != (void *)0x0) {
        operator_delete(local_540);
      }
      local_540 = (void *)0x0;
      local_538 = 0;
      local_530 = 0;
      operator_delete(local_558[0]);
      if (local_570 != (longlong *)0x0) {
        operator_delete(local_570);
      }
      local_570 = (longlong *)0x0;
      local_568 = (longlong *)0x0;
      local_560 = 0;
      operator_delete(local_588[0]);
      uVar12 = 1;
    }
    else {
      local_5c0 = 0;
      local_5c8 = local_5c8 & 0xffffff00;
      local_5d0 = local_528;
      local_5d8 = local_4f8;
      FUN_140486a20(param_1,&local_590,local_558,local_4c8);
      local_5d8 = local_528;
      FUN_140499830(param_1,local_558,local_4c8,local_4f8);
      if (local_510 != (void *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (void *)0x0;
      local_508 = 0;
      local_500 = 0;
      operator_delete(local_528[0]);
      if (local_4e0 != (void *)0x0) {
        operator_delete(local_4e0);
      }
      local_4e0 = (void *)0x0;
      local_4d8 = 0;
      local_4d0 = 0;
      operator_delete(local_4f8[0]);
      if (local_4b0 != (void *)0x0) {
        operator_delete(local_4b0);
      }
      local_4b0 = (void *)0x0;
      local_4a8 = 0;
      local_4a0 = 0;
      operator_delete(local_4c8[0]);
      if (local_540 != (void *)0x0) {
        operator_delete(local_540);
      }
      local_540 = (void *)0x0;
      local_538 = 0;
      local_530 = 0;
      operator_delete(local_558[0]);
      if (local_570 != (longlong *)0x0) {
        operator_delete(local_570);
      }
      local_570 = (longlong *)0x0;
      local_568 = (longlong *)0x0;
      local_560 = 0;
      operator_delete(local_588[0]);
      uVar12 = 1;
    }
  }
  return uVar12;
}

// ==== CMapTrap::helper_1404b3c50  @1404b3c50  [medium:callgraph-r3]  (orig: FUN_1404b3c50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1404b3c50(longlong *param_1)

{
  longlong *plVar1;
  ulonglong *puVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  char cVar6;
  undefined1 uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  longlong lVar11;
  longlong *plVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  undefined8 uVar15;
  ulonglong *puVar16;
  longlong lVar17;
  ulonglong *puVar18;
  undefined8 *puVar19;
  int iVar20;
  undefined1 auStack_458 [32];
  ulonglong **local_438;
  ulonglong **local_430;
  undefined1 local_428;
  undefined8 local_420;
  undefined4 local_418 [2];
  ulonglong *local_410;
  ulonglong *local_408;
  int local_400;
  uint local_3fc;
  ulonglong *local_3f8 [3];
  undefined8 *local_3e0;
  undefined8 *local_3d8;
  longlong local_3d0;
  ulonglong *local_3c8;
  ulonglong *local_3c0 [3];
  undefined4 *local_3a8;
  undefined4 *local_3a0;
  longlong local_398;
  ulonglong *local_390 [3];
  undefined4 *local_378;
  undefined4 *local_370;
  longlong local_368;
  ulonglong *local_360 [3];
  undefined4 *local_348;
  undefined4 *local_340;
  longlong local_338;
  ulonglong *local_330 [3];
  longlong *local_318;
  longlong *local_310;
  undefined8 local_308;
  undefined8 local_2f8;
  undefined8 uStack_2f0;
  ulonglong *local_2e8 [3];
  undefined4 *local_2d0;
  undefined4 *local_2c8;
  longlong local_2c0;
  undefined4 local_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined8 local_2a8;
  undefined8 uStack_2a0;
  undefined8 local_298;
  undefined8 uStack_290;
  undefined4 local_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined8 local_278;
  undefined8 uStack_270;
  undefined8 local_268;
  undefined4 local_258;
  undefined4 uStack_254;
  undefined4 uStack_250;
  undefined4 uStack_24c;
  undefined4 local_248;
  undefined4 uStack_244;
  undefined4 uStack_240;
  undefined4 uStack_23c;
  char local_238;
  undefined1 local_237 [510];
  undefined1 local_39;
  ulonglong local_38;
  
  local_268 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if (param_1[0x12] == 0) {
    local_438 = (ulonglong **)CONCAT44(local_438._4_4_,0x33b8);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else if (param_1[0x39] == 0) {
    local_438 = (ulonglong **)CONCAT44(local_438._4_4_,0x33b9);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else {
    lVar11 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x160))();
    uVar7 = 0;
    if (lVar11 != 0) {
      plVar12 = *(longlong **)(*(longlong *)(lVar11 + 0x58) + 8);
      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,4);
      uVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
      if ((((((uVar13 >> 0x30 & 1) != 0) || (cVar6 = FUN_14017ef50(lVar11), cVar6 == '\0')) ||
           (cVar6 = FUN_1401195d0(lVar11), cVar6 != '\0')) ||
          ((cVar6 = FUN_140119630(lVar11), cVar6 != '\0' ||
           (cVar6 = FUN_140119660(lVar11), cVar6 != '\0')))) ||
         (cVar6 = FUN_140119690(lVar11), uVar7 = 0, cVar6 != '\0')) {
        local_3c8 = *(ulonglong **)((longlong)param_1 + 0x9c);
        iVar8 = FUN_140418c50(param_1[0x12],0x72);
        puVar18 = (ulonglong *)0x0;
        if (iVar8 < 0) {
          iVar8 = 0;
        }
        local_410 = operator_new(8);
        local_330[0] = puVar18;
        if (local_410 != (ulonglong *)0x0) {
          *local_410 = (ulonglong)local_330;
          local_330[0] = local_410;
        }
        local_318 = (longlong *)0x0;
        local_310 = (longlong *)0x0;
        local_308 = 0;
        local_438 = (ulonglong **)CONCAT44(local_438._4_4_,0x1001);
        local_408 = local_410;
        FUN_1402d2470(lVar11,local_330,local_3c8,iVar8);
        local_410 = operator_new(8);
        local_3f8[0] = puVar18;
        if (local_410 != (ulonglong *)0x0) {
          *local_410 = (ulonglong)local_3f8;
          local_3f8[0] = local_410;
        }
        local_3e0 = (undefined8 *)0x0;
        local_3d8 = (undefined8 *)0x0;
        local_3d0 = 0;
        local_408 = local_410;
        local_410 = operator_new(8);
        local_360[0] = puVar18;
        if (local_410 != (ulonglong *)0x0) {
          *local_410 = (ulonglong)local_360;
          local_360[0] = local_410;
        }
        local_348 = (undefined4 *)0x0;
        local_340 = (undefined4 *)0x0;
        local_338 = 0;
        local_408 = local_410;
        local_410 = operator_new(8);
        local_390[0] = puVar18;
        if (local_410 != (ulonglong *)0x0) {
          *local_410 = (ulonglong)local_390;
          local_390[0] = local_410;
        }
        local_378 = (undefined4 *)0x0;
        local_370 = (undefined4 *)0x0;
        local_368 = 0;
        local_408 = local_410;
        local_410 = operator_new(8);
        local_3c0[0] = puVar18;
        if (local_410 != (ulonglong *)0x0) {
          *local_410 = (ulonglong)local_3c0;
          local_3c0[0] = local_410;
        }
        local_3a8 = (undefined4 *)0x0;
        local_3a0 = (undefined4 *)0x0;
        local_398 = 0;
        local_408 = local_410;
        iVar8 = FUN_140418c50(param_1[0x12],0x8c);
        if (*(char *)((longlong)param_1 + 300) != '\0') {
          local_400 = iVar8;
          iVar8 = FUN_140418c50(param_1[0x12],0x87);
        }
        plVar12 = local_318;
        local_400 = iVar8;
        if (iVar8 < 1) {
          log_InlineLogERROR("CPlayerMagic::ProcessIceLotus TARGET_NUM is 0");
          if (local_3a8 != (undefined4 *)0x0) {
            operator_delete(local_3a8);
          }
          local_3a8 = (undefined4 *)0x0;
          local_3a0 = (undefined4 *)0x0;
          local_398 = 0;
          operator_delete(local_3c0[0]);
          if (local_378 != (undefined4 *)0x0) {
            operator_delete(local_378);
          }
          local_378 = (undefined4 *)0x0;
          local_370 = (undefined4 *)0x0;
          local_368 = 0;
          operator_delete(local_390[0]);
          if (local_348 != (undefined4 *)0x0) {
            operator_delete(local_348);
          }
          local_348 = (undefined4 *)0x0;
          local_340 = (undefined4 *)0x0;
          local_338 = 0;
          operator_delete(local_360[0]);
          if (local_3e0 != (undefined8 *)0x0) {
            operator_delete(local_3e0);
          }
          local_3e0 = (undefined8 *)0x0;
          local_3d8 = (undefined8 *)0x0;
          local_3d0 = 0;
          operator_delete(local_3f8[0]);
          if (local_318 != (longlong *)0x0) {
            operator_delete(local_318);
          }
          local_318 = (longlong *)0x0;
          local_310 = (longlong *)0x0;
          local_308 = 0;
          operator_delete(local_330[0]);
          uVar7 = 0;
        }
        else {
          local_3fc = 0;
          puVar16 = puVar18;
          puVar2 = local_330[0];
          if (local_310 < local_318) {
            _invalid_parameter_noinfo();
            puVar2 = local_330[0];
          }
          while( true ) {
            plVar1 = local_310;
            if (local_310 < local_318) {
              _invalid_parameter_noinfo();
            }
            if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_330[0])) {
              _invalid_parameter_noinfo();
            }
            iVar20 = (int)puVar16;
            if ((plVar12 == plVar1) || (iVar8 <= (int)puVar18)) break;
            local_410 = (ulonglong *)0x0;
            if (puVar2 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar13 = 0;
            }
            else {
              uVar13 = *puVar2;
            }
            if (*(longlong **)(uVar13 + 0x20) <= plVar12) {
              _invalid_parameter_noinfo();
            }
            if (*plVar12 != 0) {
              if (puVar2 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar13 = 0;
              }
              else {
                uVar13 = *puVar2;
              }
              if (*(longlong **)(uVar13 + 0x20) <= plVar12) {
                _invalid_parameter_noinfo();
              }
              cVar6 = (**(code **)(*(longlong *)*plVar12 + 0x40))((longlong *)*plVar12,&local_410);
              if (cVar6 != '\0') {
                (**(code **)(*local_410 + 0x40))();
                (**(code **)(*local_410 + 0x48))();
                cVar6 = FUN_140481330(param_1,local_410);
                if (cVar6 != '\0') {
                  (**(code **)(*local_410 + 0x2d0))(local_410,0,1);
                  local_408 = (ulonglong *)0x0;
                  (**(code **)(*local_410 + 0x298))();
                  if (local_408 != (ulonglong *)0x0) {
                    local_438 = (ulonglong **)((ulonglong)local_438 & 0xffffffffffffff00);
                    FUN_1401c6d40();
                    cVar6 = FUN_1400f8890(lVar11);
                    if ((cVar6 != '\0') || (cVar6 = FUN_14016cc30(lVar11), cVar6 != '\0')) {
                      FUN_1401a6420(local_408);
                    }
                    if ((param_1[0x39] != 0) &&
                       (iVar8 = (**(code **)(local_408[2] + 0x170))(), puVar18 = local_408,
                       iVar8 != 0)) {
                      iVar8 = (**(code **)(*(longlong *)(param_1[0x39] + 0x10) + 0x170))();
                      iVar9 = (**(code **)(puVar18[2] + 0x170))(puVar18 + 2);
                      if ((iVar8 == iVar9) && (iVar20 < 5)) {
                        puVar16 = (ulonglong *)(ulonglong)(iVar20 + 1);
                      }
                    }
                    puVar19 = local_3d8;
                    if (local_3e0 == (undefined8 *)0x0) {
                      uVar13 = 0;
                    }
                    else {
                      uVar13 = local_3d0 - (longlong)local_3e0 >> 3;
                    }
                    if ((ulonglong)((longlong)local_3d8 - (longlong)local_3e0 >> 3) < uVar13) {
                      *local_3d8 = local_410;
                      local_3d8 = local_3d8 + 1;
                    }
                    else {
                      if (local_3d8 < local_3e0) {
                        _invalid_parameter_noinfo();
                      }
                      puVar3 = local_3e0;
                      puVar18 = local_3f8[0];
                      local_278 = local_3f8[0];
                      uStack_270 = puVar19;
                      if (((longlong)local_3d8 - (longlong)local_3e0 & 0xfffffffffffffff8U) == 0) {
                        lVar17 = 0;
                      }
                      else {
                        if (local_3d8 < local_3e0) {
                          _invalid_parameter_noinfo();
                        }
                        if ((puVar18 == (ulonglong *)0x0) || (puVar18 != local_3f8[0])) {
                          _invalid_parameter_noinfo();
                        }
                        lVar17 = (longlong)puVar19 - (longlong)puVar3 >> 3;
                      }
                      local_248 = (undefined4)local_278;
                      uStack_244 = local_278._4_4_;
                      uStack_240 = (undefined4)uStack_270;
                      uStack_23c = uStack_270._4_4_;
                      FUN_1401a0cb0(local_3f8,&local_248);
                      puVar19 = local_3e0;
                      if (local_3d8 < local_3e0) {
                        _invalid_parameter_noinfo();
                      }
                      puVar18 = local_3f8[0];
                      if (local_3f8[0] == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *local_3f8[0];
                      }
                      if (puVar19 + lVar17 <= *(undefined8 **)(uVar13 + 0x20)) {
                        if (puVar18 == (ulonglong *)0x0) {
                          uVar13 = 0;
                        }
                        else {
                          uVar13 = *puVar18;
                        }
                        if (*(undefined8 **)(uVar13 + 0x18) <= puVar19 + lVar17) goto LAB_1404b43c3;
                      }
                      _invalid_parameter_noinfo();
                    }
LAB_1404b43c3:
                    puVar5 = local_340;
                    uVar13 = 0;
                    local_418[0] = 0;
                    if (local_348 != (undefined4 *)0x0) {
                      uVar13 = local_338 - (longlong)local_348 >> 2;
                    }
                    if ((ulonglong)((longlong)local_340 - (longlong)local_348 >> 2) < uVar13) {
                      *local_340 = 0;
                      local_340 = local_340 + 1;
                    }
                    else {
                      if (local_340 < local_348) {
                        _invalid_parameter_noinfo();
                      }
                      puVar4 = local_348;
                      puVar18 = local_360[0];
                      lVar17 = 0;
                      local_2a8 = local_360[0];
                      uStack_2a0 = puVar5;
                      if (((longlong)local_340 - (longlong)local_348 & 0xfffffffffffffffcU) != 0) {
                        if (local_340 < local_348) {
                          _invalid_parameter_noinfo();
                        }
                        if ((puVar18 == (ulonglong *)0x0) || (puVar18 != local_360[0])) {
                          _invalid_parameter_noinfo();
                        }
                        lVar17 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                      }
                      local_258 = (undefined4)local_2a8;
                      uStack_254 = local_2a8._4_4_;
                      uStack_250 = (undefined4)uStack_2a0;
                      uStack_24c = uStack_2a0._4_4_;
                      FUN_14000df40(local_360,&local_258);
                      puVar5 = local_348;
                      if (local_340 < local_348) {
                        _invalid_parameter_noinfo();
                      }
                      puVar18 = local_360[0];
                      if (local_360[0] == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *local_360[0];
                      }
                      uVar14 = 0;
                      if (puVar5 + lVar17 <= *(undefined4 **)(uVar13 + 0x20)) {
                        if (puVar18 != (ulonglong *)0x0) {
                          uVar14 = *puVar18;
                        }
                        if (*(undefined4 **)(uVar14 + 0x18) <= puVar5 + lVar17) goto LAB_1404b4520;
                      }
                      _invalid_parameter_noinfo();
                    }
LAB_1404b4520:
                    puVar5 = local_370;
                    uVar13 = 0;
                    local_418[0] = 0;
                    if (local_378 != (undefined4 *)0x0) {
                      uVar13 = local_368 - (longlong)local_378 >> 2;
                    }
                    if ((ulonglong)((longlong)local_370 - (longlong)local_378 >> 2) < uVar13) {
                      *local_370 = 0;
                      local_370 = local_370 + 1;
                    }
                    else {
                      if (local_370 < local_378) {
                        _invalid_parameter_noinfo();
                      }
                      puVar4 = local_378;
                      puVar18 = local_390[0];
                      lVar17 = 0;
                      local_298 = local_390[0];
                      uStack_290 = puVar5;
                      if (((longlong)local_370 - (longlong)local_378 & 0xfffffffffffffffcU) != 0) {
                        if (local_370 < local_378) {
                          _invalid_parameter_noinfo();
                        }
                        if ((puVar18 == (ulonglong *)0x0) || (puVar18 != local_390[0])) {
                          _invalid_parameter_noinfo();
                        }
                        lVar17 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                      }
                      local_288 = (undefined4)local_298;
                      uStack_284 = local_298._4_4_;
                      uStack_280 = (undefined4)uStack_290;
                      uStack_27c = uStack_290._4_4_;
                      FUN_140274790(local_390,&local_288);
                      puVar5 = local_378;
                      if (local_370 < local_378) {
                        _invalid_parameter_noinfo();
                      }
                      puVar18 = local_390[0];
                      if (local_390[0] == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *local_390[0];
                      }
                      uVar14 = 0;
                      if (puVar5 + lVar17 <= *(undefined4 **)(uVar13 + 0x20)) {
                        if (puVar18 != (ulonglong *)0x0) {
                          uVar14 = *puVar18;
                        }
                        if (*(undefined4 **)(uVar14 + 0x18) <= puVar5 + lVar17) goto LAB_1404b467a;
                      }
                      _invalid_parameter_noinfo();
                    }
LAB_1404b467a:
                    puVar5 = local_3a0;
                    uVar13 = 0;
                    local_418[0] = 0;
                    if (local_3a8 != (undefined4 *)0x0) {
                      uVar13 = local_398 - (longlong)local_3a8 >> 2;
                    }
                    if ((ulonglong)((longlong)local_3a0 - (longlong)local_3a8 >> 2) < uVar13) {
                      *local_3a0 = 0;
                      local_3a0 = local_3a0 + 1;
                    }
                    else {
                      if (local_3a0 < local_3a8) {
                        _invalid_parameter_noinfo();
                      }
                      puVar4 = local_3a8;
                      puVar18 = local_3c0[0];
                      lVar17 = 0;
                      local_2f8 = local_3c0[0];
                      uStack_2f0 = puVar5;
                      if (((longlong)local_3a0 - (longlong)local_3a8 & 0xfffffffffffffffcU) != 0) {
                        if (local_3a0 < local_3a8) {
                          _invalid_parameter_noinfo();
                        }
                        if ((puVar18 == (ulonglong *)0x0) || (puVar18 != local_3c0[0])) {
                          _invalid_parameter_noinfo();
                        }
                        lVar17 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                      }
                      local_2b8 = (undefined4)local_2f8;
                      uStack_2b4 = local_2f8._4_4_;
                      uStack_2b0 = (undefined4)uStack_2f0;
                      uStack_2ac = uStack_2f0._4_4_;
                      FUN_14000df40(local_3c0);
                      puVar5 = local_3a8;
                      if (local_3a0 < local_3a8) {
                        _invalid_parameter_noinfo();
                      }
                      puVar18 = local_3c0[0];
                      if (local_3c0[0] == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *local_3c0[0];
                      }
                      uVar14 = 0;
                      if (puVar5 + lVar17 <= *(undefined4 **)(uVar13 + 0x20)) {
                        if (puVar18 != (ulonglong *)0x0) {
                          uVar14 = *puVar18;
                        }
                        if (*(undefined4 **)(uVar14 + 0x18) <= puVar5 + lVar17) goto LAB_1404b47d1;
                      }
                      _invalid_parameter_noinfo();
                    }
LAB_1404b47d1:
                    local_3fc = local_3fc + 1;
                    puVar18 = (ulonglong *)(ulonglong)local_3fc;
                    iVar8 = local_400;
                    if ((param_1[0x39] != 0) && ((int)puVar16 < 5)) {
                      local_238 = '\0';
                      memset(local_237,0,0x1ff);
                      _snprintf(&local_238,0x200,"</F>Event_Save_User");
                      local_39 = 0;
                      plVar1 = (longlong *)param_1[0x39];
                      (**(code **)(*local_408 + 8))();
                      uVar10 = (**(code **)(*plVar1 + 8))(plVar1);
                      uVar15 = FUN_140087e30();
                      local_430 = (ulonglong **)0x0;
                      local_438 = (ulonglong **)((ulonglong)local_438 & 0xffffffff00000000);
                      cVar6 = FUN_140286530(uVar15,&local_238,uVar10);
                      if (cVar6 == '\0') {
                        log_InlineLogLuaERROR
                                  (
                                  "Lua return fault, Call From:CPlayerMagic:ProcessIceLotus, lua function:%s."
                                  );
                        puVar18 = (ulonglong *)(ulonglong)local_3fc;
                        iVar8 = local_400;
                      }
                      else {
                        puVar18 = (ulonglong *)(ulonglong)local_3fc;
                        iVar8 = local_400;
                      }
                    }
                  }
                }
              }
            }
            if (puVar2 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar13 = 0;
            }
            else {
              uVar13 = *puVar2;
            }
            if (*(longlong **)(uVar13 + 0x20) <= plVar12) {
              _invalid_parameter_noinfo();
            }
            plVar12 = plVar12 + 1;
          }
          if (0 < iVar20) {
            plVar12 = *(longlong **)(*(longlong *)(lVar11 + 0x58) + 8);
            plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,4);
            uVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
            if ((uVar13 >> 0x1c & 1) == 0) {
              plVar12 = *(longlong **)(*(longlong *)(lVar11 + 0x58) + 8);
              plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,4);
              uVar13 = (**(code **)(*plVar12 + 0x58))(plVar12);
              if (((uVar13 >> 0x1f & 1) != 0) &&
                 (plVar12 = (longlong *)CurrentInstanceGet(), plVar12 != (longlong *)0x0)) {
                uVar15 = FUN_140008520((int)param_1[0x38]);
                cVar6 = FUN_14008b330(uVar15);
                if (cVar6 == '\0') {
                  plVar12 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x1c);
                  if (plVar12 != (longlong *)0x0) {
                    lVar11 = *plVar12;
                    uVar10 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar11 + 0x90))(plVar12,uVar10,iVar20 * 2,0);
                  }
                }
                else {
                  plVar12 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x25);
                  if (plVar12 != (longlong *)0x0) {
                    lVar11 = *plVar12;
                    uVar10 = (**(code **)(*param_1 + 8))(param_1);
                    (**(code **)(lVar11 + 0x98))(plVar12,uVar10,iVar20 * 2);
                  }
                }
              }
            }
            else {
              plVar12 = (longlong *)CurrentInstanceGet();
              if ((plVar12 != (longlong *)0x0) &&
                 (plVar12 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x18),
                 plVar12 != (longlong *)0x0)) {
                lVar11 = *plVar12;
                uVar10 = (**(code **)(*param_1 + 8))(param_1);
                (**(code **)(lVar11 + 0x50))(plVar12,uVar10,iVar20 * 10);
              }
              plVar12 = (longlong *)FUN_140087ed0();
              lVar11 = *plVar12;
              uVar10 = (**(code **)(*(longlong *)param_1[0x39] + 8))();
              (**(code **)(lVar11 + 0x158))(plVar12,uVar10,iVar20 * 10);
            }
          }
          puVar18 = (ulonglong *)0x0;
          local_420 = 0;
          local_428 = 1;
          local_430 = local_3c0;
          local_438 = local_390;
          FUN_140486a20(param_1,&local_3c8,local_3f8,local_360);
          local_438 = local_3c0;
          FUN_140499830(param_1,local_3f8,local_360,local_390);
          local_408 = operator_new(8);
          puVar19 = local_3e0;
          local_2e8[0] = puVar18;
          if (local_408 != (ulonglong *)0x0) {
            *local_408 = (ulonglong)local_2e8;
            local_2e8[0] = local_408;
          }
          local_2d0 = (undefined4 *)0x0;
          local_2c8 = (undefined4 *)0x0;
          local_2c0 = 0;
          local_3c8 = local_408;
          puVar2 = local_3f8[0];
          if (local_3d8 < local_3e0) {
            _invalid_parameter_noinfo();
            puVar2 = local_3f8[0];
          }
          while( true ) {
            puVar3 = local_3d8;
            if (local_3d8 < local_3e0) {
              _invalid_parameter_noinfo();
            }
            if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_3f8[0])) {
              _invalid_parameter_noinfo();
            }
            if (puVar19 == puVar3) break;
            if (puVar2 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              puVar16 = puVar18;
            }
            else {
              puVar16 = (ulonglong *)*puVar2;
            }
            if ((undefined8 *)puVar16[4] <= puVar19) {
              _invalid_parameter_noinfo();
            }
            local_418[0] = (**(code **)(*(longlong *)*puVar19 + 0x10))();
            puVar5 = local_2c8;
            puVar16 = puVar18;
            if (local_2d0 != (undefined4 *)0x0) {
              puVar16 = (ulonglong *)(local_2c0 - (longlong)local_2d0 >> 2);
            }
            if ((ulonglong *)((longlong)local_2c8 - (longlong)local_2d0 >> 2) < puVar16) {
              *local_2c8 = local_418[0];
              local_2c8 = local_2c8 + 1;
            }
            else {
              if (local_2c8 < local_2d0) {
                _invalid_parameter_noinfo();
              }
              local_2f8 = local_2e8[0];
              puVar16 = local_2f8;
              uStack_2f0 = puVar5;
              local_2f8._0_4_ = SUB84(local_2e8[0],0);
              local_2f8._4_4_ = (undefined4)((ulonglong)local_2e8[0] >> 0x20);
              uStack_2f0._0_4_ = SUB84(puVar5,0);
              uStack_2f0._4_4_ = (undefined4)((ulonglong)puVar5 >> 0x20);
              local_2b8 = (undefined4)local_2f8;
              uStack_2b4 = local_2f8._4_4_;
              uStack_2b0 = (undefined4)uStack_2f0;
              uStack_2ac = uStack_2f0._4_4_;
              local_2f8 = puVar16;
              uStack_2f0 = puVar5;
              FUN_1400375c0(local_2e8,&local_288,&local_2b8,local_418);
            }
            if (puVar2 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              puVar16 = puVar18;
            }
            else {
              puVar16 = (ulonglong *)*puVar2;
            }
            if ((undefined8 *)puVar16[4] <= puVar19) {
              _invalid_parameter_noinfo();
            }
            puVar19 = puVar19 + 1;
          }
          FUN_1404a5480(param_1,local_2e8);
          if (local_2d0 != (undefined4 *)0x0) {
            operator_delete(local_2d0);
          }
          local_2d0 = (undefined4 *)0x0;
          local_2c8 = (undefined4 *)0x0;
          local_2c0 = 0;
          operator_delete(local_2e8[0]);
          if (local_3a8 != (undefined4 *)0x0) {
            operator_delete(local_3a8);
          }
          local_3a8 = (undefined4 *)0x0;
          local_3a0 = (undefined4 *)0x0;
          local_398 = 0;
          operator_delete(local_3c0[0]);
          if (local_378 != (undefined4 *)0x0) {
            operator_delete(local_378);
          }
          local_378 = (undefined4 *)0x0;
          local_370 = (undefined4 *)0x0;
          local_368 = 0;
          operator_delete(local_390[0]);
          if (local_348 != (undefined4 *)0x0) {
            operator_delete(local_348);
          }
          local_348 = (undefined4 *)0x0;
          local_340 = (undefined4 *)0x0;
          local_338 = 0;
          operator_delete(local_360[0]);
          if (local_3e0 != (undefined8 *)0x0) {
            operator_delete(local_3e0);
          }
          local_3e0 = (undefined8 *)0x0;
          local_3d8 = (undefined8 *)0x0;
          local_3d0 = 0;
          operator_delete(local_3f8[0]);
          if (local_318 != (longlong *)0x0) {
            operator_delete(local_318);
          }
          local_318 = (longlong *)0x0;
          local_310 = (longlong *)0x0;
          local_308 = 0;
          operator_delete(local_330[0]);
          uVar7 = 1;
        }
      }
    }
  }
  return uVar7;
}

// ==== CMapTrap::helper_1404bc180  @1404bc180  [medium:callgraph-r2]  (orig: FUN_1404bc180)
undefined1 FUN_1404bc180(longlong param_1,int param_2,longlong *param_3,int param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  char cVar6;
  undefined1 uVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  undefined4 uVar11;
  longlong lVar12;
  undefined4 local_res8 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined1 local_38 [16];
  
  if (*(longlong *)(param_1 + 0x1c8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar7 = 0;
  lVar12 = FUN_14048b5f0();
  if ((lVar12 != 0) && (*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0xa88) == 0)) {
    iVar8 = FUN_140418c50(lVar12,0x7a);
    if (iVar8 != 0) {
      uVar9 = FUN_140418c50(lVar12,0x7a);
      cVar6 = FUN_140482af0(*(undefined8 *)(param_1 + 0x1c8),uVar9,0);
      if (cVar6 == '\0') goto LAB_1404bc4f7;
    }
    iVar8 = FUN_140418c50(lVar12,0x70);
    iVar10 = tq::RandGet(100);
    if (iVar10 < iVar8) {
      uVar9 = *(undefined4 *)(param_1 + 0x98);
      uVar5 = *(undefined8 *)(param_1 + 0x90);
      uVar1 = *(undefined4 *)(param_1 + 0xf8);
      uVar2 = *(undefined4 *)(param_1 + 0xfc);
      uVar3 = *(undefined4 *)(param_1 + 0x9c);
      uVar4 = *(undefined4 *)(param_1 + 0xa0);
      if (param_2 == 0x2d50) {
        if (param_3 != (longlong *)0x0) {
          *(longlong *)(param_1 + 0x90) = lVar12;
          uVar11 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
          *(undefined4 *)(param_1 + 0x98) = uVar11;
          uVar11 = (**(code **)(param_3[2] + 0x40))(param_3 + 2);
          *(undefined4 *)(param_1 + 0x9c) = uVar11;
          uVar11 = (**(code **)(param_3[2] + 0x48))(param_3 + 2);
          *(undefined4 *)(param_1 + 0xa0) = uVar11;
          uVar7 = FUN_1404bad90(param_1);
        }
      }
      else if (param_2 == 0x2f26) {
        if (param_3 != (longlong *)0x0) {
          *(longlong *)(param_1 + 0x90) = lVar12;
          uVar11 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
          *(undefined4 *)(param_1 + 0x98) = uVar11;
          uVar11 = (**(code **)(param_3[2] + 0x40))(param_3 + 2);
          *(undefined4 *)(param_1 + 0x9c) = uVar11;
          uVar11 = (**(code **)(param_3[2] + 0x48))(param_3 + 2);
          *(undefined4 *)(param_1 + 0xa0) = uVar11;
          uVar11 = (**(code **)(*param_3 + 8))(param_3);
          *(undefined4 *)(param_1 + 0xfc) = uVar11;
          uVar11 = FUN_1403a73f0(param_3);
          *(undefined4 *)(param_1 + 0xf8) = uVar11;
          uVar7 = FUN_1404b3350(param_1);
          lVar12 = FUN_1403a7430(param_3);
          if (lVar12 != 0) {
            FUN_1403a7460(lVar12,1);
            FUN_1403a8430(lVar12);
          }
        }
      }
      else if (((param_2 == 0x3052) || (param_2 == 0x305c)) && (param_3 != (longlong *)0x0)) {
        *(longlong *)(param_1 + 0x90) = lVar12;
        *(bool *)(param_1 + 300) = param_4 != 0;
        uVar11 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
        *(undefined4 *)(param_1 + 0x98) = uVar11;
        uVar11 = (**(code **)(param_3[2] + 0x40))(param_3 + 2);
        *(undefined4 *)(param_1 + 0x9c) = uVar11;
        uVar11 = (**(code **)(param_3[2] + 0x48))(param_3 + 2);
        *(undefined4 *)(param_1 + 0xa0) = uVar11;
        uVar11 = (**(code **)(*param_3 + 8))(param_3);
        *(undefined4 *)(param_1 + 0xfc) = uVar11;
        if (param_2 == 0x3052) {
          uVar7 = FUN_1404b3c50(param_1);
        }
        else {
          uVar7 = FUN_1404bad90(param_1);
        }
        *(undefined1 *)(param_1 + 300) = 0;
        local_res8[0] = (**(code **)(*param_3 + 8))(param_3);
        FUN_14048e730(param_1 + 0x178,&local_48,local_res8);
        lVar12 = *(longlong *)(param_1 + 0x1a8);
        if ((*(longlong *)(param_1 + 0x178) == 0) ||
           (*(longlong *)(param_1 + 0x178) != CONCAT44(uStack_44,local_48))) {
          _invalid_parameter_noinfo();
        }
        if (lVar12 != CONCAT44(uStack_3c,uStack_40)) {
          FUN_14048e370(param_1 + 0x178,local_38,&local_48);
        }
      }
      *(undefined8 *)(param_1 + 0x90) = uVar5;
      *(undefined4 *)(param_1 + 0x98) = uVar9;
      *(undefined4 *)(param_1 + 0x9c) = uVar3;
      *(undefined4 *)(param_1 + 0xa0) = uVar4;
      *(undefined4 *)(param_1 + 0xf8) = uVar1;
      *(undefined4 *)(param_1 + 0xfc) = uVar2;
      return uVar7;
    }
  }
LAB_1404bc4f7:
  if (param_2 == 0x2f26) {
    FUN_1403ab860(param_3);
  }
  else if ((param_2 != 0x3052) && (param_2 != 0x305c)) {
    return 0;
  }
  FUN_1403a7180(param_3);
  return 0;
}

