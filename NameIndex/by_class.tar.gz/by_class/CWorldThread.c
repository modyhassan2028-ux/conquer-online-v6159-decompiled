// ==== CWorldThread::ctor_or_dtor  @14002e7e0  [high:vtable-assign]  (orig: FUN_14002e7e0)
CThreadBase * FUN_14002e7e0(CThreadBase *param_1,undefined8 param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CWorldThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = param_2;
  return param_1;
}

// ==== CWorldThread::ctor_or_dtor  @14002e830  [high:vtable-assign]  (orig: FUN_14002e830)
void FUN_14002e830(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CWorldThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x00014002e850. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CWorldThread::vfunc_1  @14002e8b0  [high:rtti-vtable]  (orig: FUN_14002e8b0)
void FUN_14002e8b0(longlong param_1)

{
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))();
  }
  *(undefined8 *)(param_1 + 0x40) = 0;
  return;
}

// ==== CWorldThread::vfunc_2  @14002e8e0  [high:rtti-vtable]  (orig: FUN_14002e8e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14002e8e0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418[0] = '\0';
  memset(local_418 + 1,0,0x3ff);
  (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  _snprintf(local_418,0x3ff,"#%u: world thread is up and running");
  lVar2 = -1;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 0x50))
            (*(longlong **)(param_1 + 0x48),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CWorldThread::vfunc_3  @14002e990  [high:rtti-vtable]  (orig: FUN_14002e990)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14002e990(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  ulong uVar3;
  undefined1 auStack_4e8 [32];
  undefined1 *local_4c8;
  undefined4 *local_4c0;
  char local_4b8;
  char local_4b7;
  ulong local_4b4;
  longlong local_4b0;
  int local_4a8;
  undefined4 local_4a0 [4];
  undefined8 local_490;
  CTickAnalyst local_488 [24];
  CTickAnalyst local_470 [24];
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_490 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  local_4b0 = param_1;
  if ((DAT_140975a90 & 1) == 0) {
    DAT_140975a90 = DAT_140975a90 | 1;
    DAT_140975a8c = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))
                    (*(longlong **)(param_1 + 0x48),s___AVCWorldThread___1409499c8._20_4_);
  local_4b7 = cVar1;
  CTickAnalyst::CTickAnalyst(local_470,0x1d);
  uVar2 = tq::TimeGet(0);
  local_4b4 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_488,0x1f);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))(*(longlong **)(param_1 + 0x40),uVar2);
    CTickAnalyst::~CTickAnalyst(local_488);
    if (uVar2 - DAT_140975a8c < 0x2711) {
      DAT_140975a8c = DAT_140975a8c + 1000;
    }
    else {
      log_InlineLogWARNING("resync CWorldKernel::OnTimer cumulative deviation %dms");
      DAT_140975a8c = uVar2;
    }
  }
  else {
    while( true ) {
      local_4c0 = local_4a0;
      local_4c8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_4b8 = 1;
      CTickAnalyst::CTickAnalyst(local_458,0x1e);
      local_4c8 = (undefined1 *)CONCAT44(local_4c8._4_4_,local_4a0[0]);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))();
      local_4b8 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_458);
      if (cVar1 == '\0') {
        log_InlineLogERROR(
                          "CWorldThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                          );
      }
    }
  }
  uVar3 = tq::TimeGet(0);
  local_4b0 = CONCAT44(local_4b0._4_4_,uVar3);
  local_4a8 = uVar3 - uVar2;
  LOCK();
  DAT_1409756a8 = DAT_1409756a8 + local_4a8;
  UNLOCK();
  LOCK();
  DAT_1409756ac = DAT_1409756ac + 1;
  UNLOCK();
  if (DAT_1409756a4 < local_4a8) {
    DAT_1409756a4 = local_4a8;
  }
  if ((int)(uVar3 - DAT_140975a8c) < 1000) {
    s___AVCWorldThread___1409499c8._20_4_ = 1000 - (uVar3 - DAT_140975a8c);
  }
  else {
    s___AVCWorldThread___1409499c8[0x14] = '\0';
    s___AVCWorldThread___1409499c8[0x15] = '\0';
    s___AVCWorldThread___1409499c8[0x16] = '\0';
    s___AVCWorldThread___1409499c8[0x17] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_470);
  return 1;
}

// ==== CWorldThread::ctor_or_dtor  @14002ebf0  [high:vtable-assign]  (orig: FUN_14002ebf0)
CThreadBase * FUN_14002ebf0(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CWorldThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

