// ==== CWantedActor@adapter::vfunc_1  @14058de30  [high:rtti-vtable]  (orig: FUN_14058de30)
void FUN_14058de30(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CWantedActor@adapter::vfunc_3  @14058de50  [high:rtti-vtable]  (orig: FUN_14058de50)
void FUN_14058de50(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014058de6a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return;
}

// ==== CWantedActor@adapter::vfunc_0  @14058de80  [high:rtti-vtable]  (orig: FUN_14058de80)
void FUN_14058de80(longlong param_1)

{
  FUN_14058dee0(param_1 + -8);
  return;
}

// ==== CWantedActor@adapter::helper_14058dee0  @14058dee0  [medium:callgraph-r0]  (orig: FUN_14058dee0)
undefined8 * FUN_14058dee0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CWantedActor::vftable;
  param_1[1] = adapter::CWantedActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CWantedActor@adapter::vfunc_10  @14058df30  [high:rtti-vtable]  (orig: FUN_14058df30)
ulonglong FUN_14058df30(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4)

{
  ulonglong in_RAX;
  longlong lVar1;
  longlong *plVar2;
  ulonglong extraout_RAX;
  
  if (param_4 != 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar1 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))
                       (*(longlong **)(lVar1 + 0x90),param_2);
    if (plVar2 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return extraout_RAX & 0xffffffffffffff00;
    }
    in_RAX = (**(code **)(*plVar2 + 0x150))(plVar2,param_3,param_4);
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CWantedActor@adapter::vfunc_9  @14058e000  [high:rtti-vtable]  (orig: FUN_14058e000)
bool FUN_14058e000(longlong param_1,undefined8 param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x90))
                     (*(longlong **)(lVar2 + 0x90),param_2,0);
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  lVar2 = *plVar3;
  uVar1 = (**(code **)(lVar2 + 8))(plVar3);
  lVar2 = (**(code **)(lVar2 + 0x28))(plVar3,uVar1);
  return lVar2 != 0;
}

// ==== CWantedActor@adapter::vfunc_8  @14058e0d0  [high:rtti-vtable]  (orig: FUN_14058e0d0)
bool FUN_14058e0d0(longlong param_1,undefined4 param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  lVar2 = *plVar3;
  uVar1 = (**(code **)(lVar2 + 8))(plVar3);
  lVar2 = (**(code **)(lVar2 + 0x28))(plVar3,uVar1);
  return lVar2 != 0;
}

// ==== CWantedActor@adapter::vfunc_4  @14058e1a0  [high:rtti-vtable]  (orig: FUN_14058e1a0)
undefined8 FUN_14058e1a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058e24b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return uVar2;
}

// ==== CWantedActor@adapter::vfunc_5  @14058e250  [high:rtti-vtable]  (orig: FUN_14058e250)
int FUN_14058e250(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return (int)*(short *)(lVar1 + 0xef4);
}

// ==== CWantedActor@adapter::vfunc_6  @14058e300  [high:rtti-vtable]  (orig: FUN_14058e300)
undefined8 FUN_14058e300(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058e3ab. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CWantedActor@adapter::vfunc_7  @14058e3b0  [high:rtti-vtable]  (orig: FUN_14058e3b0)
undefined8 FUN_14058e3b0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058e45b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CWantedActor@adapter::vfunc_11  @14058e470  [high:rtti-vtable]  (orig: FUN_14058e470)
void FUN_14058e470(longlong param_1,undefined4 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*plVar2 + 0x140))(plVar2,param_3,param_4);
  }
  return;
}

// ==== CWantedActor@adapter::vfunc_0  @14058e540  [high:rtti-vtable]  (orig: FUN_14058e540)
bool FUN_14058e540(longlong param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2)
  ;
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = (longlong *)FUN_140118320();
    if (plVar5 != (longlong *)0x0) {
      lVar3 = *plVar5;
      uVar1 = (**(code **)(*plVar4 + 8))(plVar4);
      iVar2 = (**(code **)(lVar3 + 0x28))(plVar5,uVar1);
      return iVar2 != 0;
    }
  }
  return false;
}

// ==== CWantedActor@adapter::vfunc_1  @14058e620  [high:rtti-vtable]  (orig: FUN_14058e620)
undefined8 FUN_14058e620(longlong param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 uVar6;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2)
  ;
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = (longlong *)FUN_140118320();
    if (plVar5 != (longlong *)0x0) {
      lVar3 = *plVar5;
      uVar1 = (**(code **)(*plVar4 + 8))(plVar4);
      iVar2 = (**(code **)(lVar3 + 0x28))(plVar5,uVar1);
      if (iVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014058e705. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar6 = (**(code **)(*plVar5 + 0x48))(plVar5,iVar2,0);
        return uVar6;
      }
    }
  }
  return 0;
}

// ==== CWantedActor@adapter::vfunc_2  @14058e710  [high:rtti-vtable]  (orig: FUN_14058e710)
undefined8 FUN_14058e710(longlong param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  int iVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar2 = (int)((ulonglong)((longlong)(param_3 + -0x28) * -0x66666667) >> 0x20);
  iVar2 = (iVar2 >> 2) - (iVar2 >> 0x1f);
  if (-1 < iVar2) {
    iVar2 = -1;
  }
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
            ((longlong *)(lVar1 + 0x10),6,(longlong)iVar2,1,0);
  return 1;
}

