// ==== CMsgQueryIPADPayInfoClient::helper_1401793d0  @1401793d0  [medium:callgraph-r0]  (orig: FUN_1401793d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401793d0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined8 local_448;
  undefined4 local_438;
  undefined4 local_434;
  undefined4 local_430;
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  uVar2 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008abd0(uVar2);
  if (cVar1 != '\0') {
    local_438 = local_438 & 0xffffff00;
    memset((void *)((longlong)&local_438 + 1),0,0x417);
    local_430 = (**(code **)(*param_1 + 8))(param_1);
    local_434 = (undefined4)param_1[0x1e2];
    local_438 = param_2;
    lVar3 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar3 + 0x80) == 0) {
      local_458 = (undefined4 *)CONCAT44(local_458._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    else {
      plVar4 = *(longlong **)(lVar3 + 0x80);
    }
    local_458 = &local_438;
    (**(code **)(*plVar4 + 0x50))(plVar4,9,0x186a2,0x418);
  }
  return;
}

// ==== CMsgQueryIPADPayInfoClient::ctor_or_dtor  @1403b73e0  [high:vtable-assign]  (orig: FUN_1403b73e0)
undefined8 * FUN_1403b73e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgQueryIPADPayInfoClient::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgQueryIPADPayInfoClient::ctor_or_dtor  @1403b7430  [high:vtable-assign]  (orig: FUN_1403b7430)
void FUN_1403b7430(undefined8 *param_1)

{
  *param_1 = CMsgQueryIPADPayInfoClient::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgQueryIPADPayInfoClient::vfunc_1  @1403b7460  [high:rtti-vtable]  (orig: FUN_1403b7460)
ulonglong FUN_1403b7460(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8d7);
}

// ==== CMsgQueryIPADPayInfoClient::ctor_or_dtor  @1403b74e0  [high:vtable-assign]  (orig: FUN_1403b74e0)
undefined8 * FUN_1403b74e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgQueryIPADPayInfoClient::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgQueryIPADPayInfoClient::vfunc_3  @1403b7530  [high:rtti-vtable]  (orig: FUN_1403b7530)
void FUN_1403b7530(longlong param_1)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong local_res18 [2];
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar2 = (longlong *)FUN_1400875f0(uVar1);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x18))(plVar2,param_1,0,*plVar2,uVar3);
  if (plVar2 != (longlong *)0x0) {
    local_res18[0] = 0;
    (**(code **)(*plVar2 + 0x298))(plVar2,0x1001,local_res18);
    if (local_res18[0] != 0) {
      FUN_1401793d0(local_res18[0],**(undefined4 **)(param_1 + 0x428));
    }
  }
  return;
}

