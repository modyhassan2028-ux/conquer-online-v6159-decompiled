// ==== CNpcIncomeData::ctor_or_dtor  @1403ac8b0  [high:vtable-assign]  (orig: FUN_1403ac8b0)
void FUN_1403ac8b0(undefined8 *param_1)

{
  *param_1 = CNpcIncomeData::vftable;
  if ((longlong *)param_1[2] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[2] + 0x58))();
  }
  return;
}

// ==== CNpcIncomeData::helper_1403acaa0  @1403acaa0  [medium:callgraph-r0]  (orig: FUN_1403acaa0)
void FUN_1403acaa0(void *param_1)

{
  if ((DAT_140976210 & 1) == 0) {
    DAT_140976210 = DAT_140976210 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976208,"CNpcIncomeData");
    atexit((_func_5014 *)&LAB_1406d6be0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403acaf5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976208,param_1);
  return;
}

// ==== CNpcIncomeData::ctor_or_dtor  @1403acb60  [high:vtable-assign]  (orig: FUN_1403acb60)
undefined8 * FUN_1403acb60(undefined8 *param_1,uint param_2)

{
  *param_1 = CNpcIncomeData::vftable;
  if ((longlong *)param_1[2] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[2] + 0x58))();
  }
  if ((param_2 & 1) != 0) {
    FUN_1403acaa0(param_1);
  }
  return param_1;
}

// ==== CNpcIncomeData::ctor_or_dtor  @1403ad160  [high:vtable-assign]  (orig: FUN_1403ad160)
undefined8 * FUN_1403ad160(undefined8 *param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CNpcIncomeData::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = IGameData::vftable;
    *puVar1 = CGameData<&char*_szNpcIncomeTable,&char*_szID>::vftable;
    *(undefined1 *)(puVar1 + 2) = 0;
    puVar1[1] = 0;
  }
  param_1[2] = puVar1;
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return param_1;
}

