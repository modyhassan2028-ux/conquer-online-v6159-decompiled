// ==== CGMTalkMgr::helper_14003fea0  @14003fea0  [medium:callgraph-r0]  (orig: FUN_14003fea0)
void FUN_14003fea0(void *param_1)

{
  if ((DAT_140975ab0 & 1) == 0) {
    DAT_140975ab0 = DAT_140975ab0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975aa8,"CGMTalkMgr");
    atexit((_func_5014 *)&LAB_1406d65a0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014003fef5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975aa8,param_1);
  return;
}

// ==== CGMTalkMgr::ctor_or_dtor  @14003ff80  [high:vtable-assign]  (orig: FUN_14003ff80)
undefined8 * FUN_14003ff80(undefined8 *param_1,byte param_2)

{
  *param_1 = CGMTalkMgr::vftable;
  if ((param_2 & 1) != 0) {
    FUN_14003fea0();
  }
  return param_1;
}

// ==== CGMTalkMgr::ctor_or_dtor  @14003ffb0  [high:vtable-assign]  (orig: FUN_14003ffb0)
undefined8 * FUN_14003ffb0(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140975ab0 & 1) == 0) {
    DAT_140975ab0 = DAT_140975ab0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975aa8,"CGMTalkMgr");
    atexit((_func_5014 *)&LAB_1406d65a0);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975aa8,0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CGMTalkMgr::vftable;
    *(undefined4 *)(puVar1 + 1) = 0;
    *(undefined4 *)((longlong)puVar1 + 0xc) = 0;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR("CGMTalkMgr::CreateNew fail");
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

