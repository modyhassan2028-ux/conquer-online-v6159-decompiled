// ==== CAchievementMgr::Create  @140111ce0  [high:log-string]  (orig: FUN_140111ce0)
undefined8 FUN_140111ce0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  void *pvVar7;
  
  plVar3 = (longlong *)FUN_140006ad0(0x1f46,1,param_3,param_4,0xfffffffffffffffe);
  if ((plVar3 != (longlong *)0x0) && (lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3), lVar4 == 1)) {
    plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,2);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
    *(bool *)(param_1 + 0x50) = iVar2 != 0;
    plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,3);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
    *(bool *)(param_1 + 0x51) = iVar2 != 0;
  }
  if (plVar3 != (longlong *)0x0) {
    (**(code **)*plVar3)(plVar3);
  }
  if (*(char *)(param_1 + 0x51) == '\0') {
    uVar6 = 1;
  }
  else {
    pvVar7 = operator_new(0x88);
    if (pvVar7 == (void *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = FUN_1403767b0(pvVar7);
    }
    *(longlong *)(param_1 + 0x98) = lVar4;
    if ((lVar4 != 0) && (cVar1 = FUN_140375b20(lVar4), cVar1 != '\0')) {
      return 1;
    }
    log_InlineLogERROR(
                      "CAchievementMgr::Create(). !m_pAchievementSet || !m_pAchievementSet->Create()"
                      );
    uVar6 = 0;
  }
  return uVar6;
}

// ==== CAchievementMgr::helper_140111fe0  @140111fe0  [medium:callgraph-r3]  (orig: FUN_140111fe0)
void FUN_140111fe0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140111fe0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CAchievementMgr::helper_1401121e0  @1401121e0  [medium:callgraph-r2]  (orig: FUN_1401121e0)
void FUN_1401121e0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140111fe0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CAchievementMgr::helper_140112260  @140112260  [medium:callgraph-r1]  (orig: FUN_140112260)
void FUN_140112260(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CAchievementMgr::helper_140112fd0  @140112fd0  [medium:callgraph-r1]  (orig: FUN_140112fd0)
longlong * FUN_140112fd0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1401121e0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140112b20(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CAchievementMgr::helper_140113c50  @140113c50  [medium:callgraph-r0]  (orig: FUN_140113c50)
void FUN_140113c50(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140112fd0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CAchievementMgr::ctor_or_dtor  @140114370  [high:vtable-assign]  (orig: FUN_140114370)
void FUN_140114370(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  
  *param_1 = CAchievementMgr::vftable;
  puVar1 = (undefined8 *)param_1[0x13];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1,param_3,param_4,0xfffffffffffffffe);
  }
  FUN_14000c310(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_140113c50(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CAchievementMgr::helper_140114480  @140114480  [medium:callgraph-r0]  (orig: FUN_140114480)
undefined8 * FUN_140114480(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140112260(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CAchievementMgr::ctor_or_dtor  @140114500  [high:vtable-assign]  (orig: FUN_140114500)
undefined8 * FUN_140114500(undefined8 *param_1)

{
  *param_1 = CAchievementMgr::vftable;
  FUN_140114480(param_1 + 2);
  FUN_14000ef40(param_1 + 0xb);
  *(undefined4 *)(param_1 + 1) = 0xe;
  param_1[0x13] = 0;
  *(undefined1 *)(param_1 + 10) = 0;
  *(undefined1 *)((longlong)param_1 + 0x51) = 0;
  FUN_14000a7b0(param_1 + 0xb);
  return param_1;
}

// ==== CAchievementMgr::vfunc_0  @140114570  [high:rtti-vtable]  (orig: FUN_140114570)
void * FUN_140114570(void *param_1,uint param_2)

{
  FUN_140114370();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

