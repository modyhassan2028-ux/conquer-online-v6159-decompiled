// ==== CMsgConnect::ctor_or_dtor  @140083080  [high:vtable-assign]  (orig: FUN_140083080)
undefined8 * FUN_140083080(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgConnect::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgConnect::ctor_or_dtor  @1400830d0  [high:vtable-assign]  (orig: FUN_1400830d0)
void FUN_1400830d0(undefined8 *param_1)

{
  *param_1 = CMsgConnect::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgConnect::vfunc_1  @1400831b0  [high:rtti-vtable]  (orig: FUN_1400831b0)
ulonglong FUN_1400831b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x41c);
}

// ==== CMsgConnect::vfunc_3  @1400831e0  [high:rtti-vtable]  (orig: FUN_1400831e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400831e0(longlong *param_1,longlong param_2)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  IStringManager *pIVar7;
  longlong lVar8;
  int *piVar9;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  longlong *local_478;
  undefined4 local_470;
  undefined8 local_468;
  undefined1 local_458 [1088];
  ulonglong local_18;
  
  local_468 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  puVar3 = (undefined4 *)param_1[0x84];
  uVar1 = *(undefined2 *)(puVar3 + 2);
  local_478 = param_1;
  uVar6 = FUN_140054e10();
  FUN_1400720f0(uVar6,*puVar3,uVar1);
  if ((param_2 != 0) && (*(int *)param_1[0x84] != 0)) {
    if (DAT_140975af8 == 0) {
      local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar4 = FUN_140055070(DAT_140975af8);
    if ((int)(uint)*(ushort *)(param_1[0x84] + 8) < iVar4) {
      FUN_14007a560(local_458);
      pIVar7 = theInstance();
      uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_LOWER_VERSION");
      local_488 = 1;
      local_490 = 0;
      local_498 = 0;
      local_4a0 = 0;
      local_4a8 = 0x835;
      local_4b0 = 0xffffff;
      local_4b8 = 0;
      iVar4 = FUN_14007a620(local_458,"SYSTEM","ALLUSERS",uVar6);
      if (iVar4 != 0) {
        (**(code **)(*param_1 + 0x20))(param_1,local_458);
      }
      FUN_14007a5e0(local_458);
    }
    else {
      uVar6 = FUN_140054dc0();
      lVar8 = FUN_140054d10(uVar6);
      iVar4 = *(int *)(lVar8 + 0x68);
      piVar9 = (int *)MaxPlayerGet();
      if ((*piVar9 < iVar4) && (1000 < *(int *)param_1[0x84])) {
        FUN_14007a560(local_458);
        pIVar7 = theInstance();
        uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_ERROR_SERVER_FULL");
        local_488 = 1;
        local_490 = 0;
        local_498 = 0;
        local_4a0 = 0;
        local_4a8 = 0x835;
        local_4b0 = 0xffffff;
        local_4b8 = 0;
        iVar4 = FUN_14007a620(local_458,"SYSTEM","ALLUSERS",uVar6);
        if (iVar4 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_458);
        }
        FUN_14007a5e0(local_458);
      }
      else {
        uVar5 = *(undefined4 *)((longlong)param_1 + 0x414);
        uVar6 = FUN_140054dc0();
        uVar5 = FUN_14005ce90(uVar6,uVar5);
        local_470 = uVar5;
        if (DAT_140975af8 == 0) {
          local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar8 = DAT_140975af8;
        if (*(longlong *)(DAT_140975af8 + 0x60) == 0) {
          local_4b8 = CONCAT44(local_4b8._4_4_,0x5c);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        puVar3 = (undefined4 *)param_1[0x84];
        local_4b8._0_4_ = puVar3[5];
        iVar4 = FUN_140071350(*(undefined8 *)(lVar8 + 0x60),*puVar3,puVar3 + 3,uVar5);
        if (iVar4 == 0) {
          FUN_14007a560(local_458);
          local_488 = 1;
          local_490 = 0;
          local_498 = 0;
          local_4a0 = 0;
          local_4a8 = 0x835;
          local_4b0 = 0xffffff;
          local_4b8 = 0;
          iVar4 = FUN_14007a620(local_458,"SYSTEM","ALLUSERS","account locked.");
          if (iVar4 != 0) {
            (**(code **)(*param_1 + 0x20))(param_1,local_458);
          }
          FUN_14007a5e0(local_458);
        }
        else {
          uVar2 = *(undefined4 *)((longlong)param_1 + 0x414);
          if (DAT_140975af8 == 0) {
            local_4b8._0_4_ = 0x128;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          puVar3 = (undefined4 *)param_1[0x84];
          local_4b8 = CONCAT44(local_4b8._4_4_,uVar2);
          local_4b0 = uVar5;
          FUN_140065e50(DAT_140975af8,*puVar3,puVar3[1],puVar3 + 2);
        }
      }
    }
  }
  return;
}

// ==== CMsgConnect::ctor_or_dtor  @1400835e0  [high:vtable-assign]  (orig: FUN_1400835e0)
undefined8 * FUN_1400835e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgConnect::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

