// ==== CTrainActor@adapter::helper_14032b540  @14032b540  [medium:callgraph-r0]  (orig: FUN_14032b540)
void FUN_14032b540(longlong param_1,int param_2)

{
  *(int *)(param_1 + 0x11c0) = *(int *)(param_1 + 0x11c0) + param_2;
  return;
}

// ==== CTrainActor@adapter::helper_1403727e0  @1403727e0  [medium:callgraph-r0]  (orig: FUN_1403727e0)
void FUN_1403727e0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x134) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"online_time");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTrainActor@adapter::helper_140372850  @140372850  [medium:callgraph-r0]  (orig: FUN_140372850)
void FUN_140372850(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x138) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"auto_exercise");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTrainActor@adapter::helper_1403728c0  @1403728c0  [medium:callgraph-r0]  (orig: FUN_1403728c0)
void FUN_1403728c0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x13c) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"last_logout");
    (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTrainActor@adapter::helper_1403827a0  @1403827a0  [medium:callgraph-r1]  (orig: FUN_1403827a0)
longlong FUN_1403827a0(undefined8 param_1,longlong param_2,uint param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  double dVar3;
  double dVar4;
  double dVar5;
  
  uVar2 = param_3;
  if (param_4 < param_3) {
    uVar2 = param_4;
    param_4 = param_3;
  }
  dVar3 = DAT_14075cb68;
  dVar5 = DAT_14075cb60;
  uVar1 = uVar2;
  if ((int)uVar2 < 0) {
    uVar1 = -uVar2;
  }
  while( true ) {
    if ((uVar1 & 1) != 0) {
      dVar5 = dVar5 * dVar3;
    }
    if (uVar1 >> 1 == 0) break;
    dVar3 = dVar3 * dVar3;
    uVar1 = uVar1 >> 1;
  }
  if ((int)uVar2 < 0) {
    dVar5 = DAT_14075cb60 / dVar5;
  }
  uVar1 = (param_4 - uVar2) + 1;
  dVar3 = DAT_14075cb68;
  dVar4 = DAT_14075cb60;
  uVar2 = uVar1;
  if ((int)uVar1 < 0) {
    uVar2 = -uVar1;
  }
  while( true ) {
    if ((uVar2 & 1) != 0) {
      dVar4 = dVar4 * dVar3;
    }
    if (uVar2 >> 1 == 0) break;
    dVar3 = dVar3 * dVar3;
    uVar2 = uVar2 >> 1;
  }
  if ((int)uVar1 < 0) {
    dVar4 = DAT_14075cb60 / dVar4;
  }
  return (param_2 / (longlong)dVar5) % (longlong)dVar4;
}

// ==== CTrainActor@adapter::helper_140382850  @140382850  [medium:callgraph-r0]  (orig: FUN_140382850)
__time32_t FUN_140382850(longlong param_1)

{
  uint uVar1;
  __time32_t _Var2;
  tm *ptVar3;
  int iVar4;
  __time32_t local_res8 [2];
  tm local_38;
  
  uVar1 = *(uint *)(param_1 + 0xf38);
  if (uVar1 == 0) {
    return 0;
  }
  local_res8[0] = _time32((__time32_t *)0x0);
  ptVar3 = _localtime32(local_res8);
  local_38.tm_mday = ptVar3->tm_mday;
  local_38.tm_mon = ptVar3->tm_mon;
  local_38.tm_year = ptVar3->tm_year;
  local_38.tm_wday = ptVar3->tm_wday;
  local_38.tm_yday = ptVar3->tm_yday;
  local_38.tm_isdst = ptVar3->tm_isdst;
  iVar4 = 0;
  local_38.tm_sec = 0;
  local_38.tm_min = 0;
  local_38.tm_hour = uVar1 % 100;
  local_38.tm_mday = FUN_1403827a0(param_1,uVar1,2,3);
  local_38.tm_mon = FUN_1403827a0(param_1,uVar1,iVar4 + 4,iVar4 + 5);
  local_38.tm_mon = local_38.tm_mon + -1;
  local_38.tm_year = FUN_1403827a0(param_1,uVar1,iVar4 + 6,iVar4 + 7);
  local_38.tm_year = local_38.tm_year + 100;
  local_38.tm_wday = iVar4;
  local_38.tm_yday = iVar4;
  _Var2 = _mktime32(&local_38);
  return _Var2;
}

// ==== CTrainActor@adapter::vfunc_1  @1405baf60  [high:rtti-vtable]  (orig: FUN_1405baf60)
void FUN_1405baf60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_1  @1405bafd0  [high:rtti-vtable]  (orig: FUN_1405bafd0)
undefined8 FUN_1405bafd0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405baff2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_2  @1405bb000  [high:rtti-vtable]  (orig: FUN_1405bb000)
undefined4 FUN_1405bb000(void)

{
  return DAT_14094da38;
}

// ==== CTrainActor@adapter::vfunc_3  @1405bb010  [high:rtti-vtable]  (orig: FUN_1405bb010)
undefined8 FUN_1405bb010(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  
  lVar3 = DAT_140975be0;
  if (DAT_140975be0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  plVar1 = (longlong *)FUN_14014de60(lVar3,0,param_2);
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405bb06f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x10))(plVar1,2);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_5  @1405bb080  [high:rtti-vtable]  (orig: FUN_1405bb080)
undefined8 FUN_1405bb080(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405bb0a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0xa0))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_0  @1405bb0b0  [high:rtti-vtable]  (orig: FUN_1405bb0b0)
void FUN_1405bb0b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_14032b540(lVar1,param_3);
    FUN_140161610(lVar1,1);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_6  @1405bb100  [high:rtti-vtable]  (orig: FUN_1405bb100)
int FUN_1405bb100(longlong param_1)

{
  longlong lVar1;
  int iVar2;
  longlong lVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 != 0) {
    iVar2 = FUN_140175470(lVar3);
    if (iVar2 != 0) {
      iVar2 = FUN_140164ee0(lVar3);
      if (iVar2 == 0) {
        pIVar4 = theInstance();
        lVar1 = *(longlong *)(lVar3 + 0x10);
        uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_TRAIN_WALLOWNONE");
        (**(code **)(lVar1 + 0x358))(lVar3 + 0x10,uVar5);
      }
      else if (iVar2 == 0x32) {
        pIVar4 = theInstance();
        lVar1 = *(longlong *)(lVar3 + 0x10);
        uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_TRAIN_WALLOWHALF");
        (**(code **)(lVar1 + 0x358))(lVar3 + 0x10,uVar5);
        return 0x32;
      }
      return iVar2;
    }
  }
  return 100;
}

// ==== CTrainActor@adapter::vfunc_7  @1405bb1d0  [high:rtti-vtable]  (orig: FUN_1405bb1d0)
void FUN_1405bb1d0(longlong param_1,undefined8 param_2,int param_3,undefined8 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    (**(code **)(*plVar3 + 200))(plVar3,param_3,param_4);
    cVar1 = (**(code **)(*plVar3 + 0x118))(plVar3);
    if (cVar1 == '\0') {
      (**(code **)(plVar3[2] + 0x2e0))(plVar3 + 2,10,(longlong)(param_3 * 3),1,0);
    }
    else {
      (**(code **)(*plVar3 + 0xd0))(plVar3,param_3);
    }
    uVar2 = (**(code **)(plVar3[2] + 0x80))(plVar3 + 2);
    FUN_1401a6420(plVar3,0,uVar2,1);
    (**(code **)(*plVar3 + 0xd8))(plVar3);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_8  @1405bb2a0  [high:rtti-vtable]  (orig: FUN_1405bb2a0)
void FUN_1405bb2a0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1401a6420(lVar1,param_3,param_4,param_5);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_9  @1405bb2e0  [high:rtti-vtable]  (orig: FUN_1405bb2e0)
undefined4 FUN_1405bb2e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return *(undefined4 *)(lVar1 + 0xfac);
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_10  @1405bb310  [high:rtti-vtable]  (orig: FUN_1405bb310)
void FUN_1405bb310(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1403727e0(lVar1 + 0xe78,param_3,param_4);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_11  @1405bb350  [high:rtti-vtable]  (orig: FUN_1405bb350)
ulonglong FUN_1405bb350(longlong param_1)

{
  __time32_t _Var1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    return (ulonglong)*(uint *)(lVar2 + 0xfb4);
  }
  _Var1 = _time32((__time32_t *)0x0);
  return (longlong)_Var1;
}

// ==== CTrainActor@adapter::vfunc_13  @1405bb380  [high:rtti-vtable]  (orig: FUN_1405bb380)
undefined8 FUN_1405bb380(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_1401649c0(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_12  @1405bb3b0  [high:rtti-vtable]  (orig: FUN_1405bb3b0)
void FUN_1405bb3b0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1403728c0(lVar1 + 0xe78,param_3,param_4);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_14  @1405bb3f0  [high:rtti-vtable]  (orig: FUN_1405bb3f0)
bool FUN_1405bb3f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return *(int *)(lVar1 + 0xfb0) == 1;
  }
  return false;
}

// ==== CTrainActor@adapter::vfunc_15  @1405bb430  [high:rtti-vtable]  (orig: FUN_1405bb430)
void FUN_1405bb430(longlong param_1,undefined8 param_2,char param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140372850(lVar1 + 0xe78,param_3 != '\0',param_4);
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_16  @1405bb480  [high:rtti-vtable]  (orig: FUN_1405bb480)
longlong FUN_1405bb480(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    iVar1 = FUN_140382850(lVar2);
    return (longlong)iVar1;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_17  @1405bb4b0  [high:rtti-vtable]  (orig: FUN_1405bb4b0)
undefined8 FUN_1405bb4b0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140383750(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_20  @1405bb4e0  [high:rtti-vtable]  (orig: FUN_1405bb4e0)
undefined8 FUN_1405bb4e0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405bb502. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_21  @1405bb510  [high:rtti-vtable]  (orig: FUN_1405bb510)
undefined8 FUN_1405bb510(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140161f50(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_23  @1405bb540  [high:rtti-vtable]  (orig: FUN_1405bb540)
uint * FUN_1405bb540(longlong param_1,uint *param_2,undefined4 param_3)

{
  ushort uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = *(longlong **)(param_1 + 0x10);
  *param_2 = 0;
  param_2[1] = 0;
  lVar3 = (**(code **)(*plVar2 + 0x98))(plVar2,param_3);
  if (lVar3 != 0) {
    uVar1 = *(ushort *)(lVar3 + 0xf0c);
    param_2[1] = (uint)*(ushort *)(lVar3 + 0xf0e);
    *param_2 = (uint)uVar1;
  }
  return param_2;
}

// ==== CTrainActor@adapter::vfunc_24  @1405bb590  [high:rtti-vtable]  (orig: FUN_1405bb590)
bool FUN_1405bb590(longlong param_1,undefined8 param_2,undefined4 param_3,ulonglong param_4)

{
  int iVar1;
  longlong lVar2;
  undefined4 uStackX_24;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    uStackX_24 = (undefined4)(param_4 >> 0x20);
    iVar1 = FUN_1401c55b0(lVar2,param_3,param_4 & 0xffffffff,uStackX_24,0);
    return iVar1 == 0;
  }
  return false;
}

// ==== CTrainActor@adapter::vfunc_0  @1405bb610  [high:rtti-vtable]  (orig: FUN_1405bb610)
void FUN_1405bb610(longlong param_1)

{
  FUN_1405bb6a0(param_1 + -8);
  return;
}

// ==== CTrainActor@adapter::helper_1405bb6a0  @1405bb6a0  [medium:callgraph-r0]  (orig: FUN_1405bb6a0)
undefined8 * FUN_1405bb6a0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTrainActor::vftable;
  param_1[1] = adapter::CTrainActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTrainActor@adapter::vfunc_4  @1405bb6f0  [high:rtti-vtable]  (orig: FUN_1405bb6f0)
undefined8 FUN_1405bb6f0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = DAT_140975be0;
  if (DAT_140975be0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  lVar1 = FUN_14014de60(lVar1,0,param_2);
  if (lVar1 != 0) {
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 8) + 0x10))(*(longlong **)(lVar1 + 8),1);
                    /* WARNING: Could not recover jumptable at 0x0001405bb759. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    return uVar3;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_18  @1405bb770  [high:rtti-vtable]  (orig: FUN_1405bb770)
uint FUN_1405bb770(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x20))
                    (*(longlong **)(lVar1 + 0x98),param_2,0);
  if (lVar1 != 0) {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    return (uint)(uVar3 >> 0xf) & 1;
  }
  return 1;
}

// ==== CTrainActor@adapter::vfunc_19  @1405bb810  [high:rtti-vtable]  (orig: FUN_1405bb810)
void FUN_1405bb810(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008abf0(uVar1);
  return;
}

// ==== CTrainActor@adapter::vfunc_22  @1405bb830  [high:rtti-vtable]  (orig: FUN_1405bb830)
undefined8 * FUN_1405bb830(longlong param_1,undefined8 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x18);
  *(undefined4 *)param_2 = 0;
  *(undefined4 *)((longlong)param_2 + 4) = 0;
  lVar3 = FUN_140008520(uVar1);
  if (*(longlong *)(lVar3 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x20))
                    (*(longlong **)(lVar3 + 0x98),param_3,0);
  if (lVar3 != 0) {
    uVar1 = (**(code **)(**(longlong **)(lVar3 + 0x58) + 0x10))(*(longlong **)(lVar3 + 0x58),0xb);
    uVar2 = (**(code **)(**(longlong **)(lVar3 + 0x58) + 0x10))(*(longlong **)(lVar3 + 0x58),0xc);
    *param_2 = CONCAT44(uVar2,uVar1);
  }
  return param_2;
}

// ==== CTrainActor@adapter::vfunc_25  @1405bb8f0  [high:rtti-vtable]  (orig: FUN_1405bb8f0)
void FUN_1405bb8f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CTrainActor@adapter::vfunc_26  @1405bb990  [high:rtti-vtable]  (orig: FUN_1405bb990)
ulonglong FUN_1405bb990(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x20))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 != 0) {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    return CONCAT71((int7)((ulonglong)uVar3 >> 8),~((byte)uVar3 >> 2)) & 0xffffffffffffff01;
  }
  return 0;
}

// ==== CTrainActor@adapter::vfunc_27  @1405bba40  [high:rtti-vtable]  (orig: FUN_1405bba40)
undefined8 FUN_1405bba40(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x20))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1402c3cc0(lVar1,param_3,param_4);
  }
  return uVar2;
}

// ==== CTrainActor@adapter::vfunc_28  @1405bbae0  [high:rtti-vtable]  (orig: FUN_1405bbae0)
void FUN_1405bbae0(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008ab60(uVar1,param_2);
  return;
}

// ==== CTrainActor@adapter::vfunc_29  @1405bbb00  [high:rtti-vtable]  (orig: FUN_1405bbb00)
void FUN_1405bbb00(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006c50(*(undefined8 *)(lVar1 + 0xb0),param_2);
  return;
}

