// ==== CPeerageActor@adapter::helper_140176190  @140176190  [medium:callgraph-r0]  (orig: FUN_140176190)
void FUN_140176190(longlong *param_1,undefined8 param_2)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint uVar7;
  
  FUN_140373210(param_1 + 0x1cf);
  plVar3 = (longlong *)CurrentInstanceGet();
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x11);
  if (plVar3 != (longlong *)0x0) {
    uVar7 = 1;
    do {
      lVar4 = FUN_140008520((int)param_1[0x246]);
      lVar5 = *(longlong *)(lVar4 + 0x1a8);
      if (*(longlong *)(lVar4 + 0x1a8) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar5 = 0;
      }
      lVar5 = FUN_1402e69e0(lVar5,param_1,uVar7 & 0xff);
      if (0 < lVar5) {
        lVar4 = *plVar3;
        uVar6 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar1 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar4 + 0x58))(plVar3,uVar1,uVar6,uVar7 & 0xff,lVar5);
      }
      uVar7 = uVar7 + 1;
    } while ((int)uVar7 < 5);
    lVar5 = FUN_140008520((int)param_1[0x246]);
    lVar5 = *(longlong *)(lVar5 + 0x1d0);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    iVar2 = FUN_1401f6870(lVar5,uVar1);
    lVar5 = *plVar3;
    uVar6 = (**(code **)(param_1[2] + 0x18))();
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar5 + 0x78))(plVar3,uVar1,uVar6,(longlong)iVar2);
  }
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  uVar6 = FUN_140008520((int)param_1[0x246]);
  FUN_14008a880(uVar6,uVar1,8,param_2);
  return;
}

// ==== CPeerageActor@adapter::helper_140373210  @140373210  [medium:callgraph-r1]  (orig: FUN_140373210)
void FUN_140373210(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  
  *(undefined8 *)(param_1 + 0x158) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"donation");
    (**(code **)(*plVar1 + 0xa0))(plVar1,param_2);
    (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_1  @1405ba3f0  [high:rtti-vtable]  (orig: FUN_1405ba3f0)
void FUN_1405ba3f0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_0  @1405ba410  [high:rtti-vtable]  (orig: FUN_1405ba410)
undefined8 FUN_1405ba410(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba432. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_1  @1405ba440  [high:rtti-vtable]  (orig: FUN_1405ba440)
undefined1 FUN_1405ba440(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return *(undefined1 *)(lVar1 + 0x51c);
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_2  @1405ba470  [high:rtti-vtable]  (orig: FUN_1405ba470)
undefined8 FUN_1405ba470(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba49c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,1);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_3  @1405ba4b0  [high:rtti-vtable]  (orig: FUN_1405ba4b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405ba4b0(longlong param_1,undefined4 param_2,longlong param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  undefined1 auStack_4c8 [32];
  undefined8 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  longlong local_490;
  longlong local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar5 != (longlong *)0x0) {
    local_4a8 = 0;
    cVar2 = (**(code **)(plVar5[2] + 0x2e0))(plVar5 + 2,0x1d,-param_3);
    if (cVar2 != '\0') {
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      local_4a8._0_4_ = (int)param_3;
      FUN_1401742b0(plVar5,10,uVar3);
      lVar1 = plVar5[0x1e2];
      (**(code **)(plVar5[2] + 0x18))(plVar5 + 2);
      local_498 = 0x6f;
      local_4a0 = 0x6f;
      local_4a8 = CONCAT44(local_4a8._4_4_,(int)lVar1);
      local_490 = param_3;
      local_488 = param_3;
      tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%u\t%u\t%d\t%d\t1\t");
      FUN_14039e680(local_468);
      iVar4 = FUN_14039e700(local_468,param_2,0x1d,*(undefined4 *)((longlong)plVar5 + 0xfa4));
      if (iVar4 != 0) {
        (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_468);
      }
      FUN_14039e6d0(local_468);
      return 1;
    }
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_4  @1405ba600  [high:rtti-vtable]  (orig: FUN_1405ba600)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405ba600(longlong param_1,undefined4 param_2,longlong param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  undefined1 auStack_4c8 [32];
  undefined8 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  longlong local_490;
  longlong local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar5 != (longlong *)0x0) {
    local_4a8 = 0;
    cVar2 = (**(code **)(plVar5[2] + 0x2e0))(plVar5 + 2,0x2d,-param_3);
    if (cVar2 != '\0') {
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      local_4a8._0_4_ = (int)param_3;
      FUN_140174470(plVar5,10,uVar3);
      lVar1 = plVar5[0x1e2];
      (**(code **)(plVar5[2] + 0x18))(plVar5 + 2);
      local_498 = 0x6f;
      local_4a0 = 0x6f;
      local_4a8 = CONCAT44(local_4a8._4_4_,(int)lVar1);
      local_490 = param_3;
      local_488 = param_3;
      tq::MyLogSave("gmlog/emoney_mono_buy","%u\t%s\t%u\t%u\t%u\t%d\t%d\t1\t");
      FUN_14039e680(local_468);
      uVar3 = FUN_140371860(plVar5 + 0x1cf);
      iVar4 = FUN_14039e700(local_468,param_2,0x2d,uVar3);
      if (iVar4 != 0) {
        (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_468);
      }
      FUN_14039e6d0(local_468);
      return 1;
    }
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_5  @1405ba750  [high:rtti-vtable]  (orig: FUN_1405ba750)
undefined1 * FUN_1405ba750(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba772. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return puVar2;
  }
  return &DAT_1406dd892;
}

// ==== CPeerageActor@adapter::vfunc_10  @1405ba830  [high:rtti-vtable]  (orig: FUN_1405ba830)
undefined8 FUN_1405ba830(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba850. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_11  @1405ba860  [high:rtti-vtable]  (orig: FUN_1405ba860)
undefined8 FUN_1405ba860(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140165370(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_12  @1405ba890  [high:rtti-vtable]  (orig: FUN_1405ba890)
void FUN_1405ba890(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140176190(lVar1,param_3);
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_13  @1405ba8c0  [high:rtti-vtable]  (orig: FUN_1405ba8c0)
void FUN_1405ba8c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140194390(lVar1);
    if (*(char *)(lVar1 + 0x12c8) != '\0') {
      FUN_14018ad50(lVar1,1,4);
    }
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_14  @1405ba910  [high:rtti-vtable]  (orig: FUN_1405ba910)
bool FUN_1405ba910(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CPeerageActor@adapter::vfunc_15  @1405ba930  [high:rtti-vtable]  (orig: FUN_1405ba930)
undefined8 FUN_1405ba930(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba952. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_16  @1405ba960  [high:rtti-vtable]  (orig: FUN_1405ba960)
undefined8 FUN_1405ba960(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba982. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CPeerageActor@adapter::vfunc_17  @1405ba990  [high:rtti-vtable]  (orig: FUN_1405ba990)
void FUN_1405ba990(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x23);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405baa58. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,param_2,param_3,param_4);
  return;
}

// ==== CPeerageActor@adapter::vfunc_0  @1405baa60  [high:rtti-vtable]  (orig: FUN_1405baa60)
void FUN_1405baa60(longlong param_1)

{
  FUN_1405baac0(param_1 + -8);
  return;
}

// ==== CPeerageActor@adapter::helper_1405baac0  @1405baac0  [medium:callgraph-r0]  (orig: FUN_1405baac0)
undefined8 * FUN_1405baac0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CPeerageActor::vftable;
  param_1[1] = adapter::CPeerageActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CPeerageActor@adapter::vfunc_7  @1405bab10  [high:rtti-vtable]  (orig: FUN_1405bab10)
void FUN_1405bab10(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_8  @1405bad70  [high:rtti-vtable]  (orig: FUN_1405bad70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405bad70(longlong param_1,longlong param_2,undefined4 param_3,undefined2 param_4)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_498 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4d8 = 0;
    local_4d0 = param_3;
    local_4c8 = param_4;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 != 0) {
      plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar2 + 0x68))(plVar2,local_488,0xffffffff);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CPeerageActor@adapter::vfunc_9  @1405bae40  [high:rtti-vtable]  (orig: FUN_1405bae40)
void FUN_1405bae40(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,0,0xfffffffffffffffe);
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_2);
  if (puVar1 != (undefined8 *)0x0) {
    if (lVar2 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x348))((longlong *)(lVar2 + 0x10),puVar1,1);
    }
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

