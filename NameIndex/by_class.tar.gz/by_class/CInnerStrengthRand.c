// ==== CInnerStrengthRand::ctor_or_dtor  @140402d70  [high:vtable-assign]  (orig: FUN_140402d70)
void FUN_140402d70(undefined8 *param_1)

{
  *param_1 = CInnerStrengthRand::vftable;
  FUN_1403f70e0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CInnerStrengthRand::ctor_or_dtor  @140402df0  [high:vtable-assign]  (orig: FUN_140402df0)
undefined8 * FUN_140402df0(undefined8 *param_1,uint param_2)

{
  *param_1 = CInnerStrengthRand::vftable;
  FUN_1403f70e0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CInnerStrengthRand::ctor_or_dtor  @140402e60  [high:vtable-assign]  (orig: FUN_140402e60)
undefined8 * FUN_140402e60(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x48);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CInnerStrengthRand::vftable;
    FUN_1403f7250(puVar1 + 1);
  }
  return puVar1;
}

