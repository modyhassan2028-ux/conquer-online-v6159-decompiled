// ==== CGoldenLeaguePoint::helper_1403b7d70  @1403b7d70  [medium:callgraph-r0]  (orig: FUN_1403b7d70)
void FUN_1403b7d70(void *param_1)

{
  if ((DAT_140976270 & 1) == 0) {
    DAT_140976270 = DAT_140976270 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976268,"CGoldenLeaguePoint");
    atexit((_func_5014 *)&LAB_1406d6c40);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b7dc5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976268,param_1);
  return;
}

// ==== CGoldenLeaguePoint::ctor_or_dtor  @1403b7e30  [high:vtable-assign]  (orig: FUN_1403b7e30)
undefined8 * FUN_1403b7e30(undefined8 *param_1,byte param_2)

{
  *param_1 = CGoldenLeaguePoint::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403b7d70();
  }
  return param_1;
}

// ==== CGoldenLeaguePoint::ctor_or_dtor  @1403b7e60  [high:vtable-assign]  (orig: FUN_1403b7e60)
undefined8 * FUN_1403b7e60(undefined4 param_1,undefined1 param_2)

{
  undefined8 *puVar1;
  
  if ((DAT_140976270 & 1) == 0) {
    DAT_140976270 = DAT_140976270 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976268,"CGoldenLeaguePoint");
    atexit((_func_5014 *)&LAB_1406d6c40);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976268,0x20);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CGoldenLeaguePoint::vftable;
    *(undefined1 *)(puVar1 + 1) = param_2;
    puVar1[2] = 0;
    *(undefined4 *)(puVar1 + 3) = param_1;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pLeaguePoint",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\goldenleaguepoint.cpp"
                       ,0x1c);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

