// ==== CMsgUserCityInfo::ctor_or_dtor  @14007d770  [high:vtable-assign]  (orig: FUN_14007d770)
undefined8 * FUN_14007d770(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgUserCityInfo::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgUserCityInfo::ctor_or_dtor  @14007d7c0  [high:vtable-assign]  (orig: FUN_14007d7c0)
void FUN_14007d7c0(undefined8 *param_1)

{
  *param_1 = CMsgUserCityInfo::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgUserCityInfo::vfunc_1  @14007d870  [high:rtti-vtable]  (orig: FUN_14007d870)
ulonglong FUN_14007d870(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x822);
}

// ==== CMsgUserCityInfo::vfunc_3  @14007d8a0  [high:rtti-vtable]  (orig: FUN_14007d8a0)
void FUN_14007d8a0(void)

{
  return;
}

// ==== CMsgUserCityInfo::ctor_or_dtor  @14007d8b0  [high:vtable-assign]  (orig: FUN_14007d8b0)
undefined8 * FUN_14007d8b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgUserCityInfo::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

