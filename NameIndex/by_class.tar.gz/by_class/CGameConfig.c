// ==== CGameConfig::helper_140007aa0  @140007aa0  [medium:callgraph-r3]  (orig: FUN_140007aa0)
void FUN_140007aa0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CGameConfig::helper_140007cf0  @140007cf0  [medium:callgraph-r3]  (orig: FUN_140007cf0)
void FUN_140007cf0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140007d14. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CGameConfig::helper_140008b00  @140008b00  [medium:callgraph-r3]  (orig: FUN_140008b00)
void FUN_140008b00(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CGameConfig::helper_140008b60  @140008b60  [medium:callgraph-r3]  (orig: FUN_140008b60)
void FUN_140008b60(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CGameConfig::helper_140008d40  @140008d40  [medium:callgraph-r3]  (orig: FUN_140008d40)
void FUN_140008d40(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x75) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x75) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x75);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x75);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x75);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x75);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140008d64. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CGameConfig::helper_140008ee0  @140008ee0  [medium:callgraph-r3]  (orig: FUN_140008ee0)
void FUN_140008ee0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x75) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CGameConfig::helper_140008f40  @140008f40  [medium:callgraph-r3]  (orig: FUN_140008f40)
void FUN_140008f40(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x75) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CGameConfig::helper_1400092d0  @1400092d0  [medium:callgraph-r3]  (orig: FUN_1400092d0)
void FUN_1400092d0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x10)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 << 4);
  return;
}

// ==== CGameConfig::helper_140009710  @140009710  [medium:callgraph-r3]  (orig: FUN_140009710)
undefined8 * FUN_140009710(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 2) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = *param_1;
      param_3[1] = param_1[1];
    }
    param_3 = param_3 + 2;
  }
  return param_3;
}

// ==== CGameConfig::helper_140009960  @140009960  [medium:callgraph-r1]  (orig: FUN_140009960)
void FUN_140009960(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140009960(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CGameConfig::helper_14000a020  @14000a020  [medium:callgraph-r1]  (orig: FUN_14000a020)
void FUN_14000a020(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x78);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x74) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x75) = 0;
  return;
}

// ==== CGameConfig::helper_14000a080  @14000a080  [medium:callgraph-r1]  (orig: FUN_14000a080)
void FUN_14000a080(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CGameConfig::helper_14000a6e0  @14000a6e0  [medium:callgraph-r3]  (orig: FUN_14000a6e0)
void FUN_14000a6e0(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
    }
    param_1 = param_1 + 2;
  }
  return;
}

// ==== CGameConfig::helper_14000a830  @14000a830  [medium:callgraph-r0]  (orig: FUN_14000a830)
void FUN_14000a830(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x21);
  while (cVar1 == '\0') {
    FUN_140009960(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CGameConfig::helper_14000b370  @14000b370  [medium:callgraph-r2]  (orig: FUN_14000b370)
undefined8 * FUN_14000b370(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140007cf0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14000b55c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14000b55c:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140008b00(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140008b60(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_140008b00(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140008b60(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140008b00(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_140008b60(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CGameConfig::helper_14000bac0  @14000bac0  [medium:callgraph-r3]  (orig: FUN_14000bac0)
longlong FUN_14000bac0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  if (param_1 != param_2) {
    lVar1 = param_2;
    do {
      lVar2 = lVar1 + -0x10;
      *(undefined8 *)((param_3 - param_2) + lVar2) = *(undefined8 *)(lVar1 + -0x10);
      *(undefined8 *)((param_3 - param_2) + 8 + lVar2) = *(undefined8 *)(lVar1 + -8);
      lVar1 = lVar2;
    } while (lVar2 != param_1);
  }
  return param_3 - (param_2 - param_1 & 0xfffffffffffffff0U);
}

// ==== CGameConfig::helper_14000c890  @14000c890  [medium:callgraph-r1]  (orig: FUN_14000c890)
longlong * FUN_14000c890(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14000a830(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14000b370(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CGameConfig::helper_14000dd20  @14000dd20  [medium:callgraph-r0]  (orig: FUN_14000dd20)
void FUN_14000dd20(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14000c890((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CGameConfig::helper_14000eab0  @14000eab0  [medium:callgraph-r2]  (orig: FUN_14000eab0)
void FUN_14000eab0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  undefined1 local_res8;
  undefined8 local_38;
  undefined8 local_30;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(longlong *)(param_1 + 0x28) - lVar4 >> 4;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar2 - lVar4 >> 4;
    if (0xfffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140007aa0();
    }
    uVar7 = param_3 + lVar4;
    if (uVar6 < uVar7) {
      if (0xfffffffffffffff - (uVar6 >> 1) < uVar6) {
        uVar6 = 0;
      }
      else {
        uVar6 = uVar6 + (uVar6 >> 1);
      }
      if (uVar6 < uVar7) {
        uVar6 = uVar7;
      }
      lVar2 = FUN_1400092d0(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      local_res8 = (undefined1)lVar2;
      FUN_14000a6e0(lVar4 * 0x10 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140009710(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_140009710(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x10 + lVar2,param_1 + 0x10,local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x10 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar4 - (longlong)pvVar1 >> 4)) * 0x10 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)(lVar2 - *(longlong *)(param_2 + 8) >> 4) < param_3) {
      local_38 = *param_4;
      local_30 = param_4[1];
      FUN_140009710(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x10,
                    param_1 + 0x10);
      FUN_14000a6e0(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4),
                    &local_38,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar5 = *(undefined8 **)(param_2 + 8); puVar5 != (undefined8 *)(lVar4 + param_3 * -0x10)
          ; puVar5 = puVar5 + 2) {
        *puVar5 = local_38;
        puVar5[1] = local_30;
      }
    }
    else {
      local_38 = *param_4;
      local_30 = param_4[1];
      lVar4 = lVar2 + param_3 * -0x10;
      uVar3 = FUN_140009710(lVar4,lVar2,lVar2,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14000bac0(*(undefined8 *)(param_2 + 8),lVar4,lVar2);
      puVar8 = *(undefined8 **)(param_2 + 8);
      puVar5 = puVar8 + param_3 * 2;
      for (; puVar8 != puVar5; puVar8 = puVar8 + 2) {
        *puVar8 = local_38;
        puVar8[1] = local_30;
      }
    }
  }
  return;
}

// ==== CGameConfig::helper_14000f020  @14000f020  [medium:callgraph-r0]  (orig: FUN_14000f020)
undefined8 * FUN_14000f020(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14000a080(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CGameConfig::helper_14000f4a0  @14000f4a0  [medium:callgraph-r1]  (orig: FUN_14000f4a0)
void FUN_14000f4a0(longlong *param_1,undefined8 param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong local_28;
  ulonglong uStack_20;
  undefined8 local_18;
  undefined8 local_10;
  
  local_18 = *param_3;
  puVar1 = (undefined8 *)param_1[4];
  local_10 = param_3[1];
  if (puVar1 < (undefined8 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  puVar2 = (undefined8 *)param_1[3];
  if ((undefined8 *)param_1[4] < puVar2) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((puVar1 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (puVar2 != puVar1) {
    puVar4 = (undefined8 *)param_1[4];
    puVar6 = puVar1;
    while (puVar6 != puVar4) {
      puVar7 = puVar6 + 2;
      *(undefined8 *)((longlong)puVar2 + (-0x10 - (longlong)puVar1) + (longlong)puVar7) = *puVar6;
      *(undefined8 *)((longlong)puVar2 + (-8 - (longlong)puVar1) + (longlong)puVar7) = puVar6[1];
      puVar6 = puVar7;
    }
    param_1[4] = ((longlong)puVar4 - (longlong)puVar1 & 0xfffffffffffffff0U) + (longlong)puVar2;
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar5;
  FUN_14000eab0(param_1,&local_28,param_2,&local_18);
  return;
}

// ==== CGameConfig::helper_14000fe40  @14000fe40  [medium:callgraph-r2]  (orig: FUN_14000fe40)
undefined8 * FUN_14000fe40(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined1 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 *puStack_a0;
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  undefined1 local_50 [16];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar6 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar6 + 0x75) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140008d40(param_3);
  plVar11 = (longlong *)*plVar6;
  if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar6[2] + 0x75) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar6) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar6;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar6[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar6[2];
          *(longlong **)(plVar6[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar6) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar3 = (undefined8 *)plVar6[1];
          if ((longlong *)*puVar3 == plVar6) {
            *puVar3 = plVar10;
          }
          else {
            puVar3[2] = plVar10;
          }
        }
        plVar10[1] = plVar6[1];
        puVar1 = (undefined1 *)((longlong)plVar6 + 0x74);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x74);
        if (puVar2 != puVar1) {
          uVar5 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar5;
        }
        goto LAB_14001002d;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar6[2];
  }
  plVar11 = (longlong *)plVar6[1];
  if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar6) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar6) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar6) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
      cVar4 = *(char *)(*plVar12 + 0x75);
      plVar7 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar7, cVar4 == '\0') {
        plVar7 = (longlong *)*plVar9;
        cVar4 = *(char *)((longlong)plVar7 + 0x75);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar6) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x75) == '\0') {
      cVar4 = *(char *)(plVar12[2] + 0x75);
      plVar7 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar7, cVar4 == '\0') {
        plVar7 = (longlong *)plVar9[2];
        cVar4 = *(char *)((longlong)plVar7 + 0x75);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_14001002d:
  if (*(char *)((longlong)plVar6 + 0x74) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x74) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x74) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x74) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x74) = 0;
            FUN_140008ee0(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
            if ((*(char *)(*plVar11 + 0x74) != '\x01') || (*(char *)(plVar11[2] + 0x74) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x74) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x74) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
                FUN_140008f40(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x74) = *(undefined1 *)((longlong)plVar10 + 0x74);
              *(undefined1 *)((longlong)plVar10 + 0x74) = 1;
              *(undefined1 *)(plVar11[2] + 0x74) = 1;
              FUN_140008ee0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x74) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x74) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x74) = 0;
            FUN_140008f40(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x75) == '\0') {
            if ((*(char *)(plVar11[2] + 0x74) != '\x01') || (*(char *)(*plVar11 + 0x74) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x74) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x74) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
                FUN_140008ee0(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x74) = *(undefined1 *)((longlong)plVar10 + 0x74);
              *(undefined1 *)((longlong)plVar10 + 0x74) = 1;
              *(undefined1 *)(*plVar11 + 0x74) = 1;
              FUN_140008f40(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x74) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x74) = 1;
  }
  puVar3 = (undefined8 *)((longlong)plVar6 + 0x34);
  puStack_a0 = *(undefined8 **)((longlong)plVar6 + 100);
  local_b8 = *puVar3;
  uStack_b0 = *puStack_a0;
  local_a8 = local_b8;
  FUN_14000bd50(puVar3,local_50,&local_b8,&local_a8);
  operator_delete(*(void **)((longlong)plVar6 + 100));
  *(undefined8 *)((longlong)plVar6 + 100) = 0;
  *(undefined8 *)((longlong)plVar6 + 0x6c) = 0;
  operator_delete((void *)*puVar3);
  operator_delete(plVar6);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CGameConfig::helper_140010310  @140010310  [medium:callgraph-r0]  (orig: FUN_140010310)
void FUN_140010310(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 local_18;
  undefined8 local_10;
  
  plVar1 = *(longlong **)(param_1 + 0x38);
  puVar3 = (undefined8 *)0x0;
  plVar2 = (longlong *)*plVar1;
  *plVar1 = (longlong)plVar1;
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  if (plVar2 != *(longlong **)(param_1 + 0x38)) {
    do {
      plVar1 = (longlong *)*plVar2;
      operator_delete(plVar2);
      plVar2 = plVar1;
    } while (plVar1 != (longlong *)*(longlong *)(param_1 + 0x38));
  }
  local_10 = *(undefined8 *)(param_1 + 0x38);
  if (*(undefined8 **)(param_1 + 0x10) != (undefined8 *)0x0) {
    puVar3 = (undefined8 *)**(undefined8 **)(param_1 + 0x10);
  }
  local_18 = *puVar3;
  FUN_14000f4a0(param_1 + 0x48,9,&local_18);
  *(undefined8 *)(param_1 + 0x78) = 7;
  *(undefined8 *)(param_1 + 0x80) = 8;
  return;
}

// ==== CGameConfig::helper_1400103b0  @1400103b0  [medium:callgraph-r0]  (orig: FUN_1400103b0)
longlong FUN_1400103b0(longlong param_1,undefined2 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *local_30;
  undefined8 local_28;
  
  uVar7 = 0xfffffffffffffffe;
  *(undefined2 *)(param_1 + 8) = *param_2;
  puVar1 = (undefined8 *)(param_1 + 0x10);
  local_30 = operator_new(8);
  plVar6 = (longlong *)0x0;
  plVar5 = plVar6;
  if (local_30 != (longlong *)0x0) {
    *local_30 = (longlong)puVar1;
    plVar5 = local_30;
  }
  *puVar1 = plVar5;
  uVar3 = FUN_140009f20(puVar1);
  *(undefined8 *)(param_1 + 0x38) = uVar3;
  *(undefined8 *)(param_1 + 0x40) = 0;
  puVar2 = (undefined8 *)(param_1 + 0x48);
  plVar4 = operator_new(8);
  plVar5 = plVar6;
  if (plVar4 != (longlong *)0x0) {
    *plVar4 = (longlong)puVar2;
    plVar5 = plVar4;
  }
  *puVar2 = plVar5;
  *(undefined8 *)(param_1 + 0x60) = 0;
  *(undefined8 *)(param_1 + 0x68) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0x40800000;
  local_28 = *(undefined8 *)(param_1 + 0x38);
  if ((undefined8 *)*puVar1 != (undefined8 *)0x0) {
    plVar6 = *(longlong **)*puVar1;
  }
  local_30 = (longlong *)*plVar6;
  FUN_14000f4a0(puVar2,9,&local_30,param_4,uVar7);
  *(undefined8 *)(param_1 + 0x78) = 7;
  *(undefined8 *)(param_1 + 0x80) = 8;
  return param_1;
}

// ==== CGameConfig::helper_1400104f0  @1400104f0  [medium:callgraph-r0]  (orig: FUN_1400104f0)
void FUN_1400104f0(undefined8 param_1,longlong *param_2)

{
  undefined8 *puVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  uVar5 = 0xfffffffffffffffe;
  cVar2 = *(char *)((longlong)param_2 + 0x75);
  while (cVar2 == '\0') {
    FUN_1400104f0(param_1,param_2[2]);
    plVar3 = (longlong *)*param_2;
    puVar1 = (undefined8 *)((longlong)param_2 + 0x34);
    puVar4 = *(undefined8 **)((longlong)param_2 + 100);
    local_58 = (undefined4)*puVar1;
    uStack_54 = (undefined4)((ulonglong)*puVar1 >> 0x20);
    uStack_50 = SUB84(puVar4,0);
    uStack_4c = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uStack_40 = (undefined4)*puVar4;
    uStack_3c = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_28 = local_58;
    uStack_24 = uStack_54;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    FUN_14000bd50(puVar1,local_18,&local_28,&local_38,uVar5);
    operator_delete(*(void **)((longlong)param_2 + 100));
    *(undefined8 *)((longlong)param_2 + 100) = 0;
    *(undefined8 *)((longlong)param_2 + 0x6c) = 0;
    operator_delete((void *)*puVar1);
    operator_delete(param_2);
    param_2 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x75);
  }
  return;
}

// ==== CGameConfig::helper_140010c60  @140010c60  [medium:callgraph-r1]  (orig: FUN_140010c60)
longlong * FUN_140010c60(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400104f0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x75) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x75) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x75);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x75);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x75);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x75);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14000fe40(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CGameConfig::helper_1400111e0  @1400111e0  [medium:callgraph-r0]  (orig: FUN_1400111e0)
void FUN_1400111e0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140010c60((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CGameConfig::ctor_or_dtor  @140011510  [high:vtable-assign]  (orig: FUN_140011510)
void FUN_140011510(undefined8 *param_1)

{
  *param_1 = CGameConfig::vftable;
  if ((void *)param_1[0x40] != (void *)0x0) {
    operator_delete((void *)param_1[0x40]);
  }
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  operator_delete((void *)param_1[0x3d]);
  FUN_14000dd20(param_1 + 0x25);
  operator_delete((void *)param_1[0x25]);
  FUN_14000dd20(param_1 + 0x1c);
  operator_delete((void *)param_1[0x1c]);
  FUN_1400111e0(param_1 + 0x14);
  operator_delete((void *)param_1[0x14]);
  if ((void *)param_1[0xe] != (void *)0x0) {
    operator_delete((void *)param_1[0xe]);
  }
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  operator_delete((void *)param_1[0xb]);
  FUN_14000c380(param_1 + 4);
  return;
}

// ==== CGameConfig::helper_140012bc0  @140012bc0  [medium:callgraph-r0]  (orig: FUN_140012bc0)
undefined8 * FUN_140012bc0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14000a020(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x75) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CGameConfig::ctor_or_dtor  @140012c40  [high:vtable-assign]  (orig: FUN_140012c40)
undefined8 *
FUN_140012c40(undefined8 *param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *local_res18;
  longlong *local_res20;
  
  *param_1 = CGameConfig::vftable;
  puVar1 = param_1 + 2;
  FUN_1400103b0(puVar1,&local_res20,&local_res18,param_4,0xfffffffffffffffe,puVar1);
  FUN_140012bc0(param_1 + 0x14);
  FUN_14000f020(param_1 + 0x1c);
  plVar3 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  FUN_14000f020(param_1 + 0x25);
  *(undefined4 *)(param_1 + 0x2d) = 0;
  *(undefined4 *)((longlong)param_1 + 0x16c) = 0;
  *(undefined4 *)(param_1 + 0x2e) = 0;
  *(undefined4 *)((longlong)param_1 + 0x174) = 0;
  *(undefined4 *)(param_1 + 0x2f) = 0;
  *(undefined4 *)((longlong)param_1 + 0x17c) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
  *(undefined4 *)((longlong)param_1 + 0x184) = 0;
  *(undefined4 *)(param_1 + 0x31) = 0;
  *(undefined4 *)((longlong)param_1 + 0x18c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1bc) = 0x14;
  *(undefined4 *)(param_1 + 0x38) = 0x55;
  *(undefined4 *)((longlong)param_1 + 0x1c4) = 0x37;
  *(undefined4 *)(param_1 + 0x39) = 0x3ea;
  *(undefined4 *)((longlong)param_1 + 0x1cc) = 0x157;
  *(undefined4 *)(param_1 + 0x3a) = 0x1a9;
  puVar2 = param_1 + 0x3d;
  local_res18 = puVar2;
  local_res20 = operator_new(8);
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)puVar2;
    plVar3 = local_res20;
  }
  *puVar2 = plVar3;
  param_1[0x40] = 0;
  param_1[0x41] = 0;
  param_1[0x42] = 0;
  *(undefined4 *)((longlong)param_1 + 0x224) = 1000;
  *(undefined4 *)(param_1 + 0x45) = 10;
  *(undefined4 *)((longlong)param_1 + 0x22c) = 2;
  *(undefined4 *)(param_1 + 0x46) = 0x46;
  *(undefined4 *)((longlong)param_1 + 0x234) = 0;
  *(undefined4 *)(param_1 + 0x47) = 0;
  *(undefined4 *)((longlong)param_1 + 0x23c) = 0;
  *(undefined4 *)(param_1 + 0x48) = 0;
  *(undefined4 *)((longlong)param_1 + 0x244) = 0;
  *(undefined4 *)(param_1 + 0x49) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24c) = 0;
  *(undefined4 *)(param_1 + 0x4a) = 0;
  *(undefined4 *)((longlong)param_1 + 0x254) = 0;
  *(undefined4 *)(param_1 + 0x4b) = 0;
  *(undefined4 *)((longlong)param_1 + 0x25c) = 0;
  *(undefined4 *)(param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_14000a830(param_1 + 0x1c);
  FUN_14000a830(param_1 + 0x25);
  FUN_140010310(puVar1);
  FUN_1400104f0(param_1 + 0x14,*(undefined8 *)(param_1[0x1a] + 8));
  *(undefined8 *)(param_1[0x1a] + 8) = param_1[0x1a];
  param_1[0x1b] = 0;
  *(undefined8 *)param_1[0x1a] = param_1[0x1a];
  *(undefined8 *)(param_1[0x1a] + 0x10) = param_1[0x1a];
  *(undefined4 *)((longlong)param_1 + 0x174) = 0x3ea;
  *(undefined4 *)(param_1 + 0x2f) = 300;
  *(undefined4 *)((longlong)param_1 + 0x17c) = 0x120;
  *(undefined4 *)(param_1 + 0x30) = 0x3ea;
  *(undefined4 *)((longlong)param_1 + 0x184) = 0x201;
  *(undefined4 *)(param_1 + 0x31) = 0x2ee;
  param_1[0x32] = 9900000000;
  *(undefined4 *)(param_1 + 0x33) = 10000000;
  *(undefined4 *)((longlong)param_1 + 0x19c) = 2;
  *(undefined4 *)(param_1 + 0x34) = 0x46;
  *(undefined4 *)(param_1 + 0x35) = 5;
  *(undefined4 *)(param_1 + 0x36) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x37) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1ac) = 0x3ea;
  *(undefined4 *)((longlong)param_1 + 0x1a4) = 0xb4;
  *(undefined4 *)((longlong)param_1 + 0x1d4) = 0;
  *(undefined4 *)(param_1 + 0x3b) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1dc) = 0;
  *(undefined4 *)(param_1 + 0x3c) = 300;
  *(undefined4 *)((longlong)param_1 + 0x1e4) = 0x120;
  *(undefined4 *)(param_1 + 0x43) = 0;
  *(undefined4 *)((longlong)param_1 + 0x21c) = 0;
  *(undefined4 *)(param_1 + 0x44) = 0;
  return param_1;
}

// ==== CGameConfig::vfunc_0  @140012f60  [high:rtti-vtable]  (orig: FUN_140012f60)
void * FUN_140012f60(void *param_1,uint param_2)

{
  FUN_140011510();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

