// ==== CUserFateProtect::helper_140156ce0  @140156ce0  [medium:callgraph-r0]  (orig: FUN_140156ce0)
longlong * FUN_140156ce0(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(byte *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserFateProtect::helper_14047bcd0  @14047bcd0  [medium:callgraph-r0]  (orig: FUN_14047bcd0)
int FUN_14047bcd0(undefined8 param_1,int param_2)

{
  __time64_t _Var1;
  tm *ptVar2;
  longlong local_res18 [2];
  
  if (param_2 != 0) {
    _Var1 = _time64((__time64_t *)0x0);
    local_res18[0] = _Var1 + (ulonglong)(uint)(param_2 * 0xe10);
    ptVar2 = _localtime64(local_res18);
    if (ptVar2 != (tm *)0x0) {
      return (((((ptVar2->tm_year + 0x76c) % 100) * 100 + 1 + ptVar2->tm_mon) * 100 +
              ptVar2->tm_mday) * 100 + ptVar2->tm_hour) * 100 + ptVar2->tm_min;
    }
  }
  return 0;
}

// ==== CUserFateProtect::helper_14047be20  @14047be20  [medium:callgraph-r0]  (orig: FUN_14047be20)
int FUN_14047be20(undefined8 param_1,int param_2,int param_3)

{
  tm *ptVar1;
  longlong local_res20;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_res20 = FUN_14047bd60();
    local_res20 = local_res20 + (ulonglong)(uint)(param_3 * 0xe10);
    if (0 < local_res20) {
      ptVar1 = _localtime64(&local_res20);
      if (ptVar1 != (tm *)0x0) {
        return (((((ptVar1->tm_year + 0x76c) % 100) * 100 + 1 + ptVar1->tm_mon) * 100 +
                ptVar1->tm_mday) * 100 + ptVar1->tm_hour) * 100 + ptVar1->tm_min;
      }
    }
  }
  return 0;
}

// ==== CUserFateProtect::helper_14047bf70  @14047bf70  [medium:callgraph-r0]  (orig: FUN_14047bf70)
void FUN_14047bf70(void *param_1)

{
  if ((DAT_1409764a8 & 1) == 0) {
    DAT_1409764a8 = DAT_1409764a8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764a0,"CUserFateProtect");
    atexit((_func_5014 *)&LAB_1406d6eb0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014047bfc5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409764a0,param_1);
  return;
}

// ==== CUserFateProtect::ProtectFateAttrib  @14047cbc0  [high:log-string]  (orig: FUN_14047cbc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14047cbc0(longlong param_1,longlong param_2,undefined1 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
             char param_9)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined1 local_4b8 [8];
  longlong *local_4b0;
  undefined1 local_4a8;
  undefined7 uStack_4a7;
  longlong *local_4a0;
  undefined8 local_498;
  undefined1 local_490 [24];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (param_2 == 0) {
    return 0;
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  local_4b8[0] = param_3;
  FUN_140156ce0(plVar1,&local_4a8,local_4b8);
  local_4b0 = *(longlong **)(param_1 + 0x40);
  plVar5 = (longlong *)CONCAT71(uStack_4a7,local_4a8);
  if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  plVar6 = local_4a0;
  if (local_4a0 == local_4b0) {
    plVar5 = (longlong *)InstanceGet();
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,"cq_fate_protect");
    if (plVar5 == (longlong *)0x0) {
      local_4c0 = param_7;
      local_4c8 = param_6;
      log_InlineLogERROR(
                        "CUserFateProtect::ProtectFateAttrib() MakeDefRecord, fateno(%u), attribvalue1(%u), attribvalue2(%u), attribvalue3(%u), attribvalue4(%u)"
                        );
      return 0;
    }
    iVar3 = FUN_14047bcd0(param_1,param_8);
    local_4b0 = (longlong *)CONCAT44(local_4b0._4_4_,iVar3);
    if (iVar3 == 0) {
      local_4c0 = param_7;
      local_4c8 = param_6;
      log_InlineLogERROR(
                        "CUserFateProtect::ProtectFateAttrib() CalcExpirationDate, fateno(%u), attribvalue1(%u), attribvalue2(%u), attribvalue3(%u), attribvalue4(%u)"
                        );
      (**(code **)*plVar5)(plVar5,1);
      return 0;
    }
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,1);
    (**(code **)(*plVar6 + 0xb8))(plVar6,*(undefined4 *)(param_1 + 0xc));
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,2);
    (**(code **)(*plVar6 + 0xd8))(plVar6,param_3);
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,3);
    (**(code **)(*plVar6 + 0xa8))(plVar6,(ulonglong)local_4b0 & 0xffffffff);
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
    (**(code **)(*plVar6 + 0xa8))(plVar6,param_4);
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,5);
    (**(code **)(*plVar6 + 0xa8))(plVar6,param_5);
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,6);
    (**(code **)(*plVar6 + 0xa8))(plVar6,param_6);
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,7);
    (**(code **)(*plVar6 + 0xa8))(plVar6,param_7);
    cVar2 = (**(code **)(*plVar5 + 0x50))(plVar5,1);
    if (cVar2 == '\0') {
      local_4c0 = param_7;
      local_4c8 = param_6;
      log_InlineLogERROR(
                        "CUserFateProtect::ProtectFateAttrib() insert, fateno(%u), attribvalue1(%u), attribvalue2(%u), attribvalue3(%u), attribvalue4(%u)"
                        );
      (**(code **)*plVar5)(plVar5,1);
      return 0;
    }
    local_4a8 = param_3;
    local_4a0 = plVar5;
    FUN_140156b30(plVar1,local_490,&local_4a8);
  }
  else {
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar5;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = (longlong *)plVar6[4];
    if (plVar1 == (longlong *)0x0) {
      local_4c8 = 0xfa;
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    plVar5 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,3);
    uVar4 = (**(code **)(*plVar5 + 0x50))(plVar5);
    iVar3 = FUN_14047be20(param_1,uVar4,param_8);
    if (iVar3 == 0) {
      local_4c0 = param_7;
      local_4c8 = param_6;
      log_InlineLogERROR(
                        "CUserFateProtect::ProtectFateAttrib() update expiry date, fateno(%u), attribvalue1(%u), attribvalue2(%u), attribvalue3(%u), attribvalue4(%u)"
                        );
      return 0;
    }
    plVar5 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,3);
    (**(code **)(*plVar5 + 0xa8))(plVar5,iVar3);
    cVar2 = (**(code **)(*plVar1 + 0x38))(plVar1,0);
    if (cVar2 == '\0') {
      local_4c0 = param_7;
      local_4c8 = param_6;
      log_InlineLogERROR(
                        "CUserFateProtect::ProtectFateAttrib() update, fateno(%u), attribvalue1(%u), attribvalue2(%u), attribvalue3(%u), attribvalue4(%u)"
                        );
      return 0;
    }
  }
  uVar8 = 2;
  if (param_9 != '\0') {
    uVar8 = 0xf;
  }
  FUN_140450dc0(local_478);
  cVar2 = FUN_140450e80(local_478,param_3,uVar8);
  if (cVar2 != '\0') {
    (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478);
  }
  FUN_140450e10(local_478);
  return 1;
}

// ==== CUserFateProtect::DelayExpiryDate  @14047d2d0  [high:log-string]  (orig: FUN_14047d2d0)
undefined8 FUN_14047d2d0(longlong param_1,byte param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar3 = *(char *)((longlong)puVar9 + 0x29);
  puVar1 = *(undefined8 **)(param_1 + 0x40);
  while (cVar3 == '\0') {
    if (*(byte *)(puVar9 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar9[2];
      puVar9 = puVar1;
    }
    else {
      puVar6 = (undefined8 *)*puVar9;
    }
    puVar1 = puVar9;
    puVar9 = puVar6;
    cVar3 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  local_40 = puVar1;
  local_48 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar1 == puVar9) || (param_2 < *(byte *)(puVar1 + 3))) {
    plVar8 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar8 = &local_48;
  }
  plVar7 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x40);
  local_28 = plVar7;
  local_20 = plVar8[1];
  if ((plVar7 == (longlong *)0x0) || (plVar7 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_20;
  if (local_20 != lVar10) {
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar7;
    }
    if (lVar2 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar8 = *(longlong **)(lVar2 + 0x20);
    if (plVar8 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,3);
      uVar4 = (**(code **)(*plVar7 + 0x50))(plVar7);
      iVar5 = FUN_14047be20(param_1,uVar4,param_3);
      if (iVar5 == 0) {
        log_InlineLogERROR(
                          "CUserFateProtect::DelayExpiryDate(), userid(%u), fateno(%u) calculate delay date failed"
                          );
        return 0;
      }
      plVar7 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,3);
      (**(code **)(*plVar7 + 0xa8))(plVar7,iVar5);
      cVar3 = (**(code **)(*plVar8 + 0x38))(plVar8,0);
      if (cVar3 == '\0') {
        log_InlineLogERROR(
                          "CUserFateProtect::DelayExpiryDate(), userid(%u), fateno(%u) update sql failed."
                          );
        return 0;
      }
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CUserFateProtect::DelayExpiryDateFromCurrDate  @14047d4a0  [high:log-string]  (orig: FUN_14047d4a0)
undefined8 FUN_14047d4a0(longlong param_1,byte param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar3 = *(char *)((longlong)puVar8 + 0x29);
  puVar1 = *(undefined8 **)(param_1 + 0x40);
  while (cVar3 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar1;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar1 = puVar8;
    puVar8 = puVar5;
    cVar3 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_40 = puVar1;
  local_48 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar1 == puVar8) || (param_2 < *(byte *)(puVar1 + 3))) {
    plVar7 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_48;
  }
  plVar6 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_28 = plVar6;
  local_20 = plVar7[1];
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_20;
  if (local_20 != lVar9) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar6;
    }
    if (lVar2 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)(lVar2 + 0x20);
    if (plVar7 != (longlong *)0x0) {
      iVar4 = FUN_14047bcd0(param_1,param_3);
      if (iVar4 == 0) {
        log_InlineLogERROR(
                          "CUserFateProtect::DelayExpiryDateFromCurrDate(), userid(%u), fateno(%u) calculate expiry date failed"
                          );
        return 0;
      }
      plVar6 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
      (**(code **)(*plVar6 + 0xa8))(plVar6,iVar4);
      cVar3 = (**(code **)(*plVar7 + 0x38))(plVar7,0);
      if (cVar3 == '\0') {
        log_InlineLogERROR(
                          "CUserFateProtect::DelayExpiryDateFromCurrDate(), userid(%u), fateno(%u) update sql failed."
                          );
        return 0;
      }
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CUserFateProtect::ctor_or_dtor  @14047db70  [high:vtable-assign]  (orig: FUN_14047db70)
void FUN_14047db70(undefined8 *param_1)

{
  *param_1 = CUserFateProtect::vftable;
  FUN_140157090(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CUserFateProtect::ctor_or_dtor  @14047dbb0  [high:vtable-assign]  (orig: FUN_14047dbb0)
undefined8 * FUN_14047dbb0(undefined8 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = CUserFateProtect::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  *(undefined4 *)((longlong)param_1 + 0xc) = param_3;
  FUN_140159140(param_1 + 2);
  FUN_1401543a0(param_1 + 2);
  return param_1;
}

// ==== CUserFateProtect::ctor_or_dtor  @14047dc00  [high:vtable-assign]  (orig: FUN_14047dc00)
undefined8 * FUN_14047dc00(undefined8 *param_1,uint param_2)

{
  *param_1 = CUserFateProtect::vftable;
  FUN_140157090(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    FUN_14047bf70(param_1);
  }
  return param_1;
}

// ==== CUserFateProtect::ctor_or_dtor  @14047dc70  [high:vtable-assign]  (orig: FUN_14047dc70)
undefined8 * FUN_14047dc70(undefined4 param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  
  if ((DAT_1409764a8 & 1) == 0) {
    DAT_1409764a8 = DAT_1409764a8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764a0,"CUserFateProtect");
    atexit((_func_5014 *)&LAB_1406d6eb0);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409764a0,0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CUserFateProtect::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
    *(undefined4 *)((longlong)puVar1 + 0xc) = param_2;
    FUN_140159140(puVar1 + 2);
    FUN_1401543a0(puVar1 + 2);
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pUserFateProtect",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\trainingvitality\\userfateprotect.cpp"
                       ,0x1e);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

