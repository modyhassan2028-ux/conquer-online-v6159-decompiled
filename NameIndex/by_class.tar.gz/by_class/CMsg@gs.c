// ==== CMsg@gs::vfunc_5  @14035cf40  [high:rtti-vtable]  (orig: FUN_14035cf40)
void FUN_14035cf40(void)

{
  return;
}

// ==== CMsg@gs::vfunc_3  @14035cf50  [high:rtti-vtable]  (orig: FUN_14035cf50)
void FUN_14035cf50(void)

{
  return;
}

// ==== CMsg@gs::vfunc_0  @14035cf60  [high:rtti-vtable]  (orig: FUN_14035cf60)
undefined8 * FUN_14035cf60(undefined8 *param_1,byte param_2)

{
  *param_1 = gs::CMsg::vftable;
  *param_1 = tq::CMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

