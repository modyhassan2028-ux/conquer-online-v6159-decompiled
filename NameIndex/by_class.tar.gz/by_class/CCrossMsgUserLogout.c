// ==== CCrossMsgUserLogout::helper_1402b3820  @1402b3820  [medium:callgraph-r0]  (orig: FUN_1402b3820)
void FUN_1402b3820(longlong param_1,int param_2,int param_3,undefined4 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *local_c8;
  longlong local_c0;
  longlong *local_b8 [3];
  void *local_a0;
  undefined8 local_98;
  undefined8 local_90;
  longlong local_88;
  undefined8 local_80;
  longlong local_78;
  undefined8 *local_70;
  undefined8 local_68;
  longlong *local_60;
  longlong local_58 [6];
  
  if ((param_2 != 0) && (local_68 = 0xfffffffffffffffe, param_3 != 0)) {
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
    cVar1 = *(char *)((longlong)puVar8 + 0x31);
    puVar4 = *(undefined8 **)(param_1 + 0x108);
    while (cVar1 == '\0') {
      if ((ulonglong)puVar8[3] < CONCAT44(param_2,param_3)) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar4;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar4 = puVar8;
      puVar8 = puVar6;
      cVar1 = *(char *)((longlong)puVar6 + 0x31);
    }
    local_70 = puVar4;
    local_78 = *(longlong *)(param_1 + 0xd8);
    puVar8 = *(undefined8 **)(param_1 + 0x108);
    if (*(longlong *)(param_1 + 0xd8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar4 == puVar8) || (CONCAT44(param_2,param_3) < (ulonglong)puVar4[3])) {
      local_80 = *(undefined8 *)(param_1 + 0x108);
      local_88 = *(longlong *)(param_1 + 0xd8);
      plVar9 = &local_88;
    }
    else {
      plVar9 = &local_78;
    }
    plVar2 = (longlong *)*plVar9;
    local_c0 = plVar9[1];
    lVar3 = *(longlong *)(param_1 + 0x108);
    local_c8 = plVar2;
    if ((*(longlong **)(param_1 + 0xd8) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0xd8) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    lVar5 = local_c0;
    if (lVar3 != local_c0) {
      local_c8 = operator_new(8);
      plVar11 = (longlong *)0x0;
      local_b8[0] = plVar11;
      if (local_c8 != (longlong *)0x0) {
        *local_c8 = (longlong)local_b8;
        local_b8[0] = local_c8;
      }
      local_a0 = (void *)0x0;
      local_98 = 0;
      local_90 = 0;
      local_60 = local_c8;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar11;
      }
      else {
        plVar10 = (longlong *)*plVar2;
      }
      if (lVar5 == plVar10[6]) {
        _invalid_parameter_noinfo();
      }
      FUN_140037fe0(local_b8,lVar5 + 0x28);
      local_c8 = local_58;
      uVar7 = FUN_140043260(local_58,local_b8);
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar11;
      }
      else {
        plVar10 = (longlong *)*plVar2;
      }
      if (lVar5 == plVar10[6]) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        plVar11 = (longlong *)*plVar2;
      }
      if (lVar5 == plVar11[6]) {
        _invalid_parameter_noinfo();
      }
      FUN_1402b3560(param_1,uVar7,param_4,*(undefined1 *)(lVar5 + 0x2c),1,
                    *(undefined1 *)(lVar5 + 0x2d));
      local_c8 = (longlong *)*plVar9;
      local_c0 = plVar9[1];
      FUN_1402acd70(param_1 + 0xd8,&local_88,&local_c8);
      if (local_a0 != (void *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (void *)0x0;
      local_98 = 0;
      local_90 = 0;
      operator_delete(local_b8[0]);
    }
  }
  return;
}

// ==== CCrossMsgUserLogout::ctor_or_dtor  @14044ec50  [high:vtable-assign]  (orig: FUN_14044ec50)
undefined8 * FUN_14044ec50(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgUserLogout::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgUserLogout::ctor_or_dtor  @14044eca0  [high:vtable-assign]  (orig: FUN_14044eca0)
void FUN_14044eca0(undefined8 *param_1)

{
  *param_1 = CCrossMsgUserLogout::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgUserLogout::vfunc_1  @14044ecd0  [high:rtti-vtable]  (orig: FUN_14044ecd0)
ulonglong FUN_14044ecd0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c52);
}

// ==== CCrossMsgUserLogout::ctor_or_dtor  @14044ed80  [high:vtable-assign]  (orig: FUN_14044ed80)
undefined8 * FUN_14044ed80(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgUserLogout::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgUserLogout::vfunc_3  @14044edd0  [high:rtti-vtable]  (orig: FUN_14044edd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14044edd0(longlong param_1)

{
  undefined4 uVar1;
  short *psVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  ushort *puVar7;
  uint uVar8;
  longlong lVar9;
  int iVar10;
  undefined1 auStack_478 [32];
  int *local_458;
  int local_448;
  undefined4 local_444;
  undefined4 auStack_440 [262];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  puVar7 = *(ushort **)(param_1 + 0x428);
  if (puVar7 == (ushort *)0x0) {
    local_458 = (int *)CONCAT44(local_458._4_4_,0x45);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*puVar7 < 2) {
    if (0 < *(int *)(puVar7 + 4)) {
      local_448 = 0;
      local_444 = *(undefined4 *)(puVar7 + 2);
      if (0 < *(int *)(puVar7 + 4)) {
        lVar9 = 0xc;
        plVar6 = (longlong *)0x0;
        do {
          uVar3 = FUN_140008520(0xe);
          plVar4 = (longlong *)FUN_140087650(uVar3);
          lVar5 = (**(code **)(*plVar4 + 0x98))
                            (plVar4,*(undefined4 *)(lVar9 + *(longlong *)(param_1 + 0x428)));
          if (lVar5 != 0) {
            if (0x418 < (longlong)local_448 * 4 + 0xcU) {
              log_InlineLogERROR(&DAT_14077cba8);
              uVar3 = FUN_140008520(0xe);
              plVar4 = (longlong *)FUN_14001b560(uVar3);
              local_458 = &local_448;
              (**(code **)(*plVar4 + 0x50))(plVar4,6,0x3f0);
              local_448 = 0;
            }
            auStack_440[local_448] = *(undefined4 *)(lVar9 + *(longlong *)(param_1 + 0x428));
            local_448 = local_448 + 1;
          }
          uVar8 = (int)plVar6 + 1;
          plVar6 = (longlong *)(ulonglong)uVar8;
          lVar9 = lVar9 + 4;
        } while ((int)uVar8 < *(int *)(*(longlong *)(param_1 + 0x428) + 8));
      }
      lVar9 = FUN_140008520(0xe);
      plVar6 = *(longlong **)(lVar9 + 0x80);
      if (plVar6 == (longlong *)0x0) {
        local_458 = (int *)CONCAT44(local_458._4_4_,0x140);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = (longlong *)0x0;
      }
      local_458 = &local_448;
      (**(code **)(*plVar6 + 0x50))(plVar6,6,0x3f0);
      psVar2 = *(short **)(param_1 + 0x428);
      if (*psVar2 == 1) {
        *psVar2 = 3;
        plVar6 = (longlong *)FUN_140008520(0xe);
        (**(code **)(*plVar6 + 0x18))(plVar6,*(undefined4 *)(param_1 + 0x41c),param_1);
      }
      else {
        *psVar2 = 2;
        plVar6 = (longlong *)FUN_140008520(0xe);
        (**(code **)(*plVar6 + 8))(plVar6,param_1);
      }
    }
  }
  else if ((*puVar7 == 3) && (iVar10 = 0, 0 < *(int *)(puVar7 + 4))) {
    lVar9 = 0xc;
    do {
      if (*(int *)(lVar9 + (longlong)puVar7) != 0) {
        uVar1 = *(undefined4 *)(param_1 + 0x41c);
        lVar5 = *(longlong *)(param_1 + 0x428);
        uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar3 = FUN_140087650(uVar3);
        FUN_1402b3820(uVar3,uVar1,*(undefined4 *)(lVar9 + lVar5),*(undefined4 *)(lVar5 + 4));
      }
      puVar7 = *(ushort **)(param_1 + 0x428);
      iVar10 = iVar10 + 1;
      lVar9 = lVar9 + 4;
    } while (iVar10 < *(int *)(puVar7 + 4));
  }
  return;
}

