// ==== CItemLimitMgr::helper_14026b290  @14026b290  [medium:callgraph-r1]  (orig: FUN_14026b290)
void FUN_14026b290(longlong param_1)

{
  undefined4 local_res8 [8];
  undefined1 local_28 [32];
  
  param_1 = param_1 + 0x50;
  FUN_14000a7b0(param_1);
  local_res8[0] = 0x642bd;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x64321;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x64385;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x643e9;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x6444d;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x644b1;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x64515;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x669cd;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x66db5;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x7a24d;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x7cd45;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x89095;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x92cd5;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x94ffd;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x953e5;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x957cd;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x95bb5;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x95f9d;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x9676d;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x96b55;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 150000;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x24b26;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x24b30;
  FUN_14000d480(param_1,local_28,local_res8);
  return;
}

// ==== CItemLimitMgr::helper_14026b500  @14026b500  [medium:callgraph-r1]  (orig: FUN_14026b500)
void FUN_14026b500(longlong param_1)

{
  undefined4 local_res8 [8];
  undefined1 local_28 [32];
  
  param_1 = param_1 + 0x90;
  FUN_14000a7b0(param_1);
  local_res8[0] = 0x24b26;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x24b30;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203b7;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203b8;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203b9;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203ba;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203bb;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203bc;
  FUN_14000d480(param_1,local_28,local_res8);
  local_res8[0] = 0x203bd;
  FUN_14000d480(param_1,local_28,local_res8);
  return;
}

// ==== CItemLimitMgr::ctor_or_dtor  @14026b700  [high:vtable-assign]  (orig: FUN_14026b700)
void FUN_14026b700(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CItemLimitMgr::vftable;
  puVar1 = param_1 + 2;
  FUN_14009f560(puVar1);
  FUN_14000c310(param_1 + 0x12);
  operator_delete((void *)param_1[0x12]);
  FUN_14000c310(param_1 + 10);
  operator_delete((void *)param_1[10]);
  FUN_1400a9720(puVar1);
  operator_delete((void *)*puVar1);
  return;
}

// ==== CItemLimitMgr::helper_14026b7a0  @14026b7a0  [medium:callgraph-r0]  (orig: FUN_14026b7a0)
undefined8 FUN_14026b7a0(longlong param_1)

{
  undefined4 uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  int iVar6;
  undefined4 local_res18;
  undefined4 local_res1c;
  longlong *local_res20;
  undefined8 uVar7;
  undefined1 local_40 [24];
  
  uVar7 = 0xfffffffffffffffe;
  plVar2 = (longlong *)InstanceGet();
  plVar2 = (longlong *)
           (**(code **)(*plVar2 + 0x10))(plVar2,"SELECT * FROM cq_item_limit",1,*plVar2,uVar7);
  uVar7 = 0;
  if (plVar2 != (longlong *)0x0) {
    iVar6 = 0;
    local_res20 = plVar2;
    while( true ) {
      uVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
      if (uVar3 <= (ulonglong)(longlong)iVar6) break;
      (**(code **)(*plVar2 + 0x30))(plVar2,(longlong)iVar6);
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x38))(plVar2);
      if (plVar4 != (longlong *)0x0) {
        plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,1);
        uVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,2);
        local_res1c = (**(code **)(*plVar5 + 0x48))(plVar5);
        local_res18 = uVar1;
        FUN_1400a85a0(param_1 + 0x10,local_40,&local_res18);
        (**(code **)*plVar4)(plVar4,1);
      }
      iVar6 = iVar6 + 1;
    }
    (**(code **)*plVar2)(plVar2);
    FUN_14026b290(param_1);
    FUN_14026b500(param_1);
    uVar7 = 1;
  }
  return uVar7;
}

// ==== CItemLimitMgr::ctor_or_dtor  @14026b8e0  [high:vtable-assign]  (orig: FUN_14026b8e0)
undefined8 * FUN_14026b8e0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CItemLimitMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1400b8550(param_1 + 2);
  FUN_14000ef40(param_1 + 10);
  FUN_14000ef40(param_1 + 0x12);
  FUN_14009f560(param_1 + 2);
  return param_1;
}

// ==== CItemLimitMgr::vfunc_0  @14026b950  [high:rtti-vtable]  (orig: FUN_14026b950)
void * FUN_14026b950(void *param_1,uint param_2)

{
  FUN_14026b700();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CItemLimitMgr::ctor_or_dtor  @14026b980  [high:vtable-assign]  (orig: FUN_14026b980)
undefined8 *
FUN_14026b980(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar2 = operator_new(0xd0);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CItemLimitMgr::vftable;
    *(undefined4 *)(puVar2 + 1) = param_1;
    FUN_1400b8550(puVar2 + 2);
    FUN_14000ef40(puVar2 + 10);
    FUN_14000ef40(puVar2 + 0x12);
    FUN_14009f560(puVar2 + 2);
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_14026b7a0(puVar2);
    if (cVar1 == '\0') {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,uVar3);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

