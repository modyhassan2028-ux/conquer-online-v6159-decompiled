// ==== COperatingUserInfo::helper_14032a670  @14032a670  [medium:callgraph-r0]  (orig: FUN_14032a670)
void FUN_14032a670(void *param_1)

{
  if ((DAT_140976040 & 1) == 0) {
    DAT_140976040 = DAT_140976040 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976038,"COperatingUserInfo");
    atexit((_func_5014 *)&LAB_1406d6a70);
  }
                    /* WARNING: Could not recover jumptable at 0x00014032a6c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976038,param_1);
  return;
}

// ==== COperatingUserInfo::ctor_or_dtor  @14032a730  [high:vtable-assign]  (orig: FUN_14032a730)
void FUN_14032a730(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = COperatingUserInfo::vftable;
  if ((param_1[2] != 0) && (param_1[2] != 0)) {
    (*(code *)**(undefined8 **)param_1[2])
              ((undefined8 *)param_1[2],1,param_3,param_4,0xfffffffffffffffe);
    param_1[2] = 0;
  }
  return;
}

// ==== COperatingUserInfo::ctor_or_dtor  @14032a780  [high:vtable-assign]  (orig: FUN_14032a780)
undefined8 * FUN_14032a780(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140976040 & 1) == 0) {
    DAT_140976040 = DAT_140976040 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976038,"COperatingUserInfo");
    atexit((_func_5014 *)&LAB_1406d6a70);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976038,0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = COperatingUserInfo::vftable;
    *(undefined4 *)(puVar1 + 1) = 0;
    puVar1[2] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pOperatingUserInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\operatingact\\operatinguserinfo.cpp"
                       ,0x21);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

// ==== COperatingUserInfo::vfunc_0  @14032aab0  [high:rtti-vtable]  (orig: FUN_14032aab0)
undefined8 FUN_14032aab0(undefined8 param_1,uint param_2)

{
  FUN_14032a730();
  if ((param_2 & 1) != 0) {
    FUN_14032a670(param_1);
  }
  return param_1;
}

