// ==== CPKStatistic::ctor_or_dtor  @1403b3480  [high:vtable-assign]  (orig: FUN_1403b3480)
undefined8 * FUN_1403b3480(undefined8 *param_1)

{
  FUN_1402b5540();
  *param_1 = CPKStatistic::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  return param_1;
}

// ==== CPKStatistic::vfunc_1  @1403b3600  [high:rtti-vtable]  (orig: FUN_1403b3600)
undefined8 FUN_1403b3600(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),0);
                    /* WARNING: Could not recover jumptable at 0x0001403b3652. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CPKStatistic::helper_1403b3910  @1403b3910  [medium:callgraph-r0]  (orig: FUN_1403b3910)
void FUN_1403b3910(void *param_1)

{
  if ((DAT_140976250 & 1) == 0) {
    DAT_140976250 = DAT_140976250 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976248,"CPKStatistic");
    atexit((_func_5014 *)&LAB_1406d6c20);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b3965. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976248,param_1);
  return;
}

// ==== CPKStatistic::ctor_or_dtor  @1403b39d0  [high:vtable-assign]  (orig: FUN_1403b39d0)
void FUN_1403b39d0(undefined8 *param_1)

{
  longlong *plVar1;
  
  *param_1 = CPKStatistic::vftable;
  plVar1 = (longlong *)param_1[2];
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*plVar1 + 0x38))(plVar1,0);
  }
  if ((param_1[2] != 0) && (param_1[2] != 0)) {
    (*(code *)**(undefined8 **)param_1[2])((undefined8 *)param_1[2],1);
    param_1[2] = 0;
  }
  FUN_1402b55a0(param_1);
  return;
}

// ==== CPKStatistic::ctor_or_dtor  @1403b3a70  [high:vtable-assign]  (orig: FUN_1403b3a70)
undefined8 * FUN_1403b3a70(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140976250 & 1) == 0) {
    DAT_140976250 = DAT_140976250 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976248,"CPKStatistic");
    atexit((_func_5014 *)&LAB_1406d6c20);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976248,0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    FUN_1402b5540(puVar1);
    *puVar1 = CPKStatistic::vftable;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pPKStatistic",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\pkstatistic.cpp"
                       ,0x23);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

// ==== CPKStatistic::vfunc_0  @1403b3d10  [high:rtti-vtable]  (orig: FUN_1403b3d10)
undefined8 FUN_1403b3d10(undefined8 param_1,uint param_2)

{
  FUN_1403b39d0();
  if ((param_2 & 1) != 0) {
    FUN_1403b3910(param_1);
  }
  return param_1;
}

