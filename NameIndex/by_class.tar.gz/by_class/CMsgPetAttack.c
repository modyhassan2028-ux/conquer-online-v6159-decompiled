// ==== CMsgPetAttack::ctor_or_dtor  @14044f830  [high:vtable-assign]  (orig: FUN_14044f830)
undefined8 * FUN_14044f830(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPetAttack::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPetAttack::ctor_or_dtor  @14044f880  [high:vtable-assign]  (orig: FUN_14044f880)
void FUN_14044f880(undefined8 *param_1)

{
  *param_1 = CMsgPetAttack::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPetAttack::vfunc_1  @14044f8b0  [high:rtti-vtable]  (orig: FUN_14044f8b0)
ulonglong FUN_14044f8b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xafc);
}

// ==== CMsgPetAttack::ctor_or_dtor  @14044f8e0  [high:vtable-assign]  (orig: FUN_14044f8e0)
undefined8 * FUN_14044f8e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPetAttack::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgPetAttack::vfunc_3  @14044f930  [high:rtti-vtable]  (orig: FUN_14044f930)
void FUN_14044f930(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  int iVar7;
  longlong lVar8;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1);
  if (lVar3 != 0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x88) + 0x20))
                       (*(longlong **)(lVar4 + 0x88),**(undefined4 **)(param_1 + 0x428));
    if ((plVar5 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar5 + 0x220))(plVar5), cVar1 != '\0')) {
      lVar4 = *(longlong *)(param_1 + 0x428);
      iVar7 = 0;
      if (*(char *)(lVar4 + 4) != '\0') {
        lVar8 = 0;
        do {
          plVar6 = (longlong *)FUN_1401aaa20(lVar3,*(undefined4 *)(lVar8 + 5 + lVar4));
          if ((plVar6 != (longlong *)0x0) &&
             (cVar1 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2), cVar1 != '\0')) {
            (**(code **)(plVar6[2] + 0x380))(plVar6 + 2);
            (**(code **)(plVar6[2] + 0x388))(plVar6 + 2,plVar5);
            cVar1 = FUN_140161580(lVar3);
            if (cVar1 == '\0') {
              FUN_1401994c0(lVar3,0);
            }
            else {
              FUN_140199540(lVar3);
            }
            lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            lVar4 = *(longlong *)(lVar4 + 0x140);
            if (lVar4 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
            FUN_14024e7b0(lVar4,uVar2);
          }
          lVar4 = *(longlong *)(param_1 + 0x428);
          iVar7 = iVar7 + 1;
          lVar8 = lVar8 + 4;
        } while (iVar7 < (int)(uint)*(byte *)(lVar4 + 4));
      }
    }
  }
  return;
}

