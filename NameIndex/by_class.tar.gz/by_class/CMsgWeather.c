// ==== CMsgWeather::ctor_or_dtor  @140456d30  [high:vtable-assign]  (orig: FUN_140456d30)
undefined8 * FUN_140456d30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgWeather::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgWeather::ctor_or_dtor  @140456d80  [high:vtable-assign]  (orig: FUN_140456d80)
void FUN_140456d80(undefined8 *param_1)

{
  *param_1 = CMsgWeather::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgWeather::vfunc_1  @140456e70  [high:rtti-vtable]  (orig: FUN_140456e70)
ulonglong FUN_140456e70(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f8);
}

// ==== CMsgWeather::vfunc_3  @140456ea0  [high:rtti-vtable]  (orig: FUN_140456ea0)
void FUN_140456ea0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgWeather::ctor_or_dtor  @140456ee0  [high:vtable-assign]  (orig: FUN_140456ee0)
undefined8 * FUN_140456ee0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgWeather::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

