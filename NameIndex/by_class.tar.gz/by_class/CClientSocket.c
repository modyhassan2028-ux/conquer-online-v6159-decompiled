// ==== CClientSocket::ctor_or_dtor  @1405061c0  [high:vtable-assign]  (orig: FUN_1405061c0)
void FUN_1405061c0(undefined8 *param_1)

{
  *param_1 = CClientSocket::vftable;
  if (param_1[0x209] != 0) {
    FUN_140544e70();
    param_1[0x209] = 0;
  }
  param_1[4] = 0xffffffffffffffff;
  return;
}

// ==== CClientSocket::vfunc_1  @140506200  [high:rtti-vtable]  (orig: FUN_140506200)
undefined1 FUN_140506200(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CClientSocket::vfunc_2  @140506240  [high:rtti-vtable]  (orig: FUN_140506240)
void FUN_140506240(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CClientSocket::vfunc_3  @140506280  [high:rtti-vtable]  (orig: FUN_140506280)
void FUN_140506280(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CClientSocket::ctor_or_dtor  @140506610  [high:vtable-assign]  (orig: FUN_140506610)
undefined8 * FUN_140506610(undefined8 *param_1,uint param_2)

{
  *param_1 = CClientSocket::vftable;
  if (param_1[0x209] != 0) {
    FUN_140544e70();
    param_1[0x209] = 0;
  }
  param_1[4] = 0xffffffffffffffff;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CClientSocket::ctor_or_dtor  @140506e80  [high:vtable-assign]  (orig: FUN_140506e80)
undefined8 * FUN_140506e80(undefined8 *param_1)

{
  ulong uVar1;
  
  *param_1 = CClientSocket::vftable;
  *(undefined4 *)(param_1 + 0x20a) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1054) = 0;
  FUN_140506480(param_1 + 0x20c);
  *(undefined4 *)((longlong)param_1 + 0x105c) = 0;
  *(undefined4 *)(param_1 + 0x20b) = 0;
  FUN_140506480(param_1 + 0x20c);
  FUN_140506480(param_1 + 0x24d);
  *(undefined4 *)((longlong)param_1 + 0x1264) = 0;
  *(undefined4 *)(param_1 + 0x24c) = 0;
  FUN_140506480(param_1 + 0x24d);
  *(undefined4 *)(param_1 + 3) = 0;
  param_1[4] = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0x105) = 0;
  *(undefined4 *)((longlong)param_1 + 0x102c) = 0;
  *(undefined4 *)(param_1 + 0x206) = 0;
  param_1[0x208] = 0;
  *(undefined4 *)(param_1 + 0x207) = 0xffffffff;
  *(undefined1 *)(param_1 + 1) = 0;
  *(undefined1 *)((longlong)param_1 + 0x1034) = 1;
  param_1[0x209] = 0;
  memset(param_1 + 5,0,0x800);
  memset((void *)((longlong)param_1 + 0x82c),0,0x800);
  *(undefined4 *)(param_1 + 0x20a) = 1;
  uVar1 = tq::TimeGet(0);
  *(uint *)((longlong)param_1 + 0x1054) = uVar1 / 1000;
  return param_1;
}

