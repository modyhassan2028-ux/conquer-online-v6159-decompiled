// ==== CNetMsg::ctor_or_dtor  @1402b55f0  [high:vtable-assign]  (orig: FUN_1402b55f0)
void FUN_1402b55f0(undefined8 *param_1)

{
  *param_1 = CNetMsg::vftable;
  return;
}

// ==== CNetMsg::vfunc_1  @1402b5640  [high:rtti-vtable]  (orig: FUN_1402b5640)
undefined8 FUN_1402b5640(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CNetMsg::vfunc_3  @1402b5670  [high:rtti-vtable]  (orig: FUN_1402b5670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402b5670(longlong param_1)

{
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  local_428 = *(undefined4 *)(param_1 + 0xc);
  _snprintf(&local_418,0x3ff,"Process Msg:%d, Size:%d");
  log_InlineLogMessage(&local_418);
  return;
}

// ==== CNetMsg::ctor_or_dtor  @1402ba1c0  [high:vtable-assign]  (orig: FUN_1402ba1c0)
undefined8 * FUN_1402ba1c0(undefined8 *param_1)

{
  *param_1 = CNetMsg::vftable;
  *(undefined4 *)(param_1 + 0x83) = 0;
  *(undefined4 *)((longlong)param_1 + 0x41c) = 0;
  *(undefined4 *)(param_1 + 0x84) = 0;
  *(undefined4 *)((longlong)param_1 + 0x424) = 0;
  memset(param_1 + 2,0,0x400);
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return param_1;
}

// ==== CNetMsg::ctor_or_dtor  @1402ba220  [high:vtable-assign]  (orig: FUN_1402ba220)
undefined8 * FUN_1402ba220(undefined8 *param_1,byte param_2)

{
  *param_1 = CNetMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CNetMsg::ctor_or_dtor  @1405ba790  [high:vtable-assign]  (orig: FUN_1405ba790)
undefined8 * FUN_1405ba790(undefined8 *param_1,longlong param_2)

{
  *param_1 = CNetMsg::vftable;
  *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 8);
  *(undefined4 *)((longlong)param_1 + 0xc) = *(undefined4 *)(param_2 + 0xc);
  memcpy(param_1 + 2,(void *)(param_2 + 0x10),0x400);
  *(undefined4 *)(param_1 + 0x82) = *(undefined4 *)(param_2 + 0x410);
  *(undefined4 *)((longlong)param_1 + 0x414) = *(undefined4 *)(param_2 + 0x414);
  *(undefined4 *)(param_1 + 0x83) = *(undefined4 *)(param_2 + 0x418);
  *(undefined4 *)((longlong)param_1 + 0x41c) = *(undefined4 *)(param_2 + 0x41c);
  *(undefined4 *)(param_1 + 0x84) = *(undefined4 *)(param_2 + 0x420);
  *(undefined4 *)((longlong)param_1 + 0x424) = *(undefined4 *)(param_2 + 0x424);
  return param_1;
}

// ==== CNetMsg::ctor_or_dtor  @1405babe0  [high:vtable-assign]  (orig: FUN_1405babe0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405babe0(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4,
                  undefined2 param_5)

{
  int iVar1;
  longlong lVar2;
  undefined1 auStack_908 [32];
  undefined8 local_8e8;
  undefined4 local_8e0;
  undefined2 local_8d8;
  undefined2 local_8d0;
  undefined4 local_8c8;
  undefined4 local_8c0;
  undefined1 local_8b8;
  undefined8 local_8a8;
  undefined **local_8a0;
  undefined4 local_898;
  undefined4 local_894;
  undefined1 local_890 [1024];
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined4 local_480;
  undefined4 local_47c;
  undefined1 local_478 [8];
  undefined4 local_470;
  undefined4 local_46c;
  undefined1 local_468 [1024];
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  ulonglong local_28;
  
  local_8a8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar2 != 0) && (param_3 != 0)) {
    FUN_14015b240();
    local_8b8 = 1;
    local_8c0 = 0;
    local_8c8 = 0;
    local_8d0 = 0;
    local_8d8 = param_5;
    local_8e8 = 0;
    local_8e0 = param_4;
    iVar1 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_3);
    if (iVar1 == 0) {
      FUN_14015b2c0(local_478);
    }
    else {
      local_8a0 = CNetMsg::vftable;
      local_898 = local_470;
      local_894 = local_46c;
      memcpy(local_890,local_468,0x400);
      local_490 = local_68;
      local_48c = local_64;
      local_488 = local_60;
      local_484 = local_5c;
      local_480 = local_58;
      local_47c = local_54;
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),&local_8a0);
      FUN_1402b55f0(&local_8a0);
      FUN_14015b2c0(local_478);
    }
  }
  return;
}

