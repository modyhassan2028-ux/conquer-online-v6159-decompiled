// ==== CMsg@tq::vfunc_4  @14015b020  [high:rtti-vtable]  (orig: FUN_14015b020)
void FUN_14015b020(void)

{
                    /* WARNING: Could not recover jumptable at 0x00014015b027. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("tq::CMsg::Process(void* pInfo) error");
  return;
}

// ==== CMsg@tq::vfunc_3  @14015b030  [high:rtti-vtable]  (orig: FUN_14015b030)
void FUN_14015b030(void)

{
                    /* WARNING: Could not recover jumptable at 0x00014015b037. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("tq::CMsg::Process(OBJID idActor) error");
  return;
}

// ==== CMsg@tq::vfunc_2  @14015b040  [high:rtti-vtable]  (orig: FUN_14015b040)
void FUN_14015b040(void)

{
                    /* WARNING: Could not recover jumptable at 0x00014015b047. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("tq::CMsg::Process(OBJID idActor, void* pInfo) error");
  return;
}

// ==== CMsg@tq::vfunc_0  @14015b050  [high:rtti-vtable]  (orig: FUN_14015b050)
undefined8 * FUN_14015b050(undefined8 *param_1,byte param_2)

{
  *param_1 = tq::CMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

