// ==== CFlowerActor@adapter::helper_140165380  @140165380  [medium:callgraph-r0]  (orig: FUN_140165380)
void FUN_140165380(longlong param_1)

{
  FUN_140372f40(param_1 + 0xe78);
  return;
}

// ==== CFlowerActor@adapter::helper_140165390  @140165390  [medium:callgraph-r0]  (orig: FUN_140165390)
void FUN_140165390(longlong param_1)

{
  FUN_140372f50(param_1 + 0xe78);
  return;
}

// ==== CFlowerActor@adapter::helper_1401653a0  @1401653a0  [medium:callgraph-r0]  (orig: FUN_1401653a0)
void FUN_1401653a0(longlong param_1)

{
  FUN_140372fb0(param_1 + 0xe78);
  return;
}

// ==== CFlowerActor@adapter::helper_1401653b0  @1401653b0  [medium:callgraph-r0]  (orig: FUN_1401653b0)
void FUN_1401653b0(longlong *param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  
  iVar2 = FUN_140372fb0(param_1 + 0x1cf);
  if (iVar2 != param_3) {
    iVar2 = (**(code **)(*param_1 + 0x50))(param_1);
    if (iVar2 == 2) {
      plVar4 = (longlong *)FUN_140087ed0();
      lVar1 = *plVar4;
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 400))(plVar4,uVar3,param_2,param_3);
    }
    FUN_1403730b0(param_1 + 0x1cf,param_2,param_3,1);
  }
  return;
}

// ==== CFlowerActor@adapter::helper_140372f40  @140372f40  [medium:callgraph-r1]  (orig: FUN_140372f40)
undefined4 FUN_140372f40(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xd4);
}

// ==== CFlowerActor@adapter::helper_140372f50  @140372f50  [medium:callgraph-r1]  (orig: FUN_140372f50)
void FUN_140372f50(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0xd4) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"send_flower_date");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
  }
  return;
}

// ==== CFlowerActor@adapter::helper_140372fb0  @140372fb0  [medium:callgraph-r1]  (orig: FUN_140372fb0)
undefined4 FUN_140372fb0(longlong param_1,undefined4 param_2)

{
  switch(param_2) {
  case 0:
  case 4:
    return *(undefined4 *)(param_1 + 0xd8);
  case 1:
  case 5:
    return *(undefined4 *)(param_1 + 0xdc);
  case 2:
  case 6:
    return *(undefined4 *)(param_1 + 0xe0);
  case 3:
  case 7:
    return *(undefined4 *)(param_1 + 0xe4);
  default:
    log_InlineLogERROR("ERROR: CUserData::GetFlower() error flower type %d");
    return 0;
  }
}

// ==== CFlowerActor@adapter::helper_1403730b0  @1403730b0  [medium:callgraph-r1]  (orig: FUN_1403730b0)
void FUN_1403730b0(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  
  switch(param_2) {
  case 0:
  case 4:
    plVar1 = *(longlong **)(param_1 + 0x230);
    *(undefined4 *)(param_1 + 0xd8) = param_3;
    if (plVar1 == (longlong *)0x0) goto LAB_140373190;
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"Flower_r");
    uVar2 = *(undefined4 *)(param_1 + 0xd8);
    break;
  case 1:
  case 5:
    plVar1 = *(longlong **)(param_1 + 0x230);
    *(undefined4 *)(param_1 + 0xdc) = param_3;
    if (plVar1 == (longlong *)0x0) goto LAB_140373190;
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"Flower_w");
    uVar2 = *(undefined4 *)(param_1 + 0xdc);
    break;
  case 2:
  case 6:
    plVar1 = *(longlong **)(param_1 + 0x230);
    *(undefined4 *)(param_1 + 0xe0) = param_3;
    if (plVar1 == (longlong *)0x0) goto LAB_140373190;
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"Flower_lily");
    uVar2 = *(undefined4 *)(param_1 + 0xe0);
    break;
  case 3:
  case 7:
    plVar1 = *(longlong **)(param_1 + 0x230);
    *(undefined4 *)(param_1 + 0xe4) = param_3;
    if (plVar1 == (longlong *)0x0) goto LAB_140373190;
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"Flower_tulip");
    uVar2 = *(undefined4 *)(param_1 + 0xe4);
    break;
  default:
    log_InlineLogERROR("ERROR: CUserData::SetFlower() error flower type %d");
    return;
  }
  (**(code **)(*plVar1 + 0xb8))(plVar1,uVar2);
LAB_140373190:
  if ((param_4 != 0) && (plVar1 = *(longlong **)(param_1 + 0x230), plVar1 != (longlong *)0x0)) {
                    /* WARNING: Could not recover jumptable at 0x0001403731af. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar1 + 0x38))(plVar1,0);
    return;
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_1  @1405b5200  [high:rtti-vtable]  (orig: FUN_1405b5200)
void FUN_1405b5200(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_0  @1405b5220  [high:rtti-vtable]  (orig: FUN_1405b5220)
ulonglong FUN_1405b5220(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar3 = FUN_140340190(lVar2,param_3,1,1);
  return uVar3;
}

// ==== CFlowerActor@adapter::vfunc_1  @1405b52d0  [high:rtti-vtable]  (orig: FUN_1405b52d0)
undefined8 FUN_1405b52d0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar1 != (longlong *)0x0) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
                    /* WARNING: Could not recover jumptable at 0x0001405b5349. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x18))(lVar2 + 0x10);
    return uVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CFlowerActor@adapter::vfunc_2  @1405b5350  [high:rtti-vtable]  (orig: FUN_1405b5350)
bool FUN_1405b5350(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  return lVar1 != 0;
}

// ==== CFlowerActor@adapter::vfunc_3  @1405b5370  [high:rtti-vtable]  (orig: FUN_1405b5370)
undefined8 FUN_1405b5370(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b5400. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CFlowerActor@adapter::vfunc_4  @1405b5410  [high:rtti-vtable]  (orig: FUN_1405b5410)
undefined8 FUN_1405b5410(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar3 = FUN_140165380(lVar2);
  return uVar3;
}

// ==== CFlowerActor@adapter::vfunc_5  @1405b54b0  [high:rtti-vtable]  (orig: FUN_1405b54b0)
void FUN_1405b54b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165390(lVar2,param_3);
  return;
}

// ==== CFlowerActor@adapter::vfunc_6  @1405b5550  [high:rtti-vtable]  (orig: FUN_1405b5550)
undefined8 FUN_1405b5550(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar3 = FUN_1401653a0(lVar2,param_3);
  return uVar3;
}

// ==== CFlowerActor@adapter::vfunc_7  @1405b55f0  [high:rtti-vtable]  (orig: FUN_1405b55f0)
void FUN_1405b55f0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401653b0(lVar2,param_3,param_4);
  return;
}

// ==== CFlowerActor@adapter::vfunc_8  @1405b56b0  [high:rtti-vtable]  (orig: FUN_1405b56b0)
undefined8 FUN_1405b56b0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b5742. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x70))(lVar2 + 0x10);
  return uVar3;
}

// ==== CFlowerActor@adapter::vfunc_9  @1405b5750  [high:rtti-vtable]  (orig: FUN_1405b5750)
undefined8 FUN_1405b5750(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      uVar3 = FUN_1401649c0(lVar2);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFlowerActor@adapter::vfunc_10  @1405b57c0  [high:rtti-vtable]  (orig: FUN_1405b57c0)
ulonglong FUN_1405b57c0(longlong param_1)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b5852. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x220))(lVar2 + 0x10);
  return uVar3;
}

// ==== CFlowerActor@adapter::vfunc_11  @1405b5860  [high:rtti-vtable]  (orig: FUN_1405b5860)
undefined8 FUN_1405b5860(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CFlowerActor@adapter::vfunc_12  @1405b58c0  [high:rtti-vtable]  (orig: FUN_1405b58c0)
void FUN_1405b58c0(longlong param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  if (param_3 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x150))(plVar1,param_5,param_3);
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_17  @1405b5970  [high:rtti-vtable]  (orig: FUN_1405b5970)
void FUN_1405b5970(longlong *param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x11);
  if (plVar2 != (longlong *)0x0) {
    lVar1 = *plVar2;
    uVar3 = (**(code **)(*param_1 + 8))(param_1,param_2);
    (**(code **)(lVar1 + 0x38))(plVar2,param_2,uVar3,param_3,param_5);
    lVar1 = *plVar2;
    uVar3 = (**(code **)(*param_1 + 8))(param_1,param_2);
    (**(code **)(lVar1 + 0x40))(plVar2,param_2,uVar3,param_3,param_4);
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_20  @1405b5a30  [high:rtti-vtable]  (orig: FUN_1405b5a30)
void FUN_1405b5a30(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_1400fda10(lVar1,1,1);
  return;
}

// ==== CFlowerActor@adapter::vfunc_0  @1405b5aa0  [high:rtti-vtable]  (orig: FUN_1405b5aa0)
void FUN_1405b5aa0(longlong param_1)

{
  FUN_1405b5b00(param_1 + -8);
  return;
}

// ==== CFlowerActor@adapter::helper_1405b5b00  @1405b5b00  [medium:callgraph-r0]  (orig: FUN_1405b5b00)
undefined8 * FUN_1405b5b00(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CFlowerActor::vftable;
  param_1[1] = adapter::CFlowerActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFlowerActor@adapter::vfunc_13  @1405b5b50  [high:rtti-vtable]  (orig: FUN_1405b5b50)
void FUN_1405b5b50(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(ushort *)(param_3 + 8) - 4,0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_14  @1405b5c50  [high:rtti-vtable]  (orig: FUN_1405b5c50)
void FUN_1405b5c50(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                     (*(longlong **)(param_1 + 0x10),param_4);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x348))((longlong *)(lVar2 + 0x10),puVar3,0);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_16  @1405b5d30  [high:rtti-vtable]  (orig: FUN_1405b5d30)
void FUN_1405b5d30(longlong param_1,longlong param_2,int param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(ushort *)(param_2 + 8) - 4,0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    if (((param_3 == 0) ||
        (plVar2 = (longlong *)
                  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                            (*(longlong **)(param_1 + 0x10),param_3), plVar2 == (longlong *)0x0)) ||
       (lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 == 0)) {
      uVar4 = 0xffffffff;
    }
    else {
      uVar4 = *(undefined4 *)(lVar3 + 0x122c);
    }
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 0x68))(plVar2,puVar1,uVar4);
    (**(code **)*puVar1)(puVar1,1);
    return;
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_15  @1405b5df0  [high:rtti-vtable]  (orig: FUN_1405b5df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b5df0(longlong param_1,longlong param_2,undefined4 param_3,undefined2 param_4)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_498 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4d8 = 0;
    local_4d0 = param_3;
    local_4c8 = param_4;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 != 0) {
      plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar2 + 0x68))(plVar2,local_488,0xffffffff);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CFlowerActor@adapter::vfunc_18  @1405b5ec0  [high:rtti-vtable]  (orig: FUN_1405b5ec0)
void FUN_1405b5ec0(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008ab60(uVar1,param_2);
  return;
}

// ==== CFlowerActor@adapter::vfunc_19  @1405b5ee0  [high:rtti-vtable]  (orig: FUN_1405b5ee0)
void FUN_1405b5ee0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140170e90(lVar1,param_3);
  return;
}

// ==== CFlowerActor@adapter::vfunc_21  @1405b5fa0  [high:rtti-vtable]  (orig: FUN_1405b5fa0)
void FUN_1405b5fa0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CFlowerActor@adapter::vfunc_22  @1405b6020  [high:rtti-vtable]  (orig: FUN_1405b6020)
void FUN_1405b6020(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140261720(lVar1,param_2,0xb);
  return;
}

