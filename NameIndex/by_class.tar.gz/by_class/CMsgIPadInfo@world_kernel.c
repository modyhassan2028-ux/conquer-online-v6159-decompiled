// ==== CMsgIPadInfo@world_kernel::vfunc_1  @140084620  [high:rtti-vtable]  (orig: FUN_140084620)
bool FUN_140084620(void)

{
  int iVar1;
  
  iVar1 = FUN_1400752f0();
  return iVar1 != 0;
}

// ==== CMsgIPadInfo@world_kernel::vfunc_3  @140084670  [high:rtti-vtable]  (orig: FUN_140084670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140084670(longlong param_1)

{
  bool bVar1;
  uint uVar2;
  undefined8 uVar3;
  uint *puVar4;
  CStringPacker *pCVar5;
  undefined1 auStack_368 [32];
  char *local_348;
  char *local_340;
  char *local_338;
  undefined8 local_328;
  char local_318;
  undefined1 local_317 [127];
  char local_298;
  undefined1 local_297 [127];
  char local_218;
  undefined1 local_217 [127];
  char local_198;
  undefined1 local_197 [127];
  char local_118;
  undefined1 local_117 [127];
  char local_98;
  undefined1 local_97 [127];
  ulonglong local_18;
  
  local_328 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_368;
  if (**(char **)(param_1 + 0x420) == '\0') {
    uVar3 = FUN_140054e10();
    puVar4 = (uint *)FUN_140070520(uVar3);
    if (puVar4 != (uint *)0x0) {
      pCVar5 = (CStringPacker *)(param_1 + 0x428);
      uVar2 = tq::CStringPacker::GetStrAmount(pCVar5);
      if (2 < uVar2) {
        local_98 = '\0';
        memset(local_97,0,0x7f);
        local_198 = '\0';
        memset(local_197,0,0x7f);
        local_298 = '\0';
        memset(local_297,0,0x7f);
        bVar1 = tq::CStringPacker::GetString(pCVar5,0,&local_98,0x80);
        if (((bVar1) && (bVar1 = tq::CStringPacker::GetString(pCVar5,1,&local_198,0x80), bVar1)) &&
           (bVar1 = tq::CStringPacker::GetString(pCVar5,2,&local_298,0x80), bVar1)) {
          local_338 = &local_298;
          local_340 = &local_198;
          local_348 = &local_98;
          tq::MyLogSave("gmlog/ipadinfo",
                        "user id:%8u, name:%20s, iPad UDID: %s, IDFA:%s, version: %s",
                        (ulonglong)*puVar4,puVar4 + 1);
        }
      }
    }
  }
  else if (**(char **)(param_1 + 0x420) == '\x01') {
    pCVar5 = (CStringPacker *)(param_1 + 0x428);
    uVar2 = tq::CStringPacker::GetStrAmount(pCVar5);
    if (2 < uVar2) {
      local_318 = '\0';
      memset(local_317,0,0x7f);
      local_218 = '\0';
      memset(local_217,0,0x7f);
      local_118 = '\0';
      memset(local_117,0,0x7f);
      bVar1 = tq::CStringPacker::GetString(pCVar5,0,&local_318,0x80);
      if (((bVar1) && (bVar1 = tq::CStringPacker::GetString(pCVar5,1,&local_218,0x80), bVar1)) &&
         (bVar1 = tq::CStringPacker::GetString(pCVar5,2,&local_118,0x80), bVar1)) {
        local_348 = &local_118;
        tq::MyLogSave("gmlog/createrole","AccountID:%s, Mac:%s, IDFA: %s",&local_318,&local_218);
      }
    }
  }
  return;
}

// ==== CMsgIPadInfo@world_kernel::vfunc_0  @140084900  [high:rtti-vtable]  (orig: FUN_140084900)
undefined8 * FUN_140084900(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgIPadInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

