// ==== CCrossMsgInnerStrengthAttrib::helper_1401f6250  @1401f6250  [medium:callgraph-r0]  (orig: FUN_1401f6250)
void FUN_1401f6250(longlong param_1,longlong *param_2,longlong param_3,ushort param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined4 local_res10 [2];
  longlong *local_28;
  longlong local_20;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (param_3 != 0) {
    if (param_4 < 0xf) {
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401f5550(param_1 + 0x18,&local_28,local_res10);
      lVar2 = *(longlong *)(param_1 + 0x48);
      if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0x18))) {
        _invalid_parameter_noinfo();
      }
      if (local_20 == lVar2) {
        (**(code **)(*param_2 + 0x38))(param_2);
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CInnerStrengthMgr::LoadOSUserAttribSum not found user data, idUser:%u, idOSUser:%u."
                          );
      }
      else {
        uVar1 = (ulonglong)param_4;
        if (param_4 != 0) {
          do {
            if (local_28 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar2 = 0;
            }
            else {
              lVar2 = *local_28;
            }
            if (local_20 == *(longlong *)(lVar2 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140406d90(*(undefined8 *)(local_20 + 0x20),param_3);
            param_3 = param_3 + 5;
            uVar1 = uVar1 - 1;
          } while (uVar1 != 0);
        }
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CCrossMsgInnerStrengthAttrib::helper_140406d90  @140406d90  [medium:callgraph-r1]  (orig: FUN_140406d90)
void FUN_140406d90(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_140406b20(param_1 + 0x10);
  *puVar1 = *(undefined4 *)(param_2 + 1);
  return;
}

// ==== CCrossMsgInnerStrengthAttrib::ctor_or_dtor  @14045cc80  [high:vtable-assign]  (orig: FUN_14045cc80)
undefined8 * FUN_14045cc80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgInnerStrengthAttrib::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgInnerStrengthAttrib::ctor_or_dtor  @14045ccd0  [high:vtable-assign]  (orig: FUN_14045ccd0)
void FUN_14045ccd0(undefined8 *param_1)

{
  *param_1 = CCrossMsgInnerStrengthAttrib::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgInnerStrengthAttrib::vfunc_5  @14045cd00  [high:rtti-vtable]  (orig: FUN_14045cd00)
bool FUN_14045cd00(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c60;
    }
  }
  return false;
}

// ==== CCrossMsgInnerStrengthAttrib::ctor_or_dtor  @14045cee0  [high:vtable-assign]  (orig: FUN_14045cee0)
undefined8 * FUN_14045cee0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgInnerStrengthAttrib::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgInnerStrengthAttrib::vfunc_3  @14045cf30  [high:rtti-vtable]  (orig: FUN_14045cf30)
void FUN_14045cf30(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong lVar5;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  uVar3 = FUN_140087650(uVar3);
  lVar4 = FUN_1402af110(uVar3,uVar2,uVar1);
  if (lVar4 == 0) {
    log_InlineLogOSWARNING
              (
              "CCrossMsgInnerStrengthAttrib::Process UserManager GetCreatedOSUser failed. server id:%u, os user id:%u."
              );
  }
  else {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar5 + 0x1d0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      uVar3 = *(undefined8 *)(lVar5 + 0x1d0);
    }
    FUN_1401f6250(uVar3,lVar4,*(undefined2 **)(param_1 + 0x428) + 1,
                  **(undefined2 **)(param_1 + 0x428));
  }
  return;
}

