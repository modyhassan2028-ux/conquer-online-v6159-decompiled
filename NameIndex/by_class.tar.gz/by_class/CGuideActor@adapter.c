// ==== CGuideActor@adapter::helper_1401654c0  @1401654c0  [medium:callgraph-r0]  (orig: FUN_1401654c0)
undefined4 FUN_1401654c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x11c4);
}

// ==== CGuideActor@adapter::helper_1401654d0  @1401654d0  [medium:callgraph-r0]  (orig: FUN_1401654d0)
void FUN_1401654d0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x11c4) = param_2;
  return;
}

// ==== CGuideActor@adapter::helper_1401a7c00  @1401a7c00  [medium:callgraph-r0]  (orig: FUN_1401a7c00)
void FUN_1401a7c00(longlong *param_1,longlong param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong lVar6;
  int iVar7;
  uint uVar8;
  char local_res8 [8];
  
  if (param_1[0x220] != 0) {
    plVar4 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
    uVar5 = (**(code **)(*plVar4 + 0x58))(plVar4);
    if ((uVar5 >> 0x28 & 1) != 0) {
      return;
    }
  }
  iVar2 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
  lVar6 = (**(code **)(*param_1 + 0xa0))(param_1);
  iVar7 = 0;
  param_2 = param_2 + lVar6;
  uVar8 = 1;
  do {
    lVar6 = DAT_140975be0;
    if (DAT_140975be0 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar6 = 0;
    }
    lVar6 = FUN_14014de60(lVar6,0,iVar2 + -1 + uVar8);
    if (lVar6 == 0) goto LAB_1401a7d1f;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))(*(longlong **)(lVar6 + 8),1);
    lVar6 = (**(code **)(*plVar4 + 0x58))(plVar4);
    if (param_2 < lVar6) goto LAB_1401a7d1f;
    uVar8 = uVar8 + 1;
    param_2 = param_2 - lVar6;
    iVar7 = iVar7 + 1;
  } while (uVar8 < 0xf4241);
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1401a7d1f:
  local_res8[0] = '\0';
  if (iVar7 != 0) {
    (**(code **)(*param_1 + 200))(param_1,iVar7,local_res8);
    cVar1 = (**(code **)(*param_1 + 0x118))(param_1);
    if (cVar1 == '\0') {
      (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,10,iVar7 * 3,1,0);
    }
    else {
      (**(code **)(*param_1 + 0xd0))(param_1,iVar7);
    }
    uVar3 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
    FUN_1401a6420(param_1,0,uVar3,1);
    (**(code **)(*param_1 + 0xd8))(param_1);
    if ((local_res8[0] != '\0') &&
       (lVar6 = (**(code **)(*param_1 + 0xa0))(param_1), param_2 <= lVar6)) goto LAB_1401a7de4;
  }
  FUN_1401a6420(param_1,5,param_2);
LAB_1401a7de4:
  FUN_140371580(param_1 + 0x1cf);
  return;
}

// ==== CGuideActor@adapter::helper_1403136f0  @1403136f0  [medium:callgraph-r0]  (orig: FUN_1403136f0)
bool FUN_1403136f0(longlong param_1,uint param_2,uint param_3)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  bool bVar7;
  CMySingleLock local_res8 [8];
  longlong local_50;
  undefined8 *local_48;
  longlong local_40;
  undefined8 local_38;
  longlong local_30;
  longlong local_28;
  
  tq::CMySingleLock::CMySingleLock(local_res8,(ILockObj *)(param_1 + 0x48));
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
  puVar2 = (undefined8 *)puVar6[1];
  while (cVar1 == '\0') {
    if ((*(uint *)(puVar2 + 3) < param_2) ||
       ((*(uint *)(puVar2 + 3) <= param_2 && (*(uint *)((longlong)puVar2 + 0x1c) < param_3)))) {
      puVar4 = (undefined8 *)puVar2[2];
    }
    else {
      puVar4 = (undefined8 *)*puVar2;
      puVar6 = puVar2;
    }
    puVar2 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x29);
  }
  local_48 = puVar6;
  local_50 = *(longlong *)(param_1 + 8);
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar6 == puVar2) || (param_2 < *(uint *)(puVar6 + 3))) ||
     ((param_2 <= *(uint *)(puVar6 + 3) && (param_3 < *(uint *)((longlong)puVar6 + 0x1c))))) {
    local_38 = *(undefined8 *)(param_1 + 0x38);
    local_40 = *(longlong *)(param_1 + 8);
    plVar5 = &local_40;
  }
  else {
    plVar5 = &local_50;
  }
  local_30 = *plVar5;
  local_28 = plVar5[1];
  lVar3 = *(longlong *)(param_1 + 0x38);
  if ((local_30 == 0) || (local_30 != *(longlong *)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  bVar7 = local_28 == lVar3;
  if (bVar7) {
    tq::CMySingleLock::~CMySingleLock(local_res8);
  }
  else {
    tq::CMySingleLock::~CMySingleLock(local_res8);
  }
  return !bVar7;
}

// ==== CGuideActor@adapter::helper_140314a50  @140314a50  [medium:callgraph-r0]  (orig: FUN_140314a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140314a50(undefined8 param_1,undefined4 param_2,undefined8 param_3,char param_4,
             undefined4 param_5,longlong param_6)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 ***pppuVar5;
  ulonglong uVar6;
  undefined1 auStack_a8 [32];
  undefined4 local_88;
  undefined8 local_78;
  undefined **local_70;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [8];
  undefined8 **local_60 [3];
  ulonglong local_48;
  ulonglong local_40;
  
  local_78 = 0xfffffffffffffffe;
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  if (param_6 == 0) {
    log_InlineLogERROR("DBLoad error , pszSQL == NULL. at %s %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\dbdataprepare.cpp"
                       ,0x2d);
    uVar1 = 0;
  }
  else {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
    local_70 = tq::CString::vftable;
    if (param_4 == '\0') {
      FUN_140311d10(&local_70,param_6,param_3);
    }
    else {
      FUN_140311d10(&local_70,param_6,param_2);
    }
    plVar2 = (longlong *)InstanceGet();
    pppuVar5 = local_60;
    if (0xf < local_48) {
      pppuVar5 = (undefined8 ***)local_60[0];
    }
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,pppuVar5,2);
    if (plVar2 == (longlong *)0x0) {
      pppuVar5 = local_60;
      if (0xf < local_48) {
        pppuVar5 = (undefined8 ***)local_60[0];
      }
      log_InlineLogERROR("DBLoad pszSQL[%s] pRes == NULL. at %s %d",pppuVar5,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\dbdataprepare.cpp"
                         ,0x3f);
      local_70 = tq::CString::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
      uVar1 = 0;
    }
    else {
      lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
      if (lVar3 == 0) {
        (**(code **)*plVar2)(plVar2);
        local_70 = tq::CString::vftable;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar1 = 1;
      }
      else {
        (**(code **)(*plVar2 + 0x30))(plVar2,0);
        uVar6 = 0;
        lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
        if (lVar3 != 0) {
          do {
            (**(code **)(*plVar2 + 0x30))(plVar2,uVar6);
            lVar3 = (**(code **)(*plVar2 + 0x38))(plVar2);
            if (lVar3 == 0) {
              local_88 = 0x4d;
              log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",&DAT_1406e5370,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\dbdataprepare.cpp"
                                );
            }
            else {
              FUN_1403141e0(param_1,param_2,param_5,lVar3);
            }
            uVar6 = (ulonglong)((int)uVar6 + 1);
            uVar4 = (**(code **)(*plVar2 + 0x40))(plVar2);
          } while (uVar6 < uVar4);
        }
        (**(code **)*plVar2)(plVar2);
        local_70 = tq::CString::vftable;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar1 = 1;
      }
    }
  }
  return uVar1;
}

// ==== CGuideActor@adapter::vfunc_1  @1405b86f0  [high:rtti-vtable]  (orig: FUN_1405b86f0)
void FUN_1405b86f0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_1  @1405b8710  [high:rtti-vtable]  (orig: FUN_1405b8710)
void FUN_1405b8710(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140382f00(lVar1,param_3);
    FUN_1401a7c00(lVar1,uVar2);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_2  @1405b8760  [high:rtti-vtable]  (orig: FUN_1405b8760)
void FUN_1405b8760(longlong param_1,undefined8 param_2,undefined2 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140382b00(lVar1,param_3);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_3  @1405b8790  [high:rtti-vtable]  (orig: FUN_1405b8790)
void FUN_1405b8790(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140340e50(lVar1,0xb2391,0,1,1,0,1);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_5  @1405b87d0  [high:rtti-vtable]  (orig: FUN_1405b87d0)
undefined8 FUN_1405b87d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_1401654c0(lVar1);
    return uVar2;
  }
  return 1;
}

// ==== CGuideActor@adapter::vfunc_7  @1405b8800  [high:rtti-vtable]  (orig: FUN_1405b8800)
undefined8 FUN_1405b8800(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8822. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_8  @1405b8830  [high:rtti-vtable]  (orig: FUN_1405b8830)
uint FUN_1405b8830(longlong param_1)

{
  uint uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar2 != (longlong *)0x0) {
    uVar1 = (**(code **)(*plVar2 + 0xc0))(plVar2);
    return uVar1 / 100000;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_10  @1405b8880  [high:rtti-vtable]  (orig: FUN_1405b8880)
undefined8 FUN_1405b8880(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  lVar1 = DAT_140975be0;
  if (lVar3 != 0) {
    if (DAT_140975be0 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x70))(lVar3 + 0x10);
    plVar4 = (longlong *)FUN_14014de60(lVar1,0,uVar2);
    if (plVar4 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8908. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar5 = (**(code **)(*plVar4 + 0x10))(plVar4,2);
      return uVar5;
    }
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_14  @1405b8920  [high:rtti-vtable]  (orig: FUN_1405b8920)
undefined8 FUN_1405b8920(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8942. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_11  @1405b8950  [high:rtti-vtable]  (orig: FUN_1405b8950)
undefined8 FUN_1405b8950(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8972. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_6  @1405b8980  [high:rtti-vtable]  (orig: FUN_1405b8980)
undefined8 FUN_1405b8980(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140188830(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_12  @1405b89b0  [high:rtti-vtable]  (orig: FUN_1405b89b0)
undefined8 FUN_1405b89b0(longlong param_1)

{
  uint uVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar2 == (longlong *)0x0) {
    return 0;
  }
  uVar1 = (**(code **)(*plVar2 + 0x108))(plVar2);
  if (2 < uVar1) {
    return 2;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b89f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x108))(plVar2);
  return uVar3;
}

// ==== CGuideActor@adapter::vfunc_13  @1405b8a10  [high:rtti-vtable]  (orig: FUN_1405b8a10)
undefined8 FUN_1405b8a10(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8a30. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_15  @1405b8a40  [high:rtti-vtable]  (orig: FUN_1405b8a40)
undefined8 FUN_1405b8a40(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8a62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x198))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_16  @1405b8a70  [high:rtti-vtable]  (orig: FUN_1405b8a70)
int FUN_1405b8a70(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return (int)*(short *)(lVar1 + 0xef4);
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_17  @1405b8aa0  [high:rtti-vtable]  (orig: FUN_1405b8aa0)
undefined1 FUN_1405b8aa0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return *(undefined1 *)(lVar1 + 0xeee);
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_18  @1405b8ad0  [high:rtti-vtable]  (orig: FUN_1405b8ad0)
undefined8 FUN_1405b8ad0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8af0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_19  @1405b8b00  [high:rtti-vtable]  (orig: FUN_1405b8b00)
undefined8 FUN_1405b8b00(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8b22. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_20  @1405b8b30  [high:rtti-vtable]  (orig: FUN_1405b8b30)
void FUN_1405b8b30(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x0001405b8b4a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xf8))(plVar1,param_2);
  return;
}

// ==== CGuideActor@adapter::vfunc_21  @1405b8b60  [high:rtti-vtable]  (orig: FUN_1405b8b60)
undefined8 FUN_1405b8b60(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8b82. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x180))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_24  @1405b8b90  [high:rtti-vtable]  (orig: FUN_1405b8b90)
undefined8 FUN_1405b8b90(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8bbc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,1);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_22  @1405b8bd0  [high:rtti-vtable]  (orig: FUN_1405b8bd0)
undefined8 FUN_1405b8bd0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b8bf2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_23  @1405b8c00  [high:rtti-vtable]  (orig: FUN_1405b8c00)
bool FUN_1405b8c00(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CGuideActor@adapter::vfunc_25  @1405b8c20  [high:rtti-vtable]  (orig: FUN_1405b8c20)
void FUN_1405b8c20(longlong param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  if ((param_3 != 0) &&
     (plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))(),
     plVar1 != (longlong *)0x0)) {
    (**(code **)(*plVar1 + 0x150))(plVar1,param_5,param_3);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_27  @1405b8c60  [high:rtti-vtable]  (orig: FUN_1405b8c60)
void FUN_1405b8c60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1401654d0(lVar1,param_3);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_28  @1405b8c90  [high:rtti-vtable]  (orig: FUN_1405b8c90)
void FUN_1405b8c90(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140194840(lVar1,param_3,param_4);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_29  @1405b8cd0  [high:rtti-vtable]  (orig: FUN_1405b8cd0)
void FUN_1405b8cd0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar1 != 0) {
    FUN_14018f460(lVar1,param_2,0,0);
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_0  @1405b8d10  [high:rtti-vtable]  (orig: FUN_1405b8d10)
ulonglong FUN_1405b8d10(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140178c90(lVar1);
  return uVar2;
}

// ==== CGuideActor@adapter::vfunc_36  @1405b8d70  [high:rtti-vtable]  (orig: FUN_1405b8d70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405b8d70(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x250);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CGuideActor@adapter::vfunc_0  @1405b8ed0  [high:rtti-vtable]  (orig: FUN_1405b8ed0)
void FUN_1405b8ed0(longlong param_1)

{
  FUN_1405b8f30(param_1 + -8);
  return;
}

// ==== CGuideActor@adapter::helper_1405b8f30  @1405b8f30  [medium:callgraph-r0]  (orig: FUN_1405b8f30)
undefined8 * FUN_1405b8f30(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CGuideActor::vftable;
  param_1[1] = adapter::CGuideActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CGuideActor@adapter::vfunc_4  @1405b8f80  [high:rtti-vtable]  (orig: FUN_1405b8f80)
bool FUN_1405b8f80(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return 0x27 < (ulonglong)(*(longlong *)(lVar1 + 0xc28) - *(longlong *)(lVar1 + 0xc20) >> 2);
  }
  return false;
}

// ==== CGuideActor@adapter::vfunc_9  @1405b8fc0  [high:rtti-vtable]  (orig: FUN_1405b8fc0)
undefined8 FUN_1405b8fc0(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  lVar3 = DAT_140975be0;
  if (lVar2 != 0) {
    if (DAT_140975be0 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x70))(lVar2 + 0x10);
    lVar3 = FUN_14014de60(lVar3,0,uVar1);
    if (lVar3 != 0) {
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),1);
                    /* WARNING: Could not recover jumptable at 0x0001405b9052. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar5 = (**(code **)(*plVar4 + 0x58))(plVar4);
      return uVar5;
    }
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_26  @1405b9060  [high:rtti-vtable]  (orig: FUN_1405b9060)
void FUN_1405b9060(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CGuideActor@adapter::vfunc_31  @1405b9130  [high:rtti-vtable]  (orig: FUN_1405b9130)
undefined8 FUN_1405b9130(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  
  plVar2 = (longlong *)CurrentInstanceGet();
  if (plVar2 != (longlong *)0x0) {
    plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,4);
    if ((plVar3 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar3 + 0x10))(plVar3,param_2), cVar1 != '\0')) {
      return 1;
    }
    plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x22);
    if ((plVar3 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar3 + 0x118))(plVar3,param_2), cVar1 != '\0')) {
      return 1;
    }
    plVar3 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x21);
    if ((plVar3 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar3 + 0xe0))(plVar3,param_2), cVar1 != '\0')) {
      return 1;
    }
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x24);
    if ((plVar2 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar2 + 0xe0))(plVar2,param_2), cVar1 != '\0')) {
      return 1;
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_2);
    if (lVar4 != 0) {
      plVar2 = (longlong *)(lVar4 + 0x10);
      lVar4 = (**(code **)(*plVar2 + 0x160))(plVar2);
      if (((lVar4 != 0) && (cVar1 = FUN_1401195d0(lVar4), cVar1 != '\0')) &&
         (cVar1 = (**(code **)(*plVar2 + 0x280))(plVar2), cVar1 == '\0')) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CGuideActor@adapter::vfunc_32  @1405b9260  [high:rtti-vtable]  (orig: FUN_1405b9260)
void FUN_1405b9260(longlong param_1,undefined4 param_2,undefined8 param_3,undefined1 param_4,
                  undefined4 param_5,undefined8 param_6)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140314a50(lVar1,param_2,param_3,param_4,param_5,param_6);
  return;
}

// ==== CGuideActor@adapter::vfunc_33  @1405b92f0  [high:rtti-vtable]  (orig: FUN_1405b92f0)
void FUN_1405b92f0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1403141e0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CGuideActor@adapter::vfunc_34  @1405b9370  [high:rtti-vtable]  (orig: FUN_1405b9370)
void FUN_1405b9370(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1403136f0(lVar1,param_2,param_3);
  return;
}

// ==== CGuideActor@adapter::vfunc_35  @1405b93e0  [high:rtti-vtable]  (orig: FUN_1405b93e0)
void FUN_1405b93e0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CGuideActor@adapter::vfunc_37  @1405b9460  [high:rtti-vtable]  (orig: FUN_1405b9460)
void FUN_1405b9460(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008abf0(uVar1);
  return;
}

// ==== CGuideActor@adapter::vfunc_30  @1405b9480  [high:rtti-vtable]  (orig: FUN_1405b9480)
undefined8 FUN_1405b9480(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 != 0) {
    plVar1 = (longlong *)(lVar3 + 0x10);
    lVar3 = (**(code **)(*plVar1 + 0x160))(plVar1);
    if (lVar3 != 0) {
      cVar2 = FUN_14011dbb0(lVar3);
      if (cVar2 != '\0') {
        cVar2 = (**(code **)(*plVar1 + 0x280))(plVar1);
        if (cVar2 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}

