// ==== CMsgGodExp::helper_140161700  @140161700  [medium:callgraph-r0]  (orig: FUN_140161700)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140161700(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  uVar2 = FUN_140372dd0(param_1 + 0xe78);
  uVar3 = FUN_140372e50(param_1 + 0xe78);
  FUN_1403b3d40(local_448);
  cVar1 = FUN_1403b3dc0(local_448,0,uVar2,uVar3);
  if (cVar1 != '\0') {
    (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_448);
  }
  FUN_1403b3d90(local_448);
  return;
}

// ==== CMsgGodExp::helper_1401b1520  @1401b1520  [medium:callgraph-r0]  (orig: FUN_1401b1520)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1401b1520(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  uint uVar4;
  ulonglong uVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  plVar1 = param_1 + 2;
  uVar5 = (**(code **)(*plVar1 + 0x220))(plVar1);
  if (((char)uVar5 != '\0') &&
     (uVar5 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x1b), (char)uVar5 == '\0')) {
    if (param_1[0x220] != 0) {
      plVar6 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
      uVar5 = (**(code **)(*plVar6 + 0x58))(plVar6);
      if ((uVar5 >> 0x28 & 1) != 0) {
        pIVar7 = theInstance();
        lVar2 = *plVar1;
        uVar8 = (*(code *)**(undefined8 **)pIVar7)
                          (pIVar7,"STR_CONTRIBUTE_EXP_DISABLE_AT_NO_EXP_MAP");
        uVar5 = (**(code **)(lVar2 + 0x358))(plVar1,uVar8);
        return uVar5;
      }
    }
    uVar4 = FUN_140372dd0(param_1 + 0x1cf);
    uVar5 = (ulonglong)uVar4 * 0xd1b71759 & 0xffffffff;
    if (uVar4 != 0) {
      (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/playerexpaward","Player[%u] ExpType[OnlineExp] Amount[%u]");
      FUN_1401ad760(param_1,(ulonglong)uVar4 / 10000);
      FUN_140372de0(param_1 + 0x1cf,0,1);
      FUN_1403b3d40(local_458);
      cVar3 = FUN_1403b3dc0(local_458,1,uVar4,0);
      if (cVar3 != '\0') {
        (**(code **)(*plVar1 + 0x350))(plVar1,local_458);
      }
      uVar5 = FUN_1403b3d90(local_458);
    }
  }
  return uVar5;
}

// ==== CMsgGodExp::helper_1401b16b0  @1401b16b0  [medium:callgraph-r0]  (orig: FUN_1401b16b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1401b16b0(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  uint uVar4;
  ulonglong uVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  plVar1 = param_1 + 2;
  uVar5 = (**(code **)(*plVar1 + 0x220))(plVar1);
  if (((char)uVar5 != '\0') &&
     (uVar5 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x1b), (char)uVar5 == '\0')) {
    if (param_1[0x220] != 0) {
      plVar6 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
      uVar5 = (**(code **)(*plVar6 + 0x58))(plVar6);
      if ((uVar5 >> 0x28 & 1) != 0) {
        pIVar7 = theInstance();
        lVar2 = *plVar1;
        uVar8 = (*(code *)**(undefined8 **)pIVar7)
                          (pIVar7,"STR_CONTRIBUTE_EXP_DISABLE_AT_NO_EXP_MAP");
        uVar5 = (**(code **)(lVar2 + 0x358))(plVar1,uVar8);
        return uVar5;
      }
    }
    uVar4 = FUN_140372e50(param_1 + 0x1cf);
    uVar5 = (ulonglong)uVar4 * 0xd1b71759 & 0xffffffff;
    if (uVar4 != 0) {
      (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/playerexpaward","Player[%u] ExpType[BattleExp] Amount[%u]");
      FUN_1401ad760(param_1,(ulonglong)uVar4 / 10000);
      FUN_140372e60(param_1 + 0x1cf,0,1);
      FUN_1403b3d40(local_458);
      cVar3 = FUN_1403b3dc0(local_458,2,0,uVar4);
      if (cVar3 != '\0') {
        (**(code **)(*plVar1 + 0x350))(plVar1,local_458);
      }
      uVar5 = FUN_1403b3d90(local_458);
    }
  }
  return uVar5;
}

// ==== CMsgGodExp::helper_140372de0  @140372de0  [medium:callgraph-r1]  (orig: FUN_140372de0)
void FUN_140372de0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x164) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"online_god_exptime");
    (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgGodExp::ctor_or_dtor  @1403b3d40  [high:vtable-assign]  (orig: FUN_1403b3d40)
undefined8 * FUN_1403b3d40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGodExp::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgGodExp::ctor_or_dtor  @1403b3d90  [high:vtable-assign]  (orig: FUN_1403b3d90)
void FUN_1403b3d90(undefined8 *param_1)

{
  *param_1 = CMsgGodExp::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgGodExp::vfunc_5  @1403b3e40  [high:rtti-vtable]  (orig: FUN_1403b3e40)
bool FUN_1403b3e40(longlong param_1,undefined8 param_2,undefined2 param_3)

{
  int iVar1;
  
  iVar1 = FUN_1402b5640(param_1,param_2,param_3);
  if (iVar1 == 0) {
    return false;
  }
  return *(int *)(param_1 + 8) == 0x40c;
}

// ==== CMsgGodExp::ctor_or_dtor  @1403b3e70  [high:vtable-assign]  (orig: FUN_1403b3e70)
undefined8 * FUN_1403b3e70(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGodExp::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgGodExp::vfunc_3  @1403b3ec0  [high:rtti-vtable]  (orig: FUN_1403b3ec0)
void FUN_1403b3ec0(longlong param_1)

{
  char cVar1;
  undefined4 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar4,(int)lVar3,*puVar2);
    cVar1 = *(char *)(*(longlong *)(param_1 + 0x428) + 4);
    if (cVar1 == '\0') {
      FUN_140161700(plVar6);
    }
    else {
      if (cVar1 == '\x01') {
        FUN_1401b1520(plVar6);
        return;
      }
      if (cVar1 == '\x02') {
        FUN_1401b16b0(plVar6);
        return;
      }
    }
  }
  return;
}

