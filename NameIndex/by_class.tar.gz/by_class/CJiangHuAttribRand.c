// ==== CJiangHuAttribRand::helper_1403f7440  @1403f7440  [medium:callgraph-r0]  (orig: FUN_1403f7440)
void FUN_1403f7440(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  ushort uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  int iVar10;
  char local_res8 [4];
  int local_resc;
  undefined1 local_48 [32];
  
  plVar2 = *(longlong **)(param_1 + 8);
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar7;
          plVar7 = *(longlong **)(param_1 + 0x38);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar7) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar8 = plVar6[3];
          if ((char)lVar8 != '\0') {
            iVar10 = 0;
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *plVar2;
            }
            if (plVar6 == *(longlong **)(lVar9 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            plVar7 = (longlong *)plVar6[7];
            if ((longlong *)plVar6[8] < plVar7) {
              _invalid_parameter_noinfo();
            }
            plVar5 = (longlong *)plVar6[4];
            while( true ) {
              plVar4 = (longlong *)plVar6[8];
              if (plVar4 < (longlong *)plVar6[7]) {
                _invalid_parameter_noinfo();
              }
              if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)plVar6[4])) {
                _invalid_parameter_noinfo();
              }
              if (plVar7 == plVar4) break;
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar5;
              }
              if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
                _invalid_parameter_noinfo();
              }
              plVar4 = (longlong *)*plVar7;
              if (plVar4 != (longlong *)0x0) {
                plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,3);
                uVar3 = (**(code **)(*plVar4 + 0x30))(plVar4);
                iVar10 = iVar10 + (uint)uVar3;
              }
              if (plVar5 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar5;
              }
              if (*(longlong **)(lVar9 + 0x20) <= plVar7) {
                _invalid_parameter_noinfo();
              }
              plVar7 = plVar7 + 1;
            }
            local_res8[0] = (char)lVar8;
            local_resc = iVar10;
            FUN_1401e2440(param_1 + 0x48,local_48,local_res8);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x51) == '\0') break;
          _invalid_parameter_noinfo();
          plVar7 = plVar6;
        }
        plVar7 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar7 + 0x51) != '\0') break;
        cVar1 = *(char *)(*plVar7 + 0x51);
        plVar6 = (longlong *)*plVar7;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x51);
          plVar7 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar7 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar7 + 0x51) != '\0');
    do {
      plVar5 = plVar7;
      plVar7 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar7 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar7 + 0x51) == '\0');
  } while( true );
}

// ==== CJiangHuAttribRand::Create  @1403f7950  [high:log-string]  (orig: FUN_1403f7950)
undefined8 FUN_1403f7950(longlong param_1)

{
  void *pvVar1;
  void *pvVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  void **ppvVar10;
  void **ppvVar11;
  int iVar12;
  char local_res10 [8];
  longlong *local_res18;
  longlong *local_res20;
  void **local_e0 [3];
  void *local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  void **local_b0 [3];
  void **local_98;
  void *local_90;
  char local_88 [8];
  void *local_80 [3];
  void *local_68;
  undefined8 local_60;
  undefined8 local_58;
  void **local_50;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)
           (**(code **)(*plVar5 + 0x10))(plVar5,"SELECT * FROM cq_jianghu_attrib_rand",1);
  uVar7 = 0;
  if (plVar5 != (longlong *)0x0) {
    local_res20 = plVar5;
    lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar6 == 0) {
      log_InlineLogERROR(
                        "CJiangHuAttribRand::Create(), cq_jianghu_attrib_rand record count is 0! at %s, %d"
                        );
      (**(code **)*plVar5)(plVar5);
      uVar7 = 0;
    }
    else {
      ppvVar10 = (void **)0x0;
      ppvVar11 = ppvVar10;
      while( true ) {
        iVar4 = (**(code **)(*plVar5 + 0x40))(plVar5);
        iVar12 = (int)ppvVar11;
        if (iVar4 <= iVar12) break;
        (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar12);
        plVar8 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        local_res18 = plVar8;
        if (plVar8 != (longlong *)0x0) {
          plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,1);
          local_res10[0] = (**(code **)(*plVar9 + 0x20))(plVar9);
          if (local_res10[0] == '\0') {
            log_InlineLogERROR(
                              "CJiangHuAttribRand::Create(), cq_jianghu_attrib_rand PowerLevel == 0, at %s, %d"
                              );
            (**(code **)*plVar8)(plVar8,1);
            local_res18 = (longlong *)0x0;
          }
          else {
            plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,2);
            cVar3 = (**(code **)(*plVar9 + 0x20))(plVar9);
            if (cVar3 == '\0') {
              log_InlineLogERROR(
                                "CJiangHuAttribRand::Create(), cq_jianghu_attrib_rand PowerAttrib == 0, at %s, %d"
                                );
              (**(code **)*plVar8)(plVar8,1);
              local_res18 = (longlong *)0x0;
            }
            else {
              FUN_1403f4d90(param_1 + 8,&local_98,local_res10);
              ppvVar11 = local_98;
              pvVar1 = *(void **)(param_1 + 0x38);
              local_b0[0] = *(void ***)(param_1 + 8);
              if ((local_98 == (void **)0x0) || (local_98 != local_b0[0])) {
                _invalid_parameter_noinfo();
              }
              pvVar2 = local_90;
              if (local_90 == pvVar1) {
                local_b0[0] = operator_new(8);
                local_e0[0] = ppvVar10;
                if (local_b0[0] != (void **)0x0) {
                  *local_b0[0] = local_e0;
                  local_e0[0] = local_b0[0];
                }
                local_c8 = (void *)0x0;
                local_c0 = 0;
                local_b8 = 0;
                local_50 = local_b0[0];
                FUN_140019370(local_e0,&local_res18);
                local_88[0] = local_res10[0];
                FUN_140267b90(local_80,local_e0);
                FUN_1403f6580(param_1 + 8,local_b0,local_88);
                local_b0[0] = local_80;
                if (local_68 != (void *)0x0) {
                  operator_delete(local_68);
                }
                local_68 = (void *)0x0;
                local_60 = 0;
                local_58 = 0;
                operator_delete(local_80[0]);
                if (local_c8 != (void *)0x0) {
                  operator_delete(local_c8);
                }
                local_c8 = (void *)0x0;
                local_c0 = 0;
                local_b8 = 0;
                operator_delete(local_e0[0]);
              }
              else {
                if (ppvVar11 == (void **)0x0) {
                  _invalid_parameter_noinfo();
                  ppvVar11 = ppvVar10;
                }
                else {
                  ppvVar11 = *ppvVar11;
                }
                if (pvVar2 == ppvVar11[6]) {
                  _invalid_parameter_noinfo();
                }
                FUN_140019370((longlong)pvVar2 + 0x20,&local_res18);
              }
            }
          }
        }
        ppvVar11 = (void **)(ulonglong)(iVar12 + 1);
      }
      (**(code **)*plVar5)(plVar5);
      FUN_1403f7440(param_1);
      uVar7 = 1;
    }
  }
  return uVar7;
}

// ==== CJiangHuAttribRand::ctor_or_dtor  @1403f7f30  [high:vtable-assign]  (orig: FUN_1403f7f30)
void FUN_1403f7f30(undefined8 *param_1)

{
  *param_1 = CJiangHuAttribRand::vftable;
  FUN_1401e0500(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_1403f70e0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CJiangHuAttribRand::ctor_or_dtor  @1403f7fa0  [high:vtable-assign]  (orig: FUN_1403f7fa0)
undefined8 *
FUN_1403f7fa0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = CJiangHuAttribRand::vftable;
  FUN_1403f7250(param_1 + 1);
  FUN_1401eb7e0(param_1 + 9);
  FUN_1403f6730(param_1 + 1,*(undefined8 *)(param_1[7] + 8),param_3,param_4,uVar1);
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  FUN_1401de010(param_1 + 9);
  return param_1;
}

// ==== CJiangHuAttribRand::ctor_or_dtor  @1403f8030  [high:vtable-assign]  (orig: FUN_1403f8030)
undefined8 * FUN_1403f8030(undefined8 *param_1,uint param_2)

{
  *param_1 = CJiangHuAttribRand::vftable;
  FUN_1401e0500(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_1403f70e0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

