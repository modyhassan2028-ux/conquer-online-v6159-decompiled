// ==== CResponder@adapter::helper_1405797b0  @1405797b0  [medium:callgraph-r1]  (orig: FUN_1405797b0)
void FUN_1405797b0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CResponder@adapter::helper_1405798a0  @1405798a0  [medium:callgraph-r1]  (orig: FUN_1405798a0)
void FUN_1405798a0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405798c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CResponder@adapter::helper_140579bc0  @140579bc0  [medium:callgraph-r1]  (orig: FUN_140579bc0)
void FUN_140579bc0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CResponder@adapter::helper_140579e30  @140579e30  [medium:callgraph-r1]  (orig: FUN_140579e30)
void FUN_140579e30(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140579e30(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CResponder@adapter::helper_140579f80  @140579f80  [medium:callgraph-r2]  (orig: FUN_140579f80)
undefined8 *
FUN_140579f80(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CResponder@adapter::helper_14057a050  @14057a050  [medium:callgraph-r2]  (orig: FUN_14057a050)
void FUN_14057a050(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140579e30(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CResponder@adapter::helper_14057a1b0  @14057a1b0  [medium:callgraph-r1]  (orig: FUN_14057a1b0)
undefined8 *
FUN_14057a1b0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140579f80(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CResponder@adapter::helper_14057a660  @14057a660  [medium:callgraph-r0]  (orig: FUN_14057a660)
undefined8 * FUN_14057a660(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CResponder@adapter::helper_14057a800  @14057a800  [medium:callgraph-r0]  (orig: FUN_14057a800)
undefined8 * FUN_14057a800(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1405798a0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14057a9ec;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14057a9ec:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140579bc0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1405797b0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140579bc0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1405797b0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140579bc0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1405797b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CResponder@adapter::helper_14057ac00  @14057ac00  [medium:callgraph-r1]  (orig: FUN_14057ac00)
longlong * FUN_14057ac00(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14057a050(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14057a800(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CResponder@adapter::helper_14057ae00  @14057ae00  [medium:callgraph-r0]  (orig: FUN_14057ae00)
undefined8 FUN_14057ae00(longlong param_1,uint param_2,uint param_3,char *param_4,char *param_5)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  bool bVar6;
  uint local_28 [2];
  uint *local_20;
  undefined1 local_18 [16];
  
  if ((((param_2 == 0) || (param_3 == 0)) || (param_4 == (char *)0x0)) || (param_5 == (char *)0x0))
  {
    uVar5 = 0;
  }
  else {
    local_20 = operator_new(0xa0);
    uVar5 = 0;
    if (local_20 != (uint *)0x0) {
      *local_20 = param_2;
      local_20[1] = param_3;
      strncpy((char *)(local_20 + 2),param_4,100);
      strncpy((char *)((longlong)local_20 + 0x6d),param_5,0x32);
      puVar2 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
      bVar6 = true;
      cVar1 = *(char *)((longlong)puVar2 + 0x29);
      puVar3 = *(undefined8 **)(param_1 + 0x38);
      while (cVar1 == '\0') {
        bVar6 = param_2 < *(uint *)(puVar2 + 3);
        if (bVar6) {
          puVar4 = (undefined8 *)*puVar2;
        }
        else {
          puVar4 = (undefined8 *)puVar2[2];
        }
        puVar3 = puVar2;
        puVar2 = puVar4;
        cVar1 = *(char *)((longlong)puVar4 + 0x29);
      }
      local_28[0] = param_2;
      FUN_14057a1b0(param_1 + 8,local_18,bVar6,puVar3,local_28);
      uVar5 = 1;
    }
  }
  return uVar5;
}

// ==== CResponder@adapter::vfunc_1  @14057af10  [high:rtti-vtable]  (orig: FUN_14057af10)
BADSPACEBASE *
FUN_14057af10(longlong param_1,int param_2,int param_3,char *param_4,char *param_5,longlong param_6)

{
  ushort uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int *piVar4;
  longlong *plVar5;
  longlong *plVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  undefined8 *puVar13;
  int local_res10 [2];
  undefined8 in_stack_ffffffffffffff88;
  undefined4 uVar14;
  longlong *local_48;
  longlong *local_40;
  longlong *local_38;
  longlong *local_30;
  
  if ((((param_2 != 0) && (param_3 != 0)) && (param_4 != (char *)0x0)) && (param_5 != (char *)0x0))
  {
    local_res10[0] = param_2;
    plVar10 = (longlong *)CurrentInstanceGet();
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,2);
    if (plVar10 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      register0x00000020 = (BADSPACEBASE *)0x0;
    }
    else {
      FUN_14057a660(param_1 + 8,&local_48,local_res10);
      plVar11 = local_40;
      while( true ) {
        if ((local_48 == (longlong *)0x0) || (local_48 != local_38)) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == local_30) break;
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *local_48;
        }
        if (plVar11 == *(longlong **)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        piVar4 = (int *)plVar11[4];
        if (((piVar4 != (int *)0x0) && (*piVar4 == param_2)) &&
           ((piVar4[1] == param_3 && (iVar8 = _stricmp((char *)(piVar4 + 2),param_4), iVar8 == 0))))
        {
          iVar8 = _stricmp((char *)((longlong)piVar4 + 0x6d),param_5);
          uVar14 = (undefined4)((ulonglong)in_stack_ffffffffffffff88 >> 0x20);
          if (iVar8 == 0) goto LAB_14057b0fe;
        }
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
          plVar5 = (longlong *)plVar11[2];
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
            cVar7 = *(char *)(*plVar5 + 0x29);
            plVar11 = plVar5;
            plVar5 = (longlong *)*plVar5;
            while (cVar7 == '\0') {
              cVar7 = *(char *)(*plVar5 + 0x29);
              plVar11 = plVar5;
              plVar5 = (longlong *)*plVar5;
            }
          }
          else {
            cVar7 = *(char *)(plVar11[1] + 0x29);
            plVar6 = (longlong *)plVar11[1];
            plVar5 = plVar11;
            while ((plVar11 = plVar6, cVar7 == '\0' && (plVar5 == (longlong *)plVar11[2]))) {
              cVar7 = *(char *)(plVar11[1] + 0x29);
              plVar6 = (longlong *)plVar11[1];
              plVar5 = plVar11;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      cVar7 = FUN_14057ae00(param_1,param_2,param_3,param_4,param_5);
      uVar14 = (undefined4)((ulonglong)param_5 >> 0x20);
      if (cVar7 == '\0') {
        return (BADSPACEBASE *)(undefined1 *)0x0;
      }
LAB_14057b0fe:
      if (param_6 != 0) {
        plVar11 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,param_3);
        if (plVar11 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          return (BADSPACEBASE *)(undefined1 *)0x0;
        }
        lVar12 = (**(code **)(*plVar11 + 0x2b0))(plVar11);
        if (lVar12 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          return (BADSPACEBASE *)(undefined1 *)0x0;
        }
        uVar3 = *(undefined4 *)(lVar12 + 0x122c);
        uVar1 = *(ushort *)(param_6 + 8);
        uVar2 = *(undefined2 *)(param_6 + 10);
        uVar9 = (**(code **)(*plVar10 + 0x38))(plVar10);
        puVar13 = (undefined8 *)
                  FUN_1402ba310(uVar9,uVar3,uVar2,param_6 + 0xc,CONCAT44(uVar14,uVar1 - 4),0);
        (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x350))((longlong *)(lVar12 + 0x10),puVar13);
        if (puVar13 != (undefined8 *)0x0) {
          (**(code **)*puVar13)(puVar13,1);
        }
      }
      register0x00000020 = (BADSPACEBASE *)0x1;
    }
  }
  return register0x00000020;
}

// ==== CResponder@adapter::vfunc_2  @14057b220  [high:rtti-vtable]  (orig: FUN_14057b220)
undefined8
FUN_14057b220(longlong param_1,int param_2,int param_3,longlong param_4,longlong param_5,
             longlong param_6)

{
  char cVar1;
  char cVar2;
  ushort uVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  int *piVar6;
  longlong *plVar7;
  int iVar8;
  longlong *plVar9;
  undefined4 uVar10;
  longlong *plVar11;
  int *piVar12;
  char *pcVar13;
  longlong *plVar14;
  undefined8 *puVar15;
  longlong lVar16;
  int local_res18 [2];
  longlong local_res20;
  int *local_80 [2];
  undefined8 local_70;
  longlong *local_68;
  longlong *plStack_60;
  longlong *local_58;
  longlong *local_50;
  longlong *local_48;
  longlong *local_40;
  
  local_70 = 0xfffffffffffffffe;
  if ((((param_2 != 0) && (param_3 != 0)) && (param_4 != 0)) && (param_5 != 0)) {
    local_res18[0] = param_3;
    local_res20 = param_4;
    plVar11 = (longlong *)CurrentInstanceGet();
    plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,2);
    if (plVar11 != (longlong *)0x0) {
      FUN_14057a660(param_1 + 8,&local_58,local_res18);
      local_68 = local_58;
      plStack_60 = local_50;
      plVar14 = local_50;
      do {
        if ((local_58 == (longlong *)0x0) || (local_58 != local_48)) {
          _invalid_parameter_noinfo();
        }
        if (plVar14 == local_40) {
          return 0;
        }
        if (local_58 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = 0;
        }
        else {
          lVar16 = *local_58;
        }
        if (plVar14 == *(longlong **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        piVar6 = (int *)plVar14[4];
        local_80[0] = piVar6;
        if (((piVar6 != (int *)0x0) && (*piVar6 == param_3)) && (piVar6[1] == param_2)) {
          piVar12 = piVar6 + 2;
          lVar16 = local_res20 - (longlong)piVar12;
          do {
            iVar8 = *piVar12;
            cVar1 = *(char *)((longlong)piVar12 + lVar16);
            if ((char)iVar8 != cVar1) break;
            piVar12 = (int *)((longlong)piVar12 + 1);
          } while (cVar1 != '\0');
          if ((char)iVar8 == cVar1) {
            pcVar13 = (char *)((longlong)piVar6 + 0x6d);
            lVar16 = param_5 - (longlong)pcVar13;
            do {
              cVar1 = *pcVar13;
              cVar2 = pcVar13[lVar16];
              if (cVar1 != cVar2) break;
              pcVar13 = pcVar13 + 1;
            } while (cVar2 != '\0');
            if (cVar1 == cVar2) {
              plVar14 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,param_3);
              if (plVar14 == (longlong *)0x0) {
                return 0;
              }
              lVar16 = (**(code **)(*plVar14 + 0x2b0))(plVar14);
              if (lVar16 != 0) {
                if (param_6 != 0) {
                  uVar5 = *(undefined4 *)(lVar16 + 0x122c);
                  uVar3 = *(ushort *)(param_6 + 8);
                  uVar4 = *(undefined2 *)(param_6 + 10);
                  uVar10 = (**(code **)(*plVar11 + 0x38))();
                  puVar15 = (undefined8 *)
                            FUN_1402ba310(uVar10,uVar5,uVar4,param_6 + 0xc,uVar3 - 4,0);
                  (**(code **)(*(longlong *)(lVar16 + 0x10) + 0x350))
                            ((longlong *)(lVar16 + 0x10),puVar15);
                  if (puVar15 != (undefined8 *)0x0) {
                    (**(code **)*puVar15)(puVar15,1);
                  }
                }
                FUN_14057a800(param_1 + 8,local_80,&local_68);
                operator_delete(piVar6);
                return 1;
              }
              log_InlineLogERROR(&DAT_1406d9c10);
              return 0;
            }
          }
        }
        if (local_58 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar14 + 0x29) == '\0') {
          plVar7 = (longlong *)plVar14[2];
          if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
            cVar1 = *(char *)(*plVar7 + 0x29);
            plVar14 = plVar7;
            plVar7 = (longlong *)*plVar7;
            while (plStack_60 = plVar14, cVar1 == '\0') {
              cVar1 = *(char *)(*plVar7 + 0x29);
              plVar14 = plVar7;
              plVar7 = (longlong *)*plVar7;
            }
          }
          else {
            cVar1 = *(char *)(plVar14[1] + 0x29);
            plVar9 = (longlong *)plVar14[1];
            plVar7 = plVar14;
            while ((plVar14 = plVar9, plStack_60 = plVar14, cVar1 == '\0' &&
                   (plVar7 == (longlong *)plVar14[2]))) {
              cVar1 = *(char *)(plVar14[1] + 0x29);
              plVar9 = (longlong *)plVar14[1];
              plVar7 = plVar14;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      } while( true );
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CResponder@adapter::vfunc_3  @14057b570  [high:rtti-vtable]  (orig: FUN_14057b570)
void FUN_14057b570(void)

{
  FUN_14057b220();
  return;
}

// ==== CResponder@adapter::helper_14057b6f0  @14057b6f0  [medium:callgraph-r0]  (orig: FUN_14057b6f0)
void FUN_14057b6f0(undefined8 *param_1)

{
  undefined8 *puVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *local_48;
  longlong *plStack_40;
  longlong *local_38;
  undefined8 uStack_30;
  undefined1 local_28 [16];
  
  *param_1 = adapter::CResponder::vftable;
  plVar6 = *(longlong **)param_1[7];
  plVar3 = (longlong *)param_1[1];
  local_48 = plVar3;
  plStack_40 = plVar6;
  while( true ) {
    plVar4 = (longlong *)param_1[7];
    if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar4) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar3;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((void *)plVar6[4] == (void *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      operator_delete((void *)plVar6[4]);
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar4 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar6 = plVar4;
        plVar4 = (longlong *)*plVar4;
        while (plStack_40 = plVar6, cVar2 == '\0') {
          cVar2 = *(char *)(*plVar4 + 0x29);
          plVar6 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar2 = *(char *)(plVar6[1] + 0x29);
        plVar5 = (longlong *)plVar6[1];
        plVar4 = plVar6;
        while ((plVar6 = plVar5, plStack_40 = plVar6, cVar2 == '\0' &&
               (plVar4 == (longlong *)plVar6[2]))) {
          cVar2 = *(char *)(plVar6[1] + 0x29);
          plVar5 = (longlong *)plVar6[1];
          plVar4 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar1 = param_1 + 1;
  cVar2 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar6 = *(longlong **)(param_1[7] + 8);
  while (cVar2 == '\0') {
    FUN_140579e30(puVar1,plVar6[2]);
    plVar3 = (longlong *)*plVar6;
    operator_delete(plVar6);
    plVar6 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  plStack_40 = (longlong *)param_1[7];
  local_48 = (longlong *)*puVar1;
  uStack_30 = *plStack_40;
  local_38 = local_48;
  FUN_14057ac00(puVar1,local_28,&local_38,&local_48);
  operator_delete((void *)param_1[7]);
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*puVar1);
  *param_1 = adapter::IResponder::vftable;
  return;
}

// ==== CResponder@adapter::vfunc_0  @14057b9f0  [high:rtti-vtable]  (orig: FUN_14057b9f0)
void * FUN_14057b9f0(void *param_1,uint param_2)

{
  FUN_14057b6f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

