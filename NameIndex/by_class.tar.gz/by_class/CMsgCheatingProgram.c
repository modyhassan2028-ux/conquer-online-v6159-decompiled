// ==== CMsgCheatingProgram::ctor_or_dtor  @14035cce0  [high:vtable-assign]  (orig: FUN_14035cce0)
undefined8 * FUN_14035cce0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCheatingProgram::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x14),0x3f9,true);
  return param_1;
}

// ==== CMsgCheatingProgram::ctor_or_dtor  @14035cd60  [high:vtable-assign]  (orig: FUN_14035cd60)
void FUN_14035cd60(undefined8 *param_1)

{
  *param_1 = CMsgCheatingProgram::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgCheatingProgram::vfunc_1  @14035ce40  [high:rtti-vtable]  (orig: FUN_14035ce40)
undefined8 FUN_14035ce40(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgCheatingProgram::ctor_or_dtor  @14035ce70  [high:vtable-assign]  (orig: FUN_14035ce70)
undefined8 * FUN_14035ce70(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCheatingProgram::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

