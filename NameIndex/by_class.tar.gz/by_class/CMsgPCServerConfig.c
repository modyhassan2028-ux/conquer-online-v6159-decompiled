// ==== CMsgPCServerConfig::ctor_or_dtor  @1403623c0  [high:vtable-assign]  (orig: FUN_1403623c0)
undefined8 * FUN_1403623c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPCServerConfig::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPCServerConfig::ctor_or_dtor  @140362410  [high:vtable-assign]  (orig: FUN_140362410)
void FUN_140362410(undefined8 *param_1)

{
  *param_1 = CMsgPCServerConfig::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPCServerConfig::vfunc_1  @140362440  [high:rtti-vtable]  (orig: FUN_140362440)
ulonglong FUN_140362440(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x419);
}

// ==== CMsgPCServerConfig::vfunc_3  @1403624b0  [high:rtti-vtable]  (orig: FUN_1403624b0)
void FUN_1403624b0(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001403624b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("CMsgPCServerConfig::Process Enter.");
  return;
}

// ==== CMsgPCServerConfig::ctor_or_dtor  @1403624c0  [high:vtable-assign]  (orig: FUN_1403624c0)
undefined8 * FUN_1403624c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPCServerConfig::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

