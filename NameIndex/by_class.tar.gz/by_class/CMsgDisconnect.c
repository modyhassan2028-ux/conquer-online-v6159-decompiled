// ==== CMsgDisconnect::ctor_or_dtor  @14007d430  [high:vtable-assign]  (orig: FUN_14007d430)
undefined8 * FUN_14007d430(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgDisconnect::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgDisconnect::ctor_or_dtor  @14007d480  [high:vtable-assign]  (orig: FUN_14007d480)
void FUN_14007d480(undefined8 *param_1)

{
  *param_1 = CMsgDisconnect::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgDisconnect::vfunc_1  @14007d570  [high:rtti-vtable]  (orig: FUN_14007d570)
ulonglong FUN_14007d570(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x45b);
}

// ==== CMsgDisconnect::ctor_or_dtor  @14007d5a0  [high:vtable-assign]  (orig: FUN_14007d5a0)
undefined8 * FUN_14007d5a0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgDisconnect::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

