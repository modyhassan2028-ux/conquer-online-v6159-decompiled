// ==== CSupermanList::helper_14007f7b0  @14007f7b0  [medium:callgraph-r0]  (orig: FUN_14007f7b0)
void FUN_14007f7b0(void *param_1)

{
  if ((DAT_140975b58 & 1) == 0) {
    DAT_140975b58 = DAT_140975b58 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975b50,"CSupermanList");
    atexit((_func_5014 *)&LAB_1406d65f0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014007f805. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975b50,param_1);
  return;
}

// ==== CSupermanList::ctor_or_dtor  @140080930  [high:vtable-assign]  (orig: FUN_140080930)
undefined8 * FUN_140080930(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CSupermanList::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}

// ==== CSupermanList::ctor_or_dtor  @1400809a0  [high:vtable-assign]  (orig: FUN_1400809a0)
void FUN_1400809a0(undefined8 *param_1)

{
  *param_1 = CSupermanList::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CSupermanList::ctor_or_dtor  @140080df0  [high:vtable-assign]  (orig: FUN_140080df0)
undefined8 * FUN_140080df0(undefined8 *param_1,uint param_2)

{
  *param_1 = CSupermanList::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_14007f7b0(param_1);
  }
  return param_1;
}

