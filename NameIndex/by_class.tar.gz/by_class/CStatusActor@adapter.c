// ==== CStatusActor@adapter::helper_140152c80  @140152c80  [medium:callgraph-r2]  (orig: FUN_140152c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140152c80(longlong param_1,longlong *param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  ulonglong uVar5;
  undefined1 auStack_58 [32];
  undefined4 local_38;
  ushort local_28 [12];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  if (param_2 == (longlong *)0x0) {
    uVar1 = local_10 & 0xffffffffffff0000;
  }
  else {
    uVar1 = 0;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
    if (*(longlong *)(lVar2 + 0xf8) == 0) {
      local_38 = 0x142;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(param_2[2] + 0x1d8))(param_2 + 2);
    (**(code **)(*param_2 + 8))(param_2);
    lVar2 = 1;
    iVar4 = 1;
    do {
      if (10 < iVar4) break;
      iVar4 = iVar4 + 1;
      lVar2 = lVar2 * 10;
    } while (iVar4 < 5);
    if (lVar2 < 1) {
      uVar5 = 0;
    }
    else {
      if (lVar2 < 1) {
        lVar2 = 1;
      }
      uVar5 = (lVar3 / lVar2) % 10;
    }
    if ((int)(uVar5 & 0xff) - 1U < 9) {
      local_28[0] = 0;
      local_28[1] = 8;
      local_28[2] = 0x10;
      local_28[3] = 0x18;
      local_28[4] = 0x20;
      local_28[5] = 0x28;
      local_28[6] = 0x30;
      local_28[7] = 0x38;
      local_28[8] = 0x40;
      local_28[9] = 0x48;
      uVar1 = (ulonglong)local_28[uVar5 & 0xff];
      if (100 < local_28[uVar5 & 0xff]) {
        return 100;
      }
    }
  }
  return uVar1;
}

// ==== CStatusActor@adapter::helper_140160c50  @140160c50  [medium:callgraph-r0]  (orig: FUN_140160c50)
void FUN_140160c50(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xb8c) = param_2;
  return;
}

// ==== CStatusActor@adapter::helper_140161550  @140161550  [medium:callgraph-r0]  (orig: FUN_140161550)
void FUN_140161550(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0xa78) = param_2;
  return;
}

// ==== CStatusActor@adapter::helper_140164ab0  @140164ab0  [medium:callgraph-r0]  (orig: FUN_140164ab0)
void FUN_140164ab0(longlong param_1,undefined2 param_2)

{
  *(undefined2 *)(param_1 + 400) = param_2;
  return;
}

// ==== CStatusActor@adapter::helper_1401650c0  @1401650c0  [medium:callgraph-r0]  (orig: FUN_1401650c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401650c0(longlong *param_1)

{
  undefined4 uVar1;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  *(undefined4 *)(param_1 + 0x235) = 2;
  *(undefined4 *)((longlong)param_1 + 0x11a4) = 0;
  FUN_14039e680(local_448);
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  FUN_14039e700(local_448,uVar1,0x1f);
  (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
  FUN_14039e6d0(local_448);
  return;
}

// ==== CStatusActor@adapter::helper_14016daa0  @14016daa0  [medium:callgraph-r1]  (orig: FUN_14016daa0)
ushort FUN_14016daa0(longlong param_1)

{
  short sVar1;
  ushort uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  short sVar7;
  int iVar8;
  
  iVar8 = 1;
  sVar7 = 0;
  do {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar5 = *plVar6;
    uVar3 = FUN_14032b4b0(param_1,iVar8);
    lVar5 = (**(code **)(lVar5 + 0x60))(plVar6,uVar3);
    if ((lVar5 != 0) &&
       (((plVar6 = (longlong *)FUN_140100070(lVar5), plVar6 != (longlong *)0x0 ||
         (plVar6 = (longlong *)FUN_140100080(lVar5), plVar6 != (longlong *)0x0)) &&
        (iVar4 = (**(code **)(*plVar6 + 0x30))(plVar6,3), iVar4 == 0x130)))) {
      sVar1 = (**(code **)(*plVar6 + 0x10))(plVar6);
      sVar7 = sVar7 + sVar1;
    }
    iVar8 = iVar8 + 1;
  } while (iVar8 < 0x14);
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  plVar6 = *(longlong **)(lVar5 + 0xf8);
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar6 = (longlong *)0x0;
  }
  sVar1 = FUN_140152c80(plVar6,param_1);
  uVar2 = 100;
  if ((ushort)(sVar7 + sVar1) < 0x65) {
    uVar2 = sVar7 + sVar1;
  }
  return uVar2;
}

// ==== CStatusActor@adapter::helper_14016dbf0  @14016dbf0  [medium:callgraph-r0]  (orig: FUN_14016dbf0)
void FUN_14016dbf0(undefined8 param_1,int param_2)

{
  ushort uVar1;
  
  if (param_2 < 0) {
    param_2 = 0;
  }
  uVar1 = FUN_14016daa0();
                    /* WARNING: Could not recover jumptable at 0x00014016dc1d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  MulDiv(param_2,100 - (uint)uVar1,100);
  return;
}

// ==== CStatusActor@adapter::helper_140171a50  @140171a50  [medium:callgraph-r0]  (orig: FUN_140171a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140171a50(longlong *param_1)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  undefined1 auStack_48 [32];
  undefined4 *local_28;
  undefined4 local_18;
  undefined4 local_14;
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  uVar3 = (**(code **)(*param_1 + 8))();
  if ((uVar3 < 0xee69a15f) || (*(int *)((longlong)param_1 + 0x12fc) == 0)) {
    cVar2 = (**(code **)(param_1[2] + 0x230))(param_1 + 2);
    if ((cVar2 == '\0') &&
       ((iVar1 = *(int *)((longlong)param_1 + 0xa6c), 0x18 < iVar1 && ((int)param_1[0x14e] < iVar1))
       )) {
      *(int *)(param_1 + 0x14e) = iVar1;
      *(undefined4 *)((longlong)param_1 + 0xa6c) = 0;
      local_18 = (**(code **)(*param_1 + 8))(param_1);
      local_14 = (undefined4)param_1[0x14e];
      uVar4 = FUN_140008520((int)param_1[0x246]);
      plVar5 = (longlong *)FUN_14001b560(uVar4);
      local_28 = &local_18;
      (**(code **)(*plVar5 + 0x50))(plVar5,2,0x3f6,8);
      return;
    }
  }
  *(undefined4 *)((longlong)param_1 + 0xa6c) = 0;
  return;
}

// ==== CStatusActor@adapter::helper_140177d10  @140177d10  [medium:callgraph-r0]  (orig: FUN_140177d10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140177d10(longlong *param_1,int param_2,char param_3)

{
  char cVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 uVar7;
  undefined1 auStack_4c8 [32];
  undefined1 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_484;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar5 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar5 + 200))(plVar5,param_2);
  if (cVar1 != '\0') {
    plVar5 = (longlong *)FUN_1401181a0();
    lVar6 = *plVar5;
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    cVar1 = (**(code **)(lVar6 + 0xc0))(plVar5,uVar3,param_2);
    cVar2 = (**(code **)(param_1[2] + 0x2d8))(param_1 + 2,param_2);
    if (cVar2 != '\0') {
      uVar4 = 0;
      plVar5 = (longlong *)FUN_1401181a0();
      lVar6 = *plVar5;
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      local_488 = (**(code **)(lVar6 + 0xb0))(plVar5,uVar3,param_2);
      plVar5 = (longlong *)FUN_1401181a0();
      lVar6 = *plVar5;
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      local_484 = (**(code **)(lVar6 + 0xb8))(plVar5,uVar3,param_2);
      if ((param_2 == 0x31) || (param_2 == 0x32)) {
        uVar4 = FUN_1401663b0(param_1);
      }
      uVar7 = 0;
      if (param_3 != '\0') {
        uVar7 = 2;
      }
      FUN_1403b5d30(local_478);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      local_498 = local_484;
      local_4a0 = local_488;
      local_4a8 = cVar1 != '\0';
      local_490 = uVar4;
      cVar1 = FUN_1403b5de0(local_478,uVar3,param_2 + 3,uVar7);
      if (cVar1 == '\0') {
        FUN_1403b5d80(local_478);
      }
      else {
        FUN_140166440(param_1,local_478,param_2);
        lVar6 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        if (lVar6 == 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
        }
        else {
          (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_478,1);
        }
        FUN_1403b5d80(local_478);
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::helper_140178d20  @140178d20  [medium:callgraph-r0]  (orig: FUN_140178d20)
int FUN_140178d20(longlong param_1)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 0xb68) = 1;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0xb6c) = uVar1 / 1000;
  return uVar1 * 0x10624dd3;
}

// ==== CStatusActor@adapter::helper_140178d60  @140178d60  [medium:callgraph-r0]  (orig: FUN_140178d60)
void FUN_140178d60(longlong param_1)

{
  *(undefined4 *)(param_1 + 0xb6c) = 0;
  *(undefined4 *)(param_1 + 0xb68) = 0;
  return;
}

// ==== CStatusActor@adapter::helper_14018fa20  @14018fa20  [medium:callgraph-r0]  (orig: FUN_14018fa20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14018fa20(longlong *param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined1 auStack_4c8 [32];
  undefined1 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar8 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar8 + 200))(plVar8,param_2);
  if (cVar1 != '\0') {
    if (param_2 == 0x34) {
      iVar3 = (int)param_1[0x171];
      iVar2 = FUN_140180090(param_1);
      if (iVar2 < iVar3) {
        iVar3 = FUN_140180090(param_1);
      }
      FUN_14018e220(param_1,iVar3);
      FUN_140160b00(param_1);
    }
    cVar1 = (**(code **)(param_1[2] + 0x2d8))(param_1 + 2,param_2);
    if (cVar1 != '\0') {
      uVar6 = 0;
      plVar8 = (longlong *)FUN_1401181a0();
      lVar9 = *plVar8;
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      uVar4 = (**(code **)(lVar9 + 0xb0))(plVar8,uVar4,param_2);
      plVar8 = (longlong *)FUN_1401181a0();
      lVar9 = *plVar8;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      uVar5 = (**(code **)(lVar9 + 0xb8))(plVar8,uVar5,param_2);
      if ((param_2 == 0x31) || (param_2 == 0x32)) {
        plVar8 = (longlong *)FUN_1401181a0();
        lVar9 = *plVar8;
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar9 + 0xe8))(plVar8,uVar6,param_2,0);
        uVar6 = FUN_1401663b0(param_1);
      }
      FUN_1403b5d30(local_478);
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      local_4a8 = 0;
      local_4a0 = uVar4;
      local_498 = uVar5;
      local_490 = uVar6;
      cVar1 = FUN_1403b5de0(local_478,uVar7,param_2 + 3,1);
      if (cVar1 == '\0') {
        FUN_1403b5d80(local_478);
      }
      else {
        FUN_140166440(param_1,local_478,param_2);
        lVar9 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        if (lVar9 == 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
        }
        else {
          (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_478,1);
        }
        FUN_1403b5d80(local_478);
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::helper_1402b56f0  @1402b56f0  [medium:callgraph-r1]  (orig: FUN_1402b56f0)
undefined8 FUN_1402b56f0(uint param_1)

{
  void *pvVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  
  uVar3 = 0;
  uVar2 = 0;
  if (param_1 < 0x524) {
    if (param_1 == 0x523) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_14035bb80(pvVar1);
      }
    }
    else {
      uVar2 = uVar3;
      switch(param_1) {
      case 0x3ec:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14015b240(pvVar1);
        }
        break;
      case 0x3ee:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14044df40(pvVar1);
        }
        break;
      case 0x3f0:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140458720(pvVar1);
        }
        break;
      case 0x3f1:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1400f83e0(pvVar1);
        }
        break;
      case 0x3f4:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403edea0(pvVar1);
        }
        break;
      case 0x3f7:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14037dfb0(pvVar1);
        }
        break;
      case 0x3f8:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140456d30(pvVar1);
        }
        break;
      case 0x3fe:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14035f2f0(pvVar1);
        }
        break;
      case 0x400:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1404575b0(pvVar1);
        }
        break;
      case 0x401:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403b3fd0(pvVar1);
        }
        break;
      case 0x403:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140456ad0(pvVar1);
        }
        break;
      case 0x404:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1404592c0(pvVar1);
        }
        break;
      case 0x408:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403f0c40(pvVar1);
        }
        break;
      case 0x409:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403a6980(pvVar1);
        }
        break;
      case 0x40c:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403b3d40(pvVar1);
        }
        break;
      case 0x40d:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140455d00(pvVar1);
        }
        break;
      case 0x40e:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1404557e0(pvVar1);
        }
        break;
      case 0x40f:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140457e30(pvVar1);
        }
        break;
      case 0x412:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1404579b0(pvVar1);
        }
        break;
      case 0x413:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140455550(pvVar1);
        }
        break;
      case 0x415:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14035c460(pvVar1);
        }
        break;
      case 0x416:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_14035bec0(pvVar1);
        }
        break;
      case 0x42c:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403b58f0(pvVar1);
        }
        break;
      case 0x42d:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403865d0(pvVar1);
        }
        break;
      case 0x44d:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403a5840(pvVar1);
        }
        break;
      case 0x44f:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140456f30(pvVar1);
        }
        break;
      case 0x450:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403eff70(pvVar1);
        }
        break;
      case 0x451:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140386780(pvVar1);
        }
        break;
      case 0x454:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140387320(pvVar1);
        }
        break;
      case 0x455:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140456560(pvVar1);
        }
        break;
      case 0x456:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140456380(pvVar1);
        }
        break;
      case 0x457:
        pvVar1 = operator_new(0x448);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140458b20(pvVar1);
        }
        break;
      case 0x459:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140455ef0(pvVar1);
        }
        break;
      case 0x466:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140455a10(pvVar1);
        }
        break;
      case 0x467:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403f33e0(pvVar1);
        }
        break;
      case 0x470:
        pvVar1 = operator_new(0x430);
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403778c0(pvVar1);
        }
      }
    }
  }
  else if (param_1 < 0x961) {
    if (param_1 == 0x960) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_140420930(pvVar1);
      }
    }
    else if (param_1 < 0x7ef) {
      if (param_1 == 0x7ee) {
        pvVar1 = operator_new(0x448);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140454910(pvVar1);
        }
      }
      else if (param_1 == 0x52b) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140454ef0(pvVar1);
        }
      }
      else if (param_1 == 0x52c) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1404552d0(pvVar1);
        }
      }
      else {
        uVar2 = uVar3;
        if ((param_1 == 0x547) && (pvVar1 = operator_new(0x430), pvVar1 != (void *)0x0)) {
          uVar2 = FUN_140424690(pvVar1);
        }
      }
    }
    else if (param_1 < 0x8fd) {
      if (param_1 == 0x8fc) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140451580(pvVar1);
        }
      }
      else {
        switch(param_1) {
        case 0x7ef:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_14037d4a0(pvVar1);
          }
          break;
        case 0x7f0:
          pvVar1 = operator_new(0x448);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1403a6340(pvVar1);
          }
          break;
        case 0x7f3:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140454650(pvVar1);
          }
          break;
        case 0x7f4:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140453a60(pvVar1);
          }
          break;
        case 0x800:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1403f2320(pvVar1);
          }
          break;
        case 0x818:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140452560(pvVar1);
          }
          break;
        case 0x81c:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140452310(pvVar1);
          }
          break;
        case 0x820:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1403ee140(pvVar1);
          }
          break;
        case 0x82a:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1404531c0(pvVar1);
          }
          break;
        case 0x82d:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140452b50(pvVar1);
          }
          break;
        case 0x830:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140452f10(pvVar1);
          }
          break;
        case 0x833:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140453510(pvVar1);
          }
          break;
        case 0x83e:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140451eb0(pvVar1);
          }
          break;
        case 0x87b:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_140453760(pvVar1);
          }
          break;
        case 0x8ac:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1403f2a40(pvVar1);
          }
          break;
        case 0x8b5:
          pvVar1 = operator_new(0x448);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_1404518e0(pvVar1);
          }
          break;
        case 0x8d5:
          pvVar1 = operator_new(0x430);
          uVar2 = uVar3;
          if (pvVar1 != (void *)0x0) {
            uVar2 = FUN_14044e580(pvVar1);
          }
        }
      }
    }
    else if (param_1 == 0x906) {
      pvVar1 = operator_new(0x448);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_140451200(pvVar1);
      }
    }
    else if ((param_1 == 0x910) &&
            (pvVar1 = operator_new(0x430), uVar2 = uVar3, pvVar1 != (void *)0x0)) {
      uVar2 = FUN_1403b0410(pvVar1);
    }
  }
  else if (param_1 < 0xaf5) {
    if (param_1 == 0xaf4) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_1404500a0(pvVar1);
      }
    }
    else if (param_1 < 0xa29) {
      if (param_1 == 0xa28) {
        pvVar1 = operator_new(0x468);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140450b00(pvVar1);
        }
      }
      else if (param_1 == 0x961) {
        pvVar1 = operator_new(0x448);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140422f50(pvVar1);
        }
      }
      else if (param_1 == 0x96a) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_140423310(pvVar1);
        }
      }
      else if (param_1 == 0x97e) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403b66d0(pvVar1);
        }
      }
      else if (param_1 == 0x9e5) {
        pvVar1 = operator_new(0x430);
        uVar2 = uVar3;
        if (pvVar1 != (void *)0x0) {
          uVar2 = FUN_1403b6340(pvVar1);
        }
      }
      else if ((param_1 == 0x9e8) &&
              (pvVar1 = operator_new(0x430), uVar2 = uVar3, pvVar1 != (void *)0x0)) {
        uVar2 = FUN_140450dc0(pvVar1);
      }
    }
    else if (param_1 == 0xa32) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_14040a650(pvVar1);
      }
    }
    else if (param_1 == 0xa8c) {
      pvVar1 = operator_new(0x448);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_140400920(pvVar1);
      }
    }
    else if (param_1 == 0xa8e) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_140401810(pvVar1);
      }
    }
    else if (param_1 == 0xa8f) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_1404503d0(pvVar1);
      }
    }
    else if ((param_1 == 0xaf0) &&
            (pvVar1 = operator_new(0x430), uVar2 = uVar3, pvVar1 != (void *)0x0)) {
      uVar2 = FUN_1404507d0(pvVar1);
    }
  }
  else if (param_1 < 0x271b) {
    if (param_1 == 0x271a) {
      pvVar1 = operator_new(0x448);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_140362560(pvVar1);
      }
    }
    else if (param_1 == 0xaf5) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_1404131e0(pvVar1);
      }
    }
    else if (param_1 == 0xafc) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_14044f830(pvVar1);
      }
    }
    else if (param_1 == 0xb54) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_14044fb40(pvVar1);
      }
    }
    else if (param_1 == 0xb56) {
      pvVar1 = operator_new(0x430);
      uVar2 = uVar3;
      if (pvVar1 != (void *)0x0) {
        uVar2 = FUN_14044fd60(pvVar1);
      }
    }
    else if ((param_1 == 0x2715) &&
            (pvVar1 = operator_new(0x478), uVar2 = uVar3, pvVar1 != (void *)0x0)) {
      uVar2 = FUN_1403ed0f0(pvVar1);
    }
  }
  else if (param_1 == 0x271e) {
    pvVar1 = operator_new(0x448);
    if (pvVar1 != (void *)0x0) {
      uVar2 = FUN_14039ed70(pvVar1);
    }
  }
  else if (param_1 == 0x2721) {
    pvVar1 = operator_new(0x430);
    uVar2 = uVar3;
    if (pvVar1 != (void *)0x0) {
      uVar2 = FUN_14039e680(pvVar1);
    }
  }
  else if (param_1 == 0x4e21) {
    pvVar1 = operator_new(0x430);
    uVar2 = uVar3;
    if (pvVar1 != (void *)0x0) {
      uVar2 = FUN_14044f280(pvVar1);
    }
  }
  else if (param_1 == 0x4e22) {
    pvVar1 = operator_new(0x430);
    uVar2 = uVar3;
    if (pvVar1 != (void *)0x0) {
      uVar2 = FUN_14044f5d0(pvVar1);
    }
  }
  else if ((param_1 == 0x9c49) &&
          (pvVar1 = operator_new(0x430), uVar2 = uVar3, pvVar1 != (void *)0x0)) {
    uVar2 = FUN_1403f0820(pvVar1);
  }
  return uVar2;
}

// ==== CStatusActor@adapter::helper_1402ba440  @1402ba440  [medium:callgraph-r0]  (orig: FUN_1402ba440)
longlong FUN_1402ba440(undefined4 param_1,undefined4 param_2,int param_3,void *param_4,uint param_5,
                      undefined4 param_6)

{
  longlong lVar1;
  
  if (((param_3 == 0) || (param_4 == (void *)0x0)) || (0x400 < (int)param_5)) {
    lVar1 = 0;
  }
  else {
    lVar1 = FUN_1402b56f0(param_3,param_4,param_5);
    if (lVar1 != 0) {
      *(undefined4 *)(lVar1 + 0x410) = param_1;
      *(undefined4 *)(lVar1 + 0x414) = 0xffffffff;
      *(undefined4 *)(lVar1 + 0x418) = param_2;
      *(int *)(lVar1 + 8) = param_3;
      *(uint *)(lVar1 + 0xc) = param_5;
      *(undefined4 *)(lVar1 + 0x424) = param_6;
      memcpy((void *)(lVar1 + 0x10),param_4,(ulonglong)param_5);
    }
  }
  return lVar1;
}

// ==== CStatusActor@adapter::helper_1402ecf70  @1402ecf70  [medium:callgraph-r0]  (orig: FUN_1402ecf70)
void FUN_1402ecf70(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c8));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_3);
  if (lVar1 != 0) {
    FUN_1403eb000(param_2,lVar1,param_4);
  }
  return;
}

// ==== CStatusActor@adapter::helper_14039e870  @14039e870  [medium:callgraph-r0]  (orig: FUN_14039e870)
undefined8
FUN_14039e870(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  ulong uVar2;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x28;
  *(undefined4 *)(param_1 + 8) = 0x2721;
  uVar2 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = 0;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x1c + 0xc +
   *(longlong *)(param_1 + 0x428)) = param_3;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x1c + 0x10 +
   *(longlong *)(param_1 + 0x428)) = param_4;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x1c + 0x14 +
   *(longlong *)(param_1 + 0x428)) = param_5;
  *(undefined4 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 8) * 0x1c + 0x18 +
   *(longlong *)(param_1 + 0x428)) = param_6;
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 8);
  *piVar1 = *piVar1 + 1;
  return 1;
}

// ==== CStatusActor@adapter::helper_1403eb000  @1403eb000  [medium:callgraph-r1]  (orig: FUN_1403eb000)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403eb000(int param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  undefined1 auStack_918 [32];
  undefined4 local_8f8;
  undefined4 local_8f0;
  int local_8e8;
  undefined4 local_8e0;
  undefined4 local_8d8;
  undefined8 local_8c8;
  undefined1 local_8c0 [24];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8c8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_918;
  if (param_2 == (longlong *)0x0) {
    uVar2 = 0;
  }
  else {
    iVar5 = (**(code **)(*param_2 + 8))(param_2);
    param_2 = param_2 + 2;
    cVar1 = (**(code **)(*param_2 + 0x2d8))(param_2,0x59);
    uVar2 = 0;
    if (cVar1 != '\0') {
      iVar6 = *param_3;
      if (iVar6 < 2) {
        iVar6 = 1;
      }
      *param_3 = iVar6;
      plVar10 = (longlong *)FUN_1401181a0();
      iVar6 = (**(code **)(*plVar10 + 0xb0))(plVar10,iVar5,0x59);
      if (*param_3 < iVar6) {
        plVar10 = (longlong *)FUN_1401181a0();
        (**(code **)(*plVar10 + 0xe8))(plVar10,iVar5,0x59,iVar6 - *param_3);
        iVar6 = *param_3;
        *param_3 = 0;
        FUN_14039e680(local_8a8);
        (**(code **)(*param_2 + 0x58))(param_2,local_8c0);
        iVar7 = FUN_14039ec00(local_8a8,iVar5,0x19,local_8c0);
        if (iVar7 != 0) {
          plVar10 = (longlong *)FUN_1401181a0();
          uVar8 = (**(code **)(*plVar10 + 0xb0))(plVar10,iVar5,0x59);
          plVar10 = (longlong *)FUN_1401181a0();
          uVar9 = (**(code **)(*plVar10 + 0xb8))(plVar10,iVar5,0x59);
          plVar10 = (longlong *)FUN_1401181a0();
          local_8f0 = (**(code **)(*plVar10 + 0xa0))(plVar10,iVar5,0x59);
          local_8f8 = uVar8;
          FUN_14039ea30(local_8a8,0x31,0x5d,uVar9);
          (**(code **)(*param_2 + 0x348))(param_2,local_8a8,1);
        }
        FUN_14039e6d0(local_8a8);
      }
      else {
        *param_3 = *param_3 - iVar6;
        plVar10 = (longlong *)FUN_1401181a0();
        (**(code **)(*plVar10 + 0x10))(plVar10,iVar5,0x59);
      }
      if (param_1 == 0) {
        param_1 = iVar5;
      }
      FUN_14035f2f0(local_478);
      uVar3 = (**(code **)(*param_2 + 0x48))(param_2);
      uVar4 = (**(code **)(*param_2 + 0x40))(param_2);
      local_8d8 = 0;
      local_8e0 = 0;
      local_8f0 = CONCAT22(local_8f0._2_2_,uVar3);
      local_8f8 = CONCAT22(local_8f8._2_2_,uVar4);
      local_8e8 = iVar6;
      iVar5 = FUN_14035f3a0(local_478,0x37,param_1,iVar5);
      if (iVar5 != 0) {
        (**(code **)(*param_2 + 0x348))(param_2,local_478,1);
      }
      iVar5 = *param_3;
      if (iVar5 < 1) {
        iVar5 = 0;
      }
      *param_3 = iVar5;
      FUN_14035f340(local_478);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CStatusActor@adapter::vfunc_1  @14059e6e0  [high:rtti-vtable]  (orig: FUN_14059e6e0)
void FUN_14059e6e0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_0  @14059e700  [high:rtti-vtable]  (orig: FUN_14059e700)
ulonglong FUN_14059e700(longlong param_1,undefined8 param_2,longlong param_3)

{
  ulonglong in_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (param_3 == 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014059e735. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar2 = (**(code **)(*plVar1 + 0x130))(plVar1,0);
        return uVar2;
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CStatusActor@adapter::vfunc_1  @14059e750  [high:rtti-vtable]  (orig: FUN_14059e750)
void FUN_14059e750(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (((param_3 != 0) &&
      (plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))(),
      plVar1 != (longlong *)0x0)) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
    (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x358))((longlong *)(lVar2 + 0x10),param_3);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_4  @14059e7a0  [high:rtti-vtable]  (orig: FUN_14059e7a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059e7a0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined1 auStack_4d8 [32];
  undefined1 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined1 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar5 != (longlong *)0x0) {
    lVar6 = (**(code **)(*plVar5 + 0x2b0))(plVar5);
    plVar7 = (longlong *)(**(code **)(*plVar5 + 0x160))(plVar5);
    if (plVar7 != (longlong *)0x0) {
      FUN_140386780(local_478);
      local_490 = 0;
      local_498 = 0;
      local_4a0 = 0;
      local_4a8 = param_5;
      local_4b8 = 0;
      local_4b0 = param_4;
      iVar2 = FUN_1403868f0(local_478,param_2,param_3,0);
      if (iVar2 == 0) {
        FUN_1403867d0(local_478);
      }
      else {
        if (lVar6 == 0) {
          lVar6 = *plVar7;
          uVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
          uVar4 = (**(code **)(*plVar5 + 0x40))(plVar5);
          (**(code **)(lVar6 + 0x28))(plVar7,uVar4,uVar3,local_478);
        }
        else {
          lVar1 = *plVar7;
          uVar3 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x48))(lVar6 + 0x10);
          uVar4 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x40))(lVar6 + 0x10);
          (**(code **)(lVar1 + 0x28))(plVar7,uVar4,uVar3,local_478);
        }
        FUN_1403867d0(local_478);
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_6  @14059e8f0  [high:rtti-vtable]  (orig: FUN_14059e8f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059e8f0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_14039e680(local_468);
  local_480 = param_6;
  local_488 = param_5;
  iVar1 = FUN_14039e870(local_468,param_2,param_3,param_4);
  if (iVar1 != 0) {
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                       (*(longlong **)(param_1 + 0x10),param_2);
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x350))(plVar2,local_468);
    }
  }
  FUN_14039e6d0(local_468);
  return;
}

// ==== CStatusActor@adapter::vfunc_5  @14059e9b0  [high:rtti-vtable]  (orig: FUN_14059e9b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059e9b0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_14039e680(local_468);
  iVar1 = FUN_14039e700(local_468,param_2,param_3,param_4);
  if (iVar1 != 0) {
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                       (*(longlong **)(param_1 + 0x10),param_2);
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x350))(plVar2,local_468);
    }
  }
  FUN_14039e6d0(local_468);
  return;
}

// ==== CStatusActor@adapter::vfunc_12  @14059ea50  [high:rtti-vtable]  (orig: FUN_14059ea50)
undefined8 FUN_14059ea50(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059ea88. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x40))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0xffffffff;
}

// ==== CStatusActor@adapter::vfunc_13  @14059ea90  [high:rtti-vtable]  (orig: FUN_14059ea90)
undefined8 FUN_14059ea90(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059eac8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x48))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0xffffffff;
}

// ==== CStatusActor@adapter::vfunc_14  @14059ead0  [high:rtti-vtable]  (orig: FUN_14059ead0)
undefined8 FUN_14059ead0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059eb08. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x50))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0xffffffff;
}

// ==== CStatusActor@adapter::vfunc_18  @14059eb10  [high:rtti-vtable]  (orig: FUN_14059eb10)
void FUN_14059eb10(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059eb4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x220))(lVar2 + 0x10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059eb5e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x220))(plVar1);
  return;
}

// ==== CStatusActor@adapter::vfunc_19  @14059eb70  [high:rtti-vtable]  (orig: FUN_14059eb70)
undefined8 FUN_14059eb70(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  undefined8 local_res8 [4];
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 != (longlong *)0x0) {
    local_res8[0] = 0;
    cVar1 = (**(code **)(*plVar2 + 0x298))(plVar2,0x1002,local_res8);
    if (cVar1 != '\0') {
      uVar3 = FUN_140388010(local_res8[0],2);
      return uVar3;
    }
  }
  return 1;
}

// ==== CStatusActor@adapter::vfunc_7  @14059ebd0  [high:rtti-vtable]  (orig: FUN_14059ebd0)
void FUN_14059ebd0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x2c8))(plVar1,param_3,param_4);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_8  @14059ec10  [high:rtti-vtable]  (orig: FUN_14059ec10)
void FUN_14059ec10(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140177d10(lVar2,param_3,param_4);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_9  @14059ec60  [high:rtti-vtable]  (orig: FUN_14059ec60)
void FUN_14059ec60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x2d0))(plVar1,param_3,1);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_10  @14059ec90  [high:rtti-vtable]  (orig: FUN_14059ec90)
void FUN_14059ec90(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_14018fa20(lVar2,param_3);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_11  @14059ecd0  [high:rtti-vtable]  (orig: FUN_14059ecd0)
void FUN_14059ecd0(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  
  plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((((plVar6 != (longlong *)0x0) &&
       (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x2b0))(plVar6), plVar6 != (longlong *)0x0)) &&
      (param_3 == 0x16)) && (cVar2 = FUN_140160510(plVar6), cVar2 != '\0')) {
    lVar1 = plVar6[2];
    uVar3 = (**(code **)(lVar1 + 0x48))(plVar6 + 2);
    uVar4 = (**(code **)(plVar6[2] + 0x40))(plVar6 + 2);
    uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar1 + 0x3c0))(plVar6 + 2,0x1b59,uVar5,uVar4,uVar3);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_20  @14059ed90  [high:rtti-vtable]  (orig: FUN_14059ed90)
void FUN_14059ed90(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar2 + 0x220))(plVar2);
    if (cVar1 != '\0') {
      (**(code **)(*plVar2 + 0x3d0))(plVar2,0,1);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_21  @14059ede0  [high:rtti-vtable]  (orig: FUN_14059ede0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059ede0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  IStringManager *pIVar2;
  undefined8 uVar3;
  char *_Format;
  undefined1 auStack_458 [32];
  undefined8 local_438;
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar1 != (longlong *)0x0) &&
     (plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1), plVar1 != (longlong *)0x0)) {
    local_428 = '\0';
    memset(local_427,0,0x3ff);
    pIVar2 = theInstance();
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x18) + 0x40))
                      (*(longlong **)(param_1 + 0x18),param_3);
    (**(code **)(plVar1[2] + 0x18))(plVar1 + 2);
    _Format = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_TAKE_ON_FLOWER_SUIT");
    local_438 = uVar3;
    _snprintf(&local_428,0x400,_Format);
    local_29 = 0;
    (**(code **)(*plVar1 + 0x140))(plVar1,&local_428,1);
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_24  @14059eef0  [high:rtti-vtable]  (orig: FUN_14059eef0)
void FUN_14059eef0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140183c80(lVar2,0);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_25  @14059ef30  [high:rtti-vtable]  (orig: FUN_14059ef30)
void FUN_14059ef30(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140178d20(lVar2);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_26  @14059ef70  [high:rtti-vtable]  (orig: FUN_14059ef70)
void FUN_14059ef70(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140178d60(lVar2);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_27  @14059efb0  [high:rtti-vtable]  (orig: FUN_14059efb0)
void FUN_14059efb0(longlong param_1,undefined8 param_2,int param_3)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar2 != (longlong *)0x0) && (lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 != 0)) {
    if (((param_3 == 0xd) || (((param_3 == 0x12 || (param_3 == 0x28)) || (param_3 == 0x27)))) ||
       (((param_3 == 0x10 || (param_3 == 0x96)) || (param_3 == 0x9f)))) {
      uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0xe8))(lVar3 + 0x10);
      *(undefined4 *)(lVar3 + 0x1190) = uVar1;
    }
    if (param_3 == 0x92) {
      FUN_140164ab0(lVar3,0);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_28  @14059f040  [high:rtti-vtable]  (orig: FUN_14059f040)
ulonglong FUN_14059f040(longlong param_1,undefined8 param_2,int param_3,longlong param_4)

{
  ushort uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar3 == (longlong *)0x0) {
    return 0;
  }
  lVar4 = (**(code **)(*plVar3 + 0x2b0))(plVar3);
  uVar5 = 0;
  if (lVar4 != 0) {
    if (param_3 == 8) {
      uVar1 = *(ushort *)(lVar4 + 0xf92);
      iVar2 = FUN_1403837b0(lVar4);
      uVar5 = param_4 + (ulonglong)uVar1;
      if ((longlong)iVar2 <= (longlong)uVar5) goto LAB_14059f0ae;
    }
    uVar5 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x2e0))(lVar4 + 0x10,param_3,param_4,1,0);
    return uVar5;
  }
LAB_14059f0ae:
  return uVar5 & 0xffffffffffffff00;
}

// ==== CStatusActor@adapter::vfunc_29  @14059f100  [high:rtti-vtable]  (orig: FUN_14059f100)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059f100(longlong param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 auStack_4b8 [32];
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                     (*(longlong **)(param_1 + 0x10),param_4);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 != 0) {
      FUN_14037dfb0(local_488);
      iVar1 = FUN_14037e0a0(local_488,param_2,param_3,param_4);
      if (iVar1 == 0) {
        FUN_14037e030(local_488);
      }
      else {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_488);
        FUN_14037e030(local_488);
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_0  @14059f1c0  [high:rtti-vtable]  (orig: FUN_14059f1c0)
void FUN_14059f1c0(longlong param_1)

{
  FUN_14059f230(param_1 + -8);
  return;
}

// ==== CStatusActor@adapter::helper_14059f230  @14059f230  [medium:callgraph-r0]  (orig: FUN_14059f230)
undefined8 * FUN_14059f230(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CStatusActor::vftable;
  param_1[1] = adapter::CStatusActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CStatusActor@adapter::vfunc_2  @14059f280  [high:rtti-vtable]  (orig: FUN_14059f280)
void FUN_14059f280(longlong param_1,undefined8 param_2,longlong param_3)

{
  ushort uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  
  uVar7 = 0xfffffffffffffffe;
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar4 != (longlong *)0x0) {
    lVar5 = (**(code **)(*plVar4 + 0x2b0))(plVar4);
    if (lVar5 == 0) {
      uVar1 = *(ushort *)(param_3 + 8);
      uVar2 = *(undefined2 *)(param_3 + 10);
      uVar3 = (**(code **)(*plVar4 + 0x10))(plVar4);
      puVar6 = (undefined8 *)
               FUN_1402ba440(*(undefined4 *)(param_1 + 0x28),uVar3,uVar2,param_3 + 0xc,uVar1 - 4,0,
                             uVar7);
      if (puVar6 != (undefined8 *)0x0) {
        (**(code **)(*plVar4 + 0x350))(plVar4,puVar6);
        (**(code **)*puVar6)(puVar6,1);
      }
    }
    else {
      puVar6 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x28),*(undefined4 *)(lVar5 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(ushort *)(param_3 + 8) - 4,0);
      if (puVar6 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x350))((longlong *)(lVar5 + 0x10),puVar6);
        (**(code **)*puVar6)(puVar6,1);
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_3  @14059f3b0  [high:rtti-vtable]  (orig: FUN_14059f3b0)
void FUN_14059f3b0(longlong param_1,undefined8 param_2,longlong param_3,char param_4)

{
  ushort uVar1;
  undefined2 uVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  undefined8 uVar10;
  
  uVar10 = 0xfffffffffffffffe;
  plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar6 != (longlong *)0x0) {
    lVar7 = (**(code **)(*plVar6 + 0x2b0))(plVar6);
    plVar8 = (longlong *)(**(code **)(*plVar6 + 0x160))(plVar6);
    if (plVar8 != (longlong *)0x0) {
      if (lVar7 == 0) {
        uVar1 = *(ushort *)(param_3 + 8);
        uVar2 = *(undefined2 *)(param_3 + 10);
        uVar4 = (**(code **)(*plVar6 + 0x10))(plVar6);
        puVar9 = (undefined8 *)
                 FUN_1402ba440(*(undefined4 *)(param_1 + 0x28),uVar4,uVar2,param_3 + 0xc,uVar1 - 4,0
                               ,uVar10);
        if (puVar9 != (undefined8 *)0x0) {
          if (param_4 != '\0') {
            (**(code **)(*plVar6 + 0x350))(plVar6,puVar9);
          }
          lVar7 = *plVar8;
          uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
          uVar5 = (**(code **)(*plVar6 + 0x40))(plVar6);
          (**(code **)(lVar7 + 0x28))(plVar8,uVar5,uVar4,puVar9);
          (**(code **)*puVar9)(puVar9,1);
        }
      }
      else {
        puVar9 = (undefined8 *)
                 FUN_1402ba310(*(undefined4 *)(param_1 + 0x28),0,*(undefined2 *)(param_3 + 10),
                               param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,0);
        if (puVar9 != (undefined8 *)0x0) {
          if (param_4 != '\0') {
            (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x350))((longlong *)(lVar7 + 0x10),puVar9);
          }
          lVar3 = *plVar8;
          uVar4 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x48))(lVar7 + 0x10);
          uVar5 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x40))(lVar7 + 0x10);
          (**(code **)(lVar3 + 0x28))(plVar8,uVar5,uVar4,puVar9);
          (**(code **)*puVar9)(puVar9,1);
        }
      }
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_15  @14059f560  [high:rtti-vtable]  (orig: FUN_14059f560)
int FUN_14059f560(longlong param_1,undefined8 param_2,undefined4 param_3,uint param_4,char param_5)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  int local_res8 [2];
  undefined8 in_stack_ffffffffffffffc8;
  int local_28;
  int local_24;
  undefined8 local_20;
  
  uVar3 = (undefined4)((ulonglong)in_stack_ffffffffffffffc8 >> 0x20);
  local_20 = 0xfffffffffffffffe;
  plVar7 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar7 != (longlong *)0x0) && (cVar1 = (**(code **)(*plVar7 + 0x220))(plVar7), cVar1 != '\0')
     ) {
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x2b0))(plVar7);
    if (plVar7 != (longlong *)0x0) {
      switch(param_3) {
      case 2:
        uVar3 = (**(code **)(plVar7[2] + 0x78))(plVar7 + 2);
        local_res8[0] = FUN_1401619e0(uVar3,param_4,0);
        uVar9 = 0;
        if (local_res8[0] < 1) {
          local_res8[0] = 0;
        }
        iVar2 = (**(code **)(plVar7[2] + 0x78))(plVar7 + 2);
        if (local_res8[0] <= iVar2) {
          iVar2 = local_res8[0];
        }
        local_res8[0] = 200;
        if (iVar2 < 0xc9) {
          local_res8[0] = iVar2;
        }
        local_res8[0] = FUN_14016dbf0(plVar7);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x28));
        if (*(longlong *)(lVar8 + 0x100) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar9 = *(undefined8 *)(lVar8 + 0x100);
        }
        uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
        FUN_1402ecf70(uVar9,0,uVar3,local_res8);
        (**(code **)(plVar7[2] + 0x2e0))(plVar7 + 2,0,(longlong)-local_res8[0],1,0);
        return local_res8[0];
      default:
        log_InlineLogERROR(&DAT_1407aef90);
        break;
      case 0xd:
      case 0x12:
      case 0x28:
      case 0x9f:
        FUN_140171a50(plVar7);
        uVar3 = (**(code **)(plVar7[2] + 0xe8))();
        *(undefined4 *)(plVar7 + 0x232) = uVar3;
        break;
      case 0x1c:
        FUN_1401650c0(plVar7);
        break;
      case 0x27:
        if (param_4 == 1) {
          FUN_140161550(plVar7,1);
          FUN_1401a3370(plVar7,0);
          lVar8 = plVar7[2];
          uVar4 = (**(code **)(lVar8 + 0x48))(plVar7 + 2);
          uVar5 = (**(code **)(plVar7[2] + 0x40))(plVar7 + 2);
          uVar6 = (**(code **)(*plVar7 + 8))(plVar7);
          (**(code **)(lVar8 + 0x3c0))(plVar7 + 2,0x177a,uVar6,uVar5,CONCAT44(uVar3,uVar4));
          FUN_140161550(plVar7,0);
        }
        else {
          FUN_140171a50(plVar7);
          uVar3 = (**(code **)(plVar7[2] + 0xe8))();
          *(undefined4 *)(plVar7 + 0x232) = uVar3;
        }
        break;
      case 0x2b:
        iVar2 = (**(code **)(plVar7[2] + 0x78))(plVar7 + 2);
        local_28 = FUN_1401619e0(iVar2,param_4,0);
        uVar9 = 0;
        if (local_28 < 1) {
          local_28 = 0;
        }
        local_28 = FUN_14016dbf0(plVar7,local_28);
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x28));
        if (*(longlong *)(lVar8 + 0x100) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar9 = *(undefined8 *)(lVar8 + 0x100);
        }
        uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
        FUN_1402ecf70(uVar9,0,uVar3,&local_28);
        if (iVar2 <= local_28) {
          local_28 = iVar2 + -1;
        }
        (**(code **)(plVar7[2] + 0x2e0))(plVar7 + 2,0,(longlong)-local_28,1,0);
        return local_28;
      case 0x34:
        FUN_140160c50(plVar7,param_4);
        iVar2 = FUN_140160af0(plVar7);
        FUN_14018e220(plVar7,iVar2 + param_4);
        FUN_140160b00(plVar7);
        break;
      case 0x35:
        iVar2 = FUN_140160af0(plVar7);
        local_24 = FUN_140180090(plVar7);
        if ((int)(iVar2 + param_4) < local_24) {
          local_24 = iVar2 + param_4;
        }
        if ((param_5 != '\0') && (local_24 < iVar2)) {
          local_24 = iVar2;
        }
        FUN_14018e220(plVar7,local_24);
        FUN_140160b00(plVar7);
        break;
      case 0x92:
        FUN_140164ab0(plVar7,param_4 & 0xffff);
        break;
      case 0x96:
        FUN_140171a50(plVar7);
        uVar3 = (**(code **)(plVar7[2] + 0xe8))();
        *(undefined4 *)(plVar7 + 0x232) = uVar3;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CStatusActor@adapter::vfunc_16  @14059fa00  [high:rtti-vtable]  (orig: FUN_14059fa00)
int FUN_14059fa00(longlong param_1,undefined8 param_2,int param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 local_res8;
  
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar5 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar5 + 0x220))(plVar5);
    if (cVar1 != '\0') {
      if (param_3 == 2) {
        uVar4 = (**(code **)(*plVar5 + 0x78))(plVar5);
        iVar3 = FUN_1401619e0(uVar4,param_4,0);
        if (iVar3 < 1) {
          iVar3 = 0;
        }
        local_res8 = 0;
        iVar2 = (**(code **)(*plVar5 + 0x78))(plVar5);
        if (iVar3 <= iVar2) {
          iVar2 = iVar3;
        }
        iVar3 = 200;
        if (iVar2 < 0xc9) {
          iVar3 = iVar2;
        }
        cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1001,&local_res8);
        if (cVar1 != '\0') {
          iVar3 = FUN_14016dbf0(local_res8,iVar3);
        }
        (**(code **)(*plVar5 + 0x2e0))(plVar5,0,(longlong)-iVar3,1,0);
        return iVar3;
      }
      if (param_3 == 0x2b) {
        iVar2 = (**(code **)(*plVar5 + 0x78))(plVar5);
        iVar3 = FUN_1401619e0(iVar2,param_4,0);
        local_res8 = 0;
        if (iVar3 < 1) {
          iVar3 = 0;
        }
        cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1001,&local_res8);
        if (cVar1 != '\0') {
          iVar3 = FUN_14016dbf0(local_res8,iVar3);
        }
        if (iVar2 <= iVar3) {
          iVar3 = iVar2 + -1;
        }
        (**(code **)(*plVar5 + 0x2e0))(plVar5,0,(longlong)-iVar3,1,0);
        return iVar3;
      }
      log_InlineLogERROR(&DAT_1407aefa8);
    }
  }
  return 0;
}

// ==== CStatusActor@adapter::vfunc_22  @14059fb90  [high:rtti-vtable]  (orig: FUN_14059fb90)
undefined8 FUN_14059fb90(longlong param_1,undefined8 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  byte bVar2;
  undefined4 uVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  IStringManager *pIVar8;
  uint uVar9;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar4 != (longlong *)0x0) && (cVar1 = (**(code **)(*plVar4 + 0x220))(plVar4), cVar1 != '\0')
     ) {
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x2b0))(plVar4);
    if ((plVar4 != (longlong *)0x0) && (param_4 != 0xff)) {
      lVar7 = **(longlong **)(param_1 + 0x20);
      uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
      bVar2 = (**(code **)(lVar7 + 0x20))(*(undefined8 *)(param_1 + 0x20),param_4,uVar3);
      uVar9 = (uint)bVar2;
      if ((uVar9 != 0xff) && (uVar9 < 100)) {
        if (bVar2 == 0) {
          return 1;
        }
        do {
          uVar9 = uVar9 - 1;
          if ((int)uVar9 < 0) {
            return 1;
          }
          uVar3 = (**(code **)(**(longlong **)(param_1 + 0x20) + 0x28))
                            (*(longlong **)(param_1 + 0x20),param_4,uVar9 & 0xff);
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x28));
          plVar6 = (longlong *)FUN_140087650(uVar5);
          lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,uVar3);
        } while ((lVar7 == 0) ||
                (cVar1 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x2d8))
                                   ((longlong *)(lVar7 + 0x10),param_3), cVar1 == '\0'));
        pIVar8 = theInstance();
        lVar7 = plVar4[2];
        uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_SOMEONE_RANK_BEFORE_WORE");
        (**(code **)(lVar7 + 0x358))(plVar4 + 2,uVar5);
      }
    }
    return 0;
  }
  return 0;
}

// ==== CStatusActor@adapter::vfunc_23  @14059fcf0  [high:rtti-vtable]  (orig: FUN_14059fcf0)
void FUN_14059fcf0(longlong param_1,undefined8 param_2,undefined4 param_3,int param_4)

{
  longlong lVar1;
  char cVar2;
  byte bVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  uint uVar9;
  
  plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((((plVar6 != (longlong *)0x0) &&
       (cVar2 = (**(code **)(*plVar6 + 0x220))(plVar6), cVar2 != '\0')) &&
      (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x2b0))(plVar6), plVar6 != (longlong *)0x0)) &&
     (param_4 != 0xff)) {
    lVar1 = **(longlong **)(param_1 + 0x20);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    bVar3 = (**(code **)(lVar1 + 0x20))(*(undefined8 *)(param_1 + 0x20),param_4,uVar4);
    if ((bVar3 != 0xff) && (uVar9 = bVar3 + 1, uVar9 < 0x65)) {
      do {
        iVar5 = (**(code **)(**(longlong **)(param_1 + 0x20) + 0x28))
                          (*(longlong **)(param_1 + 0x20),param_4,uVar9 & 0xff);
        if (iVar5 == 0) {
          return;
        }
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x28));
        plVar6 = (longlong *)FUN_140087650(uVar7);
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,iVar5);
        if ((plVar6 != (longlong *)0x0) &&
           (cVar2 = (**(code **)(plVar6[2] + 0x2d8))(plVar6 + 2,param_3), cVar2 != '\0')) {
          plVar8 = (longlong *)FUN_1401181a0();
          lVar1 = *plVar8;
          uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
          (**(code **)(lVar1 + 0x10))(plVar8,uVar4,param_3);
          return;
        }
        uVar9 = uVar9 + 1;
      } while ((int)uVar9 < 0x65);
    }
  }
  return;
}

// ==== CStatusActor@adapter::vfunc_17  @14059fe40  [high:rtti-vtable]  (orig: FUN_14059fe40)
undefined8 FUN_14059fe40(longlong param_1,undefined8 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar4 == (longlong *)0x0) ||
     ((cVar1 = (**(code **)(*plVar4 + 0x220))(plVar4), cVar1 == '\0' && (param_3 != 0x6a)))) {
    return 0;
  }
  lVar5 = (**(code **)(*plVar4 + 0x160))(plVar4);
  if ((lVar5 != 0) &&
     ((param_3 != 1 ||
      (((cVar1 = FUN_14017ef50(lVar5), cVar1 == '\0' &&
        (cVar1 = FUN_14016cc30(lVar5), cVar1 == '\0')) &&
       (cVar1 = FUN_14011dbb0(lVar5), cVar1 == '\0')))))) {
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x2b0))(plVar4);
    if ((plVar4 != (longlong *)0x0) && (param_3 == 1)) {
      iVar2 = FUN_140161f90(plVar4);
      if (iVar2 == 6) {
        uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x28));
        uVar6 = FUN_140087ba0(uVar6);
        cVar1 = FUN_1401e6150(uVar6,uVar3);
        if (cVar1 != '\0') {
          return 0;
        }
      }
      iVar2 = FUN_140161f90(plVar4);
      if (iVar2 == 9) {
        return 0;
      }
      iVar2 = FUN_140161f90(plVar4);
      if (iVar2 == 0xb) {
        return 0;
      }
    }
    return 1;
  }
  return 0;
}

