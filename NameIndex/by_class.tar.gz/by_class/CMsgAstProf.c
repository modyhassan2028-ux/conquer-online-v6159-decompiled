// ==== CMsgAstProf::helper_140157550  @140157550  [medium:callgraph-r1]  (orig: FUN_140157550)
undefined8 FUN_140157550(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x80);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgAstProf::helper_140157810  @140157810  [medium:callgraph-r1]  (orig: FUN_140157810)
undefined8 FUN_140157810(longlong param_1,short param_2,byte param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  ushort uVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  uVar9 = param_2 * 0x100 + (ushort)param_3;
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0xc0);
  while (cVar1 == '\0') {
    if (*(ushort *)(puVar8 + 3) < uVar9) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0xc0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x90);
  if (*(longlong *)(param_1 + 0x90) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (uVar9 < *(ushort *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xc0);
    local_28 = *(longlong *)(param_1 + 0x90);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0xc0);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x90))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar10) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgAstProf::helper_140157fd0  @140157fd0  [medium:callgraph-r0]  (orig: FUN_140157fd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140157fd0(longlong param_1,longlong *param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_4c8 [32];
  undefined1 local_4a8;
  int local_498 [2];
  longlong *local_490;
  longlong local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
    if (((byte)(param_3 - 1U) < 10) &&
       (local_498[0] = (**(code **)(*param_2 + 8))(param_2), local_498[0] != 0)) {
      cVar1 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
      if (cVar1 == '\0') {
        pIVar5 = theInstance();
        lVar10 = param_2[2];
        uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
        (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar6);
      }
      else {
        uVar6 = (**(code **)(param_2[2] + 0x1d8))(param_2 + 2);
        uVar2 = (**(code **)(*param_2 + 8))(param_2);
        local_4a8 = 0;
        cVar1 = FUN_140152480(param_1,uVar2,uVar6,param_3);
        if (cVar1 != '\0') {
          uVar6 = FUN_140118150();
          iVar3 = FUN_14014df00(uVar6,param_3);
          FUN_140156a60((longlong *)(param_1 + 8),&local_490,local_498);
          lVar10 = *(longlong *)(param_1 + 0x38);
          if ((local_490 == (longlong *)0x0) || (local_490 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (local_488 != lVar10) {
            if (local_490 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *local_490;
            }
            if (local_488 == *(longlong *)(lVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar10 = *(longlong *)(local_488 + 0x20);
            if ((lVar10 != 0) && (iVar4 = FUN_1403afd10(lVar10,param_3), iVar4 < iVar3)) {
              uVar2 = FUN_1403afd10(lVar10,param_3);
              uVar6 = FUN_140118150();
              lVar7 = FUN_14014de60(uVar6,param_3,uVar2);
              if (lVar7 != 0) {
                lVar8 = FUN_1401669e0(param_2);
                plVar9 = (longlong *)
                         (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))
                                   (*(longlong **)(lVar7 + 8),1);
                lVar7 = (**(code **)(*plVar9 + 0x58))(plVar9);
                if (lVar7 <= lVar8) {
                  FUN_1401669f0(param_2,-lVar7,1);
                  FUN_1403afe00(lVar10,param_3,1,1);
                  FUN_1403b0410(local_478);
                  iVar3 = FUN_1403b05d0(local_478,3,param_3,0);
                  if (iVar3 != 0) {
                    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                  }
                  FUN_1403b0460(local_478);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgAstProf::helper_140158220  @140158220  [medium:callgraph-r0]  (orig: FUN_140158220)
void FUN_140158220(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  uint uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar7 + 3) < uVar5) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar3 = puVar7;
      puVar7 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x29);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x38);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 8);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar7) || (uVar5 < *(uint *)(puVar3 + 3))) {
      plVar6 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0x38);
      local_28 = *(longlong *)(param_1 + 8);
    }
    else {
      plVar6 = &local_38;
    }
    plVar2 = (longlong *)*plVar6;
    lVar9 = *(longlong *)(param_1 + 0x38);
    local_18 = plVar2;
    local_10 = plVar6[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar9) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(lVar4 + 0x20);
      if (lVar9 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_1403af010(lVar9,param_2);
      }
    }
  }
  return;
}

// ==== CMsgAstProf::helper_140158750  @140158750  [medium:callgraph-r0]  (orig: FUN_140158750)
void FUN_140158750(undefined8 param_1,longlong *param_2,char param_3)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  longlong *plVar11;
  longlong *plVar12;
  
  if ((param_2 != (longlong *)0x0) && ((byte)(param_3 - 1U) < 9)) {
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    iVar5 = FUN_140157d90(param_1,uVar4,param_3);
    if ((iVar5 < 1) &&
       (plVar11 = (longlong *)FUN_140157550(param_1,param_3), plVar11 != (longlong *)0x0)) {
      plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,2);
      uVar6 = (**(code **)(*plVar12 + 0x40))(plVar12);
      uVar7 = (**(code **)(*param_2 + 0x108))(param_2);
      if (uVar6 <= uVar7) {
        plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,2);
        iVar5 = (**(code **)(*param_2 + 0x108))(param_2);
        iVar8 = (**(code **)(*plVar12 + 0x40))(plVar12);
        if (iVar5 == iVar8) {
          plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,3);
          uVar6 = (**(code **)(*plVar12 + 0x40))(plVar12);
          uVar7 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
          if (uVar7 < uVar6) {
            return;
          }
        }
        plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,4);
        iVar5 = (**(code **)(*plVar12 + 0x40))(plVar12);
        plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,5);
        iVar8 = (**(code **)(*plVar12 + 0x50))(plVar12);
        bVar1 = false;
        if ((iVar5 != 0) && (iVar8 != 0)) {
          bVar1 = true;
          cVar3 = FUN_140338940(param_2,iVar5,iVar5,iVar8,1,0);
          if (cVar3 == '\0') {
            return;
          }
        }
        plVar12 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,6);
        iVar9 = (**(code **)(*plVar12 + 0x40))(plVar12);
        plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,7);
        iVar10 = (**(code **)(*plVar11 + 0x50))(plVar11);
        bVar2 = false;
        if ((iVar9 != 0) && (iVar10 != 0)) {
          bVar2 = true;
          cVar3 = FUN_140338940(param_2,iVar9,iVar9,iVar10,1,0);
          if (cVar3 == '\0') {
            return;
          }
        }
        if ((bVar1) && (cVar3 = FUN_140350360(param_2,iVar5,iVar5,iVar8,1,0), cVar3 == '\0')) {
          return;
        }
        if ((bVar2) && (cVar3 = FUN_140350360(param_2,iVar9,iVar9,iVar10,1,0), cVar3 == '\0')) {
          return;
        }
        FUN_140158380(param_1,param_2,param_3);
      }
    }
  }
  return;
}

// ==== CMsgAstProf::helper_1401589b0  @1401589b0  [medium:callgraph-r0]  (orig: FUN_1401589b0)
void FUN_1401589b0(undefined8 param_1,longlong *param_2,char param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  byte bVar11;
  
  if ((param_2 != (longlong *)0x0) && ((byte)(param_3 - 1U) < 9)) {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    iVar3 = FUN_140157d90(param_1,uVar2,param_3);
    if (0 < iVar3) {
      uVar8 = (**(code **)(param_2[2] + 0x1d8))();
      uVar2 = (**(code **)(*param_2 + 8))(param_2);
      cVar1 = FUN_140152480(param_1,uVar2,uVar8,param_3,0);
      bVar11 = cVar1 + 1;
      if ((bVar11 < 10) &&
         (plVar9 = (longlong *)FUN_140157810(param_1,param_3,bVar11), plVar9 != (longlong *)0x0)) {
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,3);
        uVar4 = (**(code **)(*plVar10 + 0x40))(plVar10);
        uVar5 = (**(code **)(*param_2 + 0x108))(param_2);
        if (uVar4 <= uVar5) {
          plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,3);
          iVar6 = (**(code **)(*plVar10 + 0x40))(plVar10);
          iVar7 = (**(code **)(*param_2 + 0x108))(param_2);
          if (iVar7 == iVar6) {
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
            uVar4 = (**(code **)(param_2[2] + 0x70))();
            uVar5 = (**(code **)(*plVar10 + 0x40))(plVar10);
            if (uVar4 < uVar5) {
              return;
            }
          }
          plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
          iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
          if (iVar6 <= iVar3) {
            uVar2 = (**(code **)(*param_2 + 8))(param_2);
            FUN_140152550(param_1,uVar2,param_3,bVar11,1,1);
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgAstProf::helper_1403af010  @1403af010  [medium:callgraph-r1]  (orig: FUN_1403af010)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403af010(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined1 uVar5;
  undefined1 uVar6;
  undefined1 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong lVar11;
  longlong *plVar12;
  uint uVar13;
  undefined1 auStack_4b8 [32];
  uint local_498;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
    plVar12 = (longlong *)**(undefined8 **)(param_1 + 0x38);
    plVar2 = *(longlong **)(param_1 + 8);
    uVar13 = 0;
    local_488 = param_2;
    FUN_1403b0410(local_478);
    uVar10 = FUN_1401669e0(param_2);
    iVar8 = FUN_1403b0540(local_478,7,uVar10,0);
    if (iVar8 == 0) {
      FUN_1403b0460(local_478);
    }
    else {
      while( true ) {
        plVar3 = *(longlong **)(param_1 + 0x38);
        if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
          _invalid_parameter_noinfo();
        }
        if (plVar12 == plVar3) goto LAB_1403af245;
        uVar13 = uVar13 + 1;
        if (1000 < uVar13) break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar2;
        }
        if (plVar12 == *(longlong **)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar3 = (longlong *)plVar12[4];
        if (plVar3 != (longlong *)0x0) {
          uVar5 = (**(code **)(*plVar3 + 0x10))(plVar3,2);
          lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
          lVar11 = *(longlong *)(lVar11 + 0xf8);
          if (lVar11 == 0) {
            local_498 = 0x142;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar10 = (**(code **)(local_488[2] + 0x1d8))();
          uVar9 = (**(code **)(*local_488 + 8))(local_488);
          local_498 = local_498 & 0xffffff00;
          uVar6 = FUN_140152480(lVar11,uVar9,uVar10,uVar5);
          uVar7 = (**(code **)(*plVar3 + 0x10))(plVar3,3);
          FUN_1403b0660(local_478,uVar5,uVar6,uVar7);
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar12 + 0x29) == '\0') {
          plVar3 = (longlong *)plVar12[2];
          if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x29);
            plVar12 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (cVar1 == '\0') {
              cVar1 = *(char *)(*plVar3 + 0x29);
              plVar12 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar1 = *(char *)(plVar12[1] + 0x29);
            plVar4 = (longlong *)plVar12[1];
            plVar3 = plVar12;
            while ((plVar12 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar12[2]))) {
              cVar1 = *(char *)(plVar12[1] + 0x29);
              plVar4 = (longlong *)plVar12[1];
              plVar3 = plVar12;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      local_498 = 0xef;
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1403af245:
      (**(code **)(local_488[2] + 0x350))(local_488 + 2,local_478);
      FUN_1403b0460(local_478);
    }
  }
  return;
}

// ==== CMsgAstProf::ctor_or_dtor  @1403b0410  [high:vtable-assign]  (orig: FUN_1403b0410)
undefined8 * FUN_1403b0410(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAstProf::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAstProf::ctor_or_dtor  @1403b0460  [high:vtable-assign]  (orig: FUN_1403b0460)
void FUN_1403b0460(undefined8 *param_1)

{
  *param_1 = CMsgAstProf::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAstProf::vfunc_1  @1403b0490  [high:rtti-vtable]  (orig: FUN_1403b0490)
bool FUN_1403b0490(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x910;
    }
  }
  return false;
}

// ==== CMsgAstProf::helper_1403b0660  @1403b0660  [medium:callgraph-r2]  (orig: FUN_1403b0660)
undefined8 FUN_1403b0660(longlong param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4)

{
  int *piVar1;
  longlong lVar2;
  
  if (0x3fb < (longlong)*(int *)(param_1 + 0xc) + 3U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 3;
  *(undefined1 *)((ulonglong)*(uint *)(lVar2 + 0x16) * 3 + 0x1a + lVar2) = param_2;
  *(undefined1 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0x16) * 3 +
   *(longlong *)(param_1 + 0x428) + 0x1b) = param_3;
  *(undefined1 *)
   ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0x16) * 3 + 0x1c +
   *(longlong *)(param_1 + 0x428)) = param_4;
  piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 0x16);
  *piVar1 = *piVar1 + 1;
  return 1;
}

// ==== CMsgAstProf::ctor_or_dtor  @1403b0740  [high:vtable-assign]  (orig: FUN_1403b0740)
undefined8 * FUN_1403b0740(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAstProf::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAstProf::vfunc_3  @1403b0790  [high:rtti-vtable]  (orig: FUN_1403b0790)
void FUN_1403b0790(longlong param_1)

{
  short sVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x88))(*(longlong **)(lVar6 + 0x90),param_1)
  ;
  if (plVar7 != (longlong *)0x0) {
    plVar8 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar7[0x1e2];
    lVar6 = *plVar8;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x108))(plVar8,uVar5,(int)lVar3,*puVar2);
    cVar4 = (**(code **)(plVar7[2] + 0x220))(plVar7 + 2);
    if (cVar4 == '\0') {
      pIVar9 = theInstance();
      lVar6 = plVar7[2];
      uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x0001403b0894. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(lVar6 + 0x358))(plVar7 + 2,uVar10);
      return;
    }
    lVar6 = *(longlong *)(param_1 + 0x428);
    sVar1 = *(short *)(lVar6 + 4);
    if (sVar1 == 0) {
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar10 = FUN_140117ed0(uVar10);
      FUN_140153930(uVar10,plVar7,*(undefined1 *)(lVar6 + 6));
    }
    else {
      if (sVar1 == 2) {
        uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar10 = FUN_140117ed0(uVar10);
        FUN_140157fd0(uVar10,plVar7,*(undefined1 *)(lVar6 + 6));
        return;
      }
      if (sVar1 == 6) {
        uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar10 = FUN_140117ed0(uVar10);
        FUN_140158220(uVar10,plVar7);
        return;
      }
      if (sVar1 == 9) {
        uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar10 = FUN_140117ed0(uVar10);
        FUN_140158750(uVar10,plVar7,*(undefined1 *)(lVar6 + 6));
        return;
      }
      if (sVar1 == 10) {
        uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar10 = FUN_140117ed0(uVar10);
        FUN_1401589b0(uVar10,plVar7,*(undefined1 *)(lVar6 + 6));
        return;
      }
    }
  }
  return;
}

