// ==== CMsgData::helper_1401649e0  @1401649e0  [medium:callgraph-r0]  (orig: FUN_1401649e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401649e0(longlong param_1)

{
  int iVar1;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined4 local_480;
  undefined4 local_478;
  undefined4 local_470;
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (*(int *)(param_1 + 0x100) != 0) {
    FUN_1403a6980(local_448);
    local_468 = 0x1005;
    local_470 = 0x272c;
    local_478 = 0x272b;
    local_480 = 0x271c;
    local_488 = 0x271b;
    iVar1 = FUN_1403a6a30(local_448,1,0x2c,8);
    if (iVar1 != 0) {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_448);
    }
    FUN_1403a69d0(local_448);
  }
  return;
}

// ==== CMsgData::ctor_or_dtor  @1403a6980  [high:vtable-assign]  (orig: FUN_1403a6980)
undefined8 * FUN_1403a6980(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgData::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgData::ctor_or_dtor  @1403a69d0  [high:vtable-assign]  (orig: FUN_1403a69d0)
void FUN_1403a69d0(undefined8 *param_1)

{
  *param_1 = CMsgData::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgData::vfunc_1  @1403a6a00  [high:rtti-vtable]  (orig: FUN_1403a6a00)
ulonglong FUN_1403a6a00(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x409);
}

// ==== CMsgData::ctor_or_dtor  @1403a6b00  [high:vtable-assign]  (orig: FUN_1403a6b00)
undefined8 * FUN_1403a6b00(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgData::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgData::vfunc_3  @1403a6b50  [high:rtti-vtable]  (orig: FUN_1403a6b50)
void FUN_1403a6b50(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))(*(longlong **)(lVar4 + 0x90),param_1)
  ;
  if (plVar5 != (longlong *)0x0) {
    plVar6 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar5[0x1e2];
    lVar4 = *plVar6;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    (**(code **)(lVar4 + 0x108))(plVar6,uVar3,(int)lVar2,*puVar1);
    if (*(char *)(*(longlong *)(param_1 + 0x428) + 4) == '\x01') {
      FUN_1401649e0(plVar5);
    }
  }
  return;
}

