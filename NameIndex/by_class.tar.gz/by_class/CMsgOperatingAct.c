// ==== CMsgOperatingAct::helper_1400c7820  @1400c7820  [medium:callgraph-r1]  (orig: FUN_1400c7820)
ulonglong FUN_1400c7820(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),1);
                    /* WARNING: Could not recover jumptable at 0x0001400c7875. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgOperatingAct::helper_1400c7a00  @1400c7a00  [medium:callgraph-r1]  (orig: FUN_1400c7a00)
undefined8 FUN_1400c7a00(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
                    /* WARNING: Could not recover jumptable at 0x0001400c7a55. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CMsgOperatingAct::helper_1400c7b20  @1400c7b20  [medium:callgraph-r1]  (orig: FUN_1400c7b20)
undefined8 FUN_1400c7b20(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),2);
                    /* WARNING: Could not recover jumptable at 0x0001400c7b75. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CMsgOperatingAct::helper_1400c7be0  @1400c7be0  [medium:callgraph-r1]  (orig: FUN_1400c7be0)
undefined8 FUN_1400c7be0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
                    /* WARNING: Could not recover jumptable at 0x0001400c7c35. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CMsgOperatingAct::helper_1400c7c40  @1400c7c40  [medium:callgraph-r1]  (orig: FUN_1400c7c40)
ulonglong FUN_1400c7c40(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
                    /* WARNING: Could not recover jumptable at 0x0001400c7c95. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgOperatingAct::helper_1400ce610  @1400ce610  [medium:callgraph-r1]  (orig: FUN_1400ce610)
longlong * FUN_1400ce610(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgOperatingAct::helper_1400d21a0  @1400d21a0  [medium:callgraph-r1]  (orig: FUN_1400d21a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400d21a0(longlong param_1,longlong param_2,longlong *param_3)

{
  byte bVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  char cVar6;
  undefined2 uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong *plVar11;
  undefined8 uVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  byte bVar16;
  byte bVar17;
  longlong lVar18;
  undefined8 *puVar19;
  undefined1 auStack_508 [32];
  uint local_4e8;
  undefined1 local_4e0;
  char local_4d8;
  byte local_4d7;
  byte local_4d6;
  uint local_4d4;
  longlong *local_4d0;
  uint local_4c8;
  undefined8 local_4b8;
  undefined8 uStack_4b0;
  longlong local_4a8;
  longlong local_4a0;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_4d0 = param_3;
  local_4a8 = param_2;
  local_4a0 = param_1;
  if (param_2 == 0) {
    local_4e8 = 0x5f3;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else if (param_3 == (longlong *)0x0) {
    local_4e8 = 0x5f4;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else {
    uVar8 = FUN_1400c7b20(param_2);
    local_4c8 = uVar8;
    FUN_1400c7ac0(param_2);
    local_4d4 = FUN_1400c7be0(param_2);
    cVar6 = FUN_1400c7c40(param_2);
    local_4d7 = cVar6 + 1;
    local_4d8 = '\0';
    bVar16 = 0;
    puVar19 = *(undefined8 **)(param_1 + 0x78);
    cVar6 = *(char *)((longlong)puVar19[1] + 0x29);
    puVar15 = puVar19;
    puVar13 = (undefined8 *)puVar19[1];
    while (cVar6 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar8) {
        puVar14 = (undefined8 *)puVar13[2];
        puVar13 = puVar15;
      }
      else {
        if ((*(char *)((longlong)puVar19 + 0x29) != '\0') && (uVar8 < *(uint *)(puVar13 + 3))) {
          puVar19 = puVar13;
        }
        puVar14 = (undefined8 *)*puVar13;
      }
      puVar15 = puVar13;
      puVar13 = puVar14;
      cVar6 = *(char *)((longlong)puVar14 + 0x29);
    }
    if (*(char *)((longlong)puVar19 + 0x29) == '\0') {
      puVar13 = (undefined8 *)*puVar19;
    }
    else {
      puVar13 = *(undefined8 **)(*(longlong *)(param_1 + 0x78) + 8);
    }
    cVar6 = *(char *)((longlong)puVar13 + 0x29);
    while (cVar6 == '\0') {
      if (uVar8 < *(uint *)(puVar13 + 3)) {
        puVar14 = (undefined8 *)*puVar13;
        puVar19 = puVar13;
      }
      else {
        puVar14 = (undefined8 *)puVar13[2];
      }
      puVar13 = puVar14;
      cVar6 = *(char *)((longlong)puVar14 + 0x29);
    }
    plVar3 = *(longlong **)(param_1 + 0x48);
    local_4b8._0_4_ = SUB84(plVar3,0);
    local_4b8._4_4_ = (undefined4)((ulonglong)plVar3 >> 0x20);
    uStack_4b0._0_4_ = SUB84(puVar15,0);
    uStack_4b0._4_4_ = (undefined4)((ulonglong)puVar15 >> 0x20);
    local_498 = (undefined4)local_4b8;
    uStack_494 = local_4b8._4_4_;
    uStack_490 = (undefined4)uStack_4b0;
    uStack_48c = uStack_4b0._4_4_;
    uVar8 = local_4d4;
    local_4b8 = plVar3;
    uStack_4b0 = puVar15;
    bVar17 = local_4d7;
    while( true ) {
      if ((plVar3 == (longlong *)0x0) || (plVar3 != local_4b8)) {
        _invalid_parameter_noinfo();
      }
      if (puVar15 == puVar19) break;
      if (local_4d8 != '\0') goto LAB_1400d262f;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar18 = 0;
      }
      else {
        lVar18 = *plVar3;
      }
      if (puVar15 == *(undefined8 **)(lVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar18 = puVar15[4];
      if (lVar18 != 0) {
        bVar1 = *(byte *)(lVar18 + 0xc);
        local_4d6 = bVar16;
        if (bVar16 < bVar1) {
          local_4d6 = bVar1;
        }
        bVar16 = local_4d6;
        if ((bVar1 == bVar17) && (*(uint *)(lVar18 + 0x10) <= uVar8)) {
          local_4d8 = '\x01';
          FUN_14032a1e0(param_2,bVar17,1);
          iVar2 = *(int *)(lVar18 + 8);
          if (iVar2 == 0) {
            log_InlineLogERROR("COperatingActMgr::GiveUserPrize item type is 0.");
            return 0;
          }
          plVar11 = (longlong *)FUN_140087d40();
          lVar4 = *plVar11;
          uVar9 = FUN_140167b40(local_4d0);
          uVar10 = (**(code **)(*local_4d0 + 8))(local_4d0);
          local_4e0 = 0;
          local_4e8 = uVar9;
          plVar11 = (longlong *)(**(code **)(lVar4 + 0x18))(plVar11,iVar2,uVar10,0);
          if (plVar11 == (longlong *)0x0) {
            (**(code **)(*local_4d0 + 8))();
            log_InlineLogERROR(
                              "COperatingActMgr::GiveUserPrize. CreateItem fail. itemtype:%u, user:%u, mono:%d"
                              );
            return 0;
          }
          uVar12 = FUN_140008520(*(undefined4 *)(local_4a0 + 0x188));
          cVar6 = FUN_14008a710(uVar12);
          if (cVar6 == '\0') {
            FUN_140104140(plVar11,0x16,*(undefined1 *)(lVar18 + 0x14));
          }
          else {
            FUN_140104140(plVar11,0x16,0);
          }
          uVar7 = FUN_1400fda10(plVar11,0x6e,1);
          uVar9 = FUN_1400ffda0(plVar11);
          uVar10 = FUN_1400fda10(plVar11,1,1);
          plVar5 = local_4d0;
          local_4e8 = CONCAT31(local_4e8._1_3_,1);
          cVar6 = FUN_140339ec0(local_4d0,uVar10,uVar9,uVar7);
          if (cVar6 == '\0') {
            (**(code **)(*plVar5 + 8))(plVar5);
            log_InlineLogERROR(
                              "COperatingActMgr::GiveUserPrize Bag full. itemtype:%u, user:%u, mono:%d"
                              );
          }
          uVar9 = (**(code **)(*plVar11 + 8))(plVar11);
          local_4e8 = 0;
          FUN_14033cce0(plVar5,uVar9,1);
          FUN_14035bb80(local_478);
          local_4e8 = local_4d4;
          cVar6 = FUN_14035bc30(local_478,local_4c8,3);
          if (cVar6 != '\0') {
            (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_478);
          }
          FUN_14035bbd0(local_478);
          param_2 = local_4a8;
          bVar16 = local_4d6;
          uVar8 = local_4d4;
          bVar17 = local_4d7;
        }
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar15 + 0x29) == '\0') {
        puVar13 = (undefined8 *)puVar15[2];
        if (*(char *)((longlong)puVar13 + 0x29) == '\0') {
          cVar6 = *(char *)((longlong)*puVar13 + 0x29);
          puVar15 = puVar13;
          puVar13 = (undefined8 *)*puVar13;
          while (cVar6 == '\0') {
            cVar6 = *(char *)((longlong)*puVar13 + 0x29);
            puVar15 = puVar13;
            puVar13 = (undefined8 *)*puVar13;
          }
        }
        else {
          cVar6 = *(char *)((longlong)puVar15[1] + 0x29);
          puVar14 = (undefined8 *)puVar15[1];
          puVar13 = puVar15;
          while ((puVar15 = puVar14, cVar6 == '\0' && (puVar13 == (undefined8 *)puVar15[2]))) {
            cVar6 = *(char *)((longlong)puVar15[1] + 0x29);
            puVar14 = (undefined8 *)puVar15[1];
            puVar13 = puVar15;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    if (local_4d8 == '\0') {
      return 0;
    }
LAB_1400d262f:
    uVar12 = 1;
  }
  return uVar12;
}

// ==== CMsgOperatingAct::helper_1400d4240  @1400d4240  [medium:callgraph-r0]  (orig: FUN_1400d4240)
void FUN_1400d4240(longlong param_1,longlong *param_2,int param_3)

{
  longlong *plVar1;
  bool bVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  longlong lVar12;
  bool bVar13;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR("COperatingActMgr::ProcessGiveUserPrize, pUser is NULL.");
  }
  else {
    if ((param_2[0x185] - param_2[0x184] >> 2) + 1U < 0x29) {
      bVar2 = false;
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      puVar9 = *(undefined8 **)(param_1 + 0xb8);
      puVar11 = (undefined8 *)puVar9[1];
      puVar10 = puVar9;
      while (puVar8 = puVar11, *(char *)((longlong)puVar8 + 0x29) == '\0') {
        if (*(uint *)(puVar8 + 3) < uVar4) {
          puVar11 = (undefined8 *)puVar8[2];
        }
        else {
          if ((*(char *)((longlong)puVar9 + 0x29) != '\0') && (uVar4 < *(uint *)(puVar8 + 3))) {
            puVar9 = puVar8;
          }
          puVar11 = (undefined8 *)*puVar8;
          puVar10 = puVar8;
        }
      }
      if (*(char *)((longlong)puVar9 + 0x29) == '\0') {
        puVar11 = (undefined8 *)*puVar9;
      }
      else {
        puVar11 = *(undefined8 **)(*(longlong *)(param_1 + 0xb8) + 8);
      }
      while (puVar8 = puVar11, *(char *)((longlong)puVar8 + 0x29) == '\0') {
        if (uVar4 < *(uint *)(puVar8 + 3)) {
          puVar11 = (undefined8 *)*puVar8;
          puVar9 = puVar8;
        }
        else {
          puVar11 = (undefined8 *)puVar8[2];
        }
      }
      if ((longlong *)(param_1 + 0x88) == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar1 = *(longlong **)(param_1 + 0x88);
      do {
        while( true ) {
          while( true ) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (puVar10 == puVar9) {
              if (bVar2) {
                return;
              }
              pIVar6 = theInstance();
              lVar12 = param_2[2];
              uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_OPERATING_GIVE_PRIZE_FAILED");
              (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar7);
              return;
            }
            if (bVar2) {
              return;
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = 0;
            }
            else {
              lVar12 = *plVar1;
            }
            if (puVar10 == *(undefined8 **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar12 = puVar10[4];
            if (lVar12 == 0) {
              log_InlineLogERROR("COperatingActMgr::GiveUserPrize pOperatingUserInfo is null");
            }
            else {
              iVar5 = FUN_1400c7b20(lVar12);
              if (iVar5 == param_3) {
                bVar2 = true;
                cVar3 = FUN_1400d21a0(param_1,lVar12,param_2);
                if (cVar3 == '\0') {
                  pIVar6 = theInstance();
                  lVar12 = param_2[2];
                  uVar7 = (*(code *)**(undefined8 **)pIVar6)
                                    (pIVar6,"STR_OPERATING_GIVE_PRIZE_FAILED");
                  (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar7);
                  return;
                }
              }
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)puVar10 + 0x29) == '\0') break;
            _invalid_parameter_noinfo();
          }
          puVar11 = puVar10;
          puVar8 = (undefined8 *)puVar10[2];
          if (*(char *)((longlong)puVar10[2] + 0x29) != '\0') break;
          do {
            puVar10 = puVar8;
            puVar8 = (undefined8 *)*puVar10;
          } while (*(char *)((longlong)*puVar10 + 0x29) == '\0');
        }
        do {
          puVar10 = (undefined8 *)puVar11[1];
          if (*(char *)((longlong)puVar10 + 0x29) != '\0') break;
          bVar13 = puVar11 == (undefined8 *)puVar10[2];
          puVar11 = puVar10;
        } while (bVar13);
      } while( true );
    }
    pIVar6 = theInstance();
    lVar12 = param_2[2];
    uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_OPERATING_GIVE_PRIZE_BACKPACK_IS_FULL");
    (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar7);
  }
  return;
}

// ==== CMsgOperatingAct::helper_1400d55e0  @1400d55e0  [medium:callgraph-r0]  (orig: FUN_1400d55e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400d55e0(ulonglong *param_1,longlong *param_2,longlong param_3,ushort param_4)

{
  undefined8 uVar1;
  longlong *plVar2;
  ulonglong *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  char cVar6;
  byte bVar7;
  short sVar8;
  uint uVar9;
  int iVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  longlong lVar15;
  ulonglong uVar16;
  longlong lVar17;
  ulonglong uVar18;
  bool bVar19;
  undefined1 auStack_6b8 [32];
  undefined4 local_698;
  ushort local_688;
  uint local_684;
  int local_680;
  uint local_67c;
  undefined8 *local_678;
  ulonglong *local_670;
  undefined8 *local_668;
  int local_660;
  ulonglong *local_658;
  undefined8 uStack_650;
  undefined8 local_648;
  undefined8 uStack_640;
  ulonglong *local_638 [6];
  undefined8 *local_608;
  longlong local_600;
  undefined8 *local_5f8;
  longlong *local_5f0;
  undefined8 *local_5e8;
  longlong *local_5e0;
  longlong local_5d8;
  ulonglong *local_5c8;
  undefined8 uStack_5c0;
  undefined8 *local_5b8;
  undefined8 local_5a8;
  undefined8 uStack_5a0;
  longlong *local_598;
  undefined8 *local_590;
  ulonglong *local_588;
  undefined8 uStack_580;
  undefined8 local_578;
  undefined8 uStack_570;
  undefined8 *local_568;
  undefined4 local_558;
  undefined4 uStack_554;
  undefined4 uStack_550;
  undefined4 uStack_54c;
  undefined8 *local_538;
  undefined4 local_528;
  undefined4 uStack_524;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  longlong *local_518;
  undefined8 *local_510;
  longlong *local_508;
  undefined8 *local_500;
  undefined4 local_4f8;
  undefined4 uStack_4f4;
  undefined4 uStack_4f0;
  undefined4 uStack_4ec;
  undefined4 local_4e8;
  undefined4 uStack_4e4;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined8 local_4d8;
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  ulonglong *local_4b8;
  longlong *local_4a8;
  ulonglong *local_498;
  undefined4 local_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_6b8;
  local_658 = param_1;
  local_648 = (ulonglong *)param_2;
  if (param_2 == (longlong *)0x0) {
    local_698 = 0x523;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_698 = 0x524;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 == 0) {
    local_698 = 0x525;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14035b850(local_478);
    FUN_14035b900(local_478,1);
    uVar9 = (**(code **)(*param_2 + 8))(param_2);
    local_590 = *(undefined8 **)((longlong)param_1 + 0xb8);
    puVar14 = (undefined8 *)local_590[1];
    local_668 = local_590;
    local_5f8 = local_590;
    local_568 = local_590;
    while (puVar12 = puVar14, *(char *)((longlong)puVar12 + 0x29) == '\0') {
      if (*(uint *)(puVar12 + 3) < uVar9) {
        puVar14 = (undefined8 *)puVar12[2];
      }
      else {
        if ((*(char *)((longlong)local_590 + 0x29) != '\0') &&
           (local_5f8 = local_590, uVar9 < *(uint *)(puVar12 + 3))) {
          local_590 = puVar12;
          local_5f8 = puVar12;
        }
        puVar14 = (undefined8 *)*puVar12;
        local_668 = puVar12;
        local_568 = puVar12;
      }
    }
    if (*(char *)((longlong)local_590 + 0x29) == '\0') {
      puVar14 = (undefined8 *)*local_590;
    }
    else {
      puVar14 = *(undefined8 **)(*(longlong *)((longlong)param_1 + 0xb8) + 8);
    }
    while (local_678 = puVar14, *(char *)((longlong)local_678 + 0x29) == '\0') {
      if (uVar9 < *(uint *)(local_678 + 3)) {
        local_590 = local_678;
        puVar14 = (undefined8 *)*local_678;
        local_5f8 = local_678;
      }
      else {
        puVar14 = (undefined8 *)local_678[2];
      }
    }
    local_670 = (ulonglong *)0x0;
    if ((undefined8 *)((longlong)param_1 + 0x88) == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    local_670 = *(ulonglong **)((longlong)param_1 + 0x88);
    local_510 = local_668;
    local_598 = (longlong *)local_670;
    local_518 = (longlong *)local_670;
    local_508 = (longlong *)local_670;
    local_500 = local_590;
    FUN_14000ef40(local_638);
    local_660 = 0;
    while (iVar10 = local_660, local_660 < (int)(uint)param_4) {
      if (*(int *)(param_3 + (longlong)local_660 * 4) != 0) {
        FUN_14000d480(local_638,&local_558);
      }
      local_660 = iVar10 + 1;
    }
    if (local_600 != 0) {
      local_684 = 0;
      local_680 = 0;
      local_688 = 0;
      local_67c = 0;
      puVar14 = (undefined8 *)*local_608;
      local_670 = local_638[0];
      local_4b8 = local_638[0];
      do {
        puVar12 = local_608;
        uVar18 = 0;
        local_498 = local_638[0];
        if ((local_670 == (ulonglong *)0x0) || (local_670 != local_638[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar14 == puVar12) {
LAB_1400d5eb9:
          sVar8 = FUN_14035bb10(local_478);
          if (sVar8 != 0) {
            (**(code **)(local_648[2] + 0x350))(local_648 + 2,local_478);
          }
          uStack_5a0 = local_608;
          puVar14 = uStack_5a0;
          local_5a8 = local_638[0];
          puVar3 = local_5a8;
          uVar1 = *local_608;
          local_588 = local_638[0];
          local_5a8._0_4_ = SUB84(local_638[0],0);
          local_5a8._4_4_ = (undefined4)((ulonglong)local_638[0] >> 0x20);
          uStack_5a0._0_4_ = SUB84(local_608,0);
          uStack_5a0._4_4_ = (undefined4)((ulonglong)local_608 >> 0x20);
          local_4e8 = (undefined4)local_5a8;
          uStack_4e4 = local_5a8._4_4_;
          uStack_4e0 = (undefined4)uStack_5a0;
          uStack_4dc = uStack_5a0._4_4_;
          uStack_580._0_4_ = (undefined4)uVar1;
          uStack_580._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
          local_558 = (undefined4)local_5a8;
          uStack_554 = local_5a8._4_4_;
          uStack_550 = (undefined4)uStack_580;
          uStack_54c = uStack_580._4_4_;
          local_5a8 = puVar3;
          uStack_5a0 = puVar14;
          uStack_580 = uVar1;
          FUN_14000bd50(local_638,&local_528,&local_558,&local_4e8);
          operator_delete(local_608);
          local_608 = (undefined8 *)0x0;
          local_600 = 0;
          operator_delete(local_638[0]);
          FUN_14035b8a0(local_478);
          return;
        }
        local_684 = local_684 + 1;
        if (1000 < local_684) {
          local_698 = 0x547;
          log_InlineLogERROR(&DAT_1406d9c10);
          goto LAB_1400d5eb9;
        }
        if (local_670 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar16 = uVar18;
        }
        else {
          uVar16 = *local_670;
        }
        if (puVar14 == *(undefined8 **)(uVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_680 = *(int *)(puVar14 + 3);
        bVar7 = 0;
        local_688 = 0;
        local_67c = 0;
        local_5e0 = (longlong *)0x0;
        plVar11 = (longlong *)FUN_1400ce610((longlong)param_1 + 8,&local_558,&local_680);
        plVar2 = (longlong *)*plVar11;
        local_5d8 = plVar11[1];
        lVar15 = *(longlong *)((longlong)param_1 + 0x38);
        local_4a8 = *(longlong **)((longlong)param_1 + 8);
        local_5e0 = plVar2;
        if ((plVar2 == (longlong *)0x0) || (plVar2 != local_4a8)) {
          _invalid_parameter_noinfo();
        }
        lVar4 = local_5d8;
        if (local_5d8 != lVar15) {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = 0;
          }
          else {
            lVar15 = *plVar2;
          }
          lVar17 = 0;
          if (lVar4 == *(longlong *)(lVar15 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(longlong *)(lVar4 + 0x20) != 0) {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar17 = *plVar2;
            }
            if (lVar4 == *(longlong *)(lVar17 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            sVar8 = FUN_1400c7a00(*(undefined8 *)(lVar4 + 0x20));
            if ((sVar8 == 2) || (sVar8 == 0)) {
              bVar7 = 0;
              local_688 = 0;
              uVar18 = 0;
              local_67c = 0;
            }
            else {
              param_1 = local_658;
              if (sVar8 != 1) goto LAB_1400d5e26;
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar15 = 0;
              }
              else {
                lVar15 = *plVar2;
              }
              if (lVar4 == *(longlong *)(lVar15 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              cVar6 = FUN_1400c7820(*(undefined8 *)(lVar4 + 0x20));
              plVar2 = local_518;
              if (cVar6 != '\x05') {
                local_5f0 = local_518;
                local_5e8 = local_510;
                puVar12 = local_510;
LAB_1400d5b80:
                lVar15 = 0;
                if ((plVar2 == (longlong *)0x0) || (plVar2 != local_508)) {
                  _invalid_parameter_noinfo();
                }
                if (puVar12 == local_500) goto LAB_1400d5cb7;
                if (plVar2 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                }
                else {
                  lVar15 = *plVar2;
                }
                if (puVar12 == *(undefined8 **)(lVar15 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                lVar15 = puVar12[4];
                if ((lVar15 == 0) || (iVar10 = FUN_1400c7b20(lVar15), iVar10 != local_680)) {
                  if (plVar2 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  if (*(char *)((longlong)puVar12 + 0x29) == '\0') {
                    puVar13 = puVar12;
                    puVar5 = (undefined8 *)puVar12[2];
                    if (*(char *)((longlong)puVar12[2] + 0x29) == '\0') {
                      do {
                        puVar12 = puVar5;
                        puVar5 = (undefined8 *)*puVar12;
                        local_5e8 = puVar12;
                        local_538 = puVar12;
                      } while (*(char *)((longlong)*puVar12 + 0x29) == '\0');
                    }
                    else {
                      do {
                        puVar12 = (undefined8 *)puVar13[1];
                        local_5e8 = puVar12;
                        if (*(char *)((longlong)puVar12 + 0x29) != '\0') break;
                        bVar19 = puVar13 == (undefined8 *)puVar12[2];
                        puVar13 = puVar12;
                      } while (bVar19);
                    }
                  }
                  else {
                    _invalid_parameter_noinfo();
                  }
                  goto LAB_1400d5b80;
                }
                bVar7 = FUN_1400c7c40(lVar15);
                local_688 = (ushort)bVar7;
                local_67c = FUN_1400c7be0(lVar15);
                uVar18 = (ulonglong)local_67c;
              }
            }
LAB_1400d5cb7:
            iVar10 = local_680;
            local_698 = CONCAT22(local_698._2_2_,sVar8);
            cVar6 = FUN_14035ba00(local_478,local_680,bVar7,uVar18);
            param_1 = local_658;
            if (cVar6 == '\0') {
              (**(code **)(local_648[2] + 0x350))(local_648 + 2,local_478);
              cVar6 = FUN_14035b900(local_478,1);
              if (cVar6 == '\0') {
                local_698 = 0x579;
                log_InlineLogERROR(&DAT_1406d9c10);
                uStack_570 = local_608;
                puVar14 = uStack_570;
                local_578 = local_638[0];
                puVar3 = local_578;
                uVar1 = *local_608;
                local_5c8 = local_638[0];
                local_578._0_4_ = SUB84(local_638[0],0);
                local_578._4_4_ = (undefined4)((ulonglong)local_638[0] >> 0x20);
                uStack_570._0_4_ = SUB84(local_608,0);
                uStack_570._4_4_ = (undefined4)((ulonglong)local_608 >> 0x20);
                local_4c8 = (undefined4)local_578;
                uStack_4c4 = local_578._4_4_;
                uStack_4c0 = (undefined4)uStack_570;
                uStack_4bc = uStack_570._4_4_;
                uStack_5c0._0_4_ = (undefined4)uVar1;
                uStack_5c0._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
                local_528 = (undefined4)local_578;
                uStack_524 = local_578._4_4_;
                uStack_520 = (undefined4)uStack_5c0;
                uStack_51c = uStack_5c0._4_4_;
                uStack_5c0 = uVar1;
                local_578 = puVar3;
                uStack_570 = puVar14;
                FUN_14000bd50(local_638,&local_558,&local_528,&local_4c8);
                operator_delete(local_608);
                local_608 = (undefined8 *)0x0;
                local_600 = 0;
                operator_delete(local_638[0]);
                FUN_14035b8a0(local_478);
                return;
              }
              local_698 = CONCAT22(local_698._2_2_,sVar8);
              FUN_14035ba00(local_478,iVar10,bVar7,uVar18);
              param_1 = local_658;
            }
          }
        }
LAB_1400d5e26:
        if (local_670 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar14 + 0x1d) == '\0') {
          puVar12 = puVar14;
          puVar13 = (undefined8 *)puVar14[2];
          if (*(char *)((longlong)puVar14[2] + 0x1d) == '\0') {
            do {
              puVar14 = puVar13;
              puVar13 = (undefined8 *)*puVar14;
              local_5b8 = puVar14;
            } while (*(char *)((longlong)*puVar14 + 0x1d) == '\0');
          }
          else {
            do {
              puVar14 = (undefined8 *)puVar12[1];
              if (*(char *)((longlong)puVar14 + 0x1d) != '\0') break;
              bVar19 = puVar12 == (undefined8 *)puVar14[2];
              puVar12 = puVar14;
            } while (bVar19);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      } while( true );
    }
    uStack_640 = local_608;
    puVar14 = uStack_640;
    local_648 = local_638[0];
    puVar3 = local_648;
    uVar1 = *local_608;
    local_658 = local_638[0];
    local_648._0_4_ = SUB84(local_638[0],0);
    local_648._4_4_ = (undefined4)((ulonglong)local_638[0] >> 0x20);
    uStack_640._0_4_ = SUB84(local_608,0);
    uStack_640._4_4_ = (undefined4)((ulonglong)local_608 >> 0x20);
    local_488 = (undefined4)local_648;
    uStack_484 = local_648._4_4_;
    uStack_480 = (undefined4)uStack_640;
    uStack_47c = uStack_640._4_4_;
    uStack_650._0_4_ = (undefined4)uVar1;
    uStack_650._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
    local_4f8 = (undefined4)local_648;
    uStack_4f4 = local_648._4_4_;
    uStack_4f0 = (undefined4)uStack_650;
    uStack_4ec = uStack_650._4_4_;
    uStack_650 = uVar1;
    local_648 = puVar3;
    uStack_640 = puVar14;
    FUN_14000bd50(local_638,&local_558,&local_4f8,&local_488);
    operator_delete(local_608);
    local_608 = (undefined8 *)0x0;
    local_600 = 0;
    operator_delete(local_638[0]);
    FUN_14035b8a0(local_478);
  }
  return;
}

// ==== CMsgOperatingAct::helper_14032a1e0  @14032a1e0  [medium:callgraph-r2]  (orig: FUN_14032a1e0)
undefined8 FUN_14032a1e0(longlong param_1,undefined1 param_2,char param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
  (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
  if (param_3 != '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  }
  return 1;
}

// ==== CMsgOperatingAct::helper_14035b900  @14035b900  [medium:callgraph-r1]  (orig: FUN_14035b900)
undefined8 FUN_14035b900(longlong param_1,undefined2 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 0x12;
  *(undefined4 *)(param_1 + 8) = 0x524;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 2) = 0;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgOperatingAct::helper_14035ba00  @14035ba00  [medium:callgraph-r1]  (orig: FUN_14035ba00)
ulonglong FUN_14035ba00(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                       undefined2 param_5)

{
  short *psVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (longlong)*(int *)(param_1 + 0xc) + 0xe;
    if (uVar3 < 0x400) {
      if (*(short *)(lVar2 + 2) != 0) {
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0xe;
      }
      *(undefined4 *)(lVar2 + 4 + (ulonglong)*(ushort *)(lVar2 + 2) * 0xc) = param_2;
      *(undefined2 *)
       (*(longlong *)(param_1 + 0x428) + 8 +
       (ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0xc) = param_3;
      *(undefined4 *)
       (*(longlong *)(param_1 + 0x428) +
       ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 3 + 3) * 4) = param_4;
      *(undefined2 *)
       (*(longlong *)(param_1 + 0x428) + 10 +
       (ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0xc) = param_5;
      lVar2 = *(longlong *)(param_1 + 0x428);
      psVar1 = (short *)(lVar2 + 2);
      *psVar1 = *psVar1 + 1;
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CMsgOperatingAct::helper_14035bb10  @14035bb10  [medium:callgraph-r1]  (orig: FUN_14035bb10)
undefined8 FUN_14035bb10(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x428);
  if (lVar1 == 0) {
    return 0;
  }
  return CONCAT62((int6)((ulonglong)lVar1 >> 0x10),*(undefined2 *)(lVar1 + 2));
}

// ==== CMsgOperatingAct::ctor_or_dtor  @14035bb80  [high:vtable-assign]  (orig: FUN_14035bb80)
undefined8 * FUN_14035bb80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgOperatingAct::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgOperatingAct::ctor_or_dtor  @14035bbd0  [high:vtable-assign]  (orig: FUN_14035bbd0)
void FUN_14035bbd0(undefined8 *param_1)

{
  *param_1 = CMsgOperatingAct::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgOperatingAct::vfunc_1  @14035bc00  [high:rtti-vtable]  (orig: FUN_14035bc00)
ulonglong FUN_14035bc00(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x523);
}

// ==== CMsgOperatingAct::helper_14035bc30  @14035bc30  [medium:callgraph-r2]  (orig: FUN_14035bc30)
undefined8
FUN_14035bc30(longlong param_1,undefined4 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 0xe;
  *(undefined4 *)(param_1 + 8) = 0x523;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 10) = param_2;
  **(undefined2 **)(param_1 + 0x428) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 6) = param_5;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 4) = 1;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgOperatingAct::ctor_or_dtor  @14035bc80  [high:vtable-assign]  (orig: FUN_14035bc80)
undefined8 * FUN_14035bc80(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgOperatingAct::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgOperatingAct::vfunc_3  @14035bcd0  [high:rtti-vtable]  (orig: FUN_14035bcd0)
void FUN_14035bcd0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  IStringManager *pIVar3;
  undefined8 uVar4;
  longlong lVar5;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))
                      (*(longlong **)(lVar2 + 0x90),param_1);
    if (lVar2 != 0) {
      cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x220))(lVar2 + 0x10);
      if (cVar1 == '\0') {
        pIVar3 = theInstance();
        lVar5 = *(longlong *)(lVar2 + 0x10);
        uVar4 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_DIE");
        (**(code **)(lVar5 + 0x358))(lVar2 + 0x10,uVar4);
      }
      else if (**(short **)(param_1 + 0x428) == 0) {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1c8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar4 = 0;
        }
        else {
          uVar4 = *(undefined8 *)(lVar5 + 0x1c8);
        }
        FUN_1400d55e0(uVar4,lVar2,*(longlong *)(param_1 + 0x428) + 10,
                      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4));
      }
      else if (**(short **)(param_1 + 0x428) == 2) {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1c8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar4 = 0;
        }
        else {
          uVar4 = *(undefined8 *)(lVar5 + 0x1c8);
        }
        FUN_1400d4240(uVar4,lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 10));
      }
    }
  }
  return;
}

