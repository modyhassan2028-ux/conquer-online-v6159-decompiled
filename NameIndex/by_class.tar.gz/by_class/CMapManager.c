// ==== CMapManager::helper_14002c190  @14002c190  [medium:callgraph-r2]  (orig: FUN_14002c190)
void FUN_14002c190(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapManager::helper_14002c2b0  @14002c2b0  [medium:callgraph-r2]  (orig: FUN_14002c2b0)
void FUN_14002c2b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014002c2d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapManager::helper_14002c740  @14002c740  [medium:callgraph-r2]  (orig: FUN_14002c740)
void FUN_14002c740(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapManager::helper_14002d580  @14002d580  [medium:callgraph-r1]  (orig: FUN_14002d580)
undefined8 * FUN_14002d580(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14002c2b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14002d76c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14002d76c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14002c740(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14002c190(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14002c740(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14002c190(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14002c740(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_14002c190(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapManager::helper_14008a0f0  @14008a0f0  [medium:callgraph-r0]  (orig: FUN_14008a0f0)
longlong FUN_14008a0f0(longlong param_1)

{
  int iVar1;
  
  if (*(longlong *)(param_1 + 0x80) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  return (longlong)(iVar1 + -0xd);
}

// ==== CMapManager::helper_14008a8d0  @14008a8d0  [medium:callgraph-r0]  (orig: FUN_14008a8d0)
void FUN_14008a8d0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  local_18 = param_2;
  local_14 = param_3;
  local_10 = param_4;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),8,0x15f97,0xc,&local_18);
  return;
}

// ==== CMapManager::helper_14008a910  @14008a910  [medium:callgraph-r0]  (orig: FUN_14008a910)
void FUN_14008a910(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),8,0x15f99,4,local_res10);
  return;
}

// ==== CMapManager::helper_14028e470  @14028e470  [medium:callgraph-r0]  (orig: FUN_14028e470)
void FUN_14028e470(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_res8;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x180))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x180);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x180);
  local_40 = puVar3;
  local_48 = *(longlong *)(param_1 + 0x150);
  if (*(longlong *)(param_1 + 0x150) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x180);
    local_38 = *(longlong *)(param_1 + 0x150);
  }
  else {
    plVar7 = &local_48;
  }
  plVar2 = (longlong *)*plVar7;
  lVar8 = *(longlong *)(param_1 + 0x180);
  local_28 = plVar2;
  local_20 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x150))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_20;
  if (local_20 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = *(longlong *)(lVar4 + 0x20);
    local_28 = (longlong *)*plVar7;
    local_20 = plVar7[1];
    local_res8 = lVar8;
    FUN_14002d580(param_1 + 0x150,&local_38,&local_28);
    if (lVar8 != 0) {
      FUN_14028dc40(param_1,2,&local_res8);
    }
  }
  return;
}

// ==== CMapManager::helper_1402c0d80  @1402c0d80  [medium:callgraph-r0]  (orig: FUN_1402c0d80)
undefined8 FUN_1402c0d80(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  if ((DAT_140975f88 & 1) == 0) {
    DAT_140975f88 = DAT_140975f88 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f80,"CNpc");
    atexit((_func_5014 *)&LAB_1406d69e0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975f80,0xd0);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1402c0240(pvVar1);
  }
  return uVar2;
}

// ==== CMapManager::helper_1402c29d0  @1402c29d0  [medium:callgraph-r0]  (orig: FUN_1402c29d0)
undefined8 FUN_1402c29d0(longlong *param_1,undefined4 param_2,undefined8 param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  
  *(undefined4 *)((longlong)param_1 + 0xc4) = param_2;
  *(char *)(param_1 + 0xd) = param_4;
  if (param_1[0xc] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_4 == '\0') {
    puVar5 = operator_new(0x18);
    if (puVar5 == (undefined8 *)0x0) {
      puVar5 = (undefined8 *)0x0;
    }
    else {
      *puVar5 = IGameData::vftable;
      *puVar5 = CGameData<&char*_szNpcTable,&char*_szID>::vftable;
      *(undefined1 *)(puVar5 + 2) = 0;
      puVar5[1] = 0;
    }
    if (puVar5 != (undefined8 *)0x0) {
      param_1[0xc] = (longlong)puVar5;
    }
  }
  else {
    puVar5 = operator_new(0x18);
    if (puVar5 == (undefined8 *)0x0) {
      puVar5 = (undefined8 *)0x0;
    }
    else {
      *puVar5 = IGameData::vftable;
      *puVar5 = CGameData<&char*_szDynTable,&char*_szID>::vftable;
      *(undefined1 *)(puVar5 + 2) = 0;
      puVar5[1] = 0;
    }
    if (puVar5 != (undefined8 *)0x0) {
      param_1[0xc] = (longlong)puVar5;
    }
  }
  plVar8 = (longlong *)param_1[0xc];
  if ((plVar8 == (longlong *)0x0) ||
     (cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,param_3), cVar1 == '\0')) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
  if (*(longlong *)(lVar6 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar8 = *(longlong **)(lVar6 + 0x98);
  lVar6 = *plVar8;
  uVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],7);
  lVar6 = (**(code **)(lVar6 + 0x10))(plVar8,uVar2,0);
  if (lVar6 != 0) {
    if (param_4 == '\0') {
      uVar2 = (**(code **)(*(longlong *)param_1[0xc] + 8))();
      *(undefined4 *)(param_1 + 0xb) = uVar2;
    }
    else {
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
      plVar8 = (longlong *)FUN_1400876b0(uVar7);
      uVar2 = (**(code **)(*plVar8 + 200))(plVar8);
      *(undefined4 *)(param_1 + 0xb) = uVar2;
    }
    uVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],8);
    *(undefined4 *)(param_1 + 4) = uVar2;
    uVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],9);
    *(undefined4 *)((longlong)param_1 + 0x24) = uVar2;
    cVar1 = (**(code **)(*param_1 + 0x78))(param_1);
    if (((((((cVar1 != '\0') || (cVar1 = (**(code **)(*param_1 + 0x50))(param_1), cVar1 != '\0')) ||
           (cVar1 = (**(code **)(*param_1 + 0x88))(param_1), cVar1 != '\0')) ||
          ((cVar1 = (**(code **)(*param_1 + 0x60))(param_1), cVar1 != '\0' ||
           (cVar1 = (**(code **)(*param_1 + 0xa8))(param_1), cVar1 != '\0')))) ||
         (((iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x6e ||
           ((iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
            iVar3 == 0x20 ||
            (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
            iVar3 == 0x21)))) ||
          (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar3 == 0x22)))) ||
        ((((iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x23 ||
           (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x24)) ||
          (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar3 == 0x25)) ||
         (((cVar1 = FUN_1402ba6c0(param_1), cVar1 != '\0' ||
           (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x70)) ||
          ((iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x71 ||
           (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar3 == 0x3c)))))))) && (cVar1 = FUN_1402bd1e0(param_1,param_2), cVar1 == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    cVar1 = FUN_1402bc390(param_1);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    lVar9 = FUN_1402c18f0(1);
    param_1[0xf] = lVar9;
    if (lVar9 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    param_1[0xe] = lVar6;
    uVar2 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
    uVar4 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
    uVar7 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    cVar1 = FUN_14015f9d0(uVar7,uVar4,uVar2);
    if (cVar1 == '\0') {
      (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      FUN_140087360(param_1);
      log_InlineLogDBERROR(&DAT_140743c28);
      param_1[0xe] = 0;
      return 0;
    }
    uVar7 = (**(code **)(param_1[2] + 0x2a0))(param_1 + 2);
    FUN_1402c90f0(param_1[0xe],uVar7,1);
    FUN_1402bda30(param_1);
    iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
    if (iVar3 == 10) {
      uVar2 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
      uVar7 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
      FUN_1402cb7b0(uVar7,uVar2,0);
      FUN_1402c0df0(param_1);
      plVar8 = (longlong *)param_1[0xc];
      if (plVar8 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,0x15);
        if (iVar3 != 0) {
          uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
          plVar8 = (longlong *)FUN_1400876b0(uVar7);
          lVar6 = (**(code **)(*plVar8 + 0x10))(plVar8,iVar3,1);
          if (lVar6 != 0) {
            uVar2 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
            FUN_1402cb7b0(lVar6,uVar2,0);
          }
        }
      }
    }
    if (((char)param_1[0xd] == '\0') &&
       (iVar3 = (**(code **)(param_1[2] + 0x80))(param_1 + 2), iVar3 != 0)) {
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogERROR(&DAT_140743c00);
    }
    uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
    plVar8 = (longlong *)FUN_1400875f0(uVar7);
    (**(code **)(*plVar8 + 0xd8))(plVar8,param_1,param_4);
    return 1;
  }
  if (param_4 == '\0') {
    plVar8 = (longlong *)param_1[0xc];
    (**(code **)(*plVar8 + 0x10))(plVar8,0);
    (**(code **)(*plVar8 + 0x10))(plVar8,7);
    log_InlineLogDBERROR("table:cq_map, cannot find map:%u for npc:%u @%s,%d");
  }
  return 0;
}

// ==== CMapManager::helper_1402c3f90  @1402c3f90  [medium:callgraph-r0]  (orig: FUN_1402c3f90)
void FUN_1402c3f90(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402c3f9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),0x11);
  return;
}

// ==== CMapManager::helper_1402c3fa0  @1402c3fa0  [medium:callgraph-r0]  (orig: FUN_1402c3fa0)
void FUN_1402c3fa0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402c3fac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),0x12);
  return;
}

// ==== CMapManager::helper_1402c3fb0  @1402c3fb0  [medium:callgraph-r0]  (orig: FUN_1402c3fb0)
void FUN_1402c3fb0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402c3fbc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),0x13);
  return;
}

// ==== CMapManager::helper_1402c4580  @1402c4580  [medium:callgraph-r1]  (orig: FUN_1402c4580)
longlong FUN_1402c4580(longlong param_1,ulonglong param_2)

{
  if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18)) / 0x30) <= param_2
     ) {
    _invalid_parameter_noinfo();
  }
  return param_2 * 0x30 + *(longlong *)(param_1 + 0x18);
}

// ==== CMapManager::helper_1402c4ac0  @1402c4ac0  [medium:callgraph-r2]  (orig: FUN_1402c4ac0)
void FUN_1402c4ac0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapManager::helper_1402c4b30  @1402c4b30  [medium:callgraph-r2]  (orig: FUN_1402c4b30)
void FUN_1402c4b30(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_70,"invalid vector<T> subscript");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_1409445a0);
}

// ==== CMapManager::helper_1402c5ae0  @1402c5ae0  [medium:callgraph-r0]  (orig: FUN_1402c5ae0)
void FUN_1402c5ae0(__uint64 param_1)

{
  if ((DAT_140975f98 & 1) == 0) {
    DAT_140975f98 = DAT_140975f98 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f90,"CGameMap");
    atexit((_func_5014 *)&LAB_1406d69f0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402c5b35. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975f90,param_1);
  return;
}

// ==== CMapManager::helper_1402c6040  @1402c6040  [medium:callgraph-r0]  (orig: FUN_1402c6040)
void FUN_1402c6040(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  
  uVar4 = 0;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))();
  if (lVar1 != 0) {
    do {
      lVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x18))
                        (*(longlong **)(param_1 + 0x50),uVar4,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\gamemap.cpp"
                         ,0x105);
      if (lVar1 != 0) {
        lVar1 = *(longlong *)(lVar1 + 8);
        if (lVar1 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          lVar1 = 0;
        }
        FUN_1403ac5f0(lVar1);
      }
      uVar4 = uVar4 + 1;
      uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))();
    } while (uVar4 < uVar2);
  }
  plVar3 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
  uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
  if ((uVar4 >> 0x17 & 1) != 0) {
    if (*(longlong *)(param_1 + 0x68) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_140395590(*(longlong *)(param_1 + 0x68),param_2);
  }
  return;
}

// ==== CMapManager::helper_1402c7b10  @1402c7b10  [medium:callgraph-r2]  (orig: FUN_1402c7b10)
void FUN_1402c7b10(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMapManager::helper_1402ca360  @1402ca360  [medium:callgraph-r2]  (orig: FUN_1402ca360)
longlong FUN_1402ca360(longlong param_1,longlong param_2,longlong param_3)

{
  undefined8 *puVar1;
  undefined1 *puVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar4 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar3 = param_1 - param_3;
    puVar2 = (undefined1 *)(param_3 + 0x10);
    do {
      puVar1 = (undefined8 *)(param_1 + 8);
      param_1 = param_1 + 0x18;
      *(undefined8 *)(puVar2 + -8) = *puVar1;
      *puVar2 = (puVar2 + 0x18)[lVar3 + -0x18];
      puVar2 = puVar2 + 0x18;
    } while (param_1 != param_2);
  }
  return param_3 + (lVar4 / 0x18) * 0x18;
}

// ==== CMapManager::helper_1402ca440  @1402ca440  [medium:callgraph-r2]  (orig: FUN_1402ca440)
void * FUN_1402ca440(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CMapManager::helper_1402cb1b0  @1402cb1b0  [medium:callgraph-r1]  (orig: FUN_1402cb1b0)
ulonglong FUN_1402cb1b0(longlong *param_1,ulonglong param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[3];
  if ((ulonglong)((longlong)(param_1[4] - uVar1) >> 3) <= param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1402c4b30();
  }
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 + param_2 * 8;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1402cb242;
  }
  _invalid_parameter_noinfo();
LAB_1402cb242:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMapManager::helper_1402cb5d0  @1402cb5d0  [medium:callgraph-r2]  (orig: FUN_1402cb5d0)
void * FUN_1402cb5d0(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CMapManager::helper_1402cc100  @1402cc100  [medium:callgraph-r1]  (orig: FUN_1402cc100)
undefined8 * FUN_1402cc100(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IGameObjSet<CWeatherRegion>::vftable;
  *param_1 = CGameObjSet<CWeatherRegion>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CMapManager::helper_1402cced0  @1402cced0  [medium:callgraph-r1]  (orig: FUN_1402cced0)
void FUN_1402cced0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1402c4ac0();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_1402c7b10(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_1402cb5d0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_1402cb5d0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1402ca440(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CMapManager::helper_1402cdda0  @1402cdda0  [medium:callgraph-r3]  (orig: FUN_1402cdda0)
void FUN_1402cdda0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar2 = (undefined8 *)param_1[3];
  if (puVar2 != (undefined8 *)0x0) {
    puVar1 = (undefined8 *)param_1[4];
    for (; puVar2 != puVar1; puVar2 = puVar2 + 3) {
      (**(code **)*puVar2)(puVar2,0,param_3,param_4,uVar3);
    }
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapManager::helper_1402cf060  @1402cf060  [medium:callgraph-r1]  (orig: FUN_1402cf060)
undefined8 FUN_1402cf060(longlong param_1,int param_2)

{
  int iVar1;
  void *pvVar2;
  longlong lVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong *plVar6;
  ulonglong uVar7;
  
  pvVar2 = operator_new(0x40);
  if (pvVar2 == (void *)0x0) {
    lVar3 = 0;
  }
  else {
    lVar3 = FUN_1400ad2f0(pvVar2,0);
  }
  *(longlong *)(param_1 + 0x48) = lVar3;
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    uVar7 = 0;
    while( true ) {
      plVar6 = DAT_140975bc0;
      if (DAT_140975bc0 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = (longlong *)0x0;
      }
      uVar5 = (**(code **)(*plVar6 + 0x18))();
      if (uVar5 <= uVar7) break;
      plVar6 = DAT_140975bc0;
      if (DAT_140975bc0 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = (longlong *)0x0;
      }
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,uVar7);
      if (plVar6 != (longlong *)0x0) {
        iVar1 = (**(code **)(*plVar6 + 0x10))(plVar6,1);
        if (iVar1 == param_2) {
          (**(code **)(**(longlong **)(param_1 + 0x48) + 0x28))
                    (*(longlong **)(param_1 + 0x48),plVar6);
        }
      }
      uVar7 = uVar7 + 1;
    }
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMapManager::helper_1402cf320  @1402cf320  [medium:callgraph-r1]  (orig: FUN_1402cf320)
void FUN_1402cf320(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong local_38;
  ulonglong uStack_30;
  
  uVar10 = 0xfffffffffffffffe;
  uVar1 = param_1[4];
  uVar2 = param_1[3];
  uVar5 = (longlong)(uVar1 - uVar2) / 0x18;
  if (uVar5 < param_2) {
    if (uVar1 < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_38 = *param_1;
    uStack_30 = uVar1;
    FUN_1402ce1f0(param_1,&local_38,param_2 - (param_1[4] - param_1[3]) / 0x18,param_3,uVar10);
    goto LAB_1402cf4ad;
  }
  if (uVar5 <= param_2) goto LAB_1402cf4ad;
  if (uVar1 < uVar2) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_1;
  lVar9 = 0;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar8 = lVar9;
  }
  else {
    lVar8 = *plVar3;
  }
  uVar2 = uVar2 + param_2 * 0x18;
  if (*(ulonglong *)(lVar8 + 0x20) < uVar2) {
LAB_1402cf435:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar3 != (longlong *)0x0) {
      lVar9 = *plVar3;
    }
    if (uVar2 < *(ulonglong *)(lVar9 + 0x18)) goto LAB_1402cf435;
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar9 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar9 == 0) || (lVar9 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    puVar6 = (undefined8 *)FUN_1402ca360(uVar1,param_1[4],uVar2);
    puVar4 = (undefined8 *)param_1[4];
    for (puVar7 = puVar6; puVar7 != puVar4; puVar7 = puVar7 + 3) {
      (**(code **)*puVar7)(puVar7,0);
    }
    param_1[4] = (longlong)puVar6;
  }
LAB_1402cf4ad:
  FUN_1404721c0(param_3);
  return;
}

// ==== CMapManager::helper_1402cf4d0  @1402cf4d0  [medium:callgraph-r1]  (orig: FUN_1402cf4d0)
void FUN_1402cf4d0(longlong *param_1,ulonglong param_2,undefined4 param_3)

{
  rsize_t _DstSize;
  void *_Src;
  void *pvVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_res18 [2];
  longlong local_28;
  void *pvStack_20;
  
  _Src = (void *)param_1[4];
  pvVar1 = (void *)param_1[3];
  uVar3 = (longlong)_Src - (longlong)pvVar1 >> 2;
  local_res18[0] = param_3;
  if (uVar3 < param_2) {
    if (_Src < pvVar1) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    pvStack_20 = _Src;
    FUN_14000df40(param_1,&local_28,param_2 - (param_1[4] - param_1[3] >> 2),local_res18);
    return;
  }
  if (uVar3 <= param_2) {
    return;
  }
  if (_Src < pvVar1) {
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar4 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar4;
  }
  else {
    lVar5 = *plVar2;
  }
  pvVar1 = (void *)(uVar3 + param_2 * 4);
  if (pvVar1 <= *(void **)(lVar5 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar4 = *plVar2;
    }
    if (*(void **)(lVar4 + 0x18) <= pvVar1) goto LAB_1402cf5b7;
  }
  _invalid_parameter_noinfo();
LAB_1402cf5b7:
  if ((pvVar1 < (void *)param_1[3]) || ((void *)param_1[4] < pvVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (pvVar1 != _Src) {
    lVar4 = param_1[4] - (longlong)_Src >> 2;
    _DstSize = lVar4 * 4;
    if (0 < lVar4) {
      memmove_s(pvVar1,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)pvVar1);
  }
  return;
}

// ==== CMapManager::helper_1402cf760  @1402cf760  [medium:callgraph-r3]  (orig: FUN_1402cf760)
longlong FUN_1402cf760(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_1402ceb30(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMapManager::helper_1402cf7e0  @1402cf7e0  [medium:callgraph-r3]  (orig: FUN_1402cf7e0)
longlong FUN_1402cf7e0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_1402ced30(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMapManager::helper_1402d1bd0  @1402d1bd0  [medium:callgraph-r0]  (orig: FUN_1402d1bd0)
undefined8 FUN_1402d1bd0(longlong *param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong *plVar10;
  longlong *plVar11;
  uint uVar12;
  longlong *plVar14;
  longlong *local_res8;
  longlong *local_res10;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  longlong *local_50;
  longlong *local_48;
  longlong local_40;
  longlong *plVar13;
  
  lVar4 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x98) + 0x50))();
  uVar9 = (*(longlong *)(lVar4 + 0x28) - *(longlong *)(lVar4 + 0x20) >> 3) - 1;
  local_res10 = operator_new(8);
  plVar14 = (longlong *)0x0;
  local_68[0] = plVar14;
  if (local_res10 != (longlong *)0x0) {
    *local_res10 = (longlong)local_68;
    local_68[0] = local_res10;
  }
  local_50 = (longlong *)0x0;
  local_48 = (longlong *)0x0;
  local_40 = 0;
  plVar13 = plVar14;
  local_res8 = local_res10;
LAB_1402d1cb0:
  do {
    do {
      do {
        if ((ulonglong)(*(longlong *)(lVar4 + 0x28) - *(longlong *)(lVar4 + 0x20) >> 3) <= uVar9) {
LAB_1402d1eb5:
          plVar10 = local_50;
          plVar13 = local_68[0];
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
            plVar13 = local_68[0];
          }
          while( true ) {
            plVar7 = local_48;
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            if ((plVar13 == (longlong *)0x0) || (plVar13 != local_68[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar10 == plVar7) break;
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar7 = plVar14;
            }
            else {
              plVar7 = (longlong *)*plVar13;
            }
            if ((longlong *)plVar7[4] <= plVar10) {
              _invalid_parameter_noinfo();
            }
            if (*plVar10 != 0) {
              if (plVar13 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar7 = plVar14;
              }
              else {
                plVar7 = (longlong *)*plVar13;
              }
              if ((longlong *)plVar7[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              if ((*(uint *)(*plVar10 + 0x20) < 0x10a1d0) || (0x10a5cc < *(uint *)(*plVar10 + 0x20))
                 ) {
                if (plVar13 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar7 = plVar14;
                }
                else {
                  plVar7 = (longlong *)*plVar13;
                }
                if ((longlong *)plVar7[4] <= plVar10) {
                  _invalid_parameter_noinfo();
                }
                if (*(int *)(*plVar10 + 0x1c) != 0) {
                  if (plVar13 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    plVar7 = plVar14;
                  }
                  else {
                    plVar7 = (longlong *)*plVar13;
                  }
                  if ((longlong *)plVar7[4] <= plVar10) {
                    _invalid_parameter_noinfo();
                  }
                  uVar3 = *(undefined4 *)(*plVar10 + 0x1c);
                  lVar4 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
                  plVar7 = *(longlong **)(lVar4 + 0x210);
                  if (*(longlong **)(lVar4 + 0x210) == (longlong *)0x0) {
                    log_InlineLogERROR(&DAT_1406d9c10);
                    plVar7 = plVar14;
                  }
                  FUN_14028e470(plVar7,uVar3);
                }
              }
              if (plVar13 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar7 = plVar14;
              }
              else {
                plVar7 = (longlong *)*plVar13;
              }
              if ((longlong *)plVar7[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              plVar7 = (longlong *)*plVar10;
              lVar4 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
              if (*(longlong *)(lVar4 + 0x98) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x98) + 0x50))();
              lVar4 = *plVar8;
              uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
              (**(code **)(lVar4 + 0x28))(plVar8,uVar3);
            }
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar7 = plVar14;
            }
            else {
              plVar7 = (longlong *)*plVar13;
            }
            if ((longlong *)plVar7[4] <= plVar10) {
              _invalid_parameter_noinfo();
            }
            plVar10 = plVar10 + 1;
          }
          if (local_50 != (longlong *)0x0) {
            operator_delete(local_50);
          }
          local_50 = (longlong *)0x0;
          local_48 = (longlong *)0x0;
          local_40 = 0;
          operator_delete(local_68[0]);
          return 1;
        }
        puVar5 = (undefined8 *)FUN_1402cb1b0(lVar4 + 8,uVar9);
        plVar10 = (longlong *)*puVar5;
        if (plVar10 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        uVar9 = uVar9 - 1;
        uVar12 = (int)plVar13 + 1;
        plVar13 = (longlong *)(ulonglong)uVar12;
        if (1000000 < uVar12) {
          log_InlineLogERROR(&DAT_1406d9c10);
          goto LAB_1402d1eb5;
        }
      } while ((plVar10 == (longlong *)0x0) ||
              (lVar6 = (**(code **)(*plVar10 + 0x28))(plVar10), lVar6 == 0));
      plVar7 = (longlong *)(**(code **)(*plVar10 + 0x28))(plVar10);
      iVar1 = (**(code **)(*plVar7 + 8))(plVar7);
      iVar2 = (**(code **)(*param_1 + 8))(param_1);
      plVar7 = local_48;
    } while (iVar1 != iVar2);
    plVar8 = plVar14;
    if (local_50 != (longlong *)0x0) {
      plVar8 = (longlong *)(local_40 - (longlong)local_50 >> 3);
    }
    local_res8 = plVar10;
    if (plVar8 <= (longlong *)((longlong)local_48 - (longlong)local_50 >> 3)) {
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
      }
      plVar8 = local_50;
      plVar10 = local_68[0];
      plVar11 = plVar14;
      if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffff8U) != 0) {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        if ((plVar10 == (longlong *)0x0) || (plVar10 != local_68[0])) {
          _invalid_parameter_noinfo();
        }
        plVar11 = (longlong *)((longlong)plVar7 - (longlong)plVar8 >> 3);
      }
      local_88 = SUB84(plVar10,0);
      uStack_84 = (undefined4)((ulonglong)plVar10 >> 0x20);
      uStack_80 = SUB84(plVar7,0);
      uStack_7c = (undefined4)((ulonglong)plVar7 >> 0x20);
      local_78 = local_88;
      uStack_74 = uStack_84;
      uStack_70 = uStack_80;
      uStack_6c = uStack_7c;
      FUN_1402cced0(local_68,&local_78,1,&local_res8);
      plVar10 = local_50;
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
      }
      plVar7 = local_68[0];
      if (local_68[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar14;
      }
      else {
        plVar8 = (longlong *)*local_68[0];
      }
      if (plVar10 + (longlong)plVar11 <= (longlong *)plVar8[4]) {
        plVar8 = plVar14;
        if (plVar7 != (longlong *)0x0) {
          plVar8 = (longlong *)*plVar7;
        }
        if ((longlong *)plVar8[3] <= plVar10 + (longlong)plVar11) goto LAB_1402d1cb0;
      }
      _invalid_parameter_noinfo();
      goto LAB_1402d1cb0;
    }
    *local_48 = (longlong)plVar10;
    local_48 = local_48 + 1;
  } while( true );
}

// ==== CMapManager::helper_1402d3750  @1402d3750  [medium:callgraph-r3]  (orig: FUN_1402d3750)
void FUN_1402d3750(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  undefined1 local_res8;
  undefined1 local_68 [48];
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    lVar6 = *(longlong *)(param_1 + 0x28) - lVar4;
    lVar6 = lVar6 / 6 + (lVar6 >> 0x3f);
    uVar5 = (lVar6 >> 3) - (lVar6 >> 0x3f);
  }
  if (param_3 != 0) {
    lVar4 = (*(longlong *)(param_1 + 0x20) - lVar4) / 0x30;
    if (0x555555555555555U - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1402c4980();
    }
    uVar1 = lVar4 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar5 < uVar1) {
      if (0x555555555555555 - (uVar5 >> 1) < uVar5) {
        uVar5 = 0;
      }
      else {
        uVar5 = uVar5 + (uVar5 >> 1);
      }
      if (uVar5 < uVar1) {
        uVar5 = uVar1;
      }
      lVar2 = FUN_1402c7a10(param_1 + 0x10,uVar5);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
      lVar4 = (lVar4 >> 3) - (lVar4 >> 0x3f);
      FUN_1402d2b60(lVar4 * 0x30 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar2,lVar4);
      FUN_1402d2be0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1402d2be0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x30 + lVar2,param_1 + 0x10,local_res8,0,2);
      lVar4 = *(longlong *)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (lVar4 != 0) {
        FUN_1402d2ac0(lVar4,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar5 * 0x30 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar6 - lVar4) / 0x30) * 0x30 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_1402cd430(local_68,param_4);
      FUN_1402d2be0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      FUN_1402d2b60(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (lVar6 = *(longlong *)(param_2 + 8); lVar6 != lVar4 + param_3 * -0x30;
          lVar6 = lVar6 + 0x30) {
        FUN_1402ceb30(lVar6,local_68);
      }
      FUN_1402cdda0(local_68);
    }
    else {
      FUN_1402cd430(local_68,param_4);
      lVar4 = *(longlong *)(param_1 + 0x20);
      lVar6 = lVar4 + param_3 * -0x30;
      uVar3 = FUN_1402d2be0(lVar6,lVar4,lVar4,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1402d34e0(*(undefined8 *)(param_2 + 8),lVar6,lVar4);
      lVar6 = *(longlong *)(param_2 + 8);
      lVar4 = lVar6 + param_3 * 0x30;
      for (; lVar6 != lVar4; lVar6 = lVar6 + 0x30) {
        FUN_1402ceb30(lVar6,local_68);
      }
      FUN_1402cdda0(local_68);
    }
  }
  return;
}

// ==== CMapManager::helper_1402d3b20  @1402d3b20  [medium:callgraph-r3]  (orig: FUN_1402d3b20)
void FUN_1402d3b20(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined1 local_res8;
  void *local_68 [3];
  void *local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    lVar7 = *(longlong *)(param_1 + 0x28) - lVar4;
    lVar7 = lVar7 / 6 + (lVar7 >> 0x3f);
    uVar5 = (lVar7 >> 3) - (lVar7 >> 0x3f);
  }
  uVar6 = 0;
  if (param_3 != 0) {
    lVar4 = (*(longlong *)(param_1 + 0x20) - lVar4) / 0x30;
    if (0x555555555555555U - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1402c4a10();
    }
    uVar1 = lVar4 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar5 < uVar1) {
      if (uVar5 <= 0x555555555555555 - (uVar5 >> 1)) {
        uVar6 = uVar5 + (uVar5 >> 1);
      }
      if (uVar6 < uVar1) {
        uVar6 = uVar1;
      }
      lVar2 = FUN_1402c7a90(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
      lVar4 = (lVar4 >> 3) - (lVar4 >> 0x3f);
      FUN_1402cf980(lVar4 * 0x30 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar4,lVar2);
      FUN_1402d2e30(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1402d2e30(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x30 + lVar2,param_1 + 0x10,local_res8,0,2);
      lVar4 = *(longlong *)(param_1 + 0x18);
      lVar7 = *(longlong *)(param_1 + 0x20);
      if (lVar4 != 0) {
        FUN_1402cf8b0(lVar4,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x30 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar7 - lVar4) / 0x30) * 0x30 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_1402cd5a0(local_68,param_4);
      FUN_1402d2e30(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      FUN_1402cf980(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (lVar7 = *(longlong *)(param_2 + 8); lVar7 != lVar4 + param_3 * -0x30;
          lVar7 = lVar7 + 0x30) {
        FUN_1402ced30(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
    else {
      FUN_1402cd5a0(local_68,param_4);
      lVar4 = *(longlong *)(param_1 + 0x20);
      lVar7 = lVar4 + param_3 * -0x30;
      uVar3 = FUN_1402d2e30(lVar7,lVar4,lVar4,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1402d3590(*(undefined8 *)(param_2 + 8),lVar7,lVar4);
      lVar7 = *(longlong *)(param_2 + 8);
      lVar4 = lVar7 + param_3 * 0x30;
      for (; lVar7 != lVar4; lVar7 = lVar7 + 0x30) {
        FUN_1402ced30(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
  }
  return;
}

// ==== CMapManager::helper_1402d4070  @1402d4070  [medium:callgraph-r2]  (orig: FUN_1402d4070)
void FUN_1402d4070(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  undefined1 local_res8;
  longlong local_38;
  ulonglong uStack_30;
  
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x30;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_38 = *param_1;
    uStack_30 = uVar1;
    FUN_1402d3750(param_1,&local_38,param_2 - (param_1[4] - param_1[3]) / 0x30,param_3);
    goto LAB_1402d4214;
  }
  if (uVar3 <= param_2) goto LAB_1402d4214;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar4 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = lVar4;
  }
  else {
    lVar6 = *plVar2;
  }
  uVar5 = uVar5 + param_2 * 0x30;
  if (*(ulonglong *)(lVar6 + 0x20) < uVar5) {
LAB_1402d4188:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 != (longlong *)0x0) {
      lVar4 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar4 + 0x18)) goto LAB_1402d4188;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    lVar4 = FUN_1402cf760(uVar1,param_1[4],uVar5,local_res8,local_res8,0);
    FUN_1402d2ac0(lVar4,param_1[4],param_1 + 2,local_res8);
    param_1[4] = lVar4;
  }
LAB_1402d4214:
  FUN_1402cdda0(param_3);
  return;
}

// ==== CMapManager::helper_1402d4240  @1402d4240  [medium:callgraph-r2]  (orig: FUN_1402d4240)
void FUN_1402d4240(longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  longlong local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x30;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    uStack_20 = uVar1;
    FUN_1402d3b20(param_1,&local_28,param_2 - (param_1[4] - param_1[3]) / 0x30,param_3);
    goto LAB_1402d43e5;
  }
  if (uVar3 <= param_2) goto LAB_1402d43e5;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = 0;
  }
  else {
    lVar4 = *plVar2;
  }
  uVar5 = uVar5 + param_2 * 0x30;
  if (*(ulonglong *)(lVar4 + 0x20) < uVar5) {
LAB_1402d4359:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar4 + 0x18)) goto LAB_1402d4359;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    local_res18 = SUB81(param_3,0);
    lVar4 = FUN_1402cf7e0(uVar1,param_1[4],uVar5,(ulonglong)param_3 & 0xff,local_res18,0);
    FUN_1402cf8b0(lVar4,param_1[4],param_1 + 2,(ulonglong)param_3 & 0xff);
    param_1[4] = lVar4;
  }
LAB_1402d43e5:
  if ((void *)param_3[3] != (void *)0x0) {
    operator_delete((void *)param_3[3]);
  }
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  operator_delete((void *)*param_3);
  return;
}

// ==== CMapManager::helper_1402d4710  @1402d4710  [medium:callgraph-r1]  (orig: FUN_1402d4710)
void FUN_1402d4710(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong *local_38 [3];
  undefined8 local_20;
  undefined8 local_18;
  undefined8 local_10;
  
  uVar2 = 0xfffffffffffffffe;
  plVar1 = operator_new(8);
  local_38[0] = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)local_38;
    local_38[0] = plVar1;
  }
  local_20 = 0;
  local_18 = 0;
  local_10 = 0;
  FUN_1402d4070(param_1,param_2,local_38,param_4,uVar2,plVar1);
  return;
}

// ==== CMapManager::helper_1402d47a0  @1402d47a0  [medium:callgraph-r1]  (orig: FUN_1402d47a0)
void FUN_1402d47a0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong *local_38 [3];
  undefined8 local_20;
  undefined8 local_18;
  undefined8 local_10;
  
  uVar2 = 0xfffffffffffffffe;
  plVar1 = operator_new(8);
  local_38[0] = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)local_38;
    local_38[0] = plVar1;
  }
  local_20 = 0;
  local_18 = 0;
  local_10 = 0;
  FUN_1402d4240(param_1,param_2,local_38,param_4,uVar2,plVar1);
  return;
}

// ==== CMapManager::helper_1402d4860  @1402d4860  [medium:callgraph-r0]  (orig: FUN_1402d4860)
undefined8 FUN_1402d4860(longlong *param_1,undefined4 param_2,undefined8 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 uVar5;
  void *pvVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  uint uVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 local_58 [32];
  
  *(undefined4 *)((longlong)param_1 + 0x74) = param_2;
  plVar4 = operator_new(0x18);
  if (plVar4 == (longlong *)0x0) {
    plVar4 = (longlong *)0x0;
  }
  else {
    *plVar4 = (longlong)IGameData::vftable;
    *plVar4 = (longlong)CGameData<&char*_szMapTable,&char*_szID>::vftable;
    *(undefined1 *)(plVar4 + 2) = 0;
    plVar4[1] = 0;
  }
  plVar13 = (longlong *)0x0;
  param_1[0xb] = (longlong)plVar4;
  if ((plVar4 == (longlong *)0x0) ||
     (cVar1 = (**(code **)(*plVar4 + 0x30))(plVar4,param_3), cVar1 == '\0')) {
    uVar5 = 0;
  }
  else {
    (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],3);
    log_InlineLogMessage(&DAT_1407458e8);
    uVar2 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],3);
    plVar4 = (longlong *)FUN_1405090c0(uVar2,0);
    param_1[0xc] = (longlong)plVar4;
    if (plVar4 == (longlong *)0x0) {
      (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],3);
      log_InlineLogERROR(&DAT_1407458d0);
      uVar5 = 0;
    }
    else {
      iVar3 = (**(code **)(*plVar4 + 0x28))(plVar4);
      FUN_1402d47a0(param_1 + 0x10,(longlong)iVar3);
      uVar11 = 0;
      plVar4 = plVar13;
      plVar8 = plVar13;
      plVar9 = plVar13;
      if (0 < (int)((param_1[0x14] - param_1[0x13]) / 0x30)) {
        do {
          iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x20))();
          if ((ulonglong)((param_1[0x14] - param_1[0x13]) / 0x30) <=
              (ulonglong)(longlong)(int)plVar4) {
            _invalid_parameter_noinfo();
          }
          FUN_1402cf4d0((longlong)(int)plVar4 * 0x30 + param_1[0x13],(longlong)iVar3,0);
          plVar4 = plVar13;
          plVar12 = plVar13;
          while( true ) {
            if ((longlong *)((param_1[0x14] - param_1[0x13]) / 0x30) <= plVar9) {
              _invalid_parameter_noinfo();
            }
            lVar7 = param_1[0x13];
            if ((int)(*(longlong *)((longlong)plVar8 + lVar7 + 0x20) -
                      *(longlong *)((longlong)plVar8 + lVar7 + 0x18) >> 2) <= (int)plVar12) break;
            if ((longlong *)((param_1[0x14] - lVar7) / 0x30) <= plVar9) {
              _invalid_parameter_noinfo();
            }
            lVar7 = param_1[0x13];
            if ((longlong *)
                (*(longlong *)((longlong)plVar8 + lVar7 + 0x20) -
                 *(longlong *)((longlong)plVar8 + lVar7 + 0x18) >> 2) <= plVar4) {
              _invalid_parameter_noinfo();
            }
            *(undefined4 *)(*(longlong *)((longlong)plVar8 + lVar7 + 0x18) + (longlong)plVar4 * 4) =
                 0;
            plVar12 = (longlong *)(ulonglong)((int)plVar12 + 1);
            plVar4 = (longlong *)((longlong)plVar4 + 1);
          }
          uVar11 = uVar11 + 1;
          plVar4 = (longlong *)(ulonglong)uVar11;
          plVar8 = plVar8 + 6;
          plVar9 = (longlong *)((longlong)plVar9 + 1);
        } while ((int)uVar11 < (int)((param_1[0x14] - lVar7) / 0x30));
      }
      iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x28))();
      FUN_1402d4710(param_1 + 3,(longlong)((iVar3 + -1) / 0x12 + 1));
      uVar11 = 0;
      plVar4 = plVar13;
      plVar8 = plVar13;
      plVar9 = plVar13;
      if (0 < (int)((param_1[7] - param_1[6]) / 0x30)) {
        do {
          iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x20))();
          if ((ulonglong)((param_1[7] - param_1[6]) / 0x30) <= (ulonglong)(longlong)(int)plVar8) {
            _invalid_parameter_noinfo();
          }
          lVar7 = param_1[6];
          uVar5 = FUN_1404721a0(local_58);
          FUN_1402cf320((longlong)(int)plVar8 * 0x30 + lVar7,(longlong)((iVar3 + -1) / 0x12 + 1),
                        uVar5);
          plVar8 = plVar13;
          while( true ) {
            if ((longlong *)((param_1[7] - param_1[6]) / 0x30) <= plVar9) {
              _invalid_parameter_noinfo();
            }
            iVar3 = (int)plVar8;
            if ((int)((*(longlong *)((longlong)plVar4 + param_1[6] + 0x20) -
                      *(longlong *)((longlong)plVar4 + param_1[6] + 0x18)) / 0x18) <= iVar3) break;
            if ((longlong *)((param_1[7] - param_1[6]) / 0x30) <= plVar9) {
              _invalid_parameter_noinfo();
            }
            lVar7 = param_1[6];
            if ((ulonglong)
                ((*(longlong *)((longlong)plVar4 + lVar7 + 0x20) -
                 *(longlong *)((longlong)plVar4 + lVar7 + 0x18)) / 0x18) <=
                (ulonglong)(longlong)iVar3) {
              _invalid_parameter_noinfo();
            }
            FUN_140472c00(*(longlong *)((longlong)plVar4 + lVar7 + 0x18) + (longlong)iVar3 * 0x18);
            plVar8 = (longlong *)(ulonglong)(iVar3 + 1);
          }
          uVar11 = uVar11 + 1;
          plVar4 = plVar4 + 6;
          plVar8 = (longlong *)(ulonglong)uVar11;
          plVar9 = (longlong *)((longlong)plVar9 + 1);
        } while ((int)uVar11 < (int)((param_1[7] - param_1[6]) / 0x30));
      }
      uVar2 = (**(code **)(*(longlong *)param_1[0xb] + 8))();
      cVar1 = FUN_1402cf060(param_1,uVar2);
      if (cVar1 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar5 = 0;
      }
      else {
        pvVar6 = operator_new(0x40);
        plVar4 = plVar13;
        if (pvVar6 != (void *)0x0) {
          plVar4 = (longlong *)FUN_1402cc100(pvVar6,1);
        }
        param_1[10] = (longlong)plVar4;
        if (plVar4 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar5 = 0;
        }
        else {
          lVar7 = (**(code **)(*(longlong *)param_1[9] + 0x18))();
          plVar4 = plVar13;
          if (lVar7 != 0) {
            do {
              plVar8 = (longlong *)
                       (**(code **)(*(longlong *)param_1[9] + 0x20))((longlong *)param_1[9],plVar4);
              if ((plVar8 != (longlong *)0x0) &&
                 (iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,2), iVar3 == 2)) {
                lVar7 = FUN_140471bb0(0x20);
                plVar9 = plVar13;
                if (lVar7 != 0) {
                  plVar9 = (longlong *)FUN_140471cd0(lVar7);
                }
                if (plVar9 == (longlong *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                  return 0;
                }
                cVar1 = FUN_1404719f0(plVar9,plVar8,param_2);
                if (cVar1 == '\0') {
                  log_InlineLogERROR(&DAT_1406d9c10);
                  (**(code **)(*plVar9 + 8))(plVar9,1);
                }
                else {
                  (**(code **)(*(longlong *)param_1[10] + 0x20))((longlong *)param_1[10],plVar9);
                }
              }
              plVar4 = (longlong *)((longlong)plVar4 + 1);
              plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[9] + 0x18))();
            } while (plVar4 < plVar8);
          }
          iVar3 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0x15);
          *(int *)(param_1 + 2) = iVar3;
          if (iVar3 == 0) {
            *(undefined4 *)(param_1 + 2) = 0xffffffff;
          }
          plVar4 = (longlong *)
                   (**(code **)(**(longlong **)(param_1[0xb] + 8) + 0x10))
                             (*(longlong **)(param_1[0xb] + 8),4);
          uVar10 = (**(code **)(*plVar4 + 0x58))(plVar4);
          if ((uVar10 >> 0x17 & 1) != 0) {
            uVar2 = (**(code **)(*param_1 + 8))(param_1);
            lVar7 = FUN_140399850(uVar2,param_2);
            param_1[0xd] = lVar7;
            if (lVar7 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              return 0;
            }
            FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
            uVar5 = InstanceGet();
            cVar1 = FUN_140395600(param_1[0xd],uVar5);
            if (cVar1 == '\0') {
              FUN_140398c60(param_1[0xd]);
              param_1[0xd] = 0;
              (**(code **)(*param_1 + 8))(param_1);
              log_InlineLogERROR("create Quarter Finals manager failed, mapid[%u]");
            }
          }
          uVar2 = (**(code **)(*param_1 + 8))(param_1);
          *(undefined4 *)(param_1 + 0xe) = uVar2;
          uVar5 = 1;
        }
      }
    }
  }
  return uVar5;
}

// ==== CMapManager::helper_1402d4fe0  @1402d4fe0  [medium:callgraph-r0]  (orig: FUN_1402d4fe0)
int FUN_1402d4fe0(longlong param_1,undefined4 param_2,longlong param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  void *pvVar8;
  longlong *plVar9;
  longlong *plVar10;
  uint uVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 local_68 [40];
  
  *(undefined4 *)(param_1 + 0x74) = param_2;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = 0;
  }
  else {
    lVar5 = FUN_140008520(param_2);
    if (*(longlong *)(lVar5 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar6 = (longlong *)(**(code **)(**(longlong **)(lVar5 + 0x98) + 0xb0))();
    lVar5 = (**(code **)(*plVar6 + 0x38))(plVar6,*(undefined4 *)(param_3 + 0x50));
    if (lVar5 == 0) {
      log_InlineLogWARNING(&DAT_140745970);
    }
    plVar6 = operator_new(0x18);
    if (plVar6 == (longlong *)0x0) {
      plVar6 = (longlong *)0x0;
    }
    else {
      *plVar6 = (longlong)IGameData::vftable;
      *plVar6 = (longlong)CGameData<&char*_szMapTable,&char*_szID>::vftable;
      *(undefined1 *)(plVar6 + 2) = 0;
      plVar6[1] = 0;
    }
    plVar13 = (longlong *)0x0;
    *(longlong **)(param_1 + 0x58) = plVar6;
    if (plVar6 == (longlong *)0x0) {
      iVar2 = 0;
    }
    else {
      cVar1 = (**(code **)(*plVar6 + 0x38))(plVar6,"cq_dynamap");
      if (cVar1 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x58))();
        *(undefined8 *)(param_1 + 0x58) = 0;
        iVar2 = 0;
      }
      else {
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x68))
                  (*(longlong **)(param_1 + 0x58),1,param_3);
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x10,*(undefined4 *)(param_3 + 0x30));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),5,*(undefined4 *)(param_3 + 0x34));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),3,*(undefined4 *)(param_3 + 0x24));
        uVar7 = *(undefined8 *)(param_3 + 0x28);
        plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
        (**(code **)(*plVar6 + 0xa0))(plVar6,uVar7);
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),6,*(undefined4 *)(param_3 + 0x38));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x11,*(undefined4 *)(param_3 + 0x3c));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x12,*(undefined4 *)(param_3 + 0x40));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x13,*(undefined4 *)(param_3 + 0x44));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xb,*(undefined4 *)(param_3 + 0x48));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xc,*(undefined4 *)(param_3 + 0x4c));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xd,*(undefined4 *)(param_3 + 0x50));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xe,*(undefined4 *)(param_3 + 0x54));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xf,*(undefined4 *)(param_3 + 0x58));
        iVar2 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x50))();
        if (iVar2 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          iVar2 = 0;
        }
        else {
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),3);
          log_InlineLogMessage(&DAT_140745948);
          uVar3 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))
                            (*(longlong **)(param_1 + 0x58),3);
          plVar6 = (longlong *)FUN_1405090c0(uVar3,0);
          *(longlong **)(param_1 + 0x60) = plVar6;
          if (plVar6 == (longlong *)0x0) {
            (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),3);
            log_InlineLogERROR(&DAT_140745928);
            iVar2 = 0;
          }
          else {
            iVar4 = (**(code **)(*plVar6 + 0x28))(plVar6);
            FUN_1402d47a0(param_1 + 0x80,(longlong)iVar4);
            uVar11 = 0;
            plVar6 = plVar13;
            plVar9 = plVar13;
            plVar10 = plVar13;
            if (0 < (int)((*(longlong *)(param_1 + 0xa0) - *(longlong *)(param_1 + 0x98)) / 0x30)) {
              do {
                iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
                uVar7 = FUN_1402c4580(param_1 + 0x80,(longlong)(int)plVar6);
                FUN_1402cf4d0(uVar7,(longlong)iVar4,0);
                plVar6 = plVar13;
                plVar12 = plVar13;
                while( true ) {
                  if ((longlong *)
                      ((*(longlong *)(param_1 + 0xa0) - *(longlong *)(param_1 + 0x98)) / 0x30) <=
                      plVar10) {
                    _invalid_parameter_noinfo();
                  }
                  lVar5 = *(longlong *)(param_1 + 0x98);
                  if ((int)(*(longlong *)((longlong)plVar9 + lVar5 + 0x20) -
                            *(longlong *)((longlong)plVar9 + lVar5 + 0x18) >> 2) <= (int)plVar12)
                  break;
                  if ((longlong *)((*(longlong *)(param_1 + 0xa0) - lVar5) / 0x30) <= plVar10) {
                    _invalid_parameter_noinfo();
                  }
                  lVar5 = *(longlong *)(param_1 + 0x98);
                  if ((longlong *)
                      (*(longlong *)((longlong)plVar9 + lVar5 + 0x20) -
                       *(longlong *)((longlong)plVar9 + lVar5 + 0x18) >> 2) <= plVar6) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined4 *)
                   (*(longlong *)((longlong)plVar9 + lVar5 + 0x18) + (longlong)plVar6 * 4) = 0;
                  plVar12 = (longlong *)(ulonglong)((int)plVar12 + 1);
                  plVar6 = (longlong *)((longlong)plVar6 + 1);
                }
                uVar11 = uVar11 + 1;
                plVar6 = (longlong *)(ulonglong)uVar11;
                plVar9 = plVar9 + 6;
                plVar10 = (longlong *)((longlong)plVar10 + 1);
              } while ((int)uVar11 < (int)((*(longlong *)(param_1 + 0xa0) - lVar5) / 0x30));
            }
            iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
            FUN_1402d4710(param_1 + 0x18,(longlong)((iVar4 + -1) / 0x12 + 1));
            uVar11 = 0;
            plVar6 = plVar13;
            plVar9 = plVar13;
            plVar10 = plVar13;
            if (0 < (int)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30)) {
              do {
                iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
                if ((ulonglong)
                    ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                    (ulonglong)(longlong)(int)plVar6) {
                  _invalid_parameter_noinfo();
                }
                lVar5 = *(longlong *)(param_1 + 0x30);
                uVar7 = FUN_1404721a0(local_68);
                FUN_1402cf320((longlong)(int)plVar6 * 0x30 + lVar5,
                              (longlong)((iVar4 + -1) / 0x12 + 1),uVar7);
                plVar6 = plVar13;
                while( true ) {
                  if ((longlong *)
                      ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                      plVar10) {
                    _invalid_parameter_noinfo();
                  }
                  iVar4 = (int)plVar6;
                  if ((int)((*(longlong *)((longlong)plVar9 + *(longlong *)(param_1 + 0x30) + 0x20)
                            - *(longlong *)((longlong)plVar9 + *(longlong *)(param_1 + 0x30) + 0x18)
                            ) / 0x18) <= iVar4) break;
                  if ((longlong *)
                      ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                      plVar10) {
                    _invalid_parameter_noinfo();
                  }
                  lVar5 = *(longlong *)(param_1 + 0x30);
                  if ((ulonglong)
                      ((*(longlong *)((longlong)plVar9 + lVar5 + 0x20) -
                       *(longlong *)((longlong)plVar9 + lVar5 + 0x18)) / 0x18) <=
                      (ulonglong)(longlong)iVar4) {
                    _invalid_parameter_noinfo();
                  }
                  FUN_140472c00(*(longlong *)((longlong)plVar9 + lVar5 + 0x18) +
                                (longlong)iVar4 * 0x18);
                  plVar6 = (longlong *)(ulonglong)(iVar4 + 1);
                }
                uVar11 = uVar11 + 1;
                plVar6 = (longlong *)(ulonglong)uVar11;
                plVar9 = plVar9 + 6;
                plVar10 = (longlong *)((longlong)plVar10 + 1);
              } while ((int)uVar11 <
                       (int)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30)
                      );
            }
            uVar3 = (**(code **)(**(longlong **)(param_1 + 0x58) + 8))();
            cVar1 = FUN_1402cf060(param_1,uVar3);
            if (cVar1 == '\0') {
              log_InlineLogERROR(&DAT_1406d9c10);
              iVar2 = 0;
            }
            else {
              pvVar8 = operator_new(0x40);
              plVar6 = plVar13;
              if (pvVar8 != (void *)0x0) {
                plVar6 = (longlong *)FUN_1402cc100(pvVar8,1);
              }
              *(longlong **)(param_1 + 0x50) = plVar6;
              if (plVar6 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                iVar2 = 0;
              }
              else {
                lVar5 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x18))();
                plVar6 = plVar13;
                if (lVar5 != 0) {
                  do {
                    plVar9 = (longlong *)
                             (**(code **)(**(longlong **)(param_1 + 0x48) + 0x20))
                                       (*(longlong **)(param_1 + 0x48),plVar6);
                    if ((plVar9 != (longlong *)0x0) &&
                       (iVar4 = (**(code **)(*plVar9 + 0x10))(plVar9,2), iVar4 == 2)) {
                      lVar5 = FUN_140471bb0(0x20);
                      plVar10 = plVar13;
                      if (lVar5 != 0) {
                        plVar10 = (longlong *)FUN_140471cd0(lVar5);
                      }
                      if (plVar10 == (longlong *)0x0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        return 0;
                      }
                      cVar1 = FUN_1404719f0(plVar10,plVar9,param_2);
                      if (cVar1 == '\0') {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        (**(code **)(*plVar10 + 8))(plVar10,1);
                      }
                      else {
                        (**(code **)(**(longlong **)(param_1 + 0x50) + 0x20))
                                  (*(longlong **)(param_1 + 0x50),plVar10);
                      }
                    }
                    plVar6 = (longlong *)((longlong)plVar6 + 1);
                    plVar9 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x48) + 0x18))();
                  } while (plVar6 < plVar9);
                }
                *(int *)(param_1 + 0x70) = iVar2;
              }
            }
          }
        }
      }
    }
  }
  return iVar2;
}

// ==== CMapManager::helper_1402d5850  @1402d5850  [medium:callgraph-r0]  (orig: FUN_1402d5850)
undefined8
FUN_1402d5850(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
             undefined4 param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 uVar5;
  void *pvVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint uVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined1 local_58 [32];
  
  *(undefined4 *)(param_1 + 0x74) = param_2;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    plVar4 = operator_new(0x18);
    if (plVar4 == (longlong *)0x0) {
      plVar4 = (longlong *)0x0;
    }
    else {
      *plVar4 = (longlong)IGameData::vftable;
      *plVar4 = (longlong)CGameData<&char*_szMapTable,&char*_szID>::vftable;
      *(undefined1 *)(plVar4 + 2) = 0;
      plVar4[1] = 0;
    }
    plVar12 = (longlong *)0x0;
    *(longlong **)(param_1 + 0x58) = plVar4;
    if (plVar4 == (longlong *)0x0) {
      uVar5 = 0;
    }
    else {
      cVar1 = (**(code **)(*plVar4 + 0x38))(plVar4,"cq_dynamap");
      if (cVar1 == '\0') {
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x58))();
        *(undefined8 *)(param_1 + 0x58) = 0;
        uVar5 = 0;
      }
      else {
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0,param_4);
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x68))
                  (*(longlong **)(param_1 + 0x58),1,param_3);
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x10,*(undefined4 *)(param_3 + 0x30));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),5,*(undefined4 *)(param_3 + 0x34));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),3,*(undefined4 *)(param_3 + 0x24));
        uVar5 = *(undefined8 *)(param_3 + 0x28);
        plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
        (**(code **)(*plVar4 + 0xa0))(plVar4,uVar5);
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),6,*(undefined4 *)(param_3 + 0x38));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x11,*(undefined4 *)(param_3 + 0x3c));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x12,*(undefined4 *)(param_3 + 0x40));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0x13,*(undefined4 *)(param_3 + 0x44));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xb,*(undefined4 *)(param_3 + 0x48));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xc,*(undefined4 *)(param_3 + 0x4c));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xd,*(undefined4 *)(param_3 + 0x50));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xe,*(undefined4 *)(param_3 + 0x54));
        (**(code **)(**(longlong **)(param_1 + 0x58) + 0x60))
                  (*(longlong **)(param_1 + 0x58),0xf,*(undefined4 *)(param_3 + 0x58));
        uVar2 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))
                          (*(longlong **)(param_1 + 0x58),3);
        plVar4 = (longlong *)FUN_1405090c0(uVar2,0);
        *(longlong **)(param_1 + 0x60) = plVar4;
        if (plVar4 == (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0x58) + 0x10))(*(longlong **)(param_1 + 0x58),3);
          log_InlineLogERROR("Fail to load dynamic map file [%d]!");
          uVar5 = 0;
        }
        else {
          iVar3 = (**(code **)(*plVar4 + 0x28))(plVar4);
          FUN_1402d47a0(param_1 + 0x80,(longlong)iVar3);
          uVar10 = 0;
          plVar4 = plVar12;
          plVar8 = plVar12;
          plVar9 = plVar12;
          if (0 < (int)((*(longlong *)(param_1 + 0xa0) - *(longlong *)(param_1 + 0x98)) / 0x30)) {
            do {
              iVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
              if ((ulonglong)
                  ((*(longlong *)(param_1 + 0xa0) - *(longlong *)(param_1 + 0x98)) / 0x30) <=
                  (ulonglong)(longlong)(int)plVar4) {
                _invalid_parameter_noinfo();
              }
              FUN_1402cf4d0((longlong)(int)plVar4 * 0x30 + *(longlong *)(param_1 + 0x98),
                            (longlong)iVar3,0);
              plVar4 = plVar12;
              plVar11 = plVar12;
              while( true ) {
                if ((longlong *)
                    ((*(longlong *)(param_1 + 0xa0) - *(longlong *)(param_1 + 0x98)) / 0x30) <=
                    plVar9) {
                  _invalid_parameter_noinfo();
                }
                lVar7 = *(longlong *)(param_1 + 0x98);
                if ((int)(*(longlong *)((longlong)plVar8 + lVar7 + 0x20) -
                          *(longlong *)((longlong)plVar8 + lVar7 + 0x18) >> 2) <= (int)plVar11)
                break;
                if ((longlong *)((*(longlong *)(param_1 + 0xa0) - lVar7) / 0x30) <= plVar9) {
                  _invalid_parameter_noinfo();
                }
                lVar7 = *(longlong *)(param_1 + 0x98);
                if ((longlong *)
                    (*(longlong *)((longlong)plVar8 + lVar7 + 0x20) -
                     *(longlong *)((longlong)plVar8 + lVar7 + 0x18) >> 2) <= plVar4) {
                  _invalid_parameter_noinfo();
                }
                *(undefined4 *)
                 (*(longlong *)((longlong)plVar8 + lVar7 + 0x18) + (longlong)plVar4 * 4) = 0;
                plVar11 = (longlong *)(ulonglong)((int)plVar11 + 1);
                plVar4 = (longlong *)((longlong)plVar4 + 1);
              }
              uVar10 = uVar10 + 1;
              plVar4 = (longlong *)(ulonglong)uVar10;
              plVar8 = plVar8 + 6;
              plVar9 = (longlong *)((longlong)plVar9 + 1);
            } while ((int)uVar10 < (int)((*(longlong *)(param_1 + 0xa0) - lVar7) / 0x30));
          }
          iVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
          FUN_1402d4710(param_1 + 0x18,(longlong)((iVar3 + -1) / 0x12 + 1));
          uVar10 = 0;
          plVar4 = plVar12;
          plVar8 = plVar12;
          plVar9 = plVar12;
          if (0 < (int)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30)) {
            do {
              iVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
              if ((ulonglong)
                  ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                  (ulonglong)(longlong)(int)plVar4) {
                _invalid_parameter_noinfo();
              }
              lVar7 = *(longlong *)(param_1 + 0x30);
              uVar5 = FUN_1404721a0(local_58);
              FUN_1402cf320((longlong)(int)plVar4 * 0x30 + lVar7,(longlong)((iVar3 + -1) / 0x12 + 1)
                            ,uVar5);
              plVar4 = plVar12;
              while( true ) {
                if ((longlong *)
                    ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                    plVar9) {
                  _invalid_parameter_noinfo();
                }
                iVar3 = (int)plVar4;
                if ((int)((*(longlong *)((longlong)plVar8 + *(longlong *)(param_1 + 0x30) + 0x20) -
                          *(longlong *)((longlong)plVar8 + *(longlong *)(param_1 + 0x30) + 0x18)) /
                         0x18) <= iVar3) break;
                if ((longlong *)
                    ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
                    plVar9) {
                  _invalid_parameter_noinfo();
                }
                lVar7 = *(longlong *)(param_1 + 0x30);
                if ((ulonglong)
                    ((*(longlong *)((longlong)plVar8 + lVar7 + 0x20) -
                     *(longlong *)((longlong)plVar8 + lVar7 + 0x18)) / 0x18) <=
                    (ulonglong)(longlong)iVar3) {
                  _invalid_parameter_noinfo();
                }
                FUN_140472c00(*(longlong *)((longlong)plVar8 + lVar7 + 0x18) +
                              (longlong)iVar3 * 0x18);
                plVar4 = (longlong *)(ulonglong)(iVar3 + 1);
              }
              uVar10 = uVar10 + 1;
              plVar4 = (longlong *)(ulonglong)uVar10;
              plVar8 = plVar8 + 6;
              plVar9 = (longlong *)((longlong)plVar9 + 1);
            } while ((int)uVar10 <
                     (int)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30));
          }
          cVar1 = FUN_1402cf060(param_1,param_5);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar5 = 0;
          }
          else {
            pvVar6 = operator_new(0x40);
            plVar4 = plVar12;
            if (pvVar6 != (void *)0x0) {
              plVar4 = (longlong *)FUN_1402cc100(pvVar6,1);
            }
            *(longlong **)(param_1 + 0x50) = plVar4;
            if (plVar4 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar5 = 0;
            }
            else {
              lVar7 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x18))();
              plVar4 = plVar12;
              if (lVar7 != 0) {
                do {
                  plVar8 = (longlong *)
                           (**(code **)(**(longlong **)(param_1 + 0x48) + 0x20))
                                     (*(longlong **)(param_1 + 0x48),plVar4);
                  if ((plVar8 != (longlong *)0x0) &&
                     (iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,2), iVar3 == 2)) {
                    lVar7 = FUN_140471bb0(0x20);
                    plVar9 = plVar12;
                    if (lVar7 != 0) {
                      plVar9 = (longlong *)FUN_140471cd0(lVar7);
                    }
                    if (plVar9 == (longlong *)0x0) {
                      log_InlineLogERROR(&DAT_1406d9c10);
                      return 0;
                    }
                    cVar1 = FUN_1404719f0(plVar9,plVar8,param_2);
                    if (cVar1 == '\0') {
                      log_InlineLogERROR(&DAT_1406d9c10);
                      (**(code **)(*plVar9 + 8))(plVar9,1);
                    }
                    else {
                      (**(code **)(**(longlong **)(param_1 + 0x50) + 0x20))
                                (*(longlong **)(param_1 + 0x50),plVar9);
                    }
                  }
                  plVar4 = (longlong *)((longlong)plVar4 + 1);
                  plVar8 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x48) + 0x18))();
                } while (plVar4 < plVar8);
              }
              *(undefined4 *)(param_1 + 0x70) = param_5;
              uVar5 = 1;
            }
          }
        }
      }
    }
  }
  return uVar5;
}

// ==== CMapManager::helper_1402fc1d0  @1402fc1d0  [medium:callgraph-r0]  (orig: FUN_1402fc1d0)
undefined8 FUN_1402fc1d0(void)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_1402c5ae0(0xb0);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1402d4430(lVar1);
  }
  return uVar2;
}

// ==== CMapManager::vfunc_1  @1402fceb0  [high:rtti-vtable]  (orig: FUN_1402fceb0)
void FUN_1402fceb0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapManager::vfunc_11  @1402fced0  [high:rtti-vtable]  (orig: FUN_1402fced0)
undefined4 FUN_1402fced0(longlong param_1)

{
  *(int *)(param_1 + 0x428) = *(int *)(param_1 + 0x428) + 1;
  if (0xef27894e < *(uint *)(param_1 + 0x428)) {
    log_InlineLogERROR(&DAT_14074b358);
    *(undefined4 *)(param_1 + 0x428) = 1;
    return *(undefined4 *)(param_1 + 0x428);
  }
  return *(undefined4 *)(param_1 + 0x428);
}

// ==== CMapManager::vfunc_7  @1402fcf30  [high:rtti-vtable]  (orig: FUN_1402fcf30)
int FUN_1402fcf30(undefined8 param_1,int param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  
  uVar5 = 0;
  lVar2 = (**(code **)(*DAT_140975b78 + 0x18))();
  if (lVar2 != 0) {
    do {
      plVar3 = (longlong *)(**(code **)(*DAT_140975b78 + 0x20))(DAT_140975b78,uVar5);
      if ((plVar3 != (longlong *)0x0) &&
         (iVar1 = (**(code **)(*plVar3 + 8))(plVar3), iVar1 == param_2)) {
        iVar1 = (**(code **)(*plVar3 + 0x10))(plVar3,6);
        return iVar1 + 0xe;
      }
      uVar5 = uVar5 + 1;
      uVar4 = (**(code **)(*DAT_140975b78 + 0x18))();
    } while (uVar5 < uVar4);
  }
  return -1;
}

// ==== CMapManager::vfunc_13  @1402fcfd0  [high:rtti-vtable]  (orig: FUN_1402fcfd0)
undefined8 FUN_1402fcfd0(longlong param_1,undefined4 *param_2,int param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  
  if (*(longlong *)(param_1 + 0x400) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((param_3 != 0) && (param_2 != (undefined4 *)0x0)) {
    uVar6 = 0;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x400) + 0x18))();
    if (lVar3 != 0) {
      do {
        plVar4 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x400) + 0x20))
                           (*(longlong **)(param_1 + 0x400),uVar6);
        if (((plVar4 != (longlong *)0x0) &&
            (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,1), iVar1 == param_3)) &&
           (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,2), iVar1 == param_4)) {
          uVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,3);
          *param_2 = uVar2;
          uVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,4);
          param_2[1] = uVar2;
          return 1;
        }
        uVar6 = uVar6 + 1;
        uVar5 = (**(code **)(**(longlong **)(param_1 + 0x400) + 0x18))();
      } while (uVar6 < uVar5);
    }
    return 0;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapManager::vfunc_14  @1402fd140  [high:rtti-vtable]  (orig: FUN_1402fd140)
undefined8
FUN_1402fd140(longlong param_1,undefined4 *param_2,undefined4 *param_3,int param_4,int param_5)

{
  int iVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  
  if (*(longlong *)(param_1 + 0x408) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (((param_4 != 0) && (param_2 != (undefined4 *)0x0)) && (param_3 != (undefined4 *)0x0)) {
    uVar6 = 0;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x408) + 0x18))();
    if (lVar3 != 0) {
      do {
        plVar4 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x408) + 0x20))
                           (*(longlong **)(param_1 + 0x408),uVar6);
        if (((plVar4 != (longlong *)0x0) &&
            (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,1), iVar1 == param_4)) &&
           (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,2), iVar1 == param_5)) {
          uVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,3);
          *param_2 = uVar2;
          uVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,4);
          *param_3 = uVar2;
          return 1;
        }
        uVar6 = uVar6 + 1;
        uVar5 = (**(code **)(**(longlong **)(param_1 + 0x408) + 0x18))();
      } while (uVar6 < uVar5);
    }
    return 0;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapManager::vfunc_15  @1402fd2d0  [high:rtti-vtable]  (orig: FUN_1402fd2d0)
int FUN_1402fd2d0(longlong param_1,undefined8 param_2)

{
  int iVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  lVar2 = FUN_1402c5ae0(0xb0);
  if (lVar2 == 0) {
    puVar3 = (undefined8 *)0x0;
  }
  else {
    puVar3 = (undefined8 *)FUN_1402d4430(lVar2);
  }
  if (puVar3 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar1 = 0;
  }
  else {
    iVar1 = FUN_1402d4fe0(puVar3,*(undefined4 *)(param_1 + 0x3b0),param_2);
    if (iVar1 == 0) {
      (**(code **)*puVar3)(puVar3,1);
      iVar1 = 0;
    }
    else {
      (**(code **)(**(longlong **)(param_1 + 0x3f8) + 0x28))(*(longlong **)(param_1 + 0x3f8),puVar3)
      ;
    }
  }
  return iVar1;
}

// ==== CMapManager::vfunc_12  @1402fd390  [high:rtti-vtable]  (orig: FUN_1402fd390)
undefined8 FUN_1402fd390(longlong param_1,int param_2)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x438) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_2 == 0) {
    log_InlineLogERROR("CMapManager::GetTerrainObjFileName idTerrainObj is 0.");
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402fd3f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x438) + 8))();
  return uVar1;
}

// ==== CMapManager::helper_1402fe020  @1402fe020  [medium:callgraph-r1]  (orig: FUN_1402fe020)
longlong FUN_1402fe020(longlong *param_1)

{
  ulonglong uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  uVar1 = param_1[1];
  plVar2 = (longlong *)*param_1;
  lVar5 = 0;
  uVar6 = uVar1 >> 2;
  lVar3 = lVar5;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar2 = (longlong *)*param_1;
    lVar4 = lVar5;
    if (plVar2 == (longlong *)0x0) goto LAB_1402fe070;
  }
  lVar4 = *plVar2;
  if (plVar2 != (longlong *)0x0) {
    lVar3 = lVar4;
  }
LAB_1402fe070:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar4 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = lVar5;
  if (param_1 != (longlong *)0x0) {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x28) <= uVar6) {
    lVar3 = lVar5;
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    uVar6 = uVar6 - *(longlong *)(lVar3 + 0x28);
  }
  if (param_1 != (longlong *)0x0) {
    lVar5 = *param_1;
  }
  return *(longlong *)(*(longlong *)(lVar5 + 0x20) + uVar6 * 8) + (ulonglong)((uint)uVar1 & 3) * 4;
}

// ==== CMapManager::helper_1402fe8e0  @1402fe8e0  [medium:callgraph-r0]  (orig: FUN_1402fe8e0)
void FUN_1402fe8e0(void *param_1)

{
  if ((DAT_140975fd8 & 1) == 0) {
    DAT_140975fd8 = DAT_140975fd8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975fd0,"CMapManager");
    atexit((_func_5014 *)&LAB_1406d6a30);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402fe935. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975fd0,param_1);
  return;
}

// ==== CMapManager::vfunc_4  @1402fe9a0  [high:rtti-vtable]  (orig: FUN_1402fe9a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 * FUN_1402fe9a0(longlong *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 uVar9;
  int iVar10;
  int iVar11;
  undefined1 auStack_478 [32];
  int local_458;
  undefined8 local_448;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  puVar5 = (undefined8 *)(**(code **)(*(longlong *)param_1[0x7f] + 0x40))();
  if (puVar5 == (undefined8 *)0x0) {
    if (param_3 == 0) {
      puVar5 = (undefined8 *)0x0;
    }
    else {
      cVar1 = (**(code **)(*param_1 + 0x128))(param_1);
      if (cVar1 == '\0') {
        puVar5 = (undefined8 *)0x0;
      }
      else {
        local_438 = '\0';
        memset(local_437,0,0x3ff);
        lVar6 = FUN_140008520((int)param_1[0x76]);
        local_458 = *(int *)(lVar6 + 0x68) + -0xe;
        _snprintf(&local_438,0x3ff,
                  "SELECT * FROM cq_dynamap WHERE id=%u && mapgroup=%u && del_flag=0 LIMIT 1");
        FUN_140008520((int)param_1[0x76]);
        plVar7 = (longlong *)InstanceGet();
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,&local_438,2);
        if ((plVar7 != (longlong *)0x0) &&
           (lVar6 = (**(code **)(*plVar7 + 0x40))(plVar7), lVar6 != 0)) {
          puVar5 = (undefined8 *)FUN_1402fc1d0();
          if (puVar5 == (undefined8 *)0x0) {
            (**(code **)*plVar7)(plVar7);
            return (undefined8 *)0x0;
          }
          cVar1 = FUN_1402d4860(puVar5,(int)param_1[0x76],plVar7);
          if (cVar1 == '\0') {
            (**(code **)*puVar5)(puVar5,1);
            (**(code **)*plVar7)(plVar7);
            return (undefined8 *)0x0;
          }
          (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar5);
          (**(code **)*plVar7)(plVar7);
          _snprintf(&local_438,0x3ff,"SELECT * FROM cq_dynanpc WHERE mapid=%u");
          FUN_140008520((int)param_1[0x76]);
          plVar7 = (longlong *)InstanceGet();
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,&local_438,2);
          if (plVar7 == (longlong *)0x0) {
            local_458 = 0x20c;
            log_InlineLogERROR(&DAT_1406d9c10);
            return (undefined8 *)0x0;
          }
          iVar10 = 0;
          iVar11 = 0;
          iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
          if (0 < iVar2) {
            do {
              (**(code **)(*plVar7 + 0x30))(plVar7,(longlong)iVar11);
              lVar6 = FUN_1402c0d80();
              if (lVar6 == 0) {
                local_458 = 0x210;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                cVar1 = FUN_1402c29d0(lVar6,(int)param_1[0x76],plVar7,1);
                if (cVar1 == '\0') {
                  local_458 = 0x212;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  (**(code **)(*(longlong *)(lVar6 + 0x10) + 8))();
                }
                else {
                  uVar9 = FUN_140008520((int)param_1[0x76]);
                  plVar8 = (longlong *)FUN_1400875f0(uVar9);
                  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x30))(plVar8);
                  (**(code **)(*plVar8 + 0x28))(plVar8,lVar6 + 0x10);
                }
              }
              iVar11 = iVar11 + 1;
              iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
            } while (iVar11 < iVar2);
          }
          (**(code **)*plVar7)(plVar7);
          _snprintf(&local_438,0x3ff,"SELECT * FROM cq_pet WHERE recordmap_id=%u");
          FUN_140008520((int)param_1[0x76]);
          plVar7 = (longlong *)InstanceGet();
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,&local_438,2);
          if (plVar7 == (longlong *)0x0) {
            local_458 = 0x21d;
            log_InlineLogERROR(&DAT_1406d9c10);
            return (undefined8 *)0x0;
          }
          iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
          if (0 < iVar2) {
            do {
              (**(code **)(*plVar7 + 0x30))(plVar7,(longlong)iVar10);
              lVar6 = FUN_140391b90();
              if (lVar6 == 0) {
                local_458 = 0x221;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                cVar1 = FUN_14038fa90(lVar6,(int)param_1[0x76],plVar7);
                if (cVar1 == '\0') {
                  local_458 = 0x223;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  (**(code **)(*(longlong *)(lVar6 + 0x10) + 8))();
                }
                else {
                  uVar9 = FUN_140008520((int)param_1[0x76]);
                  plVar8 = (longlong *)FUN_1400875f0(uVar9);
                  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x30))(plVar8);
                  (**(code **)(*plVar8 + 0x28))(plVar8,lVar6 + 0x10);
                  FUN_14038b420(lVar6);
                }
              }
              iVar10 = iVar10 + 1;
              iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
            } while (iVar10 < iVar2);
          }
          (**(code **)*plVar7)(plVar7);
          uVar3 = (**(code **)(*(longlong *)puVar5[0xc] + 0x28))();
          uVar4 = (**(code **)(*(longlong *)puVar5[0xc] + 0x20))();
          uVar9 = FUN_140008520((int)param_1[0x76]);
          FUN_14008a8d0(uVar9,param_2,uVar4,uVar3);
          return puVar5;
        }
        log_InlineLogWARNING(&DAT_14074b820);
        if (plVar7 != (longlong *)0x0) {
          (**(code **)*plVar7)(plVar7);
        }
        puVar5 = (undefined8 *)0x0;
      }
    }
  }
  return puVar5;
}

// ==== CMapManager::vfunc_19  @1402fee80  [high:rtti-vtable]  (orig: FUN_1402fee80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_1402fee80(longlong *param_1,undefined8 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  char *_Source;
  undefined8 *puVar7;
  undefined8 uVar8;
  undefined1 auStack_d8 [32];
  undefined4 local_b8;
  longlong local_a8;
  undefined8 local_a0;
  char local_98 [36];
  undefined4 local_74;
  undefined8 local_70;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  ulonglong local_38;
  
  local_a0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_d8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,param_2,1);
  if (lVar5 == 0) {
    local_b8 = 0x318;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    uVar2 = (**(code **)(*param_1 + 0x140))(param_1);
    uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))(*(longlong **)(lVar5 + 0x58),0xb);
    uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
    memset(local_98,0,0x60);
    local_74 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))(*(longlong **)(lVar5 + 0x58),3);
    plVar6 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    local_70 = (**(code **)(*plVar6 + 0x58))(plVar6);
    local_5c = FUN_1402c3f90(lVar5);
    local_58 = FUN_1402c3fa0(lVar5);
    local_54 = FUN_1402c3fb0(lVar5);
    local_50 = uVar3;
    local_4c = uVar4;
    local_48 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))(*(longlong **)(lVar5 + 0x58),0xd)
    ;
    local_44 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))(*(longlong **)(lVar5 + 0x58),0xe)
    ;
    _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                (*(longlong **)(lVar5 + 0x58),1);
    strncpy(local_98,_Source,0x24);
    local_a8 = FUN_1402c5ae0(0xb0);
    if (local_a8 == 0) {
      puVar7 = (undefined8 *)0x0;
    }
    else {
      puVar7 = (undefined8 *)FUN_1402d4430(local_a8);
    }
    if (puVar7 == (undefined8 *)0x0) {
      local_b8 = 0x32b;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      local_b8 = (undefined4)param_2;
      cVar1 = FUN_1402d5850(puVar7,(int)param_1[0x76],local_98,uVar2);
      if (cVar1 == '\0') {
        (**(code **)*puVar7)(puVar7,1);
        uVar2 = 0;
      }
      else {
        (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar7);
        uVar3 = (**(code **)(*(longlong *)puVar7[0xc] + 0x28))();
        uVar4 = (**(code **)(*(longlong *)puVar7[0xc] + 0x20))();
        uVar8 = FUN_140008520((int)param_1[0x76]);
        FUN_14008a8d0(uVar8,uVar2,uVar4,uVar3);
      }
    }
  }
  return uVar2;
}

// ==== CMapManager::helper_1402ffb10  @1402ffb10  [medium:callgraph-r0]  (orig: FUN_1402ffb10)
void FUN_1402ffb10(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  while (lVar1 != 0) {
    if ((*(longlong *)(param_1 + 0x38) != 0) &&
       (lVar1 = *(longlong *)(param_1 + 0x38) + -1, *(longlong *)(param_1 + 0x38) = lVar1,
       lVar1 == 0)) {
      *(undefined8 *)(param_1 + 0x30) = 0;
    }
    lVar1 = *(longlong *)(param_1 + 0x38);
  }
  lVar1 = *(longlong *)(param_1 + 0x28);
  while (lVar1 != 0) {
    lVar1 = lVar1 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar1 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar1 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  return;
}

// ==== CMapManager::helper_1402fffe0  @1402fffe0  [medium:callgraph-r1]  (orig: FUN_1402fffe0)
void FUN_1402fffe0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CMapManager::helper_140300380  @140300380  [medium:callgraph-r0]  (orig: FUN_140300380)
void FUN_140300380(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ffbb0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapManager::vfunc_36  @140300e90  [high:rtti-vtable]  (orig: FUN_140300e90)
ulonglong FUN_140300e90(longlong param_1,int param_2,int param_3,int param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong *extraout_RAX;
  longlong *extraout_RAX_00;
  longlong *plVar3;
  longlong *extraout_RAX_01;
  longlong *extraout_RAX_02;
  undefined8 *puVar4;
  longlong lVar5;
  
  puVar4 = *(undefined8 **)(param_1 + 0x458);
  if (*(undefined8 **)(param_1 + 0x460) < puVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x440);
  plVar3 = plVar1;
  do {
    puVar2 = *(undefined8 **)(param_1 + 0x460);
    if (puVar2 < *(undefined8 **)(param_1 + 0x458)) {
      _invalid_parameter_noinfo();
      plVar3 = extraout_RAX;
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x440))) {
      _invalid_parameter_noinfo();
      plVar3 = extraout_RAX_00;
    }
    if (puVar4 == puVar2) {
      return (ulonglong)plVar3 & 0xffffffffffffff00;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)*puVar4;
    if ((int)*plVar3 == param_2) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
        _invalid_parameter_noinfo();
      }
      plVar3 = (longlong *)*puVar4;
      if (*(int *)((longlong)plVar3 + 4) <= param_3) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar1;
        }
        if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar1;
        }
        if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        plVar3 = (longlong *)*puVar4;
        if (param_3 <= *(int *)((longlong)plVar3 + 0xc) + *(int *)((longlong)plVar3 + 4)) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar1;
          }
          if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
            _invalid_parameter_noinfo();
          }
          plVar3 = (longlong *)*puVar4;
          if ((int)plVar3[1] <= param_4) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar5 = 0;
            }
            else {
              lVar5 = *plVar1;
            }
            if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
              _invalid_parameter_noinfo();
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar5 = 0;
            }
            else {
              lVar5 = *plVar1;
            }
            if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
              _invalid_parameter_noinfo();
            }
            plVar3 = (longlong *)*puVar4;
            if (param_4 <= (int)plVar3[2] + (int)plVar3[1]) {
              return CONCAT71((int7)((ulonglong)plVar3 >> 8),1);
            }
          }
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
      plVar3 = extraout_RAX_01;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
      plVar3 = extraout_RAX_02;
    }
    puVar4 = puVar4 + 1;
  } while( true );
}

// ==== CMapManager::helper_1403010a0  @1403010a0  [medium:callgraph-r0]  (orig: FUN_1403010a0)
undefined4 FUN_1403010a0(undefined8 *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  undefined8 local_18;
  ulonglong local_10;
  
  if (param_1[7] == 0) {
    uVar3 = 0;
  }
  else {
    uVar2 = param_1[6];
    if (param_1[7] + uVar2 < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_18 = *param_1;
    local_10 = uVar2;
    puVar4 = (undefined4 *)FUN_1402fe020(&local_18);
    uVar3 = *puVar4;
    if (param_1[7] != 0) {
      param_1[6] = param_1[6] + 1;
      if ((ulonglong)(param_1[5] << 2) <= (ulonglong)param_1[6]) {
        param_1[6] = 0;
      }
      lVar1 = param_1[7] + -1;
      param_1[7] = lVar1;
      if (lVar1 == 0) {
        param_1[6] = 0;
        return uVar3;
      }
    }
  }
  return uVar3;
}

// ==== CMapManager::helper_140301330  @140301330  [medium:callgraph-r0]  (orig: FUN_140301330)
void FUN_140301330(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CMapManager::helper_1403017c0  @1403017c0  [medium:callgraph-r0]  (orig: FUN_1403017c0)
longlong * FUN_1403017c0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140300380(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1403009b0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapManager::vfunc_8  @140301b40  [high:rtti-vtable]  (orig: FUN_140301b40)
ulonglong FUN_140301b40(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  ulonglong uVar3;
  ulong uVar4;
  uint uVar5;
  undefined4 uVar6;
  __time32_t _Var7;
  longlong *plVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong *plVar11;
  ulonglong uVar12;
  ulonglong extraout_RAX;
  uint uVar13;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  (**(code **)(*(longlong *)param_1[0x7f] + 0x10))((longlong *)param_1[0x7f],&local_48);
  while( true ) {
    plVar8 = (longlong *)
             (**(code **)(*(longlong *)param_1[0x7f] + 0x18))((longlong *)param_1[0x7f],local_28);
    if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar8)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_40 == (longlong *)plVar8[1]) break;
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    lVar9 = (**(code **)(*(longlong *)param_1[0x7f] + 0x20))((longlong *)param_1[0x7f],&local_38);
    if (lVar9 != 0) {
      FUN_1402c6040(lVar9,param_2);
    }
    if (CONCAT44(uStack_44,local_48) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
      plVar8 = (longlong *)uStack_40[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        uStack_40 = plVar8;
        plVar8 = (longlong *)*plVar8;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar8 + 0x29);
          uStack_40 = plVar8;
          plVar8 = (longlong *)*plVar8;
        }
      }
      else {
        cVar1 = *(char *)(uStack_40[1] + 0x29);
        plVar11 = (longlong *)uStack_40[1];
        plVar8 = uStack_40;
        while ((uStack_40 = plVar11, cVar1 == '\0' && (plVar8 == (longlong *)uStack_40[2]))) {
          cVar1 = *(char *)(uStack_40[1] + 0x29);
          plVar11 = (longlong *)uStack_40[1];
          plVar8 = uStack_40;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  uVar4 = tq::TimeGet(0);
  uVar5 = *(int *)((longlong)param_1 + 0x42c) + (int)param_1[0x86];
  uVar12 = (ulonglong)uVar5;
  if (uVar5 <= uVar4 / 1000) {
    uVar4 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x86) = uVar4 / 1000;
    plVar8 = (longlong *)(**(code **)(*param_1 + 0x50))(param_1);
    uVar10 = (**(code **)(*plVar8 + 0x10))(plVar8);
    uVar12 = uVar10;
    uVar3 = uVar10;
    while (uVar3 = uVar3 - 1, uVar3 < uVar10) {
      plVar8 = (longlong *)(**(code **)(*param_1 + 0x50))(param_1);
      plVar8 = (longlong *)
               (**(code **)(*plVar8 + 0x18))
                         (plVar8,uVar3,
                          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapmanager.cpp"
                          ,0x82);
      uVar12 = 0;
      if (plVar8 != (longlong *)0x0) {
        uVar4 = tq::TimeGet(0);
        uVar12 = (ulonglong)uVar4 * 0x10624dd3 & 0xffffffff;
        if ((uint)((int)plVar8[0x13] + *(int *)((longlong)plVar8 + 0x94)) <= uVar4 / 1000) {
          if (((*(uint *)(plVar8 + 4) < 0x10a1d0) || (0x10a5cc < *(uint *)(plVar8 + 4))) &&
             (iVar2 = *(int *)((longlong)plVar8 + 0x1c), iVar2 != 0)) {
            lVar9 = FUN_140008520((int)param_1[0x76]);
            lVar9 = *(longlong *)(lVar9 + 0x210);
            if (lVar9 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              lVar9 = 0;
            }
            FUN_14028e470(lVar9,iVar2);
          }
          plVar11 = (longlong *)(**(code **)(*param_1 + 0x50))(param_1);
          lVar9 = *plVar11;
          uVar6 = (**(code **)(*plVar8 + 8))(plVar8);
          uVar12 = (**(code **)(lVar9 + 0x28))(plVar11,uVar6);
        }
      }
    }
    if ((ulonglong)param_1[0x82] < uVar10) {
      param_1[0x82] = uVar10;
    }
    if (5000 < uVar10) {
      _Var7 = _time32((__time32_t *)0x0);
      uVar5 = _Var7 - (int)param_1[0x83];
      uVar13 = (int)uVar5 >> 0x1f;
      uVar13 = (uVar5 ^ uVar13) - uVar13;
      uVar12 = (ulonglong)uVar13;
      if (0x4af < (int)uVar13) {
        log_InlineLogMessage("MapManager[%u] item count %u / %u at %s, %d");
        *(__time32_t *)(param_1 + 0x83) = _Var7;
        uVar12 = extraout_RAX;
      }
    }
  }
  return uVar12;
}

// ==== CMapManager::vfunc_23  @140301e50  [high:rtti-vtable]  (orig: FUN_140301e50)
ulonglong FUN_140301e50(longlong param_1)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  iVar1 = FUN_14008a0f0(uVar3);
  uVar2 = iVar1 + *(int *)(param_1 + 8);
  if (*(longlong *)(param_1 + 0x48) != 0) {
    uVar4 = FUN_1403010a0(param_1 + 0x10);
    return uVar4;
  }
  if (uVar2 < 599999) {
    *(uint *)(param_1 + 8) = uVar2;
    return (ulonglong)uVar2;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  *(int *)(param_1 + 8) = *(int *)(lVar5 + 0x68) + 500000;
  log_InlineLogERROR(&DAT_14074bf88);
  return (ulonglong)*(uint *)(param_1 + 8);
}

// ==== CMapManager::vfunc_25  @140301ed0  [high:rtti-vtable]  (orig: FUN_140301ed0)
ulonglong FUN_140301ed0(longlong param_1)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  iVar1 = FUN_14008a0f0(uVar3);
  uVar2 = iVar1 + *(int *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x90) != 0) {
    uVar4 = FUN_1403010a0(param_1 + 0x58);
    return uVar4;
  }
  if (uVar2 < 199999) {
    *(uint *)(param_1 + 0x50) = uVar2;
    return (ulonglong)uVar2;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  *(int *)(param_1 + 0x50) = *(int *)(lVar5 + 0x68) + 100000;
  log_InlineLogERROR(&DAT_14074bfc8);
  return (ulonglong)*(uint *)(param_1 + 0x50);
}

// ==== CMapManager::vfunc_27  @140301f60  [high:rtti-vtable]  (orig: FUN_140301f60)
ulonglong FUN_140301f60(longlong param_1)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  iVar1 = FUN_14008a0f0(uVar3);
  uVar2 = iVar1 + *(int *)(param_1 + 0x98);
  if (*(longlong *)(param_1 + 0xd8) != 0) {
    uVar4 = FUN_1403010a0(param_1 + 0xa0);
    return uVar4;
  }
  if (uVar2 < 989999) {
    *(uint *)(param_1 + 0x98) = uVar2;
    return (ulonglong)uVar2;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  *(int *)(param_1 + 0x98) = *(int *)(lVar5 + 0x68) + 900000;
  log_InlineLogERROR(&DAT_14074c008);
  return (ulonglong)*(uint *)(param_1 + 0x98);
}

// ==== CMapManager::vfunc_29  @140301ff0  [high:rtti-vtable]  (orig: FUN_140301ff0)
ulonglong FUN_140301ff0(longlong param_1)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  iVar1 = FUN_14008a0f0(uVar3);
  uVar2 = iVar1 + *(int *)(param_1 + 0xe0);
  if (*(longlong *)(param_1 + 0x120) != 0) {
    uVar4 = FUN_1403010a0(param_1 + 0xe8);
    return uVar4;
  }
  if (uVar2 < 799999) {
    *(uint *)(param_1 + 0xe0) = uVar2;
    return (ulonglong)uVar2;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  *(int *)(param_1 + 0xe0) = *(int *)(lVar5 + 0x68) + 700000;
  log_InlineLogERROR(&DAT_14074c050);
  return (ulonglong)*(uint *)(param_1 + 0xe0);
}

// ==== CMapManager::vfunc_38  @140302080  [high:rtti-vtable]  (orig: FUN_140302080)
ulonglong FUN_140302080(longlong param_1)

{
  int iVar1;
  uint uVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  iVar1 = FUN_14008a0f0(uVar3);
  uVar2 = iVar1 + *(int *)(param_1 + 0x248);
  if (*(longlong *)(param_1 + 0x288) != 0) {
    uVar4 = FUN_1403010a0(param_1 + 0x250);
    return uVar4;
  }
  if (uVar2 < 219999) {
    *(uint *)(param_1 + 0x248) = uVar2;
    return (ulonglong)uVar2;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
  *(int *)(param_1 + 0x248) = *(int *)(lVar5 + 0x68) + 200000;
  log_InlineLogERROR(&DAT_14074c0a0);
  return (ulonglong)*(uint *)(param_1 + 0x248);
}

// ==== CMapManager::vfunc_40  @140302110  [high:rtti-vtable]  (orig: FUN_140302110)
ulonglong FUN_140302110(longlong param_1)

{
  uint uVar1;
  ulonglong uVar2;
  
  uVar1 = *(int *)(param_1 + 0x200) + 1;
  if (*(longlong *)(param_1 + 0x240) != 0) {
    uVar2 = FUN_1403010a0(param_1 + 0x208);
    return uVar2;
  }
  if (uVar1 < 0xdf639) {
    *(uint *)(param_1 + 0x200) = uVar1;
    return (ulonglong)uVar1;
  }
  *(undefined4 *)(param_1 + 0x200) = 0xdee69;
  log_InlineLogERROR(&DAT_14074c0f0);
  return (ulonglong)*(uint *)(param_1 + 0x200);
}

// ==== CMapManager::vfunc_16  @140302180  [high:rtti-vtable]  (orig: FUN_140302180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140302180(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,900000,1);
  if (lVar5 == 0) {
    local_98 = 0x249;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x25] + 1;
    if (param_1[0x2d] == 0) {
      if (uVar2 < 0xdcf28) {
        *(uint *)(param_1 + 0x25) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x26a;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 900000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x25]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x25);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c160);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x26);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_17  @1403023f0  [high:rtti-vtable]  (orig: FUN_1403023f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403023f0(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,960000,1);
  if (lVar5 == 0) {
    local_98 = 0x27d;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x2e] + 1;
    if (param_1[0x36] == 0) {
      if (uVar2 < 960000) {
        *(uint *)(param_1 + 0x2e) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x29e;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 960000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x2e]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x2e);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c1e0);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x2f);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_21  @140302660  [high:rtti-vtable]  (orig: FUN_140302660)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140302660(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,930000,1);
  if (lVar5 == 0) {
    local_98 = 0x2b1;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x5b] + 1;
    if (param_1[99] == 0) {
      if (uVar2 < 930000) {
        *(uint *)(param_1 + 0x5b) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x2d2;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 930000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x5b]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x5b);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c270);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x26);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_18  @1403028d0  [high:rtti-vtable]  (orig: FUN_1403028d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403028d0(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,910000,1);
  if (lVar5 == 0) {
    local_98 = 0x2e4;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x37] + 1;
    if (param_1[0x3f] == 0) {
      if (uVar2 < 0xdee68) {
        *(uint *)(param_1 + 0x37) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x305;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 910000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x37]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x37);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c300);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x38);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_42  @140302b40  [high:rtti-vtable]  (orig: FUN_140302b40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140302b40(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,920000,1);
  if (lVar5 == 0) {
    local_98 = 0x341;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x52] + 1;
    if (param_1[0x5a] == 0) {
      if (uVar2 < 920000) {
        *(uint *)(param_1 + 0x52) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x362;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 920000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x52]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x52);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c370);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x53);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_20  @140302db0  [high:rtti-vtable]  (orig: FUN_140302db0)
undefined8 FUN_140302db0(longlong *param_1,ulonglong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *local_res8;
  longlong *local_res18 [2];
  uint in_stack_ffffffffffffff68;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  longlong *local_70 [3];
  longlong *local_58;
  longlong *local_50;
  undefined8 local_48;
  
  lVar5 = (**(code **)(*param_1 + 0x20))(param_1,param_2,0);
  if ((lVar5 == 0) || (cVar3 = FUN_14011dbb0(lVar5), cVar3 == '\0')) {
    uVar6 = 0;
  }
  else {
    FUN_1402d1bd0(lVar5);
    local_res8 = operator_new(8);
    local_70[0] = (longlong *)0x0;
    if (local_res8 != (longlong *)0x0) {
      *local_res8 = (longlong)local_70;
      local_70[0] = local_res8;
    }
    local_58 = (longlong *)0x0;
    local_50 = (longlong *)0x0;
    local_48 = 0;
    local_res18[0] = local_res8;
    FUN_1402d2100(lVar5,local_70);
    plVar8 = local_58;
    if (local_50 < local_58) {
      _invalid_parameter_noinfo();
    }
    plVar2 = local_50;
    plVar1 = local_70[0];
    plVar9 = local_70[0];
    if (local_50 < local_58) {
      _invalid_parameter_noinfo();
      plVar9 = local_70[0];
    }
    while( true ) {
      lVar5 = 0;
      if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar9)) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)*plVar8;
      if (plVar7 == (longlong *)0x0) {
        in_stack_ffffffffffffff68 = 0x388;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_res18[0] = (longlong *)0x0;
        cVar3 = (**(code **)(*plVar7 + 0x40))(plVar7,local_res18);
        if ((cVar3 != '\0') && (local_res18[0] != (longlong *)0x0)) {
          local_res8 = (longlong *)0x0;
          (**(code **)(*local_res18[0] + 0x298))(local_res18[0],0x1001,&local_res8);
          if (local_res8 == (longlong *)0x0) {
            plVar7 = (longlong *)FUN_140119790(0xe);
            lVar5 = *plVar7;
            uVar4 = (**(code **)(*local_res18[0] + 0x10))();
            (**(code **)(lVar5 + 0xc0))(plVar7,uVar4);
          }
          else {
            local_80 = 0;
            local_7c = 0;
            local_78 = 0;
            uVar6 = FUN_140008520((int)param_1[0x76]);
            uVar6 = FUN_1400d6610(uVar6);
            FUN_140006c50(uVar6,&local_80);
            in_stack_ffffffffffffff68 = in_stack_ffffffffffffff68 & 0xffffff00;
            FUN_1401c55b0(local_res8,local_80,local_7c,local_78,in_stack_ffffffffffffff68);
          }
        }
      }
      lVar5 = 0;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(longlong **)(lVar5 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar8 + 1;
    }
    (**(code **)(*(longlong *)param_1[0x7f] + 0x30))((longlong *)param_1[0x7f],param_2 & 0xffffffff)
    ;
    uVar6 = FUN_140008520(0xe);
    FUN_14008a910(uVar6,param_2 & 0xffffffff);
    if (local_58 != (longlong *)0x0) {
      operator_delete(local_58);
    }
    local_58 = (longlong *)0x0;
    local_50 = (longlong *)0x0;
    local_48 = 0;
    operator_delete(local_70[0]);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMapManager::vfunc_48  @140303070  [high:rtti-vtable]  (orig: FUN_140303070)
void FUN_140303070(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  (**(code **)(**(longlong **)(param_1 + 0x3f8) + 0x10))(*(longlong **)(param_1 + 0x3f8),&local_38);
  while( true ) {
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x3f8) + 0x18))
                       (*(longlong **)(param_1 + 0x3f8),local_18);
    if ((CONCAT44(uStack_34,local_38) == 0) || (CONCAT44(uStack_34,local_38) != *plVar6)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_30 == (longlong *)plVar6[1]) break;
    local_28 = local_38;
    uStack_24 = uStack_34;
    uStack_20 = (undefined4)uStack_30;
    uStack_1c = uStack_30._4_4_;
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x3f8) + 0x20))
                       (*(longlong **)(param_1 + 0x3f8),&local_28);
    if (plVar6 != (longlong *)0x0) {
      iVar3 = (**(code **)(*(longlong *)plVar6[0xc] + 0x28))();
      iVar4 = (**(code **)(*(longlong *)plVar6[0xc] + 0x20))();
      uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x3b0));
      FUN_14008a8d0(uVar7,uVar5,(iVar4 + -1) / 0x12 + 1,(iVar3 + -1) / 0x12 + 1);
    }
    if (CONCAT44(uStack_34,local_38) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_30 + 0x29) == '\0') {
      plVar6 = (longlong *)uStack_30[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        uStack_30 = plVar6;
        plVar6 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x29);
          uStack_30 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      else {
        cVar1 = *(char *)(uStack_30[1] + 0x29);
        plVar2 = (longlong *)uStack_30[1];
        plVar6 = uStack_30;
        while ((uStack_30 = plVar2, cVar1 == '\0' && (plVar6 == (longlong *)uStack_30[2]))) {
          cVar1 = *(char *)(uStack_30[1] + 0x29);
          plVar2 = (longlong *)uStack_30[1];
          plVar6 = uStack_30;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CMapManager::vfunc_44  @140303200  [high:rtti-vtable]  (orig: FUN_140303200)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140303200(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,940000,1);
  if (lVar5 == 0) {
    local_98 = 0x432;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[100] + 1;
    if (param_1[0x6c] == 0) {
      if (uVar2 < 940000) {
        *(uint *)(param_1 + 100) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x453;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 940000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[100]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 100);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c410);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x65);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_46  @140303470  [high:rtti-vtable]  (orig: FUN_140303470)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140303470(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong *plVar7;
  char *_Source;
  undefined8 *puVar8;
  undefined1 auStack_b8 [32];
  undefined4 local_98;
  longlong local_88;
  undefined8 local_80;
  char local_78 [36];
  undefined4 local_54;
  undefined8 local_50;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  ulonglong local_18;
  
  local_80 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  lVar5 = (**(code **)(*param_1 + 0x10))(param_1,950000,1);
  if (lVar5 == 0) {
    local_98 = 0x466;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar2 = (int)param_1[0x6d] + 1;
    if (param_1[0x75] == 0) {
      if (uVar2 < 950000) {
        *(uint *)(param_1 + 0x6d) = uVar2;
        uVar3 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                          (*(longlong **)(lVar5 + 0x58),0xb);
        uVar4 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))();
        memset(local_78,0,0x60);
        local_54 = (**(code **)(**(longlong **)(lVar5 + 0x58) + 0x10))
                             (*(longlong **)(lVar5 + 0x58),3);
        plVar7 = *(longlong **)(*(longlong *)(lVar5 + 0x58) + 8);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
        local_50 = (**(code **)(*plVar7 + 0x58))(plVar7);
        local_3c = FUN_1402c3f90(lVar5);
        local_38 = FUN_1402c3fa0(lVar5);
        local_34 = FUN_1402c3fb0(lVar5);
        local_30 = uVar3;
        local_2c = uVar4;
        _Source = (char *)(**(code **)(**(longlong **)(lVar5 + 0x58) + 0x18))
                                    (*(longlong **)(lVar5 + 0x58),1);
        strncpy(local_78,_Source,0x24);
        local_88 = FUN_1402c5ae0(0xb0);
        if (local_88 == 0) {
          puVar8 = (undefined8 *)0x0;
        }
        else {
          puVar8 = (undefined8 *)FUN_1402d4430(local_88);
        }
        if (puVar8 == (undefined8 *)0x0) {
          local_98 = 0x487;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          local_98 = 950000;
          cVar1 = FUN_1402d5850(puVar8,(int)param_1[0x76],local_78,(int)param_1[0x6d]);
          if (cVar1 == '\0') {
            (**(code **)*puVar8)(puVar8,1);
            uVar6 = 0;
          }
          else {
            (**(code **)(*(longlong *)param_1[0x7f] + 0x28))((longlong *)param_1[0x7f],puVar8);
            uVar6 = (ulonglong)*(uint *)(param_1 + 0x6d);
          }
        }
      }
      else {
        log_InlineLogERROR(&DAT_14074c480);
        uVar6 = 0;
      }
    }
    else {
      uVar6 = FUN_1403010a0(param_1 + 0x6e);
    }
  }
  return uVar6;
}

// ==== CMapManager::vfunc_5  @1403036e0  [high:rtti-vtable]  (orig: FUN_1403036e0)
undefined8 FUN_1403036e0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 1000))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 1000);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 1000);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x3b8);
  if (*(longlong *)(param_1 + 0x3b8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 1000);
    local_28 = *(longlong *)(param_1 + 0x3b8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 1000);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x3b8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMapManager::helper_140303a70  @140303a70  [medium:callgraph-r0]  (orig: FUN_140303a70)
undefined8 * FUN_140303a70(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IGameObjSet<CMapItem>::vftable;
  *param_1 = CGameObjSet<CMapItem>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CMapManager::helper_140303e80  @140303e80  [medium:callgraph-r0]  (orig: FUN_140303e80)
undefined8 * FUN_140303e80(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = ISingleObjSet2<CGameData<&char*_szPortalTable,&char*_szID>_>::vftable;
  *param_1 = CSingleObjSet2<CGameData<&char*_szPortalTable,&char*_szID>_>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CMapManager::helper_140304f70  @140304f70  [medium:callgraph-r0]  (orig: FUN_140304f70)
undefined8 * FUN_140304f70(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = ISingleObjSet2<CGameData<&char*_szPasswayTable,&char*_szID>_>::vftable;
  *param_1 = CSingleObjSet2<CGameData<&char*_szPasswayTable,&char*_szID>_>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CMapManager::ctor_or_dtor  @140307a20  [high:vtable-assign]  (orig: FUN_140307a20)
void FUN_140307a20(undefined8 *param_1)

{
  ulonglong *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  uint uVar7;
  undefined8 local_68;
  undefined8 *puStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined1 local_48 [32];
  ulonglong uVar8;
  
  *param_1 = CMapManager::vftable;
  FUN_140300380(param_1 + 0x77);
  if (param_1[0x84] != 0) {
    FUN_14001aff0(local_48,"MapManager-MapItemSet",5);
    (**(code **)(*(longlong *)param_1[0x84] + 0x10))();
    (**(code **)(*(longlong *)param_1[0x84] + 8))();
    FUN_14001b030(local_48);
  }
  if (param_1[0x80] != 0) {
    FUN_14001aff0(local_48,"MapManager-ProtalSet",5);
    (**(code **)(*(longlong *)param_1[0x80] + 0x18))();
    (**(code **)(*(longlong *)param_1[0x80] + 0x10))();
    FUN_14001b030(local_48);
  }
  if (param_1[0x81] != 0) {
    FUN_14001aff0(local_48,"MapManager-PasswaySet",5);
    (**(code **)(*(longlong *)param_1[0x81] + 0x18))();
    (**(code **)(*(longlong *)param_1[0x81] + 0x10))();
    FUN_14001b030(local_48);
  }
  if (param_1[0x7f] != 0) {
    FUN_14001aff0(local_48,"MapManager-MapSet",5);
    (**(code **)(*(longlong *)param_1[0x7f] + 0x48))();
    (**(code **)(*(longlong *)param_1[0x7f] + 8))();
    FUN_14001b030(local_48);
  }
  uVar5 = 0;
  puVar4 = (undefined8 *)param_1[0x8b];
  if ((undefined8 *)param_1[0x8c] < puVar4) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)param_1[0x88];
  uVar8 = uVar5;
  while( true ) {
    puVar2 = (undefined8 *)param_1[0x8c];
    if (puVar2 < (undefined8 *)param_1[0x8b]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)param_1[0x88])) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) goto LAB_140307c58;
    uVar7 = (int)uVar8 + 1;
    uVar8 = (ulonglong)uVar7;
    if (10000 < uVar7) break;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar6 = uVar5;
    }
    else {
      uVar6 = *puVar1;
    }
    if (*(undefined8 **)(uVar6 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    operator_delete((void *)*puVar4);
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar6 = uVar5;
    }
    else {
      uVar6 = *puVar1;
    }
    if (*(undefined8 **)(uVar6 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_140307c58:
  FUN_140301330(param_1 + 0x88);
  if (param_1[0x87] != 0) {
    (**(code **)(*(longlong *)param_1[0x87] + 0x10))();
    param_1[0x87] = 0;
  }
  if ((void *)param_1[0x8b] != (void *)0x0) {
    operator_delete((void *)param_1[0x8b]);
  }
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  operator_delete((void *)param_1[0x88]);
  puVar4 = param_1 + 0x77;
  puStack_60 = (undefined8 *)param_1[0x7d];
  local_68 = *puVar4;
  uStack_50 = *puStack_60;
  local_58 = local_68;
  FUN_1403017c0(puVar4,local_48,&local_58,&local_68);
  operator_delete((void *)param_1[0x7d]);
  param_1[0x7d] = 0;
  param_1[0x7e] = 0;
  operator_delete((void *)*puVar4);
  lVar3 = param_1[0x75];
  while (lVar3 != 0) {
    if ((param_1[0x75] != 0) && (lVar3 = param_1[0x75] + -1, param_1[0x75] = lVar3, lVar3 == 0)) {
      param_1[0x74] = 0;
    }
    lVar3 = param_1[0x75];
  }
  lVar3 = param_1[0x73];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x72] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x72] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x72] != (void *)0x0) {
    operator_delete((void *)param_1[0x72]);
  }
  param_1[0x73] = 0;
  param_1[0x72] = 0;
  operator_delete((void *)param_1[0x6e]);
  lVar3 = param_1[0x6c];
  while (lVar3 != 0) {
    if ((param_1[0x6c] != 0) && (lVar3 = param_1[0x6c] + -1, param_1[0x6c] = lVar3, lVar3 == 0)) {
      param_1[0x6b] = 0;
    }
    lVar3 = param_1[0x6c];
  }
  lVar3 = param_1[0x6a];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x69] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x69] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x69] != (void *)0x0) {
    operator_delete((void *)param_1[0x69]);
  }
  param_1[0x6a] = 0;
  param_1[0x69] = 0;
  operator_delete((void *)param_1[0x65]);
  lVar3 = param_1[99];
  while (lVar3 != 0) {
    if ((param_1[99] != 0) && (lVar3 = param_1[99] + -1, param_1[99] = lVar3, lVar3 == 0)) {
      param_1[0x62] = 0;
    }
    lVar3 = param_1[99];
  }
  lVar3 = param_1[0x61];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x60] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x60] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x60] != (void *)0x0) {
    operator_delete((void *)param_1[0x60]);
  }
  param_1[0x61] = 0;
  param_1[0x60] = 0;
  operator_delete((void *)param_1[0x5c]);
  lVar3 = param_1[0x5a];
  while (lVar3 != 0) {
    if ((param_1[0x5a] != 0) && (lVar3 = param_1[0x5a] + -1, param_1[0x5a] = lVar3, lVar3 == 0)) {
      param_1[0x59] = 0;
    }
    lVar3 = param_1[0x5a];
  }
  lVar3 = param_1[0x58];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x57] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x57] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x57] != (void *)0x0) {
    operator_delete((void *)param_1[0x57]);
  }
  param_1[0x58] = 0;
  param_1[0x57] = 0;
  operator_delete((void *)param_1[0x53]);
  lVar3 = param_1[0x51];
  while (lVar3 != 0) {
    if ((param_1[0x51] != 0) && (lVar3 = param_1[0x51] + -1, param_1[0x51] = lVar3, lVar3 == 0)) {
      param_1[0x50] = 0;
    }
    lVar3 = param_1[0x51];
  }
  lVar3 = param_1[0x4f];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x4e] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x4e] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x4e] != (void *)0x0) {
    operator_delete((void *)param_1[0x4e]);
  }
  param_1[0x4f] = 0;
  param_1[0x4e] = 0;
  operator_delete((void *)param_1[0x4a]);
  lVar3 = param_1[0x48];
  while (lVar3 != 0) {
    if ((param_1[0x48] != 0) && (lVar3 = param_1[0x48] + -1, param_1[0x48] = lVar3, lVar3 == 0)) {
      param_1[0x47] = 0;
    }
    lVar3 = param_1[0x48];
  }
  lVar3 = param_1[0x46];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x45] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x45] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x45] != (void *)0x0) {
    operator_delete((void *)param_1[0x45]);
  }
  param_1[0x46] = 0;
  param_1[0x45] = 0;
  operator_delete((void *)param_1[0x41]);
  lVar3 = param_1[0x3f];
  while (lVar3 != 0) {
    if ((param_1[0x3f] != 0) && (lVar3 = param_1[0x3f] + -1, param_1[0x3f] = lVar3, lVar3 == 0)) {
      param_1[0x3e] = 0;
    }
    lVar3 = param_1[0x3f];
  }
  lVar3 = param_1[0x3d];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x3c] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x3c] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x3c] != (void *)0x0) {
    operator_delete((void *)param_1[0x3c]);
  }
  param_1[0x3d] = 0;
  param_1[0x3c] = 0;
  operator_delete((void *)param_1[0x38]);
  lVar3 = param_1[0x36];
  while (lVar3 != 0) {
    if ((param_1[0x36] != 0) && (lVar3 = param_1[0x36] + -1, param_1[0x36] = lVar3, lVar3 == 0)) {
      param_1[0x35] = 0;
    }
    lVar3 = param_1[0x36];
  }
  lVar3 = param_1[0x34];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x33] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x33] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x33] != (void *)0x0) {
    operator_delete((void *)param_1[0x33]);
  }
  param_1[0x34] = 0;
  param_1[0x33] = 0;
  operator_delete((void *)param_1[0x2f]);
  lVar3 = param_1[0x2d];
  while (lVar3 != 0) {
    if ((param_1[0x2d] != 0) && (lVar3 = param_1[0x2d] + -1, param_1[0x2d] = lVar3, lVar3 == 0)) {
      param_1[0x2c] = 0;
    }
    lVar3 = param_1[0x2d];
  }
  lVar3 = param_1[0x2b];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x2a] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x2a] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x2a] != (void *)0x0) {
    operator_delete((void *)param_1[0x2a]);
  }
  param_1[0x2b] = 0;
  param_1[0x2a] = 0;
  operator_delete((void *)param_1[0x26]);
  lVar3 = param_1[0x24];
  while (lVar3 != 0) {
    if ((param_1[0x24] != 0) && (lVar3 = param_1[0x24] + -1, param_1[0x24] = lVar3, lVar3 == 0)) {
      param_1[0x23] = 0;
    }
    lVar3 = param_1[0x24];
  }
  lVar3 = param_1[0x22];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x21] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x21] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x21] != (void *)0x0) {
    operator_delete((void *)param_1[0x21]);
  }
  param_1[0x22] = 0;
  param_1[0x21] = 0;
  operator_delete((void *)param_1[0x1d]);
  lVar3 = param_1[0x1b];
  while (lVar3 != 0) {
    if ((param_1[0x1b] != 0) && (lVar3 = param_1[0x1b] + -1, param_1[0x1b] = lVar3, lVar3 == 0)) {
      param_1[0x1a] = 0;
    }
    lVar3 = param_1[0x1b];
  }
  lVar3 = param_1[0x19];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0x18] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0x18] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0x18] != (void *)0x0) {
    operator_delete((void *)param_1[0x18]);
  }
  param_1[0x19] = 0;
  param_1[0x18] = 0;
  operator_delete((void *)param_1[0x14]);
  lVar3 = param_1[0x12];
  while (lVar3 != 0) {
    if ((param_1[0x12] != 0) && (lVar3 = param_1[0x12] + -1, param_1[0x12] = lVar3, lVar3 == 0)) {
      param_1[0x11] = 0;
    }
    lVar3 = param_1[0x12];
  }
  lVar3 = param_1[0x10];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[0xf] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[0xf] + lVar3 * 8));
    }
  }
  if ((void *)param_1[0xf] != (void *)0x0) {
    operator_delete((void *)param_1[0xf]);
  }
  param_1[0x10] = 0;
  param_1[0xf] = 0;
  operator_delete((void *)param_1[0xb]);
  lVar3 = param_1[9];
  while (lVar3 != 0) {
    if ((param_1[9] != 0) && (lVar3 = param_1[9] + -1, param_1[9] = lVar3, lVar3 == 0)) {
      param_1[8] = 0;
    }
    lVar3 = param_1[9];
  }
  lVar3 = param_1[7];
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(param_1[6] + lVar3 * 8) != 0) {
      operator_delete(*(void **)(param_1[6] + lVar3 * 8));
    }
  }
  if ((void *)param_1[6] != (void *)0x0) {
    operator_delete((void *)param_1[6]);
  }
  param_1[7] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[2]);
  *param_1 = IMapManager::vftable;
  return;
}

// ==== CMapManager::vfunc_2  @1403083f0  [high:rtti-vtable]  (orig: FUN_1403083f0)
undefined8 FUN_1403083f0(longlong *param_1)

{
  undefined8 uVar1;
  
  if (param_1[0x7f] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140308436. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*param_1 + 0x20))();
  return uVar1;
}

// ==== CMapManager::vfunc_3  @140308440  [high:rtti-vtable]  (orig: FUN_140308440)
longlong FUN_140308440(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x3f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapManager::vfunc_6  @140308490  [high:rtti-vtable]  (orig: FUN_140308490)
void FUN_140308490(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014030849a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x3f8) + 0x48))();
  return;
}

// ==== CMapManager::vfunc_37  @1403084a0  [high:rtti-vtable]  (orig: FUN_1403084a0)
bool FUN_1403084a0(undefined8 param_1,uint param_2)

{
  return 1000000 < param_2;
}

// ==== CMapManager::vfunc_22  @1403084b0  [high:rtti-vtable]  (orig: FUN_1403084b0)
longlong FUN_1403084b0(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975b78;
  if (DAT_140975b78 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapManager::vfunc_9  @140308500  [high:rtti-vtable]  (orig: FUN_140308500)
undefined8 FUN_140308500(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x420) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014030854d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x420) + 0x30))();
  return uVar1;
}

// ==== CMapManager::vfunc_10  @140308560  [high:rtti-vtable]  (orig: FUN_140308560)
longlong FUN_140308560(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x420);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapManager::helper_1403085c0  @1403085c0  [medium:callgraph-r2]  (orig: FUN_1403085c0)
void FUN_1403085c0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"deque<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapManager::helper_140308770  @140308770  [medium:callgraph-r2]  (orig: FUN_140308770)
void FUN_140308770(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMapManager::vfunc_34  @140308920  [high:rtti-vtable]  (orig: FUN_140308920)
void FUN_140308920(longlong param_1)

{
  FUN_1402ffb10(param_1 + 0x1c0);
  *(undefined4 *)(param_1 + 0x1b8) = 910000;
  return;
}

// ==== CMapManager::vfunc_35  @140308950  [high:rtti-vtable]  (orig: FUN_140308950)
void FUN_140308950(longlong param_1)

{
  FUN_1402ffb10(param_1 + 0x178);
  *(undefined4 *)(param_1 + 0x170) = 950000;
  return;
}

// ==== CMapManager::helper_140308980  @140308980  [medium:callgraph-r1]  (orig: FUN_140308980)
void FUN_140308980(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0xfffffffffffffff - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1403085c0();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0xfffffffffffffff - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30) >> 2;
  _Dst_00 = (void *)FUN_140308770(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CMapManager::helper_140308b40  @140308b40  [medium:callgraph-r0]  (orig: FUN_140308b40)
void FUN_140308b40(longlong param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (((*(char *)(param_1 + 0x30) + (char)*(longlong *)(param_1 + 0x38) & 3U) == 0) &&
     (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 4U >> 2)) {
    FUN_140308980(param_1,1);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  uVar4 = uVar3 >> 2;
  if (*(ulonglong *)(param_1 + 0x28) <= uVar4) {
    uVar4 = uVar4 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) == 0) {
    pvVar2 = operator_new(0x10);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) = pvVar2;
  }
  puVar1 = (undefined4 *)
           (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) +
           (ulonglong)((uint)uVar3 & 3) * 4);
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = *param_2;
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CMapManager::helper_140308c10  @140308c10  [medium:callgraph-r0]  (orig: FUN_140308c10)
undefined8 * FUN_140308c10(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402fffe0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapManager::vfunc_24  @140309ee0  [high:rtti-vtable]  (orig: FUN_140309ee0)
void FUN_140309ee0(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x10,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_26  @140309f00  [high:rtti-vtable]  (orig: FUN_140309f00)
void FUN_140309f00(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x58,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_28  @140309f20  [high:rtti-vtable]  (orig: FUN_140309f20)
void FUN_140309f20(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0xa0,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_39  @140309f50  [high:rtti-vtable]  (orig: FUN_140309f50)
void FUN_140309f50(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x250,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_30  @140309f80  [high:rtti-vtable]  (orig: FUN_140309f80)
void FUN_140309f80(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0xe8,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_31  @140309fb0  [high:rtti-vtable]  (orig: FUN_140309fb0)
void FUN_140309fb0(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x130,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_32  @140309fe0  [high:rtti-vtable]  (orig: FUN_140309fe0)
void FUN_140309fe0(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x178,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_33  @14030a010  [high:rtti-vtable]  (orig: FUN_14030a010)
void FUN_14030a010(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x1c0,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_41  @14030a040  [high:rtti-vtable]  (orig: FUN_14030a040)
void FUN_14030a040(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x208,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_43  @14030a070  [high:rtti-vtable]  (orig: FUN_14030a070)
void FUN_14030a070(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x298,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_45  @14030a0a0  [high:rtti-vtable]  (orig: FUN_14030a0a0)
void FUN_14030a0a0(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x328,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_47  @14030a0d0  [high:rtti-vtable]  (orig: FUN_14030a0d0)
void FUN_14030a0d0(longlong param_1,int param_2)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140308b40(param_1 + 0x370,local_res10);
  }
  return;
}

// ==== CMapManager::vfunc_0  @14030a100  [high:rtti-vtable]  (orig: FUN_14030a100)
undefined8 FUN_14030a100(undefined8 param_1,uint param_2)

{
  FUN_140307a20();
  if ((param_2 & 1) != 0) {
    FUN_1402fe8e0(param_1);
  }
  return param_1;
}

// ==== CMapManager::ctor_or_dtor  @14030aa50  [high:vtable-assign]  (orig: FUN_14030aa50)
undefined8 * FUN_14030aa50(undefined8 *param_1,undefined4 param_2)

{
  ulong uVar1;
  longlong *plVar2;
  void *pvVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  *param_1 = IMapManager::vftable;
  *param_1 = CMapManager::vftable;
  plVar2 = operator_new(8);
  plVar5 = (longlong *)0x0;
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 2);
    plVar4 = plVar2;
  }
  param_1[2] = plVar4;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0xb);
    plVar4 = plVar2;
  }
  param_1[0xb] = plVar4;
  param_1[0xf] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x14);
    plVar4 = plVar2;
  }
  param_1[0x14] = plVar4;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x1d);
    plVar4 = plVar2;
  }
  param_1[0x1d] = plVar4;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x26);
    plVar4 = plVar2;
  }
  param_1[0x26] = plVar4;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x2f);
    plVar4 = plVar2;
  }
  param_1[0x2f] = plVar4;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x38);
    plVar4 = plVar2;
  }
  param_1[0x38] = plVar4;
  param_1[0x3c] = 0;
  param_1[0x3d] = 0;
  param_1[0x3e] = 0;
  param_1[0x3f] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x41);
    plVar4 = plVar2;
  }
  param_1[0x41] = plVar4;
  param_1[0x45] = 0;
  param_1[0x46] = 0;
  param_1[0x47] = 0;
  param_1[0x48] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x4a);
    plVar4 = plVar2;
  }
  param_1[0x4a] = plVar4;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x53);
    plVar4 = plVar2;
  }
  param_1[0x53] = plVar4;
  param_1[0x57] = 0;
  param_1[0x58] = 0;
  param_1[0x59] = 0;
  param_1[0x5a] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x5c);
    plVar4 = plVar2;
  }
  param_1[0x5c] = plVar4;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  param_1[0x62] = 0;
  param_1[99] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x65);
    plVar4 = plVar2;
  }
  param_1[0x65] = plVar4;
  param_1[0x69] = 0;
  param_1[0x6a] = 0;
  param_1[0x6b] = 0;
  param_1[0x6c] = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x6e);
    plVar4 = plVar2;
  }
  param_1[0x6e] = plVar4;
  param_1[0x72] = 0;
  param_1[0x73] = 0;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  *(undefined4 *)(param_1 + 0x76) = param_2;
  FUN_140308c10(param_1 + 0x77);
  *(undefined4 *)((longlong)param_1 + 0x42c) = 0;
  *(undefined4 *)(param_1 + 0x86) = 0;
  plVar2 = operator_new(8);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x88);
    plVar4 = plVar2;
  }
  param_1[0x88] = plVar4;
  param_1[0x8b] = 0;
  param_1[0x8c] = 0;
  param_1[0x8d] = 0;
  plVar2 = operator_new(0x50);
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)ISingleMap<CGameMap>::vftable;
    *plVar2 = (longlong)CSingleMap<CGameMap>::vftable;
    FUN_140308c10(plVar2 + 2);
    *(undefined1 *)(plVar2 + 1) = 1;
    plVar4 = plVar2;
  }
  param_1[0x7f] = plVar4;
  pvVar3 = operator_new(0x40);
  plVar4 = plVar5;
  if (pvVar3 != (void *)0x0) {
    plVar4 = (longlong *)FUN_140303e80(pvVar3,1);
  }
  param_1[0x80] = plVar4;
  pvVar3 = operator_new(0x40);
  plVar4 = plVar5;
  if (pvVar3 != (void *)0x0) {
    plVar4 = (longlong *)FUN_140304f70(pvVar3,1);
  }
  param_1[0x81] = plVar4;
  param_1[0x82] = 0;
  *(undefined4 *)(param_1 + 0x83) = 0;
  pvVar3 = operator_new(0x40);
  if (pvVar3 != (void *)0x0) {
    plVar5 = (longlong *)FUN_140303a70(pvVar3,1);
  }
  param_1[0x84] = plVar5;
  *(undefined4 *)(param_1 + 0x85) = 0;
  *(undefined4 *)(param_1 + 0x49) = 200000;
  *(undefined4 *)((longlong)param_1 + 0x42c) = 5;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x86) = uVar1 / 1000;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x76));
  *(int *)(param_1 + 1) = *(int *)(lVar6 + 0x68) + 500000;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x76));
  *(int *)(param_1 + 10) = *(int *)(lVar6 + 0x68) + 100000;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x76));
  *(int *)(param_1 + 0x13) = *(int *)(lVar6 + 0x68) + 900000;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x76));
  *(int *)(param_1 + 0x1c) = *(int *)(lVar6 + 0x68) + 700000;
  *(undefined4 *)(param_1 + 0x25) = 900000;
  *(undefined4 *)(param_1 + 0x37) = 910000;
  *(undefined4 *)(param_1 + 0x40) = 0xdee68;
  *(undefined4 *)(param_1 + 0x52) = 0xdf638;
  *(undefined4 *)(param_1 + 0x5b) = 920000;
  *(undefined4 *)(param_1 + 100) = 930000;
  *(undefined4 *)(param_1 + 0x6d) = 940000;
  *(undefined4 *)(param_1 + 0x2e) = 950000;
  param_1[0x87] = 0;
  return param_1;
}

// ==== CMapManager::helper_140395590  @140395590  [medium:callgraph-r1]  (orig: FUN_140395590)
void FUN_140395590(void)

{
  return;
}

// ==== CMapManager::helper_140395600  @140395600  [medium:callgraph-r1]  (orig: FUN_140395600)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

undefined8 FUN_140395600(int *param_1,longlong *param_2)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  undefined1 auStack_478 [32];
  undefined4 local_458;
  int aiStack_44c [9];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (param_2 == (longlong *)0x0) {
    local_458 = 0x83;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  _snprintf(local_428,0x400,
            "select data2, data3, data4, data5 from cq_globalvariable where %u = data1 and 14000 = type limit 1"
           );
  local_29 = 0;
  plVar2 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,local_428,1);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 == 0) {
      (**(code **)*plVar2)(plVar2);
    }
    else {
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0);
      iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
      param_1[0x26] = iVar1;
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,1);
      iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
      param_1[0x27] = iVar1;
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
      iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
      param_1[0x28] = iVar1;
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,3);
      iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
      param_1[0x29] = iVar1;
      (**(code **)*plVar2)(plVar2);
    }
  }
  _snprintf(local_428,0x400,
            "select map_id1, map_id2, map_id3, map_id4, map_id5 from cq_pk_mapgroup where %u in(map_id1, map_id2, map_id3, map_id4, map_id5) limit 1"
           );
  local_29 = 0;
  plVar2 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,local_428,1);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 == 0) {
      (**(code **)*plVar2)(plVar2);
    }
    else {
      uVar5 = 0;
      aiStack_44c[1] = 0;
      aiStack_44c[2] = 0;
      aiStack_44c[3] = 0;
      aiStack_44c[4] = 0;
      aiStack_44c[5] = 0;
      piVar8 = aiStack_44c;
      uVar6 = 0xffffffff;
      do {
        piVar8 = piVar8 + 1;
        plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,uVar5);
        iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
        uVar7 = uVar5;
        if (param_1[0x33] != iVar1) {
          *piVar8 = iVar1;
          uVar7 = uVar6;
        }
        uVar5 = uVar5 + 1;
        uVar6 = uVar7;
      } while ((int)uVar5 < 5);
      (**(code **)*plVar2)(plVar2);
      if (uVar7 == 0xffffffff) {
        local_458 = 0xbd;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else if (uVar7 < 5) {
        if (uVar7 != 0) {
          if (uVar7 == 4) {
            *param_1 = aiStack_44c[4];
            return 1;
          }
          *param_1 = aiStack_44c[(int)uVar7];
          aiStack_44c[2] = aiStack_44c[(longlong)(int)uVar7 + 2];
        }
        param_1[1] = aiStack_44c[2];
      }
    }
  }
  return 1;
}

// ==== CMapManager::helper_1403982a0  @1403982a0  [medium:callgraph-r3]  (orig: FUN_1403982a0)
void FUN_1403982a0(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_140396bc0(uVar1,param_1[4],uVar2);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CMapManager::helper_140398c90  @140398c90  [medium:callgraph-r2]  (orig: FUN_140398c90)
undefined4 * FUN_140398c90(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar5 = (undefined8 *)0x0;
  *param_1 = 0;
  param_1[1] = 0;
  puVar1 = (undefined8 *)(param_1 + 2);
  puVar2 = operator_new(8);
  puVar3 = puVar5;
  if (puVar2 != (undefined8 *)0x0) {
    *puVar2 = puVar1;
    puVar3 = puVar2;
  }
  *puVar1 = puVar3;
  *(undefined8 *)(param_1 + 8) = 0;
  *(undefined8 *)(param_1 + 10) = 0;
  *(undefined8 *)(param_1 + 0xc) = 0;
  puVar3 = (undefined8 *)(param_1 + 0xe);
  puVar4 = operator_new(8);
  puVar2 = puVar5;
  if (puVar4 != (undefined8 *)0x0) {
    *puVar4 = puVar3;
    puVar2 = puVar4;
  }
  *puVar3 = puVar2;
  *(undefined8 *)(param_1 + 0x14) = 0;
  *(undefined8 *)(param_1 + 0x16) = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  puVar2 = (undefined8 *)(param_1 + 0x1a);
  puVar4 = operator_new(8);
  if (puVar4 != (undefined8 *)0x0) {
    *puVar4 = puVar2;
    puVar5 = puVar4;
  }
  *puVar2 = puVar5;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x22) = 0;
  *(undefined8 *)(param_1 + 0x24) = 0;
  param_1[0x32] = 0;
  param_1[0x33] = param_2;
  param_1[0x34] = param_3;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2e] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  FUN_1403982a0(puVar1);
  FUN_1403982a0(puVar3);
  FUN_140036640(puVar2);
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  return param_1;
}

// ==== CMapManager::helper_140399850  @140399850  [medium:callgraph-r1]  (orig: FUN_140399850)
undefined8
FUN_140399850(undefined4 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if ((DAT_1409761b0 & 1) == 0) {
    DAT_1409761b0 = DAT_1409761b0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761a8,"CPKQuarterFinals");
    atexit((_func_5014 *)&LAB_1406d6b80);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761a8,0xd8);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140398c90(pvVar1,param_1,param_2,param_4,uVar2);
  }
  return uVar2;
}

// ==== CMapManager::helper_1403abdb0  @1403abdb0  [medium:callgraph-r2]  (orig: FUN_1403abdb0)
undefined8
FUN_1403abdb0(longlong param_1,int param_2,int param_3,int param_4,uint param_5,int param_6,
             undefined4 param_7)

{
  int iVar1;
  uint uVar2;
  ulonglong uVar3;
  
  if ((param_2 < 1) || (0xb < param_2)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_3 < 0) || (999 < param_3)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_4 < 0) || (0x167 < param_4)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_2 == 1) || (param_3 == 0)) {
    param_2 = 1;
    param_3 = 0;
  }
  if (param_6 == 0) {
    *(int *)(param_1 + 0x10) = param_2;
    *(int *)(param_1 + 0x14) = param_3;
    *(int *)(param_1 + 0x18) = param_4;
    *(uint *)(param_1 + 0x1c) = param_5;
    *(undefined4 *)(param_1 + 0x20) = param_7;
  }
  *(int *)(param_1 + 0x38) = param_2;
  *(int *)(param_1 + 0x3c) = param_3;
  *(int *)(param_1 + 0x40) = param_4;
  *(uint *)(param_1 + 0x44) = param_5;
  if (((*(int *)(param_1 + 0x24) == 1) || (param_2 == 1)) ||
     ((*(int *)(param_1 + 0x24) == param_2 &&
      ((*(int *)(param_1 + 0x2c) == param_4 && (*(uint *)(param_1 + 0x30) == param_5)))))) {
    *(int *)(param_1 + 0x48) = param_3 - *(int *)(param_1 + 0x28);
  }
  else {
    param_5 = -*(int *)(param_1 + 0x28);
    *(uint *)(param_1 + 0x48) = param_5;
  }
  uVar3 = (ulonglong)param_5;
  if (param_6 == 0) {
    iVar1 = tq::RandGet(0x2bd);
    *(undefined4 *)(param_1 + 0x50) = param_7;
    uVar2 = iVar1 + 500;
    uVar3 = (ulonglong)uVar2;
    *(uint *)(param_1 + 0x4c) = uVar2;
    if (param_2 == 0xb) {
      uVar3 = (ulonglong)(uVar2 * 5);
      *(uint *)(param_1 + 0x4c) = uVar2 * 5;
    }
  }
  else {
    *(int *)(param_1 + 0x4c) = param_6;
    *(undefined4 *)(param_1 + 0x50) = param_7;
  }
  return CONCAT71((int7)(uVar3 >> 8),1);
}

// ==== CMapManager::helper_1403abf30  @1403abf30  [medium:callgraph-r2]  (orig: FUN_1403abf30)
int FUN_1403abf30(longlong param_1,int param_2)

{
  int iVar1;
  float fVar2;
  
  fVar2 = sqrtf(DAT_14076249c);
  iVar1 = (int)fVar2 + param_2;
  if (999 < (int)fVar2 + param_2) {
    iVar1 = 999;
  }
  iVar1 = (iVar1 * iVar1) / 1000;
  switch(*(undefined4 *)(param_1 + 0x24)) {
  case 1:
    break;
  case 2:
  case 4:
    return (iVar1 + 1) / 2;
  case 3:
    return (int)((iVar1 + 3 >> 0x1f & 3U) + iVar1 + 3) >> 2;
  case 5:
  case 6:
  case 7:
  case 8:
  case 9:
    return (iVar1 + 0x18) / 0x19;
  case 10:
    return (iVar1 + 0x1d) / 0x1e;
  case 0xb:
    return (iVar1 + 0x21) / 0x22;
  default:
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar1 = 0;
  }
  return iVar1;
}

// ==== CMapManager::helper_1403ac2e0  @1403ac2e0  [medium:callgraph-r2]  (orig: FUN_1403ac2e0)
void FUN_1403ac2e0(__uint64 param_1)

{
  if ((DAT_140976200 & 1) == 0) {
    DAT_140976200 = DAT_140976200 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761f8,"CWeather");
    atexit((_func_5014 *)&LAB_1406d6bd0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403ac335. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_1409761f8,param_1);
  return;
}

// ==== CMapManager::helper_1403ac490  @1403ac490  [medium:callgraph-r2]  (orig: FUN_1403ac490)
undefined8
FUN_1403ac490(longlong param_1,int param_2,int param_3,int param_4,undefined4 param_5,
             undefined4 param_6)

{
  undefined4 uVar1;
  int iVar2;
  
  if ((param_2 < 1) || (0xb < param_2)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_3 < 0) || (999 < param_3)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_4 < 0) || (0x167 < param_4)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if ((param_2 == 1) || (param_3 == 0)) {
    param_2 = 1;
    param_3 = 0;
  }
  *(int *)(param_1 + 0x10) = param_2;
  *(int *)(param_1 + 0x14) = param_3;
  *(undefined4 *)(param_1 + 0x1c) = param_5;
  *(undefined4 *)(param_1 + 0x20) = param_6;
  *(undefined4 *)(param_1 + 0x30) = param_5;
  *(int *)(param_1 + 0x18) = param_4;
  *(int *)(param_1 + 0x24) = param_2;
  *(int *)(param_1 + 0x28) = param_3;
  *(int *)(param_1 + 0x2c) = param_4;
  uVar1 = FUN_1403abf30(param_1,param_3);
  *(int *)(param_1 + 0x38) = param_2;
  *(int *)(param_1 + 0x3c) = param_3;
  *(int *)(param_1 + 0x40) = param_4;
  *(undefined4 *)(param_1 + 0x34) = uVar1;
  *(undefined4 *)(param_1 + 0x44) = param_5;
  *(undefined4 *)(param_1 + 0x48) = 0;
  iVar2 = tq::RandGet(0x2bd);
  *(undefined4 *)(param_1 + 0x50) = 10;
  iVar2 = iVar2 + 500;
  *(int *)(param_1 + 0x4c) = iVar2;
  if (param_2 == 0xb) {
    iVar2 = iVar2 * 5;
    *(int *)(param_1 + 0x4c) = iVar2;
  }
  return CONCAT71((uint7)(uint3)((uint)iVar2 >> 8),1);
}

// ==== CMapManager::helper_1403ac5f0  @1403ac5f0  [medium:callgraph-r1]  (orig: FUN_1403ac5f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403ac5f0(longlong param_1)

{
  uint uVar1;
  ulong uVar2;
  uint uVar3;
  int iVar4;
  ulonglong extraout_RAX;
  ulonglong uVar5;
  int iVar6;
  uint uVar7;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  int local_480;
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  uVar2 = tq::TimeGet(0);
  if (uVar2 / 1000 < *(int *)(param_1 + 0x58) + 1U) {
    return (ulonglong)uVar2 * 0x10624dd3 & 0xffffffff;
  }
  uVar2 = tq::TimeGet(0);
  uVar5 = (ulonglong)uVar2 * 0x10624dd3 & 0xffffffff;
  *(uint *)(param_1 + 0x58) = uVar2 / 1000;
  uVar1 = *(uint *)(param_1 + 0x24);
  iVar4 = *(int *)(param_1 + 0x28);
  iVar6 = *(int *)(param_1 + 0x34);
  uVar7 = *(uint *)(param_1 + 0x38);
  if (uVar1 == uVar7) {
    uVar3 = *(uint *)(param_1 + 0x10);
    uVar5 = (ulonglong)uVar3;
    if ((uVar7 == uVar3) && (uVar3 == 1)) {
      return 1;
    }
  }
  if (((uVar1 == 1) || (uVar7 == 1)) ||
     ((uVar1 == uVar7 &&
      ((uVar5 = (ulonglong)*(uint *)(param_1 + 0x40),
       *(uint *)(param_1 + 0x2c) == *(uint *)(param_1 + 0x40) &&
       (uVar5 = (ulonglong)*(uint *)(param_1 + 0x44),
       *(uint *)(param_1 + 0x30) == *(uint *)(param_1 + 0x44))))))) {
    if (uVar1 == uVar7) {
      if (*(int *)(param_1 + 0x4c) == 0) {
LAB_1403ac70a:
        iVar4 = tq::RandGet(100);
        if (iVar4 < 0x3c) {
          uVar7 = 1;
        }
        else {
          uVar7 = *(uint *)(param_1 + 0x10);
        }
        iVar4 = tq::RandGet(500);
        iVar6 = iVar4 + -0xfa + *(int *)(param_1 + 0x14);
        iVar4 = 1;
        if ((0 < iVar6) && (iVar4 = iVar6, 999 < iVar6)) {
          iVar4 = 999;
        }
        if ((uVar7 == uVar1) || (iVar6 = tq::RandGet(100), 4 < iVar6)) {
          iVar6 = *(int *)(param_1 + 0x40);
        }
        else {
          iVar6 = tq::RandGet(0x168);
        }
        local_480 = tq::RandGet(0x2bd);
        local_480 = local_480 + 500;
        if (uVar7 == 0xb) {
          local_480 = local_480 * 5;
        }
        local_478 = *(undefined4 *)(param_1 + 0x20);
        local_488 = *(undefined4 *)(param_1 + 0x1c);
        uVar5 = FUN_1403abdb0(param_1,uVar7,iVar4,iVar6);
        return uVar5;
      }
      uVar3 = *(int *)(param_1 + 0x4c) - 1;
      uVar5 = (ulonglong)uVar3;
      *(uint *)(param_1 + 0x4c) = uVar3;
      if ((int)uVar3 < 1) goto LAB_1403ac70a;
    }
    if ((uVar1 == 1) && (uVar7 != 1)) {
      *(uint *)(param_1 + 0x24) = uVar7;
      *(undefined4 *)(param_1 + 0x28) = 0;
      *(undefined4 *)(param_1 + 0x2c) = *(undefined4 *)(param_1 + 0x40);
      *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_1 + 0x44);
      uVar5 = (ulonglong)*(uint *)(param_1 + 0x3c);
      *(uint *)(param_1 + 0x48) = *(uint *)(param_1 + 0x3c);
    }
    if ((*(int *)(param_1 + 0x24) != 1) && (*(int *)(param_1 + 0x48) != 0)) {
      uVar7 = *(uint *)(param_1 + 0x3c);
      uVar5 = (ulonglong)uVar7;
      if (*(uint *)(param_1 + 0x28) != uVar7) {
        *(uint *)(param_1 + 0x28) = uVar7;
      }
    }
  }
  else {
    if (0 < *(int *)(param_1 + 0x48)) {
      local_488 = 200;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = extraout_RAX;
    }
    if ((*(int *)(param_1 + 0x48) != 0) && (*(int *)(param_1 + 0x28) != 0)) {
      *(undefined4 *)(param_1 + 0x28) = 0;
    }
  }
  if (*(int *)(param_1 + 0x28) != iVar4) {
    uVar5 = FUN_1403abf30(param_1);
    *(int *)(param_1 + 0x34) = (int)uVar5;
  }
  if ((*(uint *)(param_1 + 0x24) != uVar1) || (*(int *)(param_1 + 0x34) != iVar6)) {
    FUN_140456d30(local_458);
    local_488 = *(undefined4 *)(param_1 + 0x30);
    iVar4 = FUN_140456db0(local_458,*(undefined4 *)(param_1 + 0x24),*(undefined4 *)(param_1 + 0x34),
                          *(undefined4 *)(param_1 + 0x2c));
    if (iVar4 != 0) {
      (**(code **)**(undefined8 **)(param_1 + 8))(*(undefined8 **)(param_1 + 8),local_458,0);
    }
    uVar5 = FUN_140456d80(local_458);
  }
  if (((*(int *)(param_1 + 0x24) != 1) && (*(int *)(param_1 + 0x28) == 0)) &&
     (*(int *)(param_1 + 0x48) < 1)) {
    *(undefined4 *)(param_1 + 0x24) = 1;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  return uVar5;
}

// ==== CMapManager::helper_1404719f0  @1404719f0  [medium:callgraph-r1]  (orig: FUN_1404719f0)
bool FUN_1404719f0(longlong param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uVar6;
  longlong lVar7;
  undefined4 uVar8;
  bool bVar9;
  
  *(undefined4 *)(param_1 + 0x18) = param_3;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar9 = false;
  }
  else {
    *(longlong **)(param_1 + 0x10) = param_2;
    lVar7 = FUN_1403ac2e0(0x60);
    if (lVar7 == 0) {
      lVar7 = 0;
    }
    else {
      lVar7 = FUN_1403ac400(lVar7,param_1);
    }
    *(longlong *)(param_1 + 8) = lVar7;
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      bVar9 = false;
    }
    else {
      iVar2 = (**(code **)(*param_2 + 0x10))(param_2,9);
      uVar8 = 5;
      if (0 < iVar2) {
        uVar8 = 10;
      }
      uVar3 = (**(code **)(*param_2 + 0x10))(param_2,0xb);
      uVar4 = (**(code **)(*param_2 + 0x10))(param_2,10);
      uVar5 = (**(code **)(*param_2 + 0x10))(param_2,9);
      uVar6 = (**(code **)(*param_2 + 0x10))(param_2,8);
      cVar1 = FUN_1403ac490(*(undefined8 *)(param_1 + 8),uVar6,
                            (uVar5 ^ (int)uVar5 >> 0x1f) - ((int)uVar5 >> 0x1f),uVar4,uVar3,uVar8);
      bVar9 = cVar1 != '\0';
    }
  }
  return bVar9;
}

// ==== CMapManager::helper_140471bb0  @140471bb0  [medium:callgraph-r1]  (orig: FUN_140471bb0)
void FUN_140471bb0(__uint64 param_1)

{
  if ((DAT_140976478 & 1) == 0) {
    DAT_140976478 = DAT_140976478 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976470,"CWeatherRegion");
    atexit((_func_5014 *)&LAB_1406d6e80);
  }
                    /* WARNING: Could not recover jumptable at 0x000140471c05. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976470,param_1);
  return;
}

// ==== CMapManager::helper_140472480  @140472480  [medium:callgraph-r2]  (orig: FUN_140472480)
undefined8 * FUN_140472480(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IMultiObjSet<IMapThing>::vftable;
  *param_1 = CMultiObjSet<IMapThing>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CMapManager::helper_140472c00  @140472c00  [medium:callgraph-r1]  (orig: FUN_140472c00)
undefined8 FUN_140472c00(longlong param_1)

{
  undefined8 uVar1;
  void *pvVar2;
  longlong lVar3;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    pvVar2 = operator_new(0x40);
    if (pvVar2 == (void *)0x0) {
      lVar3 = 0;
    }
    else {
      lVar3 = FUN_140472480(pvVar2,0);
    }
    *(longlong *)(param_1 + 8) = lVar3;
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      *(undefined1 *)(param_1 + 0x10) = 1;
      uVar1 = 1;
    }
  }
  else {
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CMapManager::helper_1405090c0  @1405090c0  [medium:callgraph-r1]  (orig: FUN_1405090c0)
void FUN_1405090c0(undefined4 param_1,undefined8 param_2)

{
  code *UNRECOVERED_JUMPTABLE;
  
  UNRECOVERED_JUMPTABLE = (code *)FUN_140509380(&DAT_1409766a0,"CreateNewMapData");
  if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140509101. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(param_1,param_2);
  return;
}

