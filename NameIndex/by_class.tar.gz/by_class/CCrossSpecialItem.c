// ==== CCrossSpecialItem::helper_1401d3f70  @1401d3f70  [medium:callgraph-r3]  (orig: FUN_1401d3f70)
undefined8 *
FUN_1401d3f70(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CCrossSpecialItem::helper_1401d4050  @1401d4050  [medium:callgraph-r3]  (orig: FUN_1401d4050)
undefined8 *
FUN_1401d4050(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x58);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    puVar1[5] = param_5[2];
    puVar1[6] = param_5[3];
    puVar1[7] = param_5[4];
    puVar1[8] = param_5[5];
    puVar1[9] = param_5[6];
    *(undefined1 *)(puVar1 + 10) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x51) = 0;
  }
  return puVar1;
}

// ==== CCrossSpecialItem::helper_1401d4650  @1401d4650  [medium:callgraph-r2]  (orig: FUN_1401d4650)
undefined8 *
FUN_1401d4650(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1401d3f70(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d49d0  @1401d49d0  [medium:callgraph-r2]  (orig: FUN_1401d49d0)
undefined8 *
FUN_1401d49d0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x492492492492490 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1401d4050(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x50);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x51) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x51) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x50);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x50) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d5880  @1401d5880  [medium:callgraph-r2]  (orig: FUN_1401d5880)
longlong * FUN_1401d5880(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1401d59dd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1401d5a0c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1401d59dd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1401d4650(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1401d5a0c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d5be0  @1401d5be0  [medium:callgraph-r2]  (orig: FUN_1401d5be0)
longlong * FUN_1401d5be0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x51) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x51) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1401d5d3d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1401d5d6c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x51) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x51) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x51);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x51);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x51);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x51);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x51) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x51) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1401d5d3d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1401d49d0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1401d5d6c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d6000  @1401d6000  [medium:callgraph-r0]  (orig: FUN_1401d6000)
longlong * FUN_1401d6000(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d62d0  @1401d62d0  [medium:callgraph-r1]  (orig: FUN_1401d62d0)
undefined8 * FUN_1401d62d0(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1401d4650(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1401d4650(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1401d4650(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_1401d4650(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1401d4650(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1401d4650(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1401d4650(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1401d5880(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d6660  @1401d6660  [medium:callgraph-r1]  (orig: FUN_1401d6660)
undefined8 * FUN_1401d6660(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1401d49d0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1401d49d0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1401d49d0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x51) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x51) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x51);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x51);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x51);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x51);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x51) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x51) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x51) != '\0') {
              FUN_1401d49d0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1401d49d0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x51) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x51);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x51);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x51);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x51);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x51) != '\0') {
              FUN_1401d49d0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1401d49d0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1401d5be0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CCrossSpecialItem::helper_1401d6ad0  @1401d6ad0  [medium:callgraph-r1]  (orig: FUN_1401d6ad0)
void FUN_1401d6ad0(longlong param_1,uint param_2)

{
  int *piVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x70))[1];
  cVar2 = *(char *)((longlong)puVar8 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x70);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x51);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x70);
  local_30 = puVar4;
  local_38 = *(longlong *)(param_1 + 0x40);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x70);
    local_28 = *(longlong *)(param_1 + 0x40);
  }
  else {
    plVar7 = &local_38;
  }
  plVar3 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x70);
  local_18 = plVar3;
  local_10 = plVar7[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x40))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 == lVar9) {
    log_InlineLogERROR("CCrossSpecialItem::IncCount. GenerateType[%u] not found!");
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar1 = (int *)(lVar5 + 0x38);
    *piVar1 = *piVar1 + 1;
  }
  return;
}

// ==== CCrossSpecialItem::helper_1401d6dd0  @1401d6dd0  [medium:callgraph-r0]  (orig: FUN_1401d6dd0)
undefined8 * FUN_1401d6dd0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_1401d62d0(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CCrossSpecialItem::helper_1401d6f00  @1401d6f00  [medium:callgraph-r0]  (orig: FUN_1401d6f00)
undefined8 * FUN_1401d6f00(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  uint uStack_a4;
  uint local_98;
  uint uStack_84;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined1 local_68 [16];
  uint local_58 [2];
  longlong local_50;
  ulonglong local_40;
  undefined8 local_38;
  longlong local_30;
  undefined8 local_28;
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58[0] = *param_2;
    local_b8 = SUB84(plVar5,0);
    uStack_b4 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_b0 = SUB84(puVar3,0);
    uStack_ac = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_78 = local_b8;
    uStack_74 = uStack_b4;
    uStack_70 = uStack_b0;
    uStack_6c = uStack_ac;
    local_50 = (ulonglong)uStack_a4 << 0x20;
    local_40 = (ulonglong)local_98;
    local_38 = 0;
    local_30 = (ulonglong)uStack_84 << 0x20;
    local_28 = 0;
    puVar3 = (undefined8 *)FUN_1401d6660(param_1,local_68,&local_78,local_58);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CCrossSpecialItem::Create  @1401d7500  [high:log-string]  (orig: FUN_1401d7500)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401d7500(undefined8 *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  longlong *plVar6;
  undefined7 uVar13;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  ulonglong uVar12;
  ulonglong uVar14;
  ulonglong uVar15;
  longlong *plVar16;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  uint local_4a8 [2];
  longlong *local_4a0;
  undefined8 *local_498;
  undefined4 local_490;
  uint uStack_48c;
  uint local_488;
  int iStack_484;
  int local_480;
  undefined4 uStack_47c;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 local_470;
  undefined4 uStack_46c;
  undefined8 local_468;
  __time64_t local_460;
  longlong *local_458;
  longlong local_450;
  undefined8 local_448;
  char local_438 [1024];
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  local_498 = param_1;
  plVar6 = (longlong *)FUN_140006ad0(0x186a2,0);
  if (plVar6 == (longlong *)0x0) {
    uVar13 = 0;
  }
  else {
    local_4a0 = plVar6;
    _time64(&local_460);
    _localtime64(&local_460);
    plVar16 = (longlong *)0x0;
    local_4a8[0] = 0;
    plVar11 = plVar16;
    while( true ) {
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x40))(plVar6);
      if (plVar7 <= plVar11) break;
      (**(code **)(*plVar6 + 0x30))(plVar6,plVar11);
      local_458 = operator_new(0xc);
      plVar7 = plVar16;
      if (local_458 != (longlong *)0x0) {
        *(undefined4 *)local_458 = 0;
        *(undefined4 *)((longlong)local_458 + 4) = 0;
        *(undefined4 *)(local_458 + 1) = 0;
        plVar7 = local_458;
      }
      if (plVar7 != (longlong *)0x0) {
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,2);
        uVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
        *(undefined4 *)(plVar7 + 1) = uVar2;
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,3);
        uVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
        *(undefined4 *)plVar7 = uVar2;
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,4);
        uVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
        *(undefined4 *)((longlong)plVar7 + 4) = uVar2;
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_4b8 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar8 = plVar16;
        }
        lVar9 = (**(code **)(*plVar8 + 0x70))(plVar8,(int)plVar7[1]);
        if (lVar9 == 0) {
          log_InlineLogERROR("CCrossSpecialItem::Create(). ItemType[%u] not found!");
          operator_delete(plVar7);
        }
        else {
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0);
          local_4a8[0] = (**(code **)(*plVar8 + 0x40))(plVar8);
          puVar10 = (undefined8 *)FUN_1401d6dd0(param_1,local_4a8);
          *puVar10 = plVar7;
        }
      }
      local_4a8[0] = (int)plVar11 + 1;
      plVar11 = (longlong *)(ulonglong)local_4a8[0];
    }
    (**(code **)*plVar6)(plVar6);
    _snprintf(local_438,0x400,"SELECT * FROM cq_region WHERE type = %d");
    plVar6 = (longlong *)InstanceGet();
    plVar11 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_438,1);
    local_4a8[0] = 0;
    lVar9 = (**(code **)(*plVar11 + 0x40))(plVar11);
    plVar6 = plVar16;
    if (lVar9 != 0) {
      do {
        (**(code **)(*plVar11 + 0x30))(plVar11,plVar6);
        local_478 = 0;
        local_470 = 0;
        local_468 = 0;
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,1);
        uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
        local_490 = uVar2;
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,3);
        uVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
        uStack_48c = uVar3;
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,4);
        local_488 = (**(code **)(*plVar6 + 0x40))(plVar6);
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,5);
        iVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
        iStack_484 = iVar4;
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,6);
        local_480 = (**(code **)(*plVar6 + 0x40))(plVar6);
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,8);
        uStack_47c = (**(code **)(*plVar6 + 0x40))(plVar6);
        plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,9);
        uStack_474 = (**(code **)(*plVar6 + 0x40))(plVar6);
        uVar5 = *(uint *)((longlong)param_1 + 0x84);
        if ((uVar5 < 0xe) ||
           ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= (ulonglong)uVar5)) {
          local_4b8 = 0x379;
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar6 = plVar16;
        }
        else {
          plVar6 = (longlong *)((ulonglong)uVar5 * 0x850 + DAT_140975c20);
        }
        if (plVar6[0x13] == 0) {
          local_4b8 = 0x131;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar9 = (**(code **)(*(longlong *)plVar6[0x13] + 0x10))((longlong *)plVar6[0x13],uVar2,1);
        if (lVar9 == 0) {
          log_InlineLogERROR("CCrossSpecialItem::Create(). Can\'t find Map[%u] in cq_config");
        }
        else {
          uVar5 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x28))();
          if (((((uVar3 < uVar5) && (iVar4 != 0)) &&
               (uVar5 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x28))(), iVar4 + uVar3 < uVar5
               )) && ((uVar3 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x20))(),
                      iVar4 = local_480, uVar5 = local_488, local_488 < uVar3 && (local_480 != 0))))
             && (uVar3 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x20))(),
                iVar4 + uVar5 < uVar3)) {
            plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,10);
            uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
            local_4a0 = (longlong *)CONCAT44(local_4a0._4_4_,uVar2);
            FUN_1401d6000(param_1,&local_458,&local_4a0);
            plVar6 = local_458;
            lVar9 = param_1[6];
            if ((local_458 == (longlong *)0x0) || (local_458 != (longlong *)*param_1)) {
              _invalid_parameter_noinfo();
            }
            lVar1 = local_450;
            if (local_450 != lVar9) {
              if (plVar6 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar7 = plVar16;
              }
              else {
                plVar7 = (longlong *)*plVar6;
              }
              if (lVar1 == plVar7[6]) {
                _invalid_parameter_noinfo();
              }
              if (*(longlong *)(lVar1 + 0x20) != 0) {
                if (plVar6 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar6 = plVar16;
                }
                else {
                  plVar6 = (longlong *)*plVar6;
                }
                if (lVar1 == plVar6[6]) {
                  _invalid_parameter_noinfo();
                }
                local_468 = *(undefined8 *)(lVar1 + 0x20);
                plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,0);
                uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
                local_4a0 = (longlong *)CONCAT44(local_4a0._4_4_,uVar2);
                puVar10 = (undefined8 *)FUN_1401d6f00(param_1 + 8,&local_4a0);
                *puVar10 = CONCAT44(uStack_48c,local_490);
                puVar10[1] = CONCAT44(iStack_484,local_488);
                puVar10[2] = CONCAT44(uStack_47c,local_480);
                puVar10[3] = CONCAT44(uStack_474,local_478);
                puVar10[4] = CONCAT44(uStack_46c,local_470);
                puVar10[5] = local_468;
                goto LAB_1401d7ab9;
              }
            }
            log_InlineLogERROR("CCrossSpecialItem::Create(). Can\'t find ID[%u] in cq_config");
          }
          else {
            plVar6 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,0);
            (**(code **)(*plVar6 + 0x40))(plVar6);
            log_InlineLogERROR("CCrossSpecialItem::Create(). RegionID[%u] Map[%u] Region Error");
          }
        }
LAB_1401d7ab9:
        local_4a8[0] = local_4a8[0] + 1;
        plVar6 = (longlong *)(ulonglong)local_4a8[0];
        plVar7 = (longlong *)(**(code **)(*plVar11 + 0x40))(plVar11);
      } while (plVar6 < plVar7);
    }
    (**(code **)*plVar11)(plVar11);
    uVar15 = param_1[0xf];
    uVar14 = (uVar15 * 3) / 10;
    uVar12 = 5;
    if (5 < uVar14) {
      uVar12 = uVar14;
    }
    if (uVar12 < uVar15) {
      uVar15 = 5;
      if (5 < uVar14) {
        uVar15 = uVar14;
      }
      uVar2 = (undefined4)uVar15;
    }
    else {
      uVar2 = (undefined4)uVar15;
    }
    *(undefined4 *)(param_1 + 0x10) = uVar2;
    uVar13 = (undefined7)(uVar12 >> 8);
  }
  return CONCAT71(uVar13,1);
}

// ==== CCrossSpecialItem::helper_1401d8260  @1401d8260  [medium:callgraph-r0]  (orig: FUN_1401d8260)
void FUN_1401d8260(longlong param_1,undefined4 *param_2,longlong param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  int iVar5;
  int iVar6;
  int local_res8;
  int local_resc;
  undefined8 local_res20;
  
  FUN_1401d6d10(param_3);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x84));
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x98) + 0x10))
                    (*(longlong **)(lVar4 + 0x98),*param_2,1);
  if ((lVar4 != 0) && (iVar6 = param_2[5] - param_2[6], 0 < iVar6)) {
    local_res8 = 0;
    local_resc = 0;
    iVar5 = 0;
    if (0 < iVar6 * 2) {
      do {
        iVar2 = tq::RandGet(param_2[3]);
        iVar2 = iVar2 + param_2[1];
        local_res8 = iVar2;
        iVar3 = tq::RandGet(param_2[4]);
        iVar3 = iVar3 + param_2[2];
        local_resc = iVar3;
        cVar1 = FUN_1402c3cc0(lVar4,iVar2,iVar3);
        if (((cVar1 != '\0') && (cVar1 = FUN_1402c68a0(lVar4,0x18,iVar2,iVar3), cVar1 == '\0')) &&
           (cVar1 = FUN_1402c68a0(lVar4,0x19,iVar2,iVar3), cVar1 == '\0')) {
          local_res20 = 0;
          cVar1 = FUN_1402c8370(lVar4,iVar2,iVar3,0x1080,&local_res20);
          if (((cVar1 == '\0') && (cVar1 = FUN_1402c99b0(lVar4,iVar2,iVar3), cVar1 != '\0')) &&
             (FUN_1401d8190(param_3,&local_res8),
             iVar6 <= (int)(*(longlong *)(param_3 + 0x20) - *(longlong *)(param_3 + 0x18) >> 3))) {
            return;
          }
        }
        iVar5 = iVar5 + 1;
      } while (iVar5 < iVar6 * 2);
    }
  }
  return;
}

// ==== CCrossSpecialItem::OnTimer  @1401d8420  [high:log-string]  (orig: FUN_1401d8420)
void FUN_1401d8420(longlong param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  tm *ptVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  uint uVar12;
  longlong *plVar13;
  int iVar14;
  undefined8 *puVar15;
  int local_res10 [2];
  int local_res18;
  uint local_res20;
  longlong *local_78 [3];
  undefined8 *local_60;
  undefined8 *local_58;
  undefined8 local_50;
  
  _time32(local_res10);
  ptVar5 = _localtime32(local_res10);
  uVar12 = (ptVar5->tm_wday * 100 + ptVar5->tm_hour) * 100 + ptVar5->tm_min;
  iVar14 = 0;
  plVar13 = (longlong *)**(undefined8 **)(param_1 + 0x70);
  plVar1 = *(longlong **)(param_1 + 0x40);
  local_res20 = uVar12;
  do {
    plVar7 = *(longlong **)(param_1 + 0x70);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x40))) {
      _invalid_parameter_noinfo();
    }
    if (plVar13 == plVar7) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((((*(uint *)plVar13[9] <= uVar12) && (uVar12 <= ((uint *)plVar13[9])[1])) &&
        (*(uint *)((longlong)plVar13 + 0x3c) <= (uint)(local_res10[0] - (int)plVar13[8]))) &&
       (0 < *(int *)((longlong)plVar13 + 0x34) - (int)plVar13[7])) {
      *(int *)(plVar13 + 8) = local_res10[0];
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x84));
      plVar7 = (longlong *)FUN_1400876b0(uVar6);
      lVar8 = (**(code **)(*plVar7 + 0x10))(plVar7,(int)plVar13[4],1);
      if (lVar8 == 0) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar1;
        }
        if (plVar13 == *(longlong **)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        log_InlineLogERROR("CCrossSpecialItem::OnTimer(). Region[%u] Can\'t found Map[%u]");
      }
      else {
        local_res18 = iVar14 + 1;
        local_78[0] = operator_new(8);
        if (local_78[0] == (longlong *)0x0) {
          local_78[0] = (longlong *)0x0;
        }
        else {
          *local_78[0] = (longlong)local_78;
        }
        local_60 = (undefined8 *)0x0;
        local_58 = (undefined8 *)0x0;
        local_50 = 0;
        FUN_1401d8260(param_1,plVar13 + 4,local_78);
        puVar15 = local_60;
        plVar7 = local_78[0];
        if (local_58 < local_60) {
          _invalid_parameter_noinfo();
          plVar7 = local_78[0];
        }
        while( true ) {
          puVar2 = local_58;
          if (local_58 < local_60) {
            _invalid_parameter_noinfo();
          }
          if ((plVar7 == (longlong *)0x0) || (plVar7 != local_78[0])) {
            _invalid_parameter_noinfo();
          }
          iVar14 = local_res18;
          if (puVar15 == puVar2) break;
          lVar9 = FUN_14037c6e0(0xe8);
          if (lVar9 == 0) {
            lVar9 = 0;
          }
          else {
            lVar9 = FUN_14037d2d0(lVar9);
          }
          if (lVar9 != 0) {
            lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x84));
            if (*(longlong *)(lVar10 + 0x98) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar11 = *(longlong **)(lVar10 + 0x98);
            if (plVar7 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar7;
            }
            if (*(undefined8 **)(lVar10 + 0x20) <= puVar15) {
              _invalid_parameter_noinfo();
            }
            lVar10 = plVar13[9];
            uVar4 = (**(code **)(*plVar11 + 0x58))(plVar11);
            cVar3 = FUN_14037c800(lVar9,uVar4,lVar8,*puVar15,*(undefined4 *)(lVar10 + 8),0);
            if (cVar3 == '\0') {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar10 = 0;
              }
              else {
                lVar10 = *plVar1;
              }
              if (plVar13 == *(longlong **)(lVar10 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              log_InlineLogWARNING("CCrossSpecialItem::OnTimer: SpecialIndex[%u], item_type[%u].");
              (**(code **)(*(longlong *)(lVar9 + 0x10) + 8))();
            }
            else {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar10 = 0;
              }
              else {
                lVar10 = *plVar1;
              }
              if (plVar13 == *(longlong **)(lVar10 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              FUN_14037c4e0(lVar9,(int)plVar13[3]);
              uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x84));
              plVar11 = (longlong *)FUN_1400876b0(uVar6);
              plVar11 = (longlong *)(**(code **)(*plVar11 + 0x50))(plVar11);
              (**(code **)(*plVar11 + 0x20))(plVar11,lVar9);
            }
          }
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar7;
          }
          if (*(undefined8 **)(lVar9 + 0x20) <= puVar15) {
            _invalid_parameter_noinfo();
          }
          puVar15 = puVar15 + 1;
        }
        if (*(int *)(param_1 + 0x80) <= local_res18) {
          if (local_60 != (undefined8 *)0x0) {
            operator_delete(local_60);
          }
          local_60 = (undefined8 *)0x0;
          local_58 = (undefined8 *)0x0;
          local_50 = 0;
          operator_delete(local_78[0]);
          return;
        }
        if (local_60 != (undefined8 *)0x0) {
          operator_delete(local_60);
        }
        local_60 = (undefined8 *)0x0;
        local_58 = (undefined8 *)0x0;
        local_50 = 0;
        operator_delete(local_78[0]);
        uVar12 = local_res20;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar13 + 0x51) == '\0') {
      plVar7 = (longlong *)plVar13[2];
      if (*(char *)((longlong)plVar7 + 0x51) == '\0') {
        cVar3 = *(char *)(*plVar7 + 0x51);
        plVar13 = plVar7;
        plVar7 = (longlong *)*plVar7;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar7 + 0x51);
          plVar13 = plVar7;
          plVar7 = (longlong *)*plVar7;
        }
      }
      else {
        cVar3 = *(char *)(plVar13[1] + 0x51);
        plVar11 = (longlong *)plVar13[1];
        plVar7 = plVar13;
        while ((plVar13 = plVar11, cVar3 == '\0' && (plVar7 == (longlong *)plVar13[2]))) {
          cVar3 = *(char *)(plVar13[1] + 0x51);
          plVar11 = (longlong *)plVar13[1];
          plVar7 = plVar13;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CCrossSpecialItem::helper_14037c4e0  @14037c4e0  [medium:callgraph-r0]  (orig: FUN_14037c4e0)
void FUN_14037c4e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xe4) = param_2;
  lVar1 = DAT_140975bf8;
  if (DAT_140975bf8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1401d6ad0(lVar1,*(undefined4 *)(param_1 + 0xe4));
  return;
}

// ==== CCrossSpecialItem::helper_14037c800  @14037c800  [medium:callgraph-r0]  (orig: FUN_14037c800)
undefined8
FUN_14037c800(longlong *param_1,undefined4 param_2,longlong param_3,undefined8 param_4,int param_5,
             int param_6)

{
  ulong uVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  undefined4 local_res20;
  undefined4 uStackX_24;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar3 = (**(code **)(*plVar4 + 0x70))(plVar4,param_5);
  uVar5 = 0;
  if (lVar3 != 0) {
    *(undefined4 *)((longlong)param_1 + 0x94) = 0xb4;
    uVar1 = tq::TimeGet(0);
    param_1[0x14] = param_3;
    *(undefined4 *)(param_1 + 0x11) = 3;
    local_res20 = (undefined4)param_4;
    *(uint *)(param_1 + 0x13) = uVar1 / 1000;
    *(undefined4 *)(param_1 + 0x10) = local_res20;
    uStackX_24 = (undefined4)((ulonglong)param_4 >> 0x20);
    *(undefined4 *)((longlong)param_1 + 0x84) = uStackX_24;
    memset((void *)((longlong)param_1 + 0x1c),0,100);
    *(undefined4 *)(param_1 + 3) = param_2;
    *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0);
    uVar2 = (**(code **)(*plVar4 + 0x40))(plVar4);
    *(undefined4 *)((longlong)param_1 + 0x24) = 0;
    *(int *)(param_1 + 5) = param_6;
    *(undefined4 *)(param_1 + 4) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x15);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)((longlong)param_1 + 0x2c) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x16);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)(param_1 + 6) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x17);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)(param_1 + 7) = 0xfe;
    *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
    *(undefined4 *)((longlong)param_1 + 0x34) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x18);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)(param_1 + 8) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x19);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)((longlong)param_1 + 0x44) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x1a);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)(param_1 + 9) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x1b);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)((longlong)param_1 + 0x4c) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 8) + 0x10))(*(longlong **)(lVar3 + 8),0x1c);
    uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(undefined4 *)((longlong)param_1 + 0x7c) = 1;
    *(undefined4 *)(param_1 + 10) = uVar2;
    if (param_6 != 0) {
      *(undefined4 *)((longlong)param_1 + 0x8c) = 0x1e;
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x12) = uVar1 / 1000;
    }
    uVar5 = (**(code **)(*param_1 + 0x20))(param_1);
    FUN_1402c90f0(param_1[0x14],uVar5,0);
    FUN_14037c190(param_1);
    uVar5 = 1;
  }
  return uVar5;
}

