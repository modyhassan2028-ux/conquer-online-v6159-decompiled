// ==== CFamilyActor@adapter::helper_14008a6f0  @14008a6f0  [medium:callgraph-r0]  (orig: FUN_14008a6f0)
undefined1 FUN_14008a6f0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x3bc);
}

// ==== CFamilyActor@adapter::helper_1400a7810  @1400a7810  [medium:callgraph-r0]  (orig: FUN_1400a7810)
undefined4 FUN_1400a7810(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x3f0))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x3f0);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x3f0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x3c0);
  if (*(longlong *)(param_1 + 0x3c0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x3f0);
    local_28 = *(longlong *)(param_1 + 0x3c0);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x3f0);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x3c0))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CFamilyActor@adapter::helper_14014ed00  @14014ed00  [medium:callgraph-r1]  (orig: FUN_14014ed00)
undefined8 FUN_14014ed00(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014014ed47. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))();
  return uVar1;
}

// ==== CFamilyActor@adapter::helper_14014f9c0  @14014f9c0  [medium:callgraph-r3]  (orig: FUN_14014f9c0)
void FUN_14014f9c0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x31);
  while (cVar1 == '\0') {
    FUN_14014f6e0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x31);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CFamilyActor@adapter::helper_14014fb20  @14014fb20  [medium:callgraph-r3]  (orig: FUN_14014fb20)
undefined8 * FUN_14014fb20(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x31) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14014f100(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x31) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 6;
        plVar8 = plVar8 + 6;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14014fd0c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x31);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x31);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14014fd0c:
  if ((char)plVar2[6] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[6] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_14014f460(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(*plVar9 + 0x30) != '\x01') || (*(char *)(plVar9[2] + 0x30) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x30) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_14014f4c0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(plVar9[2] + 0x30) = 1;
              FUN_14014f460(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        else {
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_14014f4c0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(plVar9[2] + 0x30) != '\x01') || (*(char *)(*plVar9 + 0x30) != '\x01')) {
              if (*(char *)(*plVar9 + 0x30) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_14014f460(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(*plVar9 + 0x30) = 1;
              FUN_14014f4c0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 6) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CFamilyActor@adapter::helper_14014fee0  @14014fee0  [medium:callgraph-r2]  (orig: FUN_14014fee0)
undefined8 * FUN_14014fee0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  uint uVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  bool bVar7;
  
  puVar5 = (undefined8 *)param_1[6];
  puVar6 = puVar5;
  if (*(char *)((longlong)puVar5[1] + 0x31) == '\0') {
    uVar1 = *param_3;
    puVar4 = puVar5;
    puVar3 = (undefined8 *)puVar5[1];
    do {
      puVar5 = puVar3;
      bVar7 = *(uint *)(puVar5 + 3) < uVar1;
      if ((*(uint *)(puVar5 + 3) == uVar1) &&
         (bVar7 = *(uint *)((longlong)puVar5 + 0x1c) < param_3[1],
         *(uint *)((longlong)puVar5 + 0x1c) == param_3[1])) {
        bVar7 = *(int *)(puVar5 + 4) < (int)param_3[2];
      }
      if (bVar7) {
        puVar3 = (undefined8 *)puVar5[2];
        puVar5 = puVar4;
      }
      else {
        if (*(char *)((longlong)puVar6 + 0x31) != '\0') {
          bVar7 = uVar1 < *(uint *)(puVar5 + 3);
          if ((uVar1 == *(uint *)(puVar5 + 3)) &&
             (bVar7 = param_3[1] < *(uint *)((longlong)puVar5 + 0x1c),
             param_3[1] == *(uint *)((longlong)puVar5 + 0x1c))) {
            bVar7 = (int)param_3[2] < *(int *)(puVar5 + 4);
          }
          if (bVar7) {
            puVar6 = puVar5;
          }
        }
        puVar3 = (undefined8 *)*puVar5;
      }
      puVar4 = puVar5;
    } while (*(char *)((longlong)puVar3 + 0x31) == '\0');
  }
  if (*(char *)((longlong)puVar6 + 0x31) == '\0') {
    puVar3 = (undefined8 *)*puVar6;
  }
  else {
    puVar3 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar3 + 0x31) == '\0') {
    do {
      bVar7 = *param_3 < *(uint *)(puVar3 + 3);
      if ((*param_3 == *(uint *)(puVar3 + 3)) &&
         (bVar7 = param_3[1] < *(uint *)((longlong)puVar3 + 0x1c),
         param_3[1] == *(uint *)((longlong)puVar3 + 0x1c))) {
        bVar7 = (int)param_3[2] < *(int *)(puVar3 + 4);
      }
      if (bVar7) {
        puVar4 = (undefined8 *)*puVar3;
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined8 *)puVar3[2];
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x31) == '\0');
  }
  uVar2 = *param_1;
  *param_2 = uVar2;
  param_2[1] = puVar5;
  param_2[2] = uVar2;
  param_2[3] = puVar6;
  return param_2;
}

// ==== CFamilyActor@adapter::helper_140150220  @140150220  [medium:callgraph-r2]  (orig: FUN_140150220)
longlong * FUN_140150220(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14014f9c0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x31) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x31) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x31);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x31);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x31);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x31);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14014fb20(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CFamilyActor@adapter::helper_140150c00  @140150c00  [medium:callgraph-r1]  (orig: FUN_140150c00)
longlong FUN_140150c00(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14014fee0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x31) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x31) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x31);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x31);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x31);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x31);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140150220(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CFamilyActor@adapter::helper_140150d40  @140150d40  [medium:callgraph-r1]  (orig: FUN_140150d40)
longlong * FUN_140150d40(longlong *param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  bool bVar5;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x31) == '\0') {
    puVar2 = puVar3;
    puVar4 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar4;
      bVar5 = *(uint *)(puVar3 + 3) < *param_3;
      if ((*(uint *)(puVar3 + 3) == *param_3) &&
         (bVar5 = *(uint *)((longlong)puVar3 + 0x1c) < param_3[1],
         *(uint *)((longlong)puVar3 + 0x1c) == param_3[1])) {
        bVar5 = *(int *)(puVar3 + 4) < (int)param_3[2];
      }
      if (bVar5) {
        puVar4 = (undefined8 *)puVar3[2];
        puVar3 = puVar2;
      }
      else {
        puVar4 = (undefined8 *)*puVar3;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar4 + 0x31) == '\0');
  }
  puVar4 = (undefined8 *)param_1[6];
  local_20 = puVar3;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if (puVar3 != puVar4) {
    bVar5 = *param_3 < *(uint *)(puVar3 + 3);
    if ((*param_3 == *(uint *)(puVar3 + 3)) &&
       (bVar5 = param_3[1] < *(uint *)((longlong)puVar3 + 0x1c),
       param_3[1] == *(uint *)((longlong)puVar3 + 0x1c))) {
      bVar5 = (int)param_3[2] < *(int *)(puVar3 + 4);
    }
    if (!bVar5) {
      plVar1 = &local_28;
      goto LAB_140150e23;
    }
  }
  plVar1 = &local_18;
  local_10 = param_1[6];
  local_18 = *param_1;
LAB_140150e23:
  *param_2 = *plVar1;
  param_2[1] = plVar1[1];
  return param_2;
}

// ==== CFamilyActor@adapter::helper_1401511e0  @1401511e0  [medium:callgraph-r0]  (orig: FUN_1401511e0)
void FUN_1401511e0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  longlong *local_20;
  longlong local_18;
  
  local_30 = param_2;
  local_2c = param_3;
  local_28 = param_4;
  FUN_140150d40(&DAT_140975e00,&local_20,&local_30);
  lVar2 = DAT_140975e30;
  if ((local_20 == (longlong *)0x0) || (local_20 != DAT_140975e00)) {
    _invalid_parameter_noinfo();
  }
  if (local_18 != lVar2) {
    if (local_20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar2 = 0;
    }
    else {
      lVar2 = *local_20;
    }
    if (local_18 == *(longlong *)(lVar2 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar1 = *(undefined8 **)(local_18 + 0x28);
    if (puVar1 != (undefined8 *)0x0) {
      if (puVar1[2] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)puVar1[2] + 0x48))((longlong *)puVar1[2],0);
      }
      (**(code **)*puVar1)(puVar1,1);
    }
  }
  FUN_140150c00(&DAT_140975e00,&local_30);
  return;
}

// ==== CFamilyActor@adapter::helper_1401512e0  @1401512e0  [medium:callgraph-r1]  (orig: FUN_1401512e0)
undefined8
FUN_1401512e0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  longlong *local_18;
  longlong local_10;
  
  local_28 = param_2;
  local_24 = param_3;
  local_20 = param_4;
  FUN_140150d40(&DAT_140975e00,&local_18,&local_28);
  lVar1 = DAT_140975e30;
  if ((local_18 == (longlong *)0x0) || (local_18 != DAT_140975e00)) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined8 *)(local_10 + 0x28);
  }
  return 0;
}

// ==== CFamilyActor@adapter::helper_140151580  @140151580  [medium:callgraph-r0]  (orig: FUN_140151580)
longlong FUN_140151580(void)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = FUN_1401512e0();
  if (lVar2 != 0) {
    iVar1 = FUN_1403ac920(lVar2,4);
    return (longlong)iVar1;
  }
  return 0;
}

// ==== CFamilyActor@adapter::helper_1401515b0  @1401515b0  [medium:callgraph-r0]  (orig: FUN_1401515b0)
void FUN_1401515b0(longlong param_1,undefined4 param_2,int param_3,int param_4,longlong param_5)

{
  undefined4 uVar1;
  char cVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 local_40;
  int local_38;
  undefined4 local_28;
  int local_24;
  int local_20;
  undefined8 *local_18;
  
  if ((param_4 != 0) && (param_3 != 0)) {
    lVar3 = FUN_1401512e0();
    if (lVar3 == 0) {
      uVar1 = *(undefined4 *)(param_1 + 8);
      local_40 = FUN_1403aca40(0x18);
      if (local_40 == 0) {
        puVar5 = (undefined8 *)0x0;
      }
      else {
        puVar5 = (undefined8 *)FUN_1403ad160(local_40,uVar1);
      }
      if (puVar5 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar2 = FUN_1403ac8e0(puVar5);
        if (cVar2 == '\0') {
          (**(code **)*puVar5)(puVar5,1);
        }
        else {
          FUN_1403ac940(puVar5,1,param_2);
          FUN_1403ac940(puVar5,2,param_3);
          FUN_1403ac940(puVar5,3,param_4);
          FUN_1403acbf0(puVar5,4,param_5);
          FUN_14014ed00(puVar5);
          local_40 = CONCAT44(param_3,param_2);
          local_38 = param_4;
          local_28 = param_2;
          local_24 = param_3;
          local_20 = param_4;
          local_18 = puVar5;
          FUN_140150a00(&DAT_140975e00,&local_40,&local_28);
        }
      }
    }
    else {
      lVar4 = FUN_1403acbb0(lVar3,4);
      FUN_1403acbf0(lVar3,4,lVar4 + param_5,1);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::helper_140165750  @140165750  [medium:callgraph-r0]  (orig: FUN_140165750)
undefined4 FUN_140165750(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x123c);
}

// ==== CFamilyActor@adapter::helper_140188ec0  @140188ec0  [medium:callgraph-r0]  (orig: FUN_140188ec0)
undefined4 FUN_140188ec0(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x1100) != 0) {
    plVar1 = *(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1100) + 0x58) + 8);
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
    if ((uVar2 >> 0x34 & 1) != 0) {
      return 0;
    }
  }
  return *(undefined4 *)(param_1 + 0x1238);
}

// ==== CFamilyActor@adapter::helper_1401a9e10  @1401a9e10  [medium:callgraph-r1]  (orig: FUN_1401a9e10)
undefined8 FUN_1401a9e10(longlong *param_1,undefined1 param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  FUN_1401a6420(param_1,0x1b,0,param_2);
  FUN_140183c80(param_1,param_2);
  plVar3 = (longlong *)FUN_1401181a0();
  lVar1 = *plVar3;
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar1 + 0x40))(plVar3,uVar2);
  return 1;
}

// ==== CFamilyActor@adapter::helper_1401ad7e0  @1401ad7e0  [medium:callgraph-r0]  (orig: FUN_1401ad7e0)
void FUN_1401ad7e0(longlong param_1,int param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  
  uVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
  lVar2 = DAT_140975be0;
  if (DAT_140975be0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar2 = 0;
  }
  lVar2 = FUN_14014de60(lVar2,0,uVar1);
  if (lVar2 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),1);
    lVar2 = (**(code **)(*plVar3 + 0x58))(plVar3);
    lVar2 = lVar2 + SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar2),8);
    lVar4 = (lVar2 >> 6) - (lVar2 >> 0x3f);
    lVar2 = param_2 * lVar4;
    lVar2 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar2),8) + lVar2;
    FUN_1401a7e10(param_1,((lVar2 >> 6) - (lVar2 >> 0x3f)) + lVar4,0,0xa3d70a3d70a3d701);
  }
  return;
}

// ==== CFamilyActor@adapter::helper_1401c7f70  @1401c7f70  [medium:callgraph-r0]  (orig: FUN_1401c7f70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401c7f70(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  byte bVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined1 auStack_4d8 [32];
  uint local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  int local_498;
  int local_494 [3];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_494[1] = -2;
  local_494[2] = -1;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  lVar8 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar8 + 0x98) == 0) {
    local_4b8 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x98) + 0x20))
                    (*(longlong **)(lVar8 + 0x98),param_2,1);
  if (lVar8 != 0) {
    lVar9 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    if (lVar9 != 0) {
      uVar4 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      uVar5 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      cVar1 = FUN_1402c3cc0(lVar9,uVar5,uVar4);
      if (cVar1 != '\0') {
        plVar10 = *(longlong **)(*(longlong *)(lVar9 + 0x58) + 8);
        plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,4);
        bVar2 = (**(code **)(*plVar10 + 0x58))(plVar10);
        if ((bVar2 >> 2 & 1) == 0) {
          uVar4 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
          uVar5 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
          uVar6 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
          local_4b8 = 1;
          FUN_1401732e0(param_1,uVar6,uVar5,uVar4);
        }
      }
      local_494[0] = 0;
      local_498 = 0;
      FUN_1402c3fc0(lVar8,local_494,&local_498);
      if ((local_494[0] != 0) && (local_498 != 0)) {
        local_4b8 = local_4b8 & 0xffffff00;
        iVar7 = FUN_1401c55b0(param_1,param_2);
        if (iVar7 == 0) {
          FUN_140362560(local_488);
          uVar3 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
          uVar4 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
          uVar5 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
          uVar6 = (**(code **)(*param_1 + 8))(param_1);
          local_4a0 = 0;
          local_4a8 = 1;
          local_4b0 = 1000;
          local_4b8 = CONCAT22(local_4b8._2_2_,uVar3);
          iVar7 = FUN_140362620(local_488,uVar6,uVar5,uVar4);
          if (iVar7 != 0) {
            (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_488);
          }
          FUN_1401a9e10(param_1,1);
          FUN_1403625e0(local_488);
        }
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::helper_1401c81e0  @1401c81e0  [medium:callgraph-r0]  (orig: FUN_1401c81e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401c81e0(longlong *param_1)

{
  undefined2 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  undefined8 uVar9;
  undefined1 auStack_4e8 [32];
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  lVar6 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  if (lVar6 != 0) {
    plVar7 = *(longlong **)(*(longlong *)(lVar6 + 0x58) + 8);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
    uVar8 = (**(code **)(*plVar7 + 0x58))(plVar7);
    if ((uVar8 >> 0x11 & 1) != 0) {
      local_4c8._0_1_ = 0;
      iVar2 = FUN_1401c55b0(param_1,(int)param_1[0x1e1],*(undefined2 *)((longlong)param_1 + 0xf0c),
                            *(undefined2 *)((longlong)param_1 + 0xf0e));
      if (iVar2 != 0) {
        local_4a8 = 0;
        local_4a4 = 0;
        local_4a0 = 0;
        uVar9 = FUN_140008520((int)param_1[0x246]);
        uVar9 = FUN_1400d6610(uVar9);
        FUN_140006c50(uVar9,&local_4a8);
        local_4c8._0_1_ = 0;
        FUN_1401c55b0(param_1,local_4a8,local_4a4,local_4a0);
      }
      FUN_140362560(local_488);
      uVar1 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
      uVar3 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      uVar4 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      local_4b0 = 0;
      local_4b8 = 0;
      local_4c0 = 1000;
      local_4c8 = uVar1;
      iVar2 = FUN_140362620(local_488,uVar5,uVar4,uVar3);
      if (iVar2 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_488);
      }
      FUN_1403625e0(local_488);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::helper_1402c3fc0  @1402c3fc0  [medium:callgraph-r1]  (orig: FUN_1402c3fc0)
void FUN_1402c3fc0(longlong param_1,int *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
  iVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
  iVar6 = 0;
  while( true ) {
    iVar3 = tq::RandGet(iVar1 + -2);
    iVar4 = tq::RandGet(iVar2 + -2);
    iVar3 = iVar3 + 1;
    iVar4 = iVar4 + 1;
    if ((((-1 < iVar3) &&
         (iVar5 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))(), iVar3 < iVar5)) &&
        (-1 < iVar4)) &&
       ((iVar5 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))(), iVar4 < iVar5 &&
        (iVar5 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x18))
                           (*(longlong **)(param_1 + 0x60),iVar3,iVar4), iVar5 == 0)))) break;
    iVar6 = iVar6 + 1;
    if (9 < iVar6) {
      return;
    }
  }
  *param_2 = iVar3;
  *param_3 = iVar4;
  return;
}

// ==== CFamilyActor@adapter::helper_1403ac8e0  @1403ac8e0  [medium:callgraph-r1]  (orig: FUN_1403ac8e0)
ulonglong FUN_1403ac8e0(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001403ac8f1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))();
  return uVar1;
}

// ==== CFamilyActor@adapter::helper_1403ac940  @1403ac940  [medium:callgraph-r1]  (orig: FUN_1403ac940)
void FUN_1403ac940(longlong param_1,int param_2,undefined8 param_3,char param_4)

{
  if ((*(longlong *)(param_1 + 0x10) != 0) && (param_2 < 5)) {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x60))();
    if (param_4 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x70))();
    }
  }
  return;
}

// ==== CFamilyActor@adapter::helper_1403acbb0  @1403acbb0  [medium:callgraph-r1]  (orig: FUN_1403acbb0)
undefined8 FUN_1403acbb0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if ((*(longlong *)(param_1 + 0x10) != 0) && (param_2 < 5)) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x10) + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001403acbd6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CFamilyActor@adapter::helper_1403acbf0  @1403acbf0  [medium:callgraph-r1]  (orig: FUN_1403acbf0)
void FUN_1403acbf0(longlong param_1,int param_2,undefined8 param_3,char param_4)

{
  longlong *plVar1;
  
  if ((*(longlong *)(param_1 + 0x10) != 0) && (param_2 < 5)) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x10) + 8) + 0x10))();
    (**(code **)(*plVar1 + 0xa0))(plVar1,param_3);
    if (param_4 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x70))();
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_1  @1405b6540  [high:rtti-vtable]  (orig: FUN_1405b6540)
void FUN_1405b6540(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_0  @1405b6560  [high:rtti-vtable]  (orig: FUN_1405b6560)
undefined8 FUN_1405b6560(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b6590. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x18))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_1  @1405b65a0  [high:rtti-vtable]  (orig: FUN_1405b65a0)
undefined8 FUN_1405b65a0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x28))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b65bd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 8))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_2  @1405b65d0  [high:rtti-vtable]  (orig: FUN_1405b65d0)
undefined8 FUN_1405b65d0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b6600. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x70))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_4  @1405b6610  [high:rtti-vtable]  (orig: FUN_1405b6610)
undefined1 FUN_1405b6610(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      return *(undefined1 *)(lVar2 + 0xeee);
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_5  @1405b6650  [high:rtti-vtable]  (orig: FUN_1405b6650)
undefined8 FUN_1405b6650(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b667e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_3  @1405b6690  [high:rtti-vtable]  (orig: FUN_1405b6690)
undefined8 FUN_1405b6690(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b66be. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x60))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_6  @1405b66d0  [high:rtti-vtable]  (orig: FUN_1405b66d0)
undefined8 FUN_1405b66d0(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b670a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_7  @1405b6720  [high:rtti-vtable]  (orig: FUN_1405b6720)
undefined1 FUN_1405b6720(void)

{
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_9  @1405b6730  [high:rtti-vtable]  (orig: FUN_1405b6730)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b6730(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4,
                  undefined2 param_5)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_3 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if ((plVar2 != (longlong *)0x0) && (lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 != 0))
    {
      FUN_14015b240(local_478);
      local_498 = 1;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = 0;
      local_4b8 = param_5;
      local_4c8 = 0;
      local_4c0 = param_4;
      iVar1 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_3);
      if (iVar1 == 0) {
        FUN_14015b2c0(local_478);
      }
      else {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
        FUN_14015b2c0(local_478);
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_13  @1405b6830  [high:rtti-vtable]  (orig: FUN_1405b6830)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b6830(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4,
                  undefined2 param_5)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_3 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if ((plVar2 != (longlong *)0x0) && (lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 != 0))
    {
      FUN_14015b240(local_478);
      local_498 = 1;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = 0;
      local_4b8 = param_5;
      local_4c8 = 0;
      local_4c0 = param_4;
      iVar1 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_3);
      if (iVar1 == 0) {
        FUN_14015b2c0(local_478);
      }
      else {
        plVar2 = (longlong *)(**(code **)(*(longlong *)(lVar3 + 0x10) + 0x160))();
        if (plVar2 == (longlong *)0x0) {
          local_4c8 = CONCAT44(local_4c8._4_4_,0x1ac);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*plVar2 + 0x38))(plVar2,local_478,0);
        }
        FUN_14015b2c0(local_478);
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_17  @1405b6970  [high:rtti-vtable]  (orig: FUN_1405b6970)
undefined8 FUN_1405b6970(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b699e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_18  @1405b69b0  [high:rtti-vtable]  (orig: FUN_1405b69b0)
undefined8 FUN_1405b69b0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b69de. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_29  @1405b69f0  [high:rtti-vtable]  (orig: FUN_1405b69f0)
void FUN_1405b69f0(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (((plVar4 != (longlong *)0x0) &&
      (plVar4 = (longlong *)(**(code **)(*plVar4 + 0x2b0))(plVar4), plVar4 != (longlong *)0x0)) &&
     (plVar5 = (longlong *)FUN_140118320(), plVar5 != (longlong *)0x0)) {
    lVar1 = *plVar5;
    uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
    iVar3 = (**(code **)(lVar1 + 0x28))(plVar5,uVar2);
    if (iVar3 != 0) {
      (**(code **)(*plVar5 + 0xb0))(plVar5,iVar3);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_20  @1405b6a70  [high:rtti-vtable]  (orig: FUN_1405b6a70)
bool FUN_1405b6a70(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  return lVar1 != 0;
}

// ==== CFamilyActor@adapter::vfunc_19  @1405b6a90  [high:rtti-vtable]  (orig: FUN_1405b6a90)
bool FUN_1405b6a90(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x28))();
  return lVar1 != 0;
}

// ==== CFamilyActor@adapter::vfunc_21  @1405b6ab0  [high:rtti-vtable]  (orig: FUN_1405b6ab0)
undefined1 FUN_1405b6ab0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      return *(undefined1 *)(lVar2 + 0x12c8);
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_22  @1405b6af0  [high:rtti-vtable]  (orig: FUN_1405b6af0)
void FUN_1405b6af0(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4,
                  undefined4 param_5,undefined8 param_6)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x11);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x50))(plVar1,param_2,param_3,param_5,param_6,param_4);
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_23  @1405b6b60  [high:rtti-vtable]  (orig: FUN_1405b6b60)
void FUN_1405b6b60(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                     (*(longlong **)(param_1 + 0x10),param_3);
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_14018f460(lVar2,param_2,0,0);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_24  @1405b6bb0  [high:rtti-vtable]  (orig: FUN_1405b6bb0)
void FUN_1405b6bb0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140194940(lVar2,param_3,param_4,0);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_25  @1405b6c00  [high:rtti-vtable]  (orig: FUN_1405b6c00)
undefined8 FUN_1405b6c00(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      uVar3 = FUN_140188ec0(lVar2);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_26  @1405b6c40  [high:rtti-vtable]  (orig: FUN_1405b6c40)
undefined8 FUN_1405b6c40(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      uVar3 = FUN_140165750(lVar2);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_27  @1405b6c80  [high:rtti-vtable]  (orig: FUN_1405b6c80)
undefined8 FUN_1405b6c80(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      uVar3 = FUN_140188830(lVar2);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_28  @1405b6cc0  [high:rtti-vtable]  (orig: FUN_1405b6cc0)
undefined8 FUN_1405b6cc0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b6cf0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x168))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_31  @1405b6d00  [high:rtti-vtable]  (orig: FUN_1405b6d00)
ulonglong FUN_1405b6d00(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (*(longlong *)(param_1 + 0x20) != 0) {
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x20) + 8))();
    return uVar1;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFamilyActor@adapter::vfunc_32  @1405b6d40  [high:rtti-vtable]  (orig: FUN_1405b6d40)
ulonglong FUN_1405b6d40(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (*(longlong *)(param_1 + 0x20) != 0) {
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))();
    return uVar1;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFamilyActor@adapter::vfunc_33  @1405b6d80  [high:rtti-vtable]  (orig: FUN_1405b6d80)
ulonglong FUN_1405b6d80(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (*(longlong *)(param_1 + 0x20) != 0) {
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x20) + 0x18))();
    return uVar1;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFamilyActor@adapter::vfunc_40  @1405b6dc0  [high:rtti-vtable]  (orig: FUN_1405b6dc0)
void FUN_1405b6dc0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if ((plVar2 == (longlong *)0x0) ||
     ((lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 != 0 &&
      (iVar1 = FUN_14034a8d0(lVar3,param_3,0,1,1,0,1), iVar1 == 0)))) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_41  @1405b6e60  [high:rtti-vtable]  (orig: FUN_1405b6e60)
void FUN_1405b6e60(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001405b6e67. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x58))();
  return;
}

// ==== CFamilyActor@adapter::vfunc_42  @1405b6e70  [high:rtti-vtable]  (orig: FUN_1405b6e70)
void FUN_1405b6e70(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401ad7e0(lVar2,param_3);
  return;
}

// ==== CFamilyActor@adapter::vfunc_43  @1405b6f10  [high:rtti-vtable]  (orig: FUN_1405b6f10)
undefined8 FUN_1405b6f10(longlong param_1)

{
  uint uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x70))(lVar3 + 0x10);
    if (uVar1 < DAT_14094da38) {
      return 1;
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_45  @1405b6fb0  [high:rtti-vtable]  (orig: FUN_1405b6fb0)
undefined8 FUN_1405b6fb0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 local_res8;
  
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar6 = (**(code **)(*plVar5 + 0x2b0))(plVar5);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x88))
                       (*(longlong **)(param_1 + 0x10),param_3);
    if (plVar5 != (longlong *)0x0) {
      plVar7 = (longlong *)(lVar6 + 0x10);
      lVar6 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x160))(plVar7);
      local_res8 = 0;
      if (lVar6 != 0) {
        uVar2 = (**(code **)(*plVar5 + 8))(plVar5);
        uVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
        uVar4 = (**(code **)(*plVar7 + 0x40))(plVar7);
        cVar1 = FUN_1402c84c0(lVar6,uVar4,uVar3,0x1040,uVar2,&local_res8);
        if (cVar1 != '\0') {
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_47  @1405b70f0  [high:rtti-vtable]  (orig: FUN_1405b70f0)
void FUN_1405b70f0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x88))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar4 != 0) {
    if (*(longlong *)(lVar4 + 0x60) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    iVar1 = (**(code **)(**(longlong **)(lVar4 + 0x60) + 0x10))(*(longlong **)(lVar4 + 0x60),0x13);
    if (iVar1 != 0) {
      FUN_1401c7f70(lVar3,iVar1);
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_48  @1405b7220  [high:rtti-vtable]  (orig: FUN_1405b7220)
undefined8 FUN_1405b7220(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong *local_res8 [4];
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  local_res8[0] = (longlong *)0x0;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,local_res8);
    if ((cVar1 != '\0') && ((char)local_res8[0][0xd] != '\0')) {
      iVar2 = (**(code **)(*(longlong *)local_res8[0][0xc] + 0x10))
                        ((longlong *)local_res8[0][0xc],4);
      if (iVar2 == 0x1f) {
        iVar2 = (**(code **)(*local_res8[0] + 8))();
        if (iVar2 == param_2) {
          uVar4 = FUN_140087360(local_res8[0]);
          return uVar4;
        }
      }
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_49  @1405b72b0  [high:rtti-vtable]  (orig: FUN_1405b72b0)
void FUN_1405b72b0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_1401c81e0(lVar2);
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_50  @1405b7310  [high:rtti-vtable]  (orig: FUN_1405b7310)
void FUN_1405b7310(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001405b7317. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x60))();
  return;
}

// ==== CFamilyActor@adapter::vfunc_51  @1405b7320  [high:rtti-vtable]  (orig: FUN_1405b7320)
void FUN_1405b7320(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001405b7327. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x68))();
  return;
}

// ==== CFamilyActor@adapter::vfunc_55  @1405b7330  [high:rtti-vtable]  (orig: FUN_1405b7330)
ulonglong FUN_1405b7330(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b736b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x280))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFamilyActor@adapter::vfunc_0  @1405b7380  [high:rtti-vtable]  (orig: FUN_1405b7380)
void FUN_1405b7380(longlong param_1)

{
  FUN_1405b7430(param_1 + -8);
  return;
}

// ==== CFamilyActor@adapter::helper_1405b7390  @1405b7390  [medium:callgraph-r0]  (orig: FUN_1405b7390)
uint FUN_1405b7390(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
  return (uint)(uVar2 >> 0x13) & 1;
}

// ==== CFamilyActor@adapter::helper_1405b7430  @1405b7430  [medium:callgraph-r0]  (orig: FUN_1405b7430)
undefined8 * FUN_1405b7430(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CFamilyActor::vftable;
  param_1[1] = adapter::CFamilyActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFamilyActor@adapter::vfunc_8  @1405b7480  [high:rtti-vtable]  (orig: FUN_1405b7480)
void FUN_1405b7480(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0,uVar4);
      if (puVar3 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_12  @1405b7550  [high:rtti-vtable]  (orig: FUN_1405b7550)
void FUN_1405b7550(longlong param_1,undefined8 param_2,longlong param_3,int param_4)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x348))
                  ((longlong *)(lVar2 + 0x10),puVar3,param_4 == 0);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_14  @1405b7610  [high:rtti-vtable]  (orig: FUN_1405b7610)
void FUN_1405b7610(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        plVar1 = (longlong *)(**(code **)(*(longlong *)(lVar2 + 0x10) + 0x160))();
        if (plVar1 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*plVar1 + 0x38))(plVar1,puVar3,0);
        }
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_30  @1405b7700  [high:rtti-vtable]  (orig: FUN_1405b7700)
void FUN_1405b7700(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a9d0(uVar1,param_2,param_4,param_3);
  return;
}

// ==== CFamilyActor@adapter::vfunc_34  @1405b7740  [high:rtti-vtable]  (orig: FUN_1405b7740)
void FUN_1405b7740(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a6c0(uVar1);
  return;
}

// ==== CFamilyActor@adapter::vfunc_35  @1405b7760  [high:rtti-vtable]  (orig: FUN_1405b7760)
void FUN_1405b7760(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4,
                  undefined8 param_5,undefined8 param_6,undefined8 param_7,undefined8 param_8,
                  undefined8 param_9)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x40))
            (*(longlong **)(lVar1 + 0x88),param_2,param_3,param_4,param_5,param_6,param_7,param_8,
             param_9);
  return;
}

// ==== CFamilyActor@adapter::vfunc_36  @1405b7830  [high:rtti-vtable]  (orig: FUN_1405b7830)
void FUN_1405b7830(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b78b1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x48))
            (*(longlong **)(lVar1 + 0x88),param_2,param_3,param_4);
  return;
}

// ==== CFamilyActor@adapter::vfunc_37  @1405b78c0  [high:rtti-vtable]  (orig: FUN_1405b78c0)
void FUN_1405b78c0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b7921. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x50))(*(longlong **)(lVar1 + 0x88),param_2);
  return;
}

// ==== CFamilyActor@adapter::vfunc_38  @1405b7930  [high:rtti-vtable]  (orig: FUN_1405b7930)
void FUN_1405b7930(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xd0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1401515b0(*(undefined8 *)(lVar1 + 0xd0),param_2,param_3,4,param_4);
  return;
}

// ==== CFamilyActor@adapter::vfunc_39  @1405b79c0  [high:rtti-vtable]  (orig: FUN_1405b79c0)
ulonglong FUN_1405b79c0(longlong param_1,undefined8 param_2,int param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar3 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    uVar2 = 0;
    if (lVar3 != 0) {
      if ((0 < param_3) &&
         (0x28 < (ulonglong)
                 ((*(longlong *)(lVar3 + 0xc28) - *(longlong *)(lVar3 + 0xc20) >> 2) +
                 (longlong)param_3))) {
        return 0;
      }
      return 1;
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CFamilyActor@adapter::vfunc_44  @1405b7a50  [high:rtti-vtable]  (orig: FUN_1405b7a50)
undefined8 FUN_1405b7a50(longlong param_1,int param_2)

{
  undefined8 uVar1;
  
  if (param_2 - 13000U < 1000) {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar1 = FUN_1400a7810(uVar1,param_2);
    return uVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_46  @1405b7ab0  [high:rtti-vtable]  (orig: FUN_1405b7ab0)
void FUN_1405b7ab0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a6f0(uVar1);
  return;
}

// ==== CFamilyActor@adapter::vfunc_52  @1405b7ad0  [high:rtti-vtable]  (orig: FUN_1405b7ad0)
undefined8 FUN_1405b7ad0(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar3 == (longlong *)0x0) {
    return 0;
  }
  lVar4 = (**(code **)(*plVar3 + 0x2b0))(plVar3);
  if (((lVar4 != 0) && (iVar2 = FUN_140166ec0(lVar4), iVar2 == 0)) &&
     (cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10), cVar1 != '\0')) {
    lVar4 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x160))(lVar4 + 0x10);
    if ((lVar4 != 0) && (cVar1 = FUN_1405b7390(lVar4), cVar1 != '\0')) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_53  @1405b7b60  [high:rtti-vtable]  (orig: FUN_1405b7b60)
void FUN_1405b7b60(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xd0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140151580(*(undefined8 *)(lVar1 + 0xd0),param_3,param_2,4);
  return;
}

// ==== CFamilyActor@adapter::vfunc_54  @1405b7be0  [high:rtti-vtable]  (orig: FUN_1405b7be0)
void FUN_1405b7be0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xd0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1401511e0(*(undefined8 *)(lVar1 + 0xd0),param_3,param_2,4);
  return;
}

// ==== CFamilyActor@adapter::vfunc_16  @1405b7c60  [high:rtti-vtable]  (orig: FUN_1405b7c60)
void FUN_1405b7c60(longlong param_1,longlong param_2,int param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(ushort *)(param_2 + 8) - 4,0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    if (((param_3 == 0) ||
        (plVar2 = (longlong *)
                  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                            (*(longlong **)(param_1 + 0x10),param_3), plVar2 == (longlong *)0x0)) ||
       (lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2), lVar3 == 0)) {
      uVar4 = 0xffffffff;
    }
    else {
      uVar4 = *(undefined4 *)(lVar3 + 0x122c);
    }
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 0x68))(plVar2,puVar1,uVar4);
    (**(code **)*puVar1)(puVar1,1);
    return;
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_15  @1405b7d20  [high:rtti-vtable]  (orig: FUN_1405b7d20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b7d20(longlong param_1,longlong param_2,undefined4 param_3,undefined2 param_4)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_498 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4d8 = 0;
    local_4d0 = param_3;
    local_4c8 = param_4;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 != 0) {
      plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar2 + 0x68))(plVar2,local_488,0xffffffff);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CFamilyActor@adapter::vfunc_56  @1405b7df0  [high:rtti-vtable]  (orig: FUN_1405b7df0)
undefined4 FUN_1405b7df0(longlong param_1,char *param_2)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  
  if (param_2 != (char *)0x0) {
    iVar3 = tq::NameStrCheck(param_2,false);
    if (iVar3 != 0) {
      uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      cVar2 = FUN_14008a1d0(uVar1,param_2,0);
      if (cVar2 == '\0') {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_57  @1405b7e50  [high:rtti-vtable]  (orig: FUN_1405b7e50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405b7e50(longlong param_1,int param_2,undefined4 param_3,char *param_4,undefined4 param_5,
             undefined4 param_6)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_88 [32];
  int *local_68;
  int local_58;
  undefined4 local_54;
  undefined1 local_50;
  char local_4f [39];
  undefined4 local_28;
  undefined4 local_24;
  undefined1 local_20;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  if (param_2 == 0) {
    local_68 = (int *)CONCAT44(local_68._4_4_,0x457);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else if (param_4 == (char *)0x0) {
    local_68 = (int *)CONCAT44(local_68._4_4_,0x458);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    local_4f[0] = '\0';
    local_4f[1] = '\0';
    local_4f[2] = '\0';
    local_4f[3] = '\0';
    local_4f[4] = '\0';
    local_4f[5] = '\0';
    local_4f[6] = '\0';
    local_4f[7] = '\0';
    local_4f[8] = '\0';
    local_4f[9] = '\0';
    local_4f[10] = '\0';
    local_4f[0xb] = '\0';
    local_4f[0xc] = '\0';
    local_4f[0xd] = '\0';
    local_4f[0xe] = '\0';
    local_4f[0xf] = '\0';
    local_4f[0x10] = '\0';
    local_4f[0x11] = '\0';
    local_4f[0x12] = '\0';
    local_4f[0x13] = '\0';
    local_4f[0x14] = '\0';
    local_4f[0x15] = '\0';
    local_4f[0x16] = '\0';
    local_4f[0x17] = '\0';
    local_4f[0x18] = '\0';
    local_4f[0x19] = '\0';
    local_4f[0x1a] = '\0';
    local_4f[0x1b] = '\0';
    local_4f[0x1c] = '\0';
    local_4f[0x1d] = '\0';
    local_4f[0x1e] = '\0';
    local_4f[0x1f] = '\0';
    local_4f[0x20] = '\0';
    local_4f[0x21] = '\0';
    local_4f[0x22] = '\0';
    local_4f[0x23] = '\0';
    local_28 = param_5;
    local_20 = 0;
    local_24 = param_6;
    local_50 = 1;
    local_58 = param_2;
    local_54 = param_3;
    tq::SafeCopy(local_4f,param_4,0x24);
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar3 = *(longlong **)(lVar2 + 0x80);
    if (plVar3 == (longlong *)0x0) {
      local_68 = (int *)CONCAT44(local_68._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    local_68 = &local_58;
    (**(code **)(*plVar3 + 0x50))(plVar3,4,0xc354,0x3c);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CFamilyActor@adapter::vfunc_58  @1405b7fb0  [high:rtti-vtable]  (orig: FUN_1405b7fb0)
uint FUN_1405b7fb0(longlong param_1)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 != 0) {
      uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x168))();
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar2 = (longlong *)FUN_1400876b0(uVar4);
      lVar3 = (**(code **)(*plVar2 + 0x10))(plVar2,uVar1,1);
      if (lVar3 != 0) {
        plVar2 = *(longlong **)(*(longlong *)(lVar3 + 0x58) + 8);
        plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
        uVar5 = (**(code **)(*plVar2 + 0x58))(plVar2);
        return (uint)(uVar5 >> 0x13) & 1;
      }
    }
  }
  return 0;
}

// ==== CFamilyActor@adapter::vfunc_11  @1405b8050  [high:rtti-vtable]  (orig: FUN_1405b8050)
void FUN_1405b8050(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58 [3];
  undefined4 *local_40;
  undefined4 *local_38;
  longlong local_30;
  
  local_res20 = operator_new(8);
  local_58[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_58;
    local_58[0] = local_res20;
  }
  local_40 = (undefined4 *)0x0;
  local_38 = (undefined4 *)0x0;
  local_30 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar4 + 0x38))(plVar4,local_58,param_3);
      if (local_40 != (undefined4 *)0x0) {
        operator_delete(local_40);
      }
      local_40 = (undefined4 *)0x0;
      local_38 = (undefined4 *)0x0;
      local_30 = 0;
      operator_delete(local_58[0]);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                       (*(longlong **)(param_1 + 0x10),*puVar9);
    if ((plVar4 != (longlong *)0x0) &&
       (lVar5 = (**(code **)(*plVar4 + 0x2b0))(plVar4), puVar2 = local_38, lVar5 != 0)) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar5 + 0x122c));
      if (local_40 != (undefined4 *)0x0) {
        uVar7 = local_30 - (longlong)local_40 >> 2;
      }
      if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar7) {
        *local_38 = *(undefined4 *)(lVar5 + 0x122c);
        local_38 = local_38 + 1;
      }
      else {
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_40;
        plVar4 = local_58[0];
        if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
          lVar5 = 0;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          if ((plVar4 == (longlong *)0x0) || (plVar4 != local_58[0])) {
            _invalid_parameter_noinfo();
          }
          lVar5 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_78 = SUB84(plVar4,0);
        uStack_74 = (undefined4)((ulonglong)plVar4 >> 0x20);
        uStack_70 = SUB84(puVar2,0);
        uStack_6c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_68 = local_78;
        uStack_64 = uStack_74;
        uStack_60 = uStack_70;
        uStack_5c = uStack_6c;
        FUN_140036c20(local_58,&local_68,1,&local_res20);
        puVar2 = local_40;
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        plVar4 = local_58[0];
        if (local_58[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *local_58[0];
        }
        if (puVar2 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
          if (plVar4 == (longlong *)0x0) {
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar4;
          }
          if (*(undefined4 **)(lVar6 + 0x18) <= puVar2 + lVar5) goto LAB_1405b8272;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_1405b8272:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

// ==== CFamilyActor@adapter::vfunc_10  @1405b8300  [high:rtti-vtable]  (orig: FUN_1405b8300)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b8300(longlong param_1,undefined8 *param_2,undefined8 param_3,undefined4 param_4,
                  undefined2 param_5)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined4 *puVar9;
  longlong *plVar10;
  undefined1 auStack_578 [32];
  undefined8 local_558;
  undefined4 local_550;
  undefined2 local_548;
  undefined2 local_540;
  undefined4 local_538;
  undefined4 local_530;
  undefined1 local_528;
  longlong *local_518 [3];
  undefined4 *local_500;
  undefined4 *local_4f8;
  longlong local_4f0;
  longlong *local_4e8 [2];
  undefined8 local_4d8;
  undefined8 uStack_4d0;
  undefined8 local_4c8;
  undefined4 local_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined1 local_4a8 [1104];
  ulonglong local_58;
  
  local_4c8 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  FUN_14015b240(local_4a8);
  plVar8 = (longlong *)0x0;
  local_528 = 1;
  local_530 = 0;
  local_538 = 0;
  local_540 = 0;
  local_548 = param_5;
  local_558 = 0;
  local_550 = param_4;
  iVar4 = FUN_14015b300(local_4a8,"SYSTEM","ALLUSERS",param_3);
  if (iVar4 == 0) {
    local_558 = CONCAT44(local_558._4_4_,299);
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_14015b2c0(local_4a8);
  }
  else {
    local_4e8[0] = operator_new(8);
    local_518[0] = plVar8;
    if (local_4e8[0] != (longlong *)0x0) {
      *local_4e8[0] = (longlong)local_518;
      local_518[0] = local_4e8[0];
    }
    local_500 = (undefined4 *)0x0;
    local_4f8 = (undefined4 *)0x0;
    local_4f0 = 0;
    puVar9 = (undefined4 *)param_2[3];
    local_4d8 = local_4e8[0];
    if ((undefined4 *)param_2[4] < puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar1 = (undefined8 *)*param_2;
    while( true ) {
      puVar2 = (undefined4 *)param_2[4];
      if (puVar2 < (undefined4 *)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      if ((puVar1 == (undefined8 *)0x0) || (puVar1 != (undefined8 *)*param_2)) {
        _invalid_parameter_noinfo();
      }
      if (puVar9 == puVar2) break;
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar5 = plVar8;
      }
      else {
        plVar5 = (longlong *)*puVar1;
      }
      if ((undefined4 *)plVar5[4] <= puVar9) {
        _invalid_parameter_noinfo();
      }
      plVar5 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))
                         (*(longlong **)(param_1 + 0x10),*puVar9);
      if ((plVar5 != (longlong *)0x0) &&
         (lVar6 = (**(code **)(*plVar5 + 0x2b0))(plVar5), puVar2 = local_4f8, lVar6 != 0)) {
        local_4e8[0] = (longlong *)CONCAT44(local_4e8[0]._4_4_,*(undefined4 *)(lVar6 + 0x122c));
        plVar5 = plVar8;
        if (local_500 != (undefined4 *)0x0) {
          plVar5 = (longlong *)(local_4f0 - (longlong)local_500 >> 2);
        }
        if ((longlong *)((longlong)local_4f8 - (longlong)local_500 >> 2) < plVar5) {
          *local_4f8 = *(undefined4 *)(lVar6 + 0x122c);
          local_4f8 = local_4f8 + 1;
        }
        else {
          if (local_4f8 < local_500) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_500;
          plVar5 = local_518[0];
          local_4d8 = local_518[0];
          uStack_4d0 = puVar2;
          plVar10 = plVar8;
          if (((longlong)local_4f8 - (longlong)local_500 & 0xfffffffffffffffcU) != 0) {
            if (local_4f8 < local_500) {
              _invalid_parameter_noinfo();
            }
            if ((plVar5 == (longlong *)0x0) || (plVar5 != local_518[0])) {
              _invalid_parameter_noinfo();
            }
            plVar10 = (longlong *)((longlong)puVar2 - (longlong)puVar3 >> 2);
          }
          local_4b8 = (undefined4)local_4d8;
          uStack_4b4 = local_4d8._4_4_;
          uStack_4b0 = (undefined4)uStack_4d0;
          uStack_4ac = uStack_4d0._4_4_;
          FUN_140036c20(local_518,&local_4b8,1,local_4e8);
          puVar2 = local_500;
          if (local_4f8 < local_500) {
            _invalid_parameter_noinfo();
          }
          plVar5 = local_518[0];
          if (local_518[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar7 = plVar8;
          }
          else {
            plVar7 = (longlong *)*local_518[0];
          }
          if (puVar2 + (longlong)plVar10 <= (undefined4 *)plVar7[4]) {
            plVar7 = plVar8;
            if (plVar5 != (longlong *)0x0) {
              plVar7 = (longlong *)*plVar5;
            }
            if ((undefined4 *)plVar7[3] <= puVar2 + (longlong)plVar10) goto LAB_1405b85ee;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_1405b85ee:
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar5 = plVar8;
      }
      else {
        plVar5 = (longlong *)*puVar1;
      }
      if ((undefined4 *)plVar5[4] <= puVar9) {
        _invalid_parameter_noinfo();
      }
      puVar9 = puVar9 + 1;
    }
    plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar8 + 0x40))(plVar8,local_518,local_4a8);
    if (local_500 != (undefined4 *)0x0) {
      operator_delete(local_500);
    }
    local_500 = (undefined4 *)0x0;
    local_4f8 = (undefined4 *)0x0;
    local_4f0 = 0;
    operator_delete(local_518[0]);
    FUN_14015b2c0(local_4a8);
  }
  return;
}

