// ==== CMapItem::helper_1401d6bf0  @1401d6bf0  [medium:callgraph-r0]  (orig: FUN_1401d6bf0)
void FUN_1401d6bf0(longlong param_1,uint param_2)

{
  int *piVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x70))[1];
  cVar2 = *(char *)((longlong)puVar8 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x70);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x51);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x70);
  local_30 = puVar4;
  local_38 = *(longlong *)(param_1 + 0x40);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x70);
    local_28 = *(longlong *)(param_1 + 0x40);
  }
  else {
    plVar7 = &local_38;
  }
  plVar3 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x70);
  local_18 = plVar3;
  local_10 = plVar7[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x40))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 == lVar9) {
    log_InlineLogERROR("CCrossSpecialItem::IncCount. GenerateType[%u] not found!");
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar1 = (int *)(lVar5 + 0x38);
    *piVar1 = *piVar1 + -1;
  }
  return;
}

// ==== CMapItem::helper_1403321c0  @1403321c0  [medium:callgraph-r1]  (orig: FUN_1403321c0)
longlong FUN_1403321c0(void *param_1,void *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    do {
      memcpy((void *)(lVar1 + (longlong)param_1),param_1,0x28);
      param_1 = (void *)((longlong)param_1 + 0x28);
    } while (param_1 != param_2);
  }
  return param_3 + (lVar2 / 0x28) * 0x28;
}

// ==== CMapItem::helper_14033a3d0  @14033a3d0  [medium:callgraph-r0]  (orig: FUN_14033a3d0)
void FUN_14033a3d0(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_1403321c0(uVar1,param_1[4],uVar2,local_res8,local_res8,0);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CMapItem::vfunc_6  @14037c0b0  [high:rtti-vtable]  (orig: FUN_14037c0b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14037c0b0(longlong param_1,longlong *param_2)

{
  int iVar1;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    local_468 = 0x120;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1403a5840(local_448);
    iVar1 = FUN_1403a5de0(local_448,1,param_1 + -0x10,*(undefined4 *)(param_1 + 0x18));
    if (iVar1 != 0) {
      (**(code **)(*param_2 + 0x350))(param_2,local_448);
    }
    FUN_1403a5890(local_448);
  }
  return;
}

// ==== CMapItem::helper_14037c180  @14037c180  [medium:callgraph-r1]  (orig: FUN_14037c180)
undefined4 FUN_14037c180(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x88);
}

// ==== CMapItem::vfunc_1  @14037c540  [high:rtti-vtable]  (orig: FUN_14037c540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14037c540(longlong param_1)

{
  undefined8 *puVar1;
  int iVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (*(int *)(param_1 + 0xd4) != 0) {
    lVar4 = DAT_140975bf8;
    if (DAT_140975bf8 == 0) {
      local_468 = 0x3cf;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar4 = 0;
    }
    FUN_1401d6bf0(lVar4,*(undefined4 *)(param_1 + 0xd4));
  }
  if (*(longlong *)(param_1 + 0x90) != 0) {
    uVar3 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x20))(param_1 + -0x10);
    FUN_1402c9300(*(undefined8 *)(param_1 + 0x90),uVar3,0);
    FUN_1403a5840(local_448);
    iVar2 = FUN_1403a5de0(local_448,2,param_1 + -0x10);
    if (iVar2 != 0) {
      lVar4 = **(longlong **)(param_1 + 0x90);
      uVar3 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x20))(param_1 + -0x10);
      (**(code **)(lVar4 + 0x30))(*(undefined8 *)(param_1 + 0x90),uVar3,local_448,0);
    }
    FUN_1403a5890(local_448);
  }
  puVar1 = (undefined8 *)(param_1 + -0x10);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CMapItem::helper_14037c740  @14037c740  [medium:callgraph-r0]  (orig: FUN_14037c740)
void FUN_14037c740(void *param_1)

{
  if ((DAT_140976170 & 1) == 0) {
    DAT_140976170 = DAT_140976170 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976168,"CMapItem");
    atexit((_func_5014 *)&LAB_1406d6b40);
  }
                    /* WARNING: Could not recover jumptable at 0x00014037c795. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976168,param_1);
  return;
}

// ==== CMapItem::ctor_or_dtor  @14037d150  [high:vtable-assign]  (orig: FUN_14037d150)
void FUN_14037d150(undefined8 *param_1)

{
  *param_1 = CMapItem::vftable;
  param_1[2] = CMapItem::vftable;
  if ((void *)param_1[0x19] != (void *)0x0) {
    operator_delete((void *)param_1[0x19]);
  }
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  operator_delete((void *)param_1[0x16]);
  param_1[2] = IMapThing::vftable;
  FUN_1402b55a0(param_1);
  return;
}

// ==== CMapItem::vfunc_4  @14037d1d0  [high:rtti-vtable]  (orig: FUN_14037d1d0)
longlong FUN_14037d1d0(longlong param_1)

{
  if (param_1 != 0) {
    return param_1 + 0x10;
  }
  return 0;
}

// ==== CMapItem::vfunc_1  @14037d1e0  [high:rtti-vtable]  (orig: FUN_14037d1e0)
undefined4 FUN_14037d1e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

// ==== CMapItem::vfunc_2  @14037d1f0  [high:rtti-vtable]  (orig: FUN_14037d1f0)
undefined4 FUN_14037d1f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMapItem::vfunc_4  @14037d200  [high:rtti-vtable]  (orig: FUN_14037d200)
undefined4 FUN_14037d200(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x70);
}

// ==== CMapItem::vfunc_5  @14037d210  [high:rtti-vtable]  (orig: FUN_14037d210)
undefined4 FUN_14037d210(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x74);
}

// ==== CMapItem::vfunc_5  @14037d220  [high:rtti-vtable]  (orig: FUN_14037d220)
longlong FUN_14037d220(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0xa0);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapItem::vfunc_7  @14037d270  [high:rtti-vtable]  (orig: FUN_14037d270)
ulonglong FUN_14037d270(longlong param_1,int param_2,longlong *param_3)

{
  ulonglong in_RAX;
  
  if (param_2 == 0x1080) {
    *param_3 = param_1 + -0x10;
    return CONCAT71((int7)((ulonglong)(param_1 + -0x10) >> 8),1);
  }
  *param_3 = 0;
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapItem::vfunc_8  @14037d290  [high:rtti-vtable]  (orig: FUN_14037d290)
undefined1 FUN_14037d290(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = 0;
  return 0;
}

// ==== CMapItem::vfunc_2  @14037d2a0  [high:rtti-vtable]  (orig: FUN_14037d2a0)
void FUN_14037d2a0(longlong param_1)

{
  FUN_14037d1e0(param_1 + -0x10);
  return;
}

// ==== CMapItem::vfunc_3  @14037d2b0  [high:rtti-vtable]  (orig: FUN_14037d2b0)
void FUN_14037d2b0(longlong param_1)

{
  FUN_14037d1f0(param_1 + -0x10);
  return;
}

// ==== CMapItem::vfunc_0  @14037d2c0  [high:rtti-vtable]  (orig: FUN_14037d2c0)
void FUN_14037d2c0(longlong param_1)

{
  FUN_14037d3c0(param_1 + -0x10);
  return;
}

// ==== CMapItem::ctor_or_dtor  @14037d2d0  [high:vtable-assign]  (orig: FUN_14037d2d0)
undefined8 * FUN_14037d2d0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  FUN_1402b5540();
  param_1[2] = IMapThing::vftable;
  *param_1 = CMapItem::vftable;
  param_1[2] = CMapItem::vftable;
  plVar3 = (longlong *)0x0;
  *(undefined4 *)((longlong)param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x12) = 0;
  *(undefined4 *)((longlong)param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x13) = 0;
  puVar1 = param_1 + 0x16;
  plVar2 = operator_new(8);
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)puVar1;
    plVar3 = plVar2;
  }
  *puVar1 = plVar3;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  *(undefined4 *)(param_1 + 1) = 0x1080;
  memset((void *)((longlong)param_1 + 0x1c),0,100);
  FUN_14033a3d0(puVar1);
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)((longlong)param_1 + 0x84) = 0;
  *(undefined4 *)(param_1 + 0x11) = 0;
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0;
  return param_1;
}

// ==== CMapItem::vfunc_0  @14037d3c0  [high:rtti-vtable]  (orig: FUN_14037d3c0)
undefined8 FUN_14037d3c0(undefined8 param_1,uint param_2)

{
  FUN_14037d150();
  if ((param_2 & 1) != 0) {
    FUN_14037c740(param_1);
  }
  return param_1;
}

// ==== CMapItem::helper_1403a5de0  @1403a5de0  [medium:callgraph-r0]  (orig: FUN_1403a5de0)
undefined8 FUN_1403a5de0(longlong param_1,int param_2,longlong *param_3,undefined4 param_4)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  ulong uVar5;
  undefined8 uVar6;
  
  if ((param_3 == (longlong *)0x0) || (param_2 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    FUN_1402b5600();
    *(char *)(*(longlong *)(param_1 + 0x428) + 0x12) = (char)param_2;
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar3;
    *(int *)(*(longlong *)(param_1 + 0x428) + 8) = (int)param_3[4];
    uVar2 = (**(code **)(param_3[2] + 0x20))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar2;
    uVar2 = (**(code **)(param_3[2] + 0x28))(param_3 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = uVar2;
    uVar2 = FUN_14037c180(param_3);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar2;
    *(int *)(*(longlong *)(param_1 + 0x428) + 0x13) = (int)param_3[0x1c];
    uVar6 = FUN_140008520(0xe);
    cVar1 = FUN_14008aff0(uVar6);
    if (cVar1 == '\0') {
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = 0;
    }
    else {
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_4;
    }
    iVar4 = FUN_1400ff680(*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
    if ((((iVar4 < 1) || (8 < iVar4)) && ((iVar4 < 0xc || (0xe < iVar4)))) &&
       ((iVar4 != 0x15 && (iVar4 != 0x16)))) {
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x17) = 0;
    }
    else {
      *(char *)(*(longlong *)(param_1 + 0x428) + 0x17) = (char)param_3[10];
    }
    uVar5 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar5;
    *(undefined4 *)(param_1 + 8) = 0x44d;
    *(undefined4 *)(param_1 + 0xc) = 0x41;
    uVar6 = 1;
  }
  return uVar6;
}

