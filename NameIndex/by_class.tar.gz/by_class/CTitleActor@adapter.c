// ==== CTitleActor@adapter::helper_140161fc0  @140161fc0  [medium:callgraph-r0]  (orig: FUN_140161fc0)
void FUN_140161fc0(longlong param_1)

{
  FUN_140372b50(param_1 + 0xe78);
  return;
}

// ==== CTitleActor@adapter::helper_140161fd0  @140161fd0  [medium:callgraph-r0]  (orig: FUN_140161fd0)
void FUN_140161fd0(longlong param_1)

{
  FUN_140372b60(param_1 + 0xe78);
  return;
}

// ==== CTitleActor@adapter::helper_140161fe0  @140161fe0  [medium:callgraph-r0]  (orig: FUN_140161fe0)
void FUN_140161fe0(longlong param_1)

{
  FUN_140372bd0(param_1 + 0xe78);
  return;
}

// ==== CTitleActor@adapter::helper_140161ff0  @140161ff0  [medium:callgraph-r0]  (orig: FUN_140161ff0)
void FUN_140161ff0(longlong param_1)

{
  FUN_140372be0(param_1 + 0xe78);
  return;
}

// ==== CTitleActor@adapter::helper_140372b50  @140372b50  [medium:callgraph-r1]  (orig: FUN_140372b50)
undefined4 FUN_140372b50(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1b4);
}

// ==== CTitleActor@adapter::helper_140372b60  @140372b60  [medium:callgraph-r1]  (orig: FUN_140372b60)
void FUN_140372b60(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x1b4) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"title");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTitleActor@adapter::helper_140372bd0  @140372bd0  [medium:callgraph-r1]  (orig: FUN_140372bd0)
undefined1 FUN_140372bd0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x1b8);
}

// ==== CTitleActor@adapter::helper_140372be0  @140372be0  [medium:callgraph-r1]  (orig: FUN_140372be0)
void FUN_140372be0(longlong param_1,undefined1 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined1 *)(param_1 + 0x1b8) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"title_select");
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_1  @1405b60d0  [high:rtti-vtable]  (orig: FUN_1405b60d0)
void FUN_1405b60d0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_0  @1405b60f0  [high:rtti-vtable]  (orig: FUN_1405b60f0)
undefined8 FUN_1405b60f0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      uVar3 = FUN_140161fc0(lVar2);
      return uVar3;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CTitleActor@adapter::vfunc_1  @1405b6160  [high:rtti-vtable]  (orig: FUN_1405b6160)
void FUN_1405b6160(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140161fd0(lVar2,param_3,1);
    }
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_2  @1405b61a0  [high:rtti-vtable]  (orig: FUN_1405b61a0)
undefined1 FUN_1405b61a0(longlong param_1)

{
  undefined1 uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 != 0) {
      uVar1 = FUN_140161fe0(lVar3);
      return uVar1;
    }
  }
  return 0;
}

// ==== CTitleActor@adapter::vfunc_3  @1405b61e0  [high:rtti-vtable]  (orig: FUN_1405b61e0)
void FUN_1405b61e0(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140161ff0(lVar2,param_3,1);
    }
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_4  @1405b6220  [high:rtti-vtable]  (orig: FUN_1405b6220)
bool FUN_1405b6220(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  return lVar1 != 0;
}

// ==== CTitleActor@adapter::vfunc_6  @1405b6240  [high:rtti-vtable]  (orig: FUN_1405b6240)
void FUN_1405b6240(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (((param_3 != 0) &&
      (plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))(),
      plVar1 != (longlong *)0x0)) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
    (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x358))((longlong *)(lVar2 + 0x10),param_3);
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_0  @1405b6290  [high:rtti-vtable]  (orig: FUN_1405b6290)
void FUN_1405b6290(longlong param_1)

{
  FUN_1405b62f0(param_1 + -8);
  return;
}

// ==== CTitleActor@adapter::helper_1405b62f0  @1405b62f0  [medium:callgraph-r0]  (orig: FUN_1405b62f0)
undefined8 * FUN_1405b62f0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTitleActor::vftable;
  param_1[1] = adapter::CTitleActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTitleActor@adapter::vfunc_5  @1405b6340  [high:rtti-vtable]  (orig: FUN_1405b6340)
void FUN_1405b6340(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  if (param_3 != 0) {
    uVar4 = 0xfffffffffffffffe;
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (((plVar1 != (longlong *)0x0) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)
        ) && (puVar3 = (undefined8 *)
                       FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c)
                                     ,*(undefined2 *)(param_3 + 10),param_3 + 0xc,
                                     *(ushort *)(param_3 + 8) - 4,0,uVar4),
             puVar3 != (undefined8 *)0x0)) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
      (**(code **)*puVar3)(puVar3,1);
    }
  }
  return;
}

// ==== CTitleActor@adapter::vfunc_7  @1405b63f0  [high:rtti-vtable]  (orig: FUN_1405b63f0)
void FUN_1405b63f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  
  uVar7 = 0xfffffffffffffffe;
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar3 != (longlong *)0x0) {
    lVar4 = (**(code **)(*plVar3 + 0x2b0))(plVar3);
    if (lVar4 != 0) {
      plVar3 = (longlong *)(lVar4 + 0x10);
      plVar5 = (longlong *)(**(code **)(*plVar3 + 0x160))(plVar3);
      if (plVar5 != (longlong *)0x0) {
        puVar6 = (undefined8 *)
                 FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                               param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar7);
        if (puVar6 != (undefined8 *)0x0) {
          (**(code **)(*plVar3 + 0x350))(plVar3,puVar6);
          lVar4 = *plVar5;
          uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
          uVar2 = (**(code **)(*plVar3 + 0x40))(plVar3);
          (**(code **)(lVar4 + 0x28))(plVar5,uVar2,uVar1,puVar6);
          (**(code **)*puVar6)(puVar6,1);
        }
      }
    }
  }
  return;
}

