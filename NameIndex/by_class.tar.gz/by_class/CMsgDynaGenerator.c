// ==== CMsgDynaGenerator::ctor_or_dtor  @1403a61b0  [high:vtable-assign]  (orig: FUN_1403a61b0)
undefined8 * FUN_1403a61b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgDynaGenerator::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgDynaGenerator::ctor_or_dtor  @1403a6200  [high:vtable-assign]  (orig: FUN_1403a6200)
void FUN_1403a6200(undefined8 *param_1)

{
  *param_1 = CMsgDynaGenerator::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgDynaGenerator::vfunc_1  @1403a6280  [high:rtti-vtable]  (orig: FUN_1403a6280)
undefined8 FUN_1403a6280(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgDynaGenerator::vfunc_3  @1403a62b0  [high:rtti-vtable]  (orig: FUN_1403a62b0)
void FUN_1403a62b0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgDynaGenerator::ctor_or_dtor  @1403a62f0  [high:vtable-assign]  (orig: FUN_1403a62f0)
undefined8 * FUN_1403a62f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgDynaGenerator::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

