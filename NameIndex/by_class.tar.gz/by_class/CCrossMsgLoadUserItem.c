// ==== CCrossMsgLoadUserItem::helper_140106e00  @140106e00  [medium:callgraph-r2]  (orig: FUN_140106e00)
undefined8
FUN_140106e00(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  if (param_1[2] == 0) {
    if (param_1[3] != 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    plVar6 = (longlong *)InstanceGet();
    lVar7 = (**(code **)(*plVar6 + 0x20))(plVar6,"cq_item");
    param_1[2] = lVar7;
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    *(undefined4 *)((longlong)param_1 + 100) = param_3;
    *(undefined4 *)(param_1 + 0xd) = *param_4;
    uVar8 = FUN_140087d40();
    iVar2 = FUN_1403254f0(uVar8);
    if (iVar2 != 0) {
      plVar6 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0);
      (**(code **)(*plVar6 + 0xb0))(plVar6,iVar2);
      FUN_1401067c0(param_1);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
        cVar1 = FUN_1401032b0(param_1,0);
        if (cVar1 != '\0') {
          *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
        }
      }
      uVar4 = param_4[2];
      plVar6 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
      (**(code **)(*plVar6 + 0xb0))(plVar6,uVar4);
      FUN_1401067c0(param_1);
      plVar6 = (longlong *)FUN_140087f50();
      plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
      uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
      lVar7 = *plVar6;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar7 + 0x60))(plVar6,uVar4,uVar5);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
        cVar1 = FUN_1401032b0(param_1,1);
        if (cVar1 != '\0') {
          *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
        }
      }
      plVar6 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],2);
      (**(code **)(*plVar6 + 0xb0))(plVar6,param_2);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
        cVar1 = FUN_1401032b0(param_1,2);
        if (cVar1 != '\0') {
          *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
        }
      }
      FUN_140104140(param_1,3,param_2);
      FUN_140104140(param_1,4,param_4[5]);
      FUN_140104140(param_1,5,param_4[6]);
      FUN_140104140(param_1,6,param_4[7]);
      FUN_140104140(param_1,7,param_4[8]);
      FUN_140104140(param_1,8,param_4[9]);
      FUN_140104140(param_1,9,param_4[10]);
      FUN_140104140(param_1,10,param_4[0xb]);
      uVar4 = param_4[0xc];
      plVar6 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xb)
      ;
      (**(code **)(*plVar6 + 0xb0))(plVar6,uVar4);
      FUN_1401067c0(param_1);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
        cVar1 = FUN_1401032b0(param_1,0xb);
        if (cVar1 != '\0') {
          *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
        }
      }
      uVar4 = param_4[0xd];
      plVar6 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc)
      ;
      (**(code **)(*plVar6 + 0xb0))(plVar6,uVar4);
      FUN_1401067c0(param_1);
      plVar6 = (longlong *)FUN_140087f50();
      lVar7 = *plVar6;
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      uVar5 = FUN_1400fda10(param_1,3,1);
      (**(code **)(lVar7 + 0x60))(plVar6,uVar5,uVar4);
      plVar6 = (longlong *)FUN_140087d40();
      lVar7 = *plVar6;
      uVar4 = FUN_1400fda10(param_1,0xc,1);
      uVar5 = FUN_1400fda10(param_1,1,1);
      lVar7 = (**(code **)(lVar7 + 0x78))(plVar6,uVar5,uVar4);
      param_1[5] = lVar7;
      FUN_140103140(param_1);
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
        cVar1 = FUN_1401032b0(param_1,0xc);
        if (cVar1 != '\0') {
          *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
        }
      }
      FUN_140104140(param_1,0xd,param_4[0xe]);
      FUN_140104140(param_1,0xe,param_4[0xf]);
      FUN_140104140(param_1,0xf,param_4[0x10]);
      FUN_140104140(param_1,0x10,param_4[0x11]);
      FUN_140104140(param_1,0x11,param_4[0x12]);
      FUN_140104140(param_1,0x12,param_4[0x13]);
      FUN_140104140(param_1,0x13,param_4[0x14]);
      FUN_140104140(param_1,0x14,param_4[0x15]);
      FUN_140104140(param_1,0x15,param_4[0x16]);
      uVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      cVar1 = FUN_14008a710(uVar8);
      if (cVar1 == '\0') {
        FUN_140104140(param_1,0x16,param_4[0x17]);
      }
      else {
        FUN_140104140(param_1,0x16,0);
      }
      FUN_140104140(param_1,0x17,param_4[0x18]);
      FUN_140106830(param_1,0x18,*(undefined8 *)(param_4 + 0x1a));
      FUN_140104140(param_1,0x19,param_4[0x1c]);
      FUN_140104140(param_1,0x1a,param_4[0x1d]);
      uVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      uVar8 = FUN_1400fd7b0(uVar8);
      cVar1 = FUN_140258720(uVar8,param_4[2]);
      *(bool *)((longlong)param_1 + 0x6c) = cVar1 != '\0';
      plVar6 = (longlong *)FUN_140087d40();
      lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,param_4[2]);
      param_1[3] = lVar7;
      if (lVar7 == 0) {
        log_InlineLogDBERROR
                  (
                  "table:cq_itemtype, user(%u) can not find itemtype(%u), maybe cq_itemtype not config."
                  );
        return 0;
      }
      FUN_1401067c0(param_1);
      plVar6 = (longlong *)FUN_140087d40();
      lVar7 = (**(code **)(*plVar6 + 0x78))(plVar6,param_4[2],param_4[0xd]);
      *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
      param_1[5] = lVar7;
      return 1;
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CCrossMsgLoadUserItem::helper_1401bdc80  @1401bdc80  [medium:callgraph-r0]  (orig: FUN_1401bdc80)
undefined8 FUN_1401bdc80(longlong *param_1,uint param_2,longlong param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  int *piVar11;
  undefined4 local_res10 [4];
  int local_res20;
  undefined4 local_res24;
  ulonglong local_58;
  undefined1 local_50 [24];
  
  if ((int)param_2 < 1) {
    return 0;
  }
  plVar10 = (longlong *)0x0;
  if (0 < (int)param_2) {
    local_58 = (ulonglong)param_2;
    piVar11 = (int *)(param_3 + 0xc);
    do {
      if (*piVar11 != piVar11[1]) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar3 = *(undefined4 *)((longlong)param_1 + 0x12fc);
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar10;
      }
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      plVar5 = (longlong *)FUN_1403272c0(plVar5,uVar2,uVar3,param_3);
      if (plVar5 != (longlong *)0x0) {
        plVar6 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar6 = plVar10;
        }
        lVar7 = *plVar6;
        uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        iVar4 = (**(code **)(lVar7 + 0x150))(plVar6,uVar3);
        if (iVar4 == 3) {
          plVar6 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar6 = plVar10;
          }
          uVar3 = 0;
          (**(code **)(*plVar6 + 0x130))(plVar6,param_1,plVar5,5,0,0);
          FUN_1400fe700(plVar5,param_1,0);
          plVar6 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            uVar3 = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar6 = plVar10;
          }
          lVar7 = *plVar6;
          uVar2 = (**(code **)(*plVar5 + 8))(plVar5);
          (**(code **)(lVar7 + 0x30))(plVar6,uVar2,1,0,uVar3);
        }
        else {
          iVar4 = FUN_1400fda10(plVar5,7,1);
          if (((0 < iVar4) && (iVar4 < 0x14)) || (iVar4 - 0x15U < 9)) {
            plVar6 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar6 = plVar10;
            }
            lVar7 = *plVar6;
            uVar3 = FUN_140337820(param_1,iVar4);
            lVar7 = (**(code **)(lVar7 + 0x60))(plVar6,uVar3);
            if (lVar7 == 0) {
              local_res20 = iVar4;
              local_res24 = (**(code **)(*plVar5 + 8))(plVar5);
              FUN_1400173d0(param_1 + 0x19f,local_50,&local_res20);
              if (iVar4 < 0x14) {
                uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
                *(undefined4 *)((longlong)param_1 + (longlong)iVar4 * 4 + 0xd94) = uVar3;
                uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
                FUN_140171670(param_1,uVar3,iVar4);
              }
              goto LAB_1401be0f5;
            }
            log_InlineLogOSERROR("Found same position of user equip. at %s, %d");
          }
          if ((ulonglong)(param_1[0x185] - param_1[0x184] >> 2) < 0x28) {
            iVar4 = FUN_1400fda10(plVar5,7,1);
            if (iVar4 < 200) {
              iVar4 = FUN_1400fda10(plVar5,7,1);
              if (iVar4 != 0) {
                FUN_140104140(plVar5,7,0);
              }
              local_res10[0] = (**(code **)(*plVar5 + 8))(plVar5);
              FUN_140037fe0(param_1 + 0x181,local_res10);
              goto LAB_1401be0f5;
            }
          }
          iVar4 = FUN_1400fda10(plVar5,7,1);
          if (iVar4 == 0xcd) {
            plVar6 = (longlong *)FUN_140087d40();
            lVar7 = *plVar6;
            uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
            (**(code **)(lVar7 + 0x180))(plVar6,uVar3);
            local_res10[0] = (**(code **)(*plVar5 + 8))(plVar5);
            FUN_140037fe0(param_1 + 0x193,local_res10);
          }
          else {
            cVar1 = FUN_1400ff650(plVar5,2);
            if ((cVar1 == '\0') || (iVar4 = FUN_1400fda10(plVar5,7,1), iVar4 == 0xcc)) {
              plVar6 = (longlong *)FUN_140087d40();
              lVar7 = *plVar6;
              uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
              (**(code **)(lVar7 + 0x58))(plVar6,uVar3,0xc);
            }
            else {
              plVar6 = (longlong *)FUN_140087d40();
              lVar7 = *plVar6;
              uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
              (**(code **)(lVar7 + 0x180))(plVar6,uVar3);
              local_res10[0] = (**(code **)(*plVar5 + 8))(plVar5);
              FUN_140037fe0(param_1 + 0x199,local_res10);
            }
          }
        }
      }
LAB_1401be0f5:
      param_3 = param_3 + 0x80;
      piVar11 = piVar11 + 0x20;
      local_58 = local_58 - 1;
    } while (local_58 != 0);
  }
  lVar7 = FUN_140008520((int)param_1[0x246]);
  plVar5 = *(longlong **)(lVar7 + 0x100);
  if (*(longlong **)(lVar7 + 0x100) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar10;
  }
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  lVar7 = FUN_1402f2760(plVar5,uVar3,0x2847);
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar10;
  }
  lVar8 = *plVar5;
  uVar3 = FUN_14032b4b0(param_1,5);
  lVar8 = (**(code **)(lVar8 + 0x60))(plVar5,uVar3);
  if (lVar8 != 0) {
    uVar3 = FUN_1400fda10(lVar8,1,1);
    iVar4 = FUN_1400ff680(uVar3);
    if (iVar4 == 5) {
      uVar3 = FUN_1400fda10(lVar8,7,1);
      FUN_1403418e0(param_1,uVar3,0);
    }
  }
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar10;
  }
  lVar8 = *plVar5;
  uVar3 = FUN_14032b4b0(param_1,4);
  lVar8 = (**(code **)(lVar8 + 0x60))(plVar5,uVar3);
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar10;
  }
  lVar9 = *plVar5;
  uVar3 = FUN_14032b4b0(param_1,5);
  lVar9 = (**(code **)(lVar9 + 0x60))(plVar5,uVar3);
  if (lVar8 != 0) {
    uVar3 = FUN_1400fda10(lVar8,1,1);
    iVar4 = FUN_1400ff680(uVar3);
    if ((iVar4 == 5) && (lVar9 != 0)) {
      uVar3 = FUN_1400fda10(lVar8,1,1);
      cVar1 = FUN_14015f820(uVar3);
      if (((cVar1 == '\0') || (cVar1 = FUN_14016c900(lVar9), cVar1 == '\0')) && (lVar7 == 0)) {
        uVar3 = FUN_1400fda10(lVar9,7,1);
        FUN_1403418e0(param_1,uVar3,0);
      }
    }
  }
  *(undefined1 *)((longlong)param_1 + 0x955) = 1;
  return 1;
}

// ==== CCrossMsgLoadUserItem::helper_1403272c0  @1403272c0  [medium:callgraph-r1]  (orig: FUN_1403272c0)
longlong * FUN_1403272c0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined4 *puVar8;
  longlong local_res8;
  undefined4 local_60 [2];
  longlong *local_58;
  undefined1 local_50 [16];
  char local_40;
  
  lVar1 = param_1[2];
  local_res8 = FUN_1401012b0(0x70);
  if (local_res8 == 0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = (longlong *)FUN_1400fd8d0(local_res8,(int)lVar1);
  }
  if (plVar5 == (longlong *)0x0) {
    return (longlong *)0x0;
  }
  cVar2 = FUN_140106e00(plVar5,param_2,param_3,param_4);
  if ((cVar2 == '\0') || (cVar2 = FUN_140101370(plVar5), cVar2 == '\0')) {
    FUN_140103eb0(plVar5);
    return (longlong *)0x0;
  }
  iVar3 = FUN_1400fda10(plVar5,7,1);
  if (200 < iVar3) {
    iVar3 = FUN_1400fda10(plVar5,7,1);
    if (iVar3 < 0xcd) goto LAB_1403273e9;
  }
  iVar3 = FUN_1400fda10(plVar5,7,1);
  if ((iVar3 != 0xd0) &&
     ((iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 2 ||
      (iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 3)))) {
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    FUN_14000d480(param_1 + 0x26,local_50,&local_res8);
  }
LAB_1403273e9:
  local_60[0] = (**(code **)(*plVar5 + 8))(plVar5);
  local_58 = plVar5;
  FUN_1403218d0(param_1 + 0x13,local_50,local_60);
  if (local_40 == '\0') {
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    plVar6 = (longlong *)FUN_1403256a0(param_1 + 0x13,&local_res8);
    lVar1 = *plVar6;
    local_res8 = lVar1;
    if (lVar1 != 0) {
      FUN_1400fda10(lVar1,7,1);
      FUN_1400fda10(lVar1,2,1);
      FUN_1400fda10(lVar1,3,1);
      FUN_1400fda10(plVar5,7,1);
      FUN_1400fda10(plVar5,2,1);
      FUN_1400fda10(plVar5,3,1);
      (**(code **)(*plVar5 + 8))(plVar5);
      log_InlineLogERROR(
                        "CItemMgr::CreateOSItem. Item[%u] NewItem(UserID[%u], OwnerID[%u], Position[%d]) OldItem(UserID[%u], OwnerID[%u], Position[%d])  at %s, %d"
                        );
      FUN_140103eb0(local_res8);
    }
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    puVar7 = (undefined8 *)FUN_1403256a0(param_1 + 0x13,&local_res8);
    *puVar7 = plVar5;
  }
  uVar4 = FUN_140100c20(plVar5);
  local_res8 = CONCAT44(param_3,uVar4);
  puVar8 = (undefined4 *)FUN_1402af3c0(param_1 + 0xb,&local_res8);
  uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
  *puVar8 = uVar4;
  return plVar5;
}

// ==== CCrossMsgLoadUserItem::ctor_or_dtor  @1403f16f0  [high:vtable-assign]  (orig: FUN_1403f16f0)
undefined8 * FUN_1403f16f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadUserItem::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadUserItem::ctor_or_dtor  @1403f1740  [high:vtable-assign]  (orig: FUN_1403f1740)
void FUN_1403f1740(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadUserItem::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadUserItem::vfunc_1  @1403f1770  [high:rtti-vtable]  (orig: FUN_1403f1770)
undefined8 FUN_1403f1770(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadUserItem::ctor_or_dtor  @1403f1850  [high:vtable-assign]  (orig: FUN_1403f1850)
undefined8 * FUN_1403f1850(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadUserItem::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadUserItem::vfunc_3  @1403f18a0  [high:rtti-vtable]  (orig: FUN_1403f18a0)
void FUN_1403f18a0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_1402af110(*(undefined8 *)(lVar3 + 0x90),uVar2,uVar1);
  if (lVar3 == 0) {
    log_InlineLogOSMessage("Load Other Server User(%u,%u) Item Info,Not Find User!");
  }
  else {
    FUN_1401bdc80(lVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                  *(longlong *)(param_1 + 0x428) + 8);
  }
  return;
}

