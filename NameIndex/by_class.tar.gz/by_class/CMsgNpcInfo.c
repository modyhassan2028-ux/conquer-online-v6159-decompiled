// ==== CMsgNpcInfo::helper_1404548c0  @1404548c0  [medium:callgraph-r0]  (orig: FUN_1404548c0)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_1404548c0(longlong param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (param_2,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *
                     )(param_1 + 0xa38));
  return param_2;
}

// ==== CMsgNpcInfo::ctor_or_dtor  @140454910  [high:vtable-assign]  (orig: FUN_140454910)
undefined8 * FUN_140454910(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNpcInfo::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x26),0x3e9,true);
  return param_1;
}

// ==== CMsgNpcInfo::ctor_or_dtor  @140454990  [high:vtable-assign]  (orig: FUN_140454990)
void FUN_140454990(undefined8 *param_1)

{
  *param_1 = CMsgNpcInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgNpcInfo::vfunc_1  @140454be0  [high:rtti-vtable]  (orig: FUN_140454be0)
undefined8 FUN_140454be0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgNpcInfo::ctor_or_dtor  @140454c10  [high:vtable-assign]  (orig: FUN_140454c10)
undefined8 * FUN_140454c10(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNpcInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgNpcInfo::vfunc_3  @140454c70  [high:rtti-vtable]  (orig: FUN_140454c70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140454c70(longlong param_1)

{
  int iVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  uint uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 uVar10;
  undefined8 ***pppuVar11;
  undefined1 auStack_498 [32];
  uint local_478;
  char *local_470;
  uint local_468;
  uint local_460;
  undefined8 local_458;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_450 [8];
  undefined8 **local_448 [2];
  longlong local_438;
  ulonglong local_430;
  char local_428;
  undefined1 local_427 [1023];
  ulonglong local_28;
  
  local_458 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar7 + 0x90) == 0) {
    local_478 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x88))(*(longlong **)(lVar7 + 0x90),param_1)
  ;
  if (plVar8 != (longlong *)0x0) {
    plVar9 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar8[0x1e2];
    lVar7 = *plVar9;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
    (**(code **)(lVar7 + 0x108))(plVar9,uVar5,(int)lVar3,*puVar2);
    local_428 = '\0';
    memset(local_427,0,0x3ff);
    lVar7 = *(longlong *)(param_1 + 0x428);
    local_460 = (uint)*(ushort *)(lVar7 + 0x14);
    local_468 = (uint)*(ushort *)(lVar7 + 0x12);
    local_470 = (char *)CONCAT44(local_470._4_4_,(uint)*(ushort *)(lVar7 + 0x10));
    local_478 = (uint)*(ushort *)(lVar7 + 0xe);
    _snprintf(&local_428,0x3ff,"%d %d %d %d %d",(ulonglong)*(ushort *)(lVar7 + 0xc));
    iVar1 = (int)plVar8[0x14c];
    if (iVar1 != 0) {
      cVar4 = FUN_140332fe0(plVar8,iVar1);
      if (cVar4 != '\0') {
        plVar9 = (longlong *)FUN_140087d40();
        plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,iVar1);
        if (plVar9 != (longlong *)0x0) {
          iVar1 = *(int *)((longlong)plVar8 + 0xa34);
          FUN_1404548c0(plVar8,local_450);
          if (iVar1 == 0) {
            if (local_438 != 0) {
              pppuVar11 = local_448;
              if (0xf < local_430) {
                pppuVar11 = (undefined8 ***)local_448[0];
              }
              uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
              uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
              uVar10 = FUN_140087e30();
              local_470 = &local_428;
              local_478 = uVar6;
              cVar4 = FUN_140286530(uVar10,pppuVar11,uVar5,0);
              if (cVar4 == '\0') {
                pppuVar11 = local_448;
                if (0xf < local_430) {
                  pppuVar11 = (undefined8 ***)local_448[0];
                }
                log_InlineLogLuaERROR
                          ("Lua return fault, Call From:CMsgNpcInfo::Process, lua function:%s.",
                           pppuVar11);
              }
            }
          }
          else {
            uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
            uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            uVar10 = FUN_140087730(uVar10);
            local_470 = &local_428;
            local_478 = uVar6;
            FUN_140145f60(uVar10,iVar1,plVar8,0);
          }
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_450);
        }
      }
    }
  }
  return;
}

