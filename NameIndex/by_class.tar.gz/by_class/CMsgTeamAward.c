// ==== CMsgTeamAward::ctor_or_dtor  @1403f2e40  [high:vtable-assign]  (orig: FUN_1403f2e40)
undefined8 * FUN_1403f2e40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTeamAward::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTeamAward::ctor_or_dtor  @1403f2e90  [high:vtable-assign]  (orig: FUN_1403f2e90)
void FUN_1403f2e90(undefined8 *param_1)

{
  *param_1 = CMsgTeamAward::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTeamAward::vfunc_1  @1403f2f30  [high:rtti-vtable]  (orig: FUN_1403f2f30)
ulonglong FUN_1403f2f30(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x405);
}

// ==== CMsgTeamAward::vfunc_3  @1403f2f60  [high:rtti-vtable]  (orig: FUN_1403f2f60)
void FUN_1403f2f60(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgTeamAward::ctor_or_dtor  @1403f2fa0  [high:vtable-assign]  (orig: FUN_1403f2fa0)
undefined8 * FUN_1403f2fa0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTeamAward::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

