// ==== CopyingOutputStream@io@protobuf@google::helper_14055cde0  @14055cde0  [medium:callgraph-r0]  (orig: FUN_14055cde0)
void FUN_14055cde0(undefined8 *param_1)

{
  *param_1 = google::protobuf::io::CopyingOutputStream::vftable;
  return;
}

// ==== CopyingOutputStream@io@protobuf@google::vfunc_0  @14055d630  [high:rtti-vtable]  (orig: FUN_14055d630)
void * FUN_14055d630(void *param_1,uint param_2)

{
  FUN_14055cde0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

