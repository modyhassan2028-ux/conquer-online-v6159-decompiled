// ==== CFuseItem::helper_14030b740  @14030b740  [medium:callgraph-r0]  (orig: FUN_14030b740)
void FUN_14030b740(void *param_1)

{
  if ((DAT_140975fe8 & 1) == 0) {
    DAT_140975fe8 = DAT_140975fe8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975fe0,"CFuseItem");
    atexit((_func_5014 *)&LAB_1406d6a40);
  }
                    /* WARNING: Could not recover jumptable at 0x00014030b795. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975fe0,param_1);
  return;
}

// ==== CFuseItem::ctor_or_dtor  @14030bbd0  [high:vtable-assign]  (orig: FUN_14030bbd0)
void FUN_14030bbd0(undefined8 *param_1)

{
  *param_1 = CFuseItem::vftable;
  FUN_14006d470(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CFuseItem::ctor_or_dtor  @14030be00  [high:vtable-assign]  (orig: FUN_14030be00)
undefined8 * FUN_14030be00(undefined8 *param_1,uint param_2)

{
  *param_1 = CFuseItem::vftable;
  FUN_14006d470(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_14030b740(param_1);
  }
  return param_1;
}

