// ==== CMsgTransportor::helper_140167060  @140167060  [medium:callgraph-r1]  (orig: FUN_140167060)
void FUN_140167060(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x12e4) = param_2;
  return;
}

// ==== CMsgTransportor::helper_14023ddc0  @14023ddc0  [medium:callgraph-r1]  (orig: FUN_14023ddc0)
undefined8 FUN_14023ddc0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgTransportor::helper_14023e4c0  @14023e4c0  [medium:callgraph-r0]  (orig: FUN_14023e4c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14023e4c0(longlong param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  int *piVar9;
  undefined8 ***pppuVar10;
  undefined1 auStack_98 [32];
  undefined4 local_78;
  undefined8 local_70;
  undefined8 local_68;
  int local_60;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_58 [8];
  undefined8 **local_50 [2];
  longlong local_40;
  ulonglong local_38;
  ulonglong local_30;
  
  local_68 = 0xfffffffffffffffe;
  local_30 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    local_78 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))(*(longlong **)(lVar5 + 0x90),param_3)
  ;
  if (plVar6 == (longlong *)0x0) {
    local_78 = 0x9d;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\transportormgr.cpp"
                      );
  }
  else {
    cVar1 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2);
    if (cVar1 != '\0') {
      uVar2 = (**(code **)(plVar6[2] + 0x168))(plVar6 + 2);
      uVar3 = (**(code **)(plVar6[2] + 0x40))(plVar6 + 2);
      uVar4 = (**(code **)(plVar6[2] + 0x48))(plVar6 + 2);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
      plVar8 = (longlong *)FUN_1400876b0(uVar7);
      uVar7 = (**(code **)(*plVar8 + 0x10))(plVar8,uVar2,1);
      if (param_2 == 0) {
        plVar8 = (longlong *)FUN_1402c69b0(uVar7,uVar3,uVar4);
        if (plVar8 != (longlong *)0x0) {
          uVar2 = (**(code **)(*plVar8 + 0x10))(plVar8,9);
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
          uVar7 = FUN_140087730(uVar7);
          local_70 = 0;
          local_78 = 0;
          FUN_140145f60(uVar7,uVar2,plVar6,0);
        }
      }
      else {
        lVar5 = FUN_14023ddc0(param_1,param_2);
        if (lVar5 == 0) {
          local_78 = 0xba;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pTransportor",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\transportormgr.cpp"
                            );
        }
        else {
          FUN_140167060(plVar6,param_2);
          piVar9 = (int *)FUN_140420590(lVar5);
          local_60 = *piVar9;
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>
                    (local_58,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                               *)(piVar9 + 2));
          if (local_60 == 0) {
            if (local_40 != 0) {
              pppuVar10 = local_50;
              if (0xf < local_38) {
                pppuVar10 = (undefined8 ***)local_50[0];
              }
              uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
              uVar7 = FUN_140087e30();
              local_70 = 0;
              local_78 = 0;
              cVar1 = FUN_140286530(uVar7,pppuVar10,uVar2,0);
              if (cVar1 == '\0') {
                pppuVar10 = local_50;
                if (0xf < local_38) {
                  pppuVar10 = (undefined8 ***)local_50[0];
                }
                log_InlineLogLuaERROR
                          ("Lua return fault, Call From:CTransportorMgr::EnterTransportor, lua function:%s."
                           ,pppuVar10);
              }
            }
          }
          else {
            uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
            uVar7 = FUN_140087730(uVar7);
            local_70 = 0;
            local_78 = 0;
            FUN_140145f60(uVar7,local_60,plVar6,0);
          }
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_58);
        }
      }
    }
  }
  return;
}

// ==== CMsgTransportor::helper_1402c3e00  @1402c3e00  [medium:callgraph-r2]  (orig: FUN_1402c3e00)
ulonglong FUN_1402c3e00(longlong *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  
  uVar4 = (**(code **)(*param_1 + 0x10))(param_1,1);
  if (param_2 == (int)uVar4) {
    iVar1 = (**(code **)(*param_1 + 0x10))(param_1,3);
    iVar2 = (**(code **)(*param_1 + 0x10))(param_1,4);
    uVar3 = (**(code **)(*param_1 + 0x10))(param_1,8);
    uVar4 = (ulonglong)(uVar3 ^ 2);
    if ((int)((iVar1 - param_3 ^ 2U) + (iVar2 - param_4 ^ 2U)) <= (int)(uVar3 ^ 2)) {
      return CONCAT71((uint7)(uint3)(uVar3 >> 8),1);
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMsgTransportor::helper_1402c69b0  @1402c69b0  [medium:callgraph-r1]  (orig: FUN_1402c69b0)
longlong * FUN_1402c69b0(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  ulonglong uVar4;
  longlong *plVar5;
  ulonglong uVar6;
  
  uVar6 = 0;
  while( true ) {
    plVar5 = (longlong *)param_1[9];
    if (plVar5 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    uVar4 = (**(code **)(*plVar5 + 0x18))();
    if (uVar4 <= uVar6) break;
    plVar5 = (longlong *)param_1[9];
    if (plVar5 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,uVar6);
    if ((plVar5 != (longlong *)0x0) &&
       (iVar2 = (**(code **)(*plVar5 + 0x10))(plVar5,2), iVar2 == 0xe)) {
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      cVar1 = FUN_1402c3e00(plVar5,uVar3,param_2,param_3);
      if (cVar1 != '\0') {
        return plVar5;
      }
    }
    uVar6 = uVar6 + 1;
  }
  return (longlong *)0x0;
}

// ==== CMsgTransportor::helper_140420590  @140420590  [medium:callgraph-r1]  (orig: FUN_140420590)
longlong FUN_140420590(longlong param_1)

{
  return param_1 + 0x30;
}

// ==== CMsgTransportor::ctor_or_dtor  @140420930  [high:vtable-assign]  (orig: FUN_140420930)
undefined8 * FUN_140420930(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTransportor::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTransportor::ctor_or_dtor  @140420980  [high:vtable-assign]  (orig: FUN_140420980)
void FUN_140420980(undefined8 *param_1)

{
  *param_1 = CMsgTransportor::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTransportor::vfunc_1  @1404209b0  [high:rtti-vtable]  (orig: FUN_1404209b0)
ulonglong FUN_1404209b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x960);
}

// ==== CMsgTransportor::ctor_or_dtor  @140420b00  [high:vtable-assign]  (orig: FUN_140420b00)
undefined8 * FUN_140420b00(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTransportor::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTransportor::vfunc_3  @140420b50  [high:rtti-vtable]  (orig: FUN_140420b50)
void FUN_140420b50(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))(*(longlong **)(lVar2 + 0x90),param_1)
  ;
  if ((plVar3 != (longlong *)0x0) && (**(short **)(param_1 + 0x428) == 2)) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar2 = *(longlong *)(lVar2 + 0x118);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar1 = (**(code **)(*plVar3 + 8))(plVar3);
    FUN_14023e4c0(lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),uVar1);
  }
  return;
}

