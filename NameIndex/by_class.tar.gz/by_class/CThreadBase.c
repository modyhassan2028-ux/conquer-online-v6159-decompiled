// ==== CThreadBase::method_140001080  @140001080  [medium:param1-type]  (orig: FUN_140001080)
bool FUN_140001080(CThreadBase *param_1,bool param_2)

{
  char cVar1;
  bool bVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)FUN_1400396e0();
  *(longlong **)(param_1 + 0x40) = plVar3;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 8))(plVar3,*(undefined8 *)(param_1 + 0x48));
    if (cVar1 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x0001400010c8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      bVar2 = CThreadBase::CreateThread(param_1,"ChatThread",param_2);
      return bVar2;
    }
  }
  return false;
}

// ==== CThreadBase::method_14001b1b0  @14001b1b0  [medium:param1-type]  (orig: FUN_14001b1b0)
bool FUN_14001b1b0(CThreadBase *param_1,bool param_2)

{
  char cVar1;
  bool bVar2;
  ILogKernel *pIVar3;
  
  pIVar3 = ILogKernel::CreateNew();
  *(ILogKernel **)(param_1 + 0x40) = pIVar3;
  if (pIVar3 != (ILogKernel *)0x0) {
    cVar1 = (**(code **)(*(longlong *)pIVar3 + 8))
                      (pIVar3,*(undefined8 *)(param_1 + 0x48),param_1 + 0x50);
    if (cVar1 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x00014001b1fd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      bVar2 = CThreadBase::CreateThread(param_1,"LogThread",param_2);
      return bVar2;
    }
  }
  return false;
}

// ==== CThreadBase::method_14002e450  @14002e450  [medium:param1-type]  (orig: FUN_14002e450)
bool FUN_14002e450(CThreadBase *param_1,bool param_2)

{
  char cVar1;
  bool bVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)FUN_1400f7ef0();
  *(longlong **)(param_1 + 0x40) = plVar3;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 8))(plVar3,*(undefined8 *)(param_1 + 0x48));
    if (cVar1 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x00014002e498. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      bVar2 = CThreadBase::CreateThread(param_1,"UserLoginThread",param_2);
      return bVar2;
    }
  }
  return false;
}

// ==== CThreadBase::method_14002e860  @14002e860  [medium:param1-type]  (orig: FUN_14002e860)
undefined1 FUN_14002e860(CThreadBase *param_1,bool param_2)

{
  undefined8 uVar1;
  bool bVar2;
  undefined1 uVar3;
  code *UNRECOVERED_JUMPTABLE;
  
  bVar2 = CThreadBase::CreateThread(param_1,"WorldThread",param_2);
  if (bVar2) {
    uVar1 = FUN_140067180();
    *(undefined8 *)(param_1 + 0x40) = uVar1;
    UNRECOVERED_JUMPTABLE = (code *)FUN_140508f10(1);
    if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014002e8ab. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (*UNRECOVERED_JUMPTABLE)
                        (*(undefined8 *)(param_1 + 0x40),*(undefined8 *)(param_1 + 0x48));
      return uVar3;
    }
  }
  return 0;
}

// ==== CThreadBase::helper_1400396e0  @1400396e0  [medium:callgraph-r0]  (orig: FUN_1400396e0)
undefined8 FUN_1400396e0(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(200);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140038090(pvVar1);
  }
  return uVar2;
}

// ==== CThreadBase::helper_140067180  @140067180  [medium:callgraph-r0]  (orig: FUN_140067180)
undefined8 FUN_140067180(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(0x2c8);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140066890(pvVar1);
  }
  return uVar2;
}

// ==== CThreadBase::helper_1400f7ef0  @1400f7ef0  [medium:callgraph-r0]  (orig: FUN_1400f7ef0)
undefined8 FUN_1400f7ef0(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  if ((DAT_140975cb8 & 1) == 0) {
    DAT_140975cb8 = DAT_140975cb8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975cb0,"CUserKernel");
    atexit((_func_5014 *)&LAB_1406d66b0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975cb0,0x68);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1400f7e10(pvVar1);
  }
  return uVar2;
}

