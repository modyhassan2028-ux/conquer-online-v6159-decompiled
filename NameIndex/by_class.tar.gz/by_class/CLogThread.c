// ==== CLogThread::ctor_or_dtor  @14001b100  [high:vtable-assign]  (orig: FUN_14001b100)
CThreadBase * FUN_14001b100(CThreadBase *param_1,undefined8 param_2,char *param_3)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CLogThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = param_2;
  if (param_3 != (char *)0x0) {
    tq::SafeCopy((char *)(param_1 + 0x50),param_3,0x80);
  }
  return param_1;
}

// ==== CLogThread::ctor_or_dtor  @14001b180  [high:vtable-assign]  (orig: FUN_14001b180)
void FUN_14001b180(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CLogThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x00014001b1a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CLogThread::vfunc_1  @14001b220  [high:rtti-vtable]  (orig: FUN_14001b220)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14001b220(longlong param_1)

{
  int iVar1;
  undefined1 auStack_778 [32];
  char local_758 [1855];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_778;
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x10))();
  if (0 < iVar1) {
    (**(code **)(**(longlong **)(param_1 + 0x48) + 0x10))();
    _snprintf(local_758,0x740,"error:: LOG_MSG_PORT have %d LOG not print!");
    local_19 = 0;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x28))
              (*(longlong **)(param_1 + 0x40),param_1 + 0x50,local_758,1);
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))();
  *(undefined8 *)(param_1 + 0x40) = 0;
  return;
}

// ==== CLogThread::vfunc_2  @14001b2c0  [high:rtti-vtable]  (orig: FUN_14001b2c0)
void FUN_14001b2c0(void)

{
  return;
}

// ==== CLogThread::vfunc_3  @14001b2d0  [high:rtti-vtable]  (orig: FUN_14001b2d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14001b2d0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  uint uVar3;
  undefined1 auStack_8a8 [32];
  char *local_888;
  undefined4 *local_880;
  ulong local_878;
  longlong local_870;
  undefined4 local_868;
  undefined4 local_864;
  undefined4 local_860;
  undefined8 local_858;
  CTickAnalyst local_850 [24];
  CTickAnalyst local_838 [32];
  char local_818;
  undefined1 local_817 [1854];
  undefined1 local_d9;
  ulonglong local_18;
  
  local_858 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_8a8;
  local_870 = param_1;
  if ((DAT_1409754fc & 1) == 0) {
    DAT_1409754fc = DAT_1409754fc | 1;
    DAT_1409754f8 = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))
                    (*(longlong **)(param_1 + 0x48),s___AVCLogThread___140949440._20_4_);
  CTickAnalyst::CTickAnalyst(local_838,0x3c);
  uVar2 = tq::TimeGet(0);
  local_878 = uVar2;
  if (cVar1 == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))();
    uVar3 = uVar2 - DAT_1409754f8;
    if (uVar3 < 0x2711) {
      DAT_1409754f8 = DAT_1409754f8 + 1000;
    }
    else {
      local_818 = '\0';
      memset(local_817,0,0x73f);
      _snprintf(&local_818,0x740,"error:: resync CLogThread::OnTimer cumulative deviation %ldms",
                (ulonglong)uVar3);
      local_d9 = 0;
      (**(code **)(**(longlong **)(param_1 + 0x40) + 0x28))
                (*(longlong **)(param_1 + 0x40),param_1 + 0x50,&local_818,1);
      DAT_1409754f8 = uVar2;
    }
  }
  else {
    while( true ) {
      local_880 = &local_868;
      local_888 = &local_818;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x800);
      if (cVar1 == '\0') break;
      CTickAnalyst::CTickAnalyst(local_850,0x3d);
      local_888 = (char *)CONCAT44(local_888._4_4_,local_868);
      (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))
                (*(longlong **)(param_1 + 0x40),local_864,&local_818,local_860);
      CTickAnalyst::~CTickAnalyst(local_850);
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_1409754f8) < 1000) {
    s___AVCLogThread___140949440._20_4_ = 1000 - (uVar2 - DAT_1409754f8);
  }
  else {
    s___AVCLogThread___140949440[0x14] = '\0';
    s___AVCLogThread___140949440[0x15] = '\0';
    s___AVCLogThread___140949440[0x16] = '\0';
    s___AVCLogThread___140949440[0x17] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_838);
  return 1;
}

// ==== CLogThread::ctor_or_dtor  @14001b4e0  [high:vtable-assign]  (orig: FUN_14001b4e0)
CThreadBase * FUN_14001b4e0(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CLogThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

