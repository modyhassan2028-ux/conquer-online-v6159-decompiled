// ==== CNpcManager::helper_140159680  @140159680  [medium:callgraph-r0]  (orig: FUN_140159680)
longlong FUN_140159680(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975ba0;
  if (DAT_140975ba0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpcManager::ctor_or_dtor  @1401596e0  [high:vtable-assign]  (orig: FUN_1401596e0)
void FUN_1401596e0(undefined8 *param_1)

{
  *param_1 = CNpcManager::vftable;
  *param_1 = INpcManager::vftable;
  return;
}

// ==== CNpcManager::vfunc_1  @140159710  [high:rtti-vtable]  (orig: FUN_140159710)
void FUN_140159710(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CNpcManager::helper_140159a40  @140159a40  [medium:callgraph-r0]  (orig: FUN_140159a40)
void FUN_140159a40(void *param_1)

{
  if ((DAT_140975e58 & 1) == 0) {
    DAT_140975e58 = DAT_140975e58 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975e50,"CNpcManager");
    atexit((_func_5014 *)&LAB_1406d68c0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140159a95. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975e50,param_1);
  return;
}

// ==== CNpcManager::ctor_or_dtor  @140159b00  [high:vtable-assign]  (orig: FUN_140159b00)
undefined8 * FUN_140159b00(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = INpcManager::vftable;
  *param_1 = CNpcManager::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  return param_1;
}

// ==== CNpcManager::ctor_or_dtor  @140159b30  [high:vtable-assign]  (orig: FUN_140159b30)
undefined8 * FUN_140159b30(undefined8 *param_1,byte param_2)

{
  *param_1 = CNpcManager::vftable;
  *param_1 = INpcManager::vftable;
  if ((param_2 & 1) != 0) {
    FUN_140159a40();
  }
  return param_1;
}

// ==== CNpcManager::helper_14015a010  @14015a010  [medium:callgraph-r0]  (orig: FUN_14015a010)
undefined1 FUN_14015a010(longlong param_1,undefined4 param_2,short *param_3,short *param_4)

{
  char cVar1;
  longlong lVar2;
  int iVar3;
  short sVar4;
  short sVar5;
  int iVar6;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar2 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                    (*(longlong **)(lVar2 + 0x98),param_2,1);
  if (lVar2 != 0) {
    iVar6 = 3;
    do {
      sVar4 = *param_3 + (short)iVar6;
      iVar3 = 0;
      do {
        sVar5 = *param_4 + (short)iVar3;
        cVar1 = FUN_1402c3cc0(lVar2,sVar4,sVar5);
        if (cVar1 != '\0') {
          *param_3 = sVar4;
          *param_4 = sVar5;
          return 1;
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < 4);
      iVar6 = iVar6 + -1;
    } while (-1 < iVar6);
    return 0;
  }
  log_InlineLogDBERROR("table:cq_map, CNpcManager::CheckBornPoint can not find map(%u).");
  return 0;
}

// ==== CNpcManager::vfunc_4  @14015a110  [high:rtti-vtable]  (orig: FUN_14015a110)
undefined8 FUN_14015a110(longlong param_1,void *param_2,undefined8 param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined4 local_58 [6];
  undefined2 local_40;
  
  if (param_2 == (void *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar1 = FUN_14015a010(param_1,*(undefined4 *)((longlong)param_2 + 4),(longlong)param_2 + 0x14,
                          (longlong)param_2 + 0x16);
    if (cVar1 != '\0') {
      lVar2 = FUN_140391b90();
      if (lVar2 != 0) {
        plVar3 = (longlong *)FUN_140159680();
        lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3,*(undefined2 *)((longlong)param_2 + 0x1a));
        if (lVar4 != 0) {
          memcpy(local_58,param_2,0x40);
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          plVar3 = (longlong *)FUN_1400876b0(uVar5);
          local_58[0] = (**(code **)(*plVar3 + 0xb8))(plVar3);
          local_40 = 1;
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          plVar3 = (longlong *)FUN_1400876b0(uVar5);
          lVar6 = (**(code **)(*plVar3 + 0x10))(plVar3,*(undefined4 *)((longlong)param_2 + 4),1);
          if ((lVar6 != 0) &&
             (cVar1 = FUN_140390070(lVar2,*(undefined4 *)(param_1 + 8),lVar4,local_58,param_3),
             cVar1 != '\0')) {
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            plVar3 = (longlong *)FUN_1400875f0(uVar5);
            plVar3 = (longlong *)(**(code **)(*plVar3 + 0x30))(plVar3);
            (**(code **)(*plVar3 + 0x28))(plVar3,lVar2 + 0x10);
            FUN_14038b420(lVar2);
            return 1;
          }
        }
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 8))(lVar2 + 0x10);
      }
      return 0;
    }
  }
  return 0;
}

// ==== CNpcManager::vfunc_5  @14015a2a0  [high:rtti-vtable]  (orig: FUN_14015a2a0)
longlong FUN_14015a2a0(longlong param_1,longlong *param_2,undefined2 param_3,uint param_4,
                      undefined2 param_5,undefined2 param_6,undefined1 param_7)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined2 local_44;
  undefined2 local_42;
  undefined2 local_40;
  undefined2 local_3e;
  undefined1 local_3c;
  uint local_20;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_4 < 3) {
    lVar2 = FUN_140391b90();
    if (lVar2 != 0) {
      plVar3 = (longlong *)FUN_140159680();
      lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3);
      if (lVar4 != 0) {
        memset(&local_58,0,0x40);
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
        plVar3 = (longlong *)FUN_1400876b0(uVar5);
        local_58 = (**(code **)(*plVar3 + 0xe8))(plVar3);
        local_40 = 1;
        local_3c = 1;
        local_3e = param_3;
        local_4c = (**(code **)(*param_2 + 8))(param_2);
        local_54 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
        local_44 = param_5;
        local_42 = param_6;
        local_50 = 0;
        local_48 = 0;
        local_20 = param_4;
        lVar6 = (**(code **)(param_2[2] + 0x160))(param_2 + 2);
        if ((lVar6 != 0) &&
           (cVar1 = FUN_140391c30(lVar2,*(undefined4 *)(param_1 + 8),lVar4,&local_58,param_2,param_7
                                 ), cVar1 != '\0')) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          plVar3 = (longlong *)FUN_1400875f0(uVar5);
          plVar3 = (longlong *)(**(code **)(*plVar3 + 0x30))(plVar3);
          (**(code **)(*plVar3 + 0x28))(plVar3,lVar2 + 0x10);
          FUN_14038b420(lVar2);
          return lVar2;
        }
      }
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 8))(lVar2 + 0x10);
    }
    return 0;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpcManager::vfunc_3  @14015a970  [high:rtti-vtable]  (orig: FUN_14015a970)
undefined8 FUN_14015a970(longlong param_1,void *param_2)

{
  longlong *plVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 local_res18;
  longlong *local_res20;
  longlong *local_d0;
  longlong *local_c8 [3];
  longlong *local_b0;
  longlong *local_a8;
  undefined8 local_a0;
  longlong *local_98;
  undefined8 local_88;
  longlong *local_80 [3];
  undefined1 local_68 [12];
  undefined4 local_5c;
  undefined2 local_50;
  undefined1 local_4c;
  
  local_88 = 0xfffffffffffffffe;
  plVar13 = (longlong *)0x0;
  lVar7 = FUN_140391b90();
  if (lVar7 != 0) {
    plVar10 = DAT_140975ba0;
    if (DAT_140975ba0 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = plVar13;
    }
    lVar8 = (**(code **)(*plVar10 + 0x40))(plVar10,*(undefined2 *)((longlong)param_2 + 0x1a));
    if (lVar8 != 0) {
      memcpy(local_68,param_2,0x40);
      local_5c = 0;
      local_4c = 0;
      local_50 = 1;
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      plVar10 = (longlong *)FUN_1400876b0(uVar9);
      lVar11 = (**(code **)(*plVar10 + 0x20))(plVar10,*(undefined4 *)((longlong)param_2 + 4),1);
      if (lVar11 != 0) {
        uVar6 = 0;
        cVar2 = FUN_140390070(lVar7,*(undefined4 *)(param_1 + 8),lVar8,local_68,0);
        if (cVar2 != '\0') {
          uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          plVar10 = (longlong *)FUN_1400875f0(uVar9);
          plVar10 = (longlong *)(**(code **)(*plVar10 + 0x30))(plVar10);
          (**(code **)(*plVar10 + 0x28))(plVar10,lVar7 + 0x10);
          FUN_14038b420(lVar7);
          plVar10 = (longlong *)
                    (**(code **)(*(longlong *)**(undefined8 **)(lVar7 + 0x140) + 0x10))
                              ((longlong *)**(undefined8 **)(lVar7 + 0x140),0x15);
          uVar3 = (**(code **)(*plVar10 + 0x48))(plVar10);
          if ((uVar3 >> 0x11 & 1) == 0) {
            return 1;
          }
          local_res20 = operator_new(8);
          local_c8[0] = plVar13;
          if (local_res20 != (longlong *)0x0) {
            *local_res20 = (longlong)local_c8;
            local_c8[0] = local_res20;
          }
          local_b0 = (longlong *)0x0;
          local_a8 = (longlong *)0x0;
          local_a0 = 0;
          uVar4 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x40))(lVar7 + 0x10);
          uVar5 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x48))(lVar7 + 0x10);
          local_res18 = CONCAT44(uVar5,uVar4);
          FUN_1402d0e40(lVar11,local_c8,local_res18,0,CONCAT44(uVar6,0x1001));
          plVar10 = local_b0;
          local_98 = (longlong *)0x0;
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_c8[0];
          local_98 = local_c8[0];
          do {
            plVar12 = local_a8;
            local_80[0] = (longlong *)0x0;
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            local_80[0] = local_c8[0];
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_c8[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar10 == plVar12) goto LAB_14015acca;
            local_d0 = (longlong *)0x0;
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar12 = plVar13;
            }
            else {
              plVar12 = (longlong *)*plVar1;
            }
            if ((longlong *)plVar12[4] <= plVar10) {
              _invalid_parameter_noinfo();
            }
            if (*plVar10 != 0) {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar12 = plVar13;
              }
              else {
                plVar12 = (longlong *)*plVar1;
              }
              if ((longlong *)plVar12[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              cVar2 = (**(code **)(*(longlong *)*plVar10 + 0x40))((longlong *)*plVar10,&local_d0);
              if ((((cVar2 != '\0') && (local_res20 = (longlong *)0x0, local_d0 != (longlong *)0x0))
                  && (cVar2 = (**(code **)(*local_d0 + 0x298))(local_d0,0x1001,&local_res20),
                     cVar2 != '\0')) &&
                 (lVar8 = (**(code **)(*local_res20 + 0xa8))(local_res20,local_80),
                 (*(uint *)(lVar8 + 4) >> 0xf & 1) != 0)) {
                uVar6 = (**(code **)(*local_res20 + 8))();
                FUN_140391250(lVar7,uVar6);
LAB_14015acca:
                if (local_b0 != (longlong *)0x0) {
                  operator_delete(local_b0);
                }
                local_b0 = (longlong *)0x0;
                local_a8 = (longlong *)0x0;
                local_a0 = 0;
                operator_delete(local_c8[0]);
                return 1;
              }
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar12 = plVar13;
            }
            else {
              plVar12 = (longlong *)*plVar1;
            }
            if ((longlong *)plVar12[4] <= plVar10) {
              _invalid_parameter_noinfo();
            }
            plVar10 = plVar10 + 1;
          } while( true );
        }
      }
    }
    (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))();
  }
  return 0;
}

// ==== CNpcManager::vfunc_2  @14015ad20  [high:rtti-vtable]  (orig: FUN_14015ad20)
undefined8 FUN_14015ad20(longlong param_1)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  uint uVar8;
  undefined4 *puVar10;
  longlong *plVar11;
  ulonglong local_res10;
  longlong *local_res18;
  longlong *local_90 [3];
  undefined4 *local_78;
  undefined4 *local_70;
  undefined8 local_68;
  undefined8 *local_60;
  undefined8 local_58;
  undefined8 local_50;
  longlong *local_48;
  longlong *local_40;
  undefined8 local_30;
  longlong *local_28;
  longlong *plVar9;
  
  local_30 = 0xfffffffffffffffe;
  log_InlineLogMessage("DelAllMonster() start...");
  uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar5 = (longlong *)FUN_1400875f0(uVar4);
  lVar6 = (**(code **)(*plVar5 + 0x30))(plVar5);
  local_60 = (undefined8 *)(lVar6 + 0x10);
  local_50 = **(undefined8 **)(lVar6 + 0x40);
  plVar5 = (longlong *)0x0;
  local_58 = *local_60;
  local_48 = (longlong *)0x0;
  local_res18 = operator_new(8);
  local_90[0] = plVar5;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)local_90;
    local_90[0] = local_res18;
  }
  local_78 = (undefined4 *)0x0;
  local_70 = (undefined4 *)0x0;
  local_68 = 0;
  local_res10 = (ulonglong)local_res18 & 0xffffffff00000000;
  plVar9 = plVar5;
  do {
    cVar2 = FUN_1400ce310(&local_60);
    if (cVar2 == '\0') {
LAB_14015ae93:
      puVar10 = local_78;
      local_40 = (longlong *)0x0;
      if (local_70 < local_78) {
        _invalid_parameter_noinfo();
      }
      plVar9 = local_90[0];
      local_40 = local_90[0];
      while( true ) {
        puVar1 = local_70;
        local_28 = (longlong *)0x0;
        if (local_70 < local_78) {
          _invalid_parameter_noinfo();
        }
        local_28 = local_90[0];
        if ((plVar9 == (longlong *)0x0) || (plVar9 != local_90[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar10 == puVar1) break;
        uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
        plVar7 = (longlong *)FUN_1400875f0(uVar4);
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x30))(plVar7);
        if (plVar9 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar11 = plVar5;
        }
        else {
          plVar11 = (longlong *)*plVar9;
        }
        if ((undefined4 *)plVar11[4] <= puVar10) {
          _invalid_parameter_noinfo();
        }
        (**(code **)(*plVar7 + 0x30))(plVar7,*puVar10);
        if (plVar9 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar5;
        }
        else {
          plVar7 = (longlong *)*plVar9;
        }
        if ((undefined4 *)plVar7[4] <= puVar10) {
          _invalid_parameter_noinfo();
        }
        puVar10 = puVar10 + 1;
      }
      log_InlineLogMessage("DelAllMonster() ok.");
      if (local_78 != (undefined4 *)0x0) {
        operator_delete(local_78);
      }
      local_78 = (undefined4 *)0x0;
      local_70 = (undefined4 *)0x0;
      local_68 = 0;
      operator_delete(local_90[0]);
      return 1;
    }
    uVar8 = (int)plVar9 + 1;
    plVar9 = (longlong *)(ulonglong)uVar8;
    if (1000000 < uVar8) {
      log_InlineLogERROR(&DAT_1406d9c10);
      goto LAB_14015ae93;
    }
    if ((local_48 != (longlong *)0x0) &&
       (cVar2 = (**(code **)(*local_48 + 0x298))(local_48,0x1002,&local_res18), cVar2 != '\0')) {
      iVar3 = (**(code **)(*local_48 + 0x10))();
      local_res10 = CONCAT44(local_res10._4_4_,iVar3);
      if (iVar3 != 0) {
        FUN_140037fe0(local_90,&local_res10);
      }
    }
  } while( true );
}

// ==== CNpcManager::helper_140226630  @140226630  [medium:callgraph-r2]  (orig: FUN_140226630)
undefined8 FUN_140226630(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CNpcManager::helper_1402cdf50  @1402cdf50  [medium:callgraph-r1]  (orig: FUN_1402cdf50)
void FUN_1402cdf50(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  rsize_t _DstSize;
  void *_Src;
  void *pvVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 local_res18;
  longlong local_28;
  void *pvStack_20;
  
  _Src = (void *)param_1[4];
  pvVar1 = (void *)param_1[3];
  uVar3 = (longlong)_Src - (longlong)pvVar1 >> 3;
  local_res18 = param_3;
  if (uVar3 < param_2) {
    if (_Src < pvVar1) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    pvStack_20 = _Src;
    FUN_1402cd180(param_1,&local_28,param_2 - (param_1[4] - param_1[3] >> 3),&local_res18);
    return;
  }
  if (uVar3 <= param_2) {
    return;
  }
  if (_Src < pvVar1) {
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar4 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar4;
  }
  else {
    lVar5 = *plVar2;
  }
  pvVar1 = (void *)(uVar3 + param_2 * 8);
  if (pvVar1 <= *(void **)(lVar5 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar4 = *plVar2;
    }
    if (*(void **)(lVar4 + 0x18) <= pvVar1) goto LAB_1402ce037;
  }
  _invalid_parameter_noinfo();
LAB_1402ce037:
  if ((pvVar1 < (void *)param_1[3]) || ((void *)param_1[4] < pvVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (pvVar1 != _Src) {
    lVar4 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar4 * 8;
    if (0 < lVar4) {
      memmove_s(pvVar1,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)pvVar1);
  }
  return;
}

// ==== CNpcManager::helper_1402d0e40  @1402d0e40  [medium:callgraph-r0]  (orig: FUN_1402d0e40)
void FUN_1402d0e40(longlong param_1,longlong param_2,undefined8 param_3,int param_4,uint param_5)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  int iVar10;
  int local_res18;
  int iStackX_1c;
  
  iVar1 = param_4 * 2 + 1;
  iVar1 = iVar1 * iVar1;
  FUN_1402cdf50(param_2,(longlong)iVar1,0);
  local_res18 = (int)param_3;
  iVar2 = local_res18 / 0x12 + -1;
  iVar10 = 0;
  if (0 < iVar2) {
    iVar10 = iVar2;
  }
  if (iVar10 <= local_res18 / 0x12 + 1) {
    do {
      iVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))();
      if ((iVar2 + -1) / 0x12 + 1 <= iVar10) {
        return;
      }
      iStackX_1c = (int)((ulonglong)param_3 >> 0x20);
      iVar3 = iStackX_1c / 0x12 + -1;
      iVar2 = 0;
      if (0 < iVar3) {
        iVar2 = iVar3;
      }
      if (iVar2 <= iStackX_1c / 0x12 + 1) {
        do {
          iVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))();
          if ((iVar3 + -1) / 0x12 + 1 <= iVar2) break;
          uVar9 = 0;
          lVar6 = FUN_14017eea0(param_1,iVar10,iVar2);
          lVar6 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
          if (lVar6 != 0) {
            do {
              lVar6 = FUN_14017eea0(param_1,iVar10,iVar2);
              plVar7 = (longlong *)
                       (**(code **)(**(longlong **)(lVar6 + 8) + 0x18))
                                 (*(longlong **)(lVar6 + 8),uVar9);
              if ((plVar7 != (longlong *)0x0) &&
                 (uVar4 = (**(code **)(*plVar7 + 0x18))(plVar7), (uVar4 & param_5 & 0xfff) != 0)) {
                iVar3 = (**(code **)(*plVar7 + 0x28))(plVar7);
                iVar5 = (**(code **)(*plVar7 + 0x20))(plVar7);
                uVar4 = iVar5 - local_res18 >> 0x1f;
                iVar5 = (iVar5 - local_res18 ^ uVar4) - uVar4;
                uVar4 = iVar3 - iStackX_1c >> 0x1f;
                iVar3 = (iVar3 - iStackX_1c ^ uVar4) - uVar4;
                if (iVar3 < iVar5) {
                  iVar3 = iVar5;
                }
                if (iVar3 <= param_4) {
                  iVar3 = (**(code **)(*plVar7 + 0x28))(plVar7);
                  iVar5 = (**(code **)(*plVar7 + 0x20))(plVar7);
                  iVar3 = (((param_4 - iStackX_1c) + iVar3) * (param_4 * 2 + 1) - local_res18) +
                          param_4 + iVar5;
                  if ((iVar3 < 0) || (iVar1 <= iVar3)) {
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  else {
                    if ((ulonglong)
                        (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3) <=
                        (ulonglong)(longlong)iVar3) {
                      _invalid_parameter_noinfo();
                    }
                    *(longlong **)(*(longlong *)(param_2 + 0x18) + (longlong)iVar3 * 8) = plVar7;
                  }
                }
              }
              uVar9 = uVar9 + 1;
              lVar6 = FUN_14017eea0(param_1,iVar10,iVar2);
              uVar8 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
            } while (uVar9 < uVar8);
          }
          iVar2 = iVar2 + 1;
        } while (iVar2 <= iStackX_1c / 0x12 + 1);
      }
      iVar10 = iVar10 + 1;
    } while (iVar10 <= local_res18 / 0x12 + 1);
  }
  return;
}

// ==== CNpcManager::helper_14032d550  @14032d550  [medium:callgraph-r1]  (orig: FUN_14032d550)
undefined8 FUN_14032d550(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,*(undefined4 *)(param_1 + 0xdd0));
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,1,1);
    return uVar2;
  }
  return 0;
}

// ==== CNpcManager::helper_14032d5c0  @14032d5c0  [medium:callgraph-r1]  (orig: FUN_14032d5c0)
undefined8 FUN_14032d5c0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,*(undefined4 *)(param_1 + 0xdd4));
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,1,1);
    return uVar2;
  }
  return 0;
}

// ==== CNpcManager::helper_140362d00  @140362d00  [medium:callgraph-r1]  (orig: FUN_140362d00)
undefined8 FUN_140362d00(undefined8 param_1,undefined8 param_2)

{
  FUN_140097920();
  FUN_140362c00(param_1,param_2);
  return param_1;
}

// ==== CNpcManager::helper_14038e930  @14038e930  [medium:callgraph-r1]  (orig: FUN_14038e930)
undefined8 * FUN_14038e930(undefined1 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = IGameData::vftable;
    *puVar1 = CGameData<&char*_szPetTable,&char*_szID>::vftable;
    *(undefined1 *)(puVar1 + 2) = param_1;
    puVar1[1] = 0;
  }
  return puVar1;
}

// ==== CNpcManager::helper_140390070  @140390070  [medium:callgraph-r0]  (orig: FUN_140390070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_140390070(longlong *param_1,undefined4 param_2,undefined8 *param_3,undefined4 *param_4,
                  longlong param_5)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  undefined4 uVar4;
  ulong uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  longlong local_478;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  *(undefined4 *)(param_1 + 0x2d) = param_2;
  if (param_3 == (undefined8 *)0x0) {
    local_488 = 0x13e;
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar2 = false;
  }
  else {
    *(undefined4 *)(param_1 + 0x11) = *param_4;
    iVar3 = tq::RandGet(8);
    *(int *)((longlong)param_1 + 0xe4) = iVar3;
    lVar6 = FUN_140008520((int)param_1[0x2d]);
    if (*(longlong *)(lVar6 + 0x98) == 0) {
      local_488 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x98) + 0x20))
                      (*(longlong **)(lVar6 + 0x98),param_4[1],1);
    param_1[0x21] = lVar6;
    *(uint *)((longlong)param_1 + 0xdc) = (uint)*(ushort *)(param_4 + 5);
    *(uint *)(param_1 + 0x1c) = (uint)*(ushort *)((longlong)param_4 + 0x16);
    *(undefined4 *)(param_1 + 0x1d) = 0xffffffff;
    lVar6 = 5;
    lVar8 = 0;
    do {
      *(undefined4 *)((longlong)param_1 + lVar6 * 4 + 0xec) = 0;
      lVar6 = lVar6 + -1;
    } while (-1 < lVar6);
    *(undefined4 *)((longlong)param_1 + 0x104) = 0;
    *(undefined4 *)((longlong)param_1 + 0x164) = param_4[2];
    *(undefined4 *)((longlong)param_1 + 0x16c) = param_4[8];
    *(undefined4 *)(param_1 + 0x2e) = param_4[10];
    *(undefined4 *)((longlong)param_1 + 0x174) = param_4[0xb];
    *(undefined4 *)(param_1 + 0x2f) = param_4[0xc];
    *(undefined1 *)((longlong)param_1 + 0x17e) = *(undefined1 *)(param_4 + 9);
    *(undefined1 *)((longlong)param_1 + 0x17d) = *(undefined1 *)(param_4 + 0xd);
    param_1[0x28] = (longlong)param_3;
    plVar7 = (longlong *)(**(code **)(*(longlong *)*param_3 + 0x10))((longlong *)*param_3,0x2e);
    uVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
    *(undefined4 *)(param_1 + 0x22) = uVar4;
    if (param_4[0xf] == 0) {
      plVar7 = (longlong *)
               (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],4);
      uVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
      *(undefined4 *)((longlong)param_1 + 0x114) = uVar4;
    }
    else {
      *(undefined4 *)((longlong)param_1 + 0x114) = param_4[0xf];
    }
    plVar7 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],5);
    uVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
    *(undefined4 *)(param_1 + 0x23) = uVar4;
    plVar7 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0x12);
    uVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
    *(undefined4 *)(param_1 + 0x26) = uVar4;
    uVar5 = tq::TimeGet(0);
    *(ulong *)((longlong)param_1 + 0x134) = uVar5;
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    *(undefined4 *)((longlong)param_1 + 0x11c) = uVar4;
    uVar4 = (**(code **)(*param_1 + 0x50))(param_1);
    *(undefined4 *)(param_1 + 0x24) = uVar4;
    if (param_1[0x21] == 0) {
      bVar2 = false;
    }
    else {
      local_478 = FUN_1403e9370(0x20);
      if (local_478 != 0) {
        lVar8 = FUN_1403e8ca0(local_478,(int)param_1[0x2d],param_1 + 2);
      }
      param_1[0x25] = lVar8;
      if (lVar8 == 0) {
        local_488 = 0x168;
        log_InlineLogERROR(&DAT_1406d9c10);
        bVar2 = false;
      }
      else {
        lVar6 = FUN_1404cda70((int)param_1[0x2d],param_1);
        param_1[6] = lVar6;
        if (lVar6 == 0) {
          local_488 = 0x16a;
          log_InlineLogERROR(&DAT_1406d9c10);
          bVar2 = false;
        }
        else {
          plVar7 = (longlong *)
                   (**(code **)(**(longlong **)param_1[0x28] + 0x20))
                             (*(longlong **)param_1[0x28],&DAT_140951730);
          uVar4 = (**(code **)(*plVar7 + 0x40))(plVar7);
          cVar1 = FUN_1404cd460(param_1[6],uVar4);
          if (cVar1 == '\0') {
            local_488 = 0x16b;
            log_InlineLogERROR(&DAT_1406d9c10);
            bVar2 = false;
          }
          else {
            *(undefined4 *)(param_1 + 7) = 500;
            uVar5 = tq::TimeGet(0);
            *(ulong *)((longlong)param_1 + 0x3c) = uVar5;
            iVar3 = (**(code **)(*param_1 + 8))(param_1);
            if (iVar3 - 0xaae61U < 99999) {
              iVar3 = param_4[0xe];
              if ((iVar3 < 0) || (2 < iVar3)) {
                local_488 = 0x177;
                log_InlineLogERROR(&DAT_1406d9c10);
                return false;
              }
              *(int *)(param_1 + 0x29) = iVar3;
            }
            else {
              FUN_14044f280(local_468);
              iVar3 = FUN_14044f300(local_468,param_4);
              if (iVar3 == 0) {
                local_488 = 0x172;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
              }
              FUN_14044f2d0(local_468);
            }
            if ((*(uint *)(param_1 + 0x11) < 0x7a121) || (599999 < *(uint *)(param_1 + 0x11))) {
              bVar2 = true;
            }
            else if ((param_4[3] == 0) || (*(char *)(param_4 + 7) == '\0')) {
              bVar2 = true;
            }
            else {
              plVar7 = (longlong *)FUN_14038e930(0);
              param_1[0x10] = (longlong)plVar7;
              if (plVar7 == (longlong *)0x0) {
                local_488 = 0x186;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                cVar1 = (**(code **)(*plVar7 + 0x40))(plVar7);
                if (cVar1 != '\0') {
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],1,param_4[3]);
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],2,*(undefined1 *)(param_4 + 7));
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],3,param_4[2]);
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],5,*(undefined2 *)((longlong)param_4 + 0x1a));
                  if (param_5 == 0) {
                    plVar7 = (longlong *)
                             (**(code **)(*(longlong *)*param_3 + 0x10))((longlong *)*param_3,1);
                    uVar9 = (**(code **)(*plVar7 + 0x78))(plVar7);
                    (**(code **)(*(longlong *)param_1[0x10] + 0x68))
                              ((longlong *)param_1[0x10],4,uVar9);
                  }
                  else {
                    (**(code **)(*(longlong *)param_1[0x10] + 0x68))
                              ((longlong *)param_1[0x10],4,param_5);
                  }
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],6,*(undefined4 *)((longlong)param_1 + 0x114))
                  ;
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],7,(int)param_1[0x23]);
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],8,param_4[1]);
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],9,*(undefined2 *)(param_4 + 5));
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],10,*(undefined2 *)((longlong)param_4 + 0x16))
                  ;
                  (**(code **)(*(longlong *)param_1[0x10] + 0x60))
                            ((longlong *)param_1[0x10],0xb,param_4[4]);
                  iVar3 = (**(code **)(*(longlong *)param_1[0x10] + 0x50))();
                  return iVar3 != 0;
                }
                if (param_1[0x10] != 0) {
                  (**(code **)(*(longlong *)param_1[0x10] + 0x58))();
                  param_1[0x10] = 0;
                }
              }
              bVar2 = false;
            }
          }
        }
      }
    }
  }
  return bVar2;
}

// ==== CNpcManager::helper_140391c30  @140391c30  [medium:callgraph-r0]  (orig: FUN_140391c30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140391c30(longlong *param_1,undefined4 param_2,undefined8 *param_3,longlong param_4,
             longlong param_5,char param_6)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong lVar12;
  IStringManager *pIVar13;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  int local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  int local_498;
  longlong *local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (((param_3 == (undefined8 *)0x0) || (param_4 == 0)) || (param_5 == 0)) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0xf6);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x2d) = param_2;
    uVar10 = FUN_140008520(param_2);
    plVar11 = (longlong *)FUN_1400876b0(uVar10);
    lVar12 = (**(code **)(*plVar11 + 0x20))(plVar11,*(undefined4 *)(param_4 + 4),1);
    if ((lVar12 != 0) &&
       (cVar1 = FUN_1402c3cc0(lVar12,*(undefined2 *)(param_4 + 0x14),*(undefined2 *)(param_4 + 0x16)
                             ), cVar1 == '\0')) {
      pIVar13 = theInstance();
      lVar12 = *(longlong *)(param_5 + 0x10);
      uVar10 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_INVALID_COORDINATE");
      (**(code **)(lVar12 + 0x358))((longlong *)(param_5 + 0x10),uVar10);
      return 0;
    }
    local_490 = (longlong *)(param_5 + 0x10);
    local_4c8 = (**(code **)(*local_490 + 0x18))();
    cVar1 = FUN_140390070(param_1,param_2,param_3,param_4);
    if (cVar1 == '\0') {
      local_4c8 = CONCAT44(local_4c8._4_4_,0x101);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar10 = 0;
    }
    else {
      iVar3 = (**(code **)(*param_1 + 8))(param_1);
      if (iVar3 - 0xaae61U < 99999) {
        cVar1 = FUN_140388dd0(param_1);
        if ((cVar1 != '\0') &&
           ((iVar3 = (**(code **)(*param_1 + 8))(param_1), 0x1869e < iVar3 - 0xaae61U ||
            ((int)param_1[0x29] != 1)))) {
          uVar4 = FUN_140388e30(param_1);
          uVar10 = FUN_140008520((int)param_1[0x2d]);
          uVar10 = FUN_1400877e0(uVar10);
          lVar12 = FUN_1402f0fe0(uVar10,uVar4,0);
          param_1[0xe] = lVar12;
          if (lVar12 == 0) {
            local_4c8 = CONCAT44(local_4c8._4_4_,0x108);
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar11 = (longlong *)
                      (**(code **)(*(longlong *)*param_3 + 0x20))
                                ((longlong *)*param_3,&DAT_140951730);
            (**(code **)(*plVar11 + 0x40))(plVar11);
            FUN_140388e30(param_1);
            log_InlineLogERROR("Can\'t find magic type [%d] in monster type [%d]");
            return 0;
          }
        }
        FUN_140362d00(param_1 + 8,param_5 + 0x1210);
        iVar3 = (**(code **)(*param_1 + 8))(param_1);
        if ((iVar3 - 0xaae61U < 99999) && ((int)param_1[0x29] == 2)) {
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x30))();
          *(undefined4 *)(param_1 + 0x16) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0xf8))();
          *(undefined4 *)((longlong)param_1 + 0xb4) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x100))();
          *(undefined4 *)(param_1 + 0x17) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x108))();
          *(undefined4 *)((longlong)param_1 + 0xbc) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x110))();
          *(undefined4 *)(param_1 + 0x18) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x3f0))();
          *(undefined4 *)((longlong)param_1 + 0xc4) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 200))();
          *(undefined4 *)((longlong)param_1 + 0xcc) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar2 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x38))();
          *(undefined2 *)((longlong)param_1 + 0x8c) = uVar2;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar2 = FUN_140373e50(lVar12 + 0xe78);
          *(undefined2 *)((longlong)param_1 + 0x8e) = uVar2;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x118))();
          *(undefined4 *)(param_1 + 0x12) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x1b0))();
          *(undefined4 *)((longlong)param_1 + 0x94) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x1b8))();
          *(undefined4 *)(param_1 + 0x13) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x1c0))();
          *(undefined4 *)((longlong)param_1 + 0x9c) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x128))();
          *(undefined4 *)(param_1 + 0x14) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x120))();
          *(undefined4 *)((longlong)param_1 + 0xa4) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x130))();
          *(undefined4 *)(param_1 + 0x15) = uVar4;
          lVar12 = FUN_14038c750(param_1 + 8);
          uVar4 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x138))();
          *(undefined4 *)((longlong)param_1 + 0xac) = uVar4;
          uVar10 = FUN_14038c750(param_1 + 8);
          uVar4 = FUN_14018eb30(uVar10);
          *(undefined4 *)(param_1 + 0x1b) = uVar4;
          uVar10 = FUN_14038c750(param_1 + 8);
          uVar4 = FUN_14032d5c0(uVar10);
          *(undefined4 *)(param_1 + 0x1a) = uVar4;
          uVar10 = FUN_14038c750(param_1 + 8);
          uVar4 = FUN_14032d550(uVar10);
          *(undefined4 *)((longlong)param_1 + 0xd4) = uVar4;
          *(undefined4 *)(param_1 + 0x19) = 3;
        }
        FUN_140454650(local_478);
        if (param_6 == '\0') {
          local_498 = (**(code **)(*param_1 + 0x58))(param_1);
        }
        else {
          local_498 = (**(code **)(*param_1 + 0x58))(param_1);
          local_498 = local_498 + 10000;
        }
        plVar11 = (longlong *)(**(code **)(*(longlong *)*param_3 + 0x10))((longlong *)*param_3,0x27)
        ;
        uVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
        uVar5 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
        uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
        uVar7 = (**(code **)(param_1[2] + 0x30))(param_1 + 2);
        uVar10 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar8 = (**(code **)(*param_1 + 0x50))(param_1);
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        local_4b0 = local_498;
        local_4c8 = uVar10;
        local_4c0 = uVar7;
        local_4b8 = uVar4;
        local_4a8 = uVar6;
        local_4a0 = uVar5;
        iVar3 = FUN_1404546d0(local_478,uVar9,uVar8,*(undefined4 *)(param_4 + 0x38));
        if (iVar3 == 0) {
          local_4c8 = CONCAT44(local_4c8._4_4_,0x12f);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*local_490 + 0x350))(local_490,local_478);
        }
        FUN_1404546a0(local_478);
        uVar10 = 1;
      }
      else {
        local_4c8 = CONCAT44(local_4c8._4_4_,0x103);
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar10 = 0;
      }
    }
  }
  return uVar10;
}

// ==== CNpcManager::helper_1403e9370  @1403e9370  [medium:callgraph-r1]  (orig: FUN_1403e9370)
void FUN_1403e9370(__uint64 param_1)

{
  if ((DAT_140976308 & 1) == 0) {
    DAT_140976308 = DAT_140976308 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976300,"CBattleSystem");
    atexit((_func_5014 *)&LAB_1406d6d10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403e93c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976300,param_1);
  return;
}

// ==== CNpcManager::helper_14044f300  @14044f300  [medium:callgraph-r1]  (orig: FUN_14044f300)
undefined8 FUN_14044f300(longlong param_1,undefined4 *param_2)

{
  if (*(short *)(param_2 + 6) != 1) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x38;
  *(undefined4 *)(param_1 + 8) = 0x4e21;
  **(undefined4 **)(param_1 + 0x428) = *param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x18) = *(undefined2 *)(param_2 + 6);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x1a) = *(undefined2 *)((longlong)param_2 + 0x1a)
  ;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2[1];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = *(undefined2 *)(param_2 + 5);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x16) = *(undefined2 *)((longlong)param_2 + 0x16)
  ;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_2[2];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_2[3];
  *(ushort *)(*(longlong *)(param_1 + 0x428) + 0x1c) = (ushort)*(byte *)(param_2 + 7);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_2[4];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x20) = param_2[8];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x24) = param_2[10];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x28) = param_2[0xb];
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x2c) = *(undefined1 *)(param_2 + 9);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x34) = param_2[0xf];
  return 1;
}

// ==== CNpcManager::helper_1404546d0  @1404546d0  [medium:callgraph-r1]  (orig: FUN_1404546d0)
bool FUN_1404546d0(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,char *param_5,
                  undefined4 param_6,undefined4 param_7,undefined2 param_8,undefined2 param_9,
                  undefined2 param_10)

{
  if (param_2 != 0) {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 0xc) = 0x40;
    *(undefined4 *)(param_1 + 8) = 0x7f3;
    **(int **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_6;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_7;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_8;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x16) = param_9;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_10;
    tq::SafeCopy((char *)(*(longlong *)(param_1 + 0x428) + 0x1a),param_5,0x24);
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return param_2 != 0;
}

// ==== CNpcManager::helper_1404ca5f0  @1404ca5f0  [medium:callgraph-r2]  (orig: FUN_1404ca5f0)
undefined8 FUN_1404ca5f0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xf0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 0xf0);
  }
  return *(undefined8 *)(param_1 + 0xf0);
}

// ==== CNpcManager::helper_1404cd120  @1404cd120  [medium:callgraph-r3]  (orig: FUN_1404cd120)
longlong * FUN_1404cd120(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1404cce70(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1404cd214;
  }
  _invalid_parameter_noinfo();
LAB_1404cd214:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CNpcManager::helper_1404cd2a0  @1404cd2a0  [medium:callgraph-r2]  (orig: FUN_1404cd2a0)
undefined4 * FUN_1404cd2a0(undefined4 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = (undefined8 *)0x0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  puVar1 = operator_new(8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1 + 0x12;
    puVar2 = puVar1;
  }
  *(undefined8 **)(param_1 + 0x12) = puVar2;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x1a) = 0;
  *(undefined8 *)(param_1 + 0x1c) = 0;
  param_1[0x1e] = 0;
  return param_1;
}

// ==== CNpcManager::helper_1404cd330  @1404cd330  [medium:callgraph-r2]  (orig: FUN_1404cd330)
void FUN_1404cd330(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_1404cd120(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CNpcManager::helper_1404cd460  @1404cd460  [medium:callgraph-r1]  (orig: FUN_1404cd460)
undefined8 FUN_1404cd460(longlong param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  uint *puVar12;
  uint uVar13;
  int iVar14;
  uint *local_50;
  undefined8 local_48;
  void *local_40;
  
  local_48 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
    uVar7 = FUN_1404ca5f0(uVar7);
    plVar8 = (longlong *)FUN_140226630(uVar7,param_2);
    if (plVar8 == (longlong *)0x0) {
      uVar7 = 1;
    }
    else {
      for (iVar14 = 0; iVar14 < 10; iVar14 = iVar14 + 1) {
        iVar1 = iVar14 * 5;
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar1 + 3);
        uVar2 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if (uVar2 != 0) {
          lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
          if (*(longlong *)(lVar10 + 0x100) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar7 = 0;
          }
          else {
            uVar7 = *(undefined8 *)(lVar10 + 0x100);
          }
          plVar9 = (longlong *)FUN_1402f0fe0(uVar7,uVar2,0);
          if (plVar9 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            plVar11 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar1 + 4);
            iVar3 = (**(code **)(*plVar11 + 0x48))(plVar11);
            if (iVar3 == 1) {
              plVar11 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar1 + 6);
              uVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
              if (0 < (int)uVar4) {
                plVar11 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar1 + 7);
                uVar5 = (**(code **)(*plVar11 + 0x48))();
                uVar13 = 0;
                if (0 < (int)uVar5) {
                  uVar13 = uVar5;
                }
                plVar11 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0xb);
                uVar6 = (**(code **)(*plVar11 + 0x48))();
                uVar5 = 0;
                if (0 < (int)uVar6) {
                  uVar5 = uVar6;
                }
                local_40 = operator_new(0x80);
                if (local_40 == (void *)0x0) {
                  puVar12 = (uint *)0x0;
                }
                else {
                  puVar12 = (uint *)FUN_1404cd2a0(local_40);
                }
                local_50 = puVar12;
                if (puVar12 == (uint *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  *puVar12 = uVar2;
                  puVar12[1] = 1;
                  plVar11 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,iVar1 + 5);
                  uVar2 = (**(code **)(*plVar11 + 0x48))(plVar11);
                  puVar12[2] = uVar2;
                  puVar12[3] = uVar4;
                  puVar12[4] = uVar13;
                  puVar12[5] = uVar5;
                  *(longlong **)(puVar12 + 0x10) = plVar9;
                  FUN_1404cd330(param_1 + 8,&local_50);
                }
              }
            }
          }
        }
      }
      uVar7 = 1;
    }
  }
  return uVar7;
}

// ==== CNpcManager::helper_1404cda70  @1404cda70  [medium:callgraph-r1]  (orig: FUN_1404cda70)
undefined8
FUN_1404cda70(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if ((DAT_140976518 & 1) == 0) {
    DAT_140976518 = DAT_140976518 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976510,"CMonsterMagic");
    atexit((_func_5014 *)&LAB_1406d6f20);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976510,0xb0);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1404cd7a0(pvVar1,param_1,param_2,param_4,uVar2);
  }
  return uVar2;
}

