// ==== CCrossMsgUserAttr::helper_140178780  @140178780  [medium:callgraph-r0]  (orig: FUN_140178780)
void FUN_140178780(longlong *param_1)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  FUN_140372af0(param_1 + 0x1cf,1);
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  uVar2 = FUN_140008520((int)param_1[0x246]);
  FUN_14008a880(uVar2,uVar1,4,1);
  return;
}

// ==== CCrossMsgUserAttr::helper_140372af0  @140372af0  [medium:callgraph-r1]  (orig: FUN_140372af0)
void FUN_140372af0(longlong param_1,int param_2)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x148) = 0;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"current_layout_type");
    (**(code **)(*plVar1 + 0xb0))(plVar1,0);
    if (param_2 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CCrossMsgUserAttr::ctor_or_dtor  @1403ee3f0  [high:vtable-assign]  (orig: FUN_1403ee3f0)
undefined8 * FUN_1403ee3f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgUserAttr::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgUserAttr::ctor_or_dtor  @1403ee440  [high:vtable-assign]  (orig: FUN_1403ee440)
void FUN_1403ee440(undefined8 *param_1)

{
  *param_1 = CCrossMsgUserAttr::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgUserAttr::vfunc_1  @1403ee470  [high:rtti-vtable]  (orig: FUN_1403ee470)
undefined8 FUN_1403ee470(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgUserAttr::ctor_or_dtor  @1403ee570  [high:vtable-assign]  (orig: FUN_1403ee570)
undefined8 * FUN_1403ee570(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgUserAttr::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgUserAttr::vfunc_3  @1403ee5c0  [high:rtti-vtable]  (orig: FUN_1403ee5c0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1403ee5c0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  int iVar5;
  
  if (**(short **)(param_1 + 0x428) == 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0xa0))
                      (plVar3,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c));
  }
  else {
    if (**(short **)(param_1 + 0x428) != 1) {
      return;
    }
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,*(undefined4 *)(param_1 + 0x420));
  }
  if (lVar4 == 0) {
    for (iVar5 = 0; iVar5 < (int)(uint)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2);
        iVar5 = iVar5 + 1) {
      tq::MyLogSave("gmlog/cross_userattr_update",
                    "user[%lu, %lu] is not online, attr=%d, data=%I64d",
                    *(undefined4 *)(param_1 + 0x41c),*(undefined4 *)(param_1 + 0x420));
    }
  }
  else {
    for (iVar5 = 0; lVar1 = *(longlong *)(param_1 + 0x428),
        iVar5 < (int)(uint)*(ushort *)(lVar1 + 2); iVar5 = iVar5 + 1) {
      if (*(short *)(lVar1 + 8 + (longlong)iVar5 * 0x10) == 0) {
        if (*(longlong *)(lVar1 + 0x10 + (longlong)iVar5 * 0x10) == 0) {
          FUN_140178780(lVar4);
        }
        else {
          FUN_1401786a0(lVar4);
        }
      }
    }
  }
  return;
}

