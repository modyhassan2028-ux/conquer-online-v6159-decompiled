// ==== CTerrainObjPart::helper_140563af0  @140563af0  [medium:callgraph-r0]  (orig: FUN_140563af0)
void FUN_140563af0(undefined8 param_1,longlong *param_2,longlong *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (param_2 != param_3) {
    plVar4 = param_2 + 1;
    do {
      plVar3 = (longlong *)*plVar4;
      if (plVar3 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar3 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*plVar3)(plVar3);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar3 + 8))(plVar3);
          }
        }
      }
      plVar3 = plVar4 + 1;
      plVar4 = plVar4 + 2;
    } while (plVar3 != param_3);
  }
  return;
}

// ==== CTerrainObjPart::ctor_or_dtor  @140571030  [high:vtable-assign]  (orig: FUN_140571030)
undefined8 *
FUN_140571030(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  
  FUN_140570b90(param_1,2,param_3,param_4,0xfffffffffffffffe);
  *param_1 = CTerrainObjPart::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 5);
    plVar2 = plVar1;
  }
  param_1[5] = plVar2;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  *(undefined4 *)(param_1 + 3) = 2;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 2;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  return param_1;
}

// ==== CTerrainObjPart::ctor_or_dtor  @1405710c0  [high:vtable-assign]  (orig: FUN_1405710c0)
void FUN_1405710c0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = CTerrainObjPart::vftable;
  if (param_1[8] != 0) {
    FUN_140563af0(param_1 + 5,param_1[8],param_1[9],param_4,0xfffffffffffffffe);
    operator_delete((void *)param_1[8]);
  }
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  operator_delete((void *)param_1[5]);
  FUN_140570bb0(param_1);
  return;
}

// ==== CTerrainObjPart::vfunc_0  @140571140  [high:rtti-vtable]  (orig: FUN_140571140)
void * FUN_140571140(void *param_1,uint param_2)

{
  FUN_1405710c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

