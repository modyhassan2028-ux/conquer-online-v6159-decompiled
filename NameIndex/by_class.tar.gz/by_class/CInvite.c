// ==== CInvite::helper_1403807f0  @1403807f0  [medium:callgraph-r0]  (orig: FUN_1403807f0)
void FUN_1403807f0(void *param_1)

{
  if ((DAT_140976190 & 1) == 0) {
    DAT_140976190 = DAT_140976190 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976188,"CInvite");
    atexit((_func_5014 *)&LAB_1406d6b60);
  }
                    /* WARNING: Could not recover jumptable at 0x000140380845. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976188,param_1);
  return;
}

// ==== CInvite::ctor_or_dtor  @140380c90  [high:vtable-assign]  (orig: FUN_140380c90)
void FUN_140380c90(undefined8 *param_1)

{
  *param_1 = CInvite::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CInvite::ctor_or_dtor  @140381370  [high:vtable-assign]  (orig: FUN_140381370)
undefined8 * FUN_140381370(undefined8 *param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  
  *param_1 = CInvite::vftable;
  lVar4 = 8;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  puVar3 = param_1 + 0xd;
  do {
    *(undefined4 *)(puVar3 + -4) = 0xffffffff;
    *(undefined4 *)puVar3 = 0xffffffff;
    puVar3 = (undefined8 *)((longlong)puVar3 + 4);
    lVar4 = lVar4 + -1;
  } while (lVar4 != 0);
  *(undefined4 *)(param_1 + 0x12) = 0;
  *(undefined4 *)(param_1 + 0x13) = 0;
  *(undefined4 *)((longlong)param_1 + 0x9c) = param_2;
  *(undefined4 *)(param_1 + 0x11) = 0;
  *(undefined4 *)((longlong)param_1 + 0x94) = 0;
  *(undefined4 *)((longlong)param_1 + 0x8c) = 600;
  return param_1;
}

// ==== CInvite::ctor_or_dtor  @140381440  [high:vtable-assign]  (orig: FUN_140381440)
undefined8 * FUN_140381440(undefined8 *param_1,uint param_2)

{
  *param_1 = CInvite::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_1403807f0(param_1);
  }
  return param_1;
}

