// ==== CMsgOSAction::helper_1400a7ab0  @1400a7ab0  [medium:callgraph-r0]  (orig: FUN_1400a7ab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400a7ab0(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined1 uVar5;
  char cVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == 0) {
    local_478 = 0xe9a;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1402c3180(local_458);
    uVar5 = 0;
    if (*(char *)(param_1 + 0x730) != '\0') {
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      lVar7 = *(longlong *)(lVar7 + 0x148);
      if (lVar7 == 0) {
        local_478 = 0x14d;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar7 = 0;
      }
      uVar5 = FUN_140005850(lVar7);
    }
    cVar6 = FUN_1402c3230(local_458,uVar5);
    if (cVar6 == '\0') {
      log_InlineLogERROR("CMapGroup::ProcessQueryOSConnectStatus msg create failed.");
      FUN_1402c31d0(local_458);
    }
    else {
      puVar1 = *(undefined8 **)(param_1 + 0x468);
      puVar8 = (undefined8 *)*puVar1;
      plVar2 = *(longlong **)(param_1 + 0x438);
      while( true ) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar8 == puVar1) goto LAB_1400a7ca8;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar2;
        }
        if (puVar8 == *(undefined8 **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar2;
        }
        if (puVar8 == *(undefined8 **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        cVar6 = FUN_1402c32a0(local_458,*(undefined4 *)(puVar8 + 3),*(undefined1 *)(puVar8 + 6));
        if (cVar6 == '\0') break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar8 + 0x49) == '\0') {
          puVar3 = (undefined8 *)puVar8[2];
          if (*(char *)((longlong)puVar3 + 0x49) == '\0') {
            cVar6 = *(char *)((longlong)*puVar3 + 0x49);
            puVar8 = puVar3;
            puVar3 = (undefined8 *)*puVar3;
            while (cVar6 == '\0') {
              cVar6 = *(char *)((longlong)*puVar3 + 0x49);
              puVar8 = puVar3;
              puVar3 = (undefined8 *)*puVar3;
            }
          }
          else {
            cVar6 = *(char *)((longlong)puVar8[1] + 0x49);
            puVar4 = (undefined8 *)puVar8[1];
            puVar3 = puVar8;
            while ((puVar8 = puVar4, cVar6 == '\0' && (puVar3 == (undefined8 *)puVar8[2]))) {
              cVar6 = *(char *)((longlong)puVar8[1] + 0x49);
              puVar4 = (undefined8 *)puVar8[1];
              puVar3 = puVar8;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      log_InlineLogERROR("CMapGroup::ProcessQueryOSConnectStatus msg append failed.");
LAB_1400a7ca8:
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_458);
      FUN_1402c31d0(local_458);
    }
  }
  return;
}

// ==== CMsgOSAction::helper_1402c3230  @1402c3230  [medium:callgraph-r1]  (orig: FUN_1402c3230)
ulonglong FUN_1402c3230(longlong param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  ulonglong extraout_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0xb55;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 0;
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgOSAction::helper_1402c32a0  @1402c32a0  [medium:callgraph-r1]  (orig: FUN_1402c32a0)
ulonglong FUN_1402c32a0(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  
  if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 5U) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
  *(undefined4 *)((ulonglong)*(byte *)(lVar2 + 1) * 5 + 2 + lVar2) = param_2;
  *(undefined1 *)
   ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 1) * 5 + 6 +
   *(longlong *)(param_1 + 0x428)) = param_3;
  lVar2 = *(longlong *)(param_1 + 0x428);
  pcVar1 = (char *)(lVar2 + 1);
  *pcVar1 = *pcVar1 + '\x01';
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

// ==== CMsgOSAction::ctor_or_dtor  @14044fb40  [high:vtable-assign]  (orig: FUN_14044fb40)
undefined8 * FUN_14044fb40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgOSAction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgOSAction::ctor_or_dtor  @14044fb90  [high:vtable-assign]  (orig: FUN_14044fb90)
void FUN_14044fb90(undefined8 *param_1)

{
  *param_1 = CMsgOSAction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgOSAction::vfunc_1  @14044fbc0  [high:rtti-vtable]  (orig: FUN_14044fbc0)
ulonglong FUN_14044fbc0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xb54);
}

// ==== CMsgOSAction::ctor_or_dtor  @14044fc10  [high:vtable-assign]  (orig: FUN_14044fc10)
undefined8 * FUN_14044fc10(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgOSAction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgOSAction::vfunc_3  @14044fc60  [high:rtti-vtable]  (orig: FUN_14044fc60)
void FUN_14044fc60(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x88))(plVar4,param_1);
    if (lVar5 != 0) {
      cVar2 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x220))(lVar5 + 0x10);
      if (cVar2 == '\0') {
        pIVar6 = theInstance();
        lVar1 = *(longlong *)(lVar5 + 0x10);
        uVar3 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_DIE");
        (**(code **)(lVar1 + 0x358))(lVar5 + 0x10,uVar3);
      }
      else if (**(char **)(param_1 + 0x428) == '\0') {
        uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        FUN_1400a7ab0(uVar3,lVar5);
      }
    }
  }
  return;
}

