// ==== CMsgTick::helper_140170340  @140170340  [medium:callgraph-r0]  (orig: FUN_140170340)
void FUN_140170340(longlong param_1,uint param_2)

{
  longlong lVar1;
  char cVar2;
  ulong uVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  longlong *plVar6;
  
  cVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x230))(param_1 + 0x10);
  if (cVar2 == '\0') {
    if (*(int *)(param_1 + 0xb50) == 0) {
      *(uint *)(param_1 + 0xb50) = param_2;
    }
    if (param_2 < *(uint *)(param_1 + 0xb54)) {
      pIVar4 = theInstance();
      lVar1 = *(longlong *)(param_1 + 0x10);
      uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_CONNECTION_OFF");
      (**(code **)(lVar1 + 0x358))(param_1 + 0x10,uVar5);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      plVar6 = (longlong *)FUN_140087650(uVar5);
                    /* WARNING: Could not recover jumptable at 0x0001401703da. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*plVar6 + 0x50))(plVar6,param_1,"ProcessTick");
      return;
    }
    *(uint *)(param_1 + 0xb54) = param_2;
    uVar3 = tq::TimeGet(0);
    *(int *)(param_1 + 0xb48) = *(int *)(param_1 + 0xb48) + -1;
    *(ulong *)(param_1 + 0xb58) = uVar3;
  }
  return;
}

// ==== CMsgTick::ctor_or_dtor  @1403edea0  [high:vtable-assign]  (orig: FUN_1403edea0)
undefined8 * FUN_1403edea0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTick::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTick::ctor_or_dtor  @1403edef0  [high:vtable-assign]  (orig: FUN_1403edef0)
void FUN_1403edef0(undefined8 *param_1)

{
  *param_1 = CMsgTick::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTick::vfunc_1  @1403edf20  [high:rtti-vtable]  (orig: FUN_1403edf20)
ulonglong FUN_1403edf20(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f4);
}

// ==== CMsgTick::ctor_or_dtor  @1403ee000  [high:vtable-assign]  (orig: FUN_1403ee000)
undefined8 * FUN_1403ee000(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTick::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTick::vfunc_3  @1403ee050  [high:rtti-vtable]  (orig: FUN_1403ee050)
void FUN_1403ee050(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  uint uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar3,(int)lVar2,*puVar1);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    FUN_140170340(plVar6,uVar4 ^ *(uint *)(*(longlong *)(param_1 + 0x428) + 8));
  }
  return;
}

