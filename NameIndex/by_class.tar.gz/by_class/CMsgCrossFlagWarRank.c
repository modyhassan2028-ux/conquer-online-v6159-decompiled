// ==== CMsgCrossFlagWarRank::ctor_or_dtor  @14045fa10  [high:vtable-assign]  (orig: FUN_14045fa10)
undefined8 * FUN_14045fa10(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCrossFlagWarRank::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgCrossFlagWarRank::ctor_or_dtor  @14045fa60  [high:vtable-assign]  (orig: FUN_14045fa60)
void FUN_14045fa60(undefined8 *param_1)

{
  *param_1 = CMsgCrossFlagWarRank::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgCrossFlagWarRank::vfunc_5  @14045fa90  [high:rtti-vtable]  (orig: FUN_14045fa90)
bool FUN_14045fa90(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9cb;
    }
  }
  return false;
}

// ==== CMsgCrossFlagWarRank::ctor_or_dtor  @14045fad0  [high:vtable-assign]  (orig: FUN_14045fad0)
undefined8 * FUN_14045fad0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCrossFlagWarRank::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgCrossFlagWarRank::vfunc_3  @14045fb20  [high:rtti-vtable]  (orig: FUN_14045fb20)
void FUN_14045fb20(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar1 = FUN_14008b330(uVar2);
  if (cVar1 == '\0') {
    if (**(short **)(param_1 + 0x428) != 3) {
                    /* WARNING: Could not recover jumptable at 0x00014045fb95. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CMsgFrontierFlagWarRank::Process. error typy[%u]");
      return;
    }
    if (0 < *(int *)(*(short **)(param_1 + 0x428) + 4)) {
      tq::SysLogSave("crossvlmresult","receive %d results");
      plVar3 = (longlong *)FUN_140087ed0();
      (**(code **)(*plVar3 + 0x3a0))
                (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                 *(longlong *)(param_1 + 0x428) + 0x14);
    }
  }
  return;
}

