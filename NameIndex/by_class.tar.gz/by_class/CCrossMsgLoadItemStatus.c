// ==== CCrossMsgLoadItemStatus::helper_1401684c0  @1401684c0  [medium:callgraph-r0]  (orig: FUN_1401684c0)
undefined1 FUN_1401684c0(longlong param_1,uint param_2,longlong param_3)

{
  undefined4 uVar1;
  longlong lVar2;
  undefined4 *puVar3;
  ulonglong uVar4;
  
  if (0 < (int)param_2) {
    if (0 < (int)param_2) {
      uVar4 = (ulonglong)param_2;
      puVar3 = (undefined4 *)(param_3 + 4);
      do {
        uVar1 = *(undefined4 *)(param_1 + 0x12fc);
        lVar2 = DAT_140975b60;
        if (DAT_140975b60 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          lVar2 = 0;
        }
        lVar2 = FUN_1403253b0(lVar2,uVar1,*puVar3);
        if (lVar2 == 0) {
          log_InlineLogOSERROR
                    (
                    "CUser::LoadOSItemStatusInfo cannot find item.user id[%u] item id[%u]. at %s, %d"
                    );
        }
        else {
          FUN_140102a10(lVar2,param_3,0,1);
        }
        param_3 = param_3 + 0x28;
        puVar3 = puVar3 + 10;
        uVar4 = uVar4 - 1;
      } while (uVar4 != 0);
    }
    return 1;
  }
  return 0;
}

// ==== CCrossMsgLoadItemStatus::helper_1403253b0  @1403253b0  [medium:callgraph-r1]  (orig: FUN_1403253b0)
undefined8 FUN_1403253b0(longlong *param_1,longlong param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  longlong local_20;
  longlong *local_18;
  longlong local_10;
  
  if (param_3 == 0) {
    return 0;
  }
  uVar9 = (param_2 << 0x20) + (ulonglong)param_3;
  puVar8 = (undefined8 *)((undefined8 *)param_1[0x11])[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = (undefined8 *)param_1[0x11];
  while (cVar1 == '\0') {
    if ((ulonglong)puVar8[3] < uVar9) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = (undefined8 *)param_1[0x11];
  local_30 = puVar3;
  local_38 = param_1[0xb];
  if (param_1[0xb] == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (uVar9 < (ulonglong)puVar3[3])) {
    plVar7 = &local_28;
    local_20 = param_1[0x11];
    local_28 = param_1[0xb];
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = param_1[0x11];
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[0xb])) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
                    /* WARNING: Could not recover jumptable at 0x0001403254e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar6 = (**(code **)(*param_1 + 0x60))(param_1,*(undefined4 *)(lVar4 + 0x20));
    return uVar6;
  }
  return 0;
}

// ==== CCrossMsgLoadItemStatus::ctor_or_dtor  @1403f1970  [high:vtable-assign]  (orig: FUN_1403f1970)
undefined8 * FUN_1403f1970(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadItemStatus::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadItemStatus::ctor_or_dtor  @1403f19c0  [high:vtable-assign]  (orig: FUN_1403f19c0)
void FUN_1403f19c0(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadItemStatus::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadItemStatus::vfunc_1  @1403f19f0  [high:rtti-vtable]  (orig: FUN_1403f19f0)
undefined8 FUN_1403f19f0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadItemStatus::ctor_or_dtor  @1403f1b80  [high:vtable-assign]  (orig: FUN_1403f1b80)
undefined8 * FUN_1403f1b80(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadItemStatus::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadItemStatus::vfunc_3  @1403f1bd0  [high:rtti-vtable]  (orig: FUN_1403f1bd0)
void FUN_1403f1bd0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_1402af110(*(undefined8 *)(lVar3 + 0x90),uVar2,uVar1);
  if (lVar3 == 0) {
    log_InlineLogOSWARNING("CCrossMsgLoadItemStatus::Process cannot find user(%u,%u).");
  }
  else {
    FUN_1401684c0(lVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                  *(longlong *)(param_1 + 0x428) + 8);
  }
  return;
}

