// ==== CFactionMatchActor@adapter::helper_14016cc60  @14016cc60  [medium:callgraph-r0]  (orig: FUN_14016cc60)
uint FUN_14016cc60(longlong param_1)

{
  uint extraout_var;
  longlong *plVar1;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return extraout_var & 1;
}

// ==== CFactionMatchActor@adapter::helper_1401c8390  @1401c8390  [medium:callgraph-r0]  (orig: FUN_1401c8390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1401c8390(longlong *param_1,undefined4 param_2,char param_3)

{
  char cVar1;
  byte bVar2;
  undefined1 uVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  undefined1 auStack_508 [32];
  uint local_4e8;
  undefined4 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined1 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  int local_4a8;
  int local_4a4 [3];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a4[1] = -2;
  local_4a4[2] = -1;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  lVar9 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar9 + 0x98) == 0) {
    local_4e8 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar9 = (**(code **)(**(longlong **)(lVar9 + 0x98) + 0x20))
                    (*(longlong **)(lVar9 + 0x98),param_2,1);
  uVar3 = 0;
  if (lVar9 != 0) {
    lVar10 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    uVar3 = 0;
    if (lVar10 != 0) {
      uVar5 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      cVar1 = FUN_1402c3cc0(lVar10,uVar6,uVar5);
      if (cVar1 != '\0') {
        plVar11 = *(longlong **)(*(longlong *)(lVar10 + 0x58) + 8);
        plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,4);
        bVar2 = (**(code **)(*plVar11 + 0x58))(plVar11);
        if ((bVar2 >> 2 & 1) == 0) {
          uVar5 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
          uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
          uVar7 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
          local_4e8 = 1;
          FUN_1401732e0(param_1,uVar7,uVar6,uVar5);
        }
      }
      local_4a4[0] = 0;
      local_4a8 = 0;
      uVar12 = 10;
      if (param_3 == '\0') {
        uVar12 = 0xc;
      }
      cVar1 = FUN_1402c4200(lVar9,uVar12,local_4a4,&local_4a8);
      uVar3 = 0;
      if (cVar1 != '\0') {
        if ((local_4a4[0] == 0) || (local_4a8 == 0)) {
          uVar3 = 0;
        }
        else {
          local_4e8 = local_4e8 & 0xffffff00;
          iVar8 = FUN_1401c55b0(param_1,param_2);
          if (iVar8 == 0) {
            cVar1 = (**(code **)(param_1[2] + 0x2d8))(param_1 + 2,0x57);
            if (cVar1 == '\0') {
              plVar11 = (longlong *)FUN_1401181a0();
              lVar9 = *plVar11;
              uVar5 = (**(code **)(*param_1 + 8))(param_1);
              local_4b8 = 0;
              local_4c0 = 1;
              local_4c8 = 1;
              local_4d0 = 0x3138;
              local_4d8 = 0;
              local_4e0 = 0;
              local_4e8 = 0x3138;
              (**(code **)(lVar9 + 8))(plVar11,uVar5,0x57,0x14);
            }
            FUN_140362560(local_498);
            uVar4 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
            uVar5 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
            uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
            uVar7 = (**(code **)(*param_1 + 8))(param_1);
            local_4d0 = 0;
            local_4d8 = 1;
            local_4e0 = CONCAT22(local_4e0._2_2_,1000);
            local_4e8 = CONCAT22(local_4e8._2_2_,uVar4);
            iVar8 = FUN_140362620(local_498,uVar7,uVar6,uVar5);
            if (iVar8 != 0) {
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_498);
            }
            FUN_1403625e0(local_498);
            uVar3 = 1;
          }
          else {
            uVar3 = 0;
          }
        }
      }
    }
  }
  return uVar3;
}

// ==== CFactionMatchActor@adapter::helper_1402bc670  @1402bc670  [medium:callgraph-r0]  (orig: FUN_1402bc670)
void FUN_1402bc670(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x38) != 0) {
    FUN_14046a040();
  }
  return;
}

// ==== CFactionMatchActor@adapter::helper_1402bc690  @1402bc690  [medium:callgraph-r0]  (orig: FUN_1402bc690)
void FUN_1402bc690(longlong param_1,undefined8 param_2)

{
  if (*(longlong *)(param_1 + 0x38) == 0) {
    return;
  }
  FUN_14046a080(*(longlong *)(param_1 + 0x38),param_1,param_2);
  return;
}

// ==== CFactionMatchActor@adapter::helper_1402bc6b0  @1402bc6b0  [medium:callgraph-r0]  (orig: FUN_1402bc6b0)
void FUN_1402bc6b0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  ulong uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong *plVar6;
  
  plVar6 = (longlong *)CurrentInstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0x18);
  if (plVar6 != (longlong *)0x0) {
    uVar3 = tq::TimeGet(1);
    plVar1 = *(longlong **)(param_1 + 0x60);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar4 = (**(code **)(*plVar1 + 0x10))(plVar1,1);
      if (((iVar4 != 0) && (*(int *)(param_1 + 0x9c) != 0)) &&
         (iVar4 = uVar3 - *(int *)(param_1 + 0x9c), iVar4 != 0)) {
        lVar2 = *plVar6;
        uVar5 = FUN_1400872b0(param_1,1);
        (**(code **)(lVar2 + 0x10))(plVar6,uVar5,iVar4);
      }
    }
    *(ulong *)(param_1 + 0x9c) = uVar3;
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CFactionMatchActor@adapter::helper_1402bff70  @1402bff70  [medium:callgraph-r0]  (orig: FUN_1402bff70)
undefined8 FUN_1402bff70(longlong param_1)

{
  longlong *plVar1;
  ulong uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  
  lVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x160))(param_1 + 0x10);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(undefined4 *)(param_1 + 0xb8) = 5;
  uVar2 = tq::TimeGet(0);
  uVar4 = 0;
  *(uint *)(param_1 + 0xbc) = uVar2 / 1000;
  *(undefined4 *)(param_1 + 0x9c) = 0;
  uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x80))(param_1 + 0x10);
  plVar1 = *(longlong **)(param_1 + 0x60);
  if ((plVar1 == (longlong *)0x0) || (*(char *)(param_1 + 0x68) == '\0')) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*plVar1 + 0x60))(plVar1,0x18,uVar3);
  }
  plVar1 = *(longlong **)(param_1 + 0x60);
  if ((plVar1 == (longlong *)0x0) || (*(char *)(param_1 + 0x68) == '\0')) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*plVar1 + 0x60))(plVar1,1);
    (**(code **)(**(longlong **)(param_1 + 0x60) + 0x70))();
  }
  plVar1 = *(longlong **)(param_1 + 0x60);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    uVar3 = (**(code **)(*plVar1 + 0x10))(plVar1,0x13);
  }
  plVar1 = *(longlong **)(param_1 + 0x60);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar4 = (**(code **)(*plVar1 + 0x10))(plVar1,0x12);
  }
  uVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
  FUN_1402bf7a0(param_1,uVar5,uVar4,uVar3);
  return 1;
}

// ==== CFactionMatchActor@adapter::helper_14046a040  @14046a040  [medium:callgraph-r1]  (orig: FUN_14046a040)
void FUN_14046a040(longlong param_1)

{
  undefined4 uVar1;
  
  if (((*(longlong **)(param_1 + 8) != (longlong *)0x0) && (*(longlong *)(param_1 + 0x10) != 0)) &&
     (*(int *)(param_1 + 0x18) != 0)) {
    *(undefined4 *)(param_1 + 0x18) = 0;
    uVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 8))();
    FUN_1402c7270(*(undefined8 *)(param_1 + 0x10),uVar1);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_1  @140598670  [high:rtti-vtable]  (orig: FUN_140598670)
void FUN_140598670(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_1  @140598690  [high:rtti-vtable]  (orig: FUN_140598690)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140598690(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 != (char *)0x0) {
    plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar3 == (longlong *)0x0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x5f);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar4 = (**(code **)(*plVar3 + 0x2b0))(plVar3);
      if (lVar4 == 0) {
        local_8c8 = CONCAT44(local_8c8._4_4_,0x66);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
        local_29 = 0;
        FUN_14015b240(local_878);
        uVar5 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x18))(lVar4 + 0x10);
        local_898 = 1;
        local_8a0 = 0;
        local_8a8 = 0;
        local_8b0 = 0;
        local_8c0 = 0xffff00;
        local_8c8 = 0;
        local_8b8 = param_3;
        iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar5,local_428);
        if (iVar2 != 0) {
          uVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x350))(lVar4 + 0x10,local_878);
          FUN_14015b2c0(local_878);
          return uVar1;
        }
        FUN_14015b2c0(local_878);
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_2  @140598820  [high:rtti-vtable]  (orig: FUN_140598820)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140598820(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 != (char *)0x0) {
    local_res20 = param_4;
    plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar3 == (longlong *)0x0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x82);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar4 = (**(code **)(*plVar3 + 0x2b0))(plVar3);
      if (lVar4 == 0) {
        local_8c8 = CONCAT44(local_8c8._4_4_,0x89);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
        local_29 = 0;
        FUN_14015b240(local_878);
        uVar5 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x18))(lVar4 + 0x10);
        local_898 = 1;
        local_8a0 = 0;
        local_8a8 = 0;
        local_8b0 = 0;
        local_8b8 = 0x7d5;
        local_8c0 = 0xff0000;
        local_8c8 = 0;
        iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar5,local_428);
        if (iVar2 != 0) {
          uVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x350))(lVar4 + 0x10,local_878);
          FUN_14015b2c0(local_878);
          return uVar1;
        }
        FUN_14015b2c0(local_878);
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_4  @1405989c0  [high:rtti-vtable]  (orig: FUN_1405989c0)
undefined1 * FUN_1405989c0(undefined8 param_1,int param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  if (param_2 == 0) {
    return (undefined1 *)0x0;
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140598a6d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CFactionMatchActor@adapter::vfunc_5  @140598a80  [high:rtti-vtable]  (orig: FUN_140598a80)
undefined8 FUN_140598a80(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140598b17. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x130))(plVar1,param_2);
  return uVar2;
}

// ==== CFactionMatchActor@adapter::vfunc_6  @140598b20  [high:rtti-vtable]  (orig: FUN_140598b20)
undefined8 FUN_140598b20(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140598bb2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x170))(lVar2 + 0x10);
  return uVar3;
}

// ==== CFactionMatchActor@adapter::vfunc_9  @140598bc0  [high:rtti-vtable]  (orig: FUN_140598bc0)
ulonglong FUN_140598bc0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140598c5b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2d8))((longlong *)(lVar2 + 0x10),param_3);
  return uVar3;
}

// ==== CFactionMatchActor@adapter::vfunc_10  @140598c70  [high:rtti-vtable]  (orig: FUN_140598c70)
undefined8 FUN_140598c70(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    cVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x2d8))((longlong *)(lVar3 + 0x10),0x57);
    if (cVar1 != '\0') {
      plVar2 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x000140598d2a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar4 = (**(code **)(*plVar2 + 0xb0))(plVar2,param_2,0x57);
      return uVar4;
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_11  @140598d40  [high:rtti-vtable]  (orig: FUN_140598d40)
ulonglong FUN_140598d40(longlong param_1,int param_2,int param_3,undefined1 param_4)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong *plVar1;
  ulonglong extraout_RAX_01;
  longlong lVar2;
  ulonglong extraout_RAX_02;
  ulonglong uVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX & 0xffffffffffffff00;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX_00 & 0xffffffffffffff00;
  }
  else {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = extraout_RAX_01 & 0xffffffffffffff00;
    }
    else {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = extraout_RAX_02 & 0xffffffffffffff00;
      }
      else {
        uVar3 = FUN_1401c8390(lVar2,param_3,param_4);
      }
    }
  }
  return uVar3;
}

// ==== CFactionMatchActor@adapter::vfunc_12  @140598e60  [high:rtti-vtable]  (orig: FUN_140598e60)
ulonglong FUN_140598e60(longlong param_1,int param_2)

{
  ulonglong extraout_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x70))();
    uVar2 = 0;
    if (lVar1 != 0) {
      uVar2 = FUN_1402bff70(lVar1);
      return uVar2;
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CFactionMatchActor@adapter::vfunc_17  @140598ec0  [high:rtti-vtable]  (orig: FUN_140598ec0)
undefined8 FUN_140598ec0(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x70))();
    if (lVar1 == 0) {
      return 0;
    }
    if (*(longlong *)(lVar1 + 0x60) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140598f37. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x10))(*(longlong **)(lVar1 + 0x60),1);
      return uVar2;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_18  @140598f40  [high:rtti-vtable]  (orig: FUN_140598f40)
ulonglong FUN_140598f40(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140598fd7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x2a8))(plVar1,param_2);
  return uVar2;
}

// ==== CFactionMatchActor@adapter::vfunc_22  @140598fe0  [high:rtti-vtable]  (orig: FUN_140598fe0)
void FUN_140598fe0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401602a0();
                    /* WARNING: Could not recover jumptable at 0x00014059900f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 8))(plVar1,param_2,param_3,1);
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_24  @140599020  [high:rtti-vtable]  (orig: FUN_140599020)
void FUN_140599020(undefined8 param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)CurrentInstanceGet();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x3d0))(plVar1,param_2,param_3);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_25  @1405990e0  [high:rtti-vtable]  (orig: FUN_1405990e0)
void FUN_1405990e0(void)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059916f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x3e0))(plVar1,2);
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_19  @140599180  [high:rtti-vtable]  (orig: FUN_140599180)
undefined8 FUN_140599180(undefined8 param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(*plVar1 + 0x158))(plVar1,param_2,param_3);
  return 1;
}

// ==== CFactionMatchActor@adapter::vfunc_20  @140599280  [high:rtti-vtable]  (orig: FUN_140599280)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140599280(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == 0) {
    local_498 = 0x246;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar2 == (longlong *)0x0) {
      local_498 = 0x24a;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
      if (lVar3 == 0) {
        local_498 = 0x251;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_140161fa0(lVar3,param_3);
        FUN_140362560(local_478);
        cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
        }
        FUN_1403625e0(local_478);
      }
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_26  @1405993d0  [high:rtti-vtable]  (orig: FUN_1405993d0)
bool FUN_1405993d0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      return lVar2 != 0;
    }
  }
  return false;
}

// ==== CFactionMatchActor@adapter::vfunc_27  @140599410  [high:rtti-vtable]  (orig: FUN_140599410)
ulonglong FUN_140599410(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059944b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x250))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFactionMatchActor@adapter::vfunc_28  @140599460  [high:rtti-vtable]  (orig: FUN_140599460)
ulonglong FUN_140599460(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140599494. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x220))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFactionMatchActor@adapter::vfunc_29  @1405994b0  [high:rtti-vtable]  (orig: FUN_1405994b0)
bool FUN_1405994b0(longlong param_1,int param_2)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  
  if (param_2 != 0) {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar2 != (longlong *)0x0) {
      lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
      if (lVar3 != 0) {
        iVar1 = FUN_140166ec0(lVar3);
        return iVar1 != 0;
      }
    }
  }
  return false;
}

// ==== CFactionMatchActor@adapter::vfunc_31  @140599500  [high:rtti-vtable]  (orig: FUN_140599500)
undefined8 FUN_140599500(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140599534. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x168))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_34  @140599550  [high:rtti-vtable]  (orig: FUN_140599550)
void FUN_140599550(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (((param_2 != 0) &&
      (plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))(),
      plVar1 != (longlong *)0x0)) && (lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1), lVar2 != 0)) {
    FUN_1401732e0(lVar2,param_3,param_4,param_5,param_6);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_35  @1405995b0  [high:rtti-vtable]  (orig: FUN_1405995b0)
undefined8 FUN_1405995b0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405995eb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x40))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_36  @1405995f0  [high:rtti-vtable]  (orig: FUN_1405995f0)
undefined8 FUN_1405995f0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059962b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x48))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_37  @140599630  [high:rtti-vtable]  (orig: FUN_140599630)
ulonglong FUN_140599630(longlong param_1,int param_2,undefined4 param_3)

{
  ulonglong in_RAX;
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (lVar2 != 0) {
        uVar3 = FUN_1401c7e10(lVar2,param_3);
        return uVar3;
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFactionMatchActor@adapter::vfunc_38  @140599680  [high:rtti-vtable]  (orig: FUN_140599680)
undefined8 FUN_140599680(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405996bb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x18))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_39  @1405996c0  [high:rtti-vtable]  (orig: FUN_1405996c0)
undefined8 FUN_1405996c0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405996fb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x30))(lVar2 + 0x10);
        return uVar3;
      }
    }
  }
  return 0;
}

// ==== CFactionMatchActor@adapter::vfunc_13  @140599700  [high:rtti-vtable]  (orig: FUN_140599700)
void FUN_140599700(longlong param_1,int param_2)

{
  longlong lVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x70))();
  if (lVar1 != 0) {
    FUN_1402bc6b0(lVar1);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_43  @140599760  [high:rtti-vtable]  (orig: FUN_140599760)
void FUN_140599760(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      FUN_140162110(lVar2,0x10,param_3);
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_0  @1405997b0  [high:rtti-vtable]  (orig: FUN_1405997b0)
void FUN_1405997b0(longlong param_1)

{
  FUN_140599810(param_1 + -8);
  return;
}

// ==== CFactionMatchActor@adapter::helper_140599810  @140599810  [medium:callgraph-r0]  (orig: FUN_140599810)
undefined8 * FUN_140599810(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CFactionMatchActor::vftable;
  param_1[1] = adapter::CFactionMatchActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFactionMatchActor@adapter::vfunc_0  @140599910  [high:rtti-vtable]  (orig: FUN_140599910)
void FUN_140599910(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0,uVar4);
      if (puVar3 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_3  @140599a40  [high:rtti-vtable]  (orig: FUN_140599a40)
void FUN_140599a40(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                       (*(longlong **)(lVar2 + 0x98),param_2,1);
    if (plVar3 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*plVar3 + 0x38))(plVar3,puVar1,0);
    }
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_7  @140599b50  [high:rtti-vtable]  (orig: FUN_140599b50)
void FUN_140599b50(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xa8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140145f60(*(undefined8 *)(lVar1 + 0xa8),param_2,0,0,0,0);
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_15  @140599bd0  [high:rtti-vtable]  (orig: FUN_140599bd0)
void FUN_140599bd0(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong local_28;
  longlong local_20 [3];
  
  local_20[1] = 0xfffffffffffffffe;
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar4 = (longlong *)FUN_1400875f0(uVar3);
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,param_3);
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar5 = (longlong *)FUN_1400875f0(uVar3);
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,param_4);
  local_28 = 0;
  local_20[0] = 0;
  if (((plVar4 != (longlong *)0x0) &&
      (cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_28), cVar1 != '\0')) &&
     (iVar2 = (**(code **)(*(longlong *)(local_28 + 0x10) + 0x168))(), iVar2 == param_2)) {
    FUN_1402bc670(local_28);
    cVar1 = FUN_1402bf7a0(local_28,5000,0x3c);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
  }
  if (((plVar5 != (longlong *)0x0) &&
      (cVar1 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,local_20), cVar1 != '\0')) &&
     (iVar2 = (**(code **)(*(longlong *)(local_20[0] + 0x10) + 0x168))(), iVar2 == param_2)) {
    FUN_1402bc670(local_20[0]);
    cVar1 = FUN_1402bf7a0(local_20[0],5000,0x3c);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_16  @140599d80  [high:rtti-vtable]  (orig: FUN_140599d80)
void FUN_140599d80(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *local_28;
  longlong *local_20;
  undefined8 local_18;
  
  local_18 = 0xfffffffffffffffe;
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar6 = (longlong *)FUN_1400876b0(uVar5);
  lVar7 = (**(code **)(*plVar6 + 0x10))(plVar6,param_2,1);
  if (lVar7 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar6 = (longlong *)FUN_1400875f0(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,param_3);
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar8 = (longlong *)FUN_1400875f0(uVar5);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,param_4);
    local_28 = (longlong *)0x0;
    local_20 = (longlong *)0x0;
    if (((plVar6 != (longlong *)0x0) &&
        (cVar1 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_28), cVar1 != '\0')) &&
       (iVar2 = (**(code **)(local_28[2] + 0x168))(), iVar2 == 5000)) {
      uVar3 = (**(code **)(*local_28 + 0x30))();
      uVar4 = (**(code **)(*local_28 + 0x38))();
      cVar1 = FUN_1402bf7a0(local_28,param_2,uVar3,uVar4);
      if (cVar1 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      FUN_1402bc690(local_28,lVar7);
    }
    if (((plVar8 != (longlong *)0x0) &&
        (cVar1 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1040,&local_20), cVar1 != '\0')) &&
       (iVar2 = (**(code **)(local_20[2] + 0x168))(), iVar2 == 5000)) {
      uVar3 = (**(code **)(*local_20 + 0x30))();
      uVar4 = (**(code **)(*local_20 + 0x38))();
      cVar1 = FUN_1402bf7a0(local_20,param_2,uVar3,uVar4);
      if (cVar1 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_1402bc690(local_20,lVar7);
      }
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_30  @140599fd0  [high:rtti-vtable]  (orig: FUN_140599fd0)
ulonglong FUN_140599fd0(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    in_RAX = 0;
    if (plVar1 != (longlong *)0x0) {
      lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
      in_RAX = 0;
      if (lVar2 != 0) {
        lVar2 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x160))(lVar2 + 0x10);
        in_RAX = 0;
        if (lVar2 != 0) {
          uVar3 = FUN_14016cc60(lVar2);
          return uVar3;
        }
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CFactionMatchActor@adapter::vfunc_32  @14059a020  [high:rtti-vtable]  (orig: FUN_14059a020)
bool FUN_14059a020(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CFactionMatchActor@adapter::vfunc_33  @14059a0a0  [high:rtti-vtable]  (orig: FUN_14059a0a0)
ulonglong FUN_14059a0a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 2) & 1);
}

// ==== CFactionMatchActor@adapter::vfunc_40  @14059a170  [high:rtti-vtable]  (orig: FUN_14059a170)
ulonglong FUN_14059a170(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1c) & 1);
}

// ==== CFactionMatchActor@adapter::vfunc_41  @14059a240  [high:rtti-vtable]  (orig: FUN_14059a240)
ulonglong FUN_14059a240(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1e) & 1);
}

// ==== CFactionMatchActor@adapter::vfunc_42  @14059a310  [high:rtti-vtable]  (orig: FUN_14059a310)
void FUN_14059a310(longlong param_1,int param_2)

{
  undefined2 uVar1;
  undefined2 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong lVar9;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  if (((param_2 != 0) &&
      (plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))(),
      plVar6 != (longlong *)0x0)) && (lVar7 = (**(code **)(*plVar6 + 0x2b0))(plVar6), lVar7 != 0)) {
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar6 = (longlong *)FUN_1400876b0(uVar8);
    lVar9 = *plVar6;
    uVar4 = FUN_140161f50(lVar7);
    lVar9 = (**(code **)(lVar9 + 0x10))(plVar6,uVar4,1);
    local_18 = 0;
    local_14 = 0;
    local_10 = 0;
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar8 = FUN_1400d6610(uVar8);
    FUN_140006c50(uVar8,&local_18);
    if ((lVar9 == 0) || (cVar3 = FUN_1401195d0(lVar9), cVar3 == '\0')) {
      uVar1 = *(undefined2 *)(lVar7 + 0xf0e);
      uVar2 = *(undefined2 *)(lVar7 + 0xf0c);
      uVar4 = FUN_140161f50(lVar7);
      iVar5 = FUN_1401c55b0(lVar7,uVar4,uVar2,uVar1,0);
      if (iVar5 == 0) {
        return;
      }
    }
    FUN_1401c55b0(lVar7,local_18,local_14,local_10,0);
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_21  @14059a430  [high:rtti-vtable]  (orig: FUN_14059a430)
void FUN_14059a430(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined8 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x88))(*(longlong **)(lVar1 + 0x88),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR("Npc id invalid!(%u)");
  }
  else {
    if ((*(longlong *)(lVar1 + 0x60) == 0) || (*(char *)(lVar1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x60))(*(longlong **)(lVar1 + 0x60),1,param_3);
    }
    if ((*(longlong *)(lVar1 + 0x60) == 0) || (*(char *)(lVar1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x60))(*(longlong **)(lVar1 + 0x60),0x12,param_4)
      ;
    }
    if ((*(longlong *)(lVar1 + 0x60) == 0) || (*(char *)(lVar1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x68))(*(longlong **)(lVar1 + 0x60),3,param_5);
      (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x70))();
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_8  @14059a5c0  [high:rtti-vtable]  (orig: FUN_14059a5c0)
int FUN_14059a5c0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  int iVar7;
  undefined1 local_48 [8];
  undefined1 local_40 [24];
  longlong *local_28;
  longlong *local_20;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_48);
  iVar7 = 0;
  do {
    cVar2 = FUN_1400ce310(local_40);
    if (cVar2 == '\0') {
      return iVar7;
    }
    while (cVar2 = (**(code **)(*local_28 + 0x298))(local_28,0x1001,&local_20), cVar2 == '\0') {
      cVar2 = FUN_1400ce310(local_40);
      if (cVar2 == '\0') {
        return iVar7;
      }
    }
    if ((local_20 != (longlong *)0x0) &&
       (cVar2 = (**(code **)(local_20[2] + 0x280))(local_20 + 2), cVar2 == '\0')) {
      if (local_20 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar3 = (**(code **)(local_20[2] + 0x170))(local_20 + 2);
      if (iVar3 == param_2) {
        if (local_20 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        iVar3 = (**(code **)(local_20[2] + 0x168))(local_20 + 2);
        if (iVar3 == param_3) {
          if (local_20 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar1 = local_20;
          plVar6 = (longlong *)FUN_1401181a0();
          lVar5 = *plVar6;
          uVar4 = (**(code **)(*plVar1 + 8))(plVar1);
          iVar3 = (**(code **)(lVar5 + 0xb0))(plVar6,uVar4,0x57);
          if (0 < iVar3) {
            iVar7 = iVar7 + 1;
          }
        }
      }
    }
  } while( true );
}

// ==== CFactionMatchActor@adapter::vfunc_23  @14059a7d0  [high:rtti-vtable]  (orig: FUN_14059a7d0)
void FUN_14059a7d0(longlong param_1,int param_2)

{
  undefined2 uVar1;
  undefined2 uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  uint in_stack_ffffffffffffff88;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined1 local_50 [40];
  longlong local_28;
  
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar7 = FUN_140087650(uVar6);
  if (lVar7 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1402ac340(lVar7,local_50);
    while (cVar3 = FUN_1400cf370(local_50), cVar3 != '\0') {
      if (local_28 != 0) {
        local_60 = 0;
        local_5c = 0;
        local_58 = 0;
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        uVar6 = FUN_1400d6610(uVar6);
        FUN_140006c50(uVar6,&local_60);
        if (local_28 == 0) {
          in_stack_ffffffffffffff88 = 0;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        iVar4 = (**(code **)(*(longlong *)(local_28 + 0x10) + 0x168))();
        if (iVar4 == param_2) {
          uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
          plVar8 = (longlong *)FUN_1400876b0(uVar6);
          if (local_28 == 0) {
            in_stack_ffffffffffffff88 = 0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar7 = *plVar8;
          uVar5 = FUN_140161f50(local_28);
          lVar7 = (**(code **)(lVar7 + 0x10))(plVar8,uVar5,1);
          if (lVar7 != 0) {
            plVar8 = *(longlong **)(*(longlong *)(lVar7 + 0x58) + 8);
            plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
            uVar9 = (**(code **)(*plVar8 + 0x58))(plVar8);
            if ((uVar9 >> 0x1c & 1) != 0) {
              if (local_28 == 0) {
                in_stack_ffffffffffffff88 = 0;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              in_stack_ffffffffffffff88 = in_stack_ffffffffffffff88 & 0xffffff00;
              FUN_1401c55b0(local_28,local_60,local_5c,local_58,in_stack_ffffffffffffff88);
              goto LAB_14059aa84;
            }
          }
          if (local_28 == 0) {
            in_stack_ffffffffffffff88 = 0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar7 = local_28;
          uVar1 = *(undefined2 *)(local_28 + 0xf0e);
          uVar2 = *(undefined2 *)(local_28 + 0xf0c);
          uVar5 = FUN_140161f50(local_28);
          in_stack_ffffffffffffff88 = in_stack_ffffffffffffff88 & 0xffffff00;
          iVar4 = FUN_1401c55b0(lVar7,uVar5,uVar2,uVar1,in_stack_ffffffffffffff88);
          if (iVar4 != 0) {
            if (local_28 == 0) {
              in_stack_ffffffffffffff88 = 0;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            in_stack_ffffffffffffff88 = in_stack_ffffffffffffff88 & 0xffffff00;
            FUN_1401c55b0(local_28,local_60,local_5c,local_58,in_stack_ffffffffffffff88);
          }
        }
LAB_14059aa84:
        if (local_28 == 0) {
          in_stack_ffffffffffffff88 = 0;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        cVar3 = (**(code **)(*(longlong *)(local_28 + 0x10) + 0x220))();
        if (cVar3 == '\0') {
          if (local_28 == 0) {
            in_stack_ffffffffffffff88 = 0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          in_stack_ffffffffffffff88 = in_stack_ffffffffffffff88 & 0xffffff00;
          FUN_1401c6d40(local_28,0,0,0,in_stack_ffffffffffffff88);
        }
      }
    }
  }
  return;
}

// ==== CFactionMatchActor@adapter::vfunc_14  @14059ab40  [high:rtti-vtable]  (orig: FUN_14059ab40)
void FUN_14059ab40(longlong param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  bool bVar10;
  
  *param_3 = 0;
  *param_4 = 0;
  if (param_2 != 0) {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar6 = (longlong *)FUN_1400876b0(uVar5);
    lVar7 = (**(code **)(*plVar6 + 0x10))(plVar6,param_2,1);
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar6 = (longlong *)FUN_1400875f0(uVar5);
      plVar8 = (longlong *)(**(code **)(*plVar6 + 0xd0))(plVar6);
      plVar6 = *(longlong **)plVar8[6];
      plVar1 = (longlong *)*plVar8;
LAB_14059ac10:
      lVar7 = 0;
      plVar9 = (longlong *)plVar8[6];
      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar8)) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 != plVar9) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar7 = *plVar1;
        }
        if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar9 = (longlong *)plVar6[4];
        if (plVar9 != (longlong *)0x0) {
          iVar3 = (**(code **)(plVar9[2] + 0x168))(plVar9 + 2);
          if ((iVar3 == param_2) &&
             (iVar3 = (**(code **)(*(longlong *)plVar9[0xc] + 0x10))((longlong *)plVar9[0xc],4),
             iVar3 == 0x29)) {
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            *param_3 = uVar4;
          }
          else {
            iVar3 = (**(code **)(plVar9[2] + 0x168))(plVar9 + 2);
            if ((iVar3 == param_2) &&
               (iVar3 = (**(code **)(*(longlong *)plVar9[0xc] + 0x10))((longlong *)plVar9[0xc],4),
               iVar3 == 0x2a)) {
              uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
              *param_4 = uVar4;
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
          plVar9 = plVar6;
          plVar2 = (longlong *)plVar6[2];
          if (*(char *)(plVar6[2] + 0x29) == '\0') {
            do {
              plVar6 = plVar2;
              plVar2 = (longlong *)*plVar6;
            } while (*(char *)(*plVar6 + 0x29) == '\0');
          }
          else {
            do {
              plVar6 = (longlong *)plVar9[1];
              if (*(char *)((longlong)plVar6 + 0x29) != '\0') break;
              bVar10 = plVar9 == (longlong *)plVar6[2];
              plVar9 = plVar6;
            } while (bVar10);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        goto LAB_14059ac10;
      }
    }
  }
  return;
}

