// ==== CMsgName@world_kernel::vfunc_1  @14007d200  [high:rtti-vtable]  (orig: FUN_14007d200)
ulonglong FUN_14007d200(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f7);
}

// ==== CMsgName@world_kernel::vfunc_3  @14007d3c0  [high:rtti-vtable]  (orig: FUN_14007d3c0)
void FUN_14007d3c0(void)

{
  return;
}

// ==== CMsgName@world_kernel::vfunc_0  @14007d3d0  [high:rtti-vtable]  (orig: FUN_14007d3d0)
undefined8 * FUN_14007d3d0(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgName::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_1400752a0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

