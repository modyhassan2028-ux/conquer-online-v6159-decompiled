// ==== CCrossMsgLeagueInfo::ctor_or_dtor  @14045bc40  [high:vtable-assign]  (orig: FUN_14045bc40)
undefined8 * FUN_14045bc40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLeagueInfo::ctor_or_dtor  @14045bc90  [high:vtable-assign]  (orig: FUN_14045bc90)
void FUN_14045bc90(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLeagueInfo::vfunc_1  @14045bcc0  [high:rtti-vtable]  (orig: FUN_14045bcc0)
undefined8 FUN_14045bcc0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLeagueInfo::vfunc_3  @14045bf40  [high:rtti-vtable]  (orig: FUN_14045bf40)
void FUN_14045bf40(longlong param_1)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (**(short **)(param_1 + 0x428) == 2) {
    plVar1 = (longlong *)FUN_140087ed0();
    (**(code **)(*plVar1 + 0x658))
              (plVar1,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2),
               *(longlong *)(param_1 + 0x428) + 4);
  }
  return;
}

// ==== CCrossMsgLeagueInfo::ctor_or_dtor  @14045bfc0  [high:vtable-assign]  (orig: FUN_14045bfc0)
undefined8 * FUN_14045bfc0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

