// ==== CPlayerCaltivateTimes::helper_1403feb30  @1403feb30  [medium:callgraph-r0]  (orig: FUN_1403feb30)
void FUN_1403feb30(__uint64 param_1)

{
  if ((DAT_140976328 & 1) == 0) {
    DAT_140976328 = DAT_140976328 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976320,"CPlayerCaltivateTimes");
    atexit((_func_5014 *)&LAB_1406d6d30);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403feb85. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976320,param_1);
  return;
}

// ==== CPlayerCaltivateTimes::helper_1403feb90  @1403feb90  [medium:callgraph-r0]  (orig: FUN_1403feb90)
void FUN_1403feb90(void *param_1)

{
  if ((DAT_140976328 & 1) == 0) {
    DAT_140976328 = DAT_140976328 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976320,"CPlayerCaltivateTimes");
    atexit((_func_5014 *)&LAB_1406d6d30);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403febe5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976320,param_1);
  return;
}

// ==== CPlayerCaltivateTimes::ctor_or_dtor  @1403fec50  [high:vtable-assign]  (orig: FUN_1403fec50)
undefined8 * FUN_1403fec50(undefined8 *param_1,byte param_2)

{
  *param_1 = CPlayerCaltivateTimes::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403feb90();
  }
  return param_1;
}

// ==== CPlayerCaltivateTimes::ctor_or_dtor  @1403fec80  [high:vtable-assign]  (orig: FUN_1403fec80)
undefined8 * FUN_1403fec80(int param_1,longlong param_2,undefined1 param_3)

{
  undefined8 *puVar1;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1 = (undefined8 *)FUN_1403feb30(0x20);
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = CPlayerCaltivateTimes::vftable;
      *(int *)(puVar1 + 1) = param_1;
      puVar1[2] = param_2;
      *(undefined1 *)(puVar1 + 3) = param_3;
    }
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      puVar1 = (undefined8 *)0x0;
    }
  }
  return puVar1;
}

