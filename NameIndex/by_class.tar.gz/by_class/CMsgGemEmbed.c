// ==== CMsgGemEmbed::helper_1403334d0  @1403334d0  [medium:callgraph-r0]  (orig: FUN_1403334d0)
void FUN_1403334d0(undefined8 param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined1 local_78 [36];
  int local_54;
  int local_50;
  
  cVar1 = FUN_140332fe0();
  if ((cVar1 != '\0') || (cVar1 = FUN_140333220(param_1,param_2), cVar1 != '\0')) {
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_2);
    if ((plVar5 != (longlong *)0x0) && (cVar1 = FUN_1400ffc20(plVar5), cVar1 == '\0')) {
      if (param_3 < 1) {
        param_3 = 1;
      }
      if (2 < param_3) {
        param_3 = 2;
      }
      FUN_140101cb0(plVar5,local_78);
      uVar2 = (**(code **)(*plVar5 + 8))(plVar5);
      FUN_140188880(param_1,uVar2);
      if (param_3 == 1) {
        if ((local_54 != 0) && (local_54 != 0xff)) {
          FUN_140104140(plVar5,8,0xff);
          iVar3 = FUN_1400ff520(plVar5,local_54 + 700000);
          if (iVar3 != 0) {
            iVar4 = FUN_1400fda10(plVar5,5,1);
            iVar3 = (iVar4 * 100) / (iVar3 + 100);
            if (iVar3 < 0) {
              iVar3 = 0;
            }
            FUN_140104140(plVar5,5,iVar3);
            iVar3 = FUN_1400fda10(plVar5,5,1);
            iVar4 = FUN_1400fda10(plVar5,4,1);
            if (iVar3 < iVar4) {
              uVar2 = FUN_1400fda10(plVar5,5,1);
              FUN_140104140(plVar5,4,uVar2);
            }
          }
          FUN_140104080(plVar5,1);
        }
      }
      else {
        if (param_3 != 2) {
          log_InlineLogERROR("invalid pos:%u in gem take out.");
          return;
        }
        if ((local_50 != 0) && (local_50 != 0xff)) {
          FUN_140104140(plVar5,9,0xff);
          iVar3 = FUN_1400ff520(plVar5,local_50 + 700000);
          if (iVar3 != 0) {
            iVar4 = FUN_1400fda10(plVar5,5,1);
            iVar3 = (iVar4 * 100) / (iVar3 + 100);
            if (iVar3 < 0) {
              iVar3 = 0;
            }
            FUN_140104140(plVar5,5,iVar3);
            iVar3 = FUN_1400fda10(plVar5,5,1);
            iVar4 = FUN_1400fda10(plVar5,4,1);
            if (iVar3 < iVar4) {
              uVar2 = FUN_1400fda10(plVar5,5,1);
              FUN_140104140(plVar5,4,uVar2);
            }
          }
          FUN_140104080(plVar5,1);
        }
      }
      FUN_140194390(param_1);
      plVar6 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar6 = (longlong *)0x0;
      }
      (**(code **)(*plVar6 + 0x130))(plVar6,param_1,plVar5,3,0,0);
    }
  }
  return;
}

// ==== CMsgGemEmbed::helper_140343540  @140343540  [medium:callgraph-r0]  (orig: FUN_140343540)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140343540(longlong *param_1,undefined4 param_2,uint param_3,uint param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  int iVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined1 local_98 [36];
  int local_74;
  int local_70;
  
  uVar11 = (ulonglong)param_3;
  cVar1 = FUN_140332fe0();
  if ((cVar1 == '\0') && (cVar1 = FUN_140333220(param_1,param_2), cVar1 == '\0')) {
    return;
  }
  plVar8 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar8 = (longlong *)0x0;
  }
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_2);
  if (plVar8 == (longlong *)0x0) {
    return;
  }
  uVar2 = FUN_1400fda10(plVar8,1,1);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 == 0x15) {
    return;
  }
  iVar3 = FUN_1400ff9e0(plVar8);
  if (iVar3 == 0x26b) {
    return;
  }
  cVar1 = FUN_140332fe0(param_1,param_3);
  if (cVar1 == '\0') {
    return;
  }
  plVar5 = (longlong *)FUN_140087d40();
  lVar6 = (**(code **)(*plVar5 + 0x60))(plVar5,param_3);
  if (lVar6 == 0) {
    return;
  }
  cVar1 = FUN_140103bd0(lVar6);
  if (cVar1 == '\0') {
    return;
  }
  cVar1 = FUN_1400ffc20(lVar6);
  if (cVar1 != '\0') {
    return;
  }
  cVar1 = FUN_1400ffbe0(lVar6);
  if ((cVar1 != '\0') && (cVar1 = FUN_1400ffbe0(plVar8), cVar1 == '\0')) {
    return;
  }
  iVar3 = FUN_1400fda10(lVar6,1,1);
  if (iVar3 < 0xaaec5) goto LAB_140343732;
  if (iVar3 < 0xaaec8) {
    uVar2 = FUN_1400fda10(plVar8,1,1);
    iVar4 = FUN_1400ff680(uVar2);
    if (iVar4 == 0xc) goto LAB_140343732;
    uVar2 = FUN_1400fda10(plVar8,1,1);
    iVar4 = FUN_1400ff680(uVar2);
  }
  else {
    if ((iVar3 < 0xaaed9) || (0xaaedb < iVar3)) goto LAB_140343732;
    uVar2 = FUN_1400fda10(plVar8,1,1);
    iVar4 = FUN_1400ff680(uVar2);
    if (iVar4 == 0xd) goto LAB_140343732;
    uVar2 = FUN_1400fda10(plVar8,1,1);
    iVar4 = FUN_1400ff680(uVar2);
  }
  if (iVar4 != 0x16) {
    return;
  }
LAB_140343732:
  uVar2 = FUN_1400fda10(plVar8,1,1);
  iVar4 = FUN_1400ff680(uVar2);
  if ((((iVar4 != 0xc) || (iVar3 == 0xaaec5)) || (iVar3 == 0xaaec6)) || (iVar3 == 0xaaec7)) {
    uVar2 = FUN_1400fda10(plVar8,1,1);
    iVar4 = FUN_1400ff680(uVar2);
    if (((iVar4 != 0xd) || (iVar3 == 0xaaed9)) || ((iVar3 == 0xaaeda || (iVar3 == 0xaaedb)))) {
      uVar10 = (ulonglong)param_4;
      if ((int)param_4 < 1) {
        uVar10 = 1;
      }
      if (2 < (int)uVar10) {
        uVar10 = 2;
      }
      uVar2 = FUN_1400fda10(plVar8,1,1);
      iVar4 = FUN_1400ff680(uVar2);
      iVar9 = (int)uVar10;
      if (iVar4 == 0x16) {
        if (iVar9 == 1) {
          if (((iVar3 != 0xaaec5) && (iVar3 != 0xaaec6)) && (iVar3 != 0xaaec7)) {
            return;
          }
        }
        else {
          if (iVar9 != 2) {
            return;
          }
          if (((iVar3 != 0xaaed9) && (iVar3 != 0xaaeda)) && (iVar3 != 0xaaedb)) {
            return;
          }
        }
      }
      FUN_140101cb0(plVar8,local_98);
      uVar2 = (**(code **)(*plVar8 + 8))(plVar8);
      FUN_140188880(param_1,uVar2);
      if (iVar9 == 1) {
        if (local_74 == 0xff) {
          iVar3 = FUN_1400fda10(lVar6,1,1);
          FUN_140104140(plVar8,8,iVar3 % 1000,0);
          uVar2 = FUN_1400fda10(lVar6,1,1);
          iVar3 = FUN_1400ff520(plVar8,uVar2);
          if (iVar3 != 0) {
            iVar4 = FUN_1400fda10(plVar8,5,1);
            FUN_140104140(plVar8,5,((iVar3 + 100) * iVar4) / 100,0);
          }
          cVar1 = FUN_140104440(plVar8);
          if (cVar1 != '\0') {
            FUN_1400fda10(plVar8,1,1);
            FUN_1400fda10(lVar6,1,1);
            uVar10 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/embed_gem",
                          "user[%u] embed gem[id:%u, type:%u] on socket 1 of item[id:%u, type[%u]",
                          uVar10 & 0xffffffff,uVar11);
          }
          FUN_140104080(plVar8,1);
          cVar1 = FUN_140340190(param_1,uVar11,1,1);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","ExpendMultiItem(idGem, 1, SYNCHRO_TRUE)",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
          }
        }
      }
      else {
        if (iVar9 != 2) {
          log_InlineLogERROR("invalid pos:%u in gem embed.",uVar10);
          return;
        }
        if (local_70 == 0xff) {
          iVar3 = FUN_1400fda10(lVar6,1,1);
          FUN_140104140(plVar8,9,iVar3 % 1000,0);
          uVar2 = FUN_1400fda10(lVar6,1,1);
          iVar3 = FUN_1400ff520(plVar8,uVar2);
          if (iVar3 != 0) {
            iVar4 = FUN_1400fda10(plVar8,5,1);
            FUN_140104140(plVar8,5,((iVar3 + 100) * iVar4) / 100,0);
          }
          cVar1 = FUN_140104440(plVar8);
          if (cVar1 != '\0') {
            FUN_1400fda10(plVar8,1,1);
            FUN_1400fda10(lVar6,1,1);
            uVar10 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/embed_gem",
                          "user[%u] embed gem[id:%u, type:%u] on socket 2 of item[id:%u, type[%u]",
                          uVar10 & 0xffffffff,(ulonglong)param_3);
          }
          FUN_140104080(plVar8,1);
          cVar1 = FUN_140340190(param_1,uVar11,1,1);
          if (cVar1 == '\0') {
            log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","ExpendMultiItem(idGem, 1, SYNCHRO_TRUE)",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp"
                              );
          }
        }
        else {
          FUN_1400fda10(plVar8,1,1);
          uVar11 = FUN_1400fda10(lVar6,1,1);
          uVar10 = (**(code **)(*param_1 + 8))(param_1);
          log_InlineLogERROR("CUser::EmbedGem, user[%u] embed gem[id:%u, type:%u] on socket 2 of item[id:%u, type:%u, gem2:%d]"
                             ,uVar10 & 0xffffffff,(ulonglong)param_3,uVar11 & 0xffffffff);
        }
      }
      FUN_140194390(param_1);
      plVar5 = (longlong *)FUN_140087d40();
      (**(code **)(*plVar5 + 0x130))(plVar5,param_1,plVar8,3);
      uVar7 = FUN_140008520((int)param_1[0x246]);
      uVar7 = FUN_140087c40(uVar7);
      FUN_140261810(uVar7,param_1,0xd);
    }
  }
  return;
}

// ==== CMsgGemEmbed::ctor_or_dtor  @140456ad0  [high:vtable-assign]  (orig: FUN_140456ad0)
undefined8 * FUN_140456ad0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGemEmbed::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgGemEmbed::ctor_or_dtor  @140456b20  [high:vtable-assign]  (orig: FUN_140456b20)
void FUN_140456b20(undefined8 *param_1)

{
  *param_1 = CMsgGemEmbed::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgGemEmbed::vfunc_1  @140456b50  [high:rtti-vtable]  (orig: FUN_140456b50)
ulonglong FUN_140456b50(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x403);
}

// ==== CMsgGemEmbed::ctor_or_dtor  @140456b80  [high:vtable-assign]  (orig: FUN_140456b80)
undefined8 * FUN_140456b80(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGemEmbed::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgGemEmbed::vfunc_3  @140456bd0  [high:rtti-vtable]  (orig: FUN_140456bd0)
void FUN_140456bd0(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar4,(int)lVar2,*puVar1);
    cVar3 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2);
    if (cVar3 == '\0') {
      pIVar8 = theInstance();
      lVar5 = plVar6[2];
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x000140456cd4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(lVar5 + 0x358))(plVar6 + 2,uVar9);
      return;
    }
    lVar5 = *(longlong *)(param_1 + 0x428);
    if (*(short *)(lVar5 + 0x12) == 0) {
      FUN_140343540(plVar6,*(undefined4 *)(lVar5 + 8),*(undefined4 *)(lVar5 + 0xc),
                    *(undefined2 *)(lVar5 + 0x10));
    }
    else if (*(short *)(lVar5 + 0x12) == 1) {
      FUN_1403334d0(plVar6,*(undefined4 *)(lVar5 + 8),*(undefined2 *)(lVar5 + 0x10));
      return;
    }
  }
  return;
}

