// ==== Closure@protobuf@google::helper_140556b80  @140556b80  [medium:callgraph-r0]  (orig: FUN_140556b80)
void FUN_140556b80(undefined8 *param_1)

{
  *param_1 = google::protobuf::Closure::vftable;
  return;
}

// ==== Closure@protobuf@google::vfunc_0  @1405570d0  [high:rtti-vtable]  (orig: FUN_1405570d0)
void * FUN_1405570d0(void *param_1,uint param_2)

{
  FUN_140556b80(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

