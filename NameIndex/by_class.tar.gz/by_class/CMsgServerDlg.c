// ==== CMsgServerDlg::helper_140002440  @140002440  [medium:callgraph-r0]  (orig: FUN_140002440)
undefined8 FUN_140002440(undefined8 param_1)

{
  if (DAT_1409754e8 == (undefined8 *)0x0) {
    DAT_1409754e8 = operator_new(0x10);
    if (DAT_1409754e8 == (undefined8 *)0x0) {
      DAT_1409754e8 = (undefined8 *)0x0;
    }
    else {
      *DAT_1409754e8 = param_1;
      DAT_1409754e8[1] = 0;
    }
    if (DAT_1409754e8 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
  }
  return 1;
}

// ==== CMsgServerDlg::helper_140005b50  @140005b50  [medium:callgraph-r0]  (orig: FUN_140005b50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140005b50(void)

{
  int iVar1;
  undefined1 auStack_1d8 [32];
  short local_1b8 [208];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_1d8;
  iVar1 = Ordinal_115(2,local_1b8);
  if (iVar1 != 0) {
    log_InlineLogERROR("ERROR: Init WSAStartup() failed.");
    return 0;
  }
  if (local_1b8[0] != 2) {
    log_InlineLogERROR("ERROR: WSAStartup Version not match 2.0");
    return 0;
  }
  return 1;
}

// ==== CMsgServerDlg::helper_140005c10  @140005c10  [medium:callgraph-r0]  (orig: FUN_140005c10)
undefined1 * FUN_140005c10(undefined1 *param_1)

{
  *(undefined8 *)(param_1 + 0x20) = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 0x1028) = 0;
  *(undefined4 *)(param_1 + 0x202c) = 0;
  *(undefined4 *)(param_1 + 0x2030) = 0;
  *param_1 = 0;
  memset(param_1 + 0x28,0,0x1000);
  memset(param_1 + 0x102c,0,0x1000);
  return param_1;
}

// ==== CMsgServerDlg::helper_14001e220  @14001e220  [medium:callgraph-r0]  (orig: FUN_14001e220)
undefined4 FUN_14001e220(void)

{
  int iVar1;
  IStringManager *pIVar2;
  char *pcVar3;
  undefined4 uVar4;
  
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,&DAT_1406e0658);
  if (iVar1 == 0) {
    return 0;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"English");
  if (iVar1 == 0) {
    return 1;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"Spanish");
  if (iVar1 == 0) {
    return 2;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"French");
  if (iVar1 == 0) {
    return 3;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"Japanese");
  if (iVar1 == 0) {
    return 4;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"Arabic");
  if (iVar1 == 0) {
    return 5;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,"Russian");
  if (iVar1 == 0) {
    return 7;
  }
  pIVar2 = theInstance();
  pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"Language");
  iVar1 = _stricmp(pcVar3,&DAT_1406e0614);
  uVar4 = 0;
  if (iVar1 == 0) {
    uVar4 = 6;
  }
  return uVar4;
}

// ==== CMsgServerDlg::helper_14001f2f0  @14001f2f0  [medium:callgraph-r0]  (orig: FUN_14001f2f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_14001f2f0(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_448 [32];
  undefined8 local_428;
  CIniFile local_418 [1024];
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  CIniFile::CIniFile(local_418,"shell.ini","System");
  _DAT_1409757d4 = 0;
  _DAT_1409757d8 = 0;
  DAT_1409757dc = 0;
  _DAT_1409757ec = 0;
  DAT_1409757f0 = 0;
  DAT_1409757d0 = CIniFile::GetInt(local_418,"MAPGROUP_SIZE");
  if (DAT_1409757d0 == 0) {
    CIniFile::~CIniFile(local_418);
    uVar2 = 0;
  }
  else {
    iVar1 = CIniFile::GetInt(local_418,"FREE_LEV");
    if (iVar1 != 0) {
      DAT_140949794 = iVar1;
    }
    if (DAT_1409757d0 == 0) {
      CIniFile::~CIniFile(local_418);
      uVar2 = 0;
    }
    else {
      CIniFile::SetSection(local_418,"CrossClient");
      iVar1 = CIniFile::GetInt(local_418,"Enable");
      *(bool *)(param_1 + 0x1d0) = iVar1 == 1;
      CIniFile::SetSection(local_418,"IPADPaymentsClient");
      iVar1 = CIniFile::GetInt(local_418,"IsSupportIPADPayments");
      *(bool *)(param_1 + 0x220) = iVar1 == 1;
      CIniFile::SetSection(local_418,"GooglePaymentsClient");
      iVar1 = CIniFile::GetInt(local_418,"IsSupportGooglePayments");
      *(bool *)(param_1 + 0x222) = iVar1 == 1;
      CIniFile::SetSection(local_418,"ChangeServerClient");
      iVar1 = CIniFile::GetInt(local_418,"IsConnectChangeServer");
      *(bool *)(param_1 + 0x221) = iVar1 == 1;
      CIniFile::~CIniFile(local_418);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CMsgServerDlg::helper_14001f8e0  @14001f8e0  [medium:callgraph-r3]  (orig: FUN_14001f8e0)
void FUN_14001f8e0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMsgServerDlg::helper_14001fa00  @14001fa00  [medium:callgraph-r3]  (orig: FUN_14001fa00)
void FUN_14001fa00(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMsgServerDlg::helper_140020570  @140020570  [medium:callgraph-r0]  (orig: FUN_140020570)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140020570(void)

{
  char cVar1;
  LPCSTR lpSrc;
  BOOL BVar2;
  UINT UVar3;
  LSTATUS LVar4;
  DWORD DVar5;
  int iVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  HMODULE pHVar9;
  FARPROC pFVar10;
  INT_PTR IVar11;
  longlong lVar12;
  undefined8 *******pppppppuVar13;
  uint *puVar14;
  HKEY hKey;
  uint uVar15;
  CHAR *pCVar17;
  undefined1 auStackY_14d8 [32];
  DWORD local_1498;
  DWORD local_1494;
  HKEY local_1490;
  undefined4 local_1488;
  HKEY local_1480;
  _SYSTEM_INFO local_1478;
  undefined8 local_1448;
  _OSVERSIONINFOA local_1438;
  ushort local_13a0;
  char local_139e;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_1398 [8];
  undefined8 *******local_1390 [3];
  ulonglong local_1378;
  char cStack_1369;
  uint local_1368 [2];
  undefined1 local_1360;
  undefined7 uStack_135f;
  undefined1 local_1358;
  undefined7 uStack_1357;
  undefined1 local_1350;
  undefined7 uStack_134f;
  undefined1 local_1348;
  undefined7 uStack_1347;
  undefined1 local_1340;
  undefined7 uStack_133f;
  undefined1 local_1338;
  undefined1 uStack_1337;
  undefined6 uStack_1336;
  char *local_1330;
  char *local_1328;
  char local_1318;
  undefined1 local_1317 [255];
  char local_1218 [255];
  undefined1 local_1119;
  char local_1118 [255];
  undefined1 local_1019;
  CHAR local_1018 [4096];
  ulonglong local_18;
  undefined8 local_10;
  HKEY pHVar16;
  
  local_10 = 0x14002057c;
  local_1448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStackY_14d8;
  log_InlineLogMessage("f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp");
  pIVar7 = theInstance();
  uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"Language");
  log_InlineLogMessage("This server is for language %s",uVar8);
  local_1494 = 0x1000;
  BVar2 = GetComputerNameA(local_1018,&local_1494);
  if (BVar2 == 0) {
    log_InlineLogERROR("GetComputerName() failed at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xb6);
  }
  else {
    log_InlineLogMessage("Computer name: %s",local_1018);
  }
  local_1494 = 0x1000;
  BVar2 = GetUserNameA(local_1018,&local_1494);
  if (BVar2 == 0) {
    log_InlineLogERROR("GetUserName() failed at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xbe);
  }
  else {
    log_InlineLogMessage("User name: %s",local_1018);
  }
  UVar3 = GetSystemDirectoryA(local_1018,0x1000);
  if (UVar3 == 0) {
    log_InlineLogERROR("GetSystemDirectory() failed at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xc5);
  }
  else {
    log_InlineLogMessage("System Directory: %s",local_1018);
  }
  UVar3 = GetWindowsDirectoryA(local_1018,0x1000);
  if (UVar3 == 0) {
    log_InlineLogERROR("GetWindowsDirectory() failed at %s, %d",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xcc);
  }
  else {
    log_InlineLogMessage("Windows Directory: %s",local_1018);
  }
  local_1368[0] = 0x406e22c8;
  local_1368[1] = 1;
  local_1360 = 0xb8;
  uStack_135f = 0x1406e22;
  local_1358 = 0x88;
  uStack_1357 = 0x1406e22;
  local_1350 = 0x58;
  uStack_134f = 0x1406e22;
  local_1348 = 0x28;
  uStack_1347 = 0x1406e22;
  local_1340 = 0;
  uStack_133f = 0x1406e22;
  local_1338 = 0xd8;
  uStack_1337 = 0x21;
  uStack_1336 = 0x1406e;
  local_1330 = "PATH=%PATH%";
  local_1328 = "TEMP=%TEMP%";
  log_InlineLogMessage("Some environment variables:");
  puVar14 = local_1368;
  pHVar16 = (HKEY)0x0;
  do {
    lpSrc = *(LPCSTR *)puVar14;
    local_1494 = ExpandEnvironmentStringsA(lpSrc,local_1018,0x1000);
    if (local_1494 < 0x1001) {
      if (local_1494 == 0) {
        log_InlineLogERROR("ExpandEnvironmentStrings() failed (%u) at %s, %d",pHVar16,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xea);
      }
      else {
        log_InlineLogMessage("\t%s",local_1018);
      }
    }
    else {
      log_InlineLogERROR("Buffer too small to expand: \"%s\" at %s, %d",lpSrc,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0xe5);
    }
    uVar15 = (int)pHVar16 + 1;
    pHVar16 = (HKEY)(ulonglong)uVar15;
    puVar14 = puVar14 + 2;
  } while (uVar15 < 9);
  local_1478.u = (_union_552)0x0;
  local_1478.dwPageSize = 0;
  local_1478.lpMinimumApplicationAddress = (LPVOID)0x0;
  local_1478.lpMaximumApplicationAddress = (LPVOID)0x0;
  local_1478.dwActiveProcessorMask = 0;
  local_1478.dwNumberOfProcessors = 0;
  local_1478.dwProcessorType = 0;
  local_1478.dwAllocationGranularity = 0;
  local_1478.wProcessorLevel = 0;
  local_1478.wProcessorRevision = 0;
  pHVar9 = GetModuleHandleA("kernel32.dll");
  pFVar10 = GetProcAddress(pHVar9,"GetNativeSystemInfo");
  if (pFVar10 == (FARPROC)0x0) {
    GetSystemInfo(&local_1478);
  }
  else {
    (*pFVar10)(&local_1478);
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_1398,"Intel Pentium Pro/II/III");
  local_1490 = (HKEY)0x0;
  local_1488 = 0;
  local_1480 = (HKEY)0x0;
  LVar4 = RegOpenKeyExA((HKEY)0xffffffff80000002,
                        "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",0,0xf003f,&local_1480);
  pHVar16 = local_1480;
  hKey = (HKEY)0x0;
  if (LVar4 == 0) {
    local_1490 = local_1480;
    local_1488 = 0;
    local_1368[0] = 0;
    local_1368[1] = 0;
    local_1360 = 0;
    uStack_135f = 0;
    local_1358 = 0;
    uStack_1357 = 0;
    local_1350 = 0;
    uStack_134f = 0;
    local_1348 = 0;
    uStack_1347 = 0;
    local_1340 = 0;
    uStack_133f = 0;
    local_1338 = 0;
    uStack_1337 = 0;
    local_1498 = 0x32;
    LVar4 = RegQueryValueExA(local_1480,"ProcessorNameString",(LPDWORD)0x0,(LPDWORD)&local_1480,
                             (LPBYTE)local_1368,&local_1498);
    hKey = pHVar16;
    if ((LVar4 == 0) && (((int)local_1480 == 1 || ((int)local_1480 == 2)))) {
      if (local_1498 == 0) {
        local_1368[0] = local_1368[0] & 0xffffff00;
      }
      else if ((&cStack_1369)[local_1498] != '\0') goto LAB_1400209c0;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                (local_1398,(char *)local_1368);
    }
  }
LAB_1400209c0:
  log_InlineLogMessage("System information:");
  log_InlineLogMessage("\tOEM ID: %u",local_1478._0_8_ & 0xffffffff);
  log_InlineLogMessage("\tNumber of processors: %u",local_1478._32_8_ & 0xffffffff);
  pppppppuVar13 = local_1390;
  if (0xf < local_1378) {
    pppppppuVar13 = local_1390[0];
  }
  log_InlineLogMessage
            ("\tProcessor type: %s family %u model %u stepping %u",pppppppuVar13,
             (ulonglong)local_1478._40_8_ >> 0x20 & 0xffff,(ulonglong)local_1478._40_8_ >> 0x38);
  log_InlineLogMessage("\tActive processor mask: 0x%04x",local_1478.dwActiveProcessorMask);
  log_InlineLogMessage("\tPage size: %u",(ulonglong)local_1478._0_8_ >> 0x20);
  log_InlineLogMessage
            ("\tMinimum application address: 0x%08x",local_1478.lpMinimumApplicationAddress);
  log_InlineLogMessage
            ("\tMaximum application address: 0x%08x",local_1478.lpMaximumApplicationAddress);
  log_InlineLogMessage("\tAllocation granularity: 0x%08x",local_1478._40_8_ & 0xffffffff);
  pHVar9 = LoadLibraryA("Kernel32.dll");
  if (pHVar9 == (HMODULE)0x0) {
    DVar5 = GetLastError();
    log_InlineLogERROR("LoadLibrary Kernel.dll failed, ErrorNo %d. at %s, %d",(ulonglong)DVar5,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0x155);
  }
  else {
    pFVar10 = GetProcAddress(pHVar9,"GlobalMemoryStatusEx");
    if (pFVar10 == (FARPROC)0x0) {
      DVar5 = GetLastError();
      log_InlineLogERROR("GetProcAddress GlobalMemoryStatusEx failed, ErrorNo %d. at %s, %d",
                         (ulonglong)DVar5,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0x14e);
    }
    else {
      local_1368[0] = 0x40;
      IVar11 = (*pFVar10)(local_1368);
      if ((int)IVar11 == 0) {
        DVar5 = GetLastError();
        log_InlineLogERROR("_GlobalMemoryStatusEx failed, ErrorNo %d. at %s, %d",(ulonglong)DVar5,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0x149);
      }
      else {
        log_InlineLogMessage("Memory status:");
        log_InlineLogMessage
                  ("\tTotal size of physical memory in bytes: %10I64d(%f GB)",
                   CONCAT71(uStack_135f,local_1360),
                   (double)CONCAT71(uStack_135f,local_1360) * _DAT_1406e1f40);
        log_InlineLogMessage
                  ("\tSize of physical memory available in bytes: %10I64d(%f GB)",
                   CONCAT71(uStack_1357,local_1358),
                   (double)CONCAT71(uStack_1357,local_1358) * _DAT_1406e1f40);
        log_InlineLogMessage
                  ("\tTotal possible size of the paging file in bytes: %10I64d",
                   CONCAT71(uStack_134f,local_1350));
        log_InlineLogMessage
                  ("\tSize of space available in the paging file in bytes: %10I64d",
                   CONCAT71(uStack_1347,local_1348));
        log_InlineLogMessage
                  ("\tTotal size of the user mode portion of the virtual address space in bytes: %10I64d"
                   ,CONCAT71(uStack_133f,local_1340));
        log_InlineLogMessage
                  ("\tSize of space available in the virtual address space in bytes: %10I64d");
      }
    }
    FreeLibrary(pHVar9);
  }
  local_1318 = '\0';
  memset(local_1317,0,0xff);
  memset(&local_1438,0,0x9c);
  local_1438.dwOSVersionInfoSize = 0x9c;
  BVar2 = GetVersionExA(&local_1438);
  if (BVar2 == 0) {
    DVar5 = GetLastError();
    log_InlineLogMessage
              ("GetVersionEx(OSVERSIONINFOEX2) failed with fault:%u at %s, %d",(ulonglong)DVar5,
               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0x162);
    local_1438.dwOSVersionInfoSize = 0x9c;
    BVar2 = GetVersionExA(&local_1438);
    if (BVar2 != 0) {
      log_InlineLogMessage
                ("Windows %u.%u %s SP%u.%u build(%u), platform(%u)",
                 (ulonglong)local_1438.dwMajorVersion,(ulonglong)local_1438.dwMinorVersion,
                 local_1438.szCSDVersion);
      if (hKey != (HKEY)0x0) {
        RegCloseKey(hKey);
        local_1490 = (HKEY)0x0;
      }
      local_1488 = 0;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1398);
      return;
    }
    local_1438.dwOSVersionInfoSize = 0x94;
    BVar2 = GetVersionExA(&local_1438);
    if (BVar2 == 0) {
      DVar5 = GetLastError();
      log_InlineLogERROR("GetVersionEx(OSVERSIONINFO) failed with error:%u at %s, %d",
                         (ulonglong)DVar5,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp",0x173);
    }
    else {
      log_InlineLogMessage
                ("Windows %u.%u %s build(%u), platform(%u)",(ulonglong)local_1438.dwMajorVersion,
                 (ulonglong)local_1438.dwMinorVersion,local_1438.szCSDVersion);
    }
    if (hKey != (HKEY)0x0) {
      RegCloseKey(hKey);
      local_1490 = (HKEY)0x0;
    }
    local_1488 = 0;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1398);
    return;
  }
  if ((local_1438.dwPlatformId == 2) && (4 < local_1438.dwMajorVersion)) {
    strncat(&local_1318,"Microsoft ",0x100);
    if (local_1438.dwMajorVersion == 5) {
      if (local_1438.dwMinorVersion == 0) {
        strncat(&local_1318,"Windows 2000 ",0x100);
        if (local_139e == '\x01') {
          strncat(&local_1318,"Professional",0x100);
        }
        else if ((char)local_13a0 < '\0') {
          strncat(&local_1318,"Datacenter Server",0x100);
        }
        else if ((local_13a0 & 2) == 0) {
          strncat(&local_1318,"Server",0x100);
        }
        else {
          strncat(&local_1318,"Advanced Server",0x100);
        }
      }
      else if (local_1438.dwMinorVersion == 1) {
        strncat(&local_1318,"Windows XP ",0x100);
        if ((local_13a0 & 0x200) == 0) {
          strncat(&local_1318,"Professional",0x100);
        }
        else {
          strncat(&local_1318,"Home Edition",0x100);
        }
      }
      else {
        if (local_1438.dwMinorVersion != 2) goto LAB_140021793;
        iVar6 = GetSystemMetrics(0x59);
        if (iVar6 == 0) {
          if (local_13a0 == 0x200) {
            strncat(&local_1318,"Windows Storage Server 2003",0x100);
          }
          else if ((local_139e == '\x01') && (local_1478.u.s.wProcessorArchitecture == 9)) {
            strncat(&local_1318,"Windows XP Professional x64 Edition",0x100);
          }
          else {
            strncat(&local_1318,"Windows Server 2003, ",0x100);
          }
        }
        else {
          strncat(&local_1318,"Windows Server 2003 R2, ",0x100);
        }
        if (local_139e != '\x01') {
          if (local_1478.u.s.wProcessorArchitecture == 6) {
            if ((char)local_13a0 < '\0') {
              strncat(&local_1318,"Datacenter Edition for Itanium-based Systems",0x100);
            }
            else if ((local_13a0 & 2) != 0) {
              strncat(&local_1318,"Enterprise Edition for Itanium-based Systems",0x100);
            }
          }
          else if (local_1478.u.s.wProcessorArchitecture == 9) {
            if ((char)local_13a0 < '\0') {
              strncat(&local_1318,"Datacenter x64 Edition",0x100);
            }
            else if ((local_13a0 & 2) == 0) {
              strncat(&local_1318,"Standard x64 Edition",0x100);
            }
            else {
              strncat(&local_1318,"Enterprise x64 Edition",0x100);
            }
          }
          else if ((local_13a0 & 0x4000) == 0) {
            if ((char)local_13a0 < '\0') {
              strncat(&local_1318,"Datacenter Edition",0x100);
            }
            else if ((local_13a0 & 2) == 0) {
              if ((local_13a0 & 0x400) == 0) {
                strncat(&local_1318,"Standard Edition",0x100);
              }
              else {
                strncat(&local_1318,"Web Edition",0x100);
              }
            }
            else {
              strncat(&local_1318,"Enterprise Edition",0x100);
            }
          }
          else {
            strncat(&local_1318,"Compute Cluster Edition",0x100);
          }
        }
      }
    }
    else if (local_1438.dwMajorVersion == 6) {
      if (local_1438.dwMinorVersion == 0) {
        if (local_139e == '\x01') {
          strncat(&local_1318,"Windows Vista ",0x100);
        }
        else {
          strncat(&local_1318,"Windows Server 2008 ",0x100);
        }
      }
      else if (local_1438.dwMinorVersion == 1) {
        if (local_139e == '\x01') {
          strncat(&local_1318,"Windows 7 ",0x100);
        }
        else {
          strncat(&local_1318,"Windows Server 2008 R2 ",0x100);
        }
      }
      else {
        strncat(&local_1318,"Windows 6.x ",0x100);
      }
      local_1498 = 0;
      pHVar9 = GetModuleHandleA("kernel32.dll");
      pFVar10 = GetProcAddress(pHVar9,"GetProductInfo");
      if (pFVar10 == (FARPROC)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT",&DAT_1406e1b34,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp");
      }
      (*pFVar10)(6,0,0,0);
      switch(local_1498) {
      case 1:
      case 0x1c:
        strncat(&local_1318,"Ultimate Edition",0x100);
        break;
      case 2:
      case 5:
        strncat(&local_1318,"Home Basic Edition",0x100);
        break;
      case 3:
      case 0x1a:
        strncat(&local_1318,"Home Premium Edition",0x100);
        break;
      case 4:
      case 0x1b:
        strncat(&local_1318,"Enterprise Edition",0x100);
        break;
      case 6:
      case 0x10:
        strncat(&local_1318,"Business Edition",0x100);
        break;
      case 7:
        strncat(&local_1318,"Standard Edition",0x100);
        break;
      case 8:
        strncat(&local_1318,"Datacenter Edition",0x100);
        break;
      case 9:
        strncat(&local_1318,"Small Business Server",0x100);
        break;
      case 10:
        strncat(&local_1318,"Enterprise Edition",0x100);
        break;
      case 0xb:
        strncat(&local_1318,"Starter Edition",0x100);
        break;
      case 0xc:
        strncat(&local_1318,"Datacenter Edition (core installation)",0x100);
        break;
      case 0xd:
        strncat(&local_1318,"Standard Edition (core installation)",0x100);
        break;
      case 0xe:
        strncat(&local_1318,"Enterprise Edition (core installation)",0x100);
        break;
      case 0xf:
        strncat(&local_1318,"Enterprise Edition for Itanium-based Systems",0x100);
        break;
      case 0x11:
        strncat(&local_1318,"Web Server Edition",0x100);
        break;
      case 0x12:
        strncat(&local_1318,"Cluster Server Edition",0x100);
        break;
      case 0x13:
        strncat(&local_1318,"Home Server Edition",0x100);
        break;
      case 0x14:
        strncat(&local_1318,"Storage Server Express Edition",0x100);
        break;
      case 0x15:
        strncat(&local_1318,"Storage Server Standard Edition",0x100);
        break;
      case 0x16:
        strncat(&local_1318,"Storage Server Workgroup Edition",0x100);
        break;
      case 0x17:
        strncat(&local_1318,"Storage Server Enterprise Edition",0x100);
        break;
      case 0x18:
        strncat(&local_1318,"Server for Small Business Edition",0x100);
        break;
      case 0x19:
        strncat(&local_1318,"Small Business Server Premium Edition",0x100);
        break;
      case 0x1d:
        strncat(&local_1318,"Web Server Edition (core installation)",0x100);
        break;
      case 0x1e:
        strncat(&local_1318,"Windows Essential Business Server Management Server",0x100);
        break;
      case 0x1f:
        strncat(&local_1318,"Windows Essential Business Server Security Server",0x100);
        break;
      case 0x20:
        strncat(&local_1318,"Windows Essential Business Server Messaging Server",0x100);
        break;
      default:
        strncat(&local_1318,"Windows 6.0",0x100);
      }
    }
    else {
      _snprintf(local_1218,0x100," Bad Windows version %u.%u build(%u) platform(%u)");
      local_1119 = 0;
      strncat(&local_1318,local_1218,0x100);
    }
  }
  else {
    _snprintf(local_1218,0x100," Unsupported Windows version %u.%u build(%u) platform(%u)");
    local_1119 = 0;
    strncat(&local_1318,local_1218,0x100);
  }
  if (5 < local_1438.dwMajorVersion) {
    if (local_1478.u.s.wProcessorArchitecture == 0) {
      strncat(&local_1318,", 32-bit",0x100);
    }
    else if (local_1478.u.s.wProcessorArchitecture == 9) {
      strncat(&local_1318,", 64-bit",0x100);
    }
    else {
      strncat(&local_1318,", UnkonwnArch",0x100);
    }
  }
LAB_140021793:
  lVar12 = -1;
  pCVar17 = local_1438.szCSDVersion;
  do {
    if (lVar12 == 0) break;
    lVar12 = lVar12 + -1;
    cVar1 = *pCVar17;
    pCVar17 = pCVar17 + 1;
  } while (cVar1 != '\0');
  if (lVar12 != -2) {
    strncat(&local_1318," ",0x100);
    strncat(&local_1318,local_1438.szCSDVersion,0x100);
  }
  _snprintf(local_1118,0x100," (build %d)",(ulonglong)local_1438.dwBuildNumber);
  local_1019 = 0;
  strncat(&local_1318,local_1118,0x100);
  log_InlineLogMessage(&local_1318);
  if (hKey != (HKEY)0x0) {
    RegCloseKey(hKey);
    local_1490 = (HKEY)0x0;
  }
  local_1488 = 0;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1398);
  return;
}

// ==== CMsgServerDlg::vfunc_89  @140021b80  [high:rtti-vtable]  (orig: FUN_140021b80)
void FUN_140021b80(longlong param_1)

{
  int iVar1;
  
  FUN_14001e540(param_1,"CLOSE key pressed");
  iVar1 = AfxMessageBox("Are you sure?",0x101,0);
  if (iVar1 == 1) {
    *(undefined4 *)(param_1 + 0x1fc) = 3;
    FUN_14001e540(param_1,"Server closing...");
  }
  return;
}

// ==== CMsgServerDlg::helper_140021c80  @140021c80  [medium:callgraph-r0]  (orig: FUN_140021c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140021c80(undefined8 param_1)

{
  int iVar1;
  int iVar2;
  BOOL BVar3;
  __uint64 _Var4;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *pbVar5;
  uint uVar6;
  undefined1 auStackY_658 [32];
  _PROCESS_INFORMATION local_608;
  undefined8 local_5f0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_5e8 [48];
  _STARTUPINFOA local_5b8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_548 [48];
  CIniFile local_518 [1024];
  char local_118 [128];
  char local_98 [127];
  undefined1 local_19;
  ulonglong local_18;
  
  local_5f0 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStackY_658;
  CIniFile::CIniFile(local_518,"ExtraProc.ini","Config");
  iVar1 = CIniFile::GetInt(local_518,"Count");
  uVar6 = 0;
  if (0 < iVar1) {
    do {
      uVar6 = uVar6 + 1;
      _snprintf(local_98,0x80,"Exe%d",(ulonglong)uVar6);
      local_19 = 0;
      CIniFile::SetSection(local_518,local_98);
      memset(local_118,0,0x80);
      CIniFile::GetString(local_518,local_118,"ExeName",0x80);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_548,local_118);
      _Var4 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::rfind
                        (local_548,"\\",*(__uint64 *)npos_exref,1);
      if (_Var4 != *(__uint64 *)npos_exref) {
        pbVar5 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::substr
                           (local_548,(__uint64)local_5e8,_Var4 + 1);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                  (local_548,pbVar5);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_5e8);
      }
      iVar2 = FUN_14001f4d0(param_1);
      if (iVar2 == 0) {
        memset(&local_5b8,0,0x68);
        local_5b8.cb = 0x68;
        local_608.hProcess = (HANDLE)0x0;
        local_608.hThread = (HANDLE)0x0;
        local_608.dwProcessId = 0;
        local_608.dwThreadId = 0;
        BVar3 = CreateProcessA(local_118,(LPSTR)0x0,(LPSECURITY_ATTRIBUTES)0x0,
                               (LPSECURITY_ATTRIBUTES)0x0,0,0,(LPVOID)0x0,(LPCSTR)0x0,&local_5b8,
                               &local_608);
        if (BVar3 == 0) {
          tq::SysLogSave("extrapro","Init exe (%s) FALSE!",local_118);
        }
        else {
          CloseHandle(local_608.hThread);
          CloseHandle(local_608.hProcess);
          tq::SysLogSave("extrapro","Init exe (%s) success!",local_118);
        }
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_548);
      }
      else {
        tq::SysLogSave("extrapro","Init exe (%s) fail becuse it is exist!",local_118);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_548);
      }
    } while ((int)uVar6 < iVar1);
  }
  CIniFile::~CIniFile(local_518);
  return;
}

// ==== CMsgServerDlg::helper_140022420  @140022420  [medium:callgraph-r3]  (orig: FUN_140022420)
void FUN_140022420(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMsgServerDlg::helper_140022520  @140022520  [medium:callgraph-r3]  (orig: FUN_140022520)
void FUN_140022520(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x30)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x30);
  return;
}

// ==== CMsgServerDlg::helper_140023740  @140023740  [medium:callgraph-r3]  (orig: FUN_140023740)
void * FUN_140023740(undefined8 param_1,longlong param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_3 + 8) - (longlong)*(void **)(param_2 + 8) >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,*(void **)(param_2 + 8),_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CMsgServerDlg::ctor_or_dtor  @1400238a0  [high:vtable-assign]  (orig: FUN_1400238a0)
CDialog * FUN_1400238a0(CDialog *param_1,CWnd *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  HINSTANCE__ *hInstance;
  HICON pHVar3;
  
  CDialog::CDialog(param_1,0x66,param_2);
  *(undefined ***)param_1 = CMsgServerDlg::vftable;
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xe8));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf0));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf8));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x100));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x108));
  plVar2 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 0x134) = 0;
  *(undefined4 *)(param_1 + 0x138) = 0;
  *(undefined4 *)(param_1 + 0x13c) = 0;
  *(undefined4 *)(param_1 + 0x140) = 0;
  *(undefined4 *)(param_1 + 0x144) = 0;
  *(undefined4 *)(param_1 + 0x148) = 0;
  *(undefined4 *)(param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x150) = 0;
  CPerformanceInfo::CPerformanceInfo((CPerformanceInfo *)(param_1 + 0x158));
  CThreadTimesInfo::CThreadTimesInfo((CThreadTimesInfo *)(param_1 + 0x168));
  plVar1 = operator_new(8);
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 0x188);
    plVar2 = plVar1;
  }
  *(longlong **)(param_1 + 0x188) = plVar2;
  *(undefined8 *)(param_1 + 0x1a0) = 0;
  *(undefined8 *)(param_1 + 0x1a8) = 0;
  *(undefined8 *)(param_1 + 0x1b0) = 0;
  *(undefined4 *)(param_1 + 0x210) = 0;
  *(undefined4 *)(param_1 + 0x214) = 0;
  *(undefined4 *)(param_1 + 0x218) = 0;
  *(undefined4 *)(param_1 + 0x21c) = 0;
  FUN_140005c10(param_1 + 0x240);
  *(undefined4 *)(param_1 + 0x22bc) = 0;
  *(undefined4 *)(param_1 + 0x22c0) = 0;
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::operator=
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xe8),"");
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::operator=
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf0),"");
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::operator=
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf8),"");
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::operator=
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x100),"");
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::operator=
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x108),"");
  AfxGetModuleState();
  hInstance = AfxFindResourceHandle((char *)0x80,(char *)0xe);
  pHVar3 = LoadIconA(hInstance,(LPCSTR)0x80);
  *(HICON *)(param_1 + 0x200) = pHVar3;
  *(undefined4 *)(param_1 + 0x1fc) = 0;
  *(undefined4 *)(param_1 + 0x1f8) = 0;
  *(undefined8 *)(param_1 + 0x1f0) = 0;
  *(undefined8 *)(param_1 + 0x1b8) = 0;
  *(undefined8 *)(param_1 + 0x1c0) = 0;
  *(undefined8 *)(param_1 + 0x1c8) = 0;
  param_1[0x1d0] = (CDialog)0x0;
  *(undefined8 *)(param_1 + 0x178) = 0;
  *(undefined8 *)(param_1 + 0x180) = 0;
  *(undefined8 *)(param_1 + 0x1d8) = 0;
  *(undefined8 *)(param_1 + 0x1e0) = 0;
  *(undefined8 *)(param_1 + 0x1e8) = 0;
  *(undefined8 *)(param_1 + 0x208) = 0;
  param_1[0x220] = (CDialog)0x0;
  param_1[0x221] = (CDialog)0x0;
  param_1[0x222] = (CDialog)0x0;
  *(undefined8 *)(param_1 + 0x228) = 0;
  *(undefined8 *)(param_1 + 0x230) = 0;
  *(undefined8 *)(param_1 + 0x238) = 0;
  *(undefined8 *)(param_1 + 0x110) = 0;
  *(undefined8 *)(param_1 + 0x118) = 0;
  *(undefined8 *)(param_1 + 0x120) = 0;
  *(undefined8 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 0x130) = 0;
  return param_1;
}

// ==== CMsgServerDlg::helper_140023f70  @140023f70  [medium:callgraph-r2]  (orig: FUN_140023f70)
undefined8 * FUN_140023f70(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar4 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  uVar3 = (longlong)(param_2[4] - param_2[3]) >> 3;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar3 != 0) {
    if (0x1fffffffffffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_14001f8e0();
    }
    lVar2 = FUN_140022420(param_1 + 2,uVar3);
    param_1[3] = lVar2;
    param_1[4] = lVar2;
    param_1[5] = lVar2 + uVar3 * 8;
    uVar3 = param_2[4];
    if (uVar3 < (ulonglong)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_58 = (undefined4)*param_2;
    uStack_54 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_50 = (undefined4)uVar3;
    uStack_4c = (undefined4)(uVar3 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uVar3 = param_2[3];
    if ((ulonglong)param_2[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    local_48 = (undefined4)*param_2;
    uStack_44 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_40 = (undefined4)uVar3;
    uStack_3c = (undefined4)(uVar3 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uVar4 = FUN_140023740(param_1,&local_28,&local_38,param_1[3],uVar4);
    param_1[4] = uVar4;
  }
  return param_1;
}

// ==== CMsgServerDlg::vfunc_1  @1400241d0  [high:rtti-vtable]  (orig: FUN_1400241d0)
void * FUN_1400241d0(void *param_1,uint param_2)

{
  FUN_14001db10();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgServerDlg::helper_1400247a0  @1400247a0  [medium:callgraph-r3]  (orig: FUN_1400247a0)
longlong FUN_1400247a0(longlong param_1,longlong param_2,longlong param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x30) {
    if (param_3 != 0) {
      FUN_140023f70(param_3,param_1);
    }
    param_3 = param_3 + 0x30;
  }
  return param_3;
}

// ==== CMsgServerDlg::helper_140026b60  @140026b60  [medium:callgraph-r1]  (orig: FUN_140026b60)
void FUN_140026b60(longlong param_1,longlong param_2,undefined8 param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != 0) {
      FUN_140023f70(param_1,param_3);
    }
    param_1 = param_1 + 0x30;
  }
  return;
}

// ==== CMsgServerDlg::helper_140026cc0  @140026cc0  [medium:callgraph-r3]  (orig: FUN_140026cc0)
longlong FUN_140026cc0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar2 = param_3 - param_2;
    do {
      param_2 = param_2 + -0x30;
      FUN_1400243e0(lVar2 + param_2,param_2);
    } while (param_2 != param_1);
  }
  return param_3 + (lVar1 / 0x30) * -0x30;
}

// ==== CMsgServerDlg::helper_140027110  @140027110  [medium:callgraph-r2]  (orig: FUN_140027110)
void FUN_140027110(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined1 local_res8;
  void *local_68 [3];
  void *local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    lVar7 = *(longlong *)(param_1 + 0x28) - lVar4;
    lVar7 = lVar7 / 6 + (lVar7 >> 0x3f);
    uVar5 = (lVar7 >> 3) - (lVar7 >> 0x3f);
  }
  uVar6 = 0;
  if (param_3 != 0) {
    lVar4 = (*(longlong *)(param_1 + 0x20) - lVar4) / 0x30;
    if (0x555555555555555U - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14001fa00();
    }
    uVar1 = lVar4 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar5 < uVar1) {
      if (uVar5 <= 0x555555555555555 - (uVar5 >> 1)) {
        uVar6 = uVar5 + (uVar5 >> 1);
      }
      if (uVar6 < uVar1) {
        uVar6 = uVar1;
      }
      lVar2 = FUN_140022520(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
      lVar4 = (lVar4 >> 3) - (lVar4 >> 0x3f);
      FUN_140026b60(lVar4 * 0x30 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar4,lVar2);
      FUN_1400247a0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1400247a0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x30 + lVar2,param_1 + 0x10,local_res8,0,2);
      lVar4 = *(longlong *)(param_1 + 0x18);
      lVar7 = *(longlong *)(param_1 + 0x20);
      if (lVar4 != 0) {
        FUN_140026bd0(lVar4,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x30 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar7 - lVar4) / 0x30) * 0x30 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_140023f70(local_68,param_4);
      FUN_1400247a0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      FUN_140026b60(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30,
                    local_68,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (lVar7 = *(longlong *)(param_2 + 8); lVar7 != lVar4 + param_3 * -0x30;
          lVar7 = lVar7 + 0x30) {
        FUN_1400243e0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
    else {
      FUN_140023f70(local_68,param_4);
      lVar4 = *(longlong *)(param_1 + 0x20);
      lVar7 = lVar4 + param_3 * -0x30;
      uVar3 = FUN_1400247a0(lVar7,lVar4,lVar4,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140026cc0(*(undefined8 *)(param_2 + 8),lVar7,lVar4,param_1 & 0xff,local_res8,0);
      lVar7 = *(longlong *)(param_2 + 8);
      lVar4 = lVar7 + param_3 * 0x30;
      for (; lVar7 != lVar4; lVar7 = lVar7 + 0x30) {
        FUN_1400243e0(lVar7,local_68);
      }
      if (local_50 != (void *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (void *)0x0;
      local_48 = 0;
      local_40 = 0;
      operator_delete(local_68[0]);
    }
  }
  return;
}

// ==== CMsgServerDlg::helper_140027a00  @140027a00  [medium:callgraph-r1]  (orig: FUN_140027a00)
longlong * FUN_140027a00(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar4 = param_1[3];
  lVar5 = param_1[4] - uVar4;
  lVar2 = 0;
  lVar1 = lVar5 >> 0x3f;
  lVar3 = lVar2;
  if (lVar5 / 0x30 + lVar1 != lVar1) {
    if ((ulonglong)param_1[4] < uVar4) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = (longlong)(param_3[1] - uVar4) / 6 + ((longlong)(param_3[1] - uVar4) >> 0x3f);
    lVar3 = (lVar1 >> 3) - (lVar1 >> 0x3f);
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140027110(param_1,&local_28,1,param_4);
  uVar4 = param_1[3];
  if ((ulonglong)param_1[4] < uVar4) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar4;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = lVar2;
  }
  else {
    lVar1 = *param_1;
  }
  uVar4 = lVar3 * 0x30 + uVar4;
  if (uVar4 <= *(ulonglong *)(lVar1 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar4) goto LAB_140027b26;
  }
  _invalid_parameter_noinfo();
LAB_140027b26:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar4;
  return param_2;
}

// ==== CMsgServerDlg::helper_140027b70  @140027b70  [medium:callgraph-r0]  (orig: FUN_140027b70)
void FUN_140027b70(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar4 = 0;
  }
  else {
    lVar3 = (longlong)(param_1[5] - uVar1) / 6 + ((longlong)(param_1[5] - uVar1) >> 0x3f);
    uVar4 = (lVar3 >> 3) - (lVar3 >> 0x3f);
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x30) < uVar4) {
    FUN_140026b60(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x30;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140027a00(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgServerDlg::vfunc_86  @140027dd0  [high:rtti-vtable]  (orig: FUN_140027dd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_140027dd0(CDialog *param_1)

{
  CDialog CVar1;
  HWND hWnd;
  bool bVar2;
  char cVar3;
  __time32_t _Var4;
  int iVar5;
  ulong uVar6;
  HMENU pHVar7;
  CMenu *pCVar8;
  char *pcVar9;
  HANDLE pvVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong *plVar13;
  int *piVar14;
  uint *puVar15;
  IStringManager *pIVar16;
  uint uVar17;
  CDialog *pCVar18;
  undefined4 *puVar19;
  CDialog *pCVar20;
  undefined1 auStack_8b8 [32];
  char *local_898;
  char *local_890;
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> local_888 [8];
  longlong *local_880;
  longlong *local_878 [3];
  void *local_860;
  undefined8 local_858;
  undefined8 local_850;
  longlong *local_848;
  undefined8 local_840;
  CIniFile local_838 [1024];
  CIniFile local_438 [1024];
  ulonglong local_38;
  
  local_840 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8b8;
  CDialog::OnInitDialog(param_1);
  pHVar7 = GetSystemMenu(*(HWND *)(param_1 + 0x40),0);
  pCVar8 = CMenu::FromHandle(pHVar7);
  if (pCVar8 != (CMenu *)0x0) {
    ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
    CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
              ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)&local_880);
    ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::LoadStringA
              ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)&local_880,0x65);
    bVar2 = ATL::CSimpleStringT<char,1>::IsEmpty((CSimpleStringT<char,1> *)&local_880);
    if (!bVar2) {
      AppendMenuA(*(HMENU *)(pCVar8 + 8),0x800,0,(LPCSTR)0x0);
      pcVar9 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                         ((CSimpleStringT<char,1> *)&local_880);
      AppendMenuA(*(HMENU *)(pCVar8 + 8),0,0x10,pcVar9);
    }
    ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
    ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
              ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)&local_880);
  }
  SendMessageA(*(HWND *)(param_1 + 0x40),0x80,1,*(LPARAM *)(param_1 + 0x200));
  SendMessageA(*(HWND *)(param_1 + 0x40),0x80,0,*(LPARAM *)(param_1 + 0x200));
  pvVar10 = CreateEventA((LPSECURITY_ATTRIBUTES)0x0,1,0,(LPCSTR)0x0);
  *(HANDLE *)(param_1 + 0x208) = pvVar10;
  if (pvVar10 == (HANDLE)0x0) {
    CWnd::MessageBoxA((CWnd *)param_1,"Create exit event failed!",(char *)0x0,0);
    CDialog::EndDialog(param_1,-1);
    return 0;
  }
  memset(&DAT_140975660,0,0x168);
  DAT_140975780 = 5000;
  DAT_140975784 = 3000;
  _Var4 = _time32((__time32_t *)0x0);
  tq::DateTime((char *)(param_1 + 0x120),(longlong)_Var4);
  cVar3 = FUN_14001f2f0(param_1);
  if (cVar3 == '\0') {
    CWnd::MessageBoxA((CWnd *)param_1,"Load config.ini failed!",(char *)0x0,0);
  }
  else {
    cVar3 = FUN_14050f8b0(DAT_1409757d0 + 0xe);
    if (cVar3 == '\0') {
      CWnd::MessageBoxA((CWnd *)param_1,"Initial intra message port failed!",(char *)0x0,0);
    }
    else {
      lVar11 = FUN_14002e300();
      if (lVar11 != 0) {
        uVar12 = FUN_14002e300();
        cVar3 = FUN_14002c6b0(uVar12);
        if (cVar3 != '\0') {
          plVar13 = (longlong *)FUN_14050c340(0);
          *(longlong **)(param_1 + 0x1f0) = plVar13;
          (**(code **)(*plVar13 + 0x38))(plVar13);
          (**(code **)(**(longlong **)(param_1 + 0x1f0) + 0x40))(*(longlong **)(param_1 + 0x1f0),1);
          *(undefined4 *)(param_1 + 0x1fc) = 1;
          goto LAB_140027fff;
        }
      }
      CWnd::MessageBoxA((CWnd *)param_1,"Initial CThreadRecordPtrMgr failed!",(char *)0x0,0);
    }
  }
LAB_140027fff:
  plVar13 = (longlong *)0x0;
  if (0 < DAT_1409757d0 + 0xe) {
    do {
      local_880 = operator_new(8);
      local_878[0] = (longlong *)0x0;
      if (local_880 != (longlong *)0x0) {
        *local_880 = (longlong)local_878;
        local_878[0] = local_880;
      }
      local_860 = (void *)0x0;
      local_858 = 0;
      local_850 = 0;
      local_848 = local_880;
      FUN_140027b70(g_setDeadLoop_exref,local_878);
      if (local_860 != (void *)0x0) {
        operator_delete(local_860);
      }
      local_860 = (void *)0x0;
      local_858 = 0;
      local_850 = 0;
      operator_delete(local_878[0]);
      uVar17 = (int)plVar13 + 1;
      plVar13 = (longlong *)(ulonglong)uVar17;
    } while ((int)uVar17 < DAT_1409757d0 + 0xe);
  }
  CIniFile::CIniFile(local_438,"shell.ini","AccountServer");
  CIniFile::GetString(local_438,(char *)(param_1 + 0x110),"SERVERNAME",0x10);
  _DAT_140975674 = *(undefined8 *)(param_1 + 0x110);
  _DAT_14097567c = *(undefined8 *)(param_1 + 0x118);
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_888);
  local_890 = "14:00:43";
  local_898 = "Dec  4 2015";
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::Format
            (local_888,"%s - %s - %s %s","Conquer Online Server",param_1 + 0x110);
  pcVar9 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                     ((CSimpleStringT<char,1> *)local_888);
  CWnd::SetWindowTextA((CWnd *)param_1,pcVar9);
  CreateDirectoryA("syslog",(LPSECURITY_ATTRIBUTES)0x0);
  CreateDirectoryA("gmlog",(LPSECURITY_ATTRIBUTES)0x0);
  _Var4 = _time32((__time32_t *)0x0);
  pcVar9 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                     ((CSimpleStringT<char,1> *)local_888);
  tq::InitLog(pcVar9,"syslog/cqserver","syslog/sysdb",(longlong)_Var4);
  log_InlineLogMessage("=================================================================");
  pcVar9 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                     ((CSimpleStringT<char,1> *)local_888);
  log_InlineLogMessage(pcVar9);
  log_InlineLogMessage("=================================================================");
  FUN_140020570();
  piVar14 = tq::CQLanguageGet();
  iVar5 = FUN_14001e220();
  *piVar14 = iVar5;
  puVar15 = (uint *)tq::CQLanguageGet();
  log_InlineLogMessage("CQLanguage = %u",(ulonglong)*puVar15);
  FUN_140021c80(param_1);
  pCVar18 = param_1 + 0x227c;
  *(undefined8 *)pCVar18 = 0;
  *(undefined8 *)(param_1 + 0x2284) = 0;
  pCVar20 = param_1 + 0x228c;
  *(undefined8 *)pCVar20 = 0;
  *(undefined8 *)(param_1 + 0x2294) = 0;
  *(undefined8 *)(param_1 + 0x229c) = 0;
  *(undefined8 *)(param_1 + 0x22a4) = 0;
  *(undefined8 *)(param_1 + 0x22b0) = 0;
  *(undefined4 *)(param_1 + 0x22b8) = 0;
  *(undefined4 *)(param_1 + 0x2278) = 0;
  _snprintf(s_CQServer_54_9_140949750,0x40,
            "f:\\version\\cqserver-78.0.11-1204\\msgserver\\msgserverdlg.cpp");
  DAT_14094978f = 0;
  CIniFile::CIniFile(local_838,"shell.ini","System");
  iVar5 = CIniFile::GetInt(local_838,"SERVE_PORT");
  *(int *)(param_1 + 0x22c4) = iVar5;
  if (iVar5 == 0) {
    *(undefined4 *)(param_1 + 0x22c4) = 0x16b8;
  }
  log_InlineLogMessage("%s[%d]",s_CQServer_54_9_140949750,(ulonglong)*(uint *)(param_1 + 0x22c4));
  puVar19 = &DAT_1406e0670;
  do {
    cVar3 = FUN_140508440(*puVar19);
    if (cVar3 != '\0') {
      tq::SafeCopy((char *)pCVar18,"192.168.9.138",0x10);
      tq::SafeCopy((char *)pCVar20,"192.168.9.138",0x10);
      *(undefined4 *)(param_1 + 0x22ac) = 0x268d;
      DAT_140949790 = '\x01';
      log_InlineLogMessage("This is a inner server.");
      goto LAB_1400283d2;
    }
    puVar19 = puVar19 + 1;
  } while ((longlong)puVar19 < 0x1406e0678);
  pIVar16 = theInstance();
  pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"Language");
  iVar5 = _stricmp(pcVar9,&DAT_1406e0658);
  if (iVar5 == 0) {
    tq::SafeCopy((char *)pCVar18,"121.207.253.12",0x10);
    tq::SafeCopy((char *)pCVar20,"58.49.94.9",0x10);
    *(undefined4 *)(param_1 + 0x22ac) = 0x268d;
  }
  else {
    tq::SafeCopy((char *)pCVar18,"216.93.176.117",0x10);
    tq::SafeCopy((char *)pCVar20,"92.52.79.12",0x10);
    *(undefined4 *)(param_1 + 0x22ac) = 0x268d;
  }
  DAT_140949790 = '\0';
LAB_1400283d2:
  FUN_140005b50();
  lVar11 = 0x229c - (longlong)pCVar18;
  do {
    CVar1 = *pCVar18;
    pCVar18[(longlong)(param_1 + lVar11)] = CVar1;
    pCVar18 = pCVar18 + 1;
  } while (CVar1 != (CDialog)0x0);
  local_890._0_4_ = 0x8000;
  local_898._0_4_ = 0x8000;
  cVar3 = FUN_140005ea0(param_1 + 0x240,param_1 + 0x229c,*(undefined4 *)(param_1 + 0x22ac));
  if (cVar3 == '\0') {
    FUN_140005d20(param_1 + 0x240);
    lVar11 = 0x229c - (longlong)pCVar20;
    do {
      CVar1 = *pCVar20;
      pCVar20[(longlong)(param_1 + lVar11)] = CVar1;
      pCVar20 = pCVar20 + 1;
    } while (CVar1 != (CDialog)0x0);
    local_890._0_4_ = 0x8000;
    local_898._0_4_ = 0x8000;
    cVar3 = FUN_140005ea0(param_1 + 0x240,param_1 + 0x229c,*(undefined4 *)(param_1 + 0x22ac));
    if (cVar3 == '\0') {
      FUN_140005d20(param_1 + 0x240);
    }
  }
  cVar3 = FUN_140005e80();
  if (cVar3 == '\0') {
    if (DAT_140949790 != '\0') {
      log_InlineLogERROR("connect authserver(%s) failed.",param_1 + 0x229c);
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x2278) = 1;
    FUN_14001e0b0(param_1 + 0x240,*(undefined4 *)(param_1 + 0x22c4));
    if (DAT_140949790 != '\0') {
      log_InlineLogMessage("connect authserver(%s) ok.",param_1 + 0x229c);
    }
  }
  *(undefined4 *)(param_1 + 0x22bc) = 600;
  uVar6 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x22c0) = uVar6 / 1000;
  SetTimer(*(HWND *)(param_1 + 0x40),2,100,(TIMERPROC)0x0);
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::Format
            (local_888,"%s - %s","Conquer Online Server",param_1 + 0x110);
  hWnd = *(HWND *)(param_1 + 0x40);
  pcVar9 = ATL::CSimpleStringT<char,1>::operator_char_const____ptr64
                     ((CSimpleStringT<char,1> *)local_888);
  SetPropA(hWnd,pcVar9,(HANDLE)0x1);
  FUN_14002a480(param_1);
  FUN_140002440(param_1);
  CIniFile::~CIniFile(local_838);
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>(local_888);
  CIniFile::~CIniFile(local_438);
  return 1;
}

// ==== CMsgServerDlg::vfunc_12  @1400286a0  [high:rtti-vtable]  (orig: FUN_1400286a0)
undefined ** FUN_1400286a0(void)

{
  return &PTR_LAB_1406e4038;
}

// ==== CMsgServerDlg::helper_140029ff0  @140029ff0  [medium:callgraph-r1]  (orig: FUN_140029ff0)
undefined8 * FUN_140029ff0(undefined8 *param_1,undefined8 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = param_2;
  plVar2 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  plVar1 = operator_new(8);
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 2);
    plVar2 = plVar1;
  }
  param_1[2] = plVar2;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  InitializeCriticalSection((LPCRITICAL_SECTION)(param_1 + 8));
  param_1[0xd] = 0;
  return param_1;
}

// ==== CMsgServerDlg::helper_14002a480  @14002a480  [medium:callgraph-r0]  (orig: FUN_14002a480)
undefined8 FUN_14002a480(undefined8 param_1)

{
  void *pvVar1;
  
  if (DAT_140975948 == 0) {
    pvVar1 = operator_new(0x70);
    if (pvVar1 == (void *)0x0) {
      DAT_140975948 = 0;
    }
    else {
      DAT_140975948 = FUN_140029ff0(pvVar1,param_1);
    }
    if (DAT_140975948 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
  }
  return 1;
}

// ==== CMsgServerDlg::helper_14002c6b0  @14002c6b0  [medium:callgraph-r0]  (orig: FUN_14002c6b0)
undefined4 FUN_14002c6b0(longlong param_1)

{
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,(CSyncObject *)(param_1 + 0x50),1);
  *(undefined4 *)(param_1 + 0xc) = 0;
  CSingleLock::Unlock(local_20);
  return 1;
}

// ==== CMsgServerDlg::helper_140508440  @140508440  [medium:callgraph-r0]  (orig: FUN_140508440)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_140508440(int param_1)

{
  char *_Str2;
  char cVar1;
  char cVar2;
  int iVar3;
  BOOL BVar4;
  char *pcVar5;
  HMODULE hModule;
  ulonglong extraout_RAX;
  ulonglong uVar6;
  INT_PTR IVar7;
  char *pcVar8;
  undefined4 extraout_var;
  undefined1 uVar9;
  undefined8 *puVar10;
  undefined1 auStack_2c68 [32];
  undefined4 local_2c48;
  undefined4 local_2c38 [4];
  undefined8 local_2c28 [1408];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_2c68;
  if (param_1 == 0) {
    return local_28 & 0xffffffffffffff00;
  }
  pcVar5 = (char *)Ordinal_12();
  hModule = LoadLibraryA("iphlpapi.dll");
  if (hModule == (HMODULE)0x0) {
    local_2c48 = 0xee;
    log_InlineLogERROR(&DAT_1406d9c10,"IF_OK","hModule",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\locklib\\serverlock.cpp");
    uVar6 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    _DAT_140976698 = GetProcAddress(hModule,"GetAdaptersInfo");
    local_2c38[0] = 0x2c00;
    IVar7 = (*_DAT_140976698)(local_2c28,local_2c38);
    if ((int)IVar7 != 0) {
      local_2c48 = 0xf9;
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","dwStatus == ERROR_SUCCESS",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\locklib\\serverlock.cpp");
    }
    puVar10 = local_2c28;
    uVar9 = 0;
    do {
      _Str2 = (char *)(puVar10 + 0x38);
      if (_Str2 != (char *)0x0) {
        iVar3 = strncmp("192.168.39",_Str2,10);
        if ((iVar3 != 0) && (iVar3 = strncmp("192.168.181",_Str2,0xb), iVar3 != 0)) {
          pcVar8 = pcVar5;
          do {
            cVar1 = *pcVar8;
            cVar2 = pcVar8[(longlong)_Str2 - (longlong)pcVar5];
            if (cVar1 != cVar2) break;
            pcVar8 = pcVar8 + 1;
          } while (cVar2 != '\0');
          if (cVar1 != cVar2) {
            puVar10 = (undefined8 *)*puVar10;
            goto LAB_1405085b9;
          }
        }
        uVar9 = 1;
        break;
      }
LAB_1405085b9:
    } while (puVar10 != (undefined8 *)0x0);
    BVar4 = FreeLibrary(hModule);
    uVar6 = CONCAT71((int7)(CONCAT44(extraout_var,BVar4) >> 8),uVar9);
  }
  return uVar6;
}

