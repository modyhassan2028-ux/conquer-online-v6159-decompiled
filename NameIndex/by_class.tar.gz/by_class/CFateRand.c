// ==== CFateRand::ctor_or_dtor  @140474030  [high:vtable-assign]  (orig: FUN_140474030)
void FUN_140474030(undefined8 *param_1)

{
  *param_1 = CFateRand::vftable;
  FUN_1403f70e0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CFateRand::ctor_or_dtor  @140474070  [high:vtable-assign]  (orig: FUN_140474070)
undefined8 * FUN_140474070(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CFateRand::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1403f7250(param_1 + 2);
  return param_1;
}

// ==== CFateRand::ctor_or_dtor  @1404740b0  [high:vtable-assign]  (orig: FUN_1404740b0)
undefined8 * FUN_1404740b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CFateRand::vftable;
  FUN_1403f70e0(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFateRand::ctor_or_dtor  @140474120  [high:vtable-assign]  (orig: FUN_140474120)
undefined8 * FUN_140474120(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CFateRand::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
    FUN_1403f7250(puVar1 + 2);
  }
  return puVar1;
}

