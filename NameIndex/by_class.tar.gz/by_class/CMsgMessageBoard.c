// ==== CMsgMessageBoard::helper_1400821d0  @1400821d0  [medium:callgraph-r3]  (orig: FUN_1400821d0)
longlong * FUN_1400821d0(longlong *param_1,longlong *param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  plVar1 = (longlong *)*param_1;
  lVar2 = param_1[1];
  lVar3 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar3;
  }
  else {
    lVar5 = *plVar1;
  }
  uVar4 = param_3 + lVar2;
  if (uVar4 <= (ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30))) {
    if (plVar1 != (longlong *)0x0) {
      lVar3 = *plVar1;
    }
    if (*(ulonglong *)(lVar3 + 0x30) <= uVar4) goto LAB_140082246;
  }
  _invalid_parameter_noinfo();
LAB_140082246:
  *param_2 = (longlong)plVar1;
  param_2[1] = uVar4;
  return param_2;
}

// ==== CMsgMessageBoard::helper_140082390  @140082390  [medium:callgraph-r1]  (orig: FUN_140082390)
undefined8 FUN_140082390(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  uVar3 = param_1[6];
  if (uVar3 + param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar2 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = lVar2;
  }
  else {
    lVar1 = *param_1;
  }
  uVar3 = uVar3 + param_2;
  if (uVar3 <= (ulonglong)(*(longlong *)(lVar1 + 0x38) + *(longlong *)(lVar1 + 0x30))) {
    lVar1 = lVar2;
    if (param_1 != (longlong *)0x0) {
      lVar1 = *param_1;
    }
    if (*(ulonglong *)(lVar1 + 0x30) <= uVar3) goto LAB_14008241d;
  }
  _invalid_parameter_noinfo();
LAB_14008241d:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = lVar2;
  }
  else {
    lVar1 = *param_1;
  }
  if ((ulonglong)(*(longlong *)(lVar1 + 0x38) + *(longlong *)(lVar1 + 0x30)) <= uVar3) {
    _invalid_parameter_noinfo();
  }
  lVar1 = lVar2;
  if (param_1 != (longlong *)0x0) {
    lVar1 = *param_1;
  }
  if (*(ulonglong *)(lVar1 + 0x28) <= uVar3) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    uVar3 = uVar3 - *(longlong *)(lVar2 + 0x28);
  }
  lVar2 = lRam0000000000000020;
  if (param_1 != (longlong *)0x0) {
    lVar2 = *(longlong *)(*param_1 + 0x20);
  }
  return *(undefined8 *)(lVar2 + uVar3 * 8);
}

// ==== CMsgMessageBoard::helper_140109d20  @140109d20  [medium:callgraph-r3]  (orig: FUN_140109d20)
longlong * FUN_140109d20(longlong *param_1,longlong *param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  plVar1 = (longlong *)*param_1;
  lVar2 = param_1[1];
  lVar3 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar3;
  }
  else {
    lVar5 = *plVar1;
  }
  uVar4 = lVar2 - param_3;
  if (uVar4 <= (ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30))) {
    if (plVar1 != (longlong *)0x0) {
      lVar3 = *plVar1;
    }
    if (*(ulonglong *)(lVar3 + 0x30) <= uVar4) goto LAB_140109d99;
  }
  _invalid_parameter_noinfo();
LAB_140109d99:
  *param_2 = (longlong)plVar1;
  param_2[1] = uVar4;
  return param_2;
}

// ==== CMsgMessageBoard::helper_14010a200  @14010a200  [medium:callgraph-r0]  (orig: FUN_14010a200)
undefined8 FUN_14010a200(longlong param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  char *pcVar3;
  undefined8 uVar4;
  longlong lVar5;
  int iVar6;
  
  if (param_2 != (char *)0x0) {
    lVar5 = -1;
    pcVar3 = param_2;
    do {
      if (lVar5 == 0) break;
      lVar5 = lVar5 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    if (lVar5 != -2) {
      iVar6 = 0;
      if (0 < *(int *)(param_1 + 0x40)) {
        do {
          lVar5 = FUN_140082390(param_1 + 8,(longlong)iVar6);
          pcVar3 = (char *)(lVar5 + 4);
          lVar5 = (longlong)param_2 - (longlong)pcVar3;
          do {
            cVar1 = *pcVar3;
            cVar2 = pcVar3[lVar5];
            if (cVar1 != cVar2) break;
            pcVar3 = pcVar3 + 1;
          } while (cVar2 != '\0');
          if (cVar1 == cVar2) {
            uVar4 = FUN_140082390(param_1 + 8,(longlong)iVar6);
            return uVar4;
          }
          iVar6 = iVar6 + 1;
        } while (iVar6 < *(int *)(param_1 + 0x40));
      }
      return 0;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgMessageBoard::helper_14010a540  @14010a540  [medium:callgraph-r2]  (orig: FUN_14010a540)
undefined8 FUN_14010a540(undefined8 param_1,longlong param_2,longlong *param_3,longlong *param_4)

{
  longlong *plVar1;
  ulonglong uVar2;
  void *_Src;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  FUN_140109d20(param_4,param_1,param_3[1] - *(longlong *)(param_2 + 8));
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = *(longlong **)*param_4;
  }
  plVar3 = (longlong *)*plVar3;
  uVar7 = param_4[1];
  plVar1 = (longlong *)*param_3;
  uVar6 = param_3[1];
  uVar2 = *(ulonglong *)(param_2 + 8);
  while (uVar2 != uVar6) {
    uVar6 = uVar6 - 1;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar6) {
      _invalid_parameter_noinfo();
    }
    if (plVar1 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    uVar5 = uVar6;
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar6) {
      if (plVar1 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar1;
      }
      uVar5 = uVar6 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar1 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    uVar7 = uVar7 - 1;
    _Src = *(void **)(*(longlong *)(lVar4 + 0x20) + uVar5 * 8);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar7) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    uVar5 = uVar7;
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar7) {
      if (plVar3 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar3;
      }
      uVar5 = uVar7 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar3 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    memcpy(*(void **)(*(longlong *)(lVar4 + 0x20) + uVar5 * 8),_Src,0x118);
  }
  return param_1;
}

// ==== CMsgMessageBoard::helper_14010a710  @14010a710  [medium:callgraph-r2]  (orig: FUN_14010a710)
undefined8 FUN_14010a710(undefined8 param_1,longlong *param_2,longlong param_3,longlong *param_4)

{
  ulonglong uVar1;
  longlong *plVar2;
  void *_Src;
  longlong *plVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  FUN_1400821d0(param_4,param_1,*(longlong *)(param_3 + 8) - param_2[1]);
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = *(longlong **)*param_4;
  }
  plVar3 = (longlong *)*plVar3;
  uVar7 = param_4[1];
  uVar1 = *(ulonglong *)(param_3 + 8);
  plVar2 = (longlong *)*param_2;
  for (uVar6 = param_2[1]; uVar6 != uVar1; uVar6 = uVar6 + 1) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar6) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    uVar5 = uVar6;
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar6) {
      if (plVar2 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar2;
      }
      uVar5 = uVar6 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    _Src = *(void **)(*(longlong *)(lVar4 + 0x20) + uVar5 * 8);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    if ((ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30)) <= uVar7) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    uVar5 = uVar7;
    if (*(ulonglong *)(lVar4 + 0x28) <= uVar7) {
      if (plVar3 == (longlong *)0x0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar3;
      }
      uVar5 = uVar7 - *(longlong *)(lVar4 + 0x28);
    }
    if (plVar3 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar3;
    }
    memcpy(*(void **)(*(longlong *)(lVar4 + 0x20) + uVar5 * 8),_Src,0x118);
    uVar7 = uVar7 + 1;
  }
  return param_1;
}

// ==== CMsgMessageBoard::helper_14010abf0  @14010abf0  [medium:callgraph-r1]  (orig: FUN_14010abf0)
longlong *
FUN_14010abf0(longlong *param_1,longlong *param_2,undefined8 *param_3,undefined8 *param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  ulonglong uVar8;
  undefined1 local_res10;
  longlong *local_68;
  ulonglong uStack_60;
  longlong *local_58;
  ulonglong uStack_50;
  longlong *local_48;
  ulonglong uStack_40;
  undefined1 local_38 [16];
  
  local_58 = (longlong *)*param_3;
  uVar2 = param_3[1];
  if (((param_1 == (longlong *)0x0) || (uVar2 < (ulonglong)param_1[6])) ||
     ((ulonglong)(param_1[6] + param_1[7]) < uVar2)) {
    uStack_50 = uVar2;
    _invalid_parameter_noinfo();
  }
  local_68 = (longlong *)*param_4;
  plVar5 = (longlong *)*param_1;
  uVar8 = param_4[1];
  local_58 = plVar5;
  if ((uVar8 < (ulonglong)param_1[6]) ||
     (uStack_50 = uVar2, (ulonglong)(param_1[6] + param_1[7]) < uVar8)) {
    uStack_60 = uVar8;
    uStack_50 = uVar2;
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[6];
  plVar4 = (longlong *)*param_1;
  local_68 = plVar4;
  uStack_60 = uVar8;
  if (uVar3 + param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  if ((plVar5 == (longlong *)0x0) || (plVar5 != (longlong *)*param_1)) {
    _invalid_parameter_noinfo();
  }
  if ((plVar4 == (longlong *)0x0) || (plVar4 != plVar5)) {
    _invalid_parameter_noinfo();
  }
  uVar1 = param_1[6] + param_1[7];
  lVar7 = uVar8 - uVar2;
  if (uVar1 < (ulonglong)param_1[6]) {
    _invalid_parameter_noinfo();
  }
  if (((longlong *)*param_1 == (longlong *)0x0) || ((longlong *)*param_1 != plVar4)) {
    _invalid_parameter_noinfo();
  }
  local_res10 = SUB81(param_2,0);
  if (uVar2 - uVar3 < uVar1 - uVar8) {
    uVar8 = param_1[6];
    if (uVar8 + param_1[7] < uVar8) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)0x0;
    local_58 = local_68;
    uStack_50 = uStack_60;
    local_48 = plVar4;
    if (plVar5 != (longlong *)0x0) {
      local_48 = (longlong *)*plVar5;
    }
    local_48 = (longlong *)*local_48;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      plVar4 = *(longlong **)*param_1;
    }
    local_68 = (longlong *)*plVar4;
    uStack_60 = uVar8;
    uStack_40 = uVar2;
    FUN_14010a540(local_38,&local_68,&local_48,&local_58,local_res10,local_res10,0);
    if (lVar7 != 0) {
      lVar6 = param_1[7];
      do {
        if (lVar6 != 0) {
          param_1[6] = param_1[6] + 1;
          if ((ulonglong)param_1[5] <= (ulonglong)param_1[6]) {
            param_1[6] = 0;
          }
          lVar6 = lVar6 + -1;
          if (lVar6 == 0) {
            param_1[6] = 0;
          }
        }
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
      param_1[7] = lVar6;
    }
  }
  else {
    uVar1 = param_1[6] + param_1[7];
    if (uVar1 < (ulonglong)param_1[6]) {
      _invalid_parameter_noinfo();
    }
    plVar5 = (longlong *)0x0;
    local_48 = local_58;
    uStack_40 = uStack_50;
    local_68 = plVar5;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      local_68 = *(longlong **)*param_1;
    }
    local_68 = (longlong *)*local_68;
    if (plVar4 != (longlong *)0x0) {
      plVar5 = (longlong *)*plVar4;
    }
    local_58 = (longlong *)*plVar5;
    uStack_60 = uVar1;
    uStack_50 = uVar8;
    FUN_14010a710(local_38,&local_58,&local_68,&local_48,local_res10,local_res10,0);
    if (lVar7 != 0) {
      lVar6 = param_1[7];
      do {
        if ((lVar6 != 0) && (lVar6 = lVar6 + -1, lVar6 == 0)) {
          param_1[6] = 0;
        }
        lVar7 = lVar7 + -1;
      } while (lVar7 != 0);
      param_1[7] = lVar6;
    }
  }
  lVar7 = 0;
  uVar8 = param_1[6];
  if (uVar8 + param_1[7] < uVar8) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_58 = param_1;
  uStack_50 = uVar8;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = lVar7;
  }
  else {
    lVar6 = *param_1;
  }
  uVar8 = uVar8 + (uVar2 - uVar3);
  if (uVar8 <= (ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30))) {
    if (param_1 != (longlong *)0x0) {
      lVar7 = *param_1;
    }
    if (*(ulonglong *)(lVar7 + 0x30) <= uVar8) goto LAB_14010af2a;
  }
  _invalid_parameter_noinfo();
LAB_14010af2a:
  *param_2 = (longlong)local_58;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMsgMessageBoard::helper_14010b050  @14010b050  [medium:callgraph-r0]  (orig: FUN_14010b050)
undefined8 FUN_14010b050(longlong param_1,int param_2)

{
  longlong *plVar1;
  ulonglong *puVar2;
  int *piVar3;
  ulonglong uVar4;
  int iVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong *local_48;
  ulonglong uStack_40;
  ulonglong *local_38;
  ulonglong uStack_30;
  undefined1 local_28 [32];
  
  uVar8 = 0;
  if (0 < *(int *)(param_1 + 0x40)) {
    plVar1 = (longlong *)(param_1 + 8);
    uVar6 = uVar8;
    do {
      iVar5 = (int)uVar6;
      piVar3 = (int *)FUN_140082390(plVar1,(longlong)iVar5);
      if (*piVar3 == param_2) {
        uVar6 = *(ulonglong *)(param_1 + 0x38);
        if (*(longlong *)(param_1 + 0x40) + uVar6 < uVar6) {
          _invalid_parameter_noinfo();
        }
        puVar2 = (ulonglong *)*plVar1;
        local_48 = puVar2;
        uStack_40 = uVar6;
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar4 = uVar8;
        }
        else {
          uVar4 = *puVar2;
        }
        uVar6 = uVar6 + (longlong)iVar5;
        if ((ulonglong)(*(longlong *)(uVar4 + 0x38) + *(longlong *)(uVar4 + 0x30)) < uVar6) {
LAB_14010b128:
          _invalid_parameter_noinfo();
        }
        else {
          uVar4 = uVar8;
          if (puVar2 != (ulonglong *)0x0) {
            uVar4 = *puVar2;
          }
          if (uVar6 < *(ulonglong *)(uVar4 + 0x30)) goto LAB_14010b128;
        }
        puVar2 = local_48;
        local_38 = local_48;
        uStack_40 = uVar6;
        uStack_30 = uVar6;
        if (local_48 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar4 = uVar8;
        }
        else {
          uVar4 = *local_48;
        }
        uVar7 = uVar6 + 1;
        if (uVar7 <= (ulonglong)(*(longlong *)(uVar4 + 0x38) + *(longlong *)(uVar4 + 0x30))) {
          if (puVar2 != (ulonglong *)0x0) {
            uVar8 = *puVar2;
          }
          if (*(ulonglong *)(uVar8 + 0x30) <= uVar7) goto LAB_14010b180;
        }
        _invalid_parameter_noinfo();
LAB_14010b180:
        local_48 = puVar2;
        uStack_40 = uVar6;
        uStack_30 = uVar7;
        FUN_14010abf0(plVar1,local_28,&local_48,&local_38);
        return 1;
      }
      uVar6 = (ulonglong)(iVar5 + 1U);
    } while ((int)(iVar5 + 1U) < *(int *)(param_1 + 0x40));
  }
  return 0;
}

// ==== CMsgMessageBoard::helper_14010b1c0  @14010b1c0  [medium:callgraph-r0]  (orig: FUN_14010b1c0)
undefined8 FUN_14010b1c0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  char cVar2;
  char cVar3;
  ulonglong *puVar4;
  longlong lVar5;
  char *pcVar6;
  ulonglong uVar7;
  int iVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  ulonglong *local_48;
  ulonglong uStack_40;
  ulonglong *local_38;
  ulonglong uStack_30;
  undefined1 local_28 [32];
  
  if (param_2 == 0) {
    return 0;
  }
  uVar9 = 0;
  if (0 < *(int *)(param_1 + 0x40)) {
    plVar1 = (longlong *)(param_1 + 8);
    uVar10 = uVar9;
    do {
      iVar8 = (int)uVar10;
      lVar5 = FUN_140082390(plVar1,(longlong)iVar8);
      pcVar6 = (char *)(lVar5 + 4);
      lVar5 = param_2 - (longlong)pcVar6;
      do {
        cVar2 = *pcVar6;
        cVar3 = pcVar6[lVar5];
        if (cVar2 != cVar3) break;
        pcVar6 = pcVar6 + 1;
      } while (cVar3 != '\0');
      if (cVar2 == cVar3) {
        uVar10 = *(ulonglong *)(param_1 + 0x38);
        if (uVar10 + *(longlong *)(param_1 + 0x40) < uVar10) {
          _invalid_parameter_noinfo();
        }
        puVar4 = (ulonglong *)*plVar1;
        local_48 = puVar4;
        uStack_40 = uVar10;
        if (puVar4 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar7 = uVar9;
        }
        else {
          uVar7 = *puVar4;
        }
        uVar10 = uVar10 + (longlong)iVar8;
        if ((ulonglong)(*(longlong *)(uVar7 + 0x38) + *(longlong *)(uVar7 + 0x30)) < uVar10) {
LAB_14010b2d6:
          _invalid_parameter_noinfo();
        }
        else {
          uVar7 = uVar9;
          if (puVar4 != (ulonglong *)0x0) {
            uVar7 = *puVar4;
          }
          if (uVar10 < *(ulonglong *)(uVar7 + 0x30)) goto LAB_14010b2d6;
        }
        puVar4 = local_48;
        local_38 = local_48;
        uStack_40 = uVar10;
        uStack_30 = uVar10;
        if (local_48 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar7 = uVar9;
        }
        else {
          uVar7 = *local_48;
        }
        uVar11 = uVar10 + 1;
        if (uVar11 <= (ulonglong)(*(longlong *)(uVar7 + 0x38) + *(longlong *)(uVar7 + 0x30))) {
          if (puVar4 != (ulonglong *)0x0) {
            uVar9 = *puVar4;
          }
          if (*(ulonglong *)(uVar9 + 0x30) <= uVar11) goto LAB_14010b32e;
        }
        _invalid_parameter_noinfo();
LAB_14010b32e:
        local_48 = puVar4;
        uStack_40 = uVar10;
        uStack_30 = uVar11;
        FUN_14010abf0(plVar1,local_28,&local_48,&local_38);
        return 1;
      }
      uVar10 = (ulonglong)(iVar8 + 1U);
    } while ((int)(iVar8 + 1U) < *(int *)(param_1 + 0x40));
  }
  return 0;
}

// ==== CMsgMessageBoard::helper_1401180b0  @1401180b0  [medium:callgraph-r0]  (orig: FUN_1401180b0)
longlong FUN_1401180b0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x260);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgMessageBoard::ctor_or_dtor  @140458b20  [high:vtable-assign]  (orig: FUN_140458b20)
undefined8 * FUN_140458b20(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMessageBoard::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x19),0x3f5,true);
  return param_1;
}

// ==== CMsgMessageBoard::ctor_or_dtor  @140458ba0  [high:vtable-assign]  (orig: FUN_140458ba0)
void FUN_140458ba0(undefined8 *param_1)

{
  *param_1 = CMsgMessageBoard::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgMessageBoard::vfunc_1  @140458be0  [high:rtti-vtable]  (orig: FUN_140458be0)
undefined8 FUN_140458be0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgMessageBoard::ctor_or_dtor  @140458c10  [high:vtable-assign]  (orig: FUN_140458c10)
undefined8 * FUN_140458c10(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMessageBoard::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMessageBoard::helper_140458c70  @140458c70  [medium:callgraph-r0]  (orig: FUN_140458c70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

byte FUN_140458c70(longlong param_1,undefined1 param_2,undefined2 param_3,undefined2 param_4,
                  longlong param_5)

{
  ushort uVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  ulong uVar5;
  longlong lVar6;
  char *pcVar7;
  uint uVar8;
  longlong lVar9;
  byte bVar10;
  undefined1 auStack_98 [32];
  char local_78 [16];
  char local_68 [48];
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  FUN_1402b5600();
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 8) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6) = param_3;
  bVar10 = 1;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  if (param_5 != 0) {
    uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 4);
    uVar8 = (uint)uVar1;
    if ((uint)uVar1 < uVar1 + 8) {
      do {
        if (((int)uVar8 < 0) || (*(int *)(param_5 + 0x40) <= (int)uVar8)) break;
        lVar9 = (longlong)(int)uVar8;
        lVar6 = FUN_140082390(param_5 + 8,lVar9);
        bVar2 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),(char *)(lVar6 + 4))
        ;
        if ((int)uVar8 < *(int *)(param_5 + 0x40)) {
          lVar6 = FUN_140082390(param_5 + 8,lVar9);
          pcVar7 = (char *)(lVar6 + 0x14);
        }
        else {
          pcVar7 = (char *)0x0;
        }
        tq::SafeCopy(local_68,pcVar7,0x2c);
        bVar3 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_68);
        if ((int)uVar8 < *(int *)(param_5 + 0x40)) {
          lVar6 = FUN_140082390(param_5 + 8,lVar9);
          tq::DateTimeStamp(local_78,(longlong)*(int *)(lVar6 + 0x114));
        }
        else {
          local_78[0] = '\0';
        }
        bVar4 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),local_78);
        uVar8 = uVar8 + 1;
        bVar10 = bVar10 & bVar2 & bVar3 & bVar4;
      } while ((int)uVar8 < (int)(*(ushort *)(*(longlong *)(param_1 + 0x428) + 4) + 8));
    }
  }
  uVar5 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar5;
  *(undefined4 *)(param_1 + 8) = 0x457;
  uVar8 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar8 + 0xb;
  return bVar10;
}

// ==== CMsgMessageBoard::ctor_or_dtor  @140458e30  [high:vtable-assign]  (orig: FUN_140458e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140458e30(longlong *param_1)

{
  undefined4 *puVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong lVar9;
  char *pcVar10;
  undefined1 auStack_508 [32];
  char *local_4e8;
  undefined4 local_4e0;
  undefined2 local_4d8;
  undefined2 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined1 local_4b8;
  undefined8 local_4a8;
  undefined **local_498 [134];
  CStringPacker local_68 [32];
  char local_48 [32];
  ulonglong local_28;
  
  local_4a8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  lVar5 = FUN_140008520((int)param_1[0x82]);
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    local_4e8 = (char *)CONCAT44(local_4e8._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar9 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar1 = (undefined4 *)param_1[0x85];
    uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar3,(int)lVar9,*puVar1);
    local_48[0] = '\0';
    local_48[1] = '\0';
    local_48[2] = '\0';
    local_48[3] = '\0';
    local_48[4] = '\0';
    local_48[5] = '\0';
    local_48[6] = '\0';
    local_48[7] = '\0';
    local_48[8] = '\0';
    local_48[9] = '\0';
    local_48[10] = '\0';
    local_48[0xb] = '\0';
    local_48[0xc] = '\0';
    local_48[0xd] = '\0';
    local_48[0xe] = '\0';
    local_48[0xf] = 0;
    tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x86),0,local_48,0x10);
    switch(*(undefined2 *)(param_1[0x85] + 6)) {
    case 0x899:
      uVar8 = FUN_140008520((int)param_1[0x82]);
      lVar5 = FUN_14015b100(uVar8);
      break;
    case 0x89a:
      uVar8 = FUN_140008520((int)param_1[0x82]);
      lVar5 = FUN_14015b150(uVar8);
      break;
    case 0x89b:
      uVar8 = FUN_140008520((int)param_1[0x82]);
      lVar5 = FUN_14015b1a0(uVar8);
      break;
    case 0x89c:
      plVar7 = (longlong *)FUN_140087ed0();
      lVar5 = *plVar7;
      uVar3 = (**(code **)(plVar6[2] + 0x170))();
      lVar5 = (**(code **)(lVar5 + 0x48))(plVar7,uVar3);
      break;
    case 0x89d:
      uVar8 = FUN_140008520((int)param_1[0x82]);
      lVar5 = FUN_14015b1f0(uVar8);
      break;
    case 0x89e:
      uVar8 = FUN_140008520((int)param_1[0x82]);
      lVar5 = FUN_1401180b0(uVar8);
      break;
    default:
      goto switchD_140458f70_default;
    }
    if (lVar5 != 0) {
      cVar2 = *(char *)(param_1[0x85] + 8);
      if (cVar2 == '\x01') {
        cVar2 = (**(code **)(plVar6[2] + 0x230))();
        if (cVar2 == '\0') {
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          FUN_14010b050(lVar5,uVar3);
        }
        else {
          lVar9 = -1;
          pcVar10 = local_48;
          do {
            if (lVar9 == 0) break;
            lVar9 = lVar9 + -1;
            cVar2 = *pcVar10;
            pcVar10 = pcVar10 + 1;
          } while (cVar2 != '\0');
          if (lVar9 != -2) {
            FUN_14010b1c0(lVar5,local_48);
          }
        }
      }
      else if (cVar2 == '\x02') {
        if ((int)(uint)*(ushort *)(param_1[0x85] + 4) < *(int *)(lVar5 + 0x40)) {
          FUN_140458b20(local_498);
          local_4e8 = (char *)lVar5;
          iVar4 = FUN_140458c70(local_498,3,*(undefined2 *)(param_1[0x85] + 6),
                                *(undefined2 *)(param_1[0x85] + 4));
          if (iVar4 == 0) {
            local_4e8 = (char *)CONCAT44(local_4e8._4_4_,0x9c);
            log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                               "msg.Create(MESSAGEBOARD_LIST, m_pInfo->usChannel, m_pInfo->usIndex, pObj)"
                               ,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgmessageboard.cpp"
                              );
          }
          else {
            (**(code **)(*param_1 + 0x20))(param_1,local_498);
          }
          local_498[0] = CMsgMessageBoard::vftable;
          tq::CStringPacker::~CStringPacker(local_68);
          FUN_1402b55f0(local_498);
        }
      }
      else if (cVar2 == '\x04') {
        lVar9 = -1;
        pcVar10 = local_48;
        do {
          if (lVar9 == 0) break;
          lVar9 = lVar9 + -1;
          cVar2 = *pcVar10;
          pcVar10 = pcVar10 + 1;
        } while (cVar2 != '\0');
        if (lVar9 == -2) {
          local_4e8 = (char *)CONCAT44(local_4e8._4_4_,0xa5);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECK","strlen(szSender) > 0",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgmessageboard.cpp"
                            );
        }
        else {
          lVar5 = FUN_14010a200(lVar5,local_48);
          if (lVar5 != 0) {
            tq::DateTimeStamp(local_48 + 0x10,(longlong)*(int *)(lVar5 + 0x114));
            FUN_14015b240(local_498);
            local_4b8 = 1;
            local_4c0 = 0;
            local_4c8 = 0;
            local_4d0 = 0;
            local_4d8 = *(undefined2 *)(param_1[0x85] + 6);
            local_4e0 = 0xffffff;
            local_4e8 = local_48 + 0x10;
            iVar4 = FUN_14015b300(local_498,lVar5 + 4,"ALLUSERS",lVar5 + 0x14);
            if (iVar4 == 0) {
              local_4e8 = (char *)CONCAT44(local_4e8._4_4_,0xb0);
              log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                                 "msg.Create((char*)pInfo->name, ALLUSERS_NAME, (char*)pInfo->words, buf, 0xFFFFFF, m_pInfo->usChannel)"
                                 ,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgmessageboard.cpp"
                                );
            }
            else {
              (**(code **)(*param_1 + 0x20))(param_1,local_498);
            }
            FUN_14015b2c0(local_498);
          }
        }
      }
    }
  }
switchD_140458f70_default:
  return;
}

