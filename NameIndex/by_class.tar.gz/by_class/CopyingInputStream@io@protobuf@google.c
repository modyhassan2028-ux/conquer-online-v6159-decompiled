// ==== CopyingInputStream@io@protobuf@google::helper_14055c440  @14055c440  [medium:callgraph-r0]  (orig: FUN_14055c440)
void FUN_14055c440(undefined8 *param_1)

{
  *param_1 = google::protobuf::io::CopyingInputStream::vftable;
  return;
}

// ==== CopyingInputStream@io@protobuf@google::vfunc_2  @14055c460  [high:rtti-vtable]  (orig: FUN_14055c460)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_14055c460(longlong *param_1,int param_2)

{
  undefined4 *puVar1;
  undefined1 auStack_1058 [32];
  int local_1038;
  undefined1 local_1028 [4096];
  int local_28;
  undefined4 local_24;
  undefined8 local_20;
  int local_18 [2];
  ulonglong local_10;
  undefined8 uStack_8;
  
  uStack_8 = 0x14055c473;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_1058;
  local_1038 = 0;
  while( true ) {
    if (param_2 <= local_1038) {
      return local_1038;
    }
    local_20 = 0x1000;
    local_24 = FUN_14055d7a0(&local_20);
    local_18[0] = param_2 - local_1038;
    puVar1 = (undefined4 *)FUN_14055b600(local_18,&local_24);
    local_28 = (**(code **)(*param_1 + 8))(param_1,local_1028,*puVar1);
    if (local_28 < 1) break;
    local_1038 = local_1038 + local_28;
  }
  return local_1038;
}

// ==== CopyingInputStream@io@protobuf@google::vfunc_0  @14055d5b0  [high:rtti-vtable]  (orig: FUN_14055d5b0)
void * FUN_14055d5b0(void *param_1,uint param_2)

{
  FUN_14055c440(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CopyingInputStream@io@protobuf@google::helper_14055d7a0  @14055d7a0  [medium:callgraph-r0]  (orig: FUN_14055d7a0)
undefined4 FUN_14055d7a0(undefined4 *param_1)

{
  return *param_1;
}

