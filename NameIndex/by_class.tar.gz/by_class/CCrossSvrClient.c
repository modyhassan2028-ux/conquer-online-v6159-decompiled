// ==== CCrossSvrClient::helper_1404f7290  @1404f7290  [medium:callgraph-r0]  (orig: FUN_1404f7290)
longlong FUN_1404f7290(longlong param_1,int param_2)

{
  return param_1 + 0x18 + (longlong)param_2 * 0x10;
}

// ==== CCrossSvrClient::helper_1404f8200  @1404f8200  [medium:callgraph-r0]  (orig: FUN_1404f8200)
void FUN_1404f8200(undefined8 param_1,undefined4 *param_2)

{
  longlong lVar1;
  undefined4 local_18 [2];
  longlong local_10;
  
  lVar1 = *(longlong *)(param_2 + 2);
  local_10 = FUN_140544610();
  if (local_10 == -1) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  local_18[0] = *param_2;
  (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x50))
            (*(longlong **)(lVar1 + 0x88),1,0x756d,0x10,local_18);
  return;
}

// ==== CCrossSvrClient::helper_1404f8290  @1404f8290  [medium:callgraph-r0]  (orig: FUN_1404f8290)
void FUN_1404f8290(undefined8 param_1,byte param_2,undefined4 *param_3)

{
  longlong lVar1;
  longlong *plVar2;
  int iVar3;
  undefined4 local_18 [2];
  longlong local_10;
  
  lVar1 = *(longlong *)(param_3 + 2);
  local_10 = FUN_140544610();
  if (-1 < local_10) {
    if ((char)param_2 < '\0') {
      iVar3 = FUN_1405455c0(param_1,6);
      if (iVar3 < 0) {
        Ordinal_111();
        log_InlineLogERROR("CClientSocket::Open, m_nType[%d] client bufferevent_enable error[%d].");
      }
      plVar2 = *(longlong **)(lVar1 + 0x88);
      (**(code **)(*plVar2 + 0x50))(plVar2,1,0x756f,4,param_3);
    }
    else if ((param_2 & 0x30) == 0) {
      log_InlineLogERROR("CSocketKernel::BufferEventCb, m_nType[%d] events[%0x] error.");
    }
    else {
      local_18[0] = *param_3;
      plVar2 = *(longlong **)(lVar1 + 0x88);
      (**(code **)(*plVar2 + 0x50))(plVar2,1,0x756e,0x10,local_18);
    }
  }
  return;
}

// ==== CCrossSvrClient::ctor_or_dtor  @140502b40  [high:vtable-assign]  (orig: FUN_140502b40)
undefined8 * FUN_140502b40(undefined8 *param_1)

{
  FUN_140506e80();
  *param_1 = CCrossSvrClient::vftable;
  return param_1;
}

// ==== CCrossSvrClient::ctor_or_dtor  @140502b70  [high:vtable-assign]  (orig: FUN_140502b70)
void FUN_140502b70(undefined8 *param_1)

{
  *param_1 = CCrossSvrClient::vftable;
  FUN_1405061c0();
  return;
}

// ==== CCrossSvrClient::vfunc_1  @140502ba0  [high:rtti-vtable]  (orig: FUN_140502ba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140502ba0(longlong *param_1,longlong param_2,int param_3)

{
  char cVar1;
  uint uVar2;
  undefined8 uVar3;
  undefined1 auStack_458 [32];
  undefined8 local_438;
  CIniFile local_428 [1024];
  undefined8 local_28;
  undefined2 local_20;
  undefined4 local_1e;
  undefined2 local_1a;
  ulonglong local_18;
  
  local_438 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if ((param_2 == 0) || (param_3 != 6)) {
    uVar3 = 0;
  }
  else {
    param_1[0x208] = param_2;
    *(undefined4 *)(param_1 + 0x207) = 6;
    (**(code **)(*param_1 + 0x28))(param_1,0);
    CIniFile::CIniFile(local_428,"shell.ini","CrossClient");
    local_28 = DAT_1406e8af0;
    local_20 = DAT_1406e8af8;
    local_1e = 0;
    local_1a = 0;
    CIniFile::GetString(local_428,(char *)&local_28,"CrossServerIP",0x10);
    uVar2 = CIniFile::GetInt(local_428,"CrossServerPort");
    if (uVar2 == 0) {
      log_InlineLogERROR(&DAT_14079a668,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\crosssvrclient.cpp",
                         0x2a);
      CIniFile::~CIniFile(local_428);
      uVar3 = 0;
    }
    else {
      cVar1 = (**(code **)(*param_1 + 0x40))(param_1,&local_28,uVar2);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CClientSocket::Create, CrossServer client socket Open error.");
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
      else {
        log_InlineLogMessage("intermediary server %s:%u",&local_28,(ulonglong)uVar2);
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CCrossSvrClient::vfunc_2  @140502d20  [high:rtti-vtable]  (orig: FUN_140502d20)
void FUN_140502d20(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CCrossSvrClient::vfunc_3  @140502d40  [high:rtti-vtable]  (orig: FUN_140502d40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140502d40(longlong *param_1)

{
  ushort uVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined1 local_434 [1052];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_1[0x208] == 0) {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x3f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (int)param_1[0x105];
    if (0 < iVar3) {
      while ((((0x10 < iVar3 &&
               (uVar1 = *(ushort *)((longlong)param_1 + 0x34), (int)(uint)uVar1 <= iVar3)) &&
              (0xf < uVar1)) && (uVar1 < 0x419))) {
        uVar1 = *(ushort *)((longlong)param_1 + 0x34);
        if (uVar1 == 0) {
          return;
        }
        memset((void *)((longlong)&local_438 + 1),0,0x417);
        local_438 = (uint)uVar1;
        memcpy(local_434,param_1 + 5,(ulonglong)uVar1);
        plVar4 = (longlong *)FUN_1404f7270(param_1[0x208]);
        local_448 = &local_438;
        (**(code **)(*plVar4 + 0x50))(plVar4,6,0x11174,0x418);
        cVar2 = (**(code **)(*param_1 + 0x58))(param_1,(uint)uVar1,0);
        if (cVar2 == '\0') {
          return;
        }
        iVar3 = (int)param_1[0x105];
        if (iVar3 < 1) {
          return;
        }
      }
    }
  }
  return;
}

// ==== CCrossSvrClient::ctor_or_dtor  @140502ea0  [high:vtable-assign]  (orig: FUN_140502ea0)
undefined8 * FUN_140502ea0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossSvrClient::vftable;
  FUN_1405061c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossSvrClient::vfunc_11  @1405062c0  [high:rtti-vtable]  (orig: FUN_1405062c0)
undefined8 FUN_1405062c0(longlong param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x828) < param_2) {
    log_InlineLogERROR(
                      "ClearPacket() error, m_nEvType:%d, ClearPacket nLen:%d, m_nLen:%d, unMsgType:%d at %s, %d"
                      );
  }
  if (*(int *)(param_1 + 0x1030) == 2) {
    iVar2 = *(int *)(param_1 + 0x828) - param_2;
    if (0 < iVar2) {
      memcpy((void *)(param_1 + 0x28),(void *)((longlong)param_2 + 0x28 + param_1),(longlong)iVar2);
    }
    piVar1 = (int *)(param_1 + 0x828);
    *piVar1 = *piVar1 - param_2;
    if (-1 < *piVar1) {
      return 1;
    }
    *(undefined4 *)(param_1 + 0x828) = 0;
  }
  return 0;
}

// ==== CCrossSvrClient::vfunc_13  @140506370  [high:rtti-vtable]  (orig: FUN_140506370)
void FUN_140506370(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1048) != 0) {
    FUN_140544e70();
    *(undefined8 *)(param_1 + 0x1048) = 0;
  }
  *(undefined8 *)(param_1 + 0x20) = 0xffffffffffffffff;
  *(undefined4 *)(param_1 + 0x1030) = 0;
  *(undefined4 *)(param_1 + 0x828) = 0;
  *(undefined4 *)(param_1 + 0x102c) = 0;
  return;
}

// ==== CCrossSvrClient::vfunc_12  @1405063c0  [high:rtti-vtable]  (orig: FUN_1405063c0)
undefined8 FUN_1405063c0(longlong *param_1)

{
  int iVar1;
  
  if ((int)param_1[0x206] != 2) {
    return 0;
  }
  if (*(int *)((longlong)param_1 + 0x102c) != 0) {
    iVar1 = FUN_140544000(param_1[0x209],(longlong)param_1 + 0x82c,
                          (longlong)*(int *)((longlong)param_1 + 0x102c));
    if (iVar1 == -1) {
      iVar1 = FUN_140545950(param_1[4]);
      if (iVar1 != 0x2746) {
        log_InlineLogERROR("m_nEvType[%d] Flush packet failed[%d].");
      }
      (**(code **)(*param_1 + 0x68))(param_1);
      return 0;
    }
    *(undefined4 *)((longlong)param_1 + 0x102c) = 0;
  }
  return 1;
}

// ==== CCrossSvrClient::vfunc_9  @140506450  [high:rtti-vtable]  (orig: FUN_140506450)
undefined1 FUN_140506450(longlong param_1)

{
  if ((*(int *)(param_1 + 0x1030) == 2) && (*(longlong *)(param_1 + 0x20) != -1)) {
    return 1;
  }
  return 0;
}

// ==== CCrossSvrClient::vfunc_5  @140506470  [high:rtti-vtable]  (orig: FUN_140506470)
void FUN_140506470(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x1034) = param_2;
  return;
}

// ==== CCrossSvrClient::helper_140506530  @140506530  [medium:callgraph-r0]  (orig: FUN_140506530)
void FUN_140506530(int *param_1,longlong param_2,int param_3,char param_4)

{
  int iVar1;
  int iVar2;
  byte bVar3;
  longlong lVar4;
  int iVar5;
  
  iVar1 = *param_1;
  iVar2 = param_1[1];
  for (iVar5 = 0; iVar5 < param_3; iVar5 = iVar5 + 1) {
    lVar4 = (longlong)iVar5;
    bVar3 = *(byte *)((longlong)*param_1 + 8 + (longlong)param_1) ^ *(byte *)(lVar4 + param_2);
    *(byte *)(lVar4 + param_2) = bVar3;
    *(byte *)(lVar4 + param_2) = *(byte *)((longlong)param_1[1] + 0x108 + (longlong)param_1) ^ bVar3
    ;
    *param_1 = *param_1 + 1;
    if (0xff < *param_1) {
      *param_1 = 0;
      param_1[1] = param_1[1] + 1;
      if (0xff < param_1[1]) {
        param_1[1] = 0;
      }
    }
    *(byte *)(lVar4 + param_2) =
         *(byte *)(lVar4 + param_2) * '\x10' + (*(byte *)(lVar4 + param_2) >> 4) ^ 0xab;
  }
  if (param_4 == '\0') {
    *param_1 = iVar1;
    param_1[1] = iVar2;
  }
  return;
}

// ==== CCrossSvrClient::vfunc_10  @140506670  [high:rtti-vtable]  (orig: FUN_140506670)
undefined8 FUN_140506670(longlong *param_1,void *param_2,int param_3,char param_4)

{
  undefined8 uVar1;
  char *pcVar2;
  
  if ((int)param_1[0x206] == 2) {
    if (param_1[4] == -1) {
      pcVar2 = "SendPacket() m_nEvType[%d], invalid socket failed.";
    }
    else {
      if (0x800 < param_3 + *(int *)((longlong)param_1 + 0x102c)) {
        (**(code **)(*param_1 + 0x60))(param_1);
      }
      if (*(int *)((longlong)param_1 + 0x102c) + param_3 < 0x801) {
        memcpy((void *)((longlong)*(int *)((longlong)param_1 + 0x102c) + 0x82c + (longlong)param_1),
               param_2,(longlong)param_3);
        *(int *)((longlong)param_1 + 0x102c) = *(int *)((longlong)param_1 + 0x102c) + param_3;
        if (*(char *)((longlong)param_1 + 0x1034) != '\0') {
          FUN_140506530(param_1 + 0x20b,
                        ((longlong)*(int *)((longlong)param_1 + 0x102c) - (longlong)param_3) + 0x82c
                        + (longlong)param_1,param_3,1);
        }
        if (param_4 != '\0') {
          uVar1 = (**(code **)(*param_1 + 0x60))(param_1);
          return uVar1;
        }
        return 1;
      }
      pcVar2 = "SendPacket() m_nEvType[%d], buf full!";
    }
    log_InlineLogERROR(pcVar2);
    (**(code **)(*param_1 + 0x68))(param_1);
  }
  return 0;
}

// ==== CCrossSvrClient::vfunc_6  @140506780  [high:rtti-vtable]  (orig: FUN_140506780)
void FUN_140506780(longlong *param_1)

{
  int iVar1;
  undefined8 uVar2;
  int iVar3;
  
  if (param_1[0x209] != 0) {
    if (0x7ff < (int)param_1[0x105]) {
      (**(code **)(*param_1 + 0x18))();
    }
    uVar2 = FUN_140543f80(param_1[0x209]);
    for (iVar1 = FUN_14054a780(uVar2); 0 < iVar1; iVar1 = iVar1 - iVar3) {
      iVar3 = 0x800 - (int)param_1[0x105];
      if (iVar1 <= iVar3) {
        iVar3 = iVar1;
      }
      iVar3 = FUN_140544040(param_1[0x209],(longlong)(int)param_1[0x105] + 0x28 + (longlong)param_1,
                            (longlong)iVar3);
      if (iVar3 < 1) {
        return;
      }
      if (*(char *)((longlong)param_1 + 0x1034) != '\0') {
        FUN_140506530(param_1 + 0x24c,(longlong)(int)param_1[0x105] + 0x28 + (longlong)param_1,iVar3
                      ,1);
      }
      *(int *)(param_1 + 0x105) = (int)param_1[0x105] + iVar3;
      if ((int)param_1[0x105] < 4) {
        return;
      }
      (**(code **)(*param_1 + 0x18))(param_1);
    }
  }
  return;
}

// ==== CCrossSvrClient::vfunc_8  @1405068a0  [high:rtti-vtable]  (orig: FUN_1405068a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405068a0(longlong *param_1,char *param_2,undefined4 param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined1 auStack_68 [32];
  undefined8 local_48;
  undefined8 local_38;
  undefined8 local_30;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  if ((int)param_1[0x206] != 0) {
    local_48 = CONCAT44(local_48._4_4_,0x3a);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_1[0x208] == 0) {
    local_48 = CONCAT44(local_48._4_4_,0x3b);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  tq::SafeCopy((char *)(param_1 + 1),param_2,0x10);
  *(undefined4 *)(param_1 + 3) = param_3;
  cVar1 = (**(code **)(*param_1 + 0x48))(param_1);
  if (cVar1 == '\0') {
    if (((int)param_1[0x206] == 0) || (param_1[4] == -1)) {
      if (*(char *)((longlong)param_1 + 0x1034) != '\0') {
        *(undefined4 *)((longlong)param_1 + 0x105c) = 0;
        *(undefined4 *)(param_1 + 0x20b) = 0;
        FUN_140506480(param_1 + 0x20c);
        *(undefined4 *)((longlong)param_1 + 0x1264) = 0;
        *(undefined4 *)(param_1 + 0x24c) = 0;
        FUN_140506480(param_1 + 0x24d);
      }
      if (param_1[4] != -1) {
        local_48 = CONCAT44(local_48._4_4_,0x4a);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar3 = Ordinal_11(param_1 + 1);
      if (iVar3 == -1) {
        lVar4 = Ordinal_52(param_1 + 1);
        if (lVar4 == 0) {
          log_InlineLogERROR(&DAT_14079b638);
          (**(code **)(*param_1 + 0x68))(param_1);
          return 0;
        }
        iVar3 = *(int *)**(undefined8 **)(lVar4 + 0x18);
      }
      local_30 = 0;
      local_38 = 2;
      uVar2 = Ordinal_9((short)param_1[3]);
      local_38 = CONCAT44(iVar3,CONCAT22(uVar2,(undefined2)local_38));
      uVar5 = FUN_1404f7250(param_1[0x208]);
      lVar4 = FUN_1405497f0(uVar5,0xffffffffffffffff,3);
      param_1[0x209] = lVar4;
      if (lVar4 == 0) {
        Ordinal_111();
        log_InlineLogERROR("CClientSocket::Open, bufferevent_socket_new m_nEvType[%d] error[%d].");
        (**(code **)(*param_1 + 0x68))(param_1);
        return 0;
      }
      local_48 = FUN_1404f7290(param_1[0x208],(int)param_1[0x207]);
      FUN_140543e60(param_1[0x209],FUN_1404f8200,&DAT_1404f7230,FUN_1404f8290);
      iVar3 = FUN_140549e00(param_1[0x209],&local_38,0x10);
      if (-1 < iVar3) {
        lVar4 = FUN_140544610(param_1[0x209]);
        *(undefined4 *)(param_1 + 0x105) = 0;
        *(undefined4 *)(param_1 + 0x206) = 2;
        param_1[4] = lVar4;
        goto LAB_140506b50;
      }
      Ordinal_111();
      local_48 = CONCAT44(local_48._4_4_,0x7f);
      log_InlineLogERROR(
                        "CClientSocket::Open, bufferevent_socket_connect m_nEvType[%d] error[%d], at %s, %d."
                        );
      (**(code **)(*param_1 + 0x68))(param_1);
    }
    uVar5 = 0;
  }
  else {
LAB_140506b50:
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CCrossSvrClient::vfunc_7  @140506b70  [high:rtti-vtable]  (orig: FUN_140506b70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140506b70(longlong *param_1)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined1 auStack_58 [32];
  undefined8 local_38;
  undefined8 local_28;
  undefined8 local_20;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  if ((char)param_1[1] == '\0') {
    local_38 = CONCAT44(local_38._4_4_,0x9e);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_1[0x208] == 0) {
    local_38 = CONCAT44(local_38._4_4_,0x9f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    if (cVar1 != '\0') {
      return 1;
    }
    if (((int)param_1[0x206] == 0) || (param_1[4] == -1)) {
      if (*(char *)((longlong)param_1 + 0x1034) != '\0') {
        *(undefined4 *)((longlong)param_1 + 0x105c) = 0;
        *(undefined4 *)(param_1 + 0x20b) = 0;
        FUN_140506480(param_1 + 0x20c);
        *(undefined4 *)((longlong)param_1 + 0x1264) = 0;
        *(undefined4 *)(param_1 + 0x24c) = 0;
        FUN_140506480(param_1 + 0x24d);
      }
      if (param_1[4] != -1) {
        local_38 = CONCAT44(local_38._4_4_,0xab);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar3 = Ordinal_11(param_1 + 1);
      if (iVar3 == -1) {
        lVar4 = Ordinal_52(param_1 + 1);
        if (lVar4 == 0) {
          log_InlineLogERROR(&DAT_14079b638);
          (**(code **)(*param_1 + 0x68))(param_1);
          return 0;
        }
        iVar3 = *(int *)**(undefined8 **)(lVar4 + 0x18);
      }
      local_20 = 0;
      local_28 = 2;
      uVar2 = Ordinal_9((short)param_1[3]);
      local_28 = CONCAT44(iVar3,CONCAT22(uVar2,(undefined2)local_28));
      uVar5 = FUN_1404f7250(param_1[0x208]);
      lVar4 = FUN_1405497f0(uVar5,0xffffffffffffffff,3);
      param_1[0x209] = lVar4;
      if (lVar4 == 0) {
        Ordinal_111();
        log_InlineLogERROR("CClientSocket::Open, bufferevent_socket_new m_nEvType[%d] error[%d].");
        (**(code **)(*param_1 + 0x68))(param_1);
      }
      else {
        local_38 = FUN_1404f7290(param_1[0x208],(int)param_1[0x207]);
        FUN_140543e60(param_1[0x209],FUN_1404f8200,&DAT_1404f7230,FUN_1404f8290);
        iVar3 = FUN_140549e00(param_1[0x209],&local_28,0x10);
        if (iVar3 < 0) {
          (**(code **)(*param_1 + 0x68))(param_1);
        }
        else {
          lVar4 = FUN_140544610(param_1[0x209]);
          *(undefined4 *)(param_1 + 0x105) = 0;
          *(undefined4 *)(param_1 + 0x206) = 2;
          param_1[4] = lVar4;
        }
      }
    }
  }
  return 0;
}

// ==== CCrossSvrClient::vfunc_4  @140506e00  [high:rtti-vtable]  (orig: FUN_140506e00)
void FUN_140506e00(longlong *param_1)

{
  char cVar1;
  
  cVar1 = (**(code **)(*param_1 + 0x48))();
  if ((cVar1 == '\0') && (*(int *)((longlong)param_1 + 0x1054) != 0)) {
    cVar1 = FUN_1400149a0(param_1 + 0x20a);
    if (cVar1 != '\0') {
      (**(code **)(*param_1 + 0x38))(param_1);
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_14053ceb0  @14053ceb0  [medium:callgraph-r2]  (orig: FUN_14053ceb0)
undefined4 FUN_14053ceb0(longlong param_1)

{
  undefined4 uVar1;
  
  if (param_1 == 0) {
    param_1 = DAT_140976d20;
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = *(undefined4 *)(param_1 + 0x100);
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

// ==== CCrossSvrClient::helper_14053d280  @14053d280  [medium:callgraph-r1]  (orig: FUN_14053d280)
undefined8
FUN_14053d280(undefined *param_1,longlong param_2,undefined8 param_3,ushort param_4,
             undefined8 param_5,undefined *param_6)

{
  if (param_2 == 0) {
    param_2 = DAT_140976d20;
  }
  *(undefined8 *)(param_1 + 0x38) = param_3;
  *(ushort *)(param_1 + 0x68) = param_4;
  if (param_6 == &DAT_140976d28) {
    param_6 = param_1;
  }
  *(undefined8 *)(param_1 + 0x18) = param_5;
  *(undefined **)(param_1 + 0x20) = param_6;
  *(undefined2 *)(param_1 + 0x10) = 0x80;
  *(longlong *)(param_1 + 0x40) = param_2;
  *(undefined2 *)(param_1 + 0x6a) = 0;
  *(undefined2 *)(param_1 + 0x58) = 0;
  *(undefined8 *)(param_1 + 0x60) = 0;
  if ((param_4 & 8) == 0) {
    if ((param_4 & 0x10) == 0) {
      param_1[0x13] = 0;
    }
    else {
      *(undefined4 *)(param_1 + 0x5c) = 0;
      *(undefined4 *)(param_1 + 0x58) = 0;
      param_1[0x13] = 2;
    }
  }
  else {
    if ((param_4 & 0x86) != 0) {
      FUN_14054f8b0("%s: EV_SIGNAL is not compatible with EV_READ, EV_WRITE or EV_CLOSED",
                    "event_assign");
      return 0xffffffff;
    }
    param_1[0x13] = 1;
  }
  *(undefined4 *)(param_1 + 0x28) = 0xffffffff;
  if (param_2 != 0) {
    param_1[0x12] = (char)(*(int *)(param_2 + 0x100) / 2);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_14053d440  @14053d440  [medium:callgraph-r2]  (orig: FUN_14053d440)
ushort FUN_14053d440(longlong param_1,ushort param_2,int *param_3)

{
  ushort uVar1;
  undefined8 uVar2;
  int iVar3;
  ushort uVar4;
  int local_res8;
  
  uVar4 = 0;
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = *(ushort *)(param_1 + 0x10);
  if ((uVar1 & 2) != 0) {
    uVar4 = *(ushort *)(param_1 + 0x68) & 0x8e;
  }
  if ((uVar1 & 0x28) != 0) {
    uVar4 = uVar4 | *(ushort *)(param_1 + 0x6a);
  }
  if ((uVar1 & 1) != 0) {
    uVar4 = uVar4 | 1;
  }
  if ((param_3 != (int *)0x0) && ((param_2 & 0x8f & uVar4 & 1) != 0)) {
    uVar2 = *(undefined8 *)(param_1 + 0x6c);
    local_res8 = (int)uVar2;
    *param_3 = *(int *)(*(longlong *)(param_1 + 0x40) + 0x1b8) + local_res8;
    iVar3 = *(int *)(*(longlong *)(param_1 + 0x40) + 0x1bc) +
            ((uint)((ulonglong)uVar2 >> 0x20) & 0xfffff);
    param_3[1] = iVar3;
    if (999999 < iVar3) {
      *param_3 = *param_3 + 1;
      param_3[1] = param_3[1] + -1000000;
    }
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return param_2 & 0x8f & uVar4;
}

// ==== CCrossSvrClient::helper_14053d530  @14053d530  [medium:callgraph-r2]  (orig: FUN_14053d530)
bool FUN_14053d530(longlong param_1)

{
  return (*(byte *)(param_1 + 0x10) & 0x80) != 0;
}

// ==== CCrossSvrClient::helper_14053d6e0  @14053d6e0  [medium:callgraph-r2]  (orig: FUN_14053d6e0)
void FUN_14053d6e0(undefined8 *param_1,undefined1 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = param_3;
  param_1[4] = param_4;
  *(undefined1 *)((longlong)param_1 + 0x12) = param_2;
  *(undefined1 *)((longlong)param_1 + 0x13) = 3;
  return;
}

// ==== CCrossSvrClient::helper_14053dad0  @14053dad0  [medium:callgraph-r3]  (orig: FUN_14053dad0)
void FUN_14053dad0(longlong param_1,undefined8 *param_2)

{
  undefined8 in_RAX;
  int iVar1;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    in_RAX = FUN_14054f2a0();
  }
  if ((*(ushort *)(param_2 + 2) & 0x28) == 0) {
    *(int *)(param_1 + 0xd0) =
         *(int *)(param_1 + 0xd0) +
         (~((int)CONCAT62((int6)((ulonglong)in_RAX >> 0x10),*(ushort *)(param_2 + 2)) >> 4) & 1U);
    iVar1 = *(int *)(param_1 + 0xd0);
    if (*(int *)(param_1 + 0xd0) < *(int *)(param_1 + 0xd4)) {
      iVar1 = *(int *)(param_1 + 0xd4);
    }
    *(int *)(param_1 + 0xd4) = iVar1;
    *(ushort *)(param_2 + 2) = *(ushort *)(param_2 + 2) | 0x20;
    *(int *)(param_1 + 0xd8) = *(int *)(param_1 + 0xd8) + 1;
    iVar1 = *(int *)(param_1 + 0xd8);
    if (*(int *)(param_1 + 0xd8) < *(int *)(param_1 + 0xdc)) {
      iVar1 = *(int *)(param_1 + 0xdc);
    }
    *(int *)(param_1 + 0xdc) = iVar1;
    *param_2 = 0;
    param_2[1] = *(undefined8 *)(param_1 + 0x110);
    **(undefined8 **)(param_1 + 0x110) = param_2;
    *(undefined8 **)(param_1 + 0x110) = param_2;
  }
  return;
}

// ==== CCrossSvrClient::helper_14053dc90  @14053dc90  [medium:callgraph-r1]  (orig: FUN_14053dc90)
void * FUN_14053dc90(ulonglong param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  void *pvVar2;
  int *piVar3;
  
  if ((param_1 == 0) || (param_2 == 0)) {
    return (void *)0x0;
  }
  if (DAT_140976d38 == (code *)0x0) {
    pvVar2 = calloc(param_1,param_2);
    if (pvVar2 != (void *)0x0) {
      return pvVar2;
    }
  }
  else {
    auVar1._8_8_ = 0;
    auVar1._0_8_ = param_2;
    if ((param_1 <= SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0)) &&
       (pvVar2 = (void *)(*DAT_140976d38)(param_1 * param_2), pvVar2 != (void *)0x0)) {
      memset(pvVar2,0,param_1 * param_2);
      return pvVar2;
    }
  }
  piVar3 = _errno();
  *piVar3 = 0xc;
  return (void *)0x0;
}

// ==== CCrossSvrClient::helper_14053de00  @14053de00  [medium:callgraph-r1]  (orig: FUN_14053de00)
void FUN_14053de00(void *param_1)

{
  if (DAT_140976d48 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014053de0c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*DAT_140976d48)();
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014053de0f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  free(param_1);
  return;
}

// ==== CCrossSvrClient::helper_14053e4b0  @14053e4b0  [medium:callgraph-r2]  (orig: FUN_14053e4b0)
void FUN_14053e4b0(longlong param_1)

{
  int iVar1;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  *(int *)(param_1 + 200) = *(int *)(param_1 + 200) + 1;
  iVar1 = *(int *)(param_1 + 200);
  if (*(int *)(param_1 + 200) < *(int *)(param_1 + 0xcc)) {
    iVar1 = *(int *)(param_1 + 0xcc);
  }
  *(int *)(param_1 + 0xcc) = iVar1;
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_14053e510  @14053e510  [medium:callgraph-r2]  (orig: FUN_14053e510)
void FUN_14053e510(longlong param_1)

{
  int *piVar1;
  int iVar2;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  piVar1 = (int *)(param_1 + 200);
  *piVar1 = *piVar1 + -1;
  if ((*piVar1 == 0) && (*(int *)(param_1 + 0xf0) != 0)) {
    iVar2 = FUN_14054f180();
    if (*(int *)(param_1 + 0x1c8) != iVar2) {
      FUN_14053d650(param_1);
    }
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_14053ef90  @14053ef90  [medium:callgraph-r3]  (orig: FUN_14053ef90)
undefined8 FUN_14053ef90(longlong param_1,longlong param_2)

{
  ushort uVar1;
  int iVar2;
  undefined8 uVar3;
  
  uVar1 = *(ushort *)(param_2 + 0x10);
  uVar3 = 1;
  if ((uVar1 & 0x40) != 0) {
    return 0;
  }
  if ((uVar1 & 0x28) != 0) {
    if ((uVar1 & 0x28) == 8) {
      return 0;
    }
    FUN_14053d8a0();
    uVar3 = 0;
  }
  FUN_14053da10(param_1,param_2);
  if ((*(int *)(param_1 + 0xf0) != 0) &&
     (iVar2 = FUN_14054f180(), *(int *)(param_1 + 0x1c8) != iVar2)) {
    FUN_14053d650(param_1);
  }
  return uVar3;
}

// ==== CCrossSvrClient::helper_14053f050  @14053f050  [medium:callgraph-r2]  (orig: FUN_14053f050)
undefined4 FUN_14053f050(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    param_1 = DAT_140976d20;
  }
  uVar2 = 1;
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  if (*(int *)(param_1 + 0xf4) < 0x21) {
    *(int *)(param_1 + 0xf4) = *(int *)(param_1 + 0xf4) + 1;
    uVar2 = FUN_14053ef90(param_1,param_2);
  }
  else if ((*(byte *)(param_2 + 0x10) & 0x28) == 0) {
    FUN_14053dad0(param_1,param_2);
    if (*(int *)(param_1 + 0xf0) != 0) {
      iVar1 = FUN_14054f180();
      if (*(int *)(param_1 + 0x1c8) != iVar1) {
        FUN_14053d650(param_1);
      }
    }
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return uVar2;
}

// ==== CCrossSvrClient::helper_14053f530  @14053f530  [medium:callgraph-r2]  (orig: FUN_14053f530)
void FUN_14053f530(longlong param_1,ushort param_2,undefined2 param_3)

{
  ushort uVar1;
  longlong lVar2;
  int iVar3;
  
  lVar2 = *(longlong *)(param_1 + 0x40);
  if (*(longlong *)(lVar2 + 0x1d0) != 0) {
    FUN_14054f2a0();
  }
  uVar1 = *(ushort *)(param_1 + 0x10);
  if ((uVar1 & 0x40) == 0) {
    if ((uVar1 & 0x28) == 0) {
      *(ushort *)(param_1 + 0x6a) = param_2;
    }
    else {
      if ((uVar1 & 0x28) == 8) {
        *(ushort *)(param_1 + 0x6a) = *(ushort *)(param_1 + 0x6a) | param_2;
        return;
      }
      if ((uVar1 & 0x28) == 0x20) {
        *(ushort *)(param_1 + 0x6a) = *(ushort *)(param_1 + 0x6a) | param_2;
      }
    }
    if ((int)(uint)*(byte *)(param_1 + 0x12) < *(int *)(lVar2 + 0xec)) {
      *(undefined4 *)(lVar2 + 0xe8) = 1;
    }
    if ((*(byte *)(param_1 + 0x68) & 8) != 0) {
      if ((*(longlong *)(lVar2 + 0x1e8) == param_1) &&
         (iVar3 = FUN_14054f180(), *(int *)(lVar2 + 0x1c8) != iVar3)) {
        *(int *)(lVar2 + 0x1e0) = *(int *)(lVar2 + 0x1e0) + 1;
        if (*(longlong *)(lVar2 + 0x1d8) != 0) {
          FUN_14054f280(*(longlong *)(lVar2 + 0x1d8),*(undefined8 *)(lVar2 + 0x1d0),0);
        }
      }
      *(undefined2 *)(param_1 + 0x58) = param_3;
      *(undefined8 *)(param_1 + 0x60) = 0;
    }
    FUN_14053ef90(lVar2,param_1);
  }
  return;
}

// ==== CCrossSvrClient::helper_1405400d0  @1405400d0  [medium:callgraph-r3]  (orig: FUN_1405400d0)
void FUN_1405400d0(undefined8 param_1,undefined8 param_2,longlong param_3,undefined8 param_4)

{
  ushort uVar1;
  longlong lVar2;
  int iVar3;
  
  uVar1 = *(ushort *)(param_3 + 0x10);
  if ((char)uVar1 < '\0') {
    if (*(longlong *)(param_3 + 0x40) != 0) {
      if (*(longlong *)(*(longlong *)(param_3 + 0x40) + 0x1d0) != 0) {
        FUN_14054f2a0();
      }
      if ((*(byte *)(param_3 + 0x10) & 0x40) == 0) {
        lVar2 = *(longlong *)(param_3 + 0x40);
        if ((((*(byte *)(param_3 + 0x68) & 8) != 0) && (*(short *)(param_3 + 0x58) != 0)) &&
           (*(undefined2 **)(param_3 + 0x60) != (undefined2 *)0x0)) {
          **(undefined2 **)(param_3 + 0x60) = 0;
        }
        if ((*(byte *)(param_3 + 0x10) & 1) != 0) {
          FUN_14053f100(lVar2,param_3);
        }
        if ((*(ushort *)(param_3 + 0x10) & 8) == 0) {
          if ((*(ushort *)(param_3 + 0x10) & 0x20) != 0) {
            FUN_14053d8a0(lVar2,param_3);
          }
        }
        else {
          FUN_14053d820(lVar2,param_3);
        }
        if ((*(byte *)(param_3 + 0x10) & 2) != 0) {
          if (*(longlong *)(lVar2 + 0x1d0) != 0) {
            FUN_14054f2a0();
          }
          *(int *)(lVar2 + 0xd0) =
               *(int *)(lVar2 + 0xd0) - (~((int)*(short *)(param_3 + 0x10) >> 4) & 1U);
          *(ushort *)(param_3 + 0x10) = *(ushort *)(param_3 + 0x10) & 0xfffd;
          if ((*(byte *)(param_3 + 0x68) & 0x86) == 0) {
            iVar3 = FUN_140550640(lVar2,*(undefined4 *)(param_3 + 0x38),param_3);
          }
          else {
            iVar3 = FUN_140550310(lVar2,*(undefined8 *)(param_3 + 0x38));
          }
          if ((iVar3 == 1) && (*(int *)(lVar2 + 0xf0) != 0)) {
            iVar3 = FUN_14054f180();
            if (*(int *)(lVar2 + 0x1c8) != iVar3) {
              FUN_14053d650(lVar2);
            }
          }
        }
      }
    }
  }
  else if (((uVar1 & 0x40) == 0) && ((uVar1 & 0x28) != 0)) {
    if ((uVar1 & 0x28) == 8) {
      FUN_14053d820(param_1,param_3);
    }
    else if ((uVar1 & 0x28) == 0x20) {
      FUN_14053d8a0(param_1,param_3);
    }
  }
  *(undefined1 *)(param_3 + 0x13) = 4;
  *(undefined8 *)(param_3 + 0x18) = param_4;
  FUN_14053ef90(param_1,param_3);
  *(ushort *)(param_3 + 0x10) = *(ushort *)(param_3 + 0x10) | 0x40;
  return;
}

// ==== CCrossSvrClient::helper_1405402b0  @1405402b0  [medium:callgraph-r2]  (orig: FUN_1405402b0)
undefined8 FUN_1405402b0(longlong param_1,int param_2,undefined8 *param_3,undefined8 param_4)

{
  ushort uVar1;
  longlong lVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  uVar3 = 0;
  if (param_1 == 0) {
    param_1 = DAT_140976d20;
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar4 = uVar3;
  if (0 < (longlong)param_2) {
    do {
      lVar2 = param_3[uVar3];
      if (lVar2 == *(longlong *)(param_1 + 0x1e8)) {
        FUN_1405400d0(param_1,0,lVar2,param_4);
        uVar4 = (ulonglong)((int)uVar4 + 1);
      }
      else {
        uVar1 = *(ushort *)(lVar2 + 0x10);
        if ((uVar1 & 0x40) == 0) {
          if ((char)uVar1 < '\0') {
            FUN_14053f3a0(lVar2,2);
          }
          else if ((uVar1 & 0x28) != 0) {
            if ((uVar1 & 0x28) == 8) {
              FUN_14053d820(param_1,lVar2);
            }
            else if ((uVar1 & 0x28) == 0x20) {
              FUN_14053d8a0(param_1,lVar2);
            }
          }
        }
      }
      uVar3 = uVar3 + 1;
    } while ((longlong)uVar3 < (longlong)param_2);
    if ((int)uVar4 != 0) goto LAB_14054037d;
  }
  FUN_1405400d0(param_1,0,*param_3,param_4);
LAB_14054037d:
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_140540bd0  @140540bd0  [medium:callgraph-r1]  (orig: FUN_140540bd0)
void FUN_140540bd0(longlong param_1,undefined4 param_2,undefined2 param_3)

{
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  FUN_14053f530(param_1,param_2,param_3);
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_140542250  @140542250  [medium:callgraph-r2]  (orig: FUN_140542250)
ulonglong FUN_140542250(longlong param_1,undefined8 param_2)

{
  ulonglong uVar1;
  
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = FUN_1405403b0(param_1,param_2,0);
  if (*(longlong *)(*(longlong *)(param_1 + 0x40) + 0x1d0) != 0) {
    FUN_14054f200(0);
    uVar1 = uVar1 & 0xffffffff;
  }
  return uVar1;
}

// ==== CCrossSvrClient::helper_140543c00  @140543c00  [medium:callgraph-r2]  (orig: FUN_140543c00)
void FUN_140543c00(longlong param_1,ushort param_2)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if (*(short *)(param_1 + 0x176) == 0) {
    (**(code **)(*(longlong *)(param_1 + 8) + 0x18))(param_1,2);
  }
  *(ushort *)(param_1 + 0x176) = *(ushort *)(param_1 + 0x176) | param_2;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_140543ce0  @140543ce0  [medium:callgraph-r3]  (orig: FUN_140543ce0)
void FUN_140543ce0(longlong param_1,ushort param_2)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if (*(short *)(param_1 + 0x178) == 0) {
    (**(code **)(*(longlong *)(param_1 + 8) + 0x18))(param_1,4);
  }
  *(ushort *)(param_1 + 0x178) = *(ushort *)(param_1 + 0x178) | param_2;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_140543d50  @140543d50  [medium:callgraph-r3]  (orig: FUN_140543d50)
void FUN_140543d50(longlong param_1,ushort param_2)

{
  ushort *puVar1;
  
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  puVar1 = (ushort *)(param_1 + 0x178);
  *puVar1 = *puVar1 & ~param_2;
  if ((*puVar1 == 0) && ((*(byte *)(param_1 + 0x160) & 4) != 0)) {
    (**(code **)(*(longlong *)(param_1 + 8) + 0x10))(param_1,4);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_140543e60  @140543e60  [medium:callgraph-r0]  (orig: FUN_140543e60)
void FUN_140543e60(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  undefined8 param_5)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(undefined8 *)(param_1 + 0x130) = param_2;
  *(undefined8 *)(param_1 + 0x138) = param_3;
  *(undefined8 *)(param_1 + 0x140) = param_4;
  *(undefined8 *)(param_1 + 0x148) = param_5;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_140543f80  @140543f80  [medium:callgraph-r0]  (orig: FUN_140543f80)
undefined8 FUN_140543f80(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x100);
}

// ==== CCrossSvrClient::helper_140544040  @140544040  [medium:callgraph-r0]  (orig: FUN_140544040)
longlong FUN_140544040(longlong param_1)

{
  int iVar1;
  
  iVar1 = FUN_14054c7f0(*(undefined8 *)(param_1 + 0x100));
  return (longlong)iVar1;
}

// ==== CCrossSvrClient::helper_140544200  @140544200  [medium:callgraph-r2]  (orig: FUN_140544200)
undefined4 FUN_140544200(longlong param_1,ushort param_2)

{
  int iVar1;
  undefined4 uVar2;
  
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(ushort *)(param_1 + 0x160) = *(ushort *)(param_1 + 0x160) & ~param_2;
  iVar1 = (**(code **)(*(longlong *)(param_1 + 8) + 0x18))(param_1,param_2);
  uVar2 = 0;
  if (iVar1 < 0) {
    uVar2 = 0xffffffff;
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return uVar2;
}

// ==== CCrossSvrClient::helper_1405444f0  @1405444f0  [medium:callgraph-r1]  (orig: FUN_1405444f0)
void FUN_1405444f0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
    *(int *)(param_1 + 0x1b4) = *(int *)(param_1 + 0x1b4) + 1;
    return;
  }
  *(int *)(param_1 + 0x1b4) = *(int *)(param_1 + 0x1b4) + 1;
  return;
}

// ==== CCrossSvrClient::helper_140544530  @140544530  [medium:callgraph-r2]  (orig: FUN_140544530)
void FUN_140544530(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  FUN_140544d50(param_1);
  return;
}

// ==== CCrossSvrClient::helper_140544560  @140544560  [medium:callgraph-r2]  (orig: FUN_140544560)
void FUN_140544560(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(int *)(param_1 + 0x1b4) = *(int *)(param_1 + 0x1b4) + 1;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_1405445a0  @1405445a0  [medium:callgraph-r1]  (orig: FUN_1405445a0)
undefined4 FUN_1405445a0(longlong param_1,undefined8 param_2)

{
  code *pcVar1;
  undefined4 uVar2;
  undefined8 local_res8;
  
  uVar2 = 0xffffffff;
  local_res8 = param_2;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  pcVar1 = *(code **)(*(longlong *)(param_1 + 8) + 0x40);
  if (pcVar1 != (code *)0x0) {
    uVar2 = (*pcVar1)(param_1,0,&local_res8);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return uVar2;
}

// ==== CCrossSvrClient::helper_140544610  @140544610  [medium:callgraph-r0]  (orig: FUN_140544610)
undefined8 FUN_140544610(longlong param_1)

{
  code *pcVar1;
  int iVar2;
  undefined8 local_res8;
  
  iVar2 = -1;
  local_res8 = 0xffffffffffffffff;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  pcVar1 = *(code **)(*(longlong *)(param_1 + 8) + 0x40);
  if (pcVar1 != (code *)0x0) {
    iVar2 = (*pcVar1)(param_1,1,&local_res8);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  if (iVar2 < 0) {
    local_res8 = 0xffffffffffffffff;
  }
  return local_res8;
}

// ==== CCrossSvrClient::helper_140544790  @140544790  [medium:callgraph-r3]  (orig: FUN_140544790)
undefined8 FUN_140544790(longlong param_1)

{
  code *pcVar1;
  int iVar2;
  undefined8 local_res8;
  
  iVar2 = -1;
  local_res8 = 0;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  pcVar1 = *(code **)(*(longlong *)(param_1 + 8) + 0x40);
  if (pcVar1 != (code *)0x0) {
    iVar2 = (*pcVar1)(param_1,2,&local_res8);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  if (iVar2 < 0) {
    local_res8 = 0;
  }
  return local_res8;
}

// ==== CCrossSvrClient::helper_1405448f0  @1405448f0  [medium:callgraph-r1]  (orig: FUN_1405448f0)
void FUN_1405448f0(undefined8 param_1,int *param_2)

{
  if ((*param_2 == 0) && (param_2[1] == 0)) {
    param_2 = (int *)0x0;
  }
  FUN_140542250(param_1,param_2);
  return;
}

// ==== CCrossSvrClient::helper_140544950  @140544950  [medium:callgraph-r2]  (orig: FUN_140544950)
void FUN_140544950(undefined8 *param_1,uint param_2)

{
  int iVar1;
  
  if ((code *)param_1[0x26] != (code *)0x0) {
    if (((*(uint *)(param_1 + 0x36) | param_2) & 4) == 0) {
      (*(code *)param_1[0x26])(param_1,param_1[0x29]);
    }
    else {
      *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 2;
      iVar1 = FUN_14053f050(*param_1,param_1 + 0x31);
      if (iVar1 != 0) {
        if (param_1[0x37] != 0) {
          FUN_14054f1e0(0);
        }
        *(int *)((longlong)param_1 + 0x1b4) = *(int *)((longlong)param_1 + 0x1b4) + 1;
        if (param_1[0x37] != 0) {
          FUN_14054f200(0);
          return;
        }
      }
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_1405449d0  @1405449d0  [medium:callgraph-r2]  (orig: FUN_1405449d0)
void FUN_1405449d0(undefined8 *param_1,uint param_2)

{
  int iVar1;
  
  if ((code *)param_1[0x27] != (code *)0x0) {
    if (((*(uint *)(param_1 + 0x36) | param_2) & 4) == 0) {
      (*(code *)param_1[0x27])(param_1,param_1[0x29]);
    }
    else {
      *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 4;
      iVar1 = FUN_14053f050(*param_1,param_1 + 0x31);
      if (iVar1 != 0) {
        if (param_1[0x37] != 0) {
          FUN_14054f1e0(0);
        }
        *(int *)((longlong)param_1 + 0x1b4) = *(int *)((longlong)param_1 + 0x1b4) + 1;
        if (param_1[0x37] != 0) {
          FUN_14054f200(0);
          return;
        }
      }
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_140544a50  @140544a50  [medium:callgraph-r1]  (orig: FUN_140544a50)
void FUN_140544a50(undefined8 *param_1,undefined8 param_2,uint param_3)

{
  undefined4 uVar1;
  int iVar2;
  
  if ((code *)param_1[0x28] != (code *)0x0) {
    if (((*(uint *)(param_1 + 0x36) | param_3) & 4) == 0) {
      (*(code *)param_1[0x28])(param_1,param_2,param_1[0x29]);
    }
    else {
      *(ushort *)((longlong)param_1 + 0x174) =
           *(ushort *)((longlong)param_1 + 0x174) | (ushort)param_2;
      uVar1 = Ordinal_111();
      *(undefined4 *)((longlong)param_1 + 0x17c) = uVar1;
      iVar2 = FUN_14053f050(*param_1,param_1 + 0x31);
      if (iVar2 != 0) {
        if (param_1[0x37] != 0) {
          FUN_14054f1e0(0);
        }
        *(int *)((longlong)param_1 + 0x1b4) = *(int *)((longlong)param_1 + 0x1b4) + 1;
        if (param_1[0x37] != 0) {
          FUN_14054f200(0);
          return;
        }
      }
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_140544ae0  @140544ae0  [medium:callgraph-r2]  (orig: FUN_140544ae0)
void FUN_140544ae0(undefined8 param_1,longlong param_2)

{
  code *pcVar1;
  longlong lVar2;
  
  if (*(longlong *)(param_2 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  lVar2 = FUN_140544790(param_2);
  pcVar1 = *(code **)(*(longlong *)(param_2 + 8) + 0x28);
  if (pcVar1 != (code *)0x0) {
    (*pcVar1)(param_2);
  }
  FUN_14054a710(*(undefined8 *)(param_2 + 0x100));
  FUN_14054a710(*(undefined8 *)(param_2 + 0x108));
  if (*(longlong *)(param_2 + 0x1d0) != 0) {
    if (*(longlong *)(*(longlong *)(param_2 + 0x1d0) + 0x10) != 0) {
      FUN_140552de0(param_2,0);
    }
    FUN_14053de00(*(undefined8 *)(param_2 + 0x1d0));
    *(undefined8 *)(param_2 + 0x1d0) = 0;
  }
  if (*(longlong *)(param_2 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  if (((*(byte *)(param_2 + 0x170) & 1) != 0) && (*(longlong *)(param_2 + 0x1b8) != 0)) {
    FUN_14054f1c0(*(longlong *)(param_2 + 0x1b8),1);
  }
  FUN_14053de00(param_2 - *(int *)(*(longlong *)(param_2 + 8) + 8));
  if (lVar2 != 0) {
    if (*(longlong *)(lVar2 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
    FUN_140544d50(lVar2);
  }
  return;
}

// ==== CCrossSvrClient::helper_140544be0  @140544be0  [medium:callgraph-r2]  (orig: FUN_140544be0)
undefined8 FUN_140544be0(longlong param_1,longlong param_2)

{
  longlong lVar1;
  
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    return 0xffffffff;
  }
  lVar1 = FUN_140544790();
  if (param_2 == 0) {
    if ((lVar1 == 0) || (param_2 = *(longlong *)(lVar1 + 0x1b8), param_2 == 0)) {
      param_2 = FUN_14054f1a0(1);
      if (param_2 == 0) {
        return 0xffffffff;
      }
      *(uint *)(param_1 + 0x170) = *(uint *)(param_1 + 0x170) | 1;
      *(longlong *)(param_1 + 0x1b8) = param_2;
    }
    else {
      *(uint *)(param_1 + 0x170) = *(uint *)(param_1 + 0x170) & 0xfffffffe;
      *(longlong *)(param_1 + 0x1b8) = param_2;
    }
  }
  else {
    *(uint *)(param_1 + 0x170) = *(uint *)(param_1 + 0x170) & 0xfffffffe;
    *(longlong *)(param_1 + 0x1b8) = param_2;
  }
  FUN_14054a3d0(*(undefined8 *)(param_1 + 0x100),param_2);
  FUN_14054a3d0(*(undefined8 *)(param_1 + 0x108),param_2);
  if ((lVar1 != 0) && (*(longlong *)(lVar1 + 0x1b8) == 0)) {
    FUN_140544be0(lVar1,param_2);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_140544d50  @140544d50  [medium:callgraph-r1]  (orig: FUN_140544d50)
undefined8 FUN_140544d50(undefined8 *param_1)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  int iVar4;
  undefined8 *local_88 [3];
  longlong local_70;
  
  piVar1 = (int *)((longlong)param_1 + 0x1b4);
  *piVar1 = *piVar1 + -1;
  if (*piVar1 != 0) {
    if (param_1[0x37] != 0) {
      FUN_14054f200(0);
    }
    return 0;
  }
  if (*(code **)(param_1[1] + 0x20) != (code *)0x0) {
    (**(code **)(param_1[1] + 0x20))();
  }
  local_88[0] = param_1 + 2;
  iVar4 = 3;
  local_88[1] = param_1 + 0x11;
  local_88[2] = param_1 + 0x31;
  if (param_1[0x3a] != 0) {
    lVar3 = param_1[0x3a] + 0x38;
    iVar2 = FUN_14053d530(lVar3);
    if (iVar2 != 0) {
      iVar4 = 4;
      local_70 = lVar3;
    }
  }
  iVar2 = FUN_14054be00(param_1[0x20],local_88 + iVar4,0x10 - iVar4);
  iVar4 = iVar4 + iVar2;
  iVar2 = FUN_14054be00(param_1[0x21],local_88 + iVar4,0x10 - iVar4);
  FUN_1405402b0(*param_1,iVar2 + iVar4,local_88,FUN_140544ae0);
  if (param_1[0x37] != 0) {
    FUN_14054f200(0);
  }
  return 1;
}

// ==== CCrossSvrClient::helper_140544f30  @140544f30  [medium:callgraph-r3]  (orig: FUN_140544f30)
void FUN_140544f30(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(int *)(param_3 + 0x1b4) = *(int *)(param_3 + 0x1b4) + 1;
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(ushort *)(param_3 + 0x160) = *(ushort *)(param_3 + 0x160) & 0xfffd;
  (**(code **)(*(longlong *)(param_3 + 8) + 0x18))(param_3,2);
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  FUN_140544a50(param_3,0x41,0);
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_140544fb0  @140544fb0  [medium:callgraph-r3]  (orig: FUN_140544fb0)
void FUN_140544fb0(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(int *)(param_3 + 0x1b4) = *(int *)(param_3 + 0x1b4) + 1;
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(ushort *)(param_3 + 0x160) = *(ushort *)(param_3 + 0x160) & 0xfffb;
  (**(code **)(*(longlong *)(param_3 + 8) + 0x18))(param_3,4);
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  FUN_140544a50(param_3,0x42,0);
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_140545030  @140545030  [medium:callgraph-r2]  (orig: FUN_140545030)
void FUN_140545030(undefined8 *param_1)

{
  FUN_14053d280(param_1 + 2,*param_1,0xffffffffffffffff,0x40,FUN_140544f30,param_1);
  FUN_14053d280(param_1 + 0x11,*param_1,0xffffffffffffffff,0x40,FUN_140544fb0,param_1);
  return;
}

// ==== CCrossSvrClient::helper_1405450a0  @1405450a0  [medium:callgraph-r2]  (orig: FUN_1405450a0)
void FUN_1405450a0(undefined8 param_1,longlong param_2)

{
  short sVar1;
  undefined4 uVar2;
  
  if (*(longlong *)(param_2 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if (((char)*(ushort *)(param_2 + 0x174) < '\0') && (*(longlong *)(param_2 + 0x140) != 0)) {
    *(ushort *)(param_2 + 0x174) = *(ushort *)(param_2 + 0x174) & 0xff7f;
    (**(code **)(param_2 + 0x140))(param_2,0x80,*(undefined8 *)(param_2 + 0x148));
  }
  if (((*(uint *)(param_2 + 0x170) & 2) != 0) && (*(longlong *)(param_2 + 0x130) != 0)) {
    *(uint *)(param_2 + 0x170) = *(uint *)(param_2 + 0x170) & 0xfffffffd;
    (**(code **)(param_2 + 0x130))(param_2,*(undefined8 *)(param_2 + 0x148));
  }
  if (((*(uint *)(param_2 + 0x170) & 4) != 0) && (*(longlong *)(param_2 + 0x138) != 0)) {
    *(uint *)(param_2 + 0x170) = *(uint *)(param_2 + 0x170) & 0xfffffffb;
    (**(code **)(param_2 + 0x138))(param_2,*(undefined8 *)(param_2 + 0x148));
  }
  sVar1 = *(short *)(param_2 + 0x174);
  if ((sVar1 != 0) && (*(longlong *)(param_2 + 0x140) != 0)) {
    uVar2 = *(undefined4 *)(param_2 + 0x17c);
    *(undefined2 *)(param_2 + 0x174) = 0;
    *(undefined4 *)(param_2 + 0x17c) = 0;
    Ordinal_112(uVar2);
    (**(code **)(param_2 + 0x140))(param_2,sVar1,*(undefined8 *)(param_2 + 0x148));
  }
  FUN_140544d50(param_2);
  return;
}

// ==== CCrossSvrClient::helper_1405451b0  @1405451b0  [medium:callgraph-r2]  (orig: FUN_1405451b0)
void FUN_1405451b0(undefined8 param_1,longlong param_2)

{
  short sVar1;
  undefined4 uVar2;
  code *pcVar3;
  undefined8 uVar4;
  
  if (*(longlong *)(param_2 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if (((char)*(ushort *)(param_2 + 0x174) < '\0') &&
     (pcVar3 = *(code **)(param_2 + 0x140), pcVar3 != (code *)0x0)) {
    uVar4 = *(undefined8 *)(param_2 + 0x148);
    *(ushort *)(param_2 + 0x174) = *(ushort *)(param_2 + 0x174) & 0xff7f;
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f200(0);
    }
    (*pcVar3)(param_2,0x80,uVar4);
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
  }
  if (((*(uint *)(param_2 + 0x170) & 2) != 0) &&
     (pcVar3 = *(code **)(param_2 + 0x130), pcVar3 != (code *)0x0)) {
    uVar4 = *(undefined8 *)(param_2 + 0x148);
    *(uint *)(param_2 + 0x170) = *(uint *)(param_2 + 0x170) & 0xfffffffd;
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f200(0);
    }
    (*pcVar3)(param_2,uVar4);
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
  }
  if (((*(uint *)(param_2 + 0x170) & 4) != 0) &&
     (pcVar3 = *(code **)(param_2 + 0x138), pcVar3 != (code *)0x0)) {
    uVar4 = *(undefined8 *)(param_2 + 0x148);
    *(uint *)(param_2 + 0x170) = *(uint *)(param_2 + 0x170) & 0xfffffffb;
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f200(0);
    }
    (*pcVar3)(param_2,uVar4);
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
  }
  sVar1 = *(short *)(param_2 + 0x174);
  if ((sVar1 != 0) && (pcVar3 = *(code **)(param_2 + 0x140), pcVar3 != (code *)0x0)) {
    uVar2 = *(undefined4 *)(param_2 + 0x17c);
    uVar4 = *(undefined8 *)(param_2 + 0x148);
    *(undefined2 *)(param_2 + 0x174) = 0;
    *(undefined4 *)(param_2 + 0x17c) = 0;
    Ordinal_112(uVar2);
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f200(0);
    }
    (*pcVar3)(param_2,sVar1,uVar4);
    if (*(longlong *)(param_2 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
  }
  FUN_140544d50(param_2);
  return;
}

// ==== CCrossSvrClient::helper_140545430  @140545430  [medium:callgraph-r1]  (orig: FUN_140545430)
undefined8 FUN_140545430(undefined8 *param_1,undefined8 param_2,undefined8 param_3,uint param_4)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  code *pcVar4;
  
  if (param_1[0x20] == 0) {
    lVar2 = FUN_14054a290();
    param_1[0x20] = lVar2;
    if (lVar2 != 0) goto LAB_14054546b;
LAB_140545492:
    uVar3 = 0xffffffff;
  }
  else {
LAB_14054546b:
    if (param_1[0x21] == 0) {
      lVar2 = FUN_14054a290();
      param_1[0x21] = lVar2;
      if (lVar2 == 0) {
        FUN_14054a710(param_1[0x20]);
        goto LAB_140545492;
      }
    }
    *(undefined4 *)((longlong)param_1 + 0x1b4) = 1;
    *param_1 = param_2;
    param_1[1] = param_3;
    *(undefined4 *)((longlong)param_1 + 0x154) = 0;
    *(undefined4 *)(param_1 + 0x2a) = 0;
    *(undefined4 *)((longlong)param_1 + 0x15c) = 0;
    *(undefined4 *)(param_1 + 0x2b) = 0;
    FUN_140553430(param_1);
    *(undefined2 *)(param_1 + 0x2c) = 4;
    if (((param_4 & 2) == 0) || (iVar1 = FUN_140544be0(param_1,0), -1 < iVar1)) {
      if (((byte)param_4 & 0xc) == 8) {
        FUN_14054f8b0("UNLOCK_CALLBACKS requires DEFER_CALLBACKS");
        uVar3 = 0xffffffff;
      }
      else {
        if ((param_4 & 8) == 0) {
          iVar1 = FUN_14053ceb0(param_2);
          pcVar4 = FUN_1405450a0;
        }
        else {
          iVar1 = FUN_14053ceb0(param_2);
          pcVar4 = FUN_1405451b0;
        }
        FUN_14053d6e0(param_1 + 0x31,iVar1 / 2,pcVar4,param_1);
        *(uint *)(param_1 + 0x36) = param_4;
        FUN_14054a420(param_1[0x20],param_1);
        FUN_14054a420(param_1[0x21],param_1);
        uVar3 = 0;
      }
    }
    else {
      FUN_14054a710(param_1[0x20]);
      FUN_14054a710(param_1[0x21]);
      param_1[0x20] = 0;
      param_1[0x21] = 0;
      uVar3 = 0xffffffff;
    }
  }
  return uVar3;
}

// ==== CCrossSvrClient::helper_1405455c0  @1405455c0  [medium:callgraph-r1]  (orig: FUN_1405455c0)
undefined4 FUN_1405455c0(longlong param_1,ushort param_2)

{
  int iVar1;
  undefined4 uVar2;
  ushort uVar3;
  
  uVar2 = 0;
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  *(int *)(param_1 + 0x1b4) = *(int *)(param_1 + 0x1b4) + 1;
  uVar3 = param_2;
  if (*(short *)(param_1 + 0x176) != 0) {
    uVar3 = param_2 & 0xfffd;
  }
  if (*(short *)(param_1 + 0x178) != 0) {
    uVar3 = uVar3 & 0xfffb;
  }
  *(ushort *)(param_1 + 0x160) = *(ushort *)(param_1 + 0x160) | param_2;
  if (uVar3 != 0) {
    iVar1 = (**(code **)(*(longlong *)(param_1 + 8) + 0x10))(param_1,uVar3);
    uVar2 = 0;
    if (iVar1 < 0) {
      uVar2 = 0xffffffff;
    }
  }
  FUN_140544d50(param_1);
  return uVar2;
}

// ==== CCrossSvrClient::helper_1405459d0  @1405459d0  [medium:callgraph-r1]  (orig: FUN_1405459d0)
undefined8 FUN_1405459d0(ulonglong *param_1,undefined2 *param_2,undefined4 param_3)

{
  bool bVar1;
  int iVar2;
  ulonglong uVar3;
  undefined4 local_res8 [2];
  
  bVar1 = false;
  if ((longlong)*param_1 < 0) {
    uVar3 = Ordinal_23(*param_2,1,0);
    *param_1 = uVar3;
    if ((longlong)uVar3 < 0) {
      return 0xffffffff;
    }
    bVar1 = true;
    local_res8[0] = 1;
    iVar2 = Ordinal_10(uVar3,0x8004667e,local_res8);
    if (iVar2 == -1) {
      FUN_14054f810(uVar3,"fcntl(%d, F_GETFL)",uVar3 & 0xffffffff);
      goto LAB_140545a8e;
    }
  }
  iVar2 = Ordinal_4(*param_1,param_2,param_3);
  if (-1 < iVar2) {
    return 1;
  }
  iVar2 = FUN_140545950(*param_1);
  if ((((iVar2 == 0x2733) || (iVar2 == 0x2714)) || (iVar2 == 0x2734)) || (iVar2 == 0x2726)) {
    return 0;
  }
  if (iVar2 == 0x274d) {
    return 2;
  }
  if (!bVar1) {
    return 0xffffffff;
  }
LAB_140545a8e:
  Ordinal_3(*param_1);
  *param_1 = 0xffffffffffffffff;
  return 0xffffffff;
}

// ==== CCrossSvrClient::helper_140545ac0  @140545ac0  [medium:callgraph-r2]  (orig: FUN_140545ac0)
undefined8 FUN_140545ac0(undefined8 param_1)

{
  int iVar1;
  undefined4 local_res10 [2];
  int local_res18 [4];
  
  local_res10[0] = 4;
  iVar1 = Ordinal_7(param_1,0xffff,0x1007,local_res18,local_res10);
  if (-1 < iVar1) {
    if (local_res18[0] == 0) {
      return 1;
    }
    if ((((local_res18[0] == 0x2733) || (local_res18[0] == 0x2714)) || (local_res18[0] == 0x2734))
       || (local_res18[0] == 0x2726)) {
      return 0;
    }
    Ordinal_112();
  }
  return 0xffffffff;
}

// ==== CCrossSvrClient::helper_140548ea0  @140548ea0  [medium:callgraph-r3]  (orig: FUN_140548ea0)
char * FUN_140548ea0(uint param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  uint uVar6;
  DWORD DVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  char *pcVar10;
  char *local_res10 [3];
  
  local_res10[0] = (char *)0x0;
  if (DAT_140976d70 != 0) {
    FUN_14054f1e0(0);
  }
  if (DAT_140970800 != 0) {
    uVar6 = (param_1 >> 0x10 ^ param_1) * -0x7a143595;
    uVar6 = (uVar6 >> 0xd ^ uVar6) * -0x3d4d51cb;
    uVar9 = (ulonglong)(uVar6 >> 0x10 ^ uVar6) % (ulonglong)DAT_140970808;
    plVar5 = *(longlong **)(DAT_140970800 + uVar9 * 8);
    plVar3 = (longlong *)(DAT_140970800 + uVar9 * 8);
    while ((plVar2 = plVar5, plVar2 != (longlong *)0x0 && (*(uint *)(plVar2 + 1) != param_1))) {
      plVar3 = plVar2;
      plVar5 = (longlong *)*plVar2;
    }
    if (*plVar3 != 0) {
      local_res10[0] = *(char **)(*plVar3 + 0x10);
      goto LAB_140549096;
    }
  }
  DVar7 = FormatMessageA(0x1300,(LPCVOID)0x0,param_1,0,(LPSTR)local_res10,0,(va_list *)0x0);
  if (DVar7 == 0) {
    local_res10[0] = LocalAlloc(0,0x32);
    if (local_res10[0] == (char *)0x0) {
      local_res10[0] = "LocalAlloc failed during Winsock error";
      goto LAB_140549096;
    }
    FUN_140547660(local_res10[0],0x32,"winsock error 0x%08x",param_1);
  }
  else if (local_res10[0] != (char *)0x0) {
    uVar9 = 0xffffffffffffffff;
    pcVar10 = local_res10[0];
    do {
      if (uVar9 == 0) break;
      uVar9 = uVar9 - 1;
      cVar1 = *pcVar10;
      pcVar10 = pcVar10 + 1;
    } while (cVar1 != '\0');
    uVar9 = ~uVar9;
    if ((((uVar9 != 1) && (local_res10[0][uVar9 - 2] == '\n')) &&
        (local_res10[0][uVar9 - 2] = '\0', uVar9 - 2 != 0)) && (local_res10[0][uVar9 - 3] == '\r'))
    {
      local_res10[0][uVar9 - 3] = '\0';
    }
  }
  puVar8 = (undefined8 *)FUN_14053dc70(0x18);
  if (puVar8 == (undefined8 *)0x0) {
    LocalFree(local_res10[0]);
    local_res10[0] = "malloc failed during Winsock error";
  }
  else {
    *(uint *)(puVar8 + 1) = param_1;
    puVar8[2] = local_res10[0];
    if ((DAT_140970800 == 0) || (DAT_140970810 <= DAT_14097080c)) {
      FUN_140546420(&DAT_140970800,DAT_14097080c + 1);
    }
    lVar4 = DAT_140970800;
    DAT_14097080c = DAT_14097080c + 1;
    uVar6 = (*(uint *)(puVar8 + 1) >> 0x10 ^ *(uint *)(puVar8 + 1)) * -0x7a143595;
    uVar6 = (uVar6 >> 0xd ^ uVar6) * -0x3d4d51cb;
    uVar9 = (ulonglong)(uVar6 >> 0x10 ^ uVar6) % (ulonglong)DAT_140970808;
    *puVar8 = *(undefined8 *)(DAT_140970800 + uVar9 * 8);
    *(undefined8 **)(lVar4 + uVar9 * 8) = puVar8;
  }
LAB_140549096:
  if (DAT_140976d70 != 0) {
    FUN_14054f200(0);
  }
  return local_res10[0];
}

// ==== CCrossSvrClient::helper_1405493e0  @1405493e0  [medium:callgraph-r1]  (orig: FUN_1405493e0)
void FUN_1405493e0(undefined8 param_1,longlong param_2,longlong param_3)

{
  int iVar1;
  
  if ((((*(longlong *)(param_2 + 8) != 0) && ((*(byte *)(param_3 + 0x160) & 4) != 0)) &&
      (iVar1 = FUN_14053d440(param_3 + 0x88,4,0), iVar1 == 0)) && (*(short *)(param_3 + 0x178) == 0)
     ) {
    FUN_1405448f0(param_3 + 0x88,param_3 + 0x158);
  }
  return;
}

// ==== CCrossSvrClient::helper_140549440  @140549440  [medium:callgraph-r1]  (orig: FUN_140549440)
void FUN_140549440(undefined8 param_1,short param_2,longlong param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  int iVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined2 uVar6;
  
  uVar6 = 1;
  uVar5 = 0xffffffffffffffff;
  FUN_1405444f0(param_3);
  if (param_2 == 1) {
    uVar6 = 0x41;
  }
  else {
    uVar1 = *(undefined8 *)(param_3 + 0x100);
    if (*(longlong *)(param_3 + 0x118) != 0) {
      lVar2 = FUN_14054a780(uVar1);
      uVar5 = *(longlong *)(param_3 + 0x118) - lVar2;
      if ((longlong)uVar5 < 1) {
        FUN_140543c00(param_3,1);
        goto LAB_140549570;
      }
    }
    uVar4 = FUN_140553600(param_3);
    if (((longlong)uVar5 < 0) || ((longlong)uVar4 < (longlong)uVar5)) {
      uVar5 = uVar4;
    }
    if (*(short *)(param_3 + 0x176) != 0) goto LAB_140549570;
    FUN_14054bdb0(uVar1,0);
    iVar3 = FUN_14054d220(uVar1,param_1,uVar5 & 0xffffffff);
    FUN_14054bd60(uVar1,0);
    if (iVar3 == -1) {
      iVar3 = FUN_140545950(param_1);
      if ((iVar3 == 0x2733) || (iVar3 == 0x2714)) goto LAB_140549570;
      uVar6 = 0x21;
    }
    else if (iVar3 == 0) {
      uVar6 = 0x11;
    }
    else if (0 < iVar3) {
      FUN_1405537a0(param_3,(longlong)iVar3);
      uVar5 = FUN_14054a780(*(undefined8 *)(param_3 + 0x100));
      if (*(ulonglong *)(param_3 + 0x110) <= uVar5) {
        FUN_140544950(param_3,0);
      }
      goto LAB_140549570;
    }
  }
  FUN_140544200(param_3,2);
  FUN_140544a50(param_3,uVar6,0);
LAB_140549570:
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_140549590  @140549590  [medium:callgraph-r1]  (orig: FUN_140549590)
void FUN_140549590(undefined8 param_1,short param_2,longlong param_3)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined2 uVar7;
  
  iVar3 = 0;
  uVar7 = 2;
  bVar1 = false;
  FUN_1405444f0(param_3);
  if (param_2 == 1) {
    uVar7 = 0x42;
    goto LAB_140549755;
  }
  if ((*(byte *)(param_3 + 0x170) & 8) != 0) {
    iVar2 = FUN_140545ac0(param_1);
    if ((*(uint *)(param_3 + 0x170) & 0x10) == 0) {
      if (iVar2 == 0) goto LAB_1405497c2;
    }
    else {
      iVar2 = -1;
      *(uint *)(param_3 + 0x170) = *(uint *)(param_3 + 0x170) & 0xffffffef;
    }
    *(uint *)(param_3 + 0x170) = *(uint *)(param_3 + 0x170) & 0xfffffff7;
    if (iVar2 < 0) {
      FUN_140540740(param_3 + 0x88);
      FUN_140540740(param_3 + 0x10);
      FUN_140544a50(param_3,0x20,0);
      goto LAB_1405497c2;
    }
    bVar1 = true;
    if (*(undefined ***)(param_3 + 8) == &PTR_s_socket_async_1407b4720) {
      FUN_140540740(param_3 + 0x88);
      FUN_1405c7a80(param_3);
      FUN_140544a50(param_3,0x80,0);
      goto LAB_1405497c2;
    }
    FUN_140544a50(param_3,0x80,0);
    if (((*(byte *)(param_3 + 0x160) & 4) != 0) && (*(short *)(param_3 + 0x178) == 0))
    goto LAB_1405496a5;
LAB_14054973e:
    FUN_140540740(param_3 + 0x88);
    goto LAB_1405497c2;
  }
LAB_1405496a5:
  uVar4 = FUN_1405536d0(param_3);
  if (*(short *)(param_3 + 0x178) != 0) goto LAB_1405497c2;
  lVar5 = FUN_14054a780(*(undefined8 *)(param_3 + 0x108));
  if (lVar5 == 0) {
LAB_14054977d:
    lVar5 = FUN_14054a780(*(undefined8 *)(param_3 + 0x108));
    if (lVar5 == 0) {
      FUN_140540740(param_3 + 0x88);
    }
    if ((iVar3 != 0) || (!bVar1)) {
      uVar6 = FUN_14054a780(*(undefined8 *)(param_3 + 0x108));
      if (uVar6 <= *(ulonglong *)(param_3 + 0x120)) {
        FUN_1405449d0(param_3,0);
      }
    }
  }
  else {
    FUN_14054bdb0(*(undefined8 *)(param_3 + 0x108),1);
    iVar3 = FUN_14054d540(*(undefined8 *)(param_3 + 0x108),param_1,uVar4);
    FUN_14054bd60(*(undefined8 *)(param_3 + 0x108),1);
    if (iVar3 == -1) {
      iVar3 = FUN_140545950(param_1);
      if ((iVar3 == 0x2733) || (iVar3 == 0x2714)) {
        lVar5 = FUN_14054a780(*(undefined8 *)(param_3 + 0x108));
        if (lVar5 != 0) goto LAB_1405497c2;
        goto LAB_14054973e;
      }
      uVar7 = 0x22;
    }
    else {
      if (iVar3 == 0) {
        uVar7 = 0x12;
      }
      if (0 < iVar3) {
        FUN_1405538e0(param_3,(longlong)iVar3);
        goto LAB_14054977d;
      }
    }
LAB_140549755:
    FUN_140544200(param_3,4);
    FUN_140544a50(param_3,uVar7,0);
  }
LAB_1405497c2:
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_1405497f0  @1405497f0  [medium:callgraph-r0]  (orig: FUN_1405497f0)
undefined8 * FUN_1405497f0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  if ((param_1 != 0) && (lVar2 = FUN_1405c7060(), lVar2 != 0)) {
    puVar3 = (undefined8 *)FUN_1405c7e80(param_1,param_2,param_3);
    return puVar3;
  }
  puVar3 = (undefined8 *)FUN_14053dc90(1,0x1d8);
  if (puVar3 != (undefined8 *)0x0) {
    iVar1 = FUN_140545430(puVar3,param_1,&PTR_s_socket_1407a19d0,param_3);
    if (-1 < iVar1) {
      FUN_14054a2d0(puVar3[0x21],1);
      FUN_14053d280(puVar3 + 2,*puVar3,param_2,0x52,FUN_140549440,puVar3);
      FUN_14053d280(puVar3 + 0x11,*puVar3,param_2,0x54,FUN_140549590,puVar3);
      FUN_14054baf0(puVar3[0x21],FUN_1405493e0,puVar3);
      FUN_14054bd60(puVar3[0x20],0);
      FUN_14054bd60(puVar3[0x21],1);
      return puVar3;
    }
    FUN_14053de00(puVar3);
  }
  return (undefined8 *)0x0;
}

// ==== CCrossSvrClient::helper_140549e00  @140549e00  [medium:callgraph-r0]  (orig: FUN_140549e00)
undefined4 FUN_140549e00(undefined8 *param_1,undefined2 *param_2,undefined4 param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong local_res8;
  
  iVar2 = 0;
  uVar3 = 0xffffffff;
  bVar1 = false;
  FUN_1405444f0();
  uVar4 = 0xffffffff;
  if (param_1 == (undefined8 *)0x0) goto LAB_140549f8e;
  local_res8 = FUN_140544610(param_1);
  uVar4 = uVar3;
  if (local_res8 < 0) {
    if ((param_2 == (undefined2 *)0x0) ||
       (local_res8 = FUN_140547060(*param_2,0x4000001,0), local_res8 < 0)) goto LAB_140549f8e;
    bVar1 = true;
  }
  if (param_2 == (undefined2 *)0x0) {
LAB_140549efe:
    if ((undefined **)param_1[1] == &PTR_s_socket_async_1407b4720) {
      FUN_14053d280(param_1 + 0x11,*param_1,local_res8,0x54,FUN_140549590,param_1);
    }
    FUN_1405445a0(param_1,local_res8);
    if (iVar2 == 0) {
      iVar2 = FUN_1405448f0(param_1 + 0x11,param_1 + 0x2b);
      if (iVar2 != -1) {
        *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 8;
        uVar4 = 0;
      }
    }
    else {
      uVar4 = 0;
      if (iVar2 == 1) {
        *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 8;
      }
      else {
        *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 0x18;
      }
      FUN_140540bd0(param_1 + 0x11,4);
    }
  }
  else {
    iVar2 = FUN_1405c7ac0(param_1);
    if (iVar2 == 0) {
      iVar2 = FUN_1405459d0(&local_res8,param_2,param_3);
      if (-1 < iVar2) goto LAB_140549efe;
    }
    else {
      FUN_1405445a0(param_1,local_res8);
      iVar2 = FUN_1405c7b20(param_1,local_res8,param_2,param_3);
      if (-1 < iVar2) {
        *(uint *)(param_1 + 0x2e) = *(uint *)(param_1 + 0x2e) | 8;
        uVar4 = 0;
        goto LAB_140549f8e;
      }
    }
    FUN_140544a50(param_1,0x20,0);
    if (bVar1) {
      Ordinal_3(local_res8);
    }
  }
LAB_140549f8e:
  FUN_140544d50(param_1);
  return uVar4;
}

// ==== CCrossSvrClient::helper_14054a290  @14054a290  [medium:callgraph-r2]  (orig: FUN_14054a290)
void FUN_14054a290(void)

{
  longlong lVar1;
  
  lVar1 = FUN_14053dc90(1,0x88);
  if (lVar1 == 0) {
    return;
  }
  *(undefined8 *)(lVar1 + 0x78) = 0;
  *(undefined4 *)(lVar1 + 0x48) = 1;
  *(longlong *)(lVar1 + 0x10) = lVar1;
  return;
}

// ==== CCrossSvrClient::helper_14054a2d0  @14054a2d0  [medium:callgraph-r1]  (orig: FUN_14054a2d0)
undefined8 FUN_14054a2d0(longlong param_1,uint param_2)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  *(uint *)(param_1 + 0x3c) = *(uint *)(param_1 + 0x3c) | param_2;
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_14054a3d0  @14054a3d0  [medium:callgraph-r3]  (orig: FUN_14054a3d0)
undefined8 FUN_14054a3d0(longlong param_1,longlong param_2)

{
  longlong lVar1;
  
  if (*(longlong *)(param_1 + 0x30) == 0) {
    if (param_2 != 0) {
      *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) & 0xfffffffe;
      *(longlong *)(param_1 + 0x30) = param_2;
      return 0;
    }
    lVar1 = FUN_14054f1a0(1);
    if (lVar1 != 0) {
      *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) | 1;
      *(longlong *)(param_1 + 0x30) = lVar1;
      return 0;
    }
  }
  return 0xffffffff;
}

// ==== CCrossSvrClient::helper_14054a420  @14054a420  [medium:callgraph-r2]  (orig: FUN_14054a420)
void FUN_14054a420(longlong param_1,undefined8 param_2)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  *(undefined8 *)(param_1 + 0x80) = param_2;
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CCrossSvrClient::helper_14054a470  @14054a470  [medium:callgraph-r3]  (orig: FUN_14054a470)
void FUN_14054a470(longlong param_1,int param_2)

{
  longlong lVar1;
  longlong *plVar2;
  bool bVar3;
  uint uVar4;
  uint uVar5;
  longlong *plVar6;
  longlong local_38;
  longlong local_30;
  longlong local_28;
  
  bVar3 = true;
  if (param_2 == 0) {
    if ((*(byte *)(param_1 + 0x38) & 8) == 0) {
      uVar5 = 1;
      uVar4 = 1;
    }
    else {
      uVar5 = 3;
      bVar3 = false;
      uVar4 = 3;
    }
  }
  else {
    uVar5 = 3;
    uVar4 = 1;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f2a0();
  }
  plVar6 = *(longlong **)(param_1 + 0x78);
  if (plVar6 == (longlong *)0x0) {
    *(undefined8 *)(param_1 + 0x28) = 0;
    *(undefined8 *)(param_1 + 0x20) = 0;
  }
  else {
    local_30 = *(longlong *)(param_1 + 0x20);
    if ((local_30 != 0) || (*(longlong *)(param_1 + 0x28) != 0)) {
      local_28 = *(longlong *)(param_1 + 0x28);
      lVar1 = *(longlong *)(param_1 + 0x18);
      local_38 = (local_28 - local_30) + lVar1;
      if (bVar3) {
        *(undefined8 *)(param_1 + 0x20) = 0;
        *(undefined8 *)(param_1 + 0x28) = 0;
      }
      do {
        plVar2 = (longlong *)*plVar6;
        if ((*(uint *)(plVar6 + 4) & uVar5) == uVar4) {
          if ((*(uint *)(plVar6 + 4) >> 0x12 & 1) == 0) {
            (*(code *)plVar6[2])(param_1,&local_38,plVar6[3]);
          }
          else {
            (*(code *)plVar6[2])(param_1,local_38,lVar1,plVar6[3]);
          }
        }
        plVar6 = plVar2;
      } while (plVar2 != (longlong *)0x0);
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_14054a570  @14054a570  [medium:callgraph-r3]  (orig: FUN_14054a570)
void FUN_14054a570(longlong param_1)

{
  int iVar1;
  
  if (*(longlong *)(param_1 + 0x78) == 0) {
    *(undefined8 *)(param_1 + 0x28) = 0;
    *(undefined8 *)(param_1 + 0x20) = 0;
    return;
  }
  if ((*(byte *)(param_1 + 0x38) & 8) != 0) {
    iVar1 = FUN_14053f050(*(undefined8 *)(param_1 + 0x40),param_1 + 0x50);
    if (iVar1 != 0) {
      if (*(longlong *)(param_1 + 0x30) != 0) {
        FUN_14054f1e0(0);
      }
      *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 1;
      if (*(longlong *)(param_1 + 0x80) != 0) {
        FUN_140544560();
      }
    }
    if (*(longlong *)(param_1 + 0x30) != 0) {
      FUN_14054f200(0);
    }
  }
  FUN_14054a470(param_1,0);
  return;
}

// ==== CCrossSvrClient::helper_14054a630  @14054a630  [medium:callgraph-r3]  (orig: FUN_14054a630)
void FUN_14054a630(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  
  if (param_1[6] != 0) {
    FUN_14054f2a0();
  }
  *(int *)(param_1 + 9) = *(int *)(param_1 + 9) + -1;
  if (*(int *)(param_1 + 9) < 1) {
    puVar1 = (undefined8 *)*param_1;
    while (puVar1 != (undefined8 *)0x0) {
      puVar1 = (undefined8 *)*puVar1;
      FUN_14054be80();
    }
    plVar2 = (longlong *)param_1[0xf];
    while (plVar2 != (longlong *)0x0) {
      if (*plVar2 != 0) {
        *(longlong *)(*plVar2 + 8) = plVar2[1];
      }
      *(longlong *)plVar2[1] = *plVar2;
      FUN_14053de00();
      plVar2 = (longlong *)param_1[0xf];
    }
    if ((*(byte *)(param_1 + 7) & 8) != 0) {
      FUN_140540d30(param_1[8],param_1 + 10);
    }
    if (param_1[6] != 0) {
      FUN_14054f200(0);
    }
    if (((*(byte *)(param_1 + 7) & 1) != 0) && (param_1[6] != 0)) {
      FUN_14054f1c0(param_1[6],1);
    }
    FUN_14053de00(param_1);
  }
  else if (param_1[6] != 0) {
    FUN_14054f200(0);
    return;
  }
  return;
}

// ==== CCrossSvrClient::helper_14054a710  @14054a710  [medium:callgraph-r2]  (orig: FUN_14054a710)
void FUN_14054a710(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  FUN_14054a630(param_1);
  return;
}

// ==== CCrossSvrClient::helper_14054a780  @14054a780  [medium:callgraph-r0]  (orig: FUN_14054a780)
undefined8 FUN_14054a780(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = *(undefined8 *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

// ==== CCrossSvrClient::helper_14054ad60  @14054ad60  [medium:callgraph-r2]  (orig: FUN_14054ad60)
ulonglong FUN_14054ad60(longlong *param_1,longlong *param_2,void *param_3,ulonglong param_4)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong _Size;
  undefined8 *puVar3;
  ulonglong uVar4;
  ulonglong _Size_00;
  
  if (param_1[6] != 0) {
    FUN_14054f1e0(0);
  }
  if (param_2 == (longlong *)0x0) {
    puVar3 = (undefined8 *)*param_1;
    uVar2 = 0;
    if ((ulonglong)param_1[3] < param_4) {
      param_4 = param_1[3];
    }
  }
  else {
    lVar1 = *param_2;
    if (0x7fffffffffffffffU - lVar1 < param_4) {
      uVar4 = 0xffffffffffffffff;
      goto LAB_14054ae66;
    }
    puVar3 = (undefined8 *)param_2[1];
    uVar2 = param_2[2];
    if ((ulonglong)param_1[3] < lVar1 + param_4) {
      param_4 = param_1[3] - lVar1;
    }
  }
  uVar4 = 0;
  if (param_4 != 0) {
    _Size_00 = param_4;
    if ((*(byte *)(param_1 + 7) & 2) == 0) {
      do {
        _Size = puVar3[3] - uVar2;
        uVar4 = param_4;
        if (_Size_00 < _Size) {
          if (_Size_00 != 0) {
            memcpy(param_3,(void *)(puVar3[5] + puVar3[2] + uVar2),_Size_00);
          }
          break;
        }
        memcpy(param_3,(void *)(puVar3[5] + puVar3[2] + uVar2),_Size);
        puVar3 = (undefined8 *)*puVar3;
        param_3 = (void *)((longlong)param_3 + _Size);
        _Size_00 = _Size_00 - _Size;
        uVar2 = 0;
      } while (_Size_00 != 0);
    }
    else {
      uVar4 = 0xffffffffffffffff;
    }
  }
LAB_14054ae66:
  if (param_1[6] != 0) {
    FUN_14054f200(0);
  }
  return uVar4;
}

// ==== CCrossSvrClient::helper_14054b2f0  @14054b2f0  [medium:callgraph-r3]  (orig: FUN_14054b2f0)
undefined4 FUN_14054b2f0(longlong *param_1,undefined8 param_2,ulonglong param_3)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  longlong lVar3;
  longlong *plVar4;
  int iVar5;
  undefined4 local_res8 [2];
  undefined4 local_108 [2];
  longlong local_100 [31];
  
  plVar4 = (longlong *)*param_1;
  iVar5 = 0;
  if ((longlong)param_3 < 0) {
    uVar1 = 0xffffffff;
  }
  else {
    if (param_1[6] != 0) {
      FUN_14054f2a0();
    }
    lVar3 = 0;
    if (plVar4 != (longlong *)0x0) {
      puVar2 = local_108;
      do {
        if ((0xf < lVar3) || (param_3 == 0)) break;
        *(longlong *)(puVar2 + 2) = plVar4[5] + plVar4[2];
        if (param_3 < (ulonglong)plVar4[3]) {
          lVar3 = (longlong)iVar5;
          iVar5 = iVar5 + 1;
          local_108[lVar3 * 4] = (int)param_3;
          break;
        }
        iVar5 = iVar5 + 1;
        lVar3 = lVar3 + 1;
        *puVar2 = (int)plVar4[3];
        param_3 = param_3 - plVar4[3];
        plVar4 = (longlong *)*plVar4;
        puVar2 = puVar2 + 4;
      } while (plVar4 != (longlong *)0x0);
      if (iVar5 != 0) {
        iVar5 = WSASend(param_2,local_108,iVar5,local_res8,0,0,0);
        if (iVar5 == 0) {
          return local_res8[0];
        }
        return 0xffffffff;
      }
    }
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CCrossSvrClient::helper_14054baf0  @14054baf0  [medium:callgraph-r1]  (orig: FUN_14054baf0)
longlong * FUN_14054baf0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)FUN_14053dc90(1);
  if (plVar3 != (longlong *)0x0) {
    if (*(longlong *)(param_1 + 0x30) != 0) {
      FUN_14054f1e0(0);
    }
    plVar1 = (longlong *)(param_1 + 0x78);
    plVar3[2] = param_2;
    plVar3[3] = param_3;
    *(undefined4 *)(plVar3 + 4) = 1;
    lVar2 = *plVar1;
    *plVar3 = lVar2;
    if (lVar2 != 0) {
      *(longlong **)(*plVar1 + 8) = plVar3;
    }
    *plVar1 = (longlong)plVar3;
    plVar3[1] = (longlong)plVar1;
    if (*(longlong *)(param_1 + 0x30) != 0) {
      FUN_14054f200(0);
    }
  }
  return plVar3;
}

// ==== CCrossSvrClient::helper_14054bd60  @14054bd60  [medium:callgraph-r1]  (orig: FUN_14054bd60)
undefined8 FUN_14054bd60(longlong param_1,int param_2)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  if (param_2 == 0) {
    *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) | 4;
  }
  else {
    *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) | 2;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_14054bdb0  @14054bdb0  [medium:callgraph-r2]  (orig: FUN_14054bdb0)
undefined8 FUN_14054bdb0(longlong param_1,int param_2)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  if (param_2 == 0) {
    *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) & 0xfffffffb;
  }
  else {
    *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) & 0xfffffffd;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_14054be00  @14054be00  [medium:callgraph-r2]  (orig: FUN_14054be00)
undefined8 FUN_14054be00(longlong param_1,longlong *param_2,int param_3)

{
  undefined8 uVar1;
  
  uVar1 = 0;
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  if ((*(byte *)(param_1 + 0x38) & 8) != 0) {
    if (param_3 < 1) {
      uVar1 = 0xffffffff;
    }
    else {
      uVar1 = 1;
      *param_2 = param_1 + 0x50;
    }
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

// ==== CCrossSvrClient::helper_14054be80  @14054be80  [medium:callgraph-r3]  (orig: FUN_14054be80)
void FUN_14054be80(longlong param_1)

{
  uint uVar1;
  
  *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + -1;
  if (*(int *)(param_1 + 0x24) < 1) {
    uVar1 = *(uint *)(param_1 + 0x20);
    if ((uVar1 & 0x30) != 0) {
      *(uint *)(param_1 + 0x20) = uVar1 | 0x40;
      *(int *)(param_1 + 0x24) = *(int *)(param_1 + 0x24) + 1;
      return;
    }
    if (((uVar1 & 4) != 0) && (*(code **)(param_1 + 0x30) != (code *)0x0)) {
      (**(code **)(param_1 + 0x30))
                (*(undefined8 *)(param_1 + 0x28),*(undefined8 *)(param_1 + 8),
                 *(undefined8 *)(param_1 + 0x38));
    }
    if (((*(byte *)(param_1 + 0x20) & 1) != 0) && (*(longlong *)(param_1 + 0x30) != 0)) {
      if ((*(byte *)(*(longlong *)(param_1 + 0x30) + 0x10) & 2) != 0) {
        UnmapViewOfFile(*(LPCVOID *)(param_1 + 0x28));
      }
      FUN_14054ba40(*(undefined8 *)(param_1 + 0x30));
    }
    if ((*(byte *)(param_1 + 0x20) & 0x80) != 0) {
      if (*(longlong *)(*(longlong *)(param_1 + 0x30) + 0x30) != 0) {
        FUN_14054f1e0(0);
      }
      FUN_14054be80(*(undefined8 *)(param_1 + 0x38));
      FUN_14054a630(*(undefined8 *)(param_1 + 0x30));
    }
    FUN_14053de00(param_1);
  }
  return;
}

// ==== CCrossSvrClient::helper_14054c6b0  @14054c6b0  [medium:callgraph-r2]  (orig: FUN_14054c6b0)
undefined8 FUN_14054c6b0(longlong *param_1,ulonglong param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  
  uVar6 = 0;
  if (param_1[6] != 0) {
    FUN_14054f1e0(0);
  }
  uVar5 = param_1[3];
  if (uVar5 != 0) {
    if ((*(byte *)(param_1 + 7) & 2) == 0) {
      if ((param_2 < uVar5) ||
         ((param_1[1] != 0 && (param_2 = uVar5, (*(byte *)(param_1[1] + 0x20) & 0x10) != 0)))) {
        plVar3 = (longlong *)*param_1;
        param_1[3] = uVar5 - param_2;
        plVar4 = plVar3;
        uVar5 = param_2;
        if ((ulonglong)plVar3[3] <= param_2) {
          do {
            uVar5 = uVar5 - plVar3[3];
            plVar4 = (longlong *)*plVar3;
            if (plVar3 == *(longlong **)param_1[2]) {
              param_1[2] = (longlong)param_1;
            }
            if (plVar3 == (longlong *)param_1[2]) {
              param_1[2] = (longlong)param_1;
            }
            if ((*(byte *)(plVar3 + 4) & 0x10) != 0) {
              lVar2 = plVar3[3];
              plVar3[3] = 0;
              plVar3[2] = plVar3[2] + lVar2;
              plVar4 = plVar3;
              break;
            }
            FUN_14054be80();
            plVar3 = plVar4;
          } while ((ulonglong)plVar4[3] <= uVar5);
        }
        *param_1 = (longlong)plVar4;
        plVar4[2] = plVar4[2] + uVar5;
        plVar4[3] = plVar4[3] - uVar5;
        uVar5 = param_2;
      }
      else {
        puVar1 = (undefined8 *)*param_1;
        while (puVar1 != (undefined8 *)0x0) {
          puVar1 = (undefined8 *)*puVar1;
          FUN_14054be80();
        }
        if (param_1[6] != 0) {
          FUN_14054f2a0();
        }
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = (longlong)param_1;
        param_1[3] = 0;
      }
      param_1[5] = param_1[5] + uVar5;
      FUN_14054a570(param_1);
    }
    else {
      uVar6 = 0xffffffff;
    }
  }
  if (param_1[6] != 0) {
    FUN_14054f200(0);
  }
  return uVar6;
}

// ==== CCrossSvrClient::helper_14054c7f0  @14054c7f0  [medium:callgraph-r1]  (orig: FUN_14054c7f0)
ulonglong FUN_14054c7f0(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  int iVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  uVar2 = FUN_14054ad60(param_1,0,param_2,param_3);
  if (0 < (longlong)uVar2) {
    iVar1 = FUN_14054c6b0(param_1,uVar2);
    if (iVar1 < 0) {
      uVar2 = 0xffffffffffffffff;
    }
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return uVar2 & 0xffffffff;
}

// ==== CCrossSvrClient::helper_14054cfe0  @14054cfe0  [medium:callgraph-r3]  (orig: FUN_14054cfe0)
undefined8 FUN_14054cfe0(longlong *param_1,ulonglong param_2,int param_3)

{
  undefined8 *puVar1;
  bool bVar2;
  longlong lVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  int iVar7;
  ulonglong uVar8;
  
  lVar3 = param_1[1];
  if (param_1[6] != 0) {
    FUN_14054f2a0();
  }
  if ((lVar3 == 0) || ((*(byte *)(lVar3 + 0x20) & 8) != 0)) {
    lVar3 = FUN_14054a1d0(param_2);
    if (lVar3 == 0) {
      return 0xffffffff;
    }
    FUN_14054bfc0(param_1,lVar3);
    return 0;
  }
  uVar6 = 0;
  uVar5 = uVar6;
  uVar8 = uVar6;
  for (puVar1 = *(undefined8 **)param_1[2]; iVar7 = (int)uVar8, puVar1 != (undefined8 *)0x0;
      puVar1 = (undefined8 *)*puVar1) {
    if (puVar1[3] == 0) {
      uVar5 = uVar5 + puVar1[1];
      puVar1[2] = 0;
      uVar8 = (ulonglong)(iVar7 + 1);
    }
    else if (((*(byte *)(puVar1 + 4) & 8) == 0) &&
            (lVar3 = (puVar1[1] - puVar1[2]) - puVar1[3], lVar3 != 0)) {
      uVar5 = uVar5 + lVar3;
      uVar8 = (ulonglong)(iVar7 + 1);
    }
    iVar7 = (int)uVar8;
    if (param_2 <= uVar5) goto LAB_14054d09f;
    if (iVar7 == param_3) break;
  }
  if (iVar7 < param_3) {
    lVar3 = FUN_14054a1d0(param_2 - uVar5);
    if (lVar3 == 0) {
      uVar4 = 0xffffffff;
    }
    else {
      *(longlong *)param_1[1] = lVar3;
      param_1[1] = lVar3;
LAB_14054d09f:
      uVar4 = 0;
    }
  }
  else {
    bVar2 = false;
    puVar1 = *(undefined8 **)param_1[2];
    if (puVar1[3] == 0) {
      bVar2 = true;
    }
    else {
      if ((*(byte *)(puVar1 + 4) & 8) == 0) {
        uVar6 = (puVar1[1] - puVar1[2]) - puVar1[3];
      }
      puVar1 = (undefined8 *)*puVar1;
    }
    while (puVar1 != (undefined8 *)0x0) {
      puVar1 = (undefined8 *)*puVar1;
      FUN_14054be80();
    }
    lVar3 = FUN_14054a1d0(param_2 - uVar6);
    if (lVar3 == 0) {
      if (bVar2) {
        if (param_1[6] != 0) {
          FUN_14054f2a0();
        }
        *param_1 = 0;
        param_1[1] = 0;
        param_1[2] = (longlong)param_1;
        param_1[3] = 0;
      }
      else {
        param_1[1] = *(longlong *)param_1[2];
        **(undefined8 **)param_1[2] = 0;
      }
      uVar4 = 0xffffffff;
    }
    else if (bVar2) {
      param_1[1] = lVar3;
      *param_1 = lVar3;
      param_1[2] = (longlong)param_1;
      uVar4 = 0;
    }
    else {
      uVar4 = 0;
      **(longlong **)param_1[2] = lVar3;
      param_1[1] = lVar3;
    }
  }
  return uVar4;
}

// ==== CCrossSvrClient::helper_14054d220  @14054d220  [medium:callgraph-r2]  (orig: FUN_14054d220)
int FUN_14054d220(longlong param_1,undefined8 param_2,int param_3)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong *plVar11;
  uint uVar12;
  ulonglong *puVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  int local_res8;
  undefined4 uStackX_c;
  int local_res20 [2];
  ulonglong local_a8;
  ulonglong local_a0 [7];
  undefined4 local_68 [2];
  undefined8 auStack_60 [7];
  
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  if ((*(byte *)(param_1 + 0x38) & 4) == 0) {
    local_res8 = 0x1000;
    iVar3 = Ordinal_10(param_2,0x4004667f,&local_res8);
    if (((iVar3 < 0) || (local_res8 < 1)) || (iVar3 = local_res8, 0x1000 < local_res8)) {
      iVar3 = 0x1000;
    }
    if ((param_3 < 0) || (iVar3 < param_3)) {
      param_3 = iVar3;
    }
    uVar10 = (ulonglong)param_3;
    iVar3 = FUN_14054cfe0(param_1,uVar10,4);
    if (iVar3 == -1) {
      iVar3 = -1;
    }
    else {
      if (*(longlong *)(param_1 + 0x30) != 0) {
        FUN_14054f2a0();
      }
      uVar15 = 0;
      iVar5 = 0;
      if ((longlong)uVar10 < 0) {
        plVar11 = (longlong *)CONCAT44(uStackX_c,local_res8);
        iVar4 = -1;
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x10);
        if (((*(byte *)(plVar1 + 4) & 8) != 0) ||
           (plVar11 = *(longlong **)(param_1 + 0x10), plVar1[1] - plVar1[3] == plVar1[2])) {
          plVar11 = plVar1;
        }
        puVar8 = (undefined8 *)*plVar11;
        uVar7 = uVar15;
        puVar13 = local_a0;
        uVar14 = uVar15;
        iVar4 = iVar5;
        do {
          if (uVar10 <= uVar7) break;
          uVar6 = uVar15;
          if ((*(byte *)(puVar8 + 4) & 8) == 0) {
            uVar6 = (puVar8[1] - puVar8[3]) - puVar8[2];
          }
          if (uVar10 - uVar7 < uVar6) {
            uVar6 = uVar10 - uVar7;
          }
          lVar9 = puVar8[5];
          uVar14 = uVar14 + 1;
          lVar2 = puVar8[3];
          *puVar13 = uVar6;
          plVar1 = puVar8 + 2;
          puVar8 = (undefined8 *)*puVar8;
          uVar7 = uVar7 + uVar6;
          puVar13[-1] = lVar9 + lVar2 + *plVar1;
          iVar4 = iVar4 + 1;
          puVar13 = puVar13 + 2;
        } while ((longlong)uVar14 < 2);
      }
      lVar9 = (longlong)iVar4;
      uVar10 = uVar15;
      if (0 < iVar4) {
        do {
          lVar9 = lVar9 + -1;
          *(undefined8 *)((longlong)auStack_60 + uVar10) =
               *(undefined8 *)((longlong)local_a0 + (uVar10 - 8));
          *(undefined4 *)((longlong)local_68 + uVar10) =
               *(undefined4 *)((longlong)local_a0 + uVar10);
          uVar10 = uVar10 + 0x10;
        } while (lVar9 != 0);
      }
      local_res8 = 0;
      iVar3 = WSARecv(param_2,local_68,iVar4,local_res20,&local_res8,0,0);
      if (iVar3 == 0) {
        iVar3 = -1;
        if ((local_res20[0] != -1) && (iVar3 = iVar5, local_res20[0] != 0)) {
          uVar10 = uVar15;
          iVar3 = local_res20[0];
          if (0 < iVar4) {
            do {
              lVar9 = *plVar11;
              uVar7 = uVar15;
              if (((*(byte *)(lVar9 + 0x20) & 8) == 0) &&
                 (uVar7 = (*(longlong *)(lVar9 + 8) - *(longlong *)(lVar9 + 0x18)) -
                          *(longlong *)(lVar9 + 0x10), 0x7fffffffffffffff < uVar7)) {
                uVar7 = 0x7fffffffffffffff;
              }
              if ((longlong)iVar3 <= (longlong)uVar7) {
                *(longlong *)(lVar9 + 0x18) = *(longlong *)(lVar9 + 0x18) + (longlong)iVar3;
                *(longlong **)(param_1 + 0x10) = plVar11;
                break;
              }
              *(longlong *)(lVar9 + 0x18) = *(longlong *)(lVar9 + 0x18) + uVar7;
              plVar11 = (longlong *)*plVar11;
              uVar12 = (int)uVar10 + 1;
              uVar10 = (ulonglong)uVar12;
              iVar3 = iVar3 - (int)uVar7;
            } while ((int)uVar12 < iVar4);
          }
          *(longlong *)(param_1 + 0x18) = *(longlong *)(param_1 + 0x18) + (longlong)local_res20[0];
          *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + (longlong)local_res20[0];
          iVar3 = local_res20[0];
          if (*(longlong *)(param_1 + 0x78) == 0) {
            *(undefined8 *)(param_1 + 0x28) = 0;
            *(undefined8 *)(param_1 + 0x20) = 0;
          }
          else {
            if ((*(byte *)(param_1 + 0x38) & 8) != 0) {
              iVar5 = FUN_14053f050(*(undefined8 *)(param_1 + 0x40),param_1 + 0x50);
              if (iVar5 != 0) {
                if (*(longlong *)(param_1 + 0x30) != 0) {
                  FUN_14054f1e0(0);
                }
                *(int *)(param_1 + 0x48) = *(int *)(param_1 + 0x48) + 1;
                if (*(longlong *)(param_1 + 0x80) != 0) {
                  FUN_140544560();
                }
              }
              if (*(longlong *)(param_1 + 0x30) != 0) {
                FUN_14054f200(0);
              }
            }
            FUN_14054a470(param_1,0);
          }
        }
      }
      else {
        iVar4 = Ordinal_111();
        iVar3 = iVar5;
        if (iVar4 != 0x2745) {
          iVar3 = -1;
        }
      }
    }
  }
  else {
    iVar3 = -1;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return iVar3;
}

// ==== CCrossSvrClient::helper_14054d540  @14054d540  [medium:callgraph-r2]  (orig: FUN_14054d540)
ulonglong FUN_14054d540(longlong param_1,undefined8 param_2,ulonglong param_3)

{
  int iVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  uVar2 = 0xffffffff;
  if ((*(byte *)(param_1 + 0x38) & 2) == 0) {
    if (((longlong)param_3 < 0) || (*(ulonglong *)(param_1 + 0x18) < param_3)) {
      param_3 = *(ulonglong *)(param_1 + 0x18);
    }
    uVar2 = 0xffffffff;
    if (0 < (longlong)param_3) {
      iVar1 = FUN_14054b2f0(param_1,param_2,param_3);
      uVar2 = (ulonglong)iVar1;
      if (0 < iVar1) {
        FUN_14054c6b0(param_1,uVar2);
      }
    }
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return uVar2 & 0xffffffff;
}

// ==== CCrossSvrClient::helper_14054f280  @14054f280  [medium:callgraph-r3]  (orig: FUN_14054f280)
undefined8 FUN_14054f280(void)

{
  undefined8 uVar1;
  
  if (DAT_140976dd0 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014054f28c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*DAT_140976dd0)();
    return uVar1;
  }
  return 0;
}

// ==== CCrossSvrClient::helper_14054f810  @14054f810  [medium:callgraph-r2]  (orig: FUN_14054f810)
void FUN_14054f810(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  undefined4 uVar2;
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res18 = param_3;
  local_res20 = param_4;
  uVar2 = FUN_140545950();
  uVar1 = FUN_140548ea0(uVar2);
  FUN_14054f590(2,uVar1,param_2,&local_res18);
  return;
}

// ==== CCrossSvrClient::helper_140552570  @140552570  [medium:callgraph-r3]  (orig: FUN_140552570)
undefined8 FUN_140552570(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  
  lVar1 = *param_1;
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffffb | 1;
  for (; lVar1 != 0; lVar1 = **(longlong **)(lVar1 + 0x1d0)) {
    if (((*(longlong *)(lVar1 + 0x1b8) == 0) || (iVar2 = FUN_14054f1e0(0x10), iVar2 == 0)) &&
       (FUN_140543c00(lVar1,4), *(longlong *)(lVar1 + 0x1b8) != 0)) {
      FUN_14054f200(0);
    }
  }
  return 0;
}

// ==== CCrossSvrClient::helper_1405525f0  @1405525f0  [medium:callgraph-r3]  (orig: FUN_1405525f0)
undefined8 FUN_1405525f0(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  
  lVar1 = *param_1;
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffff7 | 2;
  for (; lVar1 != 0; lVar1 = **(longlong **)(lVar1 + 0x1d0)) {
    if (((*(longlong *)(lVar1 + 0x1b8) == 0) || (iVar2 = FUN_14054f1e0(0x10), iVar2 == 0)) &&
       (FUN_140543ce0(lVar1,4), *(longlong *)(lVar1 + 0x1b8) != 0)) {
      FUN_14054f200(0);
    }
  }
  return 0;
}

// ==== CCrossSvrClient::helper_1405527e0  @1405527e0  [medium:callgraph-r3]  (orig: FUN_1405527e0)
void FUN_1405527e0(longlong *param_1)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffffe;
  iVar4 = 0;
  if ((int)param_1[0xd] == 0) {
    lVar2 = 0;
    lVar3 = lVar2;
  }
  else {
    iVar1 = FUN_140546db0(param_1 + 0x1f);
    lVar2 = *param_1;
    for (; lVar3 = lVar2, iVar1 != 0; iVar1 = iVar1 + -1) {
      lVar2 = **(longlong **)(lVar2 + 0x1d0);
    }
  }
  for (; lVar2 != 0; lVar2 = **(longlong **)(lVar2 + 0x1d0)) {
    if ((*(longlong *)(lVar2 + 0x1b8) == 0) || (iVar1 = FUN_14054f1e0(0x10), iVar1 == 0)) {
      FUN_140543c70(lVar2,4);
      if (*(longlong *)(lVar2 + 0x1b8) != 0) {
        FUN_14054f200(0);
      }
    }
    else {
      iVar4 = 1;
    }
  }
  for (lVar2 = *param_1; (lVar2 != 0 && (lVar2 != lVar3)); lVar2 = **(longlong **)(lVar2 + 0x1d0)) {
    if ((*(longlong *)(lVar2 + 0x1b8) == 0) || (iVar1 = FUN_14054f1e0(0x10), iVar1 == 0)) {
      FUN_140543c70(lVar2,4);
      if (*(longlong *)(lVar2 + 0x1b8) != 0) {
        FUN_14054f200(0);
      }
    }
    else {
      iVar4 = 1;
    }
  }
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffffb;
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) | iVar4 << 2;
  return;
}

// ==== CCrossSvrClient::helper_140552920  @140552920  [medium:callgraph-r3]  (orig: FUN_140552920)
void FUN_140552920(longlong *param_1)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  int iVar4;
  
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffffd;
  iVar4 = 0;
  if ((int)param_1[0xd] == 0) {
    lVar2 = 0;
    lVar3 = lVar2;
  }
  else {
    iVar1 = FUN_140546db0(param_1 + 0x1f);
    lVar2 = *param_1;
    for (; lVar3 = lVar2, iVar1 != 0; iVar1 = iVar1 + -1) {
      lVar2 = **(longlong **)(lVar2 + 0x1d0);
    }
  }
  for (; lVar2 != 0; lVar2 = **(longlong **)(lVar2 + 0x1d0)) {
    if ((*(longlong *)(lVar2 + 0x1b8) == 0) || (iVar1 = FUN_14054f1e0(0x10), iVar1 == 0)) {
      FUN_140543d50(lVar2,4);
      if (*(longlong *)(lVar2 + 0x1b8) != 0) {
        FUN_14054f200(0);
      }
    }
    else {
      iVar4 = 1;
    }
  }
  for (lVar2 = *param_1; (lVar2 != 0 && (lVar2 != lVar3)); lVar2 = **(longlong **)(lVar2 + 0x1d0)) {
    if ((*(longlong *)(lVar2 + 0x1b8) == 0) || (iVar1 = FUN_14054f1e0(0x10), iVar1 == 0)) {
      FUN_140543d50(lVar2,4);
      if (*(longlong *)(lVar2 + 0x1b8) != 0) {
        FUN_14054f200(0);
      }
    }
    else {
      iVar4 = 1;
    }
  }
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) & 0xfffffff7;
  *(uint *)(param_1 + 10) = *(uint *)(param_1 + 10) | iVar4 << 3;
  return;
}

// ==== CCrossSvrClient::helper_140552de0  @140552de0  [medium:callgraph-r3]  (orig: FUN_140552de0)
undefined8 FUN_140552de0(longlong param_1,int param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if ((*(longlong *)(param_1 + 0x1d0) != 0) &&
     (lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10), lVar1 != 0)) {
    if (*(longlong *)(lVar1 + 0x100) != 0) {
      FUN_14054f1e0(0);
    }
    *(undefined8 *)(*(longlong *)(param_1 + 0x1d0) + 0x10) = 0;
    *(int *)(lVar1 + 0x68) = *(int *)(lVar1 + 0x68) + -1;
    plVar2 = *(longlong **)(param_1 + 0x1d0);
    if (*plVar2 != 0) {
      *(longlong *)(*(longlong *)(*plVar2 + 0x1d0) + 8) = plVar2[1];
    }
    *(undefined8 *)(*(undefined8 **)(param_1 + 0x1d0))[1] = **(undefined8 **)(param_1 + 0x1d0);
    if (*(longlong *)(lVar1 + 0x100) != 0) {
      FUN_14054f200(0);
    }
  }
  if (param_2 != 0) {
    FUN_140543c70(param_1,4);
    FUN_140543d50(param_1,4);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_140553430  @140553430  [medium:callgraph-r2]  (orig: FUN_140553430)
undefined8 FUN_140553430(longlong param_1)

{
  *(undefined8 *)(param_1 + 0x1d0) = 0;
  *(undefined8 *)(param_1 + 0x1c0) = 0x4000;
  *(undefined8 *)(param_1 + 0x1c8) = 0x4000;
  return 0;
}

// ==== CCrossSvrClient::helper_140553460  @140553460  [medium:callgraph-r3]  (orig: FUN_140553460)
void FUN_140553460(undefined8 *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  int local_res8;
  int local_resc;
  
  FUN_14053cac0(*param_1,&local_res8);
  lVar1 = param_1[0x3a];
  uVar2 = (ulonglong)((longlong)(local_resc / 1000) + (longlong)local_res8 * 1000) /
          (ulonglong)*(uint *)(*(longlong *)(lVar1 + 0x30) + 0x28);
  if ((int)uVar2 != *(int *)(lVar1 + 0x28)) {
    FUN_140552390(lVar1 + 0x18,*(undefined8 *)(lVar1 + 0x30),uVar2 & 0xffffffff);
  }
  return;
}

// ==== CCrossSvrClient::helper_140553600  @140553600  [medium:callgraph-r2]  (orig: FUN_140553600)
longlong FUN_140553600(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar1 = *(longlong *)(param_1 + 0x1d0);
  lVar3 = *(longlong *)(param_1 + 0x1c0);
  if (lVar1 != 0) {
    if (*(longlong *)(lVar1 + 0x30) != 0) {
      FUN_140553460();
      lVar1 = *(longlong *)(param_1 + 0x1d0);
      lVar3 = *(longlong *)(lVar1 + 0x18);
    }
    lVar1 = *(longlong *)(lVar1 + 0x10);
    if (lVar1 != 0) {
      if (*(longlong *)(lVar1 + 0x100) != 0) {
        FUN_14054f1e0(0);
      }
      if ((*(byte *)(lVar1 + 0x50) & 1) == 0) {
        lVar2 = *(longlong *)(lVar1 + 8) / (longlong)*(int *)(lVar1 + 0x68);
        if (lVar2 < *(longlong *)(lVar1 + 0x70)) {
          lVar2 = *(longlong *)(lVar1 + 0x70);
        }
      }
      else {
        FUN_140543c00(param_1,4);
        lVar2 = 0;
      }
      if (*(longlong *)(lVar1 + 0x100) != 0) {
        FUN_14054f200(0);
      }
      if (lVar2 < lVar3) {
        lVar3 = lVar2;
      }
    }
    if (lVar3 < 0) {
      lVar3 = 0;
    }
  }
  return lVar3;
}

// ==== CCrossSvrClient::helper_1405536d0  @1405536d0  [medium:callgraph-r2]  (orig: FUN_1405536d0)
longlong FUN_1405536d0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar1 = *(longlong *)(param_1 + 0x1d0);
  lVar3 = *(longlong *)(param_1 + 0x1c8);
  if (lVar1 != 0) {
    if (*(longlong *)(lVar1 + 0x30) != 0) {
      FUN_140553460();
      lVar1 = *(longlong *)(param_1 + 0x1d0);
      lVar3 = *(longlong *)(lVar1 + 0x20);
    }
    lVar1 = *(longlong *)(lVar1 + 0x10);
    if (lVar1 != 0) {
      if (*(longlong *)(lVar1 + 0x100) != 0) {
        FUN_14054f1e0(0);
      }
      if ((*(byte *)(lVar1 + 0x50) & 2) == 0) {
        lVar2 = *(longlong *)(lVar1 + 0x10) / (longlong)*(int *)(lVar1 + 0x68);
        if (lVar2 < *(longlong *)(lVar1 + 0x70)) {
          lVar2 = *(longlong *)(lVar1 + 0x70);
        }
      }
      else {
        FUN_140543ce0(param_1,4);
        lVar2 = 0;
      }
      if (*(longlong *)(lVar1 + 0x100) != 0) {
        FUN_14054f200(0);
      }
      if (lVar2 < lVar3) {
        lVar3 = lVar2;
      }
    }
    if (lVar3 < 0) {
      lVar3 = 0;
    }
  }
  return lVar3;
}

// ==== CCrossSvrClient::helper_1405537a0  @1405537a0  [medium:callgraph-r2]  (orig: FUN_1405537a0)
undefined8 FUN_1405537a0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  undefined8 uVar4;
  
  lVar2 = *(longlong *)(param_1 + 0x1d0);
  uVar4 = 0;
  if (lVar2 == 0) {
    return 0;
  }
  if (*(longlong *)(lVar2 + 0x30) != 0) {
    *(longlong *)(lVar2 + 0x18) = *(longlong *)(lVar2 + 0x18) - param_2;
    if (*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x18) < 1) {
      FUN_140543c00(param_1,2);
      iVar3 = FUN_140542250(*(longlong *)(param_1 + 0x1d0) + 0x38,
                            *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x30) + 0x20);
      if (iVar3 < 0) {
        uVar4 = 0xffffffff;
      }
    }
    else if ((*(byte *)(param_1 + 0x176) & 2) != 0) {
      if ((*(byte *)(param_1 + 0x178) & 2) == 0) {
        FUN_140540740(*(longlong *)(param_1 + 0x1d0) + 0x38);
      }
      FUN_140543c70(param_1,2);
      uVar4 = 0;
    }
  }
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10);
  if (lVar2 != 0) {
    if (*(longlong *)(lVar2 + 0x100) != 0) {
      FUN_14054f1e0(0);
    }
    plVar1 = (longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 8);
    *plVar1 = *plVar1 - param_2;
    plVar1 = (longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 0x58);
    *plVar1 = *plVar1 + param_2;
    lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10);
    if (*(longlong *)(lVar2 + 8) < 1) {
      FUN_140552570();
    }
    else if ((*(byte *)(lVar2 + 0x50) & 1) != 0) {
      FUN_1405527e0();
    }
    if (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 0x100) != 0) {
      FUN_14054f200(0);
    }
  }
  return uVar4;
}

// ==== CCrossSvrClient::helper_1405538e0  @1405538e0  [medium:callgraph-r2]  (orig: FUN_1405538e0)
undefined8 FUN_1405538e0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  undefined8 uVar4;
  
  lVar2 = *(longlong *)(param_1 + 0x1d0);
  uVar4 = 0;
  if (lVar2 == 0) {
    return 0;
  }
  if (*(longlong *)(lVar2 + 0x30) != 0) {
    *(longlong *)(lVar2 + 0x20) = *(longlong *)(lVar2 + 0x20) - param_2;
    if (*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x20) < 1) {
      FUN_140543ce0(param_1,2);
      iVar3 = FUN_140542250(*(longlong *)(param_1 + 0x1d0) + 0x38,
                            *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x30) + 0x20);
      if (iVar3 < 0) {
        uVar4 = 0xffffffff;
      }
    }
    else if ((*(byte *)(param_1 + 0x178) & 2) != 0) {
      if ((*(byte *)(param_1 + 0x176) & 2) == 0) {
        FUN_140540740(*(longlong *)(param_1 + 0x1d0) + 0x38);
      }
      FUN_140543d50(param_1,2);
      uVar4 = 0;
    }
  }
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10);
  if (lVar2 != 0) {
    if (*(longlong *)(lVar2 + 0x100) != 0) {
      FUN_14054f1e0(0);
    }
    plVar1 = (longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 0x10);
    *plVar1 = *plVar1 - param_2;
    plVar1 = (longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 0x60);
    *plVar1 = *plVar1 + param_2;
    lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10);
    if (*(longlong *)(lVar2 + 0x10) < 1) {
      FUN_1405525f0();
    }
    else if ((*(byte *)(lVar2 + 0x50) & 2) != 0) {
      FUN_140552920();
    }
    if (*(longlong *)(*(longlong *)(*(longlong *)(param_1 + 0x1d0) + 0x10) + 0x100) != 0) {
      FUN_14054f200(0);
    }
  }
  return uVar4;
}

// ==== CCrossSvrClient::helper_1405c6900  @1405c6900  [medium:callgraph-r2]  (orig: FUN_1405c6900)
void FUN_1405c6900(undefined8 *param_1,undefined8 param_2)

{
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = param_2;
  return;
}

// ==== CCrossSvrClient::helper_1405c6a60  @1405c6a60  [medium:callgraph-r2]  (orig: FUN_1405c6a60)
int FUN_1405c6a60(undefined8 *param_1,HANDLE param_2,ULONG_PTR param_3)

{
  HANDLE pvVar1;
  
  pvVar1 = CreateIoCompletionPort(param_2,(HANDLE)*param_1,param_3,(int)*(short *)(param_1 + 6));
  return (pvVar1 != (HANDLE)0x0) - 1;
}

// ==== CCrossSvrClient::helper_1405c7060  @1405c7060  [medium:callgraph-r1]  (orig: FUN_1405c7060)
undefined8 FUN_1405c7060(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x1f0);
}

// ==== CCrossSvrClient::helper_1405c7200  @1405c7200  [medium:callgraph-r3]  (orig: FUN_1405c7200)
void FUN_1405c7200(undefined8 *param_1)

{
  int iVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  if ((param_1[0x4b] == 0) && ((*(byte *)(param_1 + 0x2e) & 8) == 0)) {
    if (((*(byte *)(param_1 + 0x4c) & 1) == 0) ||
       (((*(byte *)(param_1 + 0x2c) & 4) == 0 || (lVar2 = FUN_14054a780(param_1[0x21]), lVar2 == 0))
       )) {
      if ((*(uint *)(param_1 + 0x4c) & 4) != 0) {
        *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) & 0xfffffffb;
        FUN_14053e510(*param_1);
        return;
      }
    }
    else {
      uVar3 = FUN_14054a780(param_1[0x21]);
      iVar1 = FUN_1405536d0(param_1);
      if (((ulonglong)(longlong)iVar1 <= uVar3) && (-1 < iVar1)) {
        uVar3 = (longlong)iVar1;
      }
      if (*(short *)(param_1 + 0x2f) == 0) {
        FUN_140544560(param_1);
        iVar1 = FUN_1405c8290(param_1[0x21],uVar3,param_1 + 0x45);
        if (iVar1 != 0) {
          FUN_140544530(param_1);
          *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) & 0xfffffffe;
          FUN_140544a50(param_1,0x20,0);
          return;
        }
        param_1[0x4b] = uVar3;
        FUN_1405538e0(param_1,uVar3);
        if ((*(uint *)(param_1 + 0x4c) & 4) == 0) {
          *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) | 4;
          FUN_14053e4b0(*param_1);
          return;
        }
      }
      else if ((*(uint *)(param_1 + 0x4c) & 4) != 0) {
        *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) & 0xfffffffb;
        FUN_14053e510(*param_1);
      }
    }
  }
  return;
}

// ==== CCrossSvrClient::helper_1405c7360  @1405c7360  [medium:callgraph-r3]  (orig: FUN_1405c7360)
void FUN_1405c7360(undefined8 *param_1)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (param_1[0x4a] != 0) {
    return;
  }
  if ((*(byte *)(param_1 + 0x2e) & 8) != 0) {
    return;
  }
  uVar1 = *(uint *)(param_1 + 0x4c);
  if (((uVar1 & 1) == 0) || ((*(byte *)(param_1 + 0x2c) & 2) == 0)) {
    if ((uVar1 & 2) == 0) {
      return;
    }
    *(uint *)(param_1 + 0x4c) = uVar1 & 0xfffffffd;
    FUN_14053e510(*param_1);
    return;
  }
  uVar3 = FUN_14054a780(param_1[0x20]);
  uVar4 = param_1[0x23];
  if (uVar4 == 0) {
    uVar4 = 0x4000;
  }
  else {
    if (uVar4 <= uVar3) goto LAB_1405c73eb;
    uVar4 = uVar4 - uVar3;
  }
  iVar2 = FUN_140553600(param_1);
  if (((ulonglong)(longlong)iVar2 <= uVar4) && (-1 < iVar2)) {
    uVar4 = (longlong)iVar2;
  }
  if (*(short *)((longlong)param_1 + 0x176) == 0) {
    FUN_140544560(param_1);
    iVar2 = FUN_1405c8470(param_1[0x20],uVar4,param_1 + 0x40);
    if (iVar2 != 0) {
      *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) & 0xfffffffe;
      FUN_140544a50(param_1,0x20,0);
      FUN_140544530(param_1);
      return;
    }
    param_1[0x4a] = uVar4;
    FUN_1405537a0(param_1,uVar4);
    if ((*(uint *)(param_1 + 0x4c) & 2) != 0) {
      return;
    }
    *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) | 2;
    FUN_14053e4b0(*param_1);
    return;
  }
LAB_1405c73eb:
  if ((*(uint *)(param_1 + 0x4c) & 2) != 0) {
    *(uint *)(param_1 + 0x4c) = *(uint *)(param_1 + 0x4c) & 0xfffffffd;
    FUN_14053e510(*param_1);
  }
  return;
}

// ==== CCrossSvrClient::helper_1405c74c0  @1405c74c0  [medium:callgraph-r2]  (orig: FUN_1405c74c0)
void FUN_1405c74c0(undefined8 param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  
  lVar1 = param_3;
  if (*(undefined ***)(param_3 + 8) != &PTR_s_socket_async_1407b4720) {
    lVar1 = 0;
  }
  FUN_1405444f0(param_3);
  if (*(longlong *)(param_2 + 8) != 0) {
    FUN_1405c7200(lVar1);
  }
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_1405c7520  @1405c7520  [medium:callgraph-r2]  (orig: FUN_1405c7520)
void FUN_1405c7520(undefined8 param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  
  lVar1 = param_3;
  if (*(undefined ***)(param_3 + 8) != &PTR_s_socket_async_1407b4720) {
    lVar1 = 0;
  }
  FUN_1405444f0(param_3);
  if (*(longlong *)(param_2 + 0x10) != 0) {
    FUN_1405c7360(lVar1);
  }
  FUN_140544d50(param_3);
  return;
}

// ==== CCrossSvrClient::helper_1405c7580  @1405c7580  [medium:callgraph-r3]  (orig: FUN_1405c7580)
undefined8 FUN_1405c7580(longlong param_1,ushort param_2)

{
  longlong lVar1;
  
  lVar1 = param_1;
  if (*(undefined ***)(param_1 + 8) != &PTR_s_socket_async_1407b4720) {
    lVar1 = 0;
  }
  if ((*(byte *)(lVar1 + 0x260) & 1) == 0) {
    return 0xffffffff;
  }
  if ((*(byte *)(lVar1 + 0x170) & 8) == 0) {
    if (((param_2 & 2) != 0) &&
       ((*(int *)(param_1 + 0x150) != 0 || (*(int *)(param_1 + 0x154) != 0)))) {
      FUN_140542250(param_1 + 0x10);
    }
    if (((param_2 & 4) != 0) &&
       ((*(int *)(param_1 + 0x158) != 0 || (*(int *)(param_1 + 0x15c) != 0)))) {
      FUN_140542250(param_1 + 0x88);
    }
    if ((param_2 & 2) != 0) {
      FUN_1405c7360(lVar1);
    }
    if ((param_2 & 4) != 0) {
      FUN_1405c7200(lVar1);
    }
  }
  return 0;
}

// ==== CCrossSvrClient::helper_1405c77e0  @1405c77e0  [medium:callgraph-r2]  (orig: FUN_1405c77e0)
void FUN_1405c77e0(longlong param_1,undefined8 param_2,longlong param_3,int param_4)

{
  undefined8 uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8 [8];
  undefined1 local_res20 [8];
  
  if (*(longlong *)(param_1 + -0x48) != 0) {
    FUN_14054f1e0(0);
  }
  lVar3 = *(longlong *)(param_1 + 0x50);
  FUN_1405c8080(*(undefined8 *)(param_1 + -0x100),param_3);
  lVar3 = lVar3 - param_3;
  *(undefined8 *)(param_1 + 0x50) = 0;
  if (lVar3 != 0) {
    FUN_1405537a0(param_1 + -0x200,-lVar3);
  }
  if (param_4 == 0) {
    uVar1 = FUN_1405c86a0(*(undefined8 *)(param_1 + -0x100));
    WSAGetOverlappedResult(uVar1,param_1,local_res8,0,local_res20);
  }
  if ((*(uint *)(param_1 + 0x60) & 1) != 0) {
    if (param_4 == 0) {
      uVar1 = 0x21;
    }
    else {
      if (param_3 != 0) {
        if ((*(int *)(param_1 + -0xb0) != 0) || (*(int *)(param_1 + -0xac) != 0)) {
          FUN_140542250(param_1 + -0x1f0);
        }
        uVar2 = FUN_14054a780(*(undefined8 *)(param_1 + -0x100));
        if (*(ulonglong *)(param_1 + -0xf0) <= uVar2) {
          FUN_140544950(param_1 + -0x200,0);
        }
        FUN_1405c7360(param_1 + -0x200);
        goto LAB_1405c7904;
      }
      uVar1 = 0x11;
    }
    *(uint *)(param_1 + 0x60) = *(uint *)(param_1 + 0x60) & 0xfffffffe;
    FUN_140544a50(param_1 + -0x200,uVar1,0);
  }
LAB_1405c7904:
  FUN_140544d50(param_1 + -0x200);
  return;
}

// ==== CCrossSvrClient::helper_1405c7930  @1405c7930  [medium:callgraph-r2]  (orig: FUN_1405c7930)
void FUN_1405c7930(longlong param_1,undefined8 param_2,longlong param_3,int param_4)

{
  undefined8 uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8 [8];
  undefined1 local_res20 [8];
  
  if (*(longlong *)(param_1 + -0x70) != 0) {
    FUN_14054f1e0(0);
  }
  lVar3 = *(longlong *)(param_1 + 0x30);
  FUN_1405c8190(*(undefined8 *)(param_1 + -0x120),param_3);
  lVar3 = lVar3 - param_3;
  *(undefined8 *)(param_1 + 0x30) = 0;
  if (lVar3 != 0) {
    FUN_1405538e0(param_1 + -0x228,-lVar3);
  }
  if (param_4 == 0) {
    uVar1 = FUN_1405c86a0(*(undefined8 *)(param_1 + -0x128));
    WSAGetOverlappedResult(uVar1,param_1,local_res8,0,local_res20);
  }
  if ((*(uint *)(param_1 + 0x38) & 1) != 0) {
    if (param_4 == 0) {
      uVar1 = 0x22;
    }
    else {
      if (param_3 != 0) {
        if ((*(int *)(param_1 + -0xd0) != 0) || (*(int *)(param_1 + -0xcc) != 0)) {
          FUN_140542250(param_1 + -0x1a0);
        }
        uVar2 = FUN_14054a780(*(undefined8 *)(param_1 + -0x120));
        if (uVar2 <= *(ulonglong *)(param_1 + -0x108)) {
          FUN_1405449d0(param_1 + -0x228,0);
        }
        FUN_1405c7200(param_1 + -0x228);
        goto LAB_1405c7a54;
      }
      uVar1 = 0x12;
    }
    *(uint *)(param_1 + 0x38) = *(uint *)(param_1 + 0x38) & 0xfffffffe;
    FUN_140544a50(param_1 + -0x228,uVar1,0);
  }
LAB_1405c7a54:
  FUN_140544d50(param_1 + -0x228);
  return;
}

// ==== CCrossSvrClient::helper_1405c7a80  @1405c7a80  [medium:callgraph-r2]  (orig: FUN_1405c7a80)
void FUN_1405c7a80(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = param_1;
  if (*(undefined ***)(param_1 + 8) != &PTR_s_socket_async_1407b4720) {
    lVar1 = 0;
  }
  *(uint *)(lVar1 + 0x260) = *(uint *)(lVar1 + 0x260) | 1;
  FUN_140545030(param_1);
  FUN_1405c7580(param_1,*(undefined2 *)(param_1 + 0x160));
  return;
}

// ==== CCrossSvrClient::helper_1405c7ac0  @1405c7ac0  [medium:callgraph-r1]  (orig: FUN_1405c7ac0)
undefined8 FUN_1405c7ac0(undefined8 *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = FUN_1405c6d20();
  if ((undefined **)param_1[1] == &PTR_s_socket_async_1407b4720) {
    lVar2 = FUN_1405c7060(*param_1);
    if (((lVar2 != 0) && (lVar1 != 0)) && (*(longlong *)(lVar1 + 8) != 0)) {
      return 1;
    }
  }
  return 0;
}

// ==== CCrossSvrClient::helper_1405c7b20  @1405c7b20  [medium:callgraph-r1]  (orig: FUN_1405c7b20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405c7b20(undefined8 *param_1,undefined8 param_2,short *param_3,undefined4 param_4)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  undefined1 auStack_108 [32];
  undefined4 local_e8;
  undefined8 local_e0;
  undefined8 *local_d8;
  undefined2 local_c8 [2];
  undefined4 local_c4;
  undefined8 local_c0;
  undefined8 local_b8;
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_108;
  puVar4 = param_1;
  if ((undefined **)param_1[1] != &PTR_s_socket_async_1407b4720) {
    puVar4 = (undefined8 *)0x0;
  }
  lVar2 = FUN_1405c6d20();
  memset(local_c8,0,0x80);
  if (*param_3 == 2) {
    local_c4 = 0;
    local_c8[0] = 2;
LAB_1405c7bcb:
    iVar1 = Ordinal_2(param_2,local_c8,0x80);
    if (iVar1 < 0) {
      iVar1 = Ordinal_111();
      if (iVar1 != 0x2726) goto LAB_1405c7c47;
    }
    FUN_14053e4b0(*param_1);
    FUN_140544560(param_1);
    local_d8 = puVar4 + 0x3b;
    local_e0 = 0;
    local_e8 = 0;
    iVar1 = (**(code **)(lVar2 + 8))(param_2,param_3,param_4,0);
    if (iVar1 == 0) {
      iVar1 = Ordinal_111();
      if (iVar1 != 0x3e5) {
        FUN_14053e510(*param_1);
        FUN_140544530(param_1);
        goto LAB_1405c7c47;
      }
    }
    uVar3 = 0;
  }
  else {
    if (*param_3 == 0x17) {
      local_c8[0] = 0x17;
      local_c0 = DAT_1407b4cc0;
      local_b8 = DAT_1407b4cc8;
      goto LAB_1405c7bcb;
    }
LAB_1405c7c47:
    uVar3 = 0xffffffff;
  }
  return uVar3;
}

// ==== CCrossSvrClient::helper_1405c7d80  @1405c7d80  [medium:callgraph-r2]  (orig: FUN_1405c7d80)
void FUN_1405c7d80(longlong param_1,undefined8 param_2,undefined8 param_3,int param_4)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined1 local_res8 [8];
  undefined1 local_res20 [8];
  undefined8 in_stack_ffffffffffffffd8;
  uint uVar3;
  
  uVar3 = (uint)((ulonglong)in_stack_ffffffffffffffd8 >> 0x20);
  if (*(longlong *)(param_1 + -0x20) != 0) {
    FUN_14054f1e0(0);
  }
  *(uint *)(param_1 + -0x68) = *(uint *)(param_1 + -0x68) & 0xfffffff7;
  uVar1 = FUN_1405c86a0(*(undefined8 *)(param_1 + -0xd8));
  Ordinal_21(uVar1,0xffff,0x7010,0,(ulonglong)uVar3 << 0x20);
  if (param_4 == 0) {
    uVar1 = FUN_1405c86a0(*(undefined8 *)(param_1 + -0xd8));
    WSAGetOverlappedResult(uVar1,param_1,local_res8,0,local_res20);
  }
  else {
    lVar2 = param_1 + -0x1d8;
    if (*(undefined ***)(param_1 + -0x1d0) != &PTR_s_socket_async_1407b4720) {
      lVar2 = 0;
    }
    *(uint *)(lVar2 + 0x260) = *(uint *)(lVar2 + 0x260) | 1;
    FUN_140545030(param_1 + -0x1d8);
    FUN_1405c7580(param_1 + -0x1d8,*(undefined2 *)(param_1 + -0x78));
  }
  uVar1 = 0x20;
  if (param_4 != 0) {
    uVar1 = 0x80;
  }
  FUN_140544a50(param_1 + -0x1d8,uVar1,0);
  FUN_14053e510(*(undefined8 *)(param_1 + -0x1d8));
  FUN_140544d50(param_1 + -0x1d8);
  return;
}

// ==== CCrossSvrClient::helper_1405c7e80  @1405c7e80  [medium:callgraph-r1]  (orig: FUN_1405c7e80)
longlong FUN_1405c7e80(undefined8 param_1,longlong param_2,uint param_3)

{
  int iVar1;
  DWORD DVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar3 = FUN_1405c7060();
  if (lVar3 == 0) {
    return 0;
  }
  if (((-1 < param_2) && (iVar1 = FUN_1405c6a60(lVar3,param_2,1), iVar1 < 0)) &&
     (DVar2 = GetLastError(), DVar2 != 0x57)) {
    return 0;
  }
  lVar3 = FUN_14053dc90(1,0x268);
  if (lVar3 != 0) {
    lVar4 = FUN_1405c8240(param_2);
    *(longlong *)(lVar3 + 0x100) = lVar4;
    if (lVar4 != 0) {
      lVar4 = FUN_1405c8240(param_2);
      *(longlong *)(lVar3 + 0x108) = lVar4;
      if (lVar4 != 0) {
        iVar1 = FUN_140545430(lVar3,param_1,&PTR_s_socket_async_1407b4720,param_3 | 2);
        if (iVar1 < 0) {
          FUN_140544e70(lVar3);
          return 0;
        }
        FUN_14054baf0(*(undefined8 *)(lVar3 + 0x100),FUN_1405c7520,lVar3);
        FUN_14054baf0(*(undefined8 *)(lVar3 + 0x108),FUN_1405c74c0,lVar3);
        FUN_1405c6900(lVar3 + 0x1d8,FUN_1405c7d80);
        FUN_1405c6900(lVar3 + 0x200,FUN_1405c77e0);
        FUN_1405c6900(lVar3 + 0x228,FUN_1405c7930);
        FUN_140545030(lVar3);
        *(uint *)(lVar3 + 0x260) = *(uint *)(lVar3 + 0x260) & 0xfffffffe;
        *(uint *)(lVar3 + 0x260) = *(uint *)(lVar3 + 0x260) | (uint)(-1 < param_2);
        return lVar3;
      }
      FUN_14054a710(*(undefined8 *)(lVar3 + 0x100));
    }
    FUN_14053de00(lVar3);
  }
  return 0;
}

// ==== CCrossSvrClient::helper_1405c8080  @1405c8080  [medium:callgraph-r3]  (orig: FUN_1405c8080)
void FUN_1405c8080(ulonglong param_1,ulonglong param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  uint *puVar11;
  
  uVar7 = 0;
  uVar8 = uVar7;
  if ((param_1 != 0) && ((*(byte *)(param_1 + 0x38) & 0x10) != 0)) {
    uVar8 = param_1;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  FUN_14054bdb0(param_1,0);
  plVar1 = (longlong *)**(longlong **)(param_1 + 0x10);
  plVar9 = *(longlong **)(param_1 + 0x10);
  if ((*(byte *)(plVar1 + 4) & 0x10) == 0) {
    plVar9 = plVar1;
  }
  if (param_2 != 0) {
    puVar11 = (uint *)(uVar8 + 0xa8);
    uVar5 = uVar7;
    uVar10 = param_2;
    do {
      if (*(uint *)(uVar8 + 0xa0) <= (uint)uVar5) break;
      uVar3 = (ulonglong)*puVar11;
      if (uVar10 < *puVar11) {
        uVar3 = uVar10;
      }
      uVar5 = (ulonglong)((uint)uVar5 + 1);
      puVar11 = puVar11 + 4;
      *(longlong *)(*plVar9 + 0x18) = *(longlong *)(*plVar9 + 0x18) + uVar3;
      uVar10 = uVar10 - uVar3;
      *(longlong **)(param_1 + 0x10) = plVar9;
      plVar9 = (longlong *)*plVar9;
    } while (uVar10 != 0);
  }
  puVar4 = *(undefined8 **)(uVar8 + 0x98);
  if (0 < *(int *)(uVar8 + 0xa0)) {
    do {
      puVar2 = (undefined8 *)*puVar4;
      FUN_14054c0c0(puVar4,0x10);
      uVar6 = (int)uVar7 + 1;
      uVar7 = (ulonglong)uVar6;
      puVar4 = puVar2;
    } while ((int)uVar6 < *(int *)(uVar8 + 0xa0));
  }
  *(uint *)(uVar8 + 0x90) = *(uint *)(uVar8 + 0x90) & 0xfffffffe;
  *(longlong *)(param_1 + 0x18) = *(longlong *)(param_1 + 0x18) + param_2;
  *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_2;
  FUN_14054a570(param_1);
  FUN_14054a630(param_1);
  return;
}

// ==== CCrossSvrClient::helper_1405c8190  @1405c8190  [medium:callgraph-r3]  (orig: FUN_1405c8190)
void FUN_1405c8190(ulonglong param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  uint uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  
  uVar4 = 0;
  if ((param_1 == 0) || (uVar5 = param_1, (*(byte *)(param_1 + 0x38) & 0x10) == 0)) {
    uVar5 = uVar4;
  }
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  FUN_14054bdb0(param_1,1);
  FUN_14054c6b0(param_1,param_2);
  puVar2 = *(undefined8 **)(uVar5 + 0x98);
  if (0 < *(int *)(uVar5 + 0xa0)) {
    do {
      puVar1 = (undefined8 *)*puVar2;
      FUN_14054c0c0(puVar2,0x20);
      uVar3 = (int)uVar4 + 1;
      uVar4 = (ulonglong)uVar3;
      puVar2 = puVar1;
    } while ((int)uVar3 < *(int *)(uVar5 + 0xa0));
  }
  *(uint *)(uVar5 + 0x90) = *(uint *)(uVar5 + 0x90) & 0xfffffffd;
  FUN_14054a630(param_1);
  return;
}

// ==== CCrossSvrClient::helper_1405c8240  @1405c8240  [medium:callgraph-r2]  (orig: FUN_1405c8240)
void FUN_1405c8240(undefined8 param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_14053dc90(1,0x1a8);
  if (lVar1 == 0) {
    return;
  }
  *(uint *)(lVar1 + 0x38) = *(uint *)(lVar1 + 0x38) | 0x10;
  *(undefined8 *)(lVar1 + 0x78) = 0;
  *(undefined4 *)(lVar1 + 0x48) = 1;
  *(longlong *)(lVar1 + 0x10) = lVar1;
  *(undefined8 *)(lVar1 + 0x88) = param_1;
  return;
}

// ==== CCrossSvrClient::helper_1405c86a0  @1405c86a0  [medium:callgraph-r3]  (orig: FUN_1405c86a0)
undefined8 FUN_1405c86a0(longlong param_1)

{
  if ((param_1 != 0) && ((*(byte *)(param_1 + 0x38) & 0x10) != 0)) {
    return *(undefined8 *)(param_1 + 0x88);
  }
  return 0xffffffffffffffff;
}

