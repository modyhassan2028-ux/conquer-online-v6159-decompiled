// ==== CTradeActor@adapter::helper_1401003d0  @1401003d0  [medium:callgraph-r0]  (orig: FUN_1401003d0)
undefined8 FUN_1401003d0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x48) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001401003e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x30))(*(longlong **)(param_1 + 0x48),3);
    return uVar1;
  }
  return 0;
}

// ==== CTradeActor@adapter::helper_1401003f0  @1401003f0  [medium:callgraph-r0]  (orig: FUN_1401003f0)
undefined8 FUN_1401003f0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x48) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140100403. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x30))(*(longlong **)(param_1 + 0x48),4);
    return uVar1;
  }
  return 0;
}

// ==== CTradeActor@adapter::helper_140100410  @140100410  [medium:callgraph-r0]  (orig: FUN_140100410)
undefined8 FUN_140100410(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x58) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140100423. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x30))(*(longlong **)(param_1 + 0x58),4);
    return uVar1;
  }
  return 0;
}

// ==== CTradeActor@adapter::helper_140336dc0  @140336dc0  [medium:callgraph-r1]  (orig: FUN_140336dc0)
undefined8 * FUN_140336dc0(longlong param_1,undefined8 *param_2,longlong *param_3)

{
  undefined8 uVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  int iVar5;
  undefined8 *puVar6;
  ldiv_t lVar7;
  undefined8 *puVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  int local_res8;
  
  puVar8 = (undefined8 *)*param_3;
  puVar12 = (undefined8 *)0x0;
  if (puVar8 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
    puVar8 = (undefined8 *)*param_3;
    puVar6 = puVar12;
    if (puVar8 == (undefined8 *)0x0) goto LAB_140336e02;
  }
  puVar6 = (undefined8 *)*puVar8;
LAB_140336e02:
  if (param_3[1] == puVar6[5]) {
    _invalid_parameter_noinfo();
  }
  lVar7 = ldiv((*(uint *)(param_3[1] + 0x10) ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res8 = lVar7.quot;
  iVar5 = lVar7.rem * 0x41a7 + local_res8 * -0xb14;
  if (iVar5 < 0) {
    iVar5 = iVar5 + 0x7fffffff;
  }
  uVar10 = (longlong)iVar5 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar10) {
    uVar10 = uVar10 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  lVar9 = uVar10 << 4;
  while( true ) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar10) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(*(longlong *)(param_1 + 0x60) + 8 + lVar9) != param_3[1]) break;
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar10) {
      _invalid_parameter_noinfo();
    }
    puVar8 = *(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + lVar9);
    if ((longlong *)(param_1 + 0x10) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    puVar6 = *(undefined8 **)(param_1 + 0x10);
    if (puVar6 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      puVar11 = puVar12;
    }
    else {
      puVar11 = (undefined8 *)*puVar6;
    }
    if (puVar8 == (undefined8 *)puVar11[5]) {
      _invalid_parameter_noinfo();
    }
    uVar1 = *puVar8;
    puVar8 = puVar12;
    if (puVar6 != (undefined8 *)0x0) {
      puVar8 = (undefined8 *)*puVar6;
    }
    uVar2 = *puVar8;
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar10) {
      _invalid_parameter_noinfo();
    }
    lVar3 = *(longlong *)(param_1 + 0x60);
    *(undefined8 *)(lVar3 + lVar9) = uVar2;
    *(undefined8 *)(lVar3 + 8 + lVar9) = uVar1;
    if (uVar10 == 0) break;
    uVar10 = uVar10 - 1;
    lVar9 = lVar9 + -0x10;
  }
  puVar8 = (undefined8 *)param_3[1];
  plVar4 = (longlong *)param_3[1];
  if ((undefined8 *)*param_3 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    puVar12 = *(undefined8 **)*param_3;
  }
  if (puVar8 == (undefined8 *)puVar12[5]) {
    _invalid_parameter_noinfo();
  }
  uVar1 = *puVar8;
  if (plVar4 != *(longlong **)(param_1 + 0x38)) {
    *(longlong *)plVar4[1] = *plVar4;
    *(longlong *)(*plVar4 + 8) = plVar4[1];
    operator_delete(plVar4);
    *(longlong *)(param_1 + 0x40) = *(longlong *)(param_1 + 0x40) + -1;
  }
  uVar2 = *(undefined8 *)(param_1 + 0x10);
  param_2[1] = uVar1;
  *param_2 = uVar2;
  return param_2;
}

// ==== CTradeActor@adapter::helper_140337da0  @140337da0  [medium:callgraph-r0]  (orig: FUN_140337da0)
void FUN_140337da0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [2];
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  local_res10[0] = param_2;
  FUN_140335320(param_1 + 0xde8,&local_28,local_res10);
  lVar1 = *(longlong *)(param_1 + 0xe20);
  if ((CONCAT44(uStack_24,local_28) == 0) ||
     (CONCAT44(uStack_24,local_28) != *(longlong *)(param_1 + 0xdf8))) {
    _invalid_parameter_noinfo();
  }
  if (CONCAT44(uStack_1c,uStack_20) != lVar1) {
    FUN_140336dc0(param_1 + 0xde8,local_18,&local_28);
  }
  return;
}

// ==== CTradeActor@adapter::helper_140339d80  @140339d80  [medium:callgraph-r0]  (orig: FUN_140339d80)
int FUN_140339d80(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  int iVar8;
  
  plVar2 = (longlong *)*param_2;
  iVar8 = 0;
  plVar3 = *(longlong **)param_2[6];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar3;
          plVar3 = (longlong *)param_2[6];
          if (((longlong *)*param_2 == (longlong *)0x0) || ((longlong *)*param_2 != plVar2)) {
            _invalid_parameter_noinfo();
          }
          if (plVar3 == plVar6) {
            return iVar8;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          iVar4 = FUN_140339ba0(param_1,(int)plVar6[3],*(undefined2 *)((longlong)plVar6 + 0x1c),0);
          iVar8 = iVar8 + iVar4;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x21) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar6;
        }
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x21) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x21);
        plVar6 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x21);
          plVar3 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar3 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar3 + 0x21) != '\0');
    do {
      plVar5 = plVar3;
      plVar3 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar3 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar3 + 0x21) == '\0');
  } while( true );
}

// ==== CTradeActor@adapter::helper_140359020  @140359020  [medium:callgraph-r0]  (orig: FUN_140359020)
void FUN_140359020(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_140358f20(param_1 + 0xde8,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CTradeActor@adapter::vfunc_1  @14059adc0  [high:rtti-vtable]  (orig: FUN_14059adc0)
void FUN_14059adc0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_47  @14059ade0  [high:rtti-vtable]  (orig: FUN_14059ade0)
void FUN_14059ade0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_14018f460(lVar1,param_3,0,0);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_3  @14059ae20  [high:rtti-vtable]  (orig: FUN_14059ae20)
undefined8 FUN_14059ae20(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x230))(lVar2 + 0x10);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_6  @14059ae60  [high:rtti-vtable]  (orig: FUN_14059ae60)
bool FUN_14059ae60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  
  lVar7 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  lVar8 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if ((lVar7 != 0) && (lVar8 != 0)) {
    plVar1 = (longlong *)(lVar8 + 0x10);
    plVar9 = (longlong *)(lVar7 + 0x10);
    iVar3 = (**(code **)(*plVar1 + 0x168))(plVar1);
    iVar4 = (**(code **)(*plVar9 + 0x168))(plVar9);
    if (iVar4 == iVar3) {
      lVar7 = *plVar9;
      uVar5 = (**(code **)(*plVar1 + 0x48))(plVar1);
      uVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
      iVar3 = (**(code **)(lVar7 + 0x158))(plVar9,uVar6,uVar5);
      bVar2 = iVar3 < 0x13;
    }
    else {
      bVar2 = false;
    }
    return bVar2;
  }
  return false;
}

// ==== CTradeActor@adapter::vfunc_7  @14059af30  [high:rtti-vtable]  (orig: FUN_14059af30)
undefined8 FUN_14059af30(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 1;
  }
  uVar2 = FUN_140178570(lVar1,1);
  return uVar2;
}

// ==== CTradeActor@adapter::vfunc_1  @14059af90  [high:rtti-vtable]  (orig: FUN_14059af90)
void FUN_14059af90(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401183a0();
                    /* WARNING: Could not recover jumptable at 0x00014059afb9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_2,param_3);
  return;
}

// ==== CTradeActor@adapter::vfunc_5  @14059afc0  [high:rtti-vtable]  (orig: FUN_14059afc0)
undefined8 FUN_14059afc0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059afe2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_4  @14059aff0  [high:rtti-vtable]  (orig: FUN_14059aff0)
undefined8 FUN_14059aff0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140175450(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_8  @14059b020  [high:rtti-vtable]  (orig: FUN_14059b020)
void FUN_14059b020(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x338))(lVar1 + 0x10);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_43  @14059b050  [high:rtti-vtable]  (orig: FUN_14059b050)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14059b050(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined1 auStack_8b8 [32];
  undefined8 local_898;
  undefined1 local_888 [1072];
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_898 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8b8;
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                     (*(longlong **)(param_1 + 0x10),param_3);
  if ((plVar3 != (longlong *)0x0) && (plVar4 != (longlong *)0x0)) {
    FUN_14039e680(local_458);
    FUN_14039e680(local_888);
    uVar1 = (**(code **)(plVar3[2] + 0x70))(plVar3 + 2);
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    FUN_14039e700(local_458,uVar2,0xc,uVar1);
    (**(code **)(plVar4[2] + 0x350))(plVar4 + 2,local_458);
    uVar1 = (**(code **)(plVar4[2] + 0x70))(plVar4 + 2);
    uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
    FUN_14039e700(local_888,uVar2,0xc,uVar1);
    (**(code **)(plVar3[2] + 0x350))(plVar3 + 2,local_888);
    FUN_14039e6d0(local_888);
    FUN_14039e6d0(local_458);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_9  @14059b1a0  [high:rtti-vtable]  (orig: FUN_14059b1a0)
undefined8 FUN_14059b1a0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014059b1c0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x60))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_12  @14059b1d0  [high:rtti-vtable]  (orig: FUN_14059b1d0)
undefined4 FUN_14059b1d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    return *(undefined4 *)(lVar1 + 0xfa4);
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_11  @14059b200  [high:rtti-vtable]  (orig: FUN_14059b200)
undefined8 FUN_14059b200(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014059b23a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_14  @14059b250  [high:rtti-vtable]  (orig: FUN_14059b250)
undefined8 FUN_14059b250(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
                      ((longlong *)(lVar1 + 0x10),0x1d,-param_3,param_4,0);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_13  @14059b2b0  [high:rtti-vtable]  (orig: FUN_14059b2b0)
undefined8 FUN_14059b2b0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
                      ((longlong *)(lVar1 + 0x10),0x1d,param_3,param_4,0);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_10  @14059b310  [high:rtti-vtable]  (orig: FUN_14059b310)
undefined8 FUN_14059b310(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014059b34a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x180))(plVar1,param_3,param_4);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_15  @14059b360  [high:rtti-vtable]  (orig: FUN_14059b360)
undefined8 FUN_14059b360(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong *plVar4;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = FUN_140332fe0(lVar2,param_3);
    if (cVar1 != '\0') {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar4 = (longlong *)0x0;
      }
      lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
      if (lVar2 != 0) {
        cVar1 = FUN_1400ffbe0(lVar2);
        if (cVar1 == '\0') {
          uVar3 = FUN_1400fda10(lVar2,0x6e,1);
          if (((uVar3 ^ 0xff) & 1) != 0) {
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_16  @14059b410  [high:rtti-vtable]  (orig: FUN_14059b410)
undefined8 FUN_14059b410(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ffc20(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_17  @14059b480  [high:rtti-vtable]  (orig: FUN_14059b480)
bool FUN_14059b480(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    iVar1 = FUN_1400fda10(lVar2,0x17,1);
    return iVar1 != 0;
  }
  return false;
}

// ==== CTradeActor@adapter::vfunc_18  @14059b510  [high:rtti-vtable]  (orig: FUN_14059b510)
void FUN_14059b510(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1403380a0(lVar1,param_3);
  return;
}

// ==== CTradeActor@adapter::vfunc_20  @14059b540  [high:rtti-vtable]  (orig: FUN_14059b540)
undefined8 FUN_14059b540(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ffbe0(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_36  @14059b5b0  [high:rtti-vtable]  (orig: FUN_14059b5b0)
undefined8 FUN_14059b5b0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ff650(lVar1,param_3);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_19  @14059b630  [high:rtti-vtable]  (orig: FUN_14059b630)
uint FUN_14059b630(undefined8 param_1,undefined4 param_2)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    uVar1 = FUN_1400fda10(lVar2,0x6e,1);
    return ~uVar1 & 1;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_24  @14059b6a0  [high:rtti-vtable]  (orig: FUN_14059b6a0)
undefined8 FUN_14059b6a0(undefined8 param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    cVar1 = FUN_140102870(lVar2);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_26  @14059b710  [high:rtti-vtable]  (orig: FUN_14059b710)
undefined8 FUN_14059b710(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,1,1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_25  @14059b780  [high:rtti-vtable]  (orig: FUN_14059b780)
undefined8 FUN_14059b780(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400ffda0(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_23  @14059b7f0  [high:rtti-vtable]  (orig: FUN_14059b7f0)
void FUN_14059b7f0(void)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059b833. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xe8))();
  return;
}

// ==== CTradeActor@adapter::vfunc_21  @14059b840  [high:rtti-vtable]  (orig: FUN_14059b840)
undefined8 FUN_14059b840(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140104440(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_37  @14059b8b0  [high:rtti-vtable]  (orig: FUN_14059b8b0)
bool FUN_14059b8b0(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 != 0) {
    iVar1 = FUN_1400fda10(lVar2,0x9c,1);
    return 0 < iVar1;
  }
  return false;
}

// ==== CTradeActor@adapter::vfunc_28  @14059b940  [high:rtti-vtable]  (orig: FUN_14059b940)
void FUN_14059b940(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014059b98a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 200))(plVar1,param_2);
  return;
}

// ==== CTradeActor@adapter::vfunc_31  @14059b9a0  [high:rtti-vtable]  (orig: FUN_14059b9a0)
ulonglong FUN_14059b9a0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_3);
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_2);
  if ((lVar1 == 0) || (uVar2 == 0)) {
    uVar2 = uVar2 & 0xffffffffffffff00;
  }
  else {
    uVar2 = FUN_140332fe0(uVar2,param_3);
  }
  return uVar2;
}

// ==== CTradeActor@adapter::vfunc_32  @14059ba40  [high:rtti-vtable]  (orig: FUN_14059ba40)
undefined8 FUN_14059ba40(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140339d80(lVar1,param_3);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_27  @14059ba80  [high:rtti-vtable]  (orig: FUN_14059ba80)
undefined8 FUN_14059ba80(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,0x6f,1);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_30  @14059baf0  [high:rtti-vtable]  (orig: FUN_14059baf0)
void FUN_14059baf0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 != 0) {
    FUN_140104140(lVar1,0x12,param_3);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_29  @14059bb70  [high:rtti-vtable]  (orig: FUN_14059bb70)
undefined8 FUN_14059bb70(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_1400fda10(lVar1,0x12,1);
    return uVar2;
  }
  return 0xffffffff;
}

// ==== CTradeActor@adapter::vfunc_34  @14059bbe0  [high:rtti-vtable]  (orig: FUN_14059bbe0)
undefined8
FUN_14059bbe0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4,
             undefined1 param_5)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong *plVar4;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
  if ((lVar1 != 0) && (lVar2 != 0)) {
    uVar3 = FUN_1403368a0(lVar1,param_3,param_4,param_5,1);
    return uVar3;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_39  @14059bc90  [high:rtti-vtable]  (orig: FUN_14059bc90)
void FUN_14059bc90(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                  char param_5)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar6 = (longlong *)0x0;
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar6;
  }
  uVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,param_4);
  if (lVar3 != 0) {
    if (param_5 == '\0') {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar6;
      }
      (**(code **)(*plVar5 + 0x130))(plVar5,lVar3,uVar4,2,0,0);
      uVar2 = FUN_1400fda10(uVar4,1,1);
      cVar1 = FUN_1400ff940(uVar2);
      if (cVar1 != '\0') {
        FUN_14019a030(lVar3,param_4,0,0);
      }
    }
    else {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar6;
      }
      (**(code **)(*plVar5 + 0x130))(plVar5,lVar3,uVar4,6,0,0);
    }
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_44  @14059be00  [high:rtti-vtable]  (orig: FUN_14059be00)
void FUN_14059be00(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar1 != 0) {
    FUN_1401742b0(lVar1,param_2,param_3,param_4,param_5);
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_46  @14059be60  [high:rtti-vtable]  (orig: FUN_14059be60)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14059be60(longlong param_1,undefined4 param_2,undefined4 param_3,char param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar4 = (longlong *)0x0;
  }
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x60))(plVar4,param_2);
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                     (*(longlong **)(param_1 + 0x10),param_3);
  if ((plVar4 != (longlong *)0x0) && (plVar1 != (longlong *)0x0)) {
    FUN_1400fda10(plVar4,0xc,1);
    plVar5 = plVar1 + 2;
    FUN_140100410(plVar4);
    FUN_140100340(plVar4);
    FUN_1401003f0(plVar4);
    FUN_1401003d0(plVar4);
    FUN_1400fda10(plVar4,0x13,1);
    FUN_1400ffda0(plVar4);
    FUN_1400fda10(plVar4,0xf,1);
    FUN_1400fda10(plVar4,0xe,1);
    FUN_1400fda10(plVar4,0x10,1);
    FUN_1400fda10(plVar4,5,1);
    FUN_1400fda10(plVar4,4,1);
    FUN_1400fda10(plVar4,9,1);
    FUN_1400fda10(plVar4,8,1);
    FUN_1400fda10(plVar4,1,1);
    (**(code **)(*plVar4 + 8))(plVar4);
    FUN_140100430(plVar4,0x65);
    uVar2 = (**(code **)(*plVar5 + 0x18))(plVar5);
    uVar3 = (**(code **)(*plVar1 + 8))();
    tq::MyLogSave("gmlog/trade_item",
                  "user id[%u] name[%s] | item[%s][%u] type[%u] gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%u], dec_dmg[%u] add_life[%u] accumulate[%d] specialflag[%d] quenchtype[%d] quenchlev[%d] forgetype[%d] forgelev[%d]"
                  ,uVar3 & 0xffffffff,uVar2);
    if (param_4 != '\0') {
      FUN_1400fda10(plVar4,0xc,1);
      FUN_140100410(plVar4);
      FUN_140100340(plVar4);
      FUN_1401003f0(plVar4);
      FUN_1401003d0(plVar4);
      FUN_1400fda10(plVar4,0x13,1);
      FUN_1400ffda0(plVar4);
      FUN_1400fda10(plVar4,0xf,1);
      FUN_1400fda10(plVar4,0xe,1);
      FUN_1400fda10(plVar4,0x10,1);
      FUN_1400fda10(plVar4,5,1);
      FUN_1400fda10(plVar4,4,1);
      FUN_1400fda10(plVar4,9,1);
      FUN_1400fda10(plVar4,8,1);
      FUN_1400fda10(plVar4,1,1);
      (**(code **)(*plVar4 + 8))(plVar4);
      FUN_140100430(plVar4,0x65);
      uVar2 = (**(code **)(*plVar5 + 0x18))(plVar5);
      uVar3 = (**(code **)(*plVar1 + 8))(plVar1);
      tq::MyLogSave("gmlog/unfair_trade_item",
                    "user id[%u] name[%s] | item[%s][%u] type[%u] gem1[%d] gem2[%d] magic3[%d] dur[%d] max_dur[%d] antimonster[%u], dec_dmg[%u] add_life[%u] accumulate[%d] specialflag[%d] quenchtype[%d] quenchlev[%d] forgetype[%d] forgelev[%d]"
                    ,uVar3 & 0xffffffff,uVar2);
    }
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_45  @14059c3a0  [high:rtti-vtable]  (orig: FUN_14059c3a0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14059c3a0(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  char in_stack_00000050;
  
  plVar1 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x98))();
  plVar2 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x98))((longlong *)param_1[2],param_3)
  ;
  if ((plVar1 != (longlong *)0x0) && (plVar2 != (longlong *)0x0)) {
    (**(code **)(*param_1 + 8))(param_1,param_2,param_3);
    (**(code **)(plVar1[2] + 0x70))(plVar1 + 2);
    uVar3 = (**(code **)(plVar1[2] + 0x18))(plVar1 + 2);
    uVar4 = (**(code **)(*plVar1 + 8))(plVar1);
    tq::MyLogSave("gmlog/trade_item",
                  "user1_id[%u] user1[%s] lev1[%u] money1[%I64d] emoney1[%u] IsTradeBuddy[%d]",
                  uVar4 & 0xffffffff,uVar3);
    (**(code **)(plVar2[2] + 0x70))(plVar2 + 2);
    uVar3 = (**(code **)(plVar2[2] + 0x18))(plVar2 + 2);
    uVar4 = (**(code **)(*plVar2 + 8))(plVar2);
    tq::MyLogSave("gmlog/trade_item","user2_id[%u] user2[%s] lev2[%u] money2[%I64d] emoney2[%u] ",
                  uVar4 & 0xffffffff,uVar3);
    if (in_stack_00000050 != '\0') {
      (**(code **)(*param_1 + 8))(param_1,param_2,param_3);
      (**(code **)(plVar1[2] + 0x70))(plVar1 + 2);
      uVar3 = (**(code **)(plVar1[2] + 0x18))(plVar1 + 2);
      uVar4 = (**(code **)(*plVar1 + 8))(plVar1);
      tq::MyLogSave("gmlog/unfair_trade_item",
                    "user1_id[%u] user1[%s] lev1[%u] money1[%I64d] emoney1[%u] value1[%u] IsTradeBuddy[%d]"
                    ,uVar4 & 0xffffffff,uVar3);
      (**(code **)(plVar2[2] + 0x70))(plVar2 + 2);
      uVar3 = (**(code **)(plVar2[2] + 0x18))(plVar2 + 2);
      uVar4 = (**(code **)(*plVar2 + 8))(plVar2);
      tq::MyLogSave("gmlog/unfair_trade_item",
                    "user2_id[%u] user2[%s] lev2[%u] money2[%I64d] emoney2[%u] value2[%u]",
                    uVar4 & 0xffffffff,uVar3);
    }
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_42  @14059c600  [high:rtti-vtable]  (orig: FUN_14059c600)
void FUN_14059c600(longlong param_1,undefined8 param_2,longlong param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  if (param_3 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))(lVar1 + 0x10,param_3,param_4,param_5,param_6)
    ;
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_41  @14059c690  [high:rtti-vtable]  (orig: FUN_14059c690)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14059c690(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x303);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CTradeActor@adapter::vfunc_38  @14059c7f0  [high:rtti-vtable]  (orig: FUN_14059c7f0)
undefined8 FUN_14059c7f0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014059c812. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_0  @14059c820  [high:rtti-vtable]  (orig: FUN_14059c820)
void FUN_14059c820(longlong param_1)

{
  FUN_14059c8b0(param_1 + -8);
  return;
}

// ==== CTradeActor@adapter::helper_14059c830  @14059c830  [medium:callgraph-r0]  (orig: FUN_14059c830)
uint FUN_14059c830(longlong param_1)

{
  longlong *plVar1;
  uint extraout_var;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return extraout_var >> 2 & 1;
}

// ==== CTradeActor@adapter::helper_14059c8b0  @14059c8b0  [medium:callgraph-r0]  (orig: FUN_14059c8b0)
undefined8 * FUN_14059c8b0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTradeActor::vftable;
  param_1[1] = adapter::CTradeActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTradeActor@adapter::vfunc_0  @14059c900  [high:rtti-vtable]  (orig: FUN_14059c900)
undefined8 FUN_14059c900(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  char *pcVar9;
  undefined8 *puVar10;
  longlong local_res8;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  local_res8 = 0;
  if (((((lVar5 == 0) ||
        (cVar1 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x220))(lVar5 + 0x10), cVar1 == '\0'))
       || (*(char *)(lVar5 + 0x51c) == '\0')) ||
      ((cVar1 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2d8))(lVar5 + 0x10,0x37), cVar1 != '\0'
       || (cVar1 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2d8))(lVar5 + 0x10,0x38),
          cVar1 != '\0')))) ||
     ((cVar1 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2d8))(lVar5 + 0x10,0x18), cVar1 != '\0'
      || (cVar1 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x2d8))(lVar5 + 0x10,0x6e),
         cVar1 != '\0')))) {
    return 0;
  }
  lVar6 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x160))(lVar5 + 0x10);
  if (lVar6 != 0) {
    uVar2 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x48))(lVar5 + 0x10);
    uVar3 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x40))(lVar5 + 0x10);
    cVar1 = FUN_1402c84c0(lVar6,uVar3,uVar2,0x1001,param_3,&local_res8);
    if (cVar1 != '\0') {
      cVar1 = FUN_14059c830(lVar6);
      if (cVar1 == '\0') {
        if (local_res8 == 0) {
          return 0;
        }
        cVar1 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x220))(local_res8 + 0x10);
        if (cVar1 == '\0') {
          return 0;
        }
        cVar1 = FUN_140178570(local_res8,1);
        if (cVar1 != '\0') {
          return 0;
        }
        cVar1 = FUN_140178570(lVar5,1);
        if (cVar1 != '\0') {
          return 0;
        }
        cVar1 = FUN_140167b70(local_res8);
        if (cVar1 != '\0') {
          return 0;
        }
        cVar1 = FUN_140167b70(lVar5);
        if (cVar1 != '\0') {
          return 0;
        }
        cVar1 = FUN_140177530(lVar5,param_3,0);
        if (cVar1 == '\0') {
          return 0;
        }
        iVar4 = FUN_140175470(local_res8);
        if ((iVar4 == 0) ||
           ((iVar4 = FUN_140164ee0(local_res8), iVar4 != 0 &&
            (iVar4 = FUN_140164ee0(local_res8), iVar4 != 0x32)))) {
          return 1;
        }
        pIVar7 = theInstance();
        lVar6 = *(longlong *)(lVar5 + 0x10);
        pcVar9 = "STR_TRADE_WALLOW";
        puVar10 = *(undefined8 **)pIVar7;
      }
      else {
        pIVar7 = theInstance();
        lVar6 = *(longlong *)(lVar5 + 0x10);
        pcVar9 = "STR_MAP_FORBIDTRADE";
        puVar10 = *(undefined8 **)pIVar7;
      }
      goto LAB_14059cb30;
    }
  }
  pIVar7 = theInstance();
  lVar6 = *(longlong *)(lVar5 + 0x10);
  pcVar9 = "STR_NO_TRADE_TARGET";
  puVar10 = *(undefined8 **)pIVar7;
LAB_14059cb30:
  uVar8 = (*(code *)*puVar10)(pIVar7,pcVar9);
  (**(code **)(lVar6 + 0x358))(lVar5 + 0x10,uVar8);
  return 0;
}

// ==== CTradeActor@adapter::vfunc_2  @14059cb60  [high:rtti-vtable]  (orig: FUN_14059cb60)
bool FUN_14059cb60(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  int param_5,undefined4 param_6)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  longlong *plVar6;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 != 0) {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar4 = (**(code **)(*plVar6 + 0x60))(plVar6,param_3);
    if (lVar4 != 0) {
      cVar1 = FUN_1400ffbe0(lVar4);
      if (cVar1 == '\0') {
        uVar5 = FUN_1400fda10(lVar4,0x6e,1);
        if (((uVar5 ^ 0xff) & 1) != 0) {
          iVar2 = FUN_140339d80(lVar3,param_4);
          cVar1 = FUN_1400c9580(lVar3,iVar2 + param_5,param_6);
          return cVar1 != '\0';
        }
      }
    }
  }
  return false;
}

// ==== CTradeActor@adapter::vfunc_33  @14059cc40  [high:rtti-vtable]  (orig: FUN_14059cc40)
undefined8 FUN_14059cc40(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_1400c9580(lVar1,param_3,param_4);
    return uVar2;
  }
  return 0;
}

// ==== CTradeActor@adapter::vfunc_22  @14059cc90  [high:rtti-vtable]  (orig: FUN_14059cc90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14059cc90(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  ulonglong uVar11;
  undefined7 uVar12;
  undefined1 auStack_8c8 [32];
  undefined4 local_8a8;
  undefined1 local_8a0;
  undefined4 local_898;
  undefined8 local_888;
  undefined1 local_878 [1072];
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_888 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_8c8;
  plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x98))((longlong *)param_1[2],param_3)
  ;
  lVar8 = (**(code **)(*(longlong *)param_1[2] + 0x98))((longlong *)param_1[2],param_2);
  plVar9 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    local_8a8 = 0x3c0;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar9 = (longlong *)0x0;
  }
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_4);
  if (((plVar9 == (longlong *)0x0) || (plVar7 == (longlong *)0x0)) || (lVar8 == 0)) {
    uVar2 = 0;
  }
  else {
    cVar1 = FUN_140102870(plVar9);
    if (cVar1 == '\0') {
      cVar1 = FUN_140340de0(plVar7,param_4,1);
      uVar2 = 0;
      if (cVar1 != '\0') {
        cVar1 = FUN_1400ff650(plVar9,2);
        if (cVar1 != '\0') {
          cVar1 = (**(code **)(*param_1 + 8))(param_1,param_2,param_3);
          if (cVar1 != '\0') {
            local_448 = '\0';
            memset(local_447,0,0x3ff);
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            uVar6 = (**(code **)(*plVar7 + 8))(plVar7);
            uVar11 = (ulonglong)uVar6;
            local_8a8 = uVar4;
            _snprintf(&local_448,0x400,
                      "UPDATE GhostContract SET owner_id = %u WHERE Item_id = %u LIMIT 1");
            local_49 = 0;
            FUN_140008520((int)param_1[3]);
            plVar10 = (longlong *)InstanceGet();
            uVar12 = (undefined7)(uVar11 >> 8);
            (**(code **)(*plVar10 + 0x30))(plVar10,&local_448,1);
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            uVar4 = FUN_140337d00(lVar8,uVar4);
            uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
            FUN_140337da0(lVar8,uVar5);
            uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
            FUN_140359020(plVar7,uVar5,uVar4);
            FUN_1403f2320(local_878);
            uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
            local_8a8 = uVar4;
            cVar1 = FUN_1403f23d0(local_878,1,uVar5,CONCAT71(uVar12,2));
            if (cVar1 != '\0') {
              (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,local_878);
            }
            FUN_1403f2370(local_878);
          }
        }
        uVar2 = 1;
      }
    }
    else {
      uVar4 = FUN_1400ffda0(plVar9);
      uVar5 = FUN_1400fda10(plVar9,1,1);
      uVar3 = FUN_1400fda10(plVar9,0x16,1);
      local_898 = 0;
      local_8a0 = 0;
      local_8a8 = CONCAT31(local_8a8._1_3_,1);
      FUN_14033f6b0(plVar7,uVar5,uVar4,uVar3);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CTradeActor@adapter::vfunc_40  @14059cf30  [high:rtti-vtable]  (orig: FUN_14059cf30)
void FUN_14059cf30(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CTradeActor@adapter::vfunc_48  @14059d000  [high:rtti-vtable]  (orig: FUN_14059d000)
void FUN_14059d000(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a710(uVar1);
  return;
}

// ==== CTradeActor@adapter::vfunc_49  @14059d020  [high:rtti-vtable]  (orig: FUN_14059d020)
void FUN_14059d020(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006cc0(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

// ==== CTradeActor@adapter::vfunc_35  @14059d080  [high:rtti-vtable]  (orig: FUN_14059d080)
void FUN_14059d080(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *local_58 [3];
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  
  plVar7 = (longlong *)0x0;
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = plVar7;
  }
  lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,param_2);
  if (lVar4 != 0) {
    uVar3 = FUN_1400fda10(lVar4,1,1);
    cVar2 = FUN_1400ff940(uVar3);
    if (cVar2 != '\0') {
      plVar5 = operator_new(8);
      local_58[0] = plVar7;
      if (plVar5 != (longlong *)0x0) {
        *plVar5 = (longlong)local_58;
        local_58[0] = plVar5;
      }
      local_40 = (longlong *)0x0;
      local_38 = (longlong *)0x0;
      local_30 = 0;
      FUN_140109210(lVar4,local_58);
      plVar5 = local_40;
      if (0 < (int)((longlong)local_38 - (longlong)local_40 >> 3)) {
        plVar1 = local_58[0];
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
          plVar1 = local_58[0];
        }
        while( true ) {
          plVar8 = local_38;
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar8) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar7;
          }
          else {
            plVar8 = (longlong *)*plVar1;
          }
          if ((longlong *)plVar8[4] <= plVar5) {
            _invalid_parameter_noinfo();
          }
          plVar8 = (longlong *)*plVar5;
          if (plVar8 != (longlong *)0x0) {
            (**(code **)(*plVar8 + 0x38))(plVar8,2);
            (**(code **)(*plVar8 + 0x50))(plVar8);
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar7;
          }
          else {
            plVar8 = (longlong *)*plVar1;
          }
          if ((longlong *)plVar8[4] <= plVar5) {
            _invalid_parameter_noinfo();
          }
          plVar5 = plVar5 + 1;
        }
        lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                          (*(longlong **)(param_1 + 0x10),param_3);
        if (lVar6 != 0) {
          FUN_14019a030(lVar6,param_2,0,0);
        }
      }
      if (local_40 != (longlong *)0x0) {
        operator_delete(local_40);
      }
      local_40 = (longlong *)0x0;
      local_38 = (longlong *)0x0;
      local_30 = 0;
      operator_delete(local_58[0]);
    }
    cVar2 = FUN_140102870(lVar4);
    if (cVar2 != '\0') {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar7;
      }
      (**(code **)(*plVar5 + 0x30))(plVar5,param_2,1,0);
    }
  }
  return;
}

