// ==== CMsgTime@world_kernel::vfunc_1  @140082c30  [high:rtti-vtable]  (orig: FUN_140082c30)
ulonglong FUN_140082c30(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x7f2);
}

// ==== CMsgTime@world_kernel::vfunc_3  @140082c60  [high:rtti-vtable]  (orig: FUN_140082c60)
void FUN_140082c60(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgTime@world_kernel::vfunc_0  @140082ca0  [high:rtti-vtable]  (orig: FUN_140082ca0)
undefined8 * FUN_140082ca0(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgTime::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

