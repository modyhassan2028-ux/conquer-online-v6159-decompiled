// ==== CMsgShowHandLayCard@texasholdem::vfunc_1  @1404db390  [high:rtti-vtable]  (orig: FUN_1404db390)
undefined8 FUN_1404db390(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandLayCard@texasholdem::vfunc_0  @1404db430  [high:rtti-vtable]  (orig: FUN_1404db430)
undefined8 * FUN_1404db430(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandLayCard::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

