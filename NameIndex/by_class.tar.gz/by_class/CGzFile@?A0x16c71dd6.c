// ==== CGzFile@?A0x16c71dd6::vfunc_1  @140573880  [high:rtti-vtable]  (orig: FUN_140573880)
bool FUN_140573880(longlong param_1)

{
  return 0 < *(int *)(param_1 + 8);
}

// ==== CGzFile@?A0x16c71dd6::vfunc_2  @140573890  [high:rtti-vtable]  (orig: FUN_140573890)
int FUN_140573890(longlong param_1,void *param_2,int param_3,int param_4)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  param_3 = param_3 * param_4;
  if (*(int *)(param_1 + 8) < iVar1 + param_3) {
    param_3 = *(int *)(param_1 + 8) - iVar1;
  }
  if (param_2 != (void *)0x0) {
    memcpy(param_2,(void *)((longlong)iVar1 + *(longlong *)(param_1 + 0x10)),(longlong)param_3);
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + param_3;
  return param_3;
}

// ==== CGzFile@?A0x16c71dd6::vfunc_0  @140573dc0  [high:rtti-vtable]  (orig: FUN_140573dc0)
undefined8 * FUN_140573dc0(undefined8 *param_1,uint param_2)

{
  *param_1 = _anon_16C71DD6::CGzFile::vftable;
  if ((void *)param_1[2] != (void *)0x0) {
    operator_delete__((void *)param_1[2]);
  }
  *param_1 = IFile::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

