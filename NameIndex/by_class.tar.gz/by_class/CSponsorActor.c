// ==== CSponsorActor::BroadcastMsg  @140595a30  [high:log-string]  (orig: FUN_140595a30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140595a30(longlong param_1,undefined4 param_2,longlong param_3)

{
  int iVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_3 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    FUN_14015b240();
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = 0;
    local_4b8 = 2000;
    local_4c0 = 0xffffff;
    local_4c8 = 0;
    iVar1 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_3);
    if (iVar1 == 0) {
      local_4c8 = CONCAT44(local_4c8._4_4_,0xf3);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar3 = (longlong *)FUN_1400876b0(uVar2);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,param_2,1);
      if (plVar3 == (longlong *)0x0) {
        log_InlineLogERROR("CSponsorActor::BroadcastMsg(idMap=%u)");
      }
      else {
        (**(code **)(*plVar3 + 0x38))(plVar3,local_478,0);
      }
    }
    FUN_14015b2c0(local_478);
  }
  return;
}

