// ==== CChatNetMsg::helper_1400330a0  @1400330a0  [medium:callgraph-r0]  (orig: FUN_1400330a0)
ulonglong FUN_1400330a0(undefined8 param_1,longlong param_2)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  uVar1 = FUN_140031f10(param_1,*(undefined4 *)(param_2 + 0x414),*(undefined4 *)(param_2 + 8),
                        param_2 + 0x10,*(undefined4 *)(param_2 + 0xc));
  return uVar1;
}

// ==== CChatNetMsg::ctor_or_dtor  @14003f900  [high:vtable-assign]  (orig: FUN_14003f900)
void FUN_14003f900(undefined8 *param_1)

{
  *param_1 = CChatNetMsg::vftable;
  return;
}

// ==== CChatNetMsg::vfunc_2  @14003f940  [high:rtti-vtable]  (orig: FUN_14003f940)
bool FUN_14003f940(longlong param_1)

{
  return *(int *)(param_1 + 8) != 0;
}

// ==== CChatNetMsg::vfunc_1  @14003f950  [high:rtti-vtable]  (orig: FUN_14003f950)
undefined8 FUN_14003f950(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CChatNetMsg::vfunc_3  @14003f980  [high:rtti-vtable]  (orig: FUN_14003f980)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14003f980(longlong param_1)

{
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  local_428 = *(undefined4 *)(param_1 + 0xc);
  _snprintf(&local_418,0x3ff,"Process Msg:%d, Size:%d");
  log_InlineLogMessage(&local_418);
  return;
}

// ==== CChatNetMsg::vfunc_4  @14003fa00  [high:rtti-vtable]  (orig: FUN_14003fa00)
void FUN_14003fa00(void)

{
  FUN_1400330a0(DAT_140975aa0);
  return;
}

// ==== CChatNetMsg::ctor_or_dtor  @14003fc90  [high:vtable-assign]  (orig: FUN_14003fc90)
undefined8 * FUN_14003fc90(undefined8 *param_1)

{
  *param_1 = CChatNetMsg::vftable;
  *(undefined4 *)(param_1 + 0x83) = 0;
  *(undefined4 *)((longlong)param_1 + 0x41c) = 0;
  memset(param_1 + 2,0,0x400);
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return param_1;
}

// ==== CChatNetMsg::ctor_or_dtor  @14003fce0  [high:vtable-assign]  (orig: FUN_14003fce0)
undefined8 * FUN_14003fce0(undefined8 *param_1,byte param_2)

{
  *param_1 = CChatNetMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

