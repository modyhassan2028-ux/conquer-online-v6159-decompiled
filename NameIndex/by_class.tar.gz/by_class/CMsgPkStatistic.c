// ==== CMsgPkStatistic::helper_1401a3d80  @1401a3d80  [medium:callgraph-r0]  (orig: FUN_1401a3d80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401a3d80(longlong param_1,int param_2)

{
  ulonglong uVar1;
  longlong *plVar2;
  longlong *plVar3;
  bool bVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong lVar10;
  undefined8 uVar11;
  int iVar12;
  longlong *plVar13;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  int local_4a8;
  undefined8 local_498;
  undefined8 uStack_490;
  longlong local_488;
  undefined8 local_480;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_480 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_2 < 0) {
    local_4b8 = 0x5b23;
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar1 = *(ulonglong *)(param_1 + 0xbd0);
  FUN_1403f2a40(local_468);
  cVar5 = FUN_1403f2ac0(local_468,1,uVar1 & 0xffffffff);
  if (cVar5 == '\0') goto LAB_1401a3fe8;
  uVar1 = *(ulonglong *)(param_1 + 0xbf8);
  if (uVar1 < *(ulonglong *)(param_1 + 0xbf0)) {
    _invalid_parameter_noinfo();
  }
  plVar2 = *(longlong **)(param_1 + 0xbd8);
  iVar12 = 0;
  local_4a8 = 0;
  local_498 = plVar2;
  uStack_490 = (longlong *)uVar1;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar10 = 0;
  }
  else {
    lVar10 = *plVar2;
  }
  plVar13 = (longlong *)(uVar1 + (longlong)(param_2 * 10) * -8);
  if (*(longlong **)(lVar10 + 0x20) < plVar13) {
LAB_1401a3e90:
    _invalid_parameter_noinfo();
    plVar2 = local_498;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    plVar2 = local_498;
    if (plVar13 < *(longlong **)(lVar10 + 0x18)) goto LAB_1401a3e90;
  }
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0xbf0);
    uStack_490 = plVar13;
    if (*(longlong **)(param_1 + 0xbf8) < plVar3) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xbd8))) {
      _invalid_parameter_noinfo();
    }
    if ((plVar13 == plVar3) || (9 < iVar12)) break;
    local_478 = (undefined4)local_498;
    uStack_474 = local_498._4_4_;
    uStack_470 = (undefined4)uStack_490;
    uStack_46c = uStack_490._4_4_;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (plVar13 <= *(longlong **)(lVar10 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar13 + -1;
    if ((longlong *)CONCAT44(uStack_474,local_478) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *(longlong *)CONCAT44(uStack_474,local_478);
    }
    if (*(longlong **)(lVar10 + 0x20) <= plVar3) {
      _invalid_parameter_noinfo();
    }
    lVar10 = *plVar3;
    local_488 = lVar10;
    if (lVar10 != 0) {
      uVar6 = FUN_1403b3660(lVar10,5);
      uVar7 = FUN_1403b3660(lVar10,4);
      uVar8 = FUN_1403b3660(lVar10,3);
      uVar9 = FUN_1403b3660(lVar10,6);
      uVar11 = FUN_1403b3840(local_488);
      local_4b8 = uVar7;
      local_4b0 = uVar6;
      FUN_1403f2b70(local_468,uVar11,uVar9,uVar8);
      iVar12 = local_4a8 + 1;
      local_4a8 = iVar12;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    bVar4 = plVar13 <= *(longlong **)(lVar10 + 0x18);
    plVar13 = plVar3;
    if (bVar4) {
      _invalid_parameter_noinfo();
    }
  }
  (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_468);
LAB_1401a3fe8:
  FUN_1403f2a90(local_468);
  return;
}

// ==== CMsgPkStatistic::helper_1403b3840  @1403b3840  [medium:callgraph-r1]  (orig: FUN_1403b3840)
longlong FUN_1403b3840(longlong param_1)

{
  return param_1 + 0x18;
}

// ==== CMsgPkStatistic::ctor_or_dtor  @1403f2a40  [high:vtable-assign]  (orig: FUN_1403f2a40)
undefined8 * FUN_1403f2a40(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPkStatistic::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgPkStatistic::ctor_or_dtor  @1403f2a90  [high:vtable-assign]  (orig: FUN_1403f2a90)
void FUN_1403f2a90(undefined8 *param_1)

{
  *param_1 = CMsgPkStatistic::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgPkStatistic::helper_1403f2ac0  @1403f2ac0  [medium:callgraph-r1]  (orig: FUN_1403f2ac0)
undefined8 FUN_1403f2ac0(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulong uVar2;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x8ac;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  uVar2 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgPkStatistic::helper_1403f2b70  @1403f2b70  [medium:callgraph-r1]  (orig: FUN_1403f2b70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403f2b70(longlong param_1,char *param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  undefined1 auStack_58 [32];
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  iVar2 = *(int *)(*(longlong *)(param_1 + 0x428) + 0xc);
  uVar4 = (longlong)iVar2 * 0x20 + 0x30;
  if (uVar4 < 0x3fc) {
    local_38 = 0;
    local_34 = 0;
    local_30 = 0;
    local_2c = 0;
    local_28 = 0;
    *(int *)(param_1 + 0xc) = iVar2 * 0x20 + 0x30;
    local_24 = 0;
    local_20 = 0;
    local_1c = 0;
    if (param_2 != (char *)0x0) {
      tq::SafeCopy((char *)&local_38,param_2,0x10);
    }
    lVar3 = *(longlong *)(param_1 + 0x428);
    lVar5 = (longlong)*(int *)(lVar3 + 0xc) * 0x20;
    *(undefined4 *)(lVar5 + 0x10 + lVar3) = local_38;
    *(undefined4 *)(lVar5 + 0x14 + lVar3) = local_34;
    *(undefined4 *)(lVar5 + 0x18 + lVar3) = local_30;
    *(undefined4 *)(lVar5 + 0x1c + lVar3) = local_2c;
    *(undefined4 *)(lVar5 + 0x20 + lVar3) = param_3;
    *(undefined4 *)(lVar5 + 0x24 + lVar3) = param_4;
    *(undefined4 *)(lVar5 + 0x28 + lVar3) = param_6;
    *(undefined4 *)(lVar5 + 0x2c + lVar3) = param_5;
    lVar3 = *(longlong *)(param_1 + 0x428);
    piVar1 = (int *)(lVar3 + 0xc);
    *piVar1 = *piVar1 + 1;
    uVar4 = CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
  }
  else {
    uVar4 = uVar4 & 0xffffffffffffff00;
  }
  return uVar4;
}

// ==== CMsgPkStatistic::ctor_or_dtor  @1403f2ca0  [high:vtable-assign]  (orig: FUN_1403f2ca0)
undefined8 * FUN_1403f2ca0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPkStatistic::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgPkStatistic::vfunc_3  @1403f2cf0  [high:rtti-vtable]  (orig: FUN_1403f2cf0)
void FUN_1403f2cf0(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  undefined8 uVar9;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if (plVar6 != (longlong *)0x0) {
    plVar7 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar6[0x1e2];
    lVar5 = *plVar7;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    (**(code **)(lVar5 + 0x108))(plVar7,uVar4,(int)lVar2,*puVar1);
    cVar3 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2);
    if (cVar3 == '\0') {
      pIVar8 = theInstance();
      lVar5 = plVar6[2];
      uVar9 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x0001403f2df4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(lVar5 + 0x358))(plVar6 + 2,uVar9);
      return;
    }
    if (*(short *)(*(longlong *)(param_1 + 0x428) + 4) != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403f2e1c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CMsgArenicWitness::Process invalid action:%d");
      return;
    }
    FUN_1401a3d80(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
  }
  return;
}

