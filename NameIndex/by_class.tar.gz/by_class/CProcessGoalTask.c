// ==== CProcessGoalTask::helper_1404df170  @1404df170  [medium:callgraph-r0]  (orig: FUN_1404df170)
void FUN_1404df170(void *param_1)

{
  if ((DAT_140976548 & 1) == 0) {
    DAT_140976548 = DAT_140976548 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976540,"CProcessGoalTask");
    atexit((_func_5014 *)&LAB_1406d6f50);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404df1c5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976540,param_1);
  return;
}

// ==== CProcessGoalTask::ctor_or_dtor  @1404df230  [high:vtable-assign]  (orig: FUN_1404df230)
undefined8 * FUN_1404df230(undefined8 *param_1,byte param_2)

{
  *param_1 = CProcessGoalTask::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1404df170();
  }
  return param_1;
}

// ==== CProcessGoalTask::ctor_or_dtor  @1404df260  [high:vtable-assign]  (orig: FUN_1404df260)
undefined8 * FUN_1404df260(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140976548 & 1) == 0) {
    DAT_140976548 = DAT_140976548 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976540,"CProcessGoalTask");
    atexit((_func_5014 *)&LAB_1406d6f50);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976540,0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CProcessGoalTask::vftable;
    puVar1[1] = 0;
    *(undefined4 *)(puVar1 + 2) = 0;
  }
  return puVar1;
}

