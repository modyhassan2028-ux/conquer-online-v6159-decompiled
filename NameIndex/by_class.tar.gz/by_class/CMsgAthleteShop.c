// ==== CMsgAthleteShop::helper_140168ec0  @140168ec0  [medium:callgraph-r0]  (orig: FUN_140168ec0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140168ec0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_4b8 [32];
  undefined8 local_498;
  undefined1 local_488 [1136];
  ulonglong local_18;
  
  local_498 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  FUN_1403b8560(local_488);
  uVar1 = FUN_1403737d0(param_1 + 0xe78);
  iVar2 = FUN_1403b8690(local_488,uVar1);
  if (iVar2 != 0) {
    (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_488);
  }
  FUN_1403b85b0(local_488);
  return;
}

// ==== CMsgAthleteShop::ctor_or_dtor  @1403b8560  [high:vtable-assign]  (orig: FUN_1403b8560)
undefined8 * FUN_1403b8560(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAthleteShop::vftable;
  FUN_1405765d0(param_1 + 0x85);
  FUN_1402b5600(param_1);
  return param_1;
}

// ==== CMsgAthleteShop::ctor_or_dtor  @1403b85b0  [high:vtable-assign]  (orig: FUN_1403b85b0)
void FUN_1403b85b0(undefined8 *param_1)

{
  *param_1 = CMsgAthleteShop::vftable;
  FUN_1405766a0(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgAthleteShop::vfunc_1  @1403b85f0  [high:rtti-vtable]  (orig: FUN_1403b85f0)
undefined8 FUN_1403b85f0(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  uVar4 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    uVar4 = 0;
  }
  else if (*(int *)(param_1 + 8) == 0x988) {
    plVar1 = (longlong *)(param_1 + 0x428);
    cVar2 = FUN_140554950(plVar1);
    if (cVar2 == '\0') {
      cVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
      if (cVar2 == '\0') {
        lVar3 = (**(code **)(*plVar1 + 0x28))(plVar1,local_30,param_3,param_4,uVar4);
        if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
          lVar3 = lVar3 + 8;
        }
        else {
          lVar3 = *(longlong *)(lVar3 + 8);
        }
        log_InlineLogERROR(&DAT_140764f10,lVar3);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
      }
      else {
        log_InlineLogERROR("CMsgAthleteShop_pb::CreateBufMsg ParseFromArray failed.");
      }
      uVar4 = 0;
    }
    else {
      uVar4 = 1;
    }
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CMsgAthleteShop::helper_1403b8690  @1403b8690  [medium:callgraph-r1]  (orig: FUN_1403b8690)
undefined8 FUN_1403b8690(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  uVar4 = 0xfffffffffffffffe;
  FUN_1402b5600();
  *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 1;
  *(undefined4 *)(param_1 + 0x460) = param_2;
  cVar1 = FUN_1405551c0(param_1 + 0x428,param_1 + 0x10,0x400,param_4,uVar4);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x20))(param_1 + 0x428);
    if (cVar1 == '\0') {
      lVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x28))(param_1 + 0x428,local_30);
      if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
        lVar3 = lVar3 + 8;
      }
      else {
        lVar3 = *(longlong *)(lVar3 + 8);
      }
      log_InlineLogERROR(&DAT_140764fc0,lVar3);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
    }
    else {
      log_InlineLogERROR("CMsgAthleteShop_pb::CreateBufMsg SerializeToArray failed.");
    }
    uVar4 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 8) = 0x988;
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgAthleteShop::ctor_or_dtor  @1403b8780  [high:vtable-assign]  (orig: FUN_1403b8780)
undefined8 * FUN_1403b8780(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAthleteShop::vftable;
  FUN_1405766a0(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAthleteShop::vfunc_3  @1403b87e0  [high:rtti-vtable]  (orig: FUN_1403b87e0)
void FUN_1403b87e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x88))(*(longlong **)(lVar1 + 0x90),param_1);
  if (lVar1 != 0) {
    FUN_140168ec0(lVar1);
  }
  return;
}

