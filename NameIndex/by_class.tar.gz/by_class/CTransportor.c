// ==== CTransportor::ctor_or_dtor  @140420340  [high:vtable-assign]  (orig: FUN_140420340)
void FUN_140420340(undefined8 *param_1)

{
  *param_1 = CTransportor::vftable;
  param_1[2] = CTransportor::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 7));
  param_1[2] = IMapThing::vftable;
  FUN_1402b55a0(param_1);
  return;
}

// ==== CTransportor::vfunc_1  @140420420  [high:rtti-vtable]  (orig: FUN_140420420)
void FUN_140420420(longlong param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(param_1 + -0x10);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CTransportor::vfunc_1  @140420440  [high:rtti-vtable]  (orig: FUN_140420440)
undefined4 FUN_140420440(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

// ==== CTransportor::vfunc_2  @140420450  [high:rtti-vtable]  (orig: FUN_140420450)
undefined8 FUN_140420450(void)

{
  return 0x10000;
}

// ==== CTransportor::vfunc_4  @140420460  [high:rtti-vtable]  (orig: FUN_140420460)
undefined4 FUN_140420460(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1c);
}

// ==== CTransportor::vfunc_4  @140420470  [high:rtti-vtable]  (orig: FUN_140420470)
undefined4 FUN_140420470(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CTransportor::vfunc_5  @140420480  [high:rtti-vtable]  (orig: FUN_140420480)
undefined4 FUN_140420480(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x14);
}

// ==== CTransportor::vfunc_6  @140420490  [high:rtti-vtable]  (orig: FUN_140420490)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140420490(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == (longlong *)0x0) {
    local_468 = 0x5f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140420930(local_448);
    cVar1 = FUN_1404209e0(local_448,0,param_1 + -0x10);
    if (cVar1 != '\0') {
      (**(code **)(*param_2 + 0x350))(param_2,local_448);
    }
    FUN_140420980(local_448);
  }
  return;
}

// ==== CTransportor::vfunc_7  @140420550  [high:rtti-vtable]  (orig: FUN_140420550)
ulonglong FUN_140420550(longlong param_1,int param_2,longlong *param_3)

{
  ulonglong in_RAX;
  
  if (param_2 == 0x10000) {
    *param_3 = param_1 + -0x10;
    return CONCAT71((int7)((ulonglong)(param_1 + -0x10) >> 8),1);
  }
  *param_3 = 0;
  return in_RAX & 0xffffffffffffff00;
}

// ==== CTransportor::vfunc_8  @140420570  [high:rtti-vtable]  (orig: FUN_140420570)
undefined1 FUN_140420570(undefined8 param_1,undefined8 *param_2)

{
  *param_2 = 0;
  return 0;
}

// ==== CTransportor::helper_140420580  @140420580  [medium:callgraph-r1]  (orig: FUN_140420580)
undefined4 FUN_140420580(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x28);
}

// ==== CTransportor::helper_1404205b0  @1404205b0  [medium:callgraph-r1]  (orig: FUN_1404205b0)
longlong FUN_1404205b0(longlong param_1)

{
  return param_1 + 0x60;
}

// ==== CTransportor::vfunc_0  @1404205d0  [high:rtti-vtable]  (orig: FUN_1404205d0)
void FUN_1404205d0(longlong param_1)

{
  FUN_140420830(param_1 + -0x10);
  return;
}

// ==== CTransportor::vfunc_2  @1404205e0  [high:rtti-vtable]  (orig: FUN_1404205e0)
void FUN_1404205e0(longlong param_1)

{
  FUN_140420440(param_1 + -0x10);
  return;
}

// ==== CTransportor::vfunc_3  @1404205f0  [high:rtti-vtable]  (orig: FUN_1404205f0)
void FUN_1404205f0(longlong param_1)

{
  FUN_140420450(param_1 + -0x10);
  return;
}

// ==== CTransportor::helper_1404206c0  @1404206c0  [medium:callgraph-r0]  (orig: FUN_1404206c0)
void FUN_1404206c0(void *param_1)

{
  if ((DAT_1409763c8 & 1) == 0) {
    DAT_1409763c8 = DAT_1409763c8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763c0,"CTransportor");
    atexit((_func_5014 *)&LAB_1406d6dd0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140420715. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763c0,param_1);
  return;
}

// ==== CTransportor::ctor_or_dtor  @140420780  [high:vtable-assign]  (orig: FUN_140420780)
undefined8 * FUN_140420780(undefined8 *param_1,undefined4 param_2)

{
  FUN_1402b5540();
  param_1[2] = IMapThing::vftable;
  *param_1 = CTransportor::vftable;
  param_1[2] = CTransportor::vftable;
  *(undefined4 *)(param_1 + 6) = 0;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 7),"");
  *(undefined4 *)(param_1 + 1) = 0x10000;
  *(undefined4 *)(param_1 + 3) = param_2;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined1 *)((longlong)param_1 + 0x84) = 0;
  return param_1;
}

// ==== CTransportor::ctor_or_dtor  @140420830  [high:vtable-assign]  (orig: FUN_140420830)
undefined8 * FUN_140420830(undefined8 *param_1,uint param_2)

{
  *param_1 = CTransportor::vftable;
  param_1[2] = CTransportor::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 7));
  param_1[2] = IMapThing::vftable;
  FUN_1402b55a0(param_1);
  if ((param_2 & 1) != 0) {
    FUN_1404206c0(param_1);
  }
  return param_1;
}

// ==== CTransportor::helper_1404209e0  @1404209e0  [medium:callgraph-r0]  (orig: FUN_1404209e0)
ulonglong FUN_1404209e0(longlong param_1,undefined2 param_2,longlong *param_3)

{
  undefined4 uVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  char *pcVar3;
  uint7 extraout_var;
  longlong lVar4;
  
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  **(undefined2 **)(param_1 + 0x428) = param_2;
  uVar1 = (**(code **)(*param_3 + 8))(param_3);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar1;
  uVar1 = (**(code **)(*param_3 + 0x20))(param_3);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar1;
  uVar1 = (**(code **)(param_3[2] + 0x20))(param_3 + 2);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar1;
  uVar1 = (**(code **)(param_3[2] + 0x28))(param_3 + 2);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar1;
  uVar1 = FUN_140420580(param_3);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar1;
  lVar2 = FUN_1404205b0(param_3);
  lVar4 = 0;
  if (lVar2 != 0) {
    pcVar3 = (char *)FUN_1404205b0(param_3);
    tq::StrCopy((char *)(*(longlong *)(param_1 + 0x428) + 0x18),pcVar3,0x24);
    lVar4 = (ulonglong)extraout_var << 8;
  }
  *(undefined4 *)(param_1 + 8) = 0x960;
  *(undefined4 *)(param_1 + 0xc) = 0x3c;
  return CONCAT71((int7)((ulonglong)lVar4 >> 8),1);
}

