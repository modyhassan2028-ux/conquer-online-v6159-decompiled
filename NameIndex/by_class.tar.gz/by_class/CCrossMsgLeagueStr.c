// ==== CCrossMsgLeagueStr::ctor_or_dtor  @1403f36a0  [high:vtable-assign]  (orig: FUN_1403f36a0)
undefined8 * FUN_1403f36a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueStr::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x1c),0x3f1,true);
  return param_1;
}

// ==== CCrossMsgLeagueStr::ctor_or_dtor  @1403f3720  [high:vtable-assign]  (orig: FUN_1403f3720)
void FUN_1403f3720(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueStr::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CCrossMsgLeagueStr::vfunc_1  @1403f3760  [high:rtti-vtable]  (orig: FUN_1403f3760)
ulonglong FUN_1403f3760(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c63);
}

// ==== CCrossMsgLeagueStr::vfunc_3  @1403f3820  [high:rtti-vtable]  (orig: FUN_1403f3820)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403f3820(longlong param_1)

{
  short sVar1;
  short *psVar2;
  longlong *plVar3;
  undefined1 auStack_58 [32];
  undefined4 local_38;
  char local_28 [16];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  plVar3 = (longlong *)FUN_140087ed0();
  if (plVar3 == (longlong *)0x0) {
    local_38 = 0x3c;
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pSyndicateMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgleaguestr.cpp"
                      );
  }
  else {
    local_28[0] = '\0';
    local_28[1] = '\0';
    local_28[2] = '\0';
    local_28[3] = '\0';
    local_28[4] = '\0';
    local_28[5] = '\0';
    local_28[6] = '\0';
    local_28[7] = '\0';
    local_28[8] = '\0';
    local_28[9] = '\0';
    local_28[10] = '\0';
    local_28[0xb] = '\0';
    local_28[0xc] = '\0';
    local_28[0xd] = '\0';
    local_28[0xe] = '\0';
    local_28[0xf] = 0;
    tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_28,0x10);
    psVar2 = *(short **)(param_1 + 0x428);
    sVar1 = *psVar2;
    if (sVar1 == 0) {
      (**(code **)(*plVar3 + 0x498))
                (plVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4),local_28);
    }
    else if (sVar1 == 1) {
      (**(code **)(*plVar3 + 0x490))
                (plVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4),local_28);
    }
    else if (sVar1 == 2) {
      (**(code **)(*plVar3 + 0x4a0))
                (plVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4),local_28);
    }
    else if (sVar1 == 3) {
      (**(code **)(*plVar3 + 0x4a8))(plVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4))
      ;
    }
  }
  return;
}

// ==== CCrossMsgLeagueStr::ctor_or_dtor  @1403f3950  [high:vtable-assign]  (orig: FUN_1403f3950)
undefined8 * FUN_1403f3950(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueStr::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

