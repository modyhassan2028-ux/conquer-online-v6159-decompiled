// ==== CNpcPath::ctor_or_dtor  @1404be770  [high:vtable-assign]  (orig: FUN_1404be770)
void FUN_1404be770(undefined8 *param_1)

{
  *param_1 = CNpcPath::vftable;
  if ((longlong *)param_1[0xc] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xc] + 0x58))();
    param_1[0xc] = 0;
  }
  return;
}

// ==== CNpcPath::vfunc_9  @1404be7a0  [high:rtti-vtable]  (orig: FUN_1404be7a0)
void FUN_1404be7a0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 *param_4,
                  undefined4 param_5,char *param_6,undefined2 param_7)

{
  *(undefined4 *)(param_1 + 8) = param_2;
  *(undefined4 *)(param_1 + 0xc) = param_3;
  *(undefined8 *)(param_1 + 0x10) = *param_4;
  *(undefined4 *)(param_1 + 0x18) = param_5;
  *(undefined2 *)(param_1 + 0x5c) = param_7;
                    /* WARNING: Could not recover jumptable at 0x0001404be7cd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  strncpy((char *)(param_1 + 0x1c),param_6,0x40);
  return;
}

// ==== CNpcPath::vfunc_1  @1404be7e0  [high:rtti-vtable]  (orig: FUN_1404be7e0)
bool FUN_1404be7e0(longlong param_1)

{
  return *(int *)(param_1 + 8) != 0;
}

// ==== CNpcPath::vfunc_3  @1404be7f0  [high:rtti-vtable]  (orig: FUN_1404be7f0)
undefined4 FUN_1404be7f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CNpcPath::vfunc_4  @1404be800  [high:rtti-vtable]  (orig: FUN_1404be800)
undefined4 FUN_1404be800(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CNpcPath::vfunc_5  @1404be810  [high:rtti-vtable]  (orig: FUN_1404be810)
undefined8 FUN_1404be810(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpcPath::vfunc_6  @1404be850  [high:rtti-vtable]  (orig: FUN_1404be850)
undefined8 * FUN_1404be850(longlong param_1,undefined8 *param_2)

{
  *param_2 = *(undefined8 *)(param_1 + 0x10);
  return param_2;
}

// ==== CNpcPath::vfunc_7  @1404be860  [high:rtti-vtable]  (orig: FUN_1404be860)
undefined4 FUN_1404be860(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

// ==== CNpcPath::vfunc_8  @1404be870  [high:rtti-vtable]  (orig: FUN_1404be870)
longlong FUN_1404be870(longlong param_1)

{
  return param_1 + 0x1c;
}

// ==== CNpcPath::vfunc_2  @1404be880  [high:rtti-vtable]  (orig: FUN_1404be880)
undefined4 FUN_1404be880(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CNpcPath::vfunc_10  @1404be890  [high:rtti-vtable]  (orig: FUN_1404be890)
void FUN_1404be890(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CNpcPath::helper_1404beb20  @1404beb20  [medium:callgraph-r0]  (orig: FUN_1404beb20)
void FUN_1404beb20(void *param_1)

{
  if ((DAT_1409764d8 & 1) == 0) {
    DAT_1409764d8 = DAT_1409764d8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409764d0,"CNpcPath");
    atexit((_func_5014 *)&LAB_1406d6ee0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404beb75. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409764d0,param_1);
  return;
}

// ==== CNpcPath::ctor_or_dtor  @1404bebe0  [high:vtable-assign]  (orig: FUN_1404bebe0)
undefined8 * FUN_1404bebe0(undefined8 *param_1,uint param_2)

{
  *param_1 = CNpcPath::vftable;
  if ((longlong *)param_1[0xc] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xc] + 0x58))();
    param_1[0xc] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_1404beb20(param_1);
  }
  return param_1;
}

// ==== CNpcPath::ctor_or_dtor  @1404bf140  [high:vtable-assign]  (orig: FUN_1404bf140)
undefined8 * FUN_1404bf140(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  *param_1 = CNpcPath::vftable;
  puVar2 = (undefined8 *)0x0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined2 *)((longlong)param_1 + 0x5c) = 0;
  param_1[0xc] = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined8 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x24) = 0;
  *(undefined8 *)((longlong)param_1 + 0x2c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x34) = 0;
  *(undefined8 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x44) = 0;
  *(undefined8 *)((longlong)param_1 + 0x4c) = 0;
  *(undefined8 *)((longlong)param_1 + 0x54) = 0;
  puVar1 = operator_new(0x18);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = IGameData::vftable;
    *puVar1 = CGameData<&char*_szNpcPath,&char*_szID>::vftable;
    *(undefined1 *)(puVar1 + 2) = 0;
    puVar1[1] = 0;
    puVar2 = puVar1;
  }
  param_1[0xc] = puVar2;
  return param_1;
}

