// ==== CFacebookInfoMgr::helper_140226be0  @140226be0  [medium:callgraph-r0]  (orig: FUN_140226be0)
void FUN_140226be0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  bool bVar7;
  
  plVar4 = *(longlong **)param_1[8];
  plVar1 = (longlong *)param_1[2];
  do {
    while( true ) {
      while( true ) {
        plVar5 = (longlong *)param_1[8];
        if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[2])) {
          _invalid_parameter_noinfo();
        }
        if (plVar4 == plVar5) {
          FUN_14002cc10(param_1 + 2);
          if (param_1 != (undefined8 *)0x0) {
            (**(code **)*param_1)(param_1,1);
          }
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        puVar2 = (undefined8 *)plVar4[4];
        if (puVar2 != (undefined8 *)0x0) {
          (**(code **)*puVar2)(puVar2,1,param_3,param_4,puVar2);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar4;
      plVar3 = (longlong *)plVar4[2];
      if (*(char *)(plVar4[2] + 0x29) != '\0') break;
      do {
        plVar4 = plVar3;
        plVar3 = (longlong *)*plVar4;
      } while (*(char *)(*plVar4 + 0x29) == '\0');
    }
    do {
      plVar4 = (longlong *)plVar5[1];
      if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
      bVar7 = plVar5 == (longlong *)plVar4[2];
      plVar5 = plVar4;
    } while (bVar7);
  } while( true );
}

// ==== CFacebookInfoMgr::helper_140226ea0  @140226ea0  [medium:callgraph-r0]  (orig: FUN_140226ea0)
undefined8 FUN_140226ea0(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 uVar5;
  int iVar6;
  undefined4 local_38 [2];
  longlong *local_30;
  undefined1 local_28 [32];
  
  plVar1 = (longlong *)InstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,"SELECT * FROM cq_facebook",2);
  uVar5 = 0;
  if (plVar1 != (longlong *)0x0) {
    iVar6 = 0;
    while( true ) {
      uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
      if (uVar2 <= (ulonglong)(longlong)iVar6) break;
      (**(code **)(*plVar1 + 0x30))(plVar1,(longlong)iVar6);
      plVar3 = (longlong *)(**(code **)(*plVar1 + 0x38))(plVar1);
      if (plVar3 != (longlong *)0x0) {
        plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
        local_38[0] = (**(code **)(*plVar4 + 0x40))(plVar4);
        local_30 = plVar3;
        FUN_14002d3d0(param_1 + 0x10,local_28,local_38);
      }
      iVar6 = iVar6 + 1;
    }
    (**(code **)*plVar1)(plVar1);
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CFacebookInfoMgr::ctor_or_dtor  @1402273a0  [high:vtable-assign]  (orig: FUN_1402273a0)
void FUN_1402273a0(undefined8 *param_1)

{
  *param_1 = CFacebookInfoMgr::vftable;
  FUN_14002de90(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CFacebookInfoMgr::ctor_or_dtor  @1402273e0  [high:vtable-assign]  (orig: FUN_1402273e0)
undefined8 * FUN_1402273e0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CFacebookInfoMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_14002e1c0(param_1 + 2);
  return param_1;
}

// ==== CFacebookInfoMgr::ctor_or_dtor  @140227420  [high:vtable-assign]  (orig: FUN_140227420)
undefined8 * FUN_140227420(undefined8 *param_1,uint param_2)

{
  *param_1 = CFacebookInfoMgr::vftable;
  FUN_14002de90(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFacebookInfoMgr::ctor_or_dtor  @140227490  [high:vtable-assign]  (orig: FUN_140227490)
undefined8 * FUN_140227490(undefined4 param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x50);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CFacebookInfoMgr::vftable;
    *(undefined4 *)(puVar2 + 1) = param_1;
    FUN_14002e1c0(puVar2 + 2);
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140226ea0(puVar2);
    if (cVar1 == '\0') {
      FUN_140226be0(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

