// ==== CMsgOSEnter::helper_14008b150  @14008b150  [medium:callgraph-r0]  (orig: FUN_14008b150)
undefined1 FUN_14008b150(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x730);
}

// ==== CMsgOSEnter::ctor_or_dtor  @14044fd60  [high:vtable-assign]  (orig: FUN_14044fd60)
undefined8 * FUN_14044fd60(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgOSEnter::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgOSEnter::ctor_or_dtor  @14044fdb0  [high:vtable-assign]  (orig: FUN_14044fdb0)
void FUN_14044fdb0(undefined8 *param_1)

{
  *param_1 = CMsgOSEnter::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgOSEnter::vfunc_1  @14044fde0  [high:rtti-vtable]  (orig: FUN_14044fde0)
ulonglong FUN_14044fde0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xb56);
}

// ==== CMsgOSEnter::ctor_or_dtor  @14044fe10  [high:vtable-assign]  (orig: FUN_14044fe10)
undefined8 * FUN_14044fe10(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgOSEnter::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgOSEnter::vfunc_3  @14044fe60  [high:rtti-vtable]  (orig: FUN_14044fe60)
void FUN_14044fe60(longlong param_1)

{
  char *pcVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  longlong lVar8;
  longlong *plVar9;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x88))(plVar6,param_1);
    if (plVar6 != (longlong *)0x0) {
      cVar2 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2);
      if (cVar2 == '\0') {
        pIVar7 = theInstance();
        lVar8 = plVar6[2];
        uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_DIE");
        (**(code **)(lVar8 + 0x358))(plVar6 + 2,uVar5);
      }
      else {
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar8 + 0x148) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar5 = 0;
        }
        else {
          uVar5 = *(undefined8 *)(lVar8 + 0x148);
        }
        cVar2 = FUN_140005850(uVar5);
        if (cVar2 == '\0') {
          pIVar7 = theInstance();
          lVar8 = plVar6[2];
          uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_CROSS_SERVER_DISCONNECT");
          (**(code **)(lVar8 + 0x358))(plVar6 + 2,uVar5);
        }
        else {
          pcVar1 = *(char **)(param_1 + 0x428);
          if (*pcVar1 == '\0') {
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            cVar2 = FUN_1400b3d90(uVar5,*(undefined4 *)(pcVar1 + 1));
            if (cVar2 == '\0') {
              pIVar7 = theInstance();
              lVar8 = plVar6[2];
              uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_OS_ENTER_DISCONNECT");
              (**(code **)(lVar8 + 0x358))(plVar6 + 2,uVar5);
            }
            else {
              FUN_1401bdae0(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1),0);
            }
          }
          else {
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            cVar2 = FUN_14008b150(uVar5);
            if (cVar2 != '\0') {
              plVar9 = (longlong *)FUN_140118320();
              lVar8 = *plVar9;
              uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
              iVar4 = (**(code **)(lVar8 + 0x28))(plVar9,uVar3);
              if (iVar4 == 0) {
                FUN_1401bd0d0(plVar6,0,0);
              }
              else {
                pIVar7 = theInstance();
                lVar8 = plVar6[2];
                uVar5 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_CROSS_SERVER_DENY_TEAM");
                (**(code **)(lVar8 + 0x358))(plVar6 + 2,uVar5);
              }
            }
          }
        }
      }
    }
  }
  return;
}

