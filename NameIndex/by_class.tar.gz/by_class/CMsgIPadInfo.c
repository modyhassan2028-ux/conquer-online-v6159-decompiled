// ==== CMsgIPadInfo::helper_140167950  @140167950  [medium:callgraph-r0]  (orig: FUN_140167950)
void FUN_140167950(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x12f0) = param_2;
  return;
}

// ==== CMsgIPadInfo::ctor_or_dtor  @1404518e0  [high:vtable-assign]  (orig: FUN_1404518e0)
undefined8 * FUN_1404518e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgIPadInfo::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x11),0x3ff,true);
  return param_1;
}

// ==== CMsgIPadInfo::ctor_or_dtor  @140451960  [high:vtable-assign]  (orig: FUN_140451960)
void FUN_140451960(undefined8 *param_1)

{
  *param_1 = CMsgIPadInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgIPadInfo::vfunc_1  @1404519a0  [high:rtti-vtable]  (orig: FUN_1404519a0)
bool FUN_1404519a0(void)

{
  int iVar1;
  
  iVar1 = FUN_1402b5640();
  return iVar1 != 0;
}

// ==== CMsgIPadInfo::ctor_or_dtor  @1404519f0  [high:vtable-assign]  (orig: FUN_1404519f0)
undefined8 * FUN_1404519f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgIPadInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgIPadInfo::vfunc_3  @140451a50  [high:rtti-vtable]  (orig: FUN_140451a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140451a50(longlong param_1)

{
  char cVar1;
  bool bVar2;
  uint uVar3;
  ulong uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  CStringPacker *pCVar8;
  undefined1 auStack_ba8 [32];
  char *local_b88;
  char *local_b80;
  char *local_b78;
  undefined8 local_b68;
  char local_b60 [136];
  char local_ad8;
  undefined1 local_ad7 [127];
  char local_a58;
  undefined1 local_a57 [127];
  char local_9d8;
  undefined1 local_9d7 [127];
  char local_958;
  undefined1 local_957 [127];
  char local_8d8;
  undefined1 local_8d7 [127];
  char local_858;
  undefined1 local_857 [255];
  char local_758;
  undefined1 local_757 [1855];
  ulonglong local_18;
  
  local_b68 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_ba8;
  cVar1 = **(char **)(param_1 + 0x428);
  if (cVar1 == '\0') {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x88))(plVar6);
    if (plVar6 != (longlong *)0x0) {
      pCVar8 = (CStringPacker *)(param_1 + 0x430);
      uVar3 = tq::CStringPacker::GetStrAmount(pCVar8);
      if (2 < uVar3) {
        local_9d8 = '\0';
        memset(local_9d7,0,0x7f);
        local_ad8 = '\0';
        memset(local_ad7,0,0x7f);
        local_958 = '\0';
        memset(local_957,0,0x7f);
        bVar2 = tq::CStringPacker::GetString(pCVar8,0,&local_9d8,0x80);
        if (((bVar2) && (bVar2 = tq::CStringPacker::GetString(pCVar8,1,&local_ad8,0x80), bVar2)) &&
           (bVar2 = tq::CStringPacker::GetString(pCVar8,2,&local_958,0x80), bVar2)) {
          uVar5 = (**(code **)(plVar6[2] + 0x18))();
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          local_b78 = &local_958;
          local_b80 = &local_ad8;
          local_b88 = &local_9d8;
          tq::MyLogSave("gmlog/ipadinfo",
                        "user id:%8u, name:%20s, iPad UDID: %s, IDFA:%s, version: %s",
                        (ulonglong)uVar3,uVar5);
        }
      }
    }
  }
  else if (cVar1 == '\x01') {
    pCVar8 = (CStringPacker *)(param_1 + 0x430);
    uVar3 = tq::CStringPacker::GetStrAmount(pCVar8);
    if (2 < uVar3) {
      local_b60[8] = 0;
      memset(local_b60 + 9,0,0x7f);
      local_a58 = '\0';
      memset(local_a57,0,0x7f);
      local_8d8 = '\0';
      memset(local_8d7,0,0x7f);
      bVar2 = tq::CStringPacker::GetString(pCVar8,0,local_b60 + 8,0x80);
      if (((bVar2) && (bVar2 = tq::CStringPacker::GetString(pCVar8,1,&local_a58,0x80), bVar2)) &&
         (bVar2 = tq::CStringPacker::GetString(pCVar8,2,&local_8d8,0x80), bVar2)) {
        local_b88 = &local_8d8;
        tq::MyLogSave("gmlog/createrole","AccountID:%s, Mac:%s, IDFA: %s",local_b60 + 8,&local_a58);
      }
    }
  }
  else if (cVar1 == '\x02') {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    cVar1 = FUN_14008a710(uVar5);
    if (cVar1 != '\0') {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar6 = (longlong *)FUN_140087650(uVar5);
      lVar7 = (**(code **)(*plVar6 + 0x88))(plVar6);
      if (((lVar7 != 0) && (cVar1 = FUN_140167b70(lVar7), cVar1 == '\0')) &&
         (uVar3 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x430)), 1 < uVar3)) {
        local_858 = '\0';
        memset(local_857,0,0xff);
        local_b60[0] = '\0';
        local_b60[1] = '\0';
        local_b60[2] = '\0';
        local_b60[3] = '\0';
        local_b60[4] = '\0';
        local_b60[5] = '\0';
        local_b60[6] = '\0';
        local_b60[7] = 0;
        bVar2 = tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,&local_858,0x100);
        if ((bVar2) &&
           (bVar2 = tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_b60,8),
           bVar2)) {
          uVar4 = strtoul(local_b60,(char **)0x0,10);
          if (0 < (int)uVar4) {
            FUN_140167950(lVar7,uVar4);
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            plVar6 = (longlong *)FUN_140087650(uVar5);
            (**(code **)(*plVar6 + 0x70))(plVar6,uVar4,1);
          }
          local_758 = '\0';
          memset(local_757,0,0x73f);
          _snprintf(&local_758,0x73f,"[login]: %s",&local_858);
          tq::log_Save("gmlog/Login",&local_758,5);
        }
      }
    }
  }
  return;
}

