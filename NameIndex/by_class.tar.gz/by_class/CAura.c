// ==== CAura::helper_14041ddd0  @14041ddd0  [medium:callgraph-r0]  (orig: FUN_14041ddd0)
void FUN_14041ddd0(void *param_1)

{
  if ((DAT_1409763a8 & 1) == 0) {
    DAT_1409763a8 = DAT_1409763a8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763a0,"CAura");
    atexit((_func_5014 *)&LAB_1406d6db0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014041de25. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763a0,param_1);
  return;
}

// ==== CAura::ctor_or_dtor  @14041e050  [high:vtable-assign]  (orig: FUN_14041e050)
void FUN_14041e050(undefined8 *param_1)

{
  *param_1 = CAura::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0xe));
  FUN_14000c310(param_1 + 4);
  operator_delete((void *)param_1[4]);
  return;
}

// ==== CAura::ctor_or_dtor  @14041e0a0  [high:vtable-assign]  (orig: FUN_14041e0a0)
undefined8 *
FUN_14041e0a0(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,char *param_8)

{
  *param_1 = CAura::vftable;
  *(undefined4 *)(param_1 + 1) = param_3;
  *(undefined4 *)((longlong)param_1 + 0xc) = param_5;
  *(undefined4 *)(param_1 + 2) = param_2;
  *(undefined4 *)((longlong)param_1 + 0x14) = param_6;
  *(undefined4 *)(param_1 + 3) = param_7;
  FUN_14000ef40(param_1 + 4);
  *(undefined4 *)(param_1 + 0xc) = param_4;
  *(undefined4 *)((longlong)param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0xd) = 0;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0xe));
  if (param_8 != (char *)0x0) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0xe),
               param_8);
  }
  return param_1;
}

// ==== CAura::ctor_or_dtor  @14041e130  [high:vtable-assign]  (orig: FUN_14041e130)
undefined8 * FUN_14041e130(undefined8 *param_1,uint param_2)

{
  *param_1 = CAura::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0xe));
  FUN_14000c310(param_1 + 4);
  operator_delete((void *)param_1[4]);
  if ((param_2 & 1) != 0) {
    FUN_14041ddd0(param_1);
  }
  return param_1;
}

