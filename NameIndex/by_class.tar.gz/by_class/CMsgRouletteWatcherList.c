// ==== CMsgRouletteWatcherList::ctor_or_dtor  @1404f6aa0  [high:vtable-assign]  (orig: FUN_1404f6aa0)
undefined8 * FUN_1404f6aa0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteWatcherList::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteWatcherList::ctor_or_dtor  @1404f6af0  [high:vtable-assign]  (orig: FUN_1404f6af0)
void FUN_1404f6af0(undefined8 *param_1)

{
  *param_1 = CMsgRouletteWatcherList::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteWatcherList::vfunc_1  @1404f6b20  [high:rtti-vtable]  (orig: FUN_1404f6b20)
ulonglong FUN_1404f6b20(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf3);
}

// ==== CMsgRouletteWatcherList::vfunc_3  @1404f6c30  [high:rtti-vtable]  (orig: FUN_1404f6c30)
void FUN_1404f6c30(void)

{
  return;
}

// ==== CMsgRouletteWatcherList::ctor_or_dtor  @1404f6c40  [high:vtable-assign]  (orig: FUN_1404f6c40)
undefined8 * FUN_1404f6c40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteWatcherList::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

