// ==== CMsgRebirth::helper_1401654e0  @1401654e0  [medium:callgraph-r1]  (orig: FUN_1401654e0)
int FUN_1401654e0(int param_1)

{
  int iVar1;
  
  iVar1 = 0;
  param_1 = param_1 / 10;
  switch(param_1) {
  case 1:
  case 2:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
    return param_1 * 10 + 1;
  case 0xd:
  case 0xe:
    iVar1 = param_1 * 10 + 2;
  }
  return iVar1;
}

// ==== CMsgRebirth::ctor_or_dtor  @14045aff0  [high:vtable-assign]  (orig: FUN_14045aff0)
undefined8 * FUN_14045aff0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRebirth::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRebirth::ctor_or_dtor  @14045b040  [high:vtable-assign]  (orig: FUN_14045b040)
void FUN_14045b040(undefined8 *param_1)

{
  *param_1 = CMsgRebirth::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRebirth::vfunc_1  @14045b070  [high:rtti-vtable]  (orig: FUN_14045b070)
ulonglong FUN_14045b070(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x42a);
}

// ==== CMsgRebirth::ctor_or_dtor  @14045b0f0  [high:vtable-assign]  (orig: FUN_14045b0f0)
undefined8 * FUN_14045b0f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRebirth::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRebirth::helper_14045b140  @14045b140  [medium:callgraph-r0]  (orig: FUN_14045b140)
/* WARNING: Restarted to delay deadcode elimination for space: register */

ulonglong FUN_14045b140(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  byte bVar2;
  int iVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  ulonglong uVar7;
  longlong *plVar8;
  undefined8 uVar9;
  
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  FUN_140165570(param_2);
  FUN_140165580(param_2);
  plVar1 = param_2 + 2;
  cVar4 = (**(code **)(*plVar1 + 0x220))(plVar1);
  if (cVar4 == '\0') {
    return 2;
  }
  if ((uint)*(byte *)((longlong)param_2 + 0xeee) % 10 < 5) {
    return 3;
  }
  iVar5 = (**(code **)(*param_2 + 0x108))(param_2);
  if (1 < iVar5) {
    uVar7 = FUN_1401654e0(*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if ((int)uVar7 == 0) {
      return uVar7;
    }
    iVar3 = *(int *)(*(longlong *)(param_1 + 0x428) + 8);
    iVar6 = (**(code **)(*param_2 + 0x50))(param_2);
    if (iVar6 == 2) {
      if ((iVar3 != 1) && (iVar3 != 2)) {
        return 0;
      }
    }
    else {
      if (iVar6 != 1) {
        return 0;
      }
      if ((iVar3 != 3) && (iVar3 != 4)) {
        return 0;
      }
    }
    plVar8 = (longlong *)FUN_140163c90(param_2,uVar7 & 0xffffffff,3);
    if (plVar8 == (longlong *)0x0) {
      uVar7 = 5;
    }
    else {
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      cVar4 = FUN_14008ac00(uVar9);
      if ((cVar4 == '\0') ||
         (bVar2 = *(byte *)((longlong)param_2 + 0xeee),
         iVar6 = (**(code **)(*plVar8 + 0x10))(plVar8,2), (iVar6 % 1000) / 10 == bVar2 / 10)) {
        cVar4 = FUN_140338940(param_2,0xad9ab,0xad9ab,1);
        if ((cVar4 == '\0') || (cVar4 = FUN_140350360(param_2,0xad9ab,0xad9ab,1), cVar4 == '\0')) {
          uVar7 = 6;
        }
        else {
          cVar4 = FUN_1401c3180(param_2,plVar8,iVar5 + 1,iVar3);
          if (cVar4 == '\0') {
            uVar7 = 0;
          }
          else {
            FUN_140165580(param_2);
            FUN_140165570(param_2);
            uVar7 = (**(code **)(*param_2 + 8))(param_2);
            uVar9 = (**(code **)(*plVar1 + 0x18))(plVar1);
            tq::MyLogSave("gmlog/rebirth",
                          "User[%s][%d], first_prof1[%d], old_prof1[%d], new_prof1[%d] first_prof2[%d], old_prof2[%d], new_prof2[%d] "
                          ,uVar9,uVar7 & 0xffffffff);
            uVar7 = 1;
          }
        }
      }
      else {
        uVar7 = 0;
      }
    }
    return uVar7;
  }
  return 4;
}

// ==== CMsgRebirth::ctor_or_dtor  @14045b410  [high:vtable-assign]  (orig: FUN_14045b410)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14045b410(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  ulong uVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  char *_Format;
  undefined1 auStack_1148 [32];
  ulonglong local_1128;
  undefined4 local_1120;
  undefined2 local_1118;
  undefined2 local_1110;
  undefined4 local_1108;
  undefined4 local_1100;
  undefined1 local_10f8;
  undefined8 local_10e8;
  undefined **local_10d8;
  undefined4 local_10d0;
  undefined4 local_10cc;
  ulong local_10c8 [262];
  ulong *local_cb0;
  undefined1 local_ca8 [1072];
  undefined1 local_878 [1104];
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  undefined8 local_20;
  
  local_20 = 0x14045b420;
  local_10e8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_1148;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    local_1128 = CONCAT44(local_1128._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x88))(*(longlong **)(lVar6 + 0x90),param_1)
  ;
  if (plVar7 != (longlong *)0x0) {
    plVar8 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar7[0x1e2];
    lVar6 = *plVar8;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar6 + 0x108))(plVar8,uVar3,(int)lVar2,*puVar1);
    uVar4 = FUN_14045b140(param_1,plVar7);
    if (uVar4 == 1) {
      FUN_1401763f0(plVar7,0);
      FUN_140162620(plVar7);
      FUN_1400f83e0(local_ca8);
      uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
      local_1128 = local_1128 & 0xffffffff00000000;
      iVar5 = FUN_1400f8490(local_ca8,uVar3,0x1a,0xff);
      if (iVar5 == 0) {
        local_1128 = CONCAT44(local_1128._4_4_,0x4d);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(plVar7[2] + 0x348))(plVar7 + 2,local_ca8,1);
      }
      local_428 = '\0';
      memset(local_427,0,0x3ff);
      pIVar9 = theInstance();
      (**(code **)(plVar7[2] + 0x18))();
      _Format = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SYN_REBIRTH_SPECIAL");
      _snprintf(&local_428,0x400,_Format);
      local_29 = 0;
      FUN_14015b240(local_878);
      local_10f8 = 1;
      local_1100 = 0;
      local_1108 = 0;
      local_1110 = 0;
      local_1118 = 2000;
      local_1120 = 0xffffff;
      local_1128 = 0;
      iVar5 = FUN_14015b300(local_878,"SYSTEM","ALLUSERS",&local_428);
      if (iVar5 == 0) {
        local_1128 = CONCAT44(local_1128._4_4_,0x56);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        (**(code **)(*plVar8 + 0x68))(plVar8,local_878,*(undefined4 *)((longlong)plVar7 + 0x122c));
      }
      FUN_14015b2c0(local_878);
      FUN_1400f8430(local_ca8);
    }
    FUN_1402ba1c0(&local_10d8);
    local_10d8 = CMsgRebirth::vftable;
    FUN_1402b5600(&local_10d8);
    local_cb0 = local_10c8;
    FUN_1402b5600(&local_10d8);
    local_cb0[1] = uVar4;
    uVar4 = tq::TimeGet(0);
    *local_cb0 = uVar4;
    local_10d0 = 0x42a;
    local_10cc = 0xc;
    (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,&local_10d8);
    local_10d8 = CMsgRebirth::vftable;
    FUN_1402b55f0(&local_10d8);
  }
  return;
}

