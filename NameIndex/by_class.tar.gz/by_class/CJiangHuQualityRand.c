// ==== CJiangHuQualityRand::helper_1403f4f60  @1403f4f60  [medium:callgraph-r0]  (orig: FUN_1403f4f60)
void FUN_1403f4f60(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  ushort uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  char local_res20 [4];
  int local_res24;
  char local_78 [4];
  int local_74;
  char local_70 [4];
  int local_6c;
  longlong *local_68;
  undefined1 local_60 [32];
  
  plVar7 = *(longlong **)(param_1 + 8);
  plVar2 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  local_68 = plVar7;
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar2;
          plVar2 = *(longlong **)(param_1 + 0x38);
          if ((plVar7 == (longlong *)0x0) || (plVar7 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar2) {
            return;
          }
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar7;
          }
          if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          cVar1 = (char)plVar6[3];
          if (cVar1 != '\0') {
            iVar11 = 0;
            if (plVar7 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = 0;
            }
            else {
              lVar8 = *plVar7;
            }
            if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            plVar7 = (longlong *)plVar6[7];
            if ((longlong *)plVar6[8] < plVar7) {
              _invalid_parameter_noinfo();
            }
            plVar2 = (longlong *)plVar6[4];
            iVar9 = iVar11;
            iVar10 = iVar11;
            while( true ) {
              plVar5 = (longlong *)plVar6[8];
              if (plVar5 < (longlong *)plVar6[7]) {
                _invalid_parameter_noinfo();
              }
              if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)plVar6[4])) {
                _invalid_parameter_noinfo();
              }
              if (plVar7 == plVar5) break;
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar8 = 0;
              }
              else {
                lVar8 = *plVar2;
              }
              if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
                _invalid_parameter_noinfo();
              }
              plVar5 = (longlong *)*plVar7;
              if (plVar5 != (longlong *)0x0) {
                plVar4 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,3);
                uVar3 = (**(code **)(*plVar4 + 0x30))(plVar4);
                iVar11 = iVar11 + (uint)uVar3;
                plVar4 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
                uVar3 = (**(code **)(*plVar4 + 0x30))(plVar4);
                iVar10 = iVar10 + (uint)uVar3;
                plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,5);
                uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5);
                iVar9 = iVar9 + (uint)uVar3;
              }
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar8 = 0;
              }
              else {
                lVar8 = *plVar2;
              }
              if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
                _invalid_parameter_noinfo();
              }
              plVar7 = plVar7 + 1;
            }
            local_res20[0] = cVar1;
            local_res24 = iVar11;
            FUN_1401e2440(param_1 + 0x48,local_60,local_res20);
            local_78[0] = cVar1;
            local_74 = iVar10;
            FUN_1401e2440(param_1 + 0x88,local_60,local_78);
            local_70[0] = cVar1;
            local_6c = iVar9;
            FUN_1401e2440(param_1 + 200,local_60,local_70);
            plVar7 = local_68;
          }
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x51) == '\0') break;
          _invalid_parameter_noinfo();
          plVar2 = plVar6;
        }
        plVar2 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar2 + 0x51) != '\0') break;
        cVar1 = *(char *)(*plVar2 + 0x51);
        plVar6 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x51);
          plVar2 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar2 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar2 + 0x51) != '\0');
    do {
      plVar5 = plVar2;
      plVar2 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar2 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar2 + 0x51) == '\0');
  } while( true );
}

// ==== CJiangHuQualityRand::Create  @1403f67e0  [high:log-string]  (orig: FUN_1403f67e0)
undefined8 FUN_1403f67e0(longlong param_1)

{
  void *pvVar1;
  void *pvVar2;
  byte bVar3;
  byte bVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  void **ppvVar11;
  void **ppvVar12;
  byte local_res10 [8];
  longlong *local_res18;
  longlong *local_res20;
  uint local_e8;
  void **local_e0 [3];
  void *local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  void **local_b0 [3];
  void **local_98;
  void *local_90;
  byte local_88 [8];
  void *local_80 [3];
  void *local_68;
  undefined8 local_60;
  undefined8 local_58;
  void **local_50;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)
           (**(code **)(*plVar6 + 0x10))(plVar6,"SELECT * FROM cq_jianghu_quality_rand",1);
  uVar8 = 0;
  if (plVar6 != (longlong *)0x0) {
    local_res20 = plVar6;
    lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
    if (lVar7 == 0) {
      log_InlineLogERROR(
                        "CJiangHuQualityRand::Create(), cq_jianghu_quality_rand record count is 0! at %s, %d"
                        );
      (**(code **)*plVar6)(plVar6);
      uVar8 = 0;
    }
    else {
      ppvVar11 = (void **)0x0;
      local_e8 = 0;
      ppvVar12 = ppvVar11;
      while( true ) {
        iVar5 = (**(code **)(*plVar6 + 0x40))(plVar6);
        if (iVar5 <= (int)ppvVar12) break;
        (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)(int)ppvVar12);
        plVar9 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
        local_res18 = plVar9;
        if (plVar9 != (longlong *)0x0) {
          plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,1);
          bVar3 = (**(code **)(*plVar10 + 0x20))(plVar10);
          local_res10[0] = bVar3;
          if ((bVar3 == 0) || (9 < bVar3)) {
            log_InlineLogERROR(
                              "CJiangHuQualityRand::Create(), cq_jianghu_quality_rand PowerLevel(%u) error, at %s, %d"
                              );
            (**(code **)*plVar9)(plVar9,1);
            local_res18 = (longlong *)0x0;
          }
          else {
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
            bVar4 = (**(code **)(*plVar10 + 0x20))(plVar10);
            if ((bVar4 == 0) || (6 < bVar4)) {
              log_InlineLogERROR(
                                "CJiangHuQualityRand::Create(), cq_jianghu_quality_rand PowerQuality(%u), at %s, %d"
                                );
              (**(code **)*plVar9)(plVar9,1);
              local_res18 = (longlong *)0x0;
            }
            else {
              FUN_1403f4d90(param_1 + 8,&local_98,local_res10);
              ppvVar12 = local_98;
              pvVar1 = *(void **)(param_1 + 0x38);
              local_b0[0] = *(void ***)(param_1 + 8);
              if ((local_98 == (void **)0x0) || (local_98 != local_b0[0])) {
                _invalid_parameter_noinfo();
              }
              pvVar2 = local_90;
              if (local_90 == pvVar1) {
                local_b0[0] = operator_new(8);
                local_e0[0] = ppvVar11;
                if (local_b0[0] != (void **)0x0) {
                  *local_b0[0] = local_e0;
                  local_e0[0] = local_b0[0];
                }
                local_c8 = (void *)0x0;
                local_c0 = 0;
                local_b8 = 0;
                local_50 = local_b0[0];
                FUN_140019370(local_e0,&local_res18);
                local_88[0] = bVar3;
                FUN_140267b90(local_80,local_e0);
                FUN_1403f6580(param_1 + 8,local_b0,local_88);
                local_b0[0] = local_80;
                if (local_68 != (void *)0x0) {
                  operator_delete(local_68);
                }
                local_68 = (void *)0x0;
                local_60 = 0;
                local_58 = 0;
                operator_delete(local_80[0]);
                if (local_c8 != (void *)0x0) {
                  operator_delete(local_c8);
                }
                local_c8 = (void *)0x0;
                local_c0 = 0;
                local_b8 = 0;
                operator_delete(local_e0[0]);
              }
              else {
                if (ppvVar12 == (void **)0x0) {
                  _invalid_parameter_noinfo();
                  ppvVar12 = ppvVar11;
                }
                else {
                  ppvVar12 = *ppvVar12;
                }
                if (pvVar2 == ppvVar12[6]) {
                  _invalid_parameter_noinfo();
                }
                FUN_140019370((longlong)pvVar2 + 0x20,&local_res18);
              }
            }
          }
        }
        local_e8 = local_e8 + 1;
        ppvVar12 = (void **)(ulonglong)local_e8;
      }
      (**(code **)*plVar6)(plVar6);
      FUN_1403f4f60(param_1);
      uVar8 = 1;
    }
  }
  return uVar8;
}

// ==== CJiangHuQualityRand::ctor_or_dtor  @1403f71b0  [high:vtable-assign]  (orig: FUN_1403f71b0)
void FUN_1403f71b0(undefined8 *param_1)

{
  *param_1 = CJiangHuQualityRand::vftable;
  FUN_1401e0500(param_1 + 0x19);
  operator_delete((void *)param_1[0x19]);
  FUN_1401e0500(param_1 + 0x11);
  operator_delete((void *)param_1[0x11]);
  FUN_1401e0500(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_1403f70e0(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CJiangHuQualityRand::ctor_or_dtor  @1403f72d0  [high:vtable-assign]  (orig: FUN_1403f72d0)
undefined8 *
FUN_1403f72d0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = CJiangHuQualityRand::vftable;
  FUN_1403f7250(param_1 + 1);
  FUN_1401eb7e0(param_1 + 9);
  FUN_1401eb7e0(param_1 + 0x11);
  FUN_1401eb7e0(param_1 + 0x19);
  FUN_1403f6730(param_1 + 1,*(undefined8 *)(param_1[7] + 8),param_3,param_4,uVar1);
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  FUN_1401de010(param_1 + 9);
  FUN_1401de010(param_1 + 0x11);
  FUN_1401de010(param_1 + 0x19);
  return param_1;
}

// ==== CJiangHuQualityRand::vfunc_0  @1403f73a0  [high:rtti-vtable]  (orig: FUN_1403f73a0)
void * FUN_1403f73a0(void *param_1,uint param_2)

{
  FUN_1403f71b0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

