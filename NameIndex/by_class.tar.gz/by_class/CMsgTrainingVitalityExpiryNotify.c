// ==== CMsgTrainingVitalityExpiryNotify::ctor_or_dtor  @1404f65b0  [high:vtable-assign]  (orig: FUN_1404f65b0)
undefined8 * FUN_1404f65b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitalityExpiryNotify::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitalityExpiryNotify::ctor_or_dtor  @1404f6600  [high:vtable-assign]  (orig: FUN_1404f6600)
void FUN_1404f6600(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitalityExpiryNotify::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitalityExpiryNotify::vfunc_1  @1404f6630  [high:rtti-vtable]  (orig: FUN_1404f6630)
bool FUN_1404f6630(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9ea;
    }
  }
  return false;
}

// ==== CMsgTrainingVitalityExpiryNotify::vfunc_3  @1404f6750  [high:rtti-vtable]  (orig: FUN_1404f6750)
void FUN_1404f6750(void)

{
  return;
}

// ==== CMsgTrainingVitalityExpiryNotify::ctor_or_dtor  @1404f6760  [high:vtable-assign]  (orig: FUN_1404f6760)
undefined8 * FUN_1404f6760(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitalityExpiryNotify::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

