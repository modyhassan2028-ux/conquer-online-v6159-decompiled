// ==== CDialog::method_14001db10  @14001db10  [medium:param1-type]  (orig: FUN_14001db10)
void FUN_14001db10(CDialog *param_1)

{
  if (*(void **)(param_1 + 0x1a0) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x1a0));
  }
  *(undefined8 *)(param_1 + 0x1a0) = 0;
  *(undefined8 *)(param_1 + 0x1a8) = 0;
  *(undefined8 *)(param_1 + 0x1b0) = 0;
  operator_delete(*(void **)(param_1 + 0x188));
  CThreadTimesInfo::~CThreadTimesInfo((CThreadTimesInfo *)(param_1 + 0x168));
  CPerformanceInfo::~CPerformanceInfo((CPerformanceInfo *)(param_1 + 0x158));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x108));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0x100));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf8));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xf0));
  ATL::CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>::
  ~CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_>
            ((CStringT<char,StrTraitMFC_DLL<char,ATL::ChTraitsCRT<char>_>_> *)(param_1 + 0xe8));
  CDialog::~CDialog(param_1);
  return;
}

// ==== CDialog::method_14001e460  @14001e460  [medium:param1-type]  (orig: FUN_14001e460)
void FUN_14001e460(CDialog *param_1)

{
  CDialog::~CDialog(param_1);
  return;
}

// ==== CDialog::method_140021a70  @140021a70  [medium:param1-type]  (orig: FUN_140021a70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140021a70(CDialog *param_1)

{
  BOOL BVar1;
  int iVar2;
  int iVar3;
  undefined1 auStack_c8 [32];
  tagRECT local_a8;
  undefined8 local_98;
  CPaintDC local_88 [8];
  HDC local_80;
  ulonglong local_18;
  
  local_98 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_c8;
  BVar1 = IsIconic(*(HWND *)(param_1 + 0x40));
  if (BVar1 == 0) {
    CDialog::OnPaint(param_1);
  }
  else {
    CPaintDC::CPaintDC(local_88,(CWnd *)param_1);
    SendMessageA(*(HWND *)(param_1 + 0x40),0x27,(WPARAM)local_80,0);
    iVar2 = GetSystemMetrics(0xb);
    iVar3 = GetSystemMetrics(0xc);
    GetClientRect(*(HWND *)(param_1 + 0x40),&local_a8);
    DrawIcon(local_80,(((local_a8.right - local_a8.left) - iVar2) + 1) / 2,
             (((local_a8.bottom - local_a8.top) - iVar3) + 1) / 2,*(HICON *)(param_1 + 0x200));
    CPaintDC::~CPaintDC(local_88);
  }
  return;
}

