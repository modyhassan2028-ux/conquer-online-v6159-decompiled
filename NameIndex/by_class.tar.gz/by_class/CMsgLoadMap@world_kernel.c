// ==== CMsgLoadMap@world_kernel::helper_140068930  @140068930  [medium:callgraph-r0]  (orig: FUN_140068930)
ulonglong FUN_140068930(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x104) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x104) + *(int *)(param_1 + 0x100);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      return CONCAT71((uint7)(uint3)(uVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgLoadMap@world_kernel::helper_14006b5c0  @14006b5c0  [medium:callgraph-r2]  (orig: FUN_14006b5c0)
undefined8 * FUN_14006b5c0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x21) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x21) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x21) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x21) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x21) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgLoadMap@world_kernel::helper_14006e9e0  @14006e9e0  [medium:callgraph-r1]  (orig: FUN_14006e9e0)
undefined4 FUN_14006e9e0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0xe0))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0xe0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0xe0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xb0);
  if (*(longlong *)(param_1 + 0xb0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xe0);
    local_28 = *(longlong *)(param_1 + 0xb0);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0xe0);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xb0))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CMsgLoadMap@world_kernel::helper_14006ec20  @14006ec20  [medium:callgraph-r1]  (orig: FUN_14006ec20)
undefined4 FUN_14006ec20(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x120))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x120);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x120);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xf0);
  if (*(longlong *)(param_1 + 0xf0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x120);
    local_28 = *(longlong *)(param_1 + 0xf0);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x120);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xf0))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CMsgLoadMap@world_kernel::helper_14006ed40  @14006ed40  [medium:callgraph-r1]  (orig: FUN_14006ed40)
longlong FUN_14006ed40(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14006b5c0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x21) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x21);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x21);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x21);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x21);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14006d2a0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgLoadMap@world_kernel::helper_140070190  @140070190  [medium:callgraph-r0]  (orig: FUN_140070190)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140070190(undefined8 param_1,undefined8 param_2,longlong param_3,char param_4)

{
  int iVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  longlong *plVar5;
  undefined1 auStack_4d8 [32];
  longlong local_4b8;
  undefined4 local_4b0;
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  undefined8 local_478;
  undefined1 local_468 [1088];
  ulonglong local_28;
  
  local_478 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_3 == 0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x1b7);
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = FUN_14006e620();
  if (lVar2 == 0) {
    return 0;
  }
  if (param_4 != '\0') {
    uVar3 = FUN_140054dc0();
    FUN_140055820(uVar3,*(undefined4 *)(lVar2 + 0x74),1);
  }
  FUN_14007a560(local_468);
  plVar5 = (longlong *)0x0;
  local_488 = 1;
  local_490 = 0;
  local_498 = 0;
  local_4a0 = 0;
  local_4a8 = 0x835;
  local_4b0 = 0xffffff;
  local_4b8 = 0;
  iVar1 = FUN_14007a620(local_468,"SYSTEM","ALLUSERS",param_3);
  if (iVar1 != 0) {
    if (DAT_140975af8 == (longlong *)0x0) {
      local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    (**(code **)(*DAT_140975af8 + 0x38))(DAT_140975af8,*(undefined4 *)(lVar2 + 0x60),local_468);
  }
  FUN_14007a5e0(local_468);
  local_4b8 = param_3;
  log_InlineLogWARNING(&DAT_1406ef030);
  if (DAT_140975af8 == (longlong *)0x0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
    if (DAT_140975af8 == (longlong *)0x0) goto LAB_140070335;
  }
  plVar5 = DAT_140975af8 + 1;
LAB_140070335:
  uVar4 = (**(code **)(*plVar5 + 0x18))(plVar5,*(undefined4 *)(lVar2 + 0x60));
  return uVar4;
}

// ==== CMsgLoadMap@world_kernel::helper_140071e30  @140071e30  [medium:callgraph-r0]  (orig: FUN_140071e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140071e30(undefined8 param_1,undefined4 *param_2,undefined1 param_3,char *param_4)

{
  undefined4 uVar1;
  longlong *plVar2;
  int iVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 auStack_548 [32];
  undefined4 *local_528;
  undefined4 local_520;
  undefined2 local_518;
  undefined2 local_510;
  undefined4 local_508;
  undefined4 local_500;
  undefined1 local_4f8;
  undefined4 local_4e8 [2];
  undefined8 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d4;
  undefined4 local_4d0;
  undefined4 local_4cc;
  undefined4 local_4c8;
  undefined4 local_4c4;
  undefined1 local_4c0;
  char local_4bf [71];
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  local_4e0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_548;
  if (param_2 == (undefined4 *)0x0) {
    local_528 = (undefined4 *)CONCAT44(local_528._4_4_,0x3cc);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    if (DAT_140975af8 == (longlong *)0x0) {
      local_528 = (undefined4 *)CONCAT44(local_528._4_4_,0x128);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)DAT_140975af8[0xb];
    local_4d8 = 0;
    local_4cc = 0;
    local_4c8 = 0;
    local_4c4 = 0;
    local_4c0 = 0;
    local_4bf[0] = '\0';
    local_4bf[1] = '\0';
    local_4bf[2] = '\0';
    local_4bf[3] = '\0';
    local_4bf[4] = '\0';
    local_4bf[5] = '\0';
    local_4bf[6] = '\0';
    local_4bf[7] = '\0';
    local_4bf[8] = '\0';
    local_4bf[9] = '\0';
    local_4bf[10] = '\0';
    local_4bf[0xb] = '\0';
    local_4bf[0xc] = '\0';
    local_4bf[0xd] = '\0';
    local_4bf[0xe] = '\0';
    local_4bf[0xf] = '\0';
    local_4bf[0x10] = '\0';
    local_4bf[0x11] = '\0';
    local_4bf[0x12] = '\0';
    local_4bf[0x13] = '\0';
    local_4bf[0x14] = '\0';
    local_4bf[0x15] = '\0';
    local_4bf[0x16] = '\0';
    local_4bf[0x17] = '\0';
    local_4bf[0x18] = '\0';
    local_4bf[0x19] = '\0';
    local_4bf[0x1a] = '\0';
    local_4bf[0x1b] = '\0';
    local_4bf[0x1c] = '\0';
    local_4bf[0x1d] = '\0';
    local_4bf[0x1e] = '\0';
    local_4bf[0x1f] = '\0';
    local_4bf[0x20] = '\0';
    local_4bf[0x21] = '\0';
    local_4bf[0x22] = '\0';
    local_4bf[0x23] = '\0';
    local_4bf[0x24] = '\0';
    local_4bf[0x25] = '\0';
    local_4bf[0x26] = '\0';
    local_4bf[0x27] = '\0';
    local_4bf[0x28] = '\0';
    local_4bf[0x29] = '\0';
    local_4bf[0x2a] = '\0';
    local_4bf[0x2b] = '\0';
    local_4bf[0x2c] = '\0';
    local_4bf[0x2d] = '\0';
    local_4bf[0x2e] = '\0';
    local_4bf[0x2f] = '\0';
    local_4bf[0x30] = '\0';
    local_4bf[0x31] = '\0';
    local_4bf[0x32] = '\0';
    local_4bf[0x33] = '\0';
    local_4bf[0x34] = '\0';
    local_4bf[0x35] = '\0';
    local_4bf[0x36] = '\0';
    local_4bf[0x37] = '\0';
    local_4bf[0x38] = '\0';
    local_4bf[0x39] = '\0';
    local_4bf[0x3a] = '\0';
    local_4bf[0x3b] = '\0';
    local_4bf[0x3c] = '\0';
    local_4bf[0x3d] = '\0';
    local_4bf[0x3e] = '\0';
    local_4bf[0x3f] = '\0';
    local_4d4 = param_2[0x18];
    local_4d0 = *param_2;
    uVar4 = FUN_140054e10();
    local_4cc = FUN_14006ec20(uVar4,param_2[0x1d]);
    uVar4 = FUN_140054e10();
    local_4c8 = FUN_14006e9e0(uVar4,param_2[0x1d]);
    uVar4 = FUN_140054e10();
    local_4c4 = FUN_14006eb00(uVar4,param_2[0x1d]);
    local_4c0 = param_3;
    if (param_4 != (char *)0x0) {
      strncpy(local_4bf,param_4,0x40);
    }
    local_4e8[0] = param_2[0x1d];
    lVar5 = FUN_140054e10();
    FUN_14006ed40(lVar5 + 0xf0,local_4e8);
    local_4e8[0] = param_2[0x1d];
    lVar5 = FUN_140054e10();
    FUN_140050de0(lVar5 + 0xb0,local_4e8);
    uVar1 = param_2[6];
    local_528 = &local_4d8;
    (**(code **)(*plVar2 + 0x50))(plVar2,uVar1,0x2711,0x5c);
    param_2[5] = uVar1;
    FUN_14007a560(local_478);
    local_4f8 = 1;
    local_500 = 0;
    local_508 = 0;
    local_510 = 0;
    local_518 = 0x835;
    local_520 = 0xffffff;
    local_528 = (undefined4 *)0x0;
    iVar3 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS","ANSWER_OK");
    if (iVar3 != 0) {
      if (DAT_140975af8 == (longlong *)0x0) {
        local_528 = (undefined4 *)CONCAT44(local_528._4_4_,0x128);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      (**(code **)(*DAT_140975af8 + 0x38))(DAT_140975af8,param_2[0x18],local_478);
    }
    FUN_14007a5e0(local_478);
  }
  return;
}

// ==== CMsgLoadMap@world_kernel::vfunc_1  @140081cc0  [high:rtti-vtable]  (orig: FUN_140081cc0)
ulonglong FUN_140081cc0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x414);
}

// ==== CMsgLoadMap@world_kernel::vfunc_0  @140081d90  [high:rtti-vtable]  (orig: FUN_140081d90)
undefined8 * FUN_140081d90(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgLoadMap::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgLoadMap@world_kernel::vfunc_3  @140081de0  [high:rtti-vtable]  (orig: FUN_140081de0)
void FUN_140081de0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  char cVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong lVar6;
  bool bVar7;
  
  uVar1 = *(undefined4 *)(param_1 + 0x414);
  uVar4 = FUN_140054e10();
  lVar5 = FUN_140070520(uVar4,uVar1);
  if (((lVar5 != 0) && (*(short *)(*(longlong *)(param_1 + 0x420) + 4) == 0)) &&
     (*(int *)(lVar5 + 0x104) != 0)) {
    cVar3 = FUN_140068930(lVar5);
    if (cVar3 == '\0') {
      iVar2 = *(int *)(*(longlong *)(param_1 + 0x420) + 8);
      if ((iVar2 < 1) || ((longlong)*(int *)(param_1 + 0xc) != (longlong)(iVar2 + -1) * 4 + 0x10)) {
        uVar1 = *(undefined4 *)(lVar5 + 0x74);
        uVar4 = FUN_140054e10();
        FUN_140070190(uVar4,uVar1,"Failed to load the map!",1);
        return;
      }
      *(undefined4 *)(lVar5 + 0x104) = 0;
      *(undefined4 *)(lVar5 + 0x100) = 0;
      bVar7 = *(char *)(lVar5 + 0xbd) == '\0';
      if (bVar7) {
        uVar4 = FUN_140054e10();
        lVar6 = 0;
      }
      else {
        uVar4 = FUN_140054e10();
        lVar6 = lVar5 + 0xbd;
      }
      FUN_140071e30(uVar4,lVar5,!bVar7,lVar6);
    }
  }
  return;
}

