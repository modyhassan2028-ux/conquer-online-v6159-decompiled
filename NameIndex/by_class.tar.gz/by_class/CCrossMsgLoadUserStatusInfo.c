// ==== CCrossMsgLoadUserStatusInfo::helper_14018e0b0  @14018e0b0  [medium:callgraph-r1]  (orig: FUN_14018e0b0)
void FUN_14018e0b0(longlong param_1,longlong param_2)

{
  uint *puVar1;
  uint uVar2;
  longlong lVar3;
  uint uVar4;
  int iVar5;
  
  lVar3 = 5;
  iVar5 = 0;
  do {
    *(undefined4 *)(param_2 + lVar3 * 4) = 0;
    lVar3 = lVar3 + -1;
  } while (-1 < lVar3);
  if (param_1 != 0) {
    do {
      uVar4 = iVar5 >> 0x1f & 0x1f;
      uVar2 = iVar5 + uVar4;
      if ((*(uint *)(param_1 + (longlong)((int)uVar2 >> 5) * 4) >> ((uVar2 & 0x1f) - uVar4 & 0x1f) &
          1) != 0) {
        if (0xbf < (ulonglong)(longlong)iVar5) {
                    /* WARNING: Subroutine does not return */
          FUN_140118b50(param_2);
        }
        puVar1 = (uint *)(param_2 + ((ulonglong)(longlong)iVar5 >> 5) * 4);
        *puVar1 = *puVar1 | 1 << ((byte)iVar5 & 0x1f);
      }
      iVar5 = iVar5 + 1;
    } while (iVar5 < 0xc0);
  }
  return;
}

// ==== CCrossMsgLoadUserStatusInfo::helper_14018fdd0  @14018fdd0  [medium:callgraph-r0]  (orig: FUN_14018fdd0)
void FUN_14018fdd0(longlong param_1,longlong param_2)

{
  if (param_2 != 0) {
    FUN_14018e0b0(param_2,param_1 + 0xf60);
  }
  return;
}

// ==== CCrossMsgLoadUserStatusInfo::helper_14018fdf0  @14018fdf0  [medium:callgraph-r0]  (orig: FUN_14018fdf0)
void FUN_14018fdf0(longlong param_1,longlong param_2)

{
  if (param_2 != 0) {
    FUN_14018e0b0(param_2,param_1 + 0xf78);
  }
  return;
}

// ==== CCrossMsgLoadUserStatusInfo::ctor_or_dtor  @1403f1ea0  [high:vtable-assign]  (orig: FUN_1403f1ea0)
undefined8 * FUN_1403f1ea0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadUserStatusInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadUserStatusInfo::ctor_or_dtor  @1403f1ef0  [high:vtable-assign]  (orig: FUN_1403f1ef0)
void FUN_1403f1ef0(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadUserStatusInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadUserStatusInfo::vfunc_1  @1403f1f20  [high:rtti-vtable]  (orig: FUN_1403f1f20)
undefined8 FUN_1403f1f20(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadUserStatusInfo::ctor_or_dtor  @1403f2110  [high:vtable-assign]  (orig: FUN_1403f2110)
undefined8 * FUN_1403f2110(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadUserStatusInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadUserStatusInfo::vfunc_3  @1403f2160  [high:rtti-vtable]  (orig: FUN_1403f2160)
void FUN_1403f2160(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  
  if (**(short **)(param_1 + 0x428) == 0) {
    uVar3 = *(undefined4 *)(param_1 + 0x420);
    uVar1 = *(undefined4 *)(param_1 + 0x41c);
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar4 = FUN_140087650(uVar4);
    plVar5 = (longlong *)FUN_1402af110(uVar4,uVar1,uVar3);
    if (plVar5 != (longlong *)0x0) {
      FUN_14018fdd0(plVar5,*(longlong *)(param_1 + 0x428) + 8);
      FUN_14018fdf0(plVar5,*(longlong *)(param_1 + 0x428) + 0x20);
      plVar7 = (longlong *)FUN_1401181a0();
      lVar6 = *plVar7;
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      (**(code **)(lVar6 + 0x110))(plVar7,uVar3,lVar2 + 0x38,*(undefined4 *)(lVar2 + 4));
    }
  }
  else {
    if (**(short **)(param_1 + 0x428) != 1) {
                    /* WARNING: Could not recover jumptable at 0x0001403f2192. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CCrossMsgLoadUserStatusInfo::Process action error, aciotn:%u.");
      return;
    }
    uVar3 = *(undefined4 *)(param_1 + 0x420);
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar5 = (longlong *)FUN_140087650(uVar4);
    lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,uVar3);
    if (lVar6 != 0) {
      plVar5 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar5 + 0x100))
                (plVar5,uVar3,*(longlong *)(param_1 + 0x428) + 0x38,
                 *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      FUN_14018fdd0(lVar6,*(longlong *)(param_1 + 0x428) + 8);
      FUN_14018fdf0(lVar6,*(longlong *)(param_1 + 0x428) + 0x20);
      return;
    }
  }
  return;
}

