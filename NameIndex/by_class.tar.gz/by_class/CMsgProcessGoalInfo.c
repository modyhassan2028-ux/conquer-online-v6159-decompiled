// ==== CMsgProcessGoalInfo::ctor_or_dtor  @1404df8a0  [high:vtable-assign]  (orig: FUN_1404df8a0)
undefined8 * FUN_1404df8a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgProcessGoalInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgProcessGoalInfo::ctor_or_dtor  @1404df8f0  [high:vtable-assign]  (orig: FUN_1404df8f0)
void FUN_1404df8f0(undefined8 *param_1)

{
  *param_1 = CMsgProcessGoalInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgProcessGoalInfo::vfunc_1  @1404df920  [high:rtti-vtable]  (orig: FUN_1404df920)
bool FUN_1404df920(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xb10;
    }
  }
  return false;
}

// ==== CMsgProcessGoalInfo::vfunc_3  @1404dfa80  [high:rtti-vtable]  (orig: FUN_1404dfa80)
void FUN_1404dfa80(void)

{
  return;
}

// ==== CMsgProcessGoalInfo::ctor_or_dtor  @1404dfa90  [high:vtable-assign]  (orig: FUN_1404dfa90)
undefined8 * FUN_1404dfa90(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgProcessGoalInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

