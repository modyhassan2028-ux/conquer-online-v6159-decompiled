// ==== CCrossMsgOptItem::helper_1401038d0  @1401038d0  [medium:callgraph-r1]  (orig: FUN_1401038d0)
bool FUN_1401038d0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 1;
}

// ==== CCrossMsgOptItem::helper_140103900  @140103900  [medium:callgraph-r1]  (orig: FUN_140103900)
bool FUN_140103900(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 2;
}

// ==== CCrossMsgOptItem::helper_140103930  @140103930  [medium:callgraph-r1]  (orig: FUN_140103930)
bool FUN_140103930(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 3;
}

// ==== CCrossMsgOptItem::helper_140103960  @140103960  [medium:callgraph-r1]  (orig: FUN_140103960)
bool FUN_140103960(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 6;
}

// ==== CCrossMsgOptItem::helper_140103990  @140103990  [medium:callgraph-r1]  (orig: FUN_140103990)
bool FUN_140103990(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 7;
}

// ==== CCrossMsgOptItem::helper_1401039c0  @1401039c0  [medium:callgraph-r1]  (orig: FUN_1401039c0)
bool FUN_1401039c0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 8;
}

// ==== CCrossMsgOptItem::helper_140103a20  @140103a20  [medium:callgraph-r1]  (orig: FUN_140103a20)
bool FUN_140103a20(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 0xe;
}

// ==== CCrossMsgOptItem::helper_140119480  @140119480  [medium:callgraph-r1]  (orig: FUN_140119480)
bool FUN_140119480(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 4;
}

// ==== CCrossMsgOptItem::helper_14015fe60  @14015fe60  [medium:callgraph-r1]  (orig: FUN_14015fe60)
void FUN_14015fe60(longlong param_1)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0xe8))(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x1190) = uVar1;
  return;
}

// ==== CCrossMsgOptItem::helper_14016c870  @14016c870  [medium:callgraph-r1]  (orig: FUN_14016c870)
bool FUN_14016c870(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 5;
}

// ==== CCrossMsgOptItem::helper_14016c8a0  @14016c8a0  [medium:callgraph-r1]  (orig: FUN_14016c8a0)
bool FUN_14016c8a0(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 10;
}

// ==== CCrossMsgOptItem::helper_14016c8d0  @14016c8d0  [medium:callgraph-r1]  (orig: FUN_14016c8d0)
bool FUN_14016c8d0(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 0xb;
}

// ==== CCrossMsgOptItem::helper_140198a90  @140198a90  [medium:callgraph-r1]  (orig: FUN_140198a90)
void FUN_140198a90(longlong *param_1)

{
  uint uVar1;
  uint uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  uVar1 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 0x78))(param_1,0);
  if (uVar1 < uVar2) {
    FUN_140198760(param_1,uVar1,0);
  }
  if (param_1[0x220] != 0) {
    plVar3 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
    uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
    if ((uVar4 >> 0x16 & 1) != 0) {
      lVar5 = FUN_14016e430(param_1);
      if (lVar5 != 0) {
        FUN_14018e550(param_1,lVar5);
      }
    }
  }
  return;
}

// ==== CCrossMsgOptItem::helper_14020e620  @14020e620  [medium:callgraph-r2]  (orig: FUN_14020e620)
longlong * FUN_14020e620(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CCrossMsgOptItem::helper_14020e710  @14020e710  [medium:callgraph-r3]  (orig: FUN_14020e710)
undefined8 * FUN_14020e710(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14020dab0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14020dab0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14020dab0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_14020dab0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14020dab0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_14020dab0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14020dab0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14020e1f0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CCrossMsgOptItem::helper_14020ece0  @14020ece0  [medium:callgraph-r2]  (orig: FUN_14020ece0)
undefined8 * FUN_14020ece0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_14020e710(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CCrossMsgOptItem::helper_14020f0d0  @14020f0d0  [medium:callgraph-r1]  (orig: FUN_14020f0d0)
undefined1 FUN_14020f0d0(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined1 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined4 local_res10 [2];
  longlong local_res18;
  undefined8 uVar6;
  undefined1 local_40 [24];
  
  uVar6 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  cVar2 = FUN_14020c770();
  uVar3 = 0;
  if (cVar2 != '\0') {
    lVar5 = *(longlong *)(param_1 + 0x40);
    lVar1 = *(longlong *)(param_1 + 0x10);
    plVar4 = (longlong *)FUN_14020e620(param_1 + 0x10,local_40,local_res10,param_4,uVar6);
    if ((*plVar4 == 0) || (*plVar4 != lVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[1] == lVar5) {
      local_res18 = FUN_140413d20(0x48);
      if (local_res18 == 0) {
        lVar5 = 0;
      }
      else {
        lVar5 = FUN_140416100(local_res18);
      }
      if (lVar5 == 0) {
        uVar3 = 0;
      }
      else {
        cVar2 = FUN_140413a80(lVar5,*(undefined4 *)(param_1 + 8),param_2);
        if (cVar2 == '\0') {
          FUN_140415f80(lVar5);
          FUN_140413d80(lVar5);
          uVar3 = 0;
        }
        else {
          plVar4 = (longlong *)FUN_14020ece0(param_1 + 0x10,local_res10);
          *plVar4 = lVar5;
          uVar3 = 1;
        }
      }
    }
    else {
      uVar3 = 0;
    }
  }
  return uVar3;
}

// ==== CCrossMsgOptItem::helper_14031e8f0  @14031e8f0  [medium:callgraph-r2]  (orig: FUN_14031e8f0)
void FUN_14031e8f0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CCrossMsgOptItem::helper_14031f660  @14031f660  [medium:callgraph-r2]  (orig: FUN_14031f660)
void FUN_14031f660(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CCrossMsgOptItem::helper_14031ff10  @14031ff10  [medium:callgraph-r2]  (orig: FUN_14031ff10)
void * FUN_14031ff10(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CCrossMsgOptItem::helper_140321630  @140321630  [medium:callgraph-r2]  (orig: FUN_140321630)
void * FUN_140321630(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CCrossMsgOptItem::helper_140322900  @140322900  [medium:callgraph-r1]  (orig: FUN_140322900)
void FUN_140322900(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14031e8f0();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14031f660(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_140321630(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_140321630(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14031ff10(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CCrossMsgOptItem::helper_14032ed60  @14032ed60  [medium:callgraph-r1]  (orig: FUN_14032ed60)
bool FUN_14032ed60(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 0xf;
}

// ==== CCrossMsgOptItem::helper_14032edf0  @14032edf0  [medium:callgraph-r1]  (orig: FUN_14032edf0)
bool FUN_14032edf0(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 0x13;
}

// ==== CCrossMsgOptItem::helper_14032ee20  @14032ee20  [medium:callgraph-r1]  (orig: FUN_14032ee20)
bool FUN_14032ee20(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  return iVar2 == 0x14;
}

// ==== CCrossMsgOptItem::helper_14032ee50  @14032ee50  [medium:callgraph-r1]  (orig: FUN_14032ee50)
undefined4 FUN_14032ee50(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  if (iVar2 != 0x10) {
    uVar1 = FUN_1400fda10(param_1,1,1);
    iVar2 = FUN_1400ff680(uVar1);
    if (iVar2 != 0xf) {
      uVar1 = FUN_1400fda10(param_1,1,1);
      iVar2 = FUN_1400ff680(uVar1);
      if (iVar2 != 0x12) {
        return 0;
      }
    }
  }
  return 1;
}

// ==== CCrossMsgOptItem::helper_14032eec0  @14032eec0  [medium:callgraph-r1]  (orig: FUN_14032eec0)
undefined4 FUN_14032eec0(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = FUN_1400fda10(param_1,1,1);
  iVar2 = FUN_1400ff680(uVar1);
  if (iVar2 != 0xf) {
    uVar1 = FUN_1400fda10(param_1,1,1);
    iVar2 = FUN_1400ff680(uVar1);
    if (iVar2 != 0x13) {
      return 0;
    }
  }
  return 1;
}

// ==== CCrossMsgOptItem::helper_14032ef90  @14032ef90  [medium:callgraph-r1]  (orig: FUN_14032ef90)
undefined1 FUN_14032ef90(undefined8 param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = FUN_1400fda10(param_1,1,1);
  iVar3 = FUN_1400ff680(uVar2);
  if (iVar3 != 4) {
    uVar2 = FUN_1400fda10(param_1,1,1);
    iVar3 = FUN_1400ff680(uVar2);
    if (iVar3 != 5) {
      uVar2 = FUN_1400fda10(param_1,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 6) {
        cVar1 = FUN_14016c900(param_1);
        if (cVar1 == '\0') {
          return 0;
        }
      }
    }
  }
  return 1;
}

// ==== CCrossMsgOptItem::helper_140331c80  @140331c80  [medium:callgraph-r1]  (orig: FUN_140331c80)
longlong * FUN_140331c80(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)*param_1;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar2 = 0;
    if (plVar1 == (longlong *)0x0) goto LAB_140331ca2;
  }
  lVar2 = *plVar1;
LAB_140331ca2:
  if (*(ulonglong *)(lVar2 + 0x20) <= (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1[1] = param_1[1] + 8;
  return param_1;
}

// ==== CCrossMsgOptItem::helper_1403352e0  @1403352e0  [medium:callgraph-r1]  (orig: FUN_1403352e0)
void FUN_1403352e0(undefined8 *param_1)

{
  if ((void *)param_1[3] != (void *)0x0) {
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CCrossMsgOptItem::helper_1403366d0  @1403366d0  [medium:callgraph-r1]  (orig: FUN_1403366d0)
undefined8 FUN_1403366d0(longlong param_1,int param_2)

{
  void *_Dst;
  undefined8 *puVar1;
  int iVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  rsize_t _DstSize;
  ulonglong uVar6;
  int iVar7;
  
  iVar7 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) + -1;
  uVar6 = (ulonglong)iVar7;
  if (-1 < iVar7) {
    plVar4 = (longlong *)0x0;
    do {
      plVar3 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar3 = plVar4;
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar6
         ) {
        _invalid_parameter_noinfo();
      }
      plVar3 = (longlong *)
               (**(code **)(*plVar3 + 0x60))
                         (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar6 * 4));
      if ((plVar3 != (longlong *)0x0) &&
         (iVar2 = (**(code **)(*plVar3 + 8))(plVar3), iVar2 == param_2)) {
        uVar6 = *(ulonglong *)(param_1 + 0xc20);
        if (*(ulonglong *)(param_1 + 0xc28) < uVar6) {
          _invalid_parameter_noinfo();
        }
        puVar1 = *(undefined8 **)(param_1 + 0xc08);
        if (puVar1 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar3 = plVar4;
        }
        else {
          plVar3 = (longlong *)*puVar1;
        }
        _Dst = (void *)(uVar6 + (longlong)iVar7 * 4);
        if (_Dst <= (void *)plVar3[4]) {
          if (puVar1 != (undefined8 *)0x0) {
            plVar4 = (longlong *)*puVar1;
          }
          if ((void *)plVar4[3] <= _Dst) goto LAB_140336808;
        }
        _invalid_parameter_noinfo();
LAB_140336808:
        lVar5 = *(longlong *)(param_1 + 0xc28) - ((longlong)_Dst + 4) >> 2;
        if (0 < lVar5) {
          _DstSize = lVar5 << 2;
          memmove_s(_Dst,_DstSize,(void *)((longlong)_Dst + 4),_DstSize);
        }
        *(longlong *)(param_1 + 0xc28) = *(longlong *)(param_1 + 0xc28) + -4;
        if ((_Dst < *(void **)(param_1 + 0xc20)) || (*(void **)(param_1 + 0xc28) < _Dst)) {
          _invalid_parameter_noinfo();
        }
        iVar7 = FUN_140166ec0(param_1);
        if (((iVar7 != 0) && (plVar4 = (longlong *)CurrentInstanceGet(), plVar4 != (longlong *)0x0))
           && (plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,0x1b),
              plVar4 != (longlong *)0x0)) {
          (**(code **)(*plVar4 + 0x30))(plVar4,iVar7,param_2);
        }
        FUN_1401642f0(param_1);
        return 1;
      }
      iVar7 = iVar7 + -1;
      uVar6 = uVar6 - 1;
    } while (-1 < (longlong)uVar6);
  }
  return 0;
}

// ==== CCrossMsgOptItem::helper_14033cce0  @14033cce0  [medium:callgraph-r0]  (orig: FUN_14033cce0)
undefined8
FUN_14033cce0(longlong *param_1,undefined4 param_2,char param_3,char param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  bool bVar9;
  bool bVar10;
  bool bVar11;
  undefined4 local_res10 [2];
  undefined4 local_38 [4];
  
  plVar5 = DAT_140975b60;
  local_res10[0] = param_2;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar5 = (longlong *)0x0;
  }
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_2);
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else {
    iVar2 = FUN_1400fda10(plVar5,2,1);
    iVar3 = (**(code **)(*param_1 + 8))(param_1);
    bVar9 = iVar2 != iVar3;
    if (bVar9) {
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      FUN_140104140(plVar5,2,uVar4);
    }
    iVar2 = FUN_1400fda10(plVar5,3,1);
    iVar3 = (**(code **)(*param_1 + 8))(param_1);
    bVar10 = iVar2 != iVar3;
    if (bVar10) {
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      FUN_140104140(plVar5,3,uVar4);
    }
    iVar2 = FUN_1400fda10(plVar5,7,1);
    bVar11 = iVar2 != 0;
    if (bVar11) {
      FUN_140104140(plVar5,7,0);
    }
    if ((ulonglong)(param_1[0x185] - param_1[0x184] >> 2) < 0x28) {
      if ((param_4 != '\0') && (bVar11 || (bVar10 || bVar9))) {
        FUN_140104080(plVar5,1);
      }
      FUN_140037fe0(param_1 + 0x181,local_res10);
      if (param_3 != '\0') {
        plVar6 = (longlong *)FUN_140087d40();
        (**(code **)(*plVar6 + 0x130))(plVar6,param_1,plVar5,1,0,param_5);
        uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
        FUN_14019a030(param_1,uVar4,0,0);
      }
      FUN_1401642f0(param_1);
      lVar7 = FUN_140008520((int)param_1[0x246]);
      plVar5 = *(longlong **)(lVar7 + 0x128);
      if (plVar5 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = (longlong *)0x0;
      }
      cVar1 = FUN_14020c770(plVar5,param_2);
      if (cVar1 != '\0') {
        uVar8 = FUN_140008520((int)param_1[0x246]);
        uVar8 = FUN_140117f70(uVar8);
        FUN_14020f0d0(uVar8,param_2);
      }
      uVar8 = 1;
    }
    else {
      if ((param_4 != '\0') && (bVar11 || (bVar10 || bVar9))) {
        FUN_140104080(plVar5,1);
      }
      local_38[0] = (**(code **)(*plVar5 + 8))(plVar5);
      FUN_140037fe0(param_1 + 0x1ad,local_38);
      uVar8 = 0;
    }
  }
  return uVar8;
}

// ==== CCrossMsgOptItem::helper_14034aa60  @14034aa60  [medium:callgraph-r0]  (orig: FUN_14034aa60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

undefined1 FUN_14034aa60(longlong *param_1,int param_2,int param_3,char param_4)

{
  bool bVar1;
  char cVar2;
  undefined1 uVar3;
  byte bVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  longlong *plVar12;
  undefined8 uVar13;
  longlong lVar14;
  longlong *plVar15;
  longlong lVar16;
  longlong lVar17;
  undefined8 uVar18;
  longlong *plVar19;
  IStringManager *pIVar20;
  ulonglong uVar21;
  longlong *plVar22;
  longlong *plVar23;
  undefined1 uVar24;
  undefined1 auStack_578 [32];
  undefined4 local_558;
  undefined8 local_548;
  longlong *local_540;
  int local_538;
  longlong *local_530 [3];
  longlong *local_518;
  longlong *local_510;
  longlong local_508;
  undefined8 local_4f8;
  longlong *plStack_4f0;
  char local_4e8;
  longlong *local_4d8;
  longlong *plStack_4d0;
  longlong local_4b8;
  int local_4b0;
  int local_4ac;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  if (param_2 == 0) {
    return 0;
  }
  if (((param_3 != 0) && (((param_3 < 1 || (0x13 < param_3)) && (8 < param_3 - 0x15U)))) ||
     ((param_3 == 0xd || (param_3 == 0xe)))) {
    return 0;
  }
  local_4e8 = param_4;
  local_4b0 = param_2;
  plVar12 = (longlong *)FUN_140087d40();
  plVar12 = (longlong *)(**(code **)(*plVar12 + 0x60))(plVar12,param_2);
  if (plVar12 == (longlong *)0x0) {
    return 0;
  }
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  uVar13 = FUN_140008520((int)param_1[0x246]);
  uVar13 = FUN_1400877e0(uVar13);
  FUN_1402f28d0(uVar13,uVar6,0);
  cVar2 = FUN_14032f520(param_1,param_2,param_3);
  if (cVar2 == '\0') {
    return 0;
  }
  cVar2 = (**(code **)(param_1[2] + 0x278))(param_1 + 2);
  if ((cVar2 != '\0') && (cVar2 = FUN_14016c900(plVar12), cVar2 == '\0')) {
    uVar6 = FUN_1400fda10(plVar12,1,1);
    cVar2 = FUN_14015f820(uVar6);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  uVar6 = FUN_1400fda10(plVar12,1,1);
  iVar7 = FUN_1400ff680(uVar6);
  if (iVar7 == 0xc) {
LAB_14034abca:
    uVar8 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
    if (uVar8 < 100) {
      return 0;
    }
  }
  else {
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar7 = FUN_1400ff680(uVar6);
    if (iVar7 == 0xd) goto LAB_14034abca;
  }
  iVar7 = param_3;
  if (param_3 == 0) {
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 1) {
      iVar7 = 0x15;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 1;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 2) {
      iVar7 = 0x16;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 2;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 3) {
      iVar7 = 0x17;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 3;
      }
      goto LAB_14034b051;
    }
    cVar2 = FUN_14032ef90(plVar12);
    if (cVar2 != '\0') {
      iVar7 = 0x17;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 3;
      }
      cVar2 = FUN_14016c900(plVar12);
      if (cVar2 == '\0') {
        uVar6 = FUN_1400fda10(plVar12,1,1);
        iVar9 = FUN_1400ff680(uVar6);
        if (iVar9 == 5) {
          iVar7 = 0x18;
          if ((int)param_1[0x12a] == 0) {
            iVar7 = 4;
          }
        }
        else {
          uVar6 = FUN_1400fda10(plVar12,1,1);
          iVar9 = FUN_1400ff680(uVar6);
          if (iVar9 == 4) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar16 = (**(code **)(*plVar15 + 0x60))
                               (plVar15,*(undefined4 *)((longlong)param_1 + 0xda4));
            plVar15 = (longlong *)FUN_140087d40();
            lVar14 = (**(code **)(*plVar15 + 0x60))(plVar15,(int)param_1[0x1b5]);
            if (lVar16 != 0) {
              uVar6 = FUN_1400fda10(lVar16,1,1);
              iVar7 = FUN_1400ff680(uVar6);
              if ((iVar7 != 5) && (lVar14 == 0)) {
                iVar7 = FUN_1400ff9e0(plVar12);
                if ((iVar7 == 0x263) || (iVar7 = FUN_1400ff9e0(plVar12), iVar7 == 0x26c)) {
                  iVar7 = 0x18;
                  if ((int)param_1[0x12a] == 0) {
                    iVar7 = 4;
                  }
                }
                else {
                  iVar7 = 0x19;
                  if ((int)param_1[0x12a] == 0) {
                    iVar7 = 5;
                  }
                }
                goto LAB_14034ae3a;
              }
            }
            iVar7 = 0x18;
            if ((int)param_1[0x12a] == 0) {
              iVar7 = 4;
            }
          }
          else {
            uVar6 = FUN_1400fda10(plVar12,1,1);
            iVar9 = FUN_1400ff680(uVar6);
            if (iVar9 == 6) {
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = (**(code **)(*plVar15 + 0x60))
                                 (plVar15,*(undefined4 *)((longlong)param_1 + 0xda4));
              if ((lVar16 != 0) && (iVar7 = 0x19, (int)param_1[0x12a] == 0)) {
                iVar7 = 5;
              }
            }
          }
        }
      }
      else {
        iVar7 = 0x19;
        if ((int)param_1[0x12a] == 0) {
          iVar7 = 5;
        }
      }
LAB_14034ae3a:
      cVar2 = FUN_14032f520(param_1,param_2,iVar7);
      if (cVar2 == '\0') {
        return 0;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 7) {
      iVar7 = 0x1a;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 6;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 10) {
      iVar7 = 0x1b;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 7;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 8) {
      iVar7 = 0x1c;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 8;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0xb) {
      iVar7 = 0x1d;
      if ((int)param_1[0x12a] == 0) {
        iVar7 = 9;
      }
      goto LAB_14034b051;
    }
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0xc) {
      param_3 = 10;
      iVar7 = param_3;
    }
    else {
      uVar6 = FUN_1400fda10(plVar12,1,1);
      iVar9 = FUN_1400ff680(uVar6);
      if (iVar9 == 0xd) {
        param_3 = 0xb;
        iVar7 = param_3;
      }
      else {
        uVar6 = FUN_1400fda10(plVar12,1,1);
        iVar9 = FUN_1400ff680(uVar6);
        if (iVar9 == 0x16) {
          param_3 = 0x13;
          iVar7 = param_3;
        }
        else {
          uVar6 = FUN_1400fda10(plVar12,1,1);
          iVar9 = FUN_1400ff680(uVar6);
          if (iVar9 == 0x15) {
            param_3 = 0x12;
            iVar7 = param_3;
          }
          else {
            uVar6 = FUN_1400fda10(plVar12,1,1);
            iVar9 = FUN_1400ff680(uVar6);
            if (iVar9 == 0xe) {
              iVar7 = FUN_1400fda10(plVar12,0xc,1);
              iVar9 = FUN_140160850(param_1);
              *(bool *)((longlong)param_1 + 0x126c) = iVar7 < iVar9;
              param_3 = 0xc;
              iVar7 = param_3;
            }
            else {
              cVar2 = FUN_14032ee50(plVar12);
              if (cVar2 == '\0') {
                cVar2 = FUN_14032eec0(plVar12);
                if (cVar2 == '\0') {
                  uVar6 = FUN_1400fda10(plVar12,1,1);
                  iVar9 = FUN_1400ff680(uVar6);
                  if (iVar9 == 0x14) {
                    param_3 = 0x11;
                    iVar7 = param_3;
                  }
                }
                else {
                  param_3 = 0x10;
                  iVar7 = param_3;
                }
              }
              else {
                param_3 = 0xf;
                iVar7 = param_3;
              }
            }
          }
        }
      }
    }
  }
  else {
LAB_14034b051:
    param_3 = iVar7;
    if (0x14 < iVar7) {
      param_3 = iVar7 % 10;
    }
  }
  local_538 = param_3;
  if (0x28 < (ulonglong)(param_1[0x185] - param_1[0x184] >> 2)) {
    plVar15 = (longlong *)FUN_140087d40();
    lVar16 = *plVar15;
    uVar6 = FUN_14032b4b0(param_1,iVar7);
    lVar16 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
    if (lVar16 != 0) {
      return 0;
    }
  }
  if (param_3 == 4) {
    plVar15 = (longlong *)FUN_140087d40();
    lVar16 = (**(code **)(*plVar15 + 0x60))(plVar15,*(undefined4 *)((longlong)param_1 + 0xda4));
    if (lVar16 == 0) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = (**(code **)(*plVar15 + 0x60))(plVar15,(int)param_1[0x1b5]);
      if (lVar16 != 0) {
        plVar15 = (longlong *)FUN_140087d40();
        uVar13 = (**(code **)(*plVar15 + 0x60))(plVar15,(int)param_1[0x1b5]);
        cVar2 = FUN_14016c900(uVar13);
        if (cVar2 != '\0') {
          uVar6 = FUN_1400fda10(plVar12,1,1);
          cVar2 = FUN_14015f820(uVar6);
          if (cVar2 == '\0') {
            return 0;
          }
        }
      }
    }
  }
  local_4ac = FUN_14018e160(param_1);
  local_548 = operator_new(8);
  local_530[0] = (longlong *)0x0;
  if (local_548 != (longlong *)0x0) {
    *local_548 = (longlong)local_530;
    local_530[0] = local_548;
  }
  local_518 = (longlong *)0x0;
  local_510 = (longlong *)0x0;
  local_508 = 0;
  local_4f8 = local_548;
  cVar2 = FUN_1403366d0(param_1,param_2);
  if (cVar2 == '\0') {
    local_558 = 0x4dc;
    log_InlineLogERROR(&DAT_1406d9c10);
    if (local_518 != (longlong *)0x0) {
      operator_delete(local_518);
    }
    local_518 = (longlong *)0x0;
    local_510 = (longlong *)0x0;
    local_508 = 0;
    operator_delete(local_530[0]);
    return 0;
  }
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  uVar13 = FUN_140008520((int)param_1[0x246]);
  uVar13 = FUN_1400877e0(uVar13);
  plVar15 = (longlong *)FUN_1402f2760(uVar13,uVar6,0x2847);
  uVar24 = 0;
  local_4f8 = plVar15;
  switch(iVar7) {
  case 1:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 1) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15);
      plVar15 = local_510;
      if (local_548 != (longlong *)0x0) {
        if (local_518 == (longlong *)0x0) {
          uVar21 = 0;
        }
        else {
          uVar21 = local_508 - (longlong)local_518 >> 3;
        }
        if ((ulonglong)((longlong)local_510 - (longlong)local_518 >> 3) < uVar21) {
          *local_510 = (longlong)local_548;
          local_510 = local_510 + 1;
        }
        else {
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar22 = local_518;
          plVar19 = local_530[0];
          local_4f8 = local_530[0];
          plStack_4f0 = plVar15;
          if (((longlong)local_510 - (longlong)local_518 & 0xfffffffffffffff8U) == 0) {
            lVar16 = 0;
          }
          else {
            if (local_510 < local_518) {
              _invalid_parameter_noinfo();
            }
            if ((plVar19 == (longlong *)0x0) || (plVar19 != local_530[0])) {
              _invalid_parameter_noinfo();
            }
            lVar16 = (longlong)plVar15 - (longlong)plVar22 >> 3;
          }
          local_4d8 = local_4f8;
          plStack_4d0 = plStack_4f0;
          FUN_140322900(local_530,&local_4d8,1,&local_548);
          plVar15 = local_518;
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar19 = local_530[0];
          if (local_530[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar14 = 0;
          }
          else {
            lVar14 = *local_530[0];
          }
          if (plVar15 + lVar16 <= *(longlong **)(lVar14 + 0x20)) {
            if (plVar19 == (longlong *)0x0) {
              lVar14 = 0;
            }
            else {
              lVar14 = *plVar19;
            }
            param_3 = local_538;
            if (*(longlong **)(lVar14 + 0x18) <= plVar15 + lVar16) goto LAB_14034b3da;
          }
          _invalid_parameter_noinfo();
          param_3 = local_538;
        }
      }
LAB_14034b3da:
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_4f8 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_4f8);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
LAB_14034de0c:
      uVar24 = 1;
      bVar1 = false;
      iVar9 = local_538;
      if (local_4e8 != '\0') {
        FUN_1400f83e0(local_498);
        local_558 = 0;
        iVar7 = FUN_1400f8490(local_498,local_4b0,5,iVar7);
        plVar15 = local_518;
        if (iVar7 != 0) {
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar22 = local_510;
          plVar19 = local_530[0];
          local_548 = local_530[0];
          local_540 = plVar15;
          plVar23 = local_530[0];
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
            plVar23 = local_530[0];
          }
          while( true ) {
            if ((plVar19 == (longlong *)0x0) || (plVar19 != plVar23)) {
              _invalid_parameter_noinfo();
            }
            if (plVar15 == plVar22) break;
            if (plVar19 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar16 = 0;
            }
            else {
              lVar16 = *plVar19;
            }
            if (*(longlong **)(lVar16 + 0x20) <= plVar15) {
              _invalid_parameter_noinfo();
            }
            if (*plVar15 != 0) {
              if (plVar19 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar16 = 0;
              }
              else {
                lVar16 = *plVar19;
              }
              if (*(longlong **)(lVar16 + 0x20) <= plVar15) {
                _invalid_parameter_noinfo();
              }
              uVar6 = (**(code **)(*(longlong *)*plVar15 + 8))();
              FUN_1400f8750(local_498,uVar6);
            }
            FUN_140331c80(&local_548);
            plVar19 = local_548;
            plVar15 = local_540;
          }
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_498);
        }
        iVar9 = local_538;
        if ((((((local_538 == 1) || (local_538 == 3)) || (local_538 == 4)) ||
             ((local_538 == 5 || (local_538 == 9)))) || (local_538 == 0xc)) ||
           (((local_538 == 0xf || (local_538 == 0x10)) ||
            ((local_538 == 0x11 || (local_538 == 0x13)))))) {
          bVar1 = true;
        }
        FUN_1400f8430(local_498);
      }
      plVar15 = param_1 + 2;
      FUN_140338b40(param_1);
      FUN_1401642f0(param_1);
      FUN_14015fe60(param_1);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      cVar2 = FUN_14032b480(param_1,uVar6);
      if (cVar2 != '\0') {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        FUN_140171670(param_1,uVar6,iVar9);
      }
      iVar7 = FUN_1400ff9e0(plVar12);
      if (iVar7 == 0x26c) {
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        uVar13 = FUN_140008520((int)param_1[0x246]);
        uVar13 = FUN_1400877e0(uVar13);
        FUN_1402f27e0(uVar13,uVar6,1);
      }
      FUN_140194390(param_1);
      if (bVar1) {
        FUN_14039ed70(local_498);
        iVar7 = FUN_14039eef0(local_498,plVar15,0,0);
        if (iVar7 != 0) {
          (**(code **)(*plVar15 + 0x348))(plVar15,local_498,0);
        }
        FUN_14039edf0(local_498);
      }
      FUN_140194840(param_1,0,0);
      *(undefined1 *)((longlong)param_1 + 0x954) = 1;
      iVar7 = FUN_14018e160(param_1);
      if (iVar7 != local_4ac) {
        FUN_140198a90(param_1);
      }
      goto LAB_14034e0ea;
    }
    break;
  case 2:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 2) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15);
      plVar15 = local_510;
      if (local_548 != (longlong *)0x0) {
        if (local_518 == (longlong *)0x0) {
          uVar21 = 0;
        }
        else {
          uVar21 = local_508 - (longlong)local_518 >> 3;
        }
        if ((ulonglong)((longlong)local_510 - (longlong)local_518 >> 3) < uVar21) {
          *local_510 = (longlong)local_548;
          local_510 = local_510 + 1;
        }
        else {
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar22 = local_518;
          plVar19 = local_530[0];
          local_4f8 = local_530[0];
          plStack_4f0 = plVar15;
          if (((longlong)local_510 - (longlong)local_518 & 0xfffffffffffffff8U) == 0) {
            lVar16 = 0;
          }
          else {
            if (local_510 < local_518) {
              _invalid_parameter_noinfo();
            }
            if ((plVar19 == (longlong *)0x0) || (plVar19 != local_530[0])) {
              _invalid_parameter_noinfo();
            }
            lVar16 = (longlong)plVar15 - (longlong)plVar22 >> 3;
          }
          local_4d8 = local_4f8;
          plStack_4d0 = plStack_4f0;
          FUN_140322900(local_530,&local_4d8,1,&local_548);
          plVar15 = local_518;
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar19 = local_530[0];
          if (local_530[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar14 = 0;
          }
          else {
            lVar14 = *local_530[0];
          }
          if (plVar15 + lVar16 <= *(longlong **)(lVar14 + 0x20)) {
            if (plVar19 == (longlong *)0x0) {
              lVar14 = 0;
            }
            else {
              lVar14 = *plVar19;
            }
            param_3 = local_538;
            if (*(longlong **)(lVar14 + 0x18) <= plVar15 + lVar16) goto LAB_14034b5cd;
          }
          _invalid_parameter_noinfo();
          param_3 = local_538;
        }
      }
LAB_14034b5cd:
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_4f8 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_4f8);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 3:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 3) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15);
      plVar15 = local_510;
      if (local_548 != (longlong *)0x0) {
        if (local_518 == (longlong *)0x0) {
          uVar21 = 0;
        }
        else {
          uVar21 = local_508 - (longlong)local_518 >> 3;
        }
        if ((ulonglong)((longlong)local_510 - (longlong)local_518 >> 3) < uVar21) {
          *local_510 = (longlong)local_548;
          local_510 = local_510 + 1;
        }
        else {
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar22 = local_518;
          plVar19 = local_530[0];
          local_4f8 = local_530[0];
          plStack_4f0 = plVar15;
          if (((longlong)local_510 - (longlong)local_518 & 0xfffffffffffffff8U) == 0) {
            lVar16 = 0;
          }
          else {
            if (local_510 < local_518) {
              _invalid_parameter_noinfo();
            }
            if ((plVar19 == (longlong *)0x0) || (plVar19 != local_530[0])) {
              _invalid_parameter_noinfo();
            }
            lVar16 = (longlong)plVar15 - (longlong)plVar22 >> 3;
          }
          local_4d8 = local_4f8;
          plStack_4d0 = plStack_4f0;
          FUN_140322900(local_530,&local_4d8,1,&local_548);
          plVar15 = local_518;
          if (local_510 < local_518) {
            _invalid_parameter_noinfo();
          }
          plVar19 = local_530[0];
          if (local_530[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar14 = 0;
          }
          else {
            lVar14 = *local_530[0];
          }
          if (plVar15 + lVar16 <= *(longlong **)(lVar14 + 0x20)) {
            if (plVar19 == (longlong *)0x0) {
              lVar14 = 0;
            }
            else {
              lVar14 = *plVar19;
            }
            param_3 = local_538;
            if (*(longlong **)(lVar14 + 0x18) <= plVar15 + lVar16) goto LAB_14034b7c0;
          }
          _invalid_parameter_noinfo();
          param_3 = local_538;
        }
      }
LAB_14034b7c0:
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_4f8 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_4f8);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 4:
    cVar2 = FUN_14032ef90(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_140337820(param_1,4);
      lVar14 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_140337820(param_1,5);
      lVar17 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_140337820(param_1,0x10);
      plVar15 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      local_548 = plVar15;
      if (lVar17 == 0) {
LAB_14034b9b3:
        if ((local_4f8 != (longlong *)0x0) && (lVar17 != 0)) {
          uVar6 = FUN_1400fda10(lVar17,1,1);
          iVar9 = FUN_1400ff680(uVar6);
          if (iVar9 == 6) {
            uVar6 = FUN_1400fda10(plVar12,1,1);
            cVar2 = FUN_14015f820(uVar6);
            if (cVar2 != '\0') {
              if (local_518 != (longlong *)0x0) {
                operator_delete(local_518);
              }
              local_518 = (longlong *)0x0;
              local_510 = (longlong *)0x0;
              local_508 = 0;
              operator_delete(local_530[0]);
              return 0;
            }
          }
        }
        iVar9 = 1;
        if (lVar17 != 0) {
          cVar2 = FUN_140102870(lVar17);
          if (cVar2 == '\0') {
            iVar9 = 2;
          }
          else {
            uVar5 = FUN_1400fda10(lVar17,0x16,1);
            uVar6 = FUN_1400ffda0(lVar17);
            uVar11 = FUN_1400fda10(lVar17,1,1);
            iVar9 = FUN_140339ba0(param_1,uVar11,uVar6,uVar5);
            iVar9 = iVar9 + 1;
            plVar15 = local_548;
          }
        }
        if (plVar15 != (longlong *)0x0) {
          uVar6 = FUN_1400fda10(plVar12,1,1);
          iVar10 = FUN_1400ff680(uVar6);
          if (iVar10 == 5) {
            iVar9 = iVar9 + 1;
          }
        }
        uVar6 = FUN_1400fda10(plVar12,1,1);
        iVar10 = FUN_1400ff680(uVar6);
        if (iVar10 == 5) {
          if ((((lVar14 == 0) || ((lVar17 == 0 && (plVar15 == (longlong *)0x0)))) || (iVar9 < 1)) ||
             ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar9) < 0x29)) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar16 = *plVar15;
            FUN_1403418e0(param_1,iVar7,0);
            local_4b8 = (**(code **)(lVar16 + 0x60))(plVar15);
            plVar15 = local_510;
            if (local_4b8 != 0) {
              if (local_518 == (longlong *)0x0) {
                uVar21 = 0;
              }
              else {
                uVar21 = local_508 - (longlong)local_518 >> 3;
              }
              if ((ulonglong)((longlong)local_510 - (longlong)local_518 >> 3) < uVar21) {
                *local_510 = local_4b8;
                local_510 = local_510 + 1;
              }
              else {
                if (local_510 < local_518) {
                  _invalid_parameter_noinfo();
                }
                plVar22 = local_518;
                plVar19 = local_530[0];
                local_4d8 = local_530[0];
                plStack_4d0 = plVar15;
                if (((longlong)local_510 - (longlong)local_518 & 0xfffffffffffffff8U) == 0) {
                  lVar16 = 0;
                }
                else {
                  if (local_510 < local_518) {
                    _invalid_parameter_noinfo();
                  }
                  if ((plVar19 == (longlong *)0x0) || (plVar19 != local_530[0])) {
                    _invalid_parameter_noinfo();
                  }
                  lVar16 = (longlong)plVar15 - (longlong)plVar22 >> 3;
                }
                FUN_140322900(local_530,&local_4d8,1,&local_4b8);
                plVar15 = local_518;
                if (local_510 < local_518) {
                  _invalid_parameter_noinfo();
                }
                plVar19 = local_530[0];
                if (local_530[0] == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar14 = 0;
                }
                else {
                  lVar14 = *local_530[0];
                }
                if (plVar15 + lVar16 <= *(longlong **)(lVar14 + 0x20)) {
                  if (plVar19 == (longlong *)0x0) {
                    lVar14 = 0;
                  }
                  else {
                    lVar14 = *plVar19;
                  }
                  if (*(longlong **)(lVar14 + 0x18) <= plVar15 + lVar16) goto LAB_14034bc5e;
                }
                _invalid_parameter_noinfo();
              }
            }
LAB_14034bc5e:
            if (lVar17 != 0) {
              cVar2 = FUN_14016c900(lVar17);
              if (cVar2 != '\0') {
                uVar6 = FUN_1400fda10(plVar12,1,1);
                cVar2 = FUN_14015f820(uVar6);
                if (cVar2 != '\0') goto LAB_14034bce2;
              }
              if ((local_4f8 == (longlong *)0x0) || (cVar2 = FUN_140103960(lVar17), cVar2 == '\0'))
              {
                plVar15 = (longlong *)FUN_140087d40();
                lVar16 = *plVar15;
                uVar6 = FUN_1403418e0(param_1,5);
                local_4b8 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
                if (local_4b8 != 0) {
                  FUN_140327660(local_530,&local_4b8);
                }
              }
            }
LAB_14034bce2:
            if (local_548 != (longlong *)0x0) {
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = *plVar15;
              uVar6 = FUN_1403418e0(param_1,0x10);
              local_4b8 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
              if (local_4b8 != 0) {
                FUN_140327660(local_530,&local_4b8);
              }
            }
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            local_548 = (longlong *)CONCAT44(uVar6,iVar7);
            FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
            if ((int)param_1[0x12a] == 0) {
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              *(undefined4 *)((longlong)param_1 + (longlong)local_538 * 4 + 0xd94) = uVar6;
            }
            FUN_140104140(plVar12,7,iVar7);
            goto LAB_14034de0c;
          }
        }
        else {
          cVar2 = FUN_140119480(plVar12);
          if ((cVar2 != '\0') &&
             (((lVar17 == 0 || (cVar2 = FUN_14016c900(lVar17), cVar2 == '\0')) ||
              (cVar2 = FUN_1400c9580(param_1,iVar9,0), cVar2 != '\0')))) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar16 = *plVar15;
            uVar6 = FUN_1403418e0(param_1,iVar7,0);
            local_4f8 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
            if (local_4f8 != (longlong *)0x0) {
              FUN_140327660(local_530,&local_4f8);
            }
            if ((lVar17 != 0) && (cVar2 = FUN_14016c900(lVar17), cVar2 != '\0')) {
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = *plVar15;
              uVar6 = FUN_1403418e0(param_1,5);
              local_4f8 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
              if (local_4f8 != (longlong *)0x0) {
                FUN_140327660(local_530,&local_4f8);
              }
            }
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            local_548 = (longlong *)CONCAT44(uVar6,iVar7);
            FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
            if ((int)param_1[0x12a] == 0) {
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              *(undefined4 *)((longlong)param_1 + (longlong)local_538 * 4 + 0xd94) = uVar6;
            }
            FUN_140104140(plVar12,7,iVar7);
            goto LAB_14034de0c;
          }
        }
      }
      else {
        iVar9 = FUN_1400ff9e0(plVar12);
        if ((((iVar9 == 0x263) || (iVar9 = FUN_1400ff9e0(lVar17), iVar9 != 0x264)) &&
            ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x265 ||
             (iVar9 = FUN_1400ff9e0(lVar17), iVar9 != 0x265)))) &&
           ((((cVar2 = FUN_1400ffa40(plVar12), cVar2 != '\0' ||
              (cVar2 = FUN_1400ffa40(lVar17), cVar2 == '\0')) &&
             ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x269 ||
              (iVar9 = FUN_1400ff9e0(lVar17), iVar9 != 0x269)))) &&
            ((iVar9 = FUN_1400ff9e0(lVar17), iVar9 != 0x26b ||
             (cVar2 = FUN_14016caf0(plVar12), cVar2 != '\0')))))) {
          iVar9 = FUN_1400ff9e0(plVar12);
          if ((iVar9 != 0x265) || (iVar9 = FUN_1400ff9e0(lVar17), iVar9 == 0x265))
          goto LAB_14034b9b3;
          if (lVar14 != 0) {
            uVar6 = FUN_1400fda10(lVar14,1,1);
            cVar2 = FUN_14015f820(uVar6);
            if ((cVar2 != '\0') && (cVar2 = FUN_14016c900(lVar17), cVar2 != '\0'))
            goto LAB_14034b9b3;
          }
        }
      }
    }
    break;
  case 5:
    cVar2 = FUN_14032ef90(plVar12);
    if (cVar2 != '\0') {
      plVar19 = (longlong *)FUN_140087d40();
      lVar16 = *plVar19;
      uVar6 = FUN_140337820(param_1,4);
      lVar16 = (**(code **)(lVar16 + 0x60))(plVar19,uVar6);
      if (lVar16 != 0) {
        cVar2 = FUN_140119480(plVar12);
        if ((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) {
LAB_14034bfcb:
          cVar2 = FUN_140103960(plVar12);
          if (((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) ||
             ((uVar8 = *(byte *)((longlong)param_1 + 0xeee) / 10, uVar8 != 2 &&
              ((((((uVar8 != 1 && (uVar8 != 4)) && (uVar8 != 5)) &&
                 (((uVar8 != 6 && (uVar8 != 7)) && (uVar8 != 8)))) ||
                ((iVar9 = (**(code **)(*param_1 + 0x108))(param_1), iVar9 == 0 ||
                 (uVar8 = (**(code **)(param_1[2] + 0x70))(param_1 + 2), uVar8 < 0x46)))) ||
               (iVar9 = FUN_1400fda10(plVar12,0x68,1), 0x46 < iVar9)))))) {
            cVar2 = FUN_14016c900(plVar12);
            if (cVar2 != '\0') {
              uVar6 = FUN_1400fda10(lVar16,1,1);
              cVar2 = FUN_14015f820(uVar6);
              if (cVar2 != '\0') goto LAB_14034c1b4;
            }
            cVar2 = FUN_140103960(plVar12);
            if (((cVar2 != '\0') && (plVar15 != (longlong *)0x0)) &&
               (cVar2 = FUN_14016c870(lVar16), cVar2 != '\0')) {
              uVar6 = FUN_1400fda10(lVar16,1,1);
              cVar2 = FUN_14015f820(uVar6);
              if (cVar2 == '\0') goto LAB_14034c1b4;
            }
            uVar13 = FUN_140008520((int)param_1[0x246]);
            cVar2 = FUN_14008abf0(uVar13);
            if (((cVar2 == '\0') || (cVar2 = FUN_140119480(plVar12), cVar2 == '\0')) ||
               ((cVar2 = FUN_140119480(lVar16), cVar2 == '\0' ||
                (((uVar8 = *(byte *)((longlong)param_1 + 0xeee) / 10, uVar8 != 1 && (uVar8 != 4)) &&
                 ((uVar8 != 5 && (((uVar8 != 6 && (uVar8 != 7)) && (uVar8 != 8)))))))))) break;
          }
        }
        else {
          bVar4 = *(byte *)((longlong)param_1 + 0xeee);
          uVar8 = bVar4 / 10;
          if (((((uVar8 != 1) || (bVar4 < 10)) && ((uVar8 != 4 || (bVar4 < 0x28)))) &&
              (((uVar8 != 5 || (bVar4 < 0x32)) &&
               ((((uVar8 != 6 || (bVar4 < 0x3c)) && ((uVar8 != 7 || (bVar4 < 0x46)))) &&
                ((uVar8 != 8 || (bVar4 < 0x50)))))))) &&
             ((uVar8 < 10 || ((0xf < uVar8 || (iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x26b))))))
          goto LAB_14034bfcb;
        }
LAB_14034c1b4:
        iVar9 = FUN_1400ff9e0(plVar12);
        if (((((iVar9 != 0x264) || (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x263)) &&
             ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x265 ||
              (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x265)))) &&
            ((((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x265 ||
               (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x265)) &&
              ((cVar2 = FUN_1400ffa40(plVar12), cVar2 == '\0' ||
               (cVar2 = FUN_1400ffa40(lVar16), cVar2 != '\0')))) &&
             ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x269 ||
              (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x269)))))) &&
           (((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x269 ||
             (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x269)) &&
            ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x26b ||
             (cVar2 = FUN_14016caf0(lVar16), cVar2 != '\0')))))) {
          iVar9 = FUN_1400ff9e0(plVar12);
          if ((iVar9 != 0x265) || (*(byte *)((longlong)param_1 + 0xeee) / 10 == 4)) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar16 = *plVar15;
            uVar6 = FUN_1403418e0(param_1,iVar7,0);
            local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
            if (local_548 != (longlong *)0x0) {
              FUN_140327660(local_530,&local_548);
            }
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            local_548 = (longlong *)CONCAT44(uVar6,iVar7);
            FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
            if ((int)param_1[0x12a] == 0) {
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
            }
            FUN_140104140(plVar12,7,iVar7);
            FUN_140171820(param_1,param_3);
            goto LAB_14034de0c;
          }
          pIVar20 = theInstance();
          lVar16 = param_1[2];
          uVar13 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_NOT_KNIFE_BY_NO_ARCHER");
          (**(code **)(lVar16 + 0x358))(param_1 + 2,uVar13);
        }
      }
    }
    break;
  case 6:
    cVar2 = FUN_140103990(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 7:
    cVar2 = FUN_14016c8a0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 8:
    cVar2 = FUN_1401039c0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,8);
      goto LAB_14034de0c;
    }
    break;
  case 9:
    cVar2 = FUN_14016c8d0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 0) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 10:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0xc) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0xb:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0xd) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0xc:
    cVar2 = FUN_140103a20(plVar12);
    if (cVar2 != '\0') {
      iVar9 = FUN_1400fda10(plVar12,0xc,1);
      iVar10 = FUN_140160850(param_1);
      *(bool *)((longlong)param_1 + 0x126c) = iVar9 < iVar10;
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      plVar15 = param_1 + 2;
      uVar6 = (**(code **)(*plVar15 + 0x48))(plVar15);
      uVar11 = (**(code **)(*plVar15 + 0x40))(plVar15);
      cVar2 = FUN_140173660(param_1,uVar11,uVar6);
      if ((cVar2 == '\0') && (plVar15 != (longlong *)0x0)) {
        plVar19 = (longlong *)FUN_1401181a0();
        lVar16 = *plVar19;
        uVar6 = (**(code **)(*plVar15 + 0x10))(plVar15);
        (**(code **)(lVar16 + 0x10))(plVar19,uVar6,0x2f);
      }
      goto LAB_14034de0c;
    }
    break;
  default:
    FUN_1400fda10(plVar12,1,1);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("EquipItem Error player:%d, itemtype:%d, pos:%d");
    break;
  case 0xf:
    cVar2 = FUN_14032ee50(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x10:
    cVar2 = FUN_14032eec0(plVar12);
    if (cVar2 != '\0') {
      plVar19 = (longlong *)FUN_140087d40();
      lVar16 = *plVar19;
      uVar6 = FUN_140337820(param_1,4);
      lVar16 = (**(code **)(lVar16 + 0x60))(plVar19,uVar6);
      if (lVar16 != 0) {
        cVar2 = FUN_14032ed60(plVar12);
        if ((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) {
          cVar2 = FUN_14032edf0(plVar12);
          if ((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) {
            cVar2 = FUN_14032edf0(plVar12);
            if ((cVar2 == '\0') || (cVar2 = FUN_14016c870(lVar16), cVar2 == '\0')) {
              uVar13 = FUN_140008520((int)param_1[0x246]);
              cVar2 = FUN_14008abf0(uVar13);
              if ((cVar2 != '\0') &&
                 ((cVar2 = FUN_14032ed60(plVar12), cVar2 != '\0' &&
                  (cVar2 = FUN_140119480(lVar16), cVar2 != '\0')))) {
                bVar4 = *(byte *)((longlong)param_1 + 0xeee);
                goto joined_r0x00014034ccd4;
              }
            }
            else if (plVar15 != (longlong *)0x0) goto LAB_14034cdb6;
          }
          else {
            if ((*(byte *)((longlong)param_1 + 0xeee) / 10 == 2) || (plVar15 != (longlong *)0x0)) {
LAB_14034cdb6:
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = *plVar15;
              uVar6 = FUN_1403418e0(param_1,iVar7,0);
              local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
              if (local_548 != (longlong *)0x0) {
                FUN_140327660(local_530,&local_548);
              }
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              local_548 = (longlong *)CONCAT44(uVar6,iVar7);
              FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
              if ((int)param_1[0x12a] == 0) {
                uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
              }
              FUN_140104140(plVar12,7,iVar7);
              FUN_140171820(param_1,param_3);
              goto LAB_14034de0c;
            }
            iVar9 = (**(code **)(*param_1 + 0x108))(param_1);
            if ((iVar9 != 0) &&
               (uVar8 = (**(code **)(param_1[2] + 0x70))(param_1 + 2), 0x45 < uVar8)) {
              bVar4 = *(byte *)((longlong)param_1 + 0xeee);
joined_r0x00014034ccd4:
              uVar6 = bVar4 / 10;
              if (((((uVar6 == 1) || (uVar6 == 4)) || (uVar6 == 5)) ||
                  ((uVar6 == 6 || (uVar6 == 7)))) || (uVar6 == 8)) goto LAB_14034cdb6;
            }
          }
        }
        else {
          bVar4 = *(byte *)((longlong)param_1 + 0xeee);
          uVar8 = bVar4 / 10;
          if ((((((uVar8 == 1) && (9 < bVar4)) || ((uVar8 == 4 && (0x27 < bVar4)))) ||
               ((uVar8 == 5 && (0x31 < bVar4)))) || ((uVar8 == 6 && (0x3b < bVar4)))) ||
             (((uVar8 == 7 && (0x45 < bVar4)) || ((uVar8 == 8 && (0x4f < bVar4))))))
          goto LAB_14034cdb6;
        }
      }
    }
    break;
  case 0x11:
    cVar2 = FUN_14032ee20(plVar12);
    if (cVar2 != '\0') {
      uVar3 = FUN_140178c40(param_1);
      uVar13 = (**(code **)(param_1[2] + 0x1d8))(param_1 + 2);
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      uVar18 = FUN_140008520((int)param_1[0x246]);
      uVar18 = FUN_140117ed0(uVar18);
      local_558 = CONCAT31(local_558._1_3_,uVar3);
      bVar4 = FUN_140152480(uVar18,uVar6,uVar13,9);
      iVar9 = FUN_1400fda10(plVar12,0x67,1);
      if ((iVar9 <= (int)(uint)bVar4) && (bVar4 != 0)) {
        plVar15 = (longlong *)FUN_140087d40();
        lVar16 = *plVar15;
        uVar6 = FUN_1403418e0(param_1,iVar7,0);
        local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
        if (local_548 != (longlong *)0x0) {
          FUN_140327660(local_530,&local_548);
        }
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        local_548 = (longlong *)CONCAT44(uVar6,iVar7);
        FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
        FUN_140104140(plVar12,7,iVar7);
        goto LAB_14034de0c;
      }
    }
    break;
  case 0x12:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0x15) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x13:
    uVar6 = FUN_1400fda10(plVar12,1,1);
    iVar9 = FUN_1400ff680(uVar6);
    if (iVar9 == 0x16) {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      *(undefined4 *)((longlong)param_1 + (longlong)iVar7 * 4 + 0xd94) = uVar6;
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x15:
    cVar2 = FUN_1401038d0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x16:
    cVar2 = FUN_140103900(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x17:
    cVar2 = FUN_140103930(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x18:
    cVar2 = FUN_14032ef90(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_140337820(param_1,0x18);
      lVar14 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_140337820(param_1,0x19);
      lVar16 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (lVar16 == 0) {
LAB_14034d301:
        if ((local_4f8 != (longlong *)0x0) &&
           ((lVar16 != 0 && (cVar2 = FUN_140103960(lVar16), cVar2 != '\0')))) {
          uVar6 = FUN_1400fda10(plVar12,1,1);
          cVar2 = FUN_14015f820(uVar6);
          if (cVar2 != '\0') {
            if (local_518 != (longlong *)0x0) {
              operator_delete(local_518);
            }
            local_518 = (longlong *)0x0;
            local_510 = (longlong *)0x0;
            local_508 = 0;
            operator_delete(local_530[0]);
            return 0;
          }
        }
        iVar9 = 1;
        if (lVar16 != 0) {
          cVar2 = FUN_140102870(lVar16);
          if (cVar2 == '\0') {
            iVar9 = 2;
          }
          else {
            uVar5 = FUN_1400fda10(lVar16,0x16,1);
            uVar6 = FUN_1400ffda0(lVar16);
            uVar11 = FUN_1400fda10(lVar16,1,1);
            iVar9 = FUN_140339ba0(param_1,uVar11,uVar6,uVar5);
            iVar9 = iVar9 + 1;
          }
        }
        cVar2 = FUN_14016c870(plVar12);
        if (cVar2 == '\0') {
          cVar2 = FUN_140119480(plVar12);
          if ((cVar2 != '\0') &&
             (((lVar16 == 0 || (cVar2 = FUN_14016c900(lVar16), cVar2 == '\0')) ||
              (cVar2 = FUN_1400c9580(param_1,iVar9,0), cVar2 != '\0')))) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar14 = *plVar15;
            uVar6 = FUN_1403418e0(param_1,iVar7,0);
            local_4f8 = (longlong *)(**(code **)(lVar14 + 0x60))(plVar15,uVar6);
            if (local_4f8 != (longlong *)0x0) {
              FUN_140327660(local_530,&local_4f8);
            }
            if ((lVar16 != 0) && (cVar2 = FUN_14016c900(lVar16), cVar2 != '\0')) {
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = *plVar15;
              uVar6 = FUN_1403418e0(param_1,0x19);
              local_4f8 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
              if (local_4f8 != (longlong *)0x0) {
                FUN_140327660(local_530,&local_4f8);
              }
            }
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            local_548 = (longlong *)CONCAT44(uVar6,iVar7);
            FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
            if ((int)param_1[0x12a] == 1) {
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              *(undefined4 *)((longlong)param_1 + (longlong)local_538 * 4 + 0xd94) = uVar6;
            }
            FUN_140104140(plVar12,7,iVar7);
            goto LAB_14034de0c;
          }
        }
        else if (((lVar14 == 0) || (lVar16 == 0)) ||
                (cVar2 = FUN_1400c9580(param_1,iVar9,0), cVar2 != '\0')) {
          plVar15 = (longlong *)FUN_140087d40();
          lVar14 = *plVar15;
          uVar6 = FUN_1403418e0(param_1,iVar7,0);
          local_4b8 = (**(code **)(lVar14 + 0x60))(plVar15,uVar6);
          if (local_4b8 != 0) {
            FUN_140327660(local_530,&local_4b8);
          }
          if (lVar16 != 0) {
            cVar2 = FUN_14016c900(lVar16);
            if (cVar2 != '\0') {
              uVar6 = FUN_1400fda10(plVar12,1,1);
              cVar2 = FUN_14015f820(uVar6);
              if (cVar2 != '\0') goto LAB_14034d4b8;
            }
            if ((local_4f8 == (longlong *)0x0) || (cVar2 = FUN_140103960(lVar16), cVar2 == '\0')) {
              plVar15 = (longlong *)FUN_140087d40();
              lVar16 = *plVar15;
              uVar6 = FUN_1403418e0(param_1,0x19);
              local_4b8 = (**(code **)(lVar16 + 0x60))(plVar15,uVar6);
              if (local_4b8 != 0) {
                FUN_140327660(local_530,&local_4b8);
              }
            }
          }
LAB_14034d4b8:
          uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
          local_548 = (longlong *)CONCAT44(uVar6,iVar7);
          FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
          if ((int)param_1[0x12a] == 1) {
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            *(undefined4 *)((longlong)param_1 + (longlong)local_538 * 4 + 0xd94) = uVar6;
          }
          FUN_140104140(plVar12,7,iVar7);
          goto LAB_14034de0c;
        }
      }
      else {
        iVar9 = FUN_1400ff9e0(plVar12);
        if ((((iVar9 == 0x263) || (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x264)) &&
            ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x265 ||
             (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x265)))) &&
           ((((cVar2 = FUN_1400ffa40(plVar12), cVar2 != '\0' ||
              (cVar2 = FUN_1400ffa40(lVar16), cVar2 == '\0')) &&
             ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x269 ||
              (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x269)))) &&
            ((iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x26b ||
             (cVar2 = FUN_14016caf0(plVar12), cVar2 != '\0')))))) {
          iVar9 = FUN_1400ff9e0(plVar12);
          if ((iVar9 != 0x265) || (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x265))
          goto LAB_14034d301;
          if (lVar14 != 0) {
            uVar6 = FUN_1400fda10(lVar14,1,1);
            cVar2 = FUN_14015f820(uVar6);
            if ((cVar2 != '\0') && (cVar2 = FUN_14016c900(lVar16), cVar2 != '\0'))
            goto LAB_14034d301;
          }
        }
      }
    }
    break;
  case 0x19:
    cVar2 = FUN_14032ef90(plVar12);
    if (cVar2 != '\0') {
      plVar19 = (longlong *)FUN_140087d40();
      lVar16 = *plVar19;
      uVar6 = FUN_140337820(param_1,0x18);
      lVar16 = (**(code **)(lVar16 + 0x60))(plVar19,uVar6);
      if (lVar16 != 0) {
        cVar2 = FUN_140119480(plVar12);
        if ((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) {
LAB_14034d758:
          cVar2 = FUN_140103960(plVar12);
          if (((cVar2 == '\0') || (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) ||
             ((uVar8 = *(byte *)((longlong)param_1 + 0xeee) / 10, uVar8 != 2 &&
              ((((((uVar8 != 1 && (uVar8 != 4)) && (uVar8 != 5)) && ((uVar8 != 6 && (uVar8 != 7))))
                && (uVar8 != 8)) ||
               (((iVar9 = (**(code **)(*param_1 + 0x108))(param_1), iVar9 == 0 ||
                 (uVar8 = (**(code **)(param_1[2] + 0x70))(param_1 + 2), uVar8 < 0x46)) ||
                (iVar9 = FUN_1400fda10(plVar12,0x68,1), 0x46 < iVar9)))))))) {
            cVar2 = FUN_14016c900(plVar12);
            if (cVar2 != '\0') {
              uVar6 = FUN_1400fda10(lVar16,1,1);
              cVar2 = FUN_14015f820(uVar6);
              if (cVar2 != '\0') goto LAB_14034d941;
            }
            cVar2 = FUN_140103960(plVar12);
            if (((cVar2 != '\0') && (plVar15 != (longlong *)0x0)) &&
               (cVar2 = FUN_14016c870(lVar16), cVar2 != '\0')) {
              uVar6 = FUN_1400fda10(lVar16,1,1);
              cVar2 = FUN_14015f820(uVar6);
              if (cVar2 == '\0') goto LAB_14034d941;
            }
            uVar13 = FUN_140008520((int)param_1[0x246]);
            cVar2 = FUN_14008abf0(uVar13);
            if ((((cVar2 == '\0') || (cVar2 = FUN_140119480(plVar12), cVar2 == '\0')) ||
                (cVar2 = FUN_140119480(lVar16), cVar2 == '\0')) ||
               (((uVar8 = *(byte *)((longlong)param_1 + 0xeee) / 10, uVar8 != 1 && (uVar8 != 4)) &&
                ((uVar8 != 5 && (((uVar8 != 6 && (uVar8 != 7)) && (uVar8 != 8)))))))) break;
          }
        }
        else {
          bVar4 = *(byte *)((longlong)param_1 + 0xeee);
          uVar8 = bVar4 / 10;
          if (((((uVar8 != 1) || (bVar4 < 10)) &&
               (((uVar8 != 4 || (bVar4 < 0x28)) && ((uVar8 != 5 || (bVar4 < 0x32)))))) &&
              ((((uVar8 != 6 || (bVar4 < 0x3c)) && ((uVar8 != 7 || (bVar4 < 0x46)))) &&
               ((uVar8 != 8 || (bVar4 < 0x50)))))) &&
             ((uVar8 < 10 || ((0xf < uVar8 || (iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x26b))))))
          goto LAB_14034d758;
        }
LAB_14034d941:
        iVar9 = FUN_1400ff9e0(plVar12);
        if (((iVar9 != 0x264) || (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x263)) &&
           (((((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x265 ||
               (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x265)) &&
              ((((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x265 ||
                 (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x265)) &&
                ((cVar2 = FUN_1400ffa40(plVar12), cVar2 == '\0' ||
                 (cVar2 = FUN_1400ffa40(lVar16), cVar2 != '\0')))) &&
               ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x269 ||
                (iVar9 = FUN_1400ff9e0(lVar16), iVar9 == 0x269)))))) &&
             ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 == 0x269 ||
              (iVar9 = FUN_1400ff9e0(lVar16), iVar9 != 0x269)))) &&
            ((iVar9 = FUN_1400ff9e0(plVar12), iVar9 != 0x26b ||
             (cVar2 = FUN_14016caf0(lVar16), cVar2 != '\0')))))) {
          iVar9 = FUN_1400ff9e0(plVar12);
          if ((iVar9 != 0x265) || (*(byte *)((longlong)param_1 + 0xeee) / 10 == 4)) {
            plVar15 = (longlong *)FUN_140087d40();
            lVar16 = *plVar15;
            uVar6 = FUN_1403418e0(param_1,iVar7,0);
            local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
            if (local_548 != (longlong *)0x0) {
              FUN_140327660(local_530,&local_548);
            }
            uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
            local_548 = (longlong *)CONCAT44(uVar6,iVar7);
            FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
            if ((int)param_1[0x12a] == 1) {
              uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
              *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
            }
            FUN_140104140(plVar12,7,iVar7);
            FUN_140171820(param_1,param_3);
            goto LAB_14034de0c;
          }
          pIVar20 = theInstance();
          lVar16 = param_1[2];
          uVar13 = (*(code *)**(undefined8 **)pIVar20)(pIVar20,"STR_NOT_KNIFE_BY_NO_ARCHER");
          (**(code **)(lVar16 + 0x358))(param_1 + 2,uVar13);
        }
      }
    }
    break;
  case 0x1a:
    cVar2 = FUN_140103990(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x1b:
    cVar2 = FUN_14016c8a0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x1c:
    cVar2 = FUN_1401039c0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
    break;
  case 0x1d:
    cVar2 = FUN_14016c8d0(plVar12);
    if (cVar2 != '\0') {
      plVar15 = (longlong *)FUN_140087d40();
      lVar16 = *plVar15;
      uVar6 = FUN_1403418e0(param_1,iVar7,0);
      local_548 = (longlong *)(**(code **)(lVar16 + 0x60))(plVar15,uVar6);
      if (local_548 != (longlong *)0x0) {
        FUN_140327660(local_530,&local_548);
      }
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      local_548 = (longlong *)CONCAT44(uVar6,iVar7);
      FUN_1400173d0(param_1 + 0x19f,&local_4d8,&local_548);
      if ((int)param_1[0x12a] == 1) {
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        *(undefined4 *)((longlong)param_1 + (longlong)param_3 * 4 + 0xd94) = uVar6;
      }
      FUN_140104140(plVar12,7,iVar7);
      goto LAB_14034de0c;
    }
  }
  uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
  FUN_140340de0(param_1,uVar6,0,1);
LAB_14034e0ea:
  plVar12 = local_518;
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
  }
  plVar19 = local_510;
  plVar15 = local_530[0];
  local_548 = local_530[0];
  local_540 = plVar12;
  plVar22 = local_530[0];
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
    plVar22 = local_530[0];
  }
  while( true ) {
    if ((plVar15 == (longlong *)0x0) || (plVar15 != plVar22)) {
      _invalid_parameter_noinfo();
    }
    if (plVar12 == plVar19) break;
    if (plVar15 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar16 = 0;
    }
    else {
      lVar16 = *plVar15;
    }
    if (*(longlong **)(lVar16 + 0x20) <= plVar12) {
      _invalid_parameter_noinfo();
    }
    if (*plVar12 != 0) {
      if (plVar15 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = 0;
      }
      else {
        lVar16 = *plVar15;
      }
      if (*(longlong **)(lVar16 + 0x20) <= plVar12) {
        _invalid_parameter_noinfo();
      }
      cVar2 = FUN_140102870(*plVar12);
      if (cVar2 != '\0') {
        if (plVar15 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = 0;
        }
        else {
          lVar16 = *plVar15;
        }
        if (*(longlong **)(lVar16 + 0x20) <= plVar12) {
          _invalid_parameter_noinfo();
        }
        plVar12 = (longlong *)*plVar12;
        plVar15 = (longlong *)FUN_140087d40();
        lVar16 = *plVar15;
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        (**(code **)(lVar16 + 0x30))(plVar15,uVar6,1,0);
      }
    }
    FUN_140331c80(&local_548);
    plVar15 = local_548;
    plVar12 = local_540;
  }
  FUN_1403352e0(local_530);
  return uVar24;
}

// ==== CCrossMsgOptItem::ctor_or_dtor  @14036ee80  [high:vtable-assign]  (orig: FUN_14036ee80)
undefined8 * FUN_14036ee80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgOptItem::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgOptItem::ctor_or_dtor  @14036eed0  [high:vtable-assign]  (orig: FUN_14036eed0)
void FUN_14036eed0(undefined8 *param_1)

{
  *param_1 = CCrossMsgOptItem::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgOptItem::vfunc_1  @14036ef00  [high:rtti-vtable]  (orig: FUN_14036ef00)
undefined8 FUN_14036ef00(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgOptItem::ctor_or_dtor  @14036f000  [high:vtable-assign]  (orig: FUN_14036f000)
undefined8 * FUN_14036f000(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgOptItem::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgOptItem::vfunc_3  @14036f050  [high:rtti-vtable]  (orig: FUN_14036f050)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14036f050(longlong param_1)

{
  ushort *puVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined8 uVar12;
  char *pcVar13;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))
                     (*(longlong **)(lVar5 + 0x90),
                      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (plVar6 == (longlong *)0x0) {
    return;
  }
  puVar1 = *(ushort **)(param_1 + 0x428);
  switch((ulonglong)*puVar1) {
  case 0:
    if (*(int *)(puVar1 + 0x18) != 0) {
      return;
    }
    cVar2 = FUN_140102780(*(undefined4 *)(puVar1 + 0xc));
    if (cVar2 != '\0') {
      plVar9 = (longlong *)FUN_140087d40();
      lVar5 = *plVar9;
      FUN_140167b40(plVar6);
      uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
      plVar9 = (longlong *)
               (**(code **)(lVar5 + 0x18))
                         (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18),uVar4,0);
      if (plVar9 == (longlong *)0x0) {
        log_InlineLogERROR("CrossMsgOptItem add item failed,itemtype = %d, userid = %u",
                           *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18),
                           *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
        return;
      }
      uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
      FUN_14033cce0(plVar6,uVar4,1);
      FUN_140104140(plVar9,4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x24),0);
      FUN_140104140(plVar9,5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x28),0);
      FUN_140104140(plVar9,6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x2c),0);
      FUN_140104140(plVar9,7,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30),0);
      FUN_140104140(plVar9,8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x34),0);
      FUN_140104140(plVar9,9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x38),0);
      FUN_140104140(plVar9,10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x3c),0);
      FUN_140104140(plVar9,0xb,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x40),0);
      FUN_140104140(plVar9,0xc,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x44),0);
      FUN_140104140(plVar9,0xd,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x48),0);
      FUN_140104140(plVar9,0xe,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x4c),0);
      FUN_140104140(plVar9,0xf,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x50),0);
      FUN_140104140(plVar9,0x10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x54),0);
      FUN_140104140(plVar9,0x12,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x5c),0);
      FUN_140104140(plVar9,0x13,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x60),0);
      FUN_140104140(plVar9,0x14,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 100),0);
      FUN_140104140(plVar9,0x15,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x68),0);
      FUN_140104140(plVar9,0x17,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x70),0);
      FUN_140104140(plVar9,0x19,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x80),0);
      FUN_140106830(plVar9,0x18,*(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x78),0);
      FUN_140104140(plVar9,0x1a,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x84),1);
      plVar7 = (longlong *)FUN_140087d40();
      (**(code **)(*plVar7 + 0x130))(plVar7,plVar6,plVar9,3);
      if (*(int *)(*(longlong *)(param_1 + 0x428) + 0x84) < 1) {
        uVar4 = FUN_1400fda10(plVar9,1,1);
        uVar10 = FUN_1400fecd0(uVar4);
        lVar5 = *(longlong *)(param_1 + 0x428);
        uVar8 = (**(code **)(*plVar9 + 8))(plVar9);
        log_InlineLogERROR("CCrossMsgOptItem::Process CROSS_OPT_ITEM_ADD. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d"
                           ,uVar8 & 0xffffffff,uVar10 & 0xffffffff,*(undefined4 *)(lVar5 + 0x84));
      }
      plVar6 = (longlong *)FUN_140087d40();
      lVar5 = *plVar6;
      uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
      (**(code **)(lVar5 + 0x158))(plVar6,uVar4);
      return;
    }
    iVar3 = FUN_14034a8d0(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18),
                          *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x6c),1);
    if (iVar3 == 0) {
      lVar5 = *(longlong *)(param_1 + 0x428);
      log_InlineLogERROR("CrossMsgOptItem add item failed(ID_NONE),itemtype = %d, userid = %u, monopoly= %d"
                         ,*(undefined4 *)(lVar5 + 0x18),*(undefined4 *)(lVar5 + 4),
                         *(undefined4 *)(lVar5 + 0x6c));
      return;
    }
    plVar6 = (longlong *)FUN_140087d40();
    (**(code **)(*plVar6 + 0x60))(plVar6,iVar3);
    lVar5 = *(longlong *)(param_1 + 0x428);
    log_InlineLogERROR("CrossMsgOptItem add item failed,itemtype = %d, userid = %u, monopoly= %d",
                       *(undefined4 *)(lVar5 + 0x18),*(undefined4 *)(lVar5 + 4),
                       *(undefined4 *)(lVar5 + 0x6c));
    return;
  case 1:
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    plVar6 = (longlong *)FUN_140087d40();
    plVar6 = (longlong *)
             (**(code **)(*plVar6 + 0x60))
                       (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    if (plVar6 == (longlong *)0x0) {
      lVar5 = *(longlong *)(param_1 + 0x428);
      log_InlineLogERROR("Cross update:Invalid item id[%u],itemtype:%d, userid:%u",
                         *(undefined4 *)(lVar5 + 0x10),*(undefined4 *)(lVar5 + 0x18),
                         *(undefined4 *)(lVar5 + 4));
      return;
    }
    lVar5 = FUN_1400fdb80(plVar6,0x18,1);
    FUN_140104140(plVar6,4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x24));
    FUN_140104140(plVar6,7,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30));
    FUN_140104140(plVar6,0xd,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x48));
    FUN_140104140(plVar6,0x19,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x80));
    FUN_140106830(plVar6,0x18,*(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x78));
    FUN_140104140(plVar6,0x1a,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x84),1);
    iVar3 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x84);
    if (iVar3 < 1) {
      uVar10 = FUN_1400fda10(plVar6,1,1);
      uVar8 = (**(code **)(*plVar6 + 8))(plVar6);
      log_InlineLogERROR("CCrossMsgOptItem::Process CROSS_OPT_ITEM_UPDATE. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d"
                         ,uVar8 & 0xffffffff,uVar10 & 0xffffffff,iVar3);
    }
    if (lVar5 != 0) {
      return;
    }
    if (*(longlong *)(*(longlong *)(param_1 + 0x428) + 0x78) == 0) {
      return;
    }
    if (*(int *)(*(longlong *)(param_1 + 0x428) + 0x10) == 0) {
      return;
    }
    plVar6 = (longlong *)FUN_140087d40();
    (**(code **)(*plVar6 + 0x158))(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    return;
  case 2:
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    plVar9 = (longlong *)FUN_140087d40();
    lVar5 = (**(code **)(*plVar9 + 0x60))
                      (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    if (lVar5 == 0) {
      lVar5 = *(longlong *)(param_1 + 0x428);
      log_InlineLogERROR("Cross delete:Invalid item id[%u],itemtype:%d, userid:%u",
                         *(undefined4 *)(lVar5 + 0x10),*(undefined4 *)(lVar5 + 0x18),
                         *(undefined4 *)(lVar5 + 4));
      return;
    }
    iVar3 = FUN_1400fda10(lVar5,7,1);
    FUN_14032d640(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    if (((iVar3 < 1) || (0x13 < iVar3)) && (7 < iVar3 - 0x15U && iVar3 != 0x1d)) {
      cVar2 = FUN_14033a6a0(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10),0,0);
    }
    else {
      cVar2 = FUN_1403558e0(plVar6,iVar3,0,0);
      if (cVar2 == '\0') goto LAB_14036f7ec;
      plVar6 = (longlong *)FUN_140087d40();
      (**(code **)(*plVar6 + 0x160))(plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    }
    if (cVar2 != '\0') {
      return;
    }
LAB_14036f7ec:
    lVar11 = *(longlong *)(param_1 + 0x428);
    uVar10 = FUN_1400fda10(lVar5,1,1);
    log_InlineLogERROR("CROSS_OPT_ITEM_DEL fail! Userid[%lu] Itemid[%lu] ItemTypeID[%d]",
                       *(undefined4 *)(lVar11 + 4),*(undefined4 *)(lVar11 + 0x10),
                       uVar10 & 0xffffffff);
    return;
  case 3:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    plVar6 = (longlong *)
             (**(code **)(*plVar6 + 0x98))
                       (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (plVar6 != (longlong *)0x0) {
      plVar9 = (longlong *)FUN_140087d40();
      plVar9 = (longlong *)
               (**(code **)(*plVar9 + 0x60))
                         (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if (plVar9 != (longlong *)0x0) {
        FUN_1400fda10(plVar9,1,1);
        (**(code **)(*plVar9 + 8))(plVar9);
        uVar10 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar12 = (**(code **)(plVar6[2] + 0x18))(plVar6 + 2);
        tq::MyLogSave("gmlog/QuenchItem","%s(%u) Erase Temp Item Statu On Timer[id=%u, type=%u]",
                      uVar12,uVar10 & 0xffffffff);
        FUN_140100090(plVar9,0);
LAB_14036fabd:
        plVar6 = (longlong *)FUN_140087d40();
        (**(code **)(*plVar6 + 0x180))
                  (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
        return;
      }
      pcVar13 = "pItem";
      goto LAB_14036fe04;
    }
    break;
  case 4:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    plVar6 = (longlong *)
             (**(code **)(*plVar6 + 0x98))
                       (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (plVar6 != (longlong *)0x0) {
      plVar9 = (longlong *)FUN_140087d40();
      plVar9 = (longlong *)
               (**(code **)(*plVar9 + 0x60))
                         (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if (plVar9 != (longlong *)0x0) {
        FUN_1400fda10(plVar9,1,1);
        (**(code **)(*plVar9 + 8))(plVar9);
        uVar10 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar12 = (**(code **)(plVar6[2] + 0x18))(plVar6 + 2);
        tq::MyLogSave("gmlog/ForgeItem","%s(%u) Erase Temp Item ForgeAttr On Timer[id=%u, type=%u]",
                      uVar12,uVar10 & 0xffffffff);
        FUN_140100210(plVar9,0);
        goto LAB_14036fabd;
      }
      pcVar13 = "pItem";
      goto LAB_14036fe04;
    }
    break;
  case 5:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    lVar5 = (**(code **)(*plVar6 + 0x98))
                      (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar5 != 0) {
      plVar6 = (longlong *)FUN_140087d40();
      lVar11 = (**(code **)(*plVar6 + 0x60))
                         (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if (lVar11 != 0) {
        uVar4 = FUN_1400fda10(lVar11,1,1);
        cVar2 = FUN_140102710(uVar4);
        if (cVar2 == '\0') {
          return;
        }
        FUN_14034aa60(lVar5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10),
                      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30),0);
        return;
      }
      pcVar13 = "pItem";
      goto LAB_14036fe04;
    }
    break;
  case 6:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    if (*(int *)(puVar1 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->info.idGameServerItem != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    lVar5 = (**(code **)(*plVar6 + 0x98))
                      (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar5 != 0) {
      plVar6 = (longlong *)FUN_140087d40();
      lVar11 = (**(code **)(*plVar6 + 0x60))
                         (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if (lVar11 != 0) {
        FUN_14034ec60(lVar5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30),0,0);
        return;
      }
      pcVar13 = "pItem";
      goto LAB_14036fe04;
    }
    break;
  case 7:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    lVar5 = (**(code **)(*plVar6 + 0x98))
                      (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar5 != 0) {
      FUN_140354ed0(lVar5,0,1);
      return;
    }
    break;
  case 8:
    if (*(int *)(puVar1 + 2) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->m_idGameServerUser != ID_NONE",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                        );
      return;
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar12);
    lVar5 = (**(code **)(*plVar6 + 0x98))
                      (plVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    if (lVar5 != 0) {
      FUN_140354800(lVar5);
      return;
    }
    break;
  default:
    log_InlineLogERROR("CCrossMsgOptItem::Process invalid action[%u]",(ulonglong)*puVar1);
    return;
  }
  pcVar13 = "pUser";
LAB_14036fe04:
  log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",pcVar13,
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgoptitem.cpp"
                    );
  return;
}

// ==== CCrossMsgOptItem::helper_140413a80  @140413a80  [medium:callgraph-r2]  (orig: FUN_140413a80)
undefined1 FUN_140413a80(undefined4 *param_1,undefined4 param_2,undefined4 param_3)

{
  param_1[1] = param_3;
  *param_1 = param_2;
  return 1;
}

// ==== CCrossMsgOptItem::helper_140413d20  @140413d20  [medium:callgraph-r2]  (orig: FUN_140413d20)
void FUN_140413d20(__uint64 param_1)

{
  if ((DAT_140976368 & 1) == 0) {
    DAT_140976368 = DAT_140976368 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976360,"CSuperFlag");
    atexit((_func_5014 *)&LAB_1406d6d70);
  }
                    /* WARNING: Could not recover jumptable at 0x000140413d75. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976360,param_1);
  return;
}

// ==== CCrossMsgOptItem::helper_140416100  @140416100  [medium:callgraph-r2]  (orig: FUN_140416100)
undefined4 * FUN_140416100(undefined4 *param_1)

{
  *param_1 = 0;
  param_1[1] = 0;
  FUN_14007a3c0(param_1 + 2);
  return param_1;
}

