// ==== CMsgMapItem::helper_140166590  @140166590  [medium:callgraph-r1]  (orig: FUN_140166590)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140166590(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  __time32_t _Var7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 uVar10;
  undefined1 auStack_908 [32];
  undefined4 local_8e8;
  undefined4 local_8e0;
  undefined4 local_8d8;
  int local_8d0;
  undefined4 local_8c8;
  undefined4 local_8b8;
  undefined8 local_8b0;
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  cVar1 = FUN_140333220();
  if (cVar1 != '\0') {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_8e8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    lVar8 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (lVar8 != 0) goto LAB_14016666a;
  }
  cVar1 = FUN_140332fe0(param_1,param_2);
  if (cVar1 == '\0') {
    return;
  }
  plVar9 = (longlong *)FUN_140087d40();
  lVar8 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
  if (lVar8 == 0) {
    return;
  }
  uVar2 = FUN_1400fda10(lVar8,1,1);
  cVar1 = FUN_1400ff940(uVar2);
  if (cVar1 == '\0') {
    return;
  }
LAB_14016666a:
  plVar9 = (longlong *)FUN_140100070(lVar8);
  if ((plVar9 == (longlong *)0x0) &&
     (plVar9 = (longlong *)FUN_140100080(lVar8), plVar9 == (longlong *)0x0)) {
    return;
  }
  uVar10 = 3;
  uVar2 = (**(code **)(*plVar9 + 0x30))(plVar9,4);
  uVar3 = (**(code **)(*plVar9 + 0x10))(plVar9);
  uVar4 = (**(code **)(*plVar9 + 0x18))(plVar9);
  local_8b8 = (**(code **)(*plVar9 + 0x30))(plVar9,3);
  iVar6 = 0;
  iVar5 = (**(code **)(*plVar9 + 0x30))(plVar9,7);
  if (0 < iVar5) {
    uVar10 = 0;
    iVar6 = (**(code **)(*plVar9 + 0x30))(plVar9,7);
    _Var7 = _time32((__time32_t *)0x0);
    iVar6 = iVar6 - _Var7;
    if (iVar6 < 1) {
      return;
    }
  }
  FUN_1403b6000(local_478);
  local_8c8 = 0;
  local_8e8 = uVar2;
  local_8e0 = uVar3;
  local_8d8 = uVar4;
  local_8d0 = iVar6;
  iVar5 = FUN_1403b60f0(local_478,param_2,uVar10,local_8b8);
  if (iVar5 != 0) {
    (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_478);
  }
  FUN_14036fe70(local_8a8);
  iVar5 = FUN_1403702e0(local_8a8,param_1);
  if (iVar5 != 0) {
    (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_8a8);
  }
  FUN_14036fec0(local_8a8);
  FUN_1403b6050(local_478);
  return;
}

// ==== CMsgMapItem::helper_14032e780  @14032e780  [medium:callgraph-r3]  (orig: FUN_14032e780)
void FUN_14032e780(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMsgMapItem::helper_14032f040  @14032f040  [medium:callgraph-r1]  (orig: FUN_14032f040)
ulonglong FUN_14032f040(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(0);
  return CONCAT71((int7)((ulonglong)uVar1 * 0x10624dd3 >> 8),
                  uVar1 / 1000 < (uint)(*(int *)(param_1 + 0x90) + *(int *)(param_1 + 0x8c))) &
         0xffffffff;
}

// ==== CMsgMapItem::helper_1403320e0  @1403320e0  [medium:callgraph-r3]  (orig: FUN_1403320e0)
void FUN_1403320e0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x28)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x28);
  return;
}

// ==== CMsgMapItem::helper_140332270  @140332270  [medium:callgraph-r2]  (orig: FUN_140332270)
void * FUN_140332270(void *param_1,void *param_2,void *param_3)

{
  for (; param_1 != param_2; param_1 = (void *)((longlong)param_1 + 0x28)) {
    if (param_3 != (void *)0x0) {
      memcpy(param_3,param_1,0x28);
    }
    param_3 = (void *)((longlong)param_3 + 0x28);
  }
  return param_3;
}

// ==== CMsgMapItem::helper_140332840  @140332840  [medium:callgraph-r2]  (orig: FUN_140332840)
undefined8 FUN_140332840(longlong param_1,ulonglong param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  if (param_2 != 0) {
    if (0x666666666666666 < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_14032e780();
    }
    lVar1 = FUN_1403320e0(param_1 + 0x10);
    *(longlong *)(param_1 + 0x18) = lVar1;
    *(longlong *)(param_1 + 0x20) = lVar1;
    lVar1 = lVar1 + param_2 * 0x28;
    *(longlong *)(param_1 + 0x28) = lVar1;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CMsgMapItem::helper_140332f30  @140332f30  [medium:callgraph-r2]  (orig: FUN_140332f30)
void FUN_140332f30(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_140332270(param_2,param_3,param_4,param_1 + 0x10);
  return;
}

// ==== CMsgMapItem::helper_14033c200  @14033c200  [medium:callgraph-r1]  (orig: FUN_14033c200)
longlong FUN_14033c200(longlong param_1,longlong param_2)

{
  longlong lVar1;
  longlong lVar2;
  void *pvVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  char cVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  undefined1 local_res8;
  
  if (param_1 == param_2) {
    return param_1;
  }
  lVar2 = *(longlong *)(param_2 + 0x18);
  uVar4 = (*(longlong *)(param_2 + 0x20) - lVar2) / 0x28;
  if (uVar4 == 0) {
    FUN_14033a3d0();
  }
  else {
    pvVar3 = *(void **)(param_1 + 0x18);
    uVar5 = (*(longlong *)(param_1 + 0x20) - (longlong)pvVar3) / 0x28;
    if (uVar5 < uVar4) {
      if (pvVar3 == (void *)0x0) {
        uVar8 = 0;
      }
      else {
        uVar8 = (*(longlong *)(param_1 + 0x28) - (longlong)pvVar3) / 0x28;
      }
      if (uVar8 < uVar4) {
        if (pvVar3 != (void *)0x0) {
          operator_delete(pvVar3);
        }
        cVar6 = FUN_140332840(param_1,(*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)
                                      ) / 0x28);
        if (cVar6 != '\0') {
          uVar7 = FUN_140332f30(param_1,*(undefined8 *)(param_2 + 0x18),
                                *(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_1 + 0x18));
          *(undefined8 *)(param_1 + 0x20) = uVar7;
        }
      }
      else {
        lVar1 = lVar2 + uVar5 * 0x28;
        FUN_1403321c0(lVar2,lVar1,pvVar3,local_res8);
        uVar7 = FUN_140332270(lVar1,*(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_1 + 0x20),
                              param_1 + 0x10,local_res8,0);
        *(undefined8 *)(param_1 + 0x20) = uVar7;
      }
    }
    else {
      FUN_1403321c0(lVar2,*(longlong *)(param_2 + 0x20),pvVar3,local_res8);
      *(longlong *)(param_1 + 0x20) =
           *(longlong *)(param_1 + 0x18) +
           ((*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x28) * 0x28;
    }
  }
  return param_1;
}

// ==== CMsgMapItem::helper_14033e490  @14033e490  [medium:callgraph-r1]  (orig: FUN_14033e490)
undefined8 FUN_14033e490(longlong *param_1,longlong *param_2,undefined1 *param_3)

{
  longlong lVar1;
  longlong *plVar2;
  void *pvVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  IStringManager *pIVar13;
  void *pvVar14;
  longlong *plVar15;
  longlong *plVar16;
  longlong *local_e8 [3];
  void *local_d0;
  void *local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined4 local_8c;
  undefined1 local_6c;
  int local_50;
  uint local_48;
  
  local_b8 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else {
    *param_3 = 1;
    plVar10 = (longlong *)CurrentInstanceGet();
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,0x12);
    uVar12 = 0;
    if (plVar10 != (longlong *)0x0) {
      plVar11 = operator_new(8);
      plVar16 = (longlong *)0x0;
      local_e8[0] = plVar16;
      if (plVar11 != (longlong *)0x0) {
        *plVar11 = (longlong)local_e8;
        local_e8[0] = plVar11;
      }
      local_d0 = (void *)0x0;
      local_c8 = (void *)0x0;
      local_c0 = 0;
      FUN_14033a3d0(local_e8);
      FUN_14033c200(local_e8,param_2 + 0x16);
      memcpy(&local_a8,(void *)((longlong)param_2 + 0x1c),100);
      local_a0 = (**(code **)(*param_1 + 8))(param_1);
      local_9c = (**(code **)(*param_1 + 8))(param_1);
      local_8c = 0;
      lVar1 = *plVar10;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      cVar4 = (**(code **)(lVar1 + 0x60))(plVar10,uVar6,uVar5,0x28);
      if (cVar4 == '\0') {
        *param_3 = 0;
        lVar1 = *plVar10;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        cVar4 = (**(code **)(lVar1 + 0x50))(plVar10,uVar6,uVar5,0x28,local_a4,local_48,local_6c);
        if (cVar4 == '\0') {
          if (local_d0 != (void *)0x0) {
            operator_delete(local_d0);
          }
          local_d0 = (void *)0x0;
          local_c8 = (void *)0x0;
          local_c0 = 0;
          operator_delete(local_e8[0]);
          uVar12 = 0;
        }
        else {
          if (local_50 != 0) {
            iVar7 = FUN_14037c270(param_2);
            local_50 = 1;
            if (iVar7 != 0) {
              local_50 = iVar7;
            }
          }
          uVar12 = FUN_140008520((int)param_1[0x246]);
          plVar11 = (longlong *)FUN_1400876b0(uVar12);
          plVar11 = (longlong *)(**(code **)(*plVar11 + 0x50))(plVar11);
          lVar1 = *plVar11;
          uVar5 = (**(code **)(*param_2 + 8))(param_2);
          (**(code **)(lVar1 + 0x28))(plVar11,uVar5);
          plVar11 = (longlong *)FUN_140087d40();
          lVar1 = *plVar11;
          uVar5 = FUN_140167b40(param_1);
          plVar11 = (longlong *)
                    (**(code **)(lVar1 + 0x20))
                              (plVar11,&local_a8,1,local_a8,uVar5,local_48 & 0xffffff00);
          pvVar14 = local_d0;
          if (plVar11 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            pIVar13 = theInstance();
            lVar1 = param_1[2];
            uVar12 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_FAILED_GENERATE_ITEM");
            (**(code **)(lVar1 + 0x358))(param_1 + 2,uVar12);
            if (local_d0 != (void *)0x0) {
              operator_delete(local_d0);
            }
            local_d0 = (void *)0x0;
            local_c8 = (void *)0x0;
            local_c0 = 0;
            operator_delete(local_e8[0]);
            uVar12 = 1;
          }
          else {
            lVar1 = (longlong)local_c8 - (longlong)local_d0 >> 0x3f;
            if (((longlong)local_c8 - (longlong)local_d0) / 0x28 + lVar1 != lVar1) {
              plVar2 = local_e8[0];
              if (local_c8 < local_d0) {
                _invalid_parameter_noinfo();
                plVar2 = local_e8[0];
              }
              while( true ) {
                pvVar3 = local_c8;
                if (local_c8 < local_d0) {
                  _invalid_parameter_noinfo();
                }
                if ((plVar2 == (longlong *)0x0) || (plVar2 != local_e8[0])) {
                  _invalid_parameter_noinfo();
                }
                if (pvVar14 == pvVar3) break;
                if (plVar2 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar15 = plVar16;
                }
                else {
                  plVar15 = (longlong *)*plVar2;
                }
                if ((void *)plVar15[4] <= pvVar14) {
                  _invalid_parameter_noinfo();
                }
                FUN_140102a10(plVar11,pvVar14,0,0);
                if (plVar2 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar15 = plVar16;
                }
                else {
                  plVar15 = (longlong *)*plVar2;
                }
                if ((void *)plVar15[4] <= pvVar14) {
                  _invalid_parameter_noinfo();
                }
                pvVar14 = (void *)((longlong)pvVar14 + 0x28);
              }
            }
            uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
            iVar7 = FUN_1400fda10(plVar11,1,1);
            if (iVar7 == 0x2dcead) {
              FUN_14032daf0(param_1,plVar11);
            }
            lVar1 = *plVar10;
            uVar6 = (**(code **)(*plVar11 + 8))(plVar11);
            uVar8 = (**(code **)(*param_1 + 8))(param_1);
            uVar9 = (**(code **)(*param_1 + 8))(param_1);
            cVar4 = (**(code **)(lVar1 + 0x28))(plVar10,uVar9,uVar8,0x28,uVar6,1);
            if (cVar4 == '\0') {
              plVar10 = (longlong *)FUN_140087d40();
              plVar10 = (longlong *)(**(code **)(*plVar10 + 0x60))(plVar10,uVar5);
              if (plVar10 == (longlong *)0x0) {
                if (local_d0 != (void *)0x0) {
                  operator_delete(local_d0);
                }
                local_d0 = (void *)0x0;
                local_c8 = (void *)0x0;
                local_c0 = 0;
                operator_delete(local_e8[0]);
                uVar12 = 1;
              }
              else {
                cVar4 = FUN_14016c970(plVar10);
                if (cVar4 != '\0') {
                  uVar6 = FUN_1400fda10(plVar10,1,1);
                  (**(code **)(*plVar10 + 8))(plVar10);
                  (**(code **)(*param_1 + 8))(param_1);
                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                  log_InlineLogERROR(
                                    "User:%s[%u] PickMapItem checkin chestpackage fail Item[id=%u, type=%u]"
                                    );
                }
                plVar11 = (longlong *)FUN_140087d40();
                lVar1 = *plVar11;
                uVar5 = (**(code **)(*plVar10 + 8))(plVar10);
                (**(code **)(lVar1 + 0x30))(plVar11,uVar5,1,0,uVar6);
                if (local_d0 != (void *)0x0) {
                  operator_delete(local_d0);
                }
                local_d0 = (void *)0x0;
                local_c8 = (void *)0x0;
                local_c0 = 0;
                operator_delete(local_e8[0]);
                uVar12 = 1;
              }
            }
            else {
              lVar1 = *plVar10;
              uVar5 = (**(code **)(*param_1 + 8))(param_1);
              uVar6 = (**(code **)(*param_1 + 8))(param_1);
              cVar4 = (**(code **)(lVar1 + 0x60))(plVar10,uVar6,uVar5,0x28);
              if (cVar4 != '\0') {
                *param_3 = 1;
              }
              if (local_d0 != (void *)0x0) {
                operator_delete(local_d0);
              }
              local_d0 = (void *)0x0;
              local_c8 = (void *)0x0;
              local_c0 = 0;
              operator_delete(local_e8[0]);
              uVar12 = 1;
            }
          }
        }
      }
      else {
        if (local_d0 != (void *)0x0) {
          operator_delete(local_d0);
        }
        local_d0 = (void *)0x0;
        local_c8 = (void *)0x0;
        local_c0 = 0;
        operator_delete(local_e8[0]);
        uVar12 = 0;
      }
    }
  }
  return uVar12;
}

// ==== CMsgMapItem::helper_140343c00  @140343c00  [medium:callgraph-r0]  (orig: FUN_140343c00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140343c00(longlong *param_1,undefined4 param_2,char param_3,char param_4)

{
  void *pvVar1;
  char cVar2;
  char cVar3;
  undefined2 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  longlong lVar13;
  longlong *plVar14;
  undefined8 uVar15;
  IStringManager *pIVar16;
  longlong *plVar17;
  longlong *plVar18;
  char *_Format;
  undefined8 uVar19;
  void *pvVar20;
  longlong *plVar21;
  undefined1 auStack_e38 [32];
  char *local_e18;
  ulonglong local_e10;
  char *local_e08;
  undefined4 local_e00;
  undefined4 local_df8;
  undefined4 local_df0;
  undefined1 local_de8;
  char local_dd8;
  char local_dd7 [7];
  longlong *local_dd0 [3];
  void *local_db8;
  void *local_db0;
  undefined8 local_da8;
  longlong *local_da0;
  undefined4 local_d98;
  undefined4 local_d94;
  int local_d90;
  longlong *local_d88;
  undefined4 local_d78;
  undefined4 local_d74;
  undefined4 local_d70;
  undefined4 local_d6c;
  undefined4 local_d5c;
  byte local_d3c;
  undefined4 local_d24;
  int local_d20;
  int local_d18;
  undefined8 local_d08;
  char local_cf8;
  undefined1 local_cf7 [1071];
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_d08 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_e38;
  local_da0 = (longlong *)CONCAT44(local_da0._4_4_,param_2);
  cVar2 = FUN_140168a10();
  if ((cVar2 == '\0') && (param_3 != '\0')) {
    return 0;
  }
  lVar13 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar13 + 0x98) == 0) {
    local_e18 = (char *)CONCAT44(local_e18._4_4_,0x131);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar14 = (longlong *)
            (**(code **)(**(longlong **)(lVar13 + 0x98) + 0x48))
                      (*(longlong **)(lVar13 + 0x98),param_2);
  if (plVar14 == (longlong *)0x0) {
    return 0;
  }
  cVar2 = FUN_140167b70(param_1);
  if (cVar2 != '\0') {
    if ((param_3 != '\0') || (lVar13 = (**(code **)(param_1[2] + 0x160))(param_1 + 2), lVar13 == 0))
    {
      return 0;
    }
    uVar15 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    cVar2 = FUN_1400f8890(uVar15);
    if (cVar2 == '\0') {
      return 0;
    }
    lVar13 = plVar14[4];
    uVar15 = FUN_140087e80();
    cVar2 = FUN_1401d28f0(uVar15,(int)lVar13);
    if (cVar2 == '\0') {
      return 0;
    }
  }
  FUN_140008520((int)param_1[0x246]);
  cVar2 = FUN_14008abf0();
  if (cVar2 == '\0') {
    iVar5 = 0;
  }
  else if (((param_4 == '\0') || (*(uint *)(plVar14 + 4) < 0x10a1d0)) ||
          (0x10a5cc < *(uint *)(plVar14 + 4))) {
    iVar5 = 0x12;
  }
  else {
    uVar15 = FUN_140008520((int)param_1[0x246]);
    iVar5 = FUN_14008b410(uVar15);
  }
  lVar13 = param_1[2];
  uVar15 = (**(code **)(*plVar14 + 0x20))(plVar14);
  iVar6 = (**(code **)(lVar13 + 0x150))(param_1 + 2,uVar15);
  if (iVar5 < iVar6) {
    pIVar16 = theInstance();
    lVar13 = param_1[2];
    uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_FAR_CANNOT_PICK");
    (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15);
    return 0;
  }
  iVar5 = (int)plVar14[5];
  local_d90 = iVar5;
  uVar15 = FUN_140008520((int)param_1[0x246]);
  plVar17 = (longlong *)FUN_140087650(uVar15);
  plVar17 = (longlong *)(**(code **)(*plVar17 + 0x98))(plVar17,iVar5);
  cVar2 = FUN_14032f040(plVar14);
  if (((cVar2 != '\0') && (iVar6 = (**(code **)(*param_1 + 8))(param_1), iVar5 != iVar6)) &&
     ((plVar17 == (longlong *)0x0 || (cVar2 = FUN_140164460(param_1,plVar17), cVar2 == '\0')))) {
    plVar18 = (longlong *)FUN_140118320();
    if (plVar18 == (longlong *)0x0) {
LAB_140343eb2:
      pIVar16 = theInstance();
      lVar13 = param_1[2];
      uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_OTHERS_ITEM");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15);
      return 0;
    }
    lVar13 = *plVar18;
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    iVar6 = (**(code **)(lVar13 + 0x28))(plVar18,uVar7);
    if (((iVar6 == 0) ||
        (cVar2 = (**(code **)(*plVar18 + 0x58))(plVar18,iVar6,iVar5), cVar2 == '\0')) ||
       ((((*(uint *)(plVar14 + 4) < 0x10a1d0 ||
          ((0x10a5cc < *(uint *)(plVar14 + 4) ||
           (cVar2 = (**(code **)(*plVar18 + 0x68))(plVar18,iVar6), cVar2 != '\0')))) &&
         (((0x10a1cf < *(uint *)(plVar14 + 4) && (*(uint *)(plVar14 + 4) < 0x10a5cd)) ||
          (cVar2 = (**(code **)(*plVar18 + 0x70))(plVar18,iVar6), cVar2 != '\0')))) ||
        (((int)plVar14[4] == 0x109a00 || ((int)plVar14[4] == 0x109a01)))))) goto LAB_140343eb2;
  }
  if ((0x10a1cf < *(uint *)(plVar14 + 4)) && (*(uint *)(plVar14 + 4) < 0x10a5cd)) {
    iVar6 = *(int *)((longlong)plVar14 + 0x2c);
    uVar7 = (**(code **)(plVar14[2] + 0x20))(plVar14 + 2);
    local_d88 = (longlong *)CONCAT44(local_d88._4_4_,uVar7);
    local_d94 = (**(code **)(plVar14[2] + 0x28))(plVar14 + 2);
    local_d98 = (undefined4)plVar14[4];
    uVar15 = FUN_140008520((int)param_1[0x246]);
    plVar18 = (longlong *)FUN_1400876b0(uVar15);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x50))(plVar18);
    lVar13 = *plVar18;
    uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
    (**(code **)(lVar13 + 0x28))(plVar18,uVar7);
    uVar8 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
    if ((uVar8 < 0x46) &&
       (((iVar9 = (**(code **)(*param_1 + 8))(param_1), iVar9 != iVar5 &&
         (plVar17 != (longlong *)0x0)) &&
        (uVar8 = (**(code **)(plVar17[2] + 0x70))(plVar17 + 2), 0x45 < uVar8)))) {
      iVar5 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
      uVar8 = (**(code **)(plVar17[2] + 0x70))(plVar17 + 2);
      if (((iVar5 + 0x14U <= uVar8) && (iVar5 = (iVar6 * 0x14) / 100, 0 < iVar5)) &&
         (plVar14 = (longlong *)FUN_140118320(), plVar14 != (longlong *)0x0)) {
        lVar13 = *plVar14;
        uVar7 = (**(code **)(*param_1 + 8))(param_1);
        iVar9 = (**(code **)(lVar13 + 0x28))(plVar14,uVar7);
        if ((iVar9 != 0) &&
           (cVar2 = (**(code **)(*plVar14 + 0x58))(plVar14,iVar9,local_d90), cVar2 != '\0')) {
          (**(code **)(*plVar17 + 0x180))(plVar17,(longlong)iVar5,1);
          FUN_1403f2e40(&local_cf8);
          iVar10 = FUN_1403f2ec0(&local_cf8,0,iVar5,0);
          if (iVar10 == 0) {
            local_e18 = (char *)CONCAT44(local_e18._4_4_,0x14af);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            (**(code **)(plVar17[2] + 0x350))(plVar17 + 2);
          }
          FUN_1403f2e90(&local_cf8);
          uVar15 = FUN_140008520((int)param_1[0x246]);
          cVar2 = FUN_14008abf0(uVar15);
          if (cVar2 == '\0') {
            local_cf8 = cVar2;
            memset(local_cf7,0,0x3ff);
            pIVar16 = theInstance();
            _Format = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_AWARD_TEAM_MONEY");
            _snprintf(&local_cf8,0x3ff,_Format);
            FUN_14015b240();
            local_de8 = 1;
            local_df0 = 0;
            local_df8 = 0;
            local_e00 = (uint)local_e00._2_2_ << 0x10;
            local_e08 = (char *)CONCAT62(local_e08._2_6_,0x7d5);
            local_e10 = CONCAT44(local_e10._4_4_,0xffffff);
            local_e18 = (char *)0x0;
            iVar10 = FUN_14015b300(local_8c8,"SYSTEM","ALLUSERS",&local_cf8);
            if (iVar10 == 0) {
              local_e18 = (char *)CONCAT44(local_e18._4_4_,0x14bc);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              (**(code **)(*plVar14 + 0x90))(plVar14,iVar9,local_8c8,0);
            }
            FUN_14015b2c0(local_8c8);
          }
          iVar6 = iVar6 - iVar5;
        }
      }
    }
    (**(code **)(*param_1 + 0x180))(param_1,(longlong)iVar6,1);
    FUN_1403f2e40(&local_cf8);
    iVar5 = FUN_1403f2ec0(&local_cf8,0,iVar6,0);
    if (iVar5 == 0) {
      local_e18 = (char *)CONCAT44(local_e18._4_4_,0x14cd);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_cf8);
    }
    FUN_1403f2e90(&local_cf8);
    if (999 < iVar6) {
      FUN_140362560(local_8c8);
      uVar4 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
      uVar7 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      uVar11 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      uVar12 = (**(code **)(*param_1 + 8))(param_1);
      local_e00 = 0;
      local_e08 = (char *)CONCAT44(local_e08._4_4_,iVar6);
      local_e10 = CONCAT62(local_e10._2_6_,0x79);
      local_e18 = (char *)CONCAT62(local_e18._2_6_,uVar4);
      iVar5 = FUN_140362620(local_8c8,uVar12,uVar11,uVar7);
      if (iVar5 == 0) {
        local_e18 = (char *)CONCAT44(local_e18._4_4_,0x14d4);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_8c8);
      }
      FUN_1403625e0(local_8c8);
    }
    uVar15 = FUN_140008520((int)param_1[0x246]);
    cVar2 = FUN_14008abf0(uVar15);
    if (cVar2 == '\0') {
      pIVar16 = theInstance();
      lVar13 = param_1[2];
      uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_PICK_MONEY");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15,iVar6);
    }
    FUN_1403a5840(local_478);
    local_e08 = (char *)CONCAT44(local_e08._4_4_,local_d98);
    local_e10 = CONCAT44(local_e10._4_4_,iVar6);
    local_e18 = (char *)CONCAT44(local_e18._4_4_,0xe);
    iVar5 = FUN_1403a5ce0(local_478,(ulonglong)local_da0 & 0xffffffff,
                          (ulonglong)local_d88 & 0xffffffff,local_d94);
    if (iVar5 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
    }
    if (99999 < iVar6) {
      (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      local_e18 = (char *)CONCAT44(local_e18._4_4_,iVar6);
      tq::MyLogSave("gmlog/pick_item","%s(%u) pick up money: %d");
    }
    FUN_1403a5890(local_478);
    goto LAB_140344d85;
  }
  uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
  memcpy(&local_d78,(void *)((longlong)plVar14 + 0x1c),100);
  local_da0 = (longlong *)CONCAT44(local_da0._4_4_,0xc0df1);
  lVar13 = 0;
  do {
    if (*(int *)((longlong)&local_da0 + lVar13 * 4) == (int)plVar14[4]) {
      cVar2 = '\x01';
      local_dd8 = '\x01';
      goto LAB_140344495;
    }
    lVar13 = lVar13 + 1;
  } while (lVar13 < 1);
  cVar2 = '\0';
  local_dd8 = '\0';
LAB_140344495:
  if (param_3 != '\0') {
    plVar17 = (longlong *)CurrentInstanceGet();
    plVar17 = (longlong *)(**(code **)(*plVar17 + 0x20))(plVar17,0x12);
    if (plVar17 != (longlong *)0x0) {
      plVar18 = (longlong *)FUN_140087d40();
      lVar13 = (**(code **)(*plVar18 + 0x70))(plVar18,(int)plVar14[4]);
      if (lVar13 == 0) {
        return 0;
      }
      plVar18 = (longlong *)
                (**(code **)(**(longlong **)(lVar13 + 8) + 0x10))(*(longlong **)(lVar13 + 8),10);
      uVar11 = (**(code **)(*plVar18 + 0x48))(plVar18);
      cVar3 = (**(code **)(*plVar17 + 0x48))(plVar17,(int)plVar14[4],uVar11,local_d24);
      if (cVar3 == '\0') goto LAB_1403445ba;
    }
    if (cVar2 == '\0') {
      local_dd7[0] = cVar2;
      cVar2 = FUN_14033e490(param_1,plVar14,local_dd7);
      if (local_dd7[0] != '\0') {
        FUN_1403b75b0(local_8c8);
        cVar3 = FUN_1403b76a0(local_8c8,4,0);
        if (cVar3 == '\0') {
          local_e18 = (char *)CONCAT44(local_e18._4_4_,0x150e);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_8c8);
        }
        FUN_1403b7630(local_8c8);
      }
      if (cVar2 != '\0') goto LAB_140344d85;
    }
  }
LAB_1403445ba:
  uVar15 = FUN_140008520((int)param_1[0x246]);
  plVar17 = (longlong *)FUN_1400876b0(uVar15);
  lVar13 = (**(code **)(*plVar17 + 0x48))(plVar17,uVar7);
  if (lVar13 == 0) {
    return 0;
  }
  local_d70 = (**(code **)(*param_1 + 8))(param_1);
  local_d6c = (**(code **)(*param_1 + 8))(param_1);
  plVar17 = (longlong *)0x0;
  local_d5c = 0;
  local_da0 = operator_new(8);
  local_dd0[0] = plVar17;
  if (local_da0 != (longlong *)0x0) {
    *local_da0 = (longlong)local_dd0;
    local_dd0[0] = local_da0;
  }
  local_db8 = (void *)0x0;
  local_db0 = (void *)0x0;
  local_da8 = 0;
  local_d88 = local_da0;
  FUN_14033a3d0(local_dd0);
  FUN_14033c200(local_dd0,plVar14 + 0x16);
  if (local_d18 < 1) {
    local_e10 = CONCAT44(local_e10._4_4_,0x1525);
    local_e18 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp";
    log_InlineLogERROR("CUser::PickMapItem. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d");
  }
  cVar2 = FUN_140102780(local_d74);
  if (cVar2 == '\0') {
    if (0x27 < (ulonglong)(param_1[0x185] - param_1[0x184] >> 2)) {
      pIVar16 = theInstance();
      lVar13 = param_1[2];
      uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_FULL_CANNOT_PICK");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15);
      if (local_db8 != (void *)0x0) {
        operator_delete(local_db8);
      }
      local_db8 = (void *)0x0;
      local_db0 = (void *)0x0;
      local_da8 = 0;
      operator_delete(local_dd0[0]);
      return 0;
    }
  }
  else {
    iVar5 = FUN_140339ba0(param_1,local_d74,local_d18,local_d3c);
    if ((0 < iVar5) &&
       (0x28 < (ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar5))) {
      pIVar16 = theInstance();
      lVar13 = param_1[2];
      uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_FULL_CANNOT_PICK");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15);
      if (local_db8 != (void *)0x0) {
        operator_delete(local_db8);
      }
      local_db8 = (void *)0x0;
      local_db0 = (void *)0x0;
      local_da8 = 0;
      operator_delete(local_dd0[0]);
      return 0;
    }
  }
  if (local_d20 != 0) {
    iVar5 = FUN_14037c270(plVar14);
    local_d20 = 1;
    if (iVar5 != 0) {
      local_d20 = iVar5;
    }
  }
  FUN_1403a5840(&local_cf8);
  lVar13 = plVar14[4];
  uVar7 = (**(code **)(plVar14[2] + 0x28))(plVar14 + 2);
  uVar11 = (**(code **)(plVar14[2] + 0x20))(plVar14 + 2);
  uVar12 = (**(code **)(*plVar14 + 8))(plVar14);
  local_e08 = (char *)CONCAT44(local_e08._4_4_,(int)lVar13);
  local_e10 = local_e10 & 0xffffffff00000000;
  local_e18 = (char *)CONCAT44(local_e18._4_4_,0xf);
  iVar5 = FUN_1403a5ce0(&local_cf8,uVar12,uVar11,uVar7);
  if (iVar5 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_cf8);
  }
  uVar15 = FUN_140008520((int)param_1[0x246]);
  plVar18 = (longlong *)FUN_1400876b0(uVar15);
  plVar18 = (longlong *)(**(code **)(*plVar18 + 0x50))(plVar18);
  lVar13 = *plVar18;
  uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
  (**(code **)(lVar13 + 0x28))(plVar18,uVar7);
  cVar2 = FUN_140102780(local_d74);
  if (cVar2 == '\0') {
    plVar14 = (longlong *)FUN_140087d40();
    lVar13 = *plVar14;
    uVar7 = FUN_140167b40(param_1);
    local_e10 = local_e10 & 0xffffffffffffff00;
    local_e18 = (char *)CONCAT44(local_e18._4_4_,uVar7);
    plVar14 = (longlong *)(**(code **)(lVar13 + 0x20))(plVar14,&local_d78,1,local_d78);
    if (plVar14 == (longlong *)0x0) {
      FUN_140167b40(param_1);
      (**(code **)(*param_1 + 8))(param_1);
      local_e00 = 0x155d;
      local_e08 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user_item.cpp";
      local_e10 = CONCAT44(local_e10._4_4_,(uint)local_d3c);
      local_e18 = (char *)CONCAT44(local_e18._4_4_,local_d74);
      log_InlineLogERROR(
                        "CUser::PickMapItem. UserID[%lu] ServerID[%lu] Item[%lu] Type[%lu] Monopoly[%d] at %s, %d"
                        );
      pIVar16 = theInstance();
      lVar13 = param_1[2];
      uVar15 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_FAILED_GENERATE_ITEM");
      (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar15);
      FUN_1403a5890(&local_cf8);
      if (local_db8 != (void *)0x0) {
        operator_delete(local_db8);
      }
      local_db8 = (void *)0x0;
      local_db0 = (void *)0x0;
      local_da8 = 0;
      operator_delete(local_dd0[0]);
      return 0;
    }
    uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
    FUN_140340de0(param_1,uVar7,1);
  }
  else {
    if (local_d18 < 1) {
      FUN_1403a5890(&local_cf8);
      if (local_db8 != (void *)0x0) {
        operator_delete(local_db8);
      }
      local_db8 = (void *)0x0;
      local_db0 = (void *)0x0;
      local_da8 = 0;
      operator_delete(local_dd0[0]);
      return 0;
    }
    local_e08 = (char *)((ulonglong)local_e08 & 0xffffffff00000000);
    local_e10 = CONCAT71(local_e10._1_7_,1);
    local_e18 = (char *)CONCAT71(local_e18._1_7_,1);
    uVar7 = FUN_14033f6b0(param_1,local_d74,local_d18,local_d3c);
    plVar14 = (longlong *)FUN_140087d40();
    plVar14 = (longlong *)(**(code **)(*plVar14 + 0x60))(plVar14,uVar7);
    if (plVar14 == (longlong *)0x0) {
      local_e18 = (char *)CONCAT44(local_e18._4_4_,0x1553);
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_1403a5890(&local_cf8);
      if (local_db8 != (void *)0x0) {
        operator_delete(local_db8);
      }
      local_db8 = (void *)0x0;
      local_db0 = (void *)0x0;
      local_da8 = 0;
      operator_delete(local_dd0[0]);
      return 0;
    }
  }
  pvVar20 = local_db8;
  lVar13 = (longlong)local_db0 - (longlong)local_db8 >> 0x3f;
  if (((longlong)local_db0 - (longlong)local_db8) / 0x28 + lVar13 != lVar13) {
    plVar18 = local_dd0[0];
    if (local_db0 < local_db8) {
      _invalid_parameter_noinfo();
      plVar18 = local_dd0[0];
    }
    while( true ) {
      pvVar1 = local_db0;
      if (local_db0 < local_db8) {
        _invalid_parameter_noinfo();
      }
      if ((plVar18 == (longlong *)0x0) || (plVar18 != local_dd0[0])) {
        _invalid_parameter_noinfo();
      }
      if (pvVar20 == pvVar1) break;
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar17;
      }
      else {
        plVar21 = (longlong *)*plVar18;
      }
      if ((void *)plVar21[4] <= pvVar20) {
        _invalid_parameter_noinfo();
      }
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      *(undefined4 *)((longlong)pvVar20 + 8) = uVar7;
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar17;
      }
      else {
        plVar21 = (longlong *)*plVar18;
      }
      if ((void *)plVar21[4] <= pvVar20) {
        _invalid_parameter_noinfo();
      }
      FUN_140102a10(plVar14,pvVar20,0,0);
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar17;
      }
      else {
        plVar21 = (longlong *)*plVar18;
      }
      if ((void *)plVar21[4] <= pvVar20) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)((longlong)pvVar20 + 0x14) < 1) {
        uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
        FUN_140334e70(param_1,uVar7,0);
      }
      else {
        if (plVar18 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar21 = plVar17;
        }
        else {
          plVar21 = (longlong *)*plVar18;
        }
        if ((void *)plVar21[4] <= pvVar20) {
          _invalid_parameter_noinfo();
        }
        uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
        FUN_140166590(param_1,uVar7,*(undefined4 *)((longlong)pvVar20 + 0xc));
      }
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar17;
      }
      else {
        plVar21 = (longlong *)*plVar18;
      }
      if ((void *)plVar21[4] <= pvVar20) {
        _invalid_parameter_noinfo();
      }
      pvVar20 = (void *)((longlong)pvVar20 + 0x28);
    }
  }
  uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
  local_e18 = (char *)((ulonglong)local_e18 & 0xffffffffffffff00);
  FUN_14032bb40(param_1,uVar7,1,local_d18);
  pIVar16 = theInstance();
  lVar13 = param_1[2];
  uVar15 = FUN_140100430(plVar14,0x65);
  uVar19 = (*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_GOT_ITEM");
  (**(code **)(lVar13 + 0x358))(param_1 + 2,uVar19,uVar15);
  if (local_dd8 != '\0') {
    uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
    uVar15 = FUN_140008520((int)param_1[0x246]);
    uVar15 = FUN_140087730(uVar15);
    local_e10 = 0;
    local_e18 = (char *)CONCAT44(local_e18._4_4_,uVar7);
    FUN_140145f60(uVar15,0x4c4b402,param_1,param_1 + 2);
  }
  iVar5 = FUN_1400fda10(plVar14,1,1);
  if (iVar5 == 0x2dcead) {
    FUN_14032daf0(param_1,plVar14);
  }
  FUN_1403a5890(&local_cf8);
  if (local_db8 != (void *)0x0) {
    operator_delete(local_db8);
  }
  local_db8 = (void *)0x0;
  local_db0 = (void *)0x0;
  local_da8 = 0;
  operator_delete(local_dd0[0]);
LAB_140344d85:
  uVar15 = FUN_140008520((int)param_1[0x246]);
  cVar2 = FUN_14008abf0(uVar15);
  if (cVar2 == '\0') {
    FUN_1403a5840(local_478);
    uVar7 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
    uVar11 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
    uVar12 = (**(code **)(*param_1 + 8))(param_1);
    local_e08 = (char *)((ulonglong)local_e08 & 0xffffffff00000000);
    local_e10 = local_e10 & 0xffffffff00000000;
    local_e18._0_4_ = 3;
    iVar5 = FUN_1403a5ce0(local_478,uVar12,uVar11,uVar7);
    if (iVar5 == 0) {
      local_e18._0_4_ = 0x158d;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_478,0);
    }
    FUN_1403a5890(local_478);
  }
  return 1;
}

// ==== CMsgMapItem::helper_14037c270  @14037c270  [medium:callgraph-r1]  (orig: FUN_14037c270)
int FUN_14037c270(longlong param_1)

{
  longlong lVar1;
  __time32_t _Var2;
  longlong lVar3;
  longlong lVar4;
  int iVar5;
  __time32_t local_res8 [2];
  tm local_38;
  
  lVar1 = *(longlong *)(param_1 + 0xa8);
  iVar5 = 0;
  local_res8[0] = 0;
  _time32(local_res8);
  if (lVar1 == 0) {
    return 0;
  }
  local_38.tm_wday = 0;
  local_38.tm_yday = 0;
  local_38.tm_isdst = 0;
  local_38.tm_year = (int)(lVar1 / 10000000000) + 100;
  lVar4 = lVar1 / 100000000;
  lVar3 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar4),8) + lVar4;
  local_38.tm_mon = (int)lVar4 + ((int)(lVar3 >> 6) - (int)(lVar3 >> 0x3f)) * -100 + -1;
  lVar4 = lVar1 / 1000000;
  lVar3 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar4),8) + lVar4;
  local_38.tm_mday = (int)lVar4 + ((int)(lVar3 >> 6) - (int)(lVar3 >> 0x3f)) * -100;
  lVar4 = lVar1 / 10000;
  lVar3 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar4),8) + lVar4;
  local_38.tm_hour = (int)lVar4 + ((int)(lVar3 >> 6) - (int)(lVar3 >> 0x3f)) * -100;
  lVar4 = lVar1 + SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar1),8);
  lVar3 = (lVar4 >> 6) - (lVar4 >> 0x3f);
  lVar4 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(lVar3),8) + lVar3;
  local_38.tm_sec = (int)lVar1 + (int)lVar3 * -100;
  local_38.tm_min = (int)lVar3 + ((int)(lVar4 >> 6) - (int)(lVar4 >> 0x3f)) * -100;
  _Var2 = _mktime32(&local_38);
  if (local_res8[0] < _Var2) {
    _Var2 = _mktime32(&local_38);
    iVar5 = _Var2 - local_res8[0];
  }
  return iVar5;
}

// ==== CMsgMapItem::ctor_or_dtor  @1403a5840  [high:vtable-assign]  (orig: FUN_1403a5840)
undefined8 * FUN_1403a5840(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMapItem::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMapItem::ctor_or_dtor  @1403a5890  [high:vtable-assign]  (orig: FUN_1403a5890)
void FUN_1403a5890(undefined8 *param_1)

{
  *param_1 = CMsgMapItem::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMapItem::vfunc_1  @1403a58c0  [high:rtti-vtable]  (orig: FUN_1403a58c0)
ulonglong FUN_1403a58c0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x44d);
}

// ==== CMsgMapItem::ctor_or_dtor  @1403a5d90  [high:vtable-assign]  (orig: FUN_1403a5d90)
undefined8 * FUN_1403a5d90(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMapItem::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMapItem::vfunc_3  @1403a5f70  [high:rtti-vtable]  (orig: FUN_1403a5f70)
void FUN_1403a5f70(longlong param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar7 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x88))(*(longlong **)(lVar7 + 0x90),param_1)
  ;
  if (plVar8 != (longlong *)0x0) {
    cVar3 = FUN_140167b70(plVar8);
    if ((cVar3 != '\0') && (lVar7 = (**(code **)(plVar8[2] + 0x160))(plVar8 + 2), lVar7 != 0)) {
      lVar7 = (**(code **)(plVar8[2] + 0x160))(plVar8 + 2);
      plVar9 = *(longlong **)(*(longlong *)(lVar7 + 0x58) + 8);
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
      uVar10 = (**(code **)(*plVar9 + 0x58))(plVar9);
      if ((uVar10 >> 0x1f & 1) == 0) {
        return;
      }
    }
    plVar9 = (longlong *)FUN_1400e1e60();
    lVar2 = plVar8[0x1e2];
    lVar7 = *plVar9;
    puVar1 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
    (**(code **)(lVar7 + 0x108))(plVar9,uVar4,(int)lVar2,*puVar1);
    cVar3 = (**(code **)(plVar8[2] + 0x220))(plVar8 + 2);
    if (cVar3 == '\0') {
      pIVar11 = theInstance();
      lVar7 = plVar8[2];
      uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x0001403a60c9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(lVar7 + 0x358))(plVar8 + 2,uVar12);
      return;
    }
    if (*(char *)(*(longlong *)(param_1 + 0x428) + 0x12) == '\x03') {
      cVar3 = FUN_140168a10(plVar8);
      if (cVar3 == '\0') {
        if (*(char *)(*(longlong *)(param_1 + 0x428) + 0x17) != '\0') {
          return;
        }
      }
      else {
        uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar5 = FUN_14008b000(uVar12);
        uVar6 = FUN_1401649c0(plVar8);
        if (uVar6 < uVar5) {
          return;
        }
      }
      cVar3 = FUN_140160530(plVar8,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc),
                            *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe),0);
      if (cVar3 != '\0') {
        lVar7 = *(longlong *)(param_1 + 0x428);
        FUN_140343c00(plVar8,*(undefined4 *)(lVar7 + 4),*(char *)(lVar7 + 0x17) != '\0',
                      *(undefined1 *)(lVar7 + 8));
        return;
      }
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar9 = (longlong *)FUN_140087650(uVar12);
      (**(code **)(*plVar9 + 0x50))(plVar9,plVar8,"ITEM_PICK SynPosition");
    }
  }
  return;
}

