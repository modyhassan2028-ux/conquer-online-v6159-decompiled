// ==== CMsgCallPetInfo::ctor_or_dtor  @140454650  [high:vtable-assign]  (orig: FUN_140454650)
undefined8 * FUN_140454650(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCallPetInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgCallPetInfo::ctor_or_dtor  @1404546a0  [high:vtable-assign]  (orig: FUN_1404546a0)
void FUN_1404546a0(undefined8 *param_1)

{
  *param_1 = CMsgCallPetInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgCallPetInfo::vfunc_1  @1404547e0  [high:rtti-vtable]  (orig: FUN_1404547e0)
undefined8 FUN_1404547e0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgCallPetInfo::vfunc_3  @140454810  [high:rtti-vtable]  (orig: FUN_140454810)
void FUN_140454810(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgCallPetInfo::ctor_or_dtor  @140454850  [high:vtable-assign]  (orig: FUN_140454850)
undefined8 * FUN_140454850(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCallPetInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

