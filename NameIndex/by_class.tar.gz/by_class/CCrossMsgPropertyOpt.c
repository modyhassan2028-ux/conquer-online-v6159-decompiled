// ==== CCrossMsgPropertyOpt::ctor_or_dtor  @140460630  [high:vtable-assign]  (orig: FUN_140460630)
undefined8 * FUN_140460630(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgPropertyOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgPropertyOpt::ctor_or_dtor  @140460680  [high:vtable-assign]  (orig: FUN_140460680)
void FUN_140460680(undefined8 *param_1)

{
  *param_1 = CCrossMsgPropertyOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgPropertyOpt::vfunc_1  @1404606b0  [high:rtti-vtable]  (orig: FUN_1404606b0)
ulonglong FUN_1404606b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c6c);
}

// ==== CCrossMsgPropertyOpt::ctor_or_dtor  @140460720  [high:vtable-assign]  (orig: FUN_140460720)
undefined8 * FUN_140460720(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgPropertyOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgPropertyOpt::ctor_or_dtor  @140460770  [high:vtable-assign]  (orig: FUN_140460770)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140460770(longlong *param_1)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined1 auStack_4d8 [32];
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined8 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined **local_478;
  undefined4 local_470;
  undefined4 local_46c;
  undefined1 local_468 [1048];
  undefined1 *local_50;
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if ((char *)param_1[0x85] != (char *)0x0) {
    cVar2 = *(char *)param_1[0x85];
    if (cVar2 == '\0') {
      uVar5 = FUN_140008520((int)param_1[0x82]);
      plVar6 = (longlong *)FUN_140087650(uVar5);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,(int)param_1[0x84]);
      if (plVar6 != (longlong *)0x0) {
        cVar2 = FUN_14018b5d0(plVar6);
        if (cVar2 != '\0') {
          FUN_1402ba1c0(&local_478);
          local_478 = CCrossMsgPropertyOpt::vftable;
          FUN_1402b5600(&local_478);
          local_50 = local_468;
          uVar5 = FUN_140008520((int)param_1[0x82]);
          uVar3 = FUN_14008b420(uVar5);
          local_470 = 0x9c6c;
          local_46c = 8;
          *local_50 = 1;
          *(undefined4 *)(local_50 + 4) = uVar3;
          local_50[1] = 1;
          plVar7 = (longlong *)FUN_140008520((int)param_1[0x82]);
          lVar1 = *plVar7;
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          (**(code **)(lVar1 + 0x10))(plVar7,uVar3,&local_478);
          local_478 = CCrossMsgPropertyOpt::vftable;
          FUN_1402b55f0(&local_478);
        }
      }
    }
    else if (cVar2 == '\x01') {
      uVar5 = FUN_140008520((int)param_1[0x82]);
      plVar6 = (longlong *)FUN_140087650(uVar5);
      plVar6 = (longlong *)
               (**(code **)(*plVar6 + 0xa0))
                         (plVar6,(int)param_1[0x84],*(undefined4 *)(param_1[0x85] + 4));
      if (plVar6 == (longlong *)0x0) {
        log_InlineLogERROR(
                          "CCrossMsgPropertyOpt::FUNCTION_TYPE_IMME_REBORN_G2O, idUser[%lu] idServer[%lu] is not online."
                          );
      }
      else {
        cVar2 = (**(code **)(plVar6[2] + 0x220))();
        if ((cVar2 == '\0') && (*(char *)(param_1[0x85] + 1) == '\x01')) {
          plVar7 = (longlong *)FUN_1401181a0();
          lVar1 = *plVar7;
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          (**(code **)(lVar1 + 0x10))(plVar7,uVar3,0x6a);
          FUN_140362560(&local_478);
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          local_490 = 0;
          local_498 = 0;
          local_4a0 = 3;
          local_4a8 = 0;
          local_4b0 = 0x5e;
          local_4b8 = 0;
          iVar4 = FUN_140362700(&local_478,uVar3,0,0);
          if (iVar4 != 0) {
            (**(code **)(*param_1 + 0x20))(param_1,&local_478);
          }
          local_4b8 = CONCAT11(local_4b8._1_1_,3);
          FUN_1401c6d40(plVar6,0,0,1);
          FUN_1403625e0(&local_478);
        }
      }
    }
  }
  return;
}

