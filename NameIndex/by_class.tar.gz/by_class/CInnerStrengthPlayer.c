// ==== CInnerStrengthPlayer::helper_140403550  @140403550  [medium:callgraph-r0]  (orig: FUN_140403550)
void FUN_140403550(void *param_1)

{
  if ((DAT_140976348 & 1) == 0) {
    DAT_140976348 = DAT_140976348 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976340,"CInnerStrengthPlayer");
    atexit((_func_5014 *)&LAB_1406d6d50);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404035a5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976340,param_1);
  return;
}

// ==== CInnerStrengthPlayer::helper_140403a30  @140403a30  [medium:callgraph-r3]  (orig: FUN_140403a30)
void FUN_140403a30(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140403a30(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CInnerStrengthPlayer::helper_140403c60  @140403c60  [medium:callgraph-r1]  (orig: FUN_140403c60)
void FUN_140403c60(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CInnerStrengthPlayer::helper_140403e20  @140403e20  [medium:callgraph-r2]  (orig: FUN_140403e20)
void FUN_140403e20(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140403a30(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CInnerStrengthPlayer::helper_140405470  @140405470  [medium:callgraph-r1]  (orig: FUN_140405470)
longlong * FUN_140405470(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140403e20(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140404f80(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CInnerStrengthPlayer::helper_140405620  @140405620  [medium:callgraph-r0]  (orig: FUN_140405620)
void FUN_140405620(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140405470((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CInnerStrengthPlayer::ctor_or_dtor  @140406d00  [high:vtable-assign]  (orig: FUN_140406d00)
void FUN_140406d00(undefined8 *param_1)

{
  *param_1 = CInnerStrengthPlayer::vftable;
  FUN_140157090(param_1 + 0x12);
  operator_delete((void *)param_1[0x12]);
  FUN_140405620(param_1 + 10);
  operator_delete((void *)param_1[10]);
  FUN_1401e0500(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CInnerStrengthPlayer::helper_140408600  @140408600  [medium:callgraph-r0]  (orig: FUN_140408600)
undefined8 * FUN_140408600(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140403c60(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CInnerStrengthPlayer::ctor_or_dtor  @140408680  [high:vtable-assign]  (orig: FUN_140408680)
undefined8 *
FUN_140408680(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4)

{
  *param_1 = CInnerStrengthPlayer::vftable;
  FUN_1401eb7e0(param_1 + 2);
  FUN_140408600(param_1 + 10);
  FUN_140159140(param_1 + 0x12);
  *(undefined4 *)(param_1 + 1) = param_2;
  *(undefined4 *)(param_1 + 0x1a) = param_3;
  *(undefined1 *)((longlong)param_1 + 0xd4) = param_4;
  *(undefined4 *)(param_1 + 0x1b) = 0xfaef8081;
  *(undefined4 *)((longlong)param_1 + 0xdc) = 0;
  return param_1;
}

// ==== CInnerStrengthPlayer::vfunc_0  @140408720  [high:rtti-vtable]  (orig: FUN_140408720)
undefined8 FUN_140408720(undefined8 param_1,uint param_2)

{
  FUN_140406d00();
  if ((param_2 & 1) != 0) {
    FUN_140403550(param_1);
  }
  return param_1;
}

