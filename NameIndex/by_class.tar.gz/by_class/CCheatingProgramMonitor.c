// ==== CCheatingProgramMonitor::helper_140001900  @140001900  [medium:callgraph-r2]  (orig: FUN_140001900)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140001900(undefined8 *param_1)

{
  longlong *plVar1;
  IStringManager *pIVar2;
  char *_Source;
  undefined1 auStack_78 [32];
  undefined8 *local_58;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  ulonglong local_18;
  ulonglong local_10;
  
  local_48 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  if (param_1 == (undefined8 *)0x0) {
    local_58 = (undefined8 *)CONCAT44(local_58._4_4_,0x98);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar1 = (longlong *)FUN_14050c340(5);
    if (plVar1 == (longlong *)0x0) {
      local_58 = (undefined8 *)CONCAT44(local_58._4_4_,0x9a);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      local_40 = *param_1;
      local_38 = param_1[1];
      local_30 = param_1[2];
      local_28 = param_1[3];
      local_20 = param_1[4];
      local_18 = param_1[5] & 0xffffffffffffff;
      if (*(char *)((longlong)param_1 + 0xf) == '\0') {
        pIVar2 = theInstance();
        _Source = (char *)(*(code *)**(undefined8 **)pIVar2)(pIVar2,"STR_GENERAL_BOT_SIN");
        strncpy((char *)((longlong)&local_38 + 7),_Source,0x21);
      }
      local_58 = &local_40;
      (**(code **)(*plVar1 + 0x50))(plVar1,0xe,0xea61,0x30);
    }
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140001a50  @140001a50  [medium:callgraph-r2]  (orig: FUN_140001a50)
void FUN_140001a50(undefined4 *param_1)

{
  short sVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  IStringManager *pIVar4;
  char *pcVar5;
  
  if (param_1 == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)FUN_14050c340(5);
    if (plVar2 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar3 = operator_new__(0x30);
      if (puVar3 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        *puVar3 = 0;
        puVar3[1] = 0;
        puVar3[2] = 0;
        puVar3[3] = 0;
        puVar3[4] = 0;
        puVar3[5] = 0;
        *(undefined4 *)puVar3 = *param_1;
        *(undefined2 *)((longlong)puVar3 + 4) = *(undefined2 *)(param_1 + 1);
        strncpy((char *)((longlong)puVar3 + 6),(char *)((longlong)param_1 + 6),9);
        sVar1 = *(short *)(param_1 + 1);
        if (sVar1 == 1) {
          pIVar4 = theInstance();
          pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_GENERAL_BOT_SIN");
          strncpy((char *)((longlong)puVar3 + 0xf),pcVar5,0x21);
        }
        else if (sVar1 == 2) {
          pIVar4 = theInstance();
          pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_KEY_BOT_SIN");
          strncpy((char *)((longlong)puVar3 + 0xf),pcVar5,0x21);
        }
        else if (sVar1 == 3) {
          pIVar4 = theInstance();
          pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SERIOUS_BOT_SIN");
          strncpy((char *)((longlong)puVar3 + 0xf),pcVar5,0x21);
        }
        else {
          if (sVar1 != 4) {
            log_InlineLogERROR("CCheatingProgramMonitor::ProcessMsg, wrong cheat type : %u");
            return;
          }
          pIVar4 = theInstance();
          pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_HACK_TOOL_SIN");
          strncpy((char *)((longlong)puVar3 + 0xf),pcVar5,0x21);
        }
        (**(code **)(*plVar2 + 0x50))(plVar2,0xe,0xea61,0x30,puVar3);
        operator_delete__(puVar3);
      }
    }
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140001c70  @140001c70  [medium:callgraph-r1]  (orig: FUN_140001c70)
undefined8
FUN_140001c70(longlong param_1,int param_2,undefined8 param_3,longlong param_4,undefined8 param_5)

{
  undefined8 uVar1;
  
  if (param_1 == 0) {
    log_InlineLogMessage("Cheating Program Monitor invalid msg");
    uVar1 = 0;
  }
  else if (param_2 - 1U < 0x30) {
    if (param_4 == 0) {
      uVar1 = 0;
    }
    else {
      DES_cfb64_encrypt(param_1,param_1,param_2,param_3,param_5,param_4,0);
      uVar1 = 1;
    }
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CCheatingProgramMonitor::helper_140002510  @140002510  [medium:callgraph-r1]  (orig: FUN_140002510)
void FUN_140002510(longlong param_1)

{
  void *_Dst;
  int iVar1;
  uint uVar2;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = 0;
    while (uVar2 = uVar2 + 1, uVar2 < 0x3e9) {
      iVar1 = *(int *)(param_1 + 0x1c);
      if (iVar1 < 8) {
        return;
      }
      _Dst = (void *)(param_1 + 0x20);
      if (_Dst == (void *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      if (*(ushort *)(param_1 + 0x24) == 0) {
        if (iVar1 < 0x30) {
          return;
        }
        FUN_140001900(_Dst);
        memmove(_Dst,(void *)(param_1 + 0x50),(longlong)(*(int *)(param_1 + 0x1c) + -0x30));
        *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + -0x30;
      }
      else {
        if (3 < *(ushort *)(param_1 + 0x24) - 1) {
          return;
        }
        if (iVar1 < 0xf) {
          return;
        }
        FUN_140001a50(_Dst);
        memmove(_Dst,(void *)(param_1 + 0x2f),(longlong)(*(int *)(param_1 + 0x1c) + -0xf));
        *(int *)(param_1 + 0x1c) = *(int *)(param_1 + 0x1c) + -0xf;
      }
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140002840  @140002840  [medium:callgraph-r2]  (orig: FUN_140002840)
void FUN_140002840(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140002c50  @140002c50  [medium:callgraph-r1]  (orig: FUN_140002c50)
void FUN_140002c50(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count<CheatingProgram::CLIENT_INFO>::vftable;
  }
  FUN_140002840(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CCheatingProgramMonitor::helper_1400031d0  @1400031d0  [medium:callgraph-r2]  (orig: FUN_1400031d0)
void FUN_1400031d0(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = 0;
      param_1[1] = 0;
      FUN_140002840(param_1,*param_3,param_3[1]);
    }
    param_1 = param_1 + 2;
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140003730  @140003730  [medium:callgraph-r3]  (orig: FUN_140003730)
void FUN_140003730(longlong param_1,longlong param_2,ulonglong param_3,longlong *param_4)

{
  int *piVar1;
  longlong *plVar2;
  ulonglong uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 local_res8;
  longlong local_60;
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  lVar10 = *(longlong *)(param_1 + 0x18);
  if (lVar10 == 0) {
    uVar11 = 0;
  }
  else {
    uVar11 = *(longlong *)(param_1 + 0x28) - lVar10 >> 4;
  }
  uVar12 = 0;
  if (param_3 != 0) {
    lVar10 = *(longlong *)(param_1 + 0x20) - lVar10 >> 4;
    if (0xfffffffffffffffU - lVar10 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140001fa0();
    }
    uVar3 = lVar10 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar11 < uVar3) {
      if (uVar11 <= 0xfffffffffffffff - (uVar11 >> 1)) {
        uVar12 = uVar11 + (uVar11 >> 1);
      }
      if (uVar12 < uVar3) {
        uVar12 = uVar3;
      }
      lVar8 = FUN_140002730(param_1 + 0x10,uVar12);
      lVar10 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      FUN_1400031d0(lVar10 * 0x10 + lVar8,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_1400032c0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar8,
                    param_1 + 0x10,local_res8,0);
      FUN_1400032c0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar10 + param_3) * 0x10 + lVar8,param_1 + 0x10,local_res8,0);
      lVar10 = *(longlong *)(param_1 + 0x18);
      lVar5 = *(longlong *)(param_1 + 0x20);
      if (lVar10 != 0) {
        FUN_1400035c0(param_1,lVar10,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar12 * 0x10 + lVar8;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar5 - lVar10 >> 4)) * 0x10 + lVar8;
      *(longlong *)(param_1 + 0x18) = lVar8;
    }
    else if ((ulonglong)(*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4) < param_3)
    {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      local_60 = lVar10;
      local_58 = plVar6;
      FUN_1400032c0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x10,param_1 + 0x10,local_res8,0);
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = param_3 - (lVar5 - *(longlong *)(param_2 + 8) >> 4);
      FUN_1400031d0(lVar5,lVar8,&local_60,param_1 + 0x10,local_res8,0,0,lVar5,lVar8);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar5 = *(longlong *)(param_1 + 0x20);
      for (plVar13 = *(longlong **)(param_2 + 8); plVar13 != (longlong *)(lVar5 + param_3 * -0x10);
          plVar13 = plVar13 + 2) {
        if (plVar6 != (longlong *)0x0) {
          LOCK();
          *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
          UNLOCK();
        }
        plVar14 = (longlong *)plVar13[1];
        if (plVar14 != (longlong *)0x0) {
          LOCK();
          plVar7 = plVar14 + 2;
          *(int *)plVar7 = (int)*plVar7 + -1;
          UNLOCK();
          if ((int)*plVar7 == 0) {
            (**(code **)*plVar14)(plVar14);
            LOCK();
            piVar1 = (int *)((longlong)plVar14 + 0x14);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
              (**(code **)(*plVar14 + 8))(plVar14);
            }
          }
        }
        plVar13[1] = (longlong)plVar6;
        *plVar13 = lVar10;
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
    else {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = lVar5 + param_3 * -0x10;
      local_50 = lVar10;
      local_48 = plVar6;
      uVar9 = FUN_1400032c0(lVar8,lVar5,lVar5,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar9;
      FUN_140003670(*(undefined8 *)(param_2 + 8),lVar8,lVar5);
      plVar13 = *(longlong **)(param_2 + 8);
      if (plVar13 != plVar13 + param_3 * 2) {
        plVar14 = plVar13 + 1;
        do {
          if (plVar6 != (longlong *)0x0) {
            LOCK();
            *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
            UNLOCK();
          }
          plVar7 = (longlong *)*plVar14;
          if (plVar7 != (longlong *)0x0) {
            LOCK();
            plVar2 = plVar7 + 2;
            *(int *)plVar2 = (int)*plVar2 + -1;
            UNLOCK();
            if ((int)*plVar2 == 0) {
              (**(code **)*plVar7)(plVar7);
              LOCK();
              piVar1 = (int *)((longlong)plVar7 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*plVar7 + 8))(plVar7);
              }
            }
          }
          *plVar14 = (longlong)plVar6;
          plVar14[-1] = lVar10;
          plVar7 = plVar14 + 1;
          plVar14 = plVar14 + 2;
        } while (plVar7 != plVar13 + param_3 * 2);
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
  }
  return;
}

// ==== CCheatingProgramMonitor::helper_140003bb0  @140003bb0  [medium:callgraph-r2]  (orig: FUN_140003bb0)
longlong * FUN_140003bb0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar1 = 0;
  uVar3 = param_1[3];
  lVar2 = lVar1;
  if ((param_1[4] - uVar3 & 0xfffffffffffffff0) != 0) {
    if ((ulonglong)param_1[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar3) >> 4;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140003730(param_1,&local_28,1,param_4);
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar3;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar1;
  }
  else {
    lVar4 = *param_1;
  }
  uVar3 = lVar2 * 0x10 + uVar3;
  if (uVar3 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar1 = *param_1;
    }
    if (*(ulonglong *)(lVar1 + 0x18) <= uVar3) goto LAB_140003ca7;
  }
  _invalid_parameter_noinfo();
LAB_140003ca7:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar3;
  return param_2;
}

// ==== CCheatingProgramMonitor::helper_140003cf0  @140003cf0  [medium:callgraph-r1]  (orig: FUN_140003cf0)
void FUN_140003cf0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 4;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 4) < uVar3) {
    FUN_1400031d0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x10;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140003bb0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CCheatingProgramMonitor::helper_140003dc0  @140003dc0  [medium:callgraph-r0]  (orig: FUN_140003dc0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Removing unreachable block (ram,0x000140004525) */
/* WARNING: Removing unreachable block (ram,0x000140004531) */

ulonglong FUN_140003dc0(longlong param_1)

{
  int *piVar1;
  char cVar2;
  ushort uVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined8 uVar11;
  void *_Dst;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  uint uVar15;
  int iVar16;
  longlong lVar17;
  longlong *plVar18;
  char *pcVar19;
  int iVar20;
  undefined1 auStack_1198 [32];
  undefined8 local_1178;
  undefined8 local_1170;
  undefined8 local_1168;
  longlong *local_1158 [3];
  longlong *local_1140;
  longlong *local_1138;
  undefined8 local_1130;
  int local_1128;
  int local_1124;
  uint local_1120;
  uint local_111c;
  longlong local_1118;
  int local_1110;
  uint local_110c;
  int local_1108;
  char local_1104 [4];
  uint local_1100;
  longlong *local_10f8;
  uint local_10f0;
  longlong *local_10e8;
  int local_10e0;
  int local_10dc;
  int local_10d8;
  uint local_10d4;
  int local_10d0;
  uint local_10cc;
  undefined4 local_10c8;
  undefined4 local_10c4;
  int local_10c0;
  uint local_10bc;
  undefined4 local_10b8;
  uint local_10b4;
  uint local_10b0;
  undefined8 local_10a8;
  longlong *local_10a0;
  longlong *local_1098;
  longlong *local_1090;
  longlong *local_1088;
  longlong *local_1080;
  longlong *local_1078;
  char local_1070 [8];
  longlong local_1068;
  int local_1060;
  longlong *local_1058;
  longlong *local_1050;
  longlong *local_1048;
  int local_1040 [2];
  longlong local_1038;
  longlong *local_1030;
  longlong *local_1028;
  longlong *local_1020;
  longlong local_1018;
  longlong local_1010;
  ulonglong local_1008;
  ulonglong local_1000;
  longlong *local_ff8;
  char *local_ff0;
  longlong local_fe8;
  longlong *local_fe0;
  ulonglong local_fd8;
  ulonglong local_fd0;
  longlong *local_fc8;
  longlong local_fc0;
  longlong local_fb8;
  longlong *local_fb0;
  ulonglong local_fa8;
  longlong local_fa0;
  longlong *local_f98;
  longlong *local_f90;
  longlong local_f88;
  ulonglong local_f80;
  ulonglong local_f78;
  undefined1 *local_f70;
  longlong *local_f68;
  longlong *local_f60;
  longlong local_f58;
  ulonglong local_f50;
  ulonglong local_f48;
  longlong local_f40;
  longlong *local_f38;
  longlong *local_f30;
  longlong local_f28;
  ulonglong local_f20;
  ulonglong local_f18;
  longlong local_f10;
  longlong *local_f08;
  longlong *local_f00;
  longlong local_ef8;
  ulonglong local_ef0;
  ulonglong local_ee8;
  longlong local_ee0;
  longlong *local_ed8;
  longlong *local_ed0;
  undefined1 *local_ec8;
  ulonglong local_ec0;
  ulonglong local_eb8;
  longlong local_eb0;
  longlong *local_ea8;
  longlong *local_ea0;
  longlong local_e98;
  ulonglong local_e90;
  ulonglong local_e88;
  longlong local_e80;
  longlong *local_e78;
  void *local_e70;
  char *local_e68;
  longlong *local_e60;
  ulonglong local_e58;
  longlong local_e50;
  longlong *local_e48;
  ulonglong local_e40;
  longlong local_e38;
  ulonglong local_e30;
  ulonglong local_e28;
  longlong *local_e20;
  longlong *local_e18;
  longlong local_e10;
  longlong local_e08;
  ulonglong local_e00;
  ulonglong local_df8;
  longlong local_df0;
  ulonglong local_de8;
  char *local_de0;
  longlong *local_dd8;
  ulonglong local_dd0;
  undefined1 *local_dc8;
  longlong *local_dc0;
  ulonglong local_db8;
  longlong local_db0;
  longlong *local_da8;
  ulonglong local_da0;
  longlong local_d98;
  ulonglong local_d90;
  longlong *local_d88;
  longlong *local_d80;
  ulonglong local_d78;
  longlong *local_d70;
  undefined1 *local_d68;
  longlong *local_d60;
  char *local_d58;
  ulonglong local_d50;
  longlong local_d48;
  longlong local_d40;
  undefined8 local_d38;
  longlong *local_d30;
  longlong *local_d28;
  int local_d18;
  undefined1 local_d14 [76];
  uint local_cc8 [2];
  longlong alStack_cc0 [65];
  undefined4 local_ab8;
  undefined4 local_ab4;
  undefined4 local_ab0;
  undefined4 local_aac;
  undefined2 local_aa8;
  ushort local_aa6;
  undefined4 local_aa4;
  undefined1 local_a98 [2];
  ushort local_a96;
  int local_a94;
  undefined1 local_a88 [128];
  CIniFile local_a08 [1024];
  undefined1 local_608 [416];
  char local_468 [16];
  char local_458 [24];
  undefined1 local_440 [8];
  char local_438 [1024];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x140003dd4;
  local_d38 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1198;
  plVar9 = (longlong *)FUN_14050c340(5);
  local_1088 = plVar9;
  if (plVar9 == (longlong *)0x0) {
    local_1178 = (char *)CONCAT44(local_1178._4_4_,0xff);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pPort",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp");
    return 0;
  }
  (**(code **)(*plVar9 + 0x38))(plVar9);
  local_1068 = param_1;
  if (param_1 == 0) {
    local_1178 = (char *)CONCAT44(local_1178._4_4_,0x103);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pMainThread",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp");
    return 0;
  }
  uVar10 = Ordinal_115(0x202,local_608);
  local_1060 = (int)uVar10;
  if (local_1060 != 0) {
    return uVar10;
  }
  if ((char)local_608._0_2_ != '\x02') {
    return uVar10;
  }
  if (SUB21(local_608._0_2_,1) != '\x02') {
    return uVar10;
  }
  plVar14 = (longlong *)0x0;
  local_1170 = (ulonglong)local_1170._4_4_ << 0x20;
  local_1178 = (char *)((ulonglong)local_1178._4_4_ << 0x20);
  iVar20 = 1;
  local_1118 = WSASocketA(2,1,0,0);
  if (local_1118 == -1) {
    uVar4 = Ordinal_111();
    Ordinal_116();
    return (ulonglong)uVar4;
  }
  CIniFile::CIniFile(local_a08,"shell.ini","CheatingMonitor");
  uVar4 = CIniFile::GetInt(local_a08,"ListenPort");
  if (uVar4 == 0) {
    uVar4 = 0x23be;
  }
  local_d18 = 0;
  local_10bc = uVar4;
  memset(local_d14,0,0x4c);
  local_468[0] = '\0';
  local_468[1] = '\0';
  local_468[2] = '\0';
  local_468[3] = '\0';
  local_468[4] = '\0';
  local_468[5] = '\0';
  local_468[6] = '\0';
  local_468[7] = '\0';
  local_468[8] = '\0';
  local_468[9] = 0;
  local_458[0] = '\0';
  local_458[1] = '\0';
  local_458[2] = '\0';
  local_458[3] = '\0';
  local_458[4] = '\0';
  local_458[5] = '\0';
  local_458[6] = '\0';
  local_458[7] = '\0';
  local_458[8] = '\0';
  local_458[9] = '\0';
  local_458[10] = '\0';
  local_458[0xb] = '\0';
  local_458[0xc] = '\0';
  local_458[0xd] = '\0';
  local_458[0xe] = '\0';
  local_458[0xf] = '\0';
  local_458[0x10] = '\0';
  local_458[0x11] = '\0';
  local_458[0x12] = '\0';
  local_458[0x13] = 0;
  iVar5 = CIniFile::GetInt(local_a08,"IPNum");
  local_1110 = iVar5;
  if (0x14 < iVar5) {
    iVar5 = 0x14;
    local_1110 = 0x14;
    log_InlineLogWARNING("astrict ip number overrun max ip number!");
  }
  local_1100 = 0;
  plVar13 = plVar14;
  while (lVar17 = local_1118, iVar7 = (int)plVar13, iVar7 < iVar5) {
    uVar15 = iVar7 + 1;
    _snprintf(local_468,10,"IP%d",(ulonglong)uVar15);
    local_468[9] = 0;
    CIniFile::GetString(local_a08,local_458,local_468,0x14);
    uVar6 = Ordinal_11(local_458);
    *(undefined4 *)(local_d14 + (longlong)iVar7 * 4 + -4) = uVar6;
    iVar5 = local_1110;
    local_1100 = uVar15;
    plVar13 = (longlong *)(ulonglong)uVar15;
  }
  local_aa8 = 2;
  WSAHtons(local_1118,uVar4 & 0xffff,&local_aa6);
  local_aa4 = 0;
  iVar5 = Ordinal_2(lVar17,&local_aa8,0x10);
  if (iVar5 != 0) {
    uVar4 = Ordinal_111();
    uVar11 = Ordinal_12(local_aa4);
    log_InlineLogMessage
              ("Cheating Program Monitor can not bind to (%s : %u), nErr : %d",uVar11,
               (ulonglong)local_aa6,(ulonglong)uVar4);
    Ordinal_3(local_1118);
    Ordinal_116();
    CIniFile::~CIniFile(local_a08);
    return (ulonglong)uVar4;
  }
  iVar5 = Ordinal_13(lVar17);
  if (iVar5 != 0) {
    uVar4 = Ordinal_111();
    log_InlineLogMessage("Cheating Program Monitor listen failed : %d",(ulonglong)uVar4);
    Ordinal_3(lVar17);
    Ordinal_116();
    CIniFile::~CIniFile(local_a08);
    return (ulonglong)uVar4;
  }
  local_1070[0] = '\0';
  local_1070[1] = '\0';
  local_1070[2] = '\0';
  local_1070[3] = '\0';
  local_1070[4] = -0xc;
  local_1070[5] = '\x01';
  local_1070[6] = '\0';
  local_1070[7] = '\0';
  local_1128 = 1;
  local_d70 = operator_new(8);
  local_1158[0] = plVar14;
  if (local_d70 != (longlong *)0x0) {
    *local_d70 = (longlong)local_1158;
    local_1158[0] = local_d70;
  }
  local_1140 = (longlong *)0x0;
  local_1138 = (longlong *)0x0;
  local_1130 = 0;
  local_111c = 0;
  plVar13 = plVar14;
  local_1020 = local_1158[0];
  local_d28 = local_d70;
  while ((int)(uint)plVar13 < 0x40) {
    _Dst = operator_new(0x8020);
    local_e70 = _Dst;
    if (_Dst == (void *)0x0) {
      local_1178 = (char *)CONCAT44(local_1178._4_4_,0x155);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pClientInfo",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp"
                        );
      local_10d4 = 0;
      if (local_1140 != (longlong *)0x0) {
        local_1050 = local_1138;
        for (local_10f8 = local_1140; local_10f8 != local_1050; local_10f8 = local_10f8 + 2) {
          if (local_10f8[1] != 0) {
            plVar14 = (longlong *)local_10f8[1];
            LOCK();
            plVar9 = plVar14 + 2;
            *(int *)plVar9 = (int)*plVar9 + -1;
            UNLOCK();
            local_1098 = plVar14;
            if ((int)*plVar9 == 0) {
              (**(code **)*plVar14)(plVar14);
              LOCK();
              piVar1 = (int *)((longlong)plVar14 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*local_1098 + 8))();
              }
            }
          }
        }
        operator_delete(local_1140);
      }
      local_1140 = (longlong *)0x0;
      local_1138 = (longlong *)0x0;
      local_1130 = 0;
      operator_delete(local_1158[0]);
      CIniFile::~CIniFile(local_a08);
      return (ulonglong)local_10d4;
    }
    memset(_Dst,0,0x8020);
    local_10a8 = 0;
    local_10a0 = (longlong *)0x0;
    FUN_140002c50(&local_10a8,_Dst);
    FUN_140003cf0(local_1158);
    plVar18 = local_10a0;
    uVar4 = (uint)plVar13;
    if (local_10a0 != (longlong *)0x0) {
      LOCK();
      plVar13 = local_10a0 + 2;
      *(int *)plVar13 = (int)*plVar13 + -1;
      UNLOCK();
      plVar9 = local_1088;
      iVar20 = local_1128;
      uVar4 = local_111c;
      if ((int)*plVar13 == 0) {
        (**(code **)*local_10a0)(local_10a0);
        LOCK();
        piVar1 = (int *)((longlong)plVar18 + 0x14);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        plVar9 = local_1088;
        iVar20 = local_1128;
        uVar4 = local_111c;
        if (*piVar1 == 0) {
          (**(code **)(*local_10a0 + 8))();
          plVar9 = local_1088;
          iVar20 = local_1128;
          uVar4 = local_111c;
        }
      }
    }
    local_111c = uVar4 + 1;
    plVar13 = (longlong *)(ulonglong)local_111c;
  }
  if ((longlong)local_1138 - (longlong)local_1140 >> 4 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar17 = local_1118;
  local_1010 = *local_1140;
  *(longlong *)(local_1010 + 8) = local_1118;
  if ((longlong)local_1138 - (longlong)local_1140 >> 4 == 0) {
    _invalid_parameter_noinfo();
  }
  local_d68 = (undefined1 *)*local_1140;
  *local_d68 = 1;
  DES_string_to_key("df29duw",local_440);
  DES_set_key_checked(local_440);
  local_438[0] = '\0';
  memset(local_438 + 1,0,0x3ff);
  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
  _snprintf(local_438,0x3ff,"#%u: Cheating Program Monitor thread running.",(ulonglong)uVar4);
  lVar12 = -1;
  pcVar19 = local_438;
  do {
    if (lVar12 == 0) break;
    lVar12 = lVar12 + -1;
    cVar2 = *pcVar19;
    pcVar19 = pcVar19 + 1;
  } while (cVar2 != '\0');
  local_1178 = local_438;
  (**(code **)(*plVar9 + 0x50))(plVar9,0,0x9c41,~(uint)lVar12);
  local_110c = 0;
LAB_1400044f0:
  do {
    iVar7 = 1;
    iVar5 = FUN_14001f4c0(local_1068);
    if (iVar5 != 2) goto LAB_14000524a;
    local_cc8[0] = 0;
    local_10c8 = 0;
    alStack_cc0[0] = lVar17;
    local_cc8[0] = 1;
    local_cc8[0] = 1;
    uVar4 = 1;
    local_1120 = 0;
    local_10c0 = 1;
    local_10e0 = 1;
    plVar9 = local_1140;
    plVar13 = plVar14;
    while (iVar5 = local_10e0, local_10e0 < 0x40) {
      local_1120 = (int)plVar13 + 1;
      plVar13 = (longlong *)(ulonglong)local_1120;
      if (1000000 < local_1120) {
        local_1178 = (char *)CONCAT44(local_1178._4_4_,0x177);
        log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp"
                          );
        break;
      }
      uVar10 = (ulonglong)local_10e0;
      local_1000 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
        plVar9 = local_1140;
        uVar4 = local_cc8[0];
      }
      local_e60 = plVar9 + uVar10 * 2;
      local_ff0 = (char *)*local_e60;
      if (*local_ff0 != '\0') {
        local_d90 = uVar10;
        if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
          _invalid_parameter_noinfo();
          plVar9 = local_1140;
          uVar4 = local_cc8[0];
        }
        local_fe0 = plVar9 + uVar10 * 2;
        local_e50 = *local_fe0;
        if (*(longlong *)(local_e50 + 8) != 0) {
          local_10f0 = 0;
          plVar18 = plVar14;
          while (uVar15 = (uint)plVar18, uVar15 < uVar4) {
            local_fd0 = uVar10;
            if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
              _invalid_parameter_noinfo();
              plVar9 = local_1140;
              uVar4 = local_cc8[0];
            }
            local_d88 = plVar9 + uVar10 * 2;
            local_fc0 = *local_d88;
            if (alStack_cc0[(longlong)plVar18] == *(longlong *)(local_fc0 + 8)) break;
            local_10f0 = uVar15 + 1;
            plVar18 = (longlong *)(ulonglong)local_10f0;
          }
          if ((uVar15 == uVar4) && (uVar4 < 0x40)) {
            local_e40 = uVar10;
            if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
              _invalid_parameter_noinfo();
              plVar9 = local_1140;
            }
            local_fb0 = plVar9 + uVar10 * 2;
            local_d48 = *local_fb0;
            alStack_cc0[(longlong)plVar18] = *(longlong *)(local_d48 + 8);
            uVar4 = local_cc8[0] + 1;
            local_cc8[0] = uVar4;
          }
          iVar7 = iVar7 + 1;
          local_10c0 = iVar7;
          if (iVar20 <= iVar7) break;
        }
      }
      local_10e0 = iVar5 + 1;
    }
    local_1178 = local_1070;
    iVar5 = Ordinal_18(0,local_cc8,0,0);
    lVar17 = local_1118;
    local_1108 = iVar5;
    if (iVar5 == -1) {
      uVar4 = Ordinal_111();
      log_InlineLogERROR("Cheating Program Monitor select failed : %d",(ulonglong)uVar4);
      lVar17 = local_1118;
      goto LAB_14000524a;
    }
  } while (iVar5 < 1);
  iVar7 = Ordinal_151(local_1118,local_cc8);
  if (iVar7 == 0) goto LAB_140004c05;
  iVar5 = iVar5 + -1;
  local_1108 = iVar5;
  if (iVar20 < 0x40) {
    local_10b8 = 0x10;
    local_1178 = (char *)0x0;
    lVar12 = WSAAccept(lVar17,local_a98,&local_10b8);
    uVar3 = local_a96;
    local_fa0 = lVar12;
    if (lVar12 != -1) {
      uVar11 = Ordinal_12(local_a94);
      log_InlineLogMessage("Cheating Program Monitor client(%s : %u) login",uVar11,(ulonglong)uVar3)
      ;
      local_10b0 = 0;
      plVar9 = plVar14;
      while (iVar7 = (int)plVar9, iVar7 < local_1110) {
        if (*(int *)(local_d14 + (longlong)iVar7 * 4 + -4) == local_a94) {
          local_10d8 = 0;
          local_10b4 = 0;
          plVar9 = local_1140;
          plVar13 = local_1138;
          plVar18 = plVar14;
          goto LAB_1400048d6;
        }
        local_10b0 = iVar7 + 1;
        plVar9 = (longlong *)(ulonglong)local_10b0;
      }
      uVar11 = Ordinal_12();
      log_InlineLogWARNING("lawless ip address %s!",uVar11);
      Ordinal_3(lVar12);
      goto LAB_1400044f0;
    }
    uVar4 = Ordinal_111();
    log_InlineLogERROR("Cheating Program Monitor Accept client failed : %d",(ulonglong)uVar4);
  }
  else {
    log_InlineLogERROR("Cheating Program Monitor too many clients");
  }
LAB_140004c05:
  local_1120 = 0;
  local_10dc = 1;
  plVar9 = plVar14;
  while( true ) {
    iVar7 = local_10dc;
    lVar17 = local_1118;
    if ((iVar5 < 1) || (0x3f < local_10dc)) goto LAB_1400044f0;
    local_1120 = (int)plVar9 + 1;
    plVar9 = (longlong *)(ulonglong)local_1120;
    if (1000000 < local_1120) break;
    uVar10 = (ulonglong)local_10dc;
    local_de8 = uVar10;
    if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
      _invalid_parameter_noinfo();
    }
    local_f00 = local_1140 + uVar10 * 2;
    local_de0 = (char *)*local_f00;
    if (*local_de0 != '\0') {
      local_ef0 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      local_d60 = local_1140 + uVar10 * 2;
      local_ee0 = *local_d60;
      iVar8 = Ordinal_151(*(undefined8 *)(local_ee0 + 8),local_cc8);
      if (iVar8 != 0) {
        iVar5 = iVar5 + -1;
        local_1108 = iVar5;
        local_dd0 = uVar10;
        if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        local_ed0 = local_1140 + uVar10 * 2;
        local_d40 = *local_ed0;
        local_1040[0] = 0x8000 - *(int *)(local_d40 + 0x1c);
        if (local_1040[0] == 0) {
          local_1178 = (char *)CONCAT44(local_1178._4_4_,0x1da);
          log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","WSABuff.len > 0",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp"
                            );
        }
        local_ec0 = uVar10;
        if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        local_dc0 = local_1140 + uVar10 * 2;
        lVar17 = *local_dc0;
        local_eb0 = lVar17;
        local_d50 = uVar10;
        if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        local_ea0 = local_1140 + uVar10 * 2;
        local_db0 = *local_ea0;
        local_1038 = (longlong)*(int *)(local_db0 + 0x1c) + 0x20 + lVar17;
        local_1124 = 0;
        local_1104[0] = '\0';
        local_1104[1] = '\0';
        local_1104[2] = '\0';
        local_1104[3] = '\0';
        local_e90 = uVar10;
        if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        local_d80 = local_1140 + uVar10 * 2;
        local_e80 = *local_d80;
        local_1168 = 0;
        local_1170 = 0;
        local_1178 = local_1104;
        iVar8 = WSARecv(*(undefined8 *)(local_e80 + 8),local_1040,1);
        if ((iVar8 == 0) && (local_1124 != 0)) {
          local_da0 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_1028 = local_1140 + uVar10 * 2;
          lVar17 = *local_1028;
          local_1018 = lVar17;
          local_1008 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_ff8 = local_1140 + uVar10 * 2;
          local_fe8 = *local_ff8;
          local_1178 = (char *)(lVar17 + 0x14);
          FUN_140001c70(local_1038,local_1124,local_a88);
          local_fd8 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_fc8 = local_1140 + uVar10 * 2;
          local_fb8 = *local_fc8;
          *(int *)(local_fb8 + 0x1c) = *(int *)(local_fb8 + 0x1c) + local_1124;
          local_fa8 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_f98 = local_1140 + uVar10 * 2;
          local_f88 = *local_f98;
          FUN_140002510();
        }
        else {
          local_ab8 = 0;
          local_ab4 = 0;
          local_ab0 = 0;
          local_aac = 0;
          local_10c4 = 0x10;
          local_f78 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_f68 = local_1140 + uVar10 * 2;
          local_f58 = *local_f68;
          iVar8 = Ordinal_5(*(undefined8 *)(local_f58 + 8),&local_ab8,&local_10c4);
          if (iVar8 == 0) {
            uVar3 = local_ab8._2_2_;
            uVar11 = Ordinal_12(local_ab4);
            log_InlineLogMessage
                      ("Cheating Program Monitor client(%s : %u) logout",uVar11,(ulonglong)uVar3);
          }
          else {
            log_InlineLogMessage("Cheating Program Monitor one client logout");
          }
          local_f48 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_f38 = local_1140 + uVar10 * 2;
          local_f28 = *local_f38;
          Ordinal_22(*(undefined8 *)(local_f28 + 8),2);
          local_f18 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_f08 = local_1140 + uVar10 * 2;
          local_ef8 = *local_f08;
          Ordinal_3(*(undefined8 *)(local_ef8 + 8));
          local_ee8 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_ed8 = local_1140 + uVar10 * 2;
          local_ec8 = (undefined1 *)*local_ed8;
          *local_ec8 = 0;
          local_eb8 = uVar10;
          if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          local_ea8 = local_1140 + uVar10 * 2;
          local_e98 = *local_ea8;
          *(undefined8 *)(local_e98 + 8) = 0;
          iVar20 = iVar20 + -1;
          local_1128 = iVar20;
        }
      }
    }
    local_10dc = iVar7 + 1;
  }
  local_1178 = (char *)CONCAT44(local_1178._4_4_,0x1ce);
  log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount");
  lVar17 = local_1118;
  goto LAB_1400044f0;
LAB_14000524a:
  log_InlineLogMessage("Cheating Program Monitor Thread stop");
  Ordinal_3(lVar17);
  local_110c = 0;
  local_10d0 = 1;
  plVar9 = local_1140;
  do {
    iVar5 = local_10d0;
    if (iVar20 <= local_10d0) {
LAB_140005453:
      Ordinal_116();
      if (local_1140 != (longlong *)0x0) {
        local_1048 = local_1138;
        for (local_10e8 = local_1140; local_10e8 != local_1048; local_10e8 = local_10e8 + 2) {
          if (local_10e8[1] != 0) {
            plVar14 = (longlong *)local_10e8[1];
            LOCK();
            plVar9 = plVar14 + 2;
            *(int *)plVar9 = (int)*plVar9 + -1;
            UNLOCK();
            local_1080 = plVar14;
            if ((int)*plVar9 == 0) {
              (**(code **)*plVar14)(plVar14);
              LOCK();
              piVar1 = (int *)((longlong)plVar14 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*local_1080 + 8))();
              }
            }
          }
        }
        operator_delete(local_1140);
      }
      local_1140 = (longlong *)0x0;
      local_1138 = (longlong *)0x0;
      local_1130 = 0;
      operator_delete(local_1158[0]);
      CIniFile::~CIniFile(local_a08);
      return 0;
    }
    local_110c = (int)plVar14 + 1;
    plVar14 = (longlong *)(ulonglong)local_110c;
    if (1000000 < local_110c) {
      local_1178 = (char *)CONCAT44(local_1178._4_4_,0x208);
      log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp"
                        );
      goto LAB_140005453;
    }
    uVar10 = (ulonglong)local_10d0;
    local_e88 = uVar10;
    if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
      _invalid_parameter_noinfo();
      plVar9 = local_1140;
    }
    local_e78 = plVar9 + uVar10 * 2;
    local_e68 = (char *)*local_e78;
    if (*local_e68 != '\0') {
      local_e58 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)plVar9 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
        plVar9 = local_1140;
      }
      local_e48 = plVar9 + uVar10 * 2;
      local_e38 = *local_e48;
      Ordinal_22(*(undefined8 *)(local_e38 + 8),2);
      local_e28 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      local_e18 = local_1140 + uVar10 * 2;
      local_e08 = *local_e18;
      Ordinal_3(*(undefined8 *)(local_e08 + 8));
      local_df8 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      local_dd8 = local_1140 + uVar10 * 2;
      local_dc8 = (undefined1 *)*local_dd8;
      *local_dc8 = 0;
      local_db8 = uVar10;
      if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      local_da8 = local_1140 + uVar10 * 2;
      local_d98 = *local_da8;
      *(undefined8 *)(local_d98 + 8) = 0;
      plVar9 = local_1140;
    }
    local_10d0 = iVar5 + 1;
  } while( true );
LAB_1400048d6:
  iVar16 = (int)plVar18;
  iVar7 = 0;
  iVar8 = local_10d8;
  if (0x3f < iVar16) goto LAB_14000493a;
  uVar10 = (ulonglong)iVar16;
  local_e30 = uVar10;
  if ((ulonglong)((longlong)plVar13 - (longlong)plVar9 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
    plVar9 = local_1140;
    plVar13 = local_1138;
  }
  local_f90 = plVar9 + uVar10 * 2;
  local_d58 = (char *)*local_f90;
  iVar7 = iVar16;
  iVar8 = iVar16;
  if (*local_d58 == '\0') goto LAB_14000493a;
  local_10b4 = iVar16 + 1;
  plVar18 = (longlong *)(ulonglong)local_10b4;
  goto LAB_1400048d6;
LAB_14000493a:
  local_10d8 = iVar8;
  if (0x3f < iVar7) {
    local_1178 = (char *)CONCAT44(local_1178._4_4_,0x1b7);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","nNewPosition < CheatingProgram::MAX_CLIENT_NUMA",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\cheatingprogrammonitor.cpp");
    local_10cc = 0;
    if (local_1140 != (longlong *)0x0) {
      local_1058 = local_1138;
      plVar9 = local_1138;
      plVar14 = local_1140;
      for (local_1090 = local_1140; local_1090 != plVar9; local_1090 = local_1090 + 2) {
        if (local_1090[1] != 0) {
          plVar18 = (longlong *)local_1090[1];
          LOCK();
          plVar13 = plVar18 + 2;
          *(int *)plVar13 = (int)*plVar13 + -1;
          UNLOCK();
          plVar9 = local_1058;
          plVar14 = local_1140;
          local_1078 = plVar18;
          if ((int)*plVar13 == 0) {
            (**(code **)*plVar18)(plVar18);
            LOCK();
            piVar1 = (int *)((longlong)plVar18 + 0x14);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            plVar9 = local_1058;
            plVar14 = local_1140;
            if (*piVar1 == 0) {
              (**(code **)(*local_1078 + 8))();
              plVar9 = local_1058;
              plVar14 = local_1140;
            }
          }
        }
      }
      operator_delete(plVar14);
    }
    local_1140 = (longlong *)0x0;
    local_1138 = (longlong *)0x0;
    local_1130 = 0;
    operator_delete(local_1158[0]);
    CIniFile::~CIniFile(local_a08);
    return (ulonglong)local_10cc;
  }
  uVar10 = (ulonglong)iVar7;
  local_f80 = uVar10;
  if ((ulonglong)((longlong)plVar13 - (longlong)plVar9 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
    plVar9 = local_1140;
  }
  local_e20 = plVar9 + uVar10 * 2;
  local_f70 = (undefined1 *)*local_e20;
  *local_f70 = 1;
  local_d78 = uVar10;
  if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
  }
  local_f60 = local_1140 + uVar10 * 2;
  local_e10 = *local_f60;
  *(longlong *)(local_e10 + 8) = lVar12;
  local_f50 = uVar10;
  if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
  }
  local_d30 = local_1140 + uVar10 * 2;
  local_f40 = *local_d30;
  *(undefined4 *)(local_f40 + 0x10) = 0;
  local_e00 = uVar10;
  if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
  }
  local_f30 = local_1140 + uVar10 * 2;
  local_df0 = *local_f30;
  *(undefined8 *)(local_df0 + 0x14) = 0;
  local_f20 = uVar10;
  if ((ulonglong)((longlong)local_1138 - (longlong)local_1140 >> 4) <= uVar10) {
    _invalid_parameter_noinfo();
  }
  local_1030 = local_1140 + uVar10 * 2;
  local_f10 = *local_1030;
  *(undefined4 *)(local_f10 + 0x1c) = 0;
  iVar20 = iVar20 + 1;
  local_1128 = iVar20;
  goto LAB_140004c05;
}

// ==== CCheatingProgramMonitor::StartWorkerThread  @140005550  [high:log-string]  (orig: FUN_140005550)
uintptr_t FUN_140005550(undefined8 *param_1)

{
  uintptr_t uVar1;
  uint local_res10 [6];
  
  if (DAT_1409754e8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((void *)*param_1 == (void *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  local_res10[0] = 0;
  uVar1 = _beginthreadex((void *)0x0,0,FUN_140003dc0,(void *)*param_1,0,local_res10);
  param_1[1] = uVar1;
  if (uVar1 == 0) {
    log_InlineLogERROR(
                      "CCheatingProgramMonitor::StartWorkerThread() _beginthreadex failed at %s, %d"
                      );
    uVar1 = 0;
  }
  return uVar1;
}

