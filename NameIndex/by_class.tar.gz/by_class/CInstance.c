// ==== CInstance::helper_1404212d0  @1404212d0  [medium:callgraph-r0]  (orig: FUN_1404212d0)
void FUN_1404212d0(void *param_1)

{
  if ((DAT_1409763e8 & 1) == 0) {
    DAT_1409763e8 = DAT_1409763e8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763e0,"CInstance");
    atexit((_func_5014 *)&LAB_1406d6df0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140421325. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763e0,param_1);
  return;
}

// ==== CInstance::ctor_or_dtor  @1404223a0  [high:vtable-assign]  (orig: FUN_1404223a0)
void FUN_1404223a0(undefined8 *param_1)

{
  *param_1 = CInstance::vftable;
  FUN_14000c310(param_1 + 0xd);
  operator_delete((void *)param_1[0xd]);
  FUN_14000c310(param_1 + 5);
  operator_delete((void *)param_1[5]);
  return;
}

// ==== CInstance::ctor_or_dtor  @140422410  [high:vtable-assign]  (orig: FUN_140422410)
undefined8 * FUN_140422410(undefined8 *param_1,undefined4 param_2,undefined8 param_3)

{
  *param_1 = CInstance::vftable;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  FUN_14000ef40(param_1 + 5);
  FUN_14000ef40(param_1 + 0xd);
  *(undefined4 *)(param_1 + 0x15) = 0;
  *(undefined4 *)((longlong)param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 1) = param_2;
  param_1[2] = param_3;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined1 *)(param_1 + 0x16) = 0;
  return param_1;
}

// ==== CInstance::ctor_or_dtor  @1404224a0  [high:vtable-assign]  (orig: FUN_1404224a0)
undefined8 * FUN_1404224a0(undefined8 *param_1,uint param_2)

{
  *param_1 = CInstance::vftable;
  FUN_14000c310(param_1 + 0xd);
  operator_delete((void *)param_1[0xd]);
  FUN_14000c310(param_1 + 5);
  operator_delete((void *)param_1[5]);
  if ((param_2 & 1) != 0) {
    FUN_1404212d0(param_1);
  }
  return param_1;
}

