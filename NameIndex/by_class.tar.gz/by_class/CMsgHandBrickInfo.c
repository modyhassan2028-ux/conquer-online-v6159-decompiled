// ==== CMsgHandBrickInfo::ctor_or_dtor  @140434560  [high:vtable-assign]  (orig: FUN_140434560)
undefined8 * FUN_140434560(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgHandBrickInfo::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x1a),0x3f6,true);
  return param_1;
}

// ==== CMsgHandBrickInfo::ctor_or_dtor  @1404345e0  [high:vtable-assign]  (orig: FUN_1404345e0)
void FUN_1404345e0(undefined8 *param_1)

{
  *param_1 = CMsgHandBrickInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgHandBrickInfo::vfunc_1  @140434620  [high:rtti-vtable]  (orig: FUN_140434620)
bool FUN_140434620(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xbb9;
    }
  }
  return false;
}

// ==== CMsgHandBrickInfo::vfunc_3  @1404347c0  [high:rtti-vtable]  (orig: FUN_1404347c0)
void FUN_1404347c0(void)

{
  return;
}

// ==== CMsgHandBrickInfo::ctor_or_dtor  @1404347d0  [high:vtable-assign]  (orig: FUN_1404347d0)
undefined8 * FUN_1404347d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgHandBrickInfo::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

