// ==== CMsgNpcInfoEx::ctor_or_dtor  @140456560  [high:vtable-assign]  (orig: FUN_140456560)
undefined8 * FUN_140456560(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNpcInfoEx::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf((CStringPacker *)(param_1 + 0x86),(char *)(param_1 + 6),0x3dd,true);
  return param_1;
}

// ==== CMsgNpcInfoEx::ctor_or_dtor  @1404565e0  [high:vtable-assign]  (orig: FUN_1404565e0)
void FUN_1404565e0(undefined8 *param_1)

{
  *param_1 = CMsgNpcInfoEx::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgNpcInfoEx::vfunc_1  @140456710  [high:rtti-vtable]  (orig: FUN_140456710)
undefined8 FUN_140456710(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgNpcInfoEx::vfunc_3  @140456740  [high:rtti-vtable]  (orig: FUN_140456740)
void FUN_140456740(void)

{
  return;
}

// ==== CMsgNpcInfoEx::ctor_or_dtor  @140456750  [high:vtable-assign]  (orig: FUN_140456750)
undefined8 * FUN_140456750(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNpcInfoEx::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

