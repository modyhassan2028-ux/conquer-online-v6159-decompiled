// ==== CMsgFuse::helper_14030b8d0  @14030b8d0  [medium:callgraph-r1]  (orig: FUN_14030b8d0)
ulonglong FUN_14030b8d0(longlong param_1,longlong param_2)

{
  char cVar1;
  ulonglong *puVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  ulonglong uVar16;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 *local_20;
  
  if (param_2 != 0) {
    uVar16 = 0;
    iVar6 = FUN_1400fda10(param_2,1,1);
    puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar12 + 0x21);
    puVar5 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar12 + 3) < iVar6 + 200000000U) {
        puVar10 = (undefined8 *)puVar12[2];
        puVar12 = puVar5;
      }
      else {
        puVar10 = (undefined8 *)*puVar12;
      }
      puVar5 = puVar12;
      puVar12 = puVar10;
      cVar1 = *(char *)((longlong)puVar10 + 0x21);
    }
    puVar12 = *(undefined8 **)(param_1 + 0x38);
    local_30 = puVar5;
    local_38 = *(longlong *)(param_1 + 8);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar5 == puVar12) || (iVar6 + 200000000U < *(uint *)(puVar5 + 3))) {
      plVar11 = &local_28;
      local_20 = (undefined8 *)*(undefined8 *)(param_1 + 0x38);
      local_28 = *(longlong *)(param_1 + 8);
    }
    else {
      plVar11 = &local_38;
    }
    puVar2 = (ulonglong *)*plVar11;
    lVar3 = *(longlong *)(param_1 + 0x38);
    lVar4 = plVar11[1];
    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != *(ulonglong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    uVar13 = uVar16;
    if (lVar4 != lVar3) {
      if (puVar2 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        uVar13 = *puVar2;
      }
      if (lVar4 == *(longlong *)(uVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar13 = (ulonglong)*(uint *)(lVar4 + 0x1c);
    }
    uVar7 = FUN_1400fda10(param_2,1,1);
    iVar6 = FUN_1400ff680(uVar7);
    if (((((0 < iVar6) && (iVar6 < 9)) || (iVar6 == 0xc)) || ((iVar6 == 0xd || (iVar6 == 0x15)))) ||
       (iVar6 == 0x16)) {
      iVar6 = FUN_1400fed80(param_2);
      iVar8 = FUN_1400fee00(param_2);
      iVar9 = FUN_1400fda10(param_2,1,1);
      puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
      uVar14 = (iVar6 + 100000) * 1000 + iVar8 * 10 + iVar9 % 10;
      cVar1 = *(char *)((longlong)puVar12 + 0x21);
      puVar5 = *(undefined8 **)(param_1 + 0x38);
      while (cVar1 == '\0') {
        if (*(uint *)(puVar12 + 3) < uVar14) {
          puVar10 = (undefined8 *)puVar12[2];
          puVar12 = puVar5;
        }
        else {
          puVar10 = (undefined8 *)*puVar12;
        }
        puVar5 = puVar12;
        puVar12 = puVar10;
        cVar1 = *(char *)((longlong)puVar10 + 0x21);
      }
      puVar12 = *(undefined8 **)(param_1 + 0x38);
      local_20 = puVar5;
      local_28 = *(longlong *)(param_1 + 8);
      if (*(longlong *)(param_1 + 8) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar5 == puVar12) || (uVar14 < *(uint *)(puVar5 + 3))) {
        plVar11 = &local_38;
        local_30 = *(undefined8 **)(param_1 + 0x38);
        local_38 = *(longlong *)(param_1 + 8);
      }
      else {
        plVar11 = &local_28;
      }
      puVar2 = (ulonglong *)*plVar11;
      lVar3 = *(longlong *)(param_1 + 0x38);
      lVar4 = plVar11[1];
      if ((puVar2 == (ulonglong *)0x0) || (puVar2 != *(ulonglong **)(param_1 + 8))) {
        _invalid_parameter_noinfo();
      }
      if (lVar4 != lVar3) {
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar15 = uVar16;
        }
        else {
          uVar15 = *puVar2;
        }
        if (lVar4 == *(longlong *)(uVar15 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((int)uVar13 <= *(int *)(lVar4 + 0x1c)) {
          if (puVar2 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            uVar16 = *puVar2;
          }
          if (lVar4 == *(longlong *)(uVar16 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar13 = (ulonglong)*(uint *)(lVar4 + 0x1c);
        }
      }
    }
    return uVar13;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgFuse::helper_1403531e0  @1403531e0  [medium:callgraph-r0]  (orig: FUN_1403531e0)
undefined8 FUN_1403531e0(longlong param_1,longlong param_2,int param_3,int param_4)

{
  bool bVar1;
  undefined2 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  longlong lVar11;
  uint uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  longlong lVar16;
  float fVar17;
  float fVar18;
  undefined2 local_58;
  
  if ((param_2 == 0) && (0 < param_3)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (0x14 < param_3) {
    param_3 = 0x14;
  }
  uVar14 = 0;
  local_58 = 0;
  uVar12 = 0;
  lVar16 = (longlong)param_3;
  uVar13 = uVar14;
  uVar2 = 0;
  if (0 < param_3) {
    while( true ) {
      local_58 = uVar2;
      uVar12 = (uint)uVar14;
      uVar4 = *(undefined4 *)(param_2 + uVar13 * 4);
      cVar3 = FUN_140332fe0(param_1,uVar4);
      if (cVar3 == '\0') break;
      plVar8 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,uVar4);
      if (plVar8 == (longlong *)0x0) break;
      cVar3 = FUN_1400ffc20(plVar8);
      if (cVar3 != '\0') {
        pIVar9 = theInstance();
        lVar11 = *(longlong *)(param_1 + 0x10);
        uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_FUSE_DISABLE");
        (**(code **)(lVar11 + 0x358))(param_1 + 0x10,uVar10);
        break;
      }
      cVar3 = FUN_1400ff650(plVar8,2);
      if ((cVar3 != '\0') || (cVar3 = FUN_1400ff650(plVar8,1), cVar3 != '\0')) {
        pIVar9 = theInstance();
        lVar11 = *(longlong *)(param_1 + 0x10);
        uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_FUSE_LOCK_DISABLE");
        (**(code **)(lVar11 + 0x358))(param_1 + 0x10,uVar10);
        break;
      }
      cVar3 = FUN_1400ffbe0(plVar8);
      if (cVar3 != '\0') {
        local_58 = 1;
      }
      uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
      cVar3 = FUN_1403380a0(param_1,uVar4);
      if ((cVar3 != '\0') || (cVar3 = FUN_14032ef10(plVar8), cVar3 != '\0')) break;
      uVar4 = FUN_1400fda10(plVar8,1,1);
      cVar3 = FUN_1400ff940(uVar4);
      if ((cVar3 != '\0') && (iVar5 = FUN_1401011d0(plVar8), iVar5 < 6)) {
        iVar5 = FUN_1400fda10(plVar8,5,1);
        iVar6 = FUN_1400fda10(plVar8,4,1);
        if (iVar5 / 2 < iVar6) break;
      }
      cVar3 = FUN_14032ed10(plVar8);
      if (cVar3 != '\0') break;
      iVar5 = FUN_1400fda10(plVar8,0xc,1);
      if (0 < iVar5) break;
      uVar13 = uVar13 + 1;
      uVar12 = uVar12 + 1;
      uVar14 = (ulonglong)uVar12;
      uVar2 = local_58;
      if (lVar16 <= (longlong)uVar13) break;
    }
  }
  uVar13 = 0;
  if ((int)uVar12 < param_3) {
    uVar10 = 0;
  }
  else {
    iVar5 = 0;
    bVar1 = true;
    uVar14 = uVar13;
    uVar15 = uVar13;
    if (0 < lVar16) {
      do {
        uVar12 = (uint)uVar13;
        uVar4 = *(undefined4 *)(param_2 + uVar14 * 4);
        cVar3 = FUN_140332fe0(param_1,uVar4);
        if (cVar3 != '\0') {
          plVar8 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar8 = (longlong *)0x0;
          }
          lVar11 = (**(code **)(*plVar8 + 0x60))(plVar8,uVar4);
          if (lVar11 != 0) {
            iVar5 = FUN_14030b8d0(DAT_140975bb0,lVar11);
            uVar15 = (ulonglong)(uint)((int)uVar15 + iVar5);
            iVar5 = FUN_1400fda10(lVar11,0xc,1);
            if ((int)uVar12 < iVar5) {
              uVar12 = FUN_1400fda10(lVar11,0xc,1);
            }
            if (0xc < (int)uVar12) {
              uVar12 = 0xc;
            }
            uVar13 = (ulonglong)uVar12;
            if (bVar1) {
              cVar3 = FUN_140340190(param_1,uVar4,1,1);
              if (cVar3 != '\0') {
                bVar1 = true;
                goto LAB_1403535bb;
              }
            }
            bVar1 = false;
          }
        }
LAB_1403535bb:
        iVar5 = (int)uVar15;
        uVar14 = uVar14 + 1;
      } while ((longlong)uVar14 < lVar16);
    }
    iVar6 = (int)uVar13;
    fVar18 = DAT_140715a84;
    fVar17 = DAT_1407556a8;
    if (iVar6 < 0) {
      uVar13 = (ulonglong)(uint)-iVar6;
    }
    while( true ) {
      if ((uVar13 & 1) != 0) {
        fVar18 = fVar18 * fVar17;
      }
      uVar12 = (uint)uVar13 >> 1;
      uVar13 = (ulonglong)uVar12;
      if (uVar12 == 0) break;
      fVar17 = fVar17 * fVar17;
    }
    if (iVar6 < 0) {
      fVar18 = DAT_140715a84 / fVar18;
    }
    if ((bVar1) && (iVar7 = tq::RandGet(10000), iVar7 <= (int)((float)iVar5 / fVar18))) {
      if (param_4 == 0) {
        FUN_14034a8d0(param_1,iVar6 + 0xb2391,local_58,1,1,0,1);
      }
      else {
        log_InlineLogERROR("invalid fuse type:%d");
      }
    }
    uVar10 = 1;
  }
  return uVar10;
}

// ==== CMsgFuse::ctor_or_dtor  @1404592c0  [high:vtable-assign]  (orig: FUN_1404592c0)
undefined8 * FUN_1404592c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgFuse::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgFuse::ctor_or_dtor  @140459310  [high:vtable-assign]  (orig: FUN_140459310)
void FUN_140459310(undefined8 *param_1)

{
  *param_1 = CMsgFuse::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgFuse::vfunc_1  @140459340  [high:rtti-vtable]  (orig: FUN_140459340)
ulonglong FUN_140459340(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x404);
}

// ==== CMsgFuse::ctor_or_dtor  @140459430  [high:vtable-assign]  (orig: FUN_140459430)
undefined8 * FUN_140459430(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgFuse::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgFuse::vfunc_3  @140459480  [high:rtti-vtable]  (orig: FUN_140459480)
void FUN_140459480(longlong param_1)

{
  ushort uVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 uVar11;
  longlong local_res8;
  
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar9 = (longlong *)
           (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x88))(*(longlong **)(lVar8 + 0x90),param_1)
  ;
  if (plVar9 != (longlong *)0x0) {
    plVar10 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar9[0x1e2];
    lVar8 = *plVar10;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
    (**(code **)(lVar8 + 0x108))(plVar10,uVar5,(int)lVar3,*puVar2);
    cVar4 = (**(code **)(plVar9[2] + 0x220))(plVar9 + 2);
    if ((cVar4 != '\0') &&
       ((uVar1 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 10), uVar1 == 0 ||
        ((longlong)(int)(uVar1 - 1) * 4 + 0x10U < 0x3fd)))) {
      local_res8 = 0;
      uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar10 = (longlong *)FUN_1400875f0(uVar11);
      plVar10 = (longlong *)(**(code **)(*plVar10 + 0x30))(plVar10);
      plVar10 = (longlong *)
                (**(code **)(*plVar10 + 0x40))
                          (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if ((plVar10 != (longlong *)0x0) &&
         (cVar4 = (**(code **)(*plVar10 + 0x298))(plVar10,0x1040,&local_res8), cVar4 != '\0')) {
        iVar6 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x168))(local_res8 + 0x10);
        iVar7 = (**(code **)(plVar9[2] + 0x168))(plVar9 + 2);
        if (iVar7 == iVar6) {
          lVar8 = *(longlong *)(param_1 + 0x428);
          FUN_1403531e0(plVar9,lVar8 + 0xc,*(undefined2 *)(lVar8 + 10),*(undefined2 *)(lVar8 + 8));
        }
      }
    }
  }
  return;
}

