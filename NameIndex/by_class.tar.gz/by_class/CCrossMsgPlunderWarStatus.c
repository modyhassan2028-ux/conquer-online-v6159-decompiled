// ==== CCrossMsgPlunderWarStatus::ctor_or_dtor  @14045c1d0  [high:vtable-assign]  (orig: FUN_14045c1d0)
undefined8 * FUN_14045c1d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgPlunderWarStatus::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgPlunderWarStatus::ctor_or_dtor  @14045c220  [high:vtable-assign]  (orig: FUN_14045c220)
void FUN_14045c220(undefined8 *param_1)

{
  *param_1 = CCrossMsgPlunderWarStatus::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgPlunderWarStatus::vfunc_1  @14045c250  [high:rtti-vtable]  (orig: FUN_14045c250)
ulonglong FUN_14045c250(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c69);
}

// ==== CCrossMsgPlunderWarStatus::vfunc_3  @14045c280  [high:rtti-vtable]  (orig: FUN_14045c280)
void FUN_14045c280(longlong param_1)

{
  short sVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)FUN_140087ed0();
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 == 0) {
                    /* WARNING: Could not recover jumptable at 0x00014045c33e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 0x688))(plVar2,*(undefined4 *)(*(short **)(param_1 + 0x428) + 2));
    return;
  }
  if (sVar1 == 1) {
                    /* WARNING: Could not recover jumptable at 0x00014045c328. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 0x690))(plVar2);
    return;
  }
  if (sVar1 != 2) {
    if (sVar1 != 3) {
                    /* WARNING: Could not recover jumptable at 0x00014045c2f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CCrossMsgPlunderWarInfo::Process wrong action[%u]");
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x00014045c304. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 0x6a0))(plVar2);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014045c316. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0x698))(plVar2);
  return;
}

// ==== CCrossMsgPlunderWarStatus::ctor_or_dtor  @14045c350  [high:vtable-assign]  (orig: FUN_14045c350)
undefined8 * FUN_14045c350(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgPlunderWarStatus::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

