// ==== CMsgBenefitsConfig::ctor_or_dtor  @1402c33d0  [high:vtable-assign]  (orig: FUN_1402c33d0)
undefined8 * FUN_1402c33d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgBenefitsConfig::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgBenefitsConfig::ctor_or_dtor  @1402c3420  [high:vtable-assign]  (orig: FUN_1402c3420)
void FUN_1402c3420(undefined8 *param_1)

{
  *param_1 = CMsgBenefitsConfig::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgBenefitsConfig::vfunc_1  @1402c3450  [high:rtti-vtable]  (orig: FUN_1402c3450)
ulonglong FUN_1402c3450(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xa98);
}

// ==== CMsgBenefitsConfig::vfunc_3  @1402c34b0  [high:rtti-vtable]  (orig: FUN_1402c34b0)
void FUN_1402c34b0(void)

{
  return;
}

// ==== CMsgBenefitsConfig::ctor_or_dtor  @1402c3540  [high:vtable-assign]  (orig: FUN_1402c3540)
undefined8 * FUN_1402c3540(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgBenefitsConfig::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

