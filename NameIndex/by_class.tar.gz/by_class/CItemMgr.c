// ==== CItemMgr::helper_1400075f0  @1400075f0  [medium:callgraph-r1]  (orig: FUN_1400075f0)
void FUN_1400075f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x1d) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x1d) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x1d);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x1d);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x1d);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x1d);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140007614. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CItemMgr::helper_140008940  @140008940  [medium:callgraph-r1]  (orig: FUN_140008940)
void FUN_140008940(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x1d) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CItemMgr::helper_1400089a0  @1400089a0  [medium:callgraph-r1]  (orig: FUN_1400089a0)
void FUN_1400089a0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x1d) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CItemMgr::helper_14000ab40  @14000ab40  [medium:callgraph-r0]  (orig: FUN_14000ab40)
undefined8 * FUN_14000ab40(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x1d) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400075f0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x1d) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x1c);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x1c);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_14000ad2c;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x1d);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x1d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x1d);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x1d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_14000ad2c:
  if (*(char *)((longlong)plVar5 + 0x1c) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x1c) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x1c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x1c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x1c) = 0;
            FUN_140008940(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
            if ((*(char *)(*plVar11 + 0x1c) != '\x01') || (*(char *)(plVar11[2] + 0x1c) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x1c) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x1c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x1c) = 0;
                FUN_1400089a0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x1c) = *(undefined1 *)((longlong)plVar10 + 0x1c);
              *(undefined1 *)((longlong)plVar10 + 0x1c) = 1;
              *(undefined1 *)(plVar11[2] + 0x1c) = 1;
              FUN_140008940(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x1c) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x1c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x1c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x1c) = 0;
            FUN_1400089a0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
            if ((*(char *)(plVar11[2] + 0x1c) != '\x01') || (*(char *)(*plVar11 + 0x1c) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x1c) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x1c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x1c) = 0;
                FUN_140008940(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x1c) = *(undefined1 *)((longlong)plVar10 + 0x1c);
              *(undefined1 *)((longlong)plVar10 + 0x1c) = 1;
              *(undefined1 *)(*plVar11 + 0x1c) = 1;
              FUN_1400089a0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x1c) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x1c) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CItemMgr::helper_140017960  @140017960  [medium:callgraph-r0]  (orig: FUN_140017960)
undefined8 * FUN_140017960(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  void *_Src;
  ulonglong uVar1;
  undefined8 uVar2;
  longlong lVar3;
  rsize_t _DstSize;
  
  _Src = (void *)((longlong)*(void **)(param_3 + 8) + 8);
  lVar3 = param_1[4] - (longlong)_Src >> 3;
  if (0 < lVar3) {
    _DstSize = lVar3 << 3;
    memmove_s(*(void **)(param_3 + 8),_DstSize,_Src,_DstSize);
  }
  param_1[4] = param_1[4] + -8;
  uVar1 = *(ulonglong *)(param_3 + 8);
  *param_2 = 0;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  uVar2 = *param_1;
  param_2[1] = uVar1;
  *param_2 = uVar2;
  return param_2;
}

// ==== CItemMgr::helper_140087e80  @140087e80  [medium:callgraph-r0]  (orig: FUN_140087e80)
longlong FUN_140087e80(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975bf8;
  if (DAT_140975bf8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CItemMgr::helper_14009ac40  @14009ac40  [medium:callgraph-r0]  (orig: FUN_14009ac40)
void FUN_14009ac40(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x21);
  while (cVar1 == '\0') {
    FUN_14009ac40(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  return;
}

// ==== CItemMgr::helper_1400a4100  @1400a4100  [medium:callgraph-r0]  (orig: FUN_1400a4100)
longlong * FUN_1400a4100(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14009f560(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14009f1a0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CItemMgr::helper_1400fd7b0  @1400fd7b0  [medium:callgraph-r1]  (orig: FUN_1400fd7b0)
longlong FUN_1400fd7b0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x1e8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CItemMgr::helper_1400fd990  @1400fd990  [medium:callgraph-r1]  (orig: FUN_1400fd990)
int FUN_1400fd990(void)

{
  __time32_t _Var1;
  __time32_t _Var2;
  tm local_38;
  
  local_38.tm_year = 0x6b;
  local_38.tm_mon = 0;
  local_38.tm_mday = 1;
  local_38.tm_sec = 0;
  local_38.tm_min = 0;
  local_38.tm_hour = 0;
  local_38.tm_wday = 0;
  local_38.tm_yday = 0;
  local_38.tm_isdst = 0;
  _Var1 = _mktime32(&local_38);
  _Var2 = _time32((__time32_t *)0x0);
  return (_Var2 - _Var1) / 0xe10;
}

// ==== CItemMgr::helper_1400fe310  @1400fe310  [medium:callgraph-r0]  (orig: FUN_1400fe310)
undefined8 FUN_1400fe310(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x18) == 0) {
    return 0;
  }
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,0x27);
                    /* WARNING: Could not recover jumptable at 0x0001400fe33d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  return uVar2;
}

// ==== CItemMgr::helper_1400fe350  @1400fe350  [medium:callgraph-r0]  (orig: FUN_1400fe350)
void FUN_1400fe350(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                     (*(longlong **)(param_1 + 0x10),0x18);
                    /* WARNING: Could not recover jumptable at 0x0001400fe36d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return;
}

// ==== CItemMgr::helper_1400fe600  @1400fe600  [medium:callgraph-r1]  (orig: FUN_1400fe600)
longlong FUN_1400fe600(int param_1,char param_2)

{
  tm *ptVar1;
  longlong lVar2;
  longlong lVar3;
  __time32_t local_res18 [4];
  
  lVar3 = 0;
  local_res18[0] = 0;
  _time32(local_res18);
  ptVar1 = _localtime32(local_res18);
  if (ptVar1 != (tm *)0x0) {
    if (param_2 != '\0') {
      lVar3 = (longlong)
              (((((ptVar1->tm_year % 100) * 100 + 1 + ptVar1->tm_mon) * 100 + ptVar1->tm_mday) * 100
               + ptVar1->tm_hour) * 100 + ptVar1->tm_min);
    }
    local_res18[0] = local_res18[0] + param_1;
    ptVar1 = _localtime32(local_res18);
    if (ptVar1 != (tm *)0x0) {
      lVar2 = (longlong)
              (((((ptVar1->tm_year % 100) * 100 + 1 + ptVar1->tm_mon) * 100 + ptVar1->tm_mday) * 100
               + ptVar1->tm_hour) * 100 + ptVar1->tm_min);
      if ((param_2 != '\0') && (lVar3 == lVar2)) {
        lVar2 = lVar2 + 1;
      }
      return lVar2;
    }
  }
  return 0;
}

// ==== CItemMgr::helper_1400fee00  @1400fee00  [medium:callgraph-r0]  (orig: FUN_1400fee00)
int FUN_1400fee00(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return (iVar1 % 1000) / 10;
}

// ==== CItemMgr::helper_140100c10  @140100c10  [medium:callgraph-r0]  (orig: FUN_140100c10)
undefined4 FUN_140100c10(longlong param_1)

{
  return *(undefined4 *)(param_1 + 100);
}

// ==== CItemMgr::helper_1401012b0  @1401012b0  [medium:callgraph-r0]  (orig: FUN_1401012b0)
void FUN_1401012b0(__uint64 param_1)

{
  if ((DAT_140975cf0 & 1) == 0) {
    DAT_140975cf0 = DAT_140975cf0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ce8,"CItem");
    atexit((_func_5014 *)&LAB_1406d66c0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140101305. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975ce8,param_1);
  return;
}

// ==== CItemMgr::helper_140102550  @140102550  [medium:callgraph-r0]  (orig: FUN_140102550)
ulonglong FUN_140102550(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  ulonglong uVar5;
  undefined1 uVar6;
  
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  uVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
  uVar5 = FUN_1400ff680(uVar1);
  iVar3 = (int)uVar5;
  if ((((iVar3 < 1) || (8 < iVar3)) && (iVar3 != 0xc)) &&
     (((iVar3 != 0xd && (iVar3 != 0xe)) && ((iVar3 != 0x15 && (iVar3 != 0x16)))))) {
    return uVar5 & 0xffffffffffffff00;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  iVar3 = (iVar2 % 1000000) / 1000;
  uVar5 = (ulonglong)(uint)-(iVar2 % 1000000 >> 0x1f);
  uVar6 = 0;
  if (iVar3 < 0x89) {
    if (iVar3 < 0x85) {
      uVar5 = 0;
      switch(iVar3) {
      case 0x6f:
      case 0x70:
      case 0x71:
      case 0x72:
      case 0x75:
      case 0x76:
      case 0x7b:
      case 0x82:
      case 0x83:
        break;
      default:
        goto switchD_140102631_caseD_73;
      }
    }
  }
  else if (iVar3 < 0x95) {
    if (iVar3 != 0x94) {
      if (iVar3 < 0x8a) goto switchD_140102631_caseD_73;
      if (0x8b < iVar3) {
        if (iVar3 < 0x8d) goto switchD_140102631_caseD_73;
        if (0x91 < iVar3) {
          return 0;
        }
      }
    }
  }
  else if (iVar3 != 900) goto switchD_140102631_caseD_73;
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
  uVar5 = (longlong)(iVar3 % 1000) * 0x66666667 & 0xffffffff;
  if (8 < (iVar3 % 1000) / 10) {
    uVar6 = 1;
  }
switchD_140102631_caseD_73:
  return CONCAT71((int7)(uVar5 >> 8),uVar6);
}

// ==== CItemMgr::helper_140103050  @140103050  [medium:callgraph-r1]  (orig: FUN_140103050)
void FUN_140103050(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  *(undefined8 *)(param_1 + 0x20) = 0;
  lVar2 = FUN_140008520(0xe);
  plVar3 = *(longlong **)(lVar2 + 0x158);
  if (*(longlong **)(lVar2 + 0x158) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  iVar1 = FUN_14026ab70(plVar3,param_1);
  if (iVar1 != 0) {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    lVar2 = (**(code **)(*plVar3 + 0x70))(plVar3,iVar1);
    *(longlong *)(param_1 + 0x20) = lVar2;
    if (lVar2 == 0) {
      log_InlineLogDBERROR("table:cq_itemtype, not found item limit type %u");
    }
    return;
  }
  *(undefined8 *)(param_1 + 0x20) = 0;
  return;
}

// ==== CItemMgr::helper_140103140  @140103140  [medium:callgraph-r1]  (orig: FUN_140103140)
void FUN_140103140(longlong param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  
  *(undefined8 *)(param_1 + 0x30) = 0;
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
  if (iVar2 / 10 != 73000) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                       (*(longlong **)(param_1 + 0x10),0xc);
    iVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (3 < iVar2) {
      if (*(longlong *)(param_1 + 0x20) == 0) {
        plVar4 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),1);
        uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
      }
      else {
        plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x20) + 8);
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,0);
        uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
      }
      lVar5 = FUN_140008520(0xe);
      lVar5 = *(longlong *)(lVar5 + 0x158);
      if (lVar5 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar5 = 0;
      }
      cVar1 = FUN_14026b610(lVar5,uVar3);
      if (cVar1 == '\0') {
        plVar4 = (longlong *)FUN_140087d40();
        lVar5 = (**(code **)(*plVar4 + 0x78))(plVar4,uVar3,4);
        *(longlong *)(param_1 + 0x30) = lVar5;
        if (lVar5 == 0) {
          log_InlineLogDBERROR
                    (
                    "table:cq_itemaddition, Can\'t find item addtion info of limit type[%u] level[%d]"
                    );
        }
      }
    }
  }
  return;
}

// ==== CItemMgr::helper_140103820  @140103820  [medium:callgraph-r0]  (orig: FUN_140103820)
undefined8
FUN_140103820(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if ((DAT_140975cf0 & 1) == 0) {
    DAT_140975cf0 = DAT_140975cf0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ce8,"CItem");
    atexit((_func_5014 *)&LAB_1406d66c0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975ce8,0x70);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1400fd8d0(pvVar1,param_1,param_3,param_4,uVar2);
  }
  return uVar2;
}

// ==== CItemMgr::helper_140103f40  @140103f40  [medium:callgraph-r0]  (orig: FUN_140103f40)
undefined8 FUN_140103f40(longlong *param_1,char param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  uVar2 = (**(code **)(*param_1 + 8))();
  if ((4099999999 < uVar2) && (*(int *)((longlong)param_1 + 100) != 0)) {
    return 1;
  }
  if ((longlong *)param_1[8] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[8] + 0x40))();
  }
  if ((longlong *)param_1[9] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[9] + 0x40))();
  }
  if ((longlong *)param_1[10] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[10] + 0x40))();
  }
  if ((longlong *)param_1[0xb] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xb] + 0x40))();
  }
  if (param_2 != '\0') {
    plVar4 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    cVar1 = FUN_140102780(uVar3);
    if (cVar1 == '\0') {
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      uVar5 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      uVar5 = FUN_1400fd800(uVar5);
      cVar1 = FUN_14028cec0(uVar5,uVar3,param_1[2]);
      goto LAB_14010404e;
    }
  }
  lVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
  lVar6 = *(longlong *)(lVar6 + 0x210);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar6 = 0;
  }
  cVar1 = FUN_14028dc40(lVar6,2,param_1 + 2);
LAB_14010404e:
  if (cVar1 != '\0') {
    *(undefined1 *)(param_1 + 0xc) = 0;
    return 1;
  }
                    /* WARNING: Could not recover jumptable at 0x000140104076. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar5 = (**(code **)(*(longlong *)param_1[2] + 0x40))((longlong *)param_1[2],0);
  return uVar5;
}

// ==== CItemMgr::helper_1401058e0  @1401058e0  [medium:callgraph-r0]  (orig: FUN_1401058e0)
int FUN_1401058e0(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  int iVar4;
  int aiStack_3c [13];
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  aiStack_3c[1] = 1;
  aiStack_3c[2] = 2;
  aiStack_3c[3] = 5;
  aiStack_3c[4] = 0xf;
  aiStack_3c[5] = 0x1e;
  aiStack_3c[6] = 0x5a;
  aiStack_3c[7] = 0x10e;
  aiStack_3c[8] = 600;
  aiStack_3c[9] = 0x4b0;
  aiStack_3c[10] = 0x4b0;
  aiStack_3c[0xb] = 0x4b0;
  aiStack_3c[0xc] = 0x4b0;
  iVar4 = 0;
  if (iVar2 % 10 == 9) {
    iVar4 = 0x32;
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),0xc)
  ;
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar2 - 1U < 0xc) {
    iVar4 = iVar4 + aiStack_3c[iVar2];
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar2 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),9)
    ;
    iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar2 == 0) {
      cVar1 = FUN_1400f8840(param_1);
      if (cVar1 == '\0') {
        iVar4 = iVar4 + 0x96;
      }
      else {
        iVar4 = iVar4 + 10;
      }
    }
    else {
      cVar1 = FUN_1400f8840(param_1);
      if (cVar1 == '\0') {
        iVar4 = iVar4 + 500;
      }
      else {
        iVar4 = iVar4 + 100;
      }
    }
  }
  aiStack_3c[1] = 0x1e;
  aiStack_3c[2] = 0x5a;
  aiStack_3c[3] = 200;
  aiStack_3c[4] = 400;
  aiStack_3c[5] = 600;
  aiStack_3c[6] = 800;
  if (*(longlong *)(param_1 + 0x48) != 0) {
    iVar2 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x30))(*(longlong **)(param_1 + 0x48),4);
    if (iVar2 - 1U < 6) {
      iVar4 = iVar4 + aiStack_3c[iVar2];
    }
  }
  aiStack_3c[1] = 0x1e;
  aiStack_3c[2] = 0x5a;
  aiStack_3c[3] = 0xb4;
  aiStack_3c[4] = 300;
  aiStack_3c[5] = 0x1c2;
  aiStack_3c[6] = 600;
  aiStack_3c[7] = 800;
  if (*(longlong *)(param_1 + 0x58) != 0) {
    iVar2 = (**(code **)(**(longlong **)(param_1 + 0x58) + 0x30))(*(longlong **)(param_1 + 0x58),4);
    if (iVar2 - 1U < 7) {
      iVar4 = iVar4 + aiStack_3c[iVar2];
    }
  }
  iVar2 = 10;
  if (10 < iVar4) {
    iVar2 = iVar4;
  }
  return iVar2;
}

// ==== CItemMgr::helper_140106510  @140106510  [medium:callgraph-r0]  (orig: FUN_140106510)
undefined8 FUN_140106510(longlong *param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  
  if (param_1[2] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_1[3] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  param_1[2] = param_2;
  plVar7 = (longlong *)FUN_140087d40();
  plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
  uVar2 = (**(code **)(*plVar8 + 0x48))(plVar8);
  lVar9 = (**(code **)(*plVar7 + 0x70))(plVar7,uVar2);
  param_1[3] = lVar9;
  if (lVar9 == 0) {
    plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
    (**(code **)(*plVar7 + 0x48))(plVar7);
    log_InlineLogERROR(&DAT_140708b38);
    uVar10 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
    uVar10 = FUN_1400fd800(uVar10);
    cVar1 = FUN_14028dc40(uVar10,2,param_1 + 2);
    if (cVar1 != '\0') {
      *(undefined1 *)(param_1 + 0xc) = 0;
      return 0;
    }
    (**(code **)(*(longlong *)param_1[2] + 0x40))((longlong *)param_1[2],0);
    (*(code *)**(undefined8 **)param_1[2])((undefined8 *)param_1[2],1);
    param_1[2] = 0;
    return 0;
  }
  plVar7 = (longlong *)FUN_140087d40();
  plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  uVar2 = (**(code **)(*plVar8 + 0x48))(plVar8);
  plVar8 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
  uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
  lVar9 = (**(code **)(*plVar7 + 0x78))(plVar7,uVar3,uVar2);
  param_1[5] = lVar9;
  plVar7 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x12);
  iVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
  if (0 < iVar4) {
    iVar5 = FUN_1400fd990();
    if (0x47 < iVar5 - iVar4) {
      plVar7 = (longlong *)
               (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x12);
      (**(code **)(*plVar7 + 0xb0))(plVar7,0);
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      if ((uVar6 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
        (**(code **)(*(longlong *)param_1[2] + 0x38))((longlong *)param_1[2],0);
      }
      else {
        cVar1 = FUN_1401032b0(param_1,0x12);
        if (cVar1 != '\0') {
          FUN_1401033b0(param_1);
          *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
        }
      }
    }
  }
  FUN_140103050(param_1);
  FUN_140103140(param_1);
  return 1;
}

// ==== CItemMgr::helper_1401067c0  @1401067c0  [medium:callgraph-r1]  (orig: FUN_1401067c0)
void FUN_1401067c0(longlong *param_1)

{
  char cVar1;
  undefined4 uVar2;
  uint uVar3;
  longlong *plVar4;
  
  uVar2 = FUN_1400fe190();
  plVar4 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0x11);
  (**(code **)(*plVar4 + 0xb0))(plVar4,uVar2);
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  if ((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) {
    cVar1 = FUN_1401032b0(param_1,0x11);
    if (cVar1 != '\0') {
      *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
    }
  }
  return;
}

// ==== CItemMgr::helper_140107480  @140107480  [medium:callgraph-r0]  (orig: FUN_140107480)
undefined8 FUN_140107480(longlong *param_1,int param_2,longlong param_3,char param_4,int param_5)

{
  char cVar1;
  ushort uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  
  if (param_1[2] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_1[3] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((param_4 == '\0') || (param_2 != 0)) {
    plVar9 = (longlong *)InstanceGet();
    lVar8 = (**(code **)(*plVar9 + 0x20))(plVar9,"cq_item");
    param_1[2] = lVar8;
    if (param_2 != 0) {
      uVar7 = FUN_140087e80();
      cVar1 = FUN_1401d28f0(uVar7,*(undefined4 *)(param_3 + 4));
      *(char *)((longlong)param_1 + 0x6e) = cVar1;
      if (cVar1 == '\0') {
        return 0;
      }
      *(int *)((longlong)param_1 + 100) = param_2;
      uVar7 = FUN_140087d40();
      iVar3 = FUN_1403254f0(uVar7);
      if (iVar3 == 0) {
        return 0;
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0);
      (**(code **)(*plVar9 + 0xb0))(plVar9,iVar3);
      FUN_1401067c0(param_1);
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      if (((4099999999 < uVar6) && (*(int *)((longlong)param_1 + 100) != 0)) &&
         (cVar1 = FUN_1401032b0(param_1,0), cVar1 != '\0')) {
        *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
      }
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      uVar7 = FUN_1400fd7b0(uVar7);
      cVar1 = FUN_140258720(uVar7,*(undefined4 *)(param_3 + 4));
      *(bool *)((longlong)param_1 + 0x6c) = cVar1 != '\0';
    }
  }
  else if (param_5 == 0) {
    uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
    uVar7 = FUN_1400fd800(uVar7);
    lVar8 = FUN_14028deb0(uVar7,2);
    param_1[2] = lVar8;
  }
  else {
    uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
    uVar7 = FUN_1400fd800(uVar7);
    lVar8 = FUN_14028cd80(uVar7,param_5);
    param_1[2] = lVar8;
    if (lVar8 == 0) {
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
      uVar7 = FUN_1400fd800(uVar7);
      lVar8 = FUN_14028deb0(uVar7,2);
      param_1[2] = lVar8;
    }
  }
  plVar9 = (longlong *)param_1[2];
  if (plVar9 == (longlong *)0x0) {
    log_InlineLogERROR("get cq_item record err: idItem=%u,idType=%u,owner=%u,player=%u");
    return 0;
  }
  uVar4 = *(undefined4 *)(param_3 + 4);
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,1);
  (**(code **)(*plVar9 + 0xb0))(plVar9,uVar4);
  FUN_1401067c0(param_1);
  plVar9 = (longlong *)FUN_140087f50();
  plVar10 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
  uVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
  lVar8 = *plVar9;
  uVar5 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar8 + 0x60))(plVar9,uVar4,uVar5);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  if (((4099999999 < uVar6) && (*(int *)((longlong)param_1 + 100) != 0)) &&
     (cVar1 = FUN_1401032b0(param_1,1), cVar1 != '\0')) {
    *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
  }
  uVar4 = *(undefined4 *)(param_3 + 8);
  plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],2);
  (**(code **)(*plVar9 + 0xb0))(plVar9,uVar4);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  if (((4099999999 < uVar6) && (*(int *)((longlong)param_1 + 100) != 0)) &&
     (cVar1 = FUN_1401032b0(param_1,2), cVar1 != '\0')) {
    *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
  }
  FUN_140104140(param_1,3,*(undefined4 *)(param_3 + 0xc));
  FUN_140104140(param_1,4,*(undefined4 *)(param_3 + 0x10));
  FUN_140104140(param_1,5,*(undefined4 *)(param_3 + 0x14));
  FUN_140104140(param_1,6,*(undefined4 *)(param_3 + 0x18));
  FUN_140104140(param_1,7,*(undefined4 *)(param_3 + 0x1c));
  FUN_140104140(param_1,0xd,*(undefined4 *)(param_3 + 0x20));
  FUN_140104140(param_1,8,*(undefined4 *)(param_3 + 0x24));
  FUN_140104140(param_1,9,*(undefined4 *)(param_3 + 0x28));
  FUN_140104140(param_1,10,*(undefined4 *)(param_3 + 0x2c));
  uVar4 = *(undefined4 *)(param_3 + 0x30);
  plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xb);
  (**(code **)(*plVar9 + 0xb0))(plVar9,uVar4);
  FUN_1401067c0(param_1);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  if (((4099999999 < uVar6) && (*(int *)((longlong)param_1 + 100) != 0)) &&
     (cVar1 = FUN_1401032b0(param_1,0xb), cVar1 != '\0')) {
    *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
  }
  uVar4 = *(undefined4 *)(param_3 + 0x34);
  plVar9 = (longlong *)(**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
  (**(code **)(*plVar9 + 0xb0))(plVar9,uVar4);
  FUN_1401067c0(param_1);
  plVar9 = (longlong *)FUN_140087f50();
  lVar8 = *plVar9;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  uVar5 = FUN_1400fda10(param_1,3,1);
  (**(code **)(lVar8 + 0x60))(plVar9,uVar5,uVar4);
  plVar9 = (longlong *)FUN_140087d40();
  lVar8 = *plVar9;
  uVar4 = FUN_1400fda10(param_1,0xc,1);
  uVar5 = FUN_1400fda10(param_1,1,1);
  lVar8 = (**(code **)(lVar8 + 0x78))(plVar9,uVar5,uVar4);
  param_1[5] = lVar8;
  FUN_140103140(param_1);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  if (((4099999999 < uVar6) && (*(int *)((longlong)param_1 + 100) != 0)) &&
     (cVar1 = FUN_1401032b0(param_1,0xc), cVar1 != '\0')) {
    *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
  }
  FUN_140104140(param_1,0xe,*(undefined4 *)(param_3 + 0x38));
  uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
  cVar1 = FUN_14008a710(uVar7);
  if (cVar1 == '\0') {
    FUN_140104140(param_1,0x16,*(undefined1 *)(param_3 + 0x3c));
  }
  else {
    FUN_140104140(param_1,0x16,0);
  }
  FUN_140104140(param_1,0xf,*(undefined4 *)(param_3 + 0x40));
  FUN_140104140(param_1,0x10,*(undefined4 *)(param_3 + 0x44));
  FUN_140104140(param_1,0x12,*(undefined2 *)(param_3 + 0x48));
  FUN_140104140(param_1,0x13,*(undefined2 *)(param_3 + 0x4a));
  FUN_140104140(param_1,0x15,*(undefined4 *)(param_3 + 0x50));
  FUN_140104140(param_1,0x19,*(undefined4 *)(param_3 + 0x5c));
  if (*(int *)(param_3 + 0x58) == 0) {
    FUN_140106830(param_1,0x18,0);
  }
  else {
    uVar7 = FUN_1400fe600(*(int *)(param_3 + 0x58),0);
    FUN_140106830(param_1,0x18,uVar7);
  }
  uVar2 = *(ushort *)(param_3 + 0x4c);
  if (uVar2 < 2) {
    uVar2 = 3;
  }
  FUN_140104140(param_1,0x14,uVar2);
  FUN_140104140(param_1,0x1a,*(undefined4 *)(param_3 + 0x60));
  if (*(int *)(param_3 + 0x60) < 1) {
    log_InlineLogERROR("CItem::Create. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d");
  }
  if (param_4 == '\0') {
    (**(code **)(*(longlong *)param_1[2] + 0x58))();
  }
  plVar9 = (longlong *)FUN_140087d40();
  lVar8 = *plVar9;
  uVar4 = FUN_1400fda10(param_1,1,1);
  lVar8 = (**(code **)(lVar8 + 0x70))(plVar9,uVar4);
  param_1[3] = lVar8;
  if (lVar8 == 0) {
    FUN_1400fda10(param_1,1,1);
    log_InlineLogERROR("CItem::Create found no record for cq_itemtype.id=%u @%s,%d");
    return 0;
  }
  FUN_1401067c0(param_1);
  plVar9 = (longlong *)FUN_140087d40();
  lVar8 = (**(code **)(*plVar9 + 0x78))
                    (plVar9,*(undefined4 *)(param_3 + 4),*(undefined4 *)(param_3 + 0x34));
  param_1[5] = lVar8;
  if (param_2 == 0) {
    FUN_140103050(param_1);
    FUN_140103140(param_1);
    FUN_140104080(param_1,1);
  }
  else {
    *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
  }
  return 1;
}

// ==== CItemMgr::helper_140107ba0  @140107ba0  [medium:callgraph-r0]  (orig: FUN_140107ba0)
undefined8
FUN_140107ba0(longlong *param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  if (param_1[2] == 0) {
    if (param_1[3] != 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    if (param_2 != 0) {
      plVar6 = (longlong *)FUN_140087d40();
      lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,param_2);
      param_1[3] = lVar7;
      if (lVar7 == 0) {
        log_InlineLogDBERROR
                  (
                  "table:cq_itemtype, CItem::Create(), can not find itemtype(%u), maybe cq_itemtype not config."
                  );
        return 0;
      }
      if (param_3 == 0) {
        uVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
        uVar8 = FUN_1400fd800(uVar8);
        lVar7 = FUN_14028deb0(uVar8,2);
        param_1[2] = lVar7;
        if (lVar7 != 0) {
LAB_140107d87:
          plVar6 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],1);
          (**(code **)(*plVar6 + 0xb0))(plVar6,param_2);
          FUN_1401067c0(param_1);
          plVar6 = (longlong *)FUN_140087f50();
          plVar9 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],3);
          uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
          lVar7 = *plVar6;
          uVar5 = (**(code **)(*param_1 + 8))(param_1);
          (**(code **)(lVar7 + 0x60))(plVar6,uVar4,uVar5);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          if (((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) &&
             (cVar1 = FUN_1401032b0(param_1,1), cVar1 != '\0')) {
            *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
          }
          plVar6 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],2);
          (**(code **)(*plVar6 + 0xb0))(plVar6,param_4);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          if (((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) &&
             (cVar1 = FUN_1401032b0(param_1,2), cVar1 != '\0')) {
            *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
          }
          FUN_140104140(param_1,3,param_4);
          uVar4 = FUN_1400fda10(param_1,0x79,1);
          FUN_140104140(param_1,4,uVar4);
          uVar4 = FUN_1400fda10(param_1,0x7a,1);
          FUN_140104140(param_1,5,uVar4);
          uVar4 = FUN_1400fda10(param_1,0x7b,1);
          FUN_140104140(param_1,6,uVar4);
          FUN_140104140(param_1,7,param_5);
          uVar4 = FUN_1400fda10(param_1,0x7c,1);
          FUN_140104140(param_1,8,uVar4);
          uVar4 = FUN_1400fda10(param_1,0x7d,1);
          FUN_140104140(param_1,9,uVar4);
          uVar4 = FUN_1400fda10(param_1,0x7e,1);
          FUN_140104140(param_1,10,uVar4);
          uVar4 = FUN_1400fda10(param_1,0x7f,1);
          plVar6 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xb);
          (**(code **)(*plVar6 + 0xb0))(plVar6,uVar4);
          FUN_1401067c0(param_1);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          if (((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) &&
             (cVar1 = FUN_1401032b0(param_1,0xb), cVar1 != '\0')) {
            *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
          }
          uVar4 = FUN_1400fda10(param_1,0x80,1);
          plVar6 = (longlong *)
                   (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0xc);
          (**(code **)(*plVar6 + 0xb0))(plVar6,uVar4);
          FUN_1401067c0(param_1);
          plVar6 = (longlong *)FUN_140087f50();
          lVar7 = *plVar6;
          uVar4 = (**(code **)(*param_1 + 8))(param_1);
          uVar5 = FUN_1400fda10(param_1,3,1);
          (**(code **)(lVar7 + 0x60))(plVar6,uVar5,uVar4);
          plVar6 = (longlong *)FUN_140087d40();
          lVar7 = *plVar6;
          uVar4 = FUN_1400fda10(param_1,0xc,1);
          uVar5 = FUN_1400fda10(param_1,1,1);
          lVar7 = (**(code **)(lVar7 + 0x78))(plVar6,uVar5,uVar4);
          param_1[5] = lVar7;
          FUN_140103140(param_1);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          if (((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) &&
             (cVar1 = FUN_1401032b0(param_1,0xc), cVar1 != '\0')) {
            *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
          }
          FUN_140104140(param_1,0x14,3);
          FUN_140104140(param_1,0x1a,1);
          FUN_140104140(param_1,0x19,0);
          FUN_140106830(param_1,0x18,0);
          FUN_1401067c0(param_1);
          plVar6 = (longlong *)FUN_140087d40();
          lVar7 = *plVar6;
          uVar4 = FUN_1400fda10(param_1,0xc,1);
          lVar7 = (**(code **)(lVar7 + 0x78))(plVar6,param_2,uVar4);
          param_1[5] = lVar7;
          if (param_3 == 0) {
            FUN_140104080(param_1,1);
            FUN_140103050(param_1);
            FUN_140103140(param_1);
          }
          else {
            *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
          }
          return 1;
        }
        log_InlineLogERROR("get cq_item rec err:idType=%u, user=%u");
      }
      else {
        uVar8 = FUN_140087e80();
        cVar1 = FUN_1401d28f0(uVar8,param_2);
        *(char *)((longlong)param_1 + 0x6e) = cVar1;
        if (cVar1 != '\0') {
          plVar6 = (longlong *)InstanceGet();
          lVar7 = (**(code **)(*plVar6 + 0x20))(plVar6,"cq_item");
          param_1[2] = lVar7;
          if (lVar7 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            return 0;
          }
          *(int *)((longlong)param_1 + 100) = param_3;
          uVar8 = FUN_140087d40();
          iVar2 = FUN_1403254f0(uVar8);
          if (iVar2 != 0) {
            plVar6 = (longlong *)
                     (**(code **)(*(longlong *)param_1[2] + 0x10))((longlong *)param_1[2],0);
            (**(code **)(*plVar6 + 0xb0))(plVar6,iVar2);
            FUN_1401067c0(param_1);
            uVar3 = (**(code **)(*param_1 + 8))(param_1);
            if (((4099999999 < uVar3) && (*(int *)((longlong)param_1 + 100) != 0)) &&
               (cVar1 = FUN_1401032b0(param_1,0), cVar1 != '\0')) {
              *(undefined1 *)((longlong)param_1 + 0x6d) = 1;
            }
            uVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x3c));
            uVar8 = FUN_1400fd7b0(uVar8);
            cVar1 = FUN_140258720(uVar8,param_2);
            *(bool *)((longlong)param_1 + 0x6c) = cVar1 != '\0';
            goto LAB_140107d87;
          }
        }
      }
      return 0;
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CItemMgr::helper_1401ad8d0  @1401ad8d0  [medium:callgraph-r0]  (orig: FUN_1401ad8d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ad8d0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined1 auStack_8e8 [32];
  undefined4 local_8c8;
  undefined4 local_8c0;
  undefined4 local_8b8;
  undefined4 local_8b0;
  undefined4 local_8a8;
  undefined8 local_898;
  undefined1 local_888 [1072];
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_898 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  cVar1 = FUN_140333220();
  if (cVar1 != '\0') {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_8c8 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar5 = (**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (lVar5 != 0) goto LAB_1401ad9a9;
  }
  cVar1 = FUN_140332fe0(param_1,param_2);
  if (cVar1 == '\0') {
    return;
  }
  plVar6 = (longlong *)FUN_140087d40();
  lVar5 = (**(code **)(*plVar6 + 0x60))(plVar6,param_2);
  if (lVar5 == 0) {
    return;
  }
  uVar2 = FUN_1400fda10(lVar5,1,1);
  cVar1 = FUN_1400ff940(uVar2);
  if (cVar1 == '\0') {
    return;
  }
LAB_1401ad9a9:
  (**(code **)(*param_1 + 8))(param_1);
  plVar6 = (longlong *)FUN_140100070(lVar5);
  if (plVar6 != (longlong *)0x0) {
    iVar3 = (**(code **)(*plVar6 + 0x30))(plVar6,3);
    FUN_1403b6000(local_458);
    local_8a8 = 0;
    local_8b0 = 0;
    local_8b8 = 0;
    local_8c0 = 0;
    local_8c8 = 0;
    iVar4 = FUN_1403b60f0(local_458,param_2,1,iVar3);
    if (iVar4 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_458);
    }
    if (iVar3 == 0x12d) {
      iVar3 = (**(code **)(*plVar6 + 0x10))(plVar6);
      iVar4 = (**(code **)(param_1[2] + 0x80))();
      FUN_1401a6420(param_1,0,iVar4 - iVar3,1);
    }
    FUN_14036fe70(local_888);
    iVar3 = FUN_1403702e0(local_888,param_1);
    if (iVar3 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_888);
    }
    FUN_14036fec0(local_888);
    FUN_1403b6050(local_458);
  }
  return;
}

// ==== CItemMgr::helper_1401d28f0  @1401d28f0  [medium:callgraph-r0]  (orig: FUN_1401d28f0)
undefined1 FUN_1401d28f0(undefined8 param_1,uint param_2)

{
  if ((((param_2 < 0xb19cc) || (0xb1a2f < param_2)) && (param_2 != 0xf4df8)) && (param_2 != 0xf51e0)
     ) {
    return 0;
  }
  return 1;
}

// ==== CItemMgr::helper_140258650  @140258650  [medium:callgraph-r2]  (orig: FUN_140258650)
longlong * FUN_140258650(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x1d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x1d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CItemMgr::helper_140258720  @140258720  [medium:callgraph-r1]  (orig: FUN_140258720)
bool FUN_140258720(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  longlong *plVar4;
  undefined4 local_res10 [2];
  undefined1 local_18 [16];
  
  local_res10[0] = param_2;
  cVar3 = FUN_140102710(param_2);
  if (cVar3 != '\0') {
    return true;
  }
  lVar1 = *(longlong *)(param_1 + 0x10);
  lVar2 = *(longlong *)(param_1 + 0x40);
  plVar4 = (longlong *)FUN_140258650((longlong *)(param_1 + 0x10),local_18,local_res10);
  if ((*plVar4 == 0) || (*plVar4 != lVar1)) {
    _invalid_parameter_noinfo();
  }
  return plVar4[1] != lVar2;
}

// ==== CItemMgr::helper_14026ab70  @14026ab70  [medium:callgraph-r2]  (orig: FUN_14026ab70)
int FUN_14026ab70(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong lVar11;
  uint local_res10 [2];
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar5 = FUN_1400fda10(param_2,1,1);
    cVar4 = FUN_1400ff940(uVar5);
    if (cVar4 != '\0') {
      iVar6 = FUN_1400fed80(param_2);
      uVar7 = FUN_1400fda10(param_2,1,1);
      puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
      cVar4 = *(char *)((longlong)puVar10 + 0x21);
      puVar3 = *(undefined8 **)(param_1 + 0x40);
      while (cVar4 == '\0') {
        if (*(int *)(puVar10 + 3) < iVar6) {
          puVar9 = (undefined8 *)puVar10[2];
          puVar10 = puVar3;
        }
        else {
          puVar9 = (undefined8 *)*puVar10;
        }
        puVar3 = puVar10;
        puVar10 = puVar9;
        cVar4 = *(char *)((longlong)puVar9 + 0x21);
      }
      puVar10 = *(undefined8 **)(param_1 + 0x40);
      local_40 = puVar3;
      local_48 = *(longlong *)(param_1 + 0x10);
      local_res10[0] = uVar7;
      if (*(longlong *)(param_1 + 0x10) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar3 == puVar10) || (iVar6 < *(int *)(puVar3 + 3))) {
        plVar8 = &local_38;
        local_30 = *(undefined8 *)(param_1 + 0x40);
        local_38 = *(longlong *)(param_1 + 0x10);
      }
      else {
        plVar8 = &local_48;
      }
      plVar1 = (longlong *)*plVar8;
      lVar11 = *(longlong *)(param_1 + 0x40);
      local_28 = plVar1;
      local_20 = plVar8[1];
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
        _invalid_parameter_noinfo();
      }
      lVar2 = local_20;
      if (local_20 != lVar11) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar1;
        }
        if (lVar2 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        iVar6 = *(int *)(lVar2 + 0x1c);
        if (iVar6 < (int)((uVar7 % 1000) / 10)) {
          lVar11 = *(longlong *)(param_1 + 0x50);
          lVar2 = *(longlong *)(param_1 + 0x80);
          plVar8 = (longlong *)FUN_140077480(param_1 + 0x50,&local_28,local_res10);
          if ((*plVar8 == 0) || (*plVar8 != lVar11)) {
            _invalid_parameter_noinfo();
          }
          if (plVar8[1] == lVar2) {
            return uVar7 + (((uVar7 / 1000) * 100 - uVar7 / 10) + iVar6) * 10;
          }
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CItemMgr::helper_14026b610  @14026b610  [medium:callgraph-r2]  (orig: FUN_14026b610)
bool FUN_14026b610(longlong param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x1d);
  puVar3 = *(undefined8 **)(param_1 + 0xc0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x1d);
  }
  puVar6 = *(undefined8 **)(param_1 + 0xc0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x90);
  if (*(longlong *)(param_1 + 0x90) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xc0);
    local_28 = *(longlong *)(param_1 + 0x90);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0xc0);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 0x90))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

// ==== CItemMgr::helper_14028cd80  @14028cd80  [medium:callgraph-r1]  (orig: FUN_14028cd80)
undefined8 FUN_14028cd80(longlong param_1,uint param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 0x150);
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x180))[1];
  cVar2 = *(char *)((longlong)puVar8 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x180);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x180);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x180);
    local_28 = *plVar1;
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  lVar10 = *(longlong *)(param_1 + 0x180);
  local_18 = plVar3;
  local_10 = plVar9[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 == lVar10) {
    uVar7 = 0;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar7 = *(undefined8 *)(lVar5 + 0x20);
    local_18 = (longlong *)*plVar9;
    local_10 = plVar9[1];
    FUN_14002d580(plVar1,&local_28,&local_18);
  }
  return uVar7;
}

// ==== CItemMgr::helper_14028cec0  @14028cec0  [medium:callgraph-r1]  (orig: FUN_14028cec0)
BADSPACEBASE * FUN_14028cec0(longlong param_1,uint param_2,longlong *param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  uint local_res10 [2];
  uint local_50;
  undefined4 uStack_4c;
  longlong *local_48;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  local_res10[0] = param_2;
  if (param_3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pItemRec",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\recordpoolmgr.cpp"
                       ,0x1df);
    register0x00000020 = (BADSPACEBASE *)0x0;
  }
  else if (param_2 != 0) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_40,"cq_item");
    lVar1 = *(longlong *)(param_1 + 0x80);
    lVar2 = *(longlong *)(param_1 + 0x50);
    plVar3 = (longlong *)FUN_14028bac0((longlong *)(param_1 + 0x50),&local_50,local_40);
    if ((lVar2 == 0) || (lVar2 != *plVar3)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = plVar3[1];
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_40);
    if (lVar1 == lVar2) {
      register0x00000020 = (BADSPACEBASE *)0x0;
    }
    else {
      plVar3 = (longlong *)(param_1 + 0x150);
      FUN_14002d940(plVar3,&local_50,local_res10);
      lVar1 = *(longlong *)(param_1 + 0x180);
      if ((CONCAT44(uStack_4c,local_50) == 0) || (CONCAT44(uStack_4c,local_50) != *plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (local_48 == (longlong *)lVar1) {
        (**(code **)(*param_3 + 0x78))(param_3);
        local_50 = param_2;
        local_48 = param_3;
        FUN_14002d3d0(plVar3,local_40,&local_50);
        register0x00000020 = (BADSPACEBASE *)0x1;
      }
      else {
        log_InlineLogERROR(&DAT_14073cae8,(ulonglong)param_2);
        register0x00000020 = (BADSPACEBASE *)0x0;
      }
    }
  }
  return register0x00000020;
}

// ==== CItemMgr::helper_1402a80a0  @1402a80a0  [medium:callgraph-r0]  (orig: FUN_1402a80a0)
undefined8 FUN_1402a80a0(longlong *param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)(**(code **)(*param_1 + 0x98))();
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001402a80c0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x38))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CItemMgr::helper_1402a9b20  @1402a9b20  [medium:callgraph-r2]  (orig: FUN_1402a9b20)
void FUN_1402a9b20(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402a9b20(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CItemMgr::helper_1402aa310  @1402aa310  [medium:callgraph-r1]  (orig: FUN_1402aa310)
void FUN_1402aa310(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402a9b20(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CItemMgr::helper_1402ae050  @1402ae050  [medium:callgraph-r0]  (orig: FUN_1402ae050)
longlong * FUN_1402ae050(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402aa310(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402ac730(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CItemMgr::helper_14031dc50  @14031dc50  [medium:callgraph-r0]  (orig: FUN_14031dc50)
longlong FUN_14031dc50(void)

{
  longlong *plVar1;
  
  if ((DAT_140976030 & 1) == 0) {
    DAT_140976030 = DAT_140976030 | 1;
    plVar1 = (longlong *)CurrentInstanceGet();
    DAT_140976028 = (**(code **)(*plVar1 + 0x20))(plVar1,0x17);
  }
  if (DAT_140976028 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return DAT_140976028;
}

// ==== CItemMgr::vfunc_14  @14031dcd0  [high:rtti-vtable]  (orig: FUN_14031dcd0)
void FUN_14031dcd0(longlong param_1)

{
  FUN_1404c45c0(*(undefined8 *)(param_1 + 0x118));
  return;
}

// ==== CItemMgr::vfunc_15  @14031dce0  [high:rtti-vtable]  (orig: FUN_14031dce0)
void FUN_14031dce0(longlong param_1)

{
  FUN_1404c6850(*(undefined8 *)(param_1 + 0x120));
  return;
}

// ==== CItemMgr::vfunc_16  @14031dcf0  [high:rtti-vtable]  (orig: FUN_14031dcf0)
void FUN_14031dcf0(longlong param_1)

{
  FUN_1404c7e30(*(undefined8 *)(param_1 + 0x128));
  return;
}

// ==== CItemMgr::vfunc_17  @14031dd00  [high:rtti-vtable]  (orig: FUN_14031dd00)
void FUN_14031dd00(longlong param_1)

{
  FUN_1404c8070(*(undefined8 *)(param_1 + 0x128));
  return;
}

// ==== CItemMgr::vfunc_18  @14031dd10  [high:rtti-vtable]  (orig: FUN_14031dd10)
void FUN_14031dd10(longlong param_1)

{
  FUN_1404c8440(*(undefined8 *)(param_1 + 0x128));
  return;
}

// ==== CItemMgr::vfunc_27  @14031dd30  [high:rtti-vtable]  (orig: FUN_14031dd30)
bool FUN_14031dd30(longlong *param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(*param_1 + 200))();
  return 0x563 < uVar1;
}

// ==== CItemMgr::vfunc_28  @14031dd50  [high:rtti-vtable]  (orig: FUN_14031dd50)
bool FUN_14031dd50(longlong *param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(*param_1 + 200))();
  return 499 < uVar1;
}

// ==== CItemMgr::vfunc_24  @14031dd70  [high:rtti-vtable]  (orig: FUN_14031dd70)
undefined8 FUN_14031dd70(longlong *param_1,undefined8 param_2,undefined4 *param_3)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  
  plVar4 = (longlong *)(**(code **)(*param_1 + 0x60))();
  if (plVar4 == (longlong *)0x0) {
    return 0;
  }
  uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
  *param_3 = uVar3;
  uVar3 = FUN_1400fda10(plVar4,1,1);
  param_3[1] = uVar3;
  uVar1 = FUN_1400fda10(plVar4,6,1);
  *(undefined1 *)(param_3 + 2) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,8,1);
  *(undefined1 *)((longlong)param_3 + 9) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,9,1);
  *(undefined1 *)((longlong)param_3 + 10) = uVar1;
  uVar3 = FUN_1400fda10(plVar4,10,1);
  param_3[3] = uVar3;
  uVar1 = FUN_1400fda10(plVar4,0xb,1);
  *(undefined1 *)(param_3 + 4) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,0xc,1);
  *(undefined1 *)((longlong)param_3 + 0x11) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,0xe,1);
  *(undefined1 *)((longlong)param_3 + 0x12) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,0x16,1);
  *(undefined1 *)((longlong)param_3 + 0x13) = uVar1;
  uVar2 = FUN_1400fda10(plVar4,0xf,1);
  *(undefined2 *)(param_3 + 5) = uVar2;
  uVar2 = FUN_1400fda10(plVar4,0x10,1);
  *(undefined2 *)((longlong)param_3 + 0x16) = uVar2;
  uVar2 = FUN_1400fda10(plVar4,0x12,1);
  *(undefined2 *)(param_3 + 6) = uVar2;
  uVar1 = FUN_1400fda10(plVar4,0x13,1);
  *(undefined1 *)((longlong)param_3 + 0x1a) = uVar1;
  uVar1 = FUN_1400fda10(plVar4,0x14,1);
  *(undefined1 *)((longlong)param_3 + 0x1b) = uVar1;
  uVar3 = FUN_1400fda10(plVar4,0xd,1);
  param_3[7] = uVar3;
  uVar3 = FUN_1400fda10(plVar4,0x15,1);
  param_3[8] = uVar3;
  uVar3 = FUN_1400fda10(plVar4,0x17,1);
  param_3[9] = uVar3;
  uVar3 = FUN_1400fe380(plVar4);
  param_3[10] = uVar3;
  uVar3 = FUN_1400fda10(plVar4,0x19,1);
  param_3[0xb] = uVar3;
  uVar2 = FUN_1400fda10(plVar4,0x1a,1);
  *(undefined2 *)(param_3 + 0xc) = uVar2;
  uVar2 = FUN_1400fda10(plVar4,4,1);
  *(undefined2 *)((longlong)param_3 + 0x32) = uVar2;
  uVar2 = FUN_1400fda10(plVar4,5,1);
  *(undefined2 *)(param_3 + 0xd) = uVar2;
  return 1;
}

// ==== CItemMgr::vfunc_35  @14031df50  [high:rtti-vtable]  (orig: FUN_14031df50)
void FUN_14031df50(longlong *param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(*param_1 + 0x60))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1401058e0(lVar1);
  return;
}

// ==== CItemMgr::vfunc_38  @14031df70  [high:rtti-vtable]  (orig: FUN_14031df70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_14031df70(undefined8 param_1,longlong param_2,longlong param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  undefined1 uVar1;
  int iVar2;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_3 == 0) {
    local_478 = 0x474;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else if (param_2 == 0) {
    local_478 = 0x475;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    FUN_140458720(local_458);
    local_478 = param_6;
    iVar2 = FUN_1404587d0(local_458,param_3,param_4,param_5);
    if (iVar2 == 0) {
      FUN_140458770(local_458);
      uVar1 = 0;
    }
    else {
      uVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_458);
      FUN_140458770(local_458);
    }
  }
  return uVar1;
}

// ==== CItemMgr::vfunc_40  @14031e090  [high:rtti-vtable]  (orig: FUN_14031e090)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_14031e090(undefined8 param_1,longlong param_2,longlong param_3,undefined4 param_4,
             undefined4 param_5,undefined8 param_6,undefined8 param_7)

{
  undefined1 uVar1;
  int iVar2;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_3 == 0) {
    local_478 = 0x483;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else if (param_2 == 0) {
    local_478 = 0x484;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    FUN_140387320(local_458);
    local_478 = param_4;
    iVar2 = FUN_1403873d0(local_458,param_3,param_5,param_7);
    if (iVar2 == 0) {
      FUN_140387370(local_458);
      uVar1 = 0;
    }
    else {
      uVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_458);
      FUN_140387370(local_458);
    }
  }
  return uVar1;
}

// ==== CItemMgr::vfunc_41  @14031e1b0  [high:rtti-vtable]  (orig: FUN_14031e1b0)
int FUN_14031e1b0(undefined8 param_1,longlong param_2)

{
  int iVar1;
  uint uVar2;
  ulong uVar3;
  
  if (param_2 == 0) {
    return 4;
  }
  iVar1 = FUN_1400fda10(param_2,0x19,1);
  if (iVar1 == 0) {
    iVar1 = FUN_1400fe310(param_2);
  }
  uVar2 = FUN_1400fe350(param_2);
  uVar3 = tq::TimeStampGet();
  if (uVar2 == 0) {
    if (iVar1 == 0) {
      return 0;
    }
    return 1;
  }
  return 3 - (uint)(uVar3 < uVar2);
}

// ==== CItemMgr::vfunc_42  @14031e240  [high:rtti-vtable]  (orig: FUN_14031e240)
void FUN_14031e240(longlong *param_1)

{
  undefined8 uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x60))();
                    /* WARNING: Could not recover jumptable at 0x00014031e25d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x148))(param_1,uVar1);
  return;
}

// ==== CItemMgr::vfunc_46  @14031e270  [high:rtti-vtable]  (orig: FUN_14031e270)
undefined8 FUN_14031e270(longlong *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x150))();
  if ((iVar1 != 2) && (iVar1 != 3)) {
    return 0;
  }
  return 1;
}

// ==== CItemMgr::vfunc_19  @14031e2a0  [high:rtti-vtable]  (orig: FUN_14031e2a0)
void FUN_14031e2a0(longlong param_1)

{
  FUN_1404c82b0(*(undefined8 *)(param_1 + 0x128));
  return;
}

// ==== CItemMgr::helper_14031eb30  @14031eb30  [medium:callgraph-r2]  (orig: FUN_14031eb30)
void FUN_14031eb30(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014031eb54. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CItemMgr::vfunc_1  @14031ef60  [high:rtti-vtable]  (orig: FUN_14031ef60)
ulonglong FUN_14031ef60(longlong *param_1)

{
  ulong uVar1;
  ulonglong uVar2;
  
  uVar1 = tq::TimeGet(0);
  if ((uint)(*(int *)((longlong)param_1 + 0x1bc) + (int)param_1[0x37]) <= uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    *(uint *)((longlong)param_1 + 0x1bc) = uVar1 / 1000;
    (**(code **)(*param_1 + 0x168))(param_1);
  }
  uVar1 = tq::TimeGet(0);
  uVar2 = (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
  if ((uint)((int)param_1[0x38] + *(int *)((longlong)param_1 + 0x1c4)) <= uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    *(uint *)((longlong)param_1 + 0x1c4) = uVar1 / 1000;
    uVar2 = (**(code **)(*param_1 + 0x188))(param_1);
  }
  return uVar2;
}

// ==== CItemMgr::vfunc_39  @14031f030  [high:rtti-vtable]  (orig: FUN_14031f030)
ulonglong FUN_14031f030(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6)

{
  ulonglong extraout_RAX;
  longlong lVar1;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    lVar1 = FUN_140008520((int)param_1[2]);
    if (*(longlong *)(lVar1 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))
                      (*(longlong **)(lVar1 + 0x90),param_2);
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = extraout_RAX_00 & 0xffffffffffffff00;
    }
    else {
      uVar2 = (**(code **)(*param_1 + 0x130))(param_1,lVar1,param_3,param_4,param_5,param_6);
    }
  }
  return uVar2;
}

// ==== CItemMgr::helper_14031f350  @14031f350  [medium:callgraph-r2]  (orig: FUN_14031f350)
void FUN_14031f350(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CItemMgr::helper_14031f3b0  @14031f3b0  [medium:callgraph-r2]  (orig: FUN_14031f3b0)
void FUN_14031f3b0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CItemMgr::helper_14031f960  @14031f960  [medium:callgraph-r0]  (orig: FUN_14031f960)
void FUN_14031f960(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14031f960(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CItemMgr::helper_14031f9f0  @14031f9f0  [medium:callgraph-r2]  (orig: FUN_14031f9f0)
undefined8 *
FUN_14031f9f0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CItemMgr::helper_14031fc60  @14031fc60  [medium:callgraph-r1]  (orig: FUN_14031fc60)
void FUN_14031fc60(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CItemMgr::helper_14031fcc0  @14031fcc0  [medium:callgraph-r1]  (orig: FUN_14031fcc0)
void FUN_14031fcc0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CItemMgr::helper_14031fdb0  @14031fdb0  [medium:callgraph-r2]  (orig: FUN_14031fdb0)
void FUN_14031fdb0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14031fdb0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CItemMgr::helper_140320090  @140320090  [medium:callgraph-r0]  (orig: FUN_140320090)
void FUN_140320090(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14031f960(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CItemMgr::helper_140320220  @140320220  [medium:callgraph-r1]  (orig: FUN_140320220)
undefined8 * FUN_140320220(undefined8 *param_1,undefined8 *param_2,ulonglong *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if ((ulonglong)puVar2[3] < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < (ulonglong)puVar2[3])) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < (ulonglong)puVar2[3]) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CItemMgr::helper_140320430  @140320430  [medium:callgraph-r1]  (orig: FUN_140320430)
undefined8 * FUN_140320430(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14031eb30(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14032061c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14032061c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14031f350(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14031f3b0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14031f350(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14031f3b0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14031f350(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_14031f3b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CItemMgr::helper_1403207f0  @1403207f0  [medium:callgraph-r1]  (orig: FUN_1403207f0)
void FUN_1403207f0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14031fdb0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CItemMgr::helper_140320bc0  @140320bc0  [medium:callgraph-r1]  (orig: FUN_140320bc0)
undefined8 *
FUN_140320bc0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14031f9f0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CItemMgr::helper_140321350  @140321350  [medium:callgraph-r0]  (orig: FUN_140321350)
longlong * FUN_140321350(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1403207f0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140320430(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CItemMgr::vfunc_8  @140321670  [high:rtti-vtable]  (orig: FUN_140321670)
undefined8 FUN_140321670(undefined8 param_1,undefined8 param_2,longlong *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  int *piVar4;
  longlong lVar5;
  
  piVar4 = (int *)param_3[3];
  if ((int *)param_3[4] < piVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_3;
  while( true ) {
    piVar2 = (int *)param_3[4];
    if (piVar2 < (int *)param_3[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_3)) {
      _invalid_parameter_noinfo();
    }
    if (piVar4 == piVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(int **)(lVar5 + 0x20) <= piVar4) {
      _invalid_parameter_noinfo();
    }
    plVar3 = DAT_140975b60;
    if (*piVar4 != 0) {
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(int **)(lVar5 + 0x20) <= piVar4) {
        _invalid_parameter_noinfo();
      }
      (**(code **)(*plVar3 + 0x58))(plVar3,*piVar4,0);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(int **)(lVar5 + 0x20) <= piVar4) {
      _invalid_parameter_noinfo();
    }
    piVar4 = piVar4 + 1;
  }
  return 1;
}

// ==== CItemMgr::helper_140321790  @140321790  [medium:callgraph-r0]  (orig: FUN_140321790)
longlong FUN_140321790(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140320220(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1402ae050(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CItemMgr::helper_1403218d0  @1403218d0  [medium:callgraph-r0]  (orig: FUN_1403218d0)
longlong * FUN_1403218d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_140321a2d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140321a5c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140321a2d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140320bc0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140321a5c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CItemMgr::helper_140321e40  @140321e40  [medium:callgraph-r0]  (orig: FUN_140321e40)
longlong * FUN_140321e40(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CItemMgr::helper_1403220d0  @1403220d0  [medium:callgraph-r0]  (orig: FUN_1403220d0)
longlong * FUN_1403220d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar2 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar2[1] + 0x29) == '\0') {
    puVar3 = (undefined8 *)puVar2[1];
    do {
      if ((*(uint *)(puVar3 + 3) < *param_3) ||
         ((*(uint *)(puVar3 + 3) <= *param_3 && (*(uint *)((longlong)puVar3 + 0x1c) < param_3[1]))))
      {
        puVar4 = (undefined8 *)puVar3[2];
      }
      else {
        puVar4 = (undefined8 *)*puVar3;
        puVar2 = puVar3;
      }
      puVar3 = puVar4;
    } while (*(char *)((longlong)puVar4 + 0x29) == '\0');
  }
  puVar3 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar2 == puVar3) || (*param_3 < *(uint *)(puVar2 + 3))) ||
     ((*param_3 <= *(uint *)(puVar2 + 3) && (param_3[1] < *(uint *)((longlong)puVar2 + 0x1c))))) {
    plVar1 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar1 = &local_28;
  }
  *param_2 = *plVar1;
  param_2[1] = plVar1[1];
  return param_2;
}

// ==== CItemMgr::helper_140322200  @140322200  [medium:callgraph-r1]  (orig: FUN_140322200)
undefined8 * FUN_140322200(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140320bc0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_140320bc0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140320bc0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_140320bc0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_140320bc0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_140320bc0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140320bc0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1403218d0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CItemMgr::helper_1403226b0  @1403226b0  [medium:callgraph-r0]  (orig: FUN_1403226b0)
longlong * FUN_1403226b0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140320090(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140321a80(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CItemMgr::vfunc_6  @140322bb0  [high:rtti-vtable]  (orig: FUN_140322bb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140322bb0(longlong *param_1,uint param_2,char param_3,undefined1 param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 *puVar10;
  longlong lVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined8 *puVar14;
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  undefined4 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  char local_4c8;
  undefined1 local_4c7;
  longlong local_4c0;
  undefined8 *local_4b8;
  longlong *local_4a8;
  longlong local_4a0;
  longlong local_498;
  longlong local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  puVar14 = (undefined8 *)((undefined8 *)param_1[0x19])[1];
  cVar4 = *(char *)((longlong)puVar14 + 0x29);
  puVar2 = (undefined8 *)param_1[0x19];
  while (cVar4 == '\0') {
    if (*(uint *)(puVar14 + 3) < param_2) {
      puVar10 = (undefined8 *)puVar14[2];
      puVar14 = puVar2;
    }
    else {
      puVar10 = (undefined8 *)*puVar14;
    }
    puVar2 = puVar14;
    puVar14 = puVar10;
    cVar4 = *(char *)((longlong)puVar10 + 0x29);
  }
  local_4b8 = puVar2;
  local_4c0 = param_1[0x13];
  puVar14 = (undefined8 *)param_1[0x19];
  local_4c8 = param_3;
  local_4c7 = param_4;
  if (param_1[0x13] == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar14) || (param_2 < *(uint *)(puVar2 + 3))) {
    local_490 = param_1[0x19];
    local_498 = param_1[0x13];
    plVar13 = &local_498;
  }
  else {
    plVar13 = &local_4c0;
  }
  plVar1 = (longlong *)*plVar13;
  local_4a8 = plVar1;
  local_4a0 = plVar13[1];
  lVar11 = param_1[0x19];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x13])) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_4a0;
  if (local_4a0 == lVar11) {
    uVar12 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar1;
    }
    if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(lVar3 + 0x20);
    local_4a8 = (longlong *)*plVar13;
    local_4a0 = plVar13[1];
    FUN_140321a80(param_1 + 0x13,&local_498,&local_4a8);
    cVar4 = FUN_140101370(plVar1);
    if (cVar4 == '\0') {
      local_4e8 = 0x16a;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar12 = 0;
    }
    else {
      if (local_4c8 != '\0') {
        (**(code **)(*param_1 + 0x180))(param_1,param_2);
        (**(code **)(*param_1 + 0x160))(param_1,param_2);
      }
      FUN_140100090(plVar1,2);
      FUN_140100210(plVar1,2);
      if (((longlong *)param_1[0x2e] != (longlong *)0x0) &&
         (uVar5 = (**(code **)(*(longlong *)param_1[0x2e] + 8))(), uVar5 == param_2)) {
        param_1[0x2e] = 0;
      }
      cVar4 = FUN_140103280(plVar1);
      if (cVar4 == '\0') {
        FUN_140103f40(plVar1,local_4c7);
      }
      else {
        FUN_14036ee80(local_478);
        iVar6 = FUN_1400fda10(plVar1,3,1);
        uVar12 = FUN_140008520((int)param_1[2]);
        uVar12 = FUN_140087650(uVar12);
        iVar7 = FUN_1402a80a0(uVar12,iVar6);
        cVar4 = FUN_140100c40(plVar1);
        if (((cVar4 == '\0') && (iVar6 != 0)) && (iVar7 != 0)) {
          uVar8 = FUN_1400fda10(plVar1,1,1);
          uVar9 = FUN_140100c20(plVar1);
          local_4e8 = (**(code **)(*plVar1 + 8))(plVar1);
          local_4d0 = 0;
          local_4e0 = uVar9;
          local_4d8 = uVar8;
          cVar4 = FUN_14036ef90(local_478,2,iVar6,iVar7);
          if (cVar4 != '\0') {
            uVar12 = FUN_140008520((int)param_1[2]);
            plVar13 = (longlong *)FUN_140087650(uVar12);
            lVar11 = *plVar13;
            uVar8 = FUN_1400fda10(plVar1,3,1);
            plVar13 = (longlong *)(**(code **)(lVar11 + 0x98))(plVar13,uVar8);
            if (plVar13 == (longlong *)0x0) {
              FUN_1400fda10(plVar1,3,1);
              log_InlineLogOSERROR("CItemMgr::DestroyItem pUser is null, user id:%u.");
            }
            else {
              (**(code **)(*plVar13 + 0x138))(plVar13,local_478,4);
            }
          }
        }
        uVar8 = FUN_140100c10(plVar1);
        uVar9 = FUN_140100c20(plVar1);
        local_4c0 = CONCAT44(uVar8,uVar9);
        FUN_140321790(param_1 + 0xb,&local_4c0);
        FUN_14036eed0(local_478);
      }
      FUN_140103eb0(plVar1);
      uVar12 = 1;
    }
  }
  return uVar12;
}

// ==== CItemMgr::vfunc_12  @140323260  [high:rtti-vtable]  (orig: FUN_140323260)
undefined8 FUN_140323260(longlong param_1,int param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  longlong lVar2;
  int local_res10 [2];
  undefined8 uVar3;
  longlong *local_30;
  longlong local_28;
  
  uVar3 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    uVar3 = 0;
  }
  else {
    local_res10[0] = param_2;
    if ((*(longlong **)(param_1 + 0x170) != (longlong *)0x0) &&
       (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x170) + 8))(), iVar1 == param_2)) {
      return *(undefined8 *)(param_1 + 0x170);
    }
    FUN_140321e40(param_1 + 0x98,&local_30,local_res10,param_4,uVar3);
    lVar2 = *(longlong *)(param_1 + 200);
    if ((local_30 == (longlong *)0x0) || (local_30 != *(longlong **)(param_1 + 0x98))) {
      _invalid_parameter_noinfo();
    }
    if (local_28 == lVar2) {
      uVar3 = 0;
    }
    else {
      if (local_30 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = 0;
      }
      else {
        lVar2 = *local_30;
      }
      if (local_28 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar3 = *(undefined8 *)(local_28 + 0x20);
      *(undefined8 *)(param_1 + 0x170) = uVar3;
    }
  }
  return uVar3;
}

// ==== CItemMgr::vfunc_23  @140323690  [high:rtti-vtable]  (orig: FUN_140323690)
undefined4 FUN_140323690(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x240))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x240);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x240);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x210);
  if (*(longlong *)(param_1 + 0x210) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x240);
    local_28 = *(longlong *)(param_1 + 0x210);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x240);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x210))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    log_InlineLogDBERROR("table:cq_skilled_level_despise, field skilled_level_diff=%d not config.");
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CItemMgr::vfunc_25  @1403237c0  [high:rtti-vtable]  (orig: FUN_1403237c0)
int FUN_1403237c0(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  longlong lVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  longlong lVar14;
  int iVar15;
  longlong lVar16;
  undefined4 local_res8;
  undefined4 local_resc;
  undefined4 local_64;
  undefined4 local_60;
  longlong *local_58;
  longlong local_50;
  undefined1 local_48 [16];
  
  lVar11 = (**(code **)(*param_1 + 0x60))();
  if (lVar11 == 0) {
    return 0;
  }
  iVar10 = 1;
  lVar14 = 0;
  iVar15 = 0;
  uVar5 = FUN_1400fda10(lVar11,1,1);
  local_res8 = FUN_1400fda10(lVar11,8,1);
  uVar6 = FUN_1400fda10(lVar11,9,1);
  uVar7 = FUN_1400fda10(lVar11,0xc,1);
  uVar8 = FUN_1400fda10(lVar11,0xe,1);
  plVar1 = param_1 + 0x3a;
  local_64 = 5;
  local_60 = uVar5;
  FUN_1403220d0(plVar1,&local_58,&local_64,param_4,uVar8);
  plVar2 = local_58;
  lVar16 = param_1[0x40];
  if ((local_58 == (longlong *)0x0) || (local_58 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_50;
  if (local_50 != lVar16) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar16 = lVar14;
    }
    else {
      lVar16 = *plVar2;
    }
    if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar15 = *(int *)(lVar3 + 0x20);
  }
  uVar5 = FUN_1400fda10(lVar11,1,1);
  cVar4 = FUN_140102710(uVar5);
  if (cVar4 != '\0') {
    local_64 = 2;
    local_60 = local_res8;
    plVar12 = (longlong *)FUN_1403220d0(plVar1,local_48,&local_64);
    lVar16 = param_1[0x40];
    plVar2 = (longlong *)*plVar12;
    local_50 = plVar12[1];
    local_58 = plVar2;
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_50;
    if (local_50 != lVar16) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = lVar14;
      }
      else {
        lVar16 = *plVar2;
      }
      if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar15 = iVar15 + *(int *)(lVar3 + 0x20);
    }
    local_res8 = 3;
    local_resc = uVar6;
    plVar12 = (longlong *)FUN_1403220d0(plVar1,local_48,&local_res8);
    lVar16 = param_1[0x40];
    plVar2 = (longlong *)*plVar12;
    local_50 = plVar12[1];
    local_58 = plVar2;
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_50;
    if (local_50 != lVar16) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = lVar14;
      }
      else {
        lVar16 = *plVar2;
      }
      if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar15 = iVar15 + *(int *)(lVar3 + 0x20);
    }
    local_res8 = 4;
    local_resc = uVar7;
    plVar12 = (longlong *)FUN_1403220d0(plVar1,local_48,&local_res8);
    lVar16 = param_1[0x40];
    plVar2 = (longlong *)*plVar12;
    local_50 = plVar12[1];
    local_58 = plVar2;
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_50;
    if (local_50 != lVar16) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = lVar14;
      }
      else {
        lVar16 = *plVar2;
      }
      if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar15 = iVar15 + *(int *)(lVar3 + 0x20);
    }
    local_resc = uVar8;
    local_res8 = 6;
    puVar13 = (undefined8 *)FUN_1403220d0(plVar1,local_48,&local_res8);
    lVar16 = param_1[0x40];
    plVar2 = (longlong *)*puVar13;
    local_50 = puVar13[1];
    local_58 = plVar2;
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_50;
    if (local_50 != lVar16) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar14 = *plVar2;
      }
      if (lVar3 == *(longlong *)(lVar14 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar15 = iVar15 + *(int *)(lVar3 + 0x20);
    }
  }
  iVar9 = FUN_140100000(lVar11);
  if (1 < iVar9) {
    iVar10 = FUN_140100000(lVar11);
  }
  return iVar10 * iVar15;
}

// ==== CItemMgr::vfunc_20  @140323b60  [high:rtti-vtable]  (orig: FUN_140323b60)
undefined8 FUN_140323b60(longlong param_1,uint param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x108);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x108);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xd8);
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x108);
    local_28 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x108);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xd8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = *(longlong *)(lVar4 + 0x20);
    if (lVar8 != 0) {
      FUN_140101cb0(lVar8,param_3);
      return 1;
    }
  }
  return 0;
}

// ==== CItemMgr::vfunc_31  @140323c90  [high:rtti-vtable]  (orig: FUN_140323c90)
undefined8 FUN_140323c90(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x108);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x108);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xd8);
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x108);
    local_28 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x108);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xd8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar9) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lVar4 + 0x20) != 0) {
      uVar6 = FUN_1401058e0();
      return uVar6;
    }
  }
  return 0;
}

// ==== CItemMgr::vfunc_32  @140323db0  [high:rtti-vtable]  (orig: FUN_140323db0)
undefined8
FUN_140323db0(longlong param_1,int param_2,int param_3,undefined4 *param_4,undefined4 *param_5)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined4 local_38;
  int local_34;
  longlong *local_30;
  longlong local_28;
  
  if (param_3 < 3) {
    return 0;
  }
  if (param_3 < 5) {
    param_3 = 5;
  }
  if (0x15 < param_2) {
    *param_4 = 0x109a00;
    *param_5 = 10000;
    return 1;
  }
  local_34 = param_3 + param_2 * 10;
  local_38 = 7;
  FUN_1403220d0(param_1 + 0x1d0,&local_30,&local_38);
  lVar2 = *(longlong *)(param_1 + 0x200);
  if ((local_30 == (longlong *)0x0) || (local_30 != *(longlong **)(param_1 + 0x1d0))) {
    _invalid_parameter_noinfo();
  }
  if (local_28 == lVar2) {
    log_InlineLogERROR(&DAT_140750350);
    uVar1 = 0;
  }
  else {
    if (local_30 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar2 = 0;
    }
    else {
      lVar2 = *local_30;
    }
    if (local_28 == *(longlong *)(lVar2 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_5 = *(undefined4 *)(local_28 + 0x24);
    *param_4 = 0x109a01;
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CItemMgr::vfunc_33  @140323ee0  [high:rtti-vtable]  (orig: FUN_140323ee0)
undefined8 FUN_140323ee0(longlong *param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined4 local_38;
  int local_34;
  longlong *local_30;
  longlong local_28;
  
  if (param_2 == 0) {
    return 0;
  }
  lVar3 = (**(code **)(*param_1 + 0x60))();
  if (lVar3 != 0) {
    cVar1 = FUN_140102550(lVar3);
    if (cVar1 != '\0') {
      *param_3 = 0x109a00;
      *param_4 = 10000;
      return 1;
    }
    iVar2 = FUN_1400fee00(lVar3);
    local_34 = FUN_1400fda10(lVar3,1,1);
    local_34 = local_34 % 10;
    if (2 < local_34) {
      if (local_34 < 5) {
        local_34 = 5;
      }
      local_38 = 8;
      local_34 = local_34 + iVar2 * 10;
      FUN_1403220d0(param_1 + 0x3a,&local_30,&local_38);
      lVar3 = param_1[0x40];
      if ((local_30 == (longlong *)0x0) || (local_30 != (longlong *)param_1[0x3a])) {
        _invalid_parameter_noinfo();
      }
      if (local_28 != lVar3) {
        if (local_30 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar3 = 0;
        }
        else {
          lVar3 = *local_30;
        }
        if (local_28 == *(longlong *)(lVar3 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        *param_4 = *(undefined4 *)(local_28 + 0x24);
        *param_3 = 0x109a01;
        return 1;
      }
      log_InlineLogERROR(&DAT_1407503a0);
    }
    return 0;
  }
  return 0;
}

// ==== CItemMgr::vfunc_34  @140324060  [high:rtti-vtable]  (orig: FUN_140324060)
ulonglong FUN_140324060(longlong param_1,int param_2,int param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  ulonglong uVar2;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong lVar3;
  undefined4 local_28;
  int local_24;
  longlong *local_20;
  longlong local_18;
  
  uVar2 = (ulonglong)(param_3 - 1U);
  if (param_3 - 1U < 9) {
    if (2 < param_3) {
      local_28 = 9;
      if (param_3 < 5) {
        param_3 = 5;
      }
      local_24 = param_3 + param_2 * 10;
      uVar2 = FUN_1403220d0(param_1 + 0x1d0,&local_20,&local_28);
      lVar3 = *(longlong *)(param_1 + 0x200);
      if ((local_20 == (longlong *)0x0) || (local_20 != *(longlong **)(param_1 + 0x1d0))) {
        _invalid_parameter_noinfo();
        uVar2 = extraout_RAX;
      }
      if (local_18 == lVar3) {
        return uVar2 & 0xffffffffffffff00;
      }
      if (local_20 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar3 = 0;
      }
      else {
        lVar3 = *local_20;
      }
      if (local_18 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined4 *)(local_18 + 0x24);
      *param_4 = uVar1;
      return CONCAT71((uint7)(uint3)((uint)uVar1 >> 8),1);
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX_00;
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CItemMgr::vfunc_13  @140324180  [high:rtti-vtable]  (orig: FUN_140324180)
undefined8 FUN_140324180(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x108);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x108);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xd8);
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x108);
    local_28 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x108);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0xd8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CItemMgr::vfunc_36  @1403242a0  [high:rtti-vtable]  (orig: FUN_1403242a0)
bool FUN_1403242a0(longlong *param_1,uint param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  char cVar4;
  uint uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  bool bVar11;
  undefined4 uStack_64;
  longlong local_58;
  undefined8 *local_50;
  undefined8 local_38;
  longlong lStack_30;
  
  puVar10 = (undefined8 *)((undefined8 *)param_1[0x19])[1];
  cVar4 = *(char *)((longlong)puVar10 + 0x29);
  puVar3 = (undefined8 *)param_1[0x19];
  while (cVar4 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar10[2];
      puVar10 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar10;
    }
    puVar3 = puVar10;
    puVar10 = puVar6;
    cVar4 = *(char *)((longlong)puVar6 + 0x29);
  }
  local_50 = puVar3;
  local_58 = param_1[0x13];
  puVar10 = (undefined8 *)param_1[0x19];
  if (param_1[0x13] == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar10) || (param_2 < *(uint *)(puVar3 + 3))) {
    lStack_30 = param_1[0x19];
    local_38 = param_1[0x13];
    plVar9 = &local_38;
  }
  else {
    plVar9 = &local_58;
  }
  plVar1 = (longlong *)*plVar9;
  lVar8 = plVar9[1];
  lVar7 = param_1[0x19];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x13])) {
    _invalid_parameter_noinfo();
  }
  if (lVar8 == lVar7) {
    bVar11 = false;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (lVar8 == *(longlong *)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined8 *)(lVar8 + 0x20);
    cVar4 = FUN_140101370(uVar2);
    if (cVar4 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      bVar11 = false;
    }
    else {
      if (((longlong *)param_1[0x2e] != (longlong *)0x0) &&
         (uVar5 = (**(code **)(*(longlong *)param_1[0x2e] + 8))(), uVar5 == param_2)) {
        param_1[0x2e] = 0;
      }
      uStack_64 = (undefined4)((ulonglong)plVar1 >> 0x20);
      local_38._0_4_ = SUB84(plVar1,0);
      local_38._4_4_ = uStack_64;
      lStack_30 = lVar8;
      FUN_140321a80(param_1 + 0x13,&local_58,&local_38);
      (**(code **)(*param_1 + 0x160))(param_1,param_2);
      (**(code **)(*param_1 + 0x180))(param_1,param_2);
      local_38 = CONCAT44(local_38._4_4_,param_2);
      lStack_30 = uVar2;
      lVar8 = FUN_1403218d0(param_1 + 0x1b,&local_58,&local_38);
      bVar11 = *(char *)(lVar8 + 0x10) != '\0';
    }
  }
  return bVar11;
}

// ==== CItemMgr::vfunc_7  @1403244a0  [high:rtti-vtable]  (orig: FUN_1403244a0)
undefined8 FUN_1403244a0(longlong param_1,uint param_2,char param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  longlong lVar5;
  char cVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  plVar1 = (longlong *)(param_1 + 0xd8);
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar6 = *(char *)((longlong)puVar8 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x108);
  while (cVar6 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar7;
    cVar6 = *(char *)((longlong)puVar7 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x108);
  local_40 = puVar4;
  local_48 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar9 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x108);
    local_38 = *plVar1;
  }
  else {
    plVar9 = &local_48;
  }
  plVar2 = (longlong *)*plVar9;
  lVar10 = *(longlong *)(param_1 + 0x108);
  local_28 = plVar2;
  local_20 = plVar9[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_20;
  if (local_20 != lVar10) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar3 = *(undefined8 *)(lVar5 + 0x20);
    cVar6 = FUN_140101370(uVar3);
    if (cVar6 != '\0') {
      local_28 = (longlong *)*plVar9;
      local_20 = plVar9[1];
      FUN_140321a80(plVar1,&local_38,&local_28);
      if (param_3 != '\0') {
        FUN_140103f40(uVar3,0);
      }
      FUN_140103eb0(uVar3);
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CItemMgr::vfunc_37  @140324630  [high:rtti-vtable]  (orig: FUN_140324630)
bool FUN_140324630(longlong param_1,uint param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  undefined8 *puVar6;
  longlong lVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_28;
  longlong local_20;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar5 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x108);
  while (cVar5 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar5 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x108);
  local_50 = puVar3;
  local_58 = *(longlong *)(param_1 + 0xd8);
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar9 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x108);
    local_48 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar9 = &local_58;
  }
  plVar1 = (longlong *)*plVar9;
  lVar7 = *(longlong *)(param_1 + 0x108);
  local_20 = plVar9[1];
  local_28 = plVar1;
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xd8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_20;
  if (local_20 != lVar7) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (lVar4 == *(longlong *)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined8 *)(lVar4 + 0x20);
    cVar5 = FUN_140101370(uVar2);
    if (cVar5 != '\0') {
      local_28 = (longlong *)*plVar9;
      local_20 = plVar9[1];
      FUN_140321a80(param_1 + 0xd8,&local_48,&local_28);
      local_28 = (longlong *)CONCAT44(local_28._4_4_,param_2);
      local_20 = uVar2;
      lVar7 = FUN_1403218d0(param_1 + 0x98,&local_48,&local_28);
      return *(char *)(lVar7 + 0x10) != '\0';
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return false;
}

// ==== CItemMgr::vfunc_43  @1403247e0  [high:rtti-vtable]  (orig: FUN_1403247e0)
void FUN_1403247e0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0x130,local_28,local_res10);
  return;
}

// ==== CItemMgr::ProcessTimeActiveItemTimer  @140324810  [high:log-string]  (orig: FUN_140324810)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140324810(longlong *param_1)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  longlong *plVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  bool bVar15;
  undefined1 auStack_1a98 [32];
  uint local_1a78;
  uint local_1a68;
  longlong *local_1a58;
  longlong *plStack_1a50;
  longlong *local_1a48;
  undefined4 local_1a40;
  longlong *local_1a38;
  longlong *local_1a30;
  longlong *local_1a28;
  longlong *local_1a20;
  longlong *local_1a18;
  longlong *local_1a10;
  longlong *local_1a08;
  longlong *plStack_1a00;
  longlong *local_19f8;
  longlong *plStack_19f0;
  longlong *local_19e8;
  longlong *local_19d8;
  longlong *plStack_19d0;
  undefined8 local_19c8;
  longlong *local_19b8;
  longlong *plStack_19b0;
  undefined1 local_19a8 [16];
  undefined1 local_1998 [16];
  undefined1 local_1988 [16];
  undefined1 local_1978 [16];
  undefined1 local_1968 [1072];
  undefined1 local_1538 [1072];
  undefined1 local_1108 [1072];
  undefined1 local_cd8 [1072];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_19c8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1a98;
  local_1a68 = 0;
  plVar14 = *(longlong **)param_1[0x2c];
  plVar10 = (longlong *)param_1[0x26];
  local_1a58 = plVar10;
  plStack_1a50 = plVar14;
  local_1a48 = param_1;
LAB_140324890:
  do {
    plVar8 = (longlong *)param_1[0x2c];
    local_19e8 = (longlong *)param_1[0x26];
    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_19e8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar14 == plVar8) {
      return;
    }
    local_1a68 = local_1a68 + 1;
    if (100000 < local_1a68) {
      local_1a78 = 0x543;
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = 0;
    }
    else {
      lVar12 = *plVar10;
    }
    if (plVar14 == *(longlong **)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar8 = (longlong *)(**(code **)(*param_1 + 0x60))(param_1,(int)plVar14[3]);
    if (plVar8 == (longlong *)0x0) {
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = 0;
      }
      else {
        lVar12 = *plVar10;
      }
      if (plVar14 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      log_InlineLogWARNING("CItemMgr::ProcessTimeActiveItemTimer() (not find item) idItem=%u");
      plVar11 = plStack_1a50;
      plVar8 = local_1a58;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
        plVar13 = plVar14;
        plVar1 = (longlong *)plVar14[2];
        if (*(char *)(plVar14[2] + 0x1d) == '\0') {
          do {
            plVar14 = plVar1;
            plVar1 = (longlong *)*plVar14;
            plStack_1a50 = plVar14;
            local_1a10 = plVar14;
          } while (*(char *)(*plVar14 + 0x1d) == '\0');
        }
        else {
          do {
            plVar14 = (longlong *)plVar13[1];
            plStack_1a50 = plVar14;
            if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
            bVar15 = plVar13 == (longlong *)plVar14[2];
            plVar13 = plVar14;
          } while (bVar15);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_1a08 = plVar8;
      plStack_1a00 = plVar11;
      FUN_14000ab40(param_1 + 0x26,local_1998,&local_1a08);
      goto LAB_140324890;
    }
    iVar3 = (**(code **)(*plVar8 + 8))(plVar8);
    local_1a40 = FUN_1400fda10(plVar8,3,1);
    uVar4 = FUN_1400fda10(plVar8,2,1);
    uVar5 = FUN_1400fda10(plVar8,7,1);
    iVar6 = FUN_1400fda10(plVar8,7,1);
    if (((iVar6 < 0xc9) || (iVar6 = FUN_1400fda10(plVar8,7,1), 0xcc < iVar6)) &&
       (iVar6 = FUN_1400fda10(plVar8,7,1), iVar6 != 0xd0)) {
      lVar12 = *param_1;
      uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
      iVar6 = (**(code **)(lVar12 + 0x150))(param_1,uVar7);
      plVar10 = local_1a58;
      if (iVar6 == 3) {
        if (local_1a58 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *local_1a58;
        }
        if (plVar14 == *(longlong **)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        (**(code **)(*param_1 + 0x180))(param_1,(int)plVar14[3]);
        uVar9 = FUN_140008520((int)param_1[2]);
        plVar10 = (longlong *)FUN_140087650(uVar9);
        plVar11 = (longlong *)(**(code **)(*plVar10 + 0x98))(plVar10,uVar4);
        plVar10 = local_1a58;
        if (plVar11 == (longlong *)0x0) {
          local_1a78 = uVar5;
          log_InlineLogWARNING
                    (
                    "CItemMgr::ProcessTimeActiveItemTimer() (user is not find) idItem=%u, idPlayer=%u, idOwner=%u, nPosition=%d"
                    );
          param_1 = local_1a48;
          (**(code **)(*local_1a48 + 0x30))(local_1a48,iVar3,0,0);
          plVar8 = plStack_1a50;
          plVar10 = local_1a58;
          if (local_1a58 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
            plVar11 = plVar14;
            plVar13 = (longlong *)plVar14[2];
            if (*(char *)(plVar14[2] + 0x1d) == '\0') {
              do {
                plVar14 = plVar13;
                plVar13 = (longlong *)*plVar14;
                plStack_1a50 = plVar14;
                local_1a20 = plVar14;
              } while (*(char *)(*plVar14 + 0x1d) == '\0');
            }
            else {
              do {
                plVar14 = (longlong *)plVar11[1];
                plStack_1a50 = plVar14;
                if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                bVar15 = plVar11 == (longlong *)plVar14[2];
                plVar11 = plVar14;
              } while (bVar15);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          local_19b8 = plVar10;
          plStack_19b0 = plVar8;
          FUN_14000ab40(param_1 + 0x26,local_1978,&local_19b8);
        }
        else if ((char)plVar11[0x259] == '\0') {
          iVar6 = FUN_1400fda10(plVar8,0x17,1);
          if (iVar6 != 0) {
            plVar10 = (longlong *)FUN_140087f50();
            (**(code **)(*plVar10 + 0x48))(plVar10,uVar4,iVar3);
          }
          if ((((int)uVar5 < 1) || (0x13 < (int)uVar5)) && (8 < uVar5 - 0x15)) {
            if (uVar5 == 0) {
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              cVar2 = FUN_140332fe0(plVar11,uVar4);
              if (cVar2 == '\0') {
                FUN_1400f83e0(local_8a8);
                FUN_1400fda10(plVar8,7,1);
                uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                local_1a78 = uVar5;
                iVar6 = FUN_1400f8490(local_8a8,uVar4,0x2a);
                if (iVar6 != 0) {
                  (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_8a8);
                }
                FUN_1400fe700(plVar8,plVar11,0);
                param_1 = local_1a48;
                (**(code **)(*local_1a48 + 0x30))(local_1a48,iVar3,0);
                FUN_1400f8430(local_8a8);
              }
              else {
                FUN_1400fe700(plVar8,plVar11,0);
                plVar10 = (longlong *)FUN_14031dc50();
                lVar12 = *plVar10;
                uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                uVar7 = (**(code **)(*plVar11 + 8))(plVar11);
                (**(code **)(lVar12 + 0x38))(plVar10,uVar7,uVar4);
                uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                local_1a78 = local_1a78 & 0xffffff00;
                FUN_14033a6a0(plVar11,uVar4,0);
                FUN_1400f83e0(local_1538);
                local_1a78 = 0;
                iVar3 = FUN_1400f8490(local_1538,iVar3,0x2a);
                if (iVar3 != 0) {
                  (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_1538);
                }
                FUN_1400f8430(local_1538);
                param_1 = local_1a48;
              }
            }
            else if (uVar5 == 0xcd) {
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              cVar2 = FUN_140333160(plVar11,uVar4);
              if (cVar2 == '\0') {
                local_1a78 = 0x5c3;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              FUN_1400fe700(plVar8,plVar11,0);
              (**(code **)(*local_1a48 + 0x30))(local_1a48,iVar3,0,0);
              FUN_140336210(plVar11,iVar3);
              FUN_1400f83e0(local_cd8);
              local_1a78 = 0;
              iVar3 = FUN_1400f8490(local_cd8,iVar3,0x2a);
              if (iVar3 != 0) {
                (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_cd8);
              }
              FUN_1400f8430(local_cd8);
              param_1 = local_1a48;
            }
            else {
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              cVar2 = FUN_1403330a0(plVar11,uVar4);
              if (cVar2 != '\0') {
                uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                FUN_140335ff0(plVar11,uVar4);
              }
              FUN_1400f83e0(local_478);
              uVar4 = FUN_1400fda10(plVar8,7,1);
              uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
              local_1a78 = 0;
              iVar6 = FUN_1400f8490(local_478,uVar7,0x2a,uVar4);
              if (iVar6 != 0) {
                (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_478);
              }
              FUN_1400fe700(plVar8,plVar11,0);
              param_1 = local_1a48;
              (**(code **)(*local_1a48 + 0x30))(local_1a48,iVar3,0,0);
              local_1a78 = uVar5;
              log_InlineLogWARNING
                        (
                        "time_valid_item[ItemID = %u, PlayerID = %u, OwnerID = %u, Position = %d] is not fonud!"
                        );
              FUN_1400f8430(local_478);
            }
          }
          else {
            iVar6 = FUN_140337820(plVar11,uVar5);
            if (iVar3 == iVar6) {
              uVar4 = FUN_1400fda10(plVar8,7,1);
              cVar2 = FUN_1403558e0(plVar11,uVar4,1);
              param_1 = local_1a48;
              if (cVar2 != '\0') {
                FUN_1400f83e0(local_1968);
                local_1a78 = 0;
                iVar3 = FUN_1400f8490(local_1968,iVar3,0x2a);
                if (iVar3 != 0) {
                  (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_1968);
                }
                FUN_1400f8430(local_1968);
                param_1 = local_1a48;
              }
            }
            else {
              local_1a78 = uVar5;
              log_InlineLogWARNING
                        (
                        "CItemMgr::ProcessTimeActiveItemTimer() (Equip is not in setEquipItemID) idItem=%u, idPlayer=%u, idOwner=%u, nPosition=%d"
                        );
              FUN_1400f83e0(local_1108);
              FUN_1400fda10(plVar8,7,1);
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              local_1a78 = 0;
              iVar6 = FUN_1400f8490(local_1108,uVar4,0x2a);
              if (iVar6 != 0) {
                (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_1108);
              }
              FUN_1400fe700(plVar8,plVar11,0);
              param_1 = local_1a48;
              (**(code **)(*local_1a48 + 0x30))(local_1a48,iVar3,0);
              FUN_1400f8430(local_1108);
            }
          }
          plVar8 = plStack_1a50;
          plVar10 = local_1a58;
          if (local_1a58 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
            plVar11 = plVar14;
            plVar13 = (longlong *)plVar14[2];
            if (*(char *)(plVar14[2] + 0x1d) == '\0') {
              do {
                plVar14 = plVar13;
                plVar13 = (longlong *)*plVar14;
                plStack_1a50 = plVar14;
                local_1a30 = plVar14;
              } while (*(char *)(*plVar14 + 0x1d) == '\0');
            }
            else {
              do {
                plVar14 = (longlong *)plVar11[1];
                plStack_1a50 = plVar14;
                if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                bVar15 = plVar11 == (longlong *)plVar14[2];
                plVar11 = plVar14;
              } while (bVar15);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          local_19d8 = plVar10;
          plStack_19d0 = plVar8;
          FUN_14000ab40(param_1 + 0x26,local_19a8,&local_19d8);
        }
        else {
          if (local_1a58 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
            plVar8 = plVar14;
            plVar11 = (longlong *)plVar14[2];
            param_1 = local_1a48;
            if (*(char *)(plVar14[2] + 0x1d) == '\0') {
              do {
                plVar14 = plVar11;
                plVar11 = (longlong *)*plVar14;
                plStack_1a50 = plVar14;
                local_1a18 = plVar14;
              } while (*(char *)(*plVar14 + 0x1d) == '\0');
            }
            else {
              do {
                plVar14 = (longlong *)plVar8[1];
                plStack_1a50 = plVar14;
                if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                bVar15 = plVar8 == (longlong *)plVar14[2];
                plVar8 = plVar14;
              } while (bVar15);
            }
          }
          else {
            _invalid_parameter_noinfo();
            param_1 = local_1a48;
          }
        }
      }
      else {
        if (local_1a58 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
          plVar8 = plVar14;
          plVar11 = (longlong *)plVar14[2];
          if (*(char *)(plVar14[2] + 0x1d) == '\0') {
            do {
              plVar14 = plVar11;
              plVar11 = (longlong *)*plVar14;
              plStack_1a50 = plVar14;
              local_1a28 = plVar14;
            } while (*(char *)(*plVar14 + 0x1d) == '\0');
          }
          else {
            do {
              plVar14 = (longlong *)plVar8[1];
              plStack_1a50 = plVar14;
              if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
              bVar15 = plVar8 == (longlong *)plVar14[2];
              plVar8 = plVar14;
            } while (bVar15);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
    else {
      local_1a78 = uVar5;
      log_InlineLogWARNING
                (
                "CItemMgr::ProcessTimeActiveItemTimer() (not handle) idItem=%u, idPlayer=%u, idOwner=%u, nPosition=%d"
                );
      plVar8 = plStack_1a50;
      plVar10 = local_1a58;
      if (local_1a58 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
        plVar11 = plVar14;
        plVar13 = (longlong *)plVar14[2];
        if (*(char *)(plVar14[2] + 0x1d) == '\0') {
          do {
            plVar14 = plVar13;
            plVar13 = (longlong *)*plVar14;
            plStack_1a50 = plVar14;
            local_1a38 = plVar14;
          } while (*(char *)(*plVar14 + 0x1d) == '\0');
        }
        else {
          do {
            plVar14 = (longlong *)plVar11[1];
            plStack_1a50 = plVar14;
            if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
            bVar15 = plVar11 == (longlong *)plVar14[2];
            plVar11 = plVar14;
          } while (bVar15);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_19f8 = plVar10;
      plStack_19f0 = plVar8;
      FUN_14000ab40(param_1 + 0x26,local_1988,&local_19f8);
    }
  } while( true );
}

// ==== CItemMgr::vfunc_47  @140325380  [high:rtti-vtable]  (orig: FUN_140325380)
void FUN_140325380(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0x178,local_28,local_res10);
  return;
}

// ==== CItemMgr::helper_1403254f0  @1403254f0  [medium:callgraph-r1]  (orig: FUN_1403254f0)
uint FUN_1403254f0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  uint uVar4;
  longlong lVar5;
  longlong *local_38;
  longlong lStack_30;
  undefined1 local_28 [16];
  
  uVar4 = *(int *)(param_1 + 0x14) + 1;
  if (*(longlong *)(param_1 + 0x50) != 0) {
    plVar1 = *(longlong **)(param_1 + 0x48);
    plVar2 = *(longlong **)(param_1 + 0x18);
    plVar3 = (longlong *)*plVar1;
    local_38 = plVar2;
    lStack_30 = (longlong)plVar3;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar1) {
      *(uint *)(param_1 + 0x14) = uVar4;
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar2;
      }
      if (plVar3 == (longlong *)*(longlong *)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar4 = *(uint *)(plVar3 + 3);
      FUN_14000ab40(param_1 + 0x18,local_28,&local_38);
    }
    return uVar4;
  }
  if (uVar4 < 4200000000) {
    *(uint *)(param_1 + 0x14) = uVar4;
    return uVar4;
  }
  log_InlineLogOSERROR(&DAT_1407506f0);
  return 0;
}

// ==== CItemMgr::helper_1403256a0  @1403256a0  [medium:callgraph-r0]  (orig: FUN_1403256a0)
undefined8 * FUN_1403256a0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_140322200(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CItemMgr::helper_1403257d0  @1403257d0  [medium:callgraph-r0]  (orig: FUN_1403257d0)
void FUN_1403257d0(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CItemMgr::helper_140325a00  @140325a00  [medium:callgraph-r1]  (orig: FUN_140325a00)
longlong * FUN_140325a00(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140322900(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_140325af4;
  }
  _invalid_parameter_noinfo();
LAB_140325af4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CItemMgr::vfunc_4  @140325da0  [high:rtti-vtable]  (orig: FUN_140325da0)
longlong *
FUN_140325da0(longlong *param_1,longlong param_2,undefined1 param_3,undefined4 param_4,int param_5,
             char param_6)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong local_res8;
  undefined4 local_50 [2];
  longlong *local_48;
  undefined1 local_40 [16];
  char local_30;
  
  lVar1 = param_1[2];
  local_res8 = FUN_1401012b0(0x70);
  if (local_res8 == 0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = (longlong *)FUN_1400fd8d0(local_res8,(int)lVar1);
  }
  if (plVar5 == (longlong *)0x0) {
    return (longlong *)0x0;
  }
  cVar2 = FUN_140101370(plVar5);
  if (cVar2 == '\0') {
    FUN_140103eb0(plVar5);
    return (longlong *)0x0;
  }
  if (param_5 == 0) {
    uVar6 = FUN_140087e80();
    cVar2 = FUN_1401d28f0(uVar6,*(undefined4 *)(param_2 + 4));
    if (cVar2 != '\0') {
      FUN_140103eb0(plVar5);
      return (longlong *)0x0;
    }
    cVar2 = FUN_140107480(plVar5,0,param_2,param_3,param_4);
    if (cVar2 == '\0') {
      FUN_140103eb0(plVar5);
      return (longlong *)0x0;
    }
  }
  else {
    cVar2 = FUN_140107480(plVar5,param_5,param_2,param_3,param_4);
    if (cVar2 == '\0') {
      FUN_140103eb0(plVar5);
      return (longlong *)0x0;
    }
  }
  iVar3 = FUN_1400fda10(plVar5,7,1);
  if ((((iVar3 < 0xc9) || (iVar3 = FUN_1400fda10(plVar5,7,1), 0xcc < iVar3)) &&
      (iVar3 = FUN_1400fda10(plVar5,7,1), iVar3 != 0xd0)) &&
     ((iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 2 ||
      (iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 3)))) {
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    FUN_14000d480(param_1 + 0x26,local_40,&local_res8);
  }
  local_50[0] = (**(code **)(*plVar5 + 8))(plVar5);
  local_48 = plVar5;
  FUN_1403218d0(param_1 + 0x13,local_40,local_50);
  if (local_30 == '\0') {
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    plVar7 = (longlong *)FUN_1403256a0(param_1 + 0x13,&local_res8);
    lVar1 = *plVar7;
    local_res8 = lVar1;
    if (lVar1 != 0) {
      FUN_1400fda10(lVar1,7,1);
      FUN_1400fda10(lVar1,2,1);
      FUN_1400fda10(lVar1,3,1);
      FUN_1400fda10(plVar5,7,1);
      FUN_1400fda10(plVar5,2,1);
      FUN_1400fda10(plVar5,3,1);
      (**(code **)(*plVar5 + 8))(plVar5);
      log_InlineLogERROR(
                        "CItemMgr::CreateItem by ItemInfoStruct. Item[%u] NewItem(UserID[%u], OwnerID[%u], Position[%d]) OldItem(UserID[%u], OwnerID[%u], Position[%d])  at %s, %d"
                        );
      FUN_140103eb0(local_res8);
    }
    uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
    local_res8 = CONCAT44(local_res8._4_4_,uVar4);
    puVar8 = (undefined8 *)FUN_1403256a0(param_1 + 0x13,&local_res8);
    *puVar8 = plVar5;
  }
  if (param_6 != '\0') {
    lVar1 = *param_1;
    uVar4 = FUN_1400fda10(plVar5,3,1);
    (**(code **)(lVar1 + 0x138))(param_1,uVar4,plVar5,1,0,0);
  }
  return plVar5;
}

// ==== CItemMgr::vfunc_3  @140326100  [high:rtti-vtable]  (orig: FUN_140326100)
longlong *
FUN_140326100(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,char param_6)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong local_res8;
  undefined4 local_50 [2];
  longlong *local_48;
  undefined1 local_40 [16];
  char local_30;
  
  lVar1 = param_1[2];
  local_res8 = FUN_1401012b0(0x70);
  if (local_res8 == 0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = (longlong *)FUN_1400fd8d0(local_res8,(int)lVar1);
  }
  if (plVar5 == (longlong *)0x0) {
    return (longlong *)0x0;
  }
  cVar2 = FUN_140101370(plVar5);
  if (cVar2 == '\0') {
    FUN_140103eb0(plVar5);
    return (longlong *)0x0;
  }
  cVar2 = FUN_140107ba0(plVar5,param_2,param_5,param_3,param_4);
  if (cVar2 != '\0') {
    iVar3 = FUN_1400fda10(plVar5,7,1);
    if ((((iVar3 < 0xc9) || (iVar3 = FUN_1400fda10(plVar5,7,1), 0xcc < iVar3)) &&
        (iVar3 = FUN_1400fda10(plVar5,7,1), iVar3 != 0xd0)) &&
       ((iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 2 ||
        (iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 3)))) {
      uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
      local_res8 = CONCAT44(local_res8._4_4_,uVar4);
      FUN_14000d480(param_1 + 0x26,local_40,&local_res8);
    }
    local_50[0] = (**(code **)(*plVar5 + 8))(plVar5);
    local_48 = plVar5;
    FUN_1403218d0(param_1 + 0x13,local_40,local_50);
    if (local_30 == '\0') {
      uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
      local_res8 = CONCAT44(local_res8._4_4_,uVar4);
      plVar6 = (longlong *)FUN_1403256a0(param_1 + 0x13,&local_res8);
      lVar1 = *plVar6;
      local_res8 = lVar1;
      if (lVar1 != 0) {
        FUN_1400fda10(lVar1,7,1);
        FUN_1400fda10(lVar1,2,1);
        FUN_1400fda10(lVar1,3,1);
        FUN_1400fda10(plVar5,7,1);
        FUN_1400fda10(plVar5,2,1);
        FUN_1400fda10(plVar5,3,1);
        (**(code **)(*plVar5 + 8))(plVar5);
        log_InlineLogERROR(
                          "CItemMgr::CreateItem by ItemType. Item[%u] NewItem(UserID[%u], OwnerID[%u], Position[%d]) OldItem(UserID[%u], OwnerID[%u], Position[%d])  at %s, %d"
                          );
        FUN_140103eb0(local_res8);
      }
      uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
      local_res8 = CONCAT44(local_res8._4_4_,uVar4);
      puVar7 = (undefined8 *)FUN_1403256a0(param_1 + 0x13,&local_res8);
      *puVar7 = plVar5;
    }
    if (param_6 != '\0') {
      lVar1 = *param_1;
      uVar4 = FUN_1400fda10(plVar5,3,1);
      (**(code **)(lVar1 + 0x138))(param_1,uVar4,plVar5,1,0,0);
    }
    return plVar5;
  }
  FUN_140103eb0(plVar5);
  return (longlong *)0x0;
}

// ==== CItemMgr::vfunc_2  @140326400  [high:rtti-vtable]  (orig: FUN_140326400)
longlong * FUN_140326400(longlong *param_1,undefined8 param_2,char param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong local_res8;
  undefined4 local_60 [2];
  longlong *local_58;
  undefined1 local_50 [16];
  char local_40;
  
  lVar1 = param_1[2];
  local_res8 = FUN_1401012b0(0x70);
  if (local_res8 == 0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = (longlong *)FUN_1400fd8d0(local_res8,(int)lVar1);
  }
  if (plVar5 != (longlong *)0x0) {
    cVar2 = FUN_140106510(plVar5,param_2);
    if ((cVar2 != '\0') && (cVar2 = FUN_140101370(plVar5), cVar2 != '\0')) {
      iVar3 = FUN_1400fda10(plVar5,7,1);
      if ((((iVar3 < 0xc9) || (iVar3 = FUN_1400fda10(plVar5,7,1), 0xcc < iVar3)) &&
          (iVar3 = FUN_1400fda10(plVar5,7,1), iVar3 != 0xd0)) &&
         ((iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 2 ||
          (iVar3 = (**(code **)(*param_1 + 0x148))(param_1,plVar5), iVar3 == 3)))) {
        uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
        local_res8 = CONCAT44(local_res8._4_4_,uVar4);
        FUN_14000d480(param_1 + 0x26,local_50,&local_res8);
      }
      local_60[0] = (**(code **)(*plVar5 + 8))(plVar5);
      local_58 = plVar5;
      FUN_1403218d0(param_1 + 0x13,local_50,local_60);
      if (local_40 == '\0') {
        uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
        local_res8 = CONCAT44(local_res8._4_4_,uVar4);
        plVar6 = (longlong *)FUN_1403256a0(param_1 + 0x13,&local_res8);
        lVar1 = *plVar6;
        local_res8 = lVar1;
        if (lVar1 != 0) {
          FUN_1400fda10(lVar1,7,1);
          FUN_1400fda10(lVar1,2,1);
          FUN_1400fda10(lVar1,3,1);
          FUN_1400fda10(plVar5,7,1);
          FUN_1400fda10(plVar5,2,1);
          FUN_1400fda10(plVar5,3,1);
          (**(code **)(*plVar5 + 8))(plVar5);
          log_InlineLogERROR(
                            "CItemMgr::CreateItem by IRecord. Item[%u] NewItem(UserID[%u], OwnerID[%u], Position[%d]) OldItem(UserID[%u], OwnerID[%u], Position[%d])  at %s, %d"
                            );
          FUN_140103eb0(local_res8);
        }
        uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
        local_res8 = CONCAT44(local_res8._4_4_,uVar4);
        puVar7 = (undefined8 *)FUN_1403256a0(param_1 + 0x13,&local_res8);
        *puVar7 = plVar5;
      }
      if (param_3 != '\0') {
        lVar1 = *param_1;
        uVar4 = FUN_1400fda10(plVar5,3,1);
        (**(code **)(lVar1 + 0x138))(param_1,uVar4,plVar5,1,0,0);
      }
      return plVar5;
    }
    FUN_140103eb0(plVar5);
    return (longlong *)0x0;
  }
  return (longlong *)0x0;
}

// ==== CItemMgr::vfunc_44  @1403266f0  [high:rtti-vtable]  (orig: FUN_1403266f0)
void FUN_1403266f0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_14000d630(param_1 + 0x130,local_res10);
  return;
}

// ==== CItemMgr::vfunc_48  @140326710  [high:rtti-vtable]  (orig: FUN_140326710)
void FUN_140326710(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_14000d630(param_1 + 0x178,local_res10);
  return;
}

// ==== CItemMgr::vfunc_49  @140326730  [high:rtti-vtable]  (orig: FUN_140326730)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140326730(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 auStack_5b8 [32];
  undefined4 local_598;
  undefined4 local_590;
  longlong *local_588;
  longlong *plStack_580;
  longlong *local_578;
  longlong *local_570;
  longlong *local_568;
  longlong *plStack_560;
  longlong *local_558;
  longlong *plStack_550;
  longlong *local_548;
  longlong *plStack_540;
  longlong *local_538;
  longlong *plStack_530;
  undefined8 local_528;
  longlong *local_518;
  longlong *plStack_510;
  longlong *local_508;
  longlong *plStack_500;
  undefined1 local_4f8 [16];
  undefined1 local_4e8 [16];
  undefined1 local_4d8 [16];
  undefined1 local_4c8 [16];
  undefined1 local_4b8 [16];
  undefined1 local_4a8 [16];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_528 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_5b8;
  local_570 = param_1 + 0x2f;
  plVar12 = *(longlong **)param_1[0x35];
  plVar13 = (longlong *)*local_570;
  plVar11 = local_570;
  local_588 = plVar13;
  plStack_580 = plVar12;
  local_578 = param_1;
LAB_1403267a0:
  do {
    while( true ) {
      while( true ) {
        while( true ) {
          while( true ) {
            plVar7 = (longlong *)plVar11[6];
            if ((plVar13 == (longlong *)0x0) || (plVar13 != (longlong *)*plVar11)) {
              _invalid_parameter_noinfo();
            }
            if (plVar12 == plVar7) {
              return;
            }
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar13;
            }
            if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            plVar7 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_598 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar13;
            }
            if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,(int)plVar12[3]);
            if (plVar7 != (longlong *)0x0) break;
            local_598 = 0x602;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar2 = plStack_580;
            plVar7 = local_588;
            if (plVar13 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
              plVar1 = (longlong *)plVar12[2];
              if (*(char *)((longlong)plVar1 + 0x1d) == '\0') {
                cVar3 = *(char *)(*plVar1 + 0x1d);
                plVar12 = plVar1;
                plVar1 = (longlong *)*plVar1;
                while (plStack_580 = plVar12, cVar3 == '\0') {
                  cVar3 = *(char *)(*plVar1 + 0x1d);
                  plVar12 = plVar1;
                  plVar1 = (longlong *)*plVar1;
                }
              }
              else {
                cVar3 = *(char *)(plVar12[1] + 0x1d);
                plVar8 = (longlong *)plVar12[1];
                plVar1 = plVar12;
                while ((plVar12 = plVar8, plStack_580 = plVar12, cVar3 == '\0' &&
                       (plVar1 == (longlong *)plVar12[2]))) {
                  cVar3 = *(char *)(plVar12[1] + 0x1d);
                  plVar8 = (longlong *)plVar12[1];
                  plVar1 = plVar12;
                }
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
            local_518 = plVar7;
            plStack_510 = plVar2;
            FUN_14000ab40(plVar11,local_4f8,&local_518);
          }
          iVar4 = FUN_1400fda10(plVar7,7,1);
          if ((((0 < iVar4) && (iVar4 = FUN_1400fda10(plVar7,7,1), iVar4 < 0x14)) ||
              ((iVar4 = FUN_1400fda10(plVar7,7,1), 0x14 < iVar4 &&
               (iVar4 = FUN_1400fda10(plVar7,7,1), iVar4 < 0x1e)))) ||
             ((iVar4 = FUN_1400fda10(plVar7,7,1), iVar4 == 0 ||
              (iVar4 = FUN_1400fda10(plVar7,7,1), iVar4 == 0xcf)))) break;
          local_598 = 0x60b;
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar5 = FUN_1400fda10(plVar7,7,1);
          FUN_1400fda10(plVar7,3,1);
          FUN_1400fda10(plVar7,2,1);
          (**(code **)(*plVar7 + 8))(plVar7);
          local_598 = uVar5;
          log_InlineLogWARNING
                    (
                    "CItemMgr::ProcessStatuItemTimer, Item[%u] owner_id[%d] player_id[%d] position[%d] is not in (bag or equip)"
                    );
          plVar2 = plStack_580;
          plVar7 = local_588;
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
            plVar1 = (longlong *)plVar12[2];
            if (*(char *)((longlong)plVar1 + 0x1d) == '\0') {
              cVar3 = *(char *)(*plVar1 + 0x1d);
              plVar12 = plVar1;
              plVar1 = (longlong *)*plVar1;
              while (plStack_580 = plVar12, cVar3 == '\0') {
                cVar3 = *(char *)(*plVar1 + 0x1d);
                plVar12 = plVar1;
                plVar1 = (longlong *)*plVar1;
              }
            }
            else {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar8 = (longlong *)plVar12[1];
              plVar1 = plVar12;
              while ((plVar12 = plVar8, plStack_580 = plVar12, cVar3 == '\0' &&
                     (plVar1 == (longlong *)plVar12[2]))) {
                cVar3 = *(char *)(plVar12[1] + 0x1d);
                plVar8 = (longlong *)plVar12[1];
                plVar1 = plVar12;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          local_538 = plVar7;
          plStack_530 = plVar2;
          FUN_14000ab40(plVar11,local_4a8,&local_538);
          param_1 = local_578;
        }
        uVar5 = FUN_1400fda10(plVar7,1,1);
        cVar3 = FUN_1400ff940(uVar5);
        if (cVar3 != '\0') break;
        local_598 = 0x614;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar2 = plStack_580;
        plVar7 = local_588;
        if (plVar13 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
          plVar1 = (longlong *)plVar12[2];
          if (*(char *)((longlong)plVar1 + 0x1d) == '\0') {
            cVar3 = *(char *)(*plVar1 + 0x1d);
            plVar12 = plVar1;
            plVar1 = (longlong *)*plVar1;
            while (plStack_580 = plVar12, cVar3 == '\0') {
              cVar3 = *(char *)(*plVar1 + 0x1d);
              plVar12 = plVar1;
              plVar1 = (longlong *)*plVar1;
            }
          }
          else {
            cVar3 = *(char *)(plVar12[1] + 0x1d);
            plVar8 = (longlong *)plVar12[1];
            plVar1 = plVar12;
            while ((plVar12 = plVar8, plStack_580 = plVar12, cVar3 == '\0' &&
                   (plVar1 == (longlong *)plVar12[2]))) {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar8 = (longlong *)plVar12[1];
              plVar1 = plVar12;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_558 = plVar7;
        plStack_550 = plVar2;
        FUN_14000ab40(plVar11,local_4c8,&local_558);
      }
      plVar8 = (longlong *)FUN_140100070(plVar7);
      plVar9 = (longlong *)FUN_140100290(plVar7);
      plVar1 = plStack_580;
      plVar2 = local_588;
      if (plVar8 != (longlong *)0x0) break;
      if (plVar9 != (longlong *)0x0) {
LAB_140326c71:
        cVar3 = (**(code **)(*plVar9 + 0x20))(plVar9);
        if (cVar3 != '\0') goto LAB_140326c7f;
        goto LAB_140326cf1;
      }
      if (plVar13 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
        plVar7 = (longlong *)plVar12[2];
        if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
          cVar3 = *(char *)(*plVar7 + 0x1d);
          plVar12 = plVar7;
          plVar7 = (longlong *)*plVar7;
          while (plStack_580 = plVar12, cVar3 == '\0') {
            cVar3 = *(char *)(*plVar7 + 0x1d);
            plVar12 = plVar7;
            plVar7 = (longlong *)*plVar7;
          }
        }
        else {
          cVar3 = *(char *)(plVar12[1] + 0x1d);
          plVar8 = (longlong *)plVar12[1];
          plVar7 = plVar12;
          while ((plVar12 = plVar8, plStack_580 = plVar12, cVar3 == '\0' &&
                 (plVar7 == (longlong *)plVar12[2]))) {
            cVar3 = *(char *)(plVar12[1] + 0x1d);
            plVar8 = (longlong *)plVar12[1];
            plVar7 = plVar12;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_548 = plVar2;
      plStack_540 = plVar1;
      FUN_14000ab40(plVar11,local_4e8,&local_548);
    }
    cVar3 = (**(code **)(*plVar8 + 0x20))(plVar8);
    if (cVar3 == '\0') {
LAB_140326cf1:
      uVar5 = FUN_1400fda10(plVar7,2,1);
      lVar10 = FUN_140008520((int)param_1[2]);
      if (*(longlong *)(lVar10 + 0x90) == 0) {
        local_598 = 0x130;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(lVar10 + 0x90) + 0x98))
                          (*(longlong **)(lVar10 + 0x90),uVar5);
      plVar13 = local_588;
      if (plVar11 == (longlong *)0x0) {
        iVar4 = FUN_1400fda10(plVar7,7,1);
        plVar13 = local_588;
        if (iVar4 != 0xcf) {
          if (local_588 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *local_588;
          }
          if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          param_1 = local_578;
          FUN_14000d630(local_578 + 0x26,plVar12 + 3);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar13;
          }
          if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          (**(code **)(*param_1 + 0x30))(param_1,(int)plVar12[3],0,0);
          plVar2 = plStack_580;
          plVar7 = local_588;
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
            plVar11 = (longlong *)plVar12[2];
            if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
              cVar3 = *(char *)(*plVar11 + 0x1d);
              plVar12 = plVar11;
              plVar11 = (longlong *)*plVar11;
              while (plStack_580 = plVar12, cVar3 == '\0') {
                cVar3 = *(char *)(*plVar11 + 0x1d);
                plVar12 = plVar11;
                plVar11 = (longlong *)*plVar11;
              }
            }
            else {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar1 = (longlong *)plVar12[1];
              plVar11 = plVar12;
              while ((plVar12 = plVar1, plStack_580 = plVar12, cVar3 == '\0' &&
                     (plVar11 == (longlong *)plVar12[2]))) {
                cVar3 = *(char *)(plVar12[1] + 0x1d);
                plVar1 = (longlong *)plVar12[1];
                plVar11 = plVar12;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          plVar11 = local_570;
          local_568 = plVar7;
          plStack_560 = plVar2;
          FUN_14000ab40(local_570,local_4d8,&local_568);
          goto LAB_1403267a0;
        }
      }
      else if ((char)plVar11[0x259] != '\0') {
        if (local_588 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
          plVar7 = (longlong *)plVar12[2];
          param_1 = local_578;
          plVar11 = local_570;
          if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
            cVar3 = *(char *)(*plVar7 + 0x1d);
            plVar12 = plVar7;
            plVar7 = (longlong *)*plVar7;
            while (plStack_580 = plVar12, cVar3 == '\0') {
              cVar3 = *(char *)(*plVar7 + 0x1d);
              plVar12 = plVar7;
              plVar7 = (longlong *)*plVar7;
            }
          }
          else {
            cVar3 = *(char *)(plVar12[1] + 0x1d);
            plVar2 = (longlong *)plVar12[1];
            plVar7 = plVar12;
            while ((plVar12 = plVar2, plStack_580 = plVar12, cVar3 == '\0' &&
                   (plVar7 == (longlong *)plVar12[2]))) {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar2 = (longlong *)plVar12[1];
              plVar7 = plVar12;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
          param_1 = local_578;
          plVar11 = local_570;
        }
        goto LAB_1403267a0;
      }
      if ((plVar8 != (longlong *)0x0) &&
         (cVar3 = (**(code **)(*plVar8 + 0x20))(plVar8), cVar3 == '\0')) {
        if (plVar11 == (longlong *)0x0) {
          FUN_1400fda10(plVar7,1,1);
          (**(code **)(*plVar7 + 8))(plVar7);
          tq::MyLogSave("gmlog/QuenchItem","Erase Temp Item Statu On Timer[id=%u, type=%u]");
        }
        else {
          uVar5 = FUN_1400fda10(plVar7,1,1);
          uVar6 = (**(code **)(*plVar7 + 8))(plVar7);
          (**(code **)(plVar11[2] + 0x18))(plVar11 + 2);
          local_598 = uVar6;
          local_590 = uVar5;
          tq::MyLogSave("gmlog/QuenchItem","%s(%u) Erase Temp Item Statu On Timer[id=%u, type=%u]");
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          FUN_1401ad8d0(plVar11,uVar5);
        }
        FUN_140100090(plVar7,0);
      }
      if ((plVar9 != (longlong *)0x0) &&
         (cVar3 = (**(code **)(*plVar9 + 0x20))(plVar9), cVar3 == '\0')) {
        if (plVar11 == (longlong *)0x0) {
          FUN_1400fda10(plVar7,1,1);
          (**(code **)(*plVar7 + 8))(plVar7);
          tq::MyLogSave("gmlog/ForgeItem","Erase Temp Item ForgeAttr On Timer[id=%u, type=%u]");
        }
        else {
          uVar5 = FUN_1400fda10(plVar7,1,1);
          uVar6 = (**(code **)(*plVar7 + 8))(plVar7);
          (**(code **)(*plVar11 + 8))(plVar11);
          (**(code **)(plVar11[2] + 0x18))(plVar11 + 2);
          local_598 = uVar6;
          local_590 = uVar5;
          tq::MyLogSave("gmlog/ForgeItem",
                        "%s(%u) Erase Temp Item ForgeAttr On Timer[id=%u, type=%u]");
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          FUN_140335030(plVar11,uVar5);
          uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
          cVar3 = FUN_14032b480(plVar11,uVar5);
          if (cVar3 != '\0') {
            FUN_14039ed70(local_498);
            iVar4 = FUN_14039eef0(local_498,plVar11 + 2,0);
            if (iVar4 != 0) {
              (**(code **)(plVar11[2] + 0x348))(plVar11 + 2,local_498,0);
            }
            FUN_14039edf0(local_498);
          }
        }
        FUN_140100210(plVar7,0);
      }
      lVar10 = FUN_140100070(plVar7);
      if ((lVar10 == 0) &&
         (lVar10 = FUN_140100290(plVar7), plVar7 = plStack_580, plVar13 = local_588, lVar10 == 0)) {
        if (local_588 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
          plVar11 = (longlong *)plVar12[2];
          if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
            cVar3 = *(char *)(*plVar11 + 0x1d);
            plVar12 = plVar11;
            plVar11 = (longlong *)*plVar11;
            while (plStack_580 = plVar12, cVar3 == '\0') {
              cVar3 = *(char *)(*plVar11 + 0x1d);
              plVar12 = plVar11;
              plVar11 = (longlong *)*plVar11;
            }
          }
          else {
            cVar3 = *(char *)(plVar12[1] + 0x1d);
            plVar2 = (longlong *)plVar12[1];
            plVar11 = plVar12;
            while ((plVar12 = plVar2, plStack_580 = plVar12, cVar3 == '\0' &&
                   (plVar11 == (longlong *)plVar12[2]))) {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar2 = (longlong *)plVar12[1];
              plVar11 = plVar12;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        plVar11 = local_570;
        local_508 = plVar13;
        plStack_500 = plVar7;
        FUN_14000ab40(local_570,local_4b8,&local_508);
        param_1 = local_578;
      }
      else {
        plVar13 = local_588;
        if (local_588 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
          plVar7 = (longlong *)plVar12[2];
          param_1 = local_578;
          plVar11 = local_570;
          if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
            cVar3 = *(char *)(*plVar7 + 0x1d);
            plVar12 = plVar7;
            plVar7 = (longlong *)*plVar7;
            while (plStack_580 = plVar12, cVar3 == '\0') {
              cVar3 = *(char *)(*plVar7 + 0x1d);
              plVar12 = plVar7;
              plVar7 = (longlong *)*plVar7;
            }
          }
          else {
            cVar3 = *(char *)(plVar12[1] + 0x1d);
            plVar2 = (longlong *)plVar12[1];
            plVar7 = plVar12;
            while ((plVar12 = plVar2, plStack_580 = plVar12, cVar3 == '\0' &&
                   (plVar7 == (longlong *)plVar12[2]))) {
              cVar3 = *(char *)(plVar12[1] + 0x1d);
              plVar2 = (longlong *)plVar12[1];
              plVar7 = plVar12;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
          param_1 = local_578;
          plVar11 = local_570;
        }
      }
      goto LAB_1403267a0;
    }
    if (plVar9 != (longlong *)0x0) goto LAB_140326c71;
LAB_140326c7f:
    if (plVar13 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar12 + 0x1d) == '\0') {
      plVar7 = (longlong *)plVar12[2];
      if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
        cVar3 = *(char *)(*plVar7 + 0x1d);
        plVar12 = plVar7;
        plVar7 = (longlong *)*plVar7;
        while (plStack_580 = plVar12, cVar3 == '\0') {
          cVar3 = *(char *)(*plVar7 + 0x1d);
          plVar12 = plVar7;
          plVar7 = (longlong *)*plVar7;
        }
      }
      else {
        cVar3 = *(char *)(plVar12[1] + 0x1d);
        plVar2 = (longlong *)plVar12[1];
        plVar7 = plVar12;
        while ((plVar12 = plVar2, plStack_580 = plVar12, cVar3 == '\0' &&
               (plVar7 == (longlong *)plVar12[2]))) {
          cVar3 = *(char *)(plVar12[1] + 0x1d);
          plVar2 = (longlong *)plVar12[1];
          plVar7 = plVar12;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CItemMgr::helper_1403275e0  @1403275e0  [medium:callgraph-r0]  (orig: FUN_1403275e0)
undefined8 * FUN_1403275e0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14031fcc0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CItemMgr::helper_140327660  @140327660  [medium:callgraph-r0]  (orig: FUN_140327660)
void FUN_140327660(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_140325a00(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CItemMgr::ctor_or_dtor  @140327740  [high:vtable-assign]  (orig: FUN_140327740)
void FUN_140327740(undefined8 *param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong local_68;
  undefined8 *puStack_60;
  longlong local_58;
  undefined8 *puStack_50;
  undefined1 local_48 [32];
  
  *param_1 = CItemMgr::vftable;
  plVar1 = param_1 + 0x13;
  plVar7 = *(longlong **)param_1[0x19];
  plVar3 = (longlong *)*plVar1;
  while( true ) {
    plVar4 = (longlong *)param_1[0x19];
    if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar4) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7[4] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_140103eb0();
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar4 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar7 = plVar4;
        plVar4 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar4 + 0x29);
          plVar7 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar2 = *(char *)(plVar7[1] + 0x29);
        plVar8 = (longlong *)plVar7[1];
        plVar4 = plVar7;
        while ((plVar7 = plVar8, cVar2 == '\0' && (plVar4 == (longlong *)plVar7[2]))) {
          cVar2 = *(char *)(plVar7[1] + 0x29);
          plVar8 = (longlong *)plVar7[1];
          plVar4 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar2 = *(char *)((longlong)*(longlong **)(param_1[0x19] + 8) + 0x29);
  plVar7 = *(longlong **)(param_1[0x19] + 8);
  while (cVar2 == '\0') {
    FUN_14031f960(plVar1,plVar7[2]);
    plVar3 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(undefined8 *)(param_1[0x19] + 8) = param_1[0x19];
  param_1[0x1a] = 0;
  *(undefined8 *)param_1[0x19] = param_1[0x19];
  *(undefined8 *)(param_1[0x19] + 0x10) = param_1[0x19];
  plVar7 = param_1 + 0x1b;
  plVar3 = (longlong *)*plVar7;
  plVar4 = *(longlong **)param_1[0x21];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar8 = plVar4;
          plVar4 = (longlong *)param_1[0x21];
          if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar7)) {
            _invalid_parameter_noinfo();
          }
          if (plVar8 == plVar4) {
            cVar2 = *(char *)((longlong)*(longlong **)(param_1[0x21] + 8) + 0x29);
            plVar3 = *(longlong **)(param_1[0x21] + 8);
            while (cVar2 == '\0') {
              FUN_14031f960(plVar7,plVar3[2]);
              plVar4 = (longlong *)*plVar3;
              operator_delete(plVar3);
              plVar3 = plVar4;
              cVar2 = *(char *)((longlong)plVar4 + 0x29);
            }
            *(undefined8 *)(param_1[0x21] + 8) = param_1[0x21];
            param_1[0x22] = 0;
            *(undefined8 *)param_1[0x21] = param_1[0x21];
            *(undefined8 *)(param_1[0x21] + 0x10) = param_1[0x21];
            if (param_1[0x23] != 0) {
              FUN_14001aff0(local_48,"ItemType",4);
              puVar5 = (undefined8 *)param_1[0x23];
              if (puVar5 != (undefined8 *)0x0) {
                (**(code **)*puVar5)(puVar5,1);
              }
              FUN_14001b030(local_48);
            }
            if (param_1[0x24] != 0) {
              FUN_14001aff0(local_48,"ItemAddition",4);
              puVar5 = (undefined8 *)param_1[0x24];
              if (puVar5 != (undefined8 *)0x0) {
                (**(code **)*puVar5)(puVar5,1);
              }
              FUN_14001b030(local_48);
            }
            if (param_1[0x25] != 0) {
              FUN_14001aff0(local_48,"WeaponSkillUp",4);
              puVar5 = (undefined8 *)param_1[0x25];
              if (puVar5 != (undefined8 *)0x0) {
                (**(code **)*puVar5)(puVar5,1);
              }
              FUN_14001b030(local_48);
            }
            plVar3 = param_1 + 0x42;
            cVar2 = *(char *)((longlong)*(longlong **)(param_1[0x48] + 8) + 0x21);
            plVar4 = *(longlong **)(param_1[0x48] + 8);
            while (cVar2 == '\0') {
              FUN_14009ac40(plVar3,plVar4[2]);
              plVar8 = (longlong *)*plVar4;
              operator_delete(plVar4);
              plVar4 = plVar8;
              cVar2 = *(char *)((longlong)plVar8 + 0x21);
            }
            *(undefined8 *)(param_1[0x48] + 8) = param_1[0x48];
            param_1[0x49] = 0;
            *(undefined8 *)param_1[0x48] = param_1[0x48];
            *(undefined8 *)(param_1[0x48] + 0x10) = param_1[0x48];
            puStack_60 = (undefined8 *)param_1[0x48];
            local_68 = *plVar3;
            puStack_50 = (undefined8 *)*puStack_60;
            local_58 = local_68;
            FUN_1400a4100(plVar3,local_48,&local_58,&local_68);
            operator_delete((void *)param_1[0x48]);
            param_1[0x48] = 0;
            param_1[0x49] = 0;
            operator_delete((void *)*plVar3);
            plVar3 = param_1 + 0x3a;
            puStack_50 = (undefined8 *)param_1[0x40];
            local_68 = *plVar3;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_140321350(plVar3,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x40]);
            param_1[0x40] = 0;
            param_1[0x41] = 0;
            operator_delete((void *)*plVar3);
            plVar3 = param_1 + 0x2f;
            puStack_50 = (undefined8 *)param_1[0x35];
            local_68 = *plVar3;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_14000bd50(plVar3,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x35]);
            param_1[0x35] = 0;
            param_1[0x36] = 0;
            operator_delete((void *)*plVar3);
            plVar3 = param_1 + 0x26;
            puStack_50 = (undefined8 *)param_1[0x2c];
            local_68 = *plVar3;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_14000bd50(plVar3,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x2c]);
            param_1[0x2c] = 0;
            param_1[0x2d] = 0;
            operator_delete((void *)*plVar3);
            puStack_50 = (undefined8 *)param_1[0x21];
            local_68 = *plVar7;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_1403226b0(plVar7,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x21]);
            param_1[0x21] = 0;
            param_1[0x22] = 0;
            operator_delete((void *)*plVar7);
            puStack_50 = (undefined8 *)param_1[0x19];
            local_68 = *plVar1;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_1403226b0(plVar1,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x19]);
            param_1[0x19] = 0;
            param_1[0x1a] = 0;
            operator_delete((void *)*plVar1);
            plVar1 = param_1 + 0xb;
            puStack_50 = (undefined8 *)param_1[0x11];
            local_68 = *plVar1;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_1402ae050(plVar1,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[0x11]);
            param_1[0x11] = 0;
            param_1[0x12] = 0;
            operator_delete((void *)*plVar1);
            plVar1 = param_1 + 3;
            puStack_50 = (undefined8 *)param_1[9];
            local_68 = *plVar1;
            puStack_60 = (undefined8 *)*puStack_50;
            local_58 = local_68;
            FUN_14000bd50(plVar1,local_48,&local_68,&local_58);
            operator_delete((void *)param_1[9]);
            param_1[9] = 0;
            param_1[10] = 0;
            operator_delete((void *)*plVar1);
            return;
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar3;
          }
          if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar8[4] == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            FUN_140103eb0();
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar8 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar4 = plVar8;
        }
        plVar4 = (longlong *)plVar8[2];
        if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
        cVar2 = *(char *)(*plVar4 + 0x29);
        plVar8 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar8 + 0x29);
          plVar4 = plVar8;
          plVar8 = (longlong *)*plVar8;
        }
      }
      plVar4 = (longlong *)plVar8[1];
    } while (*(char *)((longlong)plVar4 + 0x29) != '\0');
    do {
      plVar6 = plVar4;
      plVar4 = plVar6;
      if (plVar8 != (longlong *)plVar6[2]) break;
      plVar4 = (longlong *)plVar6[1];
      plVar8 = plVar6;
    } while (*(char *)((longlong)plVar4 + 0x29) == '\0');
  } while( true );
}

// ==== CItemMgr::vfunc_21  @140327ef0  [high:rtti-vtable]  (orig: FUN_140327ef0)
void FUN_140327ef0(undefined8 param_1,undefined4 param_2)

{
  FUN_1400ff680(param_2);
  return;
}

// ==== CItemMgr::vfunc_22  @140327f00  [high:rtti-vtable]  (orig: FUN_140327f00)
void FUN_140327f00(undefined8 param_1,undefined4 param_2)

{
  FUN_1400fecd0(param_2);
  return;
}

// ==== CItemMgr::vfunc_26  @140327f10  [high:rtti-vtable]  (orig: FUN_140327f10)
undefined4 FUN_140327f10(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1c8);
}

// ==== CItemMgr::vfunc_29  @140327f20  [high:rtti-vtable]  (orig: FUN_140327f20)
undefined4 FUN_140327f20(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1cc);
}

// ==== CItemMgr::vfunc_30  @140327f30  [high:rtti-vtable]  (orig: FUN_140327f30)
void FUN_140327f30(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1cc) = param_2;
  return;
}

// ==== CItemMgr::vfunc_5  @140327f40  [high:rtti-vtable]  (orig: FUN_140327f40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140327f40(longlong param_1,int param_2,longlong param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined8 *puVar14;
  longlong *plVar15;
  rsize_t _DstSize;
  longlong *plVar16;
  longlong *plVar17;
  undefined1 auStack_598 [32];
  undefined4 local_578;
  undefined4 local_570;
  undefined4 local_568;
  undefined4 local_560;
  char *local_558;
  undefined4 local_550;
  longlong *local_548;
  int local_540;
  longlong *local_538;
  longlong *plStack_530;
  longlong *local_528 [3];
  longlong *local_510;
  longlong *local_508;
  longlong local_500;
  longlong local_4f8;
  longlong *local_4f0;
  longlong local_4e8;
  longlong *local_4e0;
  longlong *local_4d8;
  longlong *plStack_4d0;
  longlong *local_4c8 [3];
  void *local_4b0;
  undefined8 local_4a8;
  undefined8 local_4a0;
  longlong local_498;
  longlong *local_488;
  longlong *plStack_480;
  longlong *local_478;
  longlong *plStack_470;
  undefined8 local_468;
  undefined1 local_460 [16];
  char local_450;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_468 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  if ((param_2 < 1) || (param_3 == 0)) {
    uVar12 = 0;
  }
  else if (*(int *)(param_1 + 0x1c8) == 0) {
    uVar12 = 0;
  }
  else {
    local_448 = '\0';
    local_4f8 = param_1;
    local_4e8 = param_1;
    local_498 = param_3;
    memset(local_447,0,0x3ff);
    _snprintf(&local_448,0x3ff,PTR_s_SELECT___FROM_cq_itemstatus_WHER_1409537e8);
    local_49 = 0;
    plVar8 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))
                       (*(longlong **)(param_1 + 8),&local_448,2);
    if (plVar8 == (longlong *)0x0) {
      local_578 = 0x27e;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar12 = 0;
    }
    else {
      local_548 = operator_new(8);
      if (local_548 == (longlong *)0x0) {
        local_528[0] = (longlong *)0x0;
      }
      else {
        *local_548 = (longlong)local_528;
        local_528[0] = local_548;
      }
      plVar17 = (longlong *)0x0;
      local_510 = (longlong *)0x0;
      local_508 = (longlong *)0x0;
      local_500 = 0;
      local_4e0 = local_548;
      lVar9 = (**(code **)(*plVar8 + 0x40))(plVar8);
      plVar11 = plVar17;
      if (lVar9 != 0) {
        do {
          (**(code **)(*plVar8 + 0x30))(plVar8,plVar11);
          local_548 = (longlong *)(**(code **)(*plVar8 + 0x38))(plVar8);
          plVar10 = local_508;
          if ((local_510 == (longlong *)0x0) ||
             ((ulonglong)(local_500 - (longlong)local_510 >> 3) <=
              (ulonglong)((longlong)local_508 - (longlong)local_510 >> 3))) {
            if (local_508 < local_510) {
              _invalid_parameter_noinfo();
            }
            plVar15 = local_510;
            plVar13 = local_528[0];
            local_538 = local_528[0];
            plStack_530 = plVar10;
            plVar16 = plVar17;
            if (((longlong)local_508 - (longlong)local_510 & 0xfffffffffffffff8U) != 0) {
              if (local_508 < local_510) {
                _invalid_parameter_noinfo();
              }
              if ((plVar13 == (longlong *)0x0) || (plVar13 != local_528[0])) {
                _invalid_parameter_noinfo();
              }
              plVar16 = (longlong *)((longlong)plVar10 - (longlong)plVar15 >> 3);
            }
            local_4d8 = local_538;
            plStack_4d0 = plStack_530;
            FUN_1400183c0(local_528,&local_4d8,1,&local_548);
            plVar10 = local_510;
            if (local_508 < local_510) {
              _invalid_parameter_noinfo();
            }
            plVar13 = local_528[0];
            if (local_528[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar15 = plVar17;
            }
            else {
              plVar15 = (longlong *)*local_528[0];
            }
            if (plVar10 + (longlong)plVar16 <= (longlong *)plVar15[4]) {
              plVar15 = plVar17;
              if (plVar13 != (longlong *)0x0) {
                plVar15 = (longlong *)*plVar13;
              }
              if ((longlong *)plVar15[3] <= plVar10 + (longlong)plVar16) goto LAB_1403281fa;
            }
            _invalid_parameter_noinfo();
          }
          else {
            *local_508 = (longlong)local_548;
            local_508 = local_508 + 1;
          }
LAB_1403281fa:
          plVar11 = (longlong *)(ulonglong)((int)plVar11 + 1);
          plVar10 = (longlong *)(**(code **)(*plVar8 + 0x40))(plVar8);
        } while (plVar11 < plVar10);
      }
      (**(code **)*plVar8)(plVar8);
      for (local_540 = 0; plVar8 = local_510, local_540 < param_2; local_540 = local_540 + 1) {
        if (*(int *)(local_498 + (longlong)local_540 * 4) != 0) {
          _snprintf(&local_448,0x3ff,PTR_s_SELECT___FROM_cq_item_WHERE_id___1409539b0);
          local_49 = 0;
          plVar8 = (longlong *)
                   (**(code **)(**(longlong **)(param_1 + 8) + 0x10))
                             (*(longlong **)(param_1 + 8),&local_448,2);
          if ((plVar8 == (longlong *)0x0) ||
             (lVar9 = (**(code **)(*plVar8 + 0x40))(plVar8), lVar9 == 0)) {
            plVar11 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0);
            plVar10 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,2);
            plVar13 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,3);
            (**(code **)(*plVar11 + 0x40))(plVar11);
            (**(code **)(*plVar10 + 0x40))(plVar10);
            (**(code **)(*plVar13 + 0x40))(plVar13);
            log_InlineLogERROR(&DAT_140751278);
            (**(code **)*plVar8)(plVar8);
          }
          else {
            plVar11 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,2);
            iVar2 = (**(code **)(*plVar11 + 0x40))(plVar11);
            if (*(int *)(param_1 + 0x1c8) == iVar2) {
              plVar11 = (longlong *)FUN_140103820(*(undefined4 *)(param_1 + 0x10));
              local_548 = plVar11;
              if (plVar11 == (longlong *)0x0) {
                (**(code **)*plVar8)(plVar8);
              }
              else {
                uVar12 = (**(code **)(*plVar8 + 0x38))(plVar8);
                cVar1 = FUN_140106510(plVar11,uVar12);
                if ((cVar1 == '\0') || (cVar1 = FUN_140101370(plVar11), cVar1 == '\0')) {
                  plVar10 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0);
                  plVar13 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,2);
                  plVar15 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,3);
                  (**(code **)(*plVar10 + 0x40))(plVar10);
                  (**(code **)(*plVar13 + 0x40))(plVar13);
                  (**(code **)(*plVar15 + 0x40))(plVar15);
                  log_InlineLogERROR(&DAT_1407512b0);
                  FUN_140103eb0(plVar11);
                  (**(code **)*plVar8)(plVar8);
                }
                else {
                  (**(code **)*plVar8)(plVar8);
                  cVar1 = FUN_1400ffcb0(plVar11);
                  if (cVar1 == '\0') {
                    uVar3 = FUN_1400fda10(plVar11,3,1);
                    (**(code **)(*plVar11 + 8))(plVar11);
                    local_578 = uVar3;
                    tq::GmLogSave("invalid_item","invalid item:[%u] found in user:[%s][%u]");
                    FUN_140103eb0(plVar11);
                  }
                  else {
                    uVar3 = FUN_1400fda10(plVar11,1,1);
                    cVar1 = FUN_1400ff940(uVar3);
                    if (cVar1 != '\0') {
                      local_4f0 = operator_new(8);
                      plVar8 = local_510;
                      local_4c8[0] = plVar17;
                      if (local_4f0 != (longlong *)0x0) {
                        *local_4f0 = (longlong)local_4c8;
                        local_4c8[0] = local_4f0;
                      }
                      local_4b0 = (void *)0x0;
                      local_4a8 = 0;
                      local_4a0 = 0;
                      local_4e0 = local_4f0;
                      if (local_508 < local_510) {
                        _invalid_parameter_noinfo();
                      }
                      local_478 = local_528[0];
                      plStack_470 = plVar8;
                      local_538 = local_528[0];
                      plVar10 = local_528[0];
                      plStack_530 = plVar8;
                      while( true ) {
                        plVar13 = local_508;
                        if (local_508 < local_510) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar10 == (longlong *)0x0) || (plVar10 != local_528[0])) {
                          _invalid_parameter_noinfo();
                        }
                        if (plVar8 == plVar13) break;
                        if (plVar10 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          plVar13 = plVar17;
                        }
                        else {
                          plVar13 = (longlong *)*plVar10;
                        }
                        if ((longlong *)plVar13[4] <= plVar8) {
                          _invalid_parameter_noinfo();
                        }
                        plVar13 = (longlong *)
                                  (**(code **)(*(longlong *)*plVar8 + 0x10))((longlong *)*plVar8,1);
                        iVar2 = (**(code **)(*plVar13 + 0x40))(plVar13);
                        iVar4 = (**(code **)(*plVar11 + 8))(plVar11);
                        if (iVar2 == iVar4) {
                          if (plVar10 == (longlong *)0x0) {
                            _invalid_parameter_noinfo();
                            plVar10 = plVar17;
                          }
                          else {
                            plVar10 = (longlong *)*plVar10;
                          }
                          if ((longlong *)plVar10[4] <= plVar8) {
                            _invalid_parameter_noinfo();
                          }
                          FUN_140019370(local_4c8,plVar8);
                          lVar9 = (longlong)local_508 - (longlong)(plVar8 + 1) >> 3;
                          if (0 < lVar9) {
                            _DstSize = lVar9 << 3;
                            memmove_s(plVar8,_DstSize,plVar8 + 1,_DstSize);
                          }
                          local_508 = local_508 + -1;
                          if ((plVar8 < local_510) || (local_508 < plVar8)) {
                            _invalid_parameter_noinfo();
                          }
                          local_488 = local_528[0];
                          local_538 = local_528[0];
                          plVar10 = local_528[0];
                          plStack_530 = plVar8;
                          plStack_480 = plVar8;
                        }
                        else {
                          if (plVar10 == (longlong *)0x0) {
                            _invalid_parameter_noinfo();
                            plVar13 = plVar17;
                          }
                          else {
                            plVar13 = (longlong *)*plVar10;
                          }
                          if ((longlong *)plVar13[4] <= plVar8) {
                            _invalid_parameter_noinfo();
                          }
                          plVar8 = plVar8 + 1;
                        }
                      }
                      FUN_140108580(plVar11,local_4c8,0);
                      if (local_4b0 != (void *)0x0) {
                        operator_delete(local_4b0);
                      }
                      local_4b0 = (void *)0x0;
                      local_4a8 = 0;
                      local_4a0 = 0;
                      operator_delete(local_4c8[0]);
                    }
                    uVar3 = (**(code **)(*plVar11 + 8))(plVar11);
                    local_4d8 = (longlong *)CONCAT44(local_4d8._4_4_,uVar3);
                    plVar8 = (longlong *)(param_1 + 0xd8);
                    local_4e0 = plVar8;
                    plStack_4d0 = plVar11;
                    FUN_1403218d0(plVar8,local_460,&local_4d8);
                    if (local_450 == '\0') {
                      uVar3 = (**(code **)(*plVar11 + 8))(plVar11);
                      local_4f0 = (longlong *)CONCAT44(local_4f0._4_4_,uVar3);
                      plVar10 = (longlong *)FUN_1403256a0(plVar8,&local_4f0);
                      plVar10 = (longlong *)*plVar10;
                      local_4f0 = plVar10;
                      if (plVar10 != (longlong *)0x0) {
                        uVar3 = FUN_1400fda10(plVar10,7,1);
                        uVar5 = FUN_1400fda10(plVar10,2,1);
                        uVar6 = FUN_1400fda10(plVar10,3,1);
                        plVar8 = local_548;
                        uVar7 = FUN_1400fda10(local_548,7,1);
                        FUN_1400fda10(plVar8,2,1);
                        FUN_1400fda10(plVar8,3,1);
                        (**(code **)(*local_548 + 8))();
                        local_550 = 0x2df;
                        local_558 = 
                        "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\itemmgr.cpp"
                        ;
                        local_578 = uVar7;
                        local_570 = uVar6;
                        local_568 = uVar5;
                        local_560 = uVar3;
                        log_InlineLogERROR(
                                          "CItemMgr::LoadDetainEquip. Item[%u] NewItem(UserID[%u], OwnerID[%u], Position[%d]) OldItem(UserID[%u], OwnerID[%u], Position[%d])  at %s, %d"
                                          );
                        FUN_140103eb0(local_4f0);
                        plVar8 = local_4e0;
                        plVar11 = local_548;
                        param_1 = local_4f8;
                      }
                      uVar3 = (**(code **)(*plVar11 + 8))(plVar11);
                      local_4f0 = (longlong *)CONCAT44(local_4f0._4_4_,uVar3);
                      puVar14 = (undefined8 *)FUN_1403256a0(plVar8,&local_4f0);
                      *puVar14 = plVar11;
                    }
                  }
                }
              }
            }
            else {
              (**(code **)*plVar8)(plVar8);
            }
          }
        }
      }
      if (local_508 < local_510) {
        _invalid_parameter_noinfo();
      }
      plVar11 = local_528[0];
      local_4d8 = local_528[0];
      plStack_4d0 = plVar8;
      local_538 = local_528[0];
      plStack_530 = plVar8;
      while( true ) {
        plVar10 = local_508;
        plVar8 = plStack_530;
        if (local_508 < local_510) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == (longlong *)0x0) || (plVar11 != local_528[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar8 == plVar10) break;
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar17;
        }
        else {
          plVar10 = (longlong *)*plVar11;
        }
        if ((longlong *)plVar10[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar10 = (longlong *)(**(code **)(*(longlong *)*plVar8 + 0x10))((longlong *)*plVar8,2);
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar13 = plVar17;
        }
        else {
          plVar13 = (longlong *)*plVar11;
        }
        if ((longlong *)plVar13[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar13 = (longlong *)(**(code **)(*(longlong *)*plVar8 + 0x10))((longlong *)*plVar8,1);
        (**(code **)(*plVar10 + 0x40))(plVar10);
        (**(code **)(*plVar13 + 0x40))(plVar13);
        log_InlineLogWARNING("Item[%u] userid[%u] ItemStatus is not Load");
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar17;
        }
        else {
          plVar10 = (longlong *)*plVar11;
        }
        if ((longlong *)plVar10[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        if (*plVar8 != 0) {
          (*(code *)**(undefined8 **)*plVar8)((undefined8 *)*plVar8,1);
          *plVar8 = 0;
        }
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar17;
        }
        else {
          plVar10 = (longlong *)*plVar11;
        }
        if ((longlong *)plVar10[4] <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plStack_530 = plVar8 + 1;
      }
      if (local_510 != (longlong *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (longlong *)0x0;
      local_508 = (longlong *)0x0;
      local_500 = 0;
      operator_delete(local_528[0]);
      uVar12 = 1;
    }
  }
  return uVar12;
}

// ==== CItemMgr::vfunc_9  @140328ae0  [high:rtti-vtable]  (orig: FUN_140328ae0)
undefined1
FUN_140328ae0(longlong *param_1,int param_2,int param_3,int param_4,ushort param_5,longlong param_6)

{
  undefined4 *puVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong lVar15;
  undefined8 local_128;
  undefined8 uStack_120;
  longlong *local_118;
  undefined8 *puStack_110;
  undefined8 local_108 [2];
  longlong *local_f8;
  undefined4 *puStack_f0;
  undefined8 *local_e8;
  longlong *local_e0;
  longlong *local_d8 [3];
  void *local_c0;
  undefined8 local_b8;
  undefined8 local_b0;
  longlong *local_a8;
  longlong *local_98;
  longlong *local_88;
  undefined8 *puStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  undefined1 local_60 [16];
  undefined1 local_50 [24];
  
  local_68 = 0xfffffffffffffffe;
  if ((param_2 == 0) || (param_4 == 0)) {
    log_InlineLogERROR(
                      "CItemMgr::LoadUserStorage idOwner or idPlayer is 0, idOwner:%u, idPlayer:%u, nPosition:%d."
                      );
    uVar3 = 0;
  }
  else {
    uVar7 = FUN_140008520((int)param_1[2]);
    plVar8 = (longlong *)FUN_1400875f0(uVar7);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,param_4);
    if (plVar8 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      local_108[0] = 0;
      cVar2 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1001,local_108);
      uVar3 = 0;
      if (cVar2 != '\0') {
        puVar9 = (undefined8 *)FUN_14032b460(local_108[0]);
        uStack_120 = (undefined4 *)puVar9[3];
        local_f8 = (longlong *)0x0;
        local_e8 = puVar9;
        if ((undefined4 *)puVar9[4] < uStack_120) {
          _invalid_parameter_noinfo();
        }
        plVar8 = (longlong *)*puVar9;
        local_f8 = plVar8;
        puStack_f0 = uStack_120;
        FUN_1403257d0(param_6);
        local_128 = plVar8;
        while( true ) {
          puVar1 = (undefined4 *)puVar9[4];
          local_a8 = (longlong *)0x0;
          if (puVar1 < (undefined4 *)puVar9[3]) {
            _invalid_parameter_noinfo();
          }
          local_a8 = (longlong *)*puVar9;
          if ((plVar8 == (longlong *)0x0) || (plVar8 != local_a8)) {
            _invalid_parameter_noinfo();
          }
          if (uStack_120 == puVar1) break;
          if (plVar8 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = 0;
          }
          else {
            lVar15 = *plVar8;
          }
          if (*(undefined4 **)(lVar15 + 0x20) <= uStack_120) {
            _invalid_parameter_noinfo();
          }
          plVar10 = (longlong *)(**(code **)(*param_1 + 0x60))(param_1,*uStack_120);
          local_e0 = plVar10;
          if (plVar10 == (longlong *)0x0) {
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar15 = 0;
            }
            else {
              lVar15 = *plVar8;
            }
            if (*(undefined4 **)(lVar15 + 0x20) <= uStack_120) {
              _invalid_parameter_noinfo();
            }
            log_InlineLogERROR(
                              "CItemMgr::LoadUserStorage pItem is null, idUser:%u, idOwner:%u, position:%d, idItem:%u."
                              );
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar15 = 0;
            }
            else {
              lVar15 = *plVar8;
            }
            if (*(undefined4 **)(lVar15 + 0x20) <= uStack_120) {
              _invalid_parameter_noinfo();
            }
            uStack_120 = uStack_120 + 1;
          }
          else {
            iVar4 = FUN_1400fda10(plVar10,2,1);
            if (iVar4 == param_2) {
              iVar4 = FUN_1400fda10(plVar10,7,1);
              if (iVar4 != param_3) goto LAB_140329142;
              iVar4 = FUN_1400fda10(plVar10,3,1);
              if (iVar4 != param_4) goto LAB_140329142;
              local_78 = (undefined4)local_128;
              uStack_74 = local_128._4_4_;
              uStack_70 = (undefined4)uStack_120;
              uStack_6c = uStack_120._4_4_;
              puVar11 = (undefined8 *)FUN_1400431b0(puVar9,local_60,&local_78);
              plVar8 = (longlong *)*puVar11;
              uStack_120 = (undefined4 *)puVar11[1];
              cVar2 = FUN_1400ffcb0(plVar10);
              local_128 = plVar8;
              if (cVar2 == '\0') {
                (**(code **)(*plVar10 + 8))(plVar10);
                log_InlineLogWARNING("invalid item:[%u] found in user:[%s][%u]");
                plVar12 = DAT_140975b60;
                if (DAT_140975b60 == (longlong *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                lVar15 = *plVar12;
                uVar5 = (**(code **)(*plVar10 + 8))(plVar10);
                (**(code **)(lVar15 + 0x58))(plVar12,uVar5,0);
              }
              else {
                if (param_4 != 0) {
                  plVar12 = (longlong *)FUN_140087ed0();
                  iVar4 = (**(code **)(*plVar12 + 0xb0))(plVar12,param_4);
                  iVar6 = FUN_1400fda10(plVar10,0x17,1);
                  if (iVar6 != 0) {
                    iVar6 = FUN_1400fda10(plVar10,0x17,1);
                    if (iVar6 != iVar4) {
                      plVar12 = (longlong *)FUN_140087f50();
                      lVar15 = *plVar12;
                      uVar5 = (**(code **)(*plVar10 + 8))(plVar10);
                      (**(code **)(lVar15 + 0x48))(plVar12,param_4,uVar5);
                      FUN_140104140(plVar10,0x17,0);
                    }
                  }
                }
                uVar5 = FUN_1400fda10(plVar10,1,1);
                cVar2 = FUN_1400ff940(uVar5);
                if (cVar2 != '\0') {
                  local_f8 = operator_new(8);
                  if (local_f8 == (longlong *)0x0) {
                    local_d8[0] = (longlong *)0x0;
                  }
                  else {
                    *local_f8 = (longlong)local_d8;
                    local_d8[0] = local_f8;
                  }
                  local_c0 = (void *)0x0;
                  local_b8 = 0;
                  local_b0 = 0;
                  local_a8 = local_f8;
                  plVar12 = (longlong *)FUN_14032b470(local_108[0]);
                  puStack_110 = (undefined8 *)plVar12[3];
                  if ((undefined8 *)plVar12[4] < puStack_110) {
                    _invalid_parameter_noinfo();
                  }
                  plVar14 = (longlong *)*plVar12;
                  local_118 = plVar14;
                  while( true ) {
                    lVar15 = 0;
                    puVar9 = (undefined8 *)plVar12[4];
                    local_98 = (longlong *)0x0;
                    if (puVar9 < (undefined8 *)plVar12[3]) {
                      _invalid_parameter_noinfo();
                    }
                    local_98 = (longlong *)*plVar12;
                    if ((plVar14 == (longlong *)0x0) || (plVar14 != local_98)) {
                      _invalid_parameter_noinfo();
                    }
                    if (puStack_110 == puVar9) break;
                    if (plVar14 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                    }
                    else {
                      lVar15 = *plVar14;
                    }
                    if (*(undefined8 **)(lVar15 + 0x20) <= puStack_110) {
                      _invalid_parameter_noinfo();
                    }
                    plVar13 = (longlong *)
                              (**(code **)(*(longlong *)*puStack_110 + 0x10))
                                        ((longlong *)*puStack_110,1);
                    iVar4 = (**(code **)(*plVar10 + 8))(plVar10);
                    iVar6 = (**(code **)(*plVar13 + 0x48))(plVar13);
                    if (iVar6 == iVar4) {
                      if (plVar14 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar15 = 0;
                      }
                      else {
                        lVar15 = *plVar14;
                      }
                      if (*(undefined8 **)(lVar15 + 0x20) <= puStack_110) {
                        _invalid_parameter_noinfo();
                      }
                      FUN_140019370(local_d8,puStack_110);
                      local_88 = local_118;
                      puStack_80 = puStack_110;
                      plVar13 = (longlong *)FUN_140017960(plVar12,local_50);
                      plVar14 = (longlong *)*plVar13;
                      puStack_110 = (undefined8 *)plVar13[1];
                      local_118 = plVar14;
                    }
                    else {
                      if (plVar14 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar15 = 0;
                      }
                      else {
                        lVar15 = *plVar14;
                      }
                      if (*(undefined8 **)(lVar15 + 0x20) <= puStack_110) {
                        _invalid_parameter_noinfo();
                      }
                      puStack_110 = puStack_110 + 1;
                    }
                  }
                  FUN_140108580(plVar10,local_d8,0);
                  if (local_c0 != (void *)0x0) {
                    operator_delete(local_c0);
                  }
                  local_c0 = (void *)0x0;
                  local_b8 = 0;
                  local_b0 = 0;
                  operator_delete(local_d8[0]);
                  puVar9 = local_e8;
                }
                plVar12 = DAT_140975b60;
                if ((ushort)((longlong)
                             (ulonglong)(uint)(*(int *)(param_6 + 0x20) - *(int *)(param_6 + 0x18))
                            >> 3) < param_5) {
                  FUN_140327660(param_6,&local_e0);
                }
                else {
                  if (DAT_140975b60 == (longlong *)0x0) {
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  lVar15 = *plVar12;
                  uVar5 = (**(code **)(*plVar10 + 8))(plVar10);
                  (**(code **)(lVar15 + 0x58))(plVar12,uVar5,0);
                }
              }
            }
            else {
LAB_140329142:
              if (plVar8 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar15 = 0;
              }
              else {
                lVar15 = *plVar8;
              }
              if (*(undefined4 **)(lVar15 + 0x20) <= uStack_120) {
                _invalid_parameter_noinfo();
              }
              uStack_120 = uStack_120 + 1;
            }
          }
        }
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CItemMgr::vfunc_10  @1403291b0  [high:rtti-vtable]  (orig: FUN_1403291b0)
void FUN_1403291b0(longlong param_1,int param_2,undefined8 *param_3)

{
  longlong *plVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  undefined8 uVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong lVar14;
  rsize_t rVar15;
  ulonglong uVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong *local_168 [3];
  longlong *local_150;
  longlong *local_148;
  undefined8 local_140;
  longlong *local_138 [3];
  longlong *local_120;
  longlong *local_118;
  longlong local_110;
  longlong *local_108;
  longlong *plStack_100;
  longlong *local_f8;
  longlong *local_f0 [3];
  longlong *local_d8;
  longlong *local_d0;
  undefined8 local_c8;
  undefined8 local_b8;
  undefined8 uStack_b0;
  longlong *local_a8;
  longlong *plStack_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  longlong *local_88;
  longlong *plStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  undefined1 local_50 [24];
  
  if (param_2 != 0) {
    local_58 = 0xfffffffffffffffe;
    local_f8 = operator_new(8);
    if (local_f8 == (longlong *)0x0) {
      local_f0[0] = (longlong *)0x0;
    }
    else {
      *local_f8 = (longlong)local_f0;
      local_f0[0] = local_f8;
    }
    local_d8 = (longlong *)0x0;
    local_d0 = (longlong *)0x0;
    local_c8 = 0;
    local_f8 = operator_new(8);
    if (local_f8 == (longlong *)0x0) {
      local_168[0] = (longlong *)0x0;
    }
    else {
      *local_f8 = (longlong)local_168;
      local_168[0] = local_f8;
    }
    local_150 = (longlong *)0x0;
    local_148 = (longlong *)0x0;
    local_140 = 0;
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    lVar10 = *(longlong *)(lVar10 + 0x170);
    if (lVar10 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar10 = 0;
    }
    FUN_140313fc0(lVar10,local_f0,param_2,0x25);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    lVar10 = *(longlong *)(lVar10 + 0x170);
    if (lVar10 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar10 = 0;
    }
    FUN_140313fc0(lVar10,local_168,param_2,0x26);
    plVar18 = local_d8;
    plVar5 = local_f0[0];
    if (local_d0 < local_d8) {
      _invalid_parameter_noinfo();
      plVar5 = local_f0[0];
    }
    while( true ) {
      plVar11 = local_d0;
      if (local_d0 < local_d8) {
        _invalid_parameter_noinfo();
      }
      if ((plVar5 == (longlong *)0x0) || (plVar5 != local_f0[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar18 == plVar11) break;
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar5;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar18) {
        _invalid_parameter_noinfo();
      }
      lVar10 = *plVar18;
      if (lVar10 != 0) {
        plVar11 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar11 = (longlong *)0x0;
        }
        plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,lVar10,0);
        if (plVar11 != (longlong *)0x0) {
          plVar12 = (longlong *)FUN_140087ed0();
          iVar7 = (**(code **)(*plVar12 + 0xb0))(plVar12,param_2);
          iVar8 = FUN_1400fda10(plVar11,0x17,1);
          if ((iVar8 != 0) && (iVar8 = FUN_1400fda10(plVar11,0x17,1), iVar8 != iVar7)) {
            plVar12 = (longlong *)FUN_140087f50();
            lVar10 = *plVar12;
            uVar9 = (**(code **)(*plVar11 + 8))(plVar11);
            (**(code **)(lVar10 + 0x48))(plVar12,param_2,uVar9);
            FUN_140104140(plVar11,0x17,0);
          }
          uVar9 = FUN_1400fda10(plVar11,1);
          cVar6 = FUN_1400ff940(uVar9);
          if (cVar6 != '\0') {
            local_f8 = operator_new(8);
            plVar12 = local_150;
            if (local_f8 == (longlong *)0x0) {
              local_138[0] = (longlong *)0x0;
            }
            else {
              *local_f8 = (longlong)local_138;
              local_138[0] = local_f8;
            }
            local_120 = (longlong *)0x0;
            local_118 = (longlong *)0x0;
            local_110 = 0;
            plVar17 = local_168[0];
            if (local_148 < local_150) {
              _invalid_parameter_noinfo();
              plVar17 = local_168[0];
            }
            while( true ) {
              plVar1 = local_148;
              if (local_148 < local_150) {
                _invalid_parameter_noinfo();
              }
              if ((plVar17 == (longlong *)0x0) || (plVar17 != local_168[0])) {
                _invalid_parameter_noinfo();
              }
              if (plVar12 == plVar1) break;
              if (plVar17 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar10 = 0;
              }
              else {
                lVar10 = *plVar17;
              }
              if (*(longlong **)(lVar10 + 0x20) <= plVar12) {
                _invalid_parameter_noinfo();
              }
              plVar1 = (longlong *)*plVar12;
              if (plVar1 == (longlong *)0x0) {
                lVar10 = (longlong)local_148 - (longlong)(plVar12 + 1) >> 3;
                if (0 < lVar10) {
                  rVar15 = lVar10 << 3;
                  memmove_s(plVar12,rVar15,plVar12 + 1,rVar15);
                }
                local_148 = local_148 + -1;
                if ((plVar12 < local_150) || (local_148 < plVar12)) {
                  _invalid_parameter_noinfo();
                }
                local_88 = local_168[0];
                local_108 = local_168[0];
                plVar17 = local_168[0];
                plStack_100 = plVar12;
                plStack_80 = plVar12;
              }
              else {
                plVar13 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,1);
                iVar7 = (**(code **)(*plVar13 + 0x48))(plVar13);
                iVar8 = (**(code **)(*plVar11 + 8))(plVar11);
                plVar13 = local_118;
                if (iVar7 == iVar8) {
                  if (local_120 == (longlong *)0x0) {
                    uVar16 = 0;
                  }
                  else {
                    uVar16 = local_110 - (longlong)local_120 >> 3;
                  }
                  if ((ulonglong)((longlong)local_118 - (longlong)local_120 >> 3) < uVar16) {
                    *local_118 = (longlong)plVar1;
                    local_118 = local_118 + 1;
                  }
                  else {
                    if (local_118 < local_120) {
                      _invalid_parameter_noinfo();
                    }
                    plVar1 = local_120;
                    plVar17 = local_138[0];
                    local_98 = local_138[0];
                    uStack_90 = plVar13;
                    if (((longlong)local_118 - (longlong)local_120 & 0xfffffffffffffff8U) == 0) {
                      lVar10 = 0;
                    }
                    else {
                      if (local_118 < local_120) {
                        _invalid_parameter_noinfo();
                      }
                      if ((plVar17 == (longlong *)0x0) || (plVar17 != local_138[0])) {
                        _invalid_parameter_noinfo();
                      }
                      lVar10 = (longlong)plVar13 - (longlong)plVar1 >> 3;
                    }
                    local_68 = (undefined4)local_98;
                    uStack_64 = local_98._4_4_;
                    uStack_60 = (undefined4)uStack_90;
                    uStack_5c = uStack_90._4_4_;
                    FUN_1400183c0(local_138,&local_68,1);
                    plVar17 = local_120;
                    if (local_118 < local_120) {
                      _invalid_parameter_noinfo();
                    }
                    plVar1 = local_138[0];
                    if (local_138[0] == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar14 = 0;
                    }
                    else {
                      lVar14 = *local_138[0];
                    }
                    if (plVar17 + lVar10 <= *(longlong **)(lVar14 + 0x20)) {
                      if (plVar1 == (longlong *)0x0) {
                        lVar14 = 0;
                      }
                      else {
                        lVar14 = *plVar1;
                      }
                      if (*(longlong **)(lVar14 + 0x18) <= plVar17 + lVar10) goto LAB_140329751;
                    }
                    _invalid_parameter_noinfo();
                  }
LAB_140329751:
                  lVar10 = (longlong)local_148 - (longlong)(plVar12 + 1) >> 3;
                  if (0 < lVar10) {
                    rVar15 = lVar10 << 3;
                    memmove_s(plVar12,rVar15,plVar12 + 1,rVar15);
                  }
                  local_148 = local_148 + -1;
                  if ((plVar12 < local_150) || (local_148 < plVar12)) {
                    _invalid_parameter_noinfo();
                  }
                  local_a8 = local_168[0];
                  local_108 = local_168[0];
                  plVar17 = local_168[0];
                  plStack_100 = plVar12;
                  plStack_a0 = plVar12;
                }
                else {
                  if (plVar17 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar10 = 0;
                  }
                  else {
                    lVar10 = *plVar17;
                  }
                  if (*(longlong **)(lVar10 + 0x20) <= plVar12) {
                    _invalid_parameter_noinfo();
                  }
                  plVar12 = plVar12 + 1;
                }
              }
            }
            FUN_140108580(plVar11,local_138);
            if (local_120 != (longlong *)0x0) {
              operator_delete(local_120);
            }
            local_120 = (longlong *)0x0;
            local_118 = (longlong *)0x0;
            local_110 = 0;
            operator_delete(local_138[0]);
          }
          uVar9 = (**(code **)(*plVar11 + 8))();
          puVar2 = (undefined4 *)param_3[3];
          if (puVar2 == (undefined4 *)0x0) {
            uVar16 = 0;
          }
          else {
            uVar16 = param_3[5] - (longlong)puVar2 >> 2;
          }
          puVar3 = (undefined4 *)param_3[4];
          if ((ulonglong)((longlong)puVar3 - (longlong)puVar2 >> 2) < uVar16) {
            *puVar3 = uVar9;
            param_3[4] = puVar3 + 1;
          }
          else {
            if (puVar3 < puVar2) {
              _invalid_parameter_noinfo();
            }
            uVar4 = *param_3;
            local_b8._0_4_ = (undefined4)uVar4;
            local_b8._4_4_ = (undefined4)((ulonglong)uVar4 >> 0x20);
            uStack_b0._0_4_ = SUB84(puVar3,0);
            uStack_b0._4_4_ = (undefined4)((ulonglong)puVar3 >> 0x20);
            local_78 = (undefined4)local_b8;
            uStack_74 = local_b8._4_4_;
            uStack_70 = (undefined4)uStack_b0;
            uStack_6c = uStack_b0._4_4_;
            local_b8 = uVar4;
            uStack_b0 = puVar3;
            FUN_1400375c0(param_3,local_50);
          }
        }
      }
      if (plVar5 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar5;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar18) {
        _invalid_parameter_noinfo();
      }
      plVar18 = plVar18 + 1;
    }
    if (local_150 != (longlong *)0x0) {
      operator_delete(local_150);
    }
    local_150 = (longlong *)0x0;
    local_148 = (longlong *)0x0;
    local_140 = 0;
    operator_delete(local_168[0]);
    if (local_d8 != (longlong *)0x0) {
      operator_delete(local_d8);
    }
    local_d8 = (longlong *)0x0;
    local_d0 = (longlong *)0x0;
    local_c8 = 0;
    operator_delete(local_f0[0]);
  }
  return;
}

// ==== CItemMgr::helper_1403299b0  @1403299b0  [medium:callgraph-r0]  (orig: FUN_1403299b0)
undefined8 * FUN_1403299b0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14031fc60(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CItemMgr::ctor_or_dtor  @140329a30  [high:vtable-assign]  (orig: FUN_140329a30)
undefined8 * FUN_140329a30(undefined8 *param_1,undefined4 param_2,undefined8 param_3)

{
  *param_1 = CItemMgr::vftable;
  param_1[1] = param_3;
  *(undefined4 *)(param_1 + 2) = param_2;
  FUN_14000ef40(param_1 + 3);
  FUN_1402b1dd0(param_1 + 0xb);
  FUN_1403299b0(param_1 + 0x13);
  FUN_1403299b0(param_1 + 0x1b);
  FUN_14000ef40(param_1 + 0x26);
  FUN_14000ef40(param_1 + 0x2f);
  *(undefined4 *)(param_1 + 0x37) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1bc) = 0;
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1cc) = 0;
  FUN_1403275e0(param_1 + 0x3a);
  FUN_1400b8550(param_1 + 0x42);
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x2e] = 0;
  FUN_140320090(param_1 + 0x13);
  FUN_140320090(param_1 + 0x1b);
  *(undefined4 *)(param_1 + 0x39) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0xf4610901;
  FUN_14009f560(param_1 + 0x42);
  return param_1;
}

// ==== CItemMgr::vfunc_0  @140329b60  [high:rtti-vtable]  (orig: FUN_140329b60)
void * FUN_140329b60(void *param_1,uint param_2)

{
  FUN_140327740();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CItemMgr::helper_14032b460  @14032b460  [medium:callgraph-r0]  (orig: FUN_14032b460)
longlong FUN_14032b460(longlong param_1)

{
  return param_1 + 0xc38;
}

// ==== CItemMgr::helper_14032b470  @14032b470  [medium:callgraph-r0]  (orig: FUN_14032b470)
longlong FUN_14032b470(longlong param_1)

{
  return param_1 + 0xc68;
}

// ==== CItemMgr::helper_140333160  @140333160  [medium:callgraph-r0]  (orig: FUN_140333160)
bool FUN_140333160(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  int *piVar3;
  
  piVar1 = *(int **)(param_1 + 0xcb8);
  if (piVar1 < *(int **)(param_1 + 0xcb0)) {
    _invalid_parameter_noinfo();
  }
  piVar3 = *(int **)(param_1 + 0xcb0);
  if (*(int **)(param_1 + 0xcb8) < piVar3) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0xc98);
  for (; (piVar3 != piVar1 && (*piVar3 != param_2)); piVar3 = piVar3 + 1) {
  }
  piVar1 = *(int **)(param_1 + 0xcb8);
  if (piVar1 < *(int **)(param_1 + 0xcb0)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0xc98))) {
    _invalid_parameter_noinfo();
  }
  return piVar3 != piVar1;
}

// ==== CItemMgr::helper_140335030  @140335030  [medium:callgraph-r0]  (orig: FUN_140335030)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140335030(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  plVar4 = (longlong *)0x0;
  cVar1 = FUN_140333220();
  if ((cVar1 != '\0') || (cVar1 = FUN_140332fe0(param_1,param_2), cVar1 != '\0')) {
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_498 = 0x3c0;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = plVar4;
    }
    plVar4 = (longlong *)(**(code **)(*plVar5 + 0x60))(plVar5,param_2);
    if (plVar4 == (longlong *)0x0) {
      return;
    }
  }
  plVar4 = (longlong *)FUN_140100290(plVar4);
  if (plVar4 != (longlong *)0x0) {
    uVar2 = (**(code **)(*plVar4 + 0x30))(plVar4,3);
    FUN_1403b6000(local_458);
    local_478 = 0;
    local_480 = 0;
    local_488 = 0;
    local_490 = 0;
    local_498 = 0;
    iVar3 = FUN_1403b60f0(local_458,param_2,7,uVar2);
    if (iVar3 != 0) {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))((longlong *)(param_1 + 0x10),local_458);
    }
    FUN_1403b6050(local_458);
  }
  return;
}

// ==== CItemMgr::helper_140335ff0  @140335ff0  [medium:callgraph-r0]  (orig: FUN_140335ff0)
void FUN_140335ff0(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  rsize_t _DstSize;
  int *_Dst;
  
  piVar1 = *(int **)(param_1 + 0xce8);
  if (piVar1 < *(int **)(param_1 + 0xce0)) {
    _invalid_parameter_noinfo();
  }
  _Dst = *(int **)(param_1 + 0xce0);
  if (*(int **)(param_1 + 0xce8) < _Dst) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0xcc8);
  for (; (_Dst != piVar1 && (*_Dst != param_2)); _Dst = _Dst + 1) {
  }
  piVar1 = *(int **)(param_1 + 0xce8);
  if (piVar1 < *(int **)(param_1 + 0xce0)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0xcc8))) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != piVar1) {
    lVar2 = *(longlong *)(param_1 + 0xce8) - (longlong)(_Dst + 1) >> 2;
    if (0 < lVar2) {
      _DstSize = lVar2 << 2;
      memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
    }
    *(longlong *)(param_1 + 0xce8) = *(longlong *)(param_1 + 0xce8) + -4;
    if ((_Dst < *(int **)(param_1 + 0xce0)) || (*(int **)(param_1 + 0xce8) < _Dst)) {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CItemMgr::helper_140336210  @140336210  [medium:callgraph-r0]  (orig: FUN_140336210)
void FUN_140336210(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  rsize_t _DstSize;
  int *_Dst;
  
  piVar1 = *(int **)(param_1 + 0xcb8);
  if (piVar1 < *(int **)(param_1 + 0xcb0)) {
    _invalid_parameter_noinfo();
  }
  _Dst = *(int **)(param_1 + 0xcb0);
  if (*(int **)(param_1 + 0xcb8) < _Dst) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0xc98);
  for (; (_Dst != piVar1 && (*_Dst != param_2)); _Dst = _Dst + 1) {
  }
  piVar1 = *(int **)(param_1 + 0xcb8);
  if (piVar1 < *(int **)(param_1 + 0xcb0)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0xc98))) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != piVar1) {
    lVar2 = *(longlong *)(param_1 + 0xcb8) - (longlong)(_Dst + 1) >> 2;
    if (0 < lVar2) {
      _DstSize = lVar2 << 2;
      memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
    }
    *(longlong *)(param_1 + 0xcb8) = *(longlong *)(param_1 + 0xcb8) + -4;
    if ((_Dst < *(int **)(param_1 + 0xcb0)) || (*(int **)(param_1 + 0xcb8) < _Dst)) {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CItemMgr::helper_1403873d0  @1403873d0  [medium:callgraph-r0]  (orig: FUN_1403873d0)
undefined8
FUN_1403873d0(longlong param_1,longlong param_2,undefined4 param_3,undefined8 param_4,
             undefined1 param_5)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined4 local_78;
  undefined4 local_74;
  undefined2 local_68;
  undefined2 local_64;
  undefined1 local_60;
  undefined1 local_5c;
  undefined4 local_58;
  int local_54;
  int local_50;
  undefined4 local_4c;
  undefined1 local_48;
  undefined1 local_44;
  undefined1 local_40;
  undefined1 local_3c;
  undefined1 local_38;
  undefined4 local_34;
  undefined2 local_30;
  undefined2 local_2e;
  undefined2 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined2 local_18;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    cVar1 = FUN_140101cb0(param_2,&local_78);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      FUN_1402b5600(param_1);
      **(undefined4 **)(param_1 + 0x428) = local_78;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
      *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = local_74;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = local_68;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x16) = local_64;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_5;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x19) = local_60;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1a) = local_5c;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1b) = local_58;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1f) = (undefined1)local_54;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x20) = (undefined1)local_50;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x21) = local_4c;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x25) = local_48;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x26) = local_44;
      if ((*(byte *)(*(longlong *)(param_1 + 0x428) + 0x19) & 1) != 0) {
        if (local_54 != 0) {
          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1f) = 0xff;
        }
        if (local_50 != 0) {
          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x20) = 0xff;
        }
        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x21) = 0;
        *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x25) = 0;
        *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x26) = 0;
      }
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x27) = local_40;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x28) = local_3c;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x29) = local_38;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x2a) = local_34;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x2e) = local_30;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x30) = local_2e;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x32) = local_2c;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x34) = local_28;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x38) = local_24;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x3c) = local_20;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x40) = local_1c;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x44) = local_18;
      uVar2 = FUN_140100320(param_2);
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x46) = uVar2;
      uVar2 = FUN_140100340(param_2);
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x4a) = uVar2;
      *(undefined4 *)(param_1 + 8) = 0x454;
      *(undefined4 *)(param_1 + 0xc) = 0x4e;
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CItemMgr::helper_1403b60f0  @1403b60f0  [medium:callgraph-r1]  (orig: FUN_1403b60f0)
undefined8
FUN_1403b60f0(longlong param_1,int param_2,undefined1 param_3,int param_4,int param_5,int param_6,
             int param_7,int param_8,int param_9)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x24;
  *(undefined4 *)(param_1 + 8) = 0x81d;
  **(undefined4 **)(param_1 + 0x428) = 0;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 1] = param_2;
  *(undefined1 *)(*(int **)(param_1 + 0x428) + (longlong)**(int **)(param_1 + 0x428) * 8 + 2) =
       param_3;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 3] = param_4;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 4] = param_5;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 5] = param_6;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 6] = param_7;
  (*(int **)(param_1 + 0x428))[(longlong)**(int **)(param_1 + 0x428) * 8 + 7] = param_8;
  (*(int **)(param_1 + 0x428))[((longlong)**(int **)(param_1 + 0x428) + 1) * 8] = param_9;
  **(int **)(param_1 + 0x428) = **(int **)(param_1 + 0x428) + 1;
  return 1;
}

// ==== CItemMgr::helper_1404587d0  @1404587d0  [medium:callgraph-r0]  (orig: FUN_1404587d0)
undefined8
FUN_1404587d0(longlong param_1,longlong param_2,undefined1 param_3,int param_4,undefined2 param_5)

{
  char cVar1;
  undefined8 uVar2;
  undefined4 local_78;
  undefined4 local_74;
  undefined2 local_68;
  undefined2 local_64;
  undefined1 local_60;
  undefined1 local_5c;
  undefined4 local_58;
  int local_54;
  int local_50;
  undefined4 local_4c;
  undefined1 local_48;
  undefined1 local_44;
  undefined1 local_40;
  undefined1 local_3c;
  undefined1 local_38;
  undefined4 local_34;
  undefined2 local_30;
  undefined2 local_2e;
  undefined2 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined2 local_18;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    cVar1 = FUN_140101cb0(param_2,&local_78);
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      FUN_1402b5600(param_1);
      **(undefined4 **)(param_1 + 0x428) = local_78;
      if (param_4 != 0) {
        **(int **)(param_1 + 0x428) = param_4;
      }
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = local_74;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = local_68;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10) = local_64;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_3;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xd) = local_60;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xe) = local_5c;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = local_58;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x14) = (undefined1)local_54;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x15) = (undefined1)local_50;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = local_4c;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = local_48;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1d) = local_44;
      if ((*(byte *)(*(longlong *)(param_1 + 0x428) + 0xd) & 1) != 0) {
        if (local_54 != 0) {
          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x14) = 0xff;
        }
        if (local_50 != 0) {
          *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x15) = 0xff;
        }
        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = 0;
        *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 0;
        *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1d) = 0;
      }
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1e) = local_40;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x1f) = local_3c;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x20) = local_38;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x24) = local_34;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x28) = local_30;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x2a) = local_2e;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x2c) = local_2c;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30) = local_28;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x34) = local_24;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x38) = local_20;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x3c) = local_1c;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x40) = local_18;
      *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x42) = param_5;
      *(undefined4 *)(param_1 + 8) = 0x3f0;
      *(undefined4 *)(param_1 + 0xc) = 0x44;
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CItemMgr::helper_1404c45c0  @1404c45c0  [medium:callgraph-r0]  (orig: FUN_1404c45c0)
undefined8 FUN_1404c45c0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CItemMgr::helper_1404c6850  @1404c6850  [medium:callgraph-r0]  (orig: FUN_1404c6850)
undefined8 FUN_1404c6850(longlong param_1,uint param_2,int param_3)

{
  longlong *plVar1;
  uint uVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  uVar10 = (ulonglong)param_2;
  iVar6 = FUN_1400ff680(param_2);
  if (((iVar6 != 4) ||
      ((iVar6 = FUN_1400fecd0(uVar10), iVar6 != 21000 &&
       (iVar6 = FUN_1400fede0(param_2), iVar6 != 0x26c)))) &&
     (cVar5 = FUN_14015f820(uVar10), cVar5 == '\0')) {
    iVar6 = FUN_1400ff680(param_2);
    if (((((((iVar6 == 4) && (uVar2 = (param_2 % 10000000) / 1000, uVar2 != 0x259)) &&
           (uVar2 != 0x262)) && ((uVar2 != 0x263 && (uVar2 != 0x264)))) &&
         ((uVar2 != 0x265 && ((uVar2 != 0x266 && (uVar2 != 0x268)))))) && (uVar2 != 0x269)) &&
       (uVar2 != 0x26b)) {
      uVar10 = (ulonglong)(param_2 + (((param_2 / 100000) * 100 - param_2 / 1000) + 0x2c) * 1000);
    }
    else {
      iVar6 = FUN_1400ff680(uVar10);
      if ((iVar6 == 5) && ((param_2 % 10000000) / 1000 != 0x1ff)) {
        uVar10 = (ulonglong)(param_2 + (((param_2 / 100000) * 100 - param_2 / 1000) + 0x37) * 1000);
      }
      else {
        iVar6 = FUN_1400ff680(uVar10);
        if ((iVar6 == 0xc) ||
           (((iVar6 = FUN_1400ff680(uVar10), iVar6 == 0xd ||
             (iVar6 = FUN_1400ff680(uVar10), iVar6 == 0x15)) ||
            (iVar6 = FUN_1400ff680(uVar10), iVar6 == 0x16)))) {
          uVar10 = (ulonglong)((param_2 / 1000) * 1000);
        }
      }
    }
  }
  puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  lVar12 = ((ulonglong)(uint)((int)(uVar10 / 10) * 10) << 0x20) + (longlong)param_3;
  cVar5 = *(char *)((longlong)puVar11 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar5 == '\0') {
    if ((longlong)puVar11[3] < lVar12) {
      puVar7 = (undefined8 *)puVar11[2];
      puVar11 = puVar3;
    }
    else {
      puVar7 = (undefined8 *)*puVar11;
    }
    puVar3 = puVar11;
    puVar11 = puVar7;
    cVar5 = *(char *)((longlong)puVar7 + 0x29);
  }
  puVar11 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar11) || (lVar12 < (longlong)puVar3[3])) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar9 = &local_38;
  }
  plVar1 = (longlong *)*plVar9;
  lVar12 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar1;
  local_10 = plVar9[1];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar12) {
    uVar8 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = 0;
    }
    else {
      lVar12 = *plVar1;
    }
    if (lVar4 == *(longlong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar8 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar8;
}

// ==== CItemMgr::helper_1404c7e30  @1404c7e30  [medium:callgraph-r0]  (orig: FUN_1404c7e30)
undefined8 FUN_1404c7e30(longlong param_1,uint param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong lVar11;
  longlong *local_48;
  longlong *local_40;
  longlong *local_38;
  longlong local_30;
  longlong *local_28;
  longlong *local_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x61);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar9[2];
      puVar9 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x61);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar3;
  local_48 = *(longlong **)(param_1 + 8);
  if (*(longlong **)(param_1 + 8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar9) || (param_2 < *(uint *)(puVar3 + 3))) {
    pplVar8 = &local_38;
    local_30 = *(longlong *)(param_1 + 0x38);
    local_38 = *(longlong **)(param_1 + 8);
  }
  else {
    pplVar8 = &local_48;
  }
  plVar7 = *pplVar8;
  plVar2 = *(longlong **)(param_1 + 0x38);
  local_28 = plVar7;
  local_20 = pplVar8[1];
  if ((plVar7 == (longlong *)0x0) || (plVar7 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  plVar4 = local_20;
  if (local_20 == plVar2) {
    log_InlineLogDBERROR("table:cq_weapon_skill_up, weapontype[%u] is not found!");
    uVar6 = 0xffffffff;
  }
  else {
    lVar10 = 0;
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar10;
    }
    else {
      lVar11 = *plVar7;
    }
    if (plVar4 == *(longlong **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar9 = (undefined8 *)((undefined8 *)plVar4[10])[1];
    cVar1 = *(char *)((longlong)puVar9 + 0x29);
    puVar3 = (undefined8 *)plVar4[10];
    while (cVar1 == '\0') {
      if (*(uint *)(puVar9 + 3) < param_3) {
        puVar5 = (undefined8 *)puVar9[2];
        puVar9 = puVar3;
      }
      else {
        puVar5 = (undefined8 *)*puVar9;
      }
      puVar3 = puVar9;
      puVar9 = puVar5;
      cVar1 = *(char *)((longlong)puVar5 + 0x29);
    }
    puVar9 = (undefined8 *)plVar4[10];
    local_20 = puVar3;
    local_28 = (longlong *)plVar4[4];
    if ((longlong *)plVar4[4] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar9) || (param_3 < *(uint *)(puVar3 + 3))) {
      pplVar8 = &local_38;
      local_30 = plVar4[10];
      local_38 = (longlong *)plVar4[4];
    }
    else {
      pplVar8 = &local_28;
    }
    local_48 = *pplVar8;
    local_40 = pplVar8[1];
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar10;
    }
    else {
      lVar11 = *plVar7;
    }
    if (plVar4 == *(longlong **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = local_48;
    plVar7 = (longlong *)plVar4[10];
    if ((local_48 == (longlong *)0x0) || (local_48 != (longlong *)plVar4[4])) {
      _invalid_parameter_noinfo();
    }
    plVar4 = local_40;
    if (local_40 == plVar7) {
      log_InlineLogDBERROR("table:cq_weapon_skill_up, weapontype[%u] level[%d] is not found!");
      uVar6 = 0xffffffff;
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar10 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)plVar4[4];
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
      uVar6 = (**(code **)(*plVar7 + 0x50))(plVar7);
    }
  }
  return uVar6;
}

// ==== CItemMgr::helper_1404c8070  @1404c8070  [medium:callgraph-r0]  (orig: FUN_1404c8070)
undefined8 FUN_1404c8070(longlong param_1,uint param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong lVar11;
  longlong *local_48;
  longlong *local_40;
  longlong *local_38;
  longlong local_30;
  longlong *local_28;
  longlong *local_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x61);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar9[2];
      puVar9 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x61);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar3;
  local_48 = *(longlong **)(param_1 + 8);
  if (*(longlong **)(param_1 + 8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar9) || (param_2 < *(uint *)(puVar3 + 3))) {
    pplVar8 = &local_38;
    local_30 = *(longlong *)(param_1 + 0x38);
    local_38 = *(longlong **)(param_1 + 8);
  }
  else {
    pplVar8 = &local_48;
  }
  plVar7 = *pplVar8;
  plVar2 = *(longlong **)(param_1 + 0x38);
  local_28 = plVar7;
  local_20 = pplVar8[1];
  if ((plVar7 == (longlong *)0x0) || (plVar7 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  plVar4 = local_20;
  if (local_20 == plVar2) {
    log_InlineLogERROR(
                      "CWeaponSkillUp::QueryWeaponSkillLeveUpNeedTime, WeaponType[%u] is not found!"
                      );
    uVar6 = 0xffffffff;
  }
  else {
    lVar10 = 0;
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar10;
    }
    else {
      lVar11 = *plVar7;
    }
    if (plVar4 == *(longlong **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar9 = (undefined8 *)((undefined8 *)plVar4[10])[1];
    cVar1 = *(char *)((longlong)puVar9 + 0x29);
    puVar3 = (undefined8 *)plVar4[10];
    while (cVar1 == '\0') {
      if (*(uint *)(puVar9 + 3) < param_3) {
        puVar5 = (undefined8 *)puVar9[2];
        puVar9 = puVar3;
      }
      else {
        puVar5 = (undefined8 *)*puVar9;
      }
      puVar3 = puVar9;
      puVar9 = puVar5;
      cVar1 = *(char *)((longlong)puVar5 + 0x29);
    }
    puVar9 = (undefined8 *)plVar4[10];
    local_20 = puVar3;
    local_28 = (longlong *)plVar4[4];
    if ((longlong *)plVar4[4] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar9) || (param_3 < *(uint *)(puVar3 + 3))) {
      pplVar8 = &local_38;
      local_30 = plVar4[10];
      local_38 = (longlong *)plVar4[4];
    }
    else {
      pplVar8 = &local_28;
    }
    local_48 = *pplVar8;
    local_40 = pplVar8[1];
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar10;
    }
    else {
      lVar11 = *plVar7;
    }
    if (plVar4 == *(longlong **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = local_48;
    plVar7 = (longlong *)plVar4[10];
    if ((local_48 == (longlong *)0x0) || (local_48 != (longlong *)plVar4[4])) {
      _invalid_parameter_noinfo();
    }
    plVar4 = local_40;
    if (local_40 == plVar7) {
      log_InlineLogERROR(
                        "CWeaponSkillUp::QueryWeaponSkillLeveUpNeedTime, WeaponType[%u] level[%d] is not found!"
                        );
      uVar6 = 0xffffffff;
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar10 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)plVar4[4];
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      uVar6 = (**(code **)(*plVar7 + 0x48))(plVar7);
    }
  }
  return uVar6;
}

// ==== CItemMgr::helper_1404c82b0  @1404c82b0  [medium:callgraph-r0]  (orig: FUN_1404c82b0)
undefined4 FUN_1404c82b0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x78);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x48);
  if (*(longlong *)(param_1 + 0x48) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong *)(param_1 + 0x48);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x78);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((*(longlong **)(param_1 + 0x48) == (longlong *)0x0) ||
     (*(longlong **)(param_1 + 0x48) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (lVar9 == local_10) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CItemMgr::helper_1404c8440  @1404c8440  [medium:callgraph-r0]  (orig: FUN_1404c8440)
longlong FUN_1404c8440(undefined8 param_1,undefined4 param_2,int param_3,uint param_4,uint param_5)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  float fVar6;
  
  uVar5 = (ulonglong)param_4;
  uVar1 = FUN_1404c7e30();
  iVar2 = FUN_1404c8070(param_1,param_2,param_3);
  if ((uVar1 == 0xffffffff) || (iVar2 == -1)) {
    return 0;
  }
  if (uVar1 == 0) {
    uVar1 = 1;
  }
  uVar4 = 0;
  fVar6 = ((float)uVar5 / (float)uVar1) * (float)iVar2 + (float)param_5;
  iVar2 = FUN_1404c82b0(param_1,param_2);
  do {
    if (iVar2 <= param_3) {
LAB_1404c8580:
      if ((longlong)uVar4 < (longlong)uVar5) {
        uVar4 = uVar5;
      }
      return uVar4 - uVar5;
    }
    uVar1 = FUN_1404c7e30(param_1,param_2,param_3);
    iVar3 = FUN_1404c8070(param_1,param_2,param_3);
    if ((uVar1 == 0xffffffff) || (iVar3 == -1)) goto LAB_1404c8580;
    if (fVar6 < (float)iVar3) {
      if (iVar3 < 1) {
        iVar3 = 1;
      }
      uVar4 = uVar4 + (longlong)((fVar6 / (float)iVar3) * (float)uVar1);
      goto LAB_1404c8580;
    }
    param_3 = param_3 + 1;
    uVar4 = uVar4 + uVar1;
    fVar6 = fVar6 + (0.0 - (float)iVar3);
  } while( true );
}

