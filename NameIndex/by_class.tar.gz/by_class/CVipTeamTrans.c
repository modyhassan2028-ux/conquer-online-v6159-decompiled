// ==== CVipTeamTrans::helper_140416330  @140416330  [medium:callgraph-r0]  (orig: FUN_140416330)
void FUN_140416330(void *param_1)

{
  if ((DAT_140976378 & 1) == 0) {
    DAT_140976378 = DAT_140976378 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976370,"CVipTeamTrans");
    atexit((_func_5014 *)&LAB_1406d6d80);
  }
                    /* WARNING: Could not recover jumptable at 0x000140416385. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976370,param_1);
  return;
}

// ==== CVipTeamTrans::ctor_or_dtor  @140416430  [high:vtable-assign]  (orig: FUN_140416430)
void FUN_140416430(undefined8 *param_1)

{
  *param_1 = CVipTeamTrans::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CVipTeamTrans::ctor_or_dtor  @140416940  [high:vtable-assign]  (orig: FUN_140416940)
undefined8 * FUN_140416940(undefined8 *param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CVipTeamTrans::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  param_1[10] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  *(undefined4 *)((longlong)param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 0xb) = 10;
  return param_1;
}

// ==== CVipTeamTrans::ctor_or_dtor  @1404169d0  [high:vtable-assign]  (orig: FUN_1404169d0)
undefined8 * FUN_1404169d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CVipTeamTrans::vftable;
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_140416330(param_1);
  }
  return param_1;
}

