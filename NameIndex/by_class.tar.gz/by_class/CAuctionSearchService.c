// ==== CAuctionSearchService::helper_140281f30  @140281f30  [medium:callgraph-r1]  (orig: FUN_140281f30)
longlong *
FUN_140281f30(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  bool bVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)((undefined8 *)param_1[6])[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x69);
  puVar2 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar6 + 3),param_3);
    if (bVar3) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar2 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x69);
  }
  puVar6 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar6) ||
     (bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                        (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                                 (puVar2 + 3)), bVar3)) {
    plVar4 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar4 = &local_28;
  }
  *param_2 = *plVar4;
  param_2[1] = plVar4[1];
  return param_2;
}

// ==== CAuctionSearchService::helper_140287500  @140287500  [medium:callgraph-r3]  (orig: FUN_140287500)
void FUN_140287500(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"deque<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CAuctionSearchService::helper_140288510  @140288510  [medium:callgraph-r3]  (orig: FUN_140288510)
void FUN_140288510(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CAuctionSearchService::helper_14028bac0  @14028bac0  [medium:callgraph-r1]  (orig: FUN_14028bac0)
longlong *
FUN_14028bac0(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  bool bVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)((undefined8 *)param_1[6])[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x81);
  puVar2 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar6 + 3),param_3);
    if (bVar3) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar2 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x81);
  }
  puVar6 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar6) ||
     (bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                        (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                                 (puVar2 + 3)), bVar3)) {
    plVar4 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar4 = &local_28;
  }
  *param_2 = *plVar4;
  param_2[1] = plVar4[1];
  return param_2;
}

// ==== CAuctionSearchService::helper_14028bee0  @14028bee0  [medium:callgraph-r2]  (orig: FUN_14028bee0)
void FUN_14028bee0(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0xfffffffffffffff - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_140287500();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0xfffffffffffffff - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30) >> 1;
  _Dst_00 = (void *)FUN_140288510(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CAuctionSearchService::helper_14028d2d0  @14028d2d0  [medium:callgraph-r1]  (orig: FUN_14028d2d0)
void FUN_14028d2d0(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (((*(char *)(param_1 + 0x30) + (char)*(longlong *)(param_1 + 0x38) & 1U) == 0) &&
     (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 2U >> 1)) {
    FUN_14028bee0(param_1,1);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  uVar4 = uVar3 >> 1;
  if (*(ulonglong *)(param_1 + 0x28) <= uVar4) {
    uVar4 = uVar4 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) == 0) {
    pvVar2 = operator_new(0x10);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) = pvVar2;
  }
  puVar1 = (undefined8 *)
           (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) +
           (ulonglong)((uint)uVar3 & 1) * 8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = *param_2;
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CAuctionSearchService::helper_14028d7f0  @14028d7f0  [medium:callgraph-r0]  (orig: FUN_14028d7f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14028d7f0(longlong param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2,int param_3)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong lVar3;
  char *pcVar4;
  char cVar5;
  int iVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 uVar11;
  ulonglong *puVar12;
  ulonglong *puVar13;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar14;
  undefined8 ******ppppppuVar15;
  char *pcVar16;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *pbVar17;
  longlong lVar18;
  ulonglong uVar19;
  undefined1 auStack_128 [32];
  undefined4 local_108;
  ulonglong *local_f8;
  longlong local_f0;
  uint local_e8;
  longlong local_e0;
  longlong local_d8;
  longlong local_c8;
  char *local_c0;
  longlong *local_b8;
  char *local_b0;
  longlong *local_a8 [2];
  undefined8 local_98;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_70;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [8];
  undefined8 *****local_60 [3];
  ulonglong local_48;
  ulonglong local_40;
  
  local_98 = 0xfffffffffffffffe;
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_128;
  local_e0 = param_1;
  local_d8 = param_1;
  local_70 = param_2;
  if (*(longlong *)(param_2 + 0x18) == 0) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
    return 0;
  }
  puVar7 = (undefined8 *)
           std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::begin(param_2);
  local_f8 = (ulonglong *)*puVar7;
  local_f0 = puVar7[1];
  puVar7 = (undefined8 *)
           std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::end(param_2);
  local_c8 = *puVar7;
  local_c0 = (char *)puVar7[1];
  puVar7 = (undefined8 *)
           std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::begin(param_2);
  pcVar4 = local_c0;
  puVar1 = local_f8;
  local_b8 = (longlong *)*puVar7;
  pcVar16 = (char *)puVar7[1];
  lVar18 = local_f0;
  local_b0 = pcVar16;
  if (local_f8 != (ulonglong *)0xfffffffffffffffc) {
    if (local_f8 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    lVar18 = local_f0;
    if (puVar1[4] < 0x10) {
      puVar12 = puVar1 + 1;
    }
    else {
      puVar12 = (ulonglong *)puVar1[1];
    }
    puVar13 = puVar1 + 1;
    if (pcVar4 + (local_f0 - (longlong)pcVar16) <= (ulonglong *)((longlong)puVar12 + puVar1[3])) {
      if (0xf < puVar1[4]) {
        puVar13 = (ulonglong *)*puVar13;
      }
      if (puVar13 <= pcVar4 + (local_f0 - (longlong)pcVar16)) goto LAB_14028d934;
    }
    _invalid_parameter_noinfo();
  }
LAB_14028d934:
  if (pcVar16 != pcVar4) {
    lVar18 = lVar18 - (longlong)pcVar16;
    do {
      iVar6 = tolower((int)*pcVar16);
      pcVar16[lVar18] = (char)iVar6;
      pcVar16 = pcVar16 + 1;
    } while (pcVar16 != pcVar4);
  }
  lVar3 = local_e0;
  FUN_14028bac0(local_e0 + 0x50,&local_f8,param_2);
  puVar1 = local_f8;
  lVar18 = *(longlong *)(lVar3 + 0x80);
  if ((*(ulonglong **)(lVar3 + 0x50) == (ulonglong *)0x0) ||
     (*(ulonglong **)(lVar3 + 0x50) != local_f8)) {
    _invalid_parameter_noinfo();
  }
  lVar2 = local_f0;
  if (lVar18 == local_f0) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
    uVar11 = 0;
  }
  else {
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = 0;
    }
    else {
      uVar8 = *puVar1;
    }
    uVar19 = 0;
    if (lVar2 == *(longlong *)(uVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_c8 = lVar2 + 0x40;
    FUN_140281f30(lVar3 + 0x110,&local_f8,param_2);
    puVar1 = local_f8;
    lVar18 = *(longlong *)(lVar3 + 0x140);
    if ((*(ulonglong **)(lVar3 + 0x110) == (ulonglong *)0x0) ||
       (*(ulonglong **)(lVar3 + 0x110) != local_f8)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_f0;
    if (lVar18 == local_f0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
      uVar11 = 0;
    }
    else {
      if (puVar1 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar8 = uVar19;
      }
      else {
        uVar8 = *puVar1;
      }
      if (lVar3 == *(longlong *)(uVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>
                (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                           *)(lVar3 + 0x40));
      plVar9 = (longlong *)InstanceGet();
      local_e8 = 0;
      local_b8 = plVar9;
      while ((int)uVar19 < param_3) {
        if (*(ulonglong *)(param_2 + 0x20) < 0x10) {
          pbVar14 = param_2 + 8;
        }
        else {
          pbVar14 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)
                     (param_2 + 8);
        }
        pbVar17 = param_2 + 8;
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,pbVar14);
        local_a8[0] = plVar10;
        if (plVar10 == (longlong *)0x0) {
          local_108 = 0xf5;
          log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",&DAT_1406e5370,
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\recordpoolmgr.cpp"
                            );
        }
        else {
          ppppppuVar15 = local_60;
          if (0xf < local_48) {
            ppppppuVar15 = (undefined8 ******)local_60[0];
          }
          cVar5 = (**(code **)(*plVar9 + 0x30))(plVar9,ppppppuVar15,1);
          if (cVar5 == '\0') {
            ppppppuVar15 = local_60;
            if (0xf < local_48) {
              ppppppuVar15 = (undefined8 ******)local_60[0];
            }
            if (0xf < *(ulonglong *)(param_2 + 0x20)) {
              pbVar17 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)pbVar17
              ;
            }
            log_InlineLogERROR("CRecordPoolMgr::CreateFreeRec:%s pre create error,slq=%s",pbVar17,
                               ppppppuVar15);
            (**(code **)*plVar10)(plVar10,1);
            local_a8[0] = (longlong *)0x0;
          }
          else {
            plVar10 = (longlong *)(**(code **)(*plVar10 + 0x28))(plVar10);
            lVar18 = *plVar10;
            uVar11 = (**(code **)(*plVar9 + 0x18))(plVar9);
            (**(code **)(lVar18 + 0xa8))(plVar10,uVar11);
            tq::CMySingleLock::CMySingleLock
                      ((CMySingleLock *)&local_f8,(ILockObj *)(local_e0 + 0x198));
            FUN_14028d2d0(local_c8,local_a8);
            tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_f8);
          }
        }
        local_e8 = (int)uVar19 + 1;
        uVar19 = (ulonglong)local_e8;
      }
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
      uVar11 = 1;
    }
  }
  return uVar11;
}

// ==== CAuctionSearchService::helper_140369150  @140369150  [medium:callgraph-r1]  (orig: FUN_140369150)
undefined8 FUN_140369150(char *param_1,char *param_2)

{
  byte bVar1;
  char *pcVar2;
  
  bVar1 = param_2[0x13];
  if ((((((bVar1 == 0) || (0xc < bVar1)) || (bVar1 <= (byte)param_1[0x13])) &&
       (((bVar1 = param_2[0x11], bVar1 == 0 || (5 < bVar1)) || (bVar1 <= (byte)param_1[0x11])))) &&
      ((*param_2 == '\0' || (*param_1 == *param_2)))) &&
     (((param_2[0x12] == 0 || ((byte)param_2[0x12] <= (byte)param_1[0x12])) &&
      (((*(ushort *)(param_2 + 0x16) == 0 ||
        (*(ushort *)(param_2 + 0x16) <= *(ushort *)(param_1 + 0x16))) &&
       ((*(ushort *)(param_2 + 0x18) == 0x8c ||
        (*(ushort *)(param_1 + 0x16) <= *(ushort *)(param_2 + 0x18))))))))) {
    if ((param_2[1] != '\0') && (pcVar2 = strstr(param_1 + 1,param_2 + 1), pcVar2 == (char *)0x0)) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CAuctionSearchService::helper_1403691e0  @1403691e0  [medium:callgraph-r1]  (orig: FUN_1403691e0)
undefined4 * FUN_1403691e0(undefined4 *param_1,undefined4 *param_2)

{
  *param_1 = *param_2;
  param_1[1] = param_2[1];
  param_1[2] = param_2[2];
  *(undefined1 *)(param_1 + 3) = *(undefined1 *)(param_2 + 3);
  *(undefined1 *)((longlong)param_1 + 0x1d) = *(undefined1 *)((longlong)param_2 + 0x1d);
  *(undefined1 *)((longlong)param_1 + 0x1e) = *(undefined1 *)((longlong)param_2 + 0x1e);
  *(undefined1 *)((longlong)param_1 + 0x1f) = *(undefined1 *)((longlong)param_2 + 0x1f);
  *(undefined2 *)(param_1 + 8) = *(undefined2 *)(param_2 + 8);
  *(undefined2 *)((longlong)param_1 + 0x22) = *(undefined2 *)((longlong)param_2 + 0x22);
  *(undefined2 *)(param_1 + 9) = *(undefined2 *)(param_2 + 9);
  param_1[10] = param_2[10];
  strncpy((char *)((longlong)param_1 + 0xd),(char *)((longlong)param_2 + 0xd),0x10);
  return param_1;
}

// ==== CAuctionSearchService::vfunc_1  @140369260  [high:rtti-vtable]  (orig: FUN_140369260)
bool FUN_140369260(longlong param_1,longlong *param_2)

{
  undefined4 uVar1;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  *(longlong **)(param_1 + 0x10) = param_2;
  uVar1 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 8) = uVar1;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))(*(longlong **)(param_1 + 0x10),3);
  return *(int *)(param_1 + 8) == 10;
}

// ==== CAuctionSearchService::vfunc_3  @1403692f0  [high:rtti-vtable]  (orig: FUN_1403692f0)
void FUN_1403692f0(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975bf0;
  if (DAT_140975bf0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  if (*(longlong *)(lVar1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = DAT_140975bf0;
  if (DAT_140975bf0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  if (*(longlong **)(lVar1 + 8) != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001403693f2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(longlong **)(lVar1 + 8) + 0x40))();
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
                    /* WARNING: Could not recover jumptable at 0x0001403693e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(lRam0000000000000000 + 0x40))(0);
  return;
}

// ==== CAuctionSearchService::helper_140369440  @140369440  [medium:callgraph-r2]  (orig: FUN_140369440)
bool FUN_140369440(undefined4 *param_1,longlong param_2,longlong param_3)

{
  bool bVar1;
  bool bVar2;
  
  if (param_2 == 0) {
    return false;
  }
  if (param_3 == 0) {
    return true;
  }
  switch(*param_1) {
  case 1:
    bVar1 = *(byte *)(param_2 + 0x1d) < *(byte *)(param_3 + 0x1d);
    bVar2 = false;
    if (*(byte *)(param_2 + 0x1d) == *(byte *)(param_3 + 0x1d)) goto LAB_140369483;
    goto LAB_1403694a5;
  case 2:
    bVar2 = *(byte *)(param_2 + 0x1d) < *(byte *)(param_3 + 0x1d);
    bVar1 = *(byte *)(param_2 + 0x1d) == *(byte *)(param_3 + 0x1d);
    goto LAB_14036949b;
  case 3:
    if (*(ushort *)(param_2 + 0x22) != *(ushort *)(param_3 + 0x22)) {
      return *(ushort *)(param_3 + 0x22) < *(ushort *)(param_2 + 0x22);
    }
    goto LAB_140369483;
  case 4:
    bVar2 = *(ushort *)(param_2 + 0x22) < *(ushort *)(param_3 + 0x22);
    bVar1 = *(ushort *)(param_2 + 0x22) == *(ushort *)(param_3 + 0x22);
LAB_14036949b:
    if (!bVar1) {
      return bVar2;
    }
    break;
  case 5:
    if (*(int *)(param_2 + 0x28) != *(int *)(param_3 + 0x28)) {
      return *(int *)(param_2 + 0x28) < *(int *)(param_3 + 0x28);
    }
    goto LAB_140369483;
  case 6:
    if (*(int *)(param_2 + 0x28) != *(int *)(param_3 + 0x28)) {
      return *(int *)(param_3 + 0x28) <= *(int *)(param_2 + 0x28);
    }
    break;
  case 7:
    if (*(int *)(param_2 + 8) != *(int *)(param_3 + 8)) {
      return *(int *)(param_2 + 8) < *(int *)(param_3 + 8);
    }
LAB_140369483:
    return *(uint *)(param_2 + 4) < *(uint *)(param_3 + 4);
  case 8:
    if (*(int *)(param_2 + 8) != *(int *)(param_3 + 8)) {
      return *(int *)(param_3 + 8) <= *(int *)(param_2 + 8);
    }
    break;
  default:
    return *(uint *)(param_2 + 4) < *(uint *)(param_3 + 4);
  }
  bVar1 = *(uint *)(param_2 + 4) < *(uint *)(param_3 + 4);
  bVar2 = *(uint *)(param_2 + 4) == *(uint *)(param_3 + 4);
LAB_1403694a5:
  return !bVar1 && !bVar2;
}

// ==== CAuctionSearchService::helper_1403696e0  @1403696e0  [medium:callgraph-r3]  (orig: FUN_1403696e0)
void FUN_1403696e0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CAuctionSearchService::helper_140369870  @140369870  [medium:callgraph-r3]  (orig: FUN_140369870)
void FUN_140369870(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CAuctionSearchService::helper_140369950  @140369950  [medium:callgraph-r3]  (orig: FUN_140369950)
void FUN_140369950(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140369974. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CAuctionSearchService::helper_140369f90  @140369f90  [medium:callgraph-r3]  (orig: FUN_140369f90)
void FUN_140369f90(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4)

{
  undefined8 uVar1;
  char cVar2;
  longlong lVar3;
  
  if (param_2 <= param_3) {
    *(undefined8 *)(param_1 + param_2 * 8) = param_4;
    return;
  }
  do {
    lVar3 = (param_2 + -1) / 2;
    uVar1 = *(undefined8 *)(param_1 + lVar3 * 8);
    cVar2 = FUN_140369440(&stack0x00000028,uVar1,param_4);
    if (cVar2 == '\0') break;
    *(undefined8 *)(param_1 + param_2 * 8) = uVar1;
    param_2 = lVar3;
  } while (param_3 < lVar3);
  *(undefined8 *)(param_1 + param_2 * 8) = param_4;
  return;
}

// ==== CAuctionSearchService::helper_14036a0f0  @14036a0f0  [medium:callgraph-r0]  (orig: FUN_14036a0f0)
void FUN_14036a0f0(void *param_1)

{
  if ((DAT_140976130 & 1) == 0) {
    DAT_140976130 = DAT_140976130 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976128,"CAuctionSearchService");
    atexit((_func_5014 *)&LAB_1406d6b00);
  }
                    /* WARNING: Could not recover jumptable at 0x00014036a145. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976128,param_1);
  return;
}

// ==== CAuctionSearchService::helper_14036a1b0  @14036a1b0  [medium:callgraph-r1]  (orig: FUN_14036a1b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14036a1b0(longlong param_1,undefined4 param_2,undefined2 param_3,ushort param_4,
                  undefined4 *param_5,longlong param_6)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  longlong lVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  uint uVar7;
  undefined1 auStack_1b8 [32];
  int *local_198;
  uint local_188;
  undefined8 local_180;
  int local_178;
  uint local_174;
  undefined4 local_170;
  undefined2 local_16c;
  ushort local_16a;
  undefined4 local_168;
  undefined4 uStack_164;
  undefined4 uStack_160;
  undefined4 uStack_15c;
  undefined1 uStack_158;
  undefined1 local_157;
  undefined1 local_156;
  undefined1 local_155;
  undefined4 local_154;
  undefined4 local_150;
  undefined4 local_14c;
  undefined4 auStack_148 [64];
  ulonglong local_48;
  
  local_180 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1b8;
  if (*(longlong *)(param_1 + 0x10) == 0) {
    local_198 = (int *)CONCAT44(local_198._4_4_,0x216);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar3 = FUN_140008520(0xe);
    if (lVar3 != 0) {
      local_157 = 0;
      local_156 = 0;
      local_155 = 0;
      local_154 = 0;
      local_150 = CONCAT22(local_150._2_2_,0x8c);
      local_14c = 0;
      local_168 = 0;
      uStack_164 = 0;
      uStack_160 = 0;
      uStack_15c = 0;
      uStack_158 = 0;
      memset(&local_178,0,0x130);
      local_178 = 0;
      lVar3 = *(longlong *)(param_6 + 0x18);
      uVar5 = *(longlong *)(param_6 + 0x20) - lVar3 >> 3;
      local_174 = (uint)uVar5;
      local_168 = *param_5;
      uStack_164 = param_5[1];
      uStack_160 = param_5[2];
      uStack_15c = param_5[3];
      uVar1 = param_5[4];
      uStack_158 = (undefined1)uVar1;
      local_157 = (undefined1)((uint)uVar1 >> 8);
      local_156 = (undefined1)((uint)uVar1 >> 0x10);
      local_155 = (undefined1)((uint)uVar1 >> 0x18);
      local_154 = param_5[5];
      local_150 = param_5[6];
      local_14c = param_5[7];
      local_188 = (uint)param_4 * 0x32;
      uVar6 = (ulonglong)local_188;
      uVar7 = local_174;
      if (local_188 + 0x32 < local_174) {
        uVar7 = local_188 + 0x32;
      }
      local_170 = param_2;
      local_16c = param_3;
      local_16a = param_4;
      if (uVar6 < uVar5) {
        iVar4 = 0;
        while ((uint)uVar6 < uVar7) {
          if ((ulonglong)(*(longlong *)(param_6 + 0x20) - lVar3 >> 3) <= uVar6) {
            _invalid_parameter_noinfo();
            iVar4 = local_178;
          }
          lVar3 = *(longlong *)(param_6 + 0x18);
          puVar2 = *(undefined4 **)(lVar3 + uVar6 * 8);
          if (puVar2 != (undefined4 *)0x0) {
            auStack_148[iVar4] = *puVar2;
            local_178 = local_178 + 1;
            iVar4 = local_178;
            if (0x31 < local_178) break;
          }
          local_188 = (uint)uVar6 + 1;
          uVar6 = (ulonglong)local_188;
        }
        local_198 = &local_178;
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                  (*(longlong **)(param_1 + 0x10),0xe,0x273a,0x130);
      }
      else {
        local_198 = &local_178;
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
                  (*(longlong **)(param_1 + 0x10),0xe,0x273a,0x130);
      }
    }
  }
  return;
}

// ==== CAuctionSearchService::helper_14036a4f0  @14036a4f0  [medium:callgraph-r3]  (orig: FUN_14036a4f0)
void FUN_14036a4f0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CAuctionSearchService::helper_14036a5a0  @14036a5a0  [medium:callgraph-r3]  (orig: FUN_14036a5a0)
void FUN_14036a5a0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CAuctionSearchService::helper_14036a920  @14036a920  [medium:callgraph-r3]  (orig: FUN_14036a920)
void FUN_14036a920(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3,undefined4 param_4)

{
  undefined8 uVar1;
  char cVar2;
  undefined8 uVar3;
  undefined4 local_res20 [2];
  
  uVar1 = *param_2;
  uVar3 = *param_1;
  local_res20[0] = param_4;
  cVar2 = FUN_140369440(local_res20,uVar1);
  if ((cVar2 != '\0') && (param_2 != param_1)) {
    *param_2 = uVar3;
    *param_1 = uVar1;
  }
  uVar1 = *param_3;
  uVar3 = *param_2;
  cVar2 = FUN_140369440(local_res20,uVar1);
  if ((cVar2 != '\0') && (param_3 != param_2)) {
    *param_3 = uVar3;
    *param_2 = uVar1;
  }
  uVar1 = *param_2;
  uVar3 = *param_1;
  cVar2 = FUN_140369440(local_res20,uVar1);
  if ((cVar2 != '\0') && (param_2 != param_1)) {
    *param_2 = uVar3;
    *param_1 = uVar1;
  }
  return;
}

// ==== CAuctionSearchService::helper_14036a9b0  @14036a9b0  [medium:callgraph-r2]  (orig: FUN_14036a9b0)
void FUN_14036a9b0(longlong param_1,longlong param_2,longlong param_3,undefined8 param_4,
                  undefined4 param_5)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = param_2;
  while (lVar3 = lVar2 * 2 + 2, lVar3 < param_3) {
    cVar1 = FUN_140369440(&param_5,*(undefined8 *)(param_1 + lVar3 * 8),
                          *(undefined8 *)(param_1 + -8 + lVar3 * 8));
    if (cVar1 != '\0') {
      lVar3 = lVar3 + -1;
    }
    *(undefined8 *)(param_1 + lVar2 * 8) = *(undefined8 *)(param_1 + lVar3 * 8);
    lVar2 = lVar3;
  }
  if (lVar3 == param_3) {
    *(undefined8 *)(param_1 + lVar2 * 8) = *(undefined8 *)(param_1 + -8 + param_3 * 8);
    lVar2 = param_3 + -1;
  }
  FUN_140369f90(param_1,lVar2,param_2,param_4,param_5);
  return;
}

// ==== CAuctionSearchService::helper_14036ab20  @14036ab20  [medium:callgraph-r2]  (orig: FUN_14036ab20)
undefined8 FUN_14036ab20(longlong param_1,ulonglong param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  if (param_2 != 0) {
    if (0x1fffffffffffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_140369870();
    }
    lVar1 = FUN_14036a5a0(param_1 + 0x10);
    *(longlong *)(param_1 + 0x18) = lVar1;
    *(longlong *)(param_1 + 0x20) = lVar1;
    lVar1 = lVar1 + param_2 * 8;
    *(longlong *)(param_1 + 0x28) = lVar1;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CAuctionSearchService::helper_14036abc0  @14036abc0  [medium:callgraph-r1]  (orig: FUN_14036abc0)
void FUN_14036abc0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14036abc0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CAuctionSearchService::helper_14036ae50  @14036ae50  [medium:callgraph-r1]  (orig: FUN_14036ae50)
void FUN_14036ae50(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CAuctionSearchService::helper_14036aeb0  @14036aeb0  [medium:callgraph-r3]  (orig: FUN_14036aeb0)
undefined8 *
FUN_14036aeb0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CAuctionSearchService::helper_14036af80  @14036af80  [medium:callgraph-r2]  (orig: FUN_14036af80)
void * FUN_14036af80(void *param_1,longlong param_2,void *param_3)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _DstSize = lVar1 * 8;
  if (0 < lVar1) {
    memmove_s(param_3,_DstSize,param_1,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_3);
}

// ==== CAuctionSearchService::helper_14036afc0  @14036afc0  [medium:callgraph-r2]  (orig: FUN_14036afc0)
void * FUN_14036afc0(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CAuctionSearchService::helper_14036b0f0  @14036b0f0  [medium:callgraph-r2]  (orig: FUN_14036b0f0)
void FUN_14036b0f0(longlong param_1,longlong param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar1 = param_3 - param_1 >> 3;
  if (0x28 < lVar1) {
    lVar1 = lVar1 + 1;
    lVar2 = (longlong)(lVar1 + (ulonglong)((uint)(lVar1 >> 0x3f) & 7)) >> 3;
    lVar1 = lVar2 * 8 + param_1;
    FUN_14036a920(param_1,lVar1,param_1 + lVar2 * 0x10);
    FUN_14036a920(param_2 + lVar2 * -8,param_2,lVar2 * 8 + param_2,param_4);
    lVar3 = param_3 + lVar2 * -8;
    FUN_14036a920(param_3 + lVar2 * -0x10,lVar3,param_3,param_4);
    FUN_14036a920(lVar1,param_2,lVar3,param_4);
    return;
  }
  FUN_14036a920();
  return;
}

// ==== CAuctionSearchService::helper_14036b250  @14036b250  [medium:callgraph-r1]  (orig: FUN_14036b250)
void FUN_14036b250(undefined8 *param_1,undefined8 *param_2,undefined4 param_3)

{
  undefined8 uVar1;
  char cVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined4 local_res18 [4];
  
  if ((param_1 != param_2) && (puVar4 = param_1 + 1, puVar4 != param_2)) {
    local_res18[0] = param_3;
    do {
      uVar1 = *puVar4;
      puVar7 = puVar4;
      cVar2 = FUN_140369440(local_res18,uVar1,*param_1);
      if (cVar2 == '\0') {
        uVar5 = puVar4[-1];
        puVar6 = puVar4 + -1;
        cVar2 = FUN_140369440(local_res18,uVar1);
        while (puVar8 = puVar6, cVar2 != '\0') {
          *puVar7 = uVar5;
          uVar5 = puVar8[-1];
          puVar6 = puVar8 + -1;
          cVar2 = FUN_140369440(local_res18,uVar1);
          puVar7 = puVar8;
        }
        *puVar7 = uVar1;
      }
      else {
        lVar3 = (longlong)puVar4 - (longlong)param_1 >> 3;
        if (0 < lVar3) {
          memmove_s(puVar4 + (1 - lVar3),lVar3 * 8,param_1,lVar3 * 8);
        }
        *param_1 = uVar1;
      }
      puVar4 = puVar4 + 1;
    } while (puVar4 != param_2);
  }
  return;
}

// ==== CAuctionSearchService::helper_14036b370  @14036b370  [medium:callgraph-r0]  (orig: FUN_14036b370)
void FUN_14036b370(undefined8 *param_1)

{
  if ((void *)param_1[3] != (void *)0x0) {
    operator_delete((void *)param_1[3]);
  }
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CAuctionSearchService::helper_14036b3b0  @14036b3b0  [medium:callgraph-r0]  (orig: FUN_14036b3b0)
void FUN_14036b3b0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14036abc0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CAuctionSearchService::helper_14036b600  @14036b600  [medium:callgraph-r2]  (orig: FUN_14036b600)
undefined8 *
FUN_14036b600(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14036aeb0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CAuctionSearchService::helper_14036ba00  @14036ba00  [medium:callgraph-r1]  (orig: FUN_14036ba00)
undefined8 *
FUN_14036ba00(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3,undefined4 param_4)

{
  undefined8 uVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined4 local_res20 [2];
  
  puVar6 = param_2 + (((longlong)param_3 - (longlong)param_2 >> 3) -
                      ((longlong)param_3 - (longlong)param_2 >> 0x3f) >> 1);
  local_res20[0] = param_4;
  FUN_14036b0f0(param_2,puVar6,param_3 + -1);
  puVar8 = puVar6 + 1;
  while (puVar4 = puVar6, param_2 < puVar4) {
    uVar1 = puVar4[-1];
    uVar7 = *puVar4;
    puVar6 = puVar4 + -1;
    cVar2 = FUN_140369440(local_res20,uVar1,uVar7);
    if ((cVar2 != '\0') || (cVar2 = FUN_140369440(local_res20,uVar7,uVar1), cVar2 != '\0')) break;
  }
  puVar6 = puVar8;
  puVar5 = puVar4;
  if (puVar8 < param_3) {
    uVar1 = *puVar4;
    do {
      uVar7 = *puVar8;
      cVar2 = FUN_140369440(local_res20,uVar7,uVar1);
      puVar6 = puVar8;
      if ((cVar2 != '\0') ||
         (cVar2 = FUN_140369440(local_res20,uVar1,uVar7), puVar6 = puVar8, cVar2 != '\0')) break;
      puVar8 = puVar8 + 1;
      puVar6 = puVar8;
    } while (puVar8 < param_3);
  }
joined_r0x00014036baf3:
  do {
    puVar3 = puVar5;
    puVar5 = puVar4;
    puVar9 = puVar8;
    if (param_3 <= puVar8) {
joined_r0x00014036bb4f:
      for (; param_2 < puVar4; puVar4 = puVar4 + -1) {
        puVar5 = puVar5 + -1;
        uVar1 = *puVar3;
        uVar7 = *puVar5;
        cVar2 = FUN_140369440(local_res20,uVar7,uVar1);
        if (cVar2 == '\0') {
          cVar2 = FUN_140369440(local_res20,uVar1,uVar7);
          if (cVar2 != '\0') break;
          puVar3 = puVar3 + -1;
          if (puVar3 != puVar5) {
            uVar1 = *puVar3;
            *puVar3 = uVar7;
            *puVar5 = uVar1;
          }
        }
      }
      if (puVar4 == param_2) {
        if (puVar9 == param_3) {
          *param_1 = puVar3;
          param_1[1] = puVar6;
          return param_1;
        }
        if ((puVar6 != puVar9) && (puVar3 != puVar6)) {
          uVar1 = *puVar3;
          *puVar3 = *puVar6;
          *puVar6 = uVar1;
        }
        puVar6 = puVar6 + 1;
        puVar8 = puVar9 + 1;
        puVar5 = puVar3 + 1;
        if (puVar3 != puVar9) {
          uVar1 = *puVar3;
          *puVar3 = *puVar9;
          *puVar9 = uVar1;
        }
      }
      else {
        puVar4 = puVar4 + -1;
        if (puVar9 == param_3) {
          puVar5 = puVar3 + -1;
          if (puVar4 != puVar5) {
            uVar1 = *puVar4;
            *puVar4 = *puVar5;
            *puVar5 = uVar1;
          }
          puVar6 = puVar6 + -1;
          puVar8 = puVar9;
          if (puVar5 != puVar6) {
            uVar1 = *puVar5;
            *puVar5 = *puVar6;
            *puVar6 = uVar1;
          }
        }
        else {
          if (puVar9 != puVar4) {
            uVar1 = *puVar9;
            *puVar9 = *puVar4;
            *puVar4 = uVar1;
          }
          puVar8 = puVar9 + 1;
          puVar5 = puVar3;
        }
      }
      goto joined_r0x00014036baf3;
    }
    uVar1 = *puVar8;
    uVar7 = *puVar3;
    cVar2 = FUN_140369440(local_res20,uVar7,uVar1);
    puVar9 = puVar6;
    if (cVar2 == '\0') {
      cVar2 = FUN_140369440(local_res20,uVar1,uVar7);
      puVar9 = puVar8;
      if (cVar2 != '\0') goto joined_r0x00014036bb4f;
      puVar9 = puVar6 + 1;
      if (puVar6 != puVar8) {
        uVar7 = *puVar6;
        *puVar6 = uVar1;
        *puVar8 = uVar7;
      }
    }
    puVar8 = puVar8 + 1;
    puVar6 = puVar9;
    puVar5 = puVar3;
  } while( true );
}

// ==== CAuctionSearchService::helper_14036bc80  @14036bc80  [medium:callgraph-r1]  (orig: FUN_14036bc80)
void FUN_14036bc80(longlong param_1,longlong param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar3 = param_2 - param_1 >> 3;
  if (1 < lVar3) {
    lVar2 = lVar3 - (param_2 - param_1 >> 0x3f) >> 1;
    while (0 < lVar2) {
      lVar1 = lVar2 * 8;
      lVar2 = lVar2 + -1;
      FUN_14036a9b0(param_1,lVar2,lVar3,*(undefined8 *)(param_1 + -8 + lVar1),param_3);
    }
  }
  return;
}

// ==== CAuctionSearchService::helper_14036bd60  @14036bd60  [medium:callgraph-r0]  (orig: FUN_14036bd60)
undefined8 * FUN_14036bd60(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = operator_new(8);
  puVar2 = (void *)0x0;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_1;
    puVar2 = puVar1;
  }
  *param_1 = puVar2;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  return param_1;
}

// ==== CAuctionSearchService::helper_14036c190  @14036c190  [medium:callgraph-r1]  (orig: FUN_14036c190)
void FUN_14036c190(undefined8 *param_1,longlong param_2,undefined4 param_3)

{
  undefined8 uVar1;
  
  for (param_2 = param_2 - (longlong)param_1; 1 < param_2 >> 3; param_2 = param_2 + -8) {
    uVar1 = *(undefined8 *)((longlong)param_1 + param_2 + -8);
    *(undefined8 *)((longlong)param_1 + param_2 + -8) = *param_1;
    FUN_14036a9b0(param_1,0,param_2 + -8 >> 3,uVar1,param_3);
  }
  return;
}

// ==== CAuctionSearchService::helper_14036c200  @14036c200  [medium:callgraph-r1]  (orig: FUN_14036c200)
undefined8 * FUN_14036c200(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  void *_Src;
  ulonglong uVar1;
  undefined8 uVar2;
  longlong lVar3;
  rsize_t _DstSize;
  
  _Src = (void *)((longlong)*(void **)(param_3 + 8) + 8);
  lVar3 = param_1[4] - (longlong)_Src >> 3;
  if (0 < lVar3) {
    _DstSize = lVar3 << 3;
    memmove_s(*(void **)(param_3 + 8),_DstSize,_Src,_DstSize);
  }
  param_1[4] = param_1[4] + -8;
  uVar1 = *(ulonglong *)(param_3 + 8);
  *param_2 = 0;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  uVar2 = *param_1;
  param_2[1] = uVar1;
  *param_2 = uVar2;
  return param_2;
}

// ==== CAuctionSearchService::helper_14036c290  @14036c290  [medium:callgraph-r0]  (orig: FUN_14036c290)
void FUN_14036c290(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CAuctionSearchService::helper_14036c350  @14036c350  [medium:callgraph-r1]  (orig: FUN_14036c350)
undefined8 * FUN_14036c350(longlong param_1,undefined8 *param_2,ushort *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  bool bVar4;
  undefined1 local_18 [16];
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  bVar4 = true;
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar2;
      bVar4 = *param_3 < *(ushort *)(puVar3 + 3);
      if (bVar4) {
        puVar2 = (undefined8 *)*puVar3;
      }
      else {
        puVar2 = (undefined8 *)puVar3[2];
      }
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar3 = (undefined8 *)FUN_14036b600(param_1,local_18,bVar4,puVar3,param_3);
  uVar1 = puVar3[1];
  *param_2 = *puVar3;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CAuctionSearchService::helper_14036c3c0  @14036c3c0  [medium:callgraph-r2]  (orig: FUN_14036c3c0)
undefined8 * FUN_14036c3c0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140369950(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14036c5ac;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14036c5ac:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14036a4f0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1403696e0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14036a4f0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1403696e0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14036a4f0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1403696e0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CAuctionSearchService::helper_14036c7d0  @14036c7d0  [medium:callgraph-r3]  (orig: FUN_14036c7d0)
void FUN_14036c7d0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140369870();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14036a5a0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14036b990(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14036b990(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14036b030(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CAuctionSearchService::helper_14036ca80  @14036ca80  [medium:callgraph-r1]  (orig: FUN_14036ca80)
longlong * FUN_14036ca80(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14036b3b0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14036c3c0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CAuctionSearchService::vfunc_4  @14036cc90  [high:rtti-vtable]  (orig: FUN_14036cc90)
undefined8 FUN_14036cc90(undefined8 *param_1)

{
  ulonglong *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined7 uVar4;
  int iVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  
  puVar7 = (undefined8 *)param_1[6];
  uVar6 = 0;
  if ((undefined8 *)param_1[7] < puVar7) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)param_1[3];
  while( true ) {
    puVar2 = (undefined8 *)param_1[7];
    if (puVar2 < (undefined8 *)param_1[6]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)param_1[3])) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 == puVar2) break;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar6;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined8 **)(uVar8 + 0x20) <= puVar7) {
      _invalid_parameter_noinfo();
    }
    if ((void *)*puVar7 != (void *)0x0) {
      operator_delete((void *)*puVar7);
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar6;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined8 **)(uVar8 + 0x20) <= puVar7) {
      _invalid_parameter_noinfo();
    }
    puVar7 = puVar7 + 1;
  }
  FUN_14036c290(param_1 + 3);
  uVar8 = uVar6;
  while (iVar5 = (int)uVar8, iVar5 < 5) {
    FUN_14036c290(param_1 + (longlong)iVar5 * 6 + 9);
    uVar8 = (ulonglong)(iVar5 + 1);
  }
  while (iVar5 = (int)uVar6, iVar5 < 0xc) {
    FUN_14036c290(param_1 + (longlong)iVar5 * 6 + 0x27);
    uVar6 = (ulonglong)(iVar5 + 1);
  }
  FUN_14036b3b0(param_1 + 0x6f);
  uVar3 = FUN_14036b3b0(param_1 + 0x77);
  if (param_1 == (undefined8 *)0x0) {
    uVar4 = (undefined7)((ulonglong)uVar3 >> 8);
  }
  else {
    uVar3 = (**(code **)*param_1)(param_1,1);
    uVar4 = (undefined7)((ulonglong)uVar3 >> 8);
  }
  return CONCAT71(uVar4,1);
}

// ==== CAuctionSearchService::helper_14036ce50  @14036ce50  [medium:callgraph-r1]  (orig: FUN_14036ce50)
undefined8 FUN_14036ce50(longlong param_1,int param_2,byte param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  longlong *local_38 [2];
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  if ((byte)(param_3 - 1) < 5) {
    plVar1 = (longlong *)(param_1 + 0x48 + (ulonglong)param_3 * 0x30);
    puVar5 = (undefined8 *)plVar1[3];
    if ((undefined8 *)plVar1[4] < puVar5) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)*plVar1;
    while( true ) {
      puVar3 = (undefined8 *)plVar1[4];
      local_38[0] = (longlong *)0x0;
      if (puVar3 < (undefined8 *)plVar1[3]) {
        _invalid_parameter_noinfo();
      }
      local_38[0] = (longlong *)*plVar1;
      if ((plVar2 == (longlong *)0x0) || (plVar2 != local_38[0])) {
        _invalid_parameter_noinfo();
      }
      if (puVar5 == puVar3) {
        return 0;
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (*(undefined8 **)(lVar6 + 0x20) <= puVar5) {
        _invalid_parameter_noinfo();
      }
      if (((int *)*puVar5 != (int *)0x0) && (*(int *)*puVar5 == param_2)) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (*(undefined8 **)(lVar6 + 0x20) <= puVar5) {
        _invalid_parameter_noinfo();
      }
      puVar5 = puVar5 + 1;
    }
    local_48 = SUB84(plVar2,0);
    uStack_44 = (undefined4)((ulonglong)plVar2 >> 0x20);
    uStack_40 = SUB84(puVar5,0);
    uStack_3c = (undefined4)((ulonglong)puVar5 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    FUN_14036c200(plVar1,local_38,&local_28);
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CAuctionSearchService::helper_14036cfa0  @14036cfa0  [medium:callgraph-r1]  (orig: FUN_14036cfa0)
undefined8 FUN_14036cfa0(longlong param_1,int param_2,byte param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  longlong *local_38 [2];
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  if ((byte)(param_3 - 1) < 0xc) {
    plVar1 = (longlong *)(param_1 + 0x138 + (ulonglong)param_3 * 0x30);
    puVar5 = (undefined8 *)plVar1[3];
    if ((undefined8 *)plVar1[4] < puVar5) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)*plVar1;
    while( true ) {
      puVar3 = (undefined8 *)plVar1[4];
      local_38[0] = (longlong *)0x0;
      if (puVar3 < (undefined8 *)plVar1[3]) {
        _invalid_parameter_noinfo();
      }
      local_38[0] = (longlong *)*plVar1;
      if ((plVar2 == (longlong *)0x0) || (plVar2 != local_38[0])) {
        _invalid_parameter_noinfo();
      }
      if (puVar5 == puVar3) {
        return 0;
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (*(undefined8 **)(lVar6 + 0x20) <= puVar5) {
        _invalid_parameter_noinfo();
      }
      if (((int *)*puVar5 != (int *)0x0) && (*(int *)*puVar5 == param_2)) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (*(undefined8 **)(lVar6 + 0x20) <= puVar5) {
        _invalid_parameter_noinfo();
      }
      puVar5 = puVar5 + 1;
    }
    local_48 = SUB84(plVar2,0);
    uStack_44 = (undefined4)((ulonglong)plVar2 >> 0x20);
    uStack_40 = SUB84(puVar5,0);
    uStack_3c = (undefined4)((ulonglong)puVar5 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    FUN_14036c200(plVar1,local_38,&local_28);
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CAuctionSearchService::helper_14036d0f0  @14036d0f0  [medium:callgraph-r1]  (orig: FUN_14036d0f0)
undefined8 FUN_14036d0f0(longlong param_1,int param_2,ushort param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined8 *puVar7;
  bool bVar8;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  longlong *local_58 [2];
  undefined8 local_48;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_48 = 0xfffffffffffffffe;
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 0x3a8))[1];
  puVar4 = *(undefined8 **)(param_1 + 0x3a8);
  while (puVar7 = puVar5, *(char *)((longlong)puVar7 + 0x29) == '\0') {
    if (*(ushort *)(puVar7 + 3) < param_3) {
      puVar5 = (undefined8 *)puVar7[2];
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
      puVar4 = puVar7;
    }
  }
  if ((longlong *)(param_1 + 0x378) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x378);
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 0x3a8))[1];
  puVar7 = *(undefined8 **)(param_1 + 0x3a8);
  while (puVar3 = puVar5, *(char *)((longlong)puVar3 + 0x29) == '\0') {
    if (param_3 < *(ushort *)(puVar3 + 3)) {
      puVar5 = (undefined8 *)*puVar3;
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)puVar3[2];
    }
  }
  local_58[0] = (longlong *)0x0;
  if ((longlong *)(param_1 + 0x378) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = *(longlong **)(param_1 + 0x378);
  uStack_80 = puVar4;
  local_58[0] = plVar2;
  do {
    while( true ) {
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar2)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar7) {
          return 0;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (((int *)puVar4[4] != (int *)0x0) && (*(int *)puVar4[4] == param_2)) {
          local_88 = SUB84(plVar1,0);
          uStack_84 = (undefined4)((ulonglong)plVar1 >> 0x20);
          local_38 = local_88;
          uStack_34 = uStack_84;
          uStack_30 = (undefined4)uStack_80;
          uStack_2c = uStack_80._4_4_;
          FUN_14036c3c0(param_1 + 0x378,local_58,&local_38);
          return 1;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      puVar5 = puVar4;
      puVar3 = (undefined8 *)puVar4[2];
      if (*(char *)((longlong)puVar4[2] + 0x29) != '\0') break;
      do {
        puVar4 = puVar3;
        puVar3 = (undefined8 *)*puVar4;
        uStack_80 = puVar4;
      } while (*(char *)((longlong)*puVar4 + 0x29) == '\0');
    }
    do {
      puVar4 = (undefined8 *)puVar5[1];
      uStack_80 = puVar4;
      if (*(char *)((longlong)puVar4 + 0x29) != '\0') break;
      bVar8 = puVar5 == (undefined8 *)puVar4[2];
      puVar5 = puVar4;
    } while (bVar8);
  } while( true );
}

// ==== CAuctionSearchService::helper_14036d300  @14036d300  [medium:callgraph-r1]  (orig: FUN_14036d300)
undefined8 FUN_14036d300(longlong param_1,int param_2,ushort param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined8 *puVar7;
  bool bVar8;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  longlong *local_58 [2];
  undefined8 local_48;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_48 = 0xfffffffffffffffe;
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 1000))[1];
  puVar4 = *(undefined8 **)(param_1 + 1000);
  while (puVar7 = puVar5, *(char *)((longlong)puVar7 + 0x29) == '\0') {
    if (*(ushort *)(puVar7 + 3) < param_3) {
      puVar5 = (undefined8 *)puVar7[2];
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
      puVar4 = puVar7;
    }
  }
  if ((longlong *)(param_1 + 0x3b8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x3b8);
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 1000))[1];
  puVar7 = *(undefined8 **)(param_1 + 1000);
  while (puVar3 = puVar5, *(char *)((longlong)puVar3 + 0x29) == '\0') {
    if (param_3 < *(ushort *)(puVar3 + 3)) {
      puVar5 = (undefined8 *)*puVar3;
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)puVar3[2];
    }
  }
  local_58[0] = (longlong *)0x0;
  if ((longlong *)(param_1 + 0x3b8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = *(longlong **)(param_1 + 0x3b8);
  uStack_80 = puVar4;
  local_58[0] = plVar2;
  do {
    while( true ) {
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar2)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar7) {
          return 0;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (((int *)puVar4[4] != (int *)0x0) && (*(int *)puVar4[4] == param_2)) {
          local_88 = SUB84(plVar1,0);
          uStack_84 = (undefined4)((ulonglong)plVar1 >> 0x20);
          local_38 = local_88;
          uStack_34 = uStack_84;
          uStack_30 = (undefined4)uStack_80;
          uStack_2c = uStack_80._4_4_;
          FUN_14036c3c0(param_1 + 0x3b8,local_58,&local_38);
          return 1;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      puVar5 = puVar4;
      puVar3 = (undefined8 *)puVar4[2];
      if (*(char *)((longlong)puVar4[2] + 0x29) != '\0') break;
      do {
        puVar4 = puVar3;
        puVar3 = (undefined8 *)*puVar4;
        uStack_80 = puVar4;
      } while (*(char *)((longlong)*puVar4 + 0x29) == '\0');
    }
    do {
      puVar4 = (undefined8 *)puVar5[1];
      uStack_80 = puVar4;
      if (*(char *)((longlong)puVar4 + 0x29) != '\0') break;
      bVar8 = puVar5 == (undefined8 *)puVar4[2];
      puVar5 = puVar4;
    } while (bVar8);
  } while( true );
}

// ==== CAuctionSearchService::helper_14036d510  @14036d510  [medium:callgraph-r1]  (orig: FUN_14036d510)
longlong FUN_14036d510(longlong param_1,longlong param_2)

{
  void *pvVar1;
  void *_Src;
  void *_Dst;
  char cVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  rsize_t _DstSize;
  ulonglong uVar7;
  
  if (param_1 != param_2) {
    _Src = *(void **)(param_2 + 0x18);
    uVar3 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
    if (uVar3 == 0) {
      FUN_14036c290();
      return param_1;
    }
    _Dst = *(void **)(param_1 + 0x18);
    uVar7 = *(longlong *)(param_1 + 0x20) - (longlong)_Dst >> 3;
    if (uVar3 <= uVar7) {
      lVar6 = *(longlong *)(param_2 + 0x20) - (longlong)_Src >> 3;
      if (0 < lVar6) {
        _DstSize = lVar6 << 3;
        memmove_s(_Dst,_DstSize,_Src,_DstSize);
      }
      *(longlong *)(param_1 + 0x20) =
           *(longlong *)(param_1 + 0x18) +
           (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3) * 8;
      return param_1;
    }
    if (_Dst == (void *)0x0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(longlong *)(param_1 + 0x28) - (longlong)_Dst >> 3;
    }
    if (uVar3 <= uVar5) {
      pvVar1 = (void *)((longlong)_Src + uVar7 * 8);
      FUN_14036af80(_Src,pvVar1,_Dst);
      uVar4 = FUN_14036afc0(param_1,pvVar1,*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x20));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      return param_1;
    }
    if (_Dst != (void *)0x0) {
      operator_delete(_Dst);
    }
    cVar2 = FUN_14036ab20(param_1,*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3
                         );
    if (cVar2 != '\0') {
      uVar4 = FUN_14036afc0(param_1,*(undefined8 *)(param_2 + 0x18),*(undefined8 *)(param_2 + 0x20),
                            *(undefined8 *)(param_1 + 0x18));
      *(undefined8 *)(param_1 + 0x20) = uVar4;
    }
  }
  return param_1;
}

// ==== CAuctionSearchService::helper_14036d650  @14036d650  [medium:callgraph-r2]  (orig: FUN_14036d650)
longlong * FUN_14036d650(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14036c7d0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14036d744;
  }
  _invalid_parameter_noinfo();
LAB_14036d744:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CAuctionSearchService::helper_14036d800  @14036d800  [medium:callgraph-r0]  (orig: FUN_14036d800)
void FUN_14036d800(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14036ca80((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CAuctionSearchService::helper_14036d870  @14036d870  [medium:callgraph-r0]  (orig: FUN_14036d870)
void FUN_14036d870(longlong param_1,longlong param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  longlong local_18;
  longlong local_10;
  
  lVar1 = param_2 - param_1;
  do {
    lVar1 = lVar1 >> 3;
    if (lVar1 < 0x21) {
LAB_14036d945:
      if (1 < lVar1) {
        FUN_14036b250(param_1,param_2,param_4,0);
      }
      return;
    }
    if (param_3 < 1) {
      if (0x20 < lVar1) {
        FUN_14036bc80(param_1,param_2,param_4);
        FUN_14036c190(param_1,param_2,param_4);
        return;
      }
      goto LAB_14036d945;
    }
    FUN_14036ba00(&local_18,param_1,param_2,param_4);
    lVar1 = local_10;
    param_3 = param_3 / 2 + (param_3 / 2) / 2;
    if ((longlong)(local_18 - param_1 & 0xfffffffffffffff8U) <
        (longlong)(param_2 - local_10 & 0xfffffffffffffff8U)) {
      FUN_14036d870(param_1,local_18,param_3,param_4);
      param_1 = lVar1;
    }
    else {
      FUN_14036d870(local_10,param_2,param_3,param_4);
      param_2 = local_18;
    }
    lVar1 = param_2 - param_1;
  } while( true );
}

// ==== CAuctionSearchService::helper_14036d9a0  @14036d9a0  [medium:callgraph-r0]  (orig: FUN_14036d9a0)
undefined8 FUN_14036d9a0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  int *piVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  longlong *local_38 [2];
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  puVar4 = *(undefined8 **)(param_1 + 0x30);
  if (*(undefined8 **)(param_1 + 0x38) < puVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x18);
  while( true ) {
    puVar2 = *(undefined8 **)(param_1 + 0x38);
    local_38[0] = (longlong *)0x0;
    if (puVar2 < *(undefined8 **)(param_1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_38[0] = *(longlong **)(param_1 + 0x18);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_38[0])) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    piVar3 = (int *)*puVar4;
    if ((piVar3 != (int *)0x0) && (*piVar3 == param_2)) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(undefined8 **)(lVar5 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  local_48 = SUB84(plVar1,0);
  uStack_44 = (undefined4)((ulonglong)plVar1 >> 0x20);
  uStack_40 = SUB84(puVar4,0);
  uStack_3c = (undefined4)((ulonglong)puVar4 >> 0x20);
  local_28 = local_48;
  uStack_24 = uStack_44;
  uStack_20 = uStack_40;
  uStack_1c = uStack_3c;
  FUN_14036c200(param_1 + 0x18,local_38,&local_28);
  FUN_14036cfa0(param_1,param_2,*(undefined1 *)((longlong)piVar3 + 0x1f));
  FUN_14036ce50(param_1,param_2,*(undefined1 *)((longlong)piVar3 + 0x1d));
  FUN_14036d0f0(param_1,param_2,(short)piVar3[8]);
  FUN_14036d300(param_1,param_2,*(ushort *)(piVar3 + 8) / 1000);
  operator_delete(piVar3);
  return 1;
}

// ==== CAuctionSearchService::helper_14036db40  @14036db40  [medium:callgraph-r1]  (orig: FUN_14036db40)
void FUN_14036db40(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14036d650(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CAuctionSearchService::ctor_or_dtor  @14036dcd0  [high:vtable-assign]  (orig: FUN_14036dcd0)
void FUN_14036dcd0(undefined8 *param_1)

{
  *param_1 = CAuctionSearchService::vftable;
  FUN_14036d800(param_1 + 0x77);
  operator_delete((void *)param_1[0x77]);
  FUN_14036d800(param_1 + 0x6f);
  operator_delete((void *)param_1[0x6f]);
  _eh_vector_destructor_iterator_(param_1 + 0x27,0x30,0xc,FUN_14036b370);
  _eh_vector_destructor_iterator_(param_1 + 9,0x30,5,FUN_14036b370);
  if ((void *)param_1[6] != (void *)0x0) {
    operator_delete((void *)param_1[6]);
  }
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CAuctionSearchService::helper_14036dda0  @14036dda0  [medium:callgraph-r0]  (orig: FUN_14036dda0)
undefined8 FUN_14036dda0(longlong param_1,longlong param_2)

{
  byte bVar1;
  void *pvVar2;
  undefined8 uVar3;
  void *local_res18 [2];
  undefined2 local_30 [4];
  void *local_28;
  ushort local_20 [4];
  void *local_18;
  
  local_res18[0] = operator_new(0x2c);
  if (local_res18[0] == (void *)0x0) {
    pvVar2 = (void *)0x0;
  }
  else {
    pvVar2 = (void *)FUN_1403691e0(local_res18[0],param_2);
  }
  if (pvVar2 == (void *)0x0) {
    uVar3 = 0;
  }
  else {
    local_res18[0] = pvVar2;
    FUN_14036db40(param_1 + 0x18,local_res18);
    bVar1 = *(byte *)(param_2 + 0x1f);
    if ((bVar1 != 0) && (bVar1 < 0xd)) {
      FUN_14036db40(param_1 + 0x138 + (ulonglong)bVar1 * 0x30,local_res18);
    }
    bVar1 = *(byte *)(param_2 + 0x1d);
    if ((bVar1 != 0) && (bVar1 < 6)) {
      FUN_14036db40(param_1 + 0x48 + (ulonglong)bVar1 * 0x30,local_res18);
    }
    local_30[0] = *(undefined2 *)(param_2 + 0x20);
    local_28 = pvVar2;
    FUN_14036c350(param_1 + 0x378,local_20,local_30);
    local_20[0] = *(ushort *)(param_2 + 0x20) / 1000;
    local_18 = pvVar2;
    FUN_14036c350(param_1 + 0x3b8,local_30,local_20);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CAuctionSearchService::helper_14036ded0  @14036ded0  [medium:callgraph-r1]  (orig: FUN_14036ded0)
undefined8 FUN_14036ded0(longlong param_1,ushort param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  
  FUN_14036c290(param_3);
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 0x3a8))[1];
  cVar1 = *(char *)((longlong)puVar5 + 0x29);
  puVar6 = *(undefined8 **)(param_1 + 0x3a8);
  while (cVar1 == '\0') {
    if (*(ushort *)(puVar5 + 3) < param_2) {
      puVar3 = (undefined8 *)puVar5[2];
      puVar5 = puVar6;
    }
    else {
      puVar3 = (undefined8 *)*puVar5;
    }
    puVar6 = puVar5;
    puVar5 = puVar3;
    cVar1 = *(char *)((longlong)puVar3 + 0x29);
  }
  puVar5 = *(undefined8 **)(param_1 + 0x3a8);
  plVar2 = *(longlong **)(param_1 + 0x378);
  cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
  puVar3 = (undefined8 *)puVar5[1];
  while (cVar1 == '\0') {
    if (param_2 < *(ushort *)(puVar3 + 3)) {
      puVar4 = (undefined8 *)*puVar3;
      puVar5 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)puVar3[2];
    }
    puVar3 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x29);
  }
  while( true ) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puVar6 == *(undefined8 **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14036db40(param_3,puVar6 + 4);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x29) == '\0') {
      puVar3 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar3 + 0x29) == '\0') {
        cVar1 = *(char *)((longlong)*puVar3 + 0x29);
        puVar6 = puVar3;
        puVar3 = (undefined8 *)*puVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar3 + 0x29);
          puVar6 = puVar3;
          puVar3 = (undefined8 *)*puVar3;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
        puVar4 = (undefined8 *)puVar6[1];
        puVar3 = puVar6;
        while ((puVar6 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
          puVar4 = (undefined8 *)puVar6[1];
          puVar3 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 1;
}

// ==== CAuctionSearchService::helper_14036e030  @14036e030  [medium:callgraph-r1]  (orig: FUN_14036e030)
undefined8 FUN_14036e030(longlong param_1,ushort param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  
  FUN_14036c290(param_3);
  puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 1000))[1];
  cVar1 = *(char *)((longlong)puVar5 + 0x29);
  puVar6 = *(undefined8 **)(param_1 + 1000);
  while (cVar1 == '\0') {
    if (*(ushort *)(puVar5 + 3) < param_2) {
      puVar3 = (undefined8 *)puVar5[2];
      puVar5 = puVar6;
    }
    else {
      puVar3 = (undefined8 *)*puVar5;
    }
    puVar6 = puVar5;
    puVar5 = puVar3;
    cVar1 = *(char *)((longlong)puVar3 + 0x29);
  }
  puVar5 = *(undefined8 **)(param_1 + 1000);
  plVar2 = *(longlong **)(param_1 + 0x3b8);
  cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
  puVar3 = (undefined8 *)puVar5[1];
  while (cVar1 == '\0') {
    if (param_2 < *(ushort *)(puVar3 + 3)) {
      puVar4 = (undefined8 *)*puVar3;
      puVar5 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)puVar3[2];
    }
    puVar3 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x29);
  }
  while( true ) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puVar6 == *(undefined8 **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14036db40(param_3,puVar6 + 4);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x29) == '\0') {
      puVar3 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar3 + 0x29) == '\0') {
        cVar1 = *(char *)((longlong)*puVar3 + 0x29);
        puVar6 = puVar3;
        puVar3 = (undefined8 *)*puVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar3 + 0x29);
          puVar6 = puVar3;
          puVar3 = (undefined8 *)*puVar3;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
        puVar4 = (undefined8 *)puVar6[1];
        puVar3 = puVar6;
        while ((puVar6 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
          puVar4 = (undefined8 *)puVar6[1];
          puVar3 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 1;
}

// ==== CAuctionSearchService::helper_14036e190  @14036e190  [medium:callgraph-r0]  (orig: FUN_14036e190)
void FUN_14036e190(undefined8 param_1,int param_2,undefined2 param_3,int param_4)

{
  int *piVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *local_50 [3];
  undefined8 *local_38;
  undefined8 *local_30;
  undefined8 local_28;
  
  plVar3 = operator_new(8);
  plVar6 = (longlong *)0x0;
  local_50[0] = plVar6;
  if (plVar3 != (longlong *)0x0) {
    *plVar3 = (longlong)local_50;
    local_50[0] = plVar3;
  }
  local_38 = (undefined8 *)0x0;
  local_30 = (undefined8 *)0x0;
  local_28 = 0;
  FUN_14036ded0(param_1,param_3,local_50);
  puVar4 = local_38;
  plVar3 = local_50[0];
  if (local_30 < local_38) {
    _invalid_parameter_noinfo();
    plVar3 = local_50[0];
  }
  while( true ) {
    puVar2 = local_30;
    if (local_30 < local_38) {
      _invalid_parameter_noinfo();
    }
    if ((plVar3 == (longlong *)0x0) || (plVar3 != local_50[0])) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) {
      if (local_38 != (undefined8 *)0x0) {
        operator_delete(local_38);
      }
      local_38 = (undefined8 *)0x0;
      local_30 = (undefined8 *)0x0;
      local_28 = 0;
      operator_delete(local_50[0]);
      return;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar5 = plVar6;
    }
    else {
      plVar5 = (longlong *)*plVar3;
    }
    if ((undefined8 *)plVar5[4] <= puVar4) {
      _invalid_parameter_noinfo();
    }
    piVar1 = (int *)*puVar4;
    if ((piVar1 != (int *)0x0) && (*piVar1 == param_2)) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar5 = plVar6;
    }
    else {
      plVar5 = (longlong *)*plVar3;
    }
    if ((undefined8 *)plVar5[4] <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  piVar1[2] = param_4;
  if (local_38 != (undefined8 *)0x0) {
    operator_delete(local_38);
  }
  local_38 = (undefined8 *)0x0;
  local_30 = (undefined8 *)0x0;
  local_28 = 0;
  operator_delete(local_50[0]);
  return;
}

// ==== CAuctionSearchService::helper_14036e310  @14036e310  [medium:callgraph-r0]  (orig: FUN_14036e310)
undefined8 * FUN_14036e310(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14036ae50(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CAuctionSearchService::ctor_or_dtor  @14036e400  [high:vtable-assign]  (orig: FUN_14036e400)
undefined8 * FUN_14036e400(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CAuctionSearchService::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 3);
    plVar2 = plVar1;
  }
  param_1[3] = plVar2;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  _eh_vector_constructor_iterator_(param_1 + 9,0x30,5,FUN_14036bd60,FUN_14036b370);
  _eh_vector_constructor_iterator_(param_1 + 0x27,0x30,0xc,FUN_14036bd60,FUN_14036b370);
  FUN_14036e310(param_1 + 0x6f);
  FUN_14036e310(param_1 + 0x77);
  *(undefined4 *)(param_1 + 1) = 0;
  param_1[2] = 0;
  return param_1;
}

// ==== CAuctionSearchService::vfunc_0  @14036e4e0  [high:rtti-vtable]  (orig: FUN_14036e4e0)
undefined8 FUN_14036e4e0(undefined8 param_1,uint param_2)

{
  FUN_14036dcd0();
  if ((param_2 & 1) != 0) {
    FUN_14036a0f0(param_1);
  }
  return param_1;
}

// ==== CAuctionSearchService::helper_14036e620  @14036e620  [medium:callgraph-r1]  (orig: FUN_14036e620)
undefined8 FUN_14036e620(longlong param_1,byte param_2,undefined8 param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong *puVar4;
  
  FUN_14036c290(param_3);
  if (param_2 < 0xc) {
    puVar4 = (ulonglong *)(param_1 + 0x158 + (ulonglong)param_2 * 0x30);
    uVar3 = (ulonglong)(byte)(0xc - param_2);
    do {
      uVar1 = *puVar4;
      if (uVar1 < puVar4[-1]) {
        _invalid_parameter_noinfo();
      }
      uVar2 = puVar4[-1];
      if (*puVar4 < uVar2) {
        _invalid_parameter_noinfo();
      }
      for (; uVar2 != uVar1; uVar2 = uVar2 + 8) {
        FUN_14036db40(param_3,uVar2);
      }
      puVar4 = puVar4 + 6;
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
  }
  return 1;
}

// ==== CAuctionSearchService::helper_14036e6d0  @14036e6d0  [medium:callgraph-r1]  (orig: FUN_14036e6d0)
undefined8 FUN_14036e6d0(longlong param_1,byte param_2,undefined8 param_3)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  ulonglong *puVar4;
  
  FUN_14036c290(param_3);
  if (param_2 < 5) {
    puVar4 = (ulonglong *)(param_1 + 0x68 + (ulonglong)param_2 * 0x30);
    uVar3 = (ulonglong)(byte)(5 - param_2);
    do {
      uVar1 = *puVar4;
      if (uVar1 < puVar4[-1]) {
        _invalid_parameter_noinfo();
      }
      uVar2 = puVar4[-1];
      if (*puVar4 < uVar2) {
        _invalid_parameter_noinfo();
      }
      for (; uVar2 != uVar1; uVar2 = uVar2 + 8) {
        FUN_14036db40(param_3,uVar2);
      }
      puVar4 = puVar4 + 6;
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
  }
  return 1;
}

// ==== CAuctionSearchService::helper_14036e780  @14036e780  [medium:callgraph-r0]  (orig: FUN_14036e780)
void FUN_14036e780(longlong param_1,int *param_2)

{
  byte bVar1;
  ushort uVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  void *pvVar6;
  void *pvVar7;
  char cVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *local_res18;
  longlong *local_res20;
  longlong *local_100 [3];
  undefined8 *local_e8;
  undefined8 *local_e0;
  undefined8 local_d8;
  longlong *local_d0 [3];
  void *local_b8;
  void *local_b0;
  undefined8 local_a8;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined8 local_88;
  undefined8 uStack_80;
  longlong *local_78;
  longlong *local_68;
  undefined8 local_58;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_58 = 0xfffffffffffffffe;
  if (*param_2 != 0) {
    local_res18 = operator_new(8);
    if (local_res18 == (longlong *)0x0) {
      local_100[0] = (longlong *)0x0;
    }
    else {
      *local_res18 = (longlong)local_100;
      local_100[0] = local_res18;
    }
    plVar10 = (longlong *)0x0;
    local_e8 = (undefined8 *)0x0;
    local_e0 = (undefined8 *)0x0;
    local_d8 = 0;
    uVar2 = *(ushort *)(param_2 + 8);
    local_res20 = local_res18;
    if (uVar2 == 0) {
      bVar1 = *(byte *)((longlong)param_2 + 0x1f);
      if ((bVar1 == 0) || (0xc < bVar1)) {
        bVar1 = *(byte *)((longlong)param_2 + 0x1d);
        if ((bVar1 == 0) || (5 < bVar1)) {
          FUN_14036d510(local_100,param_1 + 0x18);
        }
        else {
          FUN_14036e6d0(param_1,bVar1,local_100);
        }
      }
      else {
        FUN_14036e620(param_1,bVar1,local_100);
      }
    }
    else if (uVar2 < 1000) {
      FUN_14036e030(param_1,uVar2,local_100);
    }
    else {
      FUN_14036ded0(param_1,uVar2,local_100);
    }
    local_res18 = operator_new(8);
    puVar9 = local_e8;
    local_d0[0] = plVar10;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_d0;
      local_d0[0] = local_res18;
    }
    local_b8 = (void *)0x0;
    local_b0 = (void *)0x0;
    local_a8 = 0;
    local_78 = (longlong *)0x0;
    local_res20 = local_res18;
    if (local_e0 < local_e8) {
      _invalid_parameter_noinfo();
    }
    plVar4 = local_100[0];
    local_78 = local_100[0];
    while( true ) {
      puVar5 = local_e0;
      local_68 = (longlong *)0x0;
      if (local_e0 < local_e8) {
        _invalid_parameter_noinfo();
      }
      local_68 = local_100[0];
      if ((plVar4 == (longlong *)0x0) || (plVar4 != local_100[0])) {
        _invalid_parameter_noinfo();
      }
      if (puVar9 == puVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar11 = plVar10;
      }
      else {
        plVar11 = (longlong *)*plVar4;
      }
      if ((undefined8 *)plVar11[4] <= puVar9) {
        _invalid_parameter_noinfo();
      }
      local_res18 = (longlong *)*puVar9;
      if ((local_res18 != (longlong *)0x0) &&
         (cVar8 = FUN_140369150((longlong)local_res18 + 0xc,param_2 + 3), cVar8 != '\0')) {
        FUN_14036db40(local_d0,&local_res18);
      }
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar11 = plVar10;
      }
      else {
        plVar11 = (longlong *)*plVar4;
      }
      if ((undefined8 *)plVar11[4] <= puVar9) {
        _invalid_parameter_noinfo();
      }
      puVar9 = puVar9 + 1;
    }
    FUN_14036c290(local_100);
    pvVar7 = local_b0;
    if ((short)param_2[1] != 0) {
      local_88 = (longlong *)0x0;
      if (local_b0 < local_b8) {
        _invalid_parameter_noinfo();
      }
      pvVar6 = local_b8;
      plVar10 = local_d0[0];
      local_88 = local_d0[0];
      uStack_80 = pvVar7;
      local_88._0_4_ = SUB84(local_d0[0],0);
      local_88._4_4_ = (undefined4)((ulonglong)local_d0[0] >> 0x20);
      uStack_80._0_4_ = SUB84(pvVar7,0);
      uStack_80._4_4_ = (undefined4)((ulonglong)pvVar7 >> 0x20);
      local_38 = (undefined4)local_88;
      uStack_34 = local_88._4_4_;
      uStack_30 = (undefined4)uStack_80;
      uStack_2c = uStack_80._4_4_;
      local_98 = (longlong *)0x0;
      local_88 = plVar10;
      uStack_80 = pvVar7;
      if (local_b0 < local_b8) {
        _invalid_parameter_noinfo();
      }
      local_98 = local_d0[0];
      plVar4 = local_98;
      uStack_90 = pvVar6;
      local_98._0_4_ = SUB84(local_d0[0],0);
      local_98._4_4_ = (undefined4)((ulonglong)local_d0[0] >> 0x20);
      uStack_90._0_4_ = SUB84(pvVar6,0);
      uStack_90._4_4_ = (undefined4)((ulonglong)pvVar6 >> 0x20);
      local_48 = (undefined4)local_98;
      uStack_44 = local_98._4_4_;
      uStack_40 = (undefined4)uStack_90;
      uStack_3c = uStack_90._4_4_;
      iVar3 = param_2[1];
      local_98 = plVar4;
      uStack_90 = pvVar6;
      if ((plVar10 == (longlong *)0x0) || (plVar10 != local_d0[0])) {
        _invalid_parameter_noinfo();
      }
      FUN_14036d870(pvVar6,pvVar7,(longlong)pvVar7 - (longlong)pvVar6 >> 3,(short)iVar3);
    }
    FUN_14036a1b0(param_1,*param_2,(short)param_2[1],*(undefined2 *)((longlong)param_2 + 6),
                  param_2 + 3,local_d0);
    if (local_b8 != (void *)0x0) {
      operator_delete(local_b8);
    }
    local_b8 = (void *)0x0;
    local_b0 = (void *)0x0;
    local_a8 = 0;
    operator_delete(local_d0[0]);
    if (local_e8 != (undefined8 *)0x0) {
      operator_delete(local_e8);
    }
    local_e8 = (undefined8 *)0x0;
    local_e0 = (undefined8 *)0x0;
    local_d8 = 0;
    operator_delete(local_100[0]);
  }
  return;
}

// ==== CAuctionSearchService::ProcessMsg  @14036eb40  [high:log-string]  (orig: FUN_14036eb40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_14036eb40(longlong param_1,undefined8 param_2,char *param_3,ulonglong param_4,uint param_5)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined1 auStack_118 [32];
  char *local_f8;
  undefined4 local_f0;
  undefined4 local_e8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_d8;
  ulonglong uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  longlong local_98;
  ulonglong uStack_90;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_88 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_60 [40];
  ulonglong local_38;
  
  local_b8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_118;
  local_e8 = (undefined4)param_2;
  switch(local_e8) {
  case 0x16379:
    if (param_3 == (char *)0x0) {
      log_InlineLogFACEBOOK
                ("CAuctionSearchService::ProcessMsg, AUCTION_ADD_ITEM, buf is NULL, type:%d, from:%d"
                 ,param_4 & 0xffffffff,(ulonglong)param_5);
      return 0;
    }
    uVar5 = FUN_14036dda0(param_1,param_3);
    return uVar5;
  case 0x1637a:
    if (param_3 == (char *)0x0) {
      log_InlineLogFACEBOOK
                ("CAuctionSearchService::ProcessMsg, AUCTION_DEL_ITEM, buf is NULL, type:%d, from:%d"
                 ,param_4 & 0xffffffff,(ulonglong)param_5);
      return 0;
    }
    uVar5 = FUN_14036d9a0(param_1,*(undefined4 *)param_3);
    return uVar5;
  case 0x1637b:
    if (param_3 == (char *)0x0) {
      log_InlineLogFACEBOOK
                ("CAuctionSearchService::ProcessMsg, AUCTION_SEARCH_ITEM, buf is NULL, type:%d, from:%d"
                 ,param_4 & 0xffffffff,(ulonglong)param_5);
      return 0;
    }
    FUN_14036e780(param_1,param_3);
    break;
  case 0x1637c:
    if (param_3 == (char *)0x0) {
      log_InlineLogFACEBOOK
                ("CAuctionSearchService::ProcessMsg, AUCTION_UPDATE_TIMEOUT, buf is NULL, type:%d, from:%d"
                 ,param_4 & 0xffffffff,(ulonglong)param_5);
      return 0;
    }
    FUN_14036e190(param_1,*(undefined4 *)param_3,*(undefined2 *)(param_3 + 0x20),
                  *(undefined4 *)(param_3 + 0x28));
    break;
  case 0x1637d:
    if (param_3 == (char *)0x0) {
      log_InlineLogFACEBOOK
                ("CAuctionSearchService::ProcessMsg, AUCTION_UPDATE_PRICE, buf is NULL, type:%d, from:%d"
                 ,param_4 & 0xffffffff,(ulonglong)param_5);
      return 0;
    }
    FUN_14036e190(param_1,*(undefined4 *)param_3,*(undefined2 *)(param_3 + 0x20),
                  *(undefined4 *)(param_3 + 8));
    break;
  case 0x1637e:
    if ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) & 0xfffffffffffffff8U) != 0)
    {
      uVar1 = *(ulonglong *)(param_1 + 0x38);
      local_d8 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0;
      if (uVar1 < *(ulonglong *)(param_1 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar4 = *(longlong *)(param_1 + 0x18);
      uVar2 = *(ulonglong *)(param_1 + 0x30);
      local_c8 = 0;
      local_d8 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)lVar4;
      uStack_d0 = uVar1;
      local_98 = lVar4;
      uStack_90 = uVar1;
      if (*(ulonglong *)(param_1 + 0x38) < uVar2) {
        _invalid_parameter_noinfo();
      }
      lVar3 = *(longlong *)(param_1 + 0x18);
      local_c8._0_4_ = (undefined4)lVar3;
      local_c8._4_4_ = (undefined4)((ulonglong)lVar3 >> 0x20);
      uStack_c0._0_4_ = (undefined4)uVar2;
      uStack_c0._4_4_ = (undefined4)(uVar2 >> 0x20);
      local_a8 = (undefined4)local_c8;
      uStack_a4 = local_c8._4_4_;
      uStack_a0 = (undefined4)uStack_c0;
      uStack_9c = uStack_c0._4_4_;
      local_c8 = lVar3;
      uStack_c0 = uVar2;
      if ((lVar4 == 0) || (lVar4 != lVar3)) {
        _invalid_parameter_noinfo();
      }
      FUN_14036d870(uVar2,uVar1,(longlong)(uVar1 - uVar2) >> 3,0);
    }
    break;
  default:
    local_f0 = 0xae;
    local_f8 = 
    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\auction\\auctionsearchservice.cpp"
    ;
    log_InlineLogERROR("CAuctionSearchService::ProcessMsg() idPacket:%u,nType:%d,nFrom:%d at %s,%d",
                       param_2,param_4 & 0xffffffff,(ulonglong)param_5);
    break;
  case 0x16380:
    lVar4 = FUN_140008520(0xe);
    if (*(longlong *)(lVar4 + 0x210) == 0) {
      local_f8 = (char *)CONCAT44(local_f8._4_4_,0x165);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pRecPoolMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    else {
      lVar4 = *(longlong *)(lVar4 + 0x210);
      if (lVar4 != 0) {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_60,param_3);
        local_d8 = local_88;
        uVar5 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                basic_string<char,std::char_traits<char>,std::allocator<char>_>
                          (local_88,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                                     *)local_60);
        FUN_14028d7f0(lVar4,uVar5,1);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_60);
      }
    }
  }
  return 1;
}

