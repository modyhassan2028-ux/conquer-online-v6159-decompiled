// ==== CMsgStrCheckKey::ctor_or_dtor  @140370520  [high:vtable-assign]  (orig: FUN_140370520)
undefined8 * FUN_140370520(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgStrCheckKey::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgStrCheckKey::ctor_or_dtor  @140370570  [high:vtable-assign]  (orig: FUN_140370570)
void FUN_140370570(undefined8 *param_1)

{
  *param_1 = CMsgStrCheckKey::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgStrCheckKey::vfunc_1  @1403705a0  [high:rtti-vtable]  (orig: FUN_1403705a0)
ulonglong FUN_1403705a0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9d8);
}

// ==== CMsgStrCheckKey::vfunc_3  @1403706c0  [high:rtti-vtable]  (orig: FUN_1403706c0)
void FUN_1403706c0(void)

{
  return;
}

// ==== CMsgStrCheckKey::ctor_or_dtor  @1403706d0  [high:vtable-assign]  (orig: FUN_1403706d0)
undefined8 * FUN_1403706d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgStrCheckKey::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

