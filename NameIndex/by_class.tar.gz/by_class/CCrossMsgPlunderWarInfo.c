// ==== CCrossMsgPlunderWarInfo::ctor_or_dtor  @14045c3a0  [high:vtable-assign]  (orig: FUN_14045c3a0)
undefined8 * FUN_14045c3a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgPlunderWarInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgPlunderWarInfo::ctor_or_dtor  @14045c3f0  [high:vtable-assign]  (orig: FUN_14045c3f0)
void FUN_14045c3f0(undefined8 *param_1)

{
  *param_1 = CCrossMsgPlunderWarInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgPlunderWarInfo::vfunc_1  @14045c420  [high:rtti-vtable]  (orig: FUN_14045c420)
ulonglong FUN_14045c420(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c69);
}

// ==== CCrossMsgPlunderWarInfo::vfunc_3  @14045c510  [high:rtti-vtable]  (orig: FUN_14045c510)
void FUN_14045c510(longlong param_1)

{
  short sVar1;
  short *psVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)FUN_140087ed0();
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  psVar2 = *(short **)(param_1 + 0x428);
  sVar1 = *psVar2;
  if ((sVar1 == 0) || (sVar1 == 2)) {
                    /* WARNING: Could not recover jumptable at 0x00014045c60e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar3 + 0x670))(plVar3,*(undefined4 *)(psVar2 + 2),(char)psVar2[6],psVar2 + 8);
    return;
  }
  if (sVar1 == 3) {
                    /* WARNING: Could not recover jumptable at 0x00014045c5f0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar3 + 0x678))(plVar3);
    return;
  }
  if (sVar1 != 0xb) {
    if (sVar1 != 0xc) {
                    /* WARNING: Could not recover jumptable at 0x00014045c58e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CCrossMsgPlunderWarInfo::Process wrong action[%u]");
      return;
    }
    (**(code **)(*plVar3 + 0x6e0))
              (plVar3,*(undefined4 *)(psVar2 + 2),(char)psVar2[6],psVar2 + 8,
               *(int *)(psVar2 + 4) != 0,*(int *)(psVar2 + 4));
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014045c5de. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar3 + 0x6e8))(plVar3,*(undefined4 *)(psVar2 + 2),(char)psVar2[6],psVar2 + 8);
  return;
}

// ==== CCrossMsgPlunderWarInfo::ctor_or_dtor  @14045c620  [high:vtable-assign]  (orig: FUN_14045c620)
undefined8 * FUN_14045c620(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgPlunderWarInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

