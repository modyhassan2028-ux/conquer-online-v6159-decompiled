// ==== CSocketKernel::helper_14004c640  @14004c640  [medium:callgraph-r0]  (orig: FUN_14004c640)
void FUN_14004c640(longlong param_1)

{
  undefined4 local_res8 [8];
  
  local_res8[0] = 0;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0xe,0x2736,4,local_res8);
  return;
}

// ==== CSocketKernel::helper_14004c680  @14004c680  [medium:callgraph-r1]  (orig: FUN_14004c680)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14004c680(longlong param_1,char param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418[0] = '\0';
  if (param_2 == '\0') {
    memset(local_418 + 1,0,0x3ff);
    pcVar3 = "Intermediary server connection broken.";
  }
  else {
    memset(local_418 + 1,0,0x3ff);
    pcVar3 = "Connect to intermediary server OK.";
  }
  _snprintf(local_418,0x3ff,pcVar3);
  lVar2 = -1;
  local_19 = 0;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CSocketKernel::helper_14004c7d0  @14004c7d0  [medium:callgraph-r0]  (orig: FUN_14004c7d0)
void FUN_14004c7d0(longlong param_1,char param_2)

{
  char *pcVar1;
  
  pcVar1 = (char *)(param_1 + 0x50);
  if ((*pcVar1 != param_2) || (*(char *)(param_1 + 0x51) == '\0')) {
    *pcVar1 = param_2;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0xe,0x2737,1,pcVar1);
    FUN_14004c680(param_1,param_2);
    *(undefined1 *)(param_1 + 0x51) = 1;
  }
  return;
}

// ==== CSocketKernel::helper_14004c950  @14004c950  [medium:callgraph-r0]  (orig: FUN_14004c950)
void FUN_14004c950(longlong param_1,short *param_2,int param_3)

{
  ushort uVar1;
  short sVar2;
  short sVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  char cVar6;
  int iVar7;
  short *_Str1;
  short sVar8;
  char local_res10 [8];
  undefined4 local_res20 [2];
  CTickAnalyst local_40 [24];
  
  if (param_2 == (short *)0x0) {
    return;
  }
  if (param_3 < 1) {
    return;
  }
  CTickAnalyst::CTickAnalyst(local_40,0x2e);
  if ((((param_3 < 0x11) || (uVar1 = param_2[6], param_3 < (int)(uint)uVar1)) || (uVar1 < 0x10)) ||
     (0x418 < uVar1)) {
LAB_14004cb26:
    CTickAnalyst::~CTickAnalyst(local_40);
    return;
  }
  uVar4 = *(undefined4 *)(param_2 + 2);
  uVar5 = *(undefined4 *)(param_2 + 4);
  sVar2 = *param_2;
  sVar8 = param_2[6] + -0x10;
  sVar3 = param_2[7];
  _Str1 = param_2 + 8;
  if (param_2[6] == 0) goto LAB_14004cb26;
  if (sVar3 == -0x63b1) {
    if (sVar2 == 1) {
      iVar7 = strncmp((char *)_Str1,(char *)(param_1 + 0x52),0x10);
      if (iVar7 == 0) {
        FUN_14004c7d0(param_1,1);
      }
      goto LAB_14004cb19;
    }
  }
  else if ((sVar3 == -0x63a8) && ((sVar2 == 1 || (sVar2 == 4)))) {
    local_res20[0] = 0xffffffff;
    local_res10[0] = '\0';
    cVar6 = FUN_1400f80b0(local_res20,local_res10,_Str1);
    if (cVar6 == '\0') goto LAB_14004cb19;
    if (local_res10[0] == '\x01') {
LAB_14004cabd:
      FUN_140052800(*(undefined8 *)(param_1 + 0x48),uVar4,local_res20[0]);
    }
    else {
      if (local_res10[0] != '\x02') {
        if (local_res10[0] != '\x03') {
          CTickAnalyst::~CTickAnalyst(local_40);
          return;
        }
        goto LAB_14004cabd;
      }
      FUN_140052800(*(undefined8 *)(param_1 + 0x48),uVar4,0);
    }
    FUN_140052b30(*(undefined8 *)(param_1 + 0x48),sVar2,uVar4,uVar5,0x9c58,sVar8,_Str1);
    goto LAB_14004cb19;
  }
  FUN_140052b30(*(undefined8 *)(param_1 + 0x48),sVar2,uVar4,uVar5,sVar3,sVar8,_Str1);
LAB_14004cb19:
  CTickAnalyst::~CTickAnalyst(local_40);
  return;
}

// ==== CSocketKernel::helper_14004cde0  @14004cde0  [medium:callgraph-r2]  (orig: FUN_14004cde0)
void FUN_14004cde0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x25) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CSocketKernel::helper_14004d170  @14004d170  [medium:callgraph-r2]  (orig: FUN_14004d170)
void FUN_14004d170(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x25) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x25) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x25);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x25);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x25);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x25);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014004d194. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CSocketKernel::helper_14004daf0  @14004daf0  [medium:callgraph-r2]  (orig: FUN_14004daf0)
void FUN_14004daf0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x25) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CSocketKernel::helper_14004e460  @14004e460  [medium:callgraph-r2]  (orig: FUN_14004e460)
void FUN_14004e460(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14004e460(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x25);
  }
  return;
}

// ==== CSocketKernel::helper_14004ec50  @14004ec50  [medium:callgraph-r1]  (orig: FUN_14004ec50)
void FUN_14004ec50(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14004e460(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CSocketKernel::helper_14004f680  @14004f680  [medium:callgraph-r2]  (orig: FUN_14004f680)
undefined8 * FUN_14004f680(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x25) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x25) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x25) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x25) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x25) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x25) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CSocketKernel::helper_14004f7a0  @14004f7a0  [medium:callgraph-r3]  (orig: FUN_14004f7a0)
undefined8 *
FUN_14004f7a0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x1555555555555553 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14004e760(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x24);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x24) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x24) = 1;
        *(undefined1 *)(lVar4 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x25) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x25) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x24) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x24) = 1;
        *(undefined1 *)(lVar4 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x25) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x25) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x24);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x24) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CSocketKernel::helper_140050990  @140050990  [medium:callgraph-r3]  (orig: FUN_140050990)
longlong * FUN_140050990(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x25) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x25) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_140050aed:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140050b1c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x25) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x25) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x25);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x25);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x25);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x25) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140050aed;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14004f7a0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140050b1c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CSocketKernel::helper_140050ff0  @140050ff0  [medium:callgraph-r1]  (orig: FUN_140050ff0)
undefined8 * FUN_140050ff0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x25) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14004d170(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x25) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x24);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x24);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_1400511dc;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x25);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x25);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_1400511dc:
  if (*(char *)((longlong)plVar5 + 0x24) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x24) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_14004daf0(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(*plVar11 + 0x24) != '\x01') || (*(char *)(plVar11[2] + 0x24) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x24) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_14004cde0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(plVar11[2] + 0x24) = 1;
              FUN_14004daf0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_14004cde0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(plVar11[2] + 0x24) != '\x01') || (*(char *)(*plVar11 + 0x24) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x24) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_14004daf0(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(*plVar11 + 0x24) = 1;
              FUN_14004cde0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x24) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CSocketKernel::helper_140051c90  @140051c90  [medium:callgraph-r2]  (orig: FUN_140051c90)
undefined8 * FUN_140051c90(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14004f7a0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14004f7a0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14004f7a0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x25) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x25);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x25);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x25);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x25) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x25) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x25) != '\0') {
              FUN_14004f7a0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14004f7a0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x25) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x25);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x25);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x25);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x25) != '\0') {
              FUN_14004f7a0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14004f7a0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_140050990(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CSocketKernel::helper_1400521d0  @1400521d0  [medium:callgraph-r2]  (orig: FUN_1400521d0)
undefined8 * FUN_1400521d0(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14004fc20(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14004fc20(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14004fc20(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x25) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x25);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x25);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x25);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x25) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x25) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x25) != '\0') {
              FUN_14004fc20(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14004fc20(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x25) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x25);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x25);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x25);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x25) != '\0') {
              FUN_14004fc20(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14004fc20(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_140050b40(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CSocketKernel::helper_140052800  @140052800  [medium:callgraph-r1]  (orig: FUN_140052800)
void FUN_140052800(longlong param_1,uint param_2,undefined4 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x25);
  puVar3 = *(undefined8 **)(param_1 + 0x88);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x25);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x88);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x58) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x88);
    local_28 = *(longlong *)(param_1 + 0x58);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x88);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)(lVar4 + 0x20) = param_3;
  }
  return;
}

// ==== CSocketKernel::helper_140052a20  @140052a20  [medium:callgraph-r1]  (orig: FUN_140052a20)
undefined4 FUN_140052a20(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x25);
  puVar3 = *(undefined8 **)(param_1 + 0x88);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x25);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x88);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x58) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x88);
    local_28 = *(longlong *)(param_1 + 0x58);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x88);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0xffffffff;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CSocketKernel::helper_140052b30  @140052b30  [medium:callgraph-r1]  (orig: FUN_140052b30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140052b30(longlong param_1,short param_2,uint param_3,undefined4 param_4,ushort param_5,
             ushort param_6,void *param_7)

{
  longlong lVar1;
  char cVar2;
  undefined8 uVar3;
  uint uVar4;
  ulonglong uVar5;
  undefined1 auStack_4a8 [32];
  uint *local_488;
  int local_478;
  int local_474 [3];
  uint local_468;
  uint local_464;
  uint local_460;
  uint local_45c;
  uint local_458;
  undefined1 local_454 [1036];
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  uVar5 = (ulonglong)param_3;
  if (param_7 == (void *)0x0) {
    log_InlineLogERROR("Null msg point found. %s, %d");
    return 0;
  }
  local_468 = param_3;
  local_464 = param_4;
  switch(param_2) {
  case 0:
  case 3:
    local_468 = FUN_140052a20(param_1,uVar5);
    if (local_468 != 0xffffffff) {
      local_460 = (uint)param_6;
      local_464 = (uint)param_5;
      memcpy(&local_45c,param_7,(ulonglong)param_6);
      local_488 = &local_468;
      (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),1,0x7533,0x418)
      ;
      return 1;
    }
    goto LAB_140053015;
  case 1:
    local_458 = (uint)param_6;
    local_460 = (uint)param_5;
    memcpy(local_454,param_7,(ulonglong)param_6);
    local_488 = &local_468;
    (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),0xe,0x2733,0x418)
    ;
    uVar3 = 1;
    break;
  case 2:
    local_464 = (uint)param_5;
    local_460 = (uint)param_6;
    memcpy(&local_45c,param_7,(ulonglong)param_6);
    uVar4 = 0;
    if (local_468 != 0) {
      do {
        local_478 = 0;
        lVar1 = (uVar4 - uVar5) * 4 + 0xc;
        memmove(&local_478,(void *)((longlong)&local_45c + (int)local_460 + lVar1 + -0xc),4);
        local_474[0] = FUN_140052a20(param_1,local_478);
        if (local_474[0] != -1) {
          memmove((void *)((longlong)&local_45c + (int)local_460 + lVar1 + -0xc),local_474,4);
        }
        uVar4 = uVar4 + 1;
      } while (uVar4 < local_468);
    }
    local_488 = &local_468;
    local_460 = (uint)param_6 + param_3 * -4;
    (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),1,0x753e,0x418);
    uVar3 = 1;
    break;
  case 4:
  case 10:
    local_458 = (uint)param_6;
    local_460 = 4200000000;
    local_45c = (uint)param_5;
    memcpy(local_454,param_7,(ulonglong)param_6);
    local_488 = &local_468;
    (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),0xe,0x3fd);
    uVar3 = 1;
    break;
  case 5:
    if (param_3 != 0xffffffff) {
      local_460 = (uint)param_6;
      local_464 = (uint)param_5;
      memcpy(&local_45c,param_7,(ulonglong)param_6);
      local_488 = &local_468;
      (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),1,0x7533,0x418)
      ;
      return 1;
    }
    goto LAB_140053015;
  case 6:
    local_464 = (uint)param_5;
    local_460 = (uint)param_6;
    memcpy(&local_45c,param_7,(ulonglong)param_6);
    uVar4 = 0;
    if (local_468 != 0) {
      do {
        local_478 = -1;
        lVar1 = (uVar4 - uVar5) * 4 + 0xc;
        memmove(&local_478,(void *)((longlong)&local_45c + (int)local_460 + lVar1 + -0xc),4);
        if (local_478 != -1) {
          memmove((void *)((longlong)&local_45c + (int)local_460 + lVar1 + -0xc),&local_478,4);
        }
        uVar4 = uVar4 + 1;
      } while (uVar4 < local_468);
    }
    local_488 = &local_468;
    local_460 = (uint)param_6 + param_3 * -4;
    (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),1,0x753e,0x418);
    uVar3 = 1;
    break;
  case 7:
  case 8:
    if (((param_2 == 7) && (param_5 == 0x3f1)) && (cVar2 = FUN_1400f87c0(param_7), cVar2 != '\0')) {
      local_458 = (uint)param_6;
      local_45c = 3;
      local_460 = 0x3f1;
      memcpy(local_454,param_7,(ulonglong)param_6);
      local_488 = &local_468;
      (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),6,0x3fc,0x418);
      uVar3 = 1;
    }
    else {
      local_458 = (uint)param_6;
      local_460 = 4200000000;
      local_45c = (uint)param_5;
      memcpy(local_454,param_7,(ulonglong)param_6);
      local_488 = &local_468;
      (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),0xe,0x3fe);
      uVar3 = 1;
    }
    break;
  default:
    log_InlineLogERROR("CCrossKernel::ProcessNetMsg illegal packet type, type:%u, %s, %d");
LAB_140053015:
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CSocketKernel::helper_140053070  @140053070  [medium:callgraph-r0]  (orig: FUN_140053070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140053070(longlong param_1,int param_2)

{
  longlong *plVar1;
  char cVar2;
  uint uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  undefined8 *puVar13;
  longlong lVar14;
  undefined1 auStack_518 [32];
  undefined4 *local_4f8;
  uint local_4e8 [4];
  longlong *local_4d8;
  longlong *plStack_4d0;
  longlong local_4c8;
  longlong local_4c0;
  undefined8 local_4b8;
  longlong local_4b0;
  undefined8 *local_4a8;
  longlong local_4a0;
  longlong local_498;
  longlong *local_488;
  longlong *plStack_480;
  undefined1 local_478 [16];
  undefined4 local_468;
  int local_464;
  uint auStack_460 [262];
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  if (*(longlong *)(param_1 + 0x90) != 0) {
    local_4c8 = param_1;
    memset((void *)((longlong)&local_468 + 1),0,0x417);
    plVar4 = *(longlong **)(param_1 + 0x58);
    plVar1 = (longlong *)(param_1 + 0x58);
    local_464 = 0;
    local_468 = (param_2 != 0) + 1;
    plVar11 = (longlong *)**(longlong **)(param_1 + 0x88);
    lVar12 = param_1;
    local_4d8 = plVar4;
    plStack_4d0 = plVar11;
    while( true ) {
      plVar5 = *(longlong **)(param_1 + 0x88);
      if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar11 == plVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar14 = 0;
      }
      else {
        lVar14 = *plVar4;
      }
      if (plVar11 == *(longlong **)(lVar14 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar3 = *(uint *)((longlong)plVar11 + 0x1c);
      local_4e8[0] = uVar3;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar14 = 0;
      }
      else {
        lVar14 = *plVar4;
      }
      if (plVar11 == *(longlong **)(lVar14 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if ((param_2 == 0) || (param_2 == (int)plVar11[4])) {
        if (0x418 < (longlong)local_464 * 4 + 0xcU) {
          local_4f8 = &local_468;
          (**(code **)(**(longlong **)(lVar12 + 8) + 0x50))
                    (*(longlong **)(lVar12 + 8),0xe,0x2735,0x418);
          local_464 = 0;
        }
        plVar10 = plStack_4d0;
        plVar5 = local_4d8;
        auStack_460[local_464] = uVar3;
        local_464 = local_464 + 1;
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
          plVar6 = (longlong *)plVar11[2];
          if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
            cVar2 = *(char *)(*plVar6 + 0x25);
            plVar11 = plVar6;
            plVar6 = (longlong *)*plVar6;
            while (plStack_4d0 = plVar11, cVar2 == '\0') {
              cVar2 = *(char *)(*plVar6 + 0x25);
              plVar11 = plVar6;
              plVar6 = (longlong *)*plVar6;
            }
          }
          else {
            cVar2 = *(char *)(plVar11[1] + 0x25);
            plVar8 = (longlong *)plVar11[1];
            plVar6 = plVar11;
            while ((plVar11 = plVar8, plStack_4d0 = plVar11, cVar2 == '\0' &&
                   (plVar6 == (longlong *)plVar11[2]))) {
              cVar2 = *(char *)(plVar11[1] + 0x25);
              plVar8 = (longlong *)plVar11[1];
              plVar6 = plVar11;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_488 = plVar5;
        plStack_480 = plVar10;
        FUN_140050ff0(plVar1,local_478,&local_488);
        puVar13 = (undefined8 *)(*(undefined8 **)(lVar12 + 0x48))[1];
        plVar5 = (longlong *)(lVar12 + 0x18);
        cVar2 = *(char *)((longlong)puVar13 + 0x21);
        puVar7 = *(undefined8 **)(lVar12 + 0x48);
        while (cVar2 == '\0') {
          if (*(uint *)(puVar13 + 3) < uVar3) {
            puVar9 = (undefined8 *)puVar13[2];
            puVar13 = puVar7;
          }
          else {
            puVar9 = (undefined8 *)*puVar13;
          }
          puVar7 = puVar13;
          puVar13 = puVar9;
          cVar2 = *(char *)((longlong)puVar9 + 0x21);
        }
        puVar13 = *(undefined8 **)(lVar12 + 0x48);
        local_4a8 = puVar7;
        local_4b0 = *plVar5;
        if (*plVar5 == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar7 == puVar13) || (uVar3 < *(uint *)(puVar7 + 3))) {
          plVar10 = &local_4c0;
          local_4b8 = *(undefined8 *)(lVar12 + 0x48);
          local_4c0 = *plVar5;
        }
        else {
          plVar10 = &local_4b0;
        }
        local_4a0 = *plVar10;
        lVar14 = *(longlong *)(lVar12 + 0x48);
        local_498 = plVar10[1];
        if ((local_4a0 == 0) || (local_4a0 != *plVar5)) {
          _invalid_parameter_noinfo();
        }
        lVar12 = local_4c8;
        if (local_498 != lVar14) {
          FUN_140050de0(plVar5,local_4e8);
        }
      }
      else {
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
          plVar5 = (longlong *)plVar11[2];
          if (*(char *)((longlong)plVar5 + 0x25) == '\0') {
            cVar2 = *(char *)(*plVar5 + 0x25);
            plVar11 = plVar5;
            plVar5 = (longlong *)*plVar5;
            while (plStack_4d0 = plVar11, cVar2 == '\0') {
              cVar2 = *(char *)(*plVar5 + 0x25);
              plVar11 = plVar5;
              plVar5 = (longlong *)*plVar5;
            }
          }
          else {
            cVar2 = *(char *)(plVar11[1] + 0x25);
            plVar10 = (longlong *)plVar11[1];
            plVar5 = plVar11;
            while ((plVar11 = plVar10, plStack_4d0 = plVar11, cVar2 == '\0' &&
                   (plVar5 == (longlong *)plVar11[2]))) {
              cVar2 = *(char *)(plVar11[1] + 0x25);
              plVar10 = (longlong *)plVar11[1];
              plVar5 = plVar11;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
    if (0 < local_464) {
      local_4f8 = &local_468;
      (**(code **)(**(longlong **)(lVar12 + 8) + 0x50))(*(longlong **)(lVar12 + 8),0xe,0x2735,0x418)
      ;
    }
    if (param_2 == 0) {
      FUN_14004ec50(plVar1);
      FUN_14004ebd0(lVar12 + 0x18);
    }
  }
  return;
}

// ==== CSocketKernel::helper_140053590  @140053590  [medium:callgraph-r1]  (orig: FUN_140053590)
longlong FUN_140053590(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  uint local_58;
  undefined8 local_54;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x25) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x25) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  local_48 = plVar5;
  uStack_40 = puVar4;
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_58 = *param_2;
    local_54 = 0xffffffffffffffff;
    local_38 = (undefined4)local_48;
    uStack_34 = local_48._4_4_;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    plVar3 = (longlong *)FUN_140051c90(param_1,local_28,&local_38,&local_58);
    plVar5 = (longlong *)*plVar3;
    puVar4 = (undefined8 *)plVar3[1];
    local_48 = plVar5;
    uStack_40 = puVar4;
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar5;
  }
  if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar4 + 0x1c;
}

// ==== CSocketKernel::helper_1400536e0  @1400536e0  [medium:callgraph-r1]  (orig: FUN_1400536e0)
longlong FUN_1400536e0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14004f680(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x25) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x25);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x25);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x25);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x25);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140051fb0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CSocketKernel::helper_140053820  @140053820  [medium:callgraph-r1]  (orig: FUN_140053820)
longlong FUN_140053820(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  longlong *plVar6;
  uint local_58;
  undefined8 local_54;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x25) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x25) == '\0');
  }
  plVar6 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  local_48 = plVar6;
  uStack_40 = puVar4;
  if (plVar6 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar5 = 0;
  if ((puVar4 == puVar1) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_58 = *param_2;
    local_54 = 0;
    local_38 = (undefined4)local_48;
    uStack_34 = local_48._4_4_;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    plVar3 = (longlong *)FUN_1400521d0(param_1,local_28,&local_38,&local_58);
    plVar6 = (longlong *)*plVar3;
    puVar4 = (undefined8 *)plVar3[1];
    local_48 = plVar6;
    uStack_40 = puVar4;
  }
  if (plVar6 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar5 = *plVar6;
  }
  if (puVar4 == *(undefined8 **)(lVar5 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar4 + 0x1c;
}

// ==== CSocketKernel::helper_140053cc0  @140053cc0  [medium:callgraph-r0]  (orig: FUN_140053cc0)
undefined1 FUN_140053cc0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined8 *puVar2;
  undefined4 local_res10 [2];
  undefined4 local_res18 [2];
  
  local_res10[0] = param_2;
  local_res18[0] = param_3;
  puVar1 = (undefined4 *)FUN_140053460(param_1 + 0x18,local_res18);
  *puVar1 = param_2;
  puVar2 = (undefined8 *)FUN_140053590(param_1 + 0x58,local_res10);
  *puVar2 = CONCAT44(param_4,param_3);
  return 1;
}

// ==== CSocketKernel::helper_140053d20  @140053d20  [medium:callgraph-r0]  (orig: FUN_140053d20)
void FUN_140053d20(longlong param_1,uint param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  ulong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined4 local_res8;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x25);
  puVar3 = *(undefined8 **)(param_1 + 0x88);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x25);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x88);
  local_40 = puVar3;
  local_48 = *(longlong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x58) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar8 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x88);
    local_38 = *(longlong *)(param_1 + 0x58);
  }
  else {
    plVar8 = &local_48;
  }
  plVar2 = (longlong *)*plVar8;
  lVar9 = *(longlong *)(param_1 + 0x88);
  local_28 = plVar2;
  local_20 = plVar8[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_20;
  if (local_20 != lVar9) {
    local_res8 = 0xf;
    if (param_3 != 4) {
      local_res8 = 5;
    }
    uVar5 = tq::TimeGet(0);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar7 = (undefined8 *)FUN_140053820(param_1 + 0x98,lVar4 + 0x1c);
    *puVar7 = CONCAT44(uVar5 / 1000,local_res8);
  }
  return;
}

// ==== CSocketKernel::helper_140054040  @140054040  [medium:callgraph-r0]  (orig: FUN_140054040)
undefined8 FUN_140054040(longlong param_1,uint param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  int local_res8 [2];
  uint local_res10 [2];
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  longlong local_20;
  
  local_res10[0] = param_2;
  iVar5 = FUN_140052a20();
  local_res8[0] = iVar5;
  if (iVar5 != -1) {
    FUN_140050de0(param_1 + 0x18,local_res8);
    local_res8[0] = iVar5;
    FUN_140053970(param_1 + 0x98,local_res8);
  }
  plVar1 = (longlong *)(param_1 + 0x58);
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar2 = *(char *)((longlong)puVar8 + 0x25);
  puVar4 = *(undefined8 **)(param_1 + 0x88);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar4 = puVar8;
    puVar8 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x25);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x88);
  local_40 = puVar4;
  local_48 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar8) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar7 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x88);
    local_38 = *plVar1;
  }
  else {
    plVar7 = &local_48;
  }
  local_28 = *plVar7;
  lVar3 = *(longlong *)(param_1 + 0x88);
  local_20 = plVar7[1];
  if ((local_28 == 0) || (local_28 != *plVar1)) {
    _invalid_parameter_noinfo();
  }
  if (local_20 != lVar3) {
    FUN_1400536e0(plVar1,local_res10);
  }
  return 1;
}

// ==== CSocketKernel::ProcessMsg  @140054380  [high:log-string]  (orig: FUN_140054380)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140054380(longlong param_1,uint param_2,uint *param_3)

{
  uint uVar1;
  undefined8 uVar2;
  int iVar3;
  uint *puVar4;
  short sVar5;
  undefined1 auStack_518 [32];
  uint *local_4f8;
  uint local_4e8;
  uint local_4e4;
  undefined4 local_4e0;
  undefined8 local_4d8;
  char local_4c8 [127];
  undefined1 local_449;
  undefined2 local_448 [2];
  uint local_444;
  uint local_440;
  short local_43c;
  undefined2 local_43a;
  undefined1 local_438 [1040];
  ulonglong local_28;
  
  local_4d8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  if (param_3 == (uint *)0x0) {
    log_InlineLogERROR("CCrossKernel::ProcessLocalMsg buf is null");
    uVar2 = 0;
  }
  else {
    if (param_2 < 0x11172) {
      if (param_2 == 0x11171) {
        local_4e0 = 0xffffffff;
        local_4e4 = 0;
        local_4e8 = 0xffffffff;
        local_4f8 = &local_4e8;
        iVar3 = sscanf((char *)param_3,"%d %u %u");
        if (iVar3 == 3) {
          FUN_140053cc0(param_1,local_4e4,local_4e0,local_4e8);
          memset(local_4c8,0,0x80);
          local_4f8 = (uint *)CONCAT44(local_4f8._4_4_,local_4e0);
          _snprintf(local_4c8,0x7f,"%u %u");
          local_449 = 0;
          local_4f8 = (uint *)local_4c8;
          (**(code **)(**(longlong **)(param_1 + 8) + 0x50))
                    (*(longlong **)(param_1 + 8),0xe,0x2738,0x80);
        }
        else {
          log_InlineLogERROR(
                            "CSocketKernel::ProcessMsg(CROSS_SERVER_ADD_USER_SOCKET) invalid param."
                            );
        }
      }
      else if (param_2 == 0x3f0) {
        iVar3 = 0;
        if (0 < (int)*param_3) {
          puVar4 = param_3 + 2;
          do {
            if (*puVar4 != 0) {
              FUN_140053d20(param_1,*puVar4,param_3[1]);
            }
            iVar3 = iVar3 + 1;
            puVar4 = puVar4 + 1;
          } while (iVar3 < (int)*param_3);
        }
      }
      else if (param_2 == 0x3f1) {
        FUN_140053070(param_1,*param_3);
      }
      else if (param_2 == 0x3fc) {
        local_444 = *param_3;
        local_440 = param_3[1];
        local_4e4 = param_3[2];
        local_4e8 = param_3[3];
        iVar3 = param_3[4] + 0x10;
        if (iVar3 < 0x419) {
          local_448[0] = (undefined2)local_4e8;
          local_43a = (undefined2)local_4e4;
          local_43c = (short)iVar3;
          memcpy(local_438,param_3 + 5,(longlong)(int)param_3[4]);
          if (local_43c != 0) {
            (**(code **)(**(longlong **)(param_1 + 0x10) + 0x28))
                      (*(longlong **)(param_1 + 0x10),local_448);
          }
        }
      }
      else if (param_2 == 0x3ff) {
        uVar1 = *param_3;
        iVar3 = param_3[4] + 0x10 + uVar1 * 4;
        if (iVar3 < 0x419) {
          local_43c = (short)iVar3;
          local_448[0] = (short)param_3[3];
          local_444 = uVar1;
          local_440 = param_3[1];
          local_43a = (short)param_3[2];
          memcpy(local_438,param_3 + 5,(longlong)(int)param_3[4] + (ulonglong)uVar1 * 4);
          sVar5 = local_43c;
        }
        else {
          sVar5 = 0;
        }
        if (sVar5 != 0) {
          (**(code **)(**(longlong **)(param_1 + 0x10) + 0x28))
                    (*(longlong **)(param_1 + 0x10),local_448,sVar5);
        }
      }
    }
    else if (param_2 == 0x11172) {
      local_4e8 = 0;
      iVar3 = sscanf((char *)param_3,"%u");
      if (iVar3 == 1) {
        FUN_140054040(param_1,local_4e8);
      }
      else {
        log_InlineLogERROR("CSocketKernel::ProcessMsg(CROSS_SERVER_DEL_USER_SOCKET) invalid param.")
        ;
      }
    }
    else if (param_2 == 0x11173) {
      if (*param_3 == 1) {
        FUN_14004c640(*(undefined8 *)(param_1 + 0x10));
      }
      else {
        FUN_14004c7d0(*(undefined8 *)(param_1 + 0x10),0);
      }
    }
    else if (param_2 == 0x11174) {
      FUN_14004c950(*(undefined8 *)(param_1 + 0x10),param_3 + 1,*param_3);
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CSocketKernel::helper_140077480  @140077480  [medium:callgraph-r0]  (orig: FUN_140077480)
longlong * FUN_140077480(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x1d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x1d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CSocketKernel::helper_1400f80b0  @1400f80b0  [medium:callgraph-r1]  (orig: FUN_1400f80b0)
ulonglong FUN_1400f80b0(undefined4 *param_1,undefined1 *param_2,undefined1 *param_3)

{
  ulonglong extraout_RAX;
  
  if (param_3 == (undefined1 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  *param_1 = *(undefined4 *)(param_3 + 4);
  *param_2 = *param_3;
  return 1;
}

// ==== CSocketKernel::helper_1400f87c0  @1400f87c0  [medium:callgraph-r2]  (orig: FUN_1400f87c0)
ulonglong FUN_1400f87c0(longlong param_1)

{
  ulonglong extraout_RAX;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  return (ulonglong)(*(short *)(param_1 + 0x10) == 0x1b);
}

// ==== CSocketKernel::helper_1400f8810  @1400f8810  [medium:callgraph-r2]  (orig: FUN_1400f8810)
void FUN_1400f8810(longlong param_1)

{
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 8) = 1;
  }
  return;
}

// ==== CSocketKernel::helper_1404f6c90  @1404f6c90  [medium:callgraph-r1]  (orig: FUN_1404f6c90)
ulonglong FUN_1404f6c90(ushort *param_1,int param_2,uint *param_3,longlong *param_4,int *param_5,
                       char param_6)

{
  ushort uVar1;
  int iVar2;
  uint uVar3;
  
  if (4 < param_2) {
    uVar1 = *param_1;
    uVar3 = -(uint)(param_6 != '\0') & 8;
    if ((uVar1 < 4) || (0x400 < uVar1)) {
      return 0xffffffff;
    }
    if ((int)(uVar1 + uVar3) <= param_2) {
      *param_3 = (uint)param_1[1];
      *param_5 = *param_1 - 4;
      *param_4 = (longlong)(param_1 + 2);
      if ((param_6 != '\0') &&
         (iVar2 = memcmp((void *)((ulonglong)*param_1 + (longlong)param_1),"TQClient",
                         (longlong)(int)uVar3), iVar2 != 0)) {
        return 0xffffffff;
      }
      return (ulonglong)*param_1;
    }
  }
  return 0;
}

// ==== CSocketKernel::helper_1404f7160  @1404f7160  [medium:callgraph-r0]  (orig: FUN_1404f7160)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1404f7160(void)

{
  int iVar1;
  ulonglong extraout_RAX;
  char *pcVar2;
  undefined1 auStack_1d8 [32];
  undefined1 local_1b8 [416];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_1d8;
  iVar1 = Ordinal_115(0x202,local_1b8);
  if (iVar1 == 0) {
    if (((char)local_1b8._0_2_ == '\x02') && (SUB21(local_1b8._0_2_,1) == '\x02')) {
      return 1;
    }
    pcVar2 = "ServerSocketInit WSAStartup version is not 2.2";
  }
  else {
    pcVar2 = "ServerSocketInit WSAStartup() failed";
  }
  log_InlineLogERROR(pcVar2);
  return extraout_RAX & 0xffffffffffffff00;
}

// ==== CSocketKernel::vfunc_3  @1404f7280  [high:rtti-vtable]  (orig: FUN_1404f7280)
undefined1 FUN_1404f7280(void)

{
  return 1;
}

// ==== CSocketKernel::helper_1404f72a0  @1404f72a0  [medium:callgraph-r1]  (orig: FUN_1404f72a0)
void FUN_1404f72a0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x178) != 0) {
    FUN_1405426b0();
  }
  return;
}

// ==== CSocketKernel::helper_1404f72e0  @1404f72e0  [medium:callgraph-r1]  (orig: FUN_1404f72e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404f72e0(longlong param_1)

{
  ushort uVar1;
  char cVar2;
  undefined1 auStack_4a8 [32];
  undefined4 *local_488;
  int local_478;
  int local_474;
  uint local_470;
  undefined4 local_46c;
  uint local_468;
  ushort *local_460;
  uint local_458;
  ushort *local_450;
  undefined8 local_448;
  undefined4 local_438;
  uint local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  local_478 = 0;
  local_460 = (ushort *)
              (**(code **)(**(longlong **)(param_1 + 0xd0) + 8))
                        (*(longlong **)(param_1 + 0xd0),&local_478);
  while( true ) {
    if (local_478 < 1) {
      return;
    }
    if (local_478 < 9) {
      return;
    }
    uVar1 = *local_460;
    if (local_478 < (int)(uint)uVar1) {
      return;
    }
    local_468 = (uint)uVar1;
    if (local_468 < 4) break;
    if (0x400 < uVar1) {
      return;
    }
    local_470 = (uint)local_460[1];
    local_474 = uVar1 - 8;
    local_46c = *(undefined4 *)(local_460 + 2);
    local_450 = local_460 + 4;
    if (local_468 == 0) {
      return;
    }
    local_438 = local_46c;
    local_434 = local_470;
    local_430 = local_474;
    memcpy(local_42c,local_450,(longlong)local_474);
    local_488 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))(*(longlong **)(param_1 + 0x88),0xe,0x3ea);
    local_458 = (uint)uVar1;
    cVar2 = (**(code **)(**(longlong **)(param_1 + 0xd0) + 0x10))();
    if (cVar2 == '\0') {
      local_488 = (undefined4 *)CONCAT44(local_488._4_4_,0x7cb);
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    LOCK();
    DAT_140975754 = DAT_140975754 + 1;
    UNLOCK();
    LOCK();
    DAT_1409757a4 = DAT_1409757a4 + 1;
    UNLOCK();
    LOCK();
    DAT_1409757a0 = DAT_1409757a0 + local_474;
    UNLOCK();
    local_460 = (ushort *)
                (**(code **)(**(longlong **)(param_1 + 0xd0) + 8))
                          (*(longlong **)(param_1 + 0xd0),&local_478);
  }
  return;
}

// ==== CSocketKernel::helper_1404f74a0  @1404f74a0  [medium:callgraph-r1]  (orig: FUN_1404f74a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404f74a0(longlong param_1)

{
  ushort uVar1;
  undefined1 auStack_488 [32];
  undefined4 *local_468;
  int local_458;
  int local_454;
  uint local_450;
  ushort *local_448;
  undefined8 local_440;
  undefined4 local_438;
  uint local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_440 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  local_458 = 0;
  local_448 = (ushort *)
              (**(code **)(**(longlong **)(param_1 + 200) + 8))
                        (*(longlong **)(param_1 + 200),&local_458);
  while( true ) {
    if (local_458 < 1) {
      return;
    }
    if (local_458 < 5) {
      return;
    }
    uVar1 = *local_448;
    if (uVar1 < 4) {
      return;
    }
    if (0x400 < uVar1) break;
    if (local_458 < (int)(uint)uVar1) {
      return;
    }
    local_450 = (uint)local_448[1];
    local_454 = uVar1 - 4;
    local_448 = local_448 + 2;
    if (uVar1 == 0) {
      return;
    }
    local_438 = 0x10000;
    local_434 = local_450;
    local_430 = local_454;
    memcpy(local_42c,local_448,(longlong)local_454);
    local_468 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))(*(longlong **)(param_1 + 0x88),0xe,0x3e9);
    (**(code **)(**(longlong **)(param_1 + 200) + 0x10))(*(longlong **)(param_1 + 200),uVar1);
    local_448 = (ushort *)
                (**(code **)(**(longlong **)(param_1 + 200) + 8))
                          (*(longlong **)(param_1 + 200),&local_458);
  }
  return;
}

// ==== CSocketKernel::helper_1404f7600  @1404f7600  [medium:callgraph-r1]  (orig: FUN_1404f7600)
ulonglong FUN_1404f7600(longlong param_1)

{
  ulonglong extraout_RAX;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  return (ulonglong)(*(int *)(param_1 + 4) == 0x3ec);
}

// ==== CSocketKernel::helper_1404f7650  @1404f7650  [medium:callgraph-r1]  (orig: FUN_1404f7650)
ulonglong FUN_1404f7650(longlong param_1)

{
  ulonglong extraout_RAX;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  return (ulonglong)(*(int *)(param_1 + 4) == 0x42b);
}

// ==== CSocketKernel::helper_1404f76a0  @1404f76a0  [medium:callgraph-r1]  (orig: FUN_1404f76a0)
ulonglong FUN_1404f76a0(longlong param_1)

{
  ulonglong extraout_RAX;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  return (ulonglong)(*(int *)(param_1 + 4) == 0x40d);
}

// ==== CSocketKernel::helper_1404f76f0  @1404f76f0  [medium:callgraph-r1]  (orig: FUN_1404f76f0)
undefined1 FUN_1404f76f0(longlong param_1)

{
  undefined1 uVar1;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(int *)(param_1 + 4) == 0x3f1) {
    uVar1 = FUN_1400f87c0(param_1 + 0xc);
    return uVar1;
  }
  return 0;
}

// ==== CSocketKernel::helper_1404f7740  @1404f7740  [medium:callgraph-r1]  (orig: FUN_1404f7740)
void FUN_1404f7740(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (((param_2 != 0) && (*(longlong *)(param_1 + 0x88) != 0)) &&
     (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x88) + 0x10))(), 3000 < iVar1)) {
    FUN_1400f8810(param_2 + 0xc);
  }
  return;
}

// ==== CSocketKernel::helper_1404f78f0  @1404f78f0  [medium:callgraph-r1]  (orig: FUN_1404f78f0)
void FUN_1404f78f0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CSocketKernel::helper_1404f7970  @1404f7970  [medium:callgraph-r1]  (orig: FUN_1404f7970)
void FUN_1404f7970(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404f7994. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CSocketKernel::helper_1404f7d50  @1404f7d50  [medium:callgraph-r3]  (orig: FUN_1404f7d50)
void FUN_1404f7d50(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404f7d74. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CSocketKernel::helper_1404f8110  @1404f8110  [medium:callgraph-r0]  (orig: FUN_1404f8110)
undefined8 FUN_1404f8110(undefined8 param_1)

{
  log_InlineLogMessage("EvnetRoutine worker thread is up and running");
  FUN_1404f72a0(param_1);
  log_InlineLogMessage("EvnetRoutine worker thread exited");
  return 0;
}

// ==== CSocketKernel::helper_1404f8440  @1404f8440  [medium:callgraph-r1]  (orig: FUN_1404f8440)
void FUN_1404f8440(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CSocketKernel::helper_1404f86c0  @1404f86c0  [medium:callgraph-r3]  (orig: FUN_1404f86c0)
void FUN_1404f86c0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CSocketKernel::helper_1404f8720  @1404f8720  [medium:callgraph-r3]  (orig: FUN_1404f8720)
void FUN_1404f8720(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CSocketKernel::helper_1404f8b00  @1404f8b00  [medium:callgraph-r0]  (orig: FUN_1404f8b00)
void FUN_1404f8b00(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404f8b00(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CSocketKernel::helper_1404f8b50  @1404f8b50  [medium:callgraph-r0]  (orig: FUN_1404f8b50)
void FUN_1404f8b50(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404f8b50(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CSocketKernel::helper_1404f8c80  @1404f8c80  [medium:callgraph-r1]  (orig: FUN_1404f8c80)
void FUN_1404f8c80(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CSocketKernel::helper_1404f8ce0  @1404f8ce0  [medium:callgraph-r3]  (orig: FUN_1404f8ce0)
undefined8 *
FUN_1404f8ce0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CSocketKernel::helper_1404f8d60  @1404f8d60  [medium:callgraph-r1]  (orig: FUN_1404f8d60)
void FUN_1404f8d60(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CSocketKernel::helper_1404f8dc0  @1404f8dc0  [medium:callgraph-r3]  (orig: FUN_1404f8dc0)
undefined8 *
FUN_1404f8dc0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CSocketKernel::helper_1404f9080  @1404f9080  [medium:callgraph-r2]  (orig: FUN_1404f9080)
void FUN_1404f9080(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404f8b00(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CSocketKernel::helper_1404f9100  @1404f9100  [medium:callgraph-r2]  (orig: FUN_1404f9100)
void FUN_1404f9100(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1404f8b50(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CSocketKernel::helper_1404f92f0  @1404f92f0  [medium:callgraph-r2]  (orig: FUN_1404f92f0)
undefined8 * FUN_1404f92f0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1404f7d50(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1404f94dc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1404f94dc:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1404f86c0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1404f8720(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1404f86c0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1404f8720(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1404f86c0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1404f8720(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CSocketKernel::helper_1404f97d0  @1404f97d0  [medium:callgraph-r2]  (orig: FUN_1404f97d0)
undefined8 *
FUN_1404f97d0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1404f8ce0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CSocketKernel::helper_1404f9b10  @1404f9b10  [medium:callgraph-r1]  (orig: FUN_1404f9b10)
undefined8 * FUN_1404f9b10(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CSocketKernel::helper_1404f9c30  @1404f9c30  [medium:callgraph-r2]  (orig: FUN_1404f9c30)
undefined8 *
FUN_1404f9c30(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1404f8dc0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CSocketKernel::helper_1404fa310  @1404fa310  [medium:callgraph-r1]  (orig: FUN_1404fa310)
longlong * FUN_1404fa310(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1404f9080(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1404f92f0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CSocketKernel::helper_1404fa520  @1404fa520  [medium:callgraph-r0]  (orig: FUN_1404fa520)
void FUN_1404fa520(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1404fa310((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CSocketKernel::helper_1404fa640  @1404fa640  [medium:callgraph-r2]  (orig: FUN_1404fa640)
longlong * FUN_1404fa640(longlong *param_1,longlong *param_2,longlong *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < (longlong)puVar8[3];
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_1404fa79d:
    local_30 = puVar4;
    if (*param_3 <= (longlong)puVar5[3]) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1404fa7cd;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x29);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1404fa79d;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_1404f97d0(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1404fa7cd:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CSocketKernel::helper_1404fa7f0  @1404fa7f0  [medium:callgraph-r2]  (orig: FUN_1404fa7f0)
longlong * FUN_1404fa7f0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1404fa94d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1404fa97c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1404fa94d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1404f9c30(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1404fa97c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CSocketKernel::vfunc_5  @1404faa60  [high:rtti-vtable]  (orig: FUN_1404faa60)
undefined8 FUN_1404faa60(undefined8 *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  
  (**(code **)(*(longlong *)param_1[0x11] + 0x30))();
  if ((longlong *)param_1[0x1a] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x1a] + 0x28))();
    FUN_140500650(param_1[0x1a]);
    param_1[0x1a] = 0;
  }
  if ((longlong *)param_1[0x19] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0x19] + 0x28))();
    FUN_140500650(param_1[0x19]);
    param_1[0x19] = 0;
  }
  plVar2 = (longlong *)param_1[0x38];
  plVar3 = *(longlong **)param_1[0x3e];
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar3;
          plVar3 = (longlong *)param_1[0x3e];
          if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[0x38])) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar3) {
            cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x3e] + 8) + 0x29);
            plVar2 = *(longlong **)(param_1[0x3e] + 8);
            while (cVar1 == '\0') {
              FUN_1404f8b50(param_1 + 0x38,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x29);
            }
            *(undefined8 *)(param_1[0x3e] + 8) = param_1[0x3e];
            param_1[0x3f] = 0;
            *(undefined8 *)param_1[0x3e] = param_1[0x3e];
            *(undefined8 *)(param_1[0x3e] + 0x10) = param_1[0x3e];
            cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x2d] + 8) + 0x29);
            plVar2 = *(longlong **)(param_1[0x2d] + 8);
            while (cVar1 == '\0') {
              FUN_1404f8b00(param_1 + 0x27,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x29);
            }
            *(undefined8 *)(param_1[0x2d] + 8) = param_1[0x2d];
            param_1[0x2e] = 0;
            *(undefined8 *)param_1[0x2d] = param_1[0x2d];
            *(undefined8 *)(param_1[0x2d] + 0x10) = param_1[0x2d];
            if (((longlong *)param_1[0x1b] != (longlong *)0x0) &&
               ((**(code **)(*(longlong *)param_1[0x1b] + 0x68))(), param_1[0x1b] != 0)) {
              (**(code **)(*(longlong *)param_1[0x1b] + 0x10))();
              param_1[0x1b] = 0;
            }
            if (((longlong *)param_1[0x1c] != (longlong *)0x0) &&
               ((**(code **)(*(longlong *)param_1[0x1c] + 0x68))(), param_1[0x1c] != 0)) {
              (**(code **)(*(longlong *)param_1[0x1c] + 0x10))();
              param_1[0x1c] = 0;
            }
            if (((longlong *)param_1[0x1d] != (longlong *)0x0) &&
               ((**(code **)(*(longlong *)param_1[0x1d] + 0x68))(), param_1[0x1d] != 0)) {
              (**(code **)(*(longlong *)param_1[0x1d] + 0x10))();
              param_1[0x1d] = 0;
            }
            if (((longlong *)param_1[0x1e] != (longlong *)0x0) &&
               ((**(code **)(*(longlong *)param_1[0x1e] + 0x68))(), param_1[0x1e] != 0)) {
              (**(code **)(*(longlong *)param_1[0x1e] + 0x10))();
              param_1[0x1e] = 0;
            }
            (**(code **)(param_1[0x13] + 0x10))();
            (**(code **)(param_1[0x17] + 0x10))();
            (**(code **)(param_1[0x15] + 0x10))();
            iVar4 = FUN_14053ed50(param_1[0x2f]);
            if (iVar4 < 0) {
              log_InlineLogERROR("CSocketKernel::Release, event_base_loopbreak error.");
            }
            CloseHandle((HANDLE)param_1[0x40]);
            FUN_1405412f0(param_1[0x2f]);
            param_1[0x2f] = 0;
            FUN_14053e5d0();
            Ordinal_116();
            (**(code **)*param_1)(param_1,1);
            return 1;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          (**(code **)(*(longlong *)plVar6[4] + 0x28))();
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_140500650(plVar6[4]);
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar6;
        }
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x29);
          plVar3 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar3 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar5 = plVar3;
      plVar3 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar3 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CSocketKernel::helper_1404faf80  @1404faf80  [medium:callgraph-r1]  (orig: FUN_1404faf80)
longlong * FUN_1404faf80(longlong *param_1,longlong *param_2,longlong *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if ((longlong)puVar1[3] < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < (longlong)puVar4[3])) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CSocketKernel::helper_1404fb050  @1404fb050  [medium:callgraph-r0]  (orig: FUN_1404fb050)
undefined8 * FUN_1404fb050(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1404f7970(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1404fb23c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1404fb23c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1404f8440(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1404f78f0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1404f8440(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1404f78f0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1404f8440(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1404f78f0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CSocketKernel::helper_1404fb410  @1404fb410  [medium:callgraph-r0]  (orig: FUN_1404fb410)
longlong * FUN_1404fb410(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CSocketKernel::helper_1404fb520  @1404fb520  [medium:callgraph-r1]  (orig: FUN_1404fb520)
undefined8 *
FUN_1404fb520(longlong *param_1,undefined8 *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1404f97d0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar6 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = param_3[1];
    if (lVar2 == lVar6) {
      if (*param_4 < *(longlong *)(lVar2 + 0x18)) {
        FUN_1404f97d0(param_1,param_2,1,lVar2,param_4);
        return param_2;
      }
    }
    else {
      lVar6 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar6) {
        if (*(longlong *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1404f97d0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        lVar6 = *param_4;
        if (lVar6 < *(longlong *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar7 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar7[2] + 0x29);
              plVar8 = (longlong *)plVar7[2];
              while (local_30 = plVar7, cVar1 == '\0') {
                cVar1 = *(char *)(plVar8[2] + 0x29);
                plVar7 = plVar8;
                plVar8 = (longlong *)plVar8[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar3 = (longlong *)local_30[1];
              plVar8 = local_30;
              while ((plVar7 = plVar3, cVar1 == '\0' && (plVar8 == (longlong *)*plVar7))) {
                cVar1 = *(char *)(plVar7[1] + 0x29);
                plVar3 = (longlong *)plVar7[1];
                plVar8 = plVar7;
              }
              local_30 = plVar7;
              if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
                local_30 = plVar8;
                _invalid_parameter_noinfo();
                plVar7 = plVar8;
              }
            }
          }
          else {
            plVar7 = (longlong *)local_30[2];
            local_30 = plVar7;
            if (*(char *)((longlong)plVar7 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          lVar6 = *param_4;
          if (plVar7[3] < lVar6) {
            if (*(char *)(plVar7[2] + 0x29) != '\0') {
              FUN_1404f97d0(param_1,param_2,0,plVar7,param_4);
              return param_2;
            }
            FUN_1404f97d0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(longlong *)(param_3[1] + 0x18) < lVar6) {
          local_38 = *param_3;
          plVar7 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar6 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar8 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar8 + 0x29);
              plVar3 = (longlong *)*plVar8;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar3 + 0x29);
                plVar8 = plVar3;
                plVar3 = (longlong *)*plVar3;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar3 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar8[2]))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar3 = plVar8;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar6)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar8 == plVar7) || (*param_4 < plVar8[3])) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1404f97d0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1404f97d0(param_1,param_2,1,plVar8,param_4);
            return param_2;
          }
        }
      }
    }
    puVar5 = (undefined8 *)FUN_1404fa640(param_1,&local_38,param_4);
    *param_2 = *puVar5;
    param_2[1] = puVar5[1];
  }
  return param_2;
}

// ==== CSocketKernel::helper_1404fb850  @1404fb850  [medium:callgraph-r1]  (orig: FUN_1404fb850)
undefined8 * FUN_1404fb850(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1404f9c30(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1404f9c30(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1404f9c30(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_1404f9c30(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1404f9c30(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1404f9c30(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1404f9c30(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1404fa7f0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CSocketKernel::helper_1404fbb70  @1404fbb70  [medium:callgraph-r1]  (orig: FUN_1404fbb70)
longlong * FUN_1404fbb70(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1404f9100(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1404fb050(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CSocketKernel::helper_1404fbd20  @1404fbd20  [medium:callgraph-r0]  (orig: FUN_1404fbd20)
void FUN_1404fbd20(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1404fbb70((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CSocketKernel::helper_1404fbe30  @1404fbe30  [medium:callgraph-r1]  (orig: FUN_1404fbe30)
void FUN_1404fbe30(longlong param_1,char *param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  int local_res18 [4];
  undefined1 local_28 [32];
  
  lVar2 = -1;
  pcVar3 = param_2;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  if (lVar2 != -2) {
    local_res18[0] = Ordinal_11(param_2);
    if ((local_res18[0] != 0) && (local_res18[0] != -1)) {
      FUN_14000d480(param_1 + 0xf8,local_28,local_res18);
    }
  }
  return;
}

// ==== CSocketKernel::helper_1404fbe90  @1404fbe90  [medium:callgraph-r0]  (orig: FUN_1404fbe90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404fbe90(longlong param_1)

{
  longlong *plVar1;
  int *piVar2;
  char cVar3;
  longlong *plVar4;
  int iVar5;
  uint uVar6;
  FILE *_File;
  void *_Dst;
  char *_Dst_00;
  longlong lVar7;
  int iVar8;
  __uint64 _Size;
  char *pcVar9;
  undefined1 auStack_578 [32];
  undefined4 local_558;
  int local_548;
  undefined8 local_540;
  longlong *local_538;
  int local_530;
  int local_52c;
  void *local_528;
  FILE *local_520;
  undefined8 local_518;
  char *local_510;
  undefined1 local_508 [1152];
  char local_88 [48];
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined1 local_38;
  ulonglong local_30;
  
  local_518 = 0xfffffffffffffffe;
  local_30 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  _File = fopen("gms_ip.dat","r+b");
  local_520 = _File;
  if (_File == (FILE *)0x0) {
    log_InlineLogERROR("CSocketKernel::LoadGMIPList cannot open file gms_ip.dat");
    return 0;
  }
  iVar8 = 0;
  local_540 = 0;
  local_538 = (longlong *)0x0;
  FUN_1404fa1f0(&local_540,_File,fclose_exref);
  fseek(_File,0,2);
  uVar6 = ftell(_File);
  local_52c = (uVar6 & 0xffffffe0) + 0x20;
  _Size = (__uint64)local_52c;
  _Dst = operator_new__(_Size);
  local_528 = _Dst;
  if (_Dst == (void *)0x0) {
    log_InlineLogERROR("CSocketKernel::LoadGMIPList cannot alloc %d bytes for input data");
    plVar4 = local_538;
    if (local_538 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_538 + 2;
      lVar7 = *plVar1;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)lVar7 == 1) {
        (**(code **)*local_538)(local_538);
        LOCK();
        piVar2 = (int *)((longlong)plVar4 + 0x14);
        iVar8 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*local_538 + 8))();
        }
      }
    }
    return 0;
  }
  _Dst_00 = operator_new__(_Size);
  local_510 = _Dst_00;
  if (_Dst_00 == (char *)0x0) {
    operator_delete__(_Dst);
    log_InlineLogERROR("CSocketKernel::LoadGMIPList cannot alloc %d bytes for output data");
    plVar4 = local_538;
    if (local_538 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_538 + 2;
      lVar7 = *plVar1;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)lVar7 == 1) {
        (**(code **)*local_538)(local_538);
        LOCK();
        piVar2 = (int *)((longlong)plVar4 + 0x14);
        iVar8 = *piVar2;
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (iVar8 == 1) {
          (**(code **)(*local_538 + 8))();
        }
      }
    }
    return 0;
  }
  memset(_Dst,0,_Size);
  memset(_Dst_00,0,_Size);
  fseek(_File,0,0);
  fread(_Dst,1,_Size,_File);
  FUN_140501160(local_508);
  local_88[0x10] = 0;
  local_88[0x11] = '\0';
  local_88[0x12] = '\0';
  local_88[0x13] = '\0';
  local_88[0x14] = '\0';
  local_88[0x15] = '\0';
  local_88[0x16] = '\0';
  local_88[0x17] = '\0';
  local_88[0x18] = '\0';
  local_88[0x19] = '\0';
  local_88[0x1a] = '\0';
  local_88[0x1b] = '\0';
  local_88[0x1c] = '\0';
  local_88[0x1d] = '\0';
  local_88[0x1e] = '\0';
  local_88[0x1f] = '\0';
  local_88[0x20] = '\0';
  local_88[0x21] = '\0';
  local_88[0x22] = '\0';
  local_88[0x23] = '\0';
  local_88[0x24] = '\0';
  local_88[0x25] = '\0';
  local_88[0x26] = '\0';
  local_88[0x27] = '\0';
  local_88[0x28] = '\0';
  local_88[0x29] = '\0';
  local_88[0x2a] = '\0';
  local_88[0x2b] = '\0';
  local_88[0x2c] = '\0';
  local_88[0x2d] = '\0';
  local_88[0x2e] = '\0';
  local_88[0x2f] = 0;
  local_58 = DAT_140795098;
  local_50 = DAT_1407950a0;
  local_48 = DAT_1407950a8;
  local_40 = DAT_1407950b0;
  local_38 = DAT_1407950b8;
  local_558 = 0x20;
  FUN_140501190(local_508,&local_58,local_88 + 0x10,0x20);
  local_558 = 1;
  FUN_1405028e0(local_508,_Dst,_Dst_00,_Size);
  local_548 = 0;
  local_88[0] = '\0';
  local_88[1] = '\0';
  local_88[2] = '\0';
  local_88[3] = '\0';
  local_88[4] = '\0';
  local_88[5] = '\0';
  local_88[6] = '\0';
  local_88[7] = '\0';
  local_88[8] = 0;
  local_88[9] = '\0';
  local_88[10] = '\0';
  local_88[0xb] = '\0';
  local_88[0xc] = '\0';
  local_88[0xd] = '\0';
  local_88[0xe] = '\0';
  local_88[0xf] = 0;
  FUN_14000a7b0(param_1 + 0xf8);
  local_530 = 0;
  do {
    iVar5 = local_530;
    lVar7 = -1;
    pcVar9 = _Dst_00;
    do {
      if (lVar7 == 0) break;
      lVar7 = lVar7 + -1;
      cVar3 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar3 != '\0');
    if ((int)(~(uint)lVar7 - 1) <= local_530) break;
    cVar3 = _Dst_00[local_530];
    if (cVar3 != ' ') {
      if ((cVar3 == '\n') || (cVar3 == '\r')) {
        lVar7 = -1;
        pcVar9 = local_88;
        do {
          if (lVar7 == 0) break;
          lVar7 = lVar7 + -1;
          cVar3 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar3 != '\0');
        if (lVar7 != -2) {
          FUN_1404fbe30(param_1,local_88);
        }
        iVar8 = 0;
        local_548 = 0;
        local_88[0] = '\0';
        local_88[1] = '\0';
        local_88[2] = '\0';
        local_88[3] = '\0';
        local_88[4] = '\0';
        local_88[5] = '\0';
        local_88[6] = '\0';
        local_88[7] = '\0';
        local_88[8] = 0;
        local_88[9] = '\0';
        local_88[10] = '\0';
        local_88[0xb] = '\0';
        local_88[0xc] = '\0';
        local_88[0xd] = '\0';
        local_88[0xe] = '\0';
        local_88[0xf] = 0;
      }
      else if (iVar8 < 0xf) {
        local_88[iVar8] = cVar3;
        iVar8 = iVar8 + 1;
        local_548 = iVar8;
      }
    }
    local_530 = iVar5 + 1;
  } while( true );
  if (0 < iVar8) {
    lVar7 = -1;
    pcVar9 = local_88;
    do {
      if (lVar7 == 0) break;
      lVar7 = lVar7 + -1;
      cVar3 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar3 != '\0');
    if (lVar7 != -2) {
      FUN_1404fbe30(param_1,local_88);
      local_548 = 0;
      local_88[0] = '\0';
      local_88[1] = '\0';
      local_88[2] = '\0';
      local_88[3] = '\0';
      local_88[4] = '\0';
      local_88[5] = '\0';
      local_88[6] = '\0';
      local_88[7] = '\0';
      local_88[8] = 0;
      local_88[9] = '\0';
      local_88[10] = '\0';
      local_88[0xb] = '\0';
      local_88[0xc] = '\0';
      local_88[0xd] = '\0';
      local_88[0xe] = '\0';
      local_88[0xf] = 0;
    }
  }
  operator_delete__(_Dst);
  operator_delete__(_Dst_00);
  FUN_140501180(local_508);
  plVar4 = local_538;
  if (local_538 != (longlong *)0x0) {
    LOCK();
    plVar1 = local_538 + 2;
    lVar7 = *plVar1;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)lVar7 == 1) {
      (**(code **)*local_538)(local_538);
      LOCK();
      piVar2 = (int *)((longlong)plVar4 + 0x14);
      iVar8 = *piVar2;
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (iVar8 == 1) {
        (**(code **)(*local_538 + 8))();
      }
    }
  }
  return 1;
}

// ==== CSocketKernel::helper_1404fc2d0  @1404fc2d0  [medium:callgraph-r0]  (orig: FUN_1404fc2d0)
undefined8 FUN_1404fc2d0(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong local_res10;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  if (param_2 == -1) {
    uVar2 = 0;
  }
  else {
    local_res10 = param_2;
    FUN_1404faf80((longlong *)(param_1 + 0x138),&local_30,&local_res10,param_4,0xfffffffffffffffe);
    lVar1 = *(longlong *)(param_1 + 0x168);
    lVar3 = 0;
    local_20 = *(longlong **)(param_1 + 0x138);
    if ((local_30 == (longlong *)0x0) || (local_30 != local_20)) {
      _invalid_parameter_noinfo();
    }
    if (local_28 == lVar1) {
      uVar2 = 0;
    }
    else {
      if (local_30 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar3 = *local_30;
      }
      if (local_28 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar2 = *(undefined8 *)(local_28 + 0x20);
    }
  }
  return uVar2;
}

// ==== CSocketKernel::helper_1404fc3b0  @1404fc3b0  [medium:callgraph-r0]  (orig: FUN_1404fc3b0)
undefined8 * FUN_1404fc3b0(longlong *param_1,longlong *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  longlong local_48 [2];
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if ((longlong)puVar1[3] < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < (longlong)puVar3[3])) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_48[1] = 0;
    puVar3 = (undefined8 *)FUN_1404fb520(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CSocketKernel::helper_1404fc4f0  @1404fc4f0  [medium:callgraph-r0]  (orig: FUN_1404fc4f0)
undefined8 * FUN_1404fc4f0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_1404fb850(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CSocketKernel::helper_1404fc620  @1404fc620  [medium:callgraph-r0]  (orig: FUN_1404fc620)
longlong FUN_1404fc620(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1404f9b10(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1404fbb70(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CSocketKernel::ctor_or_dtor  @1404fc860  [high:vtable-assign]  (orig: FUN_1404fc860)
void FUN_1404fc860(undefined8 *param_1)

{
  *param_1 = CSocketKernel::vftable;
  FUN_1404fbd20(param_1 + 0x38);
  operator_delete((void *)param_1[0x38]);
  FUN_140050610(param_1 + 0x30);
  operator_delete((void *)param_1[0x30]);
  FUN_1404fa520(param_1 + 0x27);
  operator_delete((void *)param_1[0x27]);
  FUN_14000c310(param_1 + 0x1f);
  operator_delete((void *)param_1[0x1f]);
  FUN_1404ffd70(param_1 + 0x17);
  FUN_1404ffd70(param_1 + 0x15);
  FUN_1404ffd70(param_1 + 0x13);
  *param_1 = ISocketKernel::vftable;
  return;
}

// ==== CSocketKernel::vfunc_1  @1404fc940  [high:rtti-vtable]  (orig: FUN_1404fc940)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1404fc940(void *param_1,longlong *param_2,undefined8 param_3)

{
  char cVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  int iVar4;
  int iVar5;
  ulong uVar6;
  DWORD DVar7;
  DWORD DVar8;
  longlong lVar9;
  undefined8 uVar10;
  void *pvVar11;
  longlong *plVar12;
  longlong *plVar13;
  HANDLE Thread;
  uint *puVar14;
  undefined1 auStackY_488 [32];
  _SYSTEM_INFO local_448;
  CIniFile local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStackY_488;
  *(longlong **)((longlong)param_1 + 0x88) = param_2;
  *(undefined8 *)((longlong)param_1 + 0x90) = param_3;
  (**(code **)(*param_2 + 0x38))(param_2);
  (**(code **)(**(longlong **)((longlong)param_1 + 0x88) + 0x40))
            (*(longlong **)((longlong)param_1 + 0x88),0x898);
  plVar13 = (longlong *)0x0;
  *(undefined8 *)((longlong)param_1 + 200) = 0;
  *(undefined8 *)((longlong)param_1 + 0xd0) = 0;
  cVar1 = FUN_1404f7160();
  uVar2 = 0;
  if (cVar1 != '\0') {
    FUN_14053c700();
    lVar9 = FUN_14053e9c0();
    if (lVar9 == 0) {
      log_InlineLogERROR("CSocketKernel::Create event_config_new failed");
      uVar2 = 0;
    }
    else {
      FUN_14053ce40(lVar9,4);
      GetSystemInfo(&local_448);
      FUN_14053ce60(lVar9,local_448.dwNumberOfProcessors);
      uVar10 = FUN_140542310(lVar9);
      *(undefined8 *)((longlong)param_1 + 0x178) = uVar10;
      FUN_14053eaa0(lVar9);
      if (*(longlong *)((longlong)param_1 + 0x178) == 0) {
        log_InlineLogERROR("CSocketKernel::Create m_pEventBase is NULL");
        uVar2 = 0;
      }
      else {
        uVar10 = FUN_14053d1c0();
        log_InlineLogMessage("libevent method: %s",uVar10);
        CIniFile::CIniFile(local_418,"shell.ini","System");
        iVar4 = CIniFile::GetInt(local_418,"SERVE_PORT");
        if (iVar4 == 0) {
          iVar4 = 0x16b8;
        }
        iVar5 = CIniFile::GetInt(local_418,"MSGCOUNT_OUT");
        if (iVar5 < 1) {
          *(undefined4 *)((longlong)param_1 + 8) = 0x84;
        }
        else {
          *(int *)((longlong)param_1 + 8) = iVar5;
        }
        log_InlineLogMessage("MSGCOUNT_OUT=%d",(ulonglong)*(uint *)((longlong)param_1 + 8));
        *(undefined4 *)((longlong)param_1 + 0xc) = 10;
        uVar6 = tq::TimeGet(0);
        *(uint *)((longlong)param_1 + 0x10) = uVar6 / 1000;
        cVar1 = FUN_1404fbe90(param_1);
        if (cVar1 == '\0') {
          log_InlineLogWARNING("CSocketKernel::Create cannot load GM IP list file");
        }
        cVar1 = (**(code **)(*(longlong *)((longlong)param_1 + 0xa8) + 8))
                          ((longlong *)((longlong)param_1 + 0xa8),param_1,iVar4 + 2,0);
        if (cVar1 == '\0') {
          log_InlineLogERROR("CSocketKernel::Create cannot listen on GM service port");
          CIniFile::~CIniFile(local_418);
          uVar2 = 0;
        }
        else {
          cVar1 = (**(code **)(*(longlong *)((longlong)param_1 + 0xb8) + 8))
                            ((longlong *)((longlong)param_1 + 0xb8),param_1,iVar4 + 4,0x20000);
          if (cVar1 == '\0') {
            log_InlineLogERROR("CSocketKernel::Create cannot listen on NPC service port");
            CIniFile::~CIniFile(local_418);
            uVar2 = 0;
          }
          else {
            cVar1 = (**(code **)(*(longlong *)((longlong)param_1 + 0x98) + 8))
                              ((longlong *)((longlong)param_1 + 0x98),param_1,iVar4,0x10000);
            if (cVar1 == '\0') {
              CIniFile::~CIniFile(local_418);
              uVar2 = 0;
            }
            else {
              pvVar11 = operator_new(0x1468);
              plVar12 = plVar13;
              if (pvVar11 != (void *)0x0) {
                plVar12 = (longlong *)FUN_140503610(pvVar11);
              }
              *(longlong **)((longlong)param_1 + 0xd8) = plVar12;
              if ((plVar12 == (longlong *)0x0) ||
                 (cVar1 = (**(code **)(*plVar12 + 8))(plVar12,param_1,3), cVar1 == '\0')) {
                log_InlineLogERROR(
                                  "CSocketKernel::Create cannot create AccountServer client socket."
                                  );
                if (*(longlong *)((longlong)param_1 + 0xd8) != 0) {
                  (**(code **)(**(longlong **)((longlong)param_1 + 0xd8) + 0x10))();
                  *(undefined8 *)((longlong)param_1 + 0xd8) = 0;
                }
                CIniFile::~CIniFile(local_418);
                uVar2 = 0;
              }
              else {
                CIniFile::SetSection(local_418,"ChangeServerClient");
                iVar4 = CIniFile::GetInt(local_418,"IsConnectChangeServer");
                if (iVar4 == 1) {
                  pvVar11 = operator_new(0x1468);
                  plVar12 = plVar13;
                  if (pvVar11 != (void *)0x0) {
                    plVar12 = (longlong *)FUN_140503280(pvVar11);
                  }
                  *(longlong **)((longlong)param_1 + 0xe0) = plVar12;
                  if ((plVar12 == (longlong *)0x0) ||
                     (cVar1 = (**(code **)(*plVar12 + 8))(plVar12,param_1,4), cVar1 == '\0')) {
                    log_InlineLogERROR(
                                      "CSocketKernel::Create cannot create ChangeServer client socket."
                                      );
                    if (*(longlong *)((longlong)param_1 + 0xe0) != 0) {
                      (**(code **)(**(longlong **)((longlong)param_1 + 0xe0) + 0x10))();
                      *(undefined8 *)((longlong)param_1 + 0xe0) = 0;
                    }
                    CIniFile::~CIniFile(local_418);
                    return 0;
                  }
                }
                CIniFile::SetSection(local_418,"IPADPaymentsClient");
                iVar4 = CIniFile::GetInt(local_418,"IsSupportIPADPayments");
                if (iVar4 == 1) {
                  pvVar11 = operator_new(0x1468);
                  plVar12 = plVar13;
                  if (pvVar11 != (void *)0x0) {
                    plVar12 = (longlong *)FUN_140502ef0(pvVar11);
                  }
                  *(longlong **)((longlong)param_1 + 0xe8) = plVar12;
                  if ((plVar12 == (longlong *)0x0) ||
                     (cVar1 = (**(code **)(*plVar12 + 8))(plVar12,param_1,5), cVar1 == '\0')) {
                    log_InlineLogERROR(
                                      "CSocketKernel::Create cannot create IpadServer client socket."
                                      );
                    if (*(longlong *)((longlong)param_1 + 0xe8) != 0) {
                      (**(code **)(**(longlong **)((longlong)param_1 + 0xe8) + 0x10))();
                      *(undefined8 *)((longlong)param_1 + 0xe8) = 0;
                    }
                    CIniFile::~CIniFile(local_418);
                    return 0;
                  }
                }
                CIniFile::SetSection(local_418,"CrossClient");
                iVar4 = CIniFile::GetInt(local_418,"Enable");
                if (iVar4 == 1) {
                  pvVar11 = operator_new(0x1468);
                  if (pvVar11 != (void *)0x0) {
                    plVar13 = (longlong *)FUN_140502b40(pvVar11);
                  }
                  *(longlong **)((longlong)param_1 + 0xf0) = plVar13;
                  if ((plVar13 == (longlong *)0x0) ||
                     (cVar1 = (**(code **)(*plVar13 + 8))(plVar13,param_1,6), cVar1 == '\0')) {
                    log_InlineLogERROR(
                                      "CSocketKernel::Create cannot create CrossServer client socket."
                                      );
                    if (*(longlong *)((longlong)param_1 + 0xf0) != 0) {
                      (**(code **)(**(longlong **)((longlong)param_1 + 0xf0) + 0x10))();
                      *(undefined8 *)((longlong)param_1 + 0xf0) = 0;
                    }
                    CIniFile::~CIniFile(local_418);
                    return 0;
                  }
                }
                Thread = (HANDLE)_beginthreadex((void *)0x0,0,FUN_1404f8110,param_1,0,(uint *)0x0);
                *(HANDLE *)((longlong)param_1 + 0x200) = Thread;
                if (Thread == (HANDLE)0x0) {
                  puVar14 = (uint *)_errno();
                  log_InlineLogERROR("CSocketKernel::Create _beginthreadex failed with error code:%u"
                                     ,(ulonglong)*puVar14);
                  CIniFile::~CIniFile(local_418);
                  uVar2 = 0;
                }
                else {
                  DVar7 = GetThreadId(Thread);
                  DVar8 = GetCurrentThreadId();
                  log_InlineLogMessage
                            ("thread %u created libevent worker thread %u",(ulonglong)DVar8,
                             (ulonglong)DVar7);
                  plVar13 = (longlong *)FUN_140006ad0(50000,1);
                  if (plVar13 == (longlong *)0x0) {
                    log_InlineLogERROR("CGameConfig::QueryConfig GAME_VERSION_CONFIG not configured @%s,%d"
                                       ,
                                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\socketkernel.cpp"
                                       ,0x20b);
                    CIniFile::~CIniFile(local_418);
                    uVar2 = 0;
                  }
                  else {
                    lVar9 = (**(code **)(*plVar13 + 0x40))(plVar13);
                    if (lVar9 == 0) {
                      log_InlineLogERROR("CGameConfig::QueryConfig GAME_VERSION_CONFIG not configured @%s,%d"
                                         ,
                                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\socketkernel.cpp"
                                         ,0x210);
                      (**(code **)*plVar13)(plVar13);
                      CIniFile::~CIniFile(local_418);
                      uVar2 = 0;
                    }
                    else {
                      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,2);
                      uVar3 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      (**(code **)*plVar13)();
                      FUN_140508740(0,uVar3);
                      *(undefined1 *)((longlong)param_1 + 0x208) = 1;
                      *(undefined4 *)((longlong)param_1 + 0x214) = 0x2760;
                      *(undefined4 *)((longlong)param_1 + 0x20c) = 0x3c;
                      uVar6 = tq::TimeGet(0);
                      *(uint *)((longlong)param_1 + 0x210) = uVar6 / 1000;
                      CIniFile::~CIniFile(local_418);
                      uVar2 = 1;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return uVar2;
}

// ==== CSocketKernel::helper_1404fcfd0  @1404fcfd0  [medium:callgraph-r0]  (orig: FUN_1404fcfd0)
undefined8 FUN_1404fcfd0(longlong param_1,uint param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  int *piVar9;
  longlong *plVar10;
  int iVar11;
  undefined8 *puVar12;
  longlong lVar13;
  uint local_res10 [2];
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar1 = *(undefined8 **)(param_1 + 0x1f0);
  cVar5 = *(char *)((longlong)puVar1[1] + 0x29);
  puVar3 = puVar1;
  puVar12 = (undefined8 *)puVar1[1];
  while (cVar5 == '\0') {
    if (*(uint *)(puVar12 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar12[2];
      puVar12 = puVar3;
    }
    else {
      puVar7 = (undefined8 *)*puVar12;
    }
    puVar3 = puVar12;
    puVar12 = puVar7;
    cVar5 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x1c0);
  local_res10[0] = param_2;
  if (*(longlong *)(param_1 + 0x1c0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar1) || (local_res10[0] < *(uint *)(puVar3 + 3))) {
    plVar10 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x1f0);
    local_28 = *(longlong *)(param_1 + 0x1c0);
  }
  else {
    plVar10 = &local_38;
  }
  plVar2 = (longlong *)*plVar10;
  lVar13 = *(longlong *)(param_1 + 0x1f0);
  local_18 = plVar2;
  local_10 = plVar10[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x1c0))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar13) {
    uVar8 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar13 = 0;
    }
    else {
      lVar13 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar13 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    cVar5 = (**(code **)(**(longlong **)(lVar4 + 0x20) + 0x60))();
    if (cVar5 == '\0') {
      piVar9 = (int *)FUN_140053460(param_1 + 0x180);
      lVar13 = **(longlong **)(param_1 + 0x88);
      if (*piVar9 == 2) {
        (**(code **)(lVar13 + 0x50))(*(longlong **)(param_1 + 0x88),2,0x3eb,0xea65,local_res10);
      }
      else {
        iVar11 = 0xe;
        iVar6 = (**(code **)(lVar13 + 0x18))();
        if (0xe < iVar6) {
          do {
            (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                      (*(longlong **)(param_1 + 0x88),iVar11,0x3eb,0xea65,local_res10);
            iVar11 = iVar11 + 1;
            iVar6 = (**(code **)(**(longlong **)(param_1 + 0x88) + 0x18))();
          } while (iVar11 < iVar6);
        }
      }
    }
    else {
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),0xe,0x3ee,0xea65,local_res10);
    }
    uVar8 = 1;
  }
  return uVar8;
}

// ==== CSocketKernel::helper_1404fd1a0  @1404fd1a0  [medium:callgraph-r0]  (orig: FUN_1404fd1a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404fd1a0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  ulong uVar6;
  int iVar7;
  undefined8 uVar8;
  undefined4 *puVar9;
  int *piVar10;
  bool bVar11;
  undefined1 auStack_4c8 [32];
  int *local_4a8;
  undefined1 local_4a0;
  int local_498;
  int local_494;
  int local_490;
  int local_48c;
  int local_488;
  uint local_480;
  undefined4 local_47c;
  uint local_478;
  void *local_470;
  undefined8 local_468;
  undefined8 local_460;
  int local_458;
  int local_454;
  int local_450;
  uint local_44c;
  undefined4 local_448;
  uint local_444;
  ulonglong local_38;
  
  local_460 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_498 = 0;
  uVar8 = (**(code **)(*param_2 + 8))(param_2,&local_498);
  local_468 = uVar8;
  iVar4 = FUN_140500a30(param_2);
  if (((0 < local_498) && (iVar4 != 0)) &&
     ((local_48c = iVar4, *(longlong **)(param_1 + 0x90) == (longlong *)0x0 ||
      (iVar5 = (**(code **)(**(longlong **)(param_1 + 0x90) + 0x10))(), iVar5 < 100000)))) {
    iVar5 = (**(code **)(*param_2 + 0x40))(param_2);
    uVar6 = tq::TimeGet(0);
    if ((0x4b < uVar6 - iVar5) && (cVar3 = (**(code **)(*param_2 + 0x58))(param_2), cVar3 != '\0'))
    {
      local_490 = 0;
      local_470 = (void *)0x0;
      local_494 = 0;
      local_4a0 = 1;
      local_4a8 = &local_490;
      iVar7 = FUN_1404f6c90(uVar8,local_498,&local_494,&local_470);
      iVar5 = local_494;
      local_488 = iVar7;
      if (iVar7 < 1) {
        if (iVar7 < 0) {
          (**(code **)(*param_2 + 0x28))(param_2);
        }
      }
      else {
        local_454 = local_494;
        local_450 = local_490;
        local_458 = iVar4;
        memcpy(&local_44c,local_470,(longlong)local_490);
        if (iVar5 == 0x8f) {
          uVar2 = local_478;
          if (local_450 == 0xc) {
            local_480 = local_44c;
            local_47c = local_448;
            local_478 = local_444;
            uVar2 = local_478;
            if (local_44c == (local_444 & 0xffffff)) {
              local_478._0_1_ = (byte)local_444;
              local_47c._0_1_ = (byte)local_448;
              bVar11 = (byte)local_47c == ((byte)local_478 & 7);
              if ((bVar11) &&
                 (local_47c._1_1_ = (byte)((uint)local_448 >> 8),
                 bVar11 = local_47c._1_1_ == ((byte)local_478 & 0x80), bVar11)) {
                local_478 = uVar2;
                uVar6 = tq::TimeGet(0);
                *(uint *)(param_1 + 0x210) = uVar6 / 1000;
                *(undefined4 *)(param_1 + 0x214) = 0x2760;
                uVar2 = local_478;
                if (DAT_140949790 != '\0') {
                  log_InlineLogMessage("receive heart beat.");
                  uVar2 = local_478;
                }
              }
            }
          }
        }
        else {
          cVar3 = (**(code **)(*param_2 + 0x60))(param_2);
          if (cVar3 == '\0') {
            cVar3 = FUN_1404f76f0(&local_458);
            if (cVar3 == '\0') {
              cVar3 = FUN_1404f76a0(&local_458);
              if (((cVar3 == '\0') && (cVar3 = FUN_1404f7600(&local_458), cVar3 == '\0')) &&
                 (cVar3 = FUN_1404f7650(&local_458), cVar3 == '\0')) {
                lVar1 = **(longlong **)(param_1 + 0x88);
                puVar9 = (undefined4 *)FUN_140053460(param_1 + 0x180,&local_48c);
                local_4a8 = &local_458;
                (**(code **)(lVar1 + 0x50))(*(undefined8 *)(param_1 + 0x88),*puVar9,0x3e9);
                uVar2 = local_478;
              }
              else {
                piVar10 = (int *)FUN_140053460(param_1 + 0x180,&local_48c);
                uVar2 = local_478;
                if (*piVar10 == 0xe) {
                  local_4a8 = &local_458;
                  (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                            (*(longlong **)(param_1 + 0x88),8,0x3e9);
                  uVar2 = local_478;
                }
              }
            }
            else {
              FUN_1404f7740(param_1,&local_458);
              local_4a8 = &local_458;
              (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                        (*(longlong **)(param_1 + 0x88),1,0x7533,0x418);
              uVar2 = local_478;
            }
          }
          else {
            local_4a8 = &local_458;
            (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                      (*(longlong **)(param_1 + 0x88),6,0x3e9);
            uVar2 = local_478;
          }
        }
        local_478 = uVar2;
        lVar1 = *param_2;
        uVar6 = tq::TimeGet(0);
        (**(code **)(lVar1 + 0x90))(param_2,uVar6);
        (**(code **)(*param_2 + 0x10))(param_2,iVar7 + 8);
        LOCK();
        DAT_14097574c = DAT_14097574c + 1;
        UNLOCK();
        LOCK();
        DAT_140975794 = DAT_140975794 + 1;
        UNLOCK();
        LOCK();
        DAT_140975790 = DAT_140975790 + local_488;
        UNLOCK();
        (**(code **)(*param_2 + 0x78))(param_2);
      }
    }
  }
  return;
}

// ==== CSocketKernel::vfunc_0  @1404fd620  [high:rtti-vtable]  (orig: FUN_1404fd620)
void * FUN_1404fd620(void *param_1,uint param_2)

{
  FUN_1404fc860();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSocketKernel::ProcessMsg  @1404fd650  [high:log-string]  (orig: FUN_1404fd650)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1404fd650(longlong param_1,undefined4 param_2,uint *param_3,undefined8 param_4,int param_5)

{
  uint *puVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong *puVar5;
  longlong *plVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  undefined8 *puVar13;
  undefined4 *puVar14;
  int *piVar15;
  longlong lVar16;
  int iVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  uint uVar20;
  ushort uVar21;
  char *pcVar22;
  ulonglong uVar23;
  short sVar24;
  undefined1 auStack_1698 [32];
  uint *local_1678;
  longlong local_1668;
  undefined4 local_1660;
  undefined1 local_165c [8];
  uint local_1654;
  uint local_1650;
  undefined4 local_164c;
  longlong local_1648;
  uint local_1640;
  undefined4 local_163c;
  ulonglong *local_1638;
  longlong *plStack_1630;
  undefined4 local_1628 [2];
  longlong local_1620;
  undefined4 local_1618 [2];
  uint *local_1610;
  undefined4 local_1608 [2];
  ulonglong local_1600;
  undefined4 local_15f8;
  uint local_15f4;
  uint local_15f0;
  uint local_15e8;
  uint local_15e0;
  uint local_15d8;
  ulonglong local_15d0;
  uint local_15c8;
  longlong *local_15c0;
  longlong local_15b8;
  longlong *local_15b0;
  longlong local_15a8;
  longlong *local_15a0;
  longlong local_1598;
  ulonglong *local_1590;
  uint *local_1588;
  longlong *local_1580;
  longlong local_1578;
  ulonglong *local_1570;
  longlong local_1568;
  CTickAnalyst local_1560 [24];
  uint *local_1548;
  undefined8 local_1540;
  longlong *local_1538;
  CTickAnalyst local_1530 [24];
  longlong *local_1518;
  CTickAnalyst local_1510 [24];
  longlong local_14f8;
  CTickAnalyst local_14e8 [24];
  longlong *local_14d0;
  CTickAnalyst local_14c0 [24];
  uint *local_14a8;
  longlong local_14a0;
  ulonglong *local_1498;
  longlong local_1488;
  undefined1 local_1478 [16];
  undefined1 local_1468 [16];
  undefined1 local_1458 [9];
  undefined8 local_144f;
  undefined8 local_1447;
  undefined4 local_143f;
  undefined2 local_143b;
  undefined1 local_1439;
  ushort local_1438;
  undefined2 local_1436;
  undefined1 local_1434 [1020];
  ushort local_1038;
  undefined2 local_1036;
  uint local_1034;
  undefined1 local_1030 [1016];
  short local_c38;
  undefined2 local_c36;
  undefined1 local_c34 [1020];
  ushort local_838;
  undefined2 local_836;
  undefined1 local_834 [1020];
  ushort local_438;
  undefined2 local_436;
  undefined1 local_434 [1020];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1404fd664;
  local_1540 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1698;
  local_1668 = param_1;
  local_1610 = param_3;
  switch(param_2) {
  case 0x7532:
    FUN_140050f20(param_1 + 0x180,&local_15c0);
    lVar16 = *(longlong *)(param_1 + 0x1b0);
    if ((local_15c0 == (longlong *)0x0) || (local_15c0 != *(longlong **)(param_1 + 0x180))) {
      _invalid_parameter_noinfo();
    }
    if (local_15b8 == lVar16) {
      local_1678 = param_3;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),param_5,0x3eb,0xea65);
    }
    else {
      if (local_15c0 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = 0;
      }
      else {
        lVar16 = *local_15c0;
      }
      if (local_15b8 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(uint *)(local_15b8 + 0x1c) = param_3[1];
    }
    break;
  case 0x7533:
    if ((param_3 == (uint *)0x0) || (puVar1 = param_3 + 3, puVar1 == (uint *)0x0)) {
      log_InlineLogERROR("null packet");
    }
    else {
      if (*param_3 == 0x10000) {
        local_15e8 = param_3[1];
        iVar17 = param_3[2] + 4;
        if (iVar17 < 0x401) {
          local_c36 = (undefined2)local_15e8;
          local_c38 = (short)iVar17;
          memcpy(local_c34,puVar1,(longlong)(int)param_3[2]);
          sVar24 = local_c38;
        }
        else {
          sVar24 = 0;
        }
        if (sVar24 == 0) {
          local_1678 = (uint *)CONCAT44(local_1678._4_4_,0x49c);
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","nNetPacketSize",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\socketkernel.cpp"
                            );
        }
        else {
          plVar9 = *(longlong **)(param_1 + 200);
          if (plVar9 != (longlong *)0x0) {
            (**(code **)(*plVar9 + 0x18))(plVar9,&local_c38,sVar24);
          }
        }
        return 1;
      }
      plVar9 = (longlong *)(param_1 + 0x1c0);
      FUN_1404fb410(plVar9,&local_15b0);
      local_1620 = *(longlong *)(param_1 + 0x1f0);
      lVar16 = 0;
      local_14d0 = (longlong *)*plVar9;
      local_1518 = plVar9;
      local_14a0 = local_1620;
      if ((local_15b0 == (longlong *)0x0) || (local_15b0 != local_14d0)) {
        _invalid_parameter_noinfo();
      }
      if (local_15a8 != local_1620) {
        local_15d8 = param_3[2];
        local_15e0 = param_3[1];
        if ((int)(local_15d8 + 4) < 0x401) {
          local_836 = (undefined2)local_15e0;
          local_838 = (ushort)(local_15d8 + 4);
          memcpy(local_834,puVar1,(longlong)(int)local_15d8);
          uVar20 = (uint)local_838;
          local_1650 = (uint)local_838;
        }
        else {
          uVar20 = 0;
          local_1650 = 0;
        }
        if (uVar20 == 0) {
          log_InlineLogERROR("CSocketKernel::ProcessMsg(SOCKET_SENDCLIENTMSG) msg %u has a bad size %d"
                             ,(ulonglong)param_3[1],0);
        }
        else {
          if (local_15b0 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar16 = *local_15b0;
          }
          if (local_15a8 == *(longlong *)(lVar16 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          (**(code **)(**(longlong **)(local_15a8 + 0x20) + 0x18))
                    (*(longlong **)(local_15a8 + 0x20),&local_838,uVar20);
          LOCK();
          DAT_140975748 = DAT_140975748 + uVar20;
          UNLOCK();
          LOCK();
          DAT_140975788 = DAT_140975788 + local_1650;
          UNLOCK();
          LOCK();
          DAT_14097578c = DAT_14097578c + 1;
          UNLOCK();
        }
      }
    }
    break;
  case 0x7534:
    plVar9 = *(longlong **)(param_1 + 0xd0);
    if (plVar9 != (longlong *)0x0) {
      uVar20 = param_3[2];
      if ((int)(uVar20 + 8) < 0x401) {
        local_1036 = (undefined2)param_3[1];
        local_1038 = (short)uVar20 + 8;
        local_1034 = *param_3;
        memcpy(local_1030,param_3 + 3,(longlong)(int)uVar20);
        if (local_1038 != 0) {
          uVar20 = (uint)local_1038;
          (**(code **)(*plVar9 + 0x18))(plVar9,&local_1038,uVar20);
          LOCK();
          DAT_140975750 = DAT_140975750 + uVar20;
          UNLOCK();
          LOCK();
          DAT_140975798 = DAT_140975798 + uVar20;
          UNLOCK();
          LOCK();
          DAT_14097579c = DAT_14097579c + 1;
          UNLOCK();
        }
      }
    }
    break;
  default:
    log_InlineLogERROR("CSocketKernel::ProcessMsg idPacket");
    return 0;
  case 0x7538:
    FUN_1404fb410(param_1 + 0x1c0,&local_1580);
    lVar16 = *(longlong *)(param_1 + 0x1f0);
    if ((local_1580 == (longlong *)0x0) || (local_1580 != *(longlong **)(param_1 + 0x1c0))) {
      _invalid_parameter_noinfo();
    }
    if (local_1578 != lVar16) {
      if (local_1580 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = 0;
      }
      else {
        lVar16 = *local_1580;
      }
      if (local_1578 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong **)(local_1578 + 0x20) != (longlong *)0x0) {
        (**(code **)(**(longlong **)(local_1578 + 0x20) + 0x28))();
      }
    }
    break;
  case 0x753b:
    plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x1f0);
    plVar10 = *(longlong **)(param_1 + 0x1c0);
    DAT_1409758f4 = 1;
    while( true ) {
      plVar4 = *(longlong **)(param_1 + 0x1f0);
      if ((plVar10 == (longlong *)0x0) || (plVar10 != *(longlong **)(param_1 + 0x1c0))) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == plVar4) break;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = 0;
      }
      else {
        lVar16 = *plVar10;
      }
      if (plVar9 == *(longlong **)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if ((longlong *)plVar9[4] != (longlong *)0x0) {
        (**(code **)(*(longlong *)plVar9[4] + 0x28))();
      }
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        plVar4 = (longlong *)plVar9[2];
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
          cVar2 = *(char *)(*plVar4 + 0x29);
          plVar9 = plVar4;
          plVar4 = (longlong *)*plVar4;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*plVar4 + 0x29);
            plVar9 = plVar4;
            plVar4 = (longlong *)*plVar4;
          }
        }
        else {
          cVar2 = *(char *)(plVar9[1] + 0x29);
          plVar6 = (longlong *)plVar9[1];
          plVar4 = plVar9;
          while ((plVar9 = plVar6, cVar2 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
            cVar2 = *(char *)(plVar9[1] + 0x29);
            plVar6 = (longlong *)plVar9[1];
            plVar4 = plVar9;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    break;
  case 0x753c:
    if (param_3 == (uint *)0x0) {
      local_1678 = (uint *)CONCAT44(local_1678._4_4_,0x513);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_140795ae0,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\socketkernel.cpp");
      return 0;
    }
    local_163c = 0;
    local_1640 = param_3[1];
    FUN_1404fb410(param_1 + 0x1c0,&local_1638);
    lVar16 = *(longlong *)(param_1 + 0x1f0);
    if ((local_1638 == (ulonglong *)0x0) || (local_1638 != *(ulonglong **)(param_1 + 0x1c0))) {
      _invalid_parameter_noinfo();
    }
    if (plStack_1630 != (longlong *)lVar16) {
      if (local_1638 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar18 = 0;
      }
      else {
        uVar18 = *local_1638;
      }
      if (plStack_1630 == (longlong *)*(longlong *)(uVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_163c = (**(code **)(**(longlong **)((longlong)plStack_1630 + 0x20) + 0x30))();
      plVar9 = *(longlong **)(param_1 + 0x88);
      if (plVar9 != (longlong *)0x0) {
        local_1678 = &local_1640;
        (**(code **)(*plVar9 + 0x50))(plVar9,*param_3,0x2725,8);
      }
    }
    break;
  case 0x753d:
    CTickAnalyst::CTickAnalyst(local_14c0,0x28);
    uVar20 = param_3[2];
    if ((int)(uVar20 + 4) < 0x401) {
      local_436 = (undefined2)param_3[1];
      local_438 = (short)uVar20 + 4;
      memcpy(local_434,param_3 + 3,(longlong)(int)uVar20);
      local_165c._4_4_ = ZEXT24(local_438);
      if (local_165c._4_4_ != 0) {
        uVar19 = 0;
        plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x1f0);
        puVar5 = *(ulonglong **)(param_1 + 0x1c0);
        uVar18 = uVar19;
        local_1638 = puVar5;
        plStack_1630 = plVar9;
        while( true ) {
          plVar10 = *(longlong **)(param_1 + 0x1f0);
          if ((puVar5 == (ulonglong *)0x0) || (puVar5 != *(ulonglong **)(param_1 + 0x1c0))) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar10) break;
          if (puVar5 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar23 = uVar19;
          }
          else {
            uVar23 = *puVar5;
          }
          if (plVar9 == *(longlong **)(uVar23 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(uint *)(plVar9 + 3) != *param_3) {
            if (param_5 == 8) {
              if (puVar5 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar23 = uVar19;
              }
              else {
                uVar23 = *puVar5;
              }
              if (plVar9 == *(longlong **)(uVar23 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              piVar15 = (int *)FUN_140053460(param_1 + 0x180,plVar9 + 3);
              if (*piVar15 == 0xe) {
LAB_1404fe8be:
                if (puVar5 == (ulonglong *)0x0) {
                  _invalid_parameter_noinfo();
                  uVar23 = uVar19;
                }
                else {
                  uVar23 = *puVar5;
                }
                if (plVar9 == *(longlong **)(uVar23 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                uVar7 = local_165c._4_4_;
                (**(code **)(*(longlong *)plVar9[4] + 0x18))
                          ((longlong *)plVar9[4],&local_438,local_165c._4_4_);
                uVar18 = (ulonglong)(uint)((int)uVar18 + uVar7);
              }
            }
            else {
              if (puVar5 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar23 = uVar19;
              }
              else {
                uVar23 = *puVar5;
              }
              if (plVar9 == *(longlong **)(uVar23 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              piVar15 = (int *)FUN_140053460(param_1 + 0x180,plVar9 + 3);
              if (*piVar15 == param_5) goto LAB_1404fe8be;
            }
          }
          if (puVar5 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            plVar10 = (longlong *)plVar9[2];
            if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
              cVar2 = *(char *)(*plVar10 + 0x29);
              plVar9 = plVar10;
              plVar10 = (longlong *)*plVar10;
              while (cVar2 == '\0') {
                cVar2 = *(char *)(*plVar10 + 0x29);
                plVar9 = plVar10;
                plVar10 = (longlong *)*plVar10;
              }
            }
            else {
              cVar2 = *(char *)(plVar9[1] + 0x29);
              plVar4 = (longlong *)plVar9[1];
              plVar10 = plVar9;
              while ((plVar9 = plVar4, cVar2 == '\0' && (plVar10 == (longlong *)plVar9[2]))) {
                cVar2 = *(char *)(plVar9[1] + 0x29);
                plVar4 = (longlong *)plVar9[1];
                plVar10 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        LOCK();
        DAT_140975748 = DAT_140975748 + (int)uVar18;
        UNLOCK();
        CTickAnalyst::~CTickAnalyst(local_14c0);
        break;
      }
    }
    CTickAnalyst::~CTickAnalyst(local_14c0);
    break;
  case 0x753e:
    CTickAnalyst::CTickAnalyst(local_1560,0x29);
    uVar18 = (ulonglong)*param_3;
    local_1600 = uVar18;
    local_1548 = param_3;
    memset(&local_1438,0,0x400);
    local_15c8 = param_3[2];
    local_15f0 = param_3[1];
    if ((int)(local_15c8 + 4) < 0x401) {
      local_1436 = (undefined2)local_15f0;
      local_1438 = (ushort)(local_15c8 + 4);
      memcpy(local_1434,param_3 + 3,(longlong)(int)local_15c8);
      local_1654 = (uint)local_1438;
      uVar21 = local_1438;
    }
    else {
      uVar21 = 0;
      local_1654 = 0;
    }
    if (uVar21 == 0) {
      log_InlineLogERROR("CSocketKernel::ProcessMsg(SOCKET_SENDMULTICLIENTMSG) msg %u has a bad size %d"
                         ,(ulonglong)param_3[1],0);
      CTickAnalyst::~CTickAnalyst(local_1560);
    }
    else if ((longlong)(int)(param_3[2] + 0xc) + uVar18 * 4 < 0x419) {
      local_15f4 = 0;
      local_15d0 = 0;
      uVar19 = 0;
      while (uVar23 = local_15d0, local_15d0 < uVar18) {
        local_164c = 0;
        memmove(&local_164c,
                (void *)((longlong)param_3 + local_15d0 * 4 + (longlong)(int)param_3[2] + 0xc),4);
        plVar9 = (longlong *)(param_1 + 0x1c0);
        FUN_1404fb410(plVar9,&local_1590,&local_164c);
        puVar5 = local_1590;
        local_1610 = *(uint **)(param_1 + 0x1f0);
        local_1498 = (ulonglong *)*plVar9;
        local_1538 = plVar9;
        local_14a8 = local_1610;
        if ((local_1590 == (ulonglong *)0x0) || (local_1590 != local_1498)) {
          _invalid_parameter_noinfo();
        }
        puVar1 = local_1588;
        if (local_1588 != local_1610) {
          if (puVar5 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar18 = 0;
          }
          else {
            uVar18 = *puVar5;
          }
          if (puVar1 == *(uint **)(uVar18 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar20 = local_1654;
          plVar9 = *(longlong **)(puVar1 + 8);
          (**(code **)(*plVar9 + 0x18))(plVar9,&local_1438,local_1654);
          local_15f4 = (int)uVar19 + uVar20;
          uVar19 = (ulonglong)local_15f4;
        }
        uVar18 = local_1600;
        local_15d0 = uVar23 + 1;
      }
      LOCK();
      DAT_140975748 = DAT_140975748 + (int)uVar19;
      UNLOCK();
      CTickAnalyst::~CTickAnalyst(local_1560);
    }
    else {
      log_InlineLogERROR("CSocketKernel::ProcessMsg(SOCKET_SENDMULTICLIENTMSG) msg %u has a bad player amount %u"
                         ,(ulonglong)param_3[1],uVar18);
      CTickAnalyst::~CTickAnalyst(local_1560);
    }
    break;
  case 0x7541:
    if ((int)param_3[1] < 1) {
      return 0;
    }
    uVar18 = 0;
    if (0 < (int)param_3[1]) {
      do {
        FUN_1404fb410(param_1 + 0x1c0,&local_1570,param_3 + (longlong)(int)uVar18 + 2);
        puVar5 = local_1570;
        local_1600 = *(longlong *)(param_1 + 0x1f0);
        if ((local_1570 == (ulonglong *)0x0) || (local_1570 != *(ulonglong **)(param_1 + 0x1c0))) {
          _invalid_parameter_noinfo();
        }
        lVar16 = local_1568;
        if (local_1568 != local_1600) {
          if (puVar5 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar19 = 0;
          }
          else {
            uVar19 = *puVar5;
          }
          if (lVar16 == *(longlong *)(uVar19 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar9 = *(longlong **)(lVar16 + 0x20);
          (**(code **)(*plVar9 + 0x88))(plVar9,*param_3 == 1);
        }
        uVar20 = (int)uVar18 + 1;
        uVar18 = (ulonglong)uVar20;
      } while ((int)uVar20 < (int)param_3[1]);
    }
    break;
  case 0x7542:
    FUN_1404fb410(param_1 + 0x1c0,&local_15a0);
    lVar16 = *(longlong *)(param_1 + 0x1f0);
    if ((local_15a0 == (longlong *)0x0) || (local_15a0 != *(longlong **)(param_1 + 0x1c0))) {
      _invalid_parameter_noinfo();
    }
    if (local_1598 != lVar16) {
      if (local_15a0 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar16 = 0;
      }
      else {
        lVar16 = *local_15a0;
      }
      if (local_1598 == *(longlong *)(lVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      (**(code **)(**(longlong **)(local_1598 + 0x20) + 0x70))();
    }
    break;
  case 0x756c:
    if (*(char *)(param_1 + 0x208) == '\0') {
      if (DAT_140949790 != '\0') {
        log_InlineLogERROR("compiletime timeout.");
      }
      return 1;
    }
    CTickAnalyst::CTickAnalyst(local_1530,0x25);
    lVar16 = *(longlong *)(param_3 + 2);
    if (lVar16 == -1) {
      CTickAnalyst::~CTickAnalyst(local_1530);
    }
    else {
      uVar20 = *param_3;
      if (uVar20 == 0) {
        if (((DAT_1409758f4 == 0) && (*(ulonglong *)(param_1 + 0x1f8) < 0x2000)) &&
           (plVar9 = (longlong *)FUN_140501030(param_1,lVar16,0), plVar9 != (longlong *)0x0)) {
          do {
            DAT_140976574 = DAT_140976574 + 1;
            if (0xffff < DAT_140976574) {
              DAT_140976574 = 1;
            }
            lVar16 = *(longlong *)(param_1 + 0x1f0);
            lVar3 = *(longlong *)(param_1 + 0x1c0);
            local_1488 = lVar3;
            plVar10 = (longlong *)
                      FUN_1404fb410((longlong *)(param_1 + 0x1c0),local_1468,&DAT_140976574);
            if ((*plVar10 == 0) || (*plVar10 != lVar3)) {
              _invalid_parameter_noinfo();
            }
          } while (plVar10[1] != lVar16);
          puVar13 = (undefined8 *)FUN_1404fc4f0(param_1 + 0x1c0,&DAT_140976574);
          *puVar13 = plVar9;
          local_1620 = (**(code **)(*plVar9 + 0x38))(plVar9);
          puVar13 = (undefined8 *)FUN_1404fc3b0(param_1 + 0x138,&local_1620);
          *puVar13 = plVar9;
          puVar14 = (undefined4 *)FUN_140053460(param_1 + 0x180,&DAT_140976574);
          *puVar14 = 2;
          if (0x1fff < *(ulonglong *)(param_1 + 0x1f8)) {
            log_InlineLogERROR(&DAT_140795ce8,0x2000);
          }
          (**(code **)(*plVar9 + 0x98))(plVar9,DAT_140976574);
          FUN_140500a70(plVar9);
          local_1458[0] = '\0';
          local_1458._1_8_ = 0;
          local_144f = 0;
          local_1447 = 0;
          local_143f = 0;
          local_143b = 0;
          local_1439 = 0;
          uVar7 = (**(code **)(*plVar9 + 0x30))(plVar9);
          local_1678 = (uint *)CONCAT44(local_1678._4_4_,uVar7);
          _snprintf(local_1458,0x1f,"%u %u",(ulonglong)DAT_140976574);
          lVar16 = -1;
          pcVar22 = local_1458;
          do {
            if (lVar16 == 0) break;
            lVar16 = lVar16 + -1;
            cVar2 = *pcVar22;
            pcVar22 = pcVar22 + 1;
          } while (cVar2 != '\0');
          local_1678 = (uint *)local_1458;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),2,0x4e2a,~(uint)lVar16);
        }
      }
      else if (uVar20 == 1) {
        if (*(longlong *)(param_1 + 0xd0) == 0) {
          plVar9 = (longlong *)FUN_140501030(param_1,lVar16,1);
          if (plVar9 == (longlong *)0x0) {
            Ordinal_3(*(undefined8 *)(param_3 + 2));
            log_InlineLogERROR("CSocketKernel::ProcessMsg cannot accept NPC server connection");
          }
          else {
            *(longlong **)(param_1 + 0xd0) = plVar9;
            uVar11 = (**(code **)(*plVar9 + 0x38))(plVar9);
            log_InlineLogMessage("NPC server connected via socket %u",uVar11);
          }
        }
      }
      else if (uVar20 == 2) {
        plVar9 = (longlong *)FUN_140501030(param_1,lVar16,2);
        if (plVar9 == (longlong *)0x0) {
          log_InlineLogERROR("CSocketKernel::ProcessMsg cannot accept GM via socket %u",
                             *(undefined8 *)(param_3 + 2));
          Ordinal_3(*(undefined8 *)(param_3 + 2));
        }
        else {
          uVar7 = (**(code **)(*plVar9 + 0x30))(plVar9);
          local_1648 = *(longlong *)(param_1 + 0x128);
          lVar16 = *(longlong *)(param_1 + 0xf8);
          local_15f8 = uVar7;
          local_14f8 = lVar16;
          plVar10 = (longlong *)FUN_140077480((longlong *)(param_1 + 0xf8),local_1478,&local_15f8);
          if ((lVar16 == 0) || (lVar16 != *plVar10)) {
            _invalid_parameter_noinfo();
          }
          if (local_1648 == plVar10[1]) {
            (**(code **)(*plVar9 + 0x28))(plVar9);
            FUN_140500650(plVar9);
            uVar11 = Ordinal_12(uVar7);
            tq::SysLogSave("miantuxing_error","Rejected illegal GM from %s via socket %u",uVar11,
                           *(undefined8 *)(param_3 + 2));
          }
          else if (*(longlong **)(param_1 + 200) == (longlong *)0x0) {
            *(longlong **)(param_1 + 200) = plVar9;
            uVar11 = Ordinal_12(uVar7);
            log_InlineLogMessage
                      ("Accepted GM from %s via socket %u",uVar11,*(undefined8 *)(param_3 + 2));
          }
          else {
            uVar8 = (**(code **)(**(longlong **)(param_1 + 200) + 0x30))();
            uVar11 = (**(code **)(**(longlong **)(param_1 + 200) + 0x38))();
            uVar12 = Ordinal_12(uVar8);
            log_InlineLogWARNING("Disconnect GM from %s via socket %u",uVar12,uVar11);
            (**(code **)(**(longlong **)(param_1 + 200) + 0x28))();
            FUN_140500650(*(undefined8 *)(param_1 + 200));
            *(undefined8 *)(param_1 + 200) = 0;
            (**(code **)(*plVar9 + 0x28))(plVar9);
            FUN_140500650(plVar9);
            uVar11 = Ordinal_12(uVar7);
            log_InlineLogWARNING
                      ("Rejected GM from %s via socket %u",uVar11,*(undefined8 *)(param_3 + 2));
          }
        }
      }
      CTickAnalyst::~CTickAnalyst(local_1530);
    }
    break;
  case 0x756d:
    CTickAnalyst::CTickAnalyst(local_1510,0x26);
    if (*(longlong *)(param_3 + 2) == -1) {
      CTickAnalyst::~CTickAnalyst(local_1510);
    }
    else {
      switch(*param_3) {
      case 0:
        lVar16 = FUN_1404fc2d0(param_1);
        if ((lVar16 != 0) && (iVar17 = FUN_140500e60(lVar16), 0 < iVar17)) {
          FUN_1404fd1a0(param_1,lVar16);
        }
        break;
      case 1:
        if (*(longlong *)(param_1 + 0xd0) != 0) {
          FUN_140500140();
        }
        break;
      case 2:
        if (*(longlong *)(param_1 + 200) != 0) {
          FUN_140500140();
        }
        break;
      case 3:
        if (*(longlong **)(param_1 + 0xd8) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xd8) + 0x30))();
        }
        break;
      case 4:
        if (*(longlong **)(param_1 + 0xe0) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xe0) + 0x30))();
        }
        break;
      case 5:
        if (*(longlong **)(param_1 + 0xe8) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x30))();
        }
        break;
      case 6:
        if (*(longlong **)(param_1 + 0xf0) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x30))();
        }
      }
      CTickAnalyst::~CTickAnalyst(local_1510);
    }
    break;
  case 0x756e:
    CTickAnalyst::CTickAnalyst(local_14e8,0x27);
    if (*(longlong *)(param_3 + 2) == -1) {
      CTickAnalyst::~CTickAnalyst(local_14e8);
    }
    else {
      switch(*param_3) {
      case 0:
        plVar9 = (longlong *)FUN_1404fc2d0(param_1,*(undefined8 *)(param_3 + 2));
        if (plVar9 != (longlong *)0x0) {
          local_165c._0_4_ = FUN_140500a30(plVar9);
          FUN_1404fcfd0(param_1,local_165c._0_4_);
          (**(code **)(*plVar9 + 0x28))(plVar9);
          FUN_140500650(plVar9);
          FUN_140050de0(param_1 + 0x180,local_165c);
          FUN_1404fc620(param_1 + 0x1c0,local_165c);
          local_1678 = (uint *)local_165c;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),2,0x4e31,0xea65);
        }
        break;
      case 1:
        if (*(longlong **)(param_1 + 0xd0) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xd0) + 0x28))();
          FUN_140500650(*(undefined8 *)(param_1 + 0xd0));
          *(undefined8 *)(param_1 + 0xd0) = 0;
          log_InlineLogMessage("NPC server disconnected");
          lVar16 = -1;
          pcVar22 = "NPC server connection broken";
          do {
            if (lVar16 == 0) break;
            lVar16 = lVar16 + -1;
            cVar2 = *pcVar22;
            pcVar22 = pcVar22 + 1;
          } while (cVar2 != '\0');
          local_1678 = (uint *)0x140795cb0;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),0,0x9c41,~(uint)lVar16);
        }
        break;
      case 2:
        if (*(longlong **)(param_1 + 200) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 200) + 0x28))();
          FUN_140500650(*(undefined8 *)(param_1 + 200));
          *(undefined8 *)(param_1 + 200) = 0;
          log_InlineLogMessage("GM socket disconnected");
          local_1648 = 0x100010000;
          local_1678 = (uint *)&local_1648;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),0xe,0x3fa,8);
        }
        break;
      case 3:
        if (*(longlong **)(param_1 + 0xd8) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xd8) + 0x68))();
          local_1608[0] = 0;
          local_1678 = local_1608;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),2,0x4e33,0xea65);
        }
        break;
      case 4:
        if (*(longlong **)(param_1 + 0xe0) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xe0) + 0x68))();
          local_1618[0] = 0;
          local_1678 = local_1618;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),0xb,0x16763,0xea65);
        }
        break;
      case 5:
        if (*(longlong **)(param_1 + 0xe8) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x68))();
          local_1628[0] = 0;
          local_1678 = local_1628;
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),9,0x186a8,0xea65);
        }
        break;
      case 6:
        if (*(longlong **)(param_1 + 0xf0) != (longlong *)0x0) {
          (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x68))();
          local_165c._4_4_ = 0;
          local_1678 = (uint *)(local_165c + 4);
          (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                    (*(longlong **)(param_1 + 0x88),6,0x11173,0xea65);
        }
      }
      CTickAnalyst::~CTickAnalyst(local_14e8);
    }
    break;
  case 0x756f:
    uVar20 = *param_3;
    local_1660 = 1;
    if (uVar20 == 3) {
      local_1678 = &local_1660;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),2,0x4e33,0xea65);
    }
    else if (uVar20 == 4) {
      local_1678 = &local_1660;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),0xb,0x16763,0xea65);
    }
    else if (uVar20 == 5) {
      local_1678 = &local_1660;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),9,0x186a8,0xea65);
    }
    else if (uVar20 == 6) {
      local_1678 = &local_1660;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),6,0x11173,0xea65);
    }
    break;
  case 0x7570:
    if ((param_3 == (uint *)0x0) || (param_3 + 1 == (uint *)0x0)) {
      log_InlineLogERROR("CSocketKernel::ProcessMsg, SOCKET_LIBEVENT_ACCOUNT_WRITEMSG null packet");
    }
    else {
      plVar9 = *(longlong **)(param_1 + 0xd8);
      if (plVar9 != (longlong *)0x0) {
        (**(code **)(*plVar9 + 0x50))(plVar9,param_3 + 1,*param_3,1);
        LOCK();
        DAT_140975758 = DAT_140975758 + *param_3;
        UNLOCK();
        LOCK();
        DAT_1409757a8 = DAT_1409757a8 + *param_3;
        UNLOCK();
        LOCK();
        DAT_1409757ac = DAT_1409757ac + 1;
        UNLOCK();
      }
    }
    break;
  case 0x7571:
    if ((param_3 == (uint *)0x0) || (param_3 + 1 == (uint *)0x0)) {
      log_InlineLogERROR("CSocketKernel::ProcessMsg, SOCKET_LIBEVENT_CHGSVR_WRITEMSG null packet");
    }
    else {
      plVar9 = *(longlong **)(param_1 + 0xe0);
      if (plVar9 != (longlong *)0x0) {
        (**(code **)(*plVar9 + 0x50))(plVar9,param_3 + 1,*param_3,1);
      }
    }
    break;
  case 0x7572:
    if ((param_3 == (uint *)0x0) || (param_3 + 1 == (uint *)0x0)) {
      log_InlineLogERROR("CSocketKernel::ProcessMsg, SOCKET_LIBEVENT_IPADSVR_WRITEMSG null packet");
    }
    else {
      plVar9 = *(longlong **)(param_1 + 0xe8);
      if (plVar9 != (longlong *)0x0) {
        (**(code **)(*plVar9 + 0x50))(plVar9,param_3 + 1,*param_3,1);
      }
    }
    break;
  case 0x7573:
    if ((param_3 == (uint *)0x0) || (param_3 + 1 == (uint *)0x0)) {
      log_InlineLogERROR("CSocketKernel::ProcessMsg, SOCKET_LIBEVENT_CSSVR_WRITEMSG null packet");
    }
    else {
      plVar9 = *(longlong **)(param_1 + 0xf0);
      if (plVar9 != (longlong *)0x0) {
        (**(code **)(*plVar9 + 0x50))(plVar9,param_3 + 1,*param_3,1);
      }
    }
  }
  *(undefined1 *)(param_1 + 0x208) = 1;
  return 1;
}

// ==== CSocketKernel::vfunc_4  @1404fee40  [high:rtti-vtable]  (orig: FUN_1404fee40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404fee40(longlong param_1)

{
  int *piVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  ulong uVar5;
  __time32_t _Var6;
  int iVar7;
  uint uVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  char *pcVar13;
  undefined1 auStack_e8 [32];
  char *local_c8;
  undefined4 local_b8;
  undefined4 local_b4 [3];
  longlong *local_a8;
  longlong *plStack_a0;
  char local_98 [8];
  undefined4 local_90;
  int local_8c;
  undefined4 local_88;
  longlong *local_78;
  longlong *plStack_70;
  undefined1 local_68 [16];
  char local_58 [32];
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  uVar5 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x210) + *(int *)(param_1 + 0x20c)) <= uVar5 / 1000) {
    uVar5 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x210) = uVar5 / 1000;
    piVar1 = (int *)(param_1 + 0x214);
    *piVar1 = *piVar1 + -1;
    if (*piVar1 < 0) {
      local_c8 = (char *)local_b4;
      local_b4[0] = 0;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),0xe,0x2731,0xea65);
      if (DAT_140949790 == '\0') {
        local_58[0] = '\0';
        local_58[1] = '\0';
        local_58[2] = '\0';
        local_58[3] = '\0';
        local_58[4] = '\0';
        local_58[5] = '\0';
        local_58[6] = '\0';
        local_58[7] = '\0';
        local_58[8] = '\0';
        local_58[9] = '\0';
        local_58[10] = '\0';
        local_58[0xb] = '\0';
        local_58[0xc] = '\0';
        local_58[0xd] = '\0';
        local_58[0xe] = '\0';
        local_58[0xf] = '\0';
        local_58[0x10] = '\0';
        local_58[0x11] = '\0';
        local_58[0x12] = '\0';
        local_58[0x13] = '\0';
        local_58[0x14] = '\0';
        local_58[0x15] = '\0';
        local_58[0x16] = '\0';
        local_58[0x17] = '\0';
        local_58[0x18] = '\0';
        local_58[0x19] = '\0';
        local_58[0x1a] = '\0';
        local_58[0x1b] = '\0';
        local_58[0x1c] = '\0';
        local_58[0x1d] = '\0';
        local_58[0x1e] = '\0';
        local_58[0x1f] = 0;
        _Var6 = _time32((__time32_t *)0x0);
        tq::DateTime(local_58,(longlong)_Var6);
        log_InlineLogMessage("current message: %s");
      }
      else {
        log_InlineLogERROR("heart beat timeout.");
      }
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
  }
  uVar5 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0xc) + *(int *)(param_1 + 0x10)) <= uVar5 / 1000) {
    uVar5 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x10) = uVar5 / 1000;
    plVar11 = *(longlong **)(param_1 + 0x1c0);
    plVar12 = (longlong *)**(undefined8 **)(param_1 + 0x1f0);
    while( true ) {
      plVar2 = *(longlong **)(param_1 + 0x1f0);
      if ((plVar11 == (longlong *)0x0) || (plVar11 != *(longlong **)(param_1 + 0x1c0))) {
        _invalid_parameter_noinfo();
      }
      if (plVar12 == plVar2) break;
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar11;
      }
      if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar2 = (longlong *)plVar12[4];
      iVar7 = (**(code **)(*plVar2 + 0x68))();
      if (*(int *)(param_1 + 8) <= iVar7) {
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar11;
        }
        if (plVar12 == *(longlong **)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_90 = (undefined4)plVar12[3];
        local_8c = iVar7;
        local_88 = (**(code **)(*plVar2 + 0x30))(plVar2);
        local_c8 = (char *)&local_90;
        (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                  (*(longlong **)(param_1 + 0x88),0xe,0x2741,0xc);
      }
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar12 + 0x29) == '\0') {
        plVar2 = (longlong *)plVar12[2];
        if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
          cVar4 = *(char *)(*plVar2 + 0x29);
          plVar12 = plVar2;
          plVar2 = (longlong *)*plVar2;
          while (cVar4 == '\0') {
            cVar4 = *(char *)(*plVar2 + 0x29);
            plVar12 = plVar2;
            plVar2 = (longlong *)*plVar2;
          }
        }
        else {
          cVar4 = *(char *)(plVar12[1] + 0x29);
          plVar3 = (longlong *)plVar12[1];
          plVar2 = plVar12;
          while ((plVar12 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar12[2]))) {
            cVar4 = *(char *)(plVar12[1] + 0x29);
            plVar3 = (longlong *)plVar12[1];
            plVar2 = plVar12;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  uVar5 = tq::TimeGet(0);
  local_a8 = *(longlong **)(param_1 + 0x1c0);
  plVar11 = (longlong *)**(longlong **)(param_1 + 0x1f0);
  plVar12 = local_a8;
  plStack_a0 = (longlong *)**(longlong **)(param_1 + 0x1f0);
  while( true ) {
    plVar2 = *(longlong **)(param_1 + 0x1f0);
    if ((plVar12 == (longlong *)0x0) || (plVar12 != *(longlong **)(param_1 + 0x1c0))) {
      _invalid_parameter_noinfo();
    }
    if (plVar11 == plVar2) break;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar12;
    }
    if (plVar11 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)plVar11[4];
    cVar4 = (**(code **)(*plVar2 + 0x20))(plVar2);
    if (cVar4 == '\0') {
      iVar7 = (**(code **)(*plVar2 + 0x48))(plVar2);
      LOCK();
      DAT_140975744 = DAT_140975744 + iVar7;
      UNLOCK();
      LOCK();
      DAT_140975740 = DAT_140975740 + 1;
      UNLOCK();
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar12;
      }
      if (plVar11 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_b8 = (undefined4)plVar11[3];
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar12;
      }
      if (plVar11 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1404fcfd0(param_1);
      FUN_140500650(plVar2);
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar12;
      }
      if (plVar11 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_140050de0(param_1 + 0x180,plVar11 + 3);
      local_78 = local_a8;
      plStack_70 = plStack_a0;
      puVar9 = (undefined8 *)FUN_1404fb050(param_1 + 0x1c0,local_68,&local_78);
      local_a8 = (longlong *)*puVar9;
      plStack_a0 = (longlong *)puVar9[1];
      local_c8 = (char *)&local_b8;
      (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
                (*(longlong **)(param_1 + 0x88),2,0x4e31,0xea65);
      plVar11 = plStack_a0;
      plVar12 = local_a8;
    }
    else {
      cVar4 = (**(code **)(*plVar2 + 0x58))(plVar2);
      if (cVar4 == '\0') {
        iVar7 = (**(code **)(*plVar2 + 0x50))(plVar2);
        if (40000 < uVar5 - iVar7) {
          uVar8 = (**(code **)(*plVar2 + 0x30))(plVar2);
          if (uVar8 == 0) {
            log_InlineLogMessage("CSocketKernel::OnTimer shake hand timeout");
          }
          else {
            local_c8 = (char *)CONCAT44(local_c8._4_4_,uVar8 >> 0x18);
            log_InlineLogMessage("CSocketKernel::OnTimer %d.%d.%d.%d shake hand timeout");
          }
          (**(code **)(*plVar2 + 0x28))(plVar2);
        }
      }
      else {
        cVar4 = FUN_140500130(plVar2);
        FUN_1404fd1a0(param_1);
        if (cVar4 != '\0') {
          FUN_140500e60(plVar2);
        }
      }
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
        plVar2 = (longlong *)plVar11[2];
        if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
          cVar4 = *(char *)(*plVar2 + 0x29);
          plVar11 = plVar2;
          plVar2 = (longlong *)*plVar2;
          while (plStack_a0 = plVar11, cVar4 == '\0') {
            cVar4 = *(char *)(*plVar2 + 0x29);
            plVar11 = plVar2;
            plVar2 = (longlong *)*plVar2;
          }
        }
        else {
          cVar4 = *(char *)(plVar11[1] + 0x29);
          plVar3 = (longlong *)plVar11[1];
          plVar2 = plVar11;
          while ((plVar11 = plVar3, plStack_a0 = plVar11, cVar4 == '\0' &&
                 (plVar2 == (longlong *)plVar11[2]))) {
            cVar4 = *(char *)(plVar11[1] + 0x29);
            plVar3 = (longlong *)plVar11[1];
            plVar2 = plVar11;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  if ((*(longlong **)(param_1 + 0xd0) != (longlong *)0x0) &&
     (cVar4 = (**(code **)(**(longlong **)(param_1 + 0xd0) + 0x20))(), cVar4 == '\0')) {
    lVar10 = -1;
    pcVar13 = "NPC server connection broken";
    do {
      if (lVar10 == 0) break;
      lVar10 = lVar10 + -1;
      cVar4 = *pcVar13;
      pcVar13 = pcVar13 + 1;
    } while (cVar4 != '\0');
    local_c8 = "NPC server connection broken";
    (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
              (*(longlong **)(param_1 + 0x88),0,0x9c41,~(uint)lVar10);
    FUN_140500650(*(undefined8 *)(param_1 + 0xd0));
    *(undefined8 *)(param_1 + 0xd0) = 0;
  }
  if ((*(longlong **)(param_1 + 200) != (longlong *)0x0) &&
     (cVar4 = (**(code **)(**(longlong **)(param_1 + 200) + 0x20))(), cVar4 == '\0')) {
    log_InlineLogMessage("GM socket disconnected");
    local_c8 = local_98;
    local_98[0] = '\0';
    local_98[1] = '\0';
    local_98[2] = '\x01';
    local_98[3] = '\0';
    local_98[4] = '\x01';
    local_98[5] = '\0';
    local_98[6] = '\0';
    local_98[7] = '\0';
    (**(code **)(**(longlong **)(param_1 + 0x88) + 0x50))
              (*(longlong **)(param_1 + 0x88),0xe,0x3fa,8);
    FUN_140500650(*(undefined8 *)(param_1 + 200));
    *(undefined8 *)(param_1 + 200) = 0;
  }
  if (*(longlong **)(param_1 + 0xd8) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0xd8) + 0x20))();
  }
  if (*(longlong **)(param_1 + 0xe0) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0xe0) + 0x20))();
  }
  if (*(longlong **)(param_1 + 0xe8) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0xe8) + 0x20))();
  }
  if (*(longlong **)(param_1 + 0xf0) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0xf0) + 0x20))();
  }
  return 1;
}

// ==== CSocketKernel::helper_1404ff530  @1404ff530  [medium:callgraph-r0]  (orig: FUN_1404ff530)
undefined8 * FUN_1404ff530(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1404f8c80(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CSocketKernel::helper_1404ff5b0  @1404ff5b0  [medium:callgraph-r0]  (orig: FUN_1404ff5b0)
undefined8 * FUN_1404ff5b0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1404f8d60(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CSocketKernel::ctor_or_dtor  @1404ff630  [high:vtable-assign]  (orig: FUN_1404ff630)
undefined8 * FUN_1404ff630(undefined8 *param_1)

{
  *param_1 = ISocketKernel::vftable;
  *param_1 = CSocketKernel::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  FUN_140500c80(param_1 + 0x13);
  FUN_140500c80(param_1 + 0x15);
  FUN_140500c80(param_1 + 0x17);
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  FUN_14000ef40(param_1 + 0x1f);
  FUN_1404ff530(param_1 + 0x27);
  param_1[0x2f] = 0;
  FUN_1400546e0(param_1 + 0x30);
  FUN_1404ff5b0(param_1 + 0x38);
  *(undefined4 *)((longlong)param_1 + 0x20c) = 0;
  *(undefined4 *)(param_1 + 0x42) = 0;
  param_1[0x40] = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  param_1[4] = param_1;
  *(undefined4 *)(param_1 + 5) = 1;
  param_1[6] = param_1;
  *(undefined4 *)(param_1 + 7) = 2;
  param_1[8] = param_1;
  *(undefined4 *)(param_1 + 9) = 3;
  param_1[10] = param_1;
  *(undefined4 *)(param_1 + 0xb) = 4;
  param_1[0xc] = param_1;
  *(undefined4 *)(param_1 + 0xd) = 5;
  param_1[0xe] = param_1;
  *(undefined4 *)(param_1 + 0xf) = 6;
  param_1[0x10] = param_1;
  return param_1;
}

// ==== CSocketKernel::helper_1404fffd0  @1404fffd0  [medium:callgraph-r1]  (orig: FUN_1404fffd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1404fffd0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 auStack_448 [32];
  undefined8 local_428;
  undefined1 local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  uVar3 = FUN_1404f7250(param_1[0x11f]);
  lVar4 = FUN_1405497f0(uVar3,param_1[0x120],3);
  param_1[0x121] = lVar4;
  if (lVar4 == 0) {
    uVar5 = Ordinal_3(param_1[0x120]);
    return uVar5 & 0xffffffffffffff00;
  }
  local_428 = FUN_1404f7290(param_1[0x11f],*(undefined4 *)((longlong)param_1 + 0x14));
  FUN_140543e60(param_1[0x121],FUN_1404f8200,&DAT_1404f7230,FUN_1404f8290);
  FUN_140544280(param_1[0x121],2,0,0x800);
  iVar2 = FUN_1405455c0(param_1[0x121],6);
  if (iVar2 == -1) {
    FUN_140545950(param_1[0x120]);
    log_InlineLogERROR("CServerSocket::Init bufferevent_enable error[%d].");
  }
  else if ((*(int *)((longlong)param_1 + 0x14) != 0) ||
          ((iVar2 = FUN_140504890((longlong)param_1 + 0x824,local_418,0x400), 0 < iVar2 &&
           (cVar1 = (**(code **)(*param_1 + 0x18))(param_1,local_418,iVar2), cVar1 != '\0')))) {
    *(undefined4 *)(param_1 + 2) = 0;
    *(undefined4 *)((longlong)param_1 + 0xc) = 0;
    return 1;
  }
  uVar5 = FUN_140544e70(param_1[0x121]);
  return uVar5 & 0xffffffffffffff00;
}

// ==== CSocketKernel::helper_140500130  @140500130  [medium:callgraph-r0]  (orig: FUN_140500130)
bool FUN_140500130(longlong param_1)

{
  return 0x7ff < *(int *)(param_1 + 8);
}

// ==== CSocketKernel::helper_140500140  @140500140  [medium:callgraph-r0]  (orig: FUN_140500140)
void FUN_140500140(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  int iVar3;
  int iVar4;
  
  if ((*(longlong *)(param_1 + 0x908) != 0) && (lVar1 = *(longlong *)(param_1 + 0x8f8), lVar1 != 0))
  {
    if (0x7ff < *(int *)(param_1 + 8)) {
      if (*(int *)(param_1 + 0x14) == 1) {
        FUN_1404f72e0(lVar1);
      }
      else {
        if (*(int *)(param_1 + 0x14) != 2) {
                    /* WARNING: Could not recover jumptable at 0x000140500198. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          log_InlineLogERROR("CSocketKernel::ProcessAllIncoming m_nEvType(%d) not find at %s, %d");
          return;
        }
        FUN_1404f74a0(lVar1);
      }
    }
    uVar2 = FUN_140543f80(*(undefined8 *)(param_1 + 0x908));
    iVar3 = FUN_14054a780(uVar2);
    if (0 < iVar3) {
      while( true ) {
        iVar4 = 0x800 - *(int *)(param_1 + 8);
        if (iVar3 <= iVar4) {
          iVar4 = iVar3;
        }
        iVar4 = FUN_140544040(*(undefined8 *)(param_1 + 0x908),
                              (longlong)*(int *)(param_1 + 8) + 0x1b + param_1,(longlong)iVar4);
        if (iVar4 < 1) break;
        *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + iVar4;
        if (*(int *)(param_1 + 0x14) == 1) {
          FUN_1404f72e0(*(undefined8 *)(param_1 + 0x8f8));
        }
        else {
          if (*(int *)(param_1 + 0x14) != 2) {
                    /* WARNING: Could not recover jumptable at 0x000140500271. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            log_InlineLogERROR("CSocketKernel::ProcessAllIncoming m_nEvType(%d) not find at %s, %d")
            ;
            return;
          }
          FUN_1404f74a0(*(undefined8 *)(param_1 + 0x8f8));
        }
        iVar3 = iVar3 - iVar4;
        if (iVar3 < 1) {
          return;
        }
      }
      log_InlineLogERROR(
                        "CSocketKernel::ProcessAllIncoming m_nEvType[%d] can not drain the buffer for socket %u"
                        );
    }
  }
  return;
}

// ==== CSocketKernel::helper_1405002a0  @1405002a0  [medium:callgraph-r1]  (orig: FUN_1405002a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405002a0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined1 auStack_838 [32];
  undefined1 local_818 [2048];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_838;
  if ((int)param_1[1] < 0xc) {
    return 1;
  }
  iVar2 = FUN_140505bc0((longlong)param_1 + 0x824,(longlong)param_1 + 0x1b);
  if (iVar2 != 0) {
    if (iVar2 < 0) {
      return 0;
    }
    (**(code **)(*param_1 + 0x10))(param_1,iVar2);
    *(undefined1 *)((longlong)param_1 + 0x1a) = 1;
    if (0 < (int)param_1[1]) {
      cVar1 = FUN_140504bf0((longlong)param_1 + 0x824,(longlong)param_1 + 0x1b,local_818);
      if (cVar1 == '\0') {
        return 0;
      }
      memcpy((void *)((longlong)param_1 + 0x1b),local_818,(longlong)(int)param_1[1]);
    }
  }
  return 1;
}

// ==== CSocketKernel::helper_140500650  @140500650  [medium:callgraph-r0]  (orig: FUN_140500650)
void FUN_140500650(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CSocketKernel::helper_140500a30  @140500a30  [medium:callgraph-r0]  (orig: FUN_140500a30)
undefined4 FUN_140500a30(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x8c0);
}

// ==== CSocketKernel::helper_140500a70  @140500a70  [medium:callgraph-r0]  (orig: FUN_140500a70)
void FUN_140500a70(longlong param_1)

{
  _SYSTEMTIME local_18;
  
  GetLocalTime(&local_18);
  FUN_140311d10(param_1 + 0x8c8,"%d%02d%02d:%02d%02d%02d.%03d",local_18.wYear,local_18.wMonth,
                local_18.wDay,local_18.wHour,local_18.wMinute,local_18.wSecond,
                local_18.wMilliseconds);
  return;
}

// ==== CSocketKernel::helper_140500e60  @140500e60  [medium:callgraph-r0]  (orig: FUN_140500e60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140500e60(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  int iVar4;
  undefined1 auStack_848 [32];
  uint local_828;
  undefined4 local_820;
  undefined1 local_818;
  undefined1 local_817 [2047];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_848;
  if (param_1[0x121] == 0) {
    return -1;
  }
  if ((int)param_1[1] < 0x800) {
    uVar3 = FUN_140543f80();
    iVar2 = FUN_14054a780(uVar3);
    if (0 < iVar2) {
      iVar4 = 0x800 - (int)param_1[1];
      local_818 = 0;
      if (iVar2 <= iVar4) {
        iVar4 = iVar2;
      }
      memset(local_817,0,0x7ff);
      iVar2 = FUN_140544040(param_1[0x121],&local_818,(longlong)iVar4);
      if (iVar2 < 1) {
        log_InlineLogERROR(
                          "CSocketKernel::ProcessClientIncoming can not drain the buffer for socket %u"
                          );
        return -1;
      }
      cVar1 = (**(code **)(*param_1 + 0x58))(param_1);
      if (cVar1 != '\0') {
        cVar1 = FUN_140504bf0((longlong)param_1 + 0x824,&local_818,
                              (longlong)(int)param_1[1] + 0x1b + (longlong)param_1,iVar2);
        if (cVar1 != '\0') {
          *(int *)(param_1 + 1) = (int)param_1[1] + iVar2;
          return iVar2;
        }
        log_InlineLogERROR("CSocketKernel::ProcessClientIncoming decryption failed for socket %u");
        (**(code **)(*param_1 + 0x28))(param_1);
        return -1;
      }
      memcpy((void *)((longlong)(int)param_1[1] + 0x1b + (longlong)param_1),&local_818,
             (longlong)iVar2);
      *(int *)(param_1 + 1) = (int)param_1[1] + iVar2;
      cVar1 = FUN_1405002a0(param_1);
      if (cVar1 != '\0') {
        return iVar2;
      }
      local_828 = (**(code **)(*param_1 + 0x30))(param_1);
      if (local_828 != 0) {
        local_828 = local_828 >> 0x18;
        local_820 = 0x121;
        log_InlineLogMessage
                  ("CServerSocket::ProcessIncomingPacket shake hand failed IP=%d.%d.%d.%d @%d");
        (**(code **)(*param_1 + 0x28))(param_1);
        return -1;
      }
      log_InlineLogMessage("CServerSocket::ProcessClientIncoming shake hand failed @%d");
      (**(code **)(*param_1 + 0x28))(param_1);
    }
  }
  return -1;
}

// ==== CSocketKernel::helper_140501030  @140501030  [medium:callgraph-r0]  (orig: FUN_140501030)
longlong * FUN_140501030(undefined8 param_1,undefined8 param_2,undefined1 param_3)

{
  char cVar1;
  void *pvVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  if ((DAT_140976580 & 1) == 0) {
    DAT_140976580 = DAT_140976580 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976578,"CServerSocket");
    atexit((_func_5014 *)&LAB_1406d6f60);
  }
  pvVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_140976578,0x910);
  if (pvVar2 == (void *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = (longlong *)FUN_140500d30(pvVar2,param_1,param_2,param_3,uVar4);
  }
  if ((plVar3 != (longlong *)0x0) && (cVar1 = FUN_1404fffd0(plVar3), cVar1 == '\0')) {
    (**(code **)(*plVar3 + 0x28))(plVar3);
    (**(code **)*plVar3)(plVar3,1);
    plVar3 = (longlong *)0x0;
  }
  return plVar3;
}

// ==== CSocketKernel::helper_140501100  @140501100  [medium:callgraph-r2]  (orig: FUN_140501100)
void FUN_140501100(longlong param_1,byte *param_2,byte *param_3)

{
  int iVar1;
  exception local_28 [40];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_28,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_28,(ThrowInfo *)&DAT_1409446e8);
  }
  iVar1 = 0;
  if (0 < *(int *)(param_1 + 0x3d0)) {
    do {
      iVar1 = iVar1 + 1;
      *param_2 = *param_2 ^ *param_3;
      param_3 = param_3 + 1;
      param_2 = param_2 + 1;
    } while (iVar1 < *(int *)(param_1 + 0x3d0));
  }
  return;
}

// ==== CSocketKernel::helper_140501190  @140501190  [medium:callgraph-r1]  (orig: FUN_140501190)
void FUN_140501190(longlong param_1,byte *param_2,void *param_3,int param_4,int param_5)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  uint *puVar5;
  void *pvVar6;
  int iVar7;
  longlong lVar8;
  ulonglong uVar9;
  int iVar10;
  int iVar11;
  uint *puVar12;
  byte *pbVar13;
  undefined4 *puVar14;
  longlong lVar15;
  longlong lVar16;
  char *local_res10;
  exception local_40 [24];
  
  if (param_2 == (byte *)0x0) {
    local_res10 = "Empty key";
    std::exception::exception(local_40,&local_res10);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_40,(ThrowInfo *)&DAT_1409446e8);
  }
  if (((param_4 != 0x10) && (param_4 != 0x18)) && (param_4 != 0x20)) {
    local_res10 = "Incorrect key length";
    std::exception::exception(local_40,&local_res10);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_40,(ThrowInfo *)&DAT_1409446e8);
  }
  if (((param_5 != 0x10) && (param_5 != 0x18)) && (param_5 != 0x20)) {
    local_res10 = "Incorrect block length";
    std::exception::exception(local_40,&local_res10);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_40,(ThrowInfo *)&DAT_1409446e8);
  }
  *(int *)(param_1 + 0x3cc) = param_4;
  *(int *)(param_1 + 0x3d0) = param_5;
  memcpy((void *)(param_1 + 0x3d8),param_3,(longlong)param_5);
  memcpy((void *)(param_1 + 0x3f8),param_3,(longlong)*(int *)(param_1 + 0x3d0));
  if (*(int *)(param_1 + 0x3cc) == 0x10) {
    if (*(int *)(param_1 + 0x3d0) == 0x10) {
      uVar2 = 10;
    }
    else {
      uVar2 = 0xe;
      if (*(int *)(param_1 + 0x3d0) == 0x18) {
        uVar2 = 0xc;
      }
    }
    *(undefined4 *)(param_1 + 0x3d4) = uVar2;
  }
  else if (*(int *)(param_1 + 0x3cc) == 0x18) {
    uVar2 = 0xe;
    if (*(int *)(param_1 + 0x3d0) != 0x20) {
      uVar2 = 0xc;
    }
    *(undefined4 *)(param_1 + 0x3d4) = uVar2;
  }
  else {
    *(undefined4 *)(param_1 + 0x3d4) = 0xe;
  }
  iVar7 = 0;
  iVar3 = (int)(*(int *)(param_1 + 0x3d0) + (*(int *)(param_1 + 0x3d0) >> 0x1f & 3U)) >> 2;
  lVar15 = (longlong)iVar3;
  if (-1 < *(int *)(param_1 + 0x3d4)) {
    pvVar6 = (void *)(param_1 + 0xc);
    do {
      if (0 < iVar3) {
        memset(pvVar6,0,lVar15 << 2);
      }
      iVar7 = iVar7 + 1;
      pvVar6 = (void *)((longlong)pvVar6 + 0x20);
    } while (iVar7 <= *(int *)(param_1 + 0x3d4));
  }
  iVar7 = 0;
  if (-1 < *(int *)(param_1 + 0x3d4)) {
    pvVar6 = (void *)(param_1 + 0x1ec);
    do {
      if (0 < iVar3) {
        memset(pvVar6,0,lVar15 << 2);
      }
      iVar7 = iVar7 + 1;
      pvVar6 = (void *)((longlong)pvVar6 + 0x20);
    } while (iVar7 <= *(int *)(param_1 + 0x3d4));
  }
  iVar7 = (*(int *)(param_1 + 0x3d4) + 1) * iVar3;
  uVar4 = (int)(*(int *)(param_1 + 0x3cc) + (*(int *)(param_1 + 0x3cc) >> 0x1f & 3U)) >> 2;
  lVar16 = (longlong)(int)uVar4;
  if (0 < (int)uVar4) {
    uVar9 = (ulonglong)uVar4;
    puVar5 = (uint *)(param_1 + 0x418);
    do {
      *puVar5 = (uint)*param_2 << 0x18;
      *puVar5 = *puVar5 | (uint)param_2[1] << 0x10;
      *puVar5 = *puVar5 | (uint)param_2[2] << 8;
      *puVar5 = *puVar5 | (uint)param_2[3];
      uVar9 = uVar9 - 1;
      puVar5 = puVar5 + 1;
      param_2 = param_2 + 4;
    } while (uVar9 != 0);
  }
  lVar8 = 0;
  iVar11 = 0;
  if (0 < (int)uVar4) {
    puVar14 = (undefined4 *)(param_1 + 0x418);
    iVar10 = 0;
    do {
      iVar11 = iVar10;
      if (iVar7 <= iVar10) break;
      lVar8 = lVar8 + 1;
      iVar11 = iVar10 + 1;
      *(undefined4 *)
       (param_1 + 0xc + ((longlong)(iVar10 % iVar3) + (longlong)(iVar10 / iVar3) * 8) * 4) =
           *puVar14;
      *(undefined4 *)
       (param_1 + 0x1ec +
       ((longlong)(iVar10 % iVar3) +
       ((longlong)*(int *)(param_1 + 0x3d4) - (longlong)(iVar10 / iVar3)) * 8) * 4) = *puVar14;
      puVar14 = puVar14 + 1;
      iVar10 = iVar11;
    } while (lVar8 < lVar16);
  }
  if (iVar11 < iVar7) {
    pbVar13 = &DAT_14079a430;
    do {
      uVar1 = *(uint *)(param_1 + 0x414 + lVar16 * 4);
      uVar9 = (ulonglong)(int)uVar1;
      *(uint *)(param_1 + 0x418) =
           *(uint *)(param_1 + 0x418) ^
           CONCAT31(CONCAT21(CONCAT11((&DAT_140797230)[(longlong)uVar9 >> 0x10 & 0xff] ^ *pbVar13,
                                      (&DAT_140797230)[(longlong)uVar9 >> 8 & 0xff]),
                             (&DAT_140797230)[uVar9 & 0xff]),(&DAT_140797230)[uVar1 >> 0x18]);
      if (uVar4 == 8) {
        lVar8 = 3;
        puVar5 = (uint *)(param_1 + 0x41c);
        do {
          *puVar5 = *puVar5 ^ puVar5[-1];
          lVar8 = lVar8 + -1;
          puVar5 = puVar5 + 1;
        } while (lVar8 != 0);
        uVar9 = (ulonglong)(int)*(uint *)(param_1 + 0x424);
        *(uint *)(param_1 + 0x428) =
             *(uint *)(param_1 + 0x428) ^
             CONCAT31(CONCAT21(CONCAT11((&DAT_140797230)[*(uint *)(param_1 + 0x424) >> 0x18],
                                        (&DAT_140797230)[(longlong)uVar9 >> 0x10 & 0xff]),
                               (&DAT_140797230)[(longlong)uVar9 >> 8 & 0xff]),
                      (&DAT_140797230)[uVar9 & 0xff]);
        lVar8 = 3;
        puVar5 = (uint *)(param_1 + 0x42c);
        do {
          *puVar5 = *puVar5 ^ puVar5[-1];
          lVar8 = lVar8 + -1;
          puVar5 = puVar5 + 1;
        } while (lVar8 != 0);
      }
      else if (1 < lVar16) {
        lVar8 = lVar16 + -1;
        puVar5 = (uint *)(param_1 + 0x41c);
        do {
          *puVar5 = *puVar5 ^ puVar5[-1];
          lVar8 = lVar8 + -1;
          puVar5 = puVar5 + 1;
        } while (lVar8 != 0);
      }
      lVar8 = 0;
      if (0 < (int)uVar4) {
        puVar14 = (undefined4 *)(param_1 + 0x418);
        iVar10 = iVar11;
        do {
          if (iVar7 <= iVar10) goto LAB_140501637;
          lVar8 = lVar8 + 1;
          iVar11 = iVar10 + 1;
          *(undefined4 *)
           (param_1 + 0xc + ((longlong)(iVar10 % iVar3) + (longlong)(iVar10 / iVar3) * 8) * 4) =
               *puVar14;
          *(undefined4 *)
           (param_1 + 0x1ec +
           ((longlong)(iVar10 % iVar3) +
           ((longlong)*(int *)(param_1 + 0x3d4) - (longlong)(iVar10 / iVar3)) * 8) * 4) = *puVar14;
          puVar14 = puVar14 + 1;
          iVar10 = iVar11;
        } while (lVar8 < lVar16);
      }
      pbVar13 = pbVar13 + 1;
    } while (iVar11 < iVar7);
  }
LAB_140501637:
  iVar3 = 1;
  if (1 < *(int *)(param_1 + 0x3d4)) {
    puVar5 = (uint *)(param_1 + 0x20c);
    do {
      puVar12 = puVar5;
      lVar16 = lVar15;
      if (0 < lVar15) {
        do {
          uVar9 = (ulonglong)(int)*puVar12;
          lVar16 = lVar16 + -1;
          *puVar12 = *(uint *)(&DAT_140799430 + (ulonglong)(*puVar12 >> 0x18) * 4) ^
                     *(uint *)(&DAT_140799830 + ((longlong)uVar9 >> 0x10 & 0xffU) * 4) ^
                     *(uint *)(&DAT_140799c30 + ((longlong)uVar9 >> 8 & 0xffU) * 4) ^
                     *(uint *)(&DAT_14079a030 + (uVar9 & 0xff) * 4);
          puVar12 = puVar12 + 1;
        } while (lVar16 != 0);
      }
      iVar3 = iVar3 + 1;
      puVar5 = puVar5 + 8;
    } while (iVar3 < *(int *)(param_1 + 0x3d4));
  }
  *(undefined1 *)(param_1 + 8) = 1;
  return;
}

// ==== CSocketKernel::helper_1405016f0  @1405016f0  [medium:callgraph-r3]  (orig: FUN_1405016f0)
void FUN_1405016f0(longlong param_1,byte *param_2,byte *param_3)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong lVar9;
  ulonglong uVar10;
  uint uVar11;
  int iVar12;
  ulonglong uVar13;
  exception local_48 [32];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_48,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_1409446e8);
  }
  uVar2 = ((uint)*param_2 << 0x18 | (uint)param_2[1] << 0x10 | (uint)param_2[2] << 8 |
          (uint)param_2[3]) ^ *(uint *)(param_1 + 0xc);
  iVar12 = *(int *)(param_1 + 0x3d4);
  uVar4 = ((uint)param_2[4] << 0x18 | (uint)param_2[5] << 0x10 | (uint)param_2[6] << 8 |
          (uint)param_2[7]) ^ *(uint *)(param_1 + 0x10);
  uVar3 = ((uint)param_2[8] << 0x18 | (uint)param_2[9] << 0x10 | (uint)param_2[10] << 8 |
          (uint)param_2[0xb]) ^ *(uint *)(param_1 + 0x14);
  uVar11 = ((uint)CONCAT11(param_2[0xe],param_2[0xf]) |
           (uint)param_2[0xc] << 0x18 | (uint)param_2[0xd] << 0x10) ^ *(uint *)(param_1 + 0x18);
  if (1 < iVar12) {
    uVar13 = (ulonglong)(iVar12 - 1);
    puVar5 = (uint *)(param_1 + 0x34);
    do {
      uVar7 = (ulonglong)(int)uVar4;
      uVar8 = (ulonglong)(int)uVar3;
      uVar10 = (ulonglong)(int)uVar11;
      uVar6 = (ulonglong)(int)uVar2;
      uVar4 = *(uint *)(&DAT_140797430 + ((longlong)uVar7 >> 0x18 & 0xffU) * 4) ^
              *(uint *)(&DAT_140797830 + ((longlong)uVar8 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140797c30 + ((longlong)uVar10 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798030 + (uVar6 & 0xff) * 4) ^ puVar5[-1];
      uVar3 = *(uint *)(&DAT_140797c30 + ((longlong)uVar6 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140797430 + ((longlong)uVar8 >> 0x18 & 0xffU) * 4) ^
              *(uint *)(&DAT_140797830 + ((longlong)uVar10 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798030 + (uVar7 & 0xff) * 4) ^ *puVar5;
      uVar11 = *(uint *)(&DAT_140797830 + ((longlong)uVar6 >> 0x10 & 0xffU) * 4) ^
               *(uint *)(&DAT_140797c30 + ((longlong)uVar7 >> 8 & 0xffU) * 4) ^
               *(uint *)(&DAT_140797430 + ((longlong)uVar10 >> 0x18 & 0xffU) * 4) ^
               *(uint *)(&DAT_140798030 + (uVar8 & 0xff) * 4) ^ puVar5[1];
      uVar2 = *(uint *)(&DAT_140797430 + (ulonglong)(uVar2 >> 0x18) * 4) ^
              *(uint *)(&DAT_140797830 + ((longlong)uVar7 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140797c30 + ((longlong)uVar8 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798030 + (uVar10 & 0xff) * 4) ^ puVar5[-2];
      uVar13 = uVar13 - 1;
      puVar5 = puVar5 + 8;
    } while (uVar13 != 0);
    iVar12 = *(int *)(param_1 + 0x3d4);
  }
  uVar6 = (ulonglong)(int)uVar2;
  lVar9 = (longlong)iVar12 * 0x20;
  uVar8 = (ulonglong)(int)uVar3;
  uVar13 = (ulonglong)(int)uVar4;
  uVar1 = *(undefined4 *)(lVar9 + 0xc + param_1);
  uVar7 = (ulonglong)(int)uVar11;
  *param_3 = (&DAT_140797230)[(longlong)uVar6 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[1] = (&DAT_140797230)[(longlong)uVar13 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[2] = (&DAT_140797230)[(longlong)uVar8 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[3] = (&DAT_140797230)[uVar7 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar9 + 0x10 + param_1);
  param_3[4] = (&DAT_140797230)[(longlong)uVar13 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[5] = (&DAT_140797230)[(longlong)uVar8 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[6] = (&DAT_140797230)[(longlong)uVar7 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[7] = (&DAT_140797230)[uVar6 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar9 + 0x14 + param_1);
  param_3[8] = (&DAT_140797230)[(longlong)uVar8 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[9] = (&DAT_140797230)[(longlong)uVar7 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[10] = (&DAT_140797230)[(longlong)uVar6 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[0xb] = (&DAT_140797230)[uVar13 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar9 + 0x18 + param_1);
  param_3[0xc] = (&DAT_140797230)[(longlong)uVar7 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[0xd] = (&DAT_140797230)[(longlong)uVar6 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[0xe] = (&DAT_140797230)[(longlong)uVar13 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[0xf] = (&DAT_140797230)[uVar8 & 0xff] ^ (byte)uVar1;
  return;
}

// ==== CSocketKernel::helper_140501b50  @140501b50  [medium:callgraph-r3]  (orig: FUN_140501b50)
void FUN_140501b50(longlong param_1,byte *param_2,byte *param_3)

{
  undefined4 uVar1;
  uint *puVar2;
  longlong lVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint uVar11;
  int iVar12;
  ulonglong uVar13;
  exception local_48 [32];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_48,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_1409446e8);
  }
  iVar12 = *(int *)(param_1 + 0x3d4);
  uVar6 = ((uint)*param_2 << 0x18 | (uint)param_2[1] << 0x10 | (uint)param_2[2] << 8 |
          (uint)param_2[3]) ^ *(uint *)(param_1 + 0x1ec);
  uVar5 = ((uint)param_2[4] << 0x18 | (uint)param_2[5] << 0x10 | (uint)param_2[6] << 8 |
          (uint)param_2[7]) ^ *(uint *)(param_1 + 0x1f0);
  uVar4 = ((uint)param_2[8] << 0x18 | (uint)param_2[9] << 0x10 | (uint)param_2[10] << 8 |
          (uint)param_2[0xb]) ^ *(uint *)(param_1 + 500);
  uVar11 = ((uint)CONCAT11(param_2[0xe],param_2[0xf]) |
           (uint)param_2[0xc] << 0x18 | (uint)param_2[0xd] << 0x10) ^ *(uint *)(param_1 + 0x1f8);
  if (1 < iVar12) {
    uVar13 = (ulonglong)(iVar12 - 1);
    puVar2 = (uint *)(param_1 + 0x214);
    do {
      uVar10 = (ulonglong)(int)uVar5;
      uVar9 = (ulonglong)(int)uVar11;
      uVar8 = (ulonglong)(int)uVar4;
      uVar7 = (ulonglong)(int)uVar6;
      uVar5 = *(uint *)(&DAT_140798830 + ((longlong)uVar7 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798430 + ((longlong)uVar10 >> 0x18 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798c30 + ((longlong)uVar9 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140799030 + (uVar8 & 0xff) * 4) ^ puVar2[-1];
      uVar4 = *(uint *)(&DAT_140798430 + ((longlong)uVar8 >> 0x18 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798c30 + ((longlong)uVar7 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798830 + ((longlong)uVar10 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140799030 + (uVar9 & 0xff) * 4) ^ *puVar2;
      uVar11 = *(uint *)(&DAT_140798830 + ((longlong)uVar8 >> 0x10 & 0xffU) * 4) ^
               *(uint *)(&DAT_140798c30 + ((longlong)uVar10 >> 8 & 0xffU) * 4) ^
               *(uint *)(&DAT_140798430 + ((longlong)uVar9 >> 0x18 & 0xffU) * 4) ^
               *(uint *)(&DAT_140799030 + (uVar7 & 0xff) * 4) ^ puVar2[1];
      uVar6 = *(uint *)(&DAT_140798430 + (ulonglong)(uVar6 >> 0x18) * 4) ^
              *(uint *)(&DAT_140798c30 + ((longlong)uVar8 >> 8 & 0xffU) * 4) ^
              *(uint *)(&DAT_140798830 + ((longlong)uVar9 >> 0x10 & 0xffU) * 4) ^
              *(uint *)(&DAT_140799030 + (uVar10 & 0xff) * 4) ^ puVar2[-2];
      uVar13 = uVar13 - 1;
      puVar2 = puVar2 + 8;
    } while (uVar13 != 0);
    iVar12 = *(int *)(param_1 + 0x3d4);
  }
  uVar13 = (ulonglong)(int)uVar6;
  lVar3 = (longlong)iVar12 * 0x20;
  uVar8 = (ulonglong)(int)uVar4;
  uVar9 = (ulonglong)(int)uVar11;
  uVar1 = *(undefined4 *)(lVar3 + 0x1ec + param_1);
  uVar7 = (ulonglong)(int)uVar5;
  *param_3 = (&DAT_140797330)[(longlong)uVar13 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[1] = (&DAT_140797330)[(longlong)uVar9 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[2] = (&DAT_140797330)[(longlong)uVar8 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[3] = (&DAT_140797330)[uVar7 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar3 + 0x1f0 + param_1);
  param_3[4] = (&DAT_140797330)[(longlong)uVar7 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[5] = (&DAT_140797330)[(longlong)uVar13 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[6] = (&DAT_140797330)[(longlong)uVar9 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[7] = (&DAT_140797330)[uVar8 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar3 + 500 + param_1);
  param_3[8] = (&DAT_140797330)[(longlong)uVar8 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[9] = (&DAT_140797330)[(longlong)uVar7 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[10] = (&DAT_140797330)[(longlong)uVar13 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[0xb] = (&DAT_140797330)[uVar9 & 0xff] ^ (byte)uVar1;
  uVar1 = *(undefined4 *)(lVar3 + 0x1f8 + param_1);
  param_3[0xc] = (&DAT_140797330)[(longlong)uVar9 >> 0x18 & 0xff] ^ (byte)((uint)uVar1 >> 0x18);
  param_3[0xd] = (&DAT_140797330)[(longlong)uVar8 >> 0x10 & 0xff] ^ (byte)((uint)uVar1 >> 0x10);
  param_3[0xe] = (&DAT_140797330)[(longlong)uVar7 >> 8 & 0xff] ^ (byte)((uint)uVar1 >> 8);
  param_3[0xf] = (&DAT_140797330)[uVar13 & 0xff] ^ (byte)uVar1;
  return;
}

// ==== CSocketKernel::helper_140501fd0  @140501fd0  [medium:callgraph-r2]  (orig: FUN_140501fd0)
void FUN_140501fd0(longlong param_1,byte *param_2,byte *param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  uint *puVar6;
  uint *puVar7;
  longlong lVar8;
  int iVar9;
  longlong lVar10;
  int iVar11;
  int iVar12;
  uint *puVar13;
  int local_res8;
  exception local_50 [24];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_50,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_50,(ThrowInfo *)&DAT_1409446e8);
  }
  iVar3 = *(int *)(param_1 + 0x3d0);
  if (iVar3 != 0x10) {
    iVar3 = (int)(iVar3 + (iVar3 >> 0x1f & 3U)) >> 2;
    lVar10 = (longlong)iVar3;
    if (iVar3 == 4) {
      iVar4 = 0;
    }
    else {
      iVar4 = (iVar3 != 6) + 1;
    }
    lVar5 = (longlong)iVar4 * 0x20;
    iVar4 = *(int *)(&DAT_14079a458 + lVar5);
    iVar9 = *(int *)(&DAT_14079a460 + lVar5);
    iVar12 = *(int *)(&DAT_14079a468 + lVar5);
    if (0 < iVar3) {
      puVar6 = (uint *)(param_1 + 0x458);
      puVar7 = (uint *)(param_1 + 0xc);
      lVar5 = lVar10;
      do {
        *puVar6 = (uint)*param_2 << 0x18;
        *puVar6 = *puVar6 | (uint)param_2[1] << 0x10;
        *puVar6 = *puVar6 | (uint)param_2[2] << 8;
        *puVar6 = *puVar6 | (uint)param_2[3];
        *puVar6 = *puVar6 ^ *puVar7;
        lVar5 = lVar5 + -1;
        puVar6 = puVar6 + 1;
        puVar7 = puVar7 + 1;
        param_2 = param_2 + 4;
      } while (lVar5 != 0);
    }
    local_res8 = 1;
    if (1 < *(int *)(param_1 + 0x3d4)) {
      puVar6 = (uint *)(param_1 + 0x2c);
      do {
        if (0 < lVar10) {
          lVar5 = lVar10;
          puVar7 = (uint *)(param_1 + 0x438);
          puVar13 = puVar6;
          iVar11 = iVar4;
          do {
            lVar5 = lVar5 + -1;
            *puVar7 = *(uint *)(&DAT_140797c30 +
                               ((longlong)
                                (ulonglong)
                                *(uint *)(param_1 + 0x458 +
                                         (longlong)(((iVar9 - iVar4) + iVar11) % iVar3) * 4) >> 8 &
                               0xffU) * 4) ^
                      *(uint *)(&DAT_140798030 +
                               (ulonglong)
                               *(byte *)(param_1 + 0x458 +
                                        (longlong)(((iVar12 - iVar4) + iVar11) % iVar3) * 4) * 4) ^
                      *(uint *)(&DAT_140797830 +
                               ((longlong)
                                (ulonglong)
                                *(uint *)(param_1 + 0x458 + (longlong)(iVar11 % iVar3) * 4) >> 0x10
                               & 0xffU) * 4) ^
                      *(uint *)(&DAT_140797430 + (ulonglong)*(byte *)((longlong)puVar7 + 0x23) * 4)
                      ^ *puVar13;
            puVar7 = puVar7 + 1;
            puVar13 = puVar13 + 1;
            iVar11 = iVar11 + 1;
          } while (lVar5 != 0);
        }
        memcpy((void *)(param_1 + 0x458),(void *)(param_1 + 0x438),(longlong)(iVar3 * 4));
        local_res8 = local_res8 + 1;
        puVar6 = puVar6 + 8;
      } while (local_res8 < *(int *)(param_1 + 0x3d4));
    }
    if (0 < lVar10) {
      iVar4 = iVar4 - iVar9;
      iVar12 = iVar12 - iVar9;
      lVar8 = 0;
      lVar5 = param_1 + 0x458;
      do {
        lVar1 = lVar8 + (longlong)*(int *)(param_1 + 0x3d4) * 8;
        lVar8 = lVar8 + 1;
        uVar2 = *(undefined4 *)(param_1 + 0xc + lVar1 * 4);
        *param_3 = (&DAT_140797230)[*(byte *)(lVar5 + 3)] ^ (byte)((uint)uVar2 >> 0x18);
        param_3[1] = (&DAT_140797230)
                     [(longlong)
                      (ulonglong)
                      *(uint *)(param_1 + 0x458 + (longlong)((iVar4 + iVar9) % iVar3) * 4) >> 0x10 &
                      0xff] ^ (byte)((uint)uVar2 >> 0x10);
        param_3[2] = (&DAT_140797230)
                     [(longlong)
                      (ulonglong)*(uint *)(param_1 + 0x458 + (longlong)(iVar9 % iVar3) * 4) >> 8 &
                      0xff] ^ (byte)((uint)uVar2 >> 8);
        iVar11 = iVar12 + iVar9;
        iVar9 = iVar9 + 1;
        param_3[3] = (&DAT_140797230)[*(byte *)(param_1 + 0x458 + (longlong)(iVar11 % iVar3) * 4)] ^
                     (byte)uVar2;
        param_3 = param_3 + 4;
        lVar5 = lVar5 + 4;
      } while (lVar8 < lVar10);
    }
    return;
  }
  FUN_1405016f0();
  return;
}

// ==== CSocketKernel::helper_140502360  @140502360  [medium:callgraph-r2]  (orig: FUN_140502360)
void FUN_140502360(longlong param_1,byte *param_2,byte *param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  uint *puVar6;
  uint *puVar7;
  longlong lVar8;
  int iVar9;
  longlong lVar10;
  int iVar11;
  int iVar12;
  uint *puVar13;
  int local_res8;
  exception local_50 [24];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_50,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_50,(ThrowInfo *)&DAT_1409446e8);
  }
  iVar3 = *(int *)(param_1 + 0x3d0);
  if (iVar3 != 0x10) {
    iVar3 = (int)(iVar3 + (iVar3 >> 0x1f & 3U)) >> 2;
    lVar10 = (longlong)iVar3;
    if (iVar3 == 4) {
      iVar4 = 0;
    }
    else {
      iVar4 = (iVar3 != 6) + 1;
    }
    lVar5 = (longlong)iVar4 * 0x20;
    iVar4 = *(int *)(&DAT_14079a45c + lVar5);
    iVar9 = *(int *)(&DAT_14079a464 + lVar5);
    iVar12 = *(int *)(&DAT_14079a46c + lVar5);
    if (0 < iVar3) {
      puVar6 = (uint *)(param_1 + 0x458);
      puVar7 = (uint *)(param_1 + 0x1ec);
      lVar5 = lVar10;
      do {
        *puVar6 = (uint)*param_2 << 0x18;
        *puVar6 = *puVar6 | (uint)param_2[1] << 0x10;
        *puVar6 = *puVar6 | (uint)param_2[2] << 8;
        *puVar6 = *puVar6 | (uint)param_2[3];
        *puVar6 = *puVar6 ^ *puVar7;
        lVar5 = lVar5 + -1;
        puVar6 = puVar6 + 1;
        puVar7 = puVar7 + 1;
        param_2 = param_2 + 4;
      } while (lVar5 != 0);
    }
    local_res8 = 1;
    if (1 < *(int *)(param_1 + 0x3d4)) {
      puVar6 = (uint *)(param_1 + 0x20c);
      do {
        if (0 < lVar10) {
          lVar5 = lVar10;
          puVar7 = (uint *)(param_1 + 0x438);
          puVar13 = puVar6;
          iVar11 = iVar4;
          do {
            lVar5 = lVar5 + -1;
            *puVar7 = *(uint *)(&DAT_140798c30 +
                               ((longlong)
                                (ulonglong)
                                *(uint *)(param_1 + 0x458 +
                                         (longlong)(((iVar9 - iVar4) + iVar11) % iVar3) * 4) >> 8 &
                               0xffU) * 4) ^
                      *(uint *)(&DAT_140799030 +
                               (ulonglong)
                               *(byte *)(param_1 + 0x458 +
                                        (longlong)(((iVar12 - iVar4) + iVar11) % iVar3) * 4) * 4) ^
                      *(uint *)(&DAT_140798830 +
                               ((longlong)
                                (ulonglong)
                                *(uint *)(param_1 + 0x458 + (longlong)(iVar11 % iVar3) * 4) >> 0x10
                               & 0xffU) * 4) ^
                      *(uint *)(&DAT_140798430 + (ulonglong)*(byte *)((longlong)puVar7 + 0x23) * 4)
                      ^ *puVar13;
            puVar7 = puVar7 + 1;
            puVar13 = puVar13 + 1;
            iVar11 = iVar11 + 1;
          } while (lVar5 != 0);
        }
        memcpy((void *)(param_1 + 0x458),(void *)(param_1 + 0x438),(longlong)(iVar3 * 4));
        local_res8 = local_res8 + 1;
        puVar6 = puVar6 + 8;
      } while (local_res8 < *(int *)(param_1 + 0x3d4));
    }
    if (0 < lVar10) {
      iVar4 = iVar4 - iVar9;
      iVar12 = iVar12 - iVar9;
      lVar8 = 0;
      lVar5 = param_1 + 0x458;
      do {
        lVar1 = lVar8 + (longlong)*(int *)(param_1 + 0x3d4) * 8;
        lVar8 = lVar8 + 1;
        uVar2 = *(undefined4 *)(param_1 + 0x1ec + lVar1 * 4);
        *param_3 = (&DAT_140797330)[*(byte *)(lVar5 + 3)] ^ (byte)((uint)uVar2 >> 0x18);
        param_3[1] = (&DAT_140797330)
                     [(longlong)
                      (ulonglong)
                      *(uint *)(param_1 + 0x458 + (longlong)((iVar4 + iVar9) % iVar3) * 4) >> 0x10 &
                      0xff] ^ (byte)((uint)uVar2 >> 0x10);
        param_3[2] = (&DAT_140797330)
                     [(longlong)
                      (ulonglong)*(uint *)(param_1 + 0x458 + (longlong)(iVar9 % iVar3) * 4) >> 8 &
                      0xff] ^ (byte)((uint)uVar2 >> 8);
        iVar11 = iVar12 + iVar9;
        iVar9 = iVar9 + 1;
        param_3[3] = (&DAT_140797330)[*(byte *)(param_1 + 0x458 + (longlong)(iVar11 % iVar3) * 4)] ^
                     (byte)uVar2;
        param_3 = param_3 + 4;
        lVar5 = lVar5 + 4;
      } while (lVar8 < lVar10);
    }
    return;
  }
  FUN_140501b50();
  return;
}

// ==== CSocketKernel::helper_1405028e0  @1405028e0  [medium:callgraph-r1]  (orig: FUN_1405028e0)
void FUN_1405028e0(longlong param_1,void *param_2,longlong param_3,ulonglong param_4,int param_5)

{
  int iVar1;
  int iVar2;
  exception local_38 [32];
  
  if (*(char *)(param_1 + 8) == '\0') {
    std::exception::exception(local_38,&PTR_s_Object_not_Initialized_14096fe78);
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_38,(ThrowInfo *)&DAT_1409446e8);
  }
  if ((param_4 != 0) && (param_4 % (ulonglong)(longlong)*(int *)(param_1 + 0x3d0) == 0)) {
    iVar1 = (int)(param_4 / (ulonglong)(longlong)*(int *)(param_1 + 0x3d0));
    if (param_5 == 1) {
      iVar2 = 0;
      if (0 < iVar1) {
        do {
          FUN_140502360(param_1,param_2,param_3);
          FUN_140501100(param_1,param_3,param_1 + 0x3f8);
          memcpy((void *)(param_1 + 0x3f8),param_2,(longlong)*(int *)(param_1 + 0x3d0));
          iVar2 = iVar2 + 1;
          param_2 = (void *)((longlong)param_2 + (longlong)*(int *)(param_1 + 0x3d0));
          param_3 = param_3 + *(int *)(param_1 + 0x3d0);
        } while (iVar2 < (int)(param_4 / (ulonglong)(longlong)*(int *)(param_1 + 0x3d0)));
      }
    }
    else if (param_5 == 2) {
      iVar2 = 0;
      if (0 < iVar1) {
        do {
          FUN_140501fd0(param_1,param_1 + 0x3f8,param_3);
          FUN_140501100(param_1,param_3,param_2);
          memcpy((void *)(param_1 + 0x3f8),param_2,(longlong)*(int *)(param_1 + 0x3d0));
          iVar2 = iVar2 + 1;
          param_2 = (void *)((longlong)param_2 + (longlong)*(int *)(param_1 + 0x3d0));
          param_3 = param_3 + *(int *)(param_1 + 0x3d0);
        } while (iVar2 < (int)(param_4 / (ulonglong)(longlong)*(int *)(param_1 + 0x3d0)));
      }
    }
    else {
      iVar2 = 0;
      if (0 < iVar1) {
        do {
          FUN_140502360(param_1,param_2,param_3);
          iVar2 = iVar2 + 1;
          param_2 = (void *)((longlong)param_2 + (longlong)*(int *)(param_1 + 0x3d0));
          param_3 = param_3 + *(int *)(param_1 + 0x3d0);
        } while (iVar2 < (int)(param_4 / (ulonglong)(longlong)*(int *)(param_1 + 0x3d0)));
      }
    }
    return;
  }
  std::exception::exception(local_38,&PTR_s_Data_not_multiple_of_Block_Size_14096fe80);
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_38,(ThrowInfo *)&DAT_1409446e8);
}

// ==== CSocketKernel::helper_140503aa0  @140503aa0  [medium:callgraph-r3]  (orig: FUN_140503aa0)
void FUN_140503aa0(void *param_1)

{
  if (param_1 != (void *)0x0) {
    operator_delete__(param_1);
  }
  return;
}

// ==== CSocketKernel::helper_140503ac0  @140503ac0  [medium:callgraph-r3]  (orig: FUN_140503ac0)
int FUN_140503ac0(undefined8 param_1,int *param_2,int param_3,void *param_4,int param_5)

{
  int iVar1;
  
  if ((param_2 != (int *)0x0) && (param_4 != (void *)0x0)) {
    if ((0 < param_5) && (param_5 + 4 <= param_3)) {
      iVar1 = *param_2;
      if (-1 < iVar1) {
        if (iVar1 == 0) {
          iVar1 = 4;
        }
        if (iVar1 + 4 + param_5 <= param_3) {
          *(int *)((longlong)iVar1 + (longlong)param_2) = param_5;
          memcpy((void *)((longlong)(iVar1 + 4) + (longlong)param_2),param_4,(longlong)param_5);
          param_5 = iVar1 + 4 + param_5;
          *param_2 = param_5;
          return param_5;
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CSocketKernel::helper_140503c00  @140503c00  [medium:callgraph-r3]  (orig: FUN_140503c00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140503c00(undefined8 param_1,char *param_2)

{
  char cVar1;
  char *_Memory;
  char *pcVar2;
  longlong lVar3;
  ulonglong uVar4;
  char *pcVar5;
  char *pcVar6;
  undefined1 auStack_98 [32];
  char local_78;
  undefined7 uStack_77;
  undefined1 uStack_70;
  undefined7 uStack_6f;
  undefined1 uStack_68;
  undefined7 local_67;
  undefined1 uStack_60;
  undefined7 local_5f;
  undefined1 uStack_58;
  undefined8 local_57;
  undefined8 local_4f;
  undefined8 local_47;
  undefined8 local_3f;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  _Memory = (char *)FUN_140507ca0();
  lVar3 = -1;
  pcVar5 = _Memory;
  do {
    if (lVar3 == 0) break;
    lVar3 = lVar3 + -1;
    cVar1 = *pcVar5;
    pcVar5 = pcVar5 + 1;
  } while (cVar1 != '\0');
  if (lVar3 == -0x22) {
    uStack_58 = 0;
    local_57 = 0;
    local_4f = 0;
    local_47 = 0;
    local_3f = 0;
    local_78 = (char)*(undefined8 *)_Memory;
    uStack_77 = (undefined7)((ulonglong)*(undefined8 *)_Memory >> 8);
    uStack_70 = (undefined1)*(undefined8 *)(_Memory + 8);
    uStack_6f = (undefined7)((ulonglong)*(undefined8 *)(_Memory + 8) >> 8);
    uStack_68 = (undefined1)*(undefined8 *)(_Memory + 0x10);
    local_67 = (undefined7)((ulonglong)*(undefined8 *)(_Memory + 0x10) >> 8);
    uStack_60 = (undefined1)*(undefined8 *)(_Memory + 0x18);
    local_5f = (undefined7)((ulonglong)*(undefined8 *)(_Memory + 0x18) >> 8);
    lVar3 = -1;
    pcVar5 = &local_78;
    do {
      pcVar2 = pcVar5;
      if (lVar3 == 0) break;
      lVar3 = lVar3 + -1;
      pcVar2 = pcVar5 + 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar2;
    } while (cVar1 != '\0');
    lVar3 = 0;
    do {
      cVar1 = _Memory[lVar3];
      pcVar2[lVar3 + -1] = cVar1;
      lVar3 = lVar3 + 1;
    } while (cVar1 != '\0');
    pcVar2 = (char *)FUN_140507ca0();
    lVar3 = -1;
    pcVar5 = pcVar2;
    do {
      if (lVar3 == 0) break;
      lVar3 = lVar3 + -1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (lVar3 == -0x22) {
      lVar3 = -1;
      *(undefined8 *)param_2 = *(undefined8 *)_Memory;
      *(undefined8 *)(param_2 + 8) = *(undefined8 *)(_Memory + 8);
      *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)(_Memory + 0x10);
      *(undefined8 *)(param_2 + 0x18) = *(undefined8 *)(_Memory + 0x18);
      pcVar5 = param_2;
      do {
        pcVar6 = pcVar5;
        if (lVar3 == 0) break;
        lVar3 = lVar3 + -1;
        pcVar6 = pcVar5 + 1;
        cVar1 = *pcVar5;
        pcVar5 = pcVar6;
      } while (cVar1 != '\0');
      lVar3 = 0;
      do {
        cVar1 = pcVar2[lVar3];
        pcVar6[lVar3 + -1] = cVar1;
        lVar3 = lVar3 + 1;
      } while (cVar1 != '\0');
      uVar4 = 0xffffffffffffffff;
      do {
        if (uVar4 == 0) break;
        uVar4 = uVar4 - 1;
        cVar1 = *param_2;
        param_2 = param_2 + 1;
      } while (cVar1 != '\0');
      free(_Memory);
      free(pcVar2);
      uVar4 = ~uVar4 - 1 & 0xffffffff;
    }
    else {
      free(_Memory);
      free(pcVar2);
      uVar4 = 0;
    }
  }
  else {
    free(_Memory);
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CSocketKernel::helper_140504890  @140504890  [medium:callgraph-r2]  (orig: FUN_140504890)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140504890(undefined4 *param_1,longlong param_2,int param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  uint uVar4;
  int iVar5;
  char *pcVar6;
  undefined1 auStack_548 [32];
  undefined8 *local_528;
  undefined4 *local_520;
  undefined4 local_518;
  undefined4 local_508 [4];
  undefined1 local_4f8 [144];
  undefined8 local_468;
  char local_460 [56];
  undefined1 local_428 [11];
  int local_41d [253];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_548;
  if ((((DAT_140976588 != '\0') && (DAT_140976590 != 0)) && (param_2 != 0)) && (0 < param_3)) {
    memset(local_428,0,0x400);
    RAND_bytes(local_428,0xb);
    RAND_bytes(local_460,0x32);
    uVar4 = (int)local_460[0] >> 0x1f;
    local_528._0_4_ = (int)(((int)local_460[0] ^ uVar4) - uVar4) % 0x32;
    if ((int)(uint)local_528 < 10) {
      local_528._0_4_ = (uint)local_528 + 10;
    }
    if (((uint)local_528 & 1 ^ (int)(uint)local_528 >> 0x1f) - ((int)(uint)local_528 >> 0x1f) == 1)
    {
      local_528._0_4_ = (uint)local_528 - 1;
    }
    iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5,local_460);
    if (iVar2 != 0) {
      param_1[1] = 0;
      RAND_bytes(param_1 + 4,8);
      local_528._0_4_ = 8;
      iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5,param_1 + 4);
      if (iVar2 != 0) {
        *param_1 = 0;
        RAND_bytes(param_1 + 2,8);
        local_528._0_4_ = 8;
        iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5,param_1 + 2);
        if (iVar2 != 0) {
          lVar3 = -1;
          pcVar6 = DAT_1409765b0;
          do {
            if (lVar3 == 0) break;
            lVar3 = lVar3 + -1;
            cVar1 = *pcVar6;
            pcVar6 = pcVar6 + 1;
          } while (cVar1 != '\0');
          local_528._0_4_ = ~(uint)lVar3 - 1;
          iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5);
          if (iVar2 != 0) {
            lVar3 = -1;
            pcVar6 = DAT_1409765a0;
            do {
              if (lVar3 == 0) break;
              lVar3 = lVar3 + -1;
              cVar1 = *pcVar6;
              pcVar6 = pcVar6 + 1;
            } while (cVar1 != '\0');
            local_528._0_4_ = ~(uint)lVar3 - 1;
            iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5);
            if (iVar2 != 0) {
              lVar3 = -1;
              pcVar6 = DAT_1409765c0;
              do {
                if (lVar3 == 0) break;
                lVar3 = lVar3 + -1;
                cVar1 = *pcVar6;
                pcVar6 = pcVar6 + 1;
              } while (cVar1 != '\0');
              local_528 = (undefined8 *)CONCAT44(local_528._4_4_,~(uint)lVar3 - 1);
              iVar2 = FUN_140503ac0(param_1,local_41d,0x3f5);
              if (((iVar2 != 0) && (iVar5 = iVar2 + 8, iVar5 < 0x3f6)) && (iVar5 <= param_3 + -0xb))
              {
                *(undefined8 *)((longlong)local_41d + (longlong)iVar2) = 0x7265767265535154;
                local_508[0] = 0;
                local_468 = 0;
                local_41d[0] = iVar5;
                CAST_set_key(local_4f8,0x10,"C238xs65pjy7HU9Q");
                local_520 = local_508;
                local_518 = 1;
                local_528 = &local_468;
                CAST_cfb64_encrypt(local_428,param_2,iVar2 + 0x13,local_4f8);
                return iVar2 + 0x13;
              }
            }
          }
        }
      }
    }
  }
  return 0;
}

// ==== CSocketKernel::helper_140504bf0  @140504bf0  [medium:callgraph-r1]  (orig: FUN_140504bf0)
undefined8 FUN_140504bf0(longlong param_1,longlong param_2,longlong param_3,int param_4)

{
  if ((((DAT_140976588 != '\0') && (DAT_140976590 != 0)) && (param_3 != 0)) &&
     ((param_2 != 0 && (0 < param_4)))) {
    CAST_cfb64_encrypt(param_2,param_3,param_4,param_1 + 0x18,param_1 + 8,param_1,0);
    return 1;
  }
  return 0;
}

// ==== CSocketKernel::helper_1405050f0  @1405050f0  [medium:callgraph-r3]  (orig: FUN_1405050f0)
void FUN_1405050f0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count_d<char,void_(__cdecl*)(char*___ptr64),std::allocator<int>_>::
              vftable;
    puVar1[4] = param_3;
  }
  FUN_140504090(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CSocketKernel::helper_140505300  @140505300  [medium:callgraph-r3]  (orig: FUN_140505300)
void FUN_140505300(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::
              _Ref_count_d<bignum_st,void_(__cdecl*)(bignum_st*___ptr64),std::allocator<int>_>::
              vftable;
    puVar1[4] = param_3;
  }
  FUN_140504800(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CSocketKernel::helper_140505bc0  @140505bc0  [medium:callgraph-r2]  (orig: FUN_140505bc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140505bc0(longlong param_1,longlong param_2,int param_3)

{
  longlong *plVar1;
  int *piVar2;
  undefined1 *_Src;
  longlong *plVar3;
  void *pvVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  int iVar8;
  undefined1 auStack_968 [32];
  undefined8 *local_948;
  undefined4 *local_940;
  undefined4 local_938;
  void *local_928;
  longlong *local_920;
  undefined8 local_918;
  longlong *local_910;
  void *local_908;
  longlong *local_900;
  undefined4 local_8f8 [2];
  longlong local_8f0 [2];
  undefined1 *local_8e0;
  undefined1 local_8d8 [144];
  undefined8 local_848;
  undefined8 uStack_839;
  int local_831;
  undefined1 local_82d [1013];
  undefined1 local_438 [1024];
  ulonglong local_38;
  
  local_8f0[1] = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_968;
  if ((((DAT_140976588 == '\0') || (DAT_140976590 == 0)) || (param_2 == 0)) || (param_3 < 0)) {
    iVar6 = -1;
  }
  else if (param_3 < 0xc) {
    iVar6 = 0;
  }
  else {
    iVar6 = 0;
    local_8f8[0] = 0;
    local_848 = 0;
    CAST_set_key(local_8d8,0x10,"C238xs65pjy7HU9Q");
    local_938 = 0;
    local_940 = local_8f8;
    local_948 = &local_848;
    CAST_cfb64_encrypt(param_2,(longlong)&uStack_839 + 1,0xb,local_8d8);
    lVar7 = (longlong)local_831;
    if ((local_831 < 0x401) && (0xb < local_831)) {
      iVar8 = local_831 + 7;
      if (param_3 < iVar8) {
        iVar6 = 0;
      }
      else {
        local_938 = 0;
        local_940 = local_8f8;
        local_948 = &local_848;
        CAST_cfb64_encrypt(param_2 + 0xb,local_82d,local_831,local_8d8);
        if (*(longlong *)((longlong)&uStack_839 + lVar7) == s_TQClient_14079ae38._0_8_) {
          local_8f0[0] = BN_new();
          if (local_8f0[0] == 0) {
            iVar6 = -1;
          }
          else {
            if ((0 < local_831) && (local_831 < 0x401)) {
              iVar5 = 4;
              do {
                if ((*(int *)(local_82d + (longlong)iVar5 + -4) < 1) ||
                   (iVar5 = iVar5 + 4 + *(int *)(local_82d + (longlong)iVar5 + -4),
                   local_831 < iVar5)) goto LAB_14050617d;
                iVar6 = iVar6 + 1;
              } while (iVar6 < 1);
              _Src = local_82d + iVar5;
              iVar6 = *(int *)(local_82d + (longlong)iVar5 + -4);
              local_8e0 = _Src;
              if ((0 < iVar6) && (iVar5 + 4 + iVar6 <= local_831)) {
                pvVar4 = operator_new__((longlong)(iVar6 + 1));
                local_928 = (void *)0x0;
                local_920 = (longlong *)0x0;
                FUN_1405050f0(&local_928,pvVar4,FUN_140503aa0);
                pvVar4 = local_928;
                if (local_928 == (void *)0x0) {
                  BN_free(local_8f0[0]);
                  plVar3 = local_920;
                  if (local_920 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_920 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_920)(local_920);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_920 + 8))();
                      }
                    }
                  }
                  return -1;
                }
                memset(local_928,0,(longlong)(iVar6 + 1));
                memcpy(pvVar4,_Src,(longlong)iVar6);
                iVar6 = BN_hex2bn(local_8f0,pvVar4);
                local_918 = 0;
                local_910 = (longlong *)0x0;
                FUN_140505300(&local_918,local_8f0[0],BN_free);
                plVar3 = local_910;
                if (iVar6 == 0) {
                  if (local_910 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_910 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_910)(local_910);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_910 + 8))();
                      }
                    }
                  }
                  plVar3 = local_920;
                  if (local_920 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_920 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_920)(local_920);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_920 + 8))();
                      }
                    }
                  }
                  return -1;
                }
                iVar6 = DH_size(DAT_140976590);
                pvVar4 = operator_new__((longlong)(iVar6 + 1));
                local_908 = (void *)0x0;
                local_900 = (longlong *)0x0;
                FUN_1405050f0(&local_908,pvVar4,FUN_140503aa0);
                plVar3 = local_900;
                pvVar4 = local_908;
                if (local_908 == (void *)0x0) {
                  if (local_900 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_900 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_900)(local_900);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_900 + 8))();
                      }
                    }
                  }
                  plVar3 = local_910;
                  if (local_910 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_910 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_910)(local_910);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_910 + 8))();
                      }
                    }
                  }
                  plVar3 = local_920;
                  if (local_920 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_920 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_920)(local_920);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_920 + 8))();
                      }
                    }
                  }
                  return -1;
                }
                memset(local_908,0,(longlong)(iVar6 + 1));
                iVar5 = DH_compute_key(pvVar4,local_918,DAT_140976590);
                plVar3 = local_900;
                if (iVar5 == -1) {
                  if (local_900 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_900 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_900)(local_900);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_900 + 8))();
                      }
                    }
                  }
                  plVar3 = local_910;
                  if (local_910 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_910 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_910)(local_910);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_910 + 8))();
                      }
                    }
                  }
                  plVar3 = local_920;
                  if (local_920 != (longlong *)0x0) {
                    LOCK();
                    plVar1 = local_920 + 2;
                    *(int *)plVar1 = (int)*plVar1 + -1;
                    UNLOCK();
                    if ((int)*plVar1 == 0) {
                      (**(code **)*local_920)(local_920);
                      LOCK();
                      piVar2 = (int *)((longlong)plVar3 + 0x14);
                      *piVar2 = *piVar2 + -1;
                      UNLOCK();
                      if (*piVar2 == 0) {
                        (**(code **)(*local_920 + 8))();
                      }
                    }
                  }
                  return -1;
                }
                memset(local_438,0,0x400);
                iVar5 = FUN_140503c00(param_1,local_438,pvVar4);
                if (iVar5 == 0x40) {
                  CAST_set_key(param_1 + 0x18,0x40,local_438);
                }
                else {
                  CAST_set_key(param_1 + 0x18,iVar6,pvVar4);
                }
                plVar3 = local_900;
                if (local_900 != (longlong *)0x0) {
                  LOCK();
                  plVar1 = local_900 + 2;
                  *(int *)plVar1 = (int)*plVar1 + -1;
                  UNLOCK();
                  if ((int)*plVar1 == 0) {
                    (**(code **)*local_900)(local_900);
                    LOCK();
                    piVar2 = (int *)((longlong)plVar3 + 0x14);
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (*piVar2 == 0) {
                      (**(code **)(*local_900 + 8))();
                    }
                  }
                }
                plVar3 = local_910;
                if (local_910 != (longlong *)0x0) {
                  LOCK();
                  plVar1 = local_910 + 2;
                  *(int *)plVar1 = (int)*plVar1 + -1;
                  UNLOCK();
                  if ((int)*plVar1 == 0) {
                    (**(code **)*local_910)(local_910);
                    LOCK();
                    piVar2 = (int *)((longlong)plVar3 + 0x14);
                    *piVar2 = *piVar2 + -1;
                    UNLOCK();
                    if (*piVar2 == 0) {
                      (**(code **)(*local_910 + 8))();
                    }
                  }
                }
                plVar3 = local_920;
                if (local_920 == (longlong *)0x0) {
                  return iVar8;
                }
                LOCK();
                plVar1 = local_920 + 2;
                *(int *)plVar1 = (int)*plVar1 + -1;
                UNLOCK();
                if ((int)*plVar1 != 0) {
                  return iVar8;
                }
                (**(code **)*local_920)(local_920);
                LOCK();
                piVar2 = (int *)((longlong)plVar3 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 != 0) {
                  return iVar8;
                }
                (**(code **)(*local_920 + 8))();
                return iVar8;
              }
            }
LAB_14050617d:
            BN_free(local_8f0[0]);
            iVar6 = -1;
          }
        }
        else {
          iVar6 = -1;
        }
      }
    }
    else {
      iVar6 = -1;
    }
  }
  return iVar6;
}

// ==== CSocketKernel::helper_140508070  @140508070  [medium:callgraph-r1]  (orig: FUN_140508070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140508070(undefined4 *param_1,char *param_2,int param_3)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  ulonglong uVar5;
  char *pcVar6;
  ulonglong uVar7;
  char cVar8;
  ulonglong uVar9;
  longlong lVar10;
  undefined **ppuVar11;
  undefined1 auStack_468 [32];
  char local_448 [1056];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  local_448[0x20] = '\0';
  memset(local_448 + 0x21,0,0x3ff);
  sprintf(local_448 + 0x20,"%s");
  strncpy(param_2,local_448 + 0x20,(longlong)param_3);
  param_2[(longlong)param_3 - 1] = '\0';
  uVar7 = 0;
  local_448[0] = '\0';
  pcVar4 = local_448 + 0x20;
  cVar8 = local_448[0x20];
  while (cVar8 < '!') {
    pcVar6 = local_448 + 0x20;
    if (cVar8 == '\0') goto LAB_1405081a9;
    pcVar6 = pcVar4 + 1;
    pcVar4 = pcVar4 + 1;
    cVar8 = *pcVar6;
  }
  cVar8 = *pcVar4;
  uVar5 = uVar7;
  uVar9 = uVar7;
  do {
    if ((longlong)uVar5 < 0x20) {
      local_448[uVar5] = cVar8;
      uVar9 = (ulonglong)((int)uVar9 + 1);
      uVar5 = uVar5 + 1;
    }
    cVar8 = pcVar4[1];
    pcVar4 = pcVar4 + 1;
  } while (' ' < cVar8);
  ppuVar11 = &PTR_DAT_140970280;
  iVar3 = (int)uVar9;
  if ((int)uVar9 == 0x20) {
    iVar3 = 0;
  }
  local_448[iVar3] = '\0';
  uVar5 = uVar7;
  do {
    pcVar6 = local_448;
    lVar10 = (longlong)*ppuVar11 - (longlong)pcVar6;
    do {
      cVar8 = *pcVar6;
      cVar2 = pcVar6[lVar10];
      if (cVar8 != cVar2) break;
      pcVar6 = pcVar6 + 1;
    } while (cVar2 != '\0');
    pcVar6 = pcVar4;
    if (cVar8 == cVar2) {
      param_1[4] = (int)uVar5;
      break;
    }
    ppuVar11 = ppuVar11 + 1;
    uVar5 = (ulonglong)((int)uVar5 + 1);
  } while ((longlong)ppuVar11 < 0x1409702e0);
LAB_1405081a9:
  local_448[0] = '\0';
  if (pcVar6 != (char *)0x0) {
    cVar8 = *pcVar6;
    pcVar4 = pcVar6;
    while (cVar8 < '!') {
      if (cVar8 == '\0') goto LAB_140508217;
      pcVar1 = pcVar4 + 1;
      pcVar4 = pcVar4 + 1;
      cVar8 = *pcVar1;
    }
    cVar8 = *pcVar4;
    uVar5 = uVar7;
    uVar9 = uVar7;
    do {
      if ((longlong)uVar5 < 0x20) {
        local_448[uVar5] = cVar8;
        uVar9 = (ulonglong)((int)uVar9 + 1);
        uVar5 = uVar5 + 1;
      }
      iVar3 = (int)uVar9;
      cVar8 = pcVar4[1];
      pcVar4 = pcVar4 + 1;
    } while (' ' < cVar8);
    if (iVar3 == 0x20) {
      iVar3 = 0;
    }
    local_448[iVar3] = '\0';
    iVar3 = atoi(local_448);
    param_1[3] = iVar3;
    pcVar6 = pcVar4;
  }
LAB_140508217:
  local_448[0] = '\0';
  if (pcVar6 != (char *)0x0) {
    cVar8 = *pcVar6;
    while (cVar8 < '!') {
      if (cVar8 == '\0') {
        return;
      }
      pcVar4 = pcVar6 + 1;
      pcVar6 = pcVar6 + 1;
      cVar8 = *pcVar4;
    }
    cVar8 = *pcVar6;
    uVar5 = uVar7;
    do {
      if ((longlong)uVar7 < 0x20) {
        local_448[uVar7] = cVar8;
        uVar5 = (ulonglong)((int)uVar5 + 1);
        uVar7 = uVar7 + 1;
      }
      iVar3 = (int)uVar5;
      cVar8 = pcVar6[1];
      pcVar6 = pcVar6 + 1;
    } while (' ' < cVar8);
    if (iVar3 == 0x20) {
      iVar3 = 0;
    }
    local_448[iVar3] = '\0';
    iVar3 = atoi(local_448);
    param_1[5] = iVar3 + -0x76c;
  }
  return;
}

// ==== CSocketKernel::helper_1405082d0  @1405082d0  [medium:callgraph-r1]  (orig: FUN_1405082d0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_1405082d0(void)

{
  int iVar1;
  HMODULE hModule;
  INT_PTR IVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  byte bVar6;
  undefined1 auStack_2c58 [32];
  undefined4 local_2c38;
  undefined4 local_2c28;
  undefined4 local_2c24 [3];
  longlong local_2c18 [1408];
  ulonglong local_18;
  undefined8 uStack_10;
  
  uStack_10 = 0x1405082e0;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_2c58;
  iVar4 = 0;
  local_2c28 = 0;
  hModule = LoadLibraryA("iphlpapi.dll");
  if (hModule == (HMODULE)0x0) {
    local_2c38 = 0xbc;
    log_InlineLogERROR(&DAT_1406d9c10,"IF_OK","hModule",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\locklib\\serverlock.cpp");
  }
  else {
    _DAT_140976698 = GetProcAddress(hModule,"GetAdaptersInfo");
    local_2c24[0] = 0x2c00;
    IVar2 = (*_DAT_140976698)(local_2c18,local_2c24);
    if ((int)IVar2 != 0) {
      local_2c38 = 199;
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","dwStatus == ERROR_SUCCESS",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\locklib\\serverlock.cpp");
    }
    plVar5 = local_2c18;
    bVar6 = local_2c28._1_1_;
    do {
      iVar1 = Ordinal_11(plVar5 + 0x38);
      if ((iVar4 == 0) || (cVar3 = (char)iVar4, cVar3 == '\n')) {
LAB_1405083e5:
        local_2c28._1_1_ = (byte)((uint)iVar1 >> 8);
        iVar4 = iVar1;
        bVar6 = local_2c28._1_1_;
        local_2c28 = iVar1;
      }
      else if (cVar3 == -0x54) {
        if ((0xf < bVar6) && (bVar6 < 0x20)) goto LAB_1405083e5;
      }
      else if ((cVar3 == -0x40) && (bVar6 == 0xa8)) goto LAB_1405083e5;
      plVar5 = (longlong *)*plVar5;
    } while (plVar5 != (longlong *)0x0);
    FreeLibrary(hModule);
  }
  return iVar4;
}

// ==== CSocketKernel::helper_140508740  @140508740  [medium:callgraph-r0]  (orig: FUN_140508740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140508740(undefined2 param_1,undefined2 param_2)

{
  undefined1 auStack_38 [32];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_38;
  memset(&DAT_1409766d0,0,0x54);
  _DAT_14097671c = param_1;
  _DAT_14097671e = param_2;
  _DAT_140976710 = tq::TimeGet(1);
  FUN_140508070(&DAT_1409766dc,&DAT_1409766d0,0xc);
  DAT_140976720 = FUN_1405082d0();
  return;
}

// ==== CSocketKernel::helper_14053c3b0  @14053c3b0  [medium:callgraph-r1]  (orig: FUN_14053c3b0)
LPCRITICAL_SECTION FUN_14053c3b0(void)

{
  BOOL BVar1;
  LPCRITICAL_SECTION lpCriticalSection;
  
  lpCriticalSection = (LPCRITICAL_SECTION)FUN_14053dc70(0x28);
  if (lpCriticalSection != (LPCRITICAL_SECTION)0x0) {
    BVar1 = InitializeCriticalSectionAndSpinCount(lpCriticalSection,2000);
    if (BVar1 != 0) {
      return lpCriticalSection;
    }
    FUN_14053de00(lpCriticalSection);
  }
  return (LPCRITICAL_SECTION)0x0;
}

// ==== CSocketKernel::helper_14053c400  @14053c400  [medium:callgraph-r1]  (orig: FUN_14053c400)
void FUN_14053c400(LPCRITICAL_SECTION param_1)

{
  DeleteCriticalSection(param_1);
  FUN_14053de00(param_1);
  return;
}

// ==== CSocketKernel::helper_14053c420  @14053c420  [medium:callgraph-r1]  (orig: FUN_14053c420)
bool FUN_14053c420(ulonglong param_1,LPCRITICAL_SECTION param_2)

{
  BOOL BVar1;
  
  if ((param_1 & 0x10) != 0) {
    BVar1 = TryEnterCriticalSection(param_2);
    return BVar1 == 0;
  }
  EnterCriticalSection(param_2);
  return false;
}

// ==== CSocketKernel::helper_14053c450  @14053c450  [medium:callgraph-r1]  (orig: FUN_14053c450)
undefined8 FUN_14053c450(undefined8 param_1,LPCRITICAL_SECTION param_2)

{
  LeaveCriticalSection(param_2);
  return 0;
}

// ==== CSocketKernel::helper_14053c480  @14053c480  [medium:callgraph-r1]  (orig: FUN_14053c480)
undefined8 * FUN_14053c480(void)

{
  BOOL BVar1;
  undefined8 *puVar2;
  HANDLE pvVar3;
  
  puVar2 = (undefined8 *)FUN_14053dc70(0x40);
  if (puVar2 == (undefined8 *)0x0) {
    return (undefined8 *)0x0;
  }
  BVar1 = InitializeCriticalSectionAndSpinCount((LPCRITICAL_SECTION)(puVar2 + 1),2000);
  if (BVar1 != 0) {
    pvVar3 = CreateEventA((LPSECURITY_ATTRIBUTES)0x0,1,0,(LPCSTR)0x0);
    *puVar2 = pvVar3;
    if (pvVar3 != (HANDLE)0x0) {
      *(undefined4 *)(puVar2 + 7) = 0;
      *(undefined4 *)((longlong)puVar2 + 0x34) = 0;
      *(undefined4 *)(puVar2 + 6) = 0;
      return puVar2;
    }
    DeleteCriticalSection((LPCRITICAL_SECTION)(puVar2 + 1));
  }
  FUN_14053de00(puVar2);
  return (undefined8 *)0x0;
}

// ==== CSocketKernel::helper_14053c510  @14053c510  [medium:callgraph-r1]  (orig: FUN_14053c510)
void FUN_14053c510(undefined8 *param_1)

{
  DeleteCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  CloseHandle((HANDLE)*param_1);
  FUN_14053de00(param_1);
  return;
}

// ==== CSocketKernel::helper_14053c540  @14053c540  [medium:callgraph-r1]  (orig: FUN_14053c540)
undefined8 FUN_14053c540(undefined8 *param_1,int param_2)

{
  EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  if (param_2 == 0) {
    *(int *)((longlong)param_1 + 0x34) = *(int *)((longlong)param_1 + 0x34) + 1;
  }
  else {
    *(undefined4 *)((longlong)param_1 + 0x34) = *(undefined4 *)(param_1 + 6);
  }
  *(int *)(param_1 + 7) = *(int *)(param_1 + 7) + 1;
  SetEvent((HANDLE)*param_1);
  LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  return 0;
}

// ==== CSocketKernel::helper_14053c5a0  @14053c5a0  [medium:callgraph-r1]  (orig: FUN_14053c5a0)
undefined4 FUN_14053c5a0(undefined8 *param_1,LPCRITICAL_SECTION param_2,longlong param_3)

{
  int iVar1;
  bool bVar2;
  DWORD DVar3;
  DWORD DVar4;
  undefined4 uVar5;
  DWORD dwMilliseconds;
  DWORD DVar6;
  
  uVar5 = 0xffffffff;
  DVar6 = 0xffffffff;
  bVar2 = true;
  if (param_3 != 0) {
    DVar6 = FUN_14054e800(param_3);
  }
  EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  iVar1 = *(int *)(param_1 + 7);
  *(int *)(param_1 + 6) = *(int *)(param_1 + 6) + 1;
  LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  LeaveCriticalSection(param_2);
  DVar3 = GetTickCount();
  dwMilliseconds = DVar6;
  do {
    DVar4 = WaitForSingleObject((HANDLE)*param_1,dwMilliseconds);
    EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
    if ((*(int *)((longlong)param_1 + 0x34) == 0) || (*(int *)(param_1 + 7) == iVar1)) {
      if (DVar4 == 0) {
        if (dwMilliseconds != 0xffffffff) {
          DVar4 = GetTickCount();
          if (DVar3 + DVar6 <= DVar4) {
            *(int *)(param_1 + 6) = *(int *)(param_1 + 6) + -1;
            uVar5 = 1;
            bVar2 = false;
            goto LAB_14053c69f;
          }
          dwMilliseconds = (DVar3 - DVar4) + DVar6;
        }
        if (*(int *)((longlong)param_1 + 0x34) == 0) {
          ResetEvent((HANDLE)*param_1);
        }
      }
      else {
        uVar5 = 0xffffffff;
        if (DVar4 == 0x102) {
          uVar5 = 1;
        }
        *(int *)(param_1 + 6) = *(int *)(param_1 + 6) + -1;
        bVar2 = false;
      }
    }
    else {
      *(int *)(param_1 + 6) = *(int *)(param_1 + 6) + -1;
      uVar5 = 0;
      *(int *)((longlong)param_1 + 0x34) = *(int *)((longlong)param_1 + 0x34) + -1;
      bVar2 = false;
    }
LAB_14053c69f:
    LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
    if (!bVar2) {
      EnterCriticalSection(param_2);
      EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
      if (*(int *)(param_1 + 6) == 0) {
        ResetEvent((HANDLE)*param_1);
      }
      LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
      return uVar5;
    }
  } while( true );
}

// ==== CSocketKernel::helper_14053c700  @14053c700  [medium:callgraph-r0]  (orig: FUN_14053c700)
undefined8 FUN_14053c700(void)

{
  undefined4 local_58;
  undefined4 local_54;
  code *local_50;
  code *local_48;
  code *local_40;
  code *local_38;
  undefined4 local_30 [2];
  code *local_28;
  code *local_20;
  code *local_18;
  code *local_10;
  
  local_58 = 1;
  local_54 = 1;
  local_30[0] = 1;
  local_50 = FUN_14053c3b0;
  local_48 = FUN_14053c400;
  local_40 = FUN_14053c420;
  local_38 = FUN_14053c450;
  local_28 = FUN_14053c480;
  local_20 = FUN_14053c510;
  local_18 = FUN_14053c540;
  local_10 = FUN_14053c5a0;
  FUN_14054ec40(&local_58);
  FUN_14054ec30(&DAT_14053c470);
  FUN_14054ed40(local_30);
  return 0;
}

// ==== CSocketKernel::helper_14053c9f0  @14053c9f0  [medium:callgraph-r1]  (orig: FUN_14053c9f0)
undefined8 FUN_14053c9f0(longlong param_1,int *param_2)

{
  int iVar1;
  int local_res8;
  int local_resc;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f2a0();
  }
  if (*(int *)(param_1 + 0x160) != 0) {
    *(undefined8 *)param_2 = *(undefined8 *)(param_1 + 0x160);
    return 0;
  }
  iVar1 = FUN_14054ead0(param_1 + 0x168,param_2);
  if (iVar1 == -1) {
    return 0xffffffff;
  }
  if (*(longlong *)(param_1 + 0x1c0) + 5 < (longlong)*param_2) {
    FUN_14054e770(&local_res8,0);
    *(int *)(param_1 + 0x1b8) = local_res8 - *param_2;
    iVar1 = param_2[1];
    *(int *)(param_1 + 0x1bc) = local_resc - iVar1;
    if (local_resc - iVar1 < 0) {
      *(int *)(param_1 + 0x1b8) = *(int *)(param_1 + 0x1b8) + -1;
      *(int *)(param_1 + 0x1bc) = *(int *)(param_1 + 0x1bc) + 1000000;
    }
    *(longlong *)(param_1 + 0x1c0) = (longlong)*param_2;
  }
  return 0;
}

// ==== CSocketKernel::helper_14053cca0  @14053cca0  [medium:callgraph-r1]  (orig: FUN_14053cca0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14053cca0(undefined8 param_1)

{
  char cVar1;
  char *pcVar2;
  char *pcVar3;
  undefined1 auStack_78 [32];
  char local_58 [8];
  char local_50 [56];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  FUN_140547660(local_58,0x40,"EVENT_NO%s",param_1);
  if (local_50[0] != '\0') {
    pcVar2 = local_50;
    do {
      cVar1 = FUN_140546c30(*pcVar2);
      pcVar3 = pcVar2 + 1;
      *pcVar2 = cVar1;
      pcVar2 = pcVar3;
    } while (*pcVar3 != '\0');
  }
  pcVar2 = getenv(local_58);
  return pcVar2 != (char *)0x0;
}

// ==== CSocketKernel::helper_14053ce40  @14053ce40  [medium:callgraph-r0]  (orig: FUN_14053ce40)
undefined8 FUN_14053ce40(longlong param_1,uint param_2)

{
  if (param_1 == 0) {
    return 0xffffffff;
  }
  *(uint *)(param_1 + 0x28) = *(uint *)(param_1 + 0x28) | param_2;
  return 0;
}

// ==== CSocketKernel::helper_14053ce60  @14053ce60  [medium:callgraph-r0]  (orig: FUN_14053ce60)
undefined8 FUN_14053ce60(longlong param_1,undefined4 param_2)

{
  if (param_1 == 0) {
    return 0xffffffff;
  }
  *(undefined4 *)(param_1 + 0x10) = param_2;
  return 0;
}

// ==== CSocketKernel::helper_14053d1c0  @14053d1c0  [medium:callgraph-r0]  (orig: FUN_14053d1c0)
undefined8 FUN_14053d1c0(undefined8 *param_1)

{
  return *(undefined8 *)*param_1;
}

// ==== CSocketKernel::helper_14053d600  @14053d600  [medium:callgraph-r3]  (orig: FUN_14053d600)
undefined8 FUN_14053d600(longlong param_1)

{
  int iVar1;
  int *piVar2;
  undefined1 local_res8 [32];
  
  local_res8[0] = 0;
  iVar1 = Ordinal_19(*(undefined8 *)(param_1 + 0x218),local_res8,1);
  if (iVar1 < 0) {
    piVar2 = _errno();
    if (*piVar2 != 0x2733) {
      piVar2 = _errno();
      if (*piVar2 != 0xb) {
        return 0xffffffff;
      }
    }
  }
  return 0;
}

// ==== CSocketKernel::helper_14053d650  @14053d650  [medium:callgraph-r1]  (orig: FUN_14053d650)
undefined8 FUN_14053d650(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f2a0();
  }
  if (*(code **)(param_1 + 0x298) == (code *)0x0) {
    return 0xffffffff;
  }
  if (*(int *)(param_1 + 0x20c) != 0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0x20c) = 1;
                    /* WARNING: Could not recover jumptable at 0x00014053d6a0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(param_1 + 0x298))(param_1);
  return uVar1;
}

// ==== CSocketKernel::helper_14053dc70  @14053dc70  [medium:callgraph-r2]  (orig: FUN_14053dc70)
void * FUN_14053dc70(size_t param_1)

{
  void *pvVar1;
  
  if (param_1 == 0) {
    return (void *)0x0;
  }
  if (DAT_140976d38 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014053dc84. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    pvVar1 = (void *)(*DAT_140976d38)();
    return pvVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x00014053dc87. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = malloc(param_1);
  return pvVar1;
}

// ==== CSocketKernel::helper_14053de40  @14053de40  [medium:callgraph-r3]  (orig: FUN_14053de40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14053de40(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  int iVar1;
  undefined1 auStack_438 [32];
  undefined1 local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  do {
    iVar1 = Ordinal_16(param_1,local_418,0x400,0);
  } while (0 < iVar1);
  if (*(longlong *)(param_3 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  *(undefined4 *)(param_3 + 0x20c) = 0;
  if (*(longlong *)(param_3 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CSocketKernel::helper_14053e5d0  @14053e5d0  [medium:callgraph-r0]  (orig: FUN_14053e5d0)
void FUN_14053e5d0(void)

{
  FUN_140551980();
  FUN_140547150();
  return;
}

// ==== CSocketKernel::helper_14053e5f0  @14053e5f0  [medium:callgraph-r2]  (orig: FUN_14053e5f0)
int FUN_14053e5f0(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_1405519b0();
  if (-1 < iVar1) {
    iVar1 = FUN_140546850(param_1);
    if (-1 < iVar1) {
      iVar1 = FUN_140551e60(param_1);
      return (-1 < iVar1) - 1;
    }
  }
  return -1;
}

// ==== CSocketKernel::helper_14053e9c0  @14053e9c0  [medium:callgraph-r0]  (orig: FUN_14053e9c0)
undefined8 * FUN_14053e9c0(void)

{
  undefined8 *puVar1;
  int *piVar2;
  
  if (DAT_140976d38 == (code *)0x0) {
    puVar1 = calloc(1,0x30);
    if (puVar1 == (undefined8 *)0x0) goto LAB_14053ea12;
  }
  else {
    puVar1 = (undefined8 *)(*DAT_140976d38)();
    if (puVar1 == (undefined8 *)0x0) {
LAB_14053ea12:
      piVar2 = _errno();
      *piVar2 = 0xc;
      return (undefined8 *)0x0;
    }
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    puVar1[4] = 0;
    puVar1[5] = 0;
    if (puVar1 == (undefined8 *)0x0) {
      return (undefined8 *)0x0;
    }
  }
  *puVar1 = 0;
  puVar1[1] = puVar1;
  *(undefined4 *)((longlong)puVar1 + 0x14) = 0xffffffff;
  *(undefined4 *)((longlong)puVar1 + 0x1c) = 0x7fffffff;
  *(undefined4 *)(puVar1 + 4) = 1;
  return puVar1;
}

// ==== CSocketKernel::helper_14053eaa0  @14053eaa0  [medium:callgraph-r0]  (orig: FUN_14053eaa0)
void FUN_14053eaa0(undefined8 *param_1)

{
  longlong *_Memory;
  code *UNRECOVERED_JUMPTABLE;
  
  _Memory = (longlong *)*param_1;
  UNRECOVERED_JUMPTABLE = DAT_140976d48;
  do {
    if (_Memory == (longlong *)0x0) {
      if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014053eb4e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        free(param_1);
        return;
      }
                    /* WARNING: Could not recover jumptable at 0x00014053eb3c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*UNRECOVERED_JUMPTABLE)();
      return;
    }
    if (*_Memory == 0) {
      param_1[1] = _Memory[1];
    }
    else {
      *(longlong *)(*_Memory + 8) = _Memory[1];
    }
    *(longlong *)_Memory[1] = *_Memory;
    if ((void *)_Memory[2] == (void *)0x0) {
LAB_14053eaf8:
      if (UNRECOVERED_JUMPTABLE == (code *)0x0) goto LAB_14053eb11;
      (*UNRECOVERED_JUMPTABLE)(_Memory);
      UNRECOVERED_JUMPTABLE = DAT_140976d48;
    }
    else {
      if (UNRECOVERED_JUMPTABLE != (code *)0x0) {
        (*UNRECOVERED_JUMPTABLE)();
        UNRECOVERED_JUMPTABLE = DAT_140976d48;
        goto LAB_14053eaf8;
      }
      free((void *)_Memory[2]);
LAB_14053eb11:
      free(_Memory);
    }
    _Memory = (longlong *)*param_1;
  } while( true );
}

// ==== CSocketKernel::helper_14053ec20  @14053ec20  [medium:callgraph-r1]  (orig: FUN_14053ec20)
ulonglong FUN_14053ec20(longlong param_1,int param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  uint uVar4;
  ulonglong uVar5;
  
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar3 = 0xffffffff;
  if ((*(int *)(param_1 + 0xd8) == 0) && (uVar3 = 0xffffffff, param_2 - 1U < 0xff)) {
    uVar3 = 0;
    if (param_2 != *(int *)(param_1 + 0x100)) {
      if (*(int *)(param_1 + 0x100) != 0) {
        if (DAT_140976d48 == (code *)0x0) {
          free(*(void **)(param_1 + 0xf8));
        }
        else {
          (*DAT_140976d48)();
        }
        *(undefined4 *)(param_1 + 0x100) = 0;
      }
      lVar1 = FUN_14053dc90((longlong)param_2,0x10);
      *(longlong *)(param_1 + 0xf8) = lVar1;
      if (lVar1 == 0) {
        FUN_14054f740("%s: calloc","event_base_priority_init");
        uVar3 = 0xffffffff;
      }
      else {
        *(int *)(param_1 + 0x100) = param_2;
        uVar2 = uVar3;
        uVar5 = uVar3;
        if (0 < param_2) {
          do {
            *(undefined8 *)(uVar2 + *(longlong *)(param_1 + 0xf8)) = 0;
            uVar4 = (int)uVar5 + 1;
            *(longlong *)(uVar2 + 8 + *(longlong *)(param_1 + 0xf8)) =
                 (longlong)(int)uVar5 * 0x10 + *(longlong *)(param_1 + 0xf8);
            uVar2 = uVar2 + 0x10;
            uVar5 = (ulonglong)uVar4;
          } while ((int)uVar4 < *(int *)(param_1 + 0x100));
        }
      }
    }
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return uVar3;
}

// ==== CSocketKernel::helper_14053ed50  @14053ed50  [medium:callgraph-r0]  (orig: FUN_14053ed50)
undefined4 FUN_14053ed50(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  *(undefined4 *)(param_1 + 0xe4) = 1;
  if (*(int *)(param_1 + 0xf0) != 0) {
    iVar1 = FUN_14054f180();
    if (*(int *)(param_1 + 0x1c8) != iVar1) {
      uVar2 = FUN_14053d650(param_1);
      goto LAB_14053edad;
    }
  }
  uVar2 = 0;
LAB_14053edad:
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return uVar2;
}

// ==== CSocketKernel::helper_140540d40  @140540d40  [medium:callgraph-r2]  (orig: FUN_140540d40)
undefined8 FUN_140540d40(undefined *param_1)

{
  int iVar1;
  undefined *puVar2;
  undefined8 uVar3;
  
  if (*(longlong *)(param_1 + 0x298) != 0) {
    return 0;
  }
  iVar1 = FUN_1405490c0(param_1 + 0x210);
  if (iVar1 == 0) {
    *(code **)(param_1 + 0x298) = FUN_14053d600;
    *(undefined8 *)(param_1 + 600) = *(undefined8 *)(param_1 + 0x210);
    *(undefined **)(param_1 + 0x260) = param_1;
    param_1[0x233] = 2;
    *(undefined4 *)(param_1 + 0x248) = 0xffffffff;
    puVar2 = param_1;
    if (param_1 == &DAT_140976d28) {
      puVar2 = (undefined *)0x140976f48;
    }
    *(code **)(param_1 + 0x238) = FUN_14053de40;
    *(undefined **)(param_1 + 0x240) = puVar2;
    *(undefined2 *)(param_1 + 0x28a) = 0;
    *(undefined8 *)(param_1 + 0x280) = 0;
    *(undefined4 *)(param_1 + 0x27c) = 0;
    *(undefined4 *)(param_1 + 0x278) = 0;
    *(undefined2 *)(param_1 + 0x288) = 0x12;
    *(undefined2 *)(param_1 + 0x230) = 0x80;
    param_1[0x232] = (char)(*(int *)(param_1 + 0x100) / 2);
    *(ushort *)(param_1 + 0x230) = *(ushort *)(param_1 + 0x230) | 0x10;
    if (((param_1[0x230] & 8) == 0) && (0 < *(int *)(*(longlong *)(param_1 + 0x260) + 0x100))) {
      param_1[0x232] = 0;
    }
    uVar3 = FUN_1405403b0(param_1 + 0x220,0,0);
    return uVar3;
  }
  return 0xffffffff;
}

// ==== CSocketKernel::helper_140540e40  @140540e40  [medium:callgraph-r2]  (orig: FUN_140540e40)
undefined8 FUN_140540e40(longlong param_1,void *param_2,int param_3)

{
  ushort uVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0;
  if ((char)*(ushort *)((longlong)param_2 + 0x10) < '\0') {
    if ((*(ushort *)((longlong)param_2 + 0x10) & 0x10) != 0) goto LAB_140540f09;
    if (*(longlong *)(*(longlong *)((longlong)param_2 + 0x40) + 0x1d0) != 0) {
      FUN_14054f1e0(0);
    }
    FUN_14053f3a0(param_2,3);
    lVar2 = *(longlong *)(*(longlong *)((longlong)param_2 + 0x40) + 0x1d0);
  }
  else {
    if (*(longlong *)(param_1 + 0x1d0) != 0) {
      FUN_14054f1e0(0);
    }
    uVar1 = *(ushort *)((longlong)param_2 + 0x10);
    if ((char)uVar1 < '\0') {
      FUN_14053f3a0(param_2,3);
    }
    else if ((uVar1 & 0x28) != 0) {
      if ((uVar1 & 0x28) == 8) {
        FUN_14053d820(param_1,param_2);
      }
      else if ((uVar1 & 0x28) == 0x20) {
        FUN_14053d8a0(param_1,param_2);
      }
    }
    lVar2 = *(longlong *)(param_1 + 0x1d0);
  }
  if (lVar2 != 0) {
    FUN_14054f200(0);
  }
  uVar3 = 1;
LAB_140540f09:
  if ((param_3 != 0) && ((*(byte *)((longlong)param_2 + 0x10) & 0x40) != 0)) {
    if (*(char *)((longlong)param_2 + 0x13) == '\x04') {
      (**(code **)((longlong)param_2 + 0x18))(param_2,*(undefined8 *)((longlong)param_2 + 0x20));
    }
    else if ((byte)(*(char *)((longlong)param_2 + 0x13) - 5U) < 2) {
      (**(code **)((longlong)param_2 + 0x18))(param_2,*(undefined8 *)((longlong)param_2 + 0x20));
      if (*(char *)((longlong)param_2 + 0x13) == '\x06') {
        if (DAT_140976d48 == (code *)0x0) {
          free(param_2);
        }
        else {
          (*DAT_140976d48)();
        }
      }
    }
  }
  return uVar3;
}

// ==== CSocketKernel::helper_140540f70  @140540f70  [medium:callgraph-r1]  (orig: FUN_140540f70)
void FUN_140540f70(longlong *param_1,undefined4 param_2)

{
  byte *pbVar1;
  longlong *_Memory;
  longlong lVar2;
  undefined8 *puVar3;
  code *pcVar4;
  undefined8 *puVar5;
  code *pcVar6;
  longlong *plVar7;
  uint uVar8;
  longlong *plVar9;
  longlong *plVar10;
  
  if ((param_1 == (longlong *)0x0) &&
     ((DAT_140976d20 == (longlong *)0x0 ||
      (param_1 = DAT_140976d20, DAT_140976d20 == (longlong *)0x0)))) {
    FUN_14054f8b0("%s: no base to free","event_base_free_");
    return;
  }
  plVar10 = (longlong *)0x0;
  if (param_1[0x3e] != 0) {
    FUN_1405c6f40(param_1[0x3e],0xffffffff);
    param_1[0x3e] = 0;
  }
  if (param_1[0x42] != -1) {
    FUN_140540740(param_1 + 0x44);
    Ordinal_3(param_1[0x42]);
    if (param_1[0x43] != -1) {
      Ordinal_3();
    }
    param_1[0x42] = -1;
    param_1[0x43] = -1;
    *(ushort *)(param_1 + 0x46) = *(ushort *)(param_1 + 0x46) & 0xff7f;
  }
  FUN_140550b70(param_1);
  while (((int)param_1[0x2b] != 0 && (*(longlong *)param_1[0x2a] != 0))) {
    FUN_140540740();
  }
  pcVar6 = DAT_140976d48;
  plVar7 = plVar10;
  plVar9 = plVar10;
  if (0 < (int)param_1[0x24]) {
    do {
      _Memory = *(longlong **)(param_1[0x23] + (longlong)plVar7);
      FUN_140540740(_Memory + 3);
      *(ushort *)(_Memory + 5) = *(ushort *)(_Memory + 5) & 0xff7f;
      lVar2 = *_Memory;
      pcVar6 = DAT_140976d48;
      while (DAT_140976d48 = pcVar6, lVar2 != 0) {
        pbVar1 = (byte *)(lVar2 + 0x10);
        lVar2 = *(longlong *)(lVar2 + 0x28);
        if ((*pbVar1 & 0x10) == 0) {
          FUN_140540740();
          pcVar6 = DAT_140976d48;
        }
      }
      if (pcVar6 == (code *)0x0) {
        free(_Memory);
      }
      else {
        (*pcVar6)(_Memory);
        pcVar6 = DAT_140976d48;
      }
      uVar8 = (int)plVar9 + 1;
      plVar7 = plVar7 + 1;
      plVar9 = (longlong *)(ulonglong)uVar8;
    } while ((int)uVar8 < (int)param_1[0x24]);
  }
  if ((void *)param_1[0x23] != (void *)0x0) {
    if (pcVar6 == (code *)0x0) {
      free((void *)param_1[0x23]);
    }
    else {
      (*pcVar6)();
      pcVar6 = DAT_140976d48;
    }
  }
  plVar7 = plVar10;
  plVar9 = plVar10;
  if (0 < (int)param_1[0x20]) {
    do {
      puVar5 = *(undefined8 **)(param_1[0x1f] + (longlong)plVar7);
      pcVar6 = DAT_140976d48;
      while (DAT_140976d48 = pcVar6, puVar5 != (undefined8 *)0x0) {
        puVar3 = (undefined8 *)*puVar5;
        FUN_140540e40(param_1,puVar5,param_2);
        puVar5 = puVar3;
        pcVar6 = DAT_140976d48;
      }
      uVar8 = (int)plVar9 + 1;
      plVar7 = plVar7 + 2;
      plVar9 = (longlong *)(ulonglong)uVar8;
    } while ((int)uVar8 < (int)param_1[0x20]);
  }
  lVar2 = param_1[0x21];
  while (lVar2 != 0) {
    FUN_140540e40(param_1,lVar2,param_2);
    pcVar6 = DAT_140976d48;
    lVar2 = param_1[0x21];
  }
  lVar2 = param_1[0x55];
  while (lVar2 != 0) {
    plVar7 = (longlong *)param_1[0x55];
    if (*plVar7 != 0) {
      *(longlong *)(*plVar7 + 8) = plVar7[1];
    }
    *(longlong *)plVar7[1] = *plVar7;
    if (pcVar6 == (code *)0x0) {
      free(plVar7);
      pcVar6 = (code *)0x0;
    }
    else {
      (*pcVar6)();
      pcVar6 = DAT_140976d48;
    }
    lVar2 = param_1[0x55];
  }
  if ((*param_1 != 0) && (pcVar4 = *(code **)(*param_1 + 0x28), pcVar4 != (code *)0x0)) {
    (*pcVar4)(param_1);
    pcVar6 = DAT_140976d48;
  }
  if ((void *)param_1[0x2a] != (void *)0x0) {
    if (pcVar6 == (code *)0x0) {
      free((void *)param_1[0x2a]);
    }
    else {
      (*pcVar6)();
      pcVar6 = DAT_140976d48;
    }
  }
  if (pcVar6 == (code *)0x0) {
    free((void *)param_1[0x1f]);
  }
  else {
    (*pcVar6)();
  }
  FUN_14054fee0(param_1 + 0x25);
  FUN_140550050(param_1 + 0x28);
  FUN_140550de0(param_1 + 2);
  if (param_1[0x3a] != 0) {
    FUN_14054f1c0(param_1[0x3a],0);
  }
  if (param_1[0x3b] != 0) {
    FUN_14054f240();
  }
  if (param_1 == DAT_140976d20) {
    DAT_140976d20 = plVar10;
  }
  if (DAT_140976d48 == (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405412cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    free(param_1);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405412bf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*DAT_140976d48)(param_1);
  return;
}

// ==== CSocketKernel::helper_1405412f0  @1405412f0  [medium:callgraph-r0]  (orig: FUN_1405412f0)
void FUN_1405412f0(undefined8 param_1)

{
  FUN_140540f70(param_1,1);
  return;
}

// ==== CSocketKernel::helper_140541d90  @140541d90  [medium:callgraph-r3]  (orig: FUN_140541d90)
undefined4 FUN_140541d90(longlong *param_1,uint param_2)

{
  longlong lVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 *local_res8;
  undefined4 local_res18;
  undefined4 local_res1c;
  
  lVar1 = *param_1;
  uVar5 = 0;
  if (param_1[0x3a] != 0) {
    FUN_14054f1e0(0);
  }
  if ((int)param_1[0x1e] != 0) {
    FUN_14054f8b0("%s: reentrant invocation.  Only one event_base_loop can run on each event_base at once."
                  ,"event_base_loop");
    if (param_1[0x3a] != 0) {
      FUN_14054f200(0);
    }
    return 0xffffffff;
  }
  *(undefined4 *)(param_1 + 0x1e) = 1;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  if (((int)param_1[0x16] != 0) && (*(int *)((longlong)param_1 + 0xb4) != 0)) {
    FUN_1405512a0(param_1);
  }
  uVar3 = FUN_14054f180();
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x39) = uVar3;
  do {
    while( true ) {
      *(undefined4 *)(param_1 + 0x1d) = 0;
      *(undefined4 *)((longlong)param_1 + 0xf4) = 0;
      if (((int)param_1[0x1c] != 0) || (*(int *)((longlong)param_1 + 0xe4) != 0))
      goto LAB_140541f60;
      local_res8 = &local_res18;
      if (((int)param_1[0x1b] == 0) && ((param_2 & 2) == 0)) {
        FUN_14053d710(param_1,&local_res8);
      }
      else {
        local_res1c = 0;
        local_res18 = 0;
      }
      puVar2 = local_res8;
      if ((((param_2 & 4) == 0) && (iVar4 = FUN_14053d040(param_1), iVar4 == 0)) &&
         ((int)param_1[0x1b] == 0)) {
        uVar5 = 1;
        goto LAB_140541f60;
      }
      FUN_14053db70(param_1);
      *(undefined4 *)(param_1 + 0x2c) = 0;
      iVar4 = (**(code **)(lVar1 + 0x20))(param_1,puVar2);
      if (iVar4 == -1) {
        uVar5 = 0xffffffff;
        goto LAB_140541f60;
      }
      *(undefined4 *)(param_1 + 0x2c) = 0;
      if ((*(byte *)(param_1 + 0x3f) & 8) == 0) {
        FUN_14053c9f0(param_1,param_1 + 0x2c);
      }
      FUN_14053f740(param_1);
      if ((int)param_1[0x1b] == 0) break;
      iVar4 = FUN_140541c60(param_1);
      if ((((param_2 & 1) != 0) && ((int)param_1[0x1b] == 0)) && (iVar4 != 0)) goto LAB_140541f60;
    }
  } while ((param_2 & 2) == 0);
LAB_140541f60:
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 0x1e) = 0;
  if (param_1[0x3a] != 0) {
    FUN_14054f200(0);
  }
  return uVar5;
}

// ==== CSocketKernel::helper_1405422b0  @1405422b0  [medium:callgraph-r1]  (orig: FUN_1405422b0)
undefined4 FUN_1405422b0(longlong param_1)

{
  undefined4 uVar1;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = FUN_140540d40(param_1);
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

// ==== CSocketKernel::helper_140542310  @140542310  [medium:callgraph-r0]  (orig: FUN_140542310)
longlong * FUN_140542310(undefined8 *param_1)

{
  char cVar1;
  char cVar2;
  undefined8 *puVar3;
  undefined *puVar4;
  bool bVar5;
  int iVar6;
  longlong *_Dst;
  int *piVar7;
  char *pcVar8;
  undefined **ppuVar9;
  longlong lVar10;
  bool bVar11;
  undefined1 local_res10 [8];
  
  if (DAT_140976d38 == (code *)0x0) {
    _Dst = calloc(1,0x2b0);
    if (_Dst == (longlong *)0x0) goto LAB_140542383;
  }
  else {
    _Dst = (longlong *)(*DAT_140976d38)(0x2b0);
    if (_Dst == (longlong *)0x0) {
LAB_140542383:
      piVar7 = _errno();
      *piVar7 = 0xc;
      goto LAB_14054234e;
    }
    memset(_Dst,0,0x2b0);
  }
  if (_Dst == (longlong *)0x0) {
LAB_14054234e:
    FUN_14054f740("%s: calloc","event_base_new_with_config");
    return (longlong *)0x0;
  }
  bVar11 = false;
  if ((param_1 == (undefined8 *)0x0) ||
     (*(undefined4 *)(_Dst + 0x3f) = *(undefined4 *)(param_1 + 5), bVar5 = bVar11,
     (*(byte *)(param_1 + 5) & 2) == 0)) {
    bVar5 = true;
  }
  if ((param_1 != (undefined8 *)0x0) && ((*(byte *)(param_1 + 5) & 0x20) != 0)) {
    bVar11 = true;
  }
  if ((bVar5) && (!bVar11)) {
    pcVar8 = getenv("EVENT_PRECISE_TIMER");
    bVar11 = pcVar8 != (char *)0x0;
    *(uint *)(_Dst + 0x3f) = *(uint *)(_Dst + 0x3f) | 0x20;
  }
  FUN_14054e9f0(_Dst + 0x2d,bVar11);
  FUN_14053c9f0(_Dst,local_res10);
  _Dst[0x2a] = 0;
  *(undefined4 *)(_Dst + 0x2b) = 0;
  *(undefined4 *)((longlong)_Dst + 0x15c) = 0;
  _Dst[0x14] = -1;
  _Dst[0x15] = -1;
  _Dst[0x42] = -1;
  _Dst[0x21] = 0;
  _Dst[0x43] = -1;
  _Dst[0x22] = (longlong)(_Dst + 0x21);
  FUN_14054fec0(_Dst + 0x25);
  FUN_140550040(_Dst + 0x28);
  FUN_140550c00(_Dst + 2);
  _Dst[1] = 0;
  if (param_1 == (undefined8 *)0x0) {
    *(undefined4 *)((longlong)_Dst + 0x1fc) = 0xffffffff;
    *(undefined4 *)(_Dst + 0x41) = 1;
LAB_1405424c4:
    *(undefined4 *)((longlong)_Dst + 0x204) = 0x7fffffff;
  }
  else {
    *(undefined8 *)((longlong)_Dst + 0x1fc) = *(undefined8 *)((longlong)param_1 + 0x14);
    *(undefined4 *)(_Dst + 0x41) = *(undefined4 *)(param_1 + 4);
    if (*(int *)((longlong)param_1 + 0x1c) < 0) goto LAB_1405424c4;
    *(int *)((longlong)_Dst + 0x204) = *(int *)((longlong)param_1 + 0x1c);
  }
  if ((*(int *)((longlong)_Dst + 0x204) == 0x7fffffff) && (*(int *)((longlong)_Dst + 0x1fc) == -1))
  {
    *(undefined4 *)(_Dst + 0x41) = 0x7fffffff;
  }
  if (PTR_PTR_1409707e8 != (undefined *)0x0) {
    ppuVar9 = &PTR_PTR_1409707e8;
    do {
      if (_Dst[1] != 0) break;
      if (param_1 == (undefined8 *)0x0) {
LAB_14054256c:
        if ((!bVar5) || (iVar6 = FUN_14053cca0(*(undefined8 *)*ppuVar9), iVar6 == 0)) {
          puVar4 = *ppuVar9;
          *_Dst = (longlong)puVar4;
          lVar10 = (**(code **)(puVar4 + 8))(_Dst);
          _Dst[1] = lVar10;
        }
      }
      else {
        for (puVar3 = (undefined8 *)*param_1; puVar3 != (undefined8 *)0x0;
            puVar3 = (undefined8 *)*puVar3) {
          pcVar8 = (char *)puVar3[2];
          if (pcVar8 != (char *)0x0) {
            lVar10 = *(longlong *)*ppuVar9 - (longlong)pcVar8;
            do {
              cVar1 = *pcVar8;
              cVar2 = pcVar8[lVar10];
              if (cVar1 != cVar2) break;
              pcVar8 = pcVar8 + 1;
            } while (cVar2 != '\0');
            if (cVar1 == cVar2) goto LAB_140542590;
          }
        }
        if ((*(uint *)((longlong)*ppuVar9 + 0x34) & *(uint *)((longlong)param_1 + 0x24)) ==
            *(uint *)((longlong)param_1 + 0x24)) goto LAB_14054256c;
      }
LAB_140542590:
      ppuVar9 = ppuVar9 + 1;
    } while (*ppuVar9 != (undefined *)0x0);
  }
  if (_Dst[1] == 0) {
    FUN_14054f8b0("%s: no event mechanism available","event_base_new_with_config");
    *_Dst = 0;
  }
  else {
    pcVar8 = getenv("EVENT_SHOW_METHOD");
    if (pcVar8 != (char *)0x0) {
      FUN_14054f8e0("libevent using: %s",*(undefined8 *)*_Dst);
    }
    iVar6 = FUN_14053ec20(_Dst,1);
    if (-1 < iVar6) {
      iVar6 = FUN_14054f2b0();
      if ((iVar6 != 0) && ((param_1 == (undefined8 *)0x0 || ((*(byte *)(param_1 + 5) & 1) == 0)))) {
        lVar10 = FUN_14054f1a0(0);
        _Dst[0x3a] = lVar10;
        lVar10 = FUN_14054f220(0);
        _Dst[0x3b] = lVar10;
        iVar6 = FUN_1405422b0(_Dst);
        if (iVar6 < 0) {
          FUN_14054f8b0("%s: Unable to make base notifiable.","event_base_new_with_config");
          goto LAB_140542646;
        }
      }
      if (((param_1 != (undefined8 *)0x0) && ((*(byte *)(param_1 + 5) & 4) != 0)) &&
         (_Dst[0x3e] == 0)) {
        lVar10 = FUN_1405c6d30(*(undefined4 *)(param_1 + 2));
        _Dst[0x3e] = lVar10;
        if (lVar10 == 0) {
          FUN_14054f8b0("%s: Couldn\'t launch IOCP","event_base_start_iocp_");
        }
      }
      return _Dst;
    }
  }
LAB_140542646:
  FUN_140540f70(_Dst,1);
  return (longlong *)0x0;
}

// ==== CSocketKernel::helper_1405426b0  @1405426b0  [medium:callgraph-r2]  (orig: FUN_1405426b0)
void FUN_1405426b0(undefined8 param_1)

{
  FUN_140541d90(param_1,0);
  return;
}

// ==== CSocketKernel::helper_140543dc0  @140543dc0  [medium:callgraph-r3]  (orig: FUN_140543dc0)
void FUN_140543dc0(undefined8 param_1,undefined8 param_2,longlong param_3)

{
  ushort *puVar1;
  ulonglong uVar2;
  
  uVar2 = FUN_14054a780();
  if (uVar2 < *(ulonglong *)(param_3 + 0x118)) {
    if (*(longlong *)(param_3 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
    puVar1 = (ushort *)(param_3 + 0x176);
    *puVar1 = *puVar1 & 0xfffe;
    if ((*puVar1 == 0) && ((*(byte *)(param_3 + 0x160) & 2) != 0)) {
      (**(code **)(*(longlong *)(param_3 + 8) + 0x10))(param_3,2);
    }
  }
  else {
    if (*(longlong *)(param_3 + 0x1b8) != 0) {
      FUN_14054f1e0(0);
    }
    if (*(short *)(param_3 + 0x176) == 0) {
      (**(code **)(*(longlong *)(param_3 + 8) + 0x18))(param_3,2);
    }
    *(ushort *)(param_3 + 0x176) = *(ushort *)(param_3 + 0x176) | 1;
  }
  if (*(longlong *)(param_3 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CSocketKernel::helper_140544280  @140544280  [medium:callgraph-r2]  (orig: FUN_140544280)
void FUN_140544280(longlong param_1,ushort param_2,undefined8 param_3,ulonglong param_4)

{
  undefined8 uVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f1e0(0);
  }
  if ((param_2 & 4) != 0) {
    *(undefined8 *)(param_1 + 0x120) = param_3;
    *(ulonglong *)(param_1 + 0x128) = param_4;
  }
  if ((param_2 & 2) == 0) goto LAB_140544382;
  *(undefined8 *)(param_1 + 0x110) = param_3;
  *(ulonglong *)(param_1 + 0x118) = param_4;
  if (param_4 == 0) {
    if (*(longlong *)(param_1 + 0x168) != 0) {
      FUN_14054bd10(*(undefined8 *)(param_1 + 0x100),*(longlong *)(param_1 + 0x168),1);
    }
  }
  else {
    if (*(longlong *)(param_1 + 0x168) == 0) {
      uVar1 = FUN_14054baf0(*(undefined8 *)(param_1 + 0x100),FUN_140543dc0,param_1);
      *(undefined8 *)(param_1 + 0x168) = uVar1;
    }
    FUN_14054bcc0(*(undefined8 *)(param_1 + 0x100),*(undefined8 *)(param_1 + 0x168),3);
    uVar2 = FUN_14054a780(*(undefined8 *)(param_1 + 0x100));
    if (param_4 <= uVar2) {
      FUN_140543c00(param_1,1);
      goto LAB_140544382;
    }
    uVar2 = FUN_14054a780(*(undefined8 *)(param_1 + 0x100));
    if (param_4 <= uVar2) goto LAB_140544382;
  }
  FUN_140543c70(param_1,1);
LAB_140544382:
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14054f200(0);
  }
  return;
}

// ==== CSocketKernel::helper_140546850  @140546850  [medium:callgraph-r3]  (orig: FUN_140546850)
undefined8 FUN_140546850(undefined4 param_1)

{
  DAT_140976d70 = FUN_14054f090(DAT_140976d70,0,param_1);
  if (DAT_140976d70 == 0) {
    FUN_14054f740("Couldn\'t allocate %s","windows_socket_errors_lock_");
    return 0xffffffff;
  }
  return 0;
}

// ==== CSocketKernel::helper_1405468a0  @1405468a0  [medium:callgraph-r2]  (orig: FUN_1405468a0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1405468a0(void)

{
  uint uVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar5 = (longlong *)0x0;
  plVar2 = plVar5;
  plVar4 = DAT_140970800;
  if (DAT_140970808 != 0) {
    do {
      if (*plVar4 != 0) {
        plVar2 = DAT_140970800 + (longlong)plVar2;
        while (plVar2 != (longlong *)0x0) {
          plVar4 = (longlong *)*plVar2;
          uVar1 = *(uint *)(plVar4 + 1);
          *plVar2 = *plVar4;
          DAT_14097080c = DAT_14097080c + -1;
          uVar1 = (uVar1 >> 0x10 ^ uVar1) * -0x7a143595;
          uVar1 = (uVar1 >> 0xd ^ uVar1) * -0x3d4d51cb;
          if (*plVar2 == 0) {
            uVar1 = (uVar1 >> 0x10 ^ uVar1) % DAT_140970808 + 1;
            plVar2 = plVar5;
            if (uVar1 < DAT_140970808) {
              plVar3 = DAT_140970800 + (int)uVar1;
              do {
                if (*plVar3 != 0) {
                  plVar2 = DAT_140970800 + uVar1;
                  break;
                }
                uVar1 = uVar1 + 1;
                plVar3 = plVar3 + 1;
              } while (uVar1 < DAT_140970808);
            }
          }
          LocalFree((HLOCAL)plVar4[2]);
          FUN_14053de00(plVar4);
        }
        break;
      }
      uVar1 = (int)plVar2 + 1;
      plVar2 = (longlong *)(ulonglong)uVar1;
      plVar4 = plVar4 + 1;
    } while (uVar1 < DAT_140970808);
  }
  if (DAT_140970800 != (longlong *)0x0) {
    FUN_14053de00(DAT_140970800);
  }
  DAT_140970808 = 0;
  DAT_140970800 = (longlong *)0x0;
  DAT_14097080c = 0;
  DAT_140970810 = 0;
  _DAT_140970814 = 0xffffffff;
  if (DAT_140976d70 != 0) {
    FUN_14054f1c0(DAT_140976d70,0);
    DAT_140976d70 = 0;
  }
  return;
}

// ==== CSocketKernel::helper_1405469f0  @1405469f0  [medium:callgraph-r3]  (orig: FUN_1405469f0)
int FUN_1405469f0(char *param_1,size_t param_2,char *param_3,va_list param_4)

{
  int iVar1;
  
  if (param_2 == 0) {
    iVar1 = 0;
  }
  else {
    iVar1 = _vsnprintf(param_1,param_2,param_3,param_4);
    if (iVar1 < 0) {
      iVar1 = _vscprintf(param_3,param_4);
    }
    param_1[param_2 - 1] = '\0';
  }
  return iVar1;
}

// ==== CSocketKernel::helper_140546c30  @140546c30  [medium:callgraph-r2]  (orig: FUN_140546c30)
undefined1 FUN_140546c30(byte param_1)

{
  return (&DAT_1407a1470)[param_1];
}

// ==== CSocketKernel::helper_140546fa0  @140546fa0  [medium:callgraph-r2]  (orig: FUN_140546fa0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

HMODULE FUN_140546fa0(char *param_1)

{
  char cVar1;
  UINT UVar2;
  HMODULE pHVar3;
  ulonglong uVar4;
  longlong lVar5;
  char *pcVar6;
  char *pcVar7;
  undefined1 auStack_148 [32];
  CHAR local_128 [272];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  UVar2 = GetSystemDirectoryA(local_128,0x104);
  if (UVar2 != 0) {
    uVar4 = 0xffffffffffffffff;
    pcVar6 = param_1;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar6;
      pcVar6 = pcVar6 + 1;
    } while (cVar1 != '\0');
    if (~uVar4 + 1 + (ulonglong)UVar2 < 0x104) {
      lVar5 = -1;
      pcVar6 = local_128;
      do {
        pcVar7 = pcVar6;
        if (lVar5 == 0) break;
        lVar5 = lVar5 + -1;
        pcVar7 = pcVar6 + 1;
        cVar1 = *pcVar6;
        pcVar6 = pcVar7;
      } while (cVar1 != '\0');
      lVar5 = -1;
      *(undefined2 *)(pcVar7 + -1) = DAT_1406e25a0;
      pcVar6 = local_128;
      do {
        pcVar7 = pcVar6;
        if (lVar5 == 0) break;
        lVar5 = lVar5 + -1;
        pcVar7 = pcVar6 + 1;
        cVar1 = *pcVar6;
        pcVar6 = pcVar7;
      } while (cVar1 != '\0');
      lVar5 = 0;
      do {
        cVar1 = param_1[lVar5];
        pcVar7[lVar5 + -1] = cVar1;
        lVar5 = lVar5 + 1;
      } while (cVar1 != '\0');
      pHVar3 = LoadLibraryA(local_128);
      return pHVar3;
    }
  }
  return (HMODULE)0x0;
}

// ==== CSocketKernel::helper_140547150  @140547150  [medium:callgraph-r1]  (orig: FUN_140547150)
void FUN_140547150(void)

{
  FUN_140551ef0();
  FUN_1405468a0();
  return;
}

// ==== CSocketKernel::helper_140547660  @140547660  [medium:callgraph-r2]  (orig: FUN_140547660)
int FUN_140547660(char *param_1,size_t param_2,char *param_3,undefined8 param_4)

{
  int iVar1;
  undefined8 local_res20;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res20 = param_4;
  iVar1 = _vsnprintf(param_1,param_2,param_3,(va_list)&local_res20);
  if (iVar1 < 0) {
    iVar1 = _vscprintf(param_3,(va_list)&local_res20);
  }
  param_1[param_2 - 1] = '\0';
  return iVar1;
}

// ==== CSocketKernel::helper_1405490c0  @1405490c0  [medium:callgraph-r3]  (orig: FUN_1405490c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405490c0(ulonglong *param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined1 auStack_68 [32];
  int local_48 [2];
  undefined8 local_40;
  undefined8 local_38;
  short local_30;
  short local_2e;
  int local_2c;
  ulonglong local_20;
  
  local_20 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  uVar5 = 0xffffffffffffffff;
  uVar4 = 0xffffffffffffffff;
  if (param_1 == (ulonglong *)0x0) {
    uVar1 = 0x2726;
  }
  else {
    lVar3 = Ordinal_23(2,1);
    if (lVar3 < 0) goto LAB_140549328;
    local_40 = 2;
    local_38 = 0;
    uVar1 = Ordinal_8(0x7f000001);
    local_40 = CONCAT44(uVar1,(undefined4)local_40) & 0xffffffff0000ffff;
    iVar2 = Ordinal_2(lVar3,&local_40,0x10);
    if (((iVar2 == -1) || (iVar2 = Ordinal_13(lVar3,1), iVar2 == -1)) ||
       (uVar5 = Ordinal_23(2,1,0), (longlong)uVar5 < 0)) {
LAB_1405492e9:
      uVar1 = Ordinal_111();
    }
    else {
      local_48[0] = 0x10;
      iVar2 = Ordinal_6(lVar3,&local_30,local_48);
      if (iVar2 == -1) goto LAB_1405492e9;
      if (local_48[0] != 0x10) goto LAB_1405492e1;
      iVar2 = Ordinal_4(uVar5,&local_30,0x10);
      if (iVar2 == -1) goto LAB_1405492e9;
      local_48[0] = 0x10;
      uVar4 = Ordinal_1(lVar3,&local_40,local_48);
      if ((longlong)uVar4 < 0) goto LAB_1405492e9;
      if (local_48[0] == 0x10) {
        iVar2 = Ordinal_6(uVar5,&local_30,local_48);
        if (iVar2 == -1) goto LAB_1405492e9;
        if (((local_48[0] == 0x10) && ((short)local_40 == local_30)) &&
           ((local_40._4_4_ == local_2c && (local_40._2_2_ == local_2e)))) {
          Ordinal_3(lVar3);
          *param_1 = uVar5;
          param_1[1] = uVar4;
          local_48[0] = 1;
          iVar2 = Ordinal_10(uVar5,0x8004667e,local_48);
          if (iVar2 != -1) {
            uVar5 = param_1[1];
            local_48[0] = 1;
            iVar2 = Ordinal_10(uVar5,0x8004667e,local_48);
            if (iVar2 != -1) {
              return 0;
            }
          }
          FUN_14054f810(uVar5,"fcntl(%d, F_GETFL)",uVar5 & 0xffffffff);
          Ordinal_3(*param_1);
          Ordinal_3(param_1[1]);
          goto LAB_140549328;
        }
      }
LAB_1405492e1:
      uVar1 = 0x2745;
    }
    if (lVar3 != -1) {
      Ordinal_3(lVar3);
    }
    if (uVar5 != 0xffffffffffffffff) {
      Ordinal_3(uVar5);
    }
    if (uVar4 != 0xffffffffffffffff) {
      Ordinal_3(uVar4);
    }
  }
  Ordinal_112(uVar1);
LAB_140549328:
  *param_1 = 0xffffffffffffffff;
  param_1[1] = 0xffffffffffffffff;
  return 0xffffffff;
}

// ==== CSocketKernel::helper_14054bcc0  @14054bcc0  [medium:callgraph-r3]  (orig: FUN_14054bcc0)
undefined8 FUN_14054bcc0(longlong param_1,longlong param_2,ushort param_3)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  *(uint *)(param_2 + 0x20) = *(uint *)(param_2 + 0x20) | (uint)param_3;
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CSocketKernel::helper_14054bd10  @14054bd10  [medium:callgraph-r3]  (orig: FUN_14054bd10)
undefined8 FUN_14054bd10(longlong param_1,longlong param_2,ushort param_3)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f1e0(0);
  }
  *(uint *)(param_2 + 0x20) = *(uint *)(param_2 + 0x20) & ~(uint)param_3;
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_14054f200(0);
  }
  return 0;
}

// ==== CSocketKernel::helper_14054e770  @14054e770  [medium:callgraph-r2]  (orig: FUN_14054e770)
undefined8 FUN_14054e770(undefined4 *param_1)

{
  ulonglong uVar1;
  _FILETIME local_res8 [4];
  
  if (param_1 != (undefined4 *)0x0) {
    GetSystemTimeAsFileTime(local_res8);
    if (0x19db1ded53e7fff < (ulonglong)local_res8[0]) {
      *param_1 = (int)(((longlong)local_res8[0] + 0xfe624e212ac18000U) / 10000000);
      uVar1 = ((longlong)local_res8[0] + 0xfe624e212ac18000U) / 10;
      param_1[1] = (int)uVar1 + (int)(uVar1 / 1000000) * -1000000;
      return 0;
    }
  }
  return 0xffffffff;
}

// ==== CSocketKernel::helper_14054e800  @14054e800  [medium:callgraph-r2]  (orig: FUN_14054e800)
int FUN_14054e800(int *param_1)

{
  if ((param_1[1] < 0xf4241) && (*param_1 < 0x20c49b)) {
    return (param_1[1] + 999) / 1000 + *param_1 * 1000;
  }
  return -1;
}

// ==== CSocketKernel::helper_14054e8a0  @14054e8a0  [medium:callgraph-r3]  (orig: FUN_14054e8a0)
void FUN_14054e8a0(longlong param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  bool bVar4;
  
  *param_2 = *param_2 + *(int *)(param_1 + 0x3c);
  param_2[1] = param_2[1] + *(int *)(param_1 + 0x40);
  if (999999 < param_2[1]) {
    *param_2 = *param_2 + 1;
    param_2[1] = param_2[1] + -1000000;
  }
  iVar2 = *param_2;
  iVar3 = *(int *)(param_1 + 0x44);
  bVar4 = SBORROW4(iVar2,iVar3);
  iVar1 = iVar2 - iVar3;
  if (iVar2 == iVar3) {
    bVar4 = SBORROW4(param_2[1],*(int *)(param_1 + 0x48));
    iVar1 = param_2[1] - *(int *)(param_1 + 0x48);
  }
  if (bVar4 != iVar1 < 0) {
    iVar3 = iVar3 - iVar2;
    iVar2 = *(int *)(param_1 + 0x48) - param_2[1];
    if (iVar2 < 0) {
      iVar3 = iVar3 + -1;
      iVar2 = iVar2 + 1000000;
    }
    *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + iVar3;
    *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + iVar2;
    if (999999 < *(int *)(param_1 + 0x40)) {
      *(int *)(param_1 + 0x3c) = *(int *)(param_1 + 0x3c) + 1;
      *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + -1000000;
    }
    *(undefined8 *)param_2 = *(undefined8 *)(param_1 + 0x44);
  }
  *(undefined8 *)(param_1 + 0x44) = *(undefined8 *)param_2;
  return;
}

// ==== CSocketKernel::helper_14054e980  @14054e980  [medium:callgraph-r2]  (orig: FUN_14054e980)
ulonglong FUN_14054e980(undefined8 *param_1)

{
  DWORD DVar1;
  ulonglong uVar2;
  
  if ((code *)*param_1 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014054e996. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (*(code *)*param_1)();
    return uVar2;
  }
  if ((code *)param_1[1] != (code *)0x0) {
    uVar2 = (*(code *)param_1[1])();
    return uVar2 & 0xffffffff | uVar2 >> 0x12 & 0x3fff00000000;
  }
  DVar1 = GetTickCount();
  uVar2 = (ulonglong)DVar1;
  if (uVar2 < (ulonglong)param_1[2]) {
    param_1[3] = param_1[3] + 0x100000000;
  }
  param_1[2] = uVar2;
  return param_1[3] + uVar2;
}

// ==== CSocketKernel::helper_14054e9f0  @14054e9f0  [medium:callgraph-r1]  (orig: FUN_14054e9f0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_14054e9f0(undefined8 *param_1,uint param_2)

{
  double dVar1;
  BOOL BVar2;
  HMODULE hModule;
  FARPROC pFVar3;
  undefined8 uVar4;
  LARGE_INTEGER local_res8;
  LARGE_INTEGER local_res18 [2];
  
  memset(param_1,0,0x50);
  hModule = (HMODULE)FUN_140546fa0("kernel32.dll");
  if ((hModule != (HMODULE)0x0) && ((param_2 & 2) == 0)) {
    pFVar3 = GetProcAddress(hModule,"GetTickCount64");
    *param_1 = pFVar3;
    pFVar3 = GetProcAddress(hModule,"GetTickCount");
    param_1[1] = pFVar3;
  }
  uVar4 = FUN_14054e980(param_1);
  param_1[2] = uVar4;
  param_1[4] = uVar4;
  if (((param_2 & 1) != 0) && ((param_2 & 2) == 0)) {
    BVar2 = QueryPerformanceFrequency(local_res18);
    if (BVar2 != 0) {
      QueryPerformanceCounter(&local_res8);
      *(undefined4 *)(param_1 + 7) = 1;
      dVar1 = _DAT_1407a1a68;
      *(LARGE_INTEGER *)(param_1 + 5) = local_res8;
      param_1[6] = dVar1 / (double)local_res18[0].QuadPart;
    }
  }
  return 0;
}

// ==== CSocketKernel::helper_14054ead0  @14054ead0  [medium:callgraph-r2]  (orig: FUN_14054ead0)
undefined8 FUN_14054ead0(longlong param_1,int *param_2)

{
  undefined1 auVar1 [16];
  int iVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  double dVar7;
  LARGE_INTEGER local_res8;
  
  uVar3 = FUN_14054e980();
  if (*(int *)(param_1 + 0x38) == 0) {
    auVar1._8_8_ = 0;
    auVar1._0_8_ = uVar3;
    lVar6 = SUB168(ZEXT816(0x624dd2f1a9fbe77) * auVar1,8);
    iVar2 = (int)((uVar3 - lVar6 >> 1) + lVar6 >> 9);
    *param_2 = iVar2;
    param_2[1] = ((int)uVar3 + iVar2 * -1000) * 1000;
  }
  else {
    QueryPerformanceCounter(&local_res8);
    lVar5 = (uVar3 - *(longlong *)(param_1 + 0x20)) * 1000;
    lVar6 = (longlong)
            ((double)(local_res8.QuadPart - *(longlong *)(param_1 + 0x28)) *
            *(double *)(param_1 + 0x30));
    lVar4 = lVar5 - lVar6;
    if (lVar4 < 0) {
      lVar4 = -lVar4;
    }
    if (1000000 < lVar4) {
      lVar6 = 0;
      dVar7 = (double)local_res8.QuadPart - (double)lVar5 / *(double *)(param_1 + 0x30);
      if ((DAT_14079e090 < dVar7) && (dVar7 = dVar7 - DAT_14079e090, dVar7 < DAT_14079e090)) {
        lVar6 = -0x8000000000000000;
      }
      *(longlong *)(param_1 + 0x28) = (longlong)dVar7 + lVar6;
      lVar6 = lVar5;
    }
    iVar2 = (int)(lVar6 / 1000000);
    *param_2 = iVar2;
    param_2[1] = (int)lVar6 + iVar2 * -1000000;
  }
  FUN_14054e8a0(param_1,param_2);
  return 0;
}

// ==== CSocketKernel::helper_14054ec30  @14054ec30  [medium:callgraph-r1]  (orig: FUN_14054ec30)
void FUN_14054ec30(undefined8 param_1)

{
  DAT_140976da8 = param_1;
  return;
}

// ==== CSocketKernel::helper_14054ec40  @14054ec40  [medium:callgraph-r1]  (orig: FUN_14054ec40)
undefined8 FUN_14054ec40(int *param_1)

{
  undefined8 uVar1;
  int *piVar2;
  
  piVar2 = (int *)&DAT_140976d80;
  if (DAT_140976d78 != 0) {
    piVar2 = (int *)&DAT_140976dd8;
  }
  if (param_1 == (int *)0x0) {
    if (*(longlong *)(piVar2 + 2) != 0) {
      FUN_14054f8b0(
                   "Trying to disable lock functions after they have been set up will probaby not work."
                   );
    }
    piVar2[0] = 0;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    piVar2[4] = 0;
    piVar2[5] = 0;
    piVar2[6] = 0;
    piVar2[7] = 0;
    piVar2[8] = 0;
    piVar2[9] = 0;
    return 0;
  }
  if (*(longlong *)(piVar2 + 2) == 0) {
    if ((((*(longlong *)(param_1 + 2) != 0) && (*(longlong *)(param_1 + 4) != 0)) &&
        (*(longlong *)(param_1 + 6) != 0)) && (*(longlong *)(param_1 + 8) != 0)) {
      *(undefined8 *)piVar2 = *(undefined8 *)param_1;
      *(undefined8 *)(piVar2 + 2) = *(undefined8 *)(param_1 + 2);
      *(undefined8 *)(piVar2 + 4) = *(undefined8 *)(param_1 + 4);
      *(undefined8 *)(piVar2 + 6) = *(undefined8 *)(param_1 + 6);
      *(undefined8 *)(piVar2 + 8) = *(undefined8 *)(param_1 + 8);
      uVar1 = FUN_14053e5f0(1);
      return uVar1;
    }
  }
  else {
    if ((((*piVar2 == *param_1) && (piVar2[1] == param_1[1])) &&
        ((*(longlong *)(piVar2 + 2) == *(longlong *)(param_1 + 2) &&
         ((*(longlong *)(piVar2 + 4) == *(longlong *)(param_1 + 4) &&
          (*(longlong *)(piVar2 + 6) == *(longlong *)(param_1 + 6))))))) &&
       (*(longlong *)(piVar2 + 8) == *(longlong *)(param_1 + 8))) {
      return 0;
    }
    FUN_14054f8b0("Can\'t change lock callbacks once they have been initialized.");
  }
  return 0xffffffff;
}

// ==== CSocketKernel::helper_14054ed40  @14054ed40  [medium:callgraph-r1]  (orig: FUN_14054ed40)
undefined8 FUN_14054ed40(int *param_1)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = DAT_140976d78;
  piVar2 = (int *)&DAT_140976db0;
  if (DAT_140976d78 != 0) {
    piVar2 = (int *)&DAT_140976e00;
  }
  if (param_1 == (int *)0x0) {
    if (*(longlong *)(piVar2 + 2) != 0) {
      FUN_14054f8b0(
                   "Trying to disable condition functions after they have been set up will probaby not work."
                   );
    }
    piVar2[0] = 0;
    piVar2[1] = 0;
    piVar2[2] = 0;
    piVar2[3] = 0;
    piVar2[4] = 0;
    piVar2[5] = 0;
    piVar2[6] = 0;
    piVar2[7] = 0;
    piVar2[8] = 0;
    piVar2[9] = 0;
    return 0;
  }
  if (*(longlong *)(piVar2 + 2) == 0) {
    if ((((*(longlong *)(param_1 + 2) != 0) && (*(longlong *)(param_1 + 4) != 0)) &&
        (*(longlong *)(param_1 + 6) != 0)) && (*(longlong *)(param_1 + 8) != 0)) {
      *(undefined8 *)piVar2 = *(undefined8 *)param_1;
      *(undefined8 *)(piVar2 + 2) = *(undefined8 *)(param_1 + 2);
      *(undefined8 *)(piVar2 + 4) = *(undefined8 *)(param_1 + 4);
      *(undefined8 *)(piVar2 + 6) = *(undefined8 *)(param_1 + 6);
      *(undefined8 *)(piVar2 + 8) = *(undefined8 *)(param_1 + 8);
    }
    if (iVar1 != 0) {
      DAT_140976db8 = *(undefined8 *)(param_1 + 2);
      DAT_140976dc0 = *(undefined8 *)(param_1 + 4);
      DAT_140976dc8 = *(undefined8 *)(param_1 + 6);
    }
  }
  else if (((*piVar2 != *param_1) || (*(longlong *)(piVar2 + 2) != *(longlong *)(param_1 + 2))) ||
          ((*(longlong *)(piVar2 + 4) != *(longlong *)(param_1 + 4) ||
           ((*(longlong *)(piVar2 + 6) != *(longlong *)(param_1 + 6) ||
            (*(longlong *)(piVar2 + 8) != *(longlong *)(param_1 + 8))))))) {
    FUN_14054f8b0("Can\'t change condition callbacks once they have been initialized.");
    return 0xffffffff;
  }
  return 0;
}

// ==== CSocketKernel::helper_14054f180  @14054f180  [medium:callgraph-r1]  (orig: FUN_14054f180)
undefined8 FUN_14054f180(void)

{
  undefined8 uVar1;
  
  if (DAT_140976da8 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014054f18c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*DAT_140976da8)();
    return uVar1;
  }
  return 1;
}

// ==== CSocketKernel::helper_14054f1a0  @14054f1a0  [medium:callgraph-r1]  (orig: FUN_14054f1a0)
undefined8 FUN_14054f1a0(void)

{
  undefined8 uVar1;
  
  if (DAT_140976d88 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014054f1ac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*DAT_140976d88)();
    return uVar1;
  }
  return 0;
}

// ==== CSocketKernel::helper_14054f1c0  @14054f1c0  [medium:callgraph-r2]  (orig: FUN_14054f1c0)
void FUN_14054f1c0(void)

{
  if (DAT_140976d90 != (code *)0x0) {
    (*DAT_140976d90)();
  }
  return;
}

// ==== CSocketKernel::helper_14054f220  @14054f220  [medium:callgraph-r1]  (orig: FUN_14054f220)
undefined8 FUN_14054f220(void)

{
  undefined8 uVar1;
  
  if (DAT_140976db8 != (code *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014054f22c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (*DAT_140976db8)();
    return uVar1;
  }
  return 0;
}

// ==== CSocketKernel::helper_14054f240  @14054f240  [medium:callgraph-r2]  (orig: FUN_14054f240)
void FUN_14054f240(void)

{
  if (DAT_140976dc0 != (code *)0x0) {
    (*DAT_140976dc0)();
  }
  return;
}

// ==== CSocketKernel::helper_14054f2a0  @14054f2a0  [medium:callgraph-r2]  (orig: FUN_14054f2a0)
undefined4 FUN_14054f2a0(void)

{
  return DAT_140976d78;
}

// ==== CSocketKernel::helper_14054f2b0  @14054f2b0  [medium:callgraph-r1]  (orig: FUN_14054f2b0)
bool FUN_14054f2b0(void)

{
  return DAT_140976d98 != 0;
}

// ==== CSocketKernel::helper_14054f590  @14054f590  [medium:callgraph-r2]  (orig: FUN_14054f590)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14054f590(int param_1,longlong param_2,longlong param_3)

{
  FILE *pFVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  char *pcVar4;
  undefined1 auStack_458 [31];
  char acStack_439 [1025];
  ulonglong local_38;
  
  if (param_1 != 0) {
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_458;
    if (param_3 == 0) {
      acStack_439[1] = 0;
    }
    else {
      FUN_1405469f0(acStack_439 + 1,0x400);
    }
    if (param_2 != 0) {
      uVar2 = 0xffffffffffffffff;
      pcVar4 = acStack_439;
      do {
        pcVar4 = pcVar4 + 1;
        if (uVar2 == 0) break;
        uVar2 = uVar2 - 1;
      } while (*pcVar4 != '\0');
      uVar3 = ~uVar2 - 1;
      if (uVar3 < 0x3fd) {
        FUN_140547660(acStack_439 + ~uVar2,0x400 - uVar3,&DAT_1407a1c00,param_2);
      }
    }
    if (DAT_140976e30 == (code *)0x0) {
      pFVar1 = __iob_func();
      fprintf(pFVar1 + 2,"[%s] %s\n");
    }
    else {
      (*DAT_140976e30)(param_1,acStack_439 + 1);
    }
  }
  return;
}

// ==== CSocketKernel::helper_14054f740  @14054f740  [medium:callgraph-r1]  (orig: FUN_14054f740)
void FUN_14054f740(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int *piVar1;
  char *pcVar2;
  undefined8 local_res10;
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res10 = param_2;
  local_res18 = param_3;
  local_res20 = param_4;
  piVar1 = _errno();
  pcVar2 = strerror(*piVar1);
  FUN_14054f590(2,pcVar2,param_1,&local_res10);
  return;
}

// ==== CSocketKernel::helper_14054f8b0  @14054f8b0  [medium:callgraph-r1]  (orig: FUN_14054f8b0)
void FUN_14054f8b0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res10;
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res10 = param_2;
  local_res18 = param_3;
  local_res20 = param_4;
  FUN_14054f590(2,0,param_1,&local_res10);
  return;
}

// ==== CSocketKernel::helper_14054f8e0  @14054f8e0  [medium:callgraph-r1]  (orig: FUN_14054f8e0)
void FUN_14054f8e0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res10;
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res10 = param_2;
  local_res18 = param_3;
  local_res20 = param_4;
  FUN_14054f590(1,0,param_1,&local_res10);
  return;
}

// ==== CSocketKernel::helper_14054fec0  @14054fec0  [medium:callgraph-r1]  (orig: FUN_14054fec0)
void FUN_14054fec0(undefined8 *param_1)

{
  *(undefined4 *)((longlong)param_1 + 0x14) = 0xffffffff;
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  return;
}

// ==== CSocketKernel::helper_14054fee0  @14054fee0  [medium:callgraph-r2]  (orig: FUN_14054fee0)
void FUN_14054fee0(longlong *param_1)

{
  uint uVar1;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar2;
  
  plVar5 = (longlong *)0x0;
  if ((int)param_1[1] != 0) {
    plVar2 = plVar5;
    plVar4 = (longlong *)*param_1;
    do {
      if (*plVar4 != 0) {
        plVar2 = (longlong *)*param_1 + (longlong)plVar2;
        while (plVar2 != (longlong *)0x0) {
          plVar4 = (longlong *)*plVar2;
          uVar1 = *(uint *)(plVar4 + 1);
          *plVar2 = *plVar4;
          *(int *)((longlong)param_1 + 0xc) = *(int *)((longlong)param_1 + 0xc) + -1;
          if (*plVar2 == 0) {
            uVar1 = ((uVar1 >> 2 | uVar1 << 0x1e) + uVar1) % *(uint *)(param_1 + 1) + 1;
            plVar2 = plVar5;
            if (uVar1 < *(uint *)(param_1 + 1)) {
              plVar3 = (longlong *)(*param_1 + (longlong)(int)uVar1 * 8);
              do {
                if (*plVar3 != 0) {
                  plVar2 = (longlong *)(*param_1 + (ulonglong)uVar1 * 8);
                  break;
                }
                uVar1 = uVar1 + 1;
                plVar3 = plVar3 + 1;
              } while (uVar1 < *(uint *)(param_1 + 1));
            }
          }
          FUN_14053de00(plVar4);
        }
        break;
      }
      uVar1 = (int)plVar2 + 1;
      plVar2 = (longlong *)(ulonglong)uVar1;
      plVar4 = plVar4 + 1;
    } while (uVar1 < *(uint *)(param_1 + 1));
  }
  if (*param_1 != 0) {
    FUN_14053de00();
  }
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0xffffffff;
  return;
}

// ==== CSocketKernel::helper_140550040  @140550040  [medium:callgraph-r1]  (orig: FUN_140550040)
void FUN_140550040(undefined8 *param_1)

{
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = 0;
  return;
}

// ==== CSocketKernel::helper_140550050  @140550050  [medium:callgraph-r2]  (orig: FUN_140550050)
void FUN_140550050(longlong *param_1)

{
  int iVar1;
  longlong lVar2;
  
  if (*param_1 == 0) {
    *(undefined4 *)(param_1 + 1) = 0;
    return;
  }
  iVar1 = 0;
  if (0 < (int)param_1[1]) {
    lVar2 = 0;
    do {
      if (*(longlong *)(lVar2 + *param_1) != 0) {
        FUN_14053de00(*(undefined8 *)(lVar2 + *param_1));
      }
      iVar1 = iVar1 + 1;
      lVar2 = lVar2 + 8;
    } while (iVar1 < (int)param_1[1]);
  }
  FUN_14053de00(*param_1);
  *param_1 = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return;
}

// ==== CSocketKernel::helper_140550780  @140550780  [medium:callgraph-r3]  (orig: FUN_140550780)
ulonglong FUN_140550780(longlong param_1,code *param_2,undefined8 param_3)

{
  uint uVar1;
  ulonglong uVar2;
  longlong *plVar3;
  uint uVar4;
  ulonglong uVar5;
  
  uVar2 = 0;
  if (*(uint *)(param_1 + 0x130) != 0) {
    plVar3 = *(longlong **)(param_1 + 0x128);
    do {
      if (*plVar3 != 0) {
        plVar3 = *(longlong **)(param_1 + 0x128) + uVar2;
        if (plVar3 == (longlong *)0x0) {
          return 0;
        }
        do {
          uVar2 = (*param_2)(param_1,*(undefined8 *)(*plVar3 + 8),*plVar3 + 0x10,param_3);
          uVar5 = uVar2 & 0xffffffff;
          if ((int)uVar2 != 0) {
            return uVar2;
          }
          plVar3 = (longlong *)*plVar3;
          if (*plVar3 == 0) {
            uVar4 = *(uint *)(plVar3 + 1);
            uVar1 = *(uint *)(param_1 + 0x130);
            uVar4 = ((uVar4 >> 2 | uVar4 << 0x1e) + uVar4) % uVar1 + 1;
            if (uVar1 <= uVar4) {
              return uVar5;
            }
            plVar3 = (longlong *)(*(longlong *)(param_1 + 0x128) + (longlong)(int)uVar4 * 8);
            while (*plVar3 == 0) {
              uVar4 = uVar4 + 1;
              plVar3 = plVar3 + 1;
              if (uVar1 <= uVar4) {
                return uVar5;
              }
            }
            plVar3 = (longlong *)(*(longlong *)(param_1 + 0x128) + (ulonglong)uVar4 * 8);
          }
        } while (plVar3 != (longlong *)0x0);
        return uVar5;
      }
      uVar4 = (int)uVar2 + 1;
      uVar2 = (ulonglong)uVar4;
      plVar3 = plVar3 + 1;
    } while (uVar4 < *(uint *)(param_1 + 0x130));
  }
  return 0;
}

// ==== CSocketKernel::helper_140550b10  @140550b10  [medium:callgraph-r3]  (orig: FUN_140550b10)
undefined8 FUN_140550b10(undefined8 param_1,undefined8 param_2,longlong *param_3)

{
  longlong lVar1;
  
  lVar1 = *param_3;
  while (lVar1 != 0) {
    FUN_140540740(lVar1);
    lVar1 = *param_3;
  }
  return 0;
}

// ==== CSocketKernel::helper_140550b70  @140550b70  [medium:callgraph-r2]  (orig: FUN_140550b70)
void FUN_140550b70(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  uint uVar4;
  ulonglong uVar5;
  
  uVar3 = 0;
  uVar5 = uVar3;
  if (0 < *(int *)(param_1 + 0x148)) {
    do {
      plVar1 = *(longlong **)(uVar3 + *(longlong *)(param_1 + 0x140));
      if (plVar1 != (longlong *)0x0) {
        lVar2 = *plVar1;
        while (lVar2 != 0) {
          FUN_140540740(lVar2);
          lVar2 = *plVar1;
        }
      }
      uVar4 = (int)uVar5 + 1;
      uVar3 = uVar3 + 8;
      uVar5 = (ulonglong)uVar4;
    } while ((int)uVar4 < *(int *)(param_1 + 0x148));
  }
  FUN_140550780(param_1,FUN_140550b10,0);
  return;
}

// ==== CSocketKernel::helper_140550c00  @140550c00  [medium:callgraph-r1]  (orig: FUN_140550c00)
void FUN_140550c00(undefined8 *param_1)

{
  *param_1 = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return;
}

// ==== CSocketKernel::helper_140550de0  @140550de0  [medium:callgraph-r2]  (orig: FUN_140550de0)
void FUN_140550de0(longlong *param_1)

{
  if (*param_1 != 0) {
    FUN_14053de00();
  }
  *param_1 = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 1) = 0;
  return;
}

// ==== CSocketKernel::helper_140551980  @140551980  [medium:callgraph-r1]  (orig: FUN_140551980)
void FUN_140551980(void)

{
  if (DAT_140977240 != 0) {
    FUN_14054f1c0(DAT_140977240,0);
    DAT_140977240 = 0;
  }
  return;
}

// ==== CSocketKernel::helper_1405519b0  @1405519b0  [medium:callgraph-r3]  (orig: FUN_1405519b0)
undefined8 FUN_1405519b0(undefined4 param_1)

{
  DAT_140977240 = FUN_14054f090(DAT_140977240,0,param_1);
  if (DAT_140977240 == 0) {
    FUN_14054f740("Couldn\'t allocate %s","evsig_base_lock");
    return 0xffffffff;
  }
  return 0;
}

// ==== CSocketKernel::helper_140551e60  @140551e60  [medium:callgraph-r3]  (orig: FUN_140551e60)
undefined8 FUN_140551e60(undefined4 param_1)

{
  DAT_140977268 = FUN_14054f090(DAT_140977268,0,param_1);
  if (DAT_140977268 == 0) {
    FUN_14054f740("Couldn\'t allocate %s","arc4rand_lock");
    return 0xffffffff;
  }
  return 0;
}

// ==== CSocketKernel::helper_140551ef0  @140551ef0  [medium:callgraph-r2]  (orig: FUN_140551ef0)
void FUN_140551ef0(void)

{
  if (DAT_140977268 != 0) {
    FUN_14054f1c0(DAT_140977268,0);
    DAT_140977268 = 0;
  }
  return;
}

// ==== CSocketKernel::helper_1405c6930  @1405c6930  [medium:callgraph-r2]  (orig: FUN_1405c6930)
void FUN_1405c6930(undefined8 *param_1)

{
  short *psVar1;
  short sVar2;
  HANDLE CompletionPort;
  BOOL BVar3;
  DWORD dwMilliseconds;
  DWORD local_res8 [2];
  LPOVERLAPPED local_res10;
  ulonglong local_res18;
  
  dwMilliseconds = *(DWORD *)((longlong)param_1 + 0x34);
  CompletionPort = (HANDLE)*param_1;
  if ((int)dwMilliseconds < 1) {
    dwMilliseconds = 0xffffffff;
  }
  local_res10 = (LPOVERLAPPED)0x0;
  local_res18 = 0;
  local_res8[0] = 0;
  BVar3 = GetQueuedCompletionStatus
                    (CompletionPort,local_res8,&local_res18,&local_res10,dwMilliseconds);
  EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  sVar2 = *(short *)((longlong)param_1 + 0x32);
  do {
    if (sVar2 != 0) {
LAB_1405c6a1e:
      psVar1 = (short *)(param_1 + 8);
      *psVar1 = *psVar1 + -1;
      if (*psVar1 == 0) {
        ReleaseSemaphore((HANDLE)param_1[9],1,(LPLONG)0x0);
      }
      LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
      return;
    }
    LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
    if (local_res18 == 0xffffffffffffffff) {
      if (local_res10 == (LPOVERLAPPED)0x0) goto LAB_1405c6a08;
    }
    else {
      if (local_res10 == (LPOVERLAPPED)0x0) {
LAB_1405c6a08:
        FUN_14054f8b0("GetQueuedCompletionStatus exited with no event.");
        EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
        goto LAB_1405c6a1e;
      }
      (*(code *)local_res10[1].Internal)(local_res10,local_res18,local_res8[0],BVar3);
    }
    local_res10 = (LPOVERLAPPED)0x0;
    local_res18 = 0;
    local_res8[0] = 0;
    BVar3 = GetQueuedCompletionStatus
                      (CompletionPort,local_res8,&local_res18,&local_res10,dwMilliseconds);
    EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
    sVar2 = *(short *)((longlong)param_1 + 0x32);
  } while( true );
}

// ==== CSocketKernel::helper_1405c6ae0  @1405c6ae0  [medium:callgraph-r2]  (orig: FUN_1405c6ae0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405c6ae0(undefined8 *param_1)

{
  longlong lVar1;
  undefined1 auStack_a8 [32];
  undefined8 *local_88;
  undefined4 local_80;
  undefined4 *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined4 local_58 [2];
  undefined8 local_50;
  undefined4 local_48;
  undefined2 local_44;
  undefined2 local_42;
  undefined1 local_40;
  undefined1 local_3f;
  undefined1 local_3e;
  undefined1 local_3d;
  undefined1 local_3c;
  undefined1 local_3b;
  undefined1 local_3a;
  undefined1 local_39;
  undefined4 local_38;
  undefined2 local_34;
  undefined2 local_32;
  undefined1 local_30;
  undefined1 local_2f;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 local_2b;
  undefined1 local_2a;
  undefined1 local_29;
  undefined4 local_28;
  undefined2 local_24;
  undefined2 local_22;
  undefined1 local_20;
  undefined1 local_1f;
  undefined1 local_1e;
  undefined1 local_1d;
  undefined1 local_1c;
  undefined1 local_1b;
  undefined1 local_1a;
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  local_44 = 0xcbac;
  local_24 = 0xcbac;
  local_42 = 0x11cf;
  local_22 = 0x11cf;
  local_34 = 0xddf3;
  local_48 = 0xb5367df1;
  local_40 = 0x95;
  local_3f = 0xca;
  local_3e = 0;
  local_3d = 0x80;
  local_3c = 0x5f;
  local_3b = 0x48;
  local_3a = 0xa1;
  local_39 = 0x92;
  local_38 = 0x25a207b9;
  local_32 = 0x4660;
  local_30 = 0x8e;
  local_2f = 0xe9;
  local_2e = 0x76;
  local_2d = 0xe5;
  local_2c = 0x8c;
  local_2b = 0x74;
  local_2a = 6;
  local_29 = 0x3e;
  local_28 = 0xb5367df2;
  local_20 = 0x95;
  local_1f = 0xca;
  local_1e = 0;
  local_1d = 0x80;
  local_1c = 0x5f;
  local_1b = 0x48;
  local_1a = 0xa1;
  local_19 = 0x92;
  lVar1 = Ordinal_23(2);
  if (lVar1 != -1) {
    local_78 = local_58;
    local_68 = 0;
    local_70 = 0;
    local_88 = &local_50;
    local_80 = 8;
    local_50 = 0;
    local_58[0] = 0;
    WSAIoctl(lVar1,0xc8000006,&local_48,0x10);
    local_68 = 0;
    local_70 = 0;
    local_78 = local_58;
    local_88 = &local_50;
    local_80 = 8;
    *param_1 = local_50;
    local_50 = 0;
    local_58[0] = 0;
    WSAIoctl(lVar1,0xc8000006,&local_38,0x10);
    local_68 = 0;
    local_70 = 0;
    local_78 = local_58;
    local_88 = &local_50;
    local_80 = 8;
    param_1[1] = local_50;
    local_50 = 0;
    local_58[0] = 0;
    WSAIoctl(lVar1,0xc8000006,&local_28,0x10);
    param_1[2] = local_50;
    Ordinal_3(lVar1);
    DAT_1409774a8 = 1;
  }
  return;
}

// ==== CSocketKernel::helper_1405c6d30  @1405c6d30  [medium:callgraph-r1]  (orig: FUN_1405c6d30)
undefined8 * FUN_1405c6d30(DWORD param_1)

{
  short sVar1;
  undefined8 *_ArgList;
  longlong lVar2;
  HANDLE pvVar3;
  uintptr_t uVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  
  if (DAT_1409774a8 == 0) {
    FUN_1405c6ae0(&DAT_140977490);
  }
  _ArgList = (undefined8 *)FUN_14053dc90(1);
  if (_ArgList == (undefined8 *)0x0) {
    return (undefined8 *)0x0;
  }
  if ((int)param_1 < 1) {
    param_1 = 2;
  }
  sVar1 = (short)param_1 * 2;
  *(short *)(_ArgList + 6) = sVar1;
  lVar2 = FUN_14053dc90((longlong)sVar1,8);
  _ArgList[7] = lVar2;
  if (lVar2 != 0) {
    pvVar3 = CreateIoCompletionPort((HANDLE)0xffffffffffffffff,(HANDLE)0x0,0,param_1);
    *(undefined4 *)((longlong)_ArgList + 0x34) = 0xffffffff;
    *_ArgList = pvVar3;
    if (pvVar3 == (HANDLE)0x0) goto LAB_1405c6e53;
    pvVar3 = CreateSemaphoreA((LPSECURITY_ATTRIBUTES)0x0,0,1,(LPCSTR)0x0);
    _ArgList[9] = pvVar3;
    if (pvVar3 != (HANDLE)0x0) {
      uVar5 = 0;
      uVar7 = uVar5;
      if (0 < *(short *)(_ArgList + 6)) {
        do {
          uVar4 = _beginthread(FUN_1405c6930,0,_ArgList);
          if (uVar4 == 0xffffffffffffffff) goto LAB_1405c6e45;
          uVar6 = (int)uVar7 + 1;
          *(uintptr_t *)(uVar5 + _ArgList[7]) = uVar4;
          *(short *)(_ArgList + 8) = *(short *)(_ArgList + 8) + 1;
          uVar5 = uVar5 + 8;
          uVar7 = (ulonglong)uVar6;
        } while ((int)uVar6 < (int)*(short *)(_ArgList + 6));
      }
      InitializeCriticalSectionAndSpinCount((LPCRITICAL_SECTION)(_ArgList + 1),1000);
      return _ArgList;
    }
  }
LAB_1405c6e45:
  if ((HANDLE)*_ArgList != (HANDLE)0x0) {
    CloseHandle((HANDLE)*_ArgList);
  }
LAB_1405c6e53:
  if (_ArgList[7] != 0) {
    FUN_14053de00();
  }
  if ((HANDLE)_ArgList[9] != (HANDLE)0x0) {
    CloseHandle((HANDLE)_ArgList[9]);
  }
  FUN_14053de00(_ArgList);
  return (undefined8 *)0x0;
}

// ==== CSocketKernel::helper_1405c6f40  @1405c6f40  [medium:callgraph-r2]  (orig: FUN_1405c6f40)
undefined8 FUN_1405c6f40(undefined8 *param_1,DWORD param_2)

{
  short sVar1;
  undefined8 uVar2;
  int iVar3;
  DWORD dwMilliseconds;
  
  EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  *(undefined2 *)((longlong)param_1 + 0x32) = 1;
  LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  iVar3 = 0;
  if (0 < *(short *)(param_1 + 6)) {
    do {
      PostQueuedCompletionStatus((HANDLE)*param_1,0,0xffffffffffffffff,(LPOVERLAPPED)0x0);
      iVar3 = iVar3 + 1;
    } while (iVar3 < *(short *)(param_1 + 6));
  }
  dwMilliseconds = 0xffffffff;
  if (-1 < (int)param_2) {
    dwMilliseconds = param_2;
  }
  WaitForSingleObject((HANDLE)param_1[9],dwMilliseconds);
  EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  sVar1 = *(short *)(param_1 + 8);
  LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
  if (sVar1 == 0) {
    DeleteCriticalSection((LPCRITICAL_SECTION)(param_1 + 1));
    CloseHandle((HANDLE)*param_1);
    CloseHandle((HANDLE)param_1[9]);
    FUN_14053de00(param_1[7]);
    FUN_14053de00(param_1);
    uVar2 = 0;
  }
  else {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}

