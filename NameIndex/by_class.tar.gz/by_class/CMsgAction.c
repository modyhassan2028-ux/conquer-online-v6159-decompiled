// ==== CMsgAction::helper_14000db40  @14000db40  [medium:callgraph-r1]  (orig: FUN_14000db40)
longlong * FUN_14000db40(longlong param_1,longlong *param_2,long *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  int iVar4;
  ldiv_t lVar5;
  longlong **pplVar6;
  ulonglong uVar7;
  longlong lVar8;
  longlong lVar9;
  int local_res8;
  longlong *local_48;
  undefined8 *puStack_40;
  longlong *local_38;
  undefined8 local_30;
  
  lVar5 = ldiv(*param_3,0x1f31d);
  local_res8 = lVar5.quot;
  iVar4 = lVar5.rem * 0x41a7 + local_res8 * -0xb14;
  if (iVar4 < 0) {
    iVar4 = iVar4 + 0x7fffffff;
  }
  uVar7 = (longlong)iVar4 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar7) {
    uVar7 = uVar7 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar7) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  puStack_40 = *(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + uVar7 * 0x10);
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar8 = 0;
  local_48 = plVar2;
  while( true ) {
    puVar3 = puStack_40;
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar7 + 1
       ) {
      _invalid_parameter_noinfo();
    }
    if (*(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar7 + 1) * 0x10) == puVar3) {
      param_2[1] = *(longlong *)(param_1 + 0x38);
      *param_2 = *plVar1;
      return param_2;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar8;
    }
    else {
      lVar9 = *plVar2;
    }
    if (puVar3 == *(undefined8 **)(lVar9 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)(puVar3 + 2) == *param_3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar8;
    }
    else {
      lVar9 = *plVar2;
    }
    if (puVar3 == *(undefined8 **)(lVar9 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puStack_40 = (undefined8 *)*puVar3;
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar8 = *plVar2;
  }
  if (puVar3 == *(undefined8 **)(lVar8 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*param_3 == *(int *)(puVar3 + 2)) {
    pplVar6 = &local_48;
  }
  else {
    pplVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = (longlong *)*plVar1;
  }
  *param_2 = (longlong)*pplVar6;
  param_2[1] = (longlong)pplVar6[1];
  return param_2;
}

// ==== CMsgAction::helper_14000e3a0  @14000e3a0  [medium:callgraph-r1]  (orig: FUN_14000e3a0)
longlong FUN_14000e3a0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0xd0))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x75);
  puVar3 = *(undefined8 **)(param_1 + 0xd0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x75);
  }
  puVar7 = *(undefined8 **)(param_1 + 0xd0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0xa0);
  if (*(longlong *)(param_1 + 0xa0) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xd0);
    local_28 = *(longlong *)(param_1 + 0xa0);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0xd0);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((*(longlong **)(param_1 + 0xa0) == (longlong *)0x0) ||
     (*(longlong **)(param_1 + 0xa0) != plVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (lVar8 == local_10) {
    lVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar5 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar5 = lVar5 + 0x1c;
  }
  return lVar5;
}

// ==== CMsgAction::helper_14000eea0  @14000eea0  [medium:callgraph-r0]  (orig: FUN_14000eea0)
undefined4 FUN_14000eea0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_14000db40(param_1 + 0x10,&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x48);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x20))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined4 *)(local_10 + 0x14);
  }
  return 0;
}

// ==== CMsgAction::helper_14008a5a0  @14008a5a0  [medium:callgraph-r1]  (orig: FUN_14008a5a0)
undefined1 FUN_14008a5a0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x33c);
}

// ==== CMsgAction::helper_14008a700  @14008a700  [medium:callgraph-r1]  (orig: FUN_14008a700)
byte FUN_14008a700(longlong param_1)

{
  return *(byte *)(param_1 + 0x298) & 1;
}

// ==== CMsgAction::helper_14008ac90  @14008ac90  [medium:callgraph-r1]  (orig: FUN_14008ac90)
longlong FUN_14008ac90(longlong param_1)

{
  return param_1 + 0x2e0;
}

// ==== CMsgAction::helper_14008b010  @14008b010  [medium:callgraph-r0]  (orig: FUN_14008b010)
undefined4 FUN_14008b010(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6a8);
}

// ==== CMsgAction::helper_14008b3e0  @14008b3e0  [medium:callgraph-r2]  (orig: FUN_14008b3e0)
undefined4 FUN_14008b3e0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6d0);
}

// ==== CMsgAction::helper_14008b3f0  @14008b3f0  [medium:callgraph-r2]  (orig: FUN_14008b3f0)
undefined4 FUN_14008b3f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6d4);
}

// ==== CMsgAction::helper_14008b400  @14008b400  [medium:callgraph-r2]  (orig: FUN_14008b400)
undefined4 FUN_14008b400(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6d8);
}

// ==== CMsgAction::helper_14008b430  @14008b430  [medium:callgraph-r0]  (orig: FUN_14008b430)
ulonglong FUN_14008b430(longlong param_1,ulonglong param_2,int param_3)

{
  int iVar1;
  int *piVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  int iVar6;
  
  iVar1 = (int)param_2;
  uVar4 = (ulonglong)iVar1;
  if ((((-1 < iVar1) && (-1 < param_3)) && (iVar1 <= param_3)) && (param_3 < 5)) {
    if (iVar1 == 0) {
      iVar6 = 0;
      iVar1 = *(int *)(param_1 + 0x7e8 + (longlong)param_3 * 4);
    }
    else {
      iVar6 = *(int *)(param_1 + 0x7e4 + uVar4 * 4);
      iVar1 = *(int *)(param_1 + 0x7e8 + (longlong)param_3 * 4) - iVar6;
    }
    iVar1 = tq::RandGet(iVar1);
    uVar3 = param_2 & 0xffffffff;
    uVar5 = uVar4;
    if ((longlong)uVar4 <= (longlong)param_3) {
      piVar2 = (int *)(param_1 + 0x7e8 + uVar4 * 4);
      while (uVar5 = uVar3, *piVar2 <= iVar6 + iVar1) {
        uVar4 = uVar4 + 1;
        uVar3 = (ulonglong)((int)uVar3 + 1);
        piVar2 = piVar2 + 1;
        if ((longlong)param_3 < (longlong)uVar4) {
          return param_2 & 0xffffffff;
        }
      }
    }
    return uVar5 & 0xffffffff;
  }
  return 0;
}

// ==== CMsgAction::helper_140091b80  @140091b80  [medium:callgraph-r1]  (orig: FUN_140091b80)
undefined1 FUN_140091b80(longlong *param_1)

{
  if ((*param_1 != 0) && (param_1[1] == 0)) {
    return 1;
  }
  return 0;
}

// ==== CMsgAction::helper_140091ba0  @140091ba0  [medium:callgraph-r1]  (orig: FUN_140091ba0)
void FUN_140091ba0(longlong *param_1)

{
  char cVar1;
  
  if (*param_1 != 0) {
    cVar1 = FUN_140091b80();
    if (cVar1 != '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    *(longlong *)(param_1[1] + 0x10) = param_1[2];
    if (param_1[2] != 0) {
      *(longlong *)(param_1[2] + 8) = param_1[1];
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}

// ==== CMsgAction::helper_1400ded80  @1400ded80  [medium:callgraph-r2]  (orig: FUN_1400ded80)
void FUN_1400ded80(longlong *param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  void **ppvVar4;
  longlong *plVar5;
  longlong lVar6;
  char cVar7;
  undefined4 uVar8;
  longlong lVar9;
  void *pvVar10;
  void *pvVar11;
  longlong *plVar12;
  undefined4 local_res10 [2];
  void **local_res18;
  void **local_res20;
  void **local_1d0 [3];
  longlong *local_1b8;
  longlong *local_1b0;
  undefined8 local_1a8;
  undefined8 local_198;
  undefined8 uStack_190;
  longlong local_188;
  void *local_178;
  undefined8 uStack_170;
  longlong *local_168 [3];
  undefined4 local_150 [2];
  longlong local_148;
  longlong *local_140;
  longlong local_138;
  undefined4 local_130 [2];
  longlong local_128;
  void *local_118 [6];
  undefined8 *local_e8;
  undefined8 local_e0;
  undefined4 local_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  void **local_c8;
  undefined8 local_b8;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98 [2];
  void *local_90 [8];
  undefined8 local_50 [3];
  
  local_b8 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  local_res18 = operator_new(8);
  if (local_res18 == (void **)0x0) {
    local_1d0[0] = (void **)0x0;
  }
  else {
    *local_res18 = local_1d0;
    local_1d0[0] = local_res18;
  }
  pvVar11 = (void *)0x0;
  local_1b8 = (longlong *)0x0;
  local_1b0 = (longlong *)0x0;
  local_1a8 = 0;
  local_res20 = local_res18;
  lVar9 = FUN_140008520((int)param_1[8]);
  if (*(longlong *)(lVar9 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    pvVar10 = pvVar11;
  }
  else {
    pvVar10 = *(void **)(lVar9 + 0x170);
  }
  FUN_140313fc0(pvVar10,local_1d0,local_res10[0],0x19);
  plVar12 = local_1b8;
  ppvVar4 = local_1d0[0];
  if (local_1b0 < local_1b8) {
    _invalid_parameter_noinfo();
    ppvVar4 = local_1d0[0];
  }
  while( true ) {
    plVar5 = local_1b0;
    local_c8 = (void **)0x0;
    if (local_1b0 < local_1b8) {
      _invalid_parameter_noinfo();
    }
    local_c8 = local_1d0[0];
    if ((ppvVar4 == (void **)0x0) || (ppvVar4 != local_1d0[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar12 == plVar5) break;
    if (ppvVar4 == (void **)0x0) {
      _invalid_parameter_noinfo();
      pvVar10 = pvVar11;
    }
    else {
      pvVar10 = *ppvVar4;
    }
    if (*(longlong **)((longlong)pvVar10 + 0x20) <= plVar12) {
      _invalid_parameter_noinfo();
    }
    puVar1 = (undefined8 *)*plVar12;
    if (puVar1 != (undefined8 *)0x0) {
      lVar9 = FUN_14035b110();
      local_188 = lVar9;
      if (lVar9 == 0) {
        (**(code **)*puVar1)(puVar1,1);
      }
      else {
        cVar7 = FUN_14035abd0(lVar9,puVar1);
        if (cVar7 == '\0') {
          FUN_14035b7a0(lVar9);
          local_188 = 0;
          (**(code **)*puVar1)(puVar1,1);
        }
        else {
          uVar8 = FUN_14035ab70(lVar9);
          local_res18 = (void **)CONCAT44(local_res18._4_4_,uVar8);
          FUN_1400db220(param_1,&local_140,local_res10);
          plVar5 = local_140;
          lVar2 = param_1[6];
          local_168[0] = (longlong *)*param_1;
          if ((local_140 == (longlong *)0x0) || (local_140 != local_168[0])) {
            _invalid_parameter_noinfo();
          }
          lVar6 = local_138;
          if (local_138 == lVar2) {
            FUN_1400ddfe0(local_118);
            local_130[0] = local_res18._0_4_;
            local_128 = lVar9;
            FUN_1400db2f0(local_118,local_168,local_130);
            local_98[0] = local_res10[0];
            local_res18 = local_90;
            FUN_1400dd8e0(local_90,local_118);
            FUN_1400de680(param_1,local_168,local_98);
            local_res18 = local_90;
            FUN_1400dd560(local_90);
            operator_delete(local_90[0]);
            uStack_190 = local_e8;
            puVar1 = uStack_190;
            local_198 = local_118[0];
            pvVar10 = local_198;
            uVar3 = *local_e8;
            local_178 = local_118[0];
            local_198._0_4_ = SUB84(local_118[0],0);
            local_198._4_4_ = (undefined4)((ulonglong)local_118[0] >> 0x20);
            uStack_190._0_4_ = SUB84(local_e8,0);
            uStack_190._4_4_ = (undefined4)((ulonglong)local_e8 >> 0x20);
            local_a8 = (undefined4)local_198;
            uStack_a4 = local_198._4_4_;
            uStack_a0 = (undefined4)uStack_190;
            uStack_9c = uStack_190._4_4_;
            uStack_170._0_4_ = (undefined4)uVar3;
            uStack_170._4_4_ = (undefined4)((ulonglong)uVar3 >> 0x20);
            local_d8 = (undefined4)local_198;
            uStack_d4 = local_198._4_4_;
            uStack_d0 = (undefined4)uStack_170;
            uStack_cc = uStack_170._4_4_;
            local_198 = pvVar10;
            uStack_190 = puVar1;
            uStack_170 = uVar3;
            FUN_1400dbab0(local_118,local_50,&local_d8,&local_a8);
            operator_delete(local_e8);
            local_e8 = (undefined8 *)0x0;
            local_e0 = 0;
            operator_delete(local_118[0]);
          }
          else {
            if (plVar5 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              pvVar10 = pvVar11;
            }
            else {
              pvVar10 = (void *)*plVar5;
            }
            if (lVar6 == *(longlong *)((longlong)pvVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            local_150[0] = local_res18._0_4_;
            local_148 = lVar9;
            FUN_1400db2f0(lVar6 + 0x20,local_168,local_150);
          }
        }
      }
    }
    if (ppvVar4 == (void **)0x0) {
      _invalid_parameter_noinfo();
      pvVar10 = pvVar11;
    }
    else {
      pvVar10 = *ppvVar4;
    }
    if (*(longlong **)((longlong)pvVar10 + 0x20) <= plVar12) {
      _invalid_parameter_noinfo();
    }
    plVar12 = plVar12 + 1;
  }
  if (local_1b8 != (longlong *)0x0) {
    operator_delete(local_1b8);
  }
  local_1b8 = (longlong *)0x0;
  local_1b0 = (longlong *)0x0;
  local_1a8 = 0;
  operator_delete(local_1d0[0]);
  return;
}

// ==== CMsgAction::helper_1400df220  @1400df220  [medium:callgraph-r1]  (orig: FUN_1400df220)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400df220(longlong param_1,int param_2)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    local_468 = 0x106;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1400ded80();
    cVar1 = FUN_1400dbf70(param_1,param_2);
    if (cVar1 != '\0') {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,param_2);
      if (lVar4 == 0) {
        local_468 = 0x10e;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_14035c930(local_448);
        cVar1 = FUN_14035c9f0(local_448,3);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x350))((longlong *)(lVar4 + 0x10),local_448);
        }
        FUN_14035c980(local_448);
      }
    }
  }
  return;
}

// ==== CMsgAction::helper_1400e54f0  @1400e54f0  [medium:callgraph-r2]  (orig: FUN_1400e54f0)
longlong FUN_1400e54f0(undefined4 *param_1,undefined4 *param_2,longlong param_3)

{
  longlong lVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    puVar2 = param_1;
    do {
      puVar3 = puVar2 + 3;
      *(undefined4 *)(lVar1 + -0xc + (longlong)puVar3) = *puVar2;
      *(undefined4 *)(lVar1 + -8 + (longlong)puVar3) = puVar2[1];
      *(undefined4 *)(lVar1 + -4 + (longlong)puVar3) = puVar2[2];
      puVar2 = puVar3;
    } while (puVar3 != param_2);
  }
  return param_3 + (((longlong)param_2 - (longlong)param_1) / 0xc) * 0xc;
}

// ==== CMsgAction::helper_1400e9820  @1400e9820  [medium:callgraph-r1]  (orig: FUN_1400e9820)
void FUN_1400e9820(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_1400e54f0(uVar1,param_1[4],uVar2);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CMsgAction::helper_1400fbae0  @1400fbae0  [medium:callgraph-r0]  (orig: FUN_1400fbae0)
void FUN_1400fbae0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 local_res10 [2];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_140053460(param_1 + 0x68,local_res10);
  *puVar1 = param_4;
  puVar1 = (undefined4 *)FUN_140053460(param_1 + 0xa8,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CMsgAction::helper_1400fbb30  @1400fbb30  [medium:callgraph-r0]  (orig: FUN_1400fbb30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400fbb30(longlong param_1,undefined4 param_2)

{
  int iVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined1 auStack_4c8 [32];
  int local_4a8;
  undefined4 local_4a0;
  longlong local_498;
  int local_490;
  undefined4 local_488 [2];
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_488[0] = param_2;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_4a8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (lVar3 == 0) {
    local_4a8 = 0x1fd;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    piVar5 = (int *)FUN_140053460(param_1 + 0xa8,local_488);
    iVar9 = *piVar5;
    piVar5 = (int *)FUN_140053460(param_1 + 0x68,local_488);
    if ((iVar9 != *(int *)(param_1 + 8)) || (*piVar5 != *(int *)(param_1 + 0xc))) {
      iVar10 = 0;
      iVar9 = *(int *)(param_1 + 0x10);
      iVar1 = (iVar9 + 999) / 1000;
      iVar7 = 0;
      if (0 < iVar1) {
        do {
          iVar8 = iVar9;
          if (1000 < iVar9) {
            iVar8 = 1000;
          }
          FUN_140370520(local_478);
          local_498 = (longlong)iVar10 + *(longlong *)(param_1 + 0x18);
          local_4a0 = *(undefined4 *)(param_1 + 0x10);
          local_4a8 = iVar1;
          local_490 = iVar8;
          cVar2 = FUN_1403705d0(local_478,*(undefined4 *)(param_1 + 8),
                                *(undefined4 *)(param_1 + 0xc),iVar7);
          if (cVar2 != '\0') {
            (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478)
            ;
          }
          iVar10 = iVar10 + iVar8;
          iVar9 = iVar9 - iVar8;
          FUN_140370570(local_478);
          iVar7 = iVar7 + 1;
        } while (iVar7 < iVar1);
      }
      puVar6 = (undefined4 *)FUN_140053460(param_1 + 0x68,local_488);
      *puVar6 = *(undefined4 *)(param_1 + 8);
      puVar6 = (undefined4 *)FUN_140053460(param_1 + 0xa8,local_488);
      *puVar6 = *(undefined4 *)(param_1 + 0xc);
    }
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgAction::helper_140117db0  @140117db0  [medium:callgraph-r0]  (orig: FUN_140117db0)
undefined8 FUN_140117db0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 0xd8);
  }
  return *(undefined8 *)(param_1 + 0xd8);
}

// ==== CMsgAction::helper_1401620d0  @1401620d0  [medium:callgraph-r1]  (orig: FUN_1401620d0)
void FUN_1401620d0(longlong param_1)

{
  FUN_140373ed0(param_1 + 0xe78);
  return;
}

// ==== CMsgAction::helper_140162400  @140162400  [medium:callgraph-r0]  (orig: FUN_140162400)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140162400(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  byte bVar3;
  undefined1 uVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined1 auStack_498 [32];
  int local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  uVar11 = 0;
  lVar9 = (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x10))();
  if (lVar9 != 0) {
    do {
      lVar9 = (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x18))
                        (*(longlong **)(param_1 + 0x1110),uVar11,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp",
                         0x2f8a);
      plVar2 = DAT_140975b60;
      if (lVar9 != 0) {
        iVar7 = 0;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_478 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar1 = *plVar2;
        uVar5 = FUN_14039d760(lVar9);
        uVar6 = (**(code **)(lVar1 + 0x98))(plVar2,uVar5);
        bVar3 = FUN_14039d7e0(lVar9);
        plVar2 = DAT_140975b60;
        if (bVar3 != uVar6) {
          if (DAT_140975b60 == (longlong *)0x0) {
            local_478 = 0x3c0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar1 = *plVar2;
          uVar4 = FUN_14039d7e0(lVar9);
          uVar5 = FUN_14039d760(lVar9);
          iVar7 = (**(code **)(lVar1 + 0x80))(plVar2,uVar5,uVar4);
          if (iVar7 == -1) {
            FUN_14039d7e0(lVar9);
            FUN_14039d760(lVar9);
            log_InlineLogERROR(&DAT_1407150d8);
            goto LAB_1401625d5;
          }
        }
        FUN_1403b3fd0(local_458);
        uVar5 = FUN_14039d860(lVar9);
        uVar4 = FUN_14039d7e0(lVar9);
        uVar8 = FUN_14039d760(lVar9);
        local_478 = iVar7;
        iVar7 = FUN_1403b4080(local_458,uVar8,uVar4,uVar5);
        if (iVar7 != 0) {
          (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                    ((longlong *)(param_1 + 0x10),local_458);
        }
        FUN_1403b4020(local_458);
      }
LAB_1401625d5:
      uVar11 = uVar11 + 1;
      uVar10 = (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x10))();
    } while (uVar11 < uVar10);
  }
  return;
}

// ==== CMsgAction::helper_140162d80  @140162d80  [medium:callgraph-r0]  (orig: FUN_140162d80)
void FUN_140162d80(longlong param_1,uint param_2)

{
  FUN_1403721b0(param_1 + 0xe78,
                *(uint *)(param_1 + 0xeac) +
                (param_2 - (*(uint *)(param_1 + 0xeac) / 10000) % 1000) * 10000 +
                (param_2 / 1000) * -10000000,1);
  return;
}

// ==== CMsgAction::helper_140164300  @140164300  [medium:callgraph-r0]  (orig: FUN_140164300)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140164300(longlong *param_1,undefined8 param_2,char *param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  ulonglong uVar4;
  char *pcVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_3 != (char *)0x0) {
    uVar4 = 0xffffffffffffffff;
    pcVar5 = param_3;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar5;
      pcVar5 = pcVar5 + 1;
    } while (cVar1 != '\0');
    if (~uVar4 - 1 < 0x10) {
      FUN_1403715c0(param_1 + 0x1cf,param_2,param_3,0);
      if (param_4 == '\0') {
        return;
      }
      FUN_14037dfb0(local_478);
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      iVar3 = FUN_14037e0a0(local_478,6,param_3,uVar2);
      if (iVar3 == 0) {
        local_498 = 0x49b1;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
      }
      FUN_14037e030(local_478);
      return;
    }
  }
  local_498 = 0x49aa;
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgAction::helper_140166390  @140166390  [medium:callgraph-r1]  (orig: FUN_140166390)
undefined4 FUN_140166390(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1258);
}

// ==== CMsgAction::helper_1401663a0  @1401663a0  [medium:callgraph-r1]  (orig: FUN_1401663a0)
void FUN_1401663a0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1258) = param_2;
  return;
}

// ==== CMsgAction::helper_1401670b0  @1401670b0  [medium:callgraph-r0]  (orig: FUN_1401670b0)
ulonglong FUN_1401670b0(int param_1)

{
  if (param_1 - 1U < 0x6b) {
    return CONCAT71((uint7)(uint3)(param_1 - 1U >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0xc9U >> 8),param_1 - 0xc9U < 0x5f);
}

// ==== CMsgAction::helper_1401670d0  @1401670d0  [medium:callgraph-r0]  (orig: FUN_1401670d0)
ulonglong FUN_1401670d0(int param_1)

{
  if (param_1 - 0x86U < 0x14) {
    return CONCAT71((uint7)(uint3)(param_1 - 0x86U >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x145U >> 8),param_1 - 0x145U < 0x14);
}

// ==== CMsgAction::helper_1401670f0  @1401670f0  [medium:callgraph-r0]  (orig: FUN_1401670f0)
ulonglong FUN_1401670f0(int param_1)

{
  if (param_1 - 0x6dU < 0x14) {
    return CONCAT71((uint7)(uint3)(param_1 - 0x6dU >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 300U >> 8),param_1 - 300U < 0x14);
}

// ==== CMsgAction::helper_140167110  @140167110  [medium:callgraph-r0]  (orig: FUN_140167110)
ulonglong FUN_140167110(int param_1)

{
  if (param_1 - 0x81U < 5) {
    return CONCAT71((uint7)(uint3)(param_1 - 0x81U >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x140U >> 8),param_1 - 0x140U < 5);
}

// ==== CMsgAction::helper_140167130  @140167130  [medium:callgraph-r0]  (orig: FUN_140167130)
ulonglong FUN_140167130(int param_1)

{
  if (param_1 - 0x9aU < 5) {
    return CONCAT71((uint7)(uint3)(param_1 - 0x9aU >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x159U >> 8),param_1 - 0x159U < 5);
}

// ==== CMsgAction::helper_140167150  @140167150  [medium:callgraph-r0]  (orig: FUN_140167150)
ulonglong FUN_140167150(int param_1)

{
  if (param_1 - 0x9fU < 5) {
    return CONCAT71((uint7)(uint3)(param_1 - 0x9fU >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x15eU >> 8),param_1 - 0x15eU < 5);
}

// ==== CMsgAction::helper_140167170  @140167170  [medium:callgraph-r0]  (orig: FUN_140167170)
ulonglong FUN_140167170(int param_1)

{
  if (param_1 - 0xa4U < 5) {
    return CONCAT71((uint7)(uint3)(param_1 - 0xa4U >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x163U >> 8),param_1 - 0x163U < 5);
}

// ==== CMsgAction::helper_140167190  @140167190  [medium:callgraph-r0]  (orig: FUN_140167190)
ulonglong FUN_140167190(int param_1)

{
  if (param_1 - 0xa9U < 5) {
    return CONCAT71((uint7)(uint3)(param_1 - 0xa9U >> 8),1);
  }
  return (ulonglong)CONCAT31((int3)(param_1 - 0x168U >> 8),param_1 - 0x168U < 5);
}

// ==== CMsgAction::helper_1401671b0  @1401671b0  [medium:callgraph-r0]  (orig: FUN_1401671b0)
undefined8 FUN_1401671b0(int param_1)

{
  if (param_1 < 1) {
    if (param_1 < 0xc9) {
      return 0;
    }
  }
  else if (param_1 < 0xc9) {
    return 1;
  }
  return 2;
}

// ==== CMsgAction::helper_140168af0  @140168af0  [medium:callgraph-r0]  (orig: FUN_140168af0)
ulonglong FUN_140168af0(longlong param_1)

{
  ulong uVar1;
  ulonglong in_RAX;
  
  if (*(char *)(param_1 + 0x194) != '\0') {
    uVar1 = tq::TimeGet(0);
    return (ulonglong)
           CONCAT31((int3)((uint)*(int *)(param_1 + 0x1a4) >> 8),
                    *(int *)(param_1 + 0x1a0) <=
                    (int)((uVar1 - *(int *)(param_1 + 0x1a8)) + *(int *)(param_1 + 0x1a4)));
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgAction::helper_140168bb0  @140168bb0  [medium:callgraph-r0]  (orig: FUN_140168bb0)
void FUN_140168bb0(longlong param_1,char param_2,undefined4 param_3)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if (param_2 != '\0') {
    uVar1 = param_3;
  }
  *(undefined4 *)(param_1 + 0x1ac) = uVar1;
  return;
}

// ==== CMsgAction::helper_140169750  @140169750  [medium:callgraph-r2]  (orig: FUN_140169750)
void FUN_140169750(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x3d) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMsgAction::helper_14016a2d0  @14016a2d0  [medium:callgraph-r2]  (orig: FUN_14016a2d0)
void FUN_14016a2d0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x3d) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x3d) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x3d);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x3d);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x3d);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x3d);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014016a2f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgAction::helper_14016c970  @14016c970  [medium:callgraph-r1]  (orig: FUN_14016c970)
undefined8 FUN_14016c970(undefined8 param_1)

{
  int iVar1;
  
  iVar1 = FUN_1400fda10(param_1,1,1);
  if (iVar1 % 10 != 9) {
    iVar1 = FUN_1400fda10(param_1,0xc,1);
    if (iVar1 < 6) {
      return 0;
    }
  }
  return 1;
}

// ==== CMsgAction::helper_14016e1c0  @14016e1c0  [medium:callgraph-r0]  (orig: FUN_14016e1c0)
undefined8 FUN_14016e1c0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  
  lVar7 = 0;
  iVar8 = 1;
  do {
    if (((((iVar8 != 7) && (iVar8 != 9)) && (iVar8 != 0xc)) && ((iVar8 != 0xf && (iVar8 != 0x10))))
       && (iVar8 != 0x11)) {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      cVar1 = FUN_14008a700(uVar4);
      if ((cVar1 == '\0') ||
         (((iVar8 != 10 && (iVar8 != 0xb)) &&
          ((iVar8 != 0x12 && (((iVar8 != 0xd && (iVar8 != 0xe)) && (iVar8 != 0x13)))))))) {
        plVar5 = (longlong *)FUN_140087d40();
        lVar6 = *plVar5;
        uVar2 = FUN_14032b4b0(param_1,iVar8);
        lVar6 = (**(code **)(lVar6 + 0x60))(plVar5,uVar2);
        if (iVar8 == 4) {
          lVar7 = lVar6;
        }
        if (lVar6 == 0) {
          if ((iVar8 != 0xd) && (iVar8 != 0xe)) {
            if (iVar8 != 5) {
              return 0;
            }
            if ((*(byte *)(param_1 + 0xeee) / 10 - 1 < 2) && (lVar7 != 0)) {
              uVar2 = FUN_1400fda10(lVar7,1,1);
              iVar3 = FUN_1400ff680(uVar2);
              if (iVar3 != 5) {
                return 0;
              }
            }
          }
        }
        else {
          cVar1 = FUN_14016c970(lVar6);
          if (cVar1 == '\0') {
            return 0;
          }
        }
      }
    }
    iVar8 = iVar8 + 1;
  } while (iVar8 < 0x14);
  return 1;
}

// ==== CMsgAction::helper_14016f1a0  @14016f1a0  [medium:callgraph-r0]  (orig: FUN_14016f1a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14016f1a0(longlong *param_1,uint param_2)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  undefined1 auStack_908 [32];
  undefined2 local_8e8;
  undefined2 local_8e0;
  undefined4 local_8d8;
  undefined4 local_8d0;
  undefined8 local_8c8;
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_8c8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  cVar2 = FUN_1403b4200(param_1 + 0x74);
  if (cVar2 == '\0') {
LAB_14016f2fb:
    (**(code **)(param_1[2] + 0x2b8))(param_1 + 2,param_2);
    FUN_140362560(local_488);
    uVar4 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
    uVar5 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
    uVar6 = (**(code **)(*param_1 + 8))(param_1);
    local_8d0 = 0;
    local_8d8 = 0;
    local_8e0 = 0x4f;
    local_8e8 = (undefined2)param_2;
    iVar3 = FUN_140362620(local_488,uVar6,uVar5,uVar4);
    if (iVar3 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_488,0);
    }
    FUN_1403625e0(local_488);
  }
  else {
    iVar3 = FUN_1403b41c0(param_1 + 0x74);
    if (iVar3 != 0x186a4) {
      iVar3 = FUN_1403b41c0(param_1 + 0x74);
      if (iVar3 != 0x186a7) goto LAB_14016f2fb;
    }
    uVar7 = FUN_140008520((int)param_1[0x246]);
    plVar8 = (longlong *)FUN_140087650(uVar7);
    lVar1 = *plVar8;
    uVar4 = FUN_1403b41b0(param_1 + 0x74);
    plVar8 = (longlong *)(**(code **)(lVar1 + 0x98))(plVar8,uVar4);
    if (plVar8 != (longlong *)0x0) {
      iVar3 = (**(code **)(*plVar8 + 0x50))(plVar8);
      if (iVar3 == 2) {
        (**(code **)(param_1[2] + 0x2b8))(param_1 + 2,param_2);
        (**(code **)(plVar8[2] + 0x2b8))(plVar8 + 2,param_2);
        FUN_1403ece80(local_8b8);
        cVar2 = FUN_1403ecf00(local_8b8,0,param_2 & 0xff,0);
        if (cVar2 != '\0') {
          uVar4 = (**(code **)(*param_1 + 8))(param_1);
          FUN_1403ecf80(local_8b8,uVar4);
          uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
          FUN_1403ecf80(local_8b8,uVar4);
          (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_8b8,1);
        }
        FUN_1403eced0(local_8b8);
      }
    }
  }
  return;
}

// ==== CMsgAction::helper_14016f630  @14016f630  [medium:callgraph-r0]  (orig: FUN_14016f630)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14016f630(longlong *param_1,undefined2 param_2,ushort param_3,undefined1 param_4)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined1 auStack_938 [32];
  uint local_918;
  char *local_910;
  undefined4 local_908;
  ushort local_900;
  undefined4 local_8f8;
  undefined1 local_8f0;
  undefined1 local_8e8;
  ushort local_8e6;
  ushort local_8e4;
  undefined2 local_8e2;
  longlong *local_8e0;
  undefined8 local_8d8;
  undefined1 local_8c8 [1072];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_8d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_938;
  local_8e8 = param_4;
  local_8e6 = param_3;
  local_8e4 = param_3;
  local_8e2 = param_2;
  lVar8 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  if (lVar8 != 0) {
    cVar1 = FUN_1403b4200(param_1 + 0x74);
    if ((cVar1 == '\0') ||
       ((iVar3 = FUN_1403b41c0(param_1 + 0x74), iVar3 != 0x186a4 &&
        (iVar3 = FUN_1403b41c0(param_1 + 0x74), iVar3 != 0x186a7)))) {
      FUN_140362560(local_498);
      uVar4 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
      uVar2 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
      uVar5 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
      uVar6 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      local_8f0 = local_8e8;
      local_900 = local_8e6;
      local_908 = CONCAT22(local_908._2_2_,param_2);
      local_910 = (char *)CONCAT62(local_910._2_6_,0x89);
      local_918 = CONCAT22(local_918._2_2_,uVar2);
      local_8f8 = uVar4;
      iVar3 = FUN_140362810(local_498,uVar7,uVar6,uVar5);
      if (iVar3 != 0) {
        (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_498,1);
      }
      FUN_1403625e0(local_498);
    }
    else {
      uVar9 = FUN_140008520((int)param_1[0x246]);
      plVar10 = (longlong *)FUN_140087650(uVar9);
      lVar8 = *plVar10;
      uVar4 = FUN_1403b41b0(param_1 + 0x74);
      plVar10 = (longlong *)(**(code **)(lVar8 + 0x98))(plVar10,uVar4);
      if (plVar10 != (longlong *)0x0) {
        local_8e0 = plVar10;
        iVar3 = (**(code **)(*plVar10 + 0x50))(plVar10);
        if (iVar3 == 2) {
          FUN_1403ece80(local_8c8);
          cVar1 = FUN_1403ecf40(local_8c8,2,param_2,param_3);
          if (cVar1 != '\0') {
            uVar4 = (**(code **)(*param_1 + 8))(param_1);
            FUN_1403ecf80(local_8c8,uVar4);
            uVar4 = (**(code **)(*plVar10 + 8))(plVar10);
            FUN_1403ecf80(local_8c8,uVar4);
            (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_8c8,1);
          }
          (**(code **)(plVar10[2] + 0x2e8))(plVar10 + 2,3);
          plVar11 = (longlong *)(**(code **)(plVar10[2] + 0x160))(plVar10 + 2);
          if (plVar11 == (longlong *)0x0) {
            local_918 = 0x24c4;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            cVar1 = FUN_14015f9d0(plVar11,param_2,param_3);
            if (cVar1 == '\0') {
              (**(code **)(*plVar11 + 8))(plVar11);
              (**(code **)(*plVar10 + 8))(plVar10);
              local_908 = 0x24c7;
              local_910 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
              local_918 = (uint)param_3;
              log_InlineLogERROR("CUser::SyncInteractJump user%u map%u(%d, %d) at %s, %d");
            }
            else {
              (**(code **)(plVar10[2] + 0x378))(plVar10 + 2,param_2,param_3);
            }
          }
          FUN_1403eced0(local_8c8);
        }
      }
    }
    return;
  }
  return;
}

// ==== CMsgAction::helper_1401701f0  @1401701f0  [medium:callgraph-r0]  (orig: FUN_1401701f0)
ulonglong FUN_1401701f0(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(0);
  return CONCAT71((int7)((ulonglong)uVar1 * 0x10624dd3 >> 8),
                  (uint)(*(int *)(param_1 + 0x940) + *(int *)(param_1 + 0x93c)) <= uVar1 / 1000) &
         0xffffffff;
}

// ==== CMsgAction::helper_140170230  @140170230  [medium:callgraph-r0]  (orig: FUN_140170230)
void FUN_140170230(longlong *param_1)

{
  ushort uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = *(ushort *)(param_1 + 0x214);
  if (uVar1 != 0xffff) {
    FUN_140374270(param_1 + 0x1cf,uVar1 + 1,0);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    uVar3 = FUN_140008520((int)param_1[0x246]);
    FUN_14008a880(uVar3,uVar2,7,uVar1 + 1);
  }
  return;
}

// ==== CMsgAction::helper_1401702c0  @1401702c0  [medium:callgraph-r0]  (orig: FUN_1401702c0)
void FUN_1401702c0(longlong *param_1)

{
  ushort uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = *(ushort *)(param_1 + 0x214);
  if (uVar1 != 0) {
    FUN_140374270(param_1 + 0x1cf,uVar1 - 1,0);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    uVar3 = FUN_140008520((int)param_1[0x246]);
    FUN_14008a880(uVar3,uVar2,7,(longlong)(int)(uVar1 - 1));
  }
  return;
}

// ==== CMsgAction::helper_140171b40  @140171b40  [medium:callgraph-r0]  (orig: FUN_140171b40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140171b40(longlong *param_1)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_48 [32];
  undefined4 *local_28;
  undefined4 local_18;
  undefined4 local_14;
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  uVar1 = (**(code **)(*param_1 + 8))();
  if ((uVar1 < 0xee69a15f) || (*(int *)((longlong)param_1 + 0x12fc) == 0)) {
    local_18 = (**(code **)(*param_1 + 8))(param_1);
    local_14 = 0;
    lVar2 = FUN_140008520((int)param_1[0x246]);
    plVar3 = *(longlong **)(lVar2 + 0x80);
    if (plVar3 == (longlong *)0x0) {
      local_28 = (undefined4 *)CONCAT44(local_28._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    local_28 = &local_18;
    (**(code **)(*plVar3 + 0x50))(plVar3,2,0x3f6,8);
  }
  return;
}

// ==== CMsgAction::helper_140175f60  @140175f60  [medium:callgraph-r1]  (orig: FUN_140175f60)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140175f60(longlong *param_1)

{
  longlong lVar1;
  int iVar2;
  __time32_t _Var3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined8 uVar7;
  ulonglong uVar8;
  
  iVar2 = FUN_140373950();
  _Var3 = _time32((__time32_t *)0x0);
  if (iVar2 != 0) {
    if (iVar2 < _Var3) {
      uVar7 = FUN_140008520((int)param_1[0x246]);
      iVar4 = FUN_14008b3e0(uVar7);
      if (iVar4 <= (_Var3 - iVar2) / 0x15180) {
        uVar7 = FUN_140008520((int)param_1[0x246]);
        uVar5 = FUN_14008b3f0(uVar7);
        uVar6 = (**(code **)(*param_1 + 0x108))(param_1);
        if (uVar5 <= uVar6) {
          uVar5 = *(uint *)(param_1 + 0x20);
          uVar7 = FUN_140008520((int)param_1[0x246]);
          uVar6 = FUN_14008b400(uVar7);
          if (uVar6 <= uVar5) {
            lVar1 = param_1[0x1e2];
            (**(code **)(param_1[2] + 0x70))(param_1 + 2);
            (**(code **)(*param_1 + 0x108))(param_1);
            uVar7 = FUN_140008520((int)param_1[0x246]);
            FUN_14008a730(uVar7,0);
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            uVar8 = (**(code **)(*param_1 + 8))(param_1);
            tq::MyLogSave("gmlog/coreuser_return",
                          "account id:%u, user id:%u, user name:%s, server name:%s, leave days:%d, mete:%d, level:%d, vip:%d"
                          ,(int)lVar1,uVar8 & 0xffffffff);
            return 1;
          }
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMsgAction::helper_1401781f0  @1401781f0  [medium:callgraph-r0]  (orig: FUN_1401781f0)
void FUN_1401781f0(longlong *param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520((int)param_1[0x246]);
  lVar2 = *(longlong *)(lVar2 + 0x100);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  FUN_1402f26a0(lVar2,uVar1);
  return;
}

// ==== CMsgAction::helper_140178430  @140178430  [medium:callgraph-r0]  (orig: FUN_140178430)
void FUN_140178430(longlong *param_1,int param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  uVar2 = FUN_140008520((int)param_1[0x246]);
  FUN_14008a880(uVar2,uVar1,3,(longlong)param_2);
  return;
}

// ==== CMsgAction::helper_140178d70  @140178d70  [medium:callgraph-r1]  (orig: FUN_140178d70)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140178d70(longlong *param_1,uint param_2,undefined4 param_3)

{
  char cVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  int iVar7;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","dwEMoneyCost > 0",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp");
    return 0;
  }
  uVar3 = FUN_140371860(param_1 + 0x1cf);
  if (param_2 <= uVar3 + *(int *)((longlong)param_1 + 0xfa4)) {
    if (param_2 < uVar3) {
      iVar7 = 0;
      uVar3 = param_2;
    }
    else {
      iVar7 = param_2 - uVar3;
    }
    if ((int)uVar3 < 1) {
      cVar1 = '\x01';
    }
    else {
      cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x2d,(longlong)(int)-uVar3,1);
    }
    if (((iVar7 < 1) ||
        (cVar2 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)-iVar7,1),
        cVar2 != '\0')) && (cVar1 != '\0')) {
      if (0 < (int)uVar3) {
        uVar4 = (**(code **)(*param_1 + 8))(param_1);
        FUN_140174470(param_1,param_3,uVar4,0);
        uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_mono_buy","%u\t%s\t%u\t700\t708\t%d\t%d\t1\t",uVar6 & 0xffffffff
                      ,uVar5);
        uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/buy_skill_level",
                      "user(%u,%s) buy skill: %d, current level:%d, current exp:%u emoney_mono cost:%d"
                      ,uVar6 & 0xffffffff,uVar5);
      }
      if (0 < iVar7) {
        uVar4 = (**(code **)(*param_1 + 8))(param_1);
        FUN_1401742b0(param_1,param_3,uVar4,0);
        uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t700\t708\t%d\t%d\t1\t",uVar6 & 0xffffffff,
                      uVar5);
        uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar6 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/buy_skill_level",
                      "user(%u,%s) buy skill: %d, current level:%d, current exp:%u emoney cost:%d",
                      uVar6 & 0xffffffff,uVar5);
      }
      uVar5 = 1;
    }
    else {
      uVar5 = 0;
    }
    return uVar5;
  }
  return 0;
}

// ==== CMsgAction::helper_14017aa50  @14017aa50  [medium:callgraph-r1]  (orig: FUN_14017aa50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14017aa50(longlong *param_1,int param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  uVar2 = (**(code **)(*param_1 + 8))();
  if ((uVar2 < 0xee69a15f) || (*(int *)((longlong)param_1 + 0x12fc) == 0)) {
    uVar4 = 1;
  }
  else if (param_2 == 0) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_140008520((int)param_1[0x246]);
    plVar5 = (longlong *)FUN_1400876b0(uVar4);
    lVar6 = (**(code **)(*plVar5 + 0x20))(plVar5,param_2,1);
    uVar4 = 0;
    if (lVar6 != 0) {
      plVar5 = *(longlong **)(*(longlong *)(lVar6 + 0x58) + 8);
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
      uVar7 = (**(code **)(*plVar5 + 0x58))(plVar5);
      if ((uVar7 >> 0x2f & 1) == 0) {
        FUN_140362560(local_468);
        uVar3 = (**(code **)(*param_1 + 8))(param_1);
        cVar1 = FUN_140362910(local_468,0x1b0,uVar3,0);
        if (cVar1 != '\0') {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
        }
        FUN_1403625e0(local_468);
        uVar4 = 0;
      }
      else {
        uVar4 = 1;
      }
    }
  }
  return uVar4;
}

// ==== CMsgAction::helper_14017c920  @14017c920  [medium:callgraph-r2]  (orig: FUN_14017c920)
void FUN_14017c920(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x3d) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMsgAction::helper_14017efb0  @14017efb0  [medium:callgraph-r0]  (orig: FUN_14017efb0)
undefined8 FUN_14017efb0(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x524) != 0) {
    uVar1 = tq::TimeGet(0);
    if (uVar1 / 1000 < (uint)(*(int *)(param_1 + 0x524) + *(int *)(param_1 + 0x520))) {
      return 0;
    }
    *(undefined4 *)(param_1 + 0x524) = 0;
    *(undefined4 *)(param_1 + 0x520) = 0;
  }
  return 1;
}

// ==== CMsgAction::helper_14018a9b0  @14018a9b0  [medium:callgraph-r0]  (orig: FUN_14018a9b0)
undefined8 FUN_14018a9b0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  int local_res8 [2];
  undefined4 local_res18 [2];
  uint local_res20 [2];
  ulonglong uVar5;
  
  local_res8[0] = 0;
  local_res20[0] = 0;
  local_res18[0] = 0;
  lVar3 = FUN_140008520((int)param_1[0x246]);
  lVar4 = *(longlong *)(lVar3 + 0x100);
  if (*(longlong *)(lVar3 + 0x100) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = 0;
  }
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_1402f1d80(lVar4,uVar2,param_2,local_res8,local_res20,local_res18);
  if (cVar1 != '\0') {
    if (local_res8[0] == 0) {
      local_res8[0] = 1;
    }
    uVar5 = (ulonglong)local_res20[0];
    cVar1 = FUN_140178d70(param_1,local_res8[0],0x2c,param_2,uVar5,local_res18[0]);
    if (cVar1 != '\0') {
      lVar4 = FUN_140008520((int)param_1[0x246]);
      lVar4 = *(longlong *)(lVar4 + 0x100);
      if (lVar4 == 0) {
        uVar5 = 0x144;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar4 = 0;
      }
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      FUN_1402f38a0(lVar4,uVar2,param_2,1,uVar5);
      return 1;
    }
  }
  return 0;
}

// ==== CMsgAction::helper_14018ab00  @14018ab00  [medium:callgraph-r0]  (orig: FUN_14018ab00)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_14018ab00(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  char cVar2;
  undefined1 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong *plVar10;
  ulonglong uVar11;
  double dVar12;
  
  cVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x220))(param_1 + 0x10);
  if (cVar2 == '\0') {
    return 0;
  }
  lVar9 = FUN_140162320(param_1,param_2);
  if (lVar9 != 0) {
    plVar10 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = (longlong *)0x0;
    }
    iVar4 = (**(code **)(*plVar10 + 0x98))(plVar10,param_2);
    uVar5 = FUN_14039d7e0(lVar9);
    if (iVar4 <= (int)(uVar5 & 0xff)) {
      return 0;
    }
    plVar10 = (longlong *)FUN_140087d40();
    lVar1 = *plVar10;
    uVar3 = FUN_14039d7e0(lVar9);
    uVar5 = (**(code **)(lVar1 + 0x80))(plVar10,param_2,uVar3);
    plVar10 = (longlong *)FUN_140087d40();
    lVar1 = *plVar10;
    uVar3 = FUN_14039d7e0(lVar9);
    iVar4 = (**(code **)(lVar1 + 0x88))(plVar10,param_2,uVar3);
    if ((uVar5 == 0) || (iVar4 < 1)) {
      log_InlineLogWARNING
                (
                "CUser::BuyWeaponSkillLevel, do not set the uplevtime or need_exp for weapon skill :%d"
                );
    }
    else {
      uVar6 = FUN_14039d860(lVar9);
      if (uVar6 < uVar5) {
        iVar7 = FUN_14039d860(lVar9);
        dVar12 = (((double)(uVar5 - iVar7) / (double)uVar5) * (double)iVar4 * _DAT_1407196f0) /
                 _DAT_1407196e8;
        if (0.0 <= dVar12) {
          dVar12 = ceil(dVar12);
          iVar4 = (int)(longlong)dVar12;
          if (iVar4 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar8 = FUN_14039d860(lVar9);
            uVar3 = FUN_14039d7e0(lVar9);
            uVar11 = (longlong)dVar12 & 0xffffffff;
            if (iVar4 == 0) {
              uVar11 = 1;
            }
            cVar2 = FUN_140178d70(param_1,uVar11,0x2d,param_2,uVar3,uVar8);
            if (cVar2 != '\0') {
              iVar4 = FUN_14039d860(lVar9);
              FUN_140183e30(param_1,param_2,uVar5 - iVar4,0);
              return 1;
            }
          }
        }
      }
    }
    return 0;
  }
  return 0;
}

// ==== CMsgAction::helper_14019bc00  @14019bc00  [medium:callgraph-r1]  (orig: FUN_14019bc00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14019bc00(longlong *param_1)

{
  longlong lVar1;
  longlong *plVar2;
  uint uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined1 auStack_598 [32];
  int local_578;
  int local_570;
  int local_568;
  int local_564;
  longlong *local_558;
  longlong *plStack_550;
  longlong *local_548;
  longlong *local_540;
  int local_538;
  int local_534;
  longlong *local_530 [3];
  longlong *local_518;
  longlong *local_510;
  undefined8 local_508;
  longlong *local_500;
  longlong *local_4f8;
  longlong *plStack_4f0;
  longlong *local_4e8;
  longlong *plStack_4e0;
  longlong *local_4d8;
  longlong *plStack_4d0;
  longlong *local_4c8;
  longlong *plStack_4c0;
  longlong *local_4b8;
  longlong *local_4a8;
  longlong *local_498;
  undefined8 local_488;
  longlong *local_480;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  plVar12 = (longlong *)0x0;
  local_568 = 0;
  local_564 = 0;
  local_538 = 0;
  local_534 = 0;
  local_558 = (longlong *)0x0;
  local_548 = param_1;
  local_500 = param_1;
  local_4f8 = operator_new(8);
  local_530[0] = plVar12;
  if (local_4f8 != (longlong *)0x0) {
    *local_4f8 = (longlong)local_530;
    local_530[0] = local_4f8;
  }
  local_518 = (longlong *)0x0;
  local_510 = (longlong *)0x0;
  local_508 = 0;
  local_540 = (longlong *)0x0;
  lVar1 = param_1[0x1e2];
  local_4e8 = local_4f8;
  lVar8 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar8 + 0x170) == 0) {
    local_578 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = plVar12;
  }
  else {
    plVar10 = *(longlong **)(lVar8 + 0x170);
  }
  FUN_1403144c0(plVar10,local_530,(int)lVar1,1);
  plStack_4f0 = local_518;
  local_4f8 = (longlong *)0x0;
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
  }
  plVar10 = local_530[0];
  local_4f8 = local_530[0];
  local_558 = local_530[0];
  plStack_550 = plStack_4f0;
  while( true ) {
    plVar11 = local_510;
    plVar2 = plStack_550;
    local_498 = (longlong *)0x0;
    if (local_510 < local_518) {
      _invalid_parameter_noinfo();
    }
    local_498 = local_530[0];
    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_530[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar11) break;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plVar11 = (longlong *)*plVar2;
    if (plVar11 != (longlong *)0x0) {
      local_540 = plVar11;
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
      uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
      uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
      iVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
      param_1 = local_548;
      iVar6 = FUN_140164640((int)local_548[0x1e2],uVar3,uVar4,0);
      if (iVar6 == iVar5) {
        local_568 = local_568 + 1;
      }
      else if ((*(uint *)(param_1 + 0x1e2) ^ 780000) + (uVar3 >> 1) == iVar5) {
        local_568 = local_568 + 1;
      }
      (**(code **)*plVar11)(plVar11,1);
    }
    local_540 = (longlong *)0x0;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plStack_550 = plVar2 + 1;
  }
  FUN_1400179f0(local_530);
  lVar1 = param_1[0x1e2];
  lVar8 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar8 + 0x170) == 0) {
    local_578 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = plVar12;
  }
  else {
    plVar10 = *(longlong **)(lVar8 + 0x170);
  }
  FUN_1403144c0(plVar10,local_530,(int)lVar1,2);
  plStack_4e0 = local_518;
  local_4e8 = (longlong *)0x0;
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
  }
  plVar10 = local_530[0];
  local_4e8 = local_530[0];
  local_558 = local_530[0];
  plStack_550 = plStack_4e0;
  while( true ) {
    plVar11 = local_510;
    plVar2 = plStack_550;
    local_4b8 = (longlong *)0x0;
    if (local_510 < local_518) {
      _invalid_parameter_noinfo();
    }
    local_4b8 = local_530[0];
    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_530[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar11) break;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plVar11 = (longlong *)*plVar2;
    if (plVar11 != (longlong *)0x0) {
      local_540 = plVar11;
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
      uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
      uVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
      iVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
      param_1 = local_548;
      iVar6 = FUN_140164640((int)local_548[0x1e2],uVar3,uVar4,0);
      if (iVar6 == iVar5) {
        local_564 = local_564 + 1;
      }
      else if ((*(uint *)(param_1 + 0x1e2) ^ 0xbe6e1) + (uVar3 >> 1) == iVar5) {
        local_564 = local_564 + 1;
      }
      (**(code **)*plVar11)(plVar11,1);
    }
    local_540 = (longlong *)0x0;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plStack_550 = plVar2 + 1;
  }
  FUN_1400179f0(local_530);
  lVar1 = param_1[0x1e2];
  lVar8 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar8 + 0x170) == 0) {
    local_578 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = plVar12;
  }
  else {
    plVar10 = *(longlong **)(lVar8 + 0x170);
  }
  FUN_1403144c0(plVar10,local_530,(int)lVar1,3);
  plStack_4d0 = local_518;
  local_4d8 = (longlong *)0x0;
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
  }
  plVar10 = local_530[0];
  local_4d8 = local_530[0];
  local_558 = local_530[0];
  plStack_550 = plStack_4d0;
  while( true ) {
    plVar11 = local_510;
    plVar2 = plStack_550;
    local_480 = (longlong *)0x0;
    if (local_510 < local_518) {
      _invalid_parameter_noinfo();
    }
    local_480 = local_530[0];
    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_530[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar11) break;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plVar11 = (longlong *)*plVar2;
    if (plVar11 != (longlong *)0x0) {
      local_540 = plVar11;
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
      uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
      iVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
      iVar6 = FUN_140164640((int)local_548[0x1e2],uVar4,uVar7,0);
      if (iVar6 == iVar5) {
        local_538 = local_538 + 1;
      }
      (**(code **)*plVar11)(plVar11,1);
      param_1 = local_548;
    }
    local_540 = (longlong *)0x0;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plStack_550 = plVar2 + 1;
  }
  FUN_1400179f0(local_530);
  lVar1 = param_1[0x1e2];
  lVar8 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar8 + 0x170) == 0) {
    local_578 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = plVar12;
  }
  else {
    plVar10 = *(longlong **)(lVar8 + 0x170);
  }
  FUN_1403144c0(plVar10,local_530,(int)lVar1,4);
  plStack_4c0 = local_518;
  local_4c8 = (longlong *)0x0;
  if (local_510 < local_518) {
    _invalid_parameter_noinfo();
  }
  plVar10 = local_530[0];
  local_4c8 = local_530[0];
  local_558 = local_530[0];
  plStack_550 = plStack_4c0;
  while( true ) {
    plVar11 = local_510;
    plVar2 = plStack_550;
    local_4a8 = (longlong *)0x0;
    if (local_510 < local_518) {
      _invalid_parameter_noinfo();
    }
    local_4a8 = local_530[0];
    if ((plVar10 == (longlong *)0x0) || (plVar10 != local_530[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar11) break;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plVar11 = (longlong *)*plVar2;
    if (plVar11 != (longlong *)0x0) {
      local_540 = plVar11;
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
      uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
      uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
      plVar9 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
      iVar5 = (**(code **)(*plVar9 + 0x50))(plVar9);
      iVar6 = FUN_140164640((int)local_548[0x1e2],uVar4,uVar7);
      if (iVar6 == iVar5) {
        local_534 = local_534 + 1;
      }
      (**(code **)*plVar11)(plVar11,1);
      param_1 = local_548;
    }
    local_540 = (longlong *)0x0;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar11 = plVar12;
    }
    else {
      plVar11 = (longlong *)*plVar10;
    }
    if ((longlong *)plVar11[4] <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plStack_550 = plVar2 + 1;
  }
  FUN_1400179f0(local_530);
  if ((((0 < local_568) || (0 < local_564)) || (0 < local_538)) || (0 < local_534)) {
    FUN_14035f2f0(local_468);
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    local_570 = local_564;
    local_578 = local_568;
    iVar5 = FUN_14035f5f0(local_468,0x25,uVar4,0);
    if (iVar5 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
    }
    FUN_14035f340(local_468);
  }
  if (local_518 != (longlong *)0x0) {
    operator_delete(local_518);
  }
  local_518 = (longlong *)0x0;
  local_510 = (longlong *)0x0;
  local_508 = 0;
  operator_delete(local_530[0]);
  return;
}

// ==== CMsgAction::helper_14019d860  @14019d860  [medium:callgraph-r0]  (orig: FUN_14019d860)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14019d860(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  undefined4 uVar5;
  ulong uVar6;
  longlong lVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  char *pcVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  undefined1 auStack_228 [32];
  undefined4 local_208;
  longlong *local_1f8;
  longlong *plStack_1f0;
  longlong *local_1e8 [3];
  longlong *local_1d0;
  longlong *local_1c8;
  undefined8 local_1c0;
  longlong *local_1b8;
  longlong *local_1b0;
  undefined8 local_1a8;
  undefined4 local_198;
  char local_194 [320];
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined1 local_40;
  ulonglong local_38;
  
  local_1a8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_228;
  local_1b8 = param_1;
  local_1f8 = operator_new(8);
  if (local_1f8 == (longlong *)0x0) {
    local_1e8[0] = (longlong *)0x0;
  }
  else {
    *local_1f8 = (longlong)local_1e8;
    local_1e8[0] = local_1f8;
  }
  lVar13 = 0;
  local_1d0 = (longlong *)0x0;
  local_1c8 = (longlong *)0x0;
  local_1c0 = 0;
  lVar12 = param_1[0x1e2];
  local_1b0 = local_1f8;
  lVar7 = FUN_140008520((int)param_1[0x246]);
  lVar11 = *(longlong *)(lVar7 + 0x170);
  if (*(longlong *)(lVar7 + 0x170) == 0) {
    local_208 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar11 = lVar13;
  }
  FUN_1403144c0(lVar11,local_1e8,(int)lVar12,0);
  plStack_1f0 = local_1d0;
  if (local_1c8 < local_1d0) {
    _invalid_parameter_noinfo();
  }
  plVar3 = local_1e8[0];
  local_1f8 = local_1e8[0];
  while( true ) {
    plVar1 = local_1c8;
    plVar2 = plStack_1f0;
    if (local_1c8 < local_1d0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar3 == (longlong *)0x0) || (plVar3 != local_1e8[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar1) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar13;
    }
    else {
      lVar12 = *plVar3;
    }
    if (*(longlong **)(lVar12 + 0x20) <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plVar1 = (longlong *)*plVar2;
    if (plVar1 != (longlong *)0x0) {
      plVar8 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,0);
      uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
      local_198 = 0;
      local_194[0] = '\0';
      local_194[1] = '\0';
      local_194[2] = '\0';
      local_194[3] = '\0';
      local_194[4] = '\0';
      local_194[5] = '\0';
      local_194[6] = '\0';
      local_194[7] = '\0';
      local_194[8] = '\0';
      local_194[9] = '\0';
      local_194[10] = '\0';
      local_194[0xb] = '\0';
      local_194[0xc] = '\0';
      local_194[0xd] = '\0';
      local_194[0xe] = '\0';
      local_194[0xf] = '\0';
      local_194[0x10] = '\0';
      local_194[0x11] = '\0';
      local_194[0x12] = '\0';
      local_194[0x13] = '\0';
      local_194[0x14] = '\0';
      local_194[0x15] = '\0';
      local_194[0x16] = '\0';
      local_194[0x17] = '\0';
      local_194[0x18] = '\0';
      local_194[0x19] = '\0';
      local_194[0x1a] = '\0';
      local_194[0x1b] = '\0';
      local_194[0x1c] = '\0';
      local_194[0x1d] = '\0';
      local_194[0x1e] = '\0';
      local_194[0x1f] = '\0';
      local_194[0x20] = '\0';
      local_194[0x21] = '\0';
      local_194[0x22] = '\0';
      local_194[0x23] = '\0';
      local_194[0x24] = '\0';
      local_194[0x25] = '\0';
      local_194[0x26] = '\0';
      local_194[0x27] = '\0';
      local_194[0x28] = '\0';
      local_194[0x29] = '\0';
      local_194[0x2a] = '\0';
      local_194[0x2b] = '\0';
      local_194[0x2c] = '\0';
      local_194[0x2d] = '\0';
      local_194[0x2e] = '\0';
      local_194[0x2f] = '\0';
      local_194[0x30] = '\0';
      local_194[0x31] = '\0';
      local_194[0x32] = '\0';
      local_194[0x33] = '\0';
      local_194[0x34] = '\0';
      local_194[0x35] = '\0';
      local_194[0x36] = '\0';
      local_194[0x37] = '\0';
      local_194[0x38] = '\0';
      local_194[0x39] = '\0';
      local_194[0x3a] = '\0';
      local_194[0x3b] = '\0';
      local_194[0x3c] = '\0';
      local_194[0x3d] = '\0';
      local_194[0x3e] = '\0';
      local_194[0x3f] = '\0';
      memset(local_194 + 0x40,0,0xff);
      local_54 = 0;
      local_50 = 0;
      local_4c = 0;
      local_48 = 0;
      local_44 = 0x1e;
      local_40 = 0;
      local_198 = (**(code **)(*param_1 + 8))(param_1);
      local_4c = uVar5;
      pIVar9 = theInstance();
      pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_BONUS_MAIL_SENDER_NAME");
      _snprintf(local_194,0x20,pcVar10);
      pIVar9 = theInstance();
      pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_BONUS_MAIL_TITLE");
      _snprintf(local_194 + 0x20,0x20,pcVar10);
      pIVar9 = theInstance();
      pcVar10 = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_BONUS_MAIL_CONTENT");
      _snprintf(local_194 + 0x40,0xff,pcVar10);
      lVar11 = FUN_140008520((int)param_1[0x246]);
      lVar12 = *(longlong *)(lVar11 + 0x180);
      if (*(longlong *)(lVar11 + 0x180) == 0) {
        local_208 = 0x153;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar12 = lVar13;
      }
      cVar4 = FUN_1400df9c0(lVar12,&local_198);
      if (cVar4 != '\0') {
        (**(code **)(*param_1 + 8))(param_1);
        local_208 = uVar5;
        tq::MyLogSave("gmlog/bonus","###Bonus: AccountID(%u), Player(%u) SendMail bonus(%u).");
        plVar8 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,3);
        (**(code **)(*plVar8 + 0xb0))(plVar8,1);
        plVar8 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,5);
        lVar12 = *plVar8;
        uVar6 = tq::TimeStampGet();
        (**(code **)(lVar12 + 0xb8))(plVar8,uVar6);
        (**(code **)(*plVar1 + 0x38))(plVar1,1);
      }
      (**(code **)*plVar1)(plVar1);
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar13;
    }
    else {
      lVar12 = *plVar3;
    }
    if (*(longlong **)(lVar12 + 0x20) <= plVar2) {
      _invalid_parameter_noinfo();
    }
    plStack_1f0 = plVar2 + 1;
  }
  if (local_1d0 != (longlong *)0x0) {
    operator_delete(local_1d0);
  }
  local_1d0 = (longlong *)0x0;
  local_1c8 = (longlong *)0x0;
  local_1c0 = 0;
  operator_delete(local_1e8[0]);
  return;
}

// ==== CMsgAction::helper_14019ea00  @14019ea00  [medium:callgraph-r1]  (orig: FUN_14019ea00)
undefined8 * FUN_14019ea00(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x3d) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14016a2d0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x3d) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x3d) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x3d) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x3c);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x3c);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_14019ebec;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x3d) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x3d) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x3d);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x3d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x3d) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x3d);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x3d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_14019ebec:
  if (*(char *)((longlong)plVar5 + 0x3c) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x3c) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x3c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x3c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x3c) = 0;
            FUN_14017c920(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x3d) == '\0') {
            if ((*(char *)(*plVar11 + 0x3c) != '\x01') || (*(char *)(plVar11[2] + 0x3c) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x3c) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x3c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x3c) = 0;
                FUN_140169750(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x3c) = *(undefined1 *)((longlong)plVar10 + 0x3c);
              *(undefined1 *)((longlong)plVar10 + 0x3c) = 1;
              *(undefined1 *)(plVar11[2] + 0x3c) = 1;
              FUN_14017c920(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x3c) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x3c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x3c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x3c) = 0;
            FUN_140169750(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x3d) == '\0') {
            if ((*(char *)(plVar11[2] + 0x3c) != '\x01') || (*(char *)(*plVar11 + 0x3c) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x3c) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x3c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x3c) = 0;
                FUN_14017c920(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x3c) = *(undefined1 *)((longlong)plVar10 + 0x3c);
              *(undefined1 *)((longlong)plVar10 + 0x3c) = 1;
              *(undefined1 *)(*plVar11 + 0x3c) = 1;
              FUN_140169750(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x3c) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x3c) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMsgAction::helper_1401a3700  @1401a3700  [medium:callgraph-r0]  (orig: FUN_1401a3700)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401a3700(longlong *param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  ulong uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  undefined1 auStack_cd8 [32];
  uint local_cb8;
  longlong *local_ca8;
  undefined8 *puStack_ca0;
  undefined8 local_c98;
  undefined1 local_c88 [1072];
  undefined1 local_858 [1072];
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  
  local_c98 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_cd8;
  FUN_140335990();
  FUN_1403f2320(local_c88);
  puVar9 = *(undefined8 **)param_1[0x1c4];
  plVar1 = (longlong *)param_1[0x1bf];
  local_ca8 = plVar1;
  puStack_ca0 = puVar9;
  do {
    puVar2 = (undefined8 *)param_1[0x1c4];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x1bf])) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      local_cb8 = 0;
      cVar3 = FUN_1403f23d0(local_c88,4,uVar6,0);
      if (cVar3 != '\0') {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_c88);
      }
      FUN_140194390(param_1);
      FUN_1403f0c40(local_858);
      uVar6 = FUN_14018eb30(param_1);
      uVar7 = (**(code **)(*param_1 + 8))(param_1);
      FUN_1403f0cf0(local_858,uVar7,uVar6,0);
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_858);
      FUN_140336320(param_1);
      FUN_1403f0c90(local_858);
      FUN_1403f2370(local_c88);
      return 1;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (puVar9 == *(undefined8 **)(lVar10 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined4 *)(puVar9 + 2);
    cVar3 = FUN_140332fe0(param_1,uVar6);
    if (cVar3 == '\0') {
      cVar3 = FUN_140333220(param_1,uVar6);
      if (cVar3 != '\0') goto LAB_1401a37f4;
      cVar3 = FUN_1403330a0(param_1,uVar6);
      if (cVar3 != '\0') goto LAB_1401a37f4;
    }
    else {
LAB_1401a37f4:
      plVar8 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        local_cb8 = 0x3c0;
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,uVar6);
      if (plVar8 != (longlong *)0x0) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (puVar9 == *(undefined8 **)(lVar10 + 0x28)) {
          _invalid_parameter_noinfo();
        }
        uVar5 = *(uint *)((longlong)puVar9 + 0x14);
        cVar3 = FUN_1400ff650(plVar8,2);
        if (cVar3 == '\0') {
          cVar3 = FUN_1400ff650(plVar8,1);
          if (cVar3 == '\0') goto LAB_1401a396c;
        }
        uVar4 = tq::TimeGet(3);
        if (uVar5 <= uVar4 + 19000000) {
          local_cb8 = uVar5;
          cVar3 = FUN_1403f23d0(local_c88,3,uVar6);
          if (cVar3 != '\0') {
            FUN_140104960(plVar8,0,4);
            local_428 = '\0';
            memset(local_427,0,0x3ff);
            uVar5 = FUN_1400fda10(plVar8,2,1);
            (**(code **)(*plVar8 + 8))(plVar8);
            local_cb8 = uVar5;
            _snprintf(&local_428,0x400,
                      "DELETE FROM GhostContract WHERE Item_id=%u AND owner_id=%u LIMIT 1");
            local_29 = 0;
            FUN_140008520((int)param_1[0x246]);
            plVar8 = (longlong *)InstanceGet();
            (**(code **)(*plVar8 + 0x30))(plVar8,&local_428,0);
            (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_c88);
          }
        }
      }
    }
LAB_1401a396c:
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (puVar9 == *(undefined8 **)(lVar10 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar9 = (undefined8 *)*puVar9;
  } while( true );
}

// ==== CMsgAction::helper_1401a4430  @1401a4430  [medium:callgraph-r1]  (orig: FUN_1401a4430)
void FUN_1401a4430(longlong *param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  FUN_14019d5e0();
  FUN_14019d720(param_1);
  lVar2 = FUN_140008520((int)param_1[0x246]);
  lVar3 = *(longlong *)(lVar2 + 0x170);
  if (*(longlong *)(lVar2 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(lVar3,param_1 + 0x277,uVar1,0x2b);
  lVar3 = FUN_140008520((int)param_1[0x246]);
  lVar3 = *(longlong *)(lVar3 + 0x170);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(lVar3,param_1 + 0x27d,uVar1,0x2c);
  return;
}

// ==== CMsgAction::helper_1401a4530  @1401a4530  [medium:callgraph-r0]  (orig: FUN_1401a4530)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined1 FUN_1401a4530(longlong *param_1)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  IStringManager *pIVar7;
  ulonglong uVar8;
  longlong *plVar9;
  
  cVar2 = (**(code **)(param_1[2] + 0x220))(param_1 + 2);
  if (cVar2 == '\0') {
    return 0;
  }
  uVar3 = FUN_140374150(param_1 + 0x1cf);
  uVar6 = FUN_140008520((int)param_1[0x246]);
  uVar4 = FUN_14008afc0(uVar6);
  if (uVar3 < uVar4) {
    if (*(uint *)((longlong)param_1 + 0xfa4) < 0x5a) {
      pIVar7 = theInstance();
      lVar1 = param_1[2];
      uVar6 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_NOT_SO_MUCH_MONEY");
      (**(code **)(lVar1 + 0x358))(param_1 + 2,uVar6);
    }
    else {
      cVar2 = FUN_1401a1b20(param_1,0x1d,0xffffffffffffffa6,1);
      if (cVar2 != '\0') {
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        FUN_1401742b0(param_1,0x41,uVar5);
        uVar6 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar8 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4290\t%d\t%d\t1\t",uVar8 & 0xffffffff,
                      uVar6);
        plVar9 = (longlong *)FUN_1400fd850();
        lVar1 = *plVar9;
        uVar5 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar1 + 0xa0))(plVar9,uVar5,1);
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMsgAction::helper_1401a8c40  @1401a8c40  [medium:callgraph-r0]  (orig: FUN_1401a8c40)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401a8c40(longlong *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined1 uVar4;
  short sVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  int iVar8;
  uint uVar9;
  undefined4 uVar10;
  ulong uVar11;
  int iVar12;
  uint uVar13;
  undefined4 uVar14;
  longlong lVar15;
  longlong *plVar16;
  undefined8 uVar17;
  IStringManager *pIVar18;
  char *pcVar19;
  ulonglong uVar20;
  undefined8 *puVar21;
  int iVar22;
  undefined8 *puVar23;
  undefined8 **ppuVar24;
  longlong *plVar25;
  undefined1 auStack_12d8 [32];
  undefined4 *local_12b8;
  ulonglong local_12b0;
  undefined4 local_12a8;
  int local_12a0;
  uint local_1298;
  undefined2 local_1290;
  undefined4 local_1288;
  undefined1 local_1278 [4];
  int local_1274;
  undefined4 local_1270;
  undefined4 local_126c;
  undefined4 local_1268;
  undefined8 *local_1258;
  undefined8 *local_1250;
  undefined8 *local_1248;
  undefined8 *local_1240;
  undefined8 *local_1238;
  undefined8 *local_1230;
  undefined8 local_1228;
  undefined4 local_1218;
  undefined4 local_1214;
  undefined1 local_1210;
  undefined1 local_dc8 [1072];
  undefined1 local_998 [1072];
  undefined1 local_568 [1072];
  undefined1 local_138;
  undefined1 local_137 [255];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1401a8c53;
  local_1228 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_12d8;
  lVar15 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar15 + 0xa8) == 0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x137);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGameAction",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar25 = (longlong *)0x0;
  local_12b0 = 0;
  local_12b8 = (undefined4 *)((ulonglong)local_12b8 & 0xffffffff00000000);
  FUN_140145f60(*(undefined8 *)(lVar15 + 0xa8),1000000,param_1,0);
  plVar16 = (longlong *)FUN_1400e1e60();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x10))(plVar16,uVar7);
  cVar3 = (**(code **)(param_1[2] + 0x230))(param_1 + 2);
  if (cVar3 == '\0') {
    FUN_14018fc20(param_1);
  }
  plVar16 = (longlong *)FUN_1401181a0();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x58))(plVar16,uVar7);
  uVar17 = FUN_140008520((int)param_1[0x246]);
  uVar4 = FUN_14008a5a0(uVar17);
  *(undefined1 *)(param_1 + 0x73) = uVar4;
  *(undefined4 *)((longlong)param_1 + 0x11a4) = 0;
  *(undefined4 *)(param_1 + 0x235) = 2;
  cVar3 = FUN_140383750(param_1);
  if (cVar3 != '\0') {
    FUN_140164ef0(param_1);
    iVar8 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
    if ((iVar8 == 0x259) || (iVar8 = (**(code **)(param_1[2] + 0x168))(param_1 + 2), iVar8 == 0x40f)
       ) {
      FUN_140164f80(param_1);
    }
  }
  tq::CMySingleLock::CMySingleLock((CMySingleLock *)&local_1270,(ILockObj *)&DAT_140975e90);
  uVar9 = (**(code **)(*param_1 + 8))(param_1);
  puVar2 = DAT_140975ef0;
  cVar3 = *(char *)((longlong)DAT_140975ef0[1] + 0x3d);
  puVar21 = (undefined8 *)DAT_140975ef0[1];
  puVar1 = DAT_140975ef0;
  while (puVar23 = puVar21, cVar3 == '\0') {
    if (*(uint *)(puVar23 + 3) < uVar9) {
      puVar21 = (undefined8 *)puVar23[2];
      puVar23 = puVar1;
    }
    else {
      puVar21 = (undefined8 *)*puVar23;
    }
    cVar3 = *(char *)((longlong)puVar21 + 0x3d);
    puVar1 = puVar23;
  }
  local_1230 = puVar1;
  local_1238 = DAT_140975ec0;
  if (DAT_140975ec0 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  puVar21 = DAT_140975ef0;
  if ((puVar1 == puVar2) || (uVar9 < *(uint *)(puVar1 + 3))) {
    local_1240 = DAT_140975ef0;
    local_1248 = DAT_140975ec0;
    ppuVar24 = &local_1248;
  }
  else {
    ppuVar24 = &local_1238;
  }
  puVar1 = *ppuVar24;
  local_1250 = ppuVar24[1];
  local_1258 = puVar1;
  if ((puVar1 == (undefined8 *)0x0) || (puVar1 != DAT_140975ec0)) {
    _invalid_parameter_noinfo();
  }
  puVar2 = local_1250;
  if (local_1250 != puVar21) {
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar16 = plVar25;
    }
    else {
      plVar16 = (longlong *)*puVar1;
    }
    if (puVar2 == (undefined8 *)plVar16[6]) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)((longlong)param_1 + 0xb2c) = *(undefined4 *)((longlong)puVar2 + 0x1c);
    if (*(int *)((longlong)puVar2 + 0x24) != 0) {
      FUN_140382c50(param_1,*(undefined4 *)(puVar2 + 4));
    }
    *(undefined4 *)(param_1 + 0x239) = *(undefined4 *)(puVar2 + 5);
    *(undefined4 *)((longlong)param_1 + 0x11cc) = *(undefined4 *)((longlong)puVar2 + 0x2c);
    *(undefined4 *)((longlong)param_1 + 0x11d4) = *(undefined4 *)(puVar2 + 6);
    *(undefined4 *)(param_1 + 0x23b) = *(undefined4 *)((longlong)puVar2 + 0x34);
    *(undefined4 *)((longlong)param_1 + 0x11dc) = *(undefined4 *)(puVar2 + 7);
    local_1258 = *ppuVar24;
    local_1250 = ppuVar24[1];
    FUN_14019ea00(&DAT_140975ec0,&local_1248,&local_1258);
  }
  tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_1270);
  uVar9 = FUN_140382960(param_1,0,0);
  if (uVar9 != 0) {
    local_138 = 0;
    memset(local_137,0,0xff);
    FUN_140382a40(param_1,&local_138);
    pIVar18 = theInstance();
    lVar15 = *param_1;
    uVar17 = (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_GODBLESS_HINT");
    (**(code **)(lVar15 + 0x150))(param_1,0x7d5,uVar17,&local_138);
    if (uVar9 < 0x15180) {
      pIVar18 = theInstance();
      lVar15 = param_1[2];
      uVar17 = (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_GODBLESS_RECHARGE_HINT");
      (**(code **)(lVar15 + 0x358))(param_1 + 2,uVar17);
    }
    plVar16 = (longlong *)FUN_1401181a0();
    lVar15 = *plVar16;
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    local_1288 = 0;
    local_1290 = 0;
    local_1298 = local_1298 & 0xffffff00;
    local_12a0 = 0;
    local_12a8 = 0;
    local_12b0 = local_12b0 & 0xffffffff00000000;
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,uVar9);
    (**(code **)(lVar15 + 8))(plVar16,uVar7,0x1c);
  }
  FUN_14039e680(local_568);
  uVar7 = *(undefined4 *)((longlong)param_1 + 0xf3c);
  uVar10 = (**(code **)(*param_1 + 8))(param_1);
  iVar8 = FUN_14039e700(local_568,uVar10,0x80,uVar7);
  if (iVar8 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_568);
  }
  FUN_14039e680(local_998);
  uVar7 = FUN_1403741d0(param_1 + 0x1cf);
  uVar10 = (**(code **)(*param_1 + 8))(param_1);
  iVar8 = FUN_14039e700(local_998,uVar10,0x54,uVar7);
  if (iVar8 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2);
  }
  FUN_1401a4430(param_1);
  if ((param_1[0x281] - param_1[0x280] & 0xfffffffffffffff8U) != 0) {
    pIVar18 = theInstance();
    lVar15 = param_1[2];
    (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_PK_HUNTER_BONUS");
    (**(code **)(lVar15 + 0x358))(param_1 + 2);
  }
  uVar17 = FUN_140008520((int)param_1[0x246]);
  cVar3 = FUN_14008ac00(uVar17);
  if (cVar3 == '\0') {
    FUN_14019bc00(param_1);
  }
  else {
    local_1270 = (**(code **)(*param_1 + 8))(param_1);
    local_126c = (undefined4)param_1[0x1e2];
    local_1268 = 1;
    lVar15 = FUN_140008520((int)param_1[0x246]);
    plVar16 = *(longlong **)(lVar15 + 0x80);
    if (*(longlong **)(lVar15 + 0x80) == (longlong *)0x0) {
      local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMsgPort",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar16 = plVar25;
    }
    local_12b8 = &local_1270;
    (**(code **)(*plVar16 + 0x50))(plVar16,2,0x4e35,0xc);
  }
  uVar17 = FUN_140008520((int)param_1[0x246]);
  cVar3 = FUN_14008abe0(uVar17);
  if (cVar3 != '\0') {
    local_1218 = local_1218 & 0xffffff00;
    memset((void *)((longlong)&local_1218 + 1),0,0x417);
    local_1218 = (**(code **)(*param_1 + 8))(param_1);
    local_1214 = (undefined4)param_1[0x1e2];
    local_1210 = 1;
    lVar15 = FUN_140008520((int)param_1[0x246]);
    plVar16 = *(longlong **)(lVar15 + 0x80);
    if (*(longlong **)(lVar15 + 0x80) == (longlong *)0x0) {
      local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMsgPort",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar16 = plVar25;
    }
    local_12b8 = &local_1218;
    (**(code **)(*plVar16 + 0x50))(plVar16,0xd,0x186a4,0x418);
  }
  iVar8 = FUN_140372ed0(param_1 + 0x1cf);
  if (iVar8 != 0) {
    if (iVar8 == 0xff) {
      FUN_140164cf0(param_1,0xff);
    }
    else {
      uVar11 = tq::TimeGet(3);
      if ((int)(uVar11 + 19000000) < iVar8) {
        iVar22 = 1;
        do {
          iVar12 = tq::DateStampPass(uVar11 + 19000000,iVar22);
          if (iVar12 == iVar8) {
            FUN_14035f2f0(&local_1218);
            uVar7 = (**(code **)(*param_1 + 8))(param_1);
            local_1298 = 0;
            local_12a8 = 0;
            local_12b0 = local_12b0 & 0xffffffffffff0000;
            local_12b8 = (undefined4 *)((ulonglong)local_12b8 & 0xffffffffffff0000);
            local_12a0 = iVar22;
            iVar8 = FUN_14035f3a0(&local_1218,0x2a,uVar7,0);
            if (iVar8 != 0) {
              (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_1218);
            }
            FUN_14035f340(&local_1218);
            break;
          }
          iVar22 = iVar22 + 1;
        } while (iVar22 < 6);
      }
      else {
        FUN_140372ee0(param_1 + 0x1cf,0xff);
        FUN_140164cf0(param_1,0xff);
        uVar17 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0xff);
        tq::MyLogSave("gmlog/businessman","UserID:%u\tName:%s\tBusinessState:%u\t",(ulonglong)uVar9,
                      uVar17);
      }
    }
  }
  uVar9 = FUN_140372dd0(param_1 + 0x1cf);
  uVar13 = FUN_140372e50(param_1 + 0x1cf);
  if (((uVar9 != 0) && (uVar9 < 60000000)) || (uVar13 - 1 < 299999999)) {
    pIVar18 = theInstance();
    lVar15 = param_1[2];
    uVar17 = (*(code *)**(undefined8 **)pIVar18)(pIVar18,"STR_GET_GODEXP");
    (**(code **)(lVar15 + 0x358))(param_1 + 2,uVar17);
  }
  if (59999999 < uVar9) {
    FUN_1403b3d40(&local_1218);
    cVar3 = FUN_1403b3dc0(&local_1218,3,60000000,0);
    if (cVar3 != '\0') {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_1218);
    }
    FUN_1403b3d90(&local_1218);
  }
  if (299999999 < uVar13) {
    FUN_1403b3d40(&local_1218);
    cVar3 = FUN_1403b3dc0(&local_1218,4,0,300000000);
    if (cVar3 != '\0') {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_1218);
    }
    FUN_1403b3d90(&local_1218);
  }
  plVar16 = (longlong *)CurrentInstanceGet();
  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x13);
  if (plVar16 != (longlong *)0x0) {
    lVar15 = *plVar16;
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar15 + 0x20))(plVar16,uVar7);
  }
  local_1274 = 0;
  local_1278[0] = 0;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  cVar3 = FUN_1403cf200(uVar7,&local_1274,local_1278);
  if ((cVar3 != '\0') && (local_1274 != 0)) {
    lVar15 = FUN_140008520((int)param_1[0x246]);
    plVar16 = *(longlong **)(lVar15 + 0x108);
    if (*(longlong **)(lVar15 + 0x108) == (longlong *)0x0) {
      local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x145);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pTexasMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      plVar16 = plVar25;
    }
    lVar15 = FUN_140214ce0(plVar16,local_1274);
    if (lVar15 != 0) {
      FUN_1403e50a0(lVar15,param_1,local_1278[0]);
    }
  }
  plVar16 = (longlong *)FUN_140087ed0();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x28))(plVar16,uVar7);
  plVar16 = (longlong *)FUN_140087f50();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x58))(plVar16,uVar7);
  plVar16 = (longlong *)FUN_1400e1de0();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x48))(plVar16,uVar7);
  plVar16 = (longlong *)FUN_1401602a0();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0x10))(plVar16,uVar7);
  plVar16 = (longlong *)FUN_1401183a0();
  lVar15 = *plVar16;
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar15 + 0xa0))(plVar16,uVar7);
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 400);
  if (*(longlong **)(lVar15 + 400) == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x155);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDeathMarkedMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  FUN_140237eb0(plVar16,param_1);
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 0x180);
  if (*(longlong **)(lVar15 + 0x180) == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x153);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  FUN_1400df220(plVar16,uVar7);
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 0x1c0);
  if (*(longlong **)(lVar15 + 0x1c0) == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x15c);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  FUN_1401e9370(plVar16,param_1);
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 0x1f8);
  if (*(longlong **)(lVar15 + 0x1f8) == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x163);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  FUN_1402619b0(plVar16,param_1);
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 0x220);
  if (*(longlong **)(lVar15 + 0x220) == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x168);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pSignMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  FUN_140209e70(plVar16,param_1);
  uVar7 = FUN_140384af0(param_1,3,1);
  FUN_1403f2ff0(local_dc8);
  cVar3 = FUN_1403f30b0(local_dc8);
  if ((cVar3 != '\0') && (cVar3 = FUN_1403f30f0(local_dc8,3,1,uVar7), cVar3 != '\0')) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_dc8);
  }
  plVar16 = (longlong *)CurrentInstanceGet();
  plVar16 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,10);
  if (plVar16 != (longlong *)0x0) {
    lVar15 = *plVar16;
    uVar7 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar15 + 8))(plVar16,uVar7);
  }
  pcVar19 = (char *)(**(code **)(param_1[2] + 0x18))(param_1 + 2);
  pcVar19 = strstr(pcVar19,"[Z");
  if (pcVar19 == (char *)0x0) {
    pcVar19 = (char *)(**(code **)(param_1[2] + 0x18))(param_1 + 2);
    pcVar19 = strstr(pcVar19,"[z");
    if (pcVar19 == (char *)0x0) goto LAB_1401a98ca;
  }
  FUN_1403ee140(&local_1218);
  iVar8 = FUN_1403ee230(&local_1218,4,0);
  if (iVar8 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_1218);
  }
  FUN_1403ee190(&local_1218);
LAB_1401a98ca:
  FUN_140175f60(param_1);
  uVar17 = FUN_140008520((int)param_1[0x246]);
  cVar3 = FUN_14008a600(uVar17);
  if (cVar3 != '\0') {
    uVar17 = FUN_140008520((int)param_1[0x246]);
    uVar9 = FUN_14008afa0(uVar17);
    uVar13 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
    if ((uVar13 < uVar9) && (iVar8 = (**(code **)(*param_1 + 0x108))(param_1), iVar8 == 0)) {
      FUN_1403f3040(local_dc8);
      FUN_14039e6d0(local_998);
      FUN_14039e6d0(local_568);
      return;
    }
    lVar15 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    if (lVar15 != 0) {
      plVar16 = *(longlong **)(*(longlong *)(lVar15 + 0x58) + 8);
      plVar16 = (longlong *)(**(code **)(*plVar16 + 0x10))(plVar16,4);
      uVar20 = (**(code **)(*plVar16 + 0x58))(plVar16);
      if (((uVar20 >> 8 & 1) == 0) && (sVar5 = FUN_140373e40(param_1 + 0x1cf), sVar5 == 0)) {
        FUN_140362560(&local_1218);
        uVar6 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
        uVar7 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
        uVar10 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
        uVar14 = (**(code **)(*param_1 + 8))(param_1);
        local_12a0 = 0;
        local_12a8 = 0x203;
        local_12b0 = CONCAT62(local_12b0._2_6_,0x7e);
        local_12b8 = (undefined4 *)CONCAT62(local_12b8._2_6_,uVar6);
        iVar8 = FUN_140362620(&local_1218,uVar14,uVar10,uVar7);
        if (iVar8 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,&local_1218);
        }
        FUN_1403625e0(&local_1218);
      }
    }
  }
  lVar15 = FUN_140008520((int)param_1[0x246]);
  plVar16 = *(longlong **)(lVar15 + 0x100);
  if (plVar16 == (longlong *)0x0) {
    local_12b8 = (undefined4 *)CONCAT44(local_12b8._4_4_,0x144);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMagicManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar16 = plVar25;
  }
  uVar7 = (**(code **)(*param_1 + 8))(param_1);
  FUN_1402f27e0(plVar16,uVar7,1);
  FUN_1403f3040(local_dc8);
  FUN_14039e6d0(local_998);
  FUN_14039e6d0(local_568);
  return;
}

// ==== CMsgAction::helper_1401a9be0  @1401a9be0  [medium:callgraph-r0]  (orig: FUN_1401a9be0)
void FUN_1401a9be0(longlong *param_1)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 local_28 [32];
  
  *(undefined1 *)(param_1 + 0x127) = 1;
  uVar2 = (**(code **)(*param_1 + 0x160))(param_1,local_28,10);
  FUN_14017f180(param_1,0x19,uVar2,2);
  uVar1 = (**(code **)(param_1[2] + 0x30))(param_1 + 2);
  FUN_1401a6420(param_1,0xb,uVar1,2);
  return;
}

// ==== CMsgAction::helper_1401c8690  @1401c8690  [medium:callgraph-r0]  (orig: FUN_1401c8690)
void FUN_1401c8690(longlong *param_1,int param_2)

{
  longlong lVar1;
  bool bVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  undefined8 uVar10;
  int *piVar11;
  IStringManager *pIVar12;
  longlong *plVar13;
  undefined4 local_res10 [2];
  undefined1 local_38 [16];
  
  if (param_2 != 0) {
    plVar13 = param_1 + 2;
    lVar7 = (**(code **)(param_1[2] + 0x160))(plVar13);
    if (lVar7 != 0) {
      lVar7 = (**(code **)(*plVar13 + 0x160))(plVar13);
      plVar8 = *(longlong **)(*(longlong *)(lVar7 + 0x58) + 8);
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
      uVar9 = (**(code **)(*plVar8 + 0x58))(plVar8);
      if ((uVar9 >> 8 & 1) == 0) {
        plVar8 = (longlong *)(**(code **)(*plVar13 + 0x160))(plVar13);
        uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
        if (uVar4 < 0xf4241) {
          iVar5 = (**(code **)(*plVar13 + 0x168))(plVar13);
          if (iVar5 != 0x40c) {
            uVar10 = (**(code **)(*plVar13 + 0x160))(plVar13);
            cVar3 = FUN_14016cb70(uVar10);
            if (cVar3 != '\0') {
              return;
            }
          }
          uVar10 = FUN_140008520((int)param_1[0x246]);
          uVar10 = FUN_1400d6610(uVar10);
          piVar11 = (int *)FUN_14000e3a0(uVar10,param_2);
          if ((piVar11 != (int *)0x0) && ((*piVar11 == 0 || (*piVar11 == 1)))) {
            iVar5 = (**(code **)(*plVar13 + 0x168))(plVar13);
            if (iVar5 == piVar11[1]) {
              if (*piVar11 == 1) {
                uVar10 = FUN_140008520((int)param_1[0x246]);
                uVar10 = FUN_140087830(uVar10);
                FUN_1402190f0(uVar10,1,param_1);
                return;
              }
            }
            else {
              bVar2 = false;
              local_res10[0] = (**(code **)(*plVar13 + 0x168))(plVar13);
              lVar7 = *(longlong *)(piVar11 + 0x12);
              lVar1 = *(longlong *)(piVar11 + 6);
              plVar8 = (longlong *)FUN_140077480(piVar11 + 6,local_38,local_res10);
              if ((lVar1 == 0) || (lVar1 != *plVar8)) {
                _invalid_parameter_noinfo();
              }
              if (lVar7 == plVar8[1]) {
                lVar7 = (**(code **)(*param_1 + 0x60))(param_1);
                if (lVar7 < 200) {
                  pIVar12 = theInstance();
                  lVar7 = *plVar13;
                  uVar10 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_GAMBLE_MONEY_NO_ENOUGH")
                  ;
                  (**(code **)(lVar7 + 0x358))(plVar13,uVar10);
                  return;
                }
                bVar2 = true;
              }
              uVar10 = FUN_140008520((int)param_1[0x246]);
              plVar13 = (longlong *)FUN_1400876b0(uVar10);
              plVar13 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,piVar11[1],1);
              if ((plVar13 != (longlong *)0x0) &&
                 (uVar4 = (**(code **)(*plVar13 + 8))(plVar13), uVar4 < 0xf4241)) {
                iVar5 = tq::RandGet(piVar11[4] + 1);
                iVar5 = iVar5 + piVar11[2];
                iVar6 = tq::RandGet(piVar11[5] + 1);
                iVar6 = iVar6 + piVar11[3];
                cVar3 = FUN_1402c3cc0(plVar13,iVar5,iVar6);
                if (cVar3 == '\0') {
                  iVar5 = piVar11[2];
                  iVar6 = piVar11[3];
                  cVar3 = FUN_1402c3cc0(plVar13,iVar5,iVar6);
                  if (cVar3 == '\0') {
                    log_InlineLogDBERROR
                              ("table:cq_config Type[%d] describ[mapid X Y BX BY] is not Stand");
                    return;
                  }
                }
                iVar5 = FUN_1401c55b0(param_1,piVar11[1],iVar5,iVar6,0);
                if (iVar5 != -1) {
                  if (bVar2) {
                    (**(code **)(*param_1 + 0x178))(param_1,200,1);
                  }
                  if (*piVar11 == 1) {
                    uVar10 = FUN_140008520((int)param_1[0x246]);
                    uVar10 = FUN_140087830(uVar10);
                    FUN_1402190f0(uVar10,1,param_1);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgAction::helper_1401c9d90  @1401c9d90  [medium:callgraph-r0]  (orig: FUN_1401c9d90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1401c9d90(longlong *param_1)

{
  char cVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  __time64_t _Var8;
  undefined1 auStack_4c8 [32];
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined8 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  plVar5 = (longlong *)FUN_140087ed0();
  lVar6 = *plVar5;
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = (**(code **)(lVar6 + 0x6b8))(plVar5,uVar3);
  uVar2 = 0;
  if (cVar1 != '\0') {
    iVar4 = (**(code **)(param_1[2] + 0x168))(param_1 + 2);
    if (iVar4 != 0x3ea) {
      lVar6 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
      if (lVar6 != 0) {
        lVar6 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        plVar5 = *(longlong **)(*(longlong *)(lVar6 + 0x58) + 8);
        plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
        uVar7 = (**(code **)(*plVar5 + 0x58))(plVar5);
        if ((uVar7 >> 0x31 & 1) == 0) {
          return 0;
        }
      }
    }
    if (*(int *)((longlong)param_1 + 0x944) < 1) {
      uVar2 = 0;
    }
    else {
      _Var8 = _time64((__time64_t *)0x0);
      if ((int)_Var8 < *(int *)((longlong)param_1 + 0x944)) {
        uVar2 = 0;
      }
      else {
        plVar5 = (longlong *)FUN_1401181a0();
        lVar6 = *plVar5;
        uVar3 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar6 + 0x10))(plVar5,uVar3,0x6a);
        FUN_140362560(local_468);
        uVar3 = (**(code **)(*param_1 + 8))(param_1);
        local_480 = 0;
        local_488 = 0;
        local_490 = 2;
        local_498 = 0;
        local_4a0 = 0x5e;
        local_4a8 = 0;
        iVar4 = FUN_140362700(local_468,uVar3,0,0);
        if (iVar4 != 0) {
          (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
        }
        local_4a8 = CONCAT11(local_4a8._1_1_,2);
        FUN_1401c6d40(param_1,1,0);
        FUN_1403625e0(local_468);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CMsgAction::helper_1401ca580  @1401ca580  [medium:callgraph-r0]  (orig: FUN_1401ca580)
undefined8 FUN_1401ca580(longlong *param_1,uint param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined4 local_res8 [2];
  undefined4 local_res18;
  undefined4 local_res1c;
  int local_res20;
  int iStackX_24;
  uint uVar8;
  int local_78 [10];
  int local_50 [10];
  
  if ((int)param_1[0x21f] != 0) {
    return 0;
  }
  uVar5 = FUN_140008520((int)param_1[0x246]);
  iVar2 = FUN_14008a6b0(uVar5);
  if (iVar2 != 0) {
    if (iVar2 == 1) {
      if ((int)param_1[4] == 0) goto LAB_1401ca5c7;
    }
    else if (iVar2 != 2) goto LAB_1401ca5c7;
    if (*(int *)((longlong)param_1 + 0x2c) == 0) {
      plVar6 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
      iVar2 = (**(code **)(*plVar6 + 8))(plVar6);
      if (iVar2 == 0x259) {
        FUN_140185db0(param_1);
        return 0;
      }
    }
  }
LAB_1401ca5c7:
  FUN_140198450(param_1);
  iVar2 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
  _local_res20 = CONCAT44(iStackX_24,iVar2);
  iVar3 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
  lVar7 = 0;
  _local_res20 = CONCAT44(iVar3,local_res20);
  local_res8[0] = 0;
  local_res18 = 0;
  local_res1c = 0;
  if ((int)param_2 < 0) {
    local_78[0] = 0;
    local_78[1] = 1;
    local_78[2] = 0xffffffff;
    local_78[3] = 1;
    local_78[4] = 0;
    local_78[5] = 1;
    local_78[6] = 0xffffffff;
    local_78[7] = 0xffffffff;
    local_78[8] = 0;
    local_50[0] = 0;
    local_50[1] = 1;
    local_50[2] = 0xffffffff;
    local_50[3] = 0;
    local_50[4] = 1;
    local_50[5] = 0xffffffff;
    local_50[6] = 1;
    local_50[7] = 0;
    local_50[8] = 0xffffffff;
    do {
      _local_res20 = CONCAT44(iVar3 + *(int *)((longlong)local_50 + lVar7),
                              iVar2 + *(int *)((longlong)local_78 + lVar7));
      uVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
      uVar8 = param_2;
      cVar1 = FUN_1402c6ac0(uVar5,local_res8,&local_res18,&local_res20,param_2);
      if (cVar1 != '\0') {
        cVar1 = FUN_14017aa50(param_1,local_res8[0]);
        if (cVar1 == '\0') {
          return 0;
        }
        iVar2 = FUN_1401c55b0(param_1,local_res8[0],local_res18,local_res1c,uVar8 & 0xffffff00);
        if (iVar2 == 0) {
          return 1;
        }
        break;
      }
      lVar7 = lVar7 + 4;
    } while (lVar7 < 0x24);
  }
  else {
    uVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    cVar1 = FUN_1402c6ac0(uVar5,local_res8,&local_res18,&local_res20,param_2);
    if (cVar1 != '\0') {
      cVar1 = FUN_14017aa50(param_1,local_res8[0]);
      if (cVar1 == '\0') {
        return 0;
      }
      iVar2 = FUN_1401c55b0(param_1,local_res8[0],local_res18,local_res1c,param_2 & 0xffffff00);
      if (iVar2 == 0) {
        return 1;
      }
    }
  }
  lVar7 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  if (((char)param_1[0x276] == '\0') && (lVar7 != 0)) {
    plVar6 = (longlong *)FUN_1400e1e60();
    lVar7 = *plVar6;
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar7 + 0xc0))(plVar6,uVar4,0x69);
  }
  lVar7 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar7 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x50))
            (*(longlong **)(lVar7 + 0x90),param_1,"no map passway!");
  return 0;
}

// ==== CMsgAction::helper_1401e5e60  @1401e5e60  [medium:callgraph-r2]  (orig: FUN_1401e5e60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401e5e60(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined1 uVar4;
  undefined1 uVar5;
  char cVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong lVar12;
  undefined1 auStack_4e8 [32];
  undefined1 local_4c8;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  longlong local_4a0;
  longlong local_498;
  undefined8 *local_490;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    uVar7 = (**(code **)(*param_2 + 8))(param_2);
    puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
    cVar6 = *(char *)((longlong)puVar11 + 0x29);
    puVar2 = *(undefined8 **)(param_1 + 0xc0);
    while (cVar6 == '\0') {
      if (*(uint *)(puVar11 + 3) < uVar7) {
        puVar9 = (undefined8 *)puVar11[2];
        puVar11 = puVar2;
      }
      else {
        puVar9 = (undefined8 *)*puVar11;
      }
      puVar2 = puVar11;
      puVar11 = puVar9;
      cVar6 = *(char *)((longlong)puVar9 + 0x29);
    }
    local_490 = puVar2;
    local_498 = *(longlong *)(param_1 + 0x90);
    puVar11 = *(undefined8 **)(param_1 + 0xc0);
    if (*(longlong *)(param_1 + 0x90) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar11) || (uVar7 < *(uint *)(puVar2 + 3))) {
      local_4b0 = *(undefined8 *)(param_1 + 0xc0);
      local_4b8 = *(longlong *)(param_1 + 0x90);
      plVar10 = &local_4b8;
    }
    else {
      plVar10 = &local_498;
    }
    plVar1 = (longlong *)*plVar10;
    local_4a8 = plVar1;
    local_4a0 = plVar10[1];
    lVar12 = *(longlong *)(param_1 + 0xc0);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x90))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_4a0;
    if (local_4a0 != lVar12) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = 0;
      }
      else {
        lVar12 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar12 = *(longlong *)(lVar3 + 0x20);
      if (lVar12 != 0) {
        FUN_140400920(local_478);
        uVar4 = FUN_1403fd9d0(lVar12);
        uVar5 = FUN_1403fd740(lVar12,5);
        uVar8 = (**(code **)(*param_2 + 8))(param_2);
        local_4c8 = uVar4;
        cVar6 = FUN_140400df0(local_478,7,uVar8,uVar5);
        if (cVar6 != '\0') {
          (**(code **)(param_2[2] + 0x348))(param_2 + 2,local_478,1);
        }
        FUN_1404009a0(local_478);
      }
    }
  }
  return;
}

// ==== CMsgAction::helper_1401e9370  @1401e9370  [medium:callgraph-r1]  (orig: FUN_1401e9370)
void FUN_1401e9370(undefined8 param_1,longlong param_2)

{
  if (param_2 != 0) {
    FUN_1401e5e60();
    FUN_1401e65a0(param_1,param_2);
  }
  return;
}

// ==== CMsgAction::helper_140209e70  @140209e70  [medium:callgraph-r1]  (orig: FUN_140209e70)
void FUN_140209e70(undefined4 *param_1,longlong param_2)

{
  undefined8 uVar1;
  char cVar2;
  
  if (param_2 != 0) {
    uVar1 = FUN_140008520(*param_1);
    cVar2 = FUN_14008ac00(uVar1);
    if (cVar2 != '\0') {
      FUN_140209c60(param_1,param_2);
    }
  }
  return;
}

// ==== CMsgAction::helper_14020b5a0  @14020b5a0  [medium:callgraph-r1]  (orig: FUN_14020b5a0)
longlong * FUN_14020b5a0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgAction::helper_14020ba80  @14020ba80  [medium:callgraph-r0]  (orig: FUN_14020ba80)
undefined8 FUN_14020ba80(longlong param_1,int param_2)

{
  longlong lVar1;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14020b5a0((longlong *)(param_1 + 8),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x38);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar1) {
    return 0;
  }
  if (local_18 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = 0;
  }
  else {
    lVar1 = *local_18;
  }
  if (local_10 == *(longlong *)(lVar1 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return *(undefined8 *)(local_10 + 0x20);
}

// ==== CMsgAction::helper_140231020  @140231020  [medium:callgraph-r0]  (orig: FUN_140231020)
void FUN_140231020(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  __time64_t _Var5;
  longlong *plVar6;
  longlong lVar7;
  longlong *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_60[0] = operator_new(8);
    if (local_60[0] == (longlong *)0x0) {
      local_60[0] = (longlong *)0x0;
    }
    else {
      *local_60[0] = (longlong)local_60;
    }
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    FUN_14022e390(param_1,uVar4,local_60);
    _Var5 = _time64((__time64_t *)0x0);
    plVar6 = local_48;
    plVar1 = local_60[0];
    if (local_40 < local_48) {
      _invalid_parameter_noinfo();
      plVar1 = local_60[0];
    }
    while( true ) {
      plVar2 = local_40;
      if (local_40 < local_48) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_60[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == plVar2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar1;
      }
      if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
        _invalid_parameter_noinfo();
      }
      lVar7 = *plVar6;
      if ((lVar7 != 0) && (cVar3 = FUN_14041e650(lVar7,_Var5), cVar3 == '\0')) {
        uVar4 = FUN_14041e8c0(lVar7);
        FUN_14022f7e0(param_1,param_2,uVar4);
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar1;
      }
      if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar6 + 1;
    }
    if (local_48 != (longlong *)0x0) {
      operator_delete(local_48);
    }
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    operator_delete(local_60[0]);
  }
  return;
}

// ==== CMsgAction::helper_1402619b0  @1402619b0  [medium:callgraph-r1]  (orig: FUN_1402619b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402619b0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    lVar5 = FUN_140261430(param_1,uVar2);
    if (lVar5 == 0) {
      local_478 = 0x6a;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar1 = FUN_140427220(lVar5);
      if (cVar1 == '\0') {
        FUN_14042ad10(lVar5,param_2,0);
      }
      else {
        FUN_14042aae0(lVar5,param_2);
      }
      FUN_14042a770(lVar5,param_2,1,0);
      iVar3 = FUN_1401649c0(param_2);
      if (iVar3 != 0) {
        FUN_14042a770(lVar5,param_2,3,0);
      }
      uVar2 = FUN_140384af0(param_2,2,1);
      uVar4 = FUN_140384af0(param_2,2,2);
      FUN_1403f2ff0(local_458);
      cVar1 = FUN_1403f30b0(local_458);
      if (((cVar1 != '\0') && (cVar1 = FUN_1403f30f0(local_458,2,1,uVar2), cVar1 != '\0')) &&
         (cVar1 = FUN_1403f30f0(local_458,2,2,uVar4), cVar1 != '\0')) {
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_458);
      }
      FUN_140428bd0(lVar5,param_2);
      FUN_1403f3040(local_458);
    }
  }
  return;
}

// ==== CMsgAction::helper_1402c6ac0  @1402c6ac0  [medium:callgraph-r1]  (orig: FUN_1402c6ac0)
undefined8
FUN_1402c6ac0(longlong *param_1,undefined4 *param_2,undefined8 *param_3,int *param_4,int param_5)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined4 local_res20 [2];
  undefined4 local_48 [2];
  int local_40;
  int local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  
  if ((((*param_4 < 0) ||
       (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x28))(), iVar3 <= *param_4)) ||
      (param_4[1] < 0)) ||
     (iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x20))(), iVar3 <= param_4[1])) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_5 < 0) {
    param_5 = (**(code **)(*(longlong *)param_1[0xc] + 0x30))((longlong *)param_1[0xc],*param_4);
    if (param_5 == -1) {
      return 0;
    }
LAB_1402c6c01:
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    if (uVar4 < 0xf4241) {
      local_res20[0] = 0;
      local_48[0] = 0;
      uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
      plVar7 = (longlong *)FUN_1400876b0(uVar6);
      cVar2 = (**(code **)(*plVar7 + 0x70))(plVar7,local_res20,local_48,(int)param_1[0xe],param_5);
      if (cVar2 == '\0') {
        if (param_5 < 0) {
          (**(code **)(*param_1 + 8))(param_1);
          log_InlineLogWARNING(&DAT_140744610);
        }
        uVar6 = 0;
      }
      else {
        uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
        plVar7 = (longlong *)FUN_1400876b0(uVar6);
        cVar2 = (**(code **)(*plVar7 + 0x68))(plVar7,&local_38,local_res20[0],local_48[0]);
        if (cVar2 == '\0') {
          log_InlineLogWARNING(&DAT_1407445d0);
          uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
          plVar7 = (longlong *)FUN_1400876b0(uVar6);
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0xb0))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x38))(plVar7,local_res20[0]);
          if (plVar7 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            log_InlineLogERROR(&DAT_140744588);
            return 0;
          }
          local_38 = (**(code **)(*plVar7 + 0x10))(plVar7,0xb);
          uStack_34 = (**(code **)(*plVar7 + 0x10))(plVar7,0xc);
        }
        *param_2 = local_res20[0];
        *param_3 = CONCAT44(uStack_34,local_38);
        uVar6 = 1;
      }
    }
    else {
      uVar5 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0x11);
      *param_2 = uVar5;
      uVar5 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0x12);
      *(undefined4 *)param_3 = uVar5;
      uVar5 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0x13);
      *(undefined4 *)((longlong)param_3 + 4) = uVar5;
      uVar6 = 1;
    }
  }
  else {
    local_40 = 0;
    local_3c = 0;
    uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
    plVar7 = (longlong *)FUN_1400876b0(uVar6);
    lVar1 = *plVar7;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    cVar2 = (**(code **)(lVar1 + 0x68))(plVar7,&local_40,uVar5,param_5);
    if (cVar2 != '\0') {
      if (((*param_4 <= local_40 + 6) && (local_40 + -6 <= *param_4)) &&
         ((param_4[1] <= local_3c + 6 && (local_3c + -6 <= param_4[1])))) goto LAB_1402c6c01;
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogWARNING(&DAT_140744530);
    }
    uVar6 = 0;
  }
  return uVar6;
}

// ==== CMsgAction::helper_1402f1d80  @1402f1d80  [medium:callgraph-r1]  (orig: FUN_1402f1d80)
undefined1
FUN_1402f1d80(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
             undefined8 param_5,undefined8 param_6)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_14048c310(lVar2,param_3,param_4,param_5,param_6);
    return uVar1;
  }
  return 0;
}

// ==== CMsgAction::helper_1402f26a0  @1402f26a0  [medium:callgraph-r1]  (orig: FUN_1402f26a0)
undefined1 FUN_1402f26a0(void)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_14048f3c0(lVar2);
    return uVar1;
  }
  return 0;
}

// ==== CMsgAction::helper_1403144c0  @1403144c0  [medium:callgraph-r1]  (orig: FUN_1403144c0)
undefined8 FUN_1403144c0(longlong param_1,undefined8 param_2,uint param_3,uint param_4)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong **pplVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  longlong *local_58;
  undefined8 *local_50;
  CMySingleLock local_48 [8];
  undefined8 local_40;
  longlong *local_38;
  longlong *plStack_30;
  longlong *local_28;
  longlong *plStack_20;
  
  local_40 = 0xfffffffffffffffe;
  tq::CMySingleLock::CMySingleLock(local_48,(ILockObj *)(param_1 + 0x78));
  puVar11 = *(undefined8 **)(param_1 + 0xd8);
  cVar1 = *(char *)((longlong)puVar11[1] + 0x29);
  puVar2 = (undefined8 *)puVar11[1];
  while (cVar1 == '\0') {
    if ((*(uint *)(puVar2 + 3) < param_3) ||
       ((*(uint *)(puVar2 + 3) <= param_3 && (*(uint *)((longlong)puVar2 + 0x1c) < param_4)))) {
      puVar7 = (undefined8 *)puVar2[2];
    }
    else {
      puVar7 = (undefined8 *)*puVar2;
      puVar11 = puVar2;
    }
    puVar2 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_50 = puVar11;
  local_58 = *(longlong **)(param_1 + 0xa8);
  puVar2 = *(undefined8 **)(param_1 + 0xd8);
  if (*(longlong **)(param_1 + 0xa8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar11 == puVar2) || (param_3 < *(uint *)(puVar11 + 3))) ||
     ((param_3 <= *(uint *)(puVar11 + 3) && (param_4 < *(uint *)((longlong)puVar11 + 0x1c))))) {
    plStack_20 = *(longlong **)(param_1 + 0xd8);
    local_28 = *(longlong **)(param_1 + 0xa8);
    pplVar9 = &local_28;
  }
  else {
    pplVar9 = &local_58;
  }
  plVar3 = *pplVar9;
  local_38 = plVar3;
  plStack_30 = pplVar9[1];
  plVar4 = *(longlong **)(param_1 + 0xd8);
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xa8))) {
    _invalid_parameter_noinfo();
  }
  plVar6 = plStack_30;
  if (plStack_30 != plVar4) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar3;
    }
    if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar6[4];
    uVar10 = plVar3[3];
    local_58 = plVar3;
    if ((ulonglong)plVar3[4] < uVar10) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)*plVar3;
    while( true ) {
      uVar5 = plVar3[4];
      if (uVar5 < (ulonglong)plVar3[3]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (uVar10 == uVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar4;
      }
      if (*(ulonglong *)(lVar8 + 0x20) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      FUN_140019370(param_2,uVar10);
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar4;
      }
      if (*(ulonglong *)(lVar8 + 0x20) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      uVar10 = uVar10 + 8;
    }
    FUN_1400179f0(plVar3);
    FUN_140313680(&local_58);
    local_28 = local_38;
    plStack_20 = plStack_30;
    FUN_140312fb0(param_1 + 0xa8,&local_38,&local_28);
  }
  tq::CMySingleLock::~CMySingleLock(local_48);
  return 1;
}

// ==== CMsgAction::helper_1403325b0  @1403325b0  [medium:callgraph-r0]  (orig: FUN_1403325b0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1403325b0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  ulong uVar4;
  IStringManager *pIVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 uVar8;
  char *pcVar9;
  undefined8 *puVar10;
  double dVar11;
  
  cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x220))(param_1 + 0x10);
  if (((cVar1 != '\0') && (*(int *)(param_1 + 0x37c) == 0)) && (*(longlong *)(param_1 + 0xa88) == 0)
     ) {
    cVar1 = FUN_1403309b0(param_1);
    if (cVar1 == '\0') {
      pIVar5 = theInstance();
      lVar7 = *(longlong *)(param_1 + 0x10);
      pcVar9 = "STR_MINE_WITH_PECKER";
      puVar10 = *(undefined8 **)pIVar5;
LAB_1403326c6:
      uVar8 = (*(code *)*puVar10)(pIVar5,pcVar9);
                    /* WARNING: Could not recover jumptable at 0x0001403326e9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(lVar7 + 0x358))(param_1 + 0x10,uVar8);
      return;
    }
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    plVar6 = (longlong *)FUN_1400876b0(uVar8);
    lVar7 = (**(code **)(*plVar6 + 0x10))(plVar6,uVar2,1);
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    cVar1 = FUN_14016ccc0(lVar7);
    if (cVar1 != '\0') {
      iVar3 = (**(code **)(**(longlong **)(lVar7 + 0x58) + 0x10))(*(longlong **)(lVar7 + 0x58),0xf);
      if (iVar3 < 1) {
        pIVar5 = theInstance();
        lVar7 = *(longlong *)(param_1 + 0x10);
        pcVar9 = "STR_NO_MINE";
        puVar10 = *(undefined8 **)pIVar5;
        goto LAB_1403326c6;
      }
      *(undefined4 *)(param_1 + 0x378) = 3000;
      uVar4 = tq::TimeGet(0);
      *(ulong *)(param_1 + 0x37c) = uVar4;
      *(undefined4 *)(param_1 + 0x370) = 0;
      dVar11 = tq::RandomRateGet(DAT_1407190c0);
      *(int *)(param_1 + 0x374) = (int)(longlong)(dVar11 * _DAT_1406f9568);
      FUN_140198450(param_1);
    }
  }
  return;
}

// ==== CMsgAction::helper_140336320  @140336320  [medium:callgraph-r1]  (orig: FUN_140336320)
void FUN_140336320(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  int *piVar3;
  longlong *plVar4;
  int *piVar5;
  longlong lVar6;
  
  plVar1 = (longlong *)(param_1 + 0xcc8);
  piVar5 = *(int **)(param_1 + 0xce0);
  if (*(int **)(param_1 + 0xce8) < piVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  while( true ) {
    piVar3 = *(int **)(param_1 + 0xce8);
    if (piVar3 < *(int **)(param_1 + 0xce0)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (piVar5 == piVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (*(int **)(lVar6 + 0x20) <= piVar5) {
      _invalid_parameter_noinfo();
    }
    plVar4 = DAT_140975b60;
    if (*piVar5 != 0) {
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (*(int **)(lVar6 + 0x20) <= piVar5) {
        _invalid_parameter_noinfo();
      }
      (**(code **)(*plVar4 + 0x58))(plVar4,*piVar5,0xe);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (*(int **)(lVar6 + 0x20) <= piVar5) {
      _invalid_parameter_noinfo();
    }
    piVar5 = piVar5 + 1;
  }
  FUN_140036640(plVar1);
  return;
}

// ==== CMsgAction::helper_140355f80  @140355f80  [medium:callgraph-r0]  (orig: FUN_140355f80)
void FUN_140355f80(longlong *param_1)

{
  byte bVar1;
  longlong lVar2;
  undefined8 *puVar3;
  uint *puVar4;
  void *pvVar5;
  char cVar6;
  uint uVar7;
  int iVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  uint *puVar13;
  void *pvVar14;
  longlong *plVar15;
  longlong *plVar16;
  uint local_70;
  uint local_6c;
  uint local_68;
  longlong *local_60 [3];
  void *local_48;
  void *local_40;
  undefined8 local_38;
  
  cVar6 = FUN_1401620f0(param_1,1);
  if (cVar6 == '\0') {
    pIVar9 = theInstance();
    lVar2 = param_1[2];
    uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_FIRST_PAY_PRIVILEGE_NOT_OPEN");
    (**(code **)(lVar2 + 0x358))(param_1 + 2,uVar10);
  }
  else {
    cVar6 = FUN_1401620f0(param_1,4);
    if (cVar6 == '\0') {
      bVar1 = *(byte *)((longlong)param_1 + 0xeee);
      uVar10 = FUN_140008520((int)param_1[0x246]);
      puVar11 = (undefined8 *)FUN_14008ac90(uVar10);
      if (puVar11 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar12 = operator_new(8);
        plVar16 = (longlong *)0x0;
        local_60[0] = plVar16;
        if (plVar12 != (longlong *)0x0) {
          *plVar12 = (longlong)local_60;
          local_60[0] = plVar12;
        }
        local_48 = (void *)0x0;
        local_40 = (void *)0x0;
        local_38 = 0;
        local_70 = 0;
        local_6c = 0;
        local_68 = 0;
        FUN_1400e9820(local_60);
        puVar13 = (uint *)puVar11[3];
        if ((uint *)puVar11[4] < puVar13) {
          _invalid_parameter_noinfo();
        }
        puVar3 = (undefined8 *)*puVar11;
        while( true ) {
          puVar4 = (uint *)puVar11[4];
          if (puVar4 < (uint *)puVar11[3]) {
            _invalid_parameter_noinfo();
          }
          if ((puVar3 == (undefined8 *)0x0) || (puVar3 != (undefined8 *)*puVar11)) {
            _invalid_parameter_noinfo();
          }
          if (puVar13 == puVar4) break;
          if (puVar3 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            plVar12 = plVar16;
          }
          else {
            plVar12 = (longlong *)*puVar3;
          }
          if ((uint *)plVar12[4] <= puVar13) {
            _invalid_parameter_noinfo();
          }
          if (*puVar13 == bVar1 / 10) {
            if (puVar3 == (undefined8 *)0x0) {
              _invalid_parameter_noinfo();
              plVar12 = plVar16;
            }
            else {
              plVar12 = (longlong *)*puVar3;
            }
            if ((uint *)plVar12[4] <= puVar13) {
              _invalid_parameter_noinfo();
            }
            if (0 < (int)puVar13[1]) {
              if (puVar3 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                plVar12 = plVar16;
              }
              else {
                plVar12 = (longlong *)*puVar3;
              }
              if ((uint *)plVar12[4] <= puVar13) {
                _invalid_parameter_noinfo();
              }
              local_70 = *puVar13;
              if (puVar3 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                plVar12 = plVar16;
              }
              else {
                plVar12 = (longlong *)*puVar3;
              }
              if ((uint *)plVar12[4] <= puVar13) {
                _invalid_parameter_noinfo();
              }
              local_6c = puVar13[1];
              if (puVar3 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                plVar12 = plVar16;
              }
              else {
                plVar12 = (longlong *)*puVar3;
              }
              if ((uint *)plVar12[4] <= puVar13) {
                _invalid_parameter_noinfo();
              }
              local_68 = puVar13[2];
              FUN_1400b9ad0(local_60,&local_70);
            }
          }
          if (puVar3 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            plVar12 = plVar16;
          }
          else {
            plVar12 = (longlong *)*puVar3;
          }
          if ((uint *)plVar12[4] <= puVar13) {
            _invalid_parameter_noinfo();
          }
          puVar13 = puVar13 + 3;
        }
        lVar2 = ((longlong)local_40 - (longlong)local_48) / 0xc;
        if (lVar2 == 0) {
          (**(code **)(*param_1 + 8))(param_1);
          log_InlineLogERROR(
                            "CUser::AwardFirstPayGiftBag Award item number is 0, user id:%u,profession sort:%u."
                            );
          if (local_48 != (void *)0x0) {
            operator_delete(local_48);
          }
          local_48 = (void *)0x0;
          local_40 = (void *)0x0;
          local_38 = 0;
          operator_delete(local_60[0]);
        }
        else {
          iVar8 = (int)lVar2;
          if ((iVar8 < 1) ||
             ((ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar8) < 0x29)) {
            uVar7 = FUN_1401620d0(param_1);
            FUN_1401a6420(param_1,0x47,uVar7 | 4,1);
            pvVar14 = local_48;
            plVar12 = local_60[0];
            if (local_40 < local_48) {
              _invalid_parameter_noinfo();
              plVar12 = local_60[0];
            }
            while( true ) {
              pvVar5 = local_40;
              if (local_40 < local_48) {
                _invalid_parameter_noinfo();
              }
              if ((plVar12 == (longlong *)0x0) || (plVar12 != local_60[0])) {
                _invalid_parameter_noinfo();
              }
              if (pvVar14 == pvVar5) break;
              if (plVar12 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar15 = plVar16;
              }
              else {
                plVar15 = (longlong *)*plVar12;
              }
              if ((void *)plVar15[4] <= pvVar14) {
                _invalid_parameter_noinfo();
              }
              if (plVar12 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar15 = plVar16;
              }
              else {
                plVar15 = (longlong *)*plVar12;
              }
              if ((void *)plVar15[4] <= pvVar14) {
                _invalid_parameter_noinfo();
              }
              iVar8 = FUN_14034a8d0(param_1,*(undefined4 *)((longlong)pvVar14 + 4),
                                    *(undefined2 *)((longlong)pvVar14 + 8),1,1,0,1);
              if (iVar8 == 0) {
                if (plVar12 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar15 = plVar16;
                }
                else {
                  plVar15 = (longlong *)*plVar12;
                }
                if ((void *)plVar15[4] <= pvVar14) {
                  _invalid_parameter_noinfo();
                }
                (**(code **)(*param_1 + 8))(param_1);
                log_InlineLogDBERROR
                          (
                          "table:cq_itemtype, CUser::AwardFirstPayGiftBag itemtype[%u] is configed at cq_award_config but not exist at cq_itemtype, user[%u]."
                          );
              }
              if (plVar12 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar15 = plVar16;
              }
              else {
                plVar15 = (longlong *)*plVar12;
              }
              if ((void *)plVar15[4] <= pvVar14) {
                _invalid_parameter_noinfo();
              }
              pvVar14 = (void *)((longlong)pvVar14 + 0xc);
            }
            if (local_48 != (void *)0x0) {
              operator_delete(local_48);
            }
            local_48 = (void *)0x0;
            local_40 = (void *)0x0;
            local_38 = 0;
            operator_delete(local_60[0]);
          }
          else {
            pIVar9 = theInstance();
            lVar2 = param_1[2];
            uVar10 = (*(code *)**(undefined8 **)pIVar9)
                               (pIVar9,"STR_FIRST_PAY_GIFT_BACKPACK_NOT_ENOUGH");
            (**(code **)(lVar2 + 0x358))(param_1 + 2,uVar10);
            if (local_48 != (void *)0x0) {
              operator_delete(local_48);
            }
            local_48 = (void *)0x0;
            local_40 = (void *)0x0;
            local_38 = 0;
            operator_delete(local_60[0]);
          }
        }
      }
    }
    else {
      pIVar9 = theInstance();
      lVar2 = param_1[2];
      uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_FIRST_PAY_GIFT_ALREADY_RECEIVE");
      (**(code **)(lVar2 + 0x358))(param_1 + 2,uVar10);
    }
  }
  return;
}

// ==== CMsgAction::ctor_or_dtor  @140362560  [high:vtable-assign]  (orig: FUN_140362560)
undefined8 * FUN_140362560(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAction::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x35),0x3db,true);
  return param_1;
}

// ==== CMsgAction::ctor_or_dtor  @1403625e0  [high:vtable-assign]  (orig: FUN_1403625e0)
void FUN_1403625e0(undefined8 *param_1)

{
  *param_1 = CMsgAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgAction::vfunc_1  @140362a20  [high:rtti-vtable]  (orig: FUN_140362a20)
ulonglong FUN_140362a20(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x271a);
}

// ==== CMsgAction::ctor_or_dtor  @140362ab0  [high:vtable-assign]  (orig: FUN_140362ab0)
undefined8 * FUN_140362ab0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAction::helper_140362b10  @140362b10  [medium:callgraph-r0]  (orig: FUN_140362b10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140362b10(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  undefined8 local_420;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_420 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_428 = param_2;
  plVar1 = (longlong *)InstanceGet();
  _snprintf(local_418,0x400,"SELECT * FROM cq_deluser WHERE id = %u");
  local_19 = 0;
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,local_418,2);
  if ((plVar1 != (longlong *)0x0) && (lVar2 = (**(code **)(*plVar1 + 0x40))(plVar1), lVar2 != 0)) {
    (**(code **)*plVar1)(plVar1);
    tq::MyLogSave("gmlog/deluser",
                  "CMsgAction::CheckDelUser, found same user(%u) record in cq_deluser");
    return 0;
  }
  if (plVar1 != (longlong *)0x0) {
    (**(code **)*plVar1)(plVar1);
  }
  return 1;
}

// ==== CMsgAction::helper_140362c00  @140362c00  [medium:callgraph-r0]  (orig: FUN_140362c00)
void FUN_140362c00(longlong *param_1,longlong *param_2)

{
  longlong lVar1;
  char cVar2;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (param_2 == param_1) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar2 = FUN_140091b80();
  if (cVar2 != '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140091ba0(param_1);
  lVar1 = *param_2;
  *param_1 = lVar1;
  if (lVar1 != 0) {
    param_1[1] = (longlong)param_2;
    param_1[2] = param_2[2];
    if (param_2[2] != 0) {
      *(longlong **)(param_2[2] + 8) = param_1;
    }
    param_2[2] = (longlong)param_1;
  }
  return;
}

// ==== CMsgAction::vfunc_3  @140362d80  [high:rtti-vtable]  (orig: FUN_140362d80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140362d80(longlong *param_1)

{
  ushort uVar1;
  undefined4 *puVar2;
  undefined8 *puVar3;
  char cVar4;
  bool bVar5;
  ushort uVar6;
  undefined2 uVar7;
  short sVar8;
  undefined4 uVar9;
  int iVar10;
  ulong uVar11;
  uint uVar12;
  undefined4 uVar13;
  int iVar14;
  uint uVar15;
  undefined4 uVar16;
  undefined4 uVar17;
  undefined8 uVar18;
  longlong *plVar19;
  longlong *plVar20;
  char *_Str1;
  ulonglong uVar21;
  undefined8 *puVar22;
  undefined8 uVar23;
  longlong *plVar24;
  IStringManager *pIVar25;
  longlong lVar26;
  longlong lVar27;
  undefined1 uVar28;
  longlong *plVar29;
  undefined1 auStack_de8 [32];
  undefined8 local_dc8;
  undefined8 local_dc0;
  undefined8 local_db8;
  undefined4 local_db0;
  uint local_da8;
  undefined4 local_da0;
  undefined4 local_d98;
  longlong *local_d88;
  longlong *local_d80;
  undefined1 local_d78;
  longlong local_d70;
  int local_d68;
  undefined4 local_d64;
  undefined4 local_d60;
  longlong *local_d58;
  longlong *local_d50;
  longlong *local_d48;
  longlong *local_d40;
  undefined8 local_d38;
  undefined1 local_d30 [24];
  char local_d18;
  undefined1 local_d17 [1103];
  char local_8c8 [1023];
  undefined1 local_4c9;
  char local_478 [32];
  CTickAnalyst local_458;
  undefined8 local_457;
  undefined4 local_44f;
  undefined2 local_44b;
  undefined1 local_449;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_d38 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_de8;
  plVar24 = (longlong *)0x0;
  local_d40 = (longlong *)0x0;
  local_d88 = (longlong *)0x0;
  local_d48 = param_1;
  uVar18 = FUN_140008520((int)param_1[0x82]);
  plVar19 = (longlong *)FUN_1400875f0(uVar18);
  plVar19 = (longlong *)
            (**(code **)(*plVar19 + 0x18))(plVar19,param_1,*(undefined4 *)(param_1[0x85] + 4));
  if (*(short *)(param_1[0x85] + 0x14) == 0xae) {
    local_d40 = plVar19;
    uVar18 = FUN_140008520((int)param_1[0x82]);
    plVar19 = (longlong *)FUN_1400875f0(uVar18);
    plVar19 = (longlong *)(**(code **)(*plVar19 + 0x18))(plVar19,param_1,0);
  }
  local_d40 = plVar19;
  if (plVar19 == (longlong *)0x0) {
    if (*(int *)((longlong)param_1 + 0x414) == -1) {
      return;
    }
    if (*(int *)((longlong)param_1 + 0x41c) != 0) {
      return;
    }
    local_dc8 = local_dc8 & 0xffffffff00000000;
    log_InlineLogERROR("CMsgAction::Process, idRole: %u, action: %u, OSUserID: %u, ServerID: %u",
                       (ulonglong)*(uint *)(param_1[0x85] + 4),
                       (ulonglong)*(ushort *)(param_1[0x85] + 0x14),
                       (ulonglong)*(uint *)(param_1 + 0x84));
    return;
  }
  local_d80 = (longlong *)0x0;
  cVar4 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1002,&local_d80);
  if ((cVar4 != '\0') && (cVar4 = FUN_140388010(local_d80,2), cVar4 != '\0')) {
    return;
  }
  (**(code **)(*plVar19 + 0x298))(plVar19,0x1001,&local_d88);
  if (local_d88 != (longlong *)0x0) {
    plVar20 = (longlong *)FUN_1400e1e60();
    lVar27 = local_d88[0x1e2];
    lVar26 = *plVar20;
    puVar2 = (undefined4 *)param_1[0x85];
    uVar9 = (**(code **)(*local_d88 + 8))();
    (**(code **)(lVar26 + 0x108))(plVar20,uVar9,(int)lVar27,*puVar2);
    if ((local_d88 != (longlong *)0x0) && (cVar4 = FUN_140167b70(), cVar4 != '\0')) {
      uVar6 = *(ushort *)(param_1[0x85] + 0x14);
      if (uVar6 < 0x199) {
        if (uVar6 != 0x198) {
          switch(uVar6) {
          case 0x4f:
          case 0x51:
          case 0x55:
          case 0x5d:
          case 0x5e:
          case 0x60:
          case 0x66:
          case 0x6a:
          case 0x75:
          case 0x76:
          case 0x78:
          case 0x7a:
          case 0x89:
          case 0x91:
          case 0x92:
          case 0xa1:
          case 0xb0:
          case 0xb1:
          case 0x136:
            break;
          default:
            goto switchD_1403630a9_caseD_50;
          }
        }
      }
      else if (uVar6 != 0x1b3) {
switchD_1403630a9_caseD_50:
        return;
      }
    }
  }
  if ((*(short *)(param_1[0x85] + 0x14) != 0x5d) && (*(short *)(param_1[0x85] + 0x14) != 0xae)) {
    uVar9 = (**(code **)(*plVar19 + 0x10))(plVar19);
    *(undefined4 *)(param_1[0x85] + 4) = uVar9;
  }
  uVar6 = *(ushort *)(param_1[0x85] + 0x14);
  if (uVar6 < 0x199) {
    if (uVar6 != 0x198) {
      switch(uVar6) {
      case 0x5b:
      case 0x5d:
      case 0x66:
      case 0x6a:
      case 0x73:
      case 0x75:
      case 0x78:
      case 0x7b:
      case 0x7f:
      case 0x81:
      case 0x83:
      case 0x85:
      case 0x88:
      case 0x8a:
      case 0x8b:
      case 0x8d:
      case 0x8e:
      case 0x90:
      case 0x94:
      case 0x95:
      case 0x96:
      case 0xa1:
      case 0xcd:
      case 0xce:
        break;
      default:
switchD_140362ffd_caseD_5c:
LAB_14036302f:
        (**(code **)(*plVar19 + 0x380))(plVar19);
        goto LAB_140363042;
      }
    }
switchD_140362ffd_caseD_5b:
  }
  else {
    if (((uVar6 == 0x19a) || (uVar6 == 0x1a4)) || (uVar6 == 0x1ae)) goto switchD_140362ffd_caseD_5b;
    if (uVar6 < 0x1b8) goto switchD_140362ffd_caseD_5c;
    if (0x1ba < uVar6) goto LAB_14036302f;
  }
LAB_140363042:
  plVar20 = local_d88;
  lVar26 = param_1[0x85];
  uVar6 = *(ushort *)(lVar26 + 0x14);
  if (0x192 < uVar6) {
    switch(uVar6) {
    case 0x196:
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      if (*(int *)(lVar26 + 8) == 1) {
        sVar8 = FUN_140373e40(local_d88 + 0x1cf);
        FUN_140373dd0(local_d88 + 0x1cf,*(undefined4 *)(param_1[0x85] + 8),0);
        if (sVar8 != 2) {
          return;
        }
        uVar18 = FUN_140008520((int)param_1[0x82]);
        uVar18 = FUN_140087730(uVar18);
        local_dc0 = (char *)0x0;
        local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
        FUN_140145f60(uVar18,0x5bc4f8,local_d88,0);
        return;
      }
      sVar8 = FUN_140373e40(local_d88 + 0x1cf);
      if (sVar8 != 0) {
        return;
      }
      FUN_140373dd0(local_d88 + 0x1cf,2);
      uVar18 = FUN_140008520((int)param_1[0x82]);
      uVar18 = FUN_140087730(uVar18);
      local_dc0 = (char *)0x0;
      local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
      FUN_140145f60(uVar18,0x5bc4f9,local_d88,0);
      return;
    default:
      return;
    case 0x198:
      goto switchD_140367703_caseD_198;
    case 0x1b3:
      local_d80 = (longlong *)FUN_140087ed0();
      if (local_d80 == (longlong *)0x0) {
        return;
      }
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      if (*(int *)(param_1[0x85] + 8) != 1) {
        return;
      }
      cVar4 = FUN_140168af0();
      if (cVar4 == '\0') {
        return;
      }
      uVar9 = (**(code **)(*local_d88 + 8))();
      plVar19 = (longlong *)FUN_1401181a0();
      cVar4 = (**(code **)(*plVar19 + 0x138))(plVar19,uVar9);
      if (cVar4 != '\0') {
        plVar24 = (longlong *)FUN_1401181a0();
        uVar15 = (**(code **)(*plVar24 + 0x130))(plVar24,uVar9);
        plVar24 = (longlong *)(ulonglong)uVar15;
        if ((int)uVar15 < 0) {
          return;
        }
        if (uVar15 == 4) {
          FUN_14017b240(local_d88,1,0);
          return;
        }
      }
      uVar18 = FUN_140008520((int)param_1[0x82]);
      iVar14 = FUN_14008b430(uVar18,plVar24,4);
      plVar24 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar24 + 0x140))(plVar24,uVar9);
      plVar24 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar24;
      uVar18 = FUN_140008520((int)param_1[0x82]);
      uVar16 = FUN_14008b420(uVar18);
      uVar13 = (**(code **)(*local_d80 + 0x440))();
      local_da0 = (uint)local_da0._2_2_ << 0x10;
      local_da8 = CONCAT31(local_da8._1_3_,1);
      local_db0 = 0;
      local_db8 = (char *)((ulonglong)local_db8._4_4_ << 0x20);
      local_dc0 = (char *)((ulonglong)local_dc0._4_4_ << 0x20);
      local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
      local_d98 = uVar16;
      (**(code **)(lVar26 + 8))(plVar24,uVar9,iVar14 + 0xa1,uVar13);
      FUN_14017b240(local_d88,1,0);
      return;
    case 0x1b4:
      plVar24 = (longlong *)FUN_140087ed0();
      if (plVar24 == (longlong *)0x0) {
        return;
      }
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      cVar4 = FUN_140167b70();
      if (cVar4 != '\0') {
        return;
      }
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar19;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0x138))(plVar19,uVar9);
      if (cVar4 == '\0') {
        return;
      }
      iVar14 = FUN_140168b90(local_d88);
      if (iVar14 != 1) {
        return;
      }
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar24;
      lVar27 = *plVar19;
      uVar9 = (**(code **)(*local_d88 + 8))();
      iVar14 = (**(code **)(lVar27 + 0x148))(plVar19,uVar9);
      uVar9 = (**(code **)(*local_d88 + 8))();
      iVar10 = (**(code **)(lVar26 + 0x510))(plVar24,uVar9);
      if (iVar10 == iVar14) {
        plVar19 = (longlong *)FUN_1401181a0();
        lVar26 = *plVar19;
        uVar18 = FUN_140008520((int)param_1[0x82]);
        iVar14 = FUN_14008b420(uVar18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        iVar10 = (**(code **)(lVar26 + 0x128))(plVar19,uVar9);
        if (iVar14 == iVar10) {
          return;
        }
      }
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar19;
      uVar9 = (**(code **)(*local_d88 + 8))();
      uVar9 = (**(code **)(lVar26 + 0x128))(plVar19,uVar9);
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar19;
      uVar16 = (**(code **)(*local_d88 + 8))();
      uVar16 = (**(code **)(lVar26 + 0x148))(plVar19,uVar16);
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar19;
      uVar13 = (**(code **)(*local_d88 + 8))();
      iVar14 = (**(code **)(lVar26 + 0x130))(plVar19,uVar13);
      if (iVar14 < 0) {
        return;
      }
      plVar19 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar19;
      uVar13 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0x140))(plVar19,uVar13);
      FUN_140168bb0(local_d88,1,2);
      lVar26 = *plVar24;
      uVar13 = (**(code **)(*local_d88 + 8))();
      iVar10 = (**(code **)(lVar26 + 0x510))(plVar24,uVar13);
      if (iVar10 == 0) {
        FUN_14017b2b0(local_d88,1,1,iVar14);
        return;
      }
      FUN_140433120(&local_d18);
      lVar26 = *plVar24;
      uVar13 = (**(code **)(*local_d88 + 8))();
      uVar17 = (**(code **)(*local_d88 + 8))();
      local_dc8._0_4_ = (**(code **)(lVar26 + 0x510))(plVar24,uVar17);
      local_db8 = (char *)CONCAT44(local_db8._4_4_,iVar14);
      local_dc0 = (char *)CONCAT44(local_dc0._4_4_,uVar13);
      cVar4 = FUN_140433490(&local_d18,1,uVar9,uVar16);
      if (cVar4 == '\0') {
        local_dc8._0_4_ = 0x993;
        log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                           "msgCrossServerAction.CreateHandIn(CROSS_ACTION_HAND_IN_BRICK, idBrickServer, idBrickLeague, pSynProvider->GetLeagueId(pUser->GetID()),pUser->GetID(), nQuality)"
                           ,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                          );
      }
      else {
        plVar24 = (longlong *)FUN_140008520((int)param_1[0x82]);
        (**(code **)(*plVar24 + 8))(plVar24,&local_d18);
      }
      FUN_1404331a0(&local_d18);
      return;
    case 0x1b8:
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      local_478[0] = '\0';
      local_478[1] = '\0';
      local_478[2] = '\0';
      local_478[3] = '\0';
      local_478[4] = '\0';
      local_478[5] = '\0';
      local_478[6] = '\0';
      local_478[7] = '\0';
      local_478[8] = '\0';
      local_478[9] = '\0';
      local_478[10] = '\0';
      local_478[0xb] = '\0';
      local_478[0xc] = '\0';
      local_478[0xd] = '\0';
      local_478[0xe] = '\0';
      local_478[0xf] = 0;
      bVar5 = tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x86),0,local_478,0x10);
      if (!bVar5) {
        return;
      }
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_140087650(uVar18);
      lVar26 = (**(code **)(*plVar24 + 0x90))(plVar24,local_478,0);
      if (lVar26 == 0) {
        return;
      }
      FUN_140362560(&local_d18);
      uVar9 = (**(code **)(*local_d88 + 8))();
      local_da0 = 0;
      local_da8 = 0;
      local_db0 = 1;
      local_db8 = local_478;
      local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x1b8);
      local_dc8 = local_dc8 & 0xffffffffffff0000;
      iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
      if (iVar14 != 0) {
        (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
      }
      iVar14 = (**(code **)(*local_d88 + 0xc0))();
      if ((iVar14 == 0) && (uVar15 = (**(code **)(local_d88[2] + 0x70))(), uVar15 < 100)) {
        FUN_1403625e0(&local_d18);
        return;
      }
      FUN_140170230(lVar26);
      FUN_1403625e0(&local_d18);
      return;
    case 0x1b9:
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      local_478[0x10] = 0;
      local_478[0x11] = '\0';
      local_478[0x12] = '\0';
      local_478[0x13] = '\0';
      local_478[0x14] = '\0';
      local_478[0x15] = '\0';
      local_478[0x16] = '\0';
      local_478[0x17] = '\0';
      local_478[0x18] = '\0';
      local_478[0x19] = '\0';
      local_478[0x1a] = '\0';
      local_478[0x1b] = '\0';
      local_478[0x1c] = '\0';
      local_478[0x1d] = '\0';
      local_478[0x1e] = '\0';
      local_478[0x1f] = 0;
      bVar5 = tq::CStringPacker::GetString
                        ((CStringPacker *)(param_1 + 0x86),0,local_478 + 0x10,0x10);
      if (!bVar5) {
        return;
      }
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_140087650(uVar18);
      lVar26 = (**(code **)(*plVar24 + 0x90))(plVar24,local_478 + 0x10,0);
      if (lVar26 == 0) {
        return;
      }
      FUN_140362560(&local_d18);
      uVar9 = (**(code **)(*local_d88 + 8))();
      local_da0 = 0;
      local_da8 = 0;
      local_db0 = 1;
      local_db8 = local_478 + 0x10;
      local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x1b9);
      local_dc8 = local_dc8 & 0xffffffffffff0000;
      iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
      if (iVar14 != 0) {
        (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
      }
      iVar14 = (**(code **)(*local_d88 + 0xc0))();
      if ((iVar14 == 0) && (uVar15 = (**(code **)(local_d88[2] + 0x70))(), uVar15 < 100)) {
        FUN_1403625e0(&local_d18);
        return;
      }
      FUN_1401702c0(lVar26);
      FUN_1403625e0(&local_d18);
      return;
    case 0x1ba:
      if (local_d88 == (longlong *)0x0) {
        return;
      }
      local_458 = (CTickAnalyst)0x0;
      local_457 = 0;
      local_44f = 0;
      local_44b = 0;
      local_449 = 0;
      bVar5 = tq::CStringPacker::GetString
                        ((CStringPacker *)(param_1 + 0x86),0,(char *)&local_458,0x10);
      if (!bVar5) {
        return;
      }
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_140087650(uVar18);
      plVar24 = (longlong *)(**(code **)(*plVar24 + 0x90))(plVar24,&local_458,0);
      if (plVar24 != (longlong *)0x0) {
        uVar9 = (**(code **)(*plVar24 + 8))(plVar24);
        local_db0 = 0;
        local_db8 = (char *)CONCAT44(local_db8._4_4_,1);
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x1ba);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362620(param_1,uVar9,0,0);
        if (iVar14 == 0) {
          return;
        }
        (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,param_1);
        return;
      }
      uVar9 = (**(code **)(*local_d88 + 8))();
      local_db0 = 0;
      local_db8 = (char *)((ulonglong)local_db8._4_4_ << 0x20);
      local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x1ba);
      local_dc8 = local_dc8 & 0xffffffffffff0000;
      iVar14 = FUN_140362620(param_1,uVar9,0,0);
      if (iVar14 == 0) {
        return;
      }
      (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,param_1);
      return;
    }
  }
  if (uVar6 == 0x192) {
    uVar9 = (**(code **)(local_d88[2] + 0x168))();
    uVar18 = FUN_140008520((int)param_1[0x82]);
    uVar18 = FUN_140117db0(uVar18);
    lVar26 = FUN_14020ba80(uVar18,uVar9);
    if (lVar26 == 0) {
      return;
    }
    lVar27 = (**(code **)(local_d88[2] + 0x160))();
    if (lVar27 == 0) {
      return;
    }
    plVar24 = local_d88 + 2;
    uVar9 = (**(code **)(*plVar24 + 0x48))(plVar24);
    uVar16 = (**(code **)(*plVar24 + 0x40))(plVar24);
    cVar4 = FUN_1402c68a0(lVar27,9,uVar16,uVar9);
    if (cVar4 == '\0') {
      return;
    }
    FUN_14037fcf0(lVar26,local_d88);
    return;
  }
  switch(uVar6) {
  case 0x4a:
    if (local_d88 != (longlong *)0x0) {
      FUN_1403eed30(&local_d18);
      iVar14 = FUN_1403eede0(&local_d18,1,0);
      if (iVar14 != 0) {
        (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
      }
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,1);
      if (cVar4 == '\0') {
        FUN_1403eed80(&local_d18);
      }
      else {
        uVar18 = FUN_140008520((int)param_1[0x82]);
        plVar24 = (longlong *)FUN_1400876b0(uVar18);
        lVar26 = *plVar24;
        uVar9 = (**(code **)(local_d88[2] + 0x168))();
        lVar26 = (**(code **)(lVar26 + 0x10))(plVar24,uVar9,1);
        if (lVar26 == 0) {
          local_dc8 = CONCAT44(local_dc8._4_4_,0x335);
          log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",&DAT_140705b14,
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                            );
          plVar24 = local_d88 + 2;
          uVar15 = (**(code **)(*local_d88 + 8))();
          uVar12 = (**(code **)(*plVar24 + 0x168))(plVar24);
          log_InlineLogERROR("MsgAction EnterMap: invalid map id[%u] of user:%u",(ulonglong)uVar12,
                             (ulonglong)uVar15);
        }
        else {
          plVar24 = (longlong *)FUN_1400e1e60();
          lVar26 = *plVar24;
          uVar9 = (**(code **)(*local_d88 + 8))();
          (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        }
        FUN_1403eed80(&local_d18);
      }
    }
    break;
  case 0x4b:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,2);
      if (cVar4 != '\0') {
        FUN_1401a3700(local_d88);
        FUN_14019d860(local_d88);
        FUN_140362560(&local_d18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_da0 = 0;
        local_da8 = 0;
        local_db0 = 0;
        local_db8 = (char *)0x0;
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x4b);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
        if (iVar14 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
        }
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        FUN_1403625e0(&local_d18);
      }
    }
    break;
  case 0x4c:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,3);
      if (cVar4 != '\0') {
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        FUN_140362560(&local_d18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_da0 = 0;
        local_da8 = 0;
        local_db0 = 0;
        local_db8 = (char *)0x0;
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x4c);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
        if (iVar14 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
        }
        plVar24 = (longlong *)FUN_1401183a0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0x180))(plVar24,uVar9);
        plVar24 = (longlong *)FUN_1401183a0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xd0))(plVar24,uVar9);
        plVar24 = (longlong *)FUN_1401183a0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0x1d8))(plVar24,uVar9);
        plVar24 = (longlong *)FUN_1400e1de0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0x10))(plVar24,uVar9);
        FUN_1403625e0(&local_d18);
      }
    }
    break;
  case 0x4d:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,4);
      if (cVar4 != '\0') {
        FUN_140362560(&local_d18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_da0 = 0;
        local_da8 = 0;
        local_db0 = 0;
        local_db8 = (char *)0x0;
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x4d);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
        if (iVar14 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
        }
        FUN_140162400(local_d88);
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        FUN_1403625e0(&local_d18);
      }
    }
    break;
  case 0x4e:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,5);
      if (cVar4 != '\0') {
        FUN_140362560(local_8c8);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_da0 = 0;
        local_da8 = 0;
        local_db0 = 0;
        local_db8 = (char *)0x0;
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x4e);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362700(local_8c8,uVar9,0,0);
        if (iVar14 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_8c8);
        }
        FUN_1401781f0(local_d88);
        FUN_140171b40(local_d88);
        uVar18 = FUN_140008520((int)param_1[0x82]);
        iVar14 = FUN_14008b010(uVar18);
        uVar18 = FUN_140008520((int)param_1[0x82]);
        iVar10 = FUN_14008b000(uVar18);
        uVar18 = FUN_140008520((int)param_1[0x82]);
        cVar4 = FUN_14008aff0(uVar18);
        FUN_1403b75b0(&local_d18);
        cVar4 = FUN_1403b76a0(&local_d18,0,(uint)(cVar4 != '\0') + (iVar10 + iVar14 * 10) * 10);
        if (cVar4 != '\0') {
          (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
        }
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        FUN_1403b7630(&local_d18);
        FUN_1403625e0(local_8c8);
      }
    }
    break;
  case 0x4f:
    if (local_d88 == (longlong *)0x0) {
      (**(code **)(*plVar19 + 0x2b8))(plVar19,*(undefined2 *)(lVar26 + 0x16));
      (**(code **)(*plVar19 + 0x348))(plVar19,param_1,0);
    }
    else {
      FUN_14016f1a0(local_d88,*(undefined2 *)(lVar26 + 0x16));
    }
    break;
  case 0x51:
    uVar15 = *(uint *)(lVar26 + 8);
    if (uVar15 < 0x110) {
      if (uVar15 < 0x10e) {
        switch(uVar15) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
        case 9:
        case 10:
        case 0xb:
        case 0xc:
        case 0xd:
        case 0xe:
        case 0xf:
        case 0x10:
        case 0x11:
        case 0x96:
        case 0xa0:
        case 0xaa:
        case 0xbe:
        case 200:
        case 0xd2:
        case 0xdc:
        case 0xe6:
        case 0xfa:
          break;
        default:
          goto switchD_1403630a9_caseD_50;
        }
      }
      if (local_d88 != (longlong *)0x0) {
        *(uint *)(param_1[0x85] + 8) = *(uint *)(param_1[0x85] + 8) & 0xffff;
        cVar4 = FUN_140168a10(local_d88);
        if ((cVar4 == '\0') ||
           (((iVar14 = *(int *)(param_1[0x85] + 8), iVar14 != 0xfa && (iVar14 != 0x186a8)) &&
            (iVar14 != 0x186a9)))) {
          iVar14 = (**(code **)(*plVar19 + 0x60))(plVar19);
          if (iVar14 == 0x186aa) {
            uVar18 = FUN_140161000(local_d88);
            FUN_1403b4250(uVar18);
          }
          (**(code **)(*plVar19 + 0x2c0))(plVar19,*(undefined4 *)(param_1[0x85] + 8),0);
          if (*(int *)(param_1[0x85] + 8) == 0xe6) {
            uVar11 = tq::TimeGet(0);
            if ((int)local_d88[0x221] + 3000U < uVar11) {
              cVar4 = FUN_14016e1c0();
              if (cVar4 == '\0') {
                iVar14 = (**(code **)(local_d88[2] + 0x100))();
                if (iVar14 % 10 == 9) {
                  *(uint *)(param_1[0x85] + 8) =
                       *(uint *)(param_1[0x85] + 8) |
                       (uint)*(byte *)((longlong)local_d88 + 0xeee) << 0x10;
                }
              }
              else {
                *(uint *)(param_1[0x85] + 8) =
                     *(uint *)(param_1[0x85] + 8) |
                     (*(byte *)((longlong)local_d88 + 0xeee) + 0x100) * 0x10000;
              }
              uVar11 = tq::TimeGet(0);
              *(ulong *)(local_d88 + 0x221) = uVar11;
            }
          }
          else if (*(int *)(param_1[0x85] + 8) == 0xfa) {
            lVar26 = FUN_14016e430(local_d88);
            if ((iVar14 == 0x186a4) || (iVar14 == 0x186a8)) {
              (**(code **)(*plVar19 + 0x2c0))(plVar19,0x186a8,0);
              if (lVar26 != 0) {
                (**(code **)(*(longlong *)(lVar26 + 0x10) + 0x2c0))
                          ((longlong *)(lVar26 + 0x10),0x186a8,0);
              }
            }
            else if (((iVar14 == 0x186a7) || (iVar14 == 0x186a9)) &&
                    ((**(code **)(*plVar19 + 0x2c0))(plVar19,0x186a9,0), lVar26 != 0)) {
              (**(code **)(*(longlong *)(lVar26 + 0x10) + 0x2c0))
                        ((longlong *)(lVar26 + 0x10),0x186a9,0);
            }
            uVar18 = FUN_140161000(local_d88);
            uVar9 = FUN_1403b41b0(uVar18);
            *(undefined4 *)(param_1[0x85] + 0x10) = uVar9;
          }
          (**(code **)(*plVar19 + 0x348))(plVar19,param_1,1);
        }
      }
    }
    break;
  case 0x53:
    local_dc8 = CONCAT44(local_dc8._4_4_,0x2a9);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT",&DAT_140758528,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                      );
    break;
  case 0x55:
    if (local_d88 != (longlong *)0x0) {
      cVar4 = (**(code **)(local_d88[2] + 0x220))();
      if (cVar4 == '\0') {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_DIE");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
      }
      else if (local_d88 != (longlong *)0x0) {
        (**(code **)(*plVar19 + 0x2e8))(plVar19,5);
        FUN_1401ca580(local_d88,*(undefined4 *)(param_1[0x85] + 0x20));
      }
    }
    break;
  case 0x57:
    local_dc8 = CONCAT44(local_dc8._4_4_,0x2fd);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT",&DAT_140758528,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                      );
    break;
  case 0x58:
    (**(code **)(*plVar19 + 0x348))(plVar19,param_1,0);
    break;
  case 0x59:
    cVar4 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1002,&local_d80);
    if ((cVar4 != '\0') && (*(int *)((longlong)local_d80 + 0x154) == 0)) {
      FUN_14038e270(local_d80,0);
    }
    break;
  case 0x5d:
    if (local_d88 != (longlong *)0x0) {
      lVar26 = param_1[0x85];
      uVar7 = *(undefined2 *)(lVar26 + 0x16);
      uVar9 = *(undefined4 *)(lVar26 + 8);
      uVar16 = *(undefined4 *)(lVar26 + 4);
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar13 = (**(code **)(*local_d88 + 8))();
      local_dc8 = CONCAT44(local_dc8._4_4_,uVar9);
      cVar4 = (**(code **)(lVar26 + 0x70))(plVar24,uVar13,uVar16,uVar7);
      if (cVar4 == '\0') {
        FUN_140183c80(local_d88,0);
      }
    }
    break;
  case 0x5e:
    if ((local_d88 != (longlong *)0x0) &&
       (cVar4 = (**(code **)(local_d88[2] + 0x220))(), cVar4 == '\0')) {
      if (*(int *)(param_1[0x85] + 8) == 2) {
        FUN_1401c9d90(local_d88);
      }
      else if (*(int *)(param_1[0x85] + 8) == 3) {
        plVar24 = (longlong *)FUN_140087ed0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        cVar4 = (**(code **)(lVar26 + 0x6b8))(plVar24,uVar9);
        if (cVar4 != '\0') {
          iVar14 = (**(code **)(local_d88[2] + 0x168))();
          if ((iVar14 != 0x3ea) && (lVar26 = (**(code **)(local_d88[2] + 0x160))(), lVar26 != 0)) {
            lVar26 = (**(code **)(local_d88[2] + 0x160))();
            plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
            plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
            uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
            if ((uVar21 >> 0x31 & 1) == 0) {
              return;
            }
          }
          cVar4 = FUN_140167b70(local_d88);
          if (cVar4 == '\0') {
            cVar4 = FUN_14018b5d0(local_d88);
            if (cVar4 != '\0') {
              plVar24 = (longlong *)FUN_1401181a0();
              lVar26 = *plVar24;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x10))(plVar24,uVar9,0x6a);
              FUN_140362560(&local_d18);
              uVar9 = (**(code **)(*local_d88 + 8))();
              local_da0 = 0;
              local_da8 = 0;
              local_db0 = 3;
              local_db8 = (char *)0x0;
              local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x5e);
              local_dc8 = local_dc8 & 0xffffffffffff0000;
              iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
              if (iVar14 != 0) {
                (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
              }
              local_dc8 = CONCAT71(local_dc8._1_7_,3);
              FUN_1401c6d40(local_d88,0,0,1);
              FUN_1403625e0(&local_d18);
            }
          }
          else if ((char)local_d88[0x129] != '\0') {
            FUN_140460630(&local_d18);
            iVar14 = FUN_1404606e0(&local_d18,0,0,0);
            if (iVar14 == 0) {
              local_dc8 = CONCAT44(local_dc8._4_4_,0x59d);
              log_InlineLogERROR(&DAT_1406d9c10,"CHECK",
                                 "msgPropertyOpt.Create(CCrossMsgPropertyOpt::FUNCTION_TYPE_IMME_REBORN_O2G, ID_NONE, 0)"
                                 ,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                                );
              FUN_140460680(&local_d18);
            }
            else {
              (**(code **)(*local_d88 + 0x138))(local_d88,&local_d18,4);
              *(undefined1 *)(local_d88 + 0x129) = 0;
              FUN_140460680(&local_d18);
            }
          }
        }
      }
      else {
        cVar4 = FUN_1401701f0(local_d88);
        if (((cVar4 != '\0') &&
            (cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x6a), cVar4 == '\0')) &&
           ((*(int *)(param_1[0x85] + 8) != 1 || (cVar4 = FUN_140167b70(local_d88), cVar4 == '\0')))
           ) {
          uVar28 = 1;
          local_d78 = 1;
          cVar4 = FUN_140383750(local_d88);
          if ((cVar4 != '\0') && (*(int *)(param_1[0x85] + 8) == 1)) {
            lVar26 = (**(code **)(local_d88[2] + 0x160))();
            if (lVar26 == 0) {
              local_dc8 = CONCAT44(local_dc8._4_4_,0x5ca);
              log_InlineLogERROR(&DAT_1406d9c10,"CHECK",&DAT_140705b14,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                                );
              return;
            }
            plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
            plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
            uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
            if ((uVar21 >> 0xd & 1) == 0) {
              return;
            }
            plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
            plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
            uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
            if ((uVar21 >> 0x31 & 1) != 0) {
              return;
            }
            uVar28 = 0;
            local_d78 = 0;
          }
          plVar24 = (longlong *)CurrentInstanceGet();
          if (plVar24 != (longlong *)0x0) {
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x22);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0xe0))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x21);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x98))(plVar19,uVar9);
            }
            plVar24 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x24);
            if (plVar24 != (longlong *)0x0) {
              lVar26 = *plVar24;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x98))(plVar24,uVar9);
            }
          }
          FUN_140362560(local_8c8);
          uVar9 = (**(code **)(*local_d88 + 8))();
          local_da0 = 0;
          local_da8 = 0;
          local_db0 = 0;
          local_db8 = (char *)0x0;
          local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x5e);
          local_dc8 = local_dc8 & 0xffffffffffff0000;
          iVar14 = FUN_140362700(local_8c8,uVar9,0,0);
          if (iVar14 != 0) {
            (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,local_8c8);
          }
          local_dc8 = local_dc8 & 0xffffffffffffff00;
          FUN_1401c6d40(local_d88,uVar28,1,0);
          FUN_1403625e0(local_8c8);
        }
      }
    }
    break;
  case 0x5f:
    if (local_d88 != (longlong *)0x0) {
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = FUN_140362b10(param_1,uVar9);
      if (cVar4 == '\0') {
        uVar18 = FUN_140008520((int)param_1[0x82]);
        plVar24 = (longlong *)FUN_140087650(uVar18);
        (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758228);
      }
      else if ((local_d88 != (longlong *)0x0) &&
              (iVar14 = FUN_1401642c0(), *(int *)(param_1[0x85] + 8) == iVar14)) {
        FUN_14017f110(local_d88);
        plVar19 = (longlong *)FUN_140087ed0();
        lVar26 = *plVar19;
        uVar9 = (**(code **)(*local_d88 + 8))();
        cVar4 = (**(code **)(lVar26 + 0x78))(plVar19,uVar9);
        if (cVar4 == '\0') {
          lVar26 = FUN_140008520((int)param_1[0x82]);
          if (*(longlong *)(lVar26 + 0x188) == 0) {
            local_dc8 = CONCAT44(local_dc8._4_4_,0x154);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pAuctionMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
          }
          else {
            plVar24 = *(longlong **)(lVar26 + 0x188);
          }
          FUN_140231020(plVar24,local_d88);
          plVar24 = (longlong *)CurrentInstanceGet();
          if (plVar24 != (longlong *)0x0) {
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0xb);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 8))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x10);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x28))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x11);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x60))(plVar19,uVar9);
            }
            plVar19 = (longlong *)CurrentInstanceGet();
            plVar19 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,8);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x1c8))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,4);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0xb8))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x22);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x48))(plVar19,uVar9);
            }
            plVar19 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x21);
            if (plVar19 != (longlong *)0x0) {
              lVar26 = *plVar19;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x58))(plVar19,uVar9);
            }
            plVar24 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0x24);
            if (plVar24 != (longlong *)0x0) {
              lVar26 = *plVar24;
              uVar9 = (**(code **)(*local_d88 + 8))();
              (**(code **)(lVar26 + 0x58))(plVar24,uVar9);
            }
          }
          (**(code **)(local_d88[2] + 0x338))();
          plVar24 = (longlong *)FUN_140087ed0();
          lVar26 = *plVar24;
          uVar9 = (**(code **)(*local_d88 + 8))();
          (**(code **)(lVar26 + 0xa8))(plVar24,uVar9);
          cVar4 = FUN_140164440(local_d88);
          if (cVar4 != '\0') {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            plVar24 = (longlong *)FUN_140087650(uVar18);
            lVar26 = *plVar24;
            (**(code **)(*local_d88 + 0x48))();
            lVar26 = (**(code **)(lVar26 + 0x98))(plVar24);
            if (lVar26 == 0) {
              local_d18 = '\0';
              memset(local_d17,0,0x3ff);
              uVar9 = (**(code **)(*local_d88 + 0x48))();
              local_dc8 = CONCAT44(local_dc8._4_4_,uVar9);
              _snprintf(&local_d18,0x3ff,"UPDATE cq_user SET mateid = %u WHERE id = %u LIMIT 1",0);
              FUN_140008520((int)param_1[0x82]);
              plVar24 = (longlong *)InstanceGet();
              (**(code **)(*plVar24 + 0x30))(plVar24,&local_d18,0,1);
            }
            else {
              pIVar25 = theInstance();
              uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"NOMATE_NAME");
              FUN_140164300(lVar26,0,uVar18,1);
            }
            pIVar25 = theInstance();
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"NOMATE_NAME");
            FUN_140164300(local_d88,0,uVar18,0);
          }
          puVar22 = (undefined8 *)FUN_1401183a0();
          puVar3 = (undefined8 *)*puVar22;
          uVar9 = (**(code **)(*local_d88 + 8))();
          (*(code *)*puVar3)(puVar22,uVar9);
          uVar15 = (**(code **)(*local_d88 + 8))();
          _snprintf(local_438,0x400,"delete from cq_business where userid=%u",(ulonglong)uVar15);
          local_39 = 0;
          FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)InstanceGet();
          (**(code **)(*plVar24 + 0x30))(plVar24,local_438,0,0);
          uVar15 = (**(code **)(*local_d88 + 8))();
          _snprintf(local_438,0x400,"delete from cq_business where business=%u",(ulonglong)uVar15);
          local_39 = 0;
          FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)InstanceGet();
          (**(code **)(*plVar24 + 0x30))(plVar24,local_438,0,0);
          uVar15 = (**(code **)(*local_d88 + 8))();
          _snprintf(local_438,0x400,"INSERT INTO cq_deluser SELECT * FROM cq_user WHERE id=%u",
                    (ulonglong)uVar15);
          local_39 = 0;
          FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)InstanceGet();
          cVar4 = (**(code **)(*plVar24 + 0x30))(plVar24,local_438,0,1);
          if (cVar4 == '\0') {
            uVar15 = (**(code **)(*local_d88 + 8))();
            log_InlineLogERROR("Move UID=%u to cq_deluser failed at %s, %d",(ulonglong)uVar15,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                               ,0x685);
          }
          else {
            uVar15 = (**(code **)(*local_d88 + 8))();
            _snprintf(local_438,0x400,"DELETE FROM cq_user WHERE id=%u LIMIT 1",(ulonglong)uVar15);
            local_39 = 0;
            FUN_140008520((int)param_1[0x82]);
            plVar24 = (longlong *)InstanceGet();
            cVar4 = (**(code **)(*plVar24 + 0x30))(plVar24,local_438,0,1);
            if (cVar4 == '\0') {
              uVar15 = (**(code **)(*local_d88 + 8))();
              log_InlineLogERROR("Del UID=%u from cq_user failed at %s, %d",(ulonglong)uVar15,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                                 ,0x681);
            }
          }
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758228);
        }
        else {
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_SYN_LEADER_LEAVE");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        }
      }
    }
    break;
  case 0x60:
    if (local_d88 == (longlong *)0x0) {
      return;
    }
    lVar26 = (**(code **)(local_d88[2] + 0x160))();
    if (lVar26 != 0) {
      plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
      plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
      uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
      if ((uVar21 >> 0x1c & 1) != 0) {
        return;
      }
      plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
      plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
      uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
      if ((uVar21 >> 0x20 & 1) != 0) {
        return;
      }
      plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
      plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
      uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
      if ((uVar21 >> 0x25 & 1) != 0) {
        return;
      }
      plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
      plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
      uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
      if ((uVar21 >> 0x27 & 1) != 0) {
        return;
      }
    }
    uVar15 = *(uint *)(param_1[0x85] + 8);
    cVar4 = FUN_140167b70(local_d88);
    if (cVar4 == '\0') {
      if (uVar15 == 8) {
        return;
      }
      if (uVar15 == 7) {
        return;
      }
      if (uVar15 == 10) {
        return;
      }
      if (uVar15 == 0xb) {
        return;
      }
      if (uVar15 == 9) {
        plVar24 = (longlong *)FUN_140087ed0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        cVar4 = (**(code **)(lVar26 + 0x6b8))(plVar24,uVar9);
        if (cVar4 == '\0') {
          return;
        }
        goto LAB_1403667c5;
      }
    }
    else {
      uVar18 = FUN_140008520((int)param_1[0x82]);
      cVar4 = FUN_14008b330(uVar18);
      if (cVar4 == '\0') {
        if ((uVar15 == 7) || (uVar15 == 8)) {
LAB_140366730:
          if (((uVar15 != 9) && (uVar15 != 7)) && (uVar15 != 8)) goto LAB_1403667bc;
        }
        else if (uVar15 != 9) {
          if (uVar15 != 10) {
            return;
          }
          goto LAB_140366730;
        }
        plVar24 = (longlong *)FUN_140087ed0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        cVar4 = (**(code **)(lVar26 + 0x6b8))(plVar24,uVar9);
        if (cVar4 == '\0') {
          return;
        }
      }
      else {
        if (lVar26 != 0) {
          plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
          plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
          uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
          if ((uVar21 >> 0x1f & 1) != 0) {
            if (((uVar15 != 0) && (uVar15 != 1)) && ((uVar15 != 2 && (uVar15 != 5)))) {
              return;
            }
            goto LAB_1403667bc;
          }
        }
        if ((uVar15 != 7) && (uVar15 != 0xb)) {
          return;
        }
      }
    }
LAB_1403667bc:
    if (uVar15 < 0xc) {
LAB_1403667c5:
                    /* WARNING: Could not recover jumptable at 0x0001403667d0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)(IMAGE_DOS_HEADER_140000000.e_magic +
                *(uint *)(&DAT_1403684f8 + (longlong)(int)uVar15 * 4)))
                (IMAGE_DOS_HEADER_140000000.e_magic +
                 *(uint *)(&DAT_1403684f8 + (longlong)(int)uVar15 * 4));
      return;
    }
    break;
  case 0x61:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,6);
      if (cVar4 != '\0') {
        FUN_140362560(&local_d18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_da0 = 0;
        local_da8 = 0;
        local_db0 = 0;
        local_db8 = (char *)0x0;
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x61);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362700(&local_d18,uVar9,0,0);
        if (iVar14 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,&local_d18);
        }
        plVar24 = (longlong *)FUN_140087ed0();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0x10))(plVar24,uVar9);
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        local_dc8 = 0;
        (**(code **)(local_d88[2] + 0x2e0))(local_d88 + 2,0x1c,0);
        FUN_1403625e0(&local_d18);
      }
    }
    break;
  case 99:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      iVar14 = (**(code **)(lVar26 + 0xa8))(plVar24,uVar9);
      if (iVar14 < 2) {
        lVar26 = local_d88[0x1e2];
        plVar24 = local_d88 + 2;
        uVar15 = (**(code **)(*local_d88 + 8))();
        uVar18 = (**(code **)(*plVar24 + 0x18))(plVar24);
        local_dc8 = CONCAT44(local_dc8._4_4_,(int)lVar26);
        tq::MyLogSave("gmlog/cheater","cheater[%s] player_id[%u] account id[%u], auto miner",uVar18,
                      (ulonglong)uVar15);
      }
      cVar4 = (**(code **)(local_d88[2] + 0x220))();
      if (cVar4 == '\0') {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_DIE");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
      }
      else {
        lVar26 = (**(code **)(local_d88[2] + 0x160))();
        plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
        plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
        uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar21 >> 0xb & 1) == 0) {
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_NO_MINE");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        }
        else {
          FUN_1403325b0(local_d88);
        }
      }
    }
    break;
  case 0x66:
    if (local_d88 != (longlong *)0x0) {
      uVar18 = (**(code **)(local_d88[2] + 0x160))();
      cVar4 = FUN_14011dbb0(uVar18);
      if ((cVar4 == '\0') || (cVar4 = (**(code **)(local_d88[2] + 0x280))(), cVar4 == '\0')) {
        plVar19 = (longlong *)
                  (**(code **)(local_d88[2] + 0x2a8))
                            (local_d88 + 2,*(undefined4 *)(param_1[0x85] + 8));
        if ((plVar19 != (longlong *)0x0) &&
           (cVar4 = (**(code **)(*plVar19 + 0x220))(plVar19), cVar4 != '\0')) {
          lVar26 = *plVar19;
          plVar20 = local_d88 + 2;
          uVar9 = (**(code **)(*plVar20 + 0x48))(plVar20);
          uVar16 = (**(code **)(*plVar20 + 0x40))(plVar20);
          iVar14 = (**(code **)(lVar26 + 0x158))(plVar19,uVar16,uVar9);
          if (iVar14 < 0x13) {
            plVar20 = (longlong *)(**(code **)(*plVar19 + 0x2a0))(plVar19);
            if (local_d88 != (longlong *)0x0) {
              plVar24 = local_d88 + 2;
            }
            (**(code **)(*plVar20 + 0x30))(plVar20,plVar24);
          }
        }
        cVar4 = (**(code **)(local_d88[2] + 0x230))();
        if ((cVar4 != '\0') &&
           ((**(code **)(local_d88[2] + 0x358))
                      (local_d88 + 2,"actionQueryPlayer: [%d]",*(undefined4 *)(param_1[0x85] + 8)),
           plVar19 != (longlong *)0x0)) {
          lVar26 = local_d88[2];
          uVar9 = (**(code **)(*plVar19 + 0x48))(plVar19);
          uVar16 = (**(code **)(*plVar19 + 0x40))(plVar19);
          uVar13 = (**(code **)(*plVar19 + 0x10))(plVar19);
          uVar18 = (**(code **)(*plVar19 + 0x18))(plVar19);
          local_dc0 = (char *)CONCAT44(local_dc0._4_4_,uVar9);
          local_dc8 = CONCAT44(local_dc8._4_4_,uVar16);
          (**(code **)(lVar26 + 0x358))
                    (local_d88 + 2,"target: [%s][%d], pos: [%d][%d]",uVar18,uVar13);
        }
      }
    }
    break;
  case 0x6a:
    if (local_d88 != (longlong *)0x0) {
      iVar14 = *(int *)(lVar26 + 8);
      cVar4 = FUN_140167b70();
      if (cVar4 != '\0') {
        lVar26 = param_1[0x85];
        uVar9 = FUN_140167b40(local_d88);
        uVar18 = FUN_140008520((int)param_1[0x82]);
        uVar18 = FUN_140087650(uVar18);
        iVar14 = FUN_1402aef00(uVar18,uVar9,*(undefined4 *)(lVar26 + 8));
      }
      if ((iVar14 != 0) && (plVar24 = (longlong *)FUN_140118320(), plVar24 != (longlong *)0x0)) {
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        cVar4 = (**(code **)(lVar26 + 0x20))(plVar24,uVar9,iVar14);
        if (cVar4 != '\0') {
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          lVar26 = (**(code **)(*plVar24 + 0x98))(plVar24,iVar14);
          if (lVar26 != 0) {
            iVar14 = FUN_140168a20(lVar26);
            iVar10 = FUN_140168a20(local_d88);
            plVar24 = local_d88;
            if (iVar14 == iVar10) {
              plVar19 = (longlong *)(lVar26 + 0x10);
              iVar14 = (**(code **)(*plVar19 + 0x168))(plVar19);
              iVar10 = (**(code **)(plVar24[2] + 0x168))(plVar24 + 2);
              if (iVar14 == iVar10) {
                FUN_140362560(&local_d18);
                lVar26 = param_1[0x85];
                uVar9 = (**(code **)(*plVar19 + 0x48))(plVar19);
                uVar16 = (**(code **)(*plVar19 + 0x40))(plVar19);
                local_db0 = 0;
                local_db8 = (char *)CONCAT44(local_db8._4_4_,*(undefined4 *)(lVar26 + 8));
                local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x6a);
                local_dc8 = local_dc8 & 0xffffffffffff0000;
                iVar14 = FUN_140362620(&local_d18,*(undefined4 *)(param_1[0x85] + 4),uVar16,uVar9);
                if (iVar14 == 0) {
                  local_dc8 = CONCAT44(local_dc8._4_4_,0x158);
                  log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                                     "msg.Create(m_pInfo->idUser, pTarget->GetPosX(), pTarget->GetPosY(), 0, actionQueryTeamMember, m_pInfo->idTarget)"
                                     ,
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                                    );
                }
                else {
                  (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
                }
                FUN_1403625e0(&local_d18);
              }
            }
          }
        }
      }
    }
    break;
  case 0x75:
    uVar18 = FUN_140008520((int)param_1[0x82]);
    plVar24 = (longlong *)FUN_140087650(uVar18);
    lVar26 = (**(code **)(*plVar24 + 0x98))(plVar24,*(undefined4 *)(param_1[0x85] + 8));
    if ((lVar26 != 0) && (FUN_14032b2e0(lVar26,local_d88), local_d88 != (longlong *)0x0)) {
      pIVar25 = theInstance();
      lVar27 = *(longlong *)(lVar26 + 0x10);
      uVar18 = (**(code **)(local_d88[2] + 0x18))();
      uVar23 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_QUERYEQUIPMENT_HINT");
      (**(code **)(lVar27 + 0x358))(lVar26 + 0x10,uVar23,uVar18);
    }
    break;
  case 0x76:
    if (local_d88 != (longlong *)0x0) {
      if (local_d88[0x151] == 0) {
        if ((int)local_d88[0x153] != -1) {
          FUN_140173130();
        }
      }
      else {
        FUN_140173030();
      }
    }
    break;
  case 0x78:
    if (local_d88 != (longlong *)0x0) {
      FUN_140362560(&local_d18);
      plVar24 = local_d88 + 2;
      uVar7 = (**(code **)(*plVar24 + 0x50))(plVar24);
      uVar9 = (**(code **)(*plVar24 + 0x48))(plVar24);
      uVar16 = (**(code **)(*plVar24 + 0x40))(plVar24);
      uVar13 = (**(code **)(*local_d88 + 8))();
      local_db0 = 0;
      local_db8 = (char *)CONCAT44(local_db8._4_4_,3);
      local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0x9d);
      local_dc8 = CONCAT62(local_dc8._2_6_,uVar7);
      iVar14 = FUN_140362620(&local_d18,uVar13,uVar16,uVar9);
      if (iVar14 == 0) {
        local_dc8 = CONCAT44(local_dc8._4_4_,0x76e);
        log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                           "msg.Create(pUser->GetID(), pUser->GetPosX(), pUser->GetPosY(), pUser->GetDir(), actionLandingInfo, LANDING_ACTIVE)"
                           ,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                          );
      }
      else {
        (**(code **)(local_d88[2] + 0x348))(local_d88 + 2,&local_d18,1);
      }
      plVar24 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0x10))(plVar24,uVar9,0x16);
      cVar4 = FUN_140160510(local_d88);
      if (cVar4 != '\0') {
        lVar26 = local_d88[2];
        plVar24 = local_d88 + 2;
        uVar9 = (**(code **)(lVar26 + 0x48))(plVar24);
        uVar16 = (**(code **)(*plVar24 + 0x40))(plVar24);
        uVar13 = (**(code **)(*local_d88 + 8))();
        local_dc8 = CONCAT44(local_dc8._4_4_,uVar9);
        (**(code **)(lVar26 + 0x3c0))(local_d88 + 2,0x1b59,uVar13,uVar16);
      }
      FUN_1403625e0(&local_d18);
    }
    break;
  case 0x7a:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0x10))(plVar24,uVar9,0x17);
    }
    break;
  case 0x7b:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1401183a0();
      lVar26 = *plVar24;
      lVar27 = param_1[0x85];
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0x1e0))(plVar24,uVar9,*(undefined4 *)(lVar27 + 8));
    }
    break;
  case 0x82:
    if (((plVar19 != (longlong *)0x0) &&
        (cVar4 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1002,&local_d80), cVar4 != '\0')) &&
       (iVar14 = (**(code **)(*local_d80 + 8))(), iVar14 - 0xaae61U < 99999)) {
      (**(code **)(*plVar19 + 0x348))(plVar19,param_1,1);
      lVar26 = (**(code **)(local_d80[2] + 0x2b0))();
      if ((lVar26 != 0) &&
         (iVar14 = (**(code **)(*(longlong *)(lVar26 + 0x10) + 0x158))
                             ((longlong *)(lVar26 + 0x10),*(undefined2 *)(param_1[0x85] + 8),
                              *(undefined2 *)(param_1[0x85] + 10)), iVar14 < 0x13)) {
        (**(code **)(*plVar19 + 0x2e8))(plVar19,4);
        (**(code **)(*plVar19 + 0x370))
                  (plVar19,*(undefined2 *)(param_1[0x85] + 8),*(undefined2 *)(param_1[0x85] + 10));
      }
    }
    break;
  case 0x84:
    plVar24 = (longlong *)FUN_1400e1e60();
    lVar26 = *plVar24;
    uVar9 = (**(code **)(*local_d88 + 8))();
    cVar4 = (**(code **)(lVar26 + 0xb0))(plVar24,uVar9,8);
    if ((cVar4 != '\0') && (local_d88 != (longlong *)0x0)) {
      CTickAnalyst::CTickAnalyst(&local_458,8);
      FUN_1401a8c40(local_d88);
      plVar24 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
      CTickAnalyst::~CTickAnalyst(&local_458);
    }
    break;
  case 0x89:
    if (((*(int *)((longlong)param_1 + 0x414) == -1) || (*(int *)(lVar26 + 4) - 0xaae61U < 99999))
       || (*(int *)(lVar26 + 4) - 1000000U < 0xee5be5c0)) {
      if (local_d88 == (longlong *)0x0) {
        lVar26 = (**(code **)(*plVar19 + 0x160))(plVar19);
        if (lVar26 == 0) {
          return;
        }
        cVar4 = FUN_1402c3cc0(lVar26,*(undefined2 *)(param_1[0x85] + 8),
                              *(undefined2 *)(param_1[0x85] + 10));
        if (cVar4 == '\0') {
          return;
        }
      }
      else {
        cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x18);
        if ((cVar4 != '\0') ||
           (cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x6e), cVar4 != '\0')) {
          FUN_140185db0(local_d88);
          return;
        }
        cVar4 = FUN_140168a10(local_d88);
        if (cVar4 != '\0') {
          uVar18 = FUN_140008520((int)param_1[0x82]);
          uVar15 = FUN_14008b010(uVar18);
          uVar12 = FUN_1401649c0(local_d88);
          if (uVar12 < uVar15) {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            plVar24 = (longlong *)FUN_140087650(uVar18);
            (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758478);
            return;
          }
        }
        iVar14 = (**(code **)(local_d88[2] + 0x158))
                           (local_d88 + 2,*(undefined2 *)(param_1[0x85] + 8),
                            *(undefined2 *)(param_1[0x85] + 10));
        local_d70 = CONCAT44(local_d70._4_4_,iVar14);
        iVar10 = (**(code **)(*local_d88 + 8))();
        if (iVar10 == *(int *)(param_1[0x85] + 4)) {
          cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x2f);
          if ((cVar4 != '\0') && (iVar10 = FUN_140160af0(local_d88), iVar10 < iVar14)) {
            return;
          }
          cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x2f);
          if ((cVar4 == '\0') || (*(char *)(param_1[0x85] + 0x24) == '\0')) {
            plVar20 = (longlong *)FUN_1400e1e60();
            lVar26 = *plVar20;
            lVar27 = param_1[0x85];
            uVar9 = (**(code **)(*local_d88 + 8))();
            cVar4 = (**(code **)(lVar26 + 0x98))(plVar20,uVar9,*(undefined4 *)(lVar27 + 0x10));
            if (cVar4 == '\0') {
              (**(code **)(local_d88[2] + 0x358))(local_d88 + 2,"invalid jump");
              uVar18 = FUN_140008520((int)param_1[0x82]);
              plVar24 = (longlong *)FUN_140087650(uVar18);
              (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,"invalid jump time stamp");
              return;
            }
            iVar14 = (int)local_d70;
          }
          else {
            plVar20 = (longlong *)FUN_1400e1e60();
            lVar26 = *plVar20;
            uVar9 = (**(code **)(*local_d88 + 8))();
            (**(code **)(lVar26 + 0x90))(plVar20,uVar9);
            plVar20 = (longlong *)FUN_1400e1e60();
            lVar26 = *plVar20;
            lVar27 = param_1[0x85];
            uVar9 = (**(code **)(*local_d88 + 8))();
            cVar4 = (**(code **)(lVar26 + 0xa0))(plVar20,uVar9,*(undefined4 *)(lVar27 + 0x10));
            if (cVar4 == '\0') {
              (**(code **)(local_d88[2] + 0x358))(local_d88 + 2,"invalid Mount Charge");
              uVar18 = FUN_140008520((int)param_1[0x82]);
              plVar24 = (longlong *)FUN_140087650(uVar18);
              (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,"invalid Mount Charge time stamp");
              return;
            }
            iVar14 = (int)local_d70;
          }
        }
        iVar10 = (**(code **)(local_d88[2] + 0x168))();
        if (iVar10 != *(int *)(param_1[0x85] + 0x1c)) {
          FUN_140185db0(local_d88);
          return;
        }
        cVar4 = (**(code **)(local_d88[2] + 0x220))();
        if (cVar4 == '\0') {
          FUN_140185db0(local_d88);
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_DIE");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
          return;
        }
        if (0x12 < iVar14) {
          cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x5b);
          if (cVar4 != '\0') {
            FUN_140185db0(local_d88);
            return;
          }
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_INVALID_MSG");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758408);
          return;
        }
        if (local_d88[0x151] != 0) {
          plVar20 = (longlong *)**(undefined8 **)(local_d88[0x151] + 0x10);
          plVar20 = (longlong *)(**(code **)(*plVar20 + 0x10))(plVar20,0x15);
          uVar15 = (**(code **)(*plVar20 + 0x48))(plVar20);
          if ((uVar15 >> 5 & 1) == 0) {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            plVar24 = (longlong *)FUN_140087650(uVar18);
            (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_1407583f8);
            return;
          }
        }
        uVar18 = FUN_140008520((int)param_1[0x82]);
        plVar20 = (longlong *)FUN_1400876b0(uVar18);
        lVar26 = *plVar20;
        uVar9 = (**(code **)(local_d88[2] + 0x168))();
        lVar26 = (**(code **)(lVar26 + 0x10))(plVar20,uVar9,1);
        if (lVar26 == 0) {
          return;
        }
        cVar4 = FUN_1402c3cc0(lVar26,*(undefined2 *)(param_1[0x85] + 8),
                              *(undefined2 *)(param_1[0x85] + 10));
        if (cVar4 == '\0') {
          pIVar25 = theInstance();
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          lVar26 = *plVar24;
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_INVALID_COORDINATE");
          (**(code **)(lVar26 + 0x50))(plVar24,local_d88,uVar18);
          return;
        }
        plVar20 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
        plVar20 = (longlong *)(**(code **)(*plVar20 + 0x10))(plVar20,4);
        uVar21 = (**(code **)(*plVar20 + 0x58))(plVar20);
        if ((uVar21 >> 0x19 & 1) != 0) {
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_1407583e8);
          return;
        }
        cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x27);
        if (cVar4 != '\0') {
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_1407583d0);
          return;
        }
        cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x7d);
        if (cVar4 != '\0') {
          uVar18 = FUN_140008520((int)param_1[0x82]);
          plVar24 = (longlong *)FUN_140087650(uVar18);
          (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_1407583b8);
          return;
        }
        uVar18 = FUN_140161000(local_d88);
        cVar4 = FUN_1403b4200(uVar18);
        if ((cVar4 != '\0') && (iVar14 = (**(code **)(*local_d88 + 0x50))(), iVar14 == 2)) {
          iVar14 = FUN_1403b41c0(uVar18);
          if (iVar14 == 0x186a4) {
            return;
          }
          iVar14 = FUN_1403b41c0(uVar18);
          if (iVar14 == 0x186a7) {
            return;
          }
        }
        if ((local_d88 != (longlong *)0x0) &&
           (cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x73), cVar4 != '\0')) {
          plVar20 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
          plVar20 = (longlong *)(**(code **)(*plVar20 + 0x10))(plVar20,4);
          uVar21 = (**(code **)(*plVar20 + 0x58))(plVar20);
          if ((uVar21 >> 0x1f & 1) != 0) {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            cVar4 = FUN_14008b330(uVar18);
            if (cVar4 == '\0') {
              plVar20 = (longlong *)CurrentInstanceGet();
              lVar27 = (**(code **)(*plVar20 + 0x20))(plVar20,0x1c);
              if ((lVar27 != 0) &&
                 (cVar4 = FUN_1402c68a0(lVar26,0x18,*(undefined2 *)(param_1[0x85] + 8),
                                        *(undefined2 *)(param_1[0x85] + 10)), cVar4 != '\0')) {
                pIVar25 = theInstance();
                lVar27 = local_d88[2];
                uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar27 + 0x358))(local_d88 + 2,uVar18);
                FUN_140185db0(local_d88);
                plVar24 = local_d88;
                uVar9 = (**(code **)(local_d88[2] + 0x48))(local_d88 + 2);
                uVar16 = (**(code **)(plVar24[2] + 0x40))(plVar24 + 2);
                cVar4 = FUN_1402c68a0(lVar26,0x18,uVar16,uVar9);
                if (cVar4 == '\0') {
                  return;
                }
                pIVar25 = theInstance();
                lVar26 = local_d88[2];
                uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
                uVar18 = FUN_140008520((int)param_1[0x82]);
                plVar24 = (longlong *)FUN_140087650(uVar18);
                (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758380);
                return;
              }
            }
            else {
              plVar20 = (longlong *)CurrentInstanceGet();
              lVar27 = (**(code **)(*plVar20 + 0x20))(plVar20,0x25);
              if ((lVar27 != 0) &&
                 (cVar4 = FUN_1402c68a0(lVar26,0x18,*(undefined2 *)(param_1[0x85] + 8),
                                        *(undefined2 *)(param_1[0x85] + 10)), cVar4 != '\0')) {
                pIVar25 = theInstance();
                lVar27 = local_d88[2];
                uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar27 + 0x358))(local_d88 + 2,uVar18);
                FUN_140185db0(local_d88);
                plVar24 = local_d88;
                uVar9 = (**(code **)(local_d88[2] + 0x48))(local_d88 + 2);
                uVar16 = (**(code **)(plVar24[2] + 0x40))(plVar24 + 2);
                cVar4 = FUN_1402c68a0(lVar26,0x18,uVar16,uVar9);
                if (cVar4 == '\0') {
                  return;
                }
                pIVar25 = theInstance();
                lVar26 = local_d88[2];
                uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
                uVar18 = FUN_140008520((int)param_1[0x82]);
                plVar24 = (longlong *)FUN_140087650(uVar18);
                (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758380);
                return;
              }
            }
          }
        }
        cVar4 = (**(code **)(local_d88[2] + 0x2d8))(local_d88 + 2,0x2f);
        if (cVar4 != '\0') {
          if (*(char *)(param_1[0x85] + 0x24) != '\0') {
            plVar20 = (longlong *)FUN_1401181a0();
            lVar26 = *plVar20;
            uVar9 = (**(code **)(*plVar19 + 0x10))(plVar19);
            local_d98 = 0;
            local_da0 = (uint)local_da0._2_2_ << 0x10;
            local_da8 = local_da8 & 0xffffff00;
            local_db0 = 0;
            local_db8 = (char *)((ulonglong)local_db8._4_4_ << 0x20);
            local_dc0 = (char *)((ulonglong)local_dc0._4_4_ << 0x20);
            local_dc8 = CONCAT44(local_dc8._4_4_,2);
            (**(code **)(lVar26 + 8))(plVar20,uVar9,0x75,1);
          }
          iVar14 = FUN_140160af0(local_d88);
          FUN_14018e220(local_d88,iVar14 - (int)local_d70);
          FUN_140160b00(local_d88);
        }
      }
      if (local_d88 != (longlong *)0x0) {
        lVar26 = param_1[0x85];
        cVar4 = (**(code **)(local_d88[2] + 0x278))();
        uVar18 = 200;
        if (cVar4 != '\0') {
          uVar18 = 100;
        }
        cVar4 = FUN_1401a9ee0(local_d88,*(undefined2 *)(lVar26 + 8),*(undefined2 *)(lVar26 + 10),
                              uVar18);
        if (cVar4 == '\0') {
          FUN_140185db0(local_d88);
          return;
        }
      }
      uVar11 = tq::TimeGet(0);
      *(ulong *)(param_1[0x85] + 0x10) = uVar11;
      (**(code **)(*plVar19 + 0x2b8))(plVar19,*(undefined2 *)(param_1[0x85] + 0x16));
      if (local_d88 == (longlong *)0x0) {
        (**(code **)(*plVar19 + 0x348))(plVar19,param_1,1);
      }
      else {
        lVar26 = param_1[0x85];
        FUN_14016f630(local_d88,*(undefined2 *)(lVar26 + 8),*(undefined2 *)(lVar26 + 10),
                      *(undefined1 *)(lVar26 + 0x24));
      }
      iVar14 = (**(code **)(*plVar19 + 0x158))
                         (plVar19,*(undefined2 *)(param_1[0x85] + 8),
                          *(undefined2 *)(param_1[0x85] + 10));
      if (iVar14 < 0x13) {
        (**(code **)(*plVar19 + 0x2e8))(plVar19,3);
        local_d50 = (longlong *)0x0;
        cVar4 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1001,&local_d50);
        if ((cVar4 == '\0') || (local_d50 == (longlong *)0x0)) {
          (**(code **)(*plVar19 + 0x378))
                    (plVar19,*(undefined2 *)(param_1[0x85] + 8),*(undefined2 *)(param_1[0x85] + 10))
          ;
        }
        else {
          plVar20 = (longlong *)(**(code **)(local_d50[2] + 0x160))();
          if (plVar20 == (longlong *)0x0) {
            local_dc8 = CONCAT44(local_dc8._4_4_,0x520);
            log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",&DAT_140705b14,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                              );
          }
          else {
            cVar4 = FUN_14015f9d0(plVar20,*(undefined2 *)(param_1[0x85] + 8),
                                  *(undefined2 *)(param_1[0x85] + 10));
            if (cVar4 == '\0') {
              uVar6 = *(ushort *)(param_1[0x85] + 10);
              uVar1 = *(ushort *)(param_1[0x85] + 8);
              uVar15 = (**(code **)(*plVar20 + 8))(plVar20);
              uVar12 = (**(code **)(*local_d50 + 8))();
              local_db8 = (char *)CONCAT44(local_db8._4_4_,0x523);
              local_dc0 = 
              "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
              ;
              local_dc8 = CONCAT44(local_dc8._4_4_,(uint)uVar6);
              log_InlineLogERROR("CMsgAction::Process case actionJump: user%u map%u(%d, %d) at %s, %d"
                                 ,(ulonglong)uVar12,(ulonglong)uVar15,(ulonglong)uVar1);
            }
            else {
              (**(code **)(local_d50[2] + 0x378))
                        (local_d50 + 2,*(undefined2 *)(param_1[0x85] + 8),
                         *(undefined2 *)(param_1[0x85] + 10));
            }
          }
        }
      }
      else {
        if (local_d88 != (longlong *)0x0) {
          local_dc8 = CONCAT44(local_dc8._4_4_,0x509);
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!pUser",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                            );
        }
        (**(code **)(*plVar19 + 0x2e8))(plVar19,4);
        (**(code **)(*plVar19 + 0x370))
                  (plVar19,*(undefined2 *)(param_1[0x85] + 8),*(undefined2 *)(param_1[0x85] + 10));
      }
      lVar26 = FUN_140008520((int)param_1[0x82]);
      if (*(longlong *)(lVar26 + 0x140) == 0) {
        local_dc8 = CONCAT44(local_dc8._4_4_,0x149);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pAuraMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
      }
      else {
        plVar24 = *(longlong **)(lVar26 + 0x140);
      }
      uVar9 = (**(code **)(*plVar19 + 0x10))(plVar19);
      FUN_14024e7b0(plVar24,uVar9);
    }
    else {
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_1400875f0(uVar18);
      plVar24 = (longlong *)
                (**(code **)(*plVar24 + 0x18))(plVar24,param_1,*(undefined4 *)(param_1[0x85] + 4));
      local_d80 = (longlong *)0x0;
      if ((plVar24 != (longlong *)0x0) &&
         (cVar4 = (**(code **)(*plVar24 + 0x298))(plVar24,0x1001,&local_d80), cVar4 != '\0')) {
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d80 + 8))();
        local_db0 = 0;
        local_db8 = (char *)((ulonglong)local_db8._4_4_ << 0x20);
        local_dc0 = (char *)((ulonglong)local_dc0._4_4_ << 0x20);
        local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
        (**(code **)(lVar26 + 0x28))(plVar24,uVar9,7);
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        iVar14 = tq::RandGet(300);
        uVar9 = (**(code **)(*local_d80 + 8))();
        (**(code **)(lVar26 + 0x38))(plVar24,uVar9,iVar14 + 0x1e,&DAT_140758498);
      }
    }
    break;
  case 0x91:
    if ((local_d88 != (longlong *)0x0) &&
       (cVar4 = (**(code **)(local_d88[2] + 0x220))(), cVar4 == '\0')) {
      FUN_1401a9be0(local_d88);
    }
    break;
  case 0x92:
    if (local_d88 != (longlong *)0x0) {
      cVar4 = FUN_14017efb0();
      if (cVar4 != '\0') {
        uVar18 = FUN_140008520((int)param_1[0x82]);
        plVar24 = (longlong *)FUN_140087650(uVar18);
        (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,&DAT_140758308);
      }
      *(undefined4 *)((longlong)local_d88 + 0x524) = 0;
      *(undefined4 *)(local_d88 + 0xa4) = 0;
      iVar14 = (**(code **)(local_d88[2] + 0x168))();
      if (iVar14 != *(int *)(param_1[0x85] + 0x1c)) {
        return;
      }
    }
    uVar15 = (**(code **)(*plVar19 + 0x40))(plVar19);
    if ((uVar15 != *(ushort *)(param_1[0x85] + 8)) ||
       (uVar15 = (**(code **)(*plVar19 + 0x48))(plVar19), uVar15 != *(ushort *)(param_1[0x85] + 10))
       ) {
      iVar14 = (**(code **)(*plVar19 + 0x158))
                         (plVar19,*(undefined2 *)(param_1[0x85] + 8),
                          *(undefined2 *)(param_1[0x85] + 10));
      if (iVar14 < 0x12) {
        (**(code **)(*plVar19 + 0x348))(plVar19,param_1,0);
        (**(code **)(*plVar19 + 0x2e8))(plVar19,8);
        local_d58 = (longlong *)0x0;
        cVar4 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1001,&local_d58);
        if ((cVar4 == '\0') || (local_d58 == (longlong *)0x0)) {
          (**(code **)(*plVar19 + 0x378))
                    (plVar19,*(undefined2 *)(param_1[0x85] + 8),*(undefined2 *)(param_1[0x85] + 10))
          ;
        }
        else {
          plVar24 = (longlong *)(**(code **)(local_d58[2] + 0x160))();
          if (plVar24 == (longlong *)0x0) {
            local_dc8 = CONCAT44(local_dc8._4_4_,0x55f);
            log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",&DAT_140705b14,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                              );
          }
          else {
            cVar4 = FUN_14015f9d0(plVar24,*(undefined2 *)(param_1[0x85] + 8),
                                  *(undefined2 *)(param_1[0x85] + 10));
            if (cVar4 == '\0') {
              uVar6 = *(ushort *)(param_1[0x85] + 10);
              uVar1 = *(ushort *)(param_1[0x85] + 8);
              uVar15 = (**(code **)(*plVar24 + 8))(plVar24);
              uVar12 = (**(code **)(*local_d58 + 8))();
              local_db8 = (char *)CONCAT44(local_db8._4_4_,0x562);
              local_dc0 = 
              "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
              ;
              local_dc8 = CONCAT44(local_dc8._4_4_,(uint)uVar6);
              log_InlineLogERROR("CMsgAction::Process case actionSynchro: user%u map%u(%d, %d) at %s, %d"
                                 ,(ulonglong)uVar12,(ulonglong)uVar15,(ulonglong)uVar1);
            }
            else {
              (**(code **)(local_d58[2] + 0x378))
                        (local_d58 + 2,*(undefined2 *)(param_1[0x85] + 8),
                         *(undefined2 *)(param_1[0x85] + 10));
            }
          }
        }
      }
      else if (local_d88 == (longlong *)0x0) {
        (**(code **)(*plVar19 + 0x348))(plVar19,param_1,0);
        (**(code **)(*plVar19 + 0x2e8))(plVar19,8);
        (**(code **)(*plVar19 + 0x370))
                  (plVar19,*(undefined2 *)(param_1[0x85] + 8),*(undefined2 *)(param_1[0x85] + 10));
      }
      else {
        uVar18 = FUN_140008520((int)param_1[0x82]);
        plVar24 = (longlong *)FUN_140087650(uVar18);
        (**(code **)(*plVar24 + 0x50))(plVar24,local_d88,"Receive invalid synchro msg!");
      }
    }
    break;
  case 0x94:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1401183a0();
      lVar26 = *plVar24;
      lVar27 = param_1[0x85];
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 400))(plVar24,uVar9,*(undefined4 *)(lVar27 + 8));
    }
    break;
  case 0x95:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1400e1de0();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0x10))(plVar24,uVar9);
    }
    break;
  case 0x97:
    if (local_d88 == (longlong *)0x0) {
      return;
    }
    if (*(short *)(lVar26 + 0x16) == 1) {
      uVar18 = FUN_140008520((int)param_1[0x82]);
      cVar4 = FUN_14008ab60(uVar18,2);
      if (cVar4 == '\0') {
        return;
      }
      uVar15 = FUN_1401649c0(local_d88);
      if (uVar15 < 4) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_VIP_LEVEL_NOT_TO_CHANGE_FACE");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
      uVar15 = *(byte *)((longlong)local_d88 + 0xeee) / 10;
      cVar4 = FUN_1401670d0(*(undefined4 *)(param_1[0x85] + 8));
      if ((((cVar4 == '\0') &&
           (cVar4 = FUN_140167110(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0')) &&
          (cVar4 = FUN_140167150(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0')) &&
         (cVar4 = FUN_140167190(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0')) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
      if (uVar15 == 6) {
        cVar4 = FUN_140167110(*(undefined4 *)(param_1[0x85] + 8));
        if (cVar4 == '\0') {
LAB_14036367d:
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
          return;
        }
LAB_1403636b8:
        cVar4 = FUN_140167150(*(undefined4 *)(param_1[0x85] + 8));
        if (cVar4 != '\0') {
          pIVar25 = theInstance();
          lVar26 = local_d88[2];
          uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
          (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
          return;
        }
      }
      else {
        cVar4 = FUN_140167110(*(undefined4 *)(param_1[0x85] + 8));
        if (cVar4 != '\0') goto LAB_14036367d;
        if (uVar15 != 7) goto LAB_1403636b8;
      }
      if ((uVar15 != 8) &&
         (cVar4 = FUN_140167190(*(undefined4 *)(param_1[0x85] + 8)), cVar4 != '\0')) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
      iVar14 = FUN_1401671b0(*(undefined4 *)(param_1[0x85] + 8));
      iVar10 = (**(code **)(*local_d88 + 0x50))();
      if (iVar10 != iVar14) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_SEX_DIFFER_NO_TO_BUY");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
      uVar21 = (ulonglong)*(uint *)((longlong)local_d88 + 0xeac) / 10000;
      if ((int)uVar21 + (int)(uVar21 / 1000) * -1000 == *(int *)(param_1[0x85] + 8)) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_FACE_ALREADY_NO_TO_BUY");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
LAB_140363aee:
      pIVar25 = theInstance();
      _Str1 = (char *)(*(code *)**(undefined8 **)pIVar25)(pIVar25,"Language");
      iVar14 = _stricmp(_Str1,"English");
      if ((iVar14 != 0) || (*(uint *)(param_1[0x85] + 8) < 0x191)) {
        FUN_140162d80(local_d88,*(undefined4 *)(param_1[0x85] + 8));
        (**(code **)(local_d88[2] + 0x348))(local_d88 + 2,param_1,1);
        plVar24 = (longlong *)FUN_140118320();
        if (plVar24 != (longlong *)0x0) {
          lVar26 = *plVar24;
          uVar9 = (**(code **)(*local_d88 + 8))();
          iVar14 = (**(code **)(lVar26 + 0x28))(plVar24,uVar9);
          if (iVar14 != 0) {
            lVar26 = *plVar24;
            uVar9 = (**(code **)(*local_d88 + 8))();
            (**(code **)(lVar26 + 0x90))(plVar24,iVar14,param_1,uVar9);
          }
        }
      }
    }
    else {
      uVar15 = *(byte *)((longlong)local_d88 + 0xeee) / 10;
      cVar4 = FUN_1401670b0(*(undefined4 *)(lVar26 + 8));
      if (((cVar4 == '\0') &&
          (cVar4 = FUN_1401670f0(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0')) &&
         ((cVar4 = FUN_140167130(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0' &&
          (cVar4 = FUN_140167170(*(undefined4 *)(param_1[0x85] + 8)), cVar4 == '\0')))) {
        pIVar25 = theInstance();
        lVar26 = local_d88[2];
        uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
        (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
        return;
      }
      if (uVar15 == 6) {
        cVar4 = FUN_1401670f0(*(undefined4 *)(param_1[0x85] + 8));
        if (cVar4 != '\0') {
LAB_140363934:
          cVar4 = FUN_140167130(*(undefined4 *)(param_1[0x85] + 8));
          if (cVar4 != '\0') {
LAB_140363947:
            pIVar25 = theInstance();
            lVar26 = local_d88[2];
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
            (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
            return;
          }
          if (uVar15 != 8) goto LAB_140363997;
          cVar4 = FUN_140167170(*(undefined4 *)(param_1[0x85] + 8));
          if (cVar4 == '\0') goto LAB_1403639aa;
LAB_1403639e0:
          iVar14 = FUN_1401671b0(*(undefined4 *)(param_1[0x85] + 8));
          iVar10 = (**(code **)(*local_d88 + 0x50))();
          if (iVar10 != iVar14) {
            pIVar25 = theInstance();
            lVar26 = local_d88[2];
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_SEX_DIFFER_NO_TO_BUY");
            (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
            return;
          }
          uVar21 = (ulonglong)*(uint *)((longlong)local_d88 + 0xeac) / 10000;
          if ((int)uVar21 + (int)(uVar21 / 1000) * -1000 == *(int *)(param_1[0x85] + 8)) {
            pIVar25 = theInstance();
            lVar26 = local_d88[2];
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_FACE_ALREADY_NO_TO_BUY");
            (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
            return;
          }
          cVar4 = (**(code **)(*local_d88 + 0x178))(local_d88,500,1);
          if (cVar4 == '\0') {
            pIVar25 = theInstance();
            lVar26 = local_d88[2];
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_NOT_SO_MUCH_MONEY");
            (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
            return;
          }
          goto LAB_140363aee;
        }
      }
      else {
        cVar4 = FUN_1401670f0(*(undefined4 *)(param_1[0x85] + 8));
        if (cVar4 == '\0') {
          if (uVar15 != 7) goto LAB_140363934;
          cVar4 = FUN_140167130(*(undefined4 *)(param_1[0x85] + 8));
          if (cVar4 == '\0') goto LAB_140363947;
LAB_140363997:
          cVar4 = FUN_140167170(*(undefined4 *)(param_1[0x85] + 8));
          if (cVar4 != '\0') {
LAB_1403639aa:
            pIVar25 = theInstance();
            lVar26 = local_d88[2];
            uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
            (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
            return;
          }
          goto LAB_1403639e0;
        }
      }
      pIVar25 = theInstance();
      lVar26 = local_d88[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_PROF_DIFFER_NO_TO_BUY");
      (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
    }
    break;
  case 0x98:
    if (local_d88 != (longlong *)0x0) {
      plVar24 = (longlong *)FUN_1401183a0();
      lVar26 = *plVar24;
      lVar27 = param_1[0x85];
      uVar9 = (**(code **)(*local_d88 + 8))();
      (**(code **)(lVar26 + 0xd8))(plVar24,uVar9,*(undefined4 *)(lVar27 + 8));
    }
    break;
  case 0xa1:
    if (local_d88 != (longlong *)0x0) {
      (**(code **)(*local_d88 + 0x158))(local_d88,*(int *)(lVar26 + 8) == 1);
      (**(code **)(local_d88[2] + 0x348))(local_d88 + 2,param_1,0);
    }
    break;
  case 0xa3:
    if (((local_d88 != (longlong *)0x0) &&
        (lVar26 = (**(code **)(*local_d88 + 0xa8))(local_d88,local_d30),
        (*(uint *)(lVar26 + 4) >> 0xf & 1) != 0)) && (*(int *)(param_1[0x85] + 8) != 0)) {
      local_d70 = 0;
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_1400875f0(uVar18);
      plVar24 = (longlong *)
                (**(code **)(*plVar24 + 0x20))(plVar24,*(undefined4 *)(param_1[0x85] + 8));
      if ((plVar24 != (longlong *)0x0) &&
         (cVar4 = (**(code **)(*plVar24 + 0x298))(plVar24,0x1002,&local_d70), cVar4 != '\0')) {
        plVar24 = (longlong *)
                  (**(code **)(*(longlong *)**(undefined8 **)(local_d70 + 0x140) + 0x10))
                            ((longlong *)**(undefined8 **)(local_d70 + 0x140),0x15);
        uVar15 = (**(code **)(*plVar24 + 0x48))(plVar24);
        lVar26 = local_d70;
        if (((uVar15 >> 0x11 & 1) != 0) && (*(int *)(local_d70 + 0x154) == 0)) {
          lVar27 = local_d88[2];
          uVar9 = (**(code **)(*(longlong *)(local_d70 + 0x10) + 0x48))(local_d70 + 0x10);
          uVar16 = (**(code **)(*(longlong *)(lVar26 + 0x10) + 0x40))(lVar26 + 0x10);
          iVar14 = (**(code **)(lVar27 + 0x158))(local_d88 + 2,uVar16,uVar9);
          if (iVar14 < 3) {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            plVar19 = (longlong *)FUN_1400876b0(uVar18);
            lVar26 = *plVar19;
            plVar24 = (longlong *)(local_d70 + 0x10);
            uVar9 = (**(code **)(*plVar24 + 0x48))(plVar24);
            uVar16 = (**(code **)(*plVar24 + 0x40))(plVar24);
            cVar4 = (**(code **)(lVar26 + 0x120))
                              (plVar19,*(undefined4 *)(param_1[0x85] + 0x1c),uVar16,uVar9);
            if (cVar4 != '\0') {
              FUN_140391250(local_d70,*(undefined4 *)(param_1[0x85] + 4));
            }
          }
        }
      }
    }
    break;
  case 0xa6:
    if ((local_d88 != (longlong *)0x0) && (*(int *)(lVar26 + 8) != 0)) {
      lVar26 = (**(code **)(local_d88[2] + 0x160))();
      if (lVar26 != 0) {
        lVar26 = (**(code **)(local_d88[2] + 0x160))();
        plVar24 = *(longlong **)(*(longlong *)(lVar26 + 0x58) + 8);
        plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
        uVar21 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar21 >> 8 & 1) == 0) {
          lVar26 = param_1[0x85];
          uVar18 = FUN_140008520((int)param_1[0x82]);
          uVar18 = FUN_1400d6610(uVar18);
          iVar14 = FUN_14000eea0(uVar18,*(undefined4 *)(lVar26 + 8));
          if (iVar14 != 0) {
            uVar18 = FUN_140008520((int)param_1[0x82]);
            uVar18 = FUN_140087730(uVar18);
            local_dc0 = (char *)0x0;
            local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
            FUN_140145f60(uVar18,iVar14,local_d88,0);
          }
        }
      }
    }
    break;
  case 0xa7:
    if (((local_d88 != (longlong *)0x0) && (*(int *)(lVar26 + 8) != 0)) &&
       (lVar26 = (**(code **)(local_d88[2] + 0x160))(), lVar26 != 0)) {
      FUN_1401c8690(local_d88,*(undefined4 *)(param_1[0x85] + 8));
    }
    break;
  case 0xac:
    if ((char)local_d88[0x12d] == '\x01') {
      *(undefined1 *)(local_d88 + 0x12d) = 2;
      *(undefined4 *)(local_d88 + 0x12e) = 0;
      *(undefined4 *)((longlong)local_d88 + 0x974) = 0;
      memset(local_8c8,0,0x400);
      _snprintf(local_8c8,0x400,"%d",(ulonglong)*(uint *)(param_1[0x85] + 8));
      local_4c9 = 0;
      iVar14 = *(int *)((longlong)plVar20 + 0x96c);
      if (iVar14 == 0) {
        if (plVar20[0x132] != 0) {
          if ((ulonglong)plVar20[0x133] < 0x10) {
            plVar19 = plVar20 + 0x130;
          }
          else {
            plVar19 = (longlong *)plVar20[0x130];
          }
          plVar29 = DAT_140975bf0;
          if (DAT_140975bf0 == (longlong *)0x0) {
            local_dc8 = CONCAT44(local_dc8._4_4_,0x3cd);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pLuaScriptMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
            plVar29 = plVar24;
          }
          uVar9 = (**(code **)(*local_d88 + 8))();
          local_dc0 = local_8c8;
          local_dc8 = local_dc8 & 0xffffffff00000000;
          cVar4 = FUN_140286530(plVar29,plVar19,uVar9,0);
          if (cVar4 == '\0') {
            if ((ulonglong)plVar20[0x133] < 0x10) {
              plVar20 = plVar20 + 0x130;
            }
            else {
              plVar20 = (longlong *)plVar20[0x130];
            }
            log_InlineLogLuaERROR
                      ("Lua return fault, Call From:CMsgAction::Process actionChooseTarget, lua function:%s."
                       ,plVar20);
          }
        }
      }
      else {
        uVar18 = FUN_140008520((int)param_1[0x82]);
        uVar18 = FUN_140087730(uVar18);
        local_dc0 = local_8c8;
        local_dc8 = (ulonglong)local_dc8._4_4_ << 0x20;
        FUN_140145f60(uVar18,iVar14,local_d88,0);
      }
    }
    break;
  case 0xad:
    if (local_d88 != (longlong *)0x0) {
      FUN_140165a10();
    }
    break;
  case 0xae:
    if (((local_d88 == DAT_140975c38) &&
        (plVar24 = (longlong *)CurrentInstanceGet(), plVar24 != (longlong *)0x0)) &&
       (plVar24 = (longlong *)(**(code **)(*plVar24 + 0x20))(plVar24,0xc),
       plVar24 != (longlong *)0x0)) {
      if (*(int *)(param_1[0x85] + 8) == 0) {
        (**(code **)*plVar24)();
      }
      else {
        (**(code **)(*plVar24 + 8))(plVar24,*(undefined4 *)(param_1[0x85] + 4));
      }
    }
    break;
  case 0xb0:
    cVar4 = (**(code **)(*plVar19 + 0x2d8))(plVar19,0x6e);
    if (cVar4 != '\0') {
      plVar24 = (longlong *)FUN_1401181a0();
      lVar26 = *plVar24;
      uVar9 = (**(code **)(*plVar19 + 0x10))(plVar19);
      (**(code **)(lVar26 + 0x10))(plVar24,uVar9,0x6e);
    }
    break;
  case 0xb1:
    if ((local_d88 != (longlong *)0x0) &&
       (plVar24 = (longlong *)(**(code **)(local_d88[2] + 0x160))(), plVar24 != (longlong *)0x0)) {
      local_d68 = 0;
      local_d64 = 0;
      local_d60 = 0;
      uVar18 = FUN_140008520((int)param_1[0x82]);
      uVar18 = FUN_1400d6610(uVar18);
      FUN_140006c50(uVar18,&local_d68);
      plVar20 = (longlong *)
                (**(code **)(**(longlong **)(plVar24[0xb] + 8) + 0x10))
                          (*(longlong **)(plVar24[0xb] + 8),4);
      uVar21 = (**(code **)(*plVar20 + 0x58))(plVar20);
      if (((uVar21 >> 8 & 1) == 0) &&
         ((iVar14 = (**(code **)(*plVar24 + 8))(plVar24), iVar14 != 0x259 &&
          (iVar14 = (**(code **)(*plVar24 + 8))(plVar24), iVar14 != local_d68)))) {
        (**(code **)(*plVar19 + 0x2e8))(plVar19,5);
        local_dc8 = local_dc8 & 0xffffffffffffff00;
        FUN_1401c55b0(local_d88,local_d68,local_d64,local_d60);
      }
    }
    break;
  case 0xb2:
    if (local_d88 != (longlong *)0x0) {
      uVar6 = FUN_140373e50(local_d88 + 0x1cf);
      if ((uint)uVar6 != *(uint *)(param_1[0x85] + 8)) {
        FUN_140373e60(local_d88 + 0x1cf,*(undefined2 *)(param_1[0x85] + 8),0);
        uVar9 = (**(code **)(*local_d88 + 8))();
        *(undefined4 *)(param_1[0x85] + 4) = uVar9;
        (**(code **)(local_d88[2] + 0x348))(local_d88 + 2,param_1,1);
      }
    }
    break;
  case 0xfb:
    if (local_d88 != (longlong *)0x0) {
      plVar19 = (longlong *)FUN_1400e1e60();
      lVar26 = *plVar19;
      uVar9 = (**(code **)(*local_d88 + 8))();
      cVar4 = (**(code **)(lVar26 + 0xb0))(plVar19,uVar9,7);
      if (cVar4 != '\0') {
        lVar26 = FUN_140008520((int)param_1[0x82]);
        if (*(longlong *)(lVar26 + 0x168) == 0) {
          local_dc8 = CONCAT44(local_dc8._4_4_,0x150);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pStrCheckKey",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          plVar19 = plVar24;
        }
        else {
          plVar19 = *(longlong **)(lVar26 + 0x168);
        }
        lVar26 = param_1[0x85];
        uVar9 = (**(code **)(*local_d88 + 8))();
        FUN_1400fbae0(plVar19,uVar9,*(undefined4 *)(lVar26 + 0x10),*(undefined4 *)(lVar26 + 8));
        lVar26 = FUN_140008520((int)param_1[0x82]);
        if (*(longlong *)(lVar26 + 0x168) == 0) {
          local_dc8 = CONCAT44(local_dc8._4_4_,0x150);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pStrCheckKey",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
        }
        else {
          plVar24 = *(longlong **)(lVar26 + 0x168);
        }
        uVar9 = (**(code **)(*local_d88 + 8))();
        FUN_1400fbb30(plVar24,uVar9);
        FUN_140362560(&local_d18);
        uVar9 = (**(code **)(*local_d88 + 8))();
        local_db0 = 0;
        local_db8 = (char *)((ulonglong)local_db8._4_4_ << 0x20);
        local_dc0 = (char *)CONCAT62(local_dc0._2_6_,0xfb);
        local_dc8 = local_dc8 & 0xffffffffffff0000;
        iVar14 = FUN_140362620(&local_d18,uVar9,0,0);
        if (iVar14 == 0) {
          local_dc8 = CONCAT44(local_dc8._4_4_,0x3cc);
          log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                             "msg.Create(pUser->GetID(), 0, 0, 0, actionQueryStrCheck, 0)",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgaction.cpp"
                            );
        }
        else {
          (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
        }
        plVar24 = (longlong *)FUN_140008520((int)param_1[0x82]);
        (**(code **)(*plVar24 + 0x120))(plVar24,*(undefined4 *)((longlong)local_d88 + 0x122c));
        plVar24 = (longlong *)FUN_1400e1e60();
        lVar26 = *plVar24;
        uVar9 = (**(code **)(*local_d88 + 8))();
        (**(code **)(lVar26 + 0xb8))(plVar24,uVar9);
        FUN_1403625e0(&local_d18);
      }
    }
    break;
  case 0xfc:
    if (((local_d88 != (longlong *)0x0) && (*(char *)((longlong)local_d88 + 0x51c) != '\0')) &&
       (cVar4 = FUN_14018a9b0(local_d88,*(undefined4 *)(lVar26 + 8)), cVar4 != '\0')) {
      *(undefined2 *)(param_1[0x85] + 0x14) = 0xfe;
      (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,param_1);
      pIVar25 = theInstance();
      lVar26 = local_d88[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_BUY_MAGIC_SKILL_LEVEL_OK");
      (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
    }
    break;
  case 0xfd:
    if (((local_d88 != (longlong *)0x0) && (*(char *)((longlong)local_d88 + 0x51c) != '\0')) &&
       (cVar4 = FUN_14018ab00(local_d88,*(undefined4 *)(lVar26 + 8)), cVar4 != '\0')) {
      *(undefined2 *)(param_1[0x85] + 0x14) = 0xfe;
      (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,param_1);
      pIVar25 = theInstance();
      lVar26 = local_d88[2];
      uVar18 = (*(code *)**(undefined8 **)pIVar25)(pIVar25,"STR_BUY_WEAPON_SKILL_LEVEL_OK");
      (**(code **)(lVar26 + 0x358))(local_d88 + 2,uVar18);
    }
    break;
  case 0xff:
    if (local_d88 != (longlong *)0x0) {
      FUN_140355f80();
    }
    break;
  case 0x100:
    if ((local_d88 != (longlong *)0x0) && (*(char *)((longlong)local_d88 + 0x51c) != '\0')) {
      FUN_1401a4530();
    }
    break;
  case 0x131:
    if ((local_d88 != (longlong *)0x0) &&
       (cVar4 = (**(code **)(local_d88[2] + 0x230))(), plVar24 = local_d88, cVar4 != '\0')) {
      if (local_d88 == (longlong *)0x0) {
        FUN_140097920(&DAT_140975c38);
      }
      else {
        FUN_140097920(&DAT_140975c38);
        FUN_140362c00(&DAT_140975c38,plVar24 + 0x242);
      }
      FUN_140178430(local_d88,1);
    }
    break;
  case 0x132:
    if ((local_d88 != (longlong *)0x0) &&
       (cVar4 = (**(code **)(local_d88[2] + 0x230))(), cVar4 != '\0')) {
      FUN_140097920(&DAT_140975c38);
      FUN_140178430(local_d88,0);
    }
    break;
  case 0x136:
    if (local_d88 != (longlong *)0x0) {
      uVar18 = FUN_140008520((int)param_1[0x82]);
      plVar24 = (longlong *)FUN_140087650(uVar18);
      lVar26 = (**(code **)(*plVar24 + 0x98))(plVar24,*(undefined4 *)(param_1[0x85] + 8));
      if (lVar26 != 0) {
        FUN_14039ed70(&local_d18);
        iVar14 = FUN_14039eef0(&local_d18,lVar26 + 0x10,1);
        if (iVar14 != 0) {
          (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
        }
        FUN_14039edf0(&local_d18);
      }
    }
  }
switchD_1403630a9_caseD_50:
  return;
switchD_140367703_caseD_198:
  if (local_d88 == (longlong *)0x0) {
    return;
  }
  FUN_14039e680(&local_d18);
  uVar9 = (**(code **)(*local_d88 + 8))();
  iVar14 = FUN_14039e700(&local_d18,uVar9,0xffffffff);
  if (iVar14 == 0) {
    FUN_14039e6d0(&local_d18);
    return;
  }
  uVar9 = (**(code **)(local_d88[2] + 0x80))();
  iVar14 = FUN_14039e9a0(&local_d18,1,uVar9);
  if (iVar14 == 0) {
    FUN_14039e6d0(&local_d18);
    return;
  }
  uVar9 = (**(code **)(*local_d88 + 0x88))();
  iVar14 = FUN_14039e9a0(&local_d18,3,uVar9);
  if (iVar14 == 0) {
    FUN_14039e6d0(&local_d18);
    return;
  }
  (**(code **)(local_d88[2] + 0x350))(local_d88 + 2,&local_d18);
  FUN_14039e6d0(&local_d18);
  return;
}

// ==== CMsgAction::helper_1403705d0  @1403705d0  [medium:callgraph-r1]  (orig: FUN_1403705d0)
ulonglong FUN_1403705d0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4,
                       undefined1 param_5,undefined2 param_6,void *param_7,uint param_8)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  FUN_1402b5600();
  if (param_8 < 0x3f0) {
    **(undefined4 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 8) = param_5;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 9) = param_4;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10) = param_6;
    *(short *)(*(longlong *)(param_1 + 0x428) + 0xc) = (short)param_8;
    memcpy((void *)(*(longlong *)(param_1 + 0x428) + 0xe),param_7,(longlong)(int)param_8);
    *(undefined4 *)(param_1 + 8) = 0x9d8;
    uVar1 = CONCAT71((int7)((ulonglong)*(longlong *)(param_1 + 0x428) >> 8),1);
    *(uint *)(param_1 + 0xc) = *(ushort *)(*(longlong *)(param_1 + 0x428) + 0xc) + 0xf;
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = extraout_RAX & 0xffffffffffffff00;
  }
  return uVar1;
}

// ==== CMsgAction::helper_1403715c0  @1403715c0  [medium:callgraph-r1]  (orig: FUN_1403715c0)
void FUN_1403715c0(longlong param_1,undefined4 param_2,char *param_3,int param_4)

{
  longlong *plVar1;
  
  tq::SafeCopy((char *)(param_1 + 0x1f0),param_3,0x10);
  plVar1 = *(longlong **)(param_1 + 0x230);
  *(undefined4 *)(param_1 + 0x30) = param_2;
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"mateid");
    (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
    if (param_4 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgAction::helper_140372ed0  @140372ed0  [medium:callgraph-r1]  (orig: FUN_140372ed0)
undefined4 FUN_140372ed0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x160);
}

// ==== CMsgAction::helper_140372ee0  @140372ee0  [medium:callgraph-r1]  (orig: FUN_140372ee0)
void FUN_140372ee0(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x160) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"business");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
  }
  return;
}

// ==== CMsgAction::helper_140373950  @140373950  [medium:callgraph-r2]  (orig: FUN_140373950)
undefined4 FUN_140373950(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1b0);
}

// ==== CMsgAction::helper_140373e50  @140373e50  [medium:callgraph-r0]  (orig: FUN_140373e50)
undefined2 FUN_140373e50(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x1e2);
}

// ==== CMsgAction::helper_140373e60  @140373e60  [medium:callgraph-r0]  (orig: FUN_140373e60)
void FUN_140373e60(longlong param_1,ushort param_2,char param_3)

{
  longlong *plVar1;
  
  *(ushort *)(param_1 + 0x1e2) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"showtype");
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2 & 0xff);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgAction::helper_140374270  @140374270  [medium:callgraph-r1]  (orig: FUN_140374270)
void FUN_140374270(longlong param_1,undefined2 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined2 *)(param_1 + 0x228) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"shielded_times");
    (**(code **)(*plVar1 + 200))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgAction::helper_14037f430  @14037f430  [medium:callgraph-r1]  (orig: FUN_14037f430)
bool FUN_14037f430(longlong param_1,longlong *param_2)

{
  int *piVar1;
  longlong lVar2;
  int iVar3;
  int *piVar4;
  
  if (param_2 != (longlong *)0x0) {
    iVar3 = (**(code **)(*param_2 + 8))(param_2);
    piVar1 = *(int **)(param_1 + 0x38);
    if (piVar1 < *(int **)(param_1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    piVar4 = *(int **)(param_1 + 0x30);
    if (*(int **)(param_1 + 0x38) < piVar4) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *(longlong *)(param_1 + 0x18);
    for (; (piVar4 != piVar1 && (*piVar4 != iVar3)); piVar4 = piVar4 + 1) {
    }
    piVar1 = *(int **)(param_1 + 0x38);
    if (piVar1 < *(int **)(param_1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0x18))) {
      _invalid_parameter_noinfo();
    }
    return piVar4 != piVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return false;
}

// ==== CMsgAction::helper_14037f880  @14037f880  [medium:callgraph-r1]  (orig: FUN_14037f880)
undefined4 FUN_14037f880(longlong param_1,int param_2)

{
  char cVar1;
  ulonglong *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  uint uVar9;
  ulonglong uVar11;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  ulonglong *local_28;
  longlong local_20;
  ulonglong uVar10;
  
  uVar11 = 0;
  uVar10 = uVar11;
  while( true ) {
    uVar9 = (int)uVar10 + 1;
    uVar10 = (ulonglong)uVar9;
    if (10000 < uVar9) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
    cVar1 = *(char *)((longlong)puVar8 + 0x21);
    puVar4 = *(undefined8 **)(param_1 + 0x80);
    while (cVar1 == '\0') {
      if (*(int *)(puVar8 + 3) < param_2) {
        puVar6 = (undefined8 *)puVar8[2];
        puVar8 = puVar4;
      }
      else {
        puVar6 = (undefined8 *)*puVar8;
      }
      puVar4 = puVar8;
      puVar8 = puVar6;
      cVar1 = *(char *)((longlong)puVar6 + 0x21);
    }
    puVar8 = *(undefined8 **)(param_1 + 0x80);
    local_40 = puVar4;
    local_48 = *(longlong *)(param_1 + 0x50);
    if (*(longlong *)(param_1 + 0x50) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar4 == puVar8) || (param_2 < *(int *)(puVar4 + 3))) {
      plVar7 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x80);
      local_38 = *(longlong *)(param_1 + 0x50);
    }
    else {
      plVar7 = &local_48;
    }
    puVar2 = (ulonglong *)*plVar7;
    lVar3 = *(longlong *)(param_1 + 0x80);
    local_28 = puVar2;
    local_20 = plVar7[1];
    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != *(ulonglong **)(param_1 + 0x50))) {
      _invalid_parameter_noinfo();
    }
    lVar5 = local_20;
    if (local_20 != lVar3) break;
    if (*(int *)(param_1 + 0x98) <= param_2) {
      return 0;
    }
    param_2 = param_2 + 1;
  }
  if (puVar2 == (ulonglong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    uVar11 = *puVar2;
  }
  if (lVar5 == *(longlong *)(uVar11 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return *(undefined4 *)(lVar5 + 0x1c);
}

// ==== CMsgAction::helper_14037fcf0  @14037fcf0  [medium:callgraph-r0]  (orig: FUN_14037fcf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14037fcf0(longlong param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  ulong uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  char *_Format;
  longlong *plVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined1 auStack_bc8 [32];
  undefined8 local_ba8;
  undefined8 local_ba0;
  int local_b98 [2];
  ulonglong local_b90;
  undefined4 local_b88;
  undefined8 local_b80;
  undefined8 local_b78;
  undefined1 local_b68 [1072];
  char local_738;
  undefined1 local_737 [254];
  undefined1 local_639;
  char local_638;
  undefined1 local_637 [510];
  undefined1 local_439;
  char local_438;
  undefined1 local_437 [510];
  undefined1 local_239;
  char local_238;
  undefined1 local_237 [510];
  undefined1 local_39;
  ulonglong local_38;
  
  local_b78 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_bc8;
  if (param_2 == (longlong *)0x0) {
    local_ba8 = CONCAT44(local_ba8._4_4_,0xbd);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(char *)(param_1 + 0x94) == '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(&DAT_14075c6b8);
    return 0;
  }
  cVar1 = FUN_14037f430();
  if (cVar1 != '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(&DAT_14075c680);
    return 0;
  }
  iVar2 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
  if (iVar2 == *(int *)(param_1 + 0xa8)) {
    uVar3 = tq::TimeGet(0);
    FUN_1401663a0(param_2,uVar3 - *(int *)(param_1 + 0xac));
    local_b98[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_140037fe0(param_1 + 0x18,local_b98);
    uVar12 = *(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) >> 2;
    uVar4 = FUN_14037f880(param_1,uVar12 & 0xffffffff);
    FUN_140162b60(param_2);
    local_738 = '\0';
    memset(local_737,0,0xff);
    (**(code **)(*param_2 + 8))(param_2);
    _snprintf(&local_738,0x100,"</F>RideArriveTerminal</N>%lu");
    local_639 = 0;
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    uVar7 = FUN_140087e30();
    local_ba0 = 0;
    local_ba8 = (ulonglong)local_ba8._4_4_ << 0x20;
    cVar1 = FUN_140286530(uVar7,&local_738,uVar5,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                ("Lua return fault, Call From:CCompete::ArriveTerminal, lua function:%s.");
    }
    FUN_1403803a0(local_b68);
    uVar5 = FUN_140166390(param_2);
    uVar7 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
    local_ba8._0_4_ = uVar4;
    FUN_1403804f0(local_b68,uVar7,uVar5,uVar12 & 0xffffffff);
    plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
    (**(code **)(*plVar8 + 0x68))(plVar8,local_b68,0xffffffff);
    uVar5 = FUN_140166390(param_2);
    local_ba0 = CONCAT44(local_ba0._4_4_,uVar4);
    local_ba8 = CONCAT44(local_ba8._4_4_,1);
    FUN_140380450(local_b68,uVar12 & 0xffffffff,uVar5,0);
    (**(code **)(param_2[2] + 0x350))(param_2 + 2);
    local_238 = '\0';
    memset(local_237,0,0x1ff);
    pIVar9 = theInstance();
    _Format = (char *)(*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_COMPETE_RANK");
    _snprintf(&local_238,0x200,_Format);
    local_39 = 0;
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_238);
    local_ba8 = local_ba8 & 0xffffffffffffff00;
    iVar2 = FUN_1401c55b0(param_2,(int)param_2[0x1e1],*(undefined2 *)((longlong)param_2 + 0xf0c),
                          *(undefined2 *)((longlong)param_2 + 0xf0e));
    if (iVar2 != 0) {
      local_b90 = 0;
      local_b88 = 0;
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
      uVar7 = FUN_1400d6610(uVar7);
      FUN_140006c50(uVar7,&local_b90);
      local_ba8 = local_ba8 & 0xffffffffffffff00;
      FUN_1401c55b0(param_2,local_b90 & 0xffffffff,local_b90 >> 0x20,local_b88);
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
    uVar7 = FUN_140087c40(uVar7);
    FUN_140261810(uVar7,param_2,0xf);
    if ((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) & 0xfffffffffffffffcU) == 4)
    {
      plVar8 = (longlong *)CurrentInstanceGet();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0x11);
      if (plVar8 == (longlong *)0x0) {
        local_ba8 = CONCAT44(local_ba8._4_4_,0xff);
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_1403803f0(local_b68);
        return 0;
      }
      iVar2 = (**(code **)(*plVar8 + 0x18))(plVar8,*(int *)(param_1 + 0xa8) + 40000000,0);
      if (iVar2 == 0) {
        iVar2 = *(int *)(param_1 + 0x48) * 1000;
      }
      uVar4 = (**(code **)(*plVar8 + 0x28))(plVar8,*(int *)(param_1 + 0xa8) + 40000000,0);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
      plVar10 = (longlong *)FUN_140087650(uVar7);
      local_b90 = (**(code **)(*plVar10 + 0x98))(plVar10,uVar4);
      iVar6 = FUN_140166390(param_2);
      local_b98[0] = iVar6;
      local_b80 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      if (iVar6 < iVar2) {
        lVar11 = *plVar8;
        uVar12 = (ulonglong)local_b98[0];
        iVar2 = *(int *)(param_1 + 0xa8);
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        local_ba8 = uVar12;
        (**(code **)(lVar11 + 0x70))(plVar8,uVar5,iVar2 + 40000000,local_b80);
        uVar12 = local_b90;
        if (local_b90 == 0) {
          local_438 = '\0';
          memset(local_437,0,0x1ff);
          _snprintf(&local_438,0x200,"SELECT title FROM cq_user WHERE id=%ld LIMIT 1");
          local_239 = 0;
          FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
          plVar8 = (longlong *)InstanceGet();
          plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,&local_438,2);
          if ((plVar8 == (longlong *)0x0) ||
             (lVar11 = (**(code **)(*plVar8 + 0x40))(plVar8), lVar11 == 0)) {
            if (plVar8 != (longlong *)0x0) {
              (**(code **)*plVar8)(plVar8);
            }
            FUN_1403803f0(local_b68);
            return 0;
          }
          plVar10 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0);
          (**(code **)(*plVar10 + 0x40))(plVar10);
          (**(code **)*plVar8)(plVar8);
          local_638 = '\0';
          memset(local_637,0,0x1ff);
          local_ba8 = CONCAT44(local_ba8._4_4_,uVar4);
          _snprintf(&local_638,0x200,
                    "UPDATE cq_user SET title=%ld, title_select=0 WHERE id=%ld LIMIT 1");
          local_439 = 0;
          FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
          plVar8 = (longlong *)InstanceGet();
          (**(code **)(*plVar8 + 0x30))(plVar8,&local_638,0,1);
        }
        else {
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
          uVar7 = FUN_140087730(uVar7);
          local_ba0 = 0;
          local_ba8 = local_ba8 & 0xffffffff00000000;
          FUN_140145f60(uVar7,0x55d4a7e,uVar12,0);
        }
      }
    }
    FUN_1403803f0(local_b68);
    return 1;
  }
  (**(code **)(param_2[2] + 0x168))(param_2 + 2);
  (**(code **)(*param_2 + 8))(param_2);
  log_InlineLogERROR(&DAT_14075c648);
  return 0;
}

// ==== CMsgAction::helper_140380450  @140380450  [medium:callgraph-r1]  (orig: FUN_140380450)
void FUN_140380450(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  int param_5,undefined4 param_6)

{
  if (param_5 == 0) {
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
    **(undefined2 **)(param_1 + 0x428) = 0;
    *(undefined4 *)(param_1 + 8) = 0x42f;
    *(undefined4 *)(param_1 + 0xc) = 0x20;
    return;
  }
  if (param_5 == 1) {
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_6;
    **(undefined2 **)(param_1 + 0x428) = 1;
    *(undefined4 *)(param_1 + 8) = 0x42f;
    *(undefined4 *)(param_1 + 0xc) = 0x20;
    return;
  }
  *(undefined4 *)(param_1 + 8) = 0x42f;
  *(undefined4 *)(param_1 + 0xc) = 0x20;
  return;
}

// ==== CMsgAction::helper_1403804f0  @1403804f0  [medium:callgraph-r1]  (orig: FUN_1403804f0)
ulonglong FUN_1403804f0(longlong param_1,char *param_2,undefined4 param_3,int param_4,
                       undefined4 param_5)

{
  char cVar1;
  undefined2 *puVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  char *pcVar4;
  
  if ((param_2 == (char *)0x0) && (param_4 != 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar3 = 0xffffffffffffffff;
  *(int *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  pcVar4 = param_2;
  do {
    if (uVar3 == 0) break;
    uVar3 = uVar3 - 1;
    cVar1 = *pcVar4;
    pcVar4 = pcVar4 + 1;
  } while (cVar1 != '\0');
  memcpy((void *)(*(longlong *)(param_1 + 0x428) + 8),param_2,~uVar3 - 1);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_5;
  puVar2 = *(undefined2 **)(param_1 + 0x428);
  *puVar2 = 2;
  *(undefined4 *)(param_1 + 8) = 0x42f;
  *(undefined4 *)(param_1 + 0xc) = 0x20;
  return CONCAT71((int7)((ulonglong)puVar2 >> 8),1);
}

// ==== CMsgAction::helper_140382a40  @140382a40  [medium:callgraph-r1]  (orig: FUN_140382a40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140382a40(longlong param_1,char *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  ulonglong uVar4;
  
  if (param_2 != (char *)0x0) {
    uVar1 = *(undefined4 *)(param_1 + 0xf38);
    FUN_1403827a0(param_1,uVar1,0,1);
    FUN_1403827a0(param_1,uVar1,2);
    uVar2 = FUN_1403827a0(param_1,uVar1,4);
    uVar4 = (ulonglong)uVar2;
    iVar3 = FUN_1403827a0(param_1,uVar1,6);
    sprintf(param_2,"%04d:%02d-%02d:%02d",iVar3 + 2000,uVar4 & 0xffffffff);
  }
  return;
}

// ==== CMsgAction::helper_1403b41b0  @1403b41b0  [medium:callgraph-r0]  (orig: FUN_1403b41b0)
undefined4 FUN_1403b41b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMsgAction::helper_1403b4250  @1403b4250  [medium:callgraph-r0]  (orig: FUN_1403b4250)
void FUN_1403b4250(longlong param_1)

{
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined1 *)(param_1 + 0x18) = 0;
  return;
}

// ==== CMsgAction::helper_1403b76a0  @1403b76a0  [medium:callgraph-r0]  (orig: FUN_1403b76a0)
undefined8 FUN_1403b76a0(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x42e;
  *(undefined4 *)(param_1 + 0xc) = 0x12;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 2) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgAction::helper_1403cf200  @1403cf200  [medium:callgraph-r1]  (orig: FUN_1403cf200)
ulonglong FUN_1403cf200(uint param_1,undefined4 *param_2,undefined1 *param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *extraout_RAX;
  longlong *plVar4;
  ulonglong uVar5;
  longlong **pplVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *local_48;
  longlong *local_40;
  longlong *local_38;
  longlong *local_30;
  longlong *local_28;
  longlong *local_20;
  
  plVar4 = DAT_1409762e0;
  cVar1 = *(char *)(DAT_1409762e0[1] + 0x25);
  plVar3 = (longlong *)DAT_1409762e0[1];
  plVar2 = DAT_1409762e0;
  while (plVar7 = plVar3, cVar1 == '\0') {
    if (*(uint *)(plVar7 + 3) < param_1) {
      plVar3 = (longlong *)plVar7[2];
      plVar7 = plVar2;
    }
    else {
      plVar3 = (longlong *)*plVar7;
    }
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
    plVar2 = plVar7;
  }
  local_40 = plVar2;
  local_48 = DAT_1409762b0;
  if (DAT_1409762b0 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar3 = DAT_1409762e0;
  if ((plVar2 == plVar4) || (param_1 < *(uint *)(plVar2 + 3))) {
    local_30 = DAT_1409762e0;
    local_38 = DAT_1409762b0;
    pplVar6 = &local_38;
  }
  else {
    pplVar6 = &local_48;
  }
  plVar2 = *pplVar6;
  local_28 = plVar2;
  plVar4 = pplVar6[1];
  local_20 = plVar4;
  if ((plVar2 == (longlong *)0x0) || (plVar2 != DAT_1409762b0)) {
    _invalid_parameter_noinfo();
    plVar4 = extraout_RAX;
  }
  plVar7 = local_20;
  if (local_20 == plVar3) {
    uVar5 = (ulonglong)plVar4 & 0xffffffffffffff00;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_2 = *(undefined4 *)((longlong)plVar7 + 0x1c);
    *param_3 = (char)plVar7[4];
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CMsgAction::helper_1403e50a0  @1403e50a0  [medium:callgraph-r1]  (orig: FUN_1403e50a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e50a0(void)

{
  undefined1 auStack_38 [56];
  
  return CONCAT71((uint7)((ulonglong)DAT_1409707c0 >> 8) ^ (uint7)((ulonglong)auStack_38 >> 8),1);
}

// ==== CMsgAction::helper_1403ecf40  @1403ecf40  [medium:callgraph-r1]  (orig: FUN_1403ecf40)
undefined8 FUN_1403ecf40(longlong param_1,undefined1 param_2,undefined2 param_3,undefined2 param_4)

{
  longlong lVar1;
  
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  *(undefined4 *)(param_1 + 8) = 0x45a;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgAction::helper_1403eede0  @1403eede0  [medium:callgraph-r0]  (orig: FUN_1403eede0)
undefined8 FUN_1403eede0(longlong param_1,undefined2 param_2,int param_3)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  *(undefined4 *)(param_1 + 8) = 0x414;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar1;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  if (param_3 != 0) {
    *(int *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = 1;
  }
  return 1;
}

// ==== CMsgAction::helper_1403fd9d0  @1403fd9d0  [medium:callgraph-r3]  (orig: FUN_1403fd9d0)
undefined8 FUN_1403fd9d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),2)
    ;
    cVar1 = (**(code **)(*plVar2 + 0x20))(plVar2);
    if (cVar1 != '\0') {
      if (cVar1 == '\x01') {
        return 1;
      }
      if (cVar1 != '\x02') {
        log_InlineLogERROR("CJiangHuPlayer::GetJiangHuStatus Error, user:%u, status:%u ,at %s, %d");
        return 0;
      }
      return 2;
    }
  }
  return 0;
}

// ==== CMsgAction::helper_140425950  @140425950  [medium:callgraph-r3]  (orig: FUN_140425950)
undefined8 FUN_140425950(longlong param_1,int param_2,int param_3,undefined8 *param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  int iVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *local_res8;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined1 local_38 [16];
  
  plVar2 = *(longlong **)(param_1 + 8);
  if (2 < param_2) {
    param_2 = 2;
  }
  param_3 = param_2 * 1000 + param_3;
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar9 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x38);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar3) {
            return 1;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar2;
          }
          if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar3 = (longlong *)plVar9[4];
          local_res8 = plVar3;
          if (plVar3 != (longlong *)0x0) {
            plVar7 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
            iVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
            plVar7 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,2);
            iVar6 = (**(code **)(*plVar7 + 0x48))();
            if ((iVar5 <= param_3) && (param_3 < iVar6)) {
              plVar7 = (longlong *)param_4[3];
              if (plVar7 == (longlong *)0x0) {
                uVar8 = 0;
              }
              else {
                uVar8 = param_4[5] - (longlong)plVar7 >> 3;
              }
              plVar4 = (longlong *)param_4[4];
              if ((ulonglong)((longlong)plVar4 - (longlong)plVar7 >> 3) < uVar8) {
                *plVar4 = (longlong)plVar3;
                param_4[4] = plVar4 + 1;
              }
              else {
                if (plVar4 < plVar7) {
                  _invalid_parameter_noinfo();
                }
                local_58 = (undefined4)*param_4;
                uStack_54 = (undefined4)((ulonglong)*param_4 >> 0x20);
                uStack_50 = SUB84(plVar4,0);
                uStack_4c = (undefined4)((ulonglong)plVar4 >> 0x20);
                local_48 = local_58;
                uStack_44 = uStack_54;
                uStack_40 = uStack_50;
                uStack_3c = uStack_4c;
                FUN_1400189b0(param_4,local_38,&local_48,&local_res8);
              }
            }
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar9;
        }
        plVar3 = (longlong *)plVar9[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar9 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar9 + 0x29);
          plVar3 = plVar9;
          plVar9 = (longlong *)*plVar9;
        }
      }
      plVar3 = (longlong *)plVar9[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar7 = plVar3;
      plVar3 = plVar7;
      if (plVar9 != (longlong *)plVar7[2]) break;
      plVar3 = (longlong *)plVar7[1];
      plVar9 = plVar7;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CMsgAction::helper_140428bd0  @140428bd0  [medium:callgraph-r2]  (orig: FUN_140428bd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140428bd0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  undefined1 uVar5;
  undefined1 uVar6;
  int iVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != (longlong *)0x0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
    iVar7 = (**(code **)(*param_2 + 8))(param_2);
    if (iVar7 == *(int *)(param_1 + 0x50)) {
      FUN_14042bb20(local_468);
      cVar4 = FUN_14042bbe0(local_468,3);
      if (cVar4 == '\0') {
        local_488 = 0x163;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_14042bb70(local_468);
      }
      else {
        plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x38);
        plVar1 = *(longlong **)(param_1 + 8);
        while( true ) {
          plVar2 = *(longlong **)(param_1 + 0x38);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar2) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar1;
          }
          if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar10 = plVar9[4];
          if (lVar10 != 0) {
            uVar5 = FUN_1404de150(lVar10);
            uVar6 = FUN_1404de0f0(lVar10);
            uVar8 = FUN_1404de090(lVar10);
            cVar4 = FUN_14042bc40(local_468,uVar8,uVar6,uVar5);
            if (cVar4 == '\0') {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
              FUN_14042bcb0(local_468);
              uVar5 = FUN_1404de150(lVar10);
              uVar6 = FUN_1404de0f0(lVar10);
              uVar8 = FUN_1404de090(lVar10);
              FUN_14042bc40(local_468,uVar8,uVar6,uVar5);
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            plVar2 = (longlong *)plVar9[2];
            if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
              cVar4 = *(char *)(*plVar2 + 0x29);
              plVar9 = plVar2;
              plVar2 = (longlong *)*plVar2;
              while (cVar4 == '\0') {
                cVar4 = *(char *)(*plVar2 + 0x29);
                plVar9 = plVar2;
                plVar2 = (longlong *)*plVar2;
              }
            }
            else {
              cVar4 = *(char *)(plVar9[1] + 0x29);
              plVar3 = (longlong *)plVar9[1];
              plVar2 = plVar9;
              while ((plVar9 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar9[2]))) {
                cVar4 = *(char *)(plVar9[1] + 0x29);
                plVar3 = (longlong *)plVar9[1];
                plVar2 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        cVar4 = FUN_14042bcd0(local_468);
        if (cVar4 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
        }
        FUN_14042bb70(local_468);
      }
    }
  }
  return;
}

// ==== CMsgAction::helper_14042aae0  @14042aae0  [medium:callgraph-r2]  (orig: FUN_14042aae0)
undefined8 FUN_14042aae0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *local_50 [3];
  longlong *local_38;
  longlong *local_30;
  undefined8 local_28;
  
  if ((param_2 == (longlong *)0x0) ||
     (iVar2 = (**(code **)(*param_2 + 8))(param_2), iVar2 != *(int *)(param_1 + 0x50))) {
    uVar5 = 0;
  }
  else if (*(longlong *)(param_1 + 0x48) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    local_50[0] = operator_new(8);
    if (local_50[0] == (longlong *)0x0) {
      local_50[0] = (longlong *)0x0;
    }
    else {
      *local_50[0] = (longlong)local_50;
    }
    local_38 = (longlong *)0x0;
    local_30 = (longlong *)0x0;
    local_28 = 0;
    uVar3 = (**(code **)(param_2[2] + 0x70))();
    uVar4 = (**(code **)(*param_2 + 0x108))(param_2);
    FUN_140425950(*(undefined8 *)(param_1 + 0x48),uVar4,uVar3,local_50);
    plVar8 = local_38;
    plVar1 = local_50[0];
    if (local_30 < local_38) {
      _invalid_parameter_noinfo();
      plVar1 = local_50[0];
    }
    while( true ) {
      plVar7 = local_30;
      if (local_30 < local_38) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_50[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar7) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)*plVar8;
      if ((plVar7 != (longlong *)0x0) && (lVar6 = FUN_14042a550(param_1,plVar7,0,0), lVar6 == 0)) {
        plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0);
        (**(code **)(*plVar7 + 0x40))(plVar7);
        log_InlineLogERROR(
                          "CActivityPlayer::UpdateDayTimeActivityTask AddActivityTask user_id[%u], activity_id[%u] failed."
                          );
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(longlong **)(lVar6 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar8 + 1;
    }
    if (local_38 != (longlong *)0x0) {
      operator_delete(local_38);
    }
    local_38 = (longlong *)0x0;
    local_30 = (longlong *)0x0;
    local_28 = 0;
    operator_delete(local_50[0]);
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CMsgAction::helper_14042bcb0  @14042bcb0  [medium:callgraph-r3]  (orig: FUN_14042bcb0)
void FUN_14042bcb0(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x428) != 0) {
    *(undefined4 *)(param_1 + 0xc) = 2;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 0;
  }
  return;
}

// ==== CMsgAction::helper_14042bcd0  @14042bcd0  [medium:callgraph-r3]  (orig: FUN_14042bcd0)
undefined8 FUN_14042bcd0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x428);
  if (lVar1 == 0) {
    return 0;
  }
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),*(undefined1 *)(lVar1 + 1));
}

// ==== CMsgAction::helper_140433490  @140433490  [medium:callgraph-r0]  (orig: FUN_140433490)
undefined8
FUN_140433490(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5c;
  *(undefined4 *)(param_1 + 0xc) = 0x28;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_6;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_7;
  return CONCAT71((uint7)(uint3)((uint)param_7 >> 8),1);
}

// ==== CMsgAction::helper_1404606e0  @1404606e0  [medium:callgraph-r0]  (orig: FUN_1404606e0)
undefined8 FUN_1404606e0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined1 param_4)

{
  *(undefined4 *)(param_1 + 8) = 0x9c6c;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = param_4;
  return 1;
}

// ==== CMsgAction::helper_14048c310  @14048c310  [medium:callgraph-r2]  (orig: FUN_14048c310)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_14048c310(longlong param_1,undefined8 param_2,int *param_3,undefined4 *param_4,
                       int *param_5)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  ulonglong in_RAX;
  longlong lVar4;
  ulonglong uVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong extraout_RAX;
  double dVar8;
  
  if (*(longlong *)(param_1 + 0x1c8) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  lVar4 = FUN_14048b5f0();
  if (lVar4 == 0) {
    return 0;
  }
  uVar5 = FUN_140418c50(lVar4,0x76);
  iVar1 = (int)uVar5;
  if ((iVar1 == -1) || (iVar1 == 0)) {
    return uVar5 & 0xffffffffffffff00;
  }
  iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x70))
                    (*(longlong *)(param_1 + 0x1c8) + 0x10);
  uVar5 = FUN_140418c50(lVar4,0x78);
  if ((int)uVar5 <= iVar2) {
    uVar3 = FUN_140418c50(lVar4,3);
    *param_4 = uVar3;
    lVar6 = FUN_140418fd0(lVar4,0x75);
    if (lVar6 != 0) {
      uVar7 = FUN_140480a00(*(undefined1 *)(*(longlong *)(param_1 + 0x1c8) + 0xeee));
      uVar5 = FUN_140418fd0(lVar4,0x75);
      if ((uVar7 & uVar5) == 0) goto LAB_14048c49b;
    }
    iVar2 = FUN_140418c50(lVar4,4);
    *param_5 = iVar2;
    uVar5 = FUN_140418c50(lVar4,0x94);
    dVar8 = (((double)(iVar1 - *param_5) / (double)iVar1) * (double)(int)uVar5 * _DAT_1407196f0) /
            _DAT_1407196e8;
    if (0.0 < dVar8) {
      dVar8 = ceil(dVar8);
      iVar1 = (int)(longlong)dVar8;
      *param_3 = iVar1;
      if (iVar1 != 0) {
        return CONCAT71((int7)((ulonglong)(longlong)dVar8 >> 8),1);
      }
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = extraout_RAX;
    }
  }
LAB_14048c49b:
  return uVar5 & 0xffffffffffffff00;
}

// ==== CMsgAction::helper_14048f3c0  @14048f3c0  [medium:callgraph-r2]  (orig: FUN_14048f3c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14048f3c0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined1 uVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  longlong lVar14;
  longlong *plVar15;
  longlong lVar16;
  longlong *plVar17;
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  undefined1 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  longlong *local_4c8;
  longlong *plStack_4c0;
  longlong local_4b8;
  longlong *local_4a8;
  longlong *plStack_4a0;
  undefined8 local_498;
  undefined1 local_490 [24];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  plVar15 = (longlong *)(param_1 + 8);
  plVar17 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar1 = (longlong *)*plVar15;
  local_4c8 = plVar1;
  plStack_4c0 = plVar17;
  local_4b8 = param_1;
LAB_14048f420:
  do {
    plVar2 = (longlong *)plVar15[6];
    if (((longlong *)*plVar15 == (longlong *)0x0) || ((longlong *)*plVar15 != plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar17) {
      return 1;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar16 = 0;
    }
    else {
      lVar16 = *plVar1;
    }
    if (plVar17 == *(longlong **)(lVar16 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar16 = plVar17[4];
    if ((lVar16 == 0) || (iVar8 = FUN_140418c50(lVar16,2), iVar8 == 0)) {
      plVar2 = *(longlong **)(param_1 + 0x1c8);
      (**(code **)(*plVar2 + 8))();
      (**(code **)(plVar2[2] + 0x18))(plVar2 + 2);
      log_InlineLogWARNING(&DAT_140788d48);
    }
    else {
      iVar8 = FUN_140418c50(lVar16,2);
      if (0xff < iVar8 - 10000U) {
        lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
        lVar14 = *(longlong *)(lVar14 + 0x100);
        if (lVar14 == 0) {
          local_4e8 = 0x144;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        uVar9 = FUN_140418c50(lVar16,3);
        uVar10 = FUN_140418c50(lVar16,2);
        lVar14 = FUN_1402f0fe0(lVar14,uVar10,uVar9);
        if (lVar14 == 0) {
          plVar2 = *(longlong **)(param_1 + 0x1c8);
          (**(code **)(*plVar2 + 8))();
          (**(code **)(plVar2[2] + 0x18))(plVar2 + 2);
          log_InlineLogWARNING(&DAT_140788d68);
          plVar5 = plStack_4c0;
          plVar2 = local_4c8;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar17 + 0x29) == '\0') {
            plVar3 = (longlong *)plVar17[2];
            if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
              cVar7 = *(char *)(*plVar3 + 0x29);
              plVar17 = plVar3;
              plVar3 = (longlong *)*plVar3;
              while (plStack_4c0 = plVar17, cVar7 == '\0') {
                cVar7 = *(char *)(*plVar3 + 0x29);
                plVar17 = plVar3;
                plVar3 = (longlong *)*plVar3;
              }
            }
            else {
              cVar7 = *(char *)(plVar17[1] + 0x29);
              plVar4 = (longlong *)plVar17[1];
              plVar3 = plVar17;
              while ((plVar17 = plVar4, plStack_4c0 = plVar17, cVar7 == '\0' &&
                     (plVar3 == (longlong *)plVar17[2]))) {
                cVar7 = *(char *)(plVar17[1] + 0x29);
                plVar4 = (longlong *)plVar17[1];
                plVar3 = plVar17;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          local_4a8 = plVar2;
          plStack_4a0 = plVar5;
          FUN_14048d970(plVar15,local_490,&local_4a8);
          goto LAB_14048f420;
        }
        FUN_140456f30(local_478);
        uVar9 = FUN_140418e40(lVar16,10);
        uVar10 = FUN_140418e40(lVar16,8);
        uVar6 = FUN_140418c50(lVar16,7);
        uVar11 = FUN_140418c50(lVar16,4);
        uVar12 = FUN_140418c50(lVar16,3);
        uVar13 = FUN_140418c50(lVar16,2);
        local_4e8 = uVar11;
        local_4e0 = uVar6;
        local_4d8 = uVar10;
        local_4d0 = uVar9;
        cVar7 = FUN_140456fe0(local_478,0,uVar13,uVar12);
        param_1 = local_4b8;
        if (cVar7 == '\0') {
          local_4e8 = 0x153;
          log_InlineLogERROR(&DAT_1406d9c10);
          param_1 = local_4b8;
        }
        else {
          plVar15 = (longlong *)(*(longlong *)(local_4b8 + 0x1c8) + 0x10);
          (**(code **)(*plVar15 + 0x350))(plVar15,local_478);
        }
        FUN_140456f80(local_478);
        plVar15 = (longlong *)(param_1 + 8);
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar17 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar17[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar7 = *(char *)(*plVar2 + 0x29);
        plVar17 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (plStack_4c0 = plVar17, cVar7 == '\0') {
          cVar7 = *(char *)(*plVar2 + 0x29);
          plVar17 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar7 = *(char *)(plVar17[1] + 0x29);
        plVar5 = (longlong *)plVar17[1];
        plVar2 = plVar17;
        while ((plVar17 = plVar5, plStack_4c0 = plVar17, cVar7 == '\0' &&
               (plVar2 == (longlong *)plVar17[2]))) {
          cVar7 = *(char *)(plVar17[1] + 0x29);
          plVar5 = (longlong *)plVar17[1];
          plVar2 = plVar17;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

