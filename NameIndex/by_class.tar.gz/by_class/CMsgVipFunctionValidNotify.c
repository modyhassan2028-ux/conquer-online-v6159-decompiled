// ==== CMsgVipFunctionValidNotify::ctor_or_dtor  @14044e410  [high:vtable-assign]  (orig: FUN_14044e410)
undefined8 * FUN_14044e410(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgVipFunctionValidNotify::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgVipFunctionValidNotify::ctor_or_dtor  @14044e460  [high:vtable-assign]  (orig: FUN_14044e460)
void FUN_14044e460(undefined8 *param_1)

{
  *param_1 = CMsgVipFunctionValidNotify::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgVipFunctionValidNotify::vfunc_1  @14044e490  [high:rtti-vtable]  (orig: FUN_14044e490)
ulonglong FUN_14044e490(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x469);
}

// ==== CMsgVipFunctionValidNotify::vfunc_3  @14044e500  [high:rtti-vtable]  (orig: FUN_14044e500)
void FUN_14044e500(void)

{
  return;
}

// ==== CMsgVipFunctionValidNotify::ctor_or_dtor  @14044e510  [high:vtable-assign]  (orig: FUN_14044e510)
undefined8 * FUN_14044e510(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgVipFunctionValidNotify::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

