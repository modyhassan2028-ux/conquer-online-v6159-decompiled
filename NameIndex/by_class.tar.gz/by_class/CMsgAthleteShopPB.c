// ==== CMsgAthleteShopPB::helper_140576340  @140576340  [medium:callgraph-r0]  (orig: FUN_140576340)
void FUN_140576340(void)

{
  if (DAT_140977428 != (undefined8 *)0x0) {
    (**(code **)*DAT_140977428)(DAT_140977428,1);
  }
  return;
}

// ==== CMsgAthleteShopPB::vfunc_3  @1405763a0  [high:rtti-vtable]  (orig: FUN_1405763a0)
void FUN_1405763a0(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x38) = 0;
  *(undefined4 *)(param_1 + 0x30) = 0;
                    /* WARNING: Could not recover jumptable at 0x0001405763b0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8));
  return;
}

// ==== CMsgAthleteShopPB::vfunc_9  @1405763c0  [high:rtti-vtable]  (orig: FUN_1405763c0)
void FUN_1405763c0(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
    FUN_1405c8ee0(1,*(undefined4 *)(param_1 + 0x38),param_2);
  }
  if (*(ulonglong *)(param_1 + 0x28) < 0x10) {
    lVar1 = param_1 + 0x10;
  }
  else {
    lVar1 = *(longlong *)(param_1 + 0x10);
  }
  FUN_14055a240(param_2,lVar1,*(ulonglong *)(param_1 + 0x20) & 0xffffffff);
  return;
}

// ==== CMsgAthleteShopPB::vfunc_8  @140576410  [high:rtti-vtable]  (orig: FUN_140576410)
void FUN_140576410(longlong param_1)

{
  int iVar1;
  
  iVar1 = 0;
  if ((*(char *)(param_1 + 0x30) != '\0') && (iVar1 = 0, (*(byte *)(param_1 + 0x30) & 1) != 0)) {
    if (*(uint *)(param_1 + 0x38) < 0x80) {
      *(int *)(param_1 + 0x34) = *(int *)(param_1 + 0x20) + 2;
      return;
    }
    iVar1 = FUN_14055a8a0();
    iVar1 = iVar1 + 1;
  }
  *(int *)(param_1 + 0x34) = iVar1 + *(int *)(param_1 + 0x20);
  return;
}

// ==== CMsgAthleteShopPB::helper_140576460  @140576460  [medium:callgraph-r0]  (orig: FUN_140576460)
void FUN_140576460(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 local_res8 [8];
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8[0] = 0;
    uVar2 = FUN_140556890(local_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgathleteshop.pb.cc",0xd2,
                          0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(local_res8,uVar2);
    FUN_140556900(local_48);
  }
  if ((*(char *)(param_2 + 0x30) != '\0') && ((*(byte *)(param_2 + 0x30) & 1) != 0)) {
    uVar1 = *(undefined4 *)(param_2 + 0x38);
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
    *(undefined4 *)(param_1 + 0x38) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x000140576518. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CMsgAthleteShopPB::vfunc_4  @140576560  [high:rtti-vtable]  (orig: FUN_140576560)
undefined1 FUN_140576560(void)

{
  return 1;
}

// ==== CMsgAthleteShopPB::vfunc_1  @140576570  [high:rtti-vtable]  (orig: FUN_140576570)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140576570(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2,"CMsgAthleteShopPB");
  return param_2;
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @1405765d0  [high:vtable-assign]  (orig: FUN_1405765d0)
undefined8 * FUN_1405765d0(undefined8 *param_1)

{
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgAthleteShopPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  return param_1;
}

// ==== CMsgAthleteShopPB::vfunc_11  @140576620  [high:rtti-vtable]  (orig: FUN_140576620)
undefined4 FUN_140576620(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @140576630  [high:vtable-assign]  (orig: FUN_140576630)
undefined8 *
FUN_140576630(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgAthleteShopPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  FUN_140576460(param_1,param_2,param_3,param_4,uVar1);
  return param_1;
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @1405766a0  [high:vtable-assign]  (orig: FUN_1405766a0)
void FUN_1405766a0(undefined8 *param_1)

{
  *param_1 = CMsgAthleteShopPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  return;
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @1405766e0  [high:vtable-assign]  (orig: FUN_1405766e0)
undefined8 * FUN_1405766e0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x40);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = google::protobuf::MessageLite::vftable;
    *puVar1 = CMsgAthleteShopPB::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 1));
    *(undefined4 *)((longlong)puVar1 + 0x34) = 0;
    *(undefined4 *)(puVar1 + 7) = 0;
    *(undefined4 *)(puVar1 + 6) = 0;
  }
  return puVar1;
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @1405767e0  [high:vtable-assign]  (orig: FUN_1405767e0)
void FUN_1405767e0(void)

{
  undefined8 *puVar1;
  undefined8 in_R9;
  
  if (DAT_140977431 == '\0') {
    DAT_140977431 = '\x01';
    FUN_140555f20(0x1e9bf1,0x1e9bf0,
                  "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgathleteshop.pb.cc",in_R9,
                  0xfffffffffffffffe);
    puVar1 = operator_new(0x40);
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = google::protobuf::MessageLite::vftable;
      *puVar1 = CMsgAthleteShopPB::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 1));
      *(undefined4 *)((longlong)puVar1 + 0x34) = 0;
      *(undefined4 *)(puVar1 + 7) = 0;
      *(undefined4 *)(puVar1 + 6) = 0;
    }
    DAT_140977428 = puVar1;
    FUN_140556df0(FUN_140576340);
  }
  return;
}

// ==== CMsgAthleteShopPB::ctor_or_dtor  @1405768a0  [high:vtable-assign]  (orig: FUN_1405768a0)
undefined8 * FUN_1405768a0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAthleteShopPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAthleteShopPB::vfunc_7  @140576930  [high:rtti-vtable]  (orig: FUN_140576930)
undefined8 FUN_140576930(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  byte bVar1;
  byte *pbVar2;
  char cVar3;
  uint uVar4;
  ulonglong uVar5;
  undefined1 local_40 [16];
  undefined1 local_30 [40];
  
  FUN_14055c020(local_40,param_1 + 8,param_3,param_4,0xfffffffffffffffe);
  FUN_14055a0b0(local_30,local_40);
  do {
    while ((pbVar2 = *(byte **)(param_2 + 8), *(byte **)(param_2 + 0x10) <= pbVar2 ||
           (bVar1 = *pbVar2, (char)bVar1 < '\x01'))) {
      uVar4 = FUN_140559720(param_2);
      uVar5 = (ulonglong)uVar4;
      *(uint *)(param_2 + 0x20) = uVar4;
      if (uVar4 - 1 < 0x7f) goto LAB_1405769a9;
LAB_140576a0a:
      if (((int)uVar5 == 0) || (((byte)uVar5 & 7) == 4)) goto LAB_140576a52;
      cVar3 = FUN_1405c88b0(param_2,uVar5,local_30);
      if (cVar3 == '\0') {
LAB_140576a39:
        FUN_14055a130(local_30);
        FUN_14055c070(local_40);
        return 0;
      }
    }
    uVar5 = (ulonglong)bVar1;
    *(uint *)(param_2 + 0x20) = (uint)bVar1;
    *(byte **)(param_2 + 8) = pbVar2 + 1;
LAB_1405769a9:
    if (((int)(uVar5 >> 3) != 1) || ((int)uVar5 != 8)) goto LAB_140576a0a;
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x38) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar3 = FUN_1405595b0(param_2);
      if (cVar3 == '\0') goto LAB_140576a39;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
  } while ((*(longlong *)(param_2 + 8) != *(longlong *)(param_2 + 0x10)) ||
          ((*(int *)(param_2 + 0x2c) == 0 && (*(int *)(param_2 + 0x18) != *(int *)(param_2 + 0x28)))
          ));
  *(undefined4 *)(param_2 + 0x20) = 0;
  *(undefined1 *)(param_2 + 0x24) = 1;
LAB_140576a52:
  FUN_14055a130(local_30);
  FUN_14055c070(local_40);
  return 1;
}

// ==== CMsgAthleteShopPB::vfunc_6  @140576a80  [high:rtti-vtable]  (orig: thunk_FUN_140576460)
void thunk_FUN_140576460(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 auStackX_8 [8];
  undefined1 auStack_48 [64];
  
  if (param_2 == param_1) {
    auStackX_8[0] = 0;
    uVar2 = FUN_140556890(auStack_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgathleteshop.pb.cc",0xd2,
                          0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(auStackX_8,uVar2);
    FUN_140556900(auStack_48);
  }
  if ((*(char *)(param_2 + 0x30) != '\0') && ((*(byte *)(param_2 + 0x30) & 1) != 0)) {
    uVar1 = *(undefined4 *)(param_2 + 0x38);
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
    *(undefined4 *)(param_1 + 0x38) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x000140576518. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

