// ==== CMD5Checksum@MD5::vfunc_0  @140509120  [high:rtti-vtable]  (orig: FUN_140509120)
undefined8 FUN_140509120(longlong *param_1)

{
  if (param_1 != (longlong *)0x0) {
    (**(code **)(*param_1 + 0x30))(param_1,1);
  }
  return 0;
}

// ==== CMD5Checksum@MD5::vfunc_2  @140509140  [high:rtti-vtable]  (orig: FUN_140509140)
undefined8 FUN_140509140(void)

{
  return 0;
}

// ==== CMD5Checksum@MD5::vfunc_3  @140509150  [high:rtti-vtable]  (orig: FUN_140509150)
void FUN_140509150(void)

{
  return;
}

// ==== CMD5Checksum@MD5::vfunc_4  @140509160  [high:rtti-vtable]  (orig: FUN_140509160)
undefined8 FUN_140509160(void)

{
  return 0;
}

// ==== CMD5Checksum@MD5::vfunc_5  @140509170  [high:rtti-vtable]  (orig: FUN_140509170)
void FUN_140509170(void)

{
  return;
}

// ==== CMD5Checksum@MD5::vfunc_6  @140509180  [high:rtti-vtable]  (orig: FUN_140509180)
undefined8 * FUN_140509180(undefined8 *param_1,byte param_2)

{
  *param_1 = MD5::CMD5Checksum::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMD5Checksum@MD5::helper_14050a910  @14050a910  [medium:callgraph-r0]  (orig: FUN_14050a910)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14050a910(undefined8 param_1,char *param_2)

{
  undefined8 ***pppuVar1;
  undefined1 auStack_d8 [32];
  undefined4 local_b8;
  undefined8 local_b0;
  undefined8 local_a8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_a0 [8];
  undefined8 **local_98 [2];
  undefined4 local_88;
  ulonglong local_80;
  undefined **local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  ulonglong local_18;
  
  local_a8 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_d8;
  local_b8 = 0;
  local_78 = MD5::CMD5Checksum::vftable;
  local_70 = 0;
  local_68 = 0;
  local_60 = 0;
  local_58 = 0;
  local_50 = 0;
  local_48 = 0;
  local_40 = 0;
  local_38 = 0;
  local_2c = 0;
  local_30 = 0;
  local_28 = 0x67452301;
  local_24 = 0xefcdab89;
  local_20 = 0x98badcfe;
  local_1c = 0x10325476;
  local_b0 = param_1;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_a0,param_2);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=(local_a0,-0x5d);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=(local_a0,-0x54);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=(local_a0,-0x5f);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=(local_a0,-0x5d);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
            (local_a0,"eur506,j89jfmncvl");
  pppuVar1 = local_98;
  if (0xf < local_80) {
    pppuVar1 = (undefined8 ***)local_98[0];
  }
  FUN_14050a4a0(&local_78,pppuVar1,local_88);
  FUN_14050a5d0(&local_78,param_1);
  local_b8 = 1;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_a0);
  return param_1;
}

// ==== CMD5Checksum@MD5::vfunc_1  @14050aa70  [high:rtti-vtable]  (orig: FUN_14050aa70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14050aa70(undefined8 param_1,char *param_2)

{
  char cVar1;
  char ****ppppcVar2;
  undefined1 auStack_68 [32];
  undefined8 local_48;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [8];
  char ***local_38 [3];
  ulonglong local_20;
  ulonglong local_18;
  
  local_48 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  FUN_14050a910(local_40);
  ppppcVar2 = local_38;
  if (0xf < local_20) {
    ppppcVar2 = (char ****)local_38[0];
  }
  do {
    cVar1 = *(char *)ppppcVar2;
    *param_2 = cVar1;
    ppppcVar2 = (char ****)((longlong)ppppcVar2 + 1);
    param_2 = param_2 + 1;
  } while (cVar1 != '\0');
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_40);
  return 0;
}

