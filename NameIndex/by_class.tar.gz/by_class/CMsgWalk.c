// ==== CMsgWalk::helper_14016f3d0  @14016f3d0  [medium:callgraph-r0]  (orig: FUN_14016f3d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14016f3d0(longlong *param_1,undefined1 param_2,char param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_928 [32];
  undefined1 local_908;
  char local_907;
  undefined4 local_904;
  longlong *local_900;
  longlong *local_8f8;
  undefined8 local_8f0;
  undefined1 local_8e8 [1072];
  undefined1 local_4b8 [1152];
  ulonglong local_38;
  
  local_8f0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_928;
  local_904 = 0;
  local_900 = (longlong *)0x0;
  local_908 = param_2;
  local_907 = param_3;
  local_8f8 = param_1;
  plVar5 = (longlong *)(**(code **)(param_1[2] + 0x160))();
  if (plVar5 != (longlong *)0x0) {
    local_904 = (**(code **)(*plVar5 + 8))(plVar5);
    cVar2 = FUN_1403b4200(param_1 + 0x74);
    if ((cVar2 == '\0') ||
       ((iVar3 = FUN_1403b41c0(param_1 + 0x74), iVar3 != 0x186a4 &&
        (iVar3 = FUN_1403b41c0(param_1 + 0x74), iVar3 != 0x186a7)))) {
      FUN_1403ed0f0(local_4b8);
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      iVar3 = FUN_1403ed180(local_4b8,uVar4,param_2,param_3);
      if (iVar3 != 0) {
        (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_4b8,1);
      }
      FUN_1403ed140(local_4b8);
    }
    else {
      uVar6 = FUN_140008520((int)param_1[0x246]);
      plVar5 = (longlong *)FUN_140087650(uVar6);
      lVar1 = *plVar5;
      uVar4 = FUN_1403b41b0(param_1 + 0x74);
      plVar5 = (longlong *)(**(code **)(lVar1 + 0x98))(plVar5,uVar4);
      if (plVar5 != (longlong *)0x0) {
        local_900 = plVar5;
        iVar3 = (**(code **)(*plVar5 + 0x50))(plVar5);
        if (iVar3 == 2) {
          FUN_1403ece80(local_8e8);
          cVar2 = FUN_1403ecf00(local_8e8,1,param_2,param_3);
          if (cVar2 != '\0') {
            uVar4 = (**(code **)(*param_1 + 8))(param_1);
            FUN_1403ecf80(local_8e8,uVar4);
            uVar4 = (**(code **)(*plVar5 + 8))(plVar5);
            FUN_1403ecf80(local_8e8,uVar4);
            (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_8e8,1);
          }
          FUN_1403eced0(local_8e8);
          if (param_3 != '\x02') {
            (**(code **)(plVar5[2] + 0x2e8))(plVar5 + 2,param_3);
          }
          (**(code **)(plVar5[2] + 0x368))(plVar5 + 2,param_2,0);
        }
      }
    }
  }
  return;
}

// ==== CMsgWalk::ctor_or_dtor  @1403ed0f0  [high:vtable-assign]  (orig: FUN_1403ed0f0)
undefined8 * FUN_1403ed0f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgWalk::vftable;
  FUN_140576f20(param_1 + 0x85);
  FUN_1402b5600(param_1);
  return param_1;
}

// ==== CMsgWalk::ctor_or_dtor  @1403ed140  [high:vtable-assign]  (orig: FUN_1403ed140)
void FUN_1403ed140(undefined8 *param_1)

{
  *param_1 = CMsgWalk::vftable;
  FUN_140577000(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgWalk::helper_1403ed180  @1403ed180  [medium:callgraph-r0]  (orig: FUN_1403ed180)
undefined8 FUN_1403ed180(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  ulong uVar2;
  undefined4 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (param_2 == 0) {
    uVar5 = 0;
  }
  else {
    FUN_1402b5600();
    *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 1;
    *(undefined4 *)(param_1 + 0x460) = param_3;
    *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 2;
    *(int *)(param_1 + 0x464) = param_2;
    *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 4;
    *(undefined4 *)(param_1 + 0x468) = param_4;
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 8;
    *(ulong *)(param_1 + 0x46c) = uVar2;
    cVar1 = FUN_1405551c0(param_1 + 0x428,param_1 + 0x10,0x400);
    if (cVar1 == '\0') {
      cVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x20))(param_1 + 0x428);
      if (cVar1 == '\0') {
        lVar4 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x28))(param_1 + 0x428,local_30);
        if (*(ulonglong *)(lVar4 + 0x20) < 0x10) {
          lVar4 = lVar4 + 8;
        }
        else {
          lVar4 = *(longlong *)(lVar4 + 8);
        }
        log_InlineLogERROR(&DAT_14076b150,lVar4);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
      }
      else {
        log_InlineLogERROR("CMsgWalk_pb::CreateBufMsg SerializeToArray failed.");
      }
      uVar5 = 0;
    }
    else {
      *(undefined4 *)(param_1 + 8) = 0x2715;
      uVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
      *(undefined4 *)(param_1 + 0xc) = uVar3;
      uVar5 = 1;
    }
  }
  return uVar5;
}

// ==== CMsgWalk::vfunc_1  @1403ed2c0  [high:rtti-vtable]  (orig: FUN_1403ed2c0)
undefined8 FUN_1403ed2c0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  uVar4 = 0xfffffffffffffffe;
  if (*(int *)(param_1 + 8) == 0x2715) {
    plVar1 = (longlong *)(param_1 + 0x428);
    cVar2 = FUN_140554950(plVar1);
    if (cVar2 == '\0') {
      cVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
      if (cVar2 == '\0') {
        lVar3 = (**(code **)(*plVar1 + 0x28))(plVar1,local_30,param_3,param_4,uVar4);
        if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
          lVar3 = lVar3 + 8;
        }
        else {
          lVar3 = *(longlong *)(lVar3 + 8);
        }
        log_InlineLogERROR(&DAT_14076b1f0,lVar3);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
      }
      else {
        log_InlineLogERROR("CMsgWalk_pb::CreateBufMsg ParseFromArray failed.");
      }
      uVar4 = 0;
    }
    else {
      uVar4 = 1;
    }
  }
  else {
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CMsgWalk::ctor_or_dtor  @1403ed390  [high:vtable-assign]  (orig: FUN_1403ed390)
undefined8 * FUN_1403ed390(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgWalk::vftable;
  FUN_140577000(param_1 + 0x85);
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgWalk::vfunc_3  @1403ed3f0  [high:rtti-vtable]  (orig: FUN_1403ed3f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403ed3f0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong lVar12;
  ulonglong uVar13;
  longlong lVar14;
  undefined1 auStack_538 [32];
  int local_518;
  undefined4 local_510;
  undefined4 local_508;
  undefined4 local_500;
  longlong *local_4f8;
  longlong *local_4f0;
  undefined8 local_4e8;
  longlong local_4e0;
  undefined8 local_4d8;
  uint local_4d0;
  undefined8 local_4c8;
  undefined1 local_4b8 [1152];
  ulonglong local_38;
  
  local_4c8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  local_4e0 = param_1;
  if (((*(int *)(param_1 + 0x414) == -1) || (*(int *)(param_1 + 0x464) - 0xaae61U < 99999)) ||
     (*(int *)(param_1 + 0x464) - 1000000U < 0xee5be5c0)) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar8 = (longlong *)FUN_1400875f0(uVar7);
    plVar8 = (longlong *)
             (**(code **)(*plVar8 + 0x18))(plVar8,param_1,*(undefined4 *)(param_1 + 0x464));
    local_4f0 = plVar8;
    if (plVar8 == (longlong *)0x0) {
      if (((*(uint *)(param_1 + 0x464) < 0xee69a15f) || (3999999999 < *(uint *)(param_1 + 0x464)))
         && ((*(int *)(param_1 + 0x414) != -1 && (*(int *)(param_1 + 0x414) != -0x5a91600)))) {
        log_InlineLogERROR(&DAT_14076b360);
      }
    }
    else {
      uVar7 = 0;
      local_4e8 = 0;
      cVar1 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1002,&local_4e8);
      if ((cVar1 == '\0') || (cVar1 = FUN_140388010(local_4e8,2), cVar1 == '\0')) {
        local_4f8 = (longlong *)0x0;
        cVar1 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1001,&local_4f8);
        if (cVar1 == '\0') {
          local_4d8 = 0;
          cVar1 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1040,&local_4d8);
          if (cVar1 != '\0') {
            return;
          }
          cVar1 = (**(code **)(*plVar8 + 0x220))(plVar8);
          if (cVar1 == '\0') {
            return;
          }
        }
        else {
          plVar9 = (longlong *)FUN_1400e1e60();
          uVar2 = *(undefined4 *)(param_1 + 0x46c);
          lVar14 = local_4f8[0x1e2];
          lVar12 = *plVar9;
          uVar4 = (**(code **)(*local_4f8 + 8))();
          (**(code **)(lVar12 + 0x108))(plVar9,uVar4,(int)lVar14,uVar2);
          cVar1 = (**(code **)(*plVar8 + 0x220))(plVar8);
          if ((cVar1 == '\0') && ((char)local_4f8[0x127] == '\0')) {
            FUN_140185db0();
            pIVar10 = theInstance();
            lVar12 = *plVar8;
            uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_DIE");
            (**(code **)(lVar12 + 0x358))(plVar8,uVar7);
            return;
          }
          iVar3 = *(int *)(param_1 + 0x470);
          iVar5 = (**(code **)(local_4f8[2] + 0x168))();
          if (iVar5 != iVar3) {
            FUN_140185db0(local_4f8);
            return;
          }
          if (local_4f8[0x151] != 0) {
            plVar9 = (longlong *)**(undefined8 **)(local_4f8[0x151] + 0x10);
            plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0x15);
            uVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
            if ((~(byte)(uVar6 >> 6) & 1) == 0) {
              pIVar10 = theInstance();
              lVar12 = local_4f8[2];
              uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_YOUR_CANNOT_WALK");
              (**(code **)(lVar12 + 0x358))(local_4f8 + 2,uVar7);
              FUN_140185db0(local_4f8);
              return;
            }
          }
          iVar3 = *(int *)(param_1 + 0x464);
          iVar5 = (**(code **)(*local_4f8 + 8))();
          if (iVar5 == iVar3) {
            cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x2f);
            if (cVar1 == '\0') {
              if (*(int *)(param_1 + 0x468) == 9) {
                return;
              }
              plVar9 = (longlong *)FUN_1400e1e60();
              uVar2 = *(undefined4 *)(param_1 + 0x46c);
              lVar12 = *plVar9;
              uVar4 = (**(code **)(*local_4f8 + 8))();
              cVar1 = (**(code **)(lVar12 + 0x80))(plVar9,uVar4,uVar2);
              if (cVar1 == '\0') {
                (**(code **)(local_4f8[2] + 0x358))(local_4f8 + 2,"invalid walk");
                uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                plVar8 = (longlong *)FUN_140087650(uVar7);
                (**(code **)(*plVar8 + 0x50))(plVar8,local_4f8,"invalid walk time stamp");
                return;
              }
            }
            else {
              iVar3 = FUN_140160af0(local_4f8);
              if ((iVar3 < 1) && (*(int *)(param_1 + 0x468) != 0)) {
                FUN_140185db0(local_4f8);
                return;
              }
              plVar9 = (longlong *)FUN_1400e1e60();
              lVar12 = *plVar9;
              uVar2 = (**(code **)(*local_4f8 + 8))();
              (**(code **)(lVar12 + 0x78))(plVar9,uVar2);
              plVar9 = (longlong *)FUN_1400e1e60();
              uVar2 = *(undefined4 *)(param_1 + 0x46c);
              lVar12 = *plVar9;
              uVar4 = (**(code **)(*local_4f8 + 8))();
              cVar1 = (**(code **)(lVar12 + 0x88))(plVar9,uVar4,uVar2);
              if (cVar1 == '\0') {
                (**(code **)(local_4f8[2] + 0x358))(local_4f8 + 2,"invalid walk");
                uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                plVar8 = (longlong *)FUN_140087650(uVar7);
                (**(code **)(*plVar8 + 0x50))(plVar8,local_4f8,"invalid mount walk time stamp");
                return;
              }
            }
          }
          uVar11 = FUN_140161000(local_4f8);
          cVar1 = FUN_1403b4200(uVar11);
          if ((cVar1 != '\0') && (iVar3 = (**(code **)(*local_4f8 + 0x50))(), iVar3 == 2)) {
            iVar3 = FUN_1403b41c0(uVar11);
            if (iVar3 == 0x186a4) {
              return;
            }
            iVar3 = FUN_1403b41c0(uVar11);
            if (iVar3 == 0x186a7) {
              return;
            }
          }
        }
        if (*(int *)(param_1 + 0x468) != 2) {
          (**(code **)(*plVar8 + 0x2e8))(plVar8);
        }
        lVar12 = (**(code **)(*plVar8 + 0x160))(plVar8);
        if (lVar12 == 0) {
          local_518 = 0xd5;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          lVar14 = (longlong)(int)(*(uint *)(param_1 + 0x460) & 7);
          iVar3 = (**(code **)(*plVar8 + 0x40))(plVar8);
          iVar3 = iVar3 + *(int *)(&DAT_14076af50 + lVar14 * 4);
          iVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
          iVar5 = iVar5 + *(int *)(&DAT_14076af70 + lVar14 * 4);
          if (*(int *)(param_1 + 0x468) == 9) {
            lVar14 = (longlong)(int)(*(uint *)(param_1 + 0x460) % 0x18);
            iVar3 = (**(code **)(*plVar8 + 0x40))(plVar8);
            iVar3 = iVar3 + *(int *)(&DAT_14076af90 + lVar14 * 4);
            iVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
            iVar5 = iVar5 + *(int *)(&DAT_14076aff0 + lVar14 * 4);
          }
          if ((local_4f8 != (longlong *)0x0) &&
             (cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x73), cVar1 != '\0')) {
            uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            cVar1 = FUN_14008b330(uVar11);
            if (cVar1 == '\0') {
              plVar9 = (longlong *)CurrentInstanceGet();
              lVar14 = (**(code **)(*plVar9 + 0x20))(plVar9,0x1c);
              if (lVar14 != 0) {
                plVar9 = *(longlong **)(*(longlong *)(lVar12 + 0x58) + 8);
                plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
                uVar13 = (**(code **)(*plVar9 + 0x58))(plVar9);
                if (((uVar13 >> 0x1f & 1) != 0) &&
                   (cVar1 = FUN_1402c68a0(lVar12,0x18,iVar3,iVar5), cVar1 != '\0')) {
                  pIVar10 = theInstance();
                  lVar14 = local_4f8[2];
                  uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_USER_IN_SAFE_WITH_VLM");
                  (**(code **)(lVar14 + 0x358))(local_4f8 + 2,uVar7);
                  FUN_140185db0(local_4f8);
                  plVar8 = local_4f8;
                  uVar2 = (**(code **)(local_4f8[2] + 0x48))(local_4f8 + 2);
                  uVar4 = (**(code **)(plVar8[2] + 0x40))(plVar8 + 2);
                  cVar1 = FUN_1402c68a0(lVar12,0x18,uVar4,uVar2);
                  if (cVar1 == '\0') {
                    return;
                  }
                  pIVar10 = theInstance();
                  lVar12 = local_4f8[2];
                  uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_USER_IN_SAFE_WITH_VLM");
                  (**(code **)(lVar12 + 0x358))(local_4f8 + 2,uVar7);
                  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                  plVar8 = (longlong *)FUN_140087650(uVar7);
                  (**(code **)(*plVar8 + 0x50))(plVar8,local_4f8,&DAT_140758380);
                  return;
                }
              }
            }
            else {
              plVar9 = (longlong *)CurrentInstanceGet();
              lVar14 = (**(code **)(*plVar9 + 0x20))(plVar9,0x25);
              if ((lVar14 != 0) && (cVar1 = FUN_1402c68a0(lVar12,0x18,iVar3,iVar5), cVar1 != '\0'))
              {
                pIVar10 = theInstance();
                lVar14 = local_4f8[2];
                uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar14 + 0x358))(local_4f8 + 2,uVar7);
                FUN_140185db0(local_4f8);
                plVar8 = local_4f8;
                uVar2 = (**(code **)(local_4f8[2] + 0x48))(local_4f8 + 2);
                uVar4 = (**(code **)(plVar8[2] + 0x40))(plVar8 + 2);
                cVar1 = FUN_1402c68a0(lVar12,0x18,uVar4,uVar2);
                if (cVar1 == '\0') {
                  return;
                }
                pIVar10 = theInstance();
                lVar12 = local_4f8[2];
                uVar7 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_USER_IN_SAFE_WITH_VLM");
                (**(code **)(lVar12 + 0x358))(local_4f8 + 2,uVar7);
                uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                plVar8 = (longlong *)FUN_140087650(uVar7);
                (**(code **)(*plVar8 + 0x50))(plVar8,local_4f8,&DAT_140758380);
                return;
              }
            }
          }
          cVar1 = FUN_1402c3cc0(lVar12,iVar3,iVar5);
          if (cVar1 != '\0') {
            if (local_4f8 == (longlong *)0x0) {
              FUN_1403ed0f0(local_4b8);
              iVar3 = FUN_1403ed180(local_4b8,*(undefined4 *)(param_1 + 0x464),
                                    *(undefined4 *)(param_1 + 0x460),
                                    *(undefined4 *)(param_1 + 0x468));
              if (iVar3 != 0) {
                (**(code **)(*plVar8 + 0x348))(plVar8,local_4b8,1);
              }
              FUN_1403ed140(local_4b8);
            }
            else {
              cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x38);
              if ((((cVar1 == '\0') &&
                   (cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x37), cVar1 == '\0'))
                  && (cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x18), cVar1 == '\0'
                     )) && ((cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x6e),
                            cVar1 == '\0' &&
                            (cVar1 = (**(code **)(local_4f8[2] + 0x2d8))(local_4f8 + 2,0x6a),
                            cVar1 == '\0')))) {
                local_4d0 = *(uint *)(param_1 + 0x468);
                local_4e0 = CONCAT44(local_4e0._4_4_,*(uint *)(param_1 + 0x460));
                local_518 = iVar5;
                FUN_14016f3d0(local_4f8,*(uint *)(param_1 + 0x460) & 0xff,local_4d0 & 0xff,iVar3);
              }
            }
          }
          (**(code **)(*plVar8 + 0x368))
                    (plVar8,*(undefined4 *)(param_1 + 0x460),*(undefined4 *)(param_1 + 0x468));
          lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar12 + 0x140) == 0) {
            local_518 = 0x149;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar7 = *(undefined8 *)(lVar12 + 0x140);
          }
          uVar2 = (**(code **)(*plVar8 + 0x10))(plVar8);
          FUN_14024e7b0(uVar7,uVar2);
        }
      }
    }
  }
  else {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar8 = (longlong *)FUN_1400875f0(uVar7);
    plVar8 = (longlong *)
             (**(code **)(*plVar8 + 0x18))(plVar8,param_1,*(undefined4 *)(param_1 + 0x464));
    local_4f0 = (longlong *)0x0;
    if ((plVar8 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1001,&local_4f0), cVar1 != '\0')) {
      plVar8 = (longlong *)FUN_1400e1e60();
      lVar12 = *plVar8;
      uVar2 = (**(code **)(*local_4f0 + 8))();
      local_500 = 0;
      local_508 = 0;
      local_510 = 0;
      local_518 = 0;
      (**(code **)(lVar12 + 0x28))(plVar8,uVar2,7,3);
      plVar8 = (longlong *)FUN_1400e1e60();
      lVar12 = *plVar8;
      iVar3 = tq::RandGet(300);
      uVar2 = (**(code **)(*local_4f0 + 8))();
      (**(code **)(lVar12 + 0x38))(plVar8,uVar2,iVar3 + 0x1e,&DAT_14076b3a0);
    }
  }
  return;
}

// ==== CMsgWalk::helper_1405541a0  @1405541a0  [medium:callgraph-r3]  (orig: FUN_1405541a0)
void FUN_1405541a0(int param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined1 *puVar3;
  undefined1 local_128 [8];
  undefined1 local_120 [64];
  undefined1 local_e0 [8];
  undefined1 local_d8 [64];
  undefined1 local_98 [8];
  undefined1 local_90 [64];
  uint local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_48 = 0xfffffffffffffffe;
  local_50 = 0;
  if (param_1 != param_2) {
    puVar3 = local_128;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_40 = FUN_140556890(local_120,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\message_lite.cc"
                             ,0x3f);
    local_50 = local_50 | 1;
    local_38 = local_40;
    uVar1 = FUN_1405564f0(local_40,
                          "CHECK failed: (byte_size_before_serialization) == (byte_size_after_serialization): "
                         );
    uVar1 = FUN_1405564f0(uVar1,"Protocol message was modified concurrently during serialization.");
    FUN_140556a40(local_128,uVar1);
  }
  if ((local_50 & 1) != 0) {
    local_50 = local_50 & 0xfffffffe;
    FUN_140556900(local_120);
  }
  if (param_3 != param_1) {
    puVar3 = local_e0;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_30 = FUN_140556890(local_d8,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\message_lite.cc"
                             ,0x41);
    local_50 = local_50 | 2;
    local_28 = local_30;
    uVar1 = FUN_1405564f0(local_30,
                          "CHECK failed: (bytes_produced_by_serialization) == (byte_size_before_serialization): "
                         );
    uVar1 = FUN_1405564f0(uVar1,
                          "Byte size calculation and serialization were inconsistent.  This may indicate a bug in protocol buffers or it may be caused by concurrent modification of the message."
                         );
    FUN_140556a40(local_e0,uVar1);
  }
  if ((local_50 & 2) != 0) {
    local_50 = local_50 & 0xfffffffd;
    FUN_140556900(local_d8);
  }
  puVar3 = local_98;
  for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
    *puVar3 = 0;
    puVar3 = puVar3 + 1;
  }
  local_20 = FUN_140556890(local_90,3,
                           "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\message_lite.cc",
                           0x45);
  local_18 = local_20;
  uVar1 = FUN_1405564f0(local_20,"This shouldn\'t be called if all the sizes are equal.");
  FUN_140556a40(local_98,uVar1);
  FUN_140556900(local_90);
  return;
}

// ==== CMsgWalk::helper_1405551c0  @1405551c0  [medium:callgraph-r1]  (orig: FUN_1405551c0)
/* WARNING: Removing unreachable block (ram,0x0001405551f8) */
/* WARNING: Removing unreachable block (ram,0x00014055521a) */
/* WARNING: Removing unreachable block (ram,0x000140555226) */
/* WARNING: Removing unreachable block (ram,0x000140555228) */
/* WARNING: Removing unreachable block (ram,0x000140555215) */
/* WARNING: Removing unreachable block (ram,0x0001405552e1) */
/* WARNING: Removing unreachable block (ram,0x0001405552ef) */
/* WARNING: Removing unreachable block (ram,0x000140555302) */
/* WARNING: Removing unreachable block (ram,0x000140555310) */
/* WARNING: Removing unreachable block (ram,0x000140555323) */

void FUN_1405551c0(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  FUN_140555360(param_1,param_2,param_3);
  return;
}

// ==== CMsgWalk::helper_140555360  @140555360  [medium:callgraph-r2]  (orig: FUN_140555360)
undefined8 FUN_140555360(longlong *param_1,longlong param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  
  iVar1 = (**(code **)(*param_1 + 0x40))(param_1);
  if (param_3 < iVar1) {
    uVar3 = 0;
  }
  else {
    lVar4 = (**(code **)(*param_1 + 0x50))(param_1,param_2);
    if (lVar4 - param_2 != (longlong)iVar1) {
      uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
      FUN_1405541a0(iVar1,uVar2,(int)lVar4 - (int)param_2);
    }
    uVar3 = 1;
  }
  return uVar3;
}

