// ==== C7zFile@?A0x16c71dd6::vfunc_1  @140573820  [high:rtti-vtable]  (orig: FUN_140573820)
bool FUN_140573820(longlong param_1)

{
  return 0 < *(int *)(param_1 + 8);
}

// ==== C7zFile@?A0x16c71dd6::vfunc_2  @140573830  [high:rtti-vtable]  (orig: FUN_140573830)
int FUN_140573830(longlong param_1,void *param_2,int param_3,int param_4)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0xc);
  param_3 = param_3 * param_4;
  if (*(int *)(param_1 + 8) < iVar1 + param_3) {
    param_3 = *(int *)(param_1 + 8) - iVar1;
  }
  if (param_2 != (void *)0x0) {
    memcpy(param_2,(void *)((longlong)iVar1 + *(longlong *)(param_1 + 0x10)),(longlong)param_3);
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + param_3;
  return param_3;
}

// ==== C7zFile@?A0x16c71dd6::vfunc_0  @140573d50  [high:rtti-vtable]  (orig: FUN_140573d50)
undefined8 * FUN_140573d50(undefined8 *param_1,uint param_2)

{
  *param_1 = _anon_16C71DD6::C7zFile::vftable;
  if (param_1[2] != 0) {
    FUN_1405bc140();
  }
  *param_1 = IFile::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== C7zFile@?A0x16c71dd6::helper_1405bc140  @1405bc140  [medium:callgraph-r0]  (orig: FUN_1405bc140)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_1405bc140(undefined8 param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001405bc14a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*_DAT_140975458)(&PTR_FUN_140975450,param_1);
  return;
}

