// ==== CCrossMsgTokenCheck::ctor_or_dtor  @140460da0  [high:vtable-assign]  (orig: FUN_140460da0)
undefined8 * FUN_140460da0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgTokenCheck::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgTokenCheck::ctor_or_dtor  @140460df0  [high:vtable-assign]  (orig: FUN_140460df0)
void FUN_140460df0(undefined8 *param_1)

{
  *param_1 = CCrossMsgTokenCheck::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgTokenCheck::vfunc_1  @140460e20  [high:rtti-vtable]  (orig: FUN_140460e20)
ulonglong FUN_140460e20(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c66);
}

// ==== CCrossMsgTokenCheck::ctor_or_dtor  @140460e80  [high:vtable-assign]  (orig: FUN_140460e80)
undefined8 * FUN_140460e80(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgTokenCheck::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgTokenCheck::vfunc_3  @140460ed0  [high:rtti-vtable]  (orig: FUN_140460ed0)
void FUN_140460ed0(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  char cVar3;
  longlong *plVar4;
  longlong lVar5;
  
  if ((*(longlong *)(param_1 + 0x428) != 0) && (iVar1 = *(int *)(param_1 + 0x420), iVar1 != 0)) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar4 = (longlong *)FUN_140087650(uVar2);
    lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,iVar1);
    if (lVar5 == 0) {
                    /* WARNING: Could not recover jumptable at 0x000140460f34. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CCrossMsgTokenCheck::Process, user[%lu] is not online.");
      return;
    }
    cVar3 = FUN_140167b70(lVar5);
    if (cVar3 != '\0') {
                    /* WARNING: Could not recover jumptable at 0x000140460f5a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogERROR("CCrossMsgLeagueToken::Process, user[%lu] is other server.");
      return;
    }
    plVar4 = (longlong *)FUN_140087ed0();
    if (plVar4 != (longlong *)0x0) {
      (**(code **)(*plVar4 + 0x608))
                (plVar4,iVar1,**(undefined4 **)(param_1 + 0x428),
                 (*(undefined4 **)(param_1 + 0x428))[1]);
    }
  }
  return;
}

