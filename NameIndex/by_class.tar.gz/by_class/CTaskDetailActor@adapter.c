// ==== CTaskDetailActor@adapter::helper_14008b0b0  @14008b0b0  [medium:callgraph-r0]  (orig: FUN_14008b0b0)
undefined4 FUN_14008b0b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x780);
}

// ==== CTaskDetailActor@adapter::helper_14008b0c0  @14008b0c0  [medium:callgraph-r0]  (orig: FUN_14008b0c0)
undefined4 FUN_14008b0c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x7d4);
}

// ==== CTaskDetailActor@adapter::helper_14008b0d0  @14008b0d0  [medium:callgraph-r0]  (orig: FUN_14008b0d0)
longlong FUN_14008b0d0(longlong param_1)

{
  return param_1 + 0x7ac;
}

// ==== CTaskDetailActor@adapter::helper_14008b0e0  @14008b0e0  [medium:callgraph-r0]  (orig: FUN_14008b0e0)
longlong FUN_14008b0e0(longlong param_1)

{
  return param_1 + 0x784;
}

// ==== CTaskDetailActor@adapter::helper_14008b0f0  @14008b0f0  [medium:callgraph-r0]  (orig: FUN_14008b0f0)
undefined4 FUN_14008b0f0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x7d8);
}

// ==== CTaskDetailActor@adapter::helper_14008b100  @14008b100  [medium:callgraph-r0]  (orig: FUN_14008b100)
undefined4 FUN_14008b100(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x7dc);
}

// ==== CTaskDetailActor@adapter::helper_14008b110  @14008b110  [medium:callgraph-r0]  (orig: FUN_14008b110)
undefined4 FUN_14008b110(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x7e0);
}

// ==== CTaskDetailActor@adapter::helper_1403b8930  @1403b8930  [medium:callgraph-r0]  (orig: FUN_1403b8930)
undefined8 FUN_1403b8930(longlong param_1,undefined4 *param_2)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  
  if ((param_2 != (undefined4 *)0x0) && (*(longlong *)(param_1 + 8) != 0)) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0);
    uVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
    *param_2 = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
    uVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
    param_2[2] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),1);
    uVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
    param_2[1] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
    uVar2 = (**(code **)(*plVar4 + 0x30))(plVar4);
    *(undefined2 *)(param_2 + 3) = uVar2;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
    uVar1 = (**(code **)(*plVar4 + 0x20))(plVar4);
    *(undefined1 *)((longlong)param_2 + 0xe) = uVar1;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[4] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[5] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[6] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),8);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[7] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),9);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[8] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),10);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[9] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xb);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    param_2[10] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xc);
    uVar3 = (**(code **)(*plVar4 + 0x50))(plVar4);
    param_2[0xb] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xd);
    uVar3 = (**(code **)(*plVar4 + 0x50))(plVar4);
    param_2[0xd] = uVar3;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xe);
    uVar3 = (**(code **)(*plVar4 + 0x50))(plVar4);
    param_2[0xf] = uVar3;
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CTaskDetailActor@adapter::helper_1403b8b30  @1403b8b30  [medium:callgraph-r1]  (orig: FUN_1403b8b30)
undefined8 FUN_1403b8b30(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0);
                    /* WARNING: Could not recover jumptable at 0x0001403b8b82. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CTaskDetailActor@adapter::helper_1403b8b90  @1403b8b90  [medium:callgraph-r1]  (orig: FUN_1403b8b90)
undefined8 FUN_1403b8b90(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
                    /* WARNING: Could not recover jumptable at 0x0001403b8be5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CTaskDetailActor@adapter::helper_1403b8bf0  @1403b8bf0  [medium:callgraph-r0]  (orig: FUN_1403b8bf0)
undefined8 FUN_1403b8bf0(longlong param_1,uint param_2,undefined4 param_3,char param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if ((*(longlong *)(param_1 + 8) == 0) || (0xe < param_2)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_3);
  if ((param_4 != '\0') && (*(char *)(param_1 + 0x14) == '\0')) {
                    /* WARNING: Could not recover jumptable at 0x0001403b8c62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
    return uVar2;
  }
  return 1;
}

// ==== CTaskDetailActor@adapter::helper_1403b8d30  @1403b8d30  [medium:callgraph-r0]  (orig: FUN_1403b8d30)
longlong FUN_1403b8d30(longlong param_1)

{
  return param_1 + 0x10;
}

// ==== CTaskDetailActor@adapter::helper_1403b8d40  @1403b8d40  [medium:callgraph-r0]  (orig: FUN_1403b8d40)
undefined8 FUN_1403b8d40(longlong param_1,int *param_2,char param_3)

{
  int iVar1;
  longlong *plVar2;
  
  if ((param_2 == (int *)0x0) || (*(longlong *)(param_1 + 8) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((*(char *)(param_1 + 0x14) == '\0') && (iVar1 = FUN_1403b8b30(), *param_2 != iVar1)) {
    return 0;
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
  (**(code **)(*plVar2 + 200))(plVar2,(short)param_2[3]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
  (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)((longlong)param_2 + 0xe));
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[4]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[5]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[6]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),8);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[7]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),9);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[8]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),10);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[9]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xb);
  (**(code **)(*plVar2 + 0xb0))(plVar2,param_2[10]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xc);
  (**(code **)(*plVar2 + 0xa8))(plVar2,param_2[0xb]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xd);
  (**(code **)(*plVar2 + 0xa8))(plVar2,param_2[0xd]);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xe);
  (**(code **)(*plVar2 + 0xa8))(plVar2,param_2[0xf]);
  if ((*(char *)(param_1 + 0x14) == '\0') && (param_3 != '\0')) {
    (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  }
  return 1;
}

// ==== CTaskDetailActor@adapter::helper_1403b90b0  @1403b90b0  [medium:callgraph-r2]  (orig: FUN_1403b90b0)
void FUN_1403b90b0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CTaskDetailActor@adapter::helper_1403b91d0  @1403b91d0  [medium:callgraph-r2]  (orig: FUN_1403b91d0)
void FUN_1403b91d0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001403b91f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CTaskDetailActor@adapter::helper_1403b9370  @1403b9370  [medium:callgraph-r1]  (orig: FUN_1403b9370)
void FUN_1403b9370(longlong *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar1 = (undefined8 *)*param_1;
  if (puVar1 != (undefined8 *)0x0) {
    puVar2 = (undefined8 *)puVar1[1];
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,*(char *)((longlong)puVar1 + 0x14) == '\0');
    }
    puVar1[1] = 0;
    (**(code **)*puVar1)(puVar1,1);
    *param_1 = 0;
  }
  return;
}

// ==== CTaskDetailActor@adapter::helper_1403b9710  @1403b9710  [medium:callgraph-r1]  (orig: FUN_1403b9710)
undefined8 FUN_1403b9710(longlong param_1,longlong param_2,char param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 == '\0') {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    lVar2 = *(longlong *)(lVar2 + 0x210);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar2 = 0;
    }
    lVar2 = FUN_14028deb0(lVar2,3);
    *(longlong *)(param_1 + 8) = lVar2;
    if (lVar2 == 0) {
      log_InlineLogERROR(
                        "pop task_detail rec err:user=%u,task=%u,completeFlag=%d,notifyFlag=%d,data1=%d,data2=%d,data3=%d,data4=%d,data5=%d,data6=%d,data7=%d,overTime=%u,type=%u"
                        );
      return 0;
    }
  }
  else {
    plVar3 = (longlong *)InstanceGet();
    lVar2 = (**(code **)(*plVar3 + 0x20))(plVar3,"task_detail");
    *(longlong *)(param_1 + 8) = lVar2;
    if (lVar2 == 0) {
      return 0;
    }
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),1);
  (**(code **)(*plVar3 + 0xb8))(plVar3,*(undefined4 *)(param_2 + 4));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
  (**(code **)(*plVar3 + 0xb8))(plVar3,*(undefined4 *)(param_2 + 8));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
  (**(code **)(*plVar3 + 200))(plVar3,*(undefined2 *)(param_2 + 0xc));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
  (**(code **)(*plVar3 + 0xd8))(plVar3,*(undefined1 *)(param_2 + 0xe));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x10));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x14));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x18));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),8);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x1c));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),9);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x20));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),10);
  (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x24));
  if (param_3 == '\0') {
    plVar3 = (longlong *)FUN_140118220();
    cVar1 = (**(code **)(*plVar3 + 0x30))(plVar3,*(undefined4 *)(param_2 + 8));
    if (cVar1 == '\0') {
      plVar3 = (longlong *)FUN_140118220();
      cVar1 = (**(code **)(*plVar3 + 0x28))(plVar3,*(undefined4 *)(param_2 + 8));
      if (cVar1 == '\0') goto LAB_1403b9a0a;
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xb);
    uVar4 = _time64((__time64_t *)0x0);
    (**(code **)(*plVar3 + 0xa8))(plVar3,uVar4 & 0xffffffff);
  }
  else {
LAB_1403b9a0a:
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xb);
    (**(code **)(*plVar3 + 0xb0))(plVar3,*(undefined4 *)(param_2 + 0x28));
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xc);
  (**(code **)(*plVar3 + 0xa8))(plVar3,*(undefined4 *)(param_2 + 0x2c));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xd);
  (**(code **)(*plVar3 + 0xa8))(plVar3,*(undefined4 *)(param_2 + 0x34));
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xe);
  (**(code **)(*plVar3 + 0xa8))(plVar3,*(undefined4 *)(param_2 + 0x3c));
  if (param_3 == '\0') {
    (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  }
  *(char *)(param_1 + 0x14) = param_3;
  return 1;
}

// ==== CTaskDetailActor@adapter::helper_1403b9ab0  @1403b9ab0  [medium:callgraph-r1]  (orig: FUN_1403b9ab0)
undefined8 FUN_1403b9ab0(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    lVar3 = *(longlong *)(lVar3 + 0x210);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    cVar1 = FUN_14028dc40(lVar3,3,param_1 + 8,*(undefined1 *)(param_1 + 0x14));
    if (cVar1 == '\0') {
      (**(code **)(**(longlong **)(param_1 + 8) + 0x40))(*(longlong **)(param_1 + 8),0);
      if (*(longlong *)(param_1 + 8) != 0) {
        (**(code **)**(undefined8 **)(param_1 + 8))(*(undefined8 **)(param_1 + 8),1);
        *(undefined8 *)(param_1 + 8) = 0;
      }
    }
    *(undefined8 *)(param_1 + 8) = 0;
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CTaskDetailActor@adapter::helper_1403b9d30  @1403b9d30  [medium:callgraph-r2]  (orig: FUN_1403b9d30)
void FUN_1403b9d30(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CTaskDetailActor@adapter::helper_1403ba120  @1403ba120  [medium:callgraph-r3]  (orig: FUN_1403ba120)
undefined8 *
FUN_1403ba120(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CTaskDetailActor@adapter::helper_1403ba310  @1403ba310  [medium:callgraph-r3]  (orig: FUN_1403ba310)
undefined8 *
FUN_1403ba310(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1403ba120(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CTaskDetailActor@adapter::helper_1403ba790  @1403ba790  [medium:callgraph-r3]  (orig: FUN_1403ba790)
longlong * FUN_1403ba790(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1403ba8ed:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1403ba91c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1403ba8ed;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1403ba310(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1403ba91c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CTaskDetailActor@adapter::helper_1403bab20  @1403bab20  [medium:callgraph-r1]  (orig: FUN_1403bab20)
undefined8 * FUN_1403bab20(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1403b91d0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1403bad0c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1403bad0c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1403b9d30(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1403b90b0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1403b9d30(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1403b90b0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1403b9d30(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1403b90b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CTaskDetailActor@adapter::helper_1403bafd0  @1403bafd0  [medium:callgraph-r2]  (orig: FUN_1403bafd0)
undefined8 * FUN_1403bafd0(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1403ba310(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1403ba310(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1403ba310(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_1403ba310(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1403ba310(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1403ba310(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1403ba310(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1403ba790(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CTaskDetailActor@adapter::helper_1403bb2f0  @1403bb2f0  [medium:callgraph-r0]  (orig: FUN_1403bb2f0)
longlong * FUN_1403bb2f0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1403ba1f0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1403bab20(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CTaskDetailActor@adapter::helper_1403bb4f0  @1403bb4f0  [medium:callgraph-r0]  (orig: FUN_1403bb4f0)
undefined8 FUN_1403bb4f0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CTaskDetailActor@adapter::helper_1403bb5f0  @1403bb5f0  [medium:callgraph-r0]  (orig: FUN_1403bb5f0)
undefined8 FUN_1403bb5f0(longlong param_1,uint param_2,char param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_res20;
  longlong *local_38;
  undefined8 *local_30;
  longlong *local_28;
  longlong *plStack_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x29);
  puVar5 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar9[2];
      puVar9 = puVar5;
    }
    else {
      puVar6 = (undefined8 *)*puVar9;
    }
    puVar5 = puVar9;
    puVar9 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  local_30 = puVar5;
  local_38 = *(longlong **)(param_1 + 0x10);
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  if (*(longlong **)(param_1 + 0x10) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar9) || (param_2 < *(uint *)(puVar5 + 3))) {
    plStack_20 = (longlong *)*(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong **)(param_1 + 0x10);
    pplVar8 = &local_28;
  }
  else {
    pplVar8 = &local_38;
  }
  plVar2 = *pplVar8;
  plVar3 = pplVar8[1];
  plVar4 = *(longlong **)(param_1 + 0x40);
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (plVar3 == plVar4) {
    uVar7 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (plVar3 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_res20 = plVar3[4];
    if (local_res20 != 0) {
      if (param_3 != '\0') {
        FUN_1403b9ab0();
      }
      FUN_1403b9370(&local_res20);
    }
    local_28 = plVar2;
    plStack_20 = plVar3;
    FUN_1403bab20(param_1 + 0x10,&local_38,&local_28);
    uVar7 = 1;
  }
  return uVar7;
}

// ==== CTaskDetailActor@adapter::helper_1403bb750  @1403bb750  [medium:callgraph-r1]  (orig: FUN_1403bb750)
undefined8 * FUN_1403bb750(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_1403bafd0(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CTaskDetailActor@adapter::helper_1403bbd00  @1403bbd00  [medium:callgraph-r0]  (orig: FUN_1403bbd00)
longlong FUN_1403bbd00(longlong param_1,longlong param_2,undefined1 param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res10;
  
  if ((*(int *)(param_2 + 8) == 0) || (*(int *)(param_2 + 4) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  else {
    lVar3 = FUN_1403bb4f0();
    if (lVar3 == 0) {
      lVar3 = FUN_1403b9650(*(undefined4 *)(param_1 + 8));
      local_res10 = lVar3;
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar3 = 0;
      }
      else {
        cVar1 = FUN_1403b9710(lVar3,param_2,param_3);
        if (cVar1 == '\0') {
          FUN_1403b9370(&local_res10);
          lVar3 = 0;
        }
        else {
          uVar2 = FUN_1403b8b90(lVar3);
          local_res10 = CONCAT44(local_res10._4_4_,uVar2);
          plVar4 = (longlong *)FUN_1403bb750(param_1 + 0x10,&local_res10);
          *plVar4 = lVar3;
        }
      }
    }
  }
  return lVar3;
}

// ==== CTaskDetailActor@adapter::helper_1403bbe20  @1403bbe20  [medium:callgraph-r0]  (orig: FUN_1403bbe20)
longlong FUN_1403bbe20(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  undefined1 local_48 [4];
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_1c;
  
  if (*(int *)(param_1 + 0x50) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  else {
    lVar3 = FUN_1403bb4f0();
    if (lVar3 == 0) {
      lVar3 = FUN_1403b9650(*(undefined4 *)(param_1 + 8));
      local_res8 = lVar3;
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar3 = 0;
      }
      else {
        memset(local_48,0,0x40);
        local_44 = *(undefined4 *)(param_1 + 0x50);
        local_40 = param_2;
        local_1c = param_3;
        cVar1 = FUN_1403b9710(lVar3,local_48,0);
        if (cVar1 == '\0') {
          FUN_1403b9370(&local_res8);
          lVar3 = 0;
        }
        else {
          uVar2 = FUN_1403b8b90(lVar3);
          local_res8 = CONCAT44(local_res8._4_4_,uVar2);
          plVar4 = (longlong *)FUN_1403bb750(param_1 + 0x10,&local_res8);
          *plVar4 = lVar3;
        }
      }
    }
  }
  return lVar3;
}

// ==== CTaskDetailActor@adapter::vfunc_1  @1405b2b60  [high:rtti-vtable]  (orig: FUN_1405b2b60)
void FUN_1405b2b60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_0  @1405b2b80  [high:rtti-vtable]  (orig: FUN_1405b2b80)
void FUN_1405b2b80(longlong param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  if (param_3 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x150))(plVar1,param_5,param_3);
  }
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_3  @1405b2bf0  [high:rtti-vtable]  (orig: FUN_1405b2bf0)
undefined8 FUN_1405b2bf0(longlong param_1,undefined8 param_2,undefined4 param_3,longlong param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (((lVar1 == 0) || (param_4 == 0)) || (*(longlong *)(lVar1 + 0x1118) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar1 = FUN_1403bb4f0(*(longlong *)(lVar1 + 0x1118),param_3);
    if (lVar1 != 0) {
      FUN_1403b8930(lVar1,param_4);
      return 1;
    }
  }
  return 0;
}

// ==== CTaskDetailActor@adapter::vfunc_4  @1405b2c90  [high:rtti-vtable]  (orig: FUN_1405b2c90)
ulonglong FUN_1405b2c90(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar1 == 0) || (*(longlong *)(lVar1 + 0x1118) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = FUN_1403bb4f0(*(longlong *)(lVar1 + 0x1118),param_3);
    uVar2 = 0;
    if (lVar1 != 0) {
      uVar2 = FUN_1403b8bf0(lVar1,param_4,param_5,1);
      return uVar2;
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CTaskDetailActor@adapter::vfunc_5  @1405b2d40  [high:rtti-vtable]  (orig: FUN_1405b2d40)
ulonglong FUN_1405b2d40(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  ulonglong extraout_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (((param_3 == 0) ||
      (lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))(), lVar1 == 0)) ||
     (*(longlong *)(lVar1 + 0x1118) == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = FUN_1403bb4f0(*(longlong *)(lVar1 + 0x1118),*(undefined4 *)(param_3 + 8));
    uVar2 = 0;
    if (lVar1 != 0) {
      uVar2 = FUN_1403b8d40(lVar1,param_3,param_4);
      return uVar2;
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CTaskDetailActor@adapter::vfunc_6  @1405b2e10  [high:rtti-vtable]  (orig: FUN_1405b2e10)
bool FUN_1405b2e10(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR("CTaskDetailActor::CreateNewTaskDetail. User[%u] Task[%u] TaskOverTime[%u]");
  }
  else {
    lVar1 = *(longlong *)(lVar1 + 0x1118);
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return false;
    }
    lVar2 = FUN_1403bb4f0(lVar1,param_3);
    if (lVar2 == 0) {
      lVar1 = FUN_1403bbe20(lVar1,param_3,param_4);
      return lVar1 != 0;
    }
  }
  return false;
}

// ==== CTaskDetailActor@adapter::vfunc_18  @1405b2ee0  [high:rtti-vtable]  (orig: FUN_1405b2ee0)
ulonglong FUN_1405b2ee0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140167b70(lVar1);
  return uVar2;
}

// ==== CTaskDetailActor@adapter::vfunc_8  @1405b2f40  [high:rtti-vtable]  (orig: FUN_1405b2f40)
ulonglong FUN_1405b2f40(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (*(longlong *)(lVar1 + 0x1118) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar2 = FUN_1403bb5f0(*(longlong *)(lVar1 + 0x1118),param_3,1);
  return uVar2;
}

// ==== CTaskDetailActor@adapter::vfunc_14  @1405b2fe0  [high:rtti-vtable]  (orig: FUN_1405b2fe0)
undefined1 FUN_1405b2fe0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x51c);
}

// ==== CTaskDetailActor@adapter::vfunc_15  @1405b3040  [high:rtti-vtable]  (orig: FUN_1405b3040)
/* WARNING: Restarted to delay deadcode elimination for space: register */

bool FUN_1405b3040(longlong param_1,int param_2,uint param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  
  if (param_2 != 0) {
    if (param_3 != 0) {
      plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
      if (plVar3 != (longlong *)0x0) {
        if (param_3 <= *(uint *)((longlong)plVar3 + 0xfa4)) {
          cVar1 = (**(code **)(plVar3[2] + 0x2e0))(plVar3 + 2,0x1d,-(ulonglong)param_3,1);
          if (cVar1 != '\0') {
            uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
            FUN_1401742b0(plVar3,param_4,uVar2,0);
            uVar5 = (**(code **)(plVar3[2] + 0x18))(plVar3 + 2);
            uVar4 = (**(code **)(*plVar3 + 8))(plVar3);
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%u\t%u\t%u\t%u\t%d\t",uVar4 & 0xffffffff,
                          uVar5);
          }
          else {
            uVar4 = (**(code **)(*plVar3 + 8))(plVar3);
            log_InlineLogERROR("CTaskDetailActor::CostEmoney, user_id[%d] cost emoney[%d] error.",
                               uVar4 & 0xffffffff,(ulonglong)param_3);
          }
          return cVar1 != '\0';
        }
      }
      return false;
    }
  }
  return false;
}

// ==== CTaskDetailActor@adapter::vfunc_16  @1405b3180  [high:rtti-vtable]  (orig: FUN_1405b3180)
undefined1 * FUN_1405b3180(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b31a2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return puVar2;
  }
  return &DAT_1406dd892;
}

// ==== CTaskDetailActor@adapter::vfunc_17  @1405b31c0  [high:rtti-vtable]  (orig: FUN_1405b31c0)
undefined4 FUN_1405b31c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xf10);
}

// ==== CTaskDetailActor@adapter::vfunc_19  @1405b3220  [high:rtti-vtable]  (orig: FUN_1405b3220)
void FUN_1405b3220(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b3279. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x130))(plVar1,param_3);
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_0  @1405b3290  [high:rtti-vtable]  (orig: FUN_1405b3290)
void FUN_1405b3290(longlong param_1)

{
  FUN_1405b32f0(param_1 + -8);
  return;
}

// ==== CTaskDetailActor@adapter::helper_1405b32f0  @1405b32f0  [medium:callgraph-r0]  (orig: FUN_1405b32f0)
undefined8 * FUN_1405b32f0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTaskDetailActor::vftable;
  param_1[1] = adapter::CTaskDetailActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTaskDetailActor@adapter::vfunc_1  @1405b3340  [high:rtti-vtable]  (orig: FUN_1405b3340)
void FUN_1405b3340(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_7  @1405b3400  [high:rtti-vtable]  (orig: FUN_1405b3400)
bool FUN_1405b3400(longlong param_1,undefined4 param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = FUN_1402ae4a0(*(undefined8 *)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = *(longlong *)(lVar2 + 0x1118);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return false;
    }
    lVar1 = FUN_1403bb4f0(lVar2,*(undefined4 *)(param_3 + 8));
    if (lVar1 == 0) {
      lVar2 = FUN_1403bbd00(lVar2,param_3,1);
      return lVar2 != 0;
    }
  }
  return false;
}

// ==== CTaskDetailActor@adapter::vfunc_9  @1405b3520  [high:rtti-vtable]  (orig: FUN_1405b3520)
undefined4
FUN_1405b3520(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined8 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar2 = FUN_14008b0f0(uVar1);
  *param_2 = uVar2;
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar2 = FUN_14008b100(uVar1);
  *param_3 = uVar2;
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar2 = FUN_14008b110(uVar1);
  *param_4 = uVar2;
  return 1;
}

// ==== CTaskDetailActor@adapter::vfunc_10  @1405b3590  [high:rtti-vtable]  (orig: FUN_1405b3590)
void FUN_1405b3590(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b0c0(uVar1);
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_11  @1405b35b0  [high:rtti-vtable]  (orig: FUN_1405b35b0)
void FUN_1405b35b0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b0d0(uVar1);
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_12  @1405b35d0  [high:rtti-vtable]  (orig: FUN_1405b35d0)
void FUN_1405b35d0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b0e0(uVar1);
  return;
}

// ==== CTaskDetailActor@adapter::vfunc_13  @1405b35f0  [high:rtti-vtable]  (orig: FUN_1405b35f0)
void FUN_1405b35f0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b0b0(uVar1);
  return;
}

// ==== CTaskDetailActor@adapter::helper_1405b3620  @1405b3620  [medium:callgraph-r2]  (orig: FUN_1405b3620)
undefined8 * FUN_1405b3620(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x29) == '\0') {
    puVar1 = (undefined8 *)
             FUN_1403ba120(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 5),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1405b3620(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1405b3620(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CTaskDetailActor@adapter::helper_1405b36b0  @1405b36b0  [medium:callgraph-r1]  (orig: FUN_1405b36b0)
void FUN_1405b36b0(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1405b3620(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x29) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x29);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x29);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x29);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x29);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CTaskDetailActor@adapter::helper_1405b3760  @1405b3760  [medium:callgraph-r0]  (orig: FUN_1405b3760)
undefined8 *
FUN_1405b3760(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1403ba0c0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1405b36b0(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CTaskDetailActor@adapter::vfunc_2  @1405b3820  [high:rtti-vtable]  (orig: FUN_1405b3820)
ushort FUN_1405b3820(longlong param_1,undefined8 param_2,longlong param_3,ushort param_4)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  ushort uVar8;
  undefined1 local_88 [16];
  undefined1 local_78 [8];
  undefined8 uStack_70;
  undefined1 local_68 [16];
  longlong *local_58 [6];
  undefined8 *local_28;
  undefined8 local_20;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar5 == 0) {
    log_InlineLogERROR("CTaskDetailActor::GetTaskArray. User[%u]");
    uVar8 = 0;
  }
  else if (*(longlong *)(lVar5 + 0x1118) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else {
    uVar6 = FUN_1403b8d30();
    FUN_1405b3760(local_58,uVar6);
    plVar3 = local_58[0];
    puVar7 = (undefined8 *)*local_28;
    uVar8 = 0;
    while( true ) {
      puVar2 = local_28;
      if ((plVar3 == (longlong *)0x0) || (plVar3 != local_58[0])) {
        _invalid_parameter_noinfo();
      }
      if ((puVar7 == puVar2) || (param_4 <= uVar8)) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar3;
      }
      if (puVar7 == *(undefined8 **)(lVar5 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(undefined4 *)(param_3 + (ulonglong)uVar8 * 4) = *(undefined4 *)(puVar7 + 3);
      uVar8 = uVar8 + 1;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar2 = (undefined8 *)puVar7[2];
        if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)*puVar2 + 0x29);
          puVar7 = puVar2;
          puVar2 = (undefined8 *)*puVar2;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar2 + 0x29);
            puVar7 = puVar2;
            puVar2 = (undefined8 *)*puVar2;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar2 = puVar7;
          while ((puVar7 = puVar4, cVar1 == '\0' && (puVar2 == (undefined8 *)puVar7[2]))) {
            cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
            puVar4 = (undefined8 *)puVar7[1];
            puVar2 = puVar7;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    uStack_70 = *local_28;
    FUN_1403bb2f0(local_58,local_68,local_78,local_88);
    operator_delete(local_28);
    local_28 = (undefined8 *)0x0;
    local_20 = 0;
    operator_delete(local_58[0]);
  }
  return uVar8;
}

