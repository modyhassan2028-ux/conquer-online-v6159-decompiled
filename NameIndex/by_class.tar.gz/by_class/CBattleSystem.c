// ==== CBattleSystem::ctor_or_dtor  @1403e8ca0  [high:vtable-assign]  (orig: FUN_1403e8ca0)
undefined8 * FUN_1403e8ca0(undefined8 *param_1,undefined4 param_2,undefined8 param_3)

{
  *(undefined4 *)(param_1 + 3) = param_2;
  param_1[2] = param_3;
  *param_1 = CBattleSystem::vftable;
  *(undefined4 *)(param_1 + 1) = 0;
  return param_1;
}

// ==== CBattleSystem::helper_1403e93d0  @1403e93d0  [medium:callgraph-r0]  (orig: FUN_1403e93d0)
void FUN_1403e93d0(void *param_1)

{
  if ((DAT_140976308 & 1) == 0) {
    DAT_140976308 = DAT_140976308 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976300,"CBattleSystem");
    atexit((_func_5014 *)&LAB_1406d6d10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403e9425. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976300,param_1);
  return;
}

// ==== CBattleSystem::ctor_or_dtor  @1403e9490  [high:vtable-assign]  (orig: FUN_1403e9490)
undefined8 * FUN_1403e9490(undefined8 *param_1,byte param_2)

{
  *param_1 = CBattleSystem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403e93d0();
  }
  return param_1;
}

