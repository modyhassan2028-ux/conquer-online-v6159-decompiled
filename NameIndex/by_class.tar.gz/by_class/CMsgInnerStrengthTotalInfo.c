// ==== CMsgInnerStrengthTotalInfo::ctor_or_dtor  @1404dc0c0  [high:vtable-assign]  (orig: FUN_1404dc0c0)
undefined8 * FUN_1404dc0c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInnerStrengthTotalInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgInnerStrengthTotalInfo::ctor_or_dtor  @1404dc110  [high:vtable-assign]  (orig: FUN_1404dc110)
void FUN_1404dc110(undefined8 *param_1)

{
  *param_1 = CMsgInnerStrengthTotalInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgInnerStrengthTotalInfo::vfunc_5  @1404dc140  [high:rtti-vtable]  (orig: FUN_1404dc140)
bool FUN_1404dc140(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa34;
    }
  }
  return false;
}

// ==== CMsgInnerStrengthTotalInfo::vfunc_3  @1404dc2d0  [high:rtti-vtable]  (orig: FUN_1404dc2d0)
void FUN_1404dc2d0(void)

{
  return;
}

// ==== CMsgInnerStrengthTotalInfo::ctor_or_dtor  @1404dc2e0  [high:vtable-assign]  (orig: FUN_1404dc2e0)
undefined8 * FUN_1404dc2e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInnerStrengthTotalInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

