// ==== CMsgGameServer::ctor_or_dtor  @140076510  [high:vtable-assign]  (orig: FUN_140076510)
undefined8 * FUN_140076510(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgGameServer::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgGameServer::ctor_or_dtor  @140076560  [high:vtable-assign]  (orig: FUN_140076560)
void FUN_140076560(undefined8 *param_1)

{
  *param_1 = CMsgGameServer::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgGameServer::vfunc_1  @1400766f0  [high:rtti-vtable]  (orig: FUN_1400766f0)
ulonglong FUN_1400766f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 1099);
}

// ==== CMsgGameServer::ctor_or_dtor  @140076720  [high:vtable-assign]  (orig: FUN_140076720)
undefined8 * FUN_140076720(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGameServer::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

