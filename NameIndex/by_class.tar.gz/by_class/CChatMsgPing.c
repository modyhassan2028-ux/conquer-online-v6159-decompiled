// ==== CChatMsgPing::ctor_or_dtor  @14004bdc0  [high:vtable-assign]  (orig: FUN_14004bdc0)
undefined8 * FUN_14004bdc0(undefined8 *param_1)

{
  FUN_14003fc90();
  *param_1 = CChatMsgPing::vftable;
  FUN_14003f910(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CChatMsgPing::ctor_or_dtor  @14004be10  [high:vtable-assign]  (orig: FUN_14004be10)
void FUN_14004be10(undefined8 *param_1)

{
  *param_1 = CChatMsgPing::vftable;
  FUN_14003f900();
  return;
}

// ==== CChatMsgPing::vfunc_1  @14004be40  [high:rtti-vtable]  (orig: FUN_14004be40)
ulonglong FUN_14004be40(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_14003f950();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x40d);
}

// ==== CChatMsgPing::vfunc_3  @14004be70  [high:rtti-vtable]  (orig: FUN_14004be70)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14004be70(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  uint *puVar3;
  
  lVar2 = DAT_140975aa0;
  uVar1 = *(undefined4 *)(param_1 + 0x414);
  if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h");
  }
  puVar3 = (uint *)FUN_140042e80(*(undefined8 *)(lVar2 + 0x18),uVar1);
  if (puVar3 == (uint *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgping.cpp"
                      );
    return;
  }
  tq::MyLogSave("gmlog/zf_ping","ID[%u], Name[%s], IP[%d.%d.%d.%d], Ping[%u]",(ulonglong)*puVar3,
                puVar3 + 0xc);
  return;
}

// ==== CChatMsgPing::ctor_or_dtor  @14004bf80  [high:vtable-assign]  (orig: FUN_14004bf80)
undefined8 * FUN_14004bf80(undefined8 *param_1,uint param_2)

{
  *param_1 = CChatMsgPing::vftable;
  FUN_14003f900();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

