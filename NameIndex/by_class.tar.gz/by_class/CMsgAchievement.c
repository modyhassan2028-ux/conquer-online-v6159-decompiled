// ==== CMsgAchievement::helper_1401117f0  @1401117f0  [medium:callgraph-r1]  (orig: FUN_1401117f0)
undefined8 FUN_1401117f0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x98) != 0) {
    uVar1 = FUN_1403761c0();
    return uVar1;
  }
  return 0;
}

// ==== CMsgAchievement::helper_140160840  @140160840  [medium:callgraph-r2]  (orig: FUN_140160840)
undefined4 FUN_140160840(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xdc4);
}

// ==== CMsgAchievement::helper_1401628d0  @1401628d0  [medium:callgraph-r0]  (orig: FUN_1401628d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401628d0(longlong *param_1,undefined8 param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_1[0x167] == 0) {
    lVar3 = DAT_140975b68;
    if (DAT_140975b68 == 0) {
      local_468 = 0x3c1;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    if (*(char *)(lVar3 + 0x51) != '\0') {
      FUN_1403778c0(local_448);
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      cVar1 = FUN_1403779f0(local_448,1,uVar2,0);
      if (cVar1 != '\0') {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
      }
      FUN_140377910(local_448);
      return;
    }
  }
  FUN_140376a30(param_1[0x167],param_2);
  return;
}

// ==== CMsgAchievement::helper_140223a30  @140223a30  [medium:callgraph-r1]  (orig: FUN_140223a30)
/* WARNING: Type propagation algorithm not settling */

undefined8 FUN_140223a30(undefined4 *param_1,int param_2,uint param_3,undefined4 param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  bool bVar11;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    return 0;
  }
  uVar5 = FUN_140008520(*param_1);
  plVar6 = (longlong *)FUN_140087650(uVar5);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,param_2);
  if ((plVar6 == (longlong *)0x0) || (cVar1 = FUN_140171090(plVar6,param_3), cVar1 != '\0'))
  goto switchD_140223ae5_caseD_285d;
  if (0x2b7c < param_3) {
    switch(param_3) {
    case 0x2bca:
      uVar5 = 0x952b8;
      break;
    case 0x2bcb:
      uVar5 = 0x956a0;
      break;
    case 0x2bcc:
      uVar5 = 0x7cc18;
      break;
    case 0x2bcd:
      uVar5 = 0x95a88;
      break;
    case 0x2bce:
      uVar5 = 0x95e70;
      break;
    case 0x2bcf:
      uVar5 = 0x96640;
      break;
    default:
      goto switchD_140223ae5_caseD_285d;
    case 0x2bd5:
      uVar5 = 0x96a28;
      break;
    case 0x2bd6:
      uVar5 = 620000;
    }
LAB_1402243f2:
    uVar4 = FUN_140162250(plVar6,uVar5);
    if (0xb < uVar4) goto switchD_140223ae5_caseD_28bf;
    goto switchD_140223ae5_caseD_285d;
  }
  if (param_3 == 0x2b7c) {
    uVar5 = 900000;
    goto LAB_1402243f2;
  }
  switch(param_3) {
  case 0x2846:
    uVar4 = (**(code **)(plVar6[2] + 0x70))(plVar6 + 2);
    if (uVar4 < 0x82) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2847:
    uVar4 = (**(code **)(plVar6[2] + 0x70))(plVar6 + 2);
    if (uVar4 < 0x8c) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2848:
    iVar3 = FUN_14018eb30(plVar6);
    if (iVar3 < 100) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2849:
    iVar3 = FUN_14018eb30(plVar6);
    if (iVar3 < 200) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x284a:
    iVar3 = FUN_14018eb30(plVar6);
    if (iVar3 < 300) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x284b:
    iVar3 = (**(code **)(*plVar6 + 0x108))(plVar6);
    goto joined_r0x000140224096;
  case 0x284c:
    uVar4 = (**(code **)(*plVar6 + 0x108))(plVar6);
    if (uVar4 < 2) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x284d:
    if (*(uint *)(plVar6 + 0x1e5) < 5000) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x284e:
    iVar3 = (**(code **)(plVar6[2] + 0x198))(plVar6 + 2);
    goto joined_r0x000140224096;
  case 0x284f:
    lVar9 = FUN_1401669e0(plVar6);
    if (lVar9 < 1) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2850:
    iVar3 = FUN_140165930(plVar6);
joined_r0x000140224096:
    if (iVar3 == 0) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2851:
    uVar4 = FUN_140162250(plVar6,0);
    break;
  case 0x2852:
    uVar4 = FUN_140162250(plVar6,420000);
    break;
  case 0x2853:
    uVar4 = FUN_140162250(plVar6,410000);
    break;
  case 0x2854:
    uVar4 = FUN_140162250(plVar6,460000);
    break;
  case 0x2855:
    uVar4 = FUN_140162250(plVar6,540000);
    break;
  case 0x2856:
    uVar4 = FUN_140162250(plVar6,580000);
    break;
  case 0x2857:
    uVar4 = FUN_140162250(plVar6,560000);
    break;
  case 0x2858:
    uVar4 = FUN_140162250(plVar6,490000);
    break;
  case 0x2859:
    uVar4 = FUN_140162250(plVar6,0x88f68);
    break;
  case 0x285a:
    uVar4 = FUN_140162250(plVar6,510000);
    break;
  case 0x285b:
    uVar4 = FUN_140162250(plVar6,530000);
    break;
  case 0x285c:
    uVar4 = FUN_140162250(plVar6,430000);
    break;
  default:
    goto switchD_140223ae5_caseD_285d;
  case 0x28a1:
    uVar4 = FUN_140162250(plVar6,450000);
    break;
  case 0x28a2:
    uVar4 = FUN_140162250(plVar6,480000);
    break;
  case 0x28a3:
    uVar4 = FUN_140162250(plVar6,0x756e8);
    break;
  case 0x28a4:
    uVar4 = FUN_140162250(plVar6,440000);
    break;
  case 0x28a5:
    uVar4 = FUN_140162250(plVar6,500000);
    break;
  case 0x28a6:
    uVar4 = FUN_140162250(plVar6,610000);
    break;
  case 0x28a7:
    uVar4 = FUN_140162250(plVar6,0x92ba8);
    break;
  case 0x28a8:
    uVar4 = FUN_140162250(plVar6,0x66c88);
    break;
  case 0x28a9:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,param_4);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    if (lVar9 != 0) {
      cVar1 = FUN_14016c970(lVar9);
      goto joined_r0x0001402240f0;
    }
    goto switchD_140223ae5_caseD_285d;
  case 0x28aa:
    cVar1 = FUN_140331650(plVar6,1,7);
    goto joined_r0x0001402240f0;
  case 0x28ab:
    cVar1 = FUN_140331650(plVar6,1,8);
    goto joined_r0x0001402240f0;
  case 0x28ac:
    cVar1 = FUN_140331650(plVar6,1,9);
    goto joined_r0x0001402240f0;
  case 0x28ad:
    cVar1 = FUN_140331650(plVar6,2);
    goto joined_r0x0001402240f0;
  case 0x28ae:
    cVar1 = FUN_140331650(plVar6,3);
    goto joined_r0x0001402240f0;
  case 0x28af:
    cVar1 = FUN_140331650(plVar6,4,1);
    goto joined_r0x0001402240f0;
  case 0x28b0:
    cVar1 = FUN_140331650(plVar6,5);
    goto joined_r0x0001402240f0;
  case 0x28b1:
    cVar1 = FUN_140331650(plVar6,1,9);
    if ((((cVar1 != '\0') && (cVar1 = FUN_140331650(plVar6,4,2), cVar1 != '\0')) &&
        (cVar1 = FUN_140331650(plVar6,2), cVar1 != '\0')) &&
       (cVar1 = FUN_140331650(plVar6,5), cVar1 != '\0')) {
      cVar1 = FUN_140331650(plVar6,3);
      goto joined_r0x0001402240f0;
    }
    goto switchD_140223ae5_caseD_285d;
  case 0x28b2:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,param_4);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    if (lVar9 == 0) goto switchD_140223ae5_caseD_285d;
    uVar2 = FUN_1400fda10(lVar9,1,1);
    iVar3 = FUN_1400ff680(uVar2);
    if (iVar3 != 0xc) {
      uVar2 = FUN_1400fda10(lVar9,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 0xd) {
        uVar2 = FUN_1400fda10(lVar9,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        bVar11 = iVar3 == 0x16;
        goto LAB_140224374;
      }
    }
    goto switchD_140223ae5_caseD_28bf;
  case 0x28b3:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,9);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
joined_r0x00014022414a:
    if (lVar9 == 0) goto switchD_140223ae5_caseD_285d;
    goto switchD_140223ae5_caseD_28bf;
  case 0x28bc:
    cVar1 = FUN_14032d980(plVar6);
    goto joined_r0x0001402240f0;
  case 0x28bd:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,param_4);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    if (lVar9 != 0) {
      iVar3 = FUN_1400fda10(lVar9,8,1);
      goto joined_r0x000140224096;
    }
    goto switchD_140223ae5_caseD_285d;
  case 0x28be:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,param_4);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    if ((lVar9 == 0) || (iVar3 = FUN_1400fda10(lVar9,0xc,1), iVar3 < 1))
    goto switchD_140223ae5_caseD_285d;
  case 0x28bf:
  case 0x2905:
  case 0x2906:
    goto switchD_140223ae5_caseD_28bf;
  case 0x28c0:
    cVar1 = FUN_14033a250(plVar6);
joined_r0x0001402240f0:
    if (cVar1 != '\0') goto switchD_140223ae5_caseD_28bf;
    goto switchD_140223ae5_caseD_285d;
  case 0x2907:
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,0xf);
    lVar8 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    plVar7 = (longlong *)FUN_140087d40();
    lVar9 = *plVar7;
    uVar2 = FUN_140337820(plVar6,0x10);
    lVar9 = (**(code **)(lVar9 + 0x60))(plVar7,uVar2);
    if (lVar8 == 0) goto joined_r0x00014022414a;
    goto switchD_140223ae5_caseD_28bf;
  case 0x2908:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    lVar9 = FUN_1402f2760(uVar5,param_2,0x415);
    if (lVar9 == 0) goto switchD_140223ae5_caseD_285d;
    iVar3 = FUN_140418c50(lVar9,3);
    bVar11 = iVar3 == 4;
    goto LAB_140224374;
  case 0x2909:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    lVar9 = FUN_1402f2760(uVar5,param_2,0x416);
    if (lVar9 != 0) {
      iVar3 = FUN_140418c50(lVar9,3);
      bVar11 = iVar3 == 4;
      goto LAB_140224374;
    }
    goto switchD_140223ae5_caseD_285d;
  case 0x290a:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x13a6;
    goto LAB_140224354;
  case 0x290b:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x13b0;
    goto LAB_140224354;
  case 0x290c:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x514;
    goto LAB_140224354;
  case 0x290d:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x139c;
    goto LAB_140224354;
  case 0x290e:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x4ec;
    goto LAB_140224354;
  case 0x290f:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x50a;
    goto LAB_140224354;
  case 0x2910:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x1392;
    goto LAB_140224354;
  case 0x2911:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x4e2;
    goto LAB_140224354;
  case 0x2912:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x13ba;
    goto LAB_140224354;
  case 0x2913:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 7000;
    goto LAB_140224354;
  case 0x2914:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x1b62;
    goto LAB_140224354;
  case 0x2915:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x1b6c;
    goto LAB_140224354;
  case 0x2916:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x1b76;
    goto LAB_140224354;
  case 0x2917:
    uVar5 = FUN_140008520(*param_1);
    uVar5 = FUN_1400877e0(uVar5);
    uVar10 = 0x1b80;
LAB_140224354:
    lVar9 = FUN_1402f2760(uVar5,param_2,uVar10);
    if (lVar9 != 0) {
      iVar3 = FUN_140418c50(lVar9,3);
      bVar11 = iVar3 == 9;
LAB_140224374:
      if (bVar11) goto switchD_140223ae5_caseD_28bf;
    }
    goto switchD_140223ae5_caseD_285d;
  }
  if (uVar4 < 0xc) {
switchD_140223ae5_caseD_285d:
    uVar5 = 0;
  }
  else {
switchD_140223ae5_caseD_28bf:
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CMsgAchievement::helper_140224620  @140224620  [medium:callgraph-r1]  (orig: FUN_140224620)
ulonglong FUN_140224620(undefined4 *param_1,int param_2,int param_3)

{
  uint uVar1;
  ulonglong in_RAX;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  uint uVar5;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar2 = FUN_140008520(*param_1);
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,param_2);
    in_RAX = 0;
    if ((lVar4 != 0) && (in_RAX = FUN_140171090(lVar4,param_3), (char)in_RAX == '\0')) {
      in_RAX = 0;
      switch(param_3) {
      case 0x2918:
        uVar1 = *(uint *)(lVar4 + 0xa6c);
        in_RAX = (ulonglong)uVar1;
        uVar5 = *(uint *)(lVar4 + 0xa70);
        if ((int)*(uint *)(lVar4 + 0xa70) < (int)uVar1) {
          uVar5 = uVar1;
        }
        if (9 < (int)uVar5) {
          return CONCAT71((uint7)(uint3)(uVar1 >> 8),1);
        }
        break;
      case 0x2919:
        uVar1 = *(uint *)(lVar4 + 0xa6c);
        in_RAX = (ulonglong)uVar1;
        uVar5 = *(uint *)(lVar4 + 0xa70);
        if ((int)*(uint *)(lVar4 + 0xa70) < (int)uVar1) {
          uVar5 = uVar1;
        }
        if (99 < (int)uVar5) {
          return CONCAT71((uint7)(uint3)(uVar1 >> 8),1);
        }
        break;
      case 0x291a:
        uVar1 = *(uint *)(lVar4 + 0xa6c);
        in_RAX = (ulonglong)uVar1;
        uVar5 = *(uint *)(lVar4 + 0xa70);
        if ((int)*(uint *)(lVar4 + 0xa70) < (int)uVar1) {
          uVar5 = uVar1;
        }
        if (299 < (int)uVar5) goto switchD_1402246a4_caseD_291d;
        break;
      case 0x291d:
      case 0x296d:
      case 0x296e:
      case 0x296f:
      case 0x2973:
switchD_1402246a4_caseD_291d:
        return CONCAT71((int7)(in_RAX >> 8),1);
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgAchievement::helper_140224790  @140224790  [medium:callgraph-r1]  (orig: FUN_140224790)
undefined8 FUN_140224790(undefined4 *param_1,int param_2,int param_3)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar4 = FUN_140008520(*param_1);
    plVar5 = (longlong *)FUN_140087650(uVar4);
    lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
    if ((lVar6 != 0) &&
       ((cVar1 = FUN_140171090(lVar6,param_3), cVar1 == '\0' &&
        (plVar5 = (longlong *)(**(code **)(*(longlong *)(lVar6 + 0x10) + 0x160))(lVar6 + 0x10),
        plVar5 != (longlong *)0x0)))) {
      switch(param_3) {
      case 0x2974:
      case 0x2975:
      case 0x2976:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3ea) {
          return 1;
        }
        break;
      case 0x2977:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3eb) {
          return 1;
        }
        break;
      case 0x2978:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x404) {
          return 1;
        }
        break;
      case 0x2979:
      case 0x297a:
      case 0x297b:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3f3) {
          return 1;
        }
        break;
      case 0x297c:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3f5) {
          return 1;
        }
        break;
      case 0x297d:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3f8) {
          return 1;
        }
        break;
      case 0x297e:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3f6) {
          return 1;
        }
        break;
      case 0x297f:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x434) {
          return 1;
        }
        break;
      case 0x2980:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x401) {
          return 1;
        }
        break;
      case 0x2981:
      case 0x2982:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3fc) {
          return 1;
        }
        break;
      case 0x2983:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x433) {
          return 1;
        }
        break;
      case 0x2984:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x402) {
          return 1;
        }
        break;
      case 0x2985:
      case 0x2987:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3f7) {
          return 1;
        }
        break;
      case 0x2986:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x436) {
          return 1;
        }
        break;
      case 0x29cd:
      case 0x29ce:
      case 0x29d0:
      case 0x29d3:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 1000) {
          return 1;
        }
        break;
      case 0x29cf:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x3e9) {
          return 1;
        }
        break;
      case 0x29d1:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x435) {
          return 1;
        }
        break;
      case 0x29d2:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x403) {
          return 1;
        }
        break;
      case 0x29d4:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b5) {
          return 1;
        }
        break;
      case 0x29d5:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b2) {
          return 1;
        }
        break;
      case 0x29d6:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b1) {
          return 1;
        }
        break;
      case 0x29d7:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b4) {
          return 1;
        }
        break;
      case 0x29d8:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4c0) {
          return 1;
        }
        break;
      case 0x29d9:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b7) {
          return 1;
        }
        break;
      case 0x29da:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4b8) {
          return 1;
        }
        break;
      case 0x29db:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4ba) {
          return 1;
        }
        break;
      case 0x29dc:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4bb) {
          return 1;
        }
        break;
      case 0x29dd:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4bc) {
          return 1;
        }
        break;
      case 0x29de:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4c3) {
          return 1;
        }
        break;
      case 0x29df:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4c1) {
          return 1;
        }
        break;
      case 0x29e0:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4bf) {
          return 1;
        }
        break;
      case 0x29e1:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4be) {
          return 1;
        }
        break;
      case 0x29e2:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x4c2) {
          return 1;
        }
        break;
      case 0x29e3:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x550) {
          return 1;
        }
        break;
      case 0x29e4:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x551) {
          return 1;
        }
        break;
      case 0x29e5:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x552) {
          return 1;
        }
        break;
      case 0x29e6:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x553) {
          return 1;
        }
        break;
      case 0x29e7:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x554) {
          return 1;
        }
        break;
      case 0x29e8:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x555) {
          return 1;
        }
        break;
      case 0x29e9:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x547) {
          return 1;
        }
        break;
      case 0x29ea:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x548) {
          return 1;
        }
        break;
      case 0x29eb:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x549) {
          return 1;
        }
        break;
      case 0x29ec:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x54a) {
          return 1;
        }
        break;
      case 0x2a31:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x786) {
          return 1;
        }
        break;
      case 0x2a32:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x787) {
          return 1;
        }
        break;
      case 0x2a33:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 1999) {
          return 1;
        }
        break;
      case 0x2a34:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x806) {
          return 1;
        }
        break;
      case 0x2a35:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x807) {
          return 1;
        }
        break;
      case 0x2a36:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x808) {
          return 1;
        }
        break;
      case 0x2a37:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x40f) {
          return 1;
        }
        break;
      case 0x2a38:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x70e) {
          return 1;
        }
        break;
      case 0x2a39:
        uVar2 = (**(code **)(*plVar5 + 8))(plVar5);
        if ((1099 < uVar2) && (uVar2 = (**(code **)(*plVar5 + 8))(plVar5), uVar2 < 0x456)) {
          return 1;
        }
        break;
      case 0x2a3a:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x40e) {
          return 1;
        }
        break;
      case 0x2a3b:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x6e6) {
          return 1;
        }
        break;
      case 0x2a3c:
        iVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        if (iVar3 == 0x40c) {
          return 1;
        }
      }
    }
  }
  return 0;
}

// ==== CMsgAchievement::helper_140225100  @140225100  [medium:callgraph-r1]  (orig: FUN_140225100)
undefined8 FUN_140225100(undefined4 *param_1,int param_2,uint param_3,undefined4 param_4)

{
  char cVar1;
  byte bVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined4 uVar8;
  bool bVar9;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    return 0;
  }
  uVar4 = FUN_140008520(*param_1);
  plVar5 = (longlong *)FUN_140087650(uVar4);
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x98))(plVar5,param_2);
  if ((plVar5 == (longlong *)0x0) || (cVar1 = FUN_140171090(plVar5,param_3), cVar1 != '\0'))
  goto switchD_1402251b1_caseD_2a42;
  if (0x2bc1 < param_3) {
    switch(param_3) {
    case 0x2bc2:
      uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      uVar7 = FUN_140008520(*param_1);
      uVar7 = FUN_140117ed0(uVar7);
      bVar2 = FUN_140152480(uVar7,uVar3,uVar4,9,0);
      if (8 < bVar2) {
        return 1;
      }
      goto switchD_1402251b1_caseD_2a42;
    case 0x2bc3:
      uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      uVar7 = FUN_140008520(*param_1);
      uVar7 = FUN_140117ed0(uVar7);
      uVar8 = 2;
      goto LAB_14022558a;
    case 0x2bc4:
      uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      uVar7 = FUN_140008520(*param_1);
      uVar7 = FUN_140117ed0(uVar7);
      bVar2 = FUN_140152480(uVar7,uVar3,uVar4,2,0);
      if (bVar2 < 9) goto switchD_1402251b1_caseD_2a42;
      break;
    case 0x2bc5:
    case 0x2bc6:
    case 0x2bc7:
    case 0x2bc8:
    case 0x2bc9:
    case 0x2bd0:
    case 0x2bd1:
    case 0x2bd2:
    case 0x2bd3:
    case 0x2bd4:
      break;
    default:
      goto switchD_1402251b1_caseD_2a42;
    }
    goto switchD_1402251b1_caseD_2a3d;
  }
  if (param_3 == 0x2bc1) {
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 9;
    goto LAB_14022558a;
  }
  switch(param_3) {
  case 0x2a3d:
  case 0x2a3e:
  case 0x2a3f:
  case 0x2a40:
  case 0x2a41:
  case 0x2a43:
  case 0x2a44:
  case 0x2a45:
  case 0x2a46:
  case 0x2a47:
  case 0x2a48:
  case 0x2a49:
  case 0x2a4a:
  case 0x2a4b:
  case 0x2a4c:
  case 0x2a4d:
  case 0x2a4e:
  case 0x2a4f:
  case 0x2a50:
  case 0x2a95:
  case 0x2a96:
  case 0x2a97:
  case 0x2a98:
  case 0x2a99:
  case 0x2a9a:
  case 0x2a9b:
  case 0x2a9c:
  case 0x2a9d:
  case 0x2a9e:
  case 0x2a9f:
  case 0x2aa0:
  case 0x2aa1:
  case 0x2aa2:
  case 0x2aa3:
  case 0x2aa4:
  case 0x2aa5:
    goto switchD_1402251b1_caseD_2a3d;
  default:
    goto switchD_1402251b1_caseD_2a42;
  case 0x2aa7:
    uVar4 = FUN_140008520(*param_1);
    uVar4 = FUN_1400878d0(uVar4);
    lVar6 = FUN_14024e590(uVar4,param_2);
    if (lVar6 != 0) {
      uVar3 = FUN_14041db90(param_4);
      lVar6 = FUN_14041b530(lVar6,uVar3);
      if (lVar6 != 0) {
        return 1;
      }
    }
    goto switchD_1402251b1_caseD_2a42;
  case 0x2aa8:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 5;
    goto LAB_14022558a;
  case 0x2aa9:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    bVar2 = FUN_140152480(uVar7,uVar3,uVar4,5,0);
    bVar9 = bVar2 < 9;
    break;
  case 0x2aaa:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 1;
    goto LAB_14022558a;
  case 0x2aab:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    bVar2 = FUN_140152480(uVar7,uVar3,uVar4,1,0);
    bVar9 = bVar2 < 9;
    break;
  case 0x2aac:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 3;
    goto LAB_14022558a;
  case 0x2aad:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    bVar2 = FUN_140152480(uVar7,uVar3,uVar4,3,0);
    bVar9 = bVar2 < 9;
    break;
  case 0x2aae:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 4;
    goto LAB_14022558a;
  case 0x2aaf:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    bVar2 = FUN_140152480(uVar7,uVar3,uVar4,4,0);
    bVar9 = bVar2 < 9;
    break;
  case 0x2ab0:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    uVar8 = 6;
LAB_14022558a:
    cVar1 = FUN_140152480(uVar7,uVar3,uVar4,uVar8,0);
    bVar9 = cVar1 == '\0';
    break;
  case 0x2ab1:
    uVar4 = (**(code **)(plVar5[2] + 0x1d8))(plVar5 + 2);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    uVar7 = FUN_140008520(*param_1);
    uVar7 = FUN_140117ed0(uVar7);
    bVar2 = FUN_140152480(uVar7,uVar3,uVar4,6,0);
    bVar9 = bVar2 < 9;
  }
  if (bVar9) {
switchD_1402251b1_caseD_2a42:
    uVar4 = 0;
  }
  else {
switchD_1402251b1_caseD_2a3d:
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgAchievement::helper_1402256f0  @1402256f0  [medium:callgraph-r1]  (orig: FUN_1402256f0)
undefined8 FUN_1402256f0(undefined4 *param_1,int param_2,int param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar5 = FUN_140008520(*param_1);
    plVar6 = (longlong *)FUN_140087650(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,param_2);
    if ((plVar6 != (longlong *)0x0) &&
       ((cVar1 = FUN_140171090(plVar6,param_3), cVar1 == '\0' &&
        (lVar7 = (**(code **)(plVar6[2] + 0x160))(plVar6 + 2), lVar7 != 0)))) {
      switch(param_3) {
      case 0x2b16:
        iVar2 = (**(code **)(*plVar6 + 0x108))(plVar6);
        if (iVar2 != 0) {
          return 1;
        }
        break;
      case 0x2b17:
        uVar4 = (**(code **)(*plVar6 + 0x108))(plVar6);
        if (1 < uVar4) {
          return 1;
        }
        break;
      case 0x2b18:
      case 0x2b5d:
      case 0x2b5e:
      case 0x2b5f:
      case 0x2b60:
      case 0x2b61:
      case 0x2b62:
      case 0x2b63:
      case 0x2b64:
      case 0x2b65:
        return 1;
      case 0x2b67:
        iVar2 = FUN_140165850(plVar6);
        iVar3 = FUN_140165870(plVar6);
        if (0x13 < (uint)(iVar2 + iVar3)) {
          return 1;
        }
        break;
      case 0x2b68:
        uVar4 = FUN_140165850(plVar6);
        if (8 < uVar4) {
          return 1;
        }
        break;
      case 0x2b69:
        if (param_4 != 0) {
          uVar5 = FUN_140008520(*param_1);
          uVar5 = FUN_140117db0(uVar5);
          lVar7 = FUN_14020ba80(uVar5,param_4);
          if ((lVar7 != 0) && (cVar1 = FUN_14037f430(lVar7,plVar6), cVar1 != '\0')) {
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgAchievement::helper_1402258b0  @1402258b0  [medium:callgraph-r1]  (orig: FUN_1402258b0)
undefined8 FUN_1402258b0(undefined4 *param_1,int param_2,int param_3,int param_4)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    return 0;
  }
  uVar4 = FUN_140008520(*param_1);
  plVar5 = (longlong *)FUN_140087650(uVar4);
  lVar6 = (**(code **)(*plVar5 + 0x98))(plVar5,param_2);
  if ((lVar6 != 0) && (cVar1 = FUN_140171090(lVar6,param_3), cVar1 == '\0')) {
    lVar7 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x160))(lVar6 + 0x10);
    if (lVar7 != 0) {
      if (param_3 == 0x2b70) {
        iVar3 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x198))(lVar6 + 0x10);
        if (iVar3 == 0xc) {
          return 1;
        }
      }
      else if (param_3 == 0x2b72) {
        if (param_4 != 0) {
          uVar4 = FUN_140008520(*param_1);
          uVar4 = FUN_140117db0(uVar4);
          lVar7 = FUN_14020ba80(uVar4,param_4);
          if ((lVar7 != 0) && (cVar1 = FUN_14037f150(lVar7,lVar6), cVar1 != '\0')) {
            return 1;
          }
        }
      }
      else if (param_3 == 0x2b73) {
        plVar5 = (longlong *)CurrentInstanceGet();
        if ((plVar5 != (longlong *)0x0) &&
           (plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,5), plVar5 != (longlong *)0x0)
           ) {
          lVar7 = *plVar5;
          uVar2 = FUN_140373040(lVar6 + 0xe78);
          iVar3 = (**(code **)(lVar7 + 8))(plVar5,uVar2);
          if (3 < iVar3) {
            return 1;
          }
        }
      }
      else if (((param_3 == 0x2b78) &&
               (plVar5 = (longlong *)CurrentInstanceGet(), plVar5 != (longlong *)0x0)) &&
              (plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,5),
              plVar5 != (longlong *)0x0)) {
        uVar4 = (**(code **)(*plVar5 + 0x10))(plVar5,param_2);
        return uVar4;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CMsgAchievement::helper_140225a50  @140225a50  [medium:callgraph-r1]  (orig: FUN_140225a50)
undefined1 *
FUN_140225a50(undefined4 *param_1,ulonglong param_2,ulonglong param_3,ulonglong param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined1 local_78 [8];
  undefined8 uStack_70;
  undefined1 local_68 [8];
  undefined8 uStack_60;
  undefined1 local_58 [16];
  longlong *local_48 [6];
  undefined8 *local_18;
  undefined8 local_10;
  
  if ((int)param_2 == 0) {
    return &stack0x00000000;
  }
  if ((int)param_3 == 0) {
    return &stack0x00000000;
  }
  uVar5 = FUN_140008520(*param_1,param_2,param_3,param_4,0xfffffffffffffffe);
  plVar6 = (longlong *)FUN_140087650(uVar5);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,param_2 & 0xffffffff);
  if (plVar6 == (longlong *)0x0) {
    return (undefined1 *)0x0;
  }
  cVar3 = FUN_140171090(plVar6,param_3 & 0xffffffff);
  if (cVar3 == '\0') {
    switch((int)param_3) {
    case 0x2775:
    case 0x2780:
    case 0x2784:
    case 0x2786:
    case 0x2789:
    case 0x278f:
    case 0x2790:
    case 0x2792:
    case 0x27d9:
    case 0x27db:
    case 0x27dd:
    case 0x27de:
    case 0x27df:
    case 0x27e0:
    case 0x27e1:
    case 0x27e2:
    case 0x27e3:
    case 0x27e4:
    case 0x27e5:
    case 0x27e6:
    case 0x27e7:
    case 0x27e8:
    case 0x27e9:
    case 0x27f3:
    case 0x27f6:
    case 0x27f8:
    case 0x2840:
      return (undefined1 *)0x1;
    case 0x277a:
      lVar7 = (**(code **)(*plVar6 + 0x60))(plVar6);
      if (2999999 < lVar7) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x277b:
      iVar4 = FUN_140160840(plVar6);
      if (iVar4 != 0) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x277c:
      iVar4 = FUN_140160850(plVar6);
      if (iVar4 == 0xc) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x2787:
      FUN_1401af3c0(local_48);
      FUN_1401aa6b0(plVar6,3,local_48);
      plVar6 = local_48[0];
      puVar8 = (undefined8 *)*local_18;
      while( true ) {
        puVar1 = local_18;
        if ((plVar6 == (longlong *)0x0) || (plVar6 != local_48[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar8 == puVar1) break;
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar6;
        }
        if (puVar8 == *(undefined8 **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (((longlong *)puVar8[3] != (longlong *)0x0) &&
           (iVar4 = (**(code **)(*(longlong *)puVar8[3] + 0x50))(), iVar4 == 0x232b)) {
          uStack_60 = *local_18;
          FUN_140197890(local_48,local_58,local_68,local_78);
          operator_delete(local_18);
          local_18 = (undefined8 *)0x0;
          local_10 = 0;
          operator_delete(local_48[0]);
          return (undefined1 *)0x1;
        }
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
          puVar1 = (undefined8 *)puVar8[2];
          if (*(char *)((longlong)puVar1 + 0x21) == '\0') {
            cVar3 = *(char *)((longlong)*puVar1 + 0x21);
            puVar8 = puVar1;
            puVar1 = (undefined8 *)*puVar1;
            while (cVar3 == '\0') {
              cVar3 = *(char *)((longlong)*puVar1 + 0x21);
              puVar8 = puVar1;
              puVar1 = (undefined8 *)*puVar1;
            }
          }
          else {
            cVar3 = *(char *)((longlong)puVar8[1] + 0x21);
            puVar2 = (undefined8 *)puVar8[1];
            puVar1 = puVar8;
            while ((puVar8 = puVar2, cVar3 == '\0' && (puVar1 == (undefined8 *)puVar8[2]))) {
              cVar3 = *(char *)((longlong)puVar8[1] + 0x21);
              puVar2 = (undefined8 *)puVar8[1];
              puVar1 = puVar8;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      uStack_70 = *local_18;
      FUN_140197890(local_48,local_58,local_78,local_68);
      operator_delete(local_18);
      local_18 = (undefined8 *)0x0;
      local_10 = 0;
      operator_delete(local_48[0]);
      break;
    case 0x278b:
      plVar6 = (longlong *)FUN_1401183a0();
      lVar7 = (**(code **)(*plVar6 + 0x148))(plVar6,param_2 & 0xffffffff);
      if (lVar7 != 0) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x278c:
      plVar6 = (longlong *)CurrentInstanceGet();
      if (((plVar6 != (longlong *)0x0) &&
          (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0x10),
          plVar6 != (longlong *)0x0)) &&
         (iVar4 = (**(code **)(*plVar6 + 0x88))(plVar6,param_2 & 0xffffffff,2), 0 < iVar4)) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x278d:
      plVar6 = (longlong *)CurrentInstanceGet();
      if (((plVar6 != (longlong *)0x0) &&
          (plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0x10),
          plVar6 != (longlong *)0x0)) &&
         (iVar4 = (**(code **)(*plVar6 + 0x30))(plVar6,param_2 & 0xffffffff,2), iVar4 != 0)) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x278e:
      plVar6 = (longlong *)FUN_1401183a0();
      lVar7 = (**(code **)(*plVar6 + 0xf0))(plVar6,param_2 & 0xffffffff);
      if (lVar7 != 0) {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27ea:
      iVar4 = (**(code **)(plVar6[2] + 0x170))();
      if (iVar4 != 0) {
        plVar6 = (longlong *)FUN_140087ed0();
        iVar4 = (**(code **)(*plVar6 + 0xf8))(plVar6,param_2 & 0xffffffff);
        if (iVar4 == 200) {
          return (undefined1 *)0x1;
        }
      }
      break;
    case 0x27eb:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0x78))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27ed:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0x80))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27ee:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0x88))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27ef:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0x90))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27f0:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0x98))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27f1:
      plVar6 = (longlong *)FUN_140087ed0();
      cVar3 = (**(code **)(*plVar6 + 0xa0))(plVar6,param_2 & 0xffffffff);
      if (cVar3 != '\0') {
        return (undefined1 *)0x1;
      }
      break;
    case 0x27f2:
      if ((int)param_4 != 0) {
        plVar6 = (longlong *)FUN_140087f50();
        cVar3 = (**(code **)(*plVar6 + 0x50))(plVar6,param_2 & 0xffffffff,param_4 & 0xffffffff);
        if (cVar3 != '\0') {
          return (undefined1 *)0x1;
        }
      }
    }
    return (undefined1 *)0x0;
  }
  return (undefined1 *)0x0;
}

// ==== CMsgAchievement::helper_140226070  @140226070  [medium:callgraph-r0]  (orig: FUN_140226070)
undefined1 FUN_140226070(undefined8 param_1,int param_2,int param_3,undefined4 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    uVar1 = 0;
  }
  else {
    lVar3 = DAT_140975b68;
    if (DAT_140975b68 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    iVar2 = FUN_1401117f0(lVar3,param_3);
    uVar1 = 0;
    if (iVar2 != 0) {
      uVar1 = 0;
      if (iVar2 - 10000U < 10000) {
        uVar1 = FUN_140225a50(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 20000U < 10000) {
        uVar1 = FUN_140223a30(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 30000U < 10000) {
        uVar1 = FUN_140224620(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 40000U < 10000) {
        uVar1 = FUN_140224790(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 50000U < 10000) {
        uVar1 = FUN_140225100(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 60000U < 10000) {
        uVar1 = FUN_1402256f0(param_1,param_2,param_3,param_4);
      }
      else if (iVar2 - 70000U < 10000) {
        uVar1 = FUN_1402258b0(param_1,param_2,param_3,param_4);
      }
    }
  }
  return uVar1;
}

// ==== CMsgAchievement::helper_14032d980  @14032d980  [medium:callgraph-r2]  (orig: FUN_14032d980)
bool FUN_14032d980(undefined8 param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  int iVar6;
  
  iVar6 = 1;
  plVar4 = (longlong *)0x0;
  do {
    if ((((iVar6 != 7) && (iVar6 != 0xf)) && (iVar6 != 0x10)) && (iVar6 != 0x11)) {
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = (longlong *)0x0;
      }
      lVar3 = *plVar5;
      uVar1 = FUN_14032b4b0(param_1,iVar6);
      lVar3 = (**(code **)(lVar3 + 0x60))(plVar5,uVar1);
      if (lVar3 != 0) {
        iVar2 = FUN_1400fda10(lVar3,4,1);
        if (iVar2 != 0) {
          iVar2 = FUN_1400fda10(lVar3,8,1);
          if (iVar2 % 10 == 3) {
            plVar4 = (longlong *)(ulonglong)((int)plVar4 + 1);
          }
          iVar2 = FUN_1400fda10(lVar3,9,1);
          if (iVar2 % 10 == 3) {
            plVar4 = (longlong *)(ulonglong)((int)plVar4 + 1);
          }
        }
      }
    }
    iVar6 = iVar6 + 1;
  } while (iVar6 < 0x14);
  return 0xb < (int)plVar4;
}

// ==== CMsgAchievement::helper_140331650  @140331650  [medium:callgraph-r2]  (orig: FUN_140331650)
/* WARNING: Type propagation algorithm not settling */

undefined8 FUN_140331650(longlong param_1,int param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  bool bVar9;
  uint uVar10;
  int *piVar11;
  int local_58 [12];
  
  bVar1 = false;
  uVar10 = 0;
  local_58[0] = 1;
  local_58[1] = 2;
  local_58[2] = 3;
  local_58[3] = 4;
  local_58[4] = 5;
  local_58[5] = 6;
  local_58[6] = 8;
  local_58[7] = 10;
  local_58[8] = 0xb;
  local_58[9] = 0xc;
  local_58[10] = 0x12;
  local_58[0xb] = 0x13;
  piVar11 = local_58;
  do {
    iVar5 = *piVar11;
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    cVar2 = FUN_14008a700(uVar6);
    if ((cVar2 == '\0') ||
       ((((iVar5 != 10 && (iVar5 != 0xb)) && (iVar5 != 0x12)) && (iVar5 != 0x13)))) {
      if (param_2 == 1) {
        if (iVar5 != 0xc) goto LAB_1403317a2;
      }
      else if (param_2 == 3) {
        if (iVar5 != 0xc) {
joined_r0x000140331781:
          if (((iVar5 != 0x12) && (iVar5 != 10)) && ((iVar5 != 0xb && (iVar5 != 0x13))))
          goto LAB_1403317a2;
        }
      }
      else {
        if (param_2 == 4) {
          if ((iVar5 == 0xc) || (iVar5 == 0x12)) goto LAB_140331999;
        }
        else if (param_2 == 5) goto joined_r0x000140331781;
LAB_1403317a2:
        plVar8 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar8 = (longlong *)0x0;
        }
        lVar7 = (**(code **)(*plVar8 + 0x60))
                          (plVar8,*(undefined4 *)(param_1 + 0xd94 + (longlong)iVar5 * 4));
        if (lVar7 == 0) {
          bVar9 = bVar1;
          if (iVar5 != 5) {
            return 0;
          }
        }
        else {
          if ((iVar5 == 5) && (bVar1)) goto LAB_140331999;
          bVar9 = false;
          if (param_2 == 1) {
            iVar3 = FUN_1401011d0(lVar7);
            bVar9 = param_3 <= iVar3;
          }
          else if (param_2 == 2) {
            iVar3 = FUN_1400fda10(lVar7,0xc,1);
            if (0xb < iVar3) {
              bVar9 = true;
            }
          }
          else if (param_2 == 3) {
            iVar3 = FUN_1400fda10(lVar7,0xe,1);
            if (6 < iVar3) {
              bVar9 = true;
            }
          }
          else if (param_2 == 4) {
            if (param_3 == 1) {
              iVar3 = FUN_1400fda10(lVar7,8,1);
              if (iVar3 != 0) {
                bVar9 = true;
              }
            }
            else if ((param_3 == 2) && (iVar3 = FUN_1400fda10(lVar7,9,1), iVar3 != 0)) {
              bVar9 = true;
            }
          }
          else if ((param_2 == 5) && (iVar3 = FUN_1400fda10(lVar7,0xf,1), 0 < iVar3)) {
            bVar9 = true;
          }
          if (iVar5 == 4) {
            uVar4 = FUN_1400fda10(lVar7,1,1);
            iVar5 = FUN_1400ff680(uVar4);
            if ((iVar5 == 5) || (cVar2 = FUN_14016caf0(lVar7), cVar2 != '\0')) {
              bVar1 = bVar9;
            }
          }
        }
        if (!bVar9) {
          return 0;
        }
      }
    }
LAB_140331999:
    uVar10 = uVar10 + 1;
    piVar11 = piVar11 + 1;
    if (0xb < uVar10) {
      return 1;
    }
  } while( true );
}

// ==== CMsgAchievement::helper_14033a250  @14033a250  [medium:callgraph-r2]  (orig: FUN_14033a250)
undefined8 FUN_14033a250(longlong param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0x15;
  do {
    iVar2 = FUN_140337820(param_1,iVar3);
    if (iVar2 == 0) {
      if (iVar3 != 0x19) {
        return 0;
      }
      uVar1 = *(byte *)(param_1 + 0xeee) / 10;
      if ((((uVar1 != 4) && (uVar1 != 10)) && (uVar1 != 0xd)) && (uVar1 != 0xe)) {
        return 0;
      }
    }
    iVar3 = iVar3 + 1;
    if (0x1d < iVar3) {
      return 1;
    }
  } while( true );
}

// ==== CMsgAchievement::helper_1403761c0  @1403761c0  [medium:callgraph-r2]  (orig: FUN_1403761c0)
undefined8 FUN_1403761c0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x78);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x48);
  if (*(longlong *)(param_1 + 0x48) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong *)(param_1 + 0x48);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar9 = *(longlong *)(param_1 + 0x78);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar7 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(lVar4 + 0x20);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0);
    uVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
  }
  return uVar7;
}

// ==== CMsgAchievement::helper_140376a30  @140376a30  [medium:callgraph-r1]  (orig: FUN_140376a30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140376a30(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  int iVar6;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_1403778c0(local_458);
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
  plVar5 = *(longlong **)(param_1 + 0x10);
  uVar2 = (**(code **)(*plVar4 + 0x40))(plVar4);
  uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
  cVar1 = FUN_1403779f0(local_458,1,uVar3,uVar2);
  if (cVar1 == '\0') {
    local_478 = 0x110;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140377910(local_458);
  }
  else {
    iVar6 = 3;
    do {
      plVar5 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),iVar6)
      ;
      uVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
      cVar1 = FUN_140377a70(local_458,uVar2);
      if (cVar1 == '\0') {
        local_478 = 0x114;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_140377910(local_458);
        return;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < 0xf);
    (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_458);
    FUN_140377910(local_458);
  }
  return;
}

// ==== CMsgAchievement::helper_140377860  @140377860  [medium:callgraph-r0]  (orig: FUN_140377860)
undefined8 FUN_140377860(longlong param_1)

{
  if (*(longlong *)(param_1 + 200) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 200);
  }
  return *(undefined8 *)(param_1 + 200);
}

// ==== CMsgAchievement::ctor_or_dtor  @1403778c0  [high:vtable-assign]  (orig: FUN_1403778c0)
undefined8 * FUN_1403778c0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAchievement::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAchievement::ctor_or_dtor  @140377910  [high:vtable-assign]  (orig: FUN_140377910)
void FUN_140377910(undefined8 *param_1)

{
  *param_1 = CMsgAchievement::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAchievement::vfunc_1  @140377940  [high:rtti-vtable]  (orig: FUN_140377940)
ulonglong FUN_140377940(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x470);
}

// ==== CMsgAchievement::ctor_or_dtor  @140377b20  [high:vtable-assign]  (orig: FUN_140377b20)
undefined8 * FUN_140377b20(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAchievement::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAchievement::vfunc_3  @140377b70  [high:rtti-vtable]  (orig: FUN_140377b70)
void FUN_140377b70(longlong param_1)

{
  short sVar1;
  undefined2 uVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  
  lVar5 = DAT_140975b68;
  if (DAT_140975b68 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar5 = 0;
  }
  if (*(char *)(lVar5 + 0x51) != '\0') {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(lVar5 + 0x90) + 0xa8))
                       (*(longlong **)(lVar5 + 0x90),*(undefined4 *)(param_1 + 0x414));
    if (plVar6 != (longlong *)0x0) {
      sVar1 = **(short **)(param_1 + 0x428);
      if (sVar1 == 1) {
        if ((*(int *)(*(short **)(param_1 + 0x428) + 2) != 0) &&
           (iVar4 = (**(code **)(*plVar6 + 8))(plVar6),
           iVar4 != *(int *)(*(longlong *)(param_1 + 0x428) + 4))) {
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          plVar8 = (longlong *)FUN_140087650(uVar7);
          lVar5 = (**(code **)(*plVar8 + 0x98))
                            (plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          if ((lVar5 != 0) && (cVar3 = FUN_140167b70(lVar5), cVar3 == '\0')) {
            FUN_1401628d0(lVar5,plVar6);
          }
        }
      }
      else if (((sVar1 == 2) &&
               (iVar4 = (**(code **)(*plVar6 + 8))(plVar6),
               iVar4 == *(int *)(*(longlong *)(param_1 + 0x428) + 4))) &&
              (cVar3 = FUN_140167b70(plVar6), cVar3 == '\0')) {
        lVar5 = *(longlong *)(param_1 + 0x428);
        uVar2 = *(undefined2 *)(lVar5 + 8);
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar7 = FUN_140377860(uVar7);
        cVar3 = FUN_140226070(uVar7,*(undefined4 *)(lVar5 + 4),uVar2,*(undefined4 *)(lVar5 + 0xc));
        if (cVar3 != '\0') {
          FUN_140170e90(plVar6,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8));
          return;
        }
      }
    }
  }
  return;
}

// ==== CMsgAchievement::helper_14037f150  @14037f150  [medium:callgraph-r2]  (orig: FUN_14037f150)
undefined8 FUN_14037f150(longlong param_1,longlong *param_2)

{
  int *piVar1;
  int iVar2;
  longlong lVar3;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) >> 2 != 0) {
    piVar1 = *(int **)(param_1 + 0x30);
    if (*(int **)(param_1 + 0x38) < piVar1) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong **)(param_1 + 0x18) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = **(longlong **)(param_1 + 0x18);
    }
    if (*(int **)(lVar3 + 0x20) <= piVar1) {
      _invalid_parameter_noinfo();
    }
    iVar2 = (**(code **)(*param_2 + 8))(param_2);
    if (*piVar1 == iVar2) {
      return 1;
    }
  }
  return 0;
}

