// ==== CPlayerProcessGoal::helper_14042c0a0  @14042c0a0  [medium:callgraph-r2]  (orig: FUN_14042c0a0)
void FUN_14042c0a0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CPlayerProcessGoal::helper_14042c660  @14042c660  [medium:callgraph-r0]  (orig: FUN_14042c660)
void FUN_14042c660(void *param_1)

{
  if ((DAT_140976418 & 1) == 0) {
    DAT_140976418 = DAT_140976418 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976410,"CPlayerProcessGoal");
    atexit((_func_5014 *)&LAB_1406d6e20);
  }
                    /* WARNING: Could not recover jumptable at 0x00014042c6b5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976410,param_1);
  return;
}

// ==== CPlayerProcessGoal::helper_14042cd30  @14042cd30  [medium:callgraph-r3]  (orig: FUN_14042cd30)
void FUN_14042cd30(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x51) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CPlayerProcessGoal::helper_14042cd90  @14042cd90  [medium:callgraph-r3]  (orig: FUN_14042cd90)
void FUN_14042cd90(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x51) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CPlayerProcessGoal::helper_14042ce00  @14042ce00  [medium:callgraph-r3]  (orig: FUN_14042ce00)
void FUN_14042ce00(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x51) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x51) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x51);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x51);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x51);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x51);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014042ce24. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CPlayerProcessGoal::helper_14042cea0  @14042cea0  [medium:callgraph-r2]  (orig: FUN_14042cea0)
void FUN_14042cea0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CPlayerProcessGoal::helper_14042d4b0  @14042d4b0  [medium:callgraph-r1]  (orig: FUN_14042d4b0)
void FUN_14042d4b0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x58);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 10) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x51) = 0;
  return;
}

// ==== CPlayerProcessGoal::helper_14042d640  @14042d640  [medium:callgraph-r2]  (orig: FUN_14042d640)
void * FUN_14042d640(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CPlayerProcessGoal::helper_14042da10  @14042da10  [medium:callgraph-r2]  (orig: FUN_14042da10)
void * FUN_14042da10(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CPlayerProcessGoal::helper_14042de50  @14042de50  [medium:callgraph-r2]  (orig: FUN_14042de50)
void * FUN_14042de50(undefined8 param_1,longlong param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_3 + 8) - (longlong)*(void **)(param_2 + 8) >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,*(void **)(param_2 + 8),_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CPlayerProcessGoal::helper_14042e010  @14042e010  [medium:callgraph-r1]  (orig: FUN_14042e010)
undefined8 * FUN_14042e010(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  undefined8 uVar4;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar4 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  uVar3 = (longlong)(param_2[4] - param_2[3]) >> 3;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar3 != 0) {
    if (0x1fffffffffffffff < uVar3) {
                    /* WARNING: Subroutine does not return */
      FUN_14042c0a0();
    }
    lVar2 = FUN_14042cea0(param_1 + 2,uVar3);
    param_1[3] = lVar2;
    param_1[4] = lVar2;
    param_1[5] = lVar2 + uVar3 * 8;
    uVar3 = param_2[4];
    if (uVar3 < (ulonglong)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_58 = (undefined4)*param_2;
    uStack_54 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_50 = (undefined4)uVar3;
    uStack_4c = (undefined4)(uVar3 >> 0x20);
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    uVar3 = param_2[3];
    if ((ulonglong)param_2[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    local_48 = (undefined4)*param_2;
    uStack_44 = (undefined4)((ulonglong)*param_2 >> 0x20);
    uStack_40 = (undefined4)uVar3;
    uStack_3c = (undefined4)(uVar3 >> 0x20);
    local_28 = local_48;
    uStack_24 = uStack_44;
    uStack_20 = uStack_40;
    uStack_1c = uStack_3c;
    uVar4 = FUN_14042de50(param_1,&local_28,&local_38,param_1[3],uVar4);
    param_1[4] = uVar4;
  }
  return param_1;
}

// ==== CPlayerProcessGoal::helper_14042e360  @14042e360  [medium:callgraph-r1]  (orig: FUN_14042e360)
void FUN_14042e360(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14042c0a0();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14042cea0(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_14042da10(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_14042da10(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14042d640(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CPlayerProcessGoal::helper_14042e6d0  @14042e6d0  [medium:callgraph-r0]  (orig: FUN_14042e6d0)
undefined8 FUN_14042e6d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  uint uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  longlong lVar13;
  longlong *local_d8 [3];
  longlong *local_c0;
  longlong *local_b8;
  undefined8 local_b0;
  longlong *local_a8;
  longlong *local_a0;
  longlong local_98;
  undefined8 local_90;
  uint local_88 [2];
  longlong *local_80;
  longlong local_78;
  undefined8 *local_70;
  longlong local_68;
  longlong local_60;
  undefined8 local_58;
  undefined1 local_50 [24];
  
  local_58 = 0xfffffffffffffffe;
  local_d8[0] = operator_new(8);
  if (local_d8[0] == (longlong *)0x0) {
    local_d8[0] = (longlong *)0x0;
  }
  else {
    *local_d8[0] = (longlong)local_d8;
  }
  lVar13 = 0;
  local_c0 = (longlong *)0x0;
  local_b8 = (longlong *)0x0;
  local_b0 = 0;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
  lVar8 = *(longlong *)(lVar6 + 0x170);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar8 = lVar13;
  }
  FUN_140313fc0(lVar8,local_d8,*(undefined4 *)(param_1 + 0x88),0x29);
  plVar11 = local_c0;
  if (local_b8 < local_c0) {
    _invalid_parameter_noinfo();
  }
  plVar4 = local_d8[0];
  local_a8 = local_d8[0];
  while( true ) {
    plVar2 = local_b8;
    local_a0 = plVar11;
    if (local_b8 < local_c0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar4 == (longlong *)0x0) || (plVar4 != local_d8[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar11 == plVar2) break;
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = lVar13;
    }
    else {
      lVar8 = *plVar4;
    }
    if (*(longlong **)(lVar8 + 0x20) <= plVar11) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)*plVar11;
    if (plVar2 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
      uVar5 = (**(code **)(*plVar7 + 0x40))(plVar7);
      plVar7 = (longlong *)(param_1 + 8);
      puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
      cVar1 = *(char *)((longlong)puVar12 + 0x29);
      puVar3 = *(undefined8 **)(param_1 + 0x38);
      while (cVar1 == '\0') {
        if (*(uint *)(puVar12 + 3) < uVar5) {
          puVar9 = (undefined8 *)puVar12[2];
          puVar12 = puVar3;
        }
        else {
          puVar9 = (undefined8 *)*puVar12;
        }
        puVar3 = puVar12;
        puVar12 = puVar9;
        cVar1 = *(char *)((longlong)puVar9 + 0x29);
      }
      local_70 = puVar3;
      local_78 = *plVar7;
      puVar12 = *(undefined8 **)(param_1 + 0x38);
      if (*plVar7 == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar3 == puVar12) || (uVar5 < *(uint *)(puVar3 + 3))) {
        local_90 = *(undefined8 *)(param_1 + 0x38);
        local_98 = *plVar7;
        plVar10 = &local_98;
      }
      else {
        plVar10 = &local_78;
      }
      local_68 = *plVar10;
      local_60 = plVar10[1];
      lVar8 = *(longlong *)(param_1 + 0x38);
      if ((*plVar7 == 0) || (*plVar7 != *plVar10)) {
        _invalid_parameter_noinfo();
      }
      if (lVar8 == local_60) {
        local_88[0] = uVar5;
        local_80 = plVar2;
        FUN_14002d3d0(plVar7,local_50,local_88);
      }
      else {
        (**(code **)*plVar2)(plVar2,1);
        log_InlineLogDBERROR
                  (
                  "CPlayerProcessGoal::LoadProcessGoal:cq_player_process_goal have two same record,goal = %u, user=%u"
                  );
      }
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = lVar13;
    }
    else {
      lVar8 = *plVar4;
    }
    if (*(longlong **)(lVar8 + 0x20) <= plVar11) {
      _invalid_parameter_noinfo();
    }
    plVar11 = plVar11 + 1;
  }
  if (local_c0 != (longlong *)0x0) {
    operator_delete(local_c0);
  }
  local_c0 = (longlong *)0x0;
  local_b8 = (longlong *)0x0;
  local_b0 = 0;
  operator_delete(local_d8[0]);
  return 1;
}

// ==== CPlayerProcessGoal::helper_14042f340  @14042f340  [medium:callgraph-r2]  (orig: FUN_14042f340)
longlong * FUN_14042f340(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14042e360(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14042f434;
  }
  _invalid_parameter_noinfo();
LAB_14042f434:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CPlayerProcessGoal::helper_140430670  @140430670  [medium:callgraph-r1]  (orig: FUN_140430670)
void FUN_140430670(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14042f340(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CPlayerProcessGoal::helper_140430720  @140430720  [medium:callgraph-r3]  (orig: FUN_140430720)
undefined8 *
FUN_140430720(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x58);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    FUN_14042e010(puVar1 + 4,param_5 + 2);
    *(undefined1 *)(puVar1 + 10) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x51) = 0;
  }
  return puVar1;
}

// ==== CPlayerProcessGoal::helper_140430810  @140430810  [medium:callgraph-r2]  (orig: FUN_140430810)
undefined8 * FUN_140430810(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x51) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14042ce00(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x51) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 10;
        plVar8 = plVar8 + 10;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1404309fc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x51);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x51);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x51);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x51);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1404309fc:
  if ((char)plVar2[10] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[10] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[10] == '\0') {
            *(undefined1 *)(plVar9 + 10) = 1;
            *(undefined1 *)(plVar8 + 10) = 0;
            FUN_14042cd30(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
            if ((*(char *)(*plVar9 + 0x50) != '\x01') || (*(char *)(plVar9[2] + 0x50) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x50) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x50) = 1;
                *(undefined1 *)(plVar9 + 10) = 0;
                FUN_14042cd90(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 10) = (char)plVar8[10];
              *(undefined1 *)(plVar8 + 10) = 1;
              *(undefined1 *)(plVar9[2] + 0x50) = 1;
              FUN_14042cd30(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 10) = 0;
          }
        }
        else {
          if ((char)plVar9[10] == '\0') {
            *(undefined1 *)(plVar9 + 10) = 1;
            *(undefined1 *)(plVar8 + 10) = 0;
            FUN_14042cd90(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
            if ((*(char *)(plVar9[2] + 0x50) != '\x01') || (*(char *)(*plVar9 + 0x50) != '\x01')) {
              if (*(char *)(*plVar9 + 0x50) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x50) = 1;
                *(undefined1 *)(plVar9 + 10) = 0;
                FUN_14042cd30(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 10) = (char)plVar8[10];
              *(undefined1 *)(plVar8 + 10) = 1;
              *(undefined1 *)(*plVar9 + 0x50) = 1;
              FUN_14042cd90(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 10) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 10) = 1;
  }
  if ((void *)plVar2[7] != (void *)0x0) {
    operator_delete((void *)plVar2[7]);
  }
  plVar2[7] = 0;
  plVar2[8] = 0;
  plVar2[9] = 0;
  operator_delete((void *)plVar2[4]);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CPlayerProcessGoal::helper_140431410  @140431410  [medium:callgraph-r1]  (orig: FUN_140431410)
void FUN_140431410(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x51);
  while (cVar1 == '\0') {
    FUN_140431410(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    if ((void *)param_2[7] != (void *)0x0) {
      operator_delete((void *)param_2[7]);
    }
    param_2[7] = 0;
    param_2[8] = 0;
    param_2[9] = 0;
    operator_delete((void *)param_2[4]);
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x51);
  }
  return;
}

// ==== CPlayerProcessGoal::helper_1404314c0  @1404314c0  [medium:callgraph-r2]  (orig: FUN_1404314c0)
undefined8 *
FUN_1404314c0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x492492492492490 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140430720(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x50);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x51) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x50) == '\0') {
        *(undefined1 *)(plVar2 + 10) = 1;
        *(undefined1 *)(lVar4 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x51) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x50) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x50) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x51) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x50);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x50) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CPlayerProcessGoal::helper_140431800  @140431800  [medium:callgraph-r1]  (orig: FUN_140431800)
longlong * FUN_140431800(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x51) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x51) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14043195d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14043198c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x51) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x51) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x51);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x51);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x51);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x51);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x51) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x51) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14043195d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1404314c0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14043198c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CPlayerProcessGoal::helper_1404319f0  @1404319f0  [medium:callgraph-r1]  (orig: FUN_1404319f0)
longlong * FUN_1404319f0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140431410(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x51) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x51);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x51);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x51);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x51);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140430810(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CPlayerProcessGoal::helper_140431bd0  @140431bd0  [medium:callgraph-r0]  (orig: FUN_140431bd0)
/* WARNING: Removing unreachable block (ram,0x000140431f1f) */
/* WARNING: Removing unreachable block (ram,0x000140431f30) */
/* WARNING: Removing unreachable block (ram,0x000140431f49) */
/* WARNING: Removing unreachable block (ram,0x000140431f84) */
/* WARNING: Removing unreachable block (ram,0x000140431f89) */
/* WARNING: Removing unreachable block (ram,0x000140431f94) */
/* WARNING: Removing unreachable block (ram,0x000140431f99) */
/* WARNING: Removing unreachable block (ram,0x000140431f9e) */
/* WARNING: Removing unreachable block (ram,0x000140431fa4) */

undefined8 FUN_140431bd0(longlong param_1)

{
  undefined8 *puVar1;
  void *pvVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined8 *puVar13;
  uint uVar14;
  longlong *local_res18;
  longlong *local_res20;
  longlong *local_168 [3];
  void *local_150;
  void *local_148;
  undefined8 local_140;
  longlong *local_138;
  longlong *local_130;
  longlong *local_128 [3];
  longlong *local_110;
  longlong *local_108;
  undefined8 local_100;
  undefined8 *local_f8;
  longlong local_f0;
  longlong local_e8;
  undefined8 local_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  longlong local_c8;
  undefined8 *local_c0;
  uint local_b8 [2];
  void *local_b0 [3];
  void *local_98;
  undefined8 local_90;
  undefined8 local_88;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68;
  undefined8 local_60;
  undefined1 local_58 [32];
  
  local_60 = 0xfffffffffffffffe;
  local_res18 = operator_new(8);
  if (local_res18 == (longlong *)0x0) {
    local_128[0] = (longlong *)0x0;
  }
  else {
    *local_res18 = (longlong)local_128;
    local_128[0] = local_res18;
  }
  plVar12 = (longlong *)0x0;
  local_110 = (longlong *)0x0;
  local_108 = (longlong *)0x0;
  local_100 = 0;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
  plVar10 = *(longlong **)(lVar6 + 0x170);
  if (*(longlong **)(lVar6 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = plVar12;
  }
  FUN_140313fc0(plVar10,local_128,*(undefined4 *)(param_1 + 0x88),0x2a);
  plVar10 = local_110;
  if (local_108 < local_110) {
    _invalid_parameter_noinfo();
  }
  local_138 = local_128[0];
  plVar11 = local_128[0];
  do {
    plVar9 = local_108;
    local_130 = plVar10;
    if (local_108 < local_110) {
      _invalid_parameter_noinfo();
    }
    if ((plVar11 == (longlong *)0x0) || (plVar11 != local_128[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar9) {
      if (local_110 != (longlong *)0x0) {
        operator_delete(local_110);
      }
      local_110 = (longlong *)0x0;
      local_108 = (longlong *)0x0;
      local_100 = 0;
      operator_delete(local_128[0]);
      return 1;
    }
    if (plVar11 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar12;
    }
    else {
      plVar9 = (longlong *)*plVar11;
    }
    if ((longlong *)plVar9[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)*plVar10;
    if (plVar9 != (longlong *)0x0) {
      plVar7 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
      uVar5 = (**(code **)(*plVar7 + 0x40))(plVar7);
      uVar14 = uVar5 / 100;
      if (uVar5 / 100 != 0) {
        plVar7 = (longlong *)FUN_1404df260();
        local_res18 = plVar7;
        if (plVar7 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          cVar4 = FUN_1404ded40(plVar7,*(undefined4 *)(param_1 + 0x8c),plVar9);
          if (cVar4 == '\0') {
            FUN_1404ded00(plVar7);
            local_res18 = (longlong *)0x0;
          }
          else {
            puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
            cVar4 = *(char *)((longlong)puVar13 + 0x51);
            puVar1 = *(undefined8 **)(param_1 + 0x78);
            while (cVar4 == '\0') {
              if (*(uint *)(puVar13 + 3) < uVar14) {
                puVar8 = (undefined8 *)puVar13[2];
                puVar13 = puVar1;
              }
              else {
                puVar8 = (undefined8 *)*puVar13;
              }
              puVar1 = puVar13;
              puVar13 = puVar8;
              cVar4 = *(char *)((longlong)puVar8 + 0x51);
            }
            local_c0 = puVar1;
            local_c8 = *(longlong *)(param_1 + 0x48);
            puVar13 = *(undefined8 **)(param_1 + 0x78);
            if (*(longlong *)(param_1 + 0x48) == 0) {
              _invalid_parameter_noinfo();
            }
            if ((puVar1 == puVar13) || (uVar14 < *(uint *)(puVar1 + 3))) {
              local_e0 = *(undefined8 *)(param_1 + 0x78);
              local_e8 = *(longlong *)(param_1 + 0x48);
              plVar11 = &local_e8;
            }
            else {
              plVar11 = &local_c8;
            }
            puVar13 = (undefined8 *)*plVar11;
            local_f0 = plVar11[1];
            lVar6 = *(longlong *)(param_1 + 0x78);
            local_f8 = puVar13;
            if ((*(undefined8 **)(param_1 + 0x48) == (undefined8 *)0x0) ||
               (*(undefined8 **)(param_1 + 0x48) != puVar13)) {
              _invalid_parameter_noinfo();
            }
            lVar3 = local_f0;
            if (lVar6 == local_f0) {
              local_res20 = operator_new(8);
              local_168[0] = plVar12;
              if (local_res20 != (longlong *)0x0) {
                *local_res20 = (longlong)local_168;
                local_168[0] = local_res20;
              }
              uStack_d0 = 0;
              local_140 = 0;
              local_148 = (void *)0x0;
              local_150 = (void *)0x0;
              local_d8._0_4_ = SUB84(local_168[0],0);
              local_d8._4_4_ = (undefined4)((ulonglong)local_168[0] >> 0x20);
              local_78 = (undefined4)local_d8;
              uStack_74 = local_d8._4_4_;
              uStack_70 = 0;
              uStack_6c = 0;
              local_d8 = local_168[0];
              local_68 = local_res20;
              FUN_14042e360(local_168,&local_78,1,&local_res18);
              pvVar2 = local_150;
              if (local_148 < local_150) {
                _invalid_parameter_noinfo();
              }
              plVar11 = local_168[0];
              if (local_168[0] == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar9 = plVar12;
              }
              else {
                plVar9 = (longlong *)*local_168[0];
              }
              if ((void *)plVar9[4] < pvVar2) {
LAB_140432023:
                _invalid_parameter_noinfo();
              }
              else {
                plVar9 = plVar12;
                if (plVar11 != (longlong *)0x0) {
                  plVar9 = (longlong *)*plVar11;
                }
                if (pvVar2 < (void *)plVar9[3]) goto LAB_140432023;
              }
              local_b8[0] = uVar14;
              FUN_14042e010(local_b0,local_168);
              FUN_140431800(param_1 + 0x48,local_58,local_b8);
              if (local_98 != (void *)0x0) {
                operator_delete(local_98);
              }
              local_98 = (void *)0x0;
              local_90 = 0;
              local_88 = 0;
              operator_delete(local_b0[0]);
              if (local_150 != (void *)0x0) {
                operator_delete(local_150);
              }
              local_150 = (void *)0x0;
              local_148 = (void *)0x0;
              local_140 = 0;
              operator_delete(local_168[0]);
              plVar11 = local_138;
            }
            else {
              if (puVar13 == (undefined8 *)0x0) {
                _invalid_parameter_noinfo();
                plVar11 = plVar12;
              }
              else {
                plVar11 = (longlong *)*puVar13;
              }
              if (lVar3 == plVar11[6]) {
                _invalid_parameter_noinfo();
              }
              FUN_140430670(lVar3 + 0x20,&local_res18);
              plVar11 = local_138;
            }
          }
        }
      }
    }
    if (plVar11 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar12;
    }
    else {
      plVar9 = (longlong *)*plVar11;
    }
    if ((longlong *)plVar9[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    plVar10 = plVar10 + 1;
  } while( true );
}

// ==== CPlayerProcessGoal::helper_1404321a0  @1404321a0  [medium:callgraph-r0]  (orig: FUN_1404321a0)
void FUN_1404321a0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  
  uVar9 = 0xfffffffffffffffe;
  plVar5 = *(longlong **)param_1[7];
  plVar2 = (longlong *)param_1[1];
  lVar8 = 0;
  plVar10 = plVar2;
  plVar6 = plVar5;
  while( true ) {
    plVar3 = (longlong *)param_1[7];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar6 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = plVar6;
        plVar3 = (longlong *)*plVar6;
        while (plVar6 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar6 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar6, plVar6 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar6 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar5 = *(longlong **)(param_1[7] + 8);
  while (cVar1 == '\0') {
    FUN_14002ca30(param_1 + 1,plVar5[2],param_3,param_4,uVar9,plVar10,plVar6);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  plVar5 = *(longlong **)param_1[0xf];
  plVar2 = (longlong *)param_1[9];
  while( true ) {
    plVar10 = (longlong *)param_1[0xf];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[9])) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar10) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14042e010(local_60,plVar5 + 4);
    plVar6 = local_48;
    plVar10 = local_60[0];
    if (local_40 < local_48) {
      _invalid_parameter_noinfo();
      plVar10 = local_60[0];
    }
    while( true ) {
      plVar3 = local_40;
      if (local_40 < local_48) {
        _invalid_parameter_noinfo();
      }
      if ((plVar10 == (longlong *)0x0) || (plVar10 != local_60[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == plVar3) break;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar10;
      }
      if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
        _invalid_parameter_noinfo();
      }
      if (*plVar6 != 0) {
        FUN_1404ded00();
      }
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar10;
      }
      if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar6 + 1;
    }
    if (local_48 != (longlong *)0x0) {
      operator_delete(local_48);
    }
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    operator_delete(local_60[0]);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x51) == '\0') {
      plVar10 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar10 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar10 + 0x51);
        plVar5 = plVar10;
        plVar10 = (longlong *)*plVar10;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar10 + 0x51);
          plVar5 = plVar10;
          plVar10 = (longlong *)*plVar10;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x51);
        plVar6 = (longlong *)plVar5[1];
        plVar10 = plVar5;
        while ((plVar5 = plVar6, cVar1 == '\0' && (plVar10 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x51);
          plVar6 = (longlong *)plVar5[1];
          plVar10 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_140431410(param_1 + 9,*(undefined8 *)(param_1[0xf] + 8));
  *(undefined8 *)(param_1[0xf] + 8) = param_1[0xf];
  param_1[0x10] = 0;
  *(undefined8 *)param_1[0xf] = param_1[0xf];
  *(undefined8 *)(param_1[0xf] + 0x10) = param_1[0xf];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CPlayerProcessGoal::helper_140432900  @140432900  [medium:callgraph-r0]  (orig: FUN_140432900)
void FUN_140432900(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1404319f0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CPlayerProcessGoal::ctor_or_dtor  @140432ac0  [high:vtable-assign]  (orig: FUN_140432ac0)
void FUN_140432ac0(undefined8 *param_1)

{
  *param_1 = CPlayerProcessGoal::vftable;
  FUN_140432900(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14002de90(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CPlayerProcessGoal::helper_140432e90  @140432e90  [medium:callgraph-r0]  (orig: FUN_140432e90)
undefined8 * FUN_140432e90(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14042d4b0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x51) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CPlayerProcessGoal::ctor_or_dtor  @140432f10  [high:vtable-assign]  (orig: FUN_140432f10)
undefined8 * FUN_140432f10(undefined8 *param_1,undefined4 param_2,undefined4 param_3)

{
  *param_1 = CPlayerProcessGoal::vftable;
  FUN_14002e1c0(param_1 + 1);
  FUN_140432e90(param_1 + 9);
  *(undefined4 *)(param_1 + 0x11) = param_3;
  *(undefined4 *)((longlong)param_1 + 0x8c) = param_2;
  return param_1;
}

// ==== CPlayerProcessGoal::ctor_or_dtor  @140432f80  [high:vtable-assign]  (orig: FUN_140432f80)
undefined8 * FUN_140432f80(undefined8 *param_1,uint param_2)

{
  *param_1 = CPlayerProcessGoal::vftable;
  FUN_140432900(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14002de90(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    FUN_14042c660(param_1);
  }
  return param_1;
}

// ==== CPlayerProcessGoal::ctor_or_dtor  @140433010  [high:vtable-assign]  (orig: FUN_140433010)
undefined8 * FUN_140433010(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined8 *puVar2;
  
  if ((DAT_140976418 & 1) == 0) {
    DAT_140976418 = DAT_140976418 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976410,"CPlayerProcessGoal");
    atexit((_func_5014 *)&LAB_1406d6e20);
  }
  puVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_140976410,0x90);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CPlayerProcessGoal::vftable;
    FUN_14002e1c0(puVar2 + 1);
    FUN_140432e90(puVar2 + 9);
    *(undefined4 *)(puVar2 + 0x11) = param_2;
    *(undefined4 *)((longlong)puVar2 + 0x8c) = param_1;
  }
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pPlayerGoal",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\processgoal\\playerprocessgoal.cpp"
                       ,0x1e);
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_14042e6d0(puVar2);
    if ((cVar1 == '\0') || (cVar1 = FUN_140431bd0(puVar2), cVar1 == '\0')) {
      FUN_1404321a0(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

// ==== CPlayerProcessGoal::helper_1404ded00  @1404ded00  [medium:callgraph-r1]  (orig: FUN_1404ded00)
void FUN_1404ded00(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,0);
    param_1[1] = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404ded31. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)*param_1)(param_1,1);
  return;
}

// ==== CPlayerProcessGoal::helper_1404ded40  @1404ded40  [medium:callgraph-r1]  (orig: FUN_1404ded40)
undefined1 FUN_1404ded40(longlong param_1,undefined4 param_2,longlong param_3)

{
  if (param_3 == 0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(longlong *)(param_1 + 8) = param_3;
  return 1;
}

