// ==== CLotteryActor@adapter::helper_140006b90  @140006b90  [medium:callgraph-r0]  (orig: FUN_140006b90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong * FUN_140006b90(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  plVar1 = (longlong *)InstanceGet();
  local_428 = param_2;
  _snprintf(local_418,0x400,"SELECT * FROM cq_config WHERE type BETWEEN %d AND %d");
  local_19 = 0;
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,local_418,2);
  if (plVar1 != (longlong *)0x0) {
    lVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
    if (lVar2 != 0) {
      return plVar1;
    }
    (**(code **)*plVar1)(plVar1);
  }
  return (longlong *)0x0;
}

// ==== CLotteryActor@adapter::helper_140350360  @140350360  [medium:callgraph-r0]  (orig: FUN_140350360)
void FUN_140350360(void)

{
  FUN_140344e80();
  return;
}

// ==== CLotteryActor@adapter::helper_140372930  @140372930  [medium:callgraph-r0]  (orig: FUN_140372930)
void FUN_140372930(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(short *)(param_1 + 0x140) = (short)param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"big_prize_fails");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CLotteryActor@adapter::helper_1403729a0  @1403729a0  [medium:callgraph-r0]  (orig: FUN_1403729a0)
void FUN_1403729a0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  
  *(short *)(param_1 + 0x142) = (short)param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"small_prize_fails");
    (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CLotteryActor@adapter::vfunc_1  @1405b1bd0  [high:rtti-vtable]  (orig: FUN_1405b1bd0)
void FUN_1405b1bd0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CLotteryActor@adapter::vfunc_0  @1405b1c40  [high:rtti-vtable]  (orig: FUN_1405b1c40)
undefined8 FUN_1405b1c40(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b1c93. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_1  @1405b1ca0  [high:rtti-vtable]  (orig: FUN_1405b1ca0)
undefined8 FUN_1405b1ca0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b1cf3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_2  @1405b1d00  [high:rtti-vtable]  (orig: FUN_1405b1d00)
undefined8 FUN_1405b1d00(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b1d53. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_3  @1405b1d60  [high:rtti-vtable]  (orig: FUN_1405b1d60)
undefined8 FUN_1405b1d60(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b1db1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0xa0))(plVar1);
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_4  @1405b1dc0  [high:rtti-vtable]  (orig: FUN_1405b1dc0)
undefined2 FUN_1405b1dc0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined2 *)(lVar1 + 0xfb8);
}

// ==== CLotteryActor@adapter::vfunc_5  @1405b1e20  [high:rtti-vtable]  (orig: FUN_1405b1e20)
void FUN_1405b1e20(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140372930(lVar1 + 0xe78,param_3,param_4);
  return;
}

// ==== CLotteryActor@adapter::vfunc_6  @1405b1ea0  [high:rtti-vtable]  (orig: FUN_1405b1ea0)
undefined2 FUN_1405b1ea0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined2 *)(lVar1 + 0xfba);
}

// ==== CLotteryActor@adapter::vfunc_7  @1405b1f00  [high:rtti-vtable]  (orig: FUN_1405b1f00)
void FUN_1405b1f00(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1403729a0(lVar1 + 0xe78,param_3,param_4);
  return;
}

// ==== CLotteryActor@adapter::vfunc_8  @1405b1f80  [high:rtti-vtable]  (orig: FUN_1405b1f80)
undefined8 FUN_1405b1f80(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar1 == 0) || (uVar2 = FUN_140340e50(lVar1,param_3,0,1,1,2,1), (int)uVar2 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_10  @1405b2010  [high:rtti-vtable]  (orig: FUN_1405b2010)
undefined8
FUN_1405b2010(longlong param_1,undefined8 param_2,undefined4 param_3,int param_4,int param_5)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_3);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_4 != 0) {
    if (param_4 != 1) {
      return 1;
    }
    if (param_5 < 1) {
      return 1;
    }
    uVar3 = 0xc;
    goto LAB_1405b2156;
  }
  if (param_5 == 1) {
    uVar4 = 0xff;
LAB_1405b213c:
    FUN_140104140(lVar1,8,uVar4);
    param_5 = 0;
  }
  else {
    if (param_5 != 2) {
      if (param_5 != 0) {
        return 1;
      }
      uVar4 = 0;
      goto LAB_1405b213c;
    }
    FUN_140104140(lVar1,8,0xff,0);
    param_5 = 0xff;
  }
  uVar3 = 9;
LAB_1405b2156:
  FUN_140104140(lVar1,uVar3,param_5,1);
  return 1;
}

// ==== CLotteryActor@adapter::vfunc_11  @1405b2170  [high:rtti-vtable]  (orig: FUN_1405b2170)
ulonglong FUN_1405b2170(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  longlong *plVar4;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
    if (lVar2 != 0) {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar4 = (longlong *)0x0;
      }
      uVar3 = (**(code **)(*plVar4 + 0x130))(plVar4,lVar1,lVar2,3,0,0);
      return uVar3;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return extraout_RAX & 0xffffffffffffff00;
}

// ==== CLotteryActor@adapter::vfunc_13  @1405b2290  [high:rtti-vtable]  (orig: FUN_1405b2290)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1405b2290(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  undefined8 local_res20;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if (param_3 == (char *)0x0) {
    return local_18 & 0xffffffffffffff00;
  }
  local_res20 = param_4;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    local_428 = 299;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    _vsnprintf(local_418,0x400,param_3,(va_list)&local_res20);
    local_19 = 0;
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))(lVar1 + 0x10,local_418);
  }
  return uVar2;
}

// ==== CLotteryActor@adapter::vfunc_16  @1405b2380  [high:rtti-vtable]  (orig: FUN_1405b2380)
void FUN_1405b2380(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_140006b90(param_2,param_3);
  return;
}

// ==== CLotteryActor@adapter::vfunc_18  @1405b2390  [high:rtti-vtable]  (orig: FUN_1405b2390)
ulonglong FUN_1405b2390(longlong param_1,int param_2,int param_3,int param_4)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (((param_2 != 0) && (param_3 != 0)) && (0 < param_4)) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    in_RAX = 0;
    if (lVar1 != 0) {
      uVar2 = FUN_140350360(lVar1,param_3,param_3,param_4,1,0);
      return uVar2;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CLotteryActor@adapter::vfunc_0  @1405b2400  [high:rtti-vtable]  (orig: FUN_1405b2400)
void FUN_1405b2400(longlong param_1)

{
  FUN_1405b2460(param_1 + -8);
  return;
}

// ==== CLotteryActor@adapter::helper_1405b2460  @1405b2460  [medium:callgraph-r0]  (orig: FUN_1405b2460)
undefined8 * FUN_1405b2460(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CLotteryActor::vftable;
  param_1[1] = adapter::CLotteryActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CLotteryActor@adapter::vfunc_9  @1405b24b0  [high:rtti-vtable]  (orig: FUN_1405b24b0)
undefined8 FUN_1405b24b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 != 0) {
    plVar5 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = (longlong *)0x0;
    }
    lVar4 = (**(code **)(*plVar5 + 0x60))(plVar5,param_3);
    if (lVar4 != 0) {
      cVar1 = FUN_1400f8840(lVar4);
      if (cVar1 != '\0') {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 1) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 2) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 3) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 7) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 8) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 == 6) {
        return 1;
      }
      uVar2 = FUN_1400fda10(lVar4,1,1);
      iVar3 = FUN_1400ff680(uVar2);
      if (iVar3 != 0xc) {
        uVar2 = FUN_1400fda10(lVar4,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 == 0xd) {
          return 1;
        }
        uVar2 = FUN_1400fda10(lVar4,1,1);
        iVar3 = FUN_1400ff680(uVar2);
        if (iVar3 != 0x15) {
          uVar2 = FUN_1400fda10(lVar4,1,1);
          iVar3 = FUN_1400ff680(uVar2);
          if (iVar3 != 0x16) {
            return 0;
          }
          return 1;
        }
        return 1;
      }
      return 1;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CLotteryActor@adapter::vfunc_12  @1405b26b0  [high:rtti-vtable]  (orig: FUN_1405b26b0)
undefined8 FUN_1405b26b0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    uVar3 = 0;
  }
  else {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      puVar2 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0,uVar3);
      if (puVar2 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = 0;
      }
      else {
        (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
        (**(code **)*puVar2)(puVar2,1);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CLotteryActor@adapter::vfunc_15  @1405b27b0  [high:rtti-vtable]  (orig: FUN_1405b27b0)
undefined8 FUN_1405b27b0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    uVar3 = 0;
  }
  else {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      puVar2 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0,uVar3);
      if (puVar2 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = 0;
      }
      else {
        (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x348))((longlong *)(lVar1 + 0x10),puVar2,1);
        (**(code **)*puVar2)(puVar2,1);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CLotteryActor@adapter::vfunc_14  @1405b28c0  [high:rtti-vtable]  (orig: FUN_1405b28c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405b28c0(longlong param_1,char *param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 local_res18;
  undefined8 local_res20;
  undefined1 auStack_448 [32];
  undefined4 local_428;
  undefined4 local_420;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if (param_2 != (char *)0x0) {
    local_res18 = param_3;
    local_res20 = param_4;
    _vsnprintf(local_418,0x400,param_2,(va_list)&local_res18);
    local_19 = 0;
    plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    local_420 = 2000;
    local_428 = 0xffffff;
    (**(code **)(*plVar1 + 0x60))(plVar1,local_418,0xffffffff,0);
  }
  return param_2 != (char *)0x0;
}

// ==== CLotteryActor@adapter::vfunc_17  @1405b2970  [high:rtti-vtable]  (orig: FUN_1405b2970)
undefined8 FUN_1405b2970(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0xa8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar3 = FUN_140145f60(*(undefined8 *)(lVar2 + 0xa8),param_3,lVar1,0,0,0);
    return uVar3;
  }
  return 0;
}

// ==== CLotteryActor@adapter::vfunc_19  @1405b2a20  [high:rtti-vtable]  (orig: FUN_1405b2a20)
undefined1 FUN_1405b2a20(longlong param_1,int param_2)

{
  longlong lVar1;
  
  if (param_2 == 0) {
    return 0;
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140261720(lVar1,param_2,0xe);
  return 1;
}

// ==== CLotteryActor@adapter::vfunc_20  @1405b2a90  [high:rtti-vtable]  (orig: FUN_1405b2a90)
void FUN_1405b2a90(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,param_4,param_5);
  return;
}

