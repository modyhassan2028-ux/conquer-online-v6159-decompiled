// ==== CElitePKArenicActor@adapter::vfunc_1  @140595bc0  [high:rtti-vtable]  (orig: FUN_140595bc0)
void FUN_140595bc0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_0  @140595c30  [high:rtti-vtable]  (orig: FUN_140595c30)
undefined1 * FUN_140595c30(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140595c88. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_1  @140595c90  [high:rtti-vtable]  (orig: FUN_140595c90)
undefined8 FUN_140595c90(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14018eb30(lVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_2  @140595cf0  [high:rtti-vtable]  (orig: FUN_140595cf0)
undefined8 FUN_140595cf0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140595d43. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_3  @140595d50  [high:rtti-vtable]  (orig: FUN_140595d50)
undefined8 FUN_140595d50(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140595da3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_4  @140595db0  [high:rtti-vtable]  (orig: FUN_140595db0)
undefined1 FUN_140595db0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CElitePKArenicActor@adapter::vfunc_5  @140595e10  [high:rtti-vtable]  (orig: FUN_140595e10)
bool FUN_140595e10(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CElitePKArenicActor@adapter::vfunc_6  @140595e30  [high:rtti-vtable]  (orig: FUN_140595e30)
ulonglong FUN_140595e30(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    in_RAX = 0;
    if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140595e5d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x250))(lVar1 + 0x10);
      return uVar2;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CElitePKArenicActor@adapter::vfunc_8  @140595e70  [high:rtti-vtable]  (orig: FUN_140595e70)
ulonglong FUN_140595e70(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140595ec3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_9  @140595ed0  [high:rtti-vtable]  (orig: FUN_140595ed0)
ulonglong FUN_140595ed0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140595f23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x280))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_10  @140595f30  [high:rtti-vtable]  (orig: FUN_140595f30)
void FUN_140595f30(longlong param_1,undefined8 param_2,undefined1 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  uint in_stack_ffffffffffffffe8;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401c6d40(lVar1,param_3,param_4,param_5,in_stack_ffffffffffffffe8 & 0xffffff00);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_11  @140595fb0  [high:rtti-vtable]  (orig: FUN_140595fb0)
undefined8 FUN_140595fb0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_12  @140596010  [high:rtti-vtable]  (orig: FUN_140596010)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140596010(longlong param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    local_498 = 0xa1;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140161fa0(lVar2,param_3);
    FUN_140362560(local_478);
    cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
    }
    FUN_1403625e0(local_478);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_13  @1405960f0  [high:rtti-vtable]  (orig: FUN_1405960f0)
void FUN_1405960f0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401a6420(lVar1,param_3,param_4,param_5);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_14  @140596170  [high:rtti-vtable]  (orig: FUN_140596170)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140596170(longlong param_1,undefined8 param_2,char param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined2 local_4c0;
  uint local_4b8;
  undefined4 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  plVar6 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar6 == (longlong *)0x0) {
    local_4c8 = 0xba;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140362560(local_498);
    uVar1 = (**(code **)(plVar6[2] + 0x50))(plVar6 + 2);
    uVar2 = (**(code **)(plVar6[2] + 0x48))(plVar6 + 2);
    uVar3 = (**(code **)(plVar6[2] + 0x40))(plVar6 + 2);
    uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
    local_4b0 = 0;
    local_4b8 = (uint)(param_3 != '\0');
    local_4c0 = 1000;
    local_4c8 = CONCAT22(local_4c8._2_2_,uVar1);
    iVar5 = FUN_140362620(local_498,uVar4,uVar3,uVar2);
    if (iVar5 != 0) {
      (**(code **)(plVar6[2] + 0x350))(plVar6 + 2,local_498);
    }
    FUN_1403625e0(local_498);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_15  @1405962a0  [high:rtti-vtable]  (orig: FUN_1405962a0)
void FUN_1405962a0(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140162110(lVar1,4,param_3);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_16  @1405962e0  [high:rtti-vtable]  (orig: FUN_1405962e0)
undefined8 FUN_1405962e0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596333. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_17  @140596340  [high:rtti-vtable]  (orig: FUN_140596340)
undefined8 FUN_140596340(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596391. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x88))(plVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_18  @1405963a0  [high:rtti-vtable]  (orig: FUN_1405963a0)
undefined8 FUN_1405963a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1403837b0(lVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_19  @140596400  [high:rtti-vtable]  (orig: FUN_140596400)
bool FUN_140596400(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_140166ec0(lVar2);
  return iVar1 != 0;
}

// ==== CElitePKArenicActor@adapter::vfunc_26  @140596460  [high:rtti-vtable]  (orig: FUN_140596460)
ulonglong FUN_140596460(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7e10(lVar1,param_3);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_29  @1405964c0  [high:rtti-vtable]  (orig: FUN_1405964c0)
void FUN_1405964c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405964e7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_30  @1405964f0  [high:rtti-vtable]  (orig: FUN_1405964f0)
undefined8 FUN_1405964f0(longlong param_1,undefined8 param_2,undefined4 *param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(lVar3 + 0x10);
  uVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x40))(plVar1);
  *param_3 = uVar2;
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  param_3[1] = uVar2;
  return 1;
}

// ==== CElitePKArenicActor@adapter::vfunc_41  @140596570  [high:rtti-vtable]  (orig: FUN_140596570)
void FUN_140596570(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401732e0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_44  @1405965f0  [high:rtti-vtable]  (orig: FUN_1405965f0)
ulonglong FUN_1405965f0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_45  @140596670  [high:rtti-vtable]  (orig: FUN_140596670)
undefined8
FUN_140596670(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
             undefined1 param_5,undefined1 param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140340e50(lVar1,param_3,param_4,param_5,1,0,param_6);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_48  @140596710  [high:rtti-vtable]  (orig: FUN_140596710)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140596710(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x213);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xffff00;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CElitePKArenicActor@adapter::vfunc_49  @140596870  [high:rtti-vtable]  (orig: FUN_140596870)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140596870(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x22c);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CElitePKArenicActor@adapter::vfunc_54  @1405969d0  [high:rtti-vtable]  (orig: FUN_1405969d0)
undefined8 FUN_1405969d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596a23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_55  @140596a30  [high:rtti-vtable]  (orig: FUN_140596a30)
undefined1 * FUN_140596a30(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596ad1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_56  @140596ae0  [high:rtti-vtable]  (orig: FUN_140596ae0)
ulonglong FUN_140596ae0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596b77. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x248))(plVar1,param_2);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_57  @140596b80  [high:rtti-vtable]  (orig: FUN_140596b80)
void FUN_140596b80(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,4);
  if (plVar1 == (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140596be5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR(
                      "CElitePKArenicActor::OnUserArenicHornorChange, not found arenic module interface"
                      );
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596bf6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x110))(plVar1,param_2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_58  @140596c00  [high:rtti-vtable]  (orig: FUN_140596c00)
void FUN_140596c00(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165950(lVar1,param_3,1);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_59  @140596c60  [high:rtti-vtable]  (orig: FUN_140596c60)
void FUN_140596c60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140177500(lVar1,param_3,1);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_60  @140596cc0  [high:rtti-vtable]  (orig: FUN_140596cc0)
undefined8 FUN_140596cc0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165940(lVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_61  @140596d20  [high:rtti-vtable]  (orig: FUN_140596d20)
undefined8 FUN_140596d20(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165930(lVar1);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_20  @140596d80  [high:rtti-vtable]  (orig: FUN_140596d80)
void FUN_140596d80(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_1401602a0();
                    /* WARNING: Could not recover jumptable at 0x000140596da9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)*puVar1)(puVar1,param_2,param_3);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_21  @140596db0  [high:rtti-vtable]  (orig: FUN_140596db0)
void FUN_140596db0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401602a0();
                    /* WARNING: Could not recover jumptable at 0x000140596ddf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 8))(plVar1,param_2,param_3,2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_22  @140596df0  [high:rtti-vtable]  (orig: FUN_140596df0)
ulonglong FUN_140596df0(undefined8 param_1,undefined4 param_2,undefined2 param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  undefined8 *puVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  puVar2 = (undefined8 *)(**(code **)(*plVar1 + 0x20))(plVar1,0xe);
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596ea2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)*puVar2)(puVar2,param_2,param_3);
  return uVar3;
}

// ==== CElitePKArenicActor@adapter::vfunc_23  @140596eb0  [high:rtti-vtable]  (orig: FUN_140596eb0)
ulonglong FUN_140596eb0(undefined8 param_1,undefined4 param_2,undefined2 param_3)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0xe);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140596f62. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2,param_3);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_24  @140596f70  [high:rtti-vtable]  (orig: FUN_140596f70)
void FUN_140596f70(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x000140596f8a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_25  @140596f90  [high:rtti-vtable]  (orig: FUN_140596f90)
void FUN_140596f90(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar3 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2,0x6a);
  if (cVar1 != '\0') {
    plVar3 = (longlong *)FUN_1401181a0();
    (**(code **)(*plVar3 + 0x10))(plVar3,param_2,0x6a);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_27  @140597020  [high:rtti-vtable]  (orig: FUN_140597020)
undefined8 FUN_140597020(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_1401a4030(lVar2,param_3);
  if (cVar1 == '\0') {
    FUN_140179040(lVar2,param_3);
    return 0;
  }
  return 1;
}

// ==== CElitePKArenicActor@adapter::vfunc_63  @1405970b0  [high:rtti-vtable]  (orig: FUN_1405970b0)
void FUN_1405970b0(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_53  @1405970c0  [high:rtti-vtable]  (orig: FUN_1405970c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405970c0(longlong param_1,undefined2 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  undefined1 uVar2;
  longlong lVar3;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar3 == 0) {
    local_4a8 = 0x336;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_140362560(local_488);
    cVar1 = FUN_140362910(local_488,param_2,param_3,(longlong)param_4);
    if (cVar1 == '\0') {
      FUN_1403625e0(local_488);
      uVar2 = 0;
    }
    else {
      uVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))
                        ((longlong *)(lVar3 + 0x10),local_488);
      FUN_1403625e0(local_488);
    }
  }
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_0  @1405971b0  [high:rtti-vtable]  (orig: FUN_1405971b0)
void FUN_1405971b0(longlong param_1)

{
  FUN_140597210(param_1 + -8);
  return;
}

// ==== CElitePKArenicActor@adapter::helper_140597210  @140597210  [medium:callgraph-r0]  (orig: FUN_140597210)
undefined8 * FUN_140597210(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CElitePKArenicActor::vftable;
  param_1[1] = adapter::CElitePKArenicActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CElitePKArenicActor@adapter::vfunc_7  @140597260  [high:rtti-vtable]  (orig: FUN_140597260)
ulonglong FUN_140597260(longlong param_1)

{
  uint extraout_var;
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(lVar1 + 0x10);
    uVar2 = 0;
    if (lVar1 != 0) {
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
      (**(code **)(*plVar3 + 0x58))(plVar3);
      return (ulonglong)(extraout_var & 1);
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CElitePKArenicActor@adapter::vfunc_28  @1405972f0  [high:rtti-vtable]  (orig: FUN_1405972f0)
undefined8 FUN_1405972f0(longlong param_1,undefined8 param_2,char param_3)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  uint in_stack_ffffffffffffffd8;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  local_18 = 0;
  local_14 = 0;
  local_10 = 0;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0xb0) == 0) {
    in_stack_ffffffffffffffd8 = 0x138;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006c50(*(undefined8 *)(lVar6 + 0xb0),&local_18);
  if (param_3 == '\0') {
    uVar1 = *(undefined2 *)(lVar5 + 0xf0e);
    uVar2 = *(undefined2 *)(lVar5 + 0xf0c);
    uVar3 = FUN_140161f50(lVar5);
    in_stack_ffffffffffffffd8 = in_stack_ffffffffffffffd8 & 0xffffff00;
    iVar4 = FUN_1401c55b0(lVar5,uVar3,uVar2,uVar1,in_stack_ffffffffffffffd8);
    if (iVar4 == 0) {
      return 1;
    }
  }
  FUN_1401c55b0(lVar5,local_18,local_14,local_10,in_stack_ffffffffffffffd8 & 0xffffff00);
  return 1;
}

// ==== CElitePKArenicActor@adapter::vfunc_31  @140597420  [high:rtti-vtable]  (orig: FUN_140597420)
bool FUN_140597420(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CElitePKArenicActor@adapter::vfunc_32  @1405974a0  [high:rtti-vtable]  (orig: FUN_1405974a0)
void FUN_1405974a0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405974f4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x90))();
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_33  @140597500  [high:rtti-vtable]  (orig: FUN_140597500)
void FUN_140597500(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140597561. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x108))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_34  @140597570  [high:rtti-vtable]  (orig: FUN_140597570)
void FUN_140597570(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405975c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x110))();
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_35  @1405975d0  [high:rtti-vtable]  (orig: FUN_1405975d0)
void FUN_1405975d0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140597631. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0xa0))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_36  @140597640  [high:rtti-vtable]  (orig: FUN_140597640)
ulonglong FUN_140597640(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  if (param_2 != 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar1 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                      (*(longlong **)(lVar1 + 0x98),param_2,1);
    if (lVar1 != 0) {
      plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
      uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
      return (ulonglong)((uint)(uVar3 >> 0x1d) & 1);
    }
    log_InlineLogERROR(&DAT_1406d9c10);
    in_RAX = extraout_RAX;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CElitePKArenicActor@adapter::vfunc_38  @140597710  [high:rtti-vtable]  (orig: FUN_140597710)
ulonglong FUN_140597710(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x14) & 1);
}

// ==== CElitePKArenicActor@adapter::vfunc_39  @1405977e0  [high:rtti-vtable]  (orig: FUN_1405977e0)
ulonglong FUN_1405977e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1e) & 1);
}

// ==== CElitePKArenicActor@adapter::vfunc_40  @1405978b0  [high:rtti-vtable]  (orig: FUN_1405978b0)
ulonglong FUN_1405978b0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 2) & 1);
}

// ==== CElitePKArenicActor@adapter::vfunc_46  @140597980  [high:rtti-vtable]  (orig: FUN_140597980)
void FUN_140597980(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x180);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1400df9c0(lVar1,param_2);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_47  @1405979e0  [high:rtti-vtable]  (orig: FUN_1405979e0)
void FUN_1405979e0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_51  @140597aa0  [high:rtti-vtable]  (orig: FUN_140597aa0)
void FUN_140597aa0(longlong param_1,longlong param_2,int param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined4 uVar4;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(ushort *)(param_2 + 8) - 4,0,0xfffffffffffffffe);
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar4 = 0xffffffff;
    if (param_3 != 0) {
      lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                        (*(longlong **)(param_1 + 0x10),param_3);
      uVar4 = 0xffffffff;
      if (lVar2 != 0) {
        uVar4 = *(undefined4 *)(lVar2 + 0x122c);
      }
    }
    plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar3 + 0x68))(plVar3,puVar1,uVar4);
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_50  @140597b80  [high:rtti-vtable]  (orig: FUN_140597b80)
void FUN_140597b80(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
                  int param_5)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 uVar3;
  
  if (param_5 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 != 0) {
      uVar3 = *(undefined4 *)(lVar1 + 0x122c);
      goto LAB_140597bcc;
    }
  }
  uVar3 = 0xffffffff;
LAB_140597bcc:
  plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar2 + 0x60))(plVar2,param_2,uVar3,0,param_3,param_4);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_62  @140597c10  [high:rtti-vtable]  (orig: FUN_140597c10)
ulonglong FUN_140597c10(longlong param_1,undefined4 param_2,int param_3)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong extraout_RAX;
  undefined8 uVar3;
  
  if (param_3 == 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar1 + 0xa8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar2 = FUN_140145f60(*(undefined8 *)(lVar1 + 0xa8),param_2,0,0,0,0);
    return uVar2;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar3 = FUN_140087730(uVar3);
  uVar2 = FUN_140145f60(uVar3,param_2,lVar1,0,0,0);
  return uVar2;
}

// ==== CElitePKArenicActor@adapter::vfunc_64  @140597d30  [high:rtti-vtable]  (orig: FUN_140597d30)
void FUN_140597d30(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,param_4,param_5);
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_37  @140597db0  [high:rtti-vtable]  (orig: FUN_140597db0)
ulonglong FUN_140597db0(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (param_2 != 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar1 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                      (*(longlong **)(lVar1 + 0x98),param_2,1);
    if (lVar1 != 0) {
      uVar2 = FUN_14011dbb0(lVar1);
      return uVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
    in_RAX = extraout_RAX;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CElitePKArenicActor@adapter::vfunc_42  @140597e70  [high:rtti-vtable]  (orig: FUN_140597e70)
void FUN_140597e70(longlong param_1,undefined4 param_2,char param_3,int param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong *plVar10;
  uint in_stack_ffffffffffffff58;
  longlong *local_98;
  undefined8 local_90;
  undefined4 local_88;
  longlong *local_80 [3];
  longlong *local_68;
  longlong *local_60;
  undefined8 local_58;
  longlong *local_50;
  longlong *local_40;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar7 = (longlong *)FUN_1400876b0(uVar6);
  lVar8 = (**(code **)(*plVar7 + 0x20))(plVar7,param_2,1);
  if (lVar8 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    if (param_3 != '\0') {
      plVar7 = *(longlong **)(*(longlong *)(lVar8 + 0x58) + 8);
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
      uVar9 = (**(code **)(*plVar7 + 0x58))(plVar7);
      if ((uVar9 >> 0x1d & 1) == 0) {
        return;
      }
    }
    local_98 = operator_new(8);
    if (local_98 == (longlong *)0x0) {
      local_80[0] = (longlong *)0x0;
    }
    else {
      *local_98 = (longlong)local_80;
      local_80[0] = local_98;
    }
    local_68 = (longlong *)0x0;
    local_60 = (longlong *)0x0;
    local_58 = 0;
    local_90 = local_98;
    FUN_1402d2100(lVar8,local_80);
    plVar7 = local_68;
    if (((longlong)local_60 - (longlong)local_68 & 0xfffffffffffffff8U) == 0) {
      if (local_68 != (longlong *)0x0) {
        operator_delete(local_68);
      }
      local_68 = (longlong *)0x0;
      local_60 = (longlong *)0x0;
      local_58 = 0;
      operator_delete(local_80[0]);
    }
    else {
      local_50 = (longlong *)0x0;
      if (local_60 < local_68) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_60;
      plVar1 = local_80[0];
      local_50 = local_80[0];
      local_40 = (longlong *)0x0;
      if (local_60 < local_68) {
        _invalid_parameter_noinfo();
      }
      plVar2 = local_80[0];
      local_40 = local_80[0];
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar2)) {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == plVar3) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar1;
        }
        if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        plVar10 = (longlong *)*plVar7;
        local_98 = (longlong *)0x0;
        if (((plVar10 != (longlong *)0x0) &&
            (cVar4 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1001,&local_98), cVar4 != '\0')) &&
           (iVar5 = (**(code **)(*local_98 + 8))(), iVar5 != param_4)) {
          (**(code **)(*local_98 + 8))();
          log_InlineLogERROR("CElitePKArenicActor::ClearMap error map:%u, has user:%u.");
          if (param_3 == '\0') {
            local_90 = (longlong *)0x0;
            local_88 = 0;
            uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
            uVar6 = FUN_1400d6610(uVar6);
            FUN_140006c50(uVar6,&local_90);
            in_stack_ffffffffffffff58 = in_stack_ffffffffffffff58 & 0xffffff00;
            FUN_1401c55b0(local_98,(ulonglong)local_90 & 0xffffffff,local_90._4_4_,local_88,
                          in_stack_ffffffffffffff58);
          }
          else {
            uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
            plVar10 = (longlong *)FUN_140087650(uVar6);
            (**(code **)(*plVar10 + 0x50))
                      (plVar10,local_98,"CElitePKArenicActor::ClearMap fault in elitearenic map");
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar1;
        }
        if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
          _invalid_parameter_noinfo();
        }
        plVar7 = plVar7 + 1;
      }
      if (local_68 != (longlong *)0x0) {
        operator_delete(local_68);
      }
      local_68 = (longlong *)0x0;
      local_60 = (longlong *)0x0;
      local_58 = 0;
      operator_delete(local_80[0]);
    }
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_43  @140598190  [high:rtti-vtable]  (orig: FUN_140598190)
void FUN_140598190(longlong param_1,undefined8 param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  ulonglong uVar7;
  undefined4 local_res8 [2];
  undefined4 local_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  FUN_140036640(param_2);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)(**(code **)(**(longlong **)(lVar3 + 0x98) + 0x18))();
  if (plVar4 != (longlong *)0x0) {
    (**(code **)(*plVar4 + 0x10))(plVar4,&local_38);
    while( true ) {
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x18))(plVar4,local_18);
      if ((CONCAT44(uStack_34,local_38) == 0) || (CONCAT44(uStack_34,local_38) != *plVar5)) {
        _invalid_parameter_noinfo();
      }
      if (uStack_30 == (longlong *)plVar5[1]) break;
      local_28 = local_38;
      uStack_24 = uStack_34;
      uStack_20 = (undefined4)uStack_30;
      uStack_1c = uStack_30._4_4_;
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,&local_28);
      if (plVar5 != (longlong *)0x0) {
        plVar6 = (longlong *)
                 (**(code **)(**(longlong **)(plVar5[0xb] + 8) + 0x10))
                           (*(longlong **)(plVar5[0xb] + 8),4);
        uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
        if (((uVar7 >> 0x1d & 1) != 0) &&
           (iVar2 = (**(code **)(*plVar5 + 8))(plVar5), iVar2 != 910000)) {
          local_res8[0] = (**(code **)(*plVar5 + 8))(plVar5);
          FUN_140037fe0(param_2,local_res8);
        }
      }
      if (CONCAT44(uStack_34,local_38) == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)uStack_30 + 0x29) == '\0') {
        plVar5 = (longlong *)uStack_30[2];
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          uStack_30 = plVar5;
          plVar5 = (longlong *)*plVar5;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar5 + 0x29);
            uStack_30 = plVar5;
            plVar5 = (longlong *)*plVar5;
          }
        }
        else {
          cVar1 = *(char *)(uStack_30[1] + 0x29);
          plVar6 = (longlong *)uStack_30[1];
          plVar5 = uStack_30;
          while ((uStack_30 = plVar6, cVar1 == '\0' && (plVar5 == (longlong *)uStack_30[2]))) {
            cVar1 = *(char *)(uStack_30[1] + 0x29);
            plVar6 = (longlong *)uStack_30[1];
            plVar5 = uStack_30;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return;
}

// ==== CElitePKArenicActor@adapter::vfunc_52  @140598360  [high:rtti-vtable]  (orig: FUN_140598360)
void FUN_140598360(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  local_res20 = operator_new(8);
  local_68[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_68;
    local_68[0] = local_res20;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar6 + 0x38))(plVar6,local_68,param_3);
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      if ((void *)param_2[3] != (void *)0x0) {
        operator_delete((void *)param_2[3]);
      }
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      operator_delete((void *)*param_2);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),*puVar9);
    puVar2 = local_48;
    if (lVar4 != 0) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar4 + 0x122c));
      if (local_50 != (undefined4 *)0x0) {
        uVar7 = local_40 - (longlong)local_50 >> 2;
      }
      if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar7) {
        *local_48 = *(undefined4 *)(lVar4 + 0x122c);
        local_48 = local_48 + 1;
      }
      else {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_50;
        plVar6 = local_68[0];
        if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
          lVar4 = 0;
        }
        else {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
            _invalid_parameter_noinfo();
          }
          lVar4 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_88 = SUB84(plVar6,0);
        uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_80 = SUB84(puVar2,0);
        uStack_7c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_78 = local_88;
        uStack_74 = uStack_84;
        uStack_70 = uStack_80;
        uStack_6c = uStack_7c;
        FUN_140036c20(local_68,&local_78,1,&local_res20);
        puVar2 = local_50;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_68[0];
        if (local_68[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_68[0];
        }
        if (puVar2 + lVar4 <= *(undefined4 **)(lVar5 + 0x20)) {
          if (plVar6 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar6;
          }
          if (*(undefined4 **)(lVar5 + 0x18) <= puVar2 + lVar4) goto LAB_140598570;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_140598570:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

