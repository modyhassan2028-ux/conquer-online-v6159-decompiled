// ==== CCrossMsgSyndicate::helper_140160140  @140160140  [medium:callgraph-r0]  (orig: FUN_140160140)
longlong FUN_140160140(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x208);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CCrossMsgSyndicate::helper_140165780  @140165780  [medium:callgraph-r0]  (orig: FUN_140165780)
void FUN_140165780(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1330) = param_2;
  return;
}

// ==== CCrossMsgSyndicate::helper_140263290  @140263290  [medium:callgraph-r3]  (orig: FUN_140263290)
undefined8 *
FUN_140263290(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CCrossMsgSyndicate::helper_140264140  @140264140  [medium:callgraph-r2]  (orig: FUN_140264140)
undefined8 *
FUN_140264140(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140263290(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CCrossMsgSyndicate::helper_1402646f0  @1402646f0  [medium:callgraph-r1]  (orig: FUN_1402646f0)
undefined8 FUN_1402646f0(longlong param_1,longlong param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  lVar9 = (param_2 << 0x20) + (ulonglong)param_3;
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x70))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x70);
  while (cVar1 == '\0') {
    if ((longlong)puVar8[3] < lVar9) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x70);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x40);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (lVar9 < (longlong)puVar3[3])) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x70);
    local_28 = *(longlong *)(param_1 + 0x40);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x70);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x40))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CCrossMsgSyndicate::helper_140264800  @140264800  [medium:callgraph-r0]  (orig: FUN_140264800)
undefined4 FUN_140264800(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_1402646f0();
  if (puVar1 == (undefined4 *)0x0) {
    return 0;
  }
  return *puVar1;
}

// ==== CCrossMsgSyndicate::helper_1402648e0  @1402648e0  [medium:callgraph-r1]  (orig: FUN_1402648e0)
longlong * FUN_1402648e0(longlong *param_1,longlong *param_2,longlong *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < (longlong)puVar8[3];
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_140264a3d:
    local_30 = puVar4;
    if (*param_3 <= (longlong)puVar5[3]) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140264a6d;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x29);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140264a3d;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_140264140(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140264a6d:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CCrossMsgSyndicate::helper_140264b50  @140264b50  [medium:callgraph-r3]  (orig: FUN_140264b50)
void FUN_140264b50(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1402623d0();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_140262c20(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_1402646b0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_1402646b0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140263580(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CCrossMsgSyndicate::helper_140265000  @140265000  [medium:callgraph-r0]  (orig: FUN_140265000)
void FUN_140265000(undefined8 param_1,undefined8 param_2,undefined4 *param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_1402646f0(param_1,param_2,*param_3);
  if (lVar1 != 0) {
    *(undefined4 *)(lVar1 + 0xc) = param_3[1];
    *(undefined4 *)(lVar1 + 0x10) = param_3[2];
  }
  return;
}

// ==== CCrossMsgSyndicate::helper_140265060  @140265060  [medium:callgraph-r2]  (orig: FUN_140265060)
longlong * FUN_140265060(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140264b50(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_140265154;
  }
  _invalid_parameter_noinfo();
LAB_140265154:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CCrossMsgSyndicate::helper_1402652c0  @1402652c0  [medium:callgraph-r1]  (orig: FUN_1402652c0)
void FUN_1402652c0(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_140265060(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CCrossMsgSyndicate::helper_140265500  @140265500  [medium:callgraph-r0]  (orig: FUN_140265500)
int FUN_140265500(longlong param_1,int param_2,int *param_3)

{
  int iVar1;
  longlong lVar2;
  int *piVar3;
  int *local_res18;
  undefined8 local_40;
  int *local_38;
  undefined1 local_30 [24];
  
  if (param_3 + 7 == (int *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar1 = 0;
  }
  else {
    lVar2 = FUN_1402646f0(param_1,param_2,*param_3);
    if (lVar2 == 0) {
      piVar3 = operator_new(0x48);
      if (piVar3 == (int *)0x0) {
        piVar3 = (int *)0x0;
      }
      else {
        *piVar3 = 0;
        piVar3[1] = 0;
        piVar3[2] = 0;
        piVar3[3] = 0;
        piVar3[4] = 0;
        piVar3[5] = 0;
        piVar3[6] = 0;
        piVar3[7] = 0;
        piVar3[8] = 0;
        piVar3[9] = 0;
        piVar3[10] = 0;
        piVar3[0xb] = 0;
        piVar3[0xc] = 0;
        piVar3[0xd] = 0;
        piVar3[0xe] = 0;
        piVar3[0xf] = 0;
        piVar3[0x10] = 0;
        piVar3[0x11] = 0;
      }
      if (piVar3 == (int *)0x0) {
        iVar1 = 0;
      }
      else {
        piVar3[2] = param_2;
        piVar3[1] = *param_3;
        *piVar3 = (int)(*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x28) >> 3) + 1000;
        piVar3[3] = param_3[1];
        piVar3[4] = param_3[2];
        local_res18 = piVar3;
        strncpy((char *)(piVar3 + 5),(char *)(param_3 + 7),0x23);
        if (param_3 + 3 != (int *)0x0) {
          strncpy((char *)(piVar3 + 0xe),(char *)(param_3 + 3),0xf);
        }
        FUN_1402652c0(param_1 + 0x10,&local_res18);
        local_40 = CONCAT44(param_2,*param_3);
        local_38 = piVar3;
        FUN_1402648e0(param_1 + 0x40,local_30,&local_40);
        iVar1 = *piVar3;
      }
    }
    else {
      iVar1 = 0;
    }
  }
  return iVar1;
}

// ==== CCrossMsgSyndicate::ctor_or_dtor  @1403b6940  [high:vtable-assign]  (orig: FUN_1403b6940)
undefined8 * FUN_1403b6940(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgSyndicate::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgSyndicate::ctor_or_dtor  @1403b6990  [high:vtable-assign]  (orig: FUN_1403b6990)
void FUN_1403b6990(undefined8 *param_1)

{
  *param_1 = CCrossMsgSyndicate::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgSyndicate::vfunc_1  @1403b69c0  [high:rtti-vtable]  (orig: FUN_1403b69c0)
ulonglong FUN_1403b69c0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c50);
}

// ==== CCrossMsgSyndicate::ctor_or_dtor  @1403b6a80  [high:vtable-assign]  (orig: FUN_1403b6a80)
undefined8 * FUN_1403b6a80(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgSyndicate::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgSyndicate::vfunc_3  @1403b6ad0  [high:rtti-vtable]  (orig: FUN_1403b6ad0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b6ad0(longlong param_1)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar2 = FUN_14008b330(uVar6);
  if (cVar2 != '\0') {
    if (**(short **)(param_1 + 0x428) == 0) {
      uVar5 = *(undefined4 *)(param_1 + 0x420);
      uVar1 = *(undefined4 *)(param_1 + 0x41c);
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar6 = FUN_140087650(uVar6);
      plVar8 = (longlong *)FUN_1402af110(uVar6,uVar1,uVar5);
      if (plVar8 == (longlong *)0x0) {
        log_InlineLogWARNING("CCrossMsgSyndicate::Process cannot find user!");
      }
      else {
        lVar7 = *(longlong *)(param_1 + 0x428);
        iVar3 = (**(code **)(*plVar8 + 0x38))(plVar8);
        if ((iVar3 == *(int *)(lVar7 + 4)) && (lVar7 != -0x24)) {
          uVar5 = FUN_140167b40(plVar8);
          uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar6 = FUN_140160140(uVar6);
          iVar3 = FUN_140264800(uVar6,uVar5,*(undefined4 *)(lVar7 + 8));
          if (iVar3 == 0) {
            lVar7 = *(longlong *)(param_1 + 0x428);
            uVar5 = FUN_140167b40(plVar8);
            uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            uVar6 = FUN_140160140(uVar6);
            iVar3 = FUN_140265500(uVar6,uVar5,lVar7 + 8);
          }
          FUN_140165790(plVar8,iVar3);
          FUN_140165780(plVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        }
      }
    }
    else if (**(short **)(param_1 + 0x428) == 1) {
      uVar5 = *(undefined4 *)(param_1 + 0x41c);
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar7 = *(longlong *)(lVar7 + 0x208);
      if (lVar7 == 0) {
        local_488 = 0x166;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar7 = 0;
      }
      iVar3 = FUN_140264800(lVar7,uVar5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
      if (iVar3 != 0) {
        uVar5 = *(undefined4 *)(param_1 + 0x41c);
        lVar7 = *(longlong *)(param_1 + 0x428);
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar6 = FUN_140160140(uVar6);
        FUN_140265000(uVar6,uVar5,lVar7 + 8);
        plVar8 = (longlong *)CurrentInstanceGet();
        if (plVar8 != (longlong *)0x0) {
          plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0x25);
          if (plVar8 != (longlong *)0x0) {
            (**(code **)(*plVar8 + 0xa8))
                      (plVar8,*(undefined4 *)(param_1 + 0x41c),
                       *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                       *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          }
        }
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar8 = (longlong *)FUN_140087650(uVar6);
        plVar8 = (longlong *)
                 (**(code **)(*plVar8 + 0xa0))
                           (plVar8,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c)
                           );
        if (plVar8 != (longlong *)0x0) {
          iVar3 = *(int *)(*(longlong *)(param_1 + 0x428) + 4);
          iVar4 = (**(code **)(*plVar8 + 0x38))(plVar8);
          if ((iVar4 == iVar3) && (iVar3 == *(int *)(param_1 + 0x420))) {
            FUN_140165780(plVar8,0);
            FUN_140165790(plVar8,0);
            plVar9 = (longlong *)FUN_140087ed0();
            lVar7 = *plVar9;
            uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
            (**(code **)(lVar7 + 8))(plVar9,uVar5);
            FUN_14039ed70(local_468);
            iVar3 = FUN_14039eef0(local_468,plVar8 + 2,0,0);
            if (iVar3 != 0) {
              (**(code **)(plVar8[2] + 0x348))(plVar8 + 2,local_468,0);
            }
            FUN_14039edf0(local_468);
          }
        }
      }
    }
  }
  return;
}

