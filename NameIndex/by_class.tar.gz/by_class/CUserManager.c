// ==== CUserManager::helper_140006d80  @140006d80  [medium:callgraph-r1]  (orig: FUN_140006d80)
void FUN_140006d80(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4)

{
  *param_2 = *(undefined4 *)(param_1 + 0x1c8);
  *param_3 = *(undefined4 *)(param_1 + 0x1cc);
  *param_4 = *(undefined4 *)(param_1 + 0x1d0);
  return;
}

// ==== CUserManager::helper_140042870  @140042870  [medium:callgraph-r1]  (orig: FUN_140042870)
void FUN_140042870(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x58);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 10) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x51) = 0;
  return;
}

// ==== CUserManager::helper_140043be0  @140043be0  [medium:callgraph-r2]  (orig: FUN_140043be0)
void FUN_140043be0(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x51);
  while (cVar1 == '\0') {
    FUN_140043be0(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    if ((void *)param_2[7] != (void *)0x0) {
      operator_delete((void *)param_2[7]);
    }
    param_2[7] = 0;
    param_2[8] = 0;
    param_2[9] = 0;
    operator_delete((void *)param_2[4]);
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x51);
  }
  return;
}

// ==== CUserManager::helper_140044ab0  @140044ab0  [medium:callgraph-r1]  (orig: FUN_140044ab0)
longlong * FUN_140044ab0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140043be0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x51) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x51);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x51);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x51);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x51);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140043c90(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CUserManager::helper_14004d490  @14004d490  [medium:callgraph-r1]  (orig: FUN_14004d490)
void FUN_14004d490(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014004d4b4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserManager::helper_14004df10  @14004df10  [medium:callgraph-r1]  (orig: FUN_14004df10)
void FUN_14004df10(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserManager::helper_14004df70  @14004df70  [medium:callgraph-r1]  (orig: FUN_14004df70)
void FUN_14004df70(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserManager::helper_14004ee60  @14004ee60  [medium:callgraph-r0]  (orig: FUN_14004ee60)
undefined8 * FUN_14004ee60(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14004d490(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14004f04c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14004f04c:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_14004df10(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_14004df70(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_14004df10(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_14004df70(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_14004df10(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_14004df70(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CUserManager::helper_14008ab90  @14008ab90  [medium:callgraph-r0]  (orig: FUN_14008ab90)
int FUN_14008ab90(longlong param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2ac);
  if (*(int *)(param_1 + 0x2ac) < 1) {
    iVar1 = 0;
  }
  return iVar1;
}

// ==== CUserManager::helper_140099010  @140099010  [medium:callgraph-r2]  (orig: FUN_140099010)
undefined8 *
FUN_140099010(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    *(undefined1 *)(puVar1 + 4) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_1400a26b0  @1400a26b0  [medium:callgraph-r1]  (orig: FUN_1400a26b0)
undefined8 *
FUN_1400a26b0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x1ffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140099010(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x20);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x21) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x21) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x20);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x20) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_1400a8190  @1400a8190  [medium:callgraph-r0]  (orig: FUN_1400a8190)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400a8190(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined8 local_4b8;
  undefined1 local_4a8 [1152];
  ulonglong local_28;
  
  local_4b8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (param_2 == 0) {
    local_4c8 = 0x15c1;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1402c36e0(local_4a8);
    cVar4 = FUN_1402c3770(local_4a8);
    if (cVar4 == '\0') {
      local_4c8 = 0x15c4;
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_1402c3730(local_4a8);
    }
    else {
      cVar4 = FUN_1402c39d0(local_4a8,*(undefined4 *)(param_1 + 0x404),param_1 + 0x408);
      if (cVar4 != '\0') {
        plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x468);
        plVar1 = *(longlong **)(param_1 + 0x438);
        do {
          plVar2 = *(longlong **)(param_1 + 0x468);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x438))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar2) {
            cVar4 = FUN_1402c37c0(local_4a8);
            if (cVar4 != '\0') {
              (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_4a8);
            }
            FUN_1402c3730(local_4a8);
            return;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          cVar4 = FUN_1402c39d0(local_4a8,(int)plVar5[3],(longlong)plVar5 + 0x1c);
          if (cVar4 == '\0') {
            cVar4 = FUN_1402c37c0(local_4a8);
            if (cVar4 != '\0') {
              (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_4a8);
            }
            cVar4 = FUN_1402c3770(local_4a8);
            if (cVar4 == '\0') {
              local_4c8 = 0x15d2;
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1402c3730(local_4a8);
              return;
            }
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar1;
            }
            if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            cVar4 = FUN_1402c39d0(local_4a8,(int)plVar5[3],(longlong)plVar5 + 0x1c);
            if (cVar4 == '\0') {
              local_4c8 = 0x15d3;
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1402c3730(local_4a8);
              return;
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x49) == '\0') {
            plVar2 = (longlong *)plVar5[2];
            if (*(char *)((longlong)plVar2 + 0x49) == '\0') {
              cVar4 = *(char *)(*plVar2 + 0x49);
              plVar5 = plVar2;
              plVar2 = (longlong *)*plVar2;
              while (cVar4 == '\0') {
                cVar4 = *(char *)(*plVar2 + 0x49);
                plVar5 = plVar2;
                plVar2 = (longlong *)*plVar2;
              }
            }
            else {
              cVar4 = *(char *)(plVar5[1] + 0x49);
              plVar3 = (longlong *)plVar5[1];
              plVar2 = plVar5;
              while ((plVar5 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar5[2]))) {
                cVar4 = *(char *)(plVar5[1] + 0x49);
                plVar3 = (longlong *)plVar5[1];
                plVar2 = plVar5;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        } while( true );
      }
      local_4c8 = 0x15c5;
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_1402c3730(local_4a8);
    }
  }
  return;
}

// ==== CUserManager::helper_1400a85a0  @1400a85a0  [medium:callgraph-r0]  (orig: FUN_1400a85a0)
longlong * FUN_1400a85a0(longlong *param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x21) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < *(int *)(puVar8 + 3);
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x21) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_1400a86fd:
    local_30 = puVar4;
    if (*param_3 <= *(int *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1400a872c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x21) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x21);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x21);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x21);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x21);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x21) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1400a86fd;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_1400a26b0(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1400a872c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_1400c7720  @1400c7720  [medium:callgraph-r1]  (orig: FUN_1400c7720)
longlong FUN_1400c7720(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CUserManager::helper_1400c7940  @1400c7940  [medium:callgraph-r2]  (orig: FUN_1400c7940)
undefined8 FUN_1400c7940(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
                    /* WARNING: Could not recover jumptable at 0x0001400c7995. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CUserManager::helper_1400c79a0  @1400c79a0  [medium:callgraph-r2]  (orig: FUN_1400c79a0)
undefined8 FUN_1400c79a0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
                    /* WARNING: Could not recover jumptable at 0x0001400c79f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CUserManager::helper_1400c7a60  @1400c7a60  [medium:callgraph-r2]  (orig: FUN_1400c7a60)
undefined8 FUN_1400c7a60(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),0);
                    /* WARNING: Could not recover jumptable at 0x0001400c7ab2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CUserManager::helper_1400c7ca0  @1400c7ca0  [medium:callgraph-r2]  (orig: FUN_1400c7ca0)
undefined1 FUN_1400c7ca0(undefined8 param_1,longlong param_2)

{
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14032a550(param_2);
  return 1;
}

// ==== CUserManager::helper_1400cdd10  @1400cdd10  [medium:callgraph-r1]  (orig: FUN_1400cdd10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400cdd10(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined2 uVar4;
  short sVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == 0) {
    log_InlineLogERROR("COperatingActMgr::SendAllActivityInfo, pUser is NULL.");
    return;
  }
  FUN_14035b850(local_478);
  FUN_14035b900(local_478,0);
  plVar11 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  plVar1 = *(longlong **)(param_1 + 8);
  do {
    plVar10 = *(longlong **)(param_1 + 0x38);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar11 == plVar10) {
      sVar5 = FUN_14035bb10(local_478);
      if (sVar5 != 0) {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478)
        ;
      }
      FUN_14035b8a0(local_478);
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = 0;
    }
    else {
      lVar12 = *plVar1;
    }
    if (plVar11 == *(longlong **)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar12 = plVar11[4];
    if (lVar12 == 0) goto LAB_1400ce037;
    if (*(longlong *)(lVar12 + 8) == 0) {
      local_498 = 0x31;
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1400cde7a:
      if (*(longlong *)(lVar12 + 8) == 0) {
        local_498 = 0x2f;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar7 = 0;
      }
      else {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),5);
        uVar7 = (**(code **)(*plVar10 + 0x50))(plVar10);
      }
      if (*(longlong *)(lVar12 + 8) == 0) {
        local_498 = 0x2d;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar8 = 0;
      }
      else {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),4);
        uVar8 = (**(code **)(*plVar10 + 0x50))(plVar10);
      }
      if (*(longlong *)(lVar12 + 8) == 0) {
        local_498 = 0x31;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar4 = 0;
      }
      else {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),6);
        uVar4 = (**(code **)(*plVar10 + 0x50))(plVar10);
      }
      if (*(longlong *)(lVar12 + 8) == 0) {
        local_498 = 0x25;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar9 = 0;
      }
      else {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),0);
        uVar9 = (**(code **)(*plVar10 + 0x50))(plVar10);
      }
      local_498 = uVar7;
      cVar3 = FUN_14035b930(local_478,uVar9,uVar4,uVar8);
      if (cVar3 == '\0') {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478)
        ;
        cVar3 = FUN_14035b900(local_478,0);
        if (cVar3 == '\0') {
          local_498 = 0x5a5;
          log_InlineLogERROR(&DAT_1406d9c10);
          FUN_14035b8a0(local_478);
          return;
        }
        uVar7 = FUN_1400c79a0(lVar12);
        uVar8 = FUN_1400c7940(lVar12);
        uVar4 = FUN_1400c7a00(lVar12);
        uVar9 = FUN_1400c77c0(lVar12);
        local_498 = uVar7;
        FUN_14035b930(local_478,uVar9,uVar4,uVar8);
      }
    }
    else {
      plVar10 = (longlong *)
                (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),6);
      iVar6 = (**(code **)(*plVar10 + 0x50))(plVar10);
      if (iVar6 == 0) goto LAB_1400cde7a;
      if (*(longlong *)(lVar12 + 8) == 0) {
        local_498 = 0x31;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)(lVar12 + 8) + 0x10))(*(longlong **)(lVar12 + 8),6);
        iVar6 = (**(code **)(*plVar10 + 0x50))(plVar10);
        if (iVar6 == 1) goto LAB_1400cde7a;
      }
    }
LAB_1400ce037:
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
      plVar10 = (longlong *)plVar11[2];
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar10 + 0x29);
        plVar11 = plVar10;
        plVar10 = (longlong *)*plVar10;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar10 + 0x29);
          plVar11 = plVar10;
          plVar10 = (longlong *)*plVar10;
        }
      }
      else {
        cVar3 = *(char *)(plVar11[1] + 0x29);
        plVar2 = (longlong *)plVar11[1];
        plVar10 = plVar11;
        while ((plVar11 = plVar2, cVar3 == '\0' && (plVar10 == (longlong *)plVar11[2]))) {
          cVar3 = *(char *)(plVar11[1] + 0x29);
          plVar2 = (longlong *)plVar11[1];
          plVar10 = plVar11;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CUserManager::helper_1400cfac0  @1400cfac0  [medium:callgraph-r2]  (orig: FUN_1400cfac0)
ulonglong FUN_1400cfac0(longlong param_1,uint param_2)

{
  char cVar1;
  ulonglong *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong lVar5;
  uint uVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  ulonglong uVar11;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  ulonglong *local_18;
  longlong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar4 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x29);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar4;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar10) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar9 = &local_38;
  }
  puVar2 = (ulonglong *)*plVar9;
  lVar3 = *(longlong *)(param_1 + 0x38);
  local_18 = puVar2;
  local_10 = plVar9[1];
  if ((puVar2 == (ulonglong *)0x0) || (puVar2 != *(ulonglong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 == lVar3) {
    uVar8 = 0xffffffff;
  }
  else {
    uVar8 = 0;
    if (puVar2 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar11 = uVar8;
    }
    else {
      uVar11 = *puVar2;
    }
    if (lVar5 == *(longlong *)(uVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = *(longlong *)(lVar5 + 0x20);
    if (*(longlong *)(lVar3 + 8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar9 = *(longlong **)(lVar3 + 8);
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,6);
      uVar6 = (**(code **)(*plVar9 + 0x50))(plVar9);
      uVar8 = (ulonglong)uVar6;
    }
  }
  return uVar8;
}

// ==== CUserManager::helper_1400cfc10  @1400cfc10  [medium:callgraph-r1]  (orig: FUN_1400cfc10)
ulonglong FUN_1400cfc10(longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 - 8;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1400cfc87;
  }
  _invalid_parameter_noinfo();
LAB_1400cfc87:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CUserManager::helper_1400cfd50  @1400cfd50  [medium:callgraph-r2]  (orig: FUN_1400cfd50)
undefined8 * FUN_1400cfd50(longlong param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  bool bVar4;
  undefined1 local_18 [16];
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  bVar4 = true;
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar2;
      bVar4 = *param_3 < *(uint *)(puVar3 + 3);
      if (bVar4) {
        puVar2 = (undefined8 *)*puVar3;
      }
      else {
        puVar2 = (undefined8 *)puVar3[2];
      }
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar3 = (undefined8 *)FUN_1400ccde0(param_1,local_18,bVar4,puVar3,param_3);
  uVar1 = puVar3[1];
  *param_2 = *puVar3;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CUserManager::helper_1400d0ec0  @1400d0ec0  [medium:callgraph-r3]  (orig: FUN_1400d0ec0)
void FUN_1400d0ec0(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0xfffffffffffffff - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1400c8a60();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0xfffffffffffffff - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30) >> 1;
  _Dst_00 = (void *)FUN_1400ca980(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CUserManager::helper_1400d33c0  @1400d33c0  [medium:callgraph-r2]  (orig: FUN_1400d33c0)
void FUN_1400d33c0(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (((*(char *)(param_1 + 0x30) + (char)*(longlong *)(param_1 + 0x38) & 1U) == 0) &&
     (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 2U >> 1)) {
    FUN_1400d0ec0(param_1,1);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  uVar4 = uVar3 >> 1;
  if (*(ulonglong *)(param_1 + 0x28) <= uVar4) {
    uVar4 = uVar4 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) == 0) {
    pvVar2 = operator_new(0x10);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) = pvVar2;
  }
  puVar1 = (undefined8 *)
           (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) +
           (ulonglong)((uint)uVar3 & 1) * 8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = *param_2;
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CUserManager::helper_1400d49e0  @1400d49e0  [medium:callgraph-r1]  (orig: FUN_1400d49e0)
undefined8 FUN_1400d49e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  uint uVar13;
  bool bVar15;
  undefined4 local_res10 [2];
  longlong *local_res18;
  longlong *local_res20;
  undefined8 *local_f8;
  longlong *plStack_f0;
  longlong *local_e8;
  longlong *local_e0 [3];
  void *local_c8;
  longlong local_c0;
  undefined8 local_b8;
  longlong local_b0;
  longlong *local_a8;
  undefined4 local_a0;
  undefined4 uStack_9c;
  longlong *local_98;
  undefined8 *local_90;
  longlong *local_88;
  undefined8 *local_78;
  longlong *plStack_70;
  longlong local_68 [3];
  undefined8 local_50;
  longlong *plVar14;
  
  local_50 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  FUN_1400cea50(param_1 + 0x88,&local_a0,local_res10);
  puVar2 = (undefined8 *)CONCAT44(uStack_9c,local_a0);
  plStack_f0 = local_98;
  plVar10 = (longlong *)0x0;
  plVar9 = local_98;
  plVar14 = plVar10;
  local_f8 = puVar2;
  while( true ) {
    if ((puVar2 == (undefined8 *)0x0) || (puVar2 != local_90)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == local_88) goto LAB_1400d4baf;
    uVar13 = (int)plVar14 + 1;
    plVar14 = (longlong *)(ulonglong)uVar13;
    if (10000 < (int)uVar13) break;
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar12 = plVar10;
    }
    else {
      plVar12 = (longlong *)*puVar2;
    }
    if (plVar9 == (longlong *)plVar12[6]) {
      _invalid_parameter_noinfo();
    }
    plVar12 = plStack_f0;
    puVar3 = local_f8;
    lVar8 = plVar9[4];
    local_b0 = lVar8;
    if (puVar2 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar11 = plVar9;
      plVar4 = (longlong *)plVar9[2];
      if (*(char *)(plVar9[2] + 0x29) == '\0') {
        do {
          plVar9 = plVar4;
          plVar4 = (longlong *)*plVar9;
          plStack_f0 = plVar9;
          local_a8 = plVar9;
        } while (*(char *)(*plVar9 + 0x29) == '\0');
      }
      else {
        do {
          plVar9 = (longlong *)plVar11[1];
          plStack_f0 = plVar9;
          if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
          bVar15 = plVar11 == (longlong *)plVar9[2];
          plVar11 = plVar9;
        } while (bVar15);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_78 = puVar3;
    plStack_70 = plVar12;
    FUN_1400cfdc0(param_1 + 0x88,local_68,&local_78);
    if (lVar8 != 0) {
      FUN_14032aa50(lVar8);
      local_b0 = 0;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1400d4baf:
  local_res18 = operator_new(8);
  local_e0[0] = plVar10;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)local_e0;
    local_e0[0] = local_res18;
  }
  local_c8 = (void *)0x0;
  local_c0 = 0;
  local_b8 = 0;
  local_res20 = local_res18;
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x188));
  if (*(longlong *)(lVar8 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar10 = *(longlong **)(lVar8 + 0x170);
  }
  FUN_140313fc0(plVar10,local_e0,local_res10[0],0x22);
  while ((local_c0 - (longlong)local_c8 & 0xfffffffffffffff8U) != 0) {
    plVar9 = (longlong *)FUN_1400cfc10(local_e0);
    plVar9 = (longlong *)*plVar9;
    if ((local_c0 - (longlong)local_c8 & 0xfffffffffffffff8U) != 0) {
      local_c0 = local_c0 + -8;
    }
    if (plVar9 != (longlong *)0x0) {
      plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
      iVar6 = (**(code **)(*plVar10 + 0x40))(plVar10);
      if (iVar6 == 0) {
        log_InlineLogERROR("COperatingActMgr::LoadOperatingUserInfo pRec activity id is 0");
        (**(code **)*plVar9)(plVar9,1);
      }
      else {
        plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0);
        uVar7 = (**(code **)(*plVar10 + 0x40))(plVar10);
        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
        lVar8 = *(longlong *)(param_1 + 0x138);
        lVar1 = *(longlong *)(param_1 + 0x108);
        local_68[0] = lVar1;
        plVar10 = (longlong *)FUN_140077480(param_1 + 0x108,&local_78,&local_res18);
        if ((*plVar10 == 0) || (*plVar10 != lVar1)) {
          _invalid_parameter_noinfo();
        }
        if (plVar10[1] == lVar8) {
          plVar10 = (longlong *)FUN_14032a780();
          local_e8 = plVar10;
          if (plVar10 == (longlong *)0x0) {
            log_InlineLogERROR(
                              "COperatingActMgr::LoadOperatingUserInfo pOperatingUserInfo CreateNew failed."
                              );
            (**(code **)*plVar9)(plVar9,1);
          }
          else {
            cVar5 = FUN_140329ee0(plVar10,plVar9);
            if (cVar5 == '\0') {
              log_InlineLogERROR(
                                "COperatingActMgr::LoadOperatingUserInfo pOperatingUserInfo->Create failed."
                                );
              FUN_14032aa50(plVar10);
              local_e8 = (longlong *)0x0;
            }
            else {
              iVar6 = FUN_1400cfac0(param_1,iVar6);
              if (iVar6 == 2) {
                uVar7 = FUN_1400c7a60(plVar10);
                local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar7);
                FUN_14000d480(param_1 + 0x108,local_68,&local_res20);
                FUN_1400d33c0(param_1 + 0x148,&local_e8);
              }
              else if (iVar6 == -1) {
                log_InlineLogWARNING
                          (
                          "COperatingActMgr::LoadOperatingUserInfo operating act status fault, idAct:%u, idUser:%u."
                          );
                FUN_1400c7ca0(param_1,plVar10);
                FUN_14032aa50(plVar10);
                local_e8 = (longlong *)0x0;
              }
              else {
                local_a0 = FUN_1400c7ac0(plVar10);
                local_98 = plVar10;
                FUN_1400cfd50(param_1 + 0x88,&local_f8,&local_a0);
              }
            }
          }
        }
        else {
          (**(code **)*plVar9)(plVar9,1);
        }
      }
    }
  }
  if (local_c8 != (void *)0x0) {
    operator_delete(local_c8);
  }
  local_c8 = (void *)0x0;
  local_c0 = 0;
  local_b8 = 0;
  operator_delete(local_e0[0]);
  return 1;
}

// ==== CUserManager::helper_1400d4ff0  @1400d4ff0  [medium:callgraph-r0]  (orig: FUN_1400d4ff0)
void FUN_1400d4ff0(undefined8 param_1,longlong *param_2)

{
  undefined4 uVar1;
  
  if (param_2 != (longlong *)0x0) {
    uVar1 = (**(code **)(*param_2 + 8))(param_2);
    FUN_1400d49e0(param_1,uVar1);
    FUN_1400cdd10(param_1,param_2);
    FUN_1400d40c0(param_1,param_2,1);
  }
  return;
}

// ==== CUserManager::helper_140111780  @140111780  [medium:callgraph-r1]  (orig: FUN_140111780)
undefined8 FUN_140111780(void)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140376fc0(0x30);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1403770e0(lVar1);
  }
  return uVar2;
}

// ==== CUserManager::helper_140112120  @140112120  [medium:callgraph-r3]  (orig: FUN_140112120)
undefined8 *
FUN_140112120(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_1401124f0  @1401124f0  [medium:callgraph-r2]  (orig: FUN_1401124f0)
undefined8 *
FUN_1401124f0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140112120(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_140112970  @140112970  [medium:callgraph-r1]  (orig: FUN_140112970)
longlong * FUN_140112970(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_140112acd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140112afc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140112acd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1401124f0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140112afc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_140113940  @140113940  [medium:callgraph-r1]  (orig: FUN_140113940)
void FUN_140113940(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined4 local_res10 [6];
  undefined1 local_28 [32];
  
  if ((param_2 != (longlong *)0x0) && (cVar1 = FUN_140167b70(param_2), cVar1 == '\0')) {
    local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_14000d480(param_1 + 0x58,local_28,local_res10);
  }
  return;
}

// ==== CUserManager::helper_140113f40  @140113f40  [medium:callgraph-r0]  (orig: FUN_140113f40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140113f40(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  longlong *local_4d8 [3];
  undefined8 *local_4c0;
  undefined8 *local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  undefined8 *local_4a0;
  longlong *local_498;
  undefined8 local_490;
  undefined1 local_488 [32];
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != (longlong *)0x0) {
    local_490 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_508;
    if ((*(char *)(param_1 + 0x51) != '\0') && (cVar3 = FUN_140167b70(param_2), cVar3 == '\0')) {
      FUN_140113940(param_1,param_2);
      local_4a8 = operator_new(8);
      plVar7 = (longlong *)0x0;
      local_4d8[0] = plVar7;
      if (local_4a8 != (longlong *)0x0) {
        *local_4a8 = (longlong)local_4d8;
        local_4d8[0] = local_4a8;
      }
      local_4c0 = (undefined8 *)0x0;
      local_4b8 = (undefined8 *)0x0;
      local_4b0 = 0;
      local_498 = local_4a8;
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      uVar5 = FUN_1400c7720(uVar5);
      FUN_140313fc0(uVar5,local_4d8,uVar4,0x18);
      if (((longlong)local_4b8 - (longlong)local_4c0 & 0xfffffffffffffff8U) == 8) {
        uVar4 = (**(code **)(*param_2 + 8))(param_2);
        local_498 = (longlong *)CONCAT44(local_498._4_4_,uVar4);
        FUN_140112ee0(param_1 + 0x10,&local_4a8,&local_498);
        lVar1 = *(longlong *)(param_1 + 0x40);
        if ((local_4a8 == (longlong *)0x0) || (local_4a8 != *(longlong **)(param_1 + 0x10))) {
          _invalid_parameter_noinfo();
        }
        if (local_4a0 == (undefined8 *)lVar1) {
          puVar6 = (undefined8 *)FUN_140111780();
          puVar2 = local_4c0;
          if (puVar6 == (undefined8 *)0x0) {
            log_InlineLogERROR("CAchievementMgr::OnUserLogin. pAchInfo is NULL!");
            if (local_4c0 != (undefined8 *)0x0) {
              operator_delete(local_4c0);
            }
            local_4c0 = (undefined8 *)0x0;
            local_4b8 = (undefined8 *)0x0;
            local_4b0 = 0;
            operator_delete(local_4d8[0]);
          }
          else {
            if (local_4b8 < local_4c0) {
              _invalid_parameter_noinfo();
            }
            if (local_4d8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              plVar7 = (longlong *)*local_4d8[0];
            }
            if ((undefined8 *)plVar7[4] <= puVar2) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_140377160(puVar6,param_2,*(undefined8 *)(param_1 + 0x98),*puVar2);
            if (cVar3 == '\0') {
              log_InlineLogERROR("CAchievementMgr::OnUserLogin. pAchInfo->Create() fail!");
              (**(code **)*puVar6)(puVar6,1);
              if (local_4c0 != (undefined8 *)0x0) {
                operator_delete(local_4c0);
              }
              local_4c0 = (undefined8 *)0x0;
              local_4b8 = (undefined8 *)0x0;
              local_4b0 = 0;
              operator_delete(local_4d8[0]);
            }
            else {
              uVar4 = (**(code **)(*param_2 + 8))(param_2);
              local_4a8 = (longlong *)CONCAT44(local_4a8._4_4_,uVar4);
              local_4a0 = puVar6;
              FUN_140112970(param_1 + 0x10,local_488,&local_4a8);
              FUN_1401628c0(param_2,puVar6);
              FUN_1403768c0(puVar6);
              if (local_4c0 != (undefined8 *)0x0) {
                operator_delete(local_4c0);
              }
              local_4c0 = (undefined8 *)0x0;
              local_4b8 = (undefined8 *)0x0;
              local_4b0 = 0;
              operator_delete(local_4d8[0]);
            }
          }
        }
        else {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogWARNING("CAchievementMgr::OnUserLogin. User[%u] is found!");
          if (local_4c0 != (undefined8 *)0x0) {
            operator_delete(local_4c0);
          }
          local_4c0 = (undefined8 *)0x0;
          local_4b8 = (undefined8 *)0x0;
          local_4b0 = 0;
          operator_delete(local_4d8[0]);
        }
      }
      else {
        FUN_1403778c0(local_468);
        uVar4 = (**(code **)(*param_2 + 8))(param_2);
        cVar3 = FUN_1403779f0(local_468,0,uVar4,0);
        if (cVar3 == '\0') {
          local_4e8 = 0x156;
          log_InlineLogERROR(&DAT_1406d9c10);
          FUN_140377910(local_468);
          if (local_4c0 != (undefined8 *)0x0) {
            operator_delete(local_4c0);
          }
          local_4c0 = (undefined8 *)0x0;
          local_4b8 = (undefined8 *)0x0;
          local_4b0 = 0;
          operator_delete(local_4d8[0]);
        }
        else {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_468);
          FUN_140377910(local_468);
          if (local_4c0 != (undefined8 *)0x0) {
            operator_delete(local_4c0);
          }
          local_4c0 = (undefined8 *)0x0;
          local_4b8 = (undefined8 *)0x0;
          local_4b0 = 0;
          operator_delete(local_4d8[0]);
        }
      }
    }
  }
  return;
}

// ==== CUserManager::helper_140151aa0  @140151aa0  [medium:callgraph-r2]  (orig: FUN_140151aa0)
void FUN_140151aa0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserManager::helper_140151d60  @140151d60  [medium:callgraph-r2]  (orig: FUN_140151d60)
void FUN_140151d60(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140151d84. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserManager::helper_140152fc0  @140152fc0  [medium:callgraph-r2]  (orig: FUN_140152fc0)
void FUN_140152fc0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserManager::helper_1401566a0  @1401566a0  [medium:callgraph-r1]  (orig: FUN_1401566a0)
undefined8 * FUN_1401566a0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140151d60(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14015688c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14015688c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140152fc0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140151aa0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140152fc0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140151aa0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140152fc0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_140151aa0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CUserManager::helper_140157940  @140157940  [medium:callgraph-r0]  (orig: FUN_140157940)
void FUN_140157940(longlong param_1,int param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  char cVar3;
  longlong lVar4;
  int local_res10 [2];
  int local_58;
  undefined4 uStack_54;
  undefined8 *puStack_50;
  undefined1 local_48 [32];
  
  local_res10[0] = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140156a60((longlong *)(param_1 + 8),&local_58,local_res10);
    lVar4 = *(longlong *)(param_1 + 0x38);
    plVar2 = (longlong *)CONCAT44(uStack_54,local_58);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (puStack_50 != (undefined8 *)lVar4) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar2;
      }
      if (puStack_50 == (undefined8 *)*(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)((longlong)puStack_50 + 0x20) != 0) {
        puVar1 = *(undefined8 **)((longlong)puStack_50 + 0x20);
        FUN_1403aee70(puVar1);
        if (puVar1 != (undefined8 *)0x0) {
          (**(code **)*puVar1)(puVar1,1);
        }
        *(undefined8 *)((longlong)puStack_50 + 0x20) = 0;
      }
      FUN_1401566a0(param_1 + 8,local_48,&local_58);
    }
    puStack_50 = (undefined8 *)FUN_1403b0320(*(undefined4 *)(param_1 + 0x48),param_2,0);
    if (puStack_50 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar3 = FUN_1403af820(puStack_50);
      if (cVar3 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
        log_InlineLogERROR("pUserAstProf->Init() falil.");
        FUN_1403aee70(puStack_50);
        (**(code **)*puStack_50)(puStack_50,1);
      }
      else {
        local_58 = param_2;
        FUN_1401564f0(param_1 + 8,local_48,&local_58);
      }
    }
  }
  return;
}

// ==== CUserManager::helper_1401628c0  @1401628c0  [medium:callgraph-r1]  (orig: FUN_1401628c0)
void FUN_1401628c0(longlong param_1,undefined8 param_2)

{
  *(undefined8 *)(param_1 + 0xb38) = param_2;
  return;
}

// ==== CUserManager::helper_140163380  @140163380  [medium:callgraph-r1]  (orig: FUN_140163380)
undefined8 FUN_140163380(longlong param_1)

{
  short sVar1;
  int iVar2;
  uint uVar3;
  ulonglong uVar4;
  undefined2 uVar5;
  
  uVar5 = 0;
  iVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x198))(param_1 + 0x10);
  uVar3 = iVar2 - 1;
  uVar4 = (ulonglong)uVar3;
  if (uVar3 < 0xc) {
    uVar4 = (ulonglong)(int)uVar3;
    sVar1 = (short)(uVar3 >> 0x10);
    switch(uVar3) {
    case 0:
    case 2:
      return CONCAT62((int6)sVar1,100);
    case 4:
    case 6:
      return CONCAT62((int6)sVar1,200);
    case 8:
      return CONCAT62((int6)sVar1,300);
    case 0xb:
      uVar5 = 400;
    }
  }
  return CONCAT62((int6)(uVar4 >> 0x10),uVar5);
}

// ==== CUserManager::helper_140163440  @140163440  [medium:callgraph-r0]  (orig: FUN_140163440)
void FUN_140163440(longlong param_1)

{
  FUN_1403719c0(param_1 + 0xe78);
  return;
}

// ==== CUserManager::helper_140163490  @140163490  [medium:callgraph-r1]  (orig: FUN_140163490)
void FUN_140163490(longlong param_1,ushort param_2,undefined1 param_3)

{
  undefined2 uVar1;
  ushort uVar2;
  int iVar3;
  uint uVar4;
  
  iVar3 = tq::DateStamp(0);
  uVar4 = iVar3 % 10000;
  uVar2 = FUN_140371ac0(param_1 + 0xe78);
  uVar1 = (undefined2)(uVar4 >> 0x10);
  if (uVar4 == uVar2 / 10) {
    iVar3 = CONCAT22(uVar1,(short)uVar4 * 5) * 2;
    iVar3 = CONCAT22((short)((uint)iVar3 >> 0x10),(short)iVar3 + param_2 % 10);
  }
  else {
    iVar3 = CONCAT22(uVar1,(short)uVar4 * 5) * 2;
  }
  FUN_140371ad0(param_1 + 0xe78,iVar3,param_3);
  return;
}

// ==== CUserManager::helper_140167940  @140167940  [medium:callgraph-r0]  (orig: FUN_140167940)
undefined4 FUN_140167940(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x12f0);
}

// ==== CUserManager::helper_140168cb0  @140168cb0  [medium:callgraph-r0]  (orig: FUN_140168cb0)
void FUN_140168cb0(longlong *param_1)

{
  undefined4 uVar1;
  
  if (param_1[0x25d] != 0) {
    uVar1 = (**(code **)(*param_1 + 8))();
    FUN_1403b82a0(param_1[0x25d],uVar1);
  }
  return;
}

// ==== CUserManager::helper_14016d5a0  @14016d5a0  [medium:callgraph-r0]  (orig: FUN_14016d5a0)
void FUN_14016d5a0(__uint64 param_1)

{
  if ((DAT_140975e88 & 1) == 0) {
    DAT_140975e88 = DAT_140975e88 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975e80,"CUser");
    atexit((_func_5014 *)&LAB_1406d68e0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014016d5f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975e80,param_1);
  return;
}

// ==== CUserManager::helper_14016eb60  @14016eb60  [medium:callgraph-r1]  (orig: FUN_14016eb60)
undefined8 FUN_14016eb60(longlong param_1)

{
  undefined1 uVar1;
  char cVar2;
  ulong uVar3;
  undefined4 uVar4;
  longlong lVar5;
  
  *(undefined4 *)(param_1 + 0x514) = 900;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x518) = uVar3 / 1000;
  uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0xf0))(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x1128) = uVar4;
  uVar3 = tq::TimeGet(0);
  *(ulong *)(param_1 + 0x112c) = uVar3;
  *(undefined4 *)(param_1 + 0x1140) = 0x1e;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1144) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1178) = 10;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x117c) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1180) = 5;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1184) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1148) = 0x168;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x114c) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1150) = 0x3c;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1154) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1158) = 5;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x115c) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x1160) = 300;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1164) = uVar3 / 1000;
  *(undefined4 *)(param_1 + 0x11fc) = 600;
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x1200) = uVar3 / 1000;
  lVar5 = FUN_1403e9370(0x20);
  if (lVar5 == 0) {
    lVar5 = 0;
  }
  else {
    lVar5 = FUN_1403e8ca0(lVar5,*(undefined4 *)(param_1 + 0x1230),param_1 + 0x10);
  }
  *(longlong *)(param_1 + 0x1120) = lVar5;
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = FUN_1403bc150(*(undefined4 *)(param_1 + 0x1230));
  *(longlong *)(param_1 + 0x1118) = lVar5;
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = FUN_1403b26b0(*(undefined4 *)(param_1 + 0x1230),param_1);
  *(longlong *)(param_1 + 0x1260) = lVar5;
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar1 = FUN_140167b70(param_1);
  lVar5 = FUN_1403b7e60(*(undefined4 *)(param_1 + 0x1230),uVar1);
  *(longlong *)(param_1 + 0x12e8) = lVar5;
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  cVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x230))(param_1 + 0x10);
  if ((cVar2 != '\0') &&
     (cVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x238))(param_1 + 0x10), cVar2 == '\0'))
  {
    *(undefined1 *)(param_1 + 0x108) = 0;
    return 1;
  }
  *(undefined1 *)(param_1 + 0x108) = 1;
  return 1;
}

// ==== CUserManager::helper_1401727e0  @1401727e0  [medium:callgraph-r0]  (orig: FUN_1401727e0)
void FUN_1401727e0(longlong param_1)

{
  short sVar1;
  ushort uVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  
  iVar3 = tq::DateStamp(0);
  uVar6 = iVar3 % 10000;
  uVar2 = FUN_140371ac0(param_1 + 0xe78);
  if (uVar6 != uVar2 / 10) {
    uVar5 = 0;
    uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
    if (0x59 < uVar4) {
      uVar4 = *(uint *)(param_1 + 0x100);
      if ((-1 < (int)uVar4) && (uVar5 = uVar4, 6 < uVar4)) {
        uVar5 = 6;
      }
      sVar1 = (&DAT_1407170a8)[(int)uVar5];
      iVar3 = FUN_140163380(param_1);
      uVar5 = (uint)(ushort)(sVar1 + 100) + iVar3;
    }
    FUN_140371950(param_1 + 0xe78,uVar5 & 0xffff,0);
    FUN_140163490(param_1,CONCAT22((short)(uVar6 >> 0x10),(short)uVar6 * 5) * 2,0);
  }
  return;
}

// ==== CUserManager::helper_1401728d0  @1401728d0  [medium:callgraph-r0]  (orig: FUN_1401728d0)
int FUN_1401728d0(longlong param_1)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 0xb40) = 0x4b0;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0xb44) = uVar1 / 1000;
  return uVar1 * 0x10624dd3;
}

// ==== CUserManager::helper_14018bc60  @14018bc60  [medium:callgraph-r1]  (orig: FUN_14018bc60)
void FUN_14018bc60(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14018bc60(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CUserManager::helper_1401a41f0  @1401a41f0  [medium:callgraph-r1]  (orig: FUN_1401a41f0)
undefined8 FUN_1401a41f0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res8 [2];
  undefined1 local_28 [32];
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x20))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    return 0;
  }
  local_res8[0] =
       (**(code **)(**(longlong **)(lVar1 + 0x58) + 0x10))(*(longlong **)(lVar1 + 0x58),3);
  FUN_14000d480(param_1 + 0x1370,local_28,local_res8);
  return 1;
}

// ==== CUserManager::helper_1401d2650  @1401d2650  [medium:callgraph-r1]  (orig: FUN_1401d2650)
undefined8 FUN_1401d2650(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  if ((DAT_140975e88 & 1) == 0) {
    DAT_140975e88 = DAT_140975e88 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975e80,"CUser");
    atexit((_func_5014 *)&LAB_1406d68e0);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975e80,0x1418);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1401d0da0(pvVar1);
  }
  return uVar2;
}

// ==== CUserManager::helper_1401d26c0  @1401d26c0  [medium:callgraph-r0]  (orig: FUN_1401d26c0)
longlong FUN_1401d26c0(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  uint in_stack_ffffffffffffffe8;
  
  iVar2 = FUN_1400084e0();
  if (iVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 != (undefined4 *)0x0) {
    lVar3 = FUN_1401d2650();
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    else {
      *(undefined4 *)(lVar3 + 0x1230) = param_1;
      *(undefined4 *)(lVar3 + 0x122c) = param_2;
      memcpy((void *)(lVar3 + 0xe80),param_3,0x228);
      plVar4 = (longlong *)InstanceGet();
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,"cq_user");
      *(longlong **)(lVar3 + 0x10a8) = plVar4;
      if (plVar4 == (longlong *)0x0) {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 8))(lVar3 + 0x10);
        lVar3 = 0;
      }
      else {
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,&DAT_1406de8d4);
        (**(code **)(*plVar4 + 0xb8))(plVar4,*param_3);
        FUN_14016eb60(lVar3);
        *(undefined8 *)(lVar3 + 0x1100) = 0;
        if (((*(int *)(lVar3 + 0xf9c) != 0) && (*(int *)(lVar3 + 4000) != 0)) &&
           (cVar1 = FUN_140172b80(lVar3,*(int *)(lVar3 + 0xf9c),*(int *)(lVar3 + 4000),1,
                                  in_stack_ffffffffffffffe8 & 0xffffff00), cVar1 == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
      }
    }
    return lVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CUserManager::helper_1401e55f0  @1401e55f0  [medium:callgraph-r1]  (orig: FUN_1401e55f0)
undefined8 FUN_1401e55f0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong *plVar11;
  longlong *local_b8 [3];
  longlong *local_a0;
  longlong *local_98;
  undefined8 local_90;
  longlong *local_88;
  longlong *local_80;
  undefined8 *local_78;
  undefined4 local_70 [2];
  longlong local_68;
  longlong *local_60 [3];
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  if (param_2 == (longlong *)0x0) {
    uVar4 = 0;
  }
  else {
    plVar8 = (longlong *)0x0;
    plVar5 = operator_new(8);
    local_b8[0] = plVar8;
    if (plVar5 != (longlong *)0x0) {
      *plVar5 = (longlong)local_b8;
      local_b8[0] = plVar5;
    }
    local_a0 = (longlong *)0x0;
    local_98 = (longlong *)0x0;
    local_90 = 0;
    lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar6 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar5 = plVar8;
    }
    else {
      plVar5 = *(longlong **)(lVar6 + 0x170);
    }
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    FUN_140313fc0(plVar5,local_b8,uVar3,0x1e);
    uVar10 = (longlong)local_98 - (longlong)local_a0 >> 3;
    if (uVar10 == 0) {
      if (local_a0 != (longlong *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (longlong *)0x0;
      local_98 = (longlong *)0x0;
      local_90 = 0;
      operator_delete(local_b8[0]);
      uVar4 = 0;
    }
    else {
      if (uVar10 == 1) {
        puVar7 = (undefined8 *)FUN_1400cfc10(local_b8);
        plVar5 = (longlong *)*puVar7;
      }
      else {
        plVar5 = plVar8;
        if (1 < uVar10) {
          puVar7 = (undefined8 *)FUN_1400cfc10(local_b8);
          plVar9 = local_a0;
          plVar5 = (longlong *)*puVar7;
          if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffff8U) != 0) {
            local_98 = local_98 + -1;
          }
          local_88 = (longlong *)0x0;
          if (local_98 < local_a0) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_b8[0];
          local_88 = local_b8[0];
          while( true ) {
            plVar11 = local_98;
            local_60[0] = (longlong *)0x0;
            local_80 = plVar9;
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            local_60[0] = local_b8[0];
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_b8[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar9 == plVar11) break;
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar11 = plVar8;
            }
            else {
              plVar11 = (longlong *)*plVar1;
            }
            if ((longlong *)plVar11[4] <= plVar9) {
              _invalid_parameter_noinfo();
            }
            local_78 = (undefined8 *)*plVar9;
            if (local_78 != (undefined8 *)0x0) {
              (**(code **)*local_78)(local_78,1);
            }
            local_78 = (undefined8 *)0x0;
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar11 = plVar8;
            }
            else {
              plVar11 = (longlong *)*plVar1;
            }
            if ((longlong *)plVar11[4] <= plVar9) {
              _invalid_parameter_noinfo();
            }
            plVar9 = plVar9 + 1;
          }
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CJiangHuMgr::LoadUserJiangHuData,player(%u) data not only at %s, %d");
        }
      }
      FUN_1400179f0(local_b8);
      if (plVar5 == (longlong *)0x0) {
        if (local_a0 != (longlong *)0x0) {
          operator_delete(local_a0);
        }
        local_a0 = (longlong *)0x0;
        local_98 = (longlong *)0x0;
        local_90 = 0;
        operator_delete(local_b8[0]);
        uVar4 = 0;
      }
      else {
        uVar3 = (**(code **)(*param_2 + 8))(param_2);
        lVar6 = FUN_1403fdd90(*(undefined4 *)(param_1 + 8),uVar3,plVar5,0);
        if (lVar6 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          (**(code **)*plVar5)(plVar5,1);
          if (local_a0 != (longlong *)0x0) {
            operator_delete(local_a0);
          }
          local_a0 = (longlong *)0x0;
          local_98 = (longlong *)0x0;
          local_90 = 0;
          operator_delete(local_b8[0]);
          uVar4 = 0;
        }
        else {
          cVar2 = FUN_1403fe5c0(lVar6,1);
          if (cVar2 == '\0') {
            FUN_1403fdeb0(lVar6);
            if (local_a0 != (longlong *)0x0) {
              operator_delete(local_a0);
            }
            local_a0 = (longlong *)0x0;
            local_98 = (longlong *)0x0;
            local_90 = 0;
            operator_delete(local_b8[0]);
            uVar4 = 0;
          }
          else {
            local_70[0] = (**(code **)(*param_2 + 8))(param_2);
            local_68 = lVar6;
            FUN_1401e2940(param_1 + 0x90,local_60,local_70);
            if (local_a0 != (longlong *)0x0) {
              operator_delete(local_a0);
            }
            local_a0 = (longlong *)0x0;
            local_98 = (longlong *)0x0;
            local_90 = 0;
            operator_delete(local_b8[0]);
            uVar4 = 1;
          }
        }
      }
    }
  }
  return uVar4;
}

// ==== CUserManager::helper_1401e5a10  @1401e5a10  [medium:callgraph-r1]  (orig: FUN_1401e5a10)
undefined8 FUN_1401e5a10(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong *local_b8 [3];
  longlong *local_a0;
  longlong *local_98;
  undefined8 local_90;
  longlong *local_88;
  longlong *local_80;
  undefined8 *local_78;
  undefined4 local_70 [2];
  longlong local_68;
  longlong *local_60 [3];
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  plVar6 = (longlong *)0x0;
  plVar2 = operator_new(8);
  local_b8[0] = plVar6;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)local_b8;
    local_b8[0] = plVar2;
  }
  local_a0 = (longlong *)0x0;
  local_98 = (longlong *)0x0;
  local_90 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = plVar6;
  }
  else {
    plVar2 = *(longlong **)(lVar3 + 0x170);
  }
  FUN_140313fc0(plVar2,local_b8,param_2,0x1f);
  uVar8 = (longlong)local_98 - (longlong)local_a0 >> 3;
  if (uVar8 == 0) {
    if (local_a0 != (longlong *)0x0) {
      operator_delete(local_a0);
    }
    local_a0 = (longlong *)0x0;
    local_98 = (longlong *)0x0;
    local_90 = 0;
    operator_delete(local_b8[0]);
    uVar4 = 0;
  }
  else {
    if (uVar8 == 1) {
      puVar5 = (undefined8 *)FUN_1400cfc10(local_b8);
      plVar2 = (longlong *)*puVar5;
    }
    else {
      plVar2 = plVar6;
      if (1 < uVar8) {
        puVar5 = (undefined8 *)FUN_1400cfc10(local_b8);
        plVar7 = local_a0;
        plVar2 = (longlong *)*puVar5;
        if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffff8U) != 0) {
          local_98 = local_98 + -1;
        }
        local_88 = (longlong *)0x0;
        if (local_98 < local_a0) {
          _invalid_parameter_noinfo();
        }
        plVar1 = local_b8[0];
        local_88 = local_b8[0];
        while( true ) {
          plVar9 = local_98;
          local_60[0] = (longlong *)0x0;
          local_80 = plVar7;
          if (local_98 < local_a0) {
            _invalid_parameter_noinfo();
          }
          local_60[0] = local_b8[0];
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_b8[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar7 == plVar9) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar9 = plVar6;
          }
          else {
            plVar9 = (longlong *)*plVar1;
          }
          if ((longlong *)plVar9[4] <= plVar7) {
            _invalid_parameter_noinfo();
          }
          local_78 = (undefined8 *)*plVar7;
          if (local_78 != (undefined8 *)0x0) {
            (**(code **)*local_78)(local_78,1);
          }
          local_78 = (undefined8 *)0x0;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar9 = plVar6;
          }
          else {
            plVar9 = (longlong *)*plVar1;
          }
          if ((longlong *)plVar9[4] <= plVar7) {
            _invalid_parameter_noinfo();
          }
          plVar7 = plVar7 + 1;
        }
        log_InlineLogERROR("CJiangHuMgr::LoadUserCaltivateTimes,player(%u) data not only at %s, %d")
        ;
      }
    }
    FUN_1400179f0(local_b8);
    if (plVar2 == (longlong *)0x0) {
      if (local_a0 != (longlong *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (longlong *)0x0;
      local_98 = (longlong *)0x0;
      local_90 = 0;
      operator_delete(local_b8[0]);
      uVar4 = 0;
    }
    else {
      local_68 = FUN_1403fec80(param_2,plVar2,0);
      if (local_68 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        (**(code **)*plVar2)(plVar2,1);
        if (local_a0 != (longlong *)0x0) {
          operator_delete(local_a0);
        }
        local_a0 = (longlong *)0x0;
        local_98 = (longlong *)0x0;
        local_90 = 0;
        operator_delete(local_b8[0]);
        uVar4 = 0;
      }
      else {
        local_70[0] = param_2;
        FUN_1401e2f80(param_1 + 0xd0,local_60,local_70);
        if (local_a0 != (longlong *)0x0) {
          operator_delete(local_a0);
        }
        local_a0 = (longlong *)0x0;
        local_98 = (longlong *)0x0;
        local_90 = 0;
        operator_delete(local_b8[0]);
        uVar4 = 1;
      }
    }
  }
  return uVar4;
}

// ==== CUserManager::helper_1401e5db0  @1401e5db0  [medium:callgraph-r1]  (orig: FUN_1401e5db0)
void FUN_1401e5db0(longlong param_1,ulonglong param_2)

{
  char cVar1;
  undefined4 local_30 [2];
  longlong local_28;
  undefined1 local_20 [24];
  
  local_28 = FUN_140400820(*(undefined4 *)(param_1 + 8),param_2,0);
  if (local_28 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar1 = FUN_1403ff890(local_28,param_2 & 0xffffffff);
    if (cVar1 == '\0') {
      FUN_1403ff130(local_28);
    }
    else {
      local_30[0] = (int)param_2;
      FUN_1401e35c0(param_1 + 0x150,local_20,local_30);
    }
  }
  return;
}

// ==== CUserManager::helper_1401f1190  @1401f1190  [medium:callgraph-r0]  (orig: FUN_1401f1190)
void FUN_1401f1190(undefined8 param_1,longlong *param_2)

{
  undefined4 uVar1;
  
  if (param_2 != (longlong *)0x0) {
    FUN_1401e55f0();
    uVar1 = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401e5a10(param_1,uVar1);
    uVar1 = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401e5db0(param_1,uVar1);
    FUN_1401e6e00(param_1,param_2,0,0,1);
    FUN_1401ef6d0(param_1,param_2,0,0,1);
    FUN_1401e7880(param_1,param_2,param_2);
  }
  return;
}

// ==== CUserManager::helper_1401f79d0  @1401f79d0  [medium:callgraph-r0]  (orig: FUN_1401f79d0)
undefined8 FUN_1401f79d0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined4 local_res18 [2];
  undefined4 local_68;
  undefined4 uStack_64;
  undefined8 uStack_60;
  longlong *local_58 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_1401f5550((longlong *)(param_1 + 0x18),&local_68,local_res18);
    lVar6 = *(longlong *)(param_1 + 0x48);
    local_58[0] = *(longlong **)(param_1 + 0x18);
    plVar1 = (longlong *)CONCAT44(uStack_64,local_68);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
      _invalid_parameter_noinfo();
    }
    lVar2 = uStack_60;
    if (uStack_60 != lVar6) {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR("CInnerStrengthMgr::OnUserLogin found user data, idUser:%u.");
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(lVar2 + 0x20) != 0) {
        FUN_1404056e0(*(undefined8 *)(lVar2 + 0x20));
        *(undefined8 *)(lVar2 + 0x20) = 0;
      }
      local_48 = local_68;
      uStack_44 = uStack_64;
      uStack_40 = (undefined4)uStack_60;
      uStack_3c = uStack_60._4_4_;
      FUN_1401f5190(param_1 + 0x18,local_58,&local_48);
    }
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    lVar6 = FUN_140408750(*(undefined4 *)(param_1 + 8),uVar4,0);
    if (lVar6 == 0) {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR(
                        "CInnerStrengthMgr::OnUserLogin CInnerStrengthPlayer::CreateNew failed, idUser:%u."
                        );
      uVar5 = 0;
    }
    else {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      cVar3 = FUN_140408850(lVar6,uVar4);
      if (cVar3 == '\0') {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CInnerStrengthPlayer::Create CInnerStrengthPlayer::Create failed, idUser:%u."
                          );
        FUN_1404056e0(lVar6);
        uVar5 = 0;
      }
      else {
        local_68 = (**(code **)(*param_2 + 8))(param_2);
        uStack_60 = lVar6;
        FUN_1401f4fe0(param_1 + 0x18,&local_48,&local_68);
        uVar4 = (**(code **)(*param_2 + 8))(param_2);
        FUN_1401f7300(param_1,param_2,uVar4,0);
        uVar5 = 1;
      }
    }
  }
  return uVar5;
}

// ==== CUserManager::helper_1401fe4f0  @1401fe4f0  [medium:callgraph-r2]  (orig: FUN_1401fe4f0)
void FUN_1401fe4f0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x2d) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserManager::helper_1401fe8c0  @1401fe8c0  [medium:callgraph-r2]  (orig: FUN_1401fe8c0)
void FUN_1401fe8c0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x2d) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x2d) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x2d);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x2d);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x2d);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x2d);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001401fe8e4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserManager::helper_1401ff9d0  @1401ff9d0  [medium:callgraph-r2]  (orig: FUN_1401ff9d0)
void FUN_1401ff9d0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x2d) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserManager::helper_140203bc0  @140203bc0  [medium:callgraph-r1]  (orig: FUN_140203bc0)
undefined8 * FUN_140203bc0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x2d) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1401fe8c0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x2d) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x2c);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x2c);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_140203dac;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x2d);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x2d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x2d);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x2d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_140203dac:
  if (*(char *)((longlong)plVar5 + 0x2c) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x2c) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x2c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x2c) = 0;
            FUN_1401ff9d0(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
            if ((*(char *)(*plVar11 + 0x2c) != '\x01') || (*(char *)(plVar11[2] + 0x2c) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x2c) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x2c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
                FUN_1401fe4f0(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x2c) = *(undefined1 *)((longlong)plVar10 + 0x2c);
              *(undefined1 *)((longlong)plVar10 + 0x2c) = 1;
              *(undefined1 *)(plVar11[2] + 0x2c) = 1;
              FUN_1401ff9d0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x2c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x2c) = 0;
            FUN_1401fe4f0(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
            if ((*(char *)(plVar11[2] + 0x2c) != '\x01') || (*(char *)(*plVar11 + 0x2c) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x2c) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x2c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
                FUN_1401ff9d0(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x2c) = *(undefined1 *)((longlong)plVar10 + 0x2c);
              *(undefined1 *)((longlong)plVar10 + 0x2c) = 1;
              *(undefined1 *)(*plVar11 + 0x2c) = 1;
              FUN_1401fe4f0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x2c) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CUserManager::helper_140208000  @140208000  [medium:callgraph-r0]  (orig: FUN_140208000)
void FUN_140208000(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plStack_40;
  longlong *local_38;
  longlong *plStack_30;
  undefined1 local_28 [32];
  
  if (param_2 != (longlong *)0x0) {
    uVar7 = (**(code **)(*param_2 + 8))(param_2);
    cVar6 = FUN_140204c30(param_1,uVar7);
    if (cVar6 != '\0') {
      FUN_140207dc0(param_1,param_2,0);
    }
    plVar1 = (longlong *)(param_1 + 0x90);
    plVar2 = (longlong *)*plVar1;
    plVar9 = (longlong *)**(longlong **)(param_1 + 0xc0);
    plStack_40 = plVar9;
    while( true ) {
      plVar4 = plStack_40;
      plVar3 = *(longlong **)(param_1 + 0xc0);
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == plVar3) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar2;
      }
      if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar8 = (**(code **)(*param_2 + 8))(param_2);
      if (*(int *)((longlong)plVar9 + 0x1c) == iVar8) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar9 + 0x2d) == '\0') {
          plVar3 = (longlong *)plVar9[2];
          if (*(char *)((longlong)plVar3 + 0x2d) == '\0') {
            cVar6 = *(char *)(*plVar3 + 0x2d);
            plVar9 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (plStack_40 = plVar9, cVar6 == '\0') {
              cVar6 = *(char *)(*plVar3 + 0x2d);
              plVar9 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar6 = *(char *)(plVar9[1] + 0x2d);
            plVar5 = (longlong *)plVar9[1];
            plVar3 = plVar9;
            while ((plVar9 = plVar5, plStack_40 = plVar9, cVar6 == '\0' &&
                   (plVar3 == (longlong *)plVar9[2]))) {
              cVar6 = *(char *)(plVar9[1] + 0x2d);
              plVar5 = (longlong *)plVar9[1];
              plVar3 = plVar9;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        plStack_30 = plVar4;
        local_38 = plVar2;
        FUN_140203bc0(plVar1,local_28,&local_38);
      }
      else {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar9 + 0x2d) == '\0') {
          plVar3 = (longlong *)plVar9[2];
          if (*(char *)((longlong)plVar3 + 0x2d) == '\0') {
            cVar6 = *(char *)(*plVar3 + 0x2d);
            plVar9 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (plStack_40 = plVar9, cVar6 == '\0') {
              cVar6 = *(char *)(*plVar3 + 0x2d);
              plVar9 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar6 = *(char *)(plVar9[1] + 0x2d);
            plVar4 = (longlong *)plVar9[1];
            plVar3 = plVar9;
            while ((plVar9 = plVar4, plStack_40 = plVar9, cVar6 == '\0' &&
                   (plVar3 == (longlong *)plVar9[2]))) {
              cVar6 = *(char *)(plVar9[1] + 0x2d);
              plVar4 = (longlong *)plVar9[1];
              plVar3 = plVar9;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CUserManager::helper_140208d50  @140208d50  [medium:callgraph-r0]  (orig: FUN_140208d50)
void FUN_140208d50(undefined4 *param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong *plVar11;
  longlong *local_b8 [3];
  longlong *local_a0;
  longlong *local_98;
  undefined8 local_90;
  longlong *local_88;
  longlong *local_80;
  undefined8 *local_78;
  undefined4 local_70 [2];
  longlong *local_68;
  longlong *local_60 [3];
  undefined8 local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_48 = 0xfffffffffffffffe;
    uVar4 = FUN_140008520(*param_1);
    cVar2 = FUN_14008ac00(uVar4);
    if (cVar2 != '\0') {
      plVar8 = (longlong *)0x0;
      plVar5 = operator_new(8);
      local_b8[0] = plVar8;
      if (plVar5 != (longlong *)0x0) {
        *plVar5 = (longlong)local_b8;
        local_b8[0] = plVar5;
      }
      local_a0 = (longlong *)0x0;
      local_98 = (longlong *)0x0;
      local_90 = 0;
      lVar6 = FUN_140008520(*param_1);
      if (*(longlong *)(lVar6 + 0x170) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar8;
      }
      else {
        plVar5 = *(longlong **)(lVar6 + 0x170);
      }
      uVar3 = (**(code **)(*param_2 + 8))(param_2);
      FUN_140313fc0(plVar5,local_b8,uVar3,0x2d);
      uVar10 = (longlong)local_98 - (longlong)local_a0 >> 3;
      if (uVar10 == 0) {
        if (local_a0 != (longlong *)0x0) {
          operator_delete(local_a0);
        }
        local_a0 = (longlong *)0x0;
        local_98 = (longlong *)0x0;
        local_90 = 0;
        operator_delete(local_b8[0]);
      }
      else {
        if (uVar10 == 1) {
          puVar7 = (undefined8 *)FUN_1400cfc10(local_b8);
          plVar5 = (longlong *)*puVar7;
        }
        else {
          plVar5 = plVar8;
          if (1 < uVar10) {
            puVar7 = (undefined8 *)FUN_1400cfc10(local_b8);
            plVar9 = local_a0;
            plVar5 = (longlong *)*puVar7;
            if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffff8U) != 0) {
              local_98 = local_98 + -1;
            }
            local_88 = (longlong *)0x0;
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            plVar1 = local_b8[0];
            local_88 = local_b8[0];
            while( true ) {
              plVar11 = local_98;
              local_60[0] = (longlong *)0x0;
              local_80 = plVar9;
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              local_60[0] = local_b8[0];
              if ((plVar1 == (longlong *)0x0) || (plVar1 != local_b8[0])) {
                _invalid_parameter_noinfo();
              }
              if (plVar9 == plVar11) break;
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar11 = plVar8;
              }
              else {
                plVar11 = (longlong *)*plVar1;
              }
              if ((longlong *)plVar11[4] <= plVar9) {
                _invalid_parameter_noinfo();
              }
              local_78 = (undefined8 *)*plVar9;
              if (local_78 != (undefined8 *)0x0) {
                (**(code **)*local_78)(local_78,1);
              }
              local_78 = (undefined8 *)0x0;
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar11 = plVar8;
              }
              else {
                plVar11 = (longlong *)*plVar1;
              }
              if ((longlong *)plVar11[4] <= plVar9) {
                _invalid_parameter_noinfo();
              }
              plVar9 = plVar9 + 1;
            }
            (**(code **)(*param_2 + 8))(param_2);
            log_InlineLogERROR("CSignMgr::OnUserLogin,player(%lu) data not only");
          }
        }
        FUN_1400179f0(local_b8);
        if (plVar5 == (longlong *)0x0) {
          if (local_a0 != (longlong *)0x0) {
            operator_delete(local_a0);
          }
          local_a0 = (longlong *)0x0;
          local_98 = (longlong *)0x0;
          local_90 = 0;
          operator_delete(local_b8[0]);
        }
        else {
          local_70[0] = (**(code **)(*param_2 + 8))(param_2);
          local_68 = plVar5;
          FUN_14002d3d0(param_1 + 2,local_60,local_70);
          if (local_a0 != (longlong *)0x0) {
            operator_delete(local_a0);
          }
          local_a0 = (longlong *)0x0;
          local_98 = (longlong *)0x0;
          local_90 = 0;
          operator_delete(local_b8[0]);
        }
      }
    }
  }
  return;
}

// ==== CUserManager::helper_14021b660  @14021b660  [medium:callgraph-r0]  (orig: FUN_14021b660)
void FUN_14021b660(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5[4] != 0) {
      FUN_1403815a0(plVar5[4],param_2);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CUserManager::helper_14024cf50  @14024cf50  [medium:callgraph-r3]  (orig: FUN_14024cf50)
undefined8 *
FUN_14024cf50(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_14024d650  @14024d650  [medium:callgraph-r2]  (orig: FUN_14024d650)
undefined8 * FUN_14024d650(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CUserManager::helper_14024db00  @14024db00  [medium:callgraph-r2]  (orig: FUN_14024db00)
undefined8 *
FUN_14024db00(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14024cf50(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_14024e0e0  @14024e0e0  [medium:callgraph-r1]  (orig: FUN_14024e0e0)
longlong * FUN_14024e0e0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14024e23d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14024e26c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14024e23d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14024db00(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14024e26c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_14024e290  @14024e290  [medium:callgraph-r1]  (orig: FUN_14024e290)
longlong FUN_14024e290(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14024d650(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14024d8f0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CUserManager::helper_14024e510  @14024e510  [medium:callgraph-r0]  (orig: FUN_14024e510)
undefined1 FUN_14024e510(longlong param_1,undefined4 param_2)

{
  undefined4 local_38 [2];
  longlong local_30;
  undefined1 local_28 [32];
  
  local_30 = FUN_14041bce0(param_2);
  if (local_30 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  local_38[0] = param_2;
  FUN_14024e0e0(param_1 + 8,local_28,local_38);
  return 1;
}

// ==== CUserManager::helper_14024ea80  @14024ea80  [medium:callgraph-r0]  (orig: FUN_14024ea80)
undefined1 FUN_14024ea80(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  lVar1 = FUN_14024e590();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_14041d1e0(lVar1);
  FUN_140419100(lVar1);
  FUN_14024e290(param_1 + 8,local_res10);
  return 1;
}

// ==== CUserManager::helper_14025f390  @14025f390  [medium:callgraph-r0]  (orig: FUN_14025f390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14025f390(void)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_438 [32];
  char local_418;
  undefined1 local_417 [1022];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  plVar2 = (longlong *)InstanceGet();
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  _snprintf(&local_418,0x3ff,"DELETE FROM cq_activity_user_task");
  local_19 = 0;
  cVar1 = (**(code **)(*plVar2 + 0x30))(plVar2,&local_418,0,0);
  if (cVar1 == '\0') {
    log_InlineLogERROR("CActivityMgr::ClearUserActivityTable ExecuteSQL(%s) failed.");
  }
  return cVar1 != '\0';
}

// ==== CUserManager::helper_1402604c0  @1402604c0  [medium:callgraph-r3]  (orig: FUN_1402604c0)
undefined8 *
FUN_1402604c0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402600f0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_140260a20  @140260a20  [medium:callgraph-r2]  (orig: FUN_140260a20)
longlong * FUN_140260a20(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_140260b7d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140260bac;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_140260b7d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402604c0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_140260bac:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_140260f90  @140260f90  [medium:callgraph-r2]  (orig: FUN_140260f90)
longlong * FUN_140260f90(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserManager::helper_140261280  @140261280  [medium:callgraph-r1]  (orig: FUN_140261280)
undefined8 FUN_140261280(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res18 [4];
  undefined4 local_78;
  undefined4 uStack_74;
  longlong lStack_70;
  longlong *local_68 [2];
  undefined1 local_58 [8];
  longlong lStack_50;
  
  if (param_2 == (longlong *)0x0) {
    uVar5 = 0;
  }
  else {
    local_res18[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_140260f90(param_1 + 0x18,&local_78,local_res18);
    lVar6 = *(longlong *)(param_1 + 0x48);
    lVar7 = 0;
    local_68[0] = *(longlong **)(param_1 + 0x18);
    plVar1 = (longlong *)CONCAT44(uStack_74,local_78);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_68[0])) {
      _invalid_parameter_noinfo();
    }
    lVar2 = lStack_70;
    if (lStack_70 != lVar6) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar7 = *plVar1;
      }
      if (lVar2 == *(longlong *)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar6 = *(longlong *)(lVar2 + 0x20);
      if (lVar6 != 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR("CActivityMgr::LoadUserActivityTask, user_id[%u] has exist.");
        lStack_50 = lStack_70;
        FUN_140260bd0(param_1 + 0x18,local_68,local_58);
        FUN_1404288c0(lVar6);
      }
    }
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    lVar6 = FUN_14042ba30(*(undefined4 *)(param_1 + 0x5c),uVar4,*(undefined8 *)(param_1 + 8));
    if (lVar6 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = 0;
    }
    else {
      cVar3 = FUN_140429e00(lVar6);
      if (cVar3 == '\0') {
        FUN_1404288c0(lVar6);
        uVar5 = 0;
      }
      else {
        local_78 = (**(code **)(*param_2 + 8))(param_2);
        lStack_70 = lVar6;
        FUN_140260a20(param_1 + 0x18,local_58,&local_78);
        uVar5 = 1;
      }
    }
  }
  return uVar5;
}

// ==== CUserManager::helper_140261430  @140261430  [medium:callgraph-r0]  (orig: FUN_140261430)
undefined8 FUN_140261430(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x48);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CUserManager::helper_140261990  @140261990  [medium:callgraph-r0]  (orig: FUN_140261990)
void FUN_140261990(undefined8 param_1,longlong param_2)

{
  if (param_2 != 0) {
    FUN_140261280();
  }
  return;
}

// ==== CUserManager::helper_140265690  @140265690  [medium:callgraph-r3]  (orig: FUN_140265690)
longlong FUN_140265690(longlong param_1)

{
  return param_1 + 8;
}

// ==== CUserManager::helper_140266620  @140266620  [medium:callgraph-r3]  (orig: FUN_140266620)
undefined8 *
FUN_140266620(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_140266e20  @140266e20  [medium:callgraph-r2]  (orig: FUN_140266e20)
undefined8 *
FUN_140266e20(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140266620(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_140267510  @140267510  [medium:callgraph-r1]  (orig: FUN_140267510)
longlong * FUN_140267510(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14026766d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14026769c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14026766d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140266e20(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14026769c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_140268c90  @140268c90  [medium:callgraph-r1]  (orig: FUN_140268c90)
void FUN_140268c90(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar1 = FUN_140167b70(param_2);
  if (cVar1 == '\0') {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    lVar3 = FUN_1402683a0(param_1,uVar2);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    FUN_140431060(lVar3,param_2);
  }
  return;
}

// ==== CUserManager::helper_140269240  @140269240  [medium:callgraph-r0]  (orig: FUN_140269240)
void FUN_140269240(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 local_38 [2];
  longlong local_30;
  undefined1 local_28 [32];
  
  if (param_2 != (longlong *)0x0) {
    cVar1 = FUN_140167b70(param_2);
    if (cVar1 == '\0') {
      uVar2 = (**(code **)(*param_2 + 8))(param_2);
      local_30 = FUN_140433010(*(undefined4 *)(param_1 + 0x108),uVar2);
      if (local_30 != 0) {
        local_38[0] = (**(code **)(*param_2 + 8))(param_2);
        FUN_140267510(param_1 + 200,local_28,local_38);
        FUN_140268c90(param_1,param_2);
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CUserManager::helper_14026aaa0  @14026aaa0  [medium:callgraph-r0]  (orig: FUN_14026aaa0)
longlong * FUN_14026aaa0(longlong *param_1,longlong *param_2,int *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(int *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserManager::helper_1402744f0  @1402744f0  [medium:callgraph-r3]  (orig: FUN_1402744f0)
longlong * FUN_1402744f0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x189) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x189) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserManager::helper_1402752f0  @1402752f0  [medium:callgraph-r2]  (orig: FUN_1402752f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402752f0(longlong *param_1,int param_2,uint param_3,int param_4,int param_5,char param_6)

{
  longlong lVar1;
  void *pvVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong *plVar12;
  ulonglong uVar13;
  longlong *plVar14;
  longlong *plVar15;
  uint uVar16;
  longlong *plVar17;
  int iVar18;
  uint uVar19;
  longlong *plVar20;
  void *pvVar21;
  longlong *plVar22;
  longlong *plVar23;
  bool bVar24;
  undefined1 auStack_5b8 [32];
  longlong local_598;
  longlong local_590;
  longlong local_588;
  int local_580;
  int local_578;
  int local_570;
  int local_568;
  undefined4 local_560;
  undefined4 local_558;
  undefined4 local_550;
  undefined4 local_548;
  undefined4 local_540;
  undefined4 local_538;
  uint local_530;
  uint local_528;
  undefined1 local_524;
  int local_520;
  uint local_51c;
  longlong *local_518;
  longlong *local_508;
  undefined4 uStack_500;
  undefined4 uStack_4fc;
  longlong *local_4f8;
  ulong local_4f0;
  longlong *local_4e8 [3];
  void *local_4d0;
  void *local_4c8;
  undefined8 local_4c0;
  int local_4b8;
  undefined4 local_4b4;
  int local_4b0;
  uint local_4ac;
  uint local_4a8;
  uint local_4a4;
  longlong *local_498;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  longlong *local_488;
  longlong *local_478;
  longlong *local_468 [2];
  longlong *local_458;
  longlong *local_448;
  undefined8 local_440;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5b8;
  local_528 = param_4;
  local_520 = param_2;
  local_518 = param_1;
  local_4b0 = param_2;
  local_4ac = param_3;
  local_468[0] = param_1;
  if (param_2 == 0) {
    local_598 = CONCAT44(local_598._4_4_,0x60);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_438 = '\0';
    memset(local_437,0,0x3ff);
    _snprintf(&local_438,0x3ff,"SELECT * FROM cq_operating_mail_record where player_id = %u");
    local_39 = 0;
    local_488 = (longlong *)InstanceGet();
    plVar12 = (longlong *)(**(code **)(*local_488 + 0x10))(local_488,&local_438,1);
    local_478 = plVar12;
    if (plVar12 == (longlong *)0x0) {
      log_InlineLogERROR("COperatingMailTypeMgr::PrecessUserLoginAsyn failed.");
    }
    else {
      local_4f0 = tq::TimeGet(2);
      plVar15 = *(longlong **)param_1[8];
      plVar17 = (longlong *)0x0;
      plVar23 = (longlong *)param_1[2];
      local_508 = plVar23;
      local_498 = plVar15;
      local_4f8 = operator_new(8);
      local_4e8[0] = plVar17;
      if (local_4f8 != (longlong *)0x0) {
        *local_4f8 = (longlong)local_4e8;
        local_4e8[0] = local_4f8;
      }
      local_4d0 = (void *)0x0;
      local_4c8 = (void *)0x0;
      local_4c0 = 0;
      uVar19 = local_528 * 1000 + param_5;
      local_51c = 0;
      local_528 = uVar19;
      while( true ) {
        plVar22 = (longlong *)0x0;
        plVar14 = (longlong *)param_1[8];
        local_458 = (longlong *)param_1[2];
        if ((plVar23 == (longlong *)0x0) || (uVar16 = (uint)plVar17, plVar23 != local_458)) {
          _invalid_parameter_noinfo();
          uVar16 = local_51c;
        }
        if (plVar15 == plVar14) goto LAB_140275e07;
        local_51c = uVar16 + 1;
        if (2000 < local_51c) break;
        if (plVar23 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar17 = plVar22;
        }
        else {
          plVar17 = (longlong *)*plVar23;
        }
        if (plVar15 == (longlong *)plVar17[6]) {
          _invalid_parameter_noinfo();
        }
        plVar17 = (longlong *)((longlong)plVar15 + 0x1c);
        local_458 = plVar17;
        if (plVar23 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar14 = plVar22;
        }
        else {
          plVar14 = (longlong *)*plVar23;
        }
        if (plVar15 == (longlong *)plVar14[6]) {
          _invalid_parameter_noinfo();
        }
        if (*(uint *)(plVar15 + 4) <= local_4f0) {
          if (plVar23 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar14 = plVar22;
          }
          else {
            plVar14 = (longlong *)*plVar23;
          }
          if (plVar15 == (longlong *)plVar14[6]) {
            _invalid_parameter_noinfo();
          }
          if (local_4f0 < *(uint *)((longlong)plVar15 + 0x24)) {
            if ((((*(uint *)(plVar15 + 5) >> (local_4ac & 0x1f) & 1) != 0) &&
                (*(ushort *)((longlong)plVar15 + 0x2c) <= uVar19)) &&
               ((*(ushort *)((longlong)plVar15 + 0x2e) == 0 ||
                (uVar19 <= *(ushort *)((longlong)plVar15 + 0x2e))))) {
              if ((char)plVar15[6] == '\x01') {
                if (param_6 == '\0') {
LAB_140275648:
                  uVar4 = 0;
                  local_4a4 = 0;
                  local_524 = 0;
                  local_4a8 = 0;
                  plVar14 = plVar22;
                  plVar20 = plVar22;
                  while( true ) {
                    iVar18 = (int)plVar14;
                    uVar13 = (**(code **)(*plVar12 + 0x40))(plVar12);
                    if (uVar13 <= (ulonglong)(longlong)iVar18) break;
                    local_4a4 = (int)plVar20 + 1;
                    plVar20 = (longlong *)(ulonglong)local_4a4;
                    if (10000 < local_4a4) {
                      local_598 = CONCAT44(local_598._4_4_,0xa5);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      break;
                    }
                    (**(code **)(*plVar12 + 0x30))(plVar12,(longlong)iVar18);
                    plVar14 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,2);
                    iVar7 = (**(code **)(*plVar14 + 0x50))(plVar14);
                    if (*(int *)plVar17 == iVar7) {
                      local_524 = 1;
                      param_1 = local_518;
                      uVar19 = local_528;
                      goto LAB_140275d3b;
                    }
                    local_4a8 = iVar18 + 1;
                    plVar14 = (longlong *)(ulonglong)local_4a8;
                  }
                  local_4b8 = (int)plVar15[0x30];
                  plVar12 = local_488;
                  if (local_4b8 == 0) {
LAB_140275b4d:
                    memset(&local_438,0,0x400);
                    local_568 = *(int *)((longlong)plVar17 + 0x154);
                    local_570 = *(int *)((longlong)plVar17 + 0x160);
                    local_578 = *(int *)((longlong)plVar17 + 0x15c);
                    local_580 = *(int *)((longlong)plVar17 + 0x158);
                    local_598 = (longlong)plVar17 + 0x15;
                    local_590 = (longlong)plVar17 + 0x35;
                    local_588 = (longlong)plVar17 + 0x55;
                    local_560 = uVar4;
                    _snprintf(&local_438,0x400,
                              "INSERT cq_mail SET receiver_id=%u,Sender_name=\'%s\',title=\'%s\',content=\'%s\',money=%d,emoney=%d,action=%d,expiration_date=%d,item_id=%d"
                             );
                    local_39 = 0;
                    cVar3 = (**(code **)(*plVar12 + 0x30))(plVar12,&local_438,1);
                    if (cVar3 == '\0') {
                      log_InlineLogERROR(
                                        "COperatingMailTypeMgr::PrecessUserLoginAsyn ExecuteSQL(%s) failed, at %s, %d"
                                        );
                      param_1 = local_518;
                      plVar23 = local_508;
                      uVar19 = local_528;
                    }
                    else {
                      local_568 = *(int *)((longlong)plVar17 + 0x154);
                      local_570 = *(int *)((longlong)plVar17 + 0x160);
                      local_578 = *(int *)((longlong)plVar17 + 0x15c);
                      local_580 = *(int *)((longlong)plVar17 + 0x158);
                      local_598 = (longlong)plVar17 + 0x15;
                      local_590 = (longlong)plVar17 + 0x35;
                      local_588 = (longlong)plVar17 + 0x55;
                      local_560 = uVar4;
                      tq::MyLogSave("gmlog/mail",
                                    "Send Operating Prize Mail Success| Type[%u] idReceiver[%u] szSenderName[%s] szTitle[%s] szContent[%s] unMoney[%u]  unEMoney[%u] Action[%u] ExpData[%u] idItem[%u]"
                                   );
                      memset(&local_438,0,0x400);
                      local_598 = CONCAT44(local_598._4_4_,*(int *)plVar17);
                      _snprintf(&local_438,0x400,
                                "INSERT cq_operating_mail_record SET player_id=%u,operating_mail_type=%u"
                               );
                      local_39 = 0;
                      cVar3 = (**(code **)(*plVar12 + 0x30))(plVar12,&local_438,1);
                      param_1 = local_518;
                      plVar23 = local_508;
                      uVar19 = local_528;
                      if (cVar3 == '\0') {
                        log_InlineLogERROR(
                                          "COperatingMailTypeMgr::PrecessUserLoginAsyn ExecuteSQL(%s) failed, at %s, %d"
                                          );
                        param_1 = local_518;
                        plVar23 = local_508;
                        uVar19 = local_528;
                      }
                    }
                  }
                  else {
                    plVar12 = DAT_140975b60;
                    if (DAT_140975b60 == (longlong *)0x0) {
                      local_598 = CONCAT44(local_598._4_4_,0x3c0);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      plVar12 = plVar22;
                    }
                    plVar12 = (longlong *)(**(code **)(*plVar12 + 0x70))();
                    local_4f8 = plVar12;
                    if (plVar12 == (longlong *)0x0) {
                      local_598 = CONCAT44(local_598._4_4_,0xba);
                      log_InlineLogERROR(
                                        "COperatingMailTypeMgr::PrecessUserLoginAsyn QueryItemType(idUser=%u, idType=%u) fail at %s, %d"
                                        );
                      param_1 = local_518;
                      plVar23 = local_508;
                      uVar19 = local_528;
                    }
                    else {
                      cVar3 = *(char *)((longlong)plVar15 + 0x184);
                      memset(&local_438,0,0x400);
                      plVar15 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x1c);
                      local_4b4 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      plVar15 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x1b);
                      uVar4 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      plVar15 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x1a);
                      uVar5 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      plVar15 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x19);
                      uVar6 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      plVar15 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x18);
                      iVar7 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      plVar12 = (longlong *)
                                (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                          ((longlong *)plVar12[1],0x17);
                      iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      plVar12 = (longlong *)
                                (**(code **)(*(longlong *)local_4f8[1] + 0x10))
                                          ((longlong *)local_4f8[1],0x16);
                      iVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      plVar12 = (longlong *)
                                (**(code **)(*(longlong *)local_4f8[1] + 0x10))
                                          ((longlong *)local_4f8[1],0x15);
                      uVar10 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      iVar18 = local_4b8;
                      local_530 = (uint)(cVar3 != '\0');
                      local_538 = 1;
                      local_540 = 3;
                      local_548 = local_4b4;
                      local_570 = 0xce;
                      local_588 = CONCAT44(local_588._4_4_,uVar10);
                      local_590 = CONCAT44(local_590._4_4_,local_520);
                      local_598 = 0;
                      local_580 = iVar9;
                      local_578 = iVar8;
                      local_568 = iVar7;
                      local_560 = uVar6;
                      local_558 = uVar5;
                      local_550 = uVar4;
                      _snprintf(&local_438,0x400,
                                "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,ident=%d,position=%d,gem1=%d,gem2=%d,magic1=%d,magic2=%d,magic3=%d,color=%d,accumulate_num=%d,monopoly=%d"
                               );
                      plVar12 = local_488;
                      local_39 = 0;
                      cVar3 = (**(code **)(*local_488 + 0x30))(local_488,&local_438,1);
                      if (cVar3 == '\0') {
                        log_InlineLogERROR(
                                          "COperatingMailTypeMgr::PrecessUserLoginAsyn ExecuteSQL(%s) failed, at %s, %d"
                                          );
                        param_1 = local_518;
                        plVar23 = local_508;
                        uVar19 = local_528;
                      }
                      else {
                        uVar4 = (**(code **)(*plVar12 + 0x18))(plVar12);
                        plVar12 = local_4f8;
                        plVar15 = (longlong *)
                                  (**(code **)(*(longlong *)local_4f8[1] + 0x10))
                                            ((longlong *)local_4f8[1],0x1c);
                        iVar7 = (**(code **)(*plVar15 + 0x48))(plVar15);
                        plVar15 = (longlong *)
                                  (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                            ((longlong *)plVar12[1],0x1b);
                        uVar5 = (**(code **)(*plVar15 + 0x48))(plVar15);
                        plVar15 = (longlong *)
                                  (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                            ((longlong *)plVar12[1],0x1a);
                        uVar6 = (**(code **)(*plVar15 + 0x48))(plVar15);
                        plVar12 = (longlong *)
                                  (**(code **)(*(longlong *)plVar12[1] + 0x10))
                                            ((longlong *)plVar12[1],0x19);
                        uVar10 = (**(code **)(*plVar12 + 0x48))(plVar12);
                        plVar12 = (longlong *)
                                  (**(code **)(*(longlong *)local_4f8[1] + 0x10))
                                            ((longlong *)local_4f8[1],0x18);
                        uVar11 = (**(code **)(*plVar12 + 0x48))(plVar12);
                        local_568 = 0;
                        local_570 = 0;
                        local_578 = 0;
                        local_588 = CONCAT44(local_588._4_4_,uVar5);
                        local_590 = CONCAT44(local_590._4_4_,uVar6);
                        local_580 = iVar7;
                        local_598._0_4_ = uVar10;
                        FUN_1400fe140(uVar4,local_520,iVar18,uVar11);
                        memset(&local_438,0,0x400);
                        local_598 = CONCAT44(local_598._4_4_,uVar4);
                        _snprintf(&local_438,0x3ff,
                                  "UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
                        plVar12 = local_488;
                        local_39 = 0;
                        cVar3 = (**(code **)(*local_488 + 0x30))(local_488,&local_438,1);
                        plVar17 = local_458;
                        if (cVar3 != '\0') goto LAB_140275b4d;
                        log_InlineLogERROR(
                                          "COperatingMailTypeMgr::PrecessUserLoginAsyn ExecuteSQL(%s) failed, at %s, %d"
                                          );
                        param_1 = local_518;
                        plVar23 = local_508;
                        uVar19 = local_528;
                      }
                    }
                  }
                }
              }
              else if (((char)plVar15[6] != '\x02') || (param_6 != '\0')) goto LAB_140275648;
            }
          }
          else {
            FUN_1402751c0(local_4e8);
          }
        }
LAB_140275d3b:
        if (plVar23 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        plVar15 = local_498;
        if (*(char *)((longlong)local_498 + 0x189) == '\0') {
          plVar17 = (longlong *)local_498[2];
          plVar12 = local_478;
          if (*(char *)(local_498[2] + 0x189) == '\0') {
            do {
              plVar15 = plVar17;
              plVar17 = (longlong *)*plVar15;
            } while (*(char *)(*plVar15 + 0x189) == '\0');
            plVar17 = (longlong *)(ulonglong)local_51c;
            local_498 = plVar15;
            local_448 = plVar15;
          }
          else {
            do {
              plVar15 = (longlong *)local_498[1];
              if (*(char *)((longlong)plVar15 + 0x189) != '\0') break;
              bVar24 = local_498 == (longlong *)plVar15[2];
              local_498 = plVar15;
            } while (bVar24);
            plVar17 = (longlong *)(ulonglong)local_51c;
            local_498 = plVar15;
          }
        }
        else {
          _invalid_parameter_noinfo();
          plVar17 = (longlong *)(ulonglong)local_51c;
          plVar12 = local_478;
        }
      }
      local_598 = CONCAT44(local_598._4_4_,0x75);
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_140275e07:
      if (plVar12 != (longlong *)0x0) {
        (**(code **)*plVar12)(plVar12);
      }
      pvVar21 = local_4d0;
      if (((longlong)local_4c8 - (longlong)local_4d0 & 0xfffffffffffffffcU) == 0) {
        if (local_4d0 != (void *)0x0) {
          operator_delete(local_4d0);
        }
        local_4d0 = (void *)0x0;
        local_4c8 = (void *)0x0;
        local_4c0 = 0;
        operator_delete(local_4e8[0]);
      }
      else {
        local_468[0] = (longlong *)0x0;
        if (local_4c8 < local_4d0) {
          _invalid_parameter_noinfo();
        }
        plVar12 = local_4e8[0];
        local_468[0] = local_4e8[0];
        while( true ) {
          pvVar2 = local_4c8;
          local_478 = (longlong *)0x0;
          if (local_4c8 < local_4d0) {
            _invalid_parameter_noinfo();
          }
          local_478 = local_4e8[0];
          if ((plVar12 == (longlong *)0x0) || (plVar12 != local_4e8[0])) {
            _invalid_parameter_noinfo();
          }
          if (pvVar21 == pvVar2) break;
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar22;
          }
          else {
            plVar15 = (longlong *)*plVar12;
          }
          if ((void *)plVar15[4] <= pvVar21) {
            _invalid_parameter_noinfo();
          }
          FUN_1402744f0(param_1 + 2,&local_508,pvVar21);
          lVar1 = param_1[8];
          local_488 = (longlong *)param_1[2];
          if ((local_508 == (longlong *)0x0) || (local_508 != local_488)) {
            _invalid_parameter_noinfo();
          }
          if (CONCAT44(uStack_4fc,uStack_500) != lVar1) {
            local_498 = local_508;
            uStack_490 = uStack_500;
            uStack_48c = uStack_4fc;
            FUN_1402740a0(param_1 + 2,local_468,&local_498);
          }
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar22;
          }
          else {
            plVar15 = (longlong *)*plVar12;
          }
          if ((void *)plVar15[4] <= pvVar21) {
            _invalid_parameter_noinfo();
          }
          pvVar21 = (void *)((longlong)pvVar21 + 4);
        }
        if (local_4d0 != (void *)0x0) {
          operator_delete(local_4d0);
        }
        local_4d0 = (void *)0x0;
        local_4c8 = (void *)0x0;
        local_4c0 = 0;
        operator_delete(local_4e8[0]);
      }
    }
  }
  return;
}

// ==== CUserManager::vfunc_10  @1402a7f30  [high:rtti-vtable]  (orig: FUN_1402a7f30)
void FUN_1402a7f30(longlong *param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  if (param_2 != (longlong *)0x0) {
    cVar1 = (**(code **)(param_2[2] + 0x230))();
    if (cVar1 != '\0') {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogMessage("CUserManager::KickOutUser the player is gm,idUser:%u, socket id:%u.");
    }
    cVar1 = FUN_140167b70(param_2);
    if (cVar1 == '\0') {
      (**(code **)(*param_1 + 0x48))
                (param_1,*(undefined4 *)((longlong)param_2 + 0x122c),param_3,param_4,uVar2);
    }
    else {
      (**(code **)(*param_1 + 0x58))(param_1,param_2,param_3);
    }
  }
  return;
}

// ==== CUserManager::vfunc_17  @1402a7fe0  [high:rtti-vtable]  (orig: FUN_1402a7fe0)
longlong FUN_1402a7fe0(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (*(int *)(param_2 + 0x414) != -1) {
    if ((*(int *)(param_2 + 0x420) == 0) && (*(int *)(param_2 + 0x41c) == 0)) {
      lVar1 = (**(code **)(*param_1 + 0xa8))(param_1);
      param_1[0x49] = lVar1;
      return lVar1;
    }
    lVar1 = (**(code **)(*param_1 + 0xa0))
                      (param_1,*(int *)(param_2 + 0x420),*(undefined4 *)(param_2 + 0x41c));
    param_1[0x49] = lVar1;
    return lVar1;
  }
  return 0;
}

// ==== CUserManager::helper_1402a84d0  @1402a84d0  [medium:callgraph-r1]  (orig: FUN_1402a84d0)
void FUN_1402a84d0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x31) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserManager::helper_1402a8630  @1402a8630  [medium:callgraph-r1]  (orig: FUN_1402a8630)
void FUN_1402a8630(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CUserManager::helper_1402a86b0  @1402a86b0  [medium:callgraph-r1]  (orig: FUN_1402a86b0)
void FUN_1402a86b0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402a86d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserManager::helper_1402a88c0  @1402a88c0  [medium:callgraph-r1]  (orig: FUN_1402a88c0)
void FUN_1402a88c0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x31) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x31) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x31);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x31);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x31);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x31);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402a88e4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CUserManager::helper_1402a9110  @1402a9110  [medium:callgraph-r0]  (orig: FUN_1402a9110)
void FUN_1402a9110(void *param_1)

{
  if ((DAT_140975f48 & 1) == 0) {
    DAT_140975f48 = DAT_140975f48 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f40,"CUserManager");
    atexit((_func_5014 *)&LAB_1406d69c0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402a9165. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975f40,param_1);
  return;
}

// ==== CUserManager::vfunc_9  @1402a91d0  [high:rtti-vtable]  (orig: FUN_1402a91d0)
undefined8 FUN_1402a91d0(longlong *param_1,undefined4 param_2,longlong param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)(**(code **)(*param_1 + 0xa8))();
  if (plVar3 == (longlong *)0x0) {
    if (param_3 == 0) {
      log_InlineLogERROR(&DAT_140740c50);
    }
    else {
      log_InlineLogERROR(&DAT_140740cb0);
    }
  }
  else {
    cVar2 = FUN_140167b70(plVar3);
    if (cVar2 != '\0') {
      log_InlineLogERROR(&DAT_140740db0);
      return 0;
    }
    if (*(int *)((longlong)plVar3 + 0x534) != 0) {
      return 1;
    }
    *(undefined4 *)((longlong)plVar3 + 0x534) = 1;
    plVar1 = plVar3 + 2;
    (**(code **)(*plVar1 + 0x338))(plVar1);
    if (param_3 == 0) {
      (**(code **)(*plVar3 + 8))(plVar3);
      (**(code **)(*plVar1 + 0x168))(plVar1);
      log_InlineLogWARNING(&DAT_140740d00);
    }
    else {
      (**(code **)(*plVar3 + 8))(plVar3);
      (**(code **)(*plVar1 + 0x168))(plVar1);
      log_InlineLogWARNING(&DAT_140740d60);
    }
  }
  plVar3 = (longlong *)FUN_140008520((int)param_1[0x50]);
  (**(code **)(*plVar3 + 0xd0))(plVar3,param_2);
  return 1;
}

// ==== CUserManager::vfunc_19  @1402a9330  [high:rtti-vtable]  (orig: FUN_1402a9330)
undefined8 FUN_1402a9330(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined8 local_res18;
  undefined8 uVar5;
  
  uVar5 = 0xfffffffffffffffe;
  if (param_2 != 0) {
    if ((*(longlong **)(param_1 + 0x248) != (longlong *)0x0) &&
       (iVar2 = (**(code **)(**(longlong **)(param_1 + 0x248) + 8))(), iVar2 == param_2)) {
      return *(undefined8 *)(param_1 + 0x248);
    }
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    plVar4 = (longlong *)FUN_1400875f0(uVar3);
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,param_2);
    if ((plVar4 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1001,&local_res18,*plVar4,uVar5),
       cVar1 != '\0')) {
      *(undefined8 *)(param_1 + 0x248) = local_res18;
      return local_res18;
    }
  }
  return 0;
}

// ==== CUserManager::vfunc_13  @1402a93f0  [high:rtti-vtable]  (orig: FUN_1402a93f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402a93f0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_438 = param_2;
  local_434 = param_3;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
  plVar2 = *(longlong **)(lVar1 + 0x80);
  if (plVar2 == (longlong *)0x0) {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x140);
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  local_448 = &local_438;
  (**(code **)(*plVar2 + 0x50))(plVar2,2,0x4e2c,0x418);
  return;
}

// ==== CUserManager::helper_1402a95b0  @1402a95b0  [medium:callgraph-r1]  (orig: FUN_1402a95b0)
void FUN_1402a95b0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x31) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserManager::helper_1402a9640  @1402a9640  [medium:callgraph-r1]  (orig: FUN_1402a9640)
void FUN_1402a9640(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CUserManager::helper_1402a9a30  @1402a9a30  [medium:callgraph-r3]  (orig: FUN_1402a9a30)
void FUN_1402a9a30(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402a9a30(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CUserManager::helper_1402a9bf0  @1402a9bf0  [medium:callgraph-r3]  (orig: FUN_1402a9bf0)
void FUN_1402a9bf0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x31);
  while (cVar1 == '\0') {
    FUN_1402a9bf0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x31);
  }
  return;
}

// ==== CUserManager::vfunc_3  @1402a9d90  [high:rtti-vtable]  (orig: FUN_1402a9d90)
undefined8 FUN_1402a9d90(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  ulong uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  uint7 uVar7;
  undefined8 uVar8;
  
  uVar8 = 0xfffffffffffffffe;
  iVar1 = tq::DateStamp(0);
  *(int *)(param_1 + 0x308) = iVar1;
  *(undefined1 *)(param_1 + 0x1b0) = 1;
  *(undefined4 *)(param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x1b8) = 0;
  plVar4 = (longlong *)FUN_140006ad0(0x1f44,1);
  if (plVar4 != (longlong *)0x0) {
    lVar5 = (**(code **)(*plVar4 + 0x40))(plVar4);
    if (lVar5 == 1) {
      plVar6 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,2,*plVar4,param_4,uVar8);
      uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
      *(undefined4 *)(param_1 + 0x1b8) = uVar2;
    }
  }
  if (plVar4 != (longlong *)0x0) {
    (**(code **)*plVar4)(plVar4);
  }
  if (*(uint *)(param_1 + 0x1b8) < 500) {
    *(undefined4 *)(param_1 + 0x1b8) = 500;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
  uVar8 = FUN_14008a710(uVar8);
  if ((char)uVar8 == '\0') {
    uVar7 = (uint7)((ulonglong)uVar8 >> 8);
  }
  else {
    *(undefined4 *)(param_1 + 0x160) = 300;
    uVar3 = tq::TimeGet(0);
    uVar7 = (uint7)((ulonglong)uVar3 * 0x10624dd3 >> 8) & 0xffffff;
    *(uint *)(param_1 + 0x164) = uVar3 / 1000;
  }
  return CONCAT71(uVar7,1);
}

// ==== CUserManager::helper_1402aa160  @1402aa160  [medium:callgraph-r3]  (orig: FUN_1402aa160)
undefined8 *
FUN_1402aa160(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x38);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    puVar1[5] = param_5[2];
    *(undefined1 *)(puVar1 + 6) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x31) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_1402aa1f0  @1402aa1f0  [medium:callgraph-r2]  (orig: FUN_1402aa1f0)
void FUN_1402aa1f0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402a9a30(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CUserManager::helper_1402aa470  @1402aa470  [medium:callgraph-r2]  (orig: FUN_1402aa470)
void FUN_1402aa470(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x31);
  while (cVar1 == '\0') {
    FUN_1402a9bf0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x31);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CUserManager::helper_1402aa4f0  @1402aa4f0  [medium:callgraph-r1]  (orig: FUN_1402aa4f0)
void FUN_1402aa4f0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x38);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 6) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x31) = 0;
  return;
}

// ==== CUserManager::helper_1402aa550  @1402aa550  [medium:callgraph-r1]  (orig: FUN_1402aa550)
void FUN_1402aa550(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CUserManager::helper_1402aa5b0  @1402aa5b0  [medium:callgraph-r3]  (orig: FUN_1402aa5b0)
undefined8 *
FUN_1402aa5b0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_1402aae00  @1402aae00  [medium:callgraph-r1]  (orig: FUN_1402aae00)
undefined8 * FUN_1402aae00(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CUserManager::helper_1402aaf20  @1402aaf20  [medium:callgraph-r2]  (orig: FUN_1402aaf20)
undefined8 *
FUN_1402aaf20(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402aa5b0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::vfunc_4  @1402ab440  [high:rtti-vtable]  (orig: FUN_1402ab440)
void FUN_1402ab440(longlong *param_1)

{
  (**(code **)(*param_1 + 0x60))();
  FUN_14009f560(param_1 + 0x24);
                    /* WARNING: Could not recover jumptable at 0x0001402ab46b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 8))(param_1,1);
  return;
}

// ==== CUserManager::helper_1402ab8b0  @1402ab8b0  [medium:callgraph-r2]  (orig: FUN_1402ab8b0)
undefined8 *
FUN_1402ab8b0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xaaaaaaaaaaaaaa8 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402aa160(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x30);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x30) == '\0') {
        *(undefined1 *)(plVar2 + 6) = 1;
        *(undefined1 *)(lVar4 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x31) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x31) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x30) == '\0') {
        *(undefined1 *)(plVar2 + 6) = 1;
        *(undefined1 *)(lVar4 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x31) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x31) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x30);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x30) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CUserManager::helper_1402abe50  @1402abe50  [medium:callgraph-r2]  (orig: FUN_1402abe50)
longlong * FUN_1402abe50(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402abfad:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402abfdc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402abfad;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402aaf20(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402abfdc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::vfunc_15  @1402ac3e0  [high:rtti-vtable]  (orig: FUN_1402ac3e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402ac3e0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined1 auStack_788 [32];
  undefined4 local_768;
  undefined4 local_760;
  char local_758;
  undefined1 local_757 [1855];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_788;
  plVar2 = *(longlong **)(param_1 + 0x120);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x150);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x150);
          if ((*(longlong **)(param_1 + 0x120) == (longlong *)0x0) ||
             (*(longlong **)(param_1 + 0x120) != plVar2)) {
            _invalid_parameter_noinfo();
          }
          if (plVar3 == plVar6) {
            return;
          }
          local_758 = '\0';
          memset(local_757,0,0x73f);
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
          FUN_14008b420(uVar4);
          local_760 = *(undefined4 *)((longlong)plVar6 + 0x1c);
          local_768 = (undefined4)plVar6[3];
          _snprintf(&local_758,0x73f,"[online]: %lu,%d,%d");
          tq::log_Save("gmlog/Online",&local_758,5);
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x21) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar6;
        }
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x21) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x21);
        plVar6 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x21);
          plVar3 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar3 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar3 + 0x21) != '\0');
    do {
      plVar5 = plVar3;
      plVar3 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar3 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar3 + 0x21) == '\0');
  } while( true );
}

// ==== CUserManager::vfunc_16  @1402ac5a0  [high:rtti-vtable]  (orig: FUN_1402ac5a0)
void FUN_1402ac5a0(longlong param_1,uint param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  uint uVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    uVar5 = FUN_14008b420(uVar6);
    if ((uVar5 != param_2) && (plVar7 = (longlong *)FUN_140118220(), plVar7 != (longlong *)0x0)) {
      plVar2 = *(longlong **)(param_1 + 0x18);
      plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x48);
      while( true ) {
        plVar3 = *(longlong **)(param_1 + 0x48);
        if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
          _invalid_parameter_noinfo();
        }
        if (plVar8 == plVar3) break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar2;
        }
        if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((ulonglong)param_2 == (ulonglong)plVar8[3] >> 0x20) {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar2;
          }
          if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if ((int)plVar8[4] != 0) {
            (**(code **)(*plVar7 + 0xa0))(plVar7,(int)plVar8[4],param_3);
          }
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
          plVar3 = (longlong *)plVar8[2];
          if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x29);
            plVar8 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (cVar1 == '\0') {
              cVar1 = *(char *)(*plVar3 + 0x29);
              plVar8 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar1 = *(char *)(plVar8[1] + 0x29);
            plVar4 = (longlong *)plVar8[1];
            plVar3 = plVar8;
            while ((plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar8[2]))) {
              cVar1 = *(char *)(plVar8[1] + 0x29);
              plVar4 = (longlong *)plVar8[1];
              plVar3 = plVar8;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
  }
  return;
}

// ==== CUserManager::helper_1402acbc0  @1402acbc0  [medium:callgraph-r1]  (orig: FUN_1402acbc0)
longlong * FUN_1402acbc0(longlong *param_1,longlong *param_2,ulonglong *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x31) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < (ulonglong)puVar7[3];
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x31) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402acd1d:
    local_30 = puVar4;
    if (*param_3 <= (ulonglong)puVar5[3]) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402acd4d;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x31) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x31) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x31);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x31);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x31);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x31);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x31) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x31) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402acd1d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402ab8b0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402acd4d:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_1402acd70  @1402acd70  [medium:callgraph-r0]  (orig: FUN_1402acd70)
undefined8 * FUN_1402acd70(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x31) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402a88c0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x31) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 6;
        plVar8 = plVar8 + 6;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402acf5c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x31);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x31);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x31);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402acf5c:
  if ((char)plVar2[6] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[6] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_1402a95b0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(*plVar9 + 0x30) != '\x01') || (*(char *)(plVar9[2] + 0x30) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x30) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_1402a84d0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(plVar9[2] + 0x30) = 1;
              FUN_1402a95b0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        else {
          if ((char)plVar9[6] == '\0') {
            *(undefined1 *)(plVar9 + 6) = 1;
            *(undefined1 *)(plVar8 + 6) = 0;
            FUN_1402a84d0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x31) == '\0') {
            if ((*(char *)(plVar9[2] + 0x30) != '\x01') || (*(char *)(*plVar9 + 0x30) != '\x01')) {
              if (*(char *)(*plVar9 + 0x30) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x30) = 1;
                *(undefined1 *)(plVar9 + 6) = 0;
                FUN_1402a95b0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 6) = (char)plVar8[6];
              *(undefined1 *)(plVar8 + 6) = 1;
              *(undefined1 *)(*plVar9 + 0x30) = 1;
              FUN_1402a84d0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 6) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 6) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CUserManager::helper_1402ad2f0  @1402ad2f0  [medium:callgraph-r0]  (orig: FUN_1402ad2f0)
undefined8 * FUN_1402ad2f0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402a86b0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402ad4dc;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402ad4dc:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402a9640(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402a8630(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1402a9640(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402a8630(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402a9640(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1402a8630(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CUserManager::helper_1402ad6b0  @1402ad6b0  [medium:callgraph-r0]  (orig: FUN_1402ad6b0)
longlong * FUN_1402ad6b0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CUserManager::helper_1402adb10  @1402adb10  [medium:callgraph-r1]  (orig: FUN_1402adb10)
undefined8 * FUN_1402adb10(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1402aaf20(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1402aaf20(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1402aaf20(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_1402aaf20(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1402aaf20(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_1402aaf20(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1402aaf20(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1402abe50(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CUserManager::helper_1402ade30  @1402ade30  [medium:callgraph-r1]  (orig: FUN_1402ade30)
longlong * FUN_1402ade30(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402aa1f0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402ad2f0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CUserManager::helper_1402adfe0  @1402adfe0  [medium:callgraph-r0]  (orig: FUN_1402adfe0)
void FUN_1402adfe0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402ade30((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CUserManager::helper_1402ae250  @1402ae250  [medium:callgraph-r1]  (orig: FUN_1402ae250)
longlong * FUN_1402ae250(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402aa470(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x31) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x31) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x31);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x31);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x31);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x31);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402acd70(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CUserManager::vfunc_18  @1402ae6f0  [high:rtti-vtable]  (orig: FUN_1402ae6f0)
longlong FUN_1402ae6f0(longlong param_1,longlong param_2,int param_3)

{
  char cVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  longlong lVar6;
  undefined8 *local_48;
  undefined8 local_40;
  undefined8 local_38;
  longlong *local_30;
  longlong local_28 [2];
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (*(longlong *)(param_1 + 0x248) != 0) {
    pcVar4 = (char *)(**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x248) + 0x10) + 0x18))();
    lVar6 = param_2 - (longlong)pcVar4;
    do {
      cVar2 = *pcVar4;
      cVar1 = pcVar4[lVar6];
      if (cVar2 != cVar1) break;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    if ((cVar2 == cVar1) &&
       (iVar3 = FUN_140167b40(*(undefined8 *)(param_1 + 0x248)), iVar3 == param_3)) {
      return *(longlong *)(param_1 + 0x248);
    }
  }
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
  if (*(longlong *)(lVar6 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x88) + 0x30))();
  local_48 = (undefined8 *)(lVar6 + 0x10);
  local_38 = **(undefined8 **)(lVar6 + 0x40);
  uVar5 = 0;
  local_40 = *local_48;
  local_30 = (longlong *)0x0;
  local_28[0] = 0;
  do {
    cVar2 = FUN_1400ce310(&local_48);
    while( true ) {
      if (cVar2 == '\0') {
        return 0;
      }
      cVar2 = (**(code **)(*local_30 + 0x298))(local_30,0x1001,local_28);
      if (cVar2 != '\0') break;
      cVar2 = FUN_1400ce310(&local_48);
    }
    uVar5 = uVar5 + 1;
    if (1000000 < uVar5) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
    if (local_28[0] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    pcVar4 = (char *)(**(code **)(*(longlong *)(local_28[0] + 0x10) + 0x18))();
    lVar6 = param_2 - (longlong)pcVar4;
    do {
      cVar2 = *pcVar4;
      cVar1 = pcVar4[lVar6];
      if (cVar2 != cVar1) break;
      pcVar4 = pcVar4 + 1;
    } while (cVar1 != '\0');
    if (cVar2 == cVar1) {
      if (local_28[0] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar3 = FUN_140167b40(local_28[0]);
      if (iVar3 == param_3) {
        *(longlong *)(param_1 + 0x248) = local_28[0];
        return local_28[0];
      }
    }
  } while( true );
}

// ==== CUserManager::vfunc_21  @1402ae990  [high:rtti-vtable]  (orig: FUN_1402ae990)
undefined8 FUN_1402ae990(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x238))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x238);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x238);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x208);
  if (*(longlong *)(param_1 + 0x208) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x238);
    local_28 = *(longlong *)(param_1 + 0x208);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x238);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x208))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CUserManager::vfunc_23  @1402aeab0  [high:rtti-vtable]  (orig: FUN_1402aeab0)
undefined8 FUN_1402aeab0(longlong param_1,int param_2,int *param_3)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  uint uVar6;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 *local_40;
  undefined8 local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong *local_20;
  longlong *plVar7;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  iVar3 = *param_3;
  plVar9 = (longlong *)0x0;
  bVar1 = true;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = FUN_140008520(*(undefined4 *)(*(longlong *)(lVar5 + 0x90) + 0x280));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x88) + 0x30))();
  local_40 = (undefined8 *)(lVar5 + 0x10);
  local_30 = **(undefined8 **)(lVar5 + 0x40);
  local_38 = *local_40;
  local_28 = (longlong *)0x0;
  local_20 = (longlong *)0x0;
  plVar7 = plVar9;
  plVar8 = plVar9;
  while( true ) {
    cVar2 = FUN_1400ce310(&local_40);
    while( true ) {
      if (cVar2 == '\0') {
        local_20 = (longlong *)0x0;
        goto LAB_1402aec2f;
      }
      cVar2 = (**(code **)(*local_28 + 0x298))(local_28,0x1001,&local_20);
      if (cVar2 != '\0') break;
      cVar2 = FUN_1400ce310(&local_40);
    }
    uVar6 = (int)plVar7 + 1;
    plVar7 = (longlong *)(ulonglong)uVar6;
    if (1000000 < uVar6) break;
    if ((local_20 != (longlong *)0x0) &&
       (iVar4 = (**(code **)(local_20[2] + 0x170))(local_20 + 2), iVar4 == param_2)) {
      if (bVar1) {
        bVar1 = false;
        plVar8 = local_20;
      }
      if (local_20 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(*local_20 + 8))();
      if (iVar4 == iVar3) {
        bVar1 = true;
        plVar8 = plVar9;
      }
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1402aec2f:
  if (plVar8 == (longlong *)0x0) {
    return 0;
  }
  iVar3 = (**(code **)(*plVar8 + 8))(plVar8);
  *param_3 = iVar3;
  return 1;
}

// ==== CUserManager::helper_1402af010  @1402af010  [medium:callgraph-r0]  (orig: FUN_1402af010)
void FUN_1402af010(longlong param_1,longlong param_2,ulonglong param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 0x18);
  uVar8 = (param_2 << 0x20) + (param_3 & 0xffffffff);
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar2 = *(char *)((longlong)puVar6 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x48);
  while (cVar2 == '\0') {
    if ((ulonglong)puVar6[3] < uVar8) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar4 = puVar6;
    puVar6 = puVar5;
    cVar2 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar6) || (uVar8 < (ulonglong)puVar4[3])) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *plVar1;
  }
  else {
    plVar7 = &local_38;
  }
  local_18 = *plVar7;
  lVar3 = *(longlong *)(param_1 + 0x48);
  local_10 = plVar7[1];
  if ((local_18 == 0) || (local_18 != *plVar1)) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    local_18 = *plVar7;
    local_10 = plVar7[1];
    FUN_1402ac730(plVar1,&local_28,&local_18);
  }
  return;
}

// ==== CUserManager::vfunc_14  @1402af270  [high:rtti-vtable]  (orig: FUN_1402af270)
void FUN_1402af270(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong lVar4;
  int local_res8;
  int local_resc;
  int local_res10 [2];
  longlong *local_48;
  longlong local_40;
  
  local_res10[0] = param_2;
  uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
  cVar1 = FUN_14008a710(uVar2);
  if ((cVar1 != '\0') && (-1 < param_2)) {
    FUN_14026aaa0(param_1 + 0x120,&local_48,local_res10);
    lVar3 = *(longlong *)(param_1 + 0x150);
    if ((*(longlong **)(param_1 + 0x120) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x120) != local_48)) {
      _invalid_parameter_noinfo();
    }
    if (lVar3 == local_40) {
      if (param_3 < 0) {
        param_3 = 0;
      }
      local_res8 = param_2;
      local_resc = param_3;
      FUN_1400a85a0(param_1 + 0x120,&local_48,&local_res8);
    }
    else {
      lVar3 = 0;
      if (local_48 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = lVar3;
      }
      else {
        lVar4 = *local_48;
      }
      if (local_40 == *(longlong *)(lVar4 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (param_3 + *(int *)(local_40 + 0x1c) < 0) {
        param_3 = 0;
      }
      else {
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar4 = lVar3;
        }
        else {
          lVar4 = *local_48;
        }
        if (local_40 == *(longlong *)(lVar4 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        param_3 = param_3 + *(int *)(local_40 + 0x1c);
      }
      if (local_48 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar3 = *local_48;
      }
      if (local_40 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(int *)(local_40 + 0x1c) = param_3;
    }
  }
  return;
}

// ==== CUserManager::helper_1402af4c0  @1402af4c0  [medium:callgraph-r0]  (orig: FUN_1402af4c0)
undefined8 * FUN_1402af4c0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_1402adb10(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CUserManager::helper_1402af5f0  @1402af5f0  [medium:callgraph-r0]  (orig: FUN_1402af5f0)
longlong FUN_1402af5f0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1402aae00(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1402ade30(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CUserManager::helper_1402af7b0  @1402af7b0  [medium:callgraph-r0]  (orig: FUN_1402af7b0)
void FUN_1402af7b0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402ae050((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CUserManager::helper_1402af8a0  @1402af8a0  [medium:callgraph-r0]  (orig: FUN_1402af8a0)
void FUN_1402af8a0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402ae250((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CUserManager::vfunc_6  @1402af9c0  [high:rtti-vtable]  (orig: FUN_1402af9c0)
undefined8 * FUN_1402af9c0(longlong *param_1,uint param_2,uint param_3,uint param_4)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  uint local_res10 [2];
  uint local_res18 [2];
  uint local_res20;
  uint in_stack_ffffffffffffff88;
  longlong local_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  longlong local_50 [3];
  
  local_58 = 0xfffffffffffffffe;
  uVar6 = (ulonglong)param_3;
  local_res10[0] = param_2;
  local_res18[0] = param_3;
  local_res20 = param_4;
  if ((param_2 == 0xffffffff) || (param_3 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"CUserManager::LoginUser\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.cpp"
                       ,0x10f);
    puVar3 = (undefined8 *)0x0;
  }
  else {
    FUN_1402ad6b0(param_1 + 0x41,&local_68,local_res10);
    lVar2 = param_1[0x47];
    puVar3 = (undefined8 *)0x0;
    local_50[0] = param_1[0x41];
    if ((local_68 == 0) || (local_68 != local_50[0])) {
      _invalid_parameter_noinfo();
    }
    if (CONCAT44(uStack_5c,uStack_60) != lVar2) {
      log_InlineLogERROR("CUserManager::CreateUser repeated login idSocket:%u, idUser:%u, vip:%u",
                         (ulonglong)param_2,uVar6,(ulonglong)param_4);
      (**(code **)(*param_1 + 0x40))(param_1,param_2,0,0,in_stack_ffffffffffffff88 & 0xffffff00,1);
      FUN_1402ad2f0(param_1 + 0x41,local_50,&local_68);
    }
    lVar2 = (**(code **)(*param_1 + 0x98))(param_1,uVar6);
    if (lVar2 == 0) {
      local_68 = FUN_14016d5a0(0x1418);
      if (local_68 != 0) {
        puVar3 = (undefined8 *)FUN_1401d0da0(local_68);
      }
      if (puVar3 == (undefined8 *)0x0) {
        puVar3 = (undefined8 *)0x0;
      }
      else {
        cVar1 = FUN_14044d940(puVar3,(int)param_1[0x50],param_2,uVar6,param_4);
        if (cVar1 == '\0') {
          log_InlineLogERROR(" CUserManager::CreateUser, failed in initializing user: %u",uVar6);
          (**(code **)*puVar3)(puVar3,1);
          plVar4 = (longlong *)FUN_140008520((int)param_1[0x50]);
          (**(code **)(*plVar4 + 0xd0))(plVar4,param_2);
          puVar3 = (undefined8 *)0x0;
        }
        else {
          tq::CMySingleLock::CMySingleLock((CMySingleLock *)&local_68,(ILockObj *)&DAT_140975f50);
          puVar5 = (undefined8 *)FUN_1402af4c0(param_1 + 0x51,local_res18);
          *puVar5 = puVar3;
          tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_68);
        }
      }
    }
    else {
      log_InlineLogMessage(&DAT_1407418a0,uVar6,(ulonglong)*(uint *)(lVar2 + 0x122c));
      (**(code **)(*param_1 + 0x50))(param_1,lVar2,&DAT_140741890);
      puVar3 = (undefined8 *)0x0;
    }
  }
  return puVar3;
}

// ==== CUserManager::vfunc_8  @1402afc30  [high:rtti-vtable]  (orig: FUN_1402afc30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1402afc30(longlong *param_1,undefined4 param_2,undefined4 param_3,char param_4,
             undefined8 param_5,char param_6)

{
  int *piVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  int *piVar4;
  char cVar5;
  byte bVar6;
  undefined2 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  longlong *plVar14;
  undefined8 uVar15;
  longlong *plVar16;
  IStringManager *pIVar17;
  longlong lVar18;
  undefined8 *puVar19;
  undefined8 *puVar20;
  longlong *plVar21;
  longlong *plVar22;
  undefined1 auStack_a78 [32];
  undefined4 *local_a58;
  undefined2 local_a50;
  undefined4 local_a48;
  undefined4 local_a40;
  undefined4 local_a38;
  undefined4 local_a34;
  undefined4 local_a30;
  undefined4 local_a28;
  undefined4 local_a24;
  longlong *local_a20;
  undefined4 local_a18;
  undefined4 local_a14;
  undefined4 local_a10;
  undefined8 local_a08;
  longlong *local_a00;
  undefined8 *local_9f8;
  int *piStack_9f0;
  longlong *local_9e8;
  undefined8 local_9d8;
  undefined8 uStack_9d0;
  longlong *local_9c8;
  undefined8 local_9c0;
  undefined8 local_9b8;
  undefined8 local_9b0;
  longlong local_9a8;
  longlong local_9a0;
  longlong local_998;
  undefined8 *local_990;
  longlong local_988;
  longlong local_980;
  longlong local_978;
  longlong local_970;
  longlong *local_968;
  longlong local_960;
  longlong local_958;
  longlong local_950;
  longlong local_948;
  int *local_940;
  longlong local_938;
  int *local_930;
  longlong *local_928;
  undefined8 local_920;
  undefined8 *local_918;
  longlong *local_908;
  undefined4 local_8f8;
  undefined4 uStack_8f4;
  undefined4 uStack_8f0;
  undefined4 uStack_8ec;
  longlong *local_8e8;
  longlong *local_8e0;
  longlong local_8d8;
  undefined1 local_8d0 [24];
  undefined1 local_8b8 [1104];
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  ulonglong local_48;
  
  local_920 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_a78;
  local_a24 = param_2;
  local_a00 = param_1;
  if (param_4 == '\0') {
    plVar14 = (longlong *)(**(code **)(*param_1 + 0xa8))();
    if (plVar14 == (longlong *)0x0) {
      return 0;
    }
  }
  else {
    plVar14 = (longlong *)(**(code **)(*param_1 + 0x98))(param_1,param_3);
    if (plVar14 == (longlong *)0x0) {
      return 1;
    }
  }
  local_a28 = (undefined4)plVar14[0x1e2];
  local_a20 = plVar14;
  FUN_14017f110(plVar14);
  local_978 = FUN_140008520((int)param_1[0x50]);
  if (*(longlong *)(local_978 + 0x138) == 0) {
    local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x14c);
    log_InlineLogERROR(&DAT_1406d9c10);
    local_9b0 = 0;
  }
  else {
    local_9b0 = *(undefined8 *)(local_978 + 0x138);
  }
  uVar15 = local_9b0;
  plVar22 = (longlong *)0x0;
  uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
  FUN_1402e9b00(uVar15,uVar8);
  plVar16 = plVar14 + 0x248;
  local_968 = plVar16;
  if ((int)*plVar16 != 0) {
    local_958 = FUN_140008520((int)param_1[0x50]);
    if (*(longlong *)(local_958 + 0x108) == 0) {
      local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x145);
      log_InlineLogERROR(&DAT_1406d9c10);
      local_9c0 = 0;
    }
    else {
      local_9c0 = *(undefined8 *)(local_958 + 0x108);
    }
    local_948 = FUN_140214ce0(local_9c0,(int)*plVar16);
    if (local_948 != 0) {
      FUN_1403e7860(local_948,plVar14);
    }
  }
  local_938 = FUN_140008520((int)param_1[0x50]);
  if (*(longlong *)(local_938 + 0x1d8) == 0) {
    local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x15f);
    log_InlineLogERROR(&DAT_1406d9c10);
    local_9b8 = 0;
  }
  else {
    local_9b8 = *(undefined8 *)(local_938 + 0x1d8);
  }
  FUN_140208000(local_9b8,plVar14);
  local_a38 = 0;
  local_a34 = 0;
  local_a30 = 0;
  uVar15 = FUN_140008520((int)param_1[0x50]);
  uVar15 = FUN_1400d6610(uVar15);
  FUN_140006c50(uVar15,&local_a38);
  cVar5 = FUN_14016e3f0(plVar14);
  if ((cVar5 != '\0') &&
     (plVar16 = (longlong *)FUN_14016e430(plVar14), local_928 = plVar16, plVar16 != (longlong *)0x0)
     ) {
    pIVar17 = theInstance();
    lVar18 = plVar16[2];
    uVar15 = (*(code *)**(undefined8 **)pIVar17)(pIVar17,"STR_INTERACT_TARGET_LOGOUT");
    (**(code **)(lVar18 + 0x358))(plVar16 + 2,uVar15);
    local_a58 = (undefined4 *)((ulonglong)local_a58 & 0xffffffffffffff00);
    FUN_1401c55b0(plVar16,local_a38,local_a34,local_a30);
    FUN_140362560(local_8b8);
    uVar7 = (**(code **)(plVar16[2] + 0x50))(plVar16 + 2);
    uVar8 = (**(code **)(plVar16[2] + 0x48))(plVar16 + 2);
    uVar9 = (**(code **)(plVar16[2] + 0x40))(plVar16 + 2);
    uVar10 = (**(code **)(*plVar16 + 8))(plVar16);
    local_a40 = 0;
    local_a48 = 0;
    local_a50 = 1000;
    local_a58 = (undefined4 *)CONCAT62(local_a58._2_6_,uVar7);
    iVar11 = FUN_140362620(local_8b8,uVar10,uVar9,uVar8);
    if (iVar11 != 0) {
      (**(code **)(plVar16[2] + 0x350))(plVar16 + 2,local_8b8);
    }
    FUN_1403625e0(local_8b8);
  }
  if (param_6 == '\0') goto LAB_1402b0359;
  plVar16 = (longlong *)CurrentInstanceGet();
  local_9c8 = (longlong *)0x0;
  local_8e8 = plVar16;
  if (plVar16 != (longlong *)0x0) {
    local_9c8 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x21);
  }
  plVar21 = local_9c8;
  local_9e8 = (longlong *)0x0;
  if (plVar16 != (longlong *)0x0) {
    local_9e8 = (longlong *)(**(code **)(*plVar16 + 0x20))(plVar16,0x24);
  }
  cVar5 = (**(code **)(plVar14[2] + 0x220))(plVar14 + 2);
  if ((cVar5 != '\0') && (lVar18 = (**(code **)(plVar14[2] + 0x160))(plVar14 + 2), lVar18 != 0)) {
    local_970 = (**(code **)(plVar14[2] + 0x160))(plVar14 + 2);
    local_988 = *(longlong *)(local_970 + 0x58);
    plVar16 = (longlong *)
              (**(code **)(**(longlong **)(local_988 + 8) + 0x10))(*(longlong **)(local_988 + 8),4);
    bVar6 = (**(code **)(*plVar16 + 0x58))(plVar16);
    if ((bVar6 >> 2 & 1) == 0) {
      uVar8 = (**(code **)(plVar14[2] + 0x48))(plVar14 + 2);
      uVar9 = (**(code **)(plVar14[2] + 0x40))(plVar14 + 2);
      uVar15 = (**(code **)(plVar14[2] + 0x160))(plVar14 + 2);
      cVar5 = FUN_1402c3cc0(uVar15,uVar9,uVar8);
      if (cVar5 != '\0') {
        local_960 = (**(code **)(plVar14[2] + 0x160))(plVar14 + 2);
        local_8d8 = *(longlong *)(local_960 + 0x58);
        plVar16 = (longlong *)
                  (**(code **)(**(longlong **)(local_8d8 + 8) + 0x10))
                            (*(longlong **)(local_8d8 + 8),4);
        bVar6 = (**(code **)(*plVar16 + 0x58))(plVar16);
        if ((bVar6 >> 2 & 1) == 0) {
          uVar8 = (**(code **)(plVar14[2] + 0x48))(plVar14 + 2);
          uVar9 = (**(code **)(plVar14[2] + 0x40))(plVar14 + 2);
          uVar10 = (**(code **)(plVar14[2] + 0x168))(plVar14 + 2);
          local_a58 = (undefined4 *)((ulonglong)local_a58 & 0xffffffff00000000);
          FUN_1401732e0(plVar14,uVar10,uVar9,uVar8);
        }
      }
    }
  }
  if (plVar21 == (longlong *)0x0) {
LAB_1402b014f:
    plVar16 = local_9e8;
    if (local_9e8 != (longlong *)0x0) {
      lVar18 = *local_9e8;
      uVar8 = (**(code **)(plVar14[2] + 0x168))(plVar14 + 2);
      cVar5 = (**(code **)(lVar18 + 0xa8))(plVar16,uVar8);
      if (cVar5 != '\0') goto LAB_1402b017e;
    }
  }
  else {
    lVar18 = *plVar21;
    uVar8 = (**(code **)(plVar14[2] + 0x168))(plVar14 + 2);
    cVar5 = (**(code **)(lVar18 + 0xa8))(plVar21,uVar8);
    if (cVar5 == '\0') goto LAB_1402b014f;
LAB_1402b017e:
    local_a58 = (undefined4 *)((ulonglong)local_a58 & 0xffffffff00000000);
    FUN_1401732e0(plVar14,local_a38,local_a34,local_a30);
  }
  uVar15 = FUN_140008520((int)param_1[0x50]);
  lVar18 = FUN_140117e10(uVar15);
  if (lVar18 == 0) {
    return 0;
  }
  local_950 = lVar18;
  uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
  FUN_14021b660(lVar18,uVar8);
  plVar16 = (longlong *)FUN_1401182a0();
  lVar18 = *plVar16;
  uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
  (**(code **)(lVar18 + 0x20))(plVar16,uVar8);
  cVar5 = (**(code **)(plVar14[2] + 0x230))(plVar14 + 2);
  if (cVar5 != '\0') {
    local_9d8 = (undefined8 *)0x0;
    plVar16 = param_1 + 0x4a;
    piVar1 = (int *)param_1[0x4d];
    local_9f8 = (undefined8 *)0x0;
    local_940 = piVar1;
    local_908 = plVar16;
    if ((int *)param_1[0x4e] < piVar1) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (undefined8 *)*plVar16;
    local_9f8 = puVar2;
    piStack_9f0 = piVar1;
    local_9d8 = puVar2;
    uStack_9d0 = piVar1;
    while( true ) {
      piVar4 = uStack_9d0;
      piVar1 = (int *)param_1[0x4e];
      local_918 = (undefined8 *)0x0;
      local_930 = piVar1;
      local_8e0 = plVar16;
      if (piVar1 < (int *)param_1[0x4d]) {
        _invalid_parameter_noinfo();
      }
      local_918 = (undefined8 *)*plVar16;
      if ((puVar2 == (undefined8 *)0x0) || (puVar2 != local_918)) {
        _invalid_parameter_noinfo();
      }
      if (piVar4 == piVar1) goto LAB_1402b0359;
      if (puVar2 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar22;
      }
      else {
        plVar21 = (longlong *)*puVar2;
      }
      if ((int *)plVar21[4] <= piVar4) {
        _invalid_parameter_noinfo();
      }
      iVar11 = (**(code **)(*plVar14 + 8))(plVar14);
      if (iVar11 == *piVar4) break;
      if (puVar2 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar21 = plVar22;
      }
      else {
        plVar21 = (longlong *)*puVar2;
      }
      if ((int *)plVar21[4] <= piVar4) {
        _invalid_parameter_noinfo();
      }
      uStack_9d0 = piVar4 + 1;
    }
    local_8f8 = (undefined4)local_9d8;
    uStack_8f4 = local_9d8._4_4_;
    uStack_8f0 = (undefined4)uStack_9d0;
    uStack_8ec = uStack_9d0._4_4_;
    FUN_1400431b0(plVar16,local_8d0,&local_8f8);
  }
LAB_1402b0359:
  local_980 = FUN_140008520((int)param_1[0x50]);
  if (*(longlong *)(local_980 + 0x140) == 0) {
    local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x149);
    log_InlineLogERROR(&DAT_1406d9c10);
    local_a08 = 0;
  }
  else {
    local_a08 = *(undefined8 *)(local_980 + 0x140);
  }
  uVar15 = local_a08;
  uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
  FUN_14024ea80(uVar15,uVar8);
  FUN_140198450(plVar14);
  FUN_1401bfb90(plVar14,0,0);
  FUN_1401aade0(plVar14,0);
  FUN_1401aade0(plVar14,1);
  lVar18 = FUN_140008520((int)param_1[0x50]);
  if (*(longlong *)(lVar18 + 0x88) == 0) {
    local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x12f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar16 = (longlong *)(**(code **)(**(longlong **)(lVar18 + 0x88) + 0x30))();
  lVar18 = *plVar16;
  uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
  (**(code **)(lVar18 + 0x38))(plVar16,uVar8);
  if ((longlong *)param_1[0x49] != (longlong *)0x0) {
    iVar11 = (**(code **)(*(longlong *)param_1[0x49] + 8))();
    iVar12 = (**(code **)(*plVar14 + 8))(plVar14);
    if (iVar11 == iVar12) {
      param_1[0x49] = 0;
    }
  }
  if (param_4 == '\0') {
    FUN_1402af5f0(param_1 + 0x41,&local_a24);
    lVar18 = *param_1;
    uVar8 = FUN_140167940(plVar14);
    (**(code **)(lVar18 + 0x70))(param_1,uVar8,0xffffffff);
  }
  else {
    uVar8 = (**(code **)(*plVar14 + 0x38))(plVar14);
    uVar9 = FUN_140167b40(plVar14);
    FUN_1402af010(param_1,uVar9,uVar8);
    *(int *)((longlong)param_1 + 0xc) = *(int *)((longlong)param_1 + 0xc) + -1;
    DAT_14097570c = *(undefined4 *)((longlong)param_1 + 0xc);
    LOCK();
    UNLOCK();
    LOCK();
    DAT_140975718 = DAT_140975718 + 1;
    UNLOCK();
    LOCK();
    DAT_140975720 = DAT_140975720 + 1;
    UNLOCK();
  }
  uVar13 = (**(code **)(*plVar14 + 8))(plVar14);
  puVar2 = (undefined8 *)param_1[0x5f];
  local_a00 = (longlong *)param_1[0x59];
  cVar5 = *(char *)((longlong)puVar2[1] + 0x1d);
  puVar3 = puVar2;
  puVar20 = (undefined8 *)puVar2[1];
  while (cVar5 == '\0') {
    if (*(uint *)(puVar20 + 3) < uVar13) {
      puVar19 = (undefined8 *)puVar20[2];
      puVar20 = puVar3;
    }
    else {
      puVar19 = (undefined8 *)*puVar20;
    }
    puVar3 = puVar20;
    puVar20 = puVar19;
    cVar5 = *(char *)((longlong)puVar19 + 0x1d);
  }
  local_990 = puVar3;
  local_998 = (longlong)local_a00;
  if (local_a00 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar2) || (uVar13 < *(uint *)(puVar3 + 3))) {
    local_9a0 = param_1[0x5f];
    local_9a8 = param_1[0x59];
    plVar16 = &local_9a8;
  }
  else {
    plVar16 = &local_998;
  }
  local_9f8 = (undefined8 *)*plVar16;
  piStack_9f0 = (int *)plVar16[1];
  if ((local_9f8 == (undefined8 *)0x0) || (local_9f8 != local_a00)) {
    _invalid_parameter_noinfo();
  }
  if (piStack_9f0 != (int *)puVar2) {
    uVar8 = (**(code **)(*plVar14 + 8))(plVar14);
    local_a20 = (longlong *)CONCAT44(local_a20._4_4_,uVar8);
    FUN_14000d630(param_1 + 0x59);
    memset((void *)((longlong)&local_468 + 1),0,0x417);
    local_468 = 2;
    local_464 = (**(code **)(*plVar14 + 8))(plVar14);
    uVar8 = local_a28;
    local_460 = local_a28;
    lVar18 = FUN_140008520((int)param_1[0x50]);
    plVar16 = *(longlong **)(lVar18 + 0x80);
    if (plVar16 == (longlong *)0x0) {
      local_a58 = (undefined4 *)CONCAT44(local_a58._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar16 = plVar22;
    }
    local_a58 = &local_468;
    cVar5 = (**(code **)(*plVar16 + 0x50))(plVar16,0xb,0x16761,0x418);
    if (cVar5 == '\0') {
      tq::MyLogSave("gmlog/ChangeServer",
                    "APP_CHANGE_SERVER_USER_LOGOUT fail. iduser[%u] logout finish");
      local_a18 = 0;
      local_a14 = 0;
      local_a10 = 0;
      local_a18 = (**(code **)(*plVar14 + 8))(plVar14);
      local_a14 = uVar8;
      local_a10 = 1;
      uVar15 = FUN_140008520((int)param_1[0x50]);
      plVar16 = (longlong *)FUN_14001b560(uVar15);
      local_a58 = &local_a18;
      (**(code **)(*plVar16 + 0x50))(plVar16,2,0x4e2e,0xc);
    }
    else {
      tq::MyLogSave("gmlog/ChangeServer",
                    "APP_CHANGE_SERVER_USER_LOGOUT success. iduser[%u] logout finish");
    }
  }
  (**(code **)(plVar14[2] + 8))();
  return 1;
}

// ==== CUserManager::vfunc_20  @1402b0790  [high:rtti-vtable]  (orig: FUN_1402b0790)
longlong FUN_1402b0790(longlong *param_1,int param_2,int param_3,undefined8 param_4)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    lVar2 = 0;
  }
  else {
    if (((param_1[0x49] != 0) && (iVar1 = FUN_140167b40(), iVar1 == param_3)) &&
       (iVar1 = (**(code **)(*(longlong *)param_1[0x49] + 0x38))(), iVar1 == param_2)) {
      return param_1[0x49];
    }
    iVar1 = FUN_1402aef00(param_1,param_3,param_2,param_4,uVar3);
    if (iVar1 == 0) {
      lVar2 = 0;
    }
    else {
      lVar2 = (**(code **)(*param_1 + 0x98))(param_1,iVar1);
      if (lVar2 != 0) {
        param_1[0x49] = lVar2;
      }
    }
  }
  return lVar2;
}

// ==== CUserManager::vfunc_0  @1402b0890  [high:rtti-vtable]  (orig: FUN_1402b0890)
void FUN_1402b0890(longlong param_1,undefined4 param_2,longlong param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = FUN_1401d26c0(*(undefined4 *)(param_1 + 0x280));
  if (lVar1 != 0) {
    plVar2 = (longlong *)FUN_1402af4c0(param_1 + 0x208,local_res10);
    *plVar2 = lVar1;
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    plVar2 = (longlong *)FUN_1400875f0(uVar3);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x30))(plVar2);
    (**(code **)(*plVar2 + 0x28))(plVar2,lVar1 + 0x10);
  }
  return;
}

// ==== CUserManager::helper_1402b0a70  @1402b0a70  [medium:callgraph-r0]  (orig: FUN_1402b0a70)
undefined8 * FUN_1402b0a70(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402aa550(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CUserManager::ctor_or_dtor  @1402b0bc0  [high:vtable-assign]  (orig: FUN_1402b0bc0)
void FUN_1402b0bc0(undefined8 *param_1)

{
  *param_1 = CUserManager::vftable;
  FUN_14000c310(param_1 + 0x59);
  operator_delete((void *)param_1[0x59]);
  FUN_1402adfe0(param_1 + 0x51);
  operator_delete((void *)param_1[0x51]);
  if ((void *)param_1[0x4d] != (void *)0x0) {
    operator_delete((void *)param_1[0x4d]);
  }
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  operator_delete((void *)param_1[0x4a]);
  FUN_1402adfe0(param_1 + 0x41);
  operator_delete((void *)param_1[0x41]);
  param_1[0x38] = Index<unsigned_long,int>::vftable;
  FUN_14006d470(param_1 + 0x39);
  operator_delete((void *)param_1[0x39]);
  FUN_14006d470(param_1 + 0x2d);
  operator_delete((void *)param_1[0x2d]);
  FUN_1400a9720(param_1 + 0x24);
  operator_delete((void *)param_1[0x24]);
  FUN_1402af8a0(param_1 + 0x1b);
  operator_delete((void *)param_1[0x1b]);
  FUN_14000c310(param_1 + 0x13);
  operator_delete((void *)param_1[0x13]);
  FUN_140050610(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_1402af7b0(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CUserManager::vfunc_2  @1402b0d60  [high:rtti-vtable]  (orig: FUN_1402b0d60)
undefined8 FUN_1402b0d60(undefined8 param_1)

{
  return param_1;
}

// ==== CUserManager::vfunc_22  @1402b0d70  [high:rtti-vtable]  (orig: FUN_1402b0d70)
undefined4 FUN_1402b0d70(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CUserManager::vfunc_24  @1402b0dd0  [high:rtti-vtable]  (orig: FUN_1402b0dd0)
void FUN_1402b0dd0(longlong *param_1)

{
  undefined4 *puVar1;
  longlong lVar2;
  
  if (param_1[0x4e] - param_1[0x4d] >> 2 == 0) {
    return;
  }
  puVar1 = (undefined4 *)param_1[0x4d];
  if ((undefined4 *)param_1[0x4e] < puVar1) {
    _invalid_parameter_noinfo();
  }
  if ((longlong *)param_1[0x4a] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = 0;
  }
  else {
    lVar2 = *(longlong *)param_1[0x4a];
  }
  if (*(undefined4 **)(lVar2 + 0x20) <= puVar1) {
    _invalid_parameter_noinfo();
  }
                    /* WARNING: Could not recover jumptable at 0x0001402b0e49. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x98))(param_1,*puVar1);
  return;
}

// ==== CUserManager::vfunc_7  @1402b0e50  [high:rtti-vtable]  (orig: FUN_1402b0e50)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1402b0e50(longlong param_1,undefined4 param_2,longlong *param_3)

{
  char cVar1;
  short sVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  ulong uVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 *puVar11;
  undefined8 uVar12;
  IStringManager *pIVar13;
  uint uVar14;
  longlong lVar15;
  undefined1 auStack_19f8 [32];
  undefined8 local_19d8;
  undefined4 local_19d0;
  longlong local_19c8;
  longlong local_19c0;
  undefined4 local_19b8 [2];
  longlong local_19b0 [2];
  undefined1 local_19a0 [24];
  undefined1 local_1988 [1072];
  undefined1 local_1558 [1072];
  undefined1 local_1128 [1072];
  undefined1 local_cf8 [1072];
  undefined1 local_8c8 [1072];
  undefined1 local_498 [1104];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x1402b0e66;
  local_19b0[1] = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_19f8;
  local_19b0[0] = CONCAT44(local_19b0[0]._4_4_,param_2);
  local_19b8[0] = param_2;
  if (param_3 == (longlong *)0x0) {
    local_19d8 = CONCAT44(local_19d8._4_4_,0x149);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else {
    puVar7 = (undefined8 *)FUN_1402af4c0(param_1 + 0x208,local_19b0);
    *puVar7 = param_3;
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    if (*(longlong *)(lVar8 + 0x88) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x12f);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar9 = (longlong *)(**(code **)(**(longlong **)(lVar8 + 0x88) + 0x30))();
    (**(code **)(*plVar9 + 0x28))(plVar9,param_3 + 2);
    plVar9 = (longlong *)CurrentInstanceGet();
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,0x16);
    if (plVar9 != (longlong *)0x0) {
      lVar8 = *plVar9;
      uVar3 = (**(code **)(*param_3 + 8))(param_3);
      uVar3 = (**(code **)(lVar8 + 0xb0))(plVar9,uVar3);
      FUN_140165790(param_3,uVar3);
    }
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar15 = 0;
    lVar8 = *(longlong *)(lVar10 + 0x1a8);
    if (*(longlong *)(lVar10 + 0x1a8) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x159);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_1402e64b0(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x1c0);
    if (*(longlong *)(lVar10 + 0x1c0) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x15c);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_1401f1190(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x1d0);
    if (*(longlong *)(lVar10 + 0x1d0) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x15e);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_1401f79d0(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x1f8);
    if (*(longlong *)(lVar10 + 0x1f8) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x163);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_140261990(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x200);
    if (*(longlong *)(lVar10 + 0x200) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x164);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_140269240(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x220);
    if (*(longlong *)(lVar10 + 0x220) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x168);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_140208d50(lVar8,param_3);
    FUN_140168cb0(param_3);
    iVar4 = (**(code **)(*param_3 + 0x78))(param_3,0);
    if (iVar4 == 0) {
      local_19d8 = 0;
      (**(code **)(param_3[2] + 0x2e0))(param_3 + 2,0,1);
    }
    puVar11 = (undefined8 *)FUN_1400e1e60();
    puVar7 = (undefined8 *)*puVar11;
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    (*(code *)*puVar7)(puVar11,uVar3);
    FUN_140194390(param_3);
    FUN_1401727e0(param_3);
    sVar2 = FUN_140163440(param_3);
    if (sVar2 != 0) {
      FUN_1401728d0(param_3);
    }
    lVar8 = DAT_140975be0;
    if (DAT_140975be0 == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x3c5);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    uVar3 = (**(code **)(param_3[2] + 0x70))(param_3 + 2);
    lVar8 = FUN_14014de60(lVar8,0,uVar3);
    if (lVar8 != 0) {
      plVar9 = (longlong *)
               (**(code **)(**(longlong **)(lVar8 + 8) + 0x10))(*(longlong **)(lVar8 + 8),1);
      lVar8 = (**(code **)(*plVar9 + 0x58))(plVar9);
      local_19b0[0] = (**(code **)(*param_3 + 0xa0))(param_3);
      if (lVar8 < local_19b0[0]) {
        FUN_140371b40(param_3 + 0x1cf,lVar8 + -1,0);
        uVar3 = (**(code **)(param_3[2] + 0x70))(param_3 + 2);
        uVar12 = (**(code **)(param_3[2] + 0x18))(param_3 + 2);
        (**(code **)(*param_3 + 8))(param_3);
        local_19c8 = local_19b0[0];
        local_19d8 = uVar12;
        local_19d0 = uVar3;
        local_19c0 = lVar8;
        tq::MyLogSave("gmlog/expcheater1","%u\t%u\t%s\t%u\t%I64d\t%I64d\t");
        param_2 = local_19b8[0];
      }
    }
    FUN_14044df40(local_498);
    uVar3 = FUN_1401649c0(param_3);
    uVar5 = (**(code **)(*param_3 + 8))(param_3);
    iVar4 = FUN_14044e030(local_498,uVar5,param_3 + 0x1d0,uVar3);
    if (iVar4 != 0) {
      puVar7 = (undefined8 *)FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      (**(code **)*puVar7)(puVar7,param_2,local_498);
    }
    plVar9 = (longlong *)CurrentInstanceGet();
    puVar7 = (undefined8 *)(**(code **)(*plVar9 + 0x20))(plVar9,0x11);
    if (puVar7 != (undefined8 *)0x0) {
      puVar11 = (undefined8 *)*puVar7;
      uVar3 = (**(code **)(*param_3 + 8))(param_3);
      (*(code *)*puVar11)(puVar7,uVar3);
    }
    iVar4 = FUN_1401642c0(param_3);
    if (iVar4 == 0) {
      *(undefined1 *)((longlong)param_3 + 0x51c) = 1;
    }
    else {
      *(undefined1 *)((longlong)param_3 + 0x51c) = 0;
      iVar4 = FUN_140164270(param_3);
      if (iVar4 == 0) {
        FUN_14044e580(local_1988);
        iVar4 = FUN_14044e730(local_1988);
        if (iVar4 != 0) {
          FUN_14044e620(local_1988,param_3,5);
        }
        FUN_14044e5d0(local_1988);
      }
      else {
        uVar6 = tq::TimeStampGet();
        uVar14 = FUN_140164270(param_3);
        if (uVar6 / 100 < uVar14) {
          FUN_14044e580(local_1988);
          iVar4 = FUN_14044e730(local_1988);
          if (iVar4 != 0) {
            FUN_14044e620(local_1988,param_3,8);
          }
          FUN_14044e5d0(local_1988);
        }
        else {
          *(undefined1 *)((longlong)param_3 + 0x51c) = 1;
          FUN_140164280(param_3,0);
          FUN_1401642a0(param_3,0);
          FUN_14044e580(local_1988);
          iVar4 = FUN_14044e730(local_1988);
          if (iVar4 != 0) {
            FUN_14044e6c0(local_1988,param_3,2);
          }
          FUN_14044e5d0(local_1988);
        }
      }
    }
    FUN_14039e680(local_1988);
    uVar12 = (**(code **)(param_3[2] + 0x58))(param_3 + 2,local_19a0);
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    iVar4 = FUN_14039ec00(local_1988,uVar3,0x19,uVar12);
    if (iVar4 != 0) {
      puVar7 = (undefined8 *)FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      (**(code **)*puVar7)(puVar7,param_2,local_1988);
    }
    FUN_14039e6d0(local_1988);
    if ((999 < *(short *)((longlong)param_3 + 0xef4)) &&
       (iVar4 = FUN_140161f50(param_3), iVar4 != 6000)) {
      plVar9 = (longlong *)FUN_1401182a0();
      lVar8 = *plVar9;
      uVar3 = (**(code **)(*param_3 + 8))(param_3);
      (**(code **)(lVar8 + 0x18))(plVar9,uVar3);
    }
    cVar1 = FUN_140164440(param_3);
    if (cVar1 != '\0') {
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      plVar9 = (longlong *)FUN_140087650(uVar12);
      lVar8 = *plVar9;
      uVar3 = (**(code **)(*param_3 + 0x48))(param_3);
      plVar9 = (longlong *)(**(code **)(lVar8 + 0x98))(plVar9,uVar3);
      if (plVar9 != (longlong *)0x0) {
        pIVar13 = theInstance();
        uVar12 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"MALE_MATE_LOGIN");
        iVar4 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if (iVar4 == 1) {
          pIVar13 = theInstance();
          uVar12 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"FEMALE_MATE_LOGIN");
        }
        (**(code **)(*plVar9 + 0x150))(plVar9,2000,uVar12);
      }
    }
    uVar14 = (int)*(undefined8 *)(param_1 + 0x240) + *(int *)(param_1 + 0xc);
    if (*(uint *)(param_1 + 8) <= uVar14) {
      *(uint *)(param_1 + 8) = uVar14;
    }
    FUN_14039e680(local_1128);
    uVar3 = FUN_1401649c0(param_3);
    uVar5 = (**(code **)(*param_3 + 8))(param_3);
    iVar4 = FUN_14039e700(local_1128,uVar5,0x27,uVar3);
    if (iVar4 != 0) {
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      cVar1 = FUN_14008abd0(uVar12);
      if (cVar1 != '\0') {
        uVar3 = FUN_1401649b0(param_3);
        FUN_14039e9a0(local_1128,0x48,uVar3);
      }
      (**(code **)(param_3[2] + 0x350))(param_3 + 2,local_1128);
    }
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    uVar3 = FUN_14008ab90(uVar12);
    FUN_14044e410(local_8c8);
    iVar4 = FUN_14044e4c0(local_8c8,uVar3);
    if (iVar4 != 0) {
      (**(code **)(param_3[2] + 0x350))(param_3 + 2,local_8c8);
    }
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    if (*(longlong *)(lVar8 + 0x98) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x131);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x98) + 0x10))
                      (*(longlong **)(lVar8 + 0x98),*(undefined4 *)((longlong)param_3 + 0xf2c),1);
    if (lVar8 != 0) {
      FUN_14039e680(local_1988);
      iVar4 = (**(code **)(**(longlong **)(lVar8 + 0x58) + 0x10))(*(longlong **)(lVar8 + 0x58),0xf);
      uVar3 = (**(code **)(*param_3 + 8))(param_3);
      FUN_14039e700(local_1988,uVar3,0x4c,(longlong)iVar4);
      puVar7 = (undefined8 *)FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      (**(code **)*puVar7)(puVar7,param_2,local_1988);
      FUN_14039e6d0(local_1988);
    }
    FUN_14039e680(local_cf8);
    uVar3 = FUN_140166ab0(param_3);
    uVar5 = (**(code **)(*param_3 + 8))(param_3);
    iVar4 = FUN_14039e700(local_cf8,uVar5,0x4d,uVar3);
    if (iVar4 != 0) {
      (**(code **)(param_3[2] + 0x350))(param_3 + 2,local_cf8);
    }
    FUN_14039e680(local_1558);
    uVar3 = FUN_140168bc0(param_3);
    uVar5 = (**(code **)(*param_3 + 8))(param_3);
    iVar4 = FUN_14039e700(local_1558,uVar5,0x4f,uVar3);
    if (iVar4 != 0) {
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
      iVar4 = FUN_14008afc0(uVar12);
      FUN_14039e9a0(local_1558,0x50,(longlong)iVar4);
      (**(code **)(param_3[2] + 0x350))(param_3 + 2,local_1558);
    }
    lVar8 = DAT_140975b68;
    if (DAT_140975b68 == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x3c1);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_140113f40(lVar8,param_3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0x140);
    if (*(longlong *)(lVar10 + 0x140) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x149);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    FUN_14024e510(lVar8,uVar3);
    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar10 + 0xf8);
    if (*(longlong *)(lVar10 + 0xf8) == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x142);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    FUN_140157940(lVar8,uVar3);
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    lVar8 = *(longlong *)(lVar8 + 0x1c8);
    if (lVar8 == 0) {
      local_19d8 = CONCAT44(local_19d8._4_4_,0x15d);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar15;
    }
    FUN_1400d4ff0(lVar8,param_3);
    plVar9 = (longlong *)FUN_1400e1e60();
    lVar8 = *plVar9;
    uVar3 = (**(code **)(*param_3 + 8))(param_3);
    (**(code **)(lVar8 + 8))(plVar9,uVar3);
    uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    FUN_1400a8190(uVar12,param_3);
    cVar1 = (**(code **)(param_3[2] + 0x230))(param_3 + 2);
    if (cVar1 != '\0') {
      local_19b8[0] = (**(code **)(*param_3 + 8))(param_3);
      FUN_140037fe0(param_1 + 0x250,local_19b8);
    }
    plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    (**(code **)(*plVar9 + 0x118))
              (plVar9,*(undefined4 *)(param_1 + 0x280),*(undefined4 *)((longlong)param_3 + 0x122c));
    FUN_14039e6d0(local_1558);
    FUN_14039e6d0(local_cf8);
    FUN_14044e460(local_8c8);
    FUN_14039e6d0(local_1128);
    FUN_14044dfc0(local_498);
    uVar12 = 1;
  }
  return uVar12;
}

// ==== CUserManager::helper_1402b1e50  @1402b1e50  [medium:callgraph-r0]  (orig: FUN_1402b1e50)
undefined8 * FUN_1402b1e50(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402aa4f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x31) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CUserManager::ctor_or_dtor  @1402b1ed0  [high:vtable-assign]  (orig: FUN_1402b1ed0)
undefined8 * FUN_1402b1ed0(undefined8 *param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CUserManager::vftable;
  plVar2 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0xee69a160;
  FUN_1402b1dd0(param_1 + 3);
  FUN_1400546e0(param_1 + 0xb);
  FUN_14000ef40(param_1 + 0x13);
  FUN_1402b1e50(param_1 + 0x1b);
  FUN_1400b8550(param_1 + 0x24);
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x164) = 0;
  FUN_140072180(param_1 + 0x2d);
  *(undefined4 *)(param_1 + 0x35) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1ac) = 0;
  *(undefined1 *)(param_1 + 0x36) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1b4) = 0;
  *(undefined4 *)(param_1 + 0x37) = 0;
  param_1[0x38] = Index<unsigned_long,int>::vftable;
  FUN_140072180(param_1 + 0x39);
  FUN_1402b0a70(param_1 + 0x41);
  param_1[0x49] = 0;
  plVar1 = operator_new(8);
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 0x4a);
    plVar2 = plVar1;
  }
  param_1[0x4a] = plVar2;
  param_1[0x4d] = 0;
  param_1[0x4e] = 0;
  param_1[0x4f] = 0;
  *(undefined4 *)(param_1 + 0x50) = param_2;
  FUN_1402b0a70(param_1 + 0x51);
  FUN_14000ef40(param_1 + 0x59);
  *(undefined4 *)(param_1 + 0x61) = 0;
  FUN_14000a7b0(param_1 + 0x59);
  return param_1;
}

// ==== CUserManager::vfunc_1  @1402b2030  [high:rtti-vtable]  (orig: FUN_1402b2030)
undefined8 FUN_1402b2030(undefined8 param_1,uint param_2)

{
  FUN_1402b0bc0();
  if ((param_2 & 1) != 0) {
    FUN_1402a9110(param_1);
  }
  return param_1;
}

// ==== CUserManager::helper_1402b2060  @1402b2060  [medium:callgraph-r2]  (orig: FUN_1402b2060)
undefined8 * FUN_1402b2060(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140044080(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_140044080(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140044080(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x51) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x51) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x51);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x51);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x51);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x51);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x51) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x51) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x51) != '\0') {
              FUN_140044080(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_140044080(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x51) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x51) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x51);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x51);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x51);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x51);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x51) != '\0') {
              FUN_140044080(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140044080(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_140044900(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CUserManager::helper_1402b2380  @1402b2380  [medium:callgraph-r1]  (orig: FUN_1402b2380)
undefined8 * FUN_1402b2380(undefined8 *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong *local_c8 [3];
  void *local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  uint local_98 [2];
  void *local_90 [3];
  void *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 *local_58;
  undefined8 *puStack_50;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  puVar1 = (undefined8 *)*param_1;
  puVar2 = (undefined8 *)param_1[6];
  if (puVar1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar5 = (longlong *)0x0;
  if ((puVar4 == puVar2) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_58 = puVar1;
    puStack_50 = puVar4;
    plVar3 = operator_new(8);
    local_c8[0] = plVar5;
    if (plVar3 != (longlong *)0x0) {
      *plVar3 = (longlong)local_c8;
      local_c8[0] = plVar3;
    }
    local_b0 = (void *)0x0;
    local_a8 = 0;
    local_a0 = 0;
    local_98[0] = *param_2;
    FUN_140043260(local_90,local_c8);
    puVar4 = (undefined8 *)FUN_1402b2060(param_1,local_40,&local_58,local_98);
    puVar1 = (undefined8 *)*puVar4;
    puVar4 = (undefined8 *)puVar4[1];
    if (local_78 != (void *)0x0) {
      operator_delete(local_78);
    }
    local_78 = (void *)0x0;
    local_70 = 0;
    local_68 = 0;
    operator_delete(local_90[0]);
    if (local_b0 != (void *)0x0) {
      operator_delete(local_b0);
    }
    local_b0 = (void *)0x0;
    local_a8 = 0;
    local_a0 = 0;
    operator_delete(local_c8[0]);
  }
  if (puVar1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    plVar5 = (longlong *)*puVar1;
  }
  if (puVar4 == (undefined8 *)plVar5[6]) {
    _invalid_parameter_noinfo();
  }
  return puVar4 + 4;
}

// ==== CUserManager::helper_1402b2560  @1402b2560  [medium:callgraph-r0]  (orig: FUN_1402b2560)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Removing unreachable block (ram,0x0001402b2a0d) */
/* WARNING: Removing unreachable block (ram,0x0001402b2a33) */
/* WARNING: Removing unreachable block (ram,0x0001402b2a4f) */
/* WARNING: Removing unreachable block (ram,0x0001402b2a8d) */
/* WARNING: Removing unreachable block (ram,0x0001402b2a92) */
/* WARNING: Removing unreachable block (ram,0x0001402b2aa0) */
/* WARNING: Removing unreachable block (ram,0x0001402b2aa5) */
/* WARNING: Removing unreachable block (ram,0x0001402b2aaa) */
/* WARNING: Removing unreachable block (ram,0x0001402b2ab0) */

void FUN_1402b2560(longlong param_1,longlong *param_2,undefined4 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong *plVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong *plVar4;
  void *pvVar5;
  char cVar6;
  ulong uVar7;
  undefined4 uVar8;
  uint uVar9;
  int iVar10;
  longlong lVar11;
  longlong *plVar12;
  undefined8 uVar13;
  ulonglong uVar14;
  longlong **pplVar15;
  longlong *plVar16;
  undefined4 *puVar17;
  longlong *plVar18;
  longlong *plVar19;
  longlong lVar20;
  undefined1 auStack_638 [32];
  undefined4 local_618;
  undefined4 local_610;
  undefined1 local_608;
  undefined8 local_5f8;
  undefined8 uStack_5f0;
  undefined4 local_5e8;
  undefined8 local_5d8;
  undefined8 uStack_5d0;
  longlong *local_5c8 [6];
  longlong *local_598;
  undefined8 local_590;
  longlong *local_588 [2];
  undefined4 local_578;
  undefined4 uStack_574;
  undefined4 uStack_570;
  undefined4 uStack_56c;
  undefined4 local_568;
  undefined4 uStack_564;
  undefined4 uStack_560;
  undefined4 uStack_55c;
  longlong *local_558 [3];
  void *local_540;
  void *local_538;
  undefined8 local_530;
  undefined4 local_528;
  uint uStack_524;
  undefined4 local_520;
  undefined1 uStack_51c;
  undefined1 uStack_51b;
  undefined2 uStack_51a;
  longlong *local_518;
  longlong local_510;
  longlong *local_508;
  longlong *local_500;
  longlong *local_4f8;
  longlong *local_4f0;
  longlong *local_4e8;
  longlong *local_4e0;
  longlong *local_4d8;
  undefined8 local_4d0;
  undefined8 local_4c8;
  undefined8 local_4c0;
  longlong *local_4b8;
  longlong *local_4b0;
  undefined8 local_4a8;
  longlong *local_4a0;
  undefined1 local_498 [32];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_638;
  local_608 = param_4;
  local_5e8 = param_3;
  local_510 = param_1;
  local_508 = param_2;
  local_4b0 = param_2;
  local_588[0] = operator_new(8);
  local_5c8[0] = (longlong *)0x0;
  if (local_588[0] != (longlong *)0x0) {
    *local_588[0] = (longlong)local_5c8;
    local_5c8[0] = local_588[0];
  }
  local_518 = local_588[0];
  local_598 = (longlong *)FUN_140042870(local_5c8);
  *(undefined1 *)((longlong)local_598 + 0x51) = 1;
  local_598[1] = (longlong)local_598;
  *local_598 = (longlong)local_598;
  local_598[2] = (longlong)local_598;
  local_590 = 0;
  puVar17 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar17) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  do {
    lVar11 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar17 == puVar2) {
      FUN_14044ec50(local_478);
      uVar8 = local_5e8;
      cVar6 = FUN_14044ed00(local_478,1,local_5e8);
      lVar11 = local_510;
      plVar1 = local_5c8[0];
      if (cVar6 == '\0') {
        local_618 = 0x5b7;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_14044eca0(local_478);
        uStack_5f0 = local_598;
        plVar12 = uStack_5f0;
        local_5f8 = local_5c8[0];
        plVar1 = local_5f8;
        lVar11 = *local_598;
        local_5d8 = local_5c8[0];
        local_5f8._0_4_ = SUB84(local_5c8[0],0);
        local_5f8._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
        uStack_5f0._0_4_ = SUB84(local_598,0);
        uStack_5f0._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
        local_578 = (undefined4)local_5f8;
        uStack_574 = local_5f8._4_4_;
        uStack_570 = (undefined4)uStack_5f0;
        uStack_56c = uStack_5f0._4_4_;
        uStack_5d0._0_4_ = (undefined4)lVar11;
        uStack_5d0._4_4_ = (undefined4)((ulonglong)lVar11 >> 0x20);
        local_568 = (undefined4)local_5f8;
        uStack_564 = local_5f8._4_4_;
        uStack_560 = (undefined4)uStack_5d0;
        uStack_55c = uStack_5d0._4_4_;
        local_5f8 = plVar1;
        uStack_5f0 = plVar12;
        uStack_5d0 = (undefined4 *)lVar11;
        FUN_140044ab0(local_5c8,&local_5f8,&local_568,&local_578);
        operator_delete(local_598);
        local_598 = (longlong *)0x0;
        local_590 = 0;
        operator_delete(local_5c8[0]);
        if ((void *)param_2[3] != (void *)0x0) {
          operator_delete((void *)param_2[3]);
        }
        param_2[3] = 0;
        param_2[4] = 0;
        param_2[5] = 0;
        operator_delete((void *)*param_2);
      }
      else {
        plVar12 = (longlong *)*local_598;
        while( true ) {
          plVar19 = local_598;
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_5c8[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar12 == plVar19) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar20 = 0;
          }
          else {
            lVar20 = *plVar1;
          }
          if (plVar12 == *(longlong **)(lVar20 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          puVar17 = (undefined4 *)plVar12[7];
          if ((undefined4 *)plVar12[8] < puVar17) {
            _invalid_parameter_noinfo();
          }
          plVar19 = (longlong *)plVar12[4];
          while( true ) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar20 = 0;
            }
            else {
              lVar20 = *plVar1;
            }
            if (plVar12 == *(longlong **)(lVar20 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            puVar2 = (undefined4 *)plVar12[8];
            if (puVar2 < (undefined4 *)plVar12[7]) {
              _invalid_parameter_noinfo();
            }
            if ((plVar19 == (longlong *)0x0) || (plVar19 != (longlong *)plVar12[4])) {
              _invalid_parameter_noinfo();
            }
            if (puVar17 == puVar2) break;
            if (plVar19 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar20 = 0;
            }
            else {
              lVar20 = *plVar19;
            }
            if (*(undefined4 **)(lVar20 + 0x20) <= puVar17) {
              _invalid_parameter_noinfo();
            }
            cVar6 = FUN_14044ed40(local_478,*puVar17);
            if (cVar6 == '\0') {
              uVar14 = (ulonglong)*(uint *)(lVar11 + 0x280);
              iVar10 = FUN_1400084e0(uVar14);
              if (iVar10 == 0) {
                local_618 = 0x379;
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar18 = (longlong *)0x0;
              }
              else {
                if ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= uVar14) {
                  _invalid_parameter_noinfo();
                }
                plVar18 = (longlong *)(uVar14 * 0x850 + DAT_140975c20);
              }
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar20 = 0;
              }
              else {
                lVar20 = *plVar1;
              }
              if (plVar12 == *(longlong **)(lVar20 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              (**(code **)(*plVar18 + 0x18))(plVar18,(int)plVar12[3],local_478);
              cVar6 = FUN_14044ed00(local_478,1,uVar8);
              if (cVar6 == '\0') {
                local_618 = 0x5c2;
                log_InlineLogERROR(&DAT_1406d9c10);
                FUN_14044eca0(local_478);
                uStack_5f0 = local_598;
                plVar12 = uStack_5f0;
                local_5f8 = local_5c8[0];
                plVar1 = local_5f8;
                lVar11 = *local_598;
                local_5d8 = local_5c8[0];
                local_5f8._0_4_ = SUB84(local_5c8[0],0);
                local_5f8._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
                uStack_5f0._0_4_ = SUB84(local_598,0);
                uStack_5f0._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
                local_578 = (undefined4)local_5f8;
                uStack_574 = local_5f8._4_4_;
                uStack_570 = (undefined4)uStack_5f0;
                uStack_56c = uStack_5f0._4_4_;
                uStack_5d0._0_4_ = (undefined4)lVar11;
                uStack_5d0._4_4_ = (undefined4)((ulonglong)lVar11 >> 0x20);
                local_568 = (undefined4)local_5f8;
                uStack_564 = local_5f8._4_4_;
                uStack_560 = (undefined4)uStack_5d0;
                uStack_55c = uStack_5d0._4_4_;
                local_5f8 = plVar1;
                uStack_5f0 = plVar12;
                uStack_5d0 = (undefined4 *)lVar11;
                FUN_140044ab0(local_5c8,&local_5f8,&local_568,&local_578);
                operator_delete(local_598);
                local_598 = (longlong *)0x0;
                local_590 = 0;
                operator_delete(local_5c8[0]);
                if ((void *)param_2[3] != (void *)0x0) {
                  operator_delete((void *)param_2[3]);
                }
                param_2[3] = 0;
                param_2[4] = 0;
                param_2[5] = 0;
                operator_delete((void *)*param_2);
                return;
              }
              if (plVar19 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar20 = 0;
              }
              else {
                lVar20 = *plVar19;
              }
              if (*(undefined4 **)(lVar20 + 0x20) <= puVar17) {
                _invalid_parameter_noinfo();
              }
              FUN_14044ed40(local_478,*puVar17);
            }
            if (plVar19 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar20 = 0;
            }
            else {
              lVar20 = *plVar19;
            }
            if (*(undefined4 **)(lVar20 + 0x20) <= puVar17) {
              _invalid_parameter_noinfo();
            }
            puVar17 = puVar17 + 1;
          }
          uVar14 = (ulonglong)*(uint *)(lVar11 + 0x280);
          iVar10 = FUN_1400084e0(uVar14);
          if (iVar10 == 0) {
            local_618 = 0x379;
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar19 = (longlong *)0x0;
          }
          else {
            if ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= uVar14) {
              _invalid_parameter_noinfo();
            }
            plVar19 = (longlong *)(uVar14 * 0x850 + DAT_140975c20);
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar20 = 0;
          }
          else {
            lVar20 = *plVar1;
          }
          if (plVar12 == *(longlong **)(lVar20 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          (**(code **)(*plVar19 + 0x18))(plVar19,(int)plVar12[3],local_478);
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar12 + 0x51) == '\0') {
            plVar19 = (longlong *)plVar12[2];
            if (*(char *)((longlong)plVar19 + 0x51) == '\0') {
              cVar6 = *(char *)(*plVar19 + 0x51);
              plVar12 = plVar19;
              plVar19 = (longlong *)*plVar19;
              while (cVar6 == '\0') {
                cVar6 = *(char *)(*plVar19 + 0x51);
                plVar12 = plVar19;
                plVar19 = (longlong *)*plVar19;
              }
            }
            else {
              cVar6 = *(char *)(plVar12[1] + 0x51);
              plVar18 = (longlong *)plVar12[1];
              plVar19 = plVar12;
              while ((plVar12 = plVar18, cVar6 == '\0' && (plVar19 == (longlong *)plVar12[2]))) {
                cVar6 = *(char *)(plVar12[1] + 0x51);
                plVar18 = (longlong *)plVar12[1];
                plVar19 = plVar12;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        FUN_14044eca0(local_478);
        uStack_5f0 = local_598;
        plVar12 = uStack_5f0;
        local_5f8 = local_5c8[0];
        plVar1 = local_5f8;
        lVar11 = *local_598;
        local_5d8 = local_5c8[0];
        local_5f8._0_4_ = SUB84(local_5c8[0],0);
        local_5f8._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
        uStack_5f0._0_4_ = SUB84(local_598,0);
        uStack_5f0._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
        local_578 = (undefined4)local_5f8;
        uStack_574 = local_5f8._4_4_;
        uStack_570 = (undefined4)uStack_5f0;
        uStack_56c = uStack_5f0._4_4_;
        uStack_5d0._0_4_ = (undefined4)lVar11;
        uStack_5d0._4_4_ = (undefined4)((ulonglong)lVar11 >> 0x20);
        local_568 = (undefined4)local_5f8;
        uStack_564 = local_5f8._4_4_;
        uStack_560 = (undefined4)uStack_5d0;
        uStack_55c = uStack_5d0._4_4_;
        local_5f8 = plVar1;
        uStack_5f0 = plVar12;
        uStack_5d0 = (undefined4 *)lVar11;
        FUN_140044ab0(local_5c8,&local_5f8,&local_568,&local_578);
        operator_delete(local_598);
        local_598 = (longlong *)0x0;
        local_590 = 0;
        operator_delete(local_5c8[0]);
        if ((void *)param_2[3] != (void *)0x0) {
          operator_delete((void *)param_2[3]);
        }
        param_2[3] = 0;
        param_2[4] = 0;
        param_2[5] = 0;
        operator_delete((void *)*param_2);
      }
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar1;
    }
    if (*(undefined4 **)(lVar11 + 0x20) <= puVar17) {
      _invalid_parameter_noinfo();
    }
    uVar8 = *puVar17;
    lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x280));
    if (*(longlong *)(lVar11 + 0x90) == 0) {
      local_618 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(lVar11 + 0x90) + 0x98))
                        (*(longlong **)(lVar11 + 0x90),uVar8);
    if (plVar12 != (longlong *)0x0) {
      local_528 = 5;
      uVar7 = tq::TimeGet(0);
      uStack_524 = uVar7 / 1000;
      uStack_51b = param_5;
      local_520 = uVar8;
      uStack_51c = param_4;
      uVar8 = (**(code **)(*plVar12 + 0x38))(plVar12);
      local_588[0] = (longlong *)CONCAT44(local_588[0]._4_4_,uVar8);
      uVar9 = FUN_140167b40(plVar12);
      local_518 = (longlong *)CONCAT44(local_518._4_4_,uVar9);
      local_4d0 = CONCAT44(uVar9,uVar8);
      local_4c8 = CONCAT44(uStack_524,local_528);
      local_4c0 = CONCAT26(uStack_51a,CONCAT15(uStack_51b,CONCAT14(uStack_51c,local_520)));
      FUN_1402acbc0(param_1 + 0xd8,local_498,&local_4d0);
      plVar4 = local_598;
      cVar6 = *(char *)(local_598[1] + 0x51);
      plVar19 = (longlong *)local_598[1];
      plVar18 = local_598;
      while (plVar16 = plVar19, cVar6 == '\0') {
        if (*(uint *)(plVar16 + 3) < uVar9) {
          plVar19 = (longlong *)plVar16[2];
          plVar16 = plVar18;
        }
        else {
          plVar19 = (longlong *)*plVar16;
        }
        cVar6 = *(char *)((longlong)plVar19 + 0x51);
        plVar18 = plVar16;
      }
      local_4f8 = plVar18;
      local_500 = local_5c8[0];
      if (local_5c8[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar19 = local_598;
      if ((plVar18 == plVar4) || (uVar9 < *(uint *)(plVar18 + 3))) {
        local_4d8 = local_598;
        local_4e0 = local_5c8[0];
        pplVar15 = &local_4e0;
      }
      else {
        pplVar15 = &local_500;
      }
      plVar18 = *pplVar15;
      local_4f0 = plVar18;
      local_4e8 = pplVar15[1];
      if ((plVar18 == (longlong *)0x0) || (plVar18 != local_5c8[0])) {
        _invalid_parameter_noinfo();
      }
      plVar4 = local_4e8;
      if (local_4e8 == plVar19) {
        local_4b8 = operator_new(8);
        if (local_4b8 == (longlong *)0x0) {
          local_558[0] = (longlong *)0x0;
        }
        else {
          *local_4b8 = (longlong)local_558;
          local_558[0] = local_4b8;
        }
        lVar11 = 0;
        local_530 = 0;
        local_538 = (void *)0x0;
        local_540 = (void *)0x0;
        uStack_5f0 = (longlong *)0x0;
        local_5f8._0_4_ = SUB84(local_558[0],0);
        local_5f8._4_4_ = (undefined4)((ulonglong)local_558[0] >> 0x20);
        local_578 = (undefined4)local_5f8;
        uStack_574 = local_5f8._4_4_;
        uStack_570 = 0;
        uStack_56c = 0;
        local_5f8 = local_558[0];
        local_4a0 = local_4b8;
        FUN_140036c20(local_558,&local_578,1,local_588);
        pvVar5 = local_540;
        if (local_538 < local_540) {
          _invalid_parameter_noinfo();
        }
        plVar19 = local_558[0];
        if (local_558[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar20 = lVar11;
        }
        else {
          lVar20 = *local_558[0];
        }
        if (*(void **)(lVar20 + 0x20) < pvVar5) {
LAB_1402b2b38:
          _invalid_parameter_noinfo();
        }
        else {
          if (plVar19 != (longlong *)0x0) {
            lVar11 = *plVar19;
          }
          if (pvVar5 < *(void **)(lVar11 + 0x18)) goto LAB_1402b2b38;
        }
        uVar13 = FUN_1402b2380(local_5c8,&local_518);
        FUN_140037140(uVar13,local_558);
        if (local_540 != (void *)0x0) {
          operator_delete(local_540);
        }
        local_540 = (void *)0x0;
        local_538 = (void *)0x0;
        local_530 = 0;
        operator_delete(local_558[0]);
      }
      else {
        if (plVar18 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar18;
        }
        if (plVar4 == *(longlong **)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar19 = plVar4 + 4;
        puVar2 = (undefined4 *)plVar4[7];
        if (puVar2 == (undefined4 *)0x0) {
          uVar14 = 0;
        }
        else {
          uVar14 = plVar4[9] - (longlong)puVar2 >> 2;
        }
        puVar3 = (undefined4 *)plVar4[8];
        if ((ulonglong)((longlong)puVar3 - (longlong)puVar2 >> 2) < uVar14) {
          *puVar3 = uVar8;
          plVar4[8] = (longlong)(puVar3 + 1);
        }
        else {
          if (puVar3 < puVar2) {
            _invalid_parameter_noinfo();
          }
          lVar11 = *plVar19;
          uVar14 = plVar4[7];
          local_5d8 = (longlong *)lVar11;
          uStack_5d0 = puVar3;
          if ((plVar4[8] - uVar14 & 0xfffffffffffffffc) == 0) {
            lVar11 = 0;
          }
          else {
            if ((ulonglong)plVar4[8] < uVar14) {
              _invalid_parameter_noinfo();
            }
            if ((lVar11 == 0) || (lVar11 != *plVar19)) {
              _invalid_parameter_noinfo();
            }
            lVar11 = (longlong)((longlong)puVar3 - uVar14) >> 2;
          }
          local_568 = (undefined4)local_5d8;
          uStack_564 = local_5d8._4_4_;
          uStack_560 = (undefined4)uStack_5d0;
          uStack_55c = uStack_5d0._4_4_;
          FUN_140036c20(plVar19,&local_568,1,local_588);
          uVar14 = plVar4[7];
          if ((ulonglong)plVar4[8] < uVar14) {
            _invalid_parameter_noinfo();
          }
          plVar19 = (longlong *)*plVar19;
          if (plVar19 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar20 = 0;
          }
          else {
            lVar20 = *plVar19;
          }
          uVar14 = uVar14 + lVar11 * 4;
          if (uVar14 <= *(ulonglong *)(lVar20 + 0x20)) {
            if (plVar19 == (longlong *)0x0) {
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar19;
            }
            if (*(ulonglong *)(lVar11 + 0x18) <= uVar14) goto LAB_1402b2b98;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_1402b2b98:
      uVar8 = FUN_140167b40(plVar12);
      (**(code **)(*plVar12 + 8))(plVar12);
      (**(code **)(*plVar12 + 0x38))(plVar12);
      (**(code **)(plVar12[2] + 0x18))(plVar12 + 2);
      local_610 = local_5e8;
      local_618 = uVar8;
      log_InlineLogOSMessage("Exit OS: user:%s(%u,%u), server(%u) Reason[%d]");
      param_1 = local_510;
      param_4 = local_608;
    }
    lVar11 = 0;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar1;
    }
    if (*(undefined4 **)(lVar11 + 0x20) <= puVar17) {
      _invalid_parameter_noinfo();
    }
    puVar17 = puVar17 + 1;
    param_2 = local_508;
  } while( true );
}

// ==== CUserManager::vfunc_11  @1402b3270  [high:rtti-vtable]  (orig: FUN_1402b3270)
void FUN_1402b3270(undefined8 param_1,longlong *param_2,longlong param_3)

{
  longlong lVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *local_res10 [2];
  longlong *local_res20;
  longlong *local_a8;
  undefined4 *puStack_a0;
  longlong *local_98 [3];
  undefined4 *local_80;
  undefined4 *local_78;
  longlong local_70;
  longlong local_68 [6];
  
  if (param_2 == (longlong *)0x0) {
    return;
  }
  cVar4 = FUN_140167b70(param_2);
  if (cVar4 == '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(&DAT_140741f80);
    return;
  }
  if (param_3 != 0) {
    (**(code **)(param_2[2] + 0x18))(param_2 + 2);
    (**(code **)(*param_2 + 8))(param_2);
    (**(code **)(*param_2 + 0x38))(param_2);
    FUN_140167b40(param_2);
    (**(code **)(param_2[2] + 0x168))(param_2 + 2);
    log_InlineLogWARNING(&DAT_140741f00);
  }
  plVar6 = (longlong *)FUN_1401181a0();
  lVar1 = *plVar6;
  uVar5 = (**(code **)(*param_2 + 8))(param_2);
  (**(code **)(lVar1 + 0x38))(plVar6,uVar5);
  local_res10[0] = operator_new(8);
  plVar6 = (longlong *)0x0;
  local_98[0] = plVar6;
  if (local_res10[0] != (longlong *)0x0) {
    *local_res10[0] = (longlong)local_98;
    local_98[0] = local_res10[0];
  }
  local_80 = (undefined4 *)0x0;
  local_78 = (undefined4 *)0x0;
  local_70 = 0;
  local_res20 = local_res10[0];
  uVar5 = (**(code **)(*param_2 + 8))(param_2);
  puVar3 = local_78;
  local_res10[0] = (longlong *)CONCAT44(local_res10[0]._4_4_,uVar5);
  plVar8 = plVar6;
  if (local_80 != (undefined4 *)0x0) {
    plVar8 = (longlong *)(local_70 - (longlong)local_80 >> 2);
  }
  if ((longlong *)((longlong)local_78 - (longlong)local_80 >> 2) < plVar8) {
    *local_78 = uVar5;
    local_78 = local_78 + 1;
  }
  else {
    if (local_78 < local_80) {
      _invalid_parameter_noinfo();
    }
    puVar2 = local_80;
    plVar8 = local_98[0];
    local_a8 = local_98[0];
    puStack_a0 = puVar3;
    plVar9 = plVar6;
    if (((longlong)local_78 - (longlong)local_80 & 0xfffffffffffffffcU) != 0) {
      if (local_78 < local_80) {
        _invalid_parameter_noinfo();
      }
      if ((plVar8 == (longlong *)0x0) || (plVar8 != local_98[0])) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)((longlong)puVar3 - (longlong)puVar2 >> 2);
    }
    FUN_140036c20(local_98,&local_a8,1,local_res10);
    puVar3 = local_80;
    if (local_78 < local_80) {
      _invalid_parameter_noinfo();
    }
    plVar8 = local_98[0];
    if (local_98[0] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar10 = plVar6;
    }
    else {
      plVar10 = (longlong *)*local_98[0];
    }
    if (puVar3 + (longlong)plVar9 <= (undefined4 *)plVar10[4]) {
      if (plVar8 != (longlong *)0x0) {
        plVar6 = (longlong *)*plVar8;
      }
      if ((undefined4 *)plVar6[3] <= puVar3 + (longlong)plVar9) goto LAB_1402b34d9;
    }
    _invalid_parameter_noinfo();
  }
LAB_1402b34d9:
  local_res10[0] = local_68;
  uVar7 = FUN_140043260(local_68,local_98);
  FUN_1402b2560(param_1,uVar7,0x10,1,1);
  if (local_80 != (undefined4 *)0x0) {
    operator_delete(local_80);
  }
  local_80 = (undefined4 *)0x0;
  local_78 = (undefined4 *)0x0;
  local_70 = 0;
  operator_delete(local_98[0]);
  return;
}

// ==== CUserManager::vfunc_5  @1402b3df0  [high:rtti-vtable]  (orig: FUN_1402b3df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402b3df0(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  ulong uVar6;
  int iVar7;
  longlong *plVar8;
  tm *ptVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  longlong lVar13;
  longlong *plVar14;
  ulonglong uVar15;
  longlong *plVar16;
  longlong *plVar17;
  longlong *plVar18;
  longlong lVar19;
  uint uVar20;
  bool bVar21;
  undefined1 auStack_9e8 [32];
  int local_9c8;
  int local_9c0;
  int local_9b8;
  int local_9b0;
  int local_9a8;
  __time32_t local_998 [4];
  longlong *local_988;
  longlong *plStack_980;
  longlong *local_978;
  longlong *plStack_970;
  ulong local_968;
  longlong *local_960;
  longlong *local_958;
  longlong *local_950;
  longlong *local_948;
  longlong *local_938;
  longlong *plStack_930;
  longlong *local_928 [3];
  void *local_910;
  undefined8 local_908;
  undefined8 local_900;
  CTickAnalyst local_8f8 [24];
  undefined8 local_8e0;
  longlong local_8d8 [6];
  char local_8a8;
  undefined1 local_8a7 [1022];
  undefined1 local_4a9;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8e0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_9e8;
  local_988 = param_1;
  local_968 = tq::TimeGet(0);
  local_960 = param_1 + 0xb;
  plVar16 = *(longlong **)param_1[0x11];
  plVar14 = (longlong *)*local_960;
  uVar20 = 0;
  plVar8 = local_960;
  local_978 = plVar14;
  plStack_970 = plVar16;
  while( true ) {
    lVar13 = 0;
    plVar10 = (longlong *)plVar8[6];
    if ((plVar14 == (longlong *)0x0) || (plVar14 != (longlong *)*plVar8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar16 == plVar10) goto LAB_1402b40d0;
    uVar20 = uVar20 + 1;
    if (2000 < uVar20) break;
    if (plVar14 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar13 = *plVar14;
    }
    if (plVar16 == *(longlong **)(lVar13 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar13 = plVar16[3];
    if (plVar14 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar19 = 0;
    }
    else {
      lVar19 = *plVar14;
    }
    if (plVar16 == *(longlong **)(lVar19 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar18 = plStack_970;
    plVar10 = local_978;
    if (local_968 - *(int *)((longlong)plVar16 + 0x1c) < 0x7531) {
      if (plVar14 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar16 + 0x21) == '\0') {
        plVar10 = (longlong *)plVar16[2];
        if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
          cVar3 = *(char *)(*plVar10 + 0x21);
          plVar16 = plVar10;
          plVar10 = (longlong *)*plVar10;
          while (plStack_970 = plVar16, cVar3 == '\0') {
            cVar3 = *(char *)(*plVar10 + 0x21);
            plVar16 = plVar10;
            plVar10 = (longlong *)*plVar10;
          }
        }
        else {
          cVar3 = *(char *)(plVar16[1] + 0x21);
          plVar18 = (longlong *)plVar16[1];
          plVar10 = plVar16;
          while ((plVar16 = plVar18, plStack_970 = plVar16, cVar3 == '\0' &&
                 (plVar10 == (longlong *)plVar16[2]))) {
            cVar3 = *(char *)(plVar16[1] + 0x21);
            plVar18 = (longlong *)plVar16[1];
            plVar10 = plVar16;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    else {
      if (plVar14 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar16 + 0x21) == '\0') {
        plVar1 = (longlong *)plVar16[2];
        if (*(char *)((longlong)plVar1 + 0x21) == '\0') {
          cVar3 = *(char *)(*plVar1 + 0x21);
          plVar16 = plVar1;
          plVar1 = (longlong *)*plVar1;
          while (plStack_970 = plVar16, cVar3 == '\0') {
            cVar3 = *(char *)(*plVar1 + 0x21);
            plVar16 = plVar1;
            plVar1 = (longlong *)*plVar1;
          }
        }
        else {
          cVar3 = *(char *)(plVar16[1] + 0x21);
          plVar17 = (longlong *)plVar16[1];
          plVar1 = plVar16;
          while ((plVar16 = plVar17, plStack_970 = plVar16, cVar3 == '\0' &&
                 (plVar1 == (longlong *)plVar16[2]))) {
            cVar3 = *(char *)(plVar16[1] + 0x21);
            plVar17 = (longlong *)plVar16[1];
            plVar1 = plVar16;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_938 = plVar10;
      plStack_930 = plVar18;
      FUN_14004ee60(plVar8,local_8f8,&local_938);
      plVar8 = (longlong *)FUN_1402ae4a0(param_1,(__time32_t)lVar13);
      uVar4 = 0;
      uVar5 = 0xffffffff;
      if (plVar8 != (longlong *)0x0) {
        uVar4 = (**(code **)(*plVar8 + 0x38))(plVar8);
        uVar5 = FUN_140167b40(plVar8);
        (**(code **)(plVar8[2] + 8))();
      }
      local_998[0] = (__time32_t)lVar13;
      tq::CMySingleLock::CMySingleLock((CMySingleLock *)&local_958,(ILockObj *)&DAT_140975f50);
      FUN_1402af5f0(local_988 + 0x51,local_998);
      tq::CMySingleLock::~CMySingleLock((CMySingleLock *)&local_958);
      param_1 = local_988;
      FUN_1402af010(local_988,uVar5,uVar4);
      plVar8 = local_960;
    }
  }
  local_9c8 = 0x62;
  log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","ulCount",
                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.cpp"
                    );
LAB_1402b40d0:
  plVar16 = local_988;
  if ((char)local_988[0x36] == '\0') {
    uVar6 = tq::TimeGet(0);
    if ((uint)(*(int *)((longlong)plVar16 + 0x1ac) + (int)plVar16[0x35]) <= uVar6 / 1000) {
      uVar6 = tq::TimeGet(0);
      *(uint *)((longlong)plVar16 + 0x1ac) = uVar6 / 1000;
      if (*(int *)((longlong)plVar16 + 0x1b4) == 0x3b) {
        *(undefined4 *)((longlong)plVar16 + 0x1b4) = 0xffffffff;
      }
      *(int *)((longlong)plVar16 + 0x1b4) = *(int *)((longlong)plVar16 + 0x1b4) + 1;
      if (*(int *)((longlong)plVar16 + 0x1b4) == 0x3b) {
        *(undefined4 *)((longlong)plVar16 + 0x1b4) = 0xffffffff;
        local_998[0] = _time32((__time32_t *)0x0);
        ptVar9 = _localtime32(local_998);
        if (ptVar9 == (tm *)0x0) {
          return;
        }
        FUN_1403a6980(&local_8a8);
        local_9a8 = ptVar9->tm_sec;
        local_9b0 = ptVar9->tm_min;
        local_9b8 = ptVar9->tm_hour;
        local_9c0 = ptVar9->tm_mday;
        local_9c8 = ptVar9->tm_yday;
        iVar7 = FUN_1403a6a30(&local_8a8,0,ptVar9->tm_year,ptVar9->tm_mon);
        if (iVar7 != 0) {
          plVar14 = (longlong *)FUN_140008520((int)plVar16[0x50]);
          (**(code **)(*plVar14 + 0x68))(plVar14,&local_8a8,0xffffffff);
        }
        FUN_1403a69d0();
      }
    }
  }
  else {
    local_998[0] = _time32((__time32_t *)0x0);
    ptVar9 = _localtime32(local_998);
    if (ptVar9 == (tm *)0x0) {
      return;
    }
    if ((ptVar9->tm_sec == 0) || (ptVar9->tm_sec == 1)) {
      *(undefined4 *)(plVar16 + 0x35) = 0x3c;
      uVar6 = tq::TimeGet(0);
      *(uint *)((longlong)plVar16 + 0x1ac) = uVar6 / 1000;
      *(int *)((longlong)plVar16 + 0x1b4) = ptVar9->tm_min;
      *(undefined1 *)(plVar16 + 0x36) = 0;
    }
  }
  iVar7 = tq::DateStamp(0);
  if ((int)plVar16[0x61] != iVar7) {
    CTickAnalyst::CTickAnalyst(local_8f8,0x15);
    iVar7 = tq::DateStamp(0);
    *(int *)(plVar16 + 0x61) = iVar7;
    plVar10 = (longlong *)FUN_140118220();
    plVar14 = *(longlong **)plVar16[0x47];
    plVar8 = (longlong *)plVar16[0x41];
    while( true ) {
      plVar18 = (longlong *)plVar16[0x47];
      if ((plVar8 == (longlong *)0x0) || (plVar8 != (longlong *)plVar16[0x41])) {
        _invalid_parameter_noinfo();
      }
      if (plVar14 == plVar18) break;
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar8;
      }
      if (plVar14 == *(longlong **)(lVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar18 = (longlong *)plVar14[4];
      if (plVar18 != (longlong *)0x0) {
        FUN_1401727e0(plVar18);
        if (plVar10 != (longlong *)0x0) {
          lVar13 = *plVar10;
          uVar4 = (**(code **)(*plVar18 + 8))(plVar18);
          cVar3 = (**(code **)(lVar13 + 0x98))(plVar10,uVar4);
          if (cVar3 != '\0') {
            pIVar11 = theInstance();
            lVar13 = plVar18[2];
            uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TASK_DAYTIME_RESET");
            (**(code **)(lVar13 + 0x358))(plVar18 + 2,uVar12);
          }
        }
        lVar13 = FUN_140008520((int)plVar16[0x50]);
        lVar13 = *(longlong *)(lVar13 + 0x1f8);
        if (lVar13 == 0) {
          local_9c8 = 0x163;
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr");
        }
        (**(code **)(*plVar18 + 8))(plVar18);
        lVar13 = FUN_140261430(lVar13);
        if (lVar13 != 0) {
          FUN_140428a50(lVar13);
        }
        FUN_140384200(plVar18);
      }
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar14 + 0x29) == '\0') {
        plVar18 = (longlong *)plVar14[2];
        if (*(char *)((longlong)plVar18 + 0x29) == '\0') {
          cVar3 = *(char *)(*plVar18 + 0x29);
          plVar14 = plVar18;
          plVar18 = (longlong *)*plVar18;
          while (cVar3 == '\0') {
            cVar3 = *(char *)(*plVar18 + 0x29);
            plVar14 = plVar18;
            plVar18 = (longlong *)*plVar18;
          }
        }
        else {
          cVar3 = *(char *)(plVar14[1] + 0x29);
          plVar1 = (longlong *)plVar14[1];
          plVar18 = plVar14;
          while ((plVar14 = plVar1, cVar3 == '\0' && (plVar18 == (longlong *)plVar14[2]))) {
            cVar3 = *(char *)(plVar14[1] + 0x29);
            plVar1 = (longlong *)plVar14[1];
            plVar18 = plVar14;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    lVar13 = FUN_140008520((int)plVar16[0x50]);
    lVar13 = *(longlong *)(lVar13 + 0x1f8);
    if (lVar13 == 0) {
      local_9c8 = 0x163;
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      lVar13 = 0;
    }
    FUN_14025f390(lVar13);
    plVar14 = (longlong *)InstanceGet();
    local_8a8 = '\0';
    memset(local_8a7,0,0x3ff);
    _snprintf(&local_8a8,0x3ff,"DELETE FROM cq_statistic_daily");
    local_4a9 = 0;
    cVar3 = (**(code **)(*plVar14 + 0x30))(plVar14,&local_8a8,1,0);
    if (cVar3 == '\0') {
      log_InlineLogERROR("CUserManager::OnTimer ExecuteSQL(%s) failed.",&local_8a8);
    }
    FUN_14044f0b0();
    uVar15 = _time64((__time64_t *)0x0);
    uVar12 = FUN_140008520((int)plVar16[0x50]);
    uVar4 = FUN_14008b420(uVar12);
    cVar3 = FUN_14044f160(local_478,uVar4,uVar15 & 0xffffffff);
    if (cVar3 != '\0') {
      plVar14 = (longlong *)FUN_140008520((int)plVar16[0x50]);
      (**(code **)(*plVar14 + 0x78))(plVar14,local_478);
    }
    FUN_14044f100(local_478);
    CTickAnalyst::~CTickAnalyst(local_8f8);
  }
  plVar14 = (longlong *)0x0;
  uVar6 = tq::TimeGet(0);
  if ((uint)((int)plVar16[0x2c] + *(int *)((longlong)plVar16 + 0x164)) <= uVar6 / 1000) {
    uVar6 = tq::TimeGet(0);
    *(uint *)((longlong)plVar16 + 0x164) = uVar6 / 1000;
    (**(code **)(*plVar16 + 0x78))();
  }
  plVar10 = *(longlong **)plVar16[0x21];
  plVar8 = (longlong *)plVar16[0x1b];
  local_988 = plVar8;
  plStack_980 = plVar10;
LAB_1402b4600:
  do {
    plVar18 = (longlong *)plVar16[0x21];
    local_938 = (longlong *)plVar16[0x1b];
    if ((plVar8 == (longlong *)0x0) || (plVar8 != local_938)) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar18) {
      return;
    }
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar18 = plVar14;
    }
    else {
      plVar18 = (longlong *)*plVar8;
    }
    if (plVar10 == (longlong *)plVar18[6]) {
      _invalid_parameter_noinfo();
    }
    uVar6 = tq::TimeGet(0);
    if ((uint)(*(int *)((longlong)plVar10 + 0x24) + (int)plVar10[4]) <= uVar6 / 1000) {
      local_960 = operator_new(8);
      local_928[0] = plVar14;
      if (local_960 != (longlong *)0x0) {
        *local_960 = (longlong)local_928;
        local_928[0] = local_960;
      }
      local_910 = (void *)0x0;
      local_908 = 0;
      local_900 = 0;
      local_958 = local_960;
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar18 = plVar14;
      }
      else {
        plVar18 = (longlong *)*plVar8;
      }
      if (plVar10 == (longlong *)plVar18[6]) {
        _invalid_parameter_noinfo();
      }
      FUN_140037fe0(local_928,plVar10 + 5);
      local_960 = local_8d8;
      uVar12 = FUN_140043260(local_8d8,local_928);
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar18 = plVar14;
      }
      else {
        plVar18 = (longlong *)*plVar8;
      }
      if (plVar10 == (longlong *)plVar18[6]) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar18 = plVar14;
      }
      else {
        plVar18 = (longlong *)*plVar8;
      }
      if (plVar10 == (longlong *)plVar18[6]) {
        _invalid_parameter_noinfo();
      }
      local_9c0 = CONCAT31(local_9c0._1_3_,*(undefined1 *)((longlong)plVar10 + 0x2d));
      local_9c8 = CONCAT31(local_9c8._1_3_,1);
      FUN_1402b3560(plVar16,uVar12,0xb,*(undefined1 *)((longlong)plVar10 + 0x2c));
      plVar1 = plStack_980;
      plVar18 = local_988;
      if (plVar8 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
        plVar17 = plVar10;
        plVar2 = (longlong *)plVar10[2];
        if (*(char *)(plVar10[2] + 0x31) == '\0') {
          do {
            plVar10 = plVar2;
            plVar2 = (longlong *)*plVar10;
            plStack_980 = plVar10;
            local_950 = plVar10;
          } while (*(char *)(*plVar10 + 0x31) == '\0');
        }
        else {
          do {
            plVar10 = (longlong *)plVar17[1];
            plStack_980 = plVar10;
            if (*(char *)((longlong)plVar10 + 0x31) != '\0') break;
            bVar21 = plVar17 == (longlong *)plVar10[2];
            plVar17 = plVar10;
          } while (bVar21);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_978 = plVar18;
      plStack_970 = plVar1;
      FUN_1402acd70(plVar16 + 0x1b,local_8f8,&local_978);
      if (local_910 != (void *)0x0) {
        operator_delete(local_910);
      }
      local_910 = (void *)0x0;
      local_908 = 0;
      local_900 = 0;
      operator_delete(local_928[0]);
      goto LAB_1402b4600;
    }
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar10 + 0x31) == '\0') {
      plVar18 = plVar10;
      plVar1 = (longlong *)plVar10[2];
      if (*(char *)(plVar10[2] + 0x31) == '\0') {
        do {
          plVar10 = plVar1;
          plVar1 = (longlong *)*plVar10;
          plStack_980 = plVar10;
          local_948 = plVar10;
        } while (*(char *)(*plVar10 + 0x31) == '\0');
      }
      else {
        do {
          plVar10 = (longlong *)plVar18[1];
          plStack_980 = plVar10;
          if (*(char *)((longlong)plVar10 + 0x31) != '\0') break;
          bVar21 = plVar18 == (longlong *)plVar10[2];
          plVar18 = plVar10;
        } while (bVar21);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CUserManager::vfunc_12  @1402b48f0  [high:rtti-vtable]  (orig: FUN_1402b48f0)
void FUN_1402b48f0(longlong *param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong *plVar9;
  uint uVar10;
  longlong *plVar11;
  longlong *plVar12;
  uint in_stack_ffffffffffffff08;
  longlong *local_e8 [3];
  undefined4 *local_d0;
  undefined4 *local_c8;
  longlong local_c0;
  longlong local_b8;
  undefined8 *local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  longlong *local_98;
  longlong *local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  longlong local_60 [7];
  
  local_68 = 0xfffffffffffffffe;
  lVar5 = FUN_140008520((int)param_1[0x50]);
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    in_stack_ffffffffffffff08 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = FUN_140008520(*(undefined4 *)(*(longlong *)(lVar5 + 0x90) + 0x280));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    in_stack_ffffffffffffff08 = 0x12f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  local_b8 = (**(code **)(**(longlong **)(lVar5 + 0x88) + 0x30))();
  local_b0 = (undefined8 *)(local_b8 + 0x10);
  local_a0 = **(undefined8 **)(local_b8 + 0x40);
  plVar12 = (longlong *)0x0;
  local_a8 = *local_b0;
  local_98 = (longlong *)0x0;
  local_90 = (longlong *)0x0;
  plVar6 = operator_new(8);
  local_e8[0] = plVar12;
  if (plVar6 != (longlong *)0x0) {
    *plVar6 = (longlong)local_e8;
    local_e8[0] = plVar6;
  }
  local_d0 = (undefined4 *)0x0;
  local_c8 = (undefined4 *)0x0;
  local_c0 = 0;
  FUN_140036640(local_e8);
  plVar6 = plVar12;
LAB_1402b4a34:
  do {
    cVar3 = FUN_1400ce310(&local_b0);
    while( true ) {
      if (cVar3 == '\0') {
        local_90 = (longlong *)0x0;
        goto LAB_1402b4cf8;
      }
      cVar3 = (**(code **)(*local_98 + 0x298))(local_98,0x1001,&local_90);
      if (cVar3 != '\0') break;
      cVar3 = FUN_1400ce310(&local_b0);
    }
    uVar10 = (int)plVar6 + 1;
    plVar6 = (longlong *)(ulonglong)uVar10;
    if (1000000 < uVar10) {
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1402b4cf8:
      if (((longlong)local_c8 - (longlong)local_d0 & 0xfffffffffffffffcU) != 0) {
        uVar8 = FUN_140043260(local_60,local_e8);
        FUN_1402b3560(param_1,uVar8,0xe,1,1,1);
      }
      if (local_d0 != (undefined4 *)0x0) {
        operator_delete(local_d0);
      }
      local_d0 = (undefined4 *)0x0;
      local_c8 = (undefined4 *)0x0;
      local_c0 = 0;
      operator_delete(local_e8[0]);
      return;
    }
    if (local_90 == (longlong *)0x0) {
      in_stack_ffffffffffffff08 = 0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    cVar3 = FUN_140167b70(local_90);
    if (cVar3 != '\0') {
      if (local_90 == (longlong *)0x0) {
        in_stack_ffffffffffffff08 = 0;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar4 = (**(code **)(*local_90 + 8))();
      puVar2 = local_c8;
      plVar9 = plVar12;
      if (local_d0 != (undefined4 *)0x0) {
        plVar9 = (longlong *)(local_c0 - (longlong)local_d0 >> 2);
      }
      if ((longlong *)((longlong)local_c8 - (longlong)local_d0 >> 2) < plVar9) {
        *local_c8 = uVar4;
        local_c8 = local_c8 + 1;
        goto LAB_1402b4a34;
      }
      if (local_c8 < local_d0) {
        _invalid_parameter_noinfo();
      }
      puVar1 = local_d0;
      plVar9 = local_e8[0];
      local_88 = local_e8[0];
      uStack_80 = puVar2;
      plVar11 = plVar12;
      if (((longlong)local_c8 - (longlong)local_d0 & 0xfffffffffffffffcU) != 0) {
        if (local_c8 < local_d0) {
          _invalid_parameter_noinfo();
        }
        if ((plVar9 == (longlong *)0x0) || (plVar9 != local_e8[0])) {
          _invalid_parameter_noinfo();
        }
        plVar11 = (longlong *)((longlong)puVar2 - (longlong)puVar1 >> 2);
      }
      local_78 = (undefined4)local_88;
      uStack_74 = local_88._4_4_;
      uStack_70 = (undefined4)uStack_80;
      uStack_6c = uStack_80._4_4_;
      FUN_140036c20(local_e8,&local_78,1);
      puVar2 = local_d0;
      if (local_c8 < local_d0) {
        _invalid_parameter_noinfo();
      }
      plVar9 = local_e8[0];
      if (local_e8[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar7 = plVar12;
      }
      else {
        plVar7 = (longlong *)*local_e8[0];
      }
      if (puVar2 + (longlong)plVar11 <= (undefined4 *)plVar7[4]) {
        plVar7 = plVar12;
        if (plVar9 != (longlong *)0x0) {
          plVar7 = (longlong *)*plVar9;
        }
        if ((undefined4 *)plVar7[3] <= puVar2 + (longlong)plVar11) goto LAB_1402b4a34;
      }
      _invalid_parameter_noinfo();
      goto LAB_1402b4a34;
    }
    if (local_90 == (longlong *)0x0) {
      in_stack_ffffffffffffff08 = 0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    in_stack_ffffffffffffff08 = in_stack_ffffffffffffff08 & 0xffffff00;
    (**(code **)(*param_1 + 0x40))
              (param_1,*(undefined4 *)((longlong)local_90 + 0x122c),0,0,in_stack_ffffffffffffff08,1)
    ;
  } while( true );
}

// ==== CUserManager::helper_1402c3670  @1402c3670  [medium:callgraph-r2]  (orig: FUN_1402c3670)
void FUN_1402c3670(longlong param_1,char *param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar1;
  
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x40;
  if (*(longlong *)(param_1 + 0x50) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar1 = 0;
    }
    else {
      uVar1 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x50) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402c36d1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::assign
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x50),
             param_2);
  return;
}

// ==== CUserManager::helper_1402c3770  @1402c3770  [medium:callgraph-r1]  (orig: FUN_1402c3770)
undefined8 FUN_1402c3770(longlong param_1)

{
  undefined4 uVar1;
  
  FUN_1402b5600();
  (**(code **)(*(longlong *)(param_1 + 0x428) + 0x18))(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9c4;
  uVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = uVar1;
  return 1;
}

// ==== CUserManager::helper_1402c37c0  @1402c37c0  [medium:callgraph-r1]  (orig: FUN_1402c37c0)
undefined8 FUN_1402c37c0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  cVar1 = FUN_1405551c0(param_1 + 0x428,param_1 + 0x10,0x400,param_4,0xfffffffffffffffe);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x20))(param_1 + 0x428);
    if (cVar1 == '\0') {
      lVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x28))(param_1 + 0x428,local_30);
      if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
        lVar3 = lVar3 + 8;
      }
      else {
        lVar3 = *(longlong *)(lVar3 + 8);
      }
      log_InlineLogERROR(&DAT_140744000,lVar3);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
    }
    else {
      log_InlineLogERROR("CMsgSameGroupServerList::CreateBufMsg SerializeToArray failed.");
    }
    uVar4 = 0;
  }
  else {
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CUserManager::helper_1402c3930  @1402c3930  [medium:callgraph-r2]  (orig: FUN_1402c3930)
undefined8 FUN_1402c3930(longlong *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  void *pvVar2;
  undefined8 uVar3;
  
  iVar1 = (int)param_1[1];
  if (iVar1 < *(int *)((longlong)param_1 + 0xc)) {
    uVar3 = *(undefined8 *)(*param_1 + (longlong)iVar1 * 8);
    *(int *)(param_1 + 1) = iVar1 + 1;
  }
  else {
    if (*(int *)((longlong)param_1 + 0xc) == (int)param_1[2]) {
      FUN_140555c70(param_1,(int)param_1[2] + 1,param_3,param_4,0xfffffffffffffffe);
    }
    pvVar2 = operator_new(0x58);
    if (pvVar2 == (void *)0x0) {
      uVar3 = 0;
    }
    else {
      uVar3 = FUN_140574e10(pvVar2);
    }
    *(int *)((longlong)param_1 + 0xc) = *(int *)((longlong)param_1 + 0xc) + 1;
    *(undefined8 *)(*param_1 + (longlong)(int)param_1[1] * 8) = uVar3;
    *(int *)(param_1 + 1) = (int)param_1[1] + 1;
  }
  return uVar3;
}

// ==== CUserManager::helper_1402c39d0  @1402c39d0  [medium:callgraph-r1]  (orig: FUN_1402c39d0)
bool FUN_1402c39d0(longlong param_1,undefined4 param_2,longlong param_3)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  bool bVar5;
  
  iVar2 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
  bVar5 = (longlong)iVar2 + 0x38U < 0x400;
  if (bVar5) {
    lVar4 = FUN_1402c3930(param_1 + 0x460);
    *(uint *)(lVar4 + 0x30) = *(uint *)(lVar4 + 0x30) | 1;
    *(undefined4 *)(lVar4 + 0x38) = param_2;
    FUN_1402c3670(lVar4,param_3);
    uVar3 = *(undefined4 *)(param_3 + 0x18);
    *(uint *)(lVar4 + 0x30) = *(uint *)(lVar4 + 0x30) | 4;
    uVar1 = *(uint *)(lVar4 + 0x30);
    *(undefined4 *)(lVar4 + 0x40) = uVar3;
    uVar3 = *(undefined4 *)(param_3 + 0x1c);
    *(uint *)(lVar4 + 0x30) = uVar1 | 8;
    *(undefined4 *)(lVar4 + 0x44) = uVar3;
    *(undefined4 *)(lVar4 + 0x48) = *(undefined4 *)(param_3 + 0x20);
    *(uint *)(lVar4 + 0x30) = uVar1 | 0x18;
    uVar3 = *(undefined4 *)(param_3 + 0x28);
    *(uint *)(lVar4 + 0x30) = uVar1 | 0x1a;
    *(undefined4 *)(lVar4 + 0x3c) = uVar3;
    *(undefined4 *)(lVar4 + 0x4c) = *(undefined4 *)(param_3 + 0x10);
    *(uint *)(lVar4 + 0x30) = uVar1 | 0x3a;
    uVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
    *(undefined4 *)(param_1 + 0xc) = uVar3;
  }
  return bVar5;
}

// ==== CUserManager::helper_1402c6f50  @1402c6f50  [medium:callgraph-r1]  (orig: FUN_1402c6f50)
ulonglong FUN_1402c6f50(longlong *param_1,int *param_2,undefined8 *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ulonglong extraout_RAX;
  longlong lVar4;
  longlong *plVar5;
  ulonglong extraout_RAX_00;
  ulonglong uVar6;
  ulonglong extraout_RAX_01;
  
  iVar1 = (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0xd);
  (**(code **)(*(longlong *)param_1[0xb] + 0x10))((longlong *)param_1[0xb],0xe);
  if (iVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar4 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
  if (*(longlong *)(lVar4 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x98) + 0xb0))();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5,iVar1);
  if (plVar5 == (longlong *)0x0) {
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogDBERROR(&DAT_1407446d0);
    uVar6 = extraout_RAX_00 & 0xffffffffffffff00;
  }
  else {
    iVar2 = (**(code **)(*plVar5 + 0x10))(plVar5,0xb);
    iVar3 = (**(code **)(*plVar5 + 0x10))(plVar5,0xc);
    if ((iVar2 == 0) && (iVar3 == 0)) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = extraout_RAX_01 & 0xffffffffffffff00;
    }
    else {
      *param_2 = iVar1;
      *param_3 = CONCAT44(iVar3,iVar2);
      uVar6 = CONCAT71((int7)(CONCAT44(iVar3,iVar2) >> 8),1);
    }
  }
  return uVar6;
}

// ==== CUserManager::helper_1402e2970  @1402e2970  [medium:callgraph-r1]  (orig: FUN_1402e2970)
void FUN_1402e2970(longlong param_1,longlong param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  undefined8 uVar6;
  
  if (param_2 != 0) {
    iVar1 = FUN_140165970(param_2);
    iVar1 = tq::DateStamp((longlong)iVar1);
    iVar2 = tq::DateStamp(0);
    if (iVar1 != iVar2) {
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
      uVar3 = FUN_14008aea0(uVar6);
      uVar4 = FUN_140166bf0(param_2);
      if (uVar4 < uVar3) {
        uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
        iVar5 = FUN_14008aeb0(uVar6);
        iVar1 = tq::DateStampDiff(iVar1,iVar2);
        if (0 < iVar1) {
          if (2 < iVar1) {
            iVar1 = 3;
          }
          iVar2 = FUN_140166bf0(param_2);
          uVar4 = iVar2 + iVar1 * iVar5;
          if (uVar4 < uVar3) {
            FUN_140166c00(param_2,uVar4,0);
          }
          else {
            FUN_140166c00(param_2,uVar3,0);
          }
        }
      }
    }
  }
  return;
}

// ==== CUserManager::helper_1402e64b0  @1402e64b0  [medium:callgraph-r0]  (orig: FUN_1402e64b0)
void FUN_1402e64b0(longlong param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  int local_40 [2];
  longlong local_38;
  undefined1 local_30 [24];
  
  if (((param_2 != (longlong *)0x0) && (*(longlong *)(param_1 + 0x98) != 0)) &&
     (iVar2 = (**(code **)(*param_2 + 8))(param_2), iVar2 != 0)) {
    FUN_1402e2970(param_1,param_2);
    lVar3 = FUN_140478740(*(undefined4 *)(param_1 + 0x88),param_2,*(undefined8 *)(param_1 + 0x98));
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar1 = FUN_140479610(lVar3);
      if (cVar1 == '\0') {
        FUN_1404795e0(lVar3);
      }
      else {
        local_40[0] = iVar2;
        local_38 = lVar3;
        FUN_1402e5330(param_1 + 8,local_30,local_40);
        lVar4 = FUN_14047dc70(*(undefined4 *)(param_1 + 0x88),iVar2);
        if (lVar4 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          cVar1 = FUN_14047c860(lVar4);
          if (cVar1 == '\0') {
            FUN_14047c830(lVar4);
          }
          else {
            FUN_14047c540(lVar4,param_2);
            local_40[0] = iVar2;
            local_38 = lVar4;
            FUN_1402e5970(param_1 + 0x48,local_30,local_40);
          }
          FUN_140478d30(lVar3,1,param_2,param_2);
        }
      }
    }
  }
  return;
}

// ==== CUserManager::helper_1402e9b00  @1402e9b00  [medium:callgraph-r0]  (orig: FUN_1402e9b00)
void FUN_1402e9b00(void)

{
  return;
}

// ==== CUserManager::helper_140313960  @140313960  [medium:callgraph-r3]  (orig: FUN_140313960)
bool FUN_140313960(longlong param_1,uint param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  undefined8 *local_20;
  
  puVar2 = *(undefined8 **)(param_1 + 0x118);
  lVar3 = *(longlong *)(param_1 + 0xe8);
  cVar1 = *(char *)((longlong)puVar2[1] + 0x1d);
  puVar4 = puVar2;
  puVar7 = (undefined8 *)puVar2[1];
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x1d);
  }
  local_40 = puVar4;
  local_48 = lVar3;
  if (lVar3 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar2) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x118);
    local_38 = *(longlong *)(param_1 + 0xe8);
  }
  else {
    plVar6 = &local_48;
  }
  local_28 = *plVar6;
  local_20 = (undefined8 *)plVar6[1];
  if ((local_28 == 0) || (local_28 != lVar3)) {
    _invalid_parameter_noinfo();
  }
  return local_20 != puVar2;
}

// ==== CUserManager::helper_140313a50  @140313a50  [medium:callgraph-r3]  (orig: FUN_140313a50)
void FUN_140313a50(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0xe8,local_28,local_res10);
  return;
}

// ==== CUserManager::helper_140314350  @140314350  [medium:callgraph-r3]  (orig: FUN_140314350)
BADSPACEBASE *
FUN_140314350(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4)

{
  longlong *plVar1;
  longlong lVar2;
  longlong local_res20;
  undefined4 local_48;
  undefined4 uStack_44;
  CMySingleLock local_40 [8];
  undefined8 local_38;
  longlong *local_30;
  longlong local_28;
  undefined1 local_20 [24];
  
  local_38 = 0xfffffffffffffffe;
  if (param_4 != 0) {
    local_res20 = param_4;
    tq::CMySingleLock::CMySingleLock(local_40,(ILockObj *)(param_1 + 0x78));
    plVar1 = (longlong *)(param_1 + 0xa8);
    local_48 = param_2;
    uStack_44 = param_3;
    FUN_140313370(plVar1,&local_30,&local_48);
    lVar2 = *(longlong *)(param_1 + 0xd8);
    if ((local_30 == (longlong *)0x0) || (local_30 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (local_28 == lVar2) {
      local_30 = operator_new(0x30);
      if (local_30 == (longlong *)0x0) {
        local_28 = 0;
      }
      else {
        local_28 = FUN_140016910(local_30);
      }
      if (local_28 == 0) {
        log_InlineLogDB(" new db::REC_VEC error ,mem out");
        tq::CMySingleLock::~CMySingleLock(local_40);
        register0x00000020 = (BADSPACEBASE *)0x0;
      }
      else {
        FUN_140019370(local_28,&local_res20);
        local_30 = (longlong *)CONCAT44(uStack_44,local_48);
        FUN_140312df0(plVar1,local_20,&local_30);
        tq::CMySingleLock::~CMySingleLock(local_40);
        register0x00000020 = (BADSPACEBASE *)0x1;
      }
    }
    else {
      if (local_30 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = 0;
      }
      else {
        lVar2 = *local_30;
      }
      if (local_28 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(local_28 + 0x20) != 0) {
        FUN_140019370(*(longlong *)(local_28 + 0x20),&local_res20);
      }
      tq::CMySingleLock::~CMySingleLock(local_40);
      register0x00000020 = (BADSPACEBASE *)0x1;
    }
  }
  return register0x00000020;
}

// ==== CUserManager::helper_140314eb0  @140314eb0  [medium:callgraph-r2]  (orig: FUN_140314eb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140314eb0(undefined8 param_1,undefined4 param_2,undefined4 param_3,longlong param_4)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 ***pppuVar5;
  ulonglong uVar6;
  undefined1 auStack_a8 [32];
  undefined4 local_88;
  undefined8 local_78;
  undefined **local_70;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [8];
  undefined8 **local_60 [3];
  ulonglong local_48;
  ulonglong local_40;
  
  local_78 = 0xfffffffffffffffe;
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  if (param_4 == 0) {
    log_InlineLogERROR("CDBDataPrepare::LoadRecordSetByAccountId DBLoad error , pszSQL == NULL.");
    uVar1 = 0;
  }
  else {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
    local_70 = tq::CString::vftable;
    FUN_140311d10(&local_70,param_4,param_2);
    plVar2 = (longlong *)InstanceGet();
    pppuVar5 = local_60;
    if (0xf < local_48) {
      pppuVar5 = (undefined8 ***)local_60[0];
    }
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,pppuVar5,2);
    if (plVar2 == (longlong *)0x0) {
      pppuVar5 = local_60;
      if (0xf < local_48) {
        pppuVar5 = (undefined8 ***)local_60[0];
      }
      log_InlineLogERROR("CDBDataPrepare::LoadRecordSetByAccountId DBLoad pszSQL[%s] pRes == NULL.",
                         pppuVar5);
      local_70 = tq::CString::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
      uVar1 = 0;
    }
    else {
      lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
      if (lVar3 == 0) {
        (**(code **)*plVar2)(plVar2);
        local_70 = tq::CString::vftable;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar1 = 1;
      }
      else {
        (**(code **)(*plVar2 + 0x30))(plVar2,0);
        uVar6 = 0;
        lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
        if (lVar3 != 0) {
          do {
            (**(code **)(*plVar2 + 0x30))(plVar2,uVar6);
            lVar3 = (**(code **)(*plVar2 + 0x38))(plVar2);
            if (lVar3 == 0) {
              local_88 = 0xce;
              log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",&DAT_1406e5370,
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\dbdataprepare.cpp"
                                );
            }
            else {
              FUN_140314350(param_1,param_2,param_3,lVar3);
            }
            uVar6 = (ulonglong)((int)uVar6 + 1);
            uVar4 = (**(code **)(*plVar2 + 0x40))(plVar2);
          } while (uVar6 < uVar4);
        }
        (**(code **)*plVar2)(plVar2);
        local_70 = tq::CString::vftable;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_68);
        uVar1 = 1;
      }
    }
  }
  return uVar1;
}

// ==== CUserManager::helper_14031c3f0  @14031c3f0  [medium:callgraph-r2]  (orig: FUN_14031c3f0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_14031c3f0(longlong param_1,uint param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined4 local_res18 [4];
  
  local_res18[0] = param_3;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_3)
  ;
  if (plVar3 != (longlong *)0x0) {
    if (*(uint *)(plVar3 + 0x248) != param_2) {
      uVar4 = (**(code **)(*plVar3 + 8))(plVar3);
      tq::MyLogSave("gmlog/texasholdemwitness",
                    "CTexasWittnessMgr::DelWitness. User[%u] DelWitness CurTable[%u] UserTable[%u] Error"
                    ,uVar4 & 0xffffffff,(ulonglong)param_2);
    }
    lVar2 = FUN_14031bf40(param_1,param_2);
    if (lVar2 != 0) {
      cVar1 = FUN_1404bf940(lVar2,param_3);
      if (cVar1 != '\0') {
        FUN_140050de0(param_1 + 8,local_res18);
        return 1;
      }
      uVar4 = (**(code **)(*plVar3 + 8))(plVar3);
      tq::MyLogSave("gmlog/texasholdemwitness",
                    "CTexasWittnessMgr::DelWitness. User[%u] DelWitness CurTable[%u] UserTable[%u] not found user"
                    ,uVar4 & 0xffffffff,(ulonglong)param_2);
    }
  }
  return 0;
}

// ==== CUserManager::helper_140329ee0  @140329ee0  [medium:callgraph-r2]  (orig: FUN_140329ee0)
undefined1 FUN_140329ee0(longlong param_1,longlong param_2)

{
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(longlong *)(param_1 + 0x10) = param_2;
  return 1;
}

// ==== CUserManager::helper_14032a550  @14032a550  [medium:callgraph-r3]  (orig: FUN_14032a550)
void FUN_14032a550(longlong param_1)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),6);
                    /* WARNING: Could not recover jumptable at 0x00014032a5a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xb0))(plVar1,1);
  return;
}

// ==== CUserManager::helper_14035b930  @14035b930  [medium:callgraph-r2]  (orig: FUN_14035b930)
ulonglong FUN_14035b930(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                       undefined4 param_5)

{
  short *psVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (longlong)*(int *)(param_1 + 0xc) + 0xe;
    if (uVar3 < 0x400) {
      if (*(short *)(lVar2 + 2) != 0) {
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0xe;
      }
      *(undefined4 *)((ulonglong)*(ushort *)(lVar2 + 2) * 0xe + 4 + lVar2) = param_2;
      *(undefined2 *)
       ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0xe + 8 +
       *(longlong *)(param_1 + 0x428)) = param_3;
      *(undefined4 *)
       ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0xe + 10 +
       *(longlong *)(param_1 + 0x428)) = param_4;
      *(undefined4 *)
       (((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) + 1) * 0xe +
       *(longlong *)(param_1 + 0x428)) = param_5;
      lVar2 = *(longlong *)(param_1 + 0x428);
      psVar1 = (short *)(lVar2 + 2);
      *psVar1 = *psVar1 + 1;
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CUserManager::helper_140371500  @140371500  [medium:callgraph-r3]  (orig: FUN_140371500)
undefined8 FUN_140371500(longlong param_1)

{
  int local_18 [6];
  
  if (*(int *)(param_1 + 300) != 0) {
    local_18[0] = 0x1c32094;
    local_18[1] = 0x2f93c2;
    local_18[2] = 0x9234d5;
    if (*(uint *)(param_1 + 0x130) !=
        (local_18[*(uint *)(param_1 + 300) % 3] +
         (*(uint *)(param_1 + 0x1bc) & *(uint *)(param_1 + 0x98)) + *(uint *)(param_1 + 0x98) ^
        *(uint *)(param_1 + 300))) {
      return 0;
    }
  }
  return 1;
}

// ==== CUserManager::helper_140371ac0  @140371ac0  [medium:callgraph-r1]  (orig: FUN_140371ac0)
undefined2 FUN_140371ac0(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x172);
}

// ==== CUserManager::helper_140371ad0  @140371ad0  [medium:callgraph-r2]  (orig: FUN_140371ad0)
void FUN_140371ad0(longlong param_1,undefined2 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined2 *)(param_1 + 0x172) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"mentor_day");
    (**(code **)(*plVar1 + 200))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CUserManager::helper_140371b40  @140371b40  [medium:callgraph-r0]  (orig: FUN_140371b40)
void FUN_140371b40(longlong param_1,undefined8 param_2,int param_3)

{
  longlong *plVar1;
  
  *(undefined8 *)(param_1 + 0x58) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,&DAT_14070eeb8);
    (**(code **)(*plVar1 + 0xa0))(plVar1,param_2);
    if (param_3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CUserManager::helper_140371cf0  @140371cf0  [medium:callgraph-r1]  (orig: FUN_140371cf0)
void FUN_140371cf0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  iVar1 = tq::DateStamp(0);
  plVar2 = *(longlong **)(param_1 + 0x230);
  *(int *)(param_1 + 0xa0) = iVar1;
  if (plVar2 != (longlong *)0x0) {
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,"last_login");
    (**(code **)(*plVar2 + 0xb8))(plVar2,*(undefined4 *)(param_1 + 0xa0));
  }
  return;
}

// ==== CUserManager::helper_140371d50  @140371d50  [medium:callgraph-r1]  (orig: FUN_140371d50)
void FUN_140371d50(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  if (*(int *)(param_1 + 0xa4) == 0) {
    iVar1 = tq::DateStamp(0);
    plVar2 = *(longlong **)(param_1 + 0x230);
    *(int *)(param_1 + 0xa4) = iVar1;
    if (plVar2 != (longlong *)0x0) {
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,"first_login");
      (**(code **)(*plVar2 + 0xb8))(plVar2,*(undefined4 *)(param_1 + 0xa4));
    }
  }
  return;
}

// ==== CUserManager::helper_140371e80  @140371e80  [medium:callgraph-r2]  (orig: FUN_140371e80)
undefined1 FUN_140371e80(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x88);
}

// ==== CUserManager::helper_1403744b0  @1403744b0  [medium:callgraph-r2]  (orig: FUN_1403744b0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1403744b0(longlong param_1)

{
  undefined1 uVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  undefined8 uVar7;
  IStringManager *pIVar8;
  char *pcVar9;
  longlong lVar10;
  
  plVar6 = *(longlong **)(param_1 + 0x230);
  if (plVar6 == (longlong *)0x0) {
    return 0;
  }
  if (*(int *)(param_1 + 8) != 0) {
    return 1;
  }
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,&DAT_14070dc20);
  uVar3 = (**(code **)(*plVar6 + 0x28))(plVar6);
  *(undefined2 *)(param_1 + 0x7c) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"coin_money");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x50) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"last_login");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xa0) = uVar4;
  *(undefined4 *)(param_1 + 0xa8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"first_login");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xa4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"lookface");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x34) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14075a3e4);
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x38) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"medal");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x80) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"medal_select");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x84) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"money");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x40) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"money_saved");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x48) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"recordx");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x94) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"recordy");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x96) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_1406de8d4);
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"account_id");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x98) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_1406f3818);
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x9c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"recordmap_id");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x8c) = 0;
  *(undefined4 *)(param_1 + 0x90) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14075a9f4);
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x78) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14070eeb8);
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x58) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"level");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x54) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"task_mask");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xac) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"virtue");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xb0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"home_id");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xb4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"lock_key");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xb8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"lock_cls");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xbc) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"lock_key");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x120) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mateid");
  iVar5 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(int *)(param_1 + 0x30) = iVar5;
  if (iVar5 == 0) {
    pIVar8 = theInstance();
    pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar8)(pIVar8,"NOMATE_NAME");
    tq::StrCopy((char *)(param_1 + 0x1f0),pcVar9,0x10);
  }
  else {
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                       (*(longlong **)(param_1 + 0x230),"mate_name");
    pcVar9 = (char *)(**(code **)(*plVar6 + 0x78))(plVar6);
    tq::StrCopy((char *)(param_1 + 0x1f0),pcVar9,0x10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_1406ef6e0);
  pcVar9 = (char *)(**(code **)(*plVar6 + 0x78))(plVar6);
  tq::StrCopy((char *)(param_1 + 0x10),pcVar9,0x10);
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"lastname");
  pcVar9 = (char *)(**(code **)(*plVar6 + 0x78))(plVar6);
  tq::StrCopy((char *)(param_1 + 0x20),pcVar9,0x10);
  if (DAT_140975c00 != '\0') {
    lVar10 = -1;
    pcVar9 = (char *)(param_1 + 0x20);
    do {
      if (lVar10 == 0) break;
      lVar10 = lVar10 + -1;
      cVar2 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar2 != '\0');
    if (lVar10 != -2) {
      _snprintf((char *)(param_1 + 0x238),0x24,"%s.%s",param_1 + 0x10);
      *(undefined1 *)(param_1 + 0x25b) = 0;
    }
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"additional_point");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x6a) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"auto_allot");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x6c) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"strength");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x60) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"health");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x66) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14070ef58);
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x70) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14070ef10);
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x74) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"metempsychosis");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x88) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"nobility");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x7e) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"profession");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x76) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"first_prof");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x62) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"old_prof");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 99) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_14070eddc);
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x68) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"speed");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 100) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"emoney");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 300) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"chk_sum");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x130) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"god_status");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xc0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"exp_ball_usage");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xc4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),&DAT_1406de8cc);
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0xcc) = uVar4;
  uVar7 = FUN_140008520(0xe);
  cVar2 = FUN_14008abd0(uVar7);
  if (cVar2 != '\0') {
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                       (*(longlong **)(param_1 + 0x230),"vip_value");
    uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
    *(undefined4 *)(param_1 + 0xd0) = uVar4;
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"online_time");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x134) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"auto_exercise");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x138) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"last_logout");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x13c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"big_prize_fails");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x140) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"small_prize_fails");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x142) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mete_lev");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x144) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"current_layout_type");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x148) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"online_time2");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x14c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"offline_time");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x150) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"last_logout2");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x154) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"donation");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x158) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"send_flower_date");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0xd4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"flower_r");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xd8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"flower_w");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xdc) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"flower_lily");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xe0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"flower_tulip");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0xe4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"quiz_point");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 200) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"business");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x160) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"online_god_exptime");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x164) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"battle_god_exptime");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x168) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mentor_opportunity");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x16c) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mentor_uplev_time");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x16e) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mentor_achieve");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x170) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mentor_day");
  uVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined2 *)(param_1 + 0x172) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_point");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x174) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_history_wins");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x17c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_history_loses");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x180) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_day_wins");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x184) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_day_loses");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x188) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_cur_honor_point");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 400) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"athlete_hisorty_honor_point");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x194) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"last_logout_3");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x1b0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"family_arenic");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x1ac) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"team_athlete_point");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x198) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"team_athlete_win");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x19c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"team_athlete_lost");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x1a0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"team_athlete_season_win");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x1a4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"team_athlete_season_lost");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x1a8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"title");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x1b4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"title_select");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x1b8) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"emoney_mono");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x1bc) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"ridepet_point");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x1c0) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"current_ast_prof");
  uVar1 = (**(code **)(*plVar6 + 0x20))(plVar6);
  *(undefined1 *)(param_1 + 0x1c4) = uVar1;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"ast_prof_rank");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x1c8) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"cultivation");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x1d0) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"mete_lev2");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x1d8) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"changenamerecord");
  uVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined4 *)(param_1 + 0x1dc) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"pkprotocol");
  uVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
  *(undefined2 *)(param_1 + 0x1e0) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"showtype");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x1e2) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"strength_value");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x1e4) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"culture_value");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x200) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"chestpackage_size");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x204) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"nationality");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x1e8) = uVar3;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"pk_setting");
  uVar4 = (**(code **)(*plVar6 + 0x40))(plVar6);
  *(undefined4 *)(param_1 + 0x1ec) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"texasmatch_win");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x208) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"texasmatch_lose");
  uVar7 = (**(code **)(*plVar6 + 0x58))(plVar6);
  *(undefined8 *)(param_1 + 0x210) = uVar7;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"league_contribution");
  uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
  *(undefined4 *)(param_1 + 0x218) = uVar4;
  plVar6 = (longlong *)FUN_140087ed0();
  uVar4 = (**(code **)(*plVar6 + 0x630))(plVar6,*(undefined4 *)(param_1 + 0x218));
  *(undefined4 *)(param_1 + 0x21c) = uVar4;
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x230) + 0x20))
                     (*(longlong **)(param_1 + 0x230),"shielded_times");
  uVar3 = (**(code **)(*plVar6 + 0x30))(plVar6);
  *(undefined2 *)(param_1 + 0x228) = uVar3;
  cVar2 = FUN_140371500(param_1);
  if (cVar2 == '\0') {
    log_InlineLogERROR("user[%s][%u] emoney chksum error!",param_1 + 0x10,
                       *(undefined4 *)(param_1 + 8));
    tq::MyLogSave("gmlog/emoney","user[%s][%u] emoney chksum error!",param_1 + 0x10,
                  *(undefined4 *)(param_1 + 8));
    return 0;
  }
  return 1;
}

// ==== CUserManager::helper_1403756b0  @1403756b0  [medium:callgraph-r1]  (orig: FUN_1403756b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403756b0(longlong param_1,undefined4 param_2,longlong *param_3)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  undefined1 auStack_478 [32];
  undefined4 local_458;
  undefined4 local_448;
  longlong *local_440;
  longlong local_438;
  undefined8 local_430;
  char local_428;
  undefined1 local_427 [1023];
  ulonglong local_28;
  
  local_430 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_448 = param_2;
  local_438 = param_1;
  if (*(longlong *)(param_1 + 0x230) == 0) {
    if (param_3 == (longlong *)0x0) {
      local_458 = 0x25;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = extraout_RAX_00 & 0xffffffffffffff00;
    }
    else {
      local_428 = '\0';
      memset(local_427,0,0x3ff);
      _snprintf(&local_428,0x3ff,
                "SELECT cq_user.*, b.name AS mate_name FROM cq_user LEFT JOIN cq_user as b ON cq_user.mateid = b.id WHERE cq_user.id = %u LIMIT 1"
               );
      plVar1 = (longlong *)(**(code **)(*param_3 + 0x10))(param_3,&local_428,2);
      uVar2 = 0;
      local_440 = plVar1;
      if (((plVar1 == (longlong *)0x0) ||
          (uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1), uVar2 == 0)) &&
         (plVar1 != (longlong *)0x0)) {
        uVar2 = (**(code **)*plVar1)(plVar1);
        plVar1 = (longlong *)0x0;
        local_440 = (longlong *)0x0;
      }
      if (plVar1 == (longlong *)0x0) {
        uVar2 = uVar2 & 0xffffffffffffff00;
      }
      else {
        uVar3 = (**(code **)(*plVar1 + 0x38))(plVar1);
        *(undefined8 *)(param_1 + 0x230) = uVar3;
        (**(code **)*plVar1)(plVar1);
        uVar2 = FUN_1403744b0(param_1);
      }
    }
  }
  else {
    local_458 = 0x24;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  return uVar2;
}

// ==== CUserManager::helper_1403768c0  @1403768c0  [medium:callgraph-r1]  (orig: FUN_1403768c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403768c0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  int iVar6;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  FUN_1403778c0(local_448);
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
  plVar5 = *(longlong **)(param_1 + 0x10);
  uVar2 = (**(code **)(*plVar4 + 0x40))(plVar4);
  uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
  cVar1 = FUN_1403779f0(local_448,0,uVar3,uVar2);
  if (cVar1 == '\0') {
    local_468 = 0x102;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140377910(local_448);
  }
  else {
    iVar6 = 3;
    do {
      plVar5 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),iVar6)
      ;
      uVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
      cVar1 = FUN_140377a70(local_448,uVar2);
      if (cVar1 == '\0') {
        local_468 = 0x106;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_140377910(local_448);
        return;
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < 0xf);
    plVar5 = (longlong *)(*(longlong *)(param_1 + 0x10) + 0x10);
    (**(code **)(*plVar5 + 0x350))(plVar5,local_448);
    FUN_140377910(local_448);
  }
  return;
}

// ==== CUserManager::helper_140376fc0  @140376fc0  [medium:callgraph-r2]  (orig: FUN_140376fc0)
void FUN_140376fc0(__uint64 param_1)

{
  if ((DAT_140976160 & 1) == 0) {
    DAT_140976160 = DAT_140976160 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976158,"CAchInfo");
    atexit((_func_5014 *)&LAB_1406d6b30);
  }
                    /* WARNING: Could not recover jumptable at 0x000140377015. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976158,param_1);
  return;
}

// ==== CUserManager::helper_140377160  @140377160  [medium:callgraph-r1]  (orig: FUN_140377160)
ulonglong FUN_140377160(longlong param_1,longlong param_2,longlong param_3,longlong *param_4)

{
  longlong lVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  ulong uVar5;
  ulonglong in_RAX;
  longlong *plVar6;
  longlong *plVar7;
  
  if (((param_2 != 0) && (param_3 != 0)) && (param_4 != (longlong *)0x0)) {
    *(longlong *)(param_1 + 0x10) = param_2;
    *(longlong *)(param_1 + 0x28) = param_3;
    *(longlong **)(param_1 + 8) = param_4;
    plVar6 = (longlong *)(**(code **)(*param_4 + 0x10))(param_4,0);
    plVar7 = *(longlong **)(param_1 + 0x10);
    iVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
    iVar3 = (**(code **)(*plVar7 + 8))(plVar7);
    if (iVar2 != iVar3) {
      plVar7 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0);
      lVar1 = *plVar7;
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 8))();
      (**(code **)(lVar1 + 0xb8))(plVar7,uVar4);
      *(undefined1 *)(param_1 + 0x18) = 1;
    }
    *(undefined4 *)(param_1 + 0x1c) = 300;
    uVar5 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x20) = uVar5 / 1000;
    return CONCAT71((uint7)((ulonglong)uVar5 * 0x10624dd3 >> 8) & 0xffffff,1);
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CUserManager::helper_1403815a0  @1403815a0  [medium:callgraph-r1]  (orig: FUN_1403815a0)
void FUN_1403815a0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong lVar4;
  rsize_t _DstSize;
  longlong *_Dst;
  
  _Dst = *(longlong **)(param_1 + 0x20);
  if (*(longlong **)(param_1 + 0x28) < _Dst) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 8);
  do {
    plVar2 = *(longlong **)(param_1 + 0x28);
    if (plVar2 < *(longlong **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst == plVar2) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    if (*_Dst != 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = 0;
      }
      else {
        lVar4 = *plVar1;
      }
      if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
        _invalid_parameter_noinfo();
      }
      iVar3 = (**(code **)(*(longlong *)*_Dst + 8))();
      if (iVar3 == param_2) {
        lVar4 = *(longlong *)(param_1 + 0x28) - (longlong)(_Dst + 1) >> 3;
        if (0 < lVar4) {
          _DstSize = lVar4 << 3;
          memmove_s(_Dst,_DstSize,_Dst + 1,_DstSize);
        }
        *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -8;
        if ((_Dst < *(longlong **)(param_1 + 0x20)) || (*(longlong **)(param_1 + 0x28) < _Dst)) {
          _invalid_parameter_noinfo();
        }
        return;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    _Dst = _Dst + 1;
  } while( true );
}

// ==== CUserManager::helper_140382710  @140382710  [medium:callgraph-r3]  (orig: FUN_140382710)
void FUN_140382710(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CUserManager::helper_140383970  @140383970  [medium:callgraph-r3]  (orig: FUN_140383970)
undefined8 * FUN_140383970(undefined1 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = IGameData::vftable;
    *puVar1 = CGameData<&char*_szStatisticDailyTable,&char*_szID>::vftable;
    *(undefined1 *)(puVar1 + 2) = param_1;
    puVar1[1] = 0;
  }
  return puVar1;
}

// ==== CUserManager::helper_140384200  @140384200  [medium:callgraph-r0]  (orig: FUN_140384200)
undefined8 FUN_140384200(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  char cVar6;
  longlong *plVar7;
  longlong lVar8;
  
  cVar6 = FUN_140167b70();
  if (cVar6 == '\0') {
    plVar1 = (longlong *)(param_1 + 0xc0);
    plVar2 = (longlong *)*plVar1;
    plVar7 = (longlong *)**(undefined8 **)(param_1 + 0xf0);
    while( true ) {
      plVar3 = *(longlong **)(param_1 + 0xf0);
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar3) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar2;
      }
      if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar4 = (undefined8 *)plVar7[4];
      if (puVar4 != (undefined8 *)0x0) {
        (**(code **)*puVar4)(puVar4,1);
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        plVar3 = (longlong *)plVar7[2];
        if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
          cVar6 = *(char *)(*plVar3 + 0x29);
          plVar5 = (longlong *)*plVar3;
          plVar7 = plVar3;
          while (plVar3 = plVar5, cVar6 == '\0') {
            plVar5 = (longlong *)*plVar3;
            cVar6 = *(char *)((longlong)plVar5 + 0x29);
            plVar7 = plVar3;
          }
        }
        else {
          cVar6 = *(char *)(plVar7[1] + 0x29);
          plVar5 = (longlong *)plVar7[1];
          plVar3 = plVar7;
          while ((plVar7 = plVar5, cVar6 == '\0' && (plVar3 == (longlong *)plVar7[2]))) {
            cVar6 = *(char *)(plVar7[1] + 0x29);
            plVar5 = (longlong *)plVar7[1];
            plVar3 = plVar7;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    plVar2 = *(longlong **)(*(longlong *)(param_1 + 0xf0) + 8);
    cVar6 = *(char *)((longlong)plVar2 + 0x29);
    while (cVar6 == '\0') {
      FUN_14018bc60(plVar1,plVar2[2]);
      plVar7 = (longlong *)*plVar2;
      operator_delete(plVar2);
      plVar2 = plVar7;
      cVar6 = *(char *)((longlong)plVar7 + 0x29);
    }
    *(longlong *)(*(longlong *)(param_1 + 0xf0) + 8) = *(longlong *)(param_1 + 0xf0);
    *(undefined8 *)(param_1 + 0xf8) = 0;
    *(undefined8 *)*(undefined8 *)(param_1 + 0xf0) = *(undefined8 *)(param_1 + 0xf0);
    *(longlong *)(*(longlong *)(param_1 + 0xf0) + 0x10) = *(longlong *)(param_1 + 0xf0);
  }
  return 1;
}

// ==== CUserManager::helper_140384480  @140384480  [medium:callgraph-r3]  (orig: FUN_140384480)
longlong * FUN_140384480(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar6 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar6;
      if ((*param_3 < *(uint *)(puVar7 + 3)) ||
         ((*param_3 <= *(uint *)(puVar7 + 3) && (param_3[1] < *(uint *)((longlong)puVar7 + 0x1c)))))
      {
        puVar6 = (undefined8 *)*puVar7;
        bVar8 = true;
      }
      else {
        puVar6 = (undefined8 *)puVar7[2];
        bVar8 = false;
      }
    } while (*(char *)((longlong)puVar6 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar6 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8) {
    puVar6 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar6) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar6 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar6 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar6[2] + 0x29);
          puVar3 = (undefined8 *)puVar6[2];
          while (puVar4 = puVar6, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar6 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar6 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar6))) {
            cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
            puVar4 = (undefined8 *)puVar6[1];
            puVar3 = puVar6;
            local_30 = puVar6;
          }
          puVar4 = puVar6;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar6 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar6 = (undefined8 *)puVar7[2];
        puVar4 = puVar6;
        if (*(char *)((longlong)puVar6 + 0x29) != '\0') {
          local_30 = puVar6;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1403845bd;
    }
    bVar8 = true;
  }
  else {
LAB_1403845bd:
    local_30 = puVar4;
    if ((*param_3 <= *(uint *)(puVar6 + 3)) &&
       ((*param_3 < *(uint *)(puVar6 + 3) || (param_3[1] <= *(uint *)((longlong)puVar6 + 0x1c))))) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140384613;
    }
  }
  plVar5 = (longlong *)FUN_140383a10(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar5[1];
  *param_2 = *plVar5;
LAB_140384613:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_1403ad3f0  @1403ad3f0  [medium:callgraph-r2]  (orig: FUN_1403ad3f0)
undefined8 FUN_1403ad3f0(longlong param_1,longlong *param_2,int param_3)

{
  int iVar1;
  longlong *plVar2;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(longlong **)(param_1 + 8) = param_2;
    if (param_2 != (longlong *)0x0) {
      plVar2 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,&DAT_140951730);
      iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
      if (iVar1 != param_3) {
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                           (*(longlong **)(param_1 + 8),&DAT_140951730);
        (**(code **)(*plVar2 + 0xb8))(plVar2,param_3);
      }
      return 1;
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CUserManager::helper_1403ae020  @1403ae020  [medium:callgraph-r2]  (orig: FUN_1403ae020)
void FUN_1403ae020(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403ae020(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CUserManager::helper_1403aee70  @1403aee70  [medium:callgraph-r1]  (orig: FUN_1403aee70)
void FUN_1403aee70(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = (longlong *)plVar4[4];
    if ((plVar3 != (longlong *)0x0) && (*(char *)(param_1 + 0x50) == '\0')) {
      (**(code **)(*plVar3 + 0x70))(plVar3);
    }
    if (plVar3 != (longlong *)0x0) {
      (**(code **)(*plVar3 + 0x58))(plVar3);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x29);
  while (cVar1 == '\0') {
    FUN_1403ae020(param_1 + 8,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  return;
}

// ==== CUserManager::helper_1403af820  @1403af820  [medium:callgraph-r1]  (orig: FUN_1403af820)
undefined8 FUN_1403af820(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined1 local_90 [8];
  longlong *local_88;
  undefined1 local_80 [24];
  longlong *local_68 [3];
  longlong *local_50;
  longlong *local_48;
  undefined8 local_40;
  
  if (*(char *)(param_1 + 0x50) == '\0') {
    plVar3 = operator_new(8);
    plVar9 = (longlong *)0x0;
    local_68[0] = plVar9;
    if (plVar3 != (longlong *)0x0) {
      *plVar3 = (longlong)local_68;
      local_68[0] = plVar3;
    }
    local_50 = (longlong *)0x0;
    local_48 = (longlong *)0x0;
    local_40 = 0;
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
    plVar3 = *(longlong **)(lVar4 + 0x170);
    if (*(longlong **)(lVar4 + 0x170) == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = plVar9;
    }
    FUN_140313fc0(plVar3,local_68,*(undefined4 *)(param_1 + 0x4c),5);
    plVar7 = local_50;
    plVar3 = local_68[0];
    if (local_48 < local_50) {
      _invalid_parameter_noinfo();
      plVar3 = local_68[0];
    }
    while( true ) {
      plVar8 = local_48;
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
      }
      if ((plVar3 == (longlong *)0x0) || (plVar3 != local_68[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar7 == plVar8) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar9;
      }
      else {
        plVar8 = (longlong *)*plVar3;
      }
      if ((longlong *)plVar8[4] <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar8 = (longlong *)*plVar7;
      if (plVar8 != (longlong *)0x0) {
        plVar5 = operator_new(0x18);
        plVar6 = plVar9;
        if (plVar5 != (longlong *)0x0) {
          *plVar5 = (longlong)IGameData::vftable;
          *plVar5 = (longlong)CGameData<&char*_szAstProfExpTable,&char*_szID>::vftable;
          *(undefined1 *)(plVar5 + 2) = 0;
          plVar5[1] = 0;
          plVar6 = plVar5;
        }
        if (plVar6 != (longlong *)0x0) {
          plVar5 = (longlong *)(**(code **)(*plVar8 + 0x28))(plVar8);
          uVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
          cVar1 = FUN_1403ad3f0(plVar6,plVar8,uVar2);
          if (cVar1 == '\0') {
            (**(code **)(*plVar6 + 0x58))(plVar6);
          }
          else {
            local_90[0] = (**(code **)(*plVar6 + 0x10))(plVar6,2);
            local_88 = plVar6;
            FUN_1403af4c0(param_1 + 8,local_80,local_90);
          }
        }
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar9;
      }
      else {
        plVar8 = (longlong *)*plVar3;
      }
      if ((longlong *)plVar8[4] <= plVar7) {
        _invalid_parameter_noinfo();
      }
      plVar7 = plVar7 + 1;
    }
    if (local_50 != (longlong *)0x0) {
      operator_delete(local_50);
    }
    local_50 = (longlong *)0x0;
    local_48 = (longlong *)0x0;
    local_40 = 0;
    operator_delete(local_68[0]);
  }
  return 1;
}

// ==== CUserManager::helper_1403b2450  @1403b2450  [medium:callgraph-r3]  (orig: FUN_1403b2450)
undefined8 * FUN_1403b2450(undefined8 *param_1,undefined4 param_2,longlong param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  param_1[1] = 0;
  puVar1 = param_1 + 5;
  plVar2 = operator_new(8);
  plVar3 = (longlong *)0x0;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)puVar1;
    plVar3 = plVar2;
  }
  *puVar1 = plVar3;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  *(undefined4 *)(param_1 + 2) = param_2;
  param_1[3] = param_3;
  plVar3 = DAT_140975bc8;
  if (DAT_140975bc8 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  *param_1 = plVar3;
  FUN_1403b20b0(puVar1);
  *(undefined4 *)(param_1 + 4) = 1;
  return param_1;
}

// ==== CUserManager::helper_1403b26b0  @1403b26b0  [medium:callgraph-r2]  (orig: FUN_1403b26b0)
void FUN_1403b26b0(undefined4 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  void *pvVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if ((DAT_140976230 & 1) == 0) {
    DAT_140976230 = DAT_140976230 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976228,"CProps");
    atexit((_func_5014 *)&LAB_1406d6c00);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976228,0x58);
  if (pvVar1 == (void *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = FUN_1403b2450(pvVar1,param_1,param_2,param_4,uVar3);
  }
  *(undefined4 *)(lVar2 + 0x10) = param_1;
  *(undefined8 *)(lVar2 + 0x18) = param_2;
  return;
}

// ==== CUserManager::helper_1403b34f0  @1403b34f0  [medium:callgraph-r3]  (orig: FUN_1403b34f0)
ulonglong FUN_1403b34f0(longlong param_1,longlong *param_2)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong *plVar1;
  char *pcVar2;
  undefined7 extraout_var;
  
  if (*(longlong *)(param_1 + 0x10) != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  *(longlong **)(param_1 + 0x10) = param_2;
  plVar1 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,7);
  pcVar2 = (char *)(**(code **)(*plVar1 + 0x78))(plVar1);
  tq::SafeCopy((char *)(param_1 + 0x18),pcVar2,0x10);
  return CONCAT71(extraout_var,1);
}

// ==== CUserManager::helper_1403b4190  @1403b4190  [medium:callgraph-r1]  (orig: FUN_1403b4190)
undefined1 FUN_1403b4190(longlong *param_1,undefined4 param_2,longlong param_3)

{
  if (param_3 == 0) {
    return 0;
  }
  *param_1 = param_3;
  *(undefined4 *)((longlong)param_1 + 0x1c) = param_2;
  return 1;
}

// ==== CUserManager::helper_1403b82a0  @1403b82a0  [medium:callgraph-r1]  (orig: FUN_1403b82a0)
undefined8 FUN_1403b82a0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  
  if (param_2 == 0) {
    uVar3 = 0;
  }
  else {
    local_60[0] = operator_new(8);
    if (local_60[0] == (longlong *)0x0) {
      local_60[0] = (longlong *)0x0;
    }
    else {
      *local_60[0] = (longlong)local_60;
    }
    lVar8 = 0;
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    lVar6 = *(longlong *)(lVar4 + 0x170);
    if (*(longlong *)(lVar4 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar6 = lVar8;
    }
    FUN_140313fc0(lVar6,local_60,param_2,0x1d);
    uVar9 = (longlong)local_40 - (longlong)local_48 >> 3;
    if (uVar9 == 0) {
      if (local_48 != (longlong *)0x0) {
        operator_delete(local_48);
      }
      local_48 = (longlong *)0x0;
      local_40 = (longlong *)0x0;
      local_38 = 0;
      operator_delete(local_60[0]);
      uVar3 = 0;
    }
    else {
      if (uVar9 == 1) {
        puVar5 = (undefined8 *)FUN_1400cfc10(local_60);
        *(undefined8 *)(param_1 + 0x10) = *puVar5;
      }
      else if (1 < uVar9) {
        puVar5 = (undefined8 *)FUN_1400cfc10(local_60);
        plVar7 = local_48;
        *(undefined8 *)(param_1 + 0x10) = *puVar5;
        if (((longlong)local_40 - (longlong)local_48 & 0xfffffffffffffff8U) != 0) {
          local_40 = local_40 + -1;
        }
        plVar1 = local_60[0];
        if (local_40 < local_48) {
          _invalid_parameter_noinfo();
          plVar1 = local_60[0];
        }
        while( true ) {
          plVar2 = local_40;
          if (local_40 < local_48) {
            _invalid_parameter_noinfo();
          }
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_60[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar7 == plVar2) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = lVar8;
          }
          else {
            lVar6 = *plVar1;
          }
          if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
            _invalid_parameter_noinfo();
          }
          puVar5 = (undefined8 *)*plVar7;
          if (puVar5 != (undefined8 *)0x0) {
            (**(code **)*puVar5)(puVar5,1);
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = lVar8;
          }
          else {
            lVar6 = *plVar1;
          }
          if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
            _invalid_parameter_noinfo();
          }
          plVar7 = plVar7 + 1;
        }
      }
      FUN_1400179f0(local_60);
      if (*(longlong *)(param_1 + 0x10) == 0) {
        if (local_48 != (longlong *)0x0) {
          operator_delete(local_48);
        }
        local_48 = (longlong *)0x0;
        local_40 = (longlong *)0x0;
        local_38 = 0;
        operator_delete(local_60[0]);
        uVar3 = 0;
      }
      else {
        if (local_48 != (longlong *)0x0) {
          operator_delete(local_48);
        }
        local_48 = (longlong *)0x0;
        local_40 = (longlong *)0x0;
        local_38 = 0;
        operator_delete(local_60[0]);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CUserManager::helper_1403bb940  @1403bb940  [medium:callgraph-r2]  (orig: FUN_1403bb940)
undefined8 FUN_1403bb940(longlong param_1,undefined4 param_2,longlong *param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  uint uVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong local_res20;
  longlong local_70;
  undefined8 *local_68;
  longlong local_60;
  undefined8 local_58;
  longlong *local_50;
  longlong local_48;
  
  plVar13 = (longlong *)param_3[3];
  if ((longlong *)param_3[4] < plVar13) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_3;
  do {
    plVar9 = (longlong *)param_3[4];
    if (plVar9 < (longlong *)param_3[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*param_3)) {
      _invalid_parameter_noinfo();
    }
    if (plVar13 == plVar9) {
      *(undefined4 *)(param_1 + 0x50) = param_2;
      return CONCAT71((uint7)(uint3)((uint)param_2 >> 8),1);
    }
    lVar8 = FUN_1403b9650(*(undefined4 *)(param_1 + 8));
    local_res20 = lVar8;
    if (lVar8 == 0) {
LAB_1403bbc85:
      FUN_1403b9370(&local_res20);
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = 0;
      }
      else {
        lVar12 = *plVar2;
      }
      if (*(longlong **)(lVar12 + 0x20) <= plVar13) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)*plVar13;
      if (*(longlong *)(lVar8 + 8) != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1403bbc85;
      }
      if (plVar9 == (longlong *)0x0) goto LAB_1403bbc85;
      *(longlong **)(lVar8 + 8) = plVar9;
      if (plVar9 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar6 = 0;
      }
      else {
        plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,2);
        uVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
      }
      puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
      cVar1 = *(char *)((longlong)puVar11 + 0x29);
      puVar4 = *(undefined8 **)(param_1 + 0x40);
      while (cVar1 == '\0') {
        if (*(uint *)(puVar11 + 3) < uVar6) {
          puVar10 = (undefined8 *)puVar11[2];
          puVar11 = puVar4;
        }
        else {
          puVar10 = (undefined8 *)*puVar11;
        }
        puVar4 = puVar11;
        puVar11 = puVar10;
        cVar1 = *(char *)((longlong)puVar10 + 0x29);
      }
      local_68 = puVar4;
      local_70 = *(longlong *)(param_1 + 0x10);
      puVar11 = *(undefined8 **)(param_1 + 0x40);
      if (*(longlong *)(param_1 + 0x10) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar4 == puVar11) || (uVar6 < *(uint *)(puVar4 + 3))) {
        local_58 = *(undefined8 *)(param_1 + 0x40);
        local_60 = *(longlong *)(param_1 + 0x10);
        plVar9 = &local_60;
      }
      else {
        plVar9 = &local_70;
      }
      plVar3 = (longlong *)*plVar9;
      local_50 = plVar3;
      local_48 = plVar9[1];
      lVar12 = *(longlong *)(param_1 + 0x40);
      if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x10))) {
        _invalid_parameter_noinfo();
      }
      lVar5 = local_48;
      if (local_48 != lVar12) {
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (lVar5 == *(longlong *)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lVar5 + 0x20) != 0) {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (lVar5 == *(longlong *)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (lVar5 == *(longlong *)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_1403b8b30(*(undefined8 *)(lVar5 + 0x20));
          FUN_1403b8b90(*(undefined8 *)(lVar5 + 0x20));
          log_InlineLogWARNING
                    ("CUserTaskDetail::Create task id repeat. user id:%u, task id:%u, id:%u");
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (lVar5 == *(longlong *)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_1403b9370(lVar5 + 0x20);
        }
      }
      if (*(longlong *)(lVar8 + 8) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar7 = 0;
      }
      else {
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)(lVar8 + 8) + 0x10))(*(longlong **)(lVar8 + 8),2);
        uVar7 = (**(code **)(*plVar9 + 0x40))(plVar9);
      }
      local_res20 = CONCAT44(local_res20._4_4_,uVar7);
      plVar9 = (longlong *)FUN_1403bb750(param_1 + 0x10,&local_res20);
      *plVar9 = lVar8;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (*(longlong **)(lVar8 + 0x20) <= plVar13) {
      _invalid_parameter_noinfo();
    }
    plVar13 = plVar13 + 1;
  } while( true );
}

// ==== CUserManager::helper_1403d6e00  @1403d6e00  [medium:callgraph-r1]  (orig: FUN_1403d6e00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403d6e00(longlong param_1,undefined4 param_2,longlong *param_3,char param_4)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined4 local_478;
  undefined4 local_470;
  uint uStack_46c;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  local_478 = param_2;
  if (*(longlong *)(param_1 + 0x220) == 0) {
    local_488 = 0x1454;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else if (param_3 == (longlong *)0x0) {
    local_488 = 0x1455;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else if ((int)param_3[0x248] == 0) {
    uVar3 = 0;
  }
  else {
    uVar2 = (**(code **)(*param_3 + 8))(param_3);
    cVar1 = FUN_14031c3f0(*(undefined8 *)(param_1 + 0x220),param_2,uVar2);
    if (cVar1 == '\0') {
      (**(code **)(*param_3 + 8))(param_3);
      local_488 = (undefined4)param_3[0x248];
      tq::MyLogSave("gmlog/texasholdemwitness",
                    "CTexasHoldEm::OnExitWitness. User[%u] DelWitness CurTable[%u] UserTable[%u] del fail"
                   );
      uVar3 = 0;
    }
    else {
      if (param_4 != '\0') {
        FUN_140452f10(local_458);
        uVar2 = (**(code **)(*param_3 + 8))(param_3);
        cVar1 = FUN_140452fc0(local_458,1,*(undefined4 *)(param_1 + 0x1b4),uVar2);
        if (cVar1 != '\0') {
          FUN_1403d63a0(param_1,local_458,0);
          (**(code **)(param_3[2] + 0x350))(param_3 + 2,local_458);
        }
        FUN_140452f60(local_458);
      }
      local_470 = 0;
      uStack_46c = uStack_46c & 0xffffff00;
      (**(code **)(*param_3 + 8))(param_3);
      local_488 = (undefined4)param_3[0x248];
      tq::MyLogSave("gmlog/texasholdemwitness",
                    "CTexasHoldEm::OnExitWitness. SetTexasHoldEmInfo none User[%u]  ExitWitness CurTable[%u] UserTable[%u]"
                   );
      param_3[0x248] = CONCAT44(uStack_46c,local_470);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CUserManager::helper_1403e75f0  @1403e75f0  [medium:callgraph-r1]  (orig: FUN_1403e75f0)
undefined8 FUN_1403e75f0(longlong param_1,longlong *param_2)

{
  bool bVar1;
  uint uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong lVar8;
  uint uStackX_1c;
  undefined1 uVar9;
  longlong *local_38;
  longlong local_30;
  longlong *local_28;
  
  if (param_2 == (longlong *)0x0) {
    uVar6 = 0;
  }
  else if ((int)param_2[0x248] == 0) {
    uVar6 = 0;
  }
  else if (*(byte *)((longlong)param_2 + 0x1244) < 9) {
    FUN_1403ccc50(param_1 + 0x108,&local_38,(longlong)param_2 + 0x1244);
    lVar8 = *(longlong *)(param_1 + 0x138);
    local_28 = *(longlong **)(param_1 + 0x108);
    if ((local_38 == (longlong *)0x0) || (local_38 != local_28)) {
      _invalid_parameter_noinfo();
    }
    if (local_30 == lVar8) {
      uVar6 = 0;
    }
    else {
      if (local_38 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *local_38;
      }
      if (local_30 == *(longlong *)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar4 = (**(code **)(*param_2 + 8))(param_2);
      if (iVar4 == *(int *)(local_30 + 0x20)) {
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        *(undefined4 *)(param_1 + 0x194) = uVar5;
        FUN_1403e7110(param_1,param_2,1);
        bVar1 = false;
        uVar9 = 0;
        if (*(char *)(local_30 + 0x60) == '\x02') {
          puVar7 = (undefined8 *)FUN_1403cff10(param_1 + 0x1c8,local_30 + 0x20);
          *puVar7 = *(undefined8 *)(local_30 + 0x58);
          bVar1 = true;
          uVar9 = 1;
          if (*(char *)(param_1 + 0x189) == *(char *)((longlong)param_2 + 0x1244)) {
            FUN_1403e5a50(param_1,*(char *)(param_1 + 0x189),param_2,0,1);
          }
        }
        if (*(char *)(param_1 + 0x208) == '\0') {
          iVar4 = FUN_14016b120(param_1 + 0x248);
          if ((iVar4 < 1) && (cVar3 = FUN_1403c9910(param_1), cVar3 != '\0')) {
            FUN_1403e1140(param_1);
          }
        }
        else if (bVar1) {
          cVar3 = FUN_1403e3280(param_1);
          if (cVar3 != '\0') {
            return 1;
          }
          FUN_1403e44e0(param_1);
        }
        *(undefined4 *)(param_1 + 0x194) = 0;
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        cVar3 = FUN_14031b8d0(*(undefined8 *)(param_1 + 0x220),uVar5);
        if (cVar3 != '\0') {
          uVar2 = uStackX_1c >> 8;
          uStackX_1c = uVar2 << 8;
          param_2[0x248] = CONCAT44(uStackX_1c,*(undefined4 *)(param_1 + 0x210));
          FUN_1403d6e00(param_1,*(undefined4 *)(param_1 + 0x210),param_2,0,uVar9);
          (**(code **)(*param_2 + 8))(param_2);
          tq::MyLogSave("gmlog/texasholdemwitness",
                        "CTexasHoldEm::OnUserExit. SetTexasHoldEmInfo none User[%u] ExitWitness CurTable[%u]"
                       );
          uStackX_1c = uVar2 << 8;
          param_2[0x248] = (ulonglong)uStackX_1c << 0x20;
        }
        uVar6 = 1;
      }
      else {
        uVar6 = 0;
      }
    }
  }
  else {
    uVar6 = 0;
  }
  return uVar6;
}

// ==== CUserManager::helper_1403e7860  @1403e7860  [medium:callgraph-r0]  (orig: FUN_1403e7860)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403e7860(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  undefined1 auStack_48 [32];
  undefined4 local_28;
  undefined8 local_18;
  ulonglong local_10;
  
  local_18 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  if (param_2 == (longlong *)0x0) {
    local_28 = 0x65d;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    cVar1 = FUN_14031b8d0(*(undefined8 *)(param_1 + 0x220),uVar2);
    if (cVar1 == '\0') {
      uVar3 = FUN_1403e75f0(param_1,param_2);
    }
    else {
      uVar3 = FUN_1403d6e00(param_1,*(undefined4 *)(param_1 + 0x210),param_2,1);
    }
  }
  return uVar3;
}

// ==== CUserManager::helper_1403ff890  @1403ff890  [medium:callgraph-r2]  (orig: FUN_1403ff890)
undefined8 FUN_1403ff890(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *local_a8 [3];
  longlong *local_90;
  longlong *local_88;
  undefined8 local_80;
  longlong *local_78;
  longlong *local_70;
  longlong *local_68;
  char local_60 [8];
  longlong *local_58;
  longlong *local_50 [3];
  undefined8 local_38;
  
  local_38 = 0xfffffffffffffffe;
  local_a8[0] = operator_new(8);
  if (local_a8[0] == (longlong *)0x0) {
    local_a8[0] = (longlong *)0x0;
  }
  else {
    *local_a8[0] = (longlong)local_a8;
  }
  lVar7 = 0;
  local_90 = (longlong *)0x0;
  local_88 = (longlong *)0x0;
  local_80 = 0;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar4 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = lVar7;
  }
  else {
    lVar4 = *(longlong *)(lVar4 + 0x170);
  }
  FUN_140313fc0(lVar4,local_a8,param_2,0x20);
  plVar8 = local_90;
  if ((longlong)local_88 - (longlong)local_90 >> 3 == 0) {
    if (local_90 != (longlong *)0x0) {
      operator_delete(local_90);
    }
    local_90 = (longlong *)0x0;
    local_88 = (longlong *)0x0;
    local_80 = 0;
    operator_delete(local_a8[0]);
    uVar5 = 0;
  }
  else {
    local_78 = (longlong *)0x0;
    if (local_88 < local_90) {
      _invalid_parameter_noinfo();
    }
    plVar2 = local_a8[0];
    local_78 = local_a8[0];
    while( true ) {
      plVar1 = local_88;
      local_50[0] = (longlong *)0x0;
      local_70 = plVar8;
      if (local_88 < local_90) {
        _invalid_parameter_noinfo();
      }
      local_50[0] = local_a8[0];
      if ((plVar2 == (longlong *)0x0) || (plVar2 != local_a8[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar1) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = lVar7;
      }
      else {
        lVar4 = *plVar2;
      }
      if (*(longlong **)(lVar4 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar1 = (longlong *)*plVar8;
      local_68 = plVar1;
      if (plVar1 != (longlong *)0x0) {
        plVar6 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
        cVar3 = (**(code **)(*plVar6 + 0x20))(plVar6);
        if (cVar3 == '\0') {
          log_InlineLogERROR(
                            "CJiangHuPlayerPower::LoadUserPowerData, powerlevel(%d) error at %s, %d"
                            );
          (**(code **)*plVar1)(plVar1,1);
          local_68 = (longlong *)0x0;
        }
        else {
          local_60[0] = cVar3;
          local_58 = plVar1;
          FUN_140156b30(param_1 + 0x10,local_50,local_60);
        }
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar4 = lVar7;
      }
      else {
        lVar4 = *plVar2;
      }
      if (*(longlong **)(lVar4 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar8 + 1;
    }
    if (local_90 != (longlong *)0x0) {
      operator_delete(local_90);
    }
    local_90 = (longlong *)0x0;
    local_88 = (longlong *)0x0;
    local_80 = 0;
    operator_delete(local_a8[0]);
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CUserManager::helper_140408110  @140408110  [medium:callgraph-r2]  (orig: FUN_140408110)
void FUN_140408110(longlong param_1,undefined1 param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  int *piVar7;
  undefined8 *puVar8;
  
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  lVar6 = *(longlong *)(lVar6 + 0x1d0);
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar6 = 0;
  }
  lVar6 = FUN_1401f74e0(lVar6,param_2);
  if (lVar6 != 0) {
    puVar2 = *(undefined8 **)(lVar6 + 0x78);
    plVar3 = *(longlong **)(lVar6 + 0x48);
    puVar8 = (undefined8 *)*puVar2;
    while( true ) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (puVar8 == puVar2) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar3;
      }
      if (puVar8 == *(undefined8 **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      piVar7 = (int *)FUN_140406b20(param_1 + 0x10,puVar8 + 3);
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar3;
      }
      if (puVar8 == *(undefined8 **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *piVar7 = *piVar7 + *(int *)((longlong)puVar8 + 0x1c);
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
        puVar4 = (undefined8 *)puVar8[2];
        if (*(char *)((longlong)puVar4 + 0x21) == '\0') {
          cVar1 = *(char *)((longlong)*puVar4 + 0x21);
          puVar8 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar4 + 0x21);
            puVar8 = puVar4;
            puVar4 = (undefined8 *)*puVar4;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x21);
          puVar5 = (undefined8 *)puVar8[1];
          puVar4 = puVar8;
          while ((puVar8 = puVar5, cVar1 == '\0' && (puVar4 == (undefined8 *)puVar8[2]))) {
            cVar1 = *(char *)((longlong)puVar8[1] + 0x21);
            puVar5 = (undefined8 *)puVar8[1];
            puVar4 = puVar8;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140408187. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR(
                    "CInnerStrengthPlayer::ProcessSecretAttribAdd not found secret type info, user id:%u, secret type:%u."
                    );
  return;
}

// ==== CUserManager::helper_140408750  @140408750  [medium:callgraph-r1]  (orig: FUN_140408750)
longlong FUN_140408750(undefined4 param_1,int param_2,undefined1 param_3)

{
  void *pvVar1;
  longlong lVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","idUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\innerstrength\\innerstrengthplayer.cpp"
                       ,0x1f);
    lVar2 = 0;
  }
  else {
    if ((DAT_140976348 & 1) == 0) {
      DAT_140976348 = DAT_140976348 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140976340,"CInnerStrengthPlayer");
      atexit((_func_5014 *)&LAB_1406d6d50);
    }
    pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976340,0xe0);
    if (pvVar1 == (void *)0x0) {
      lVar2 = 0;
    }
    else {
      lVar2 = FUN_140408680(pvVar1,param_1,param_2,param_3);
    }
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pInnerStrengthPlayer",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\innerstrength\\innerstrengthplayer.cpp"
                         ,0x24);
      lVar2 = 0;
    }
  }
  return lVar2;
}

// ==== CUserManager::helper_140408850  @140408850  [medium:callgraph-r1]  (orig: FUN_140408850)
undefined8 FUN_140408850(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  int *piVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  int local_148;
  longlong *local_140 [3];
  longlong *local_128;
  longlong *local_120;
  undefined8 local_118;
  longlong *local_110 [3];
  longlong *local_f8;
  longlong *local_f0;
  undefined8 local_e8;
  longlong *local_d8;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  longlong *local_c8;
  undefined8 uStack_c0;
  longlong local_b8;
  longlong *local_a8;
  longlong *plStack_a0;
  undefined2 local_98 [4];
  longlong local_90;
  char local_88 [8];
  longlong *local_80;
  undefined8 local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 local_60;
  char local_58 [32];
  
  local_60 = 0xfffffffffffffffe;
  local_140[0] = operator_new(8);
  if (local_140[0] == (longlong *)0x0) {
    local_140[0] = (longlong *)0x0;
  }
  else {
    *local_140[0] = (longlong)local_140;
  }
  plVar11 = (longlong *)0x0;
  local_128 = (longlong *)0x0;
  local_120 = (longlong *)0x0;
  local_118 = 0;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar5 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = plVar11;
  }
  else {
    plVar7 = *(longlong **)(lVar5 + 0x170);
  }
  FUN_140313fc0(plVar7,local_140,param_2,0x24);
  plVar7 = local_128;
  if (local_120 < local_128) {
    _invalid_parameter_noinfo();
  }
  plVar13 = local_120;
  plVar1 = local_140[0];
  local_d8 = (longlong *)0x0;
  if (local_120 < local_128) {
    _invalid_parameter_noinfo();
  }
  plVar8 = local_140[0];
  local_d8 = local_140[0];
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar13) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar12 = plVar11;
    }
    else {
      plVar12 = (longlong *)*plVar1;
    }
    if ((longlong *)plVar12[4] <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar12 = (longlong *)*plVar7;
    if (plVar12 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,2);
      cVar2 = (**(code **)(*plVar6 + 0x20))(plVar6);
      if (cVar2 != '\0') {
        local_88[0] = cVar2;
        local_80 = plVar12;
        local_58[0] = cVar2;
        FUN_140156b30(param_1 + 0x90,&local_78,local_88);
        FUN_140408110(param_1,cVar2);
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar12 = plVar11;
    }
    else {
      plVar12 = (longlong *)*plVar1;
    }
    if ((longlong *)plVar12[4] <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  }
  plVar7 = operator_new(8);
  local_110[0] = plVar11;
  if (plVar7 != (longlong *)0x0) {
    *plVar7 = (longlong)local_110;
    local_110[0] = plVar7;
  }
  local_f8 = (longlong *)0x0;
  local_f0 = (longlong *)0x0;
  local_e8 = 0;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar5 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = plVar11;
  }
  else {
    plVar7 = *(longlong **)(lVar5 + 0x170);
  }
  FUN_140313fc0(plVar7,local_110,param_2,0x23);
  plVar7 = local_f8;
  local_a8 = (longlong *)0x0;
  if (local_f0 < local_f8) {
    _invalid_parameter_noinfo();
  }
  plVar13 = local_f0;
  plVar1 = local_110[0];
  local_a8 = local_110[0];
  plStack_a0 = plVar7;
  local_c8 = (longlong *)0x0;
  if (local_f0 < local_f8) {
    _invalid_parameter_noinfo();
  }
  local_c8 = local_110[0];
  uStack_c0 = plVar13;
  uStack_c0._0_4_ = SUB84(plVar13,0);
  uStack_c0._4_4_ = (undefined4)((ulonglong)plVar13 >> 0x20);
  local_d8 = local_110[0];
  uStack_d0 = (undefined4)uStack_c0;
  uStack_cc = uStack_c0._4_4_;
  uStack_c0 = plVar13;
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_d8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == (longlong *)CONCAT44(uStack_cc,uStack_d0)) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar13 = plVar11;
    }
    else {
      plVar13 = (longlong *)*plVar1;
    }
    if ((longlong *)plVar13[4] <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar13 = (longlong *)*plVar7;
    if (plVar13 != (longlong *)0x0) {
      plVar8 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,0);
      (**(code **)(*plVar8 + 0x40))(plVar8);
      lVar5 = FUN_1404dbf30(param_2,plVar13,*(undefined1 *)(param_1 + 0xd4));
      local_b8 = lVar5;
      if (lVar5 == 0) {
        log_InlineLogERROR(
                          "CInnerStrengthPlayer::LoadUserData CreateNew failed, idUser:%u, data id:%u."
                          );
      }
      else {
        local_78 = 0;
        local_98[0] = FUN_1404db500(lVar5);
        local_90 = lVar5;
        puVar9 = (undefined8 *)FUN_140404dd0(param_1 + 0x50,local_58,local_98);
        local_78 = *puVar9;
        local_70 = puVar9[1];
        local_68 = puVar9[2];
        if ((char)local_68 == '\0') {
          FUN_1404db500(lVar5);
          log_InlineLogERROR("CInnerStrengthPlayer::LoadUserData type repeat, idUser:%u, type:%d.");
          FUN_1404dbee0(lVar5);
          local_b8 = 0;
        }
        else {
          for (local_148 = 8; local_148 < 0x16; local_148 = local_148 + 1) {
            plVar8 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,local_148);
            iVar4 = (**(code **)(*plVar8 + 0x50))(plVar8);
            if ((iVar4 != 0) && (6 < local_148)) {
              piVar10 = (int *)FUN_140406b20(param_1 + 0x10);
              *piVar10 = *piVar10 + iVar4;
            }
          }
          bVar3 = FUN_1404db810(lVar5);
          *(int *)(param_1 + 0xdc) = *(int *)(param_1 + 0xdc) + (uint)bVar3;
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar13 = plVar11;
    }
    else {
      plVar13 = (longlong *)*plVar1;
    }
    if ((longlong *)plVar13[4] <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  }
  if (local_f8 != (longlong *)0x0) {
    operator_delete(local_f8);
  }
  local_f8 = (longlong *)0x0;
  local_f0 = (longlong *)0x0;
  local_e8 = 0;
  operator_delete(local_110[0]);
  if (local_128 != (longlong *)0x0) {
    operator_delete(local_128);
  }
  local_128 = (longlong *)0x0;
  local_120 = (longlong *)0x0;
  local_118 = 0;
  operator_delete(local_140[0]);
  return 1;
}

// ==== CUserManager::helper_14041a7a0  @14041a7a0  [medium:callgraph-r3]  (orig: FUN_14041a7a0)
void FUN_14041a7a0(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_14041a280(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x29) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x29);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x29);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x29);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x29);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CUserManager::helper_14041b2b0  @14041b2b0  [medium:callgraph-r3]  (orig: FUN_14041b2b0)
longlong FUN_14041b2b0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_14041a310(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14041a590(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CUserManager::helper_14041b740  @14041b740  [medium:callgraph-r2]  (orig: FUN_14041b740)
undefined8 *
FUN_14041b740(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140419ac0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_14041a7a0(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CUserManager::helper_14041bdf0  @14041bdf0  [medium:callgraph-r2]  (orig: FUN_14041bdf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14041bdf0(longlong param_1,int param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  undefined1 auStack_548 [32];
  undefined4 local_528;
  undefined4 local_520;
  undefined4 local_518;
  undefined1 local_508 [8];
  undefined8 uStack_500;
  undefined4 local_4f8;
  undefined4 local_4f4 [3];
  undefined1 local_4e8 [8];
  undefined8 uStack_4e0;
  longlong *local_4d8 [6];
  undefined8 *local_4a8;
  undefined8 local_4a0;
  undefined8 local_498;
  undefined1 local_490 [24];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_498 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_548;
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x90));
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    local_528 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))
                    (*(longlong **)(lVar8 + 0x90),*(undefined4 *)(param_1 + 8));
  if (lVar8 == 0) {
    local_528 = 0xae;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_4f4[0] = FUN_14041db90(param_2);
    lVar9 = FUN_14041b530(param_1,local_4f4[0]);
    if (lVar9 == 0) {
      local_528 = 0xb1;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar5 = FUN_14041da90(lVar9);
      if (iVar5 == param_2) {
        uVar6 = FUN_14041dac0(lVar9);
        uVar7 = FUN_14041dab0(lVar9);
        local_4f8 = FUN_14041dc50(param_2);
        FUN_140423310(local_478);
        local_518 = FUN_14041dae0(lVar9);
        local_528 = uVar6;
        local_520 = uVar7;
        cVar4 = FUN_1404233c0(local_478,1,*(undefined4 *)(param_1 + 8),param_2);
        if (cVar4 != '\0') {
          (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x348))((longlong *)(lVar8 + 0x10),local_478,1)
          ;
        }
        uVar10 = FUN_14041daf0(lVar9);
        FUN_14000e970(local_4d8,uVar10);
        puVar2 = local_4a8;
        plVar11 = local_4d8[0];
        puVar12 = (undefined8 *)*local_4a8;
        uStack_500 = puVar12;
        while( true ) {
          if (plVar11 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (puVar12 == puVar2) break;
          if (plVar11 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar11;
          }
          if (puVar12 == *(undefined8 **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar6 = *(undefined4 *)(puVar12 + 3);
          lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x90));
          lVar8 = *(longlong *)(lVar8 + 0x140);
          if (lVar8 == 0) {
            local_528 = 0x149;
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar8 = 0;
          }
          lVar8 = FUN_14024e590(lVar8,uVar6);
          if (lVar8 == 0) {
            local_528 = 199;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            FUN_14041b950(lVar8,param_2);
          }
          if (plVar11 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar12 + 0x1d) == '\0') {
            puVar1 = (undefined8 *)puVar12[2];
            if (*(char *)((longlong)puVar1 + 0x1d) == '\0') {
              cVar4 = *(char *)((longlong)*puVar1 + 0x1d);
              puVar12 = puVar1;
              puVar1 = (undefined8 *)*puVar1;
              while (cVar4 == '\0') {
                cVar4 = *(char *)((longlong)*puVar1 + 0x1d);
                puVar12 = puVar1;
                puVar1 = (undefined8 *)*puVar1;
              }
            }
            else {
              cVar4 = *(char *)((longlong)puVar12[1] + 0x1d);
              puVar3 = (undefined8 *)puVar12[1];
              puVar1 = puVar12;
              while ((puVar12 = puVar3, cVar4 == '\0' && (puVar1 == (undefined8 *)puVar12[2]))) {
                cVar4 = *(char *)((longlong)puVar12[1] + 0x1d);
                puVar3 = (undefined8 *)puVar12[1];
                puVar1 = puVar12;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        FUN_14041da70(lVar9);
        FUN_14041b2b0(param_1 + 0x10,local_4f4);
        plVar11 = (longlong *)FUN_1401181a0();
        (**(code **)(*plVar11 + 0x10))(plVar11,*(undefined4 *)(param_1 + 8),local_4f8);
        uStack_4e0 = *local_4a8;
        FUN_14000bd50(local_4d8,local_490,local_4e8,local_508);
        operator_delete(local_4a8);
        local_4a8 = (undefined8 *)0x0;
        local_4a0 = 0;
        operator_delete(local_4d8[0]);
        FUN_140423360(local_478);
      }
      else {
        local_528 = 0xb2;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    }
  }
  return;
}

// ==== CUserManager::helper_14041d1e0  @14041d1e0  [medium:callgraph-r1]  (orig: FUN_14041d1e0)
void FUN_14041d1e0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined4 uVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  undefined1 local_c8 [8];
  undefined8 uStack_c0;
  undefined1 local_b8 [8];
  undefined8 uStack_b0;
  longlong *local_a8 [6];
  undefined8 *local_78;
  undefined8 local_70;
  longlong *local_68 [6];
  undefined8 *local_38;
  undefined8 local_30;
  undefined1 local_28 [16];
  undefined8 local_18;
  
  local_18 = 0xfffffffffffffffe;
  FUN_14041b740(local_a8,param_1 + 0x10);
  puVar3 = local_78;
  plVar2 = local_a8[0];
  puVar6 = (undefined8 *)*local_78;
  while( true ) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (puVar6[4] != 0) {
      uVar4 = FUN_14041da90();
      FUN_14041bdf0(param_1,uVar4);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x29) == '\0') {
      puVar7 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        cVar1 = *(char *)((longlong)*puVar7 + 0x29);
        puVar6 = puVar7;
        puVar7 = (undefined8 *)*puVar7;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar7 + 0x29);
          puVar6 = puVar7;
          puVar7 = (undefined8 *)*puVar7;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
        puVar5 = (undefined8 *)puVar6[1];
        puVar7 = puVar6;
        while ((puVar6 = puVar5, cVar1 == '\0' && (puVar7 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
          puVar5 = (undefined8 *)puVar6[1];
          puVar7 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_14041b740(local_68,param_1 + 0x50);
  puVar3 = local_38;
  plVar2 = local_68[0];
  puVar6 = (undefined8 *)*local_38;
  do {
    do {
      while( true ) {
        while( true ) {
          puVar7 = puVar6;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (puVar7 == puVar3) {
            uStack_c0 = *local_38;
            FUN_14041a590(local_68,local_28,local_c8,local_b8);
            operator_delete(local_38);
            local_38 = (undefined8 *)0x0;
            local_30 = 0;
            operator_delete(local_68[0]);
            uStack_b0 = *local_78;
            FUN_14041a590(local_a8,local_28,local_b8,local_c8);
            operator_delete(local_78);
            local_78 = (undefined8 *)0x0;
            local_70 = 0;
            operator_delete(local_a8[0]);
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = 0;
          }
          else {
            lVar8 = *plVar2;
          }
          if (puVar7 == *(undefined8 **)(lVar8 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (puVar7[4] != 0) {
            uVar4 = FUN_14041da90();
            FUN_14041b950(param_1,uVar4);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar7 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          puVar6 = puVar7;
        }
        puVar6 = (undefined8 *)puVar7[2];
        if (*(char *)((longlong)puVar6 + 0x29) != '\0') break;
        cVar1 = *(char *)((longlong)*puVar6 + 0x29);
        puVar7 = (undefined8 *)*puVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar7 + 0x29);
          puVar6 = puVar7;
          puVar7 = (undefined8 *)*puVar7;
        }
      }
      puVar6 = (undefined8 *)puVar7[1];
    } while (*(char *)((longlong)puVar6 + 0x29) != '\0');
    do {
      puVar5 = puVar6;
      puVar6 = puVar5;
      if (puVar7 != (undefined8 *)puVar5[2]) break;
      puVar6 = (undefined8 *)puVar5[1];
      puVar7 = puVar5;
    } while (*(char *)((longlong)puVar6 + 0x29) == '\0');
  } while( true );
}

// ==== CUserManager::helper_14041da70  @14041da70  [medium:callgraph-r3]  (orig: FUN_14041da70)
void FUN_14041da70(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CUserManager::helper_14041daf0  @14041daf0  [medium:callgraph-r3]  (orig: FUN_14041daf0)
longlong FUN_14041daf0(longlong param_1)

{
  return param_1 + 0x20;
}

// ==== CUserManager::helper_14041dc50  @14041dc50  [medium:callgraph-r3]  (orig: FUN_14041dc50)
undefined8 FUN_14041dc50(undefined4 param_1)

{
  switch(param_1) {
  case 1:
    return 0x5c;
  case 2:
    return 0x5e;
  case 3:
    return 0x60;
  case 4:
    return 0x62;
  case 5:
    return 100;
  case 6:
    return 0x66;
  case 7:
    return 0x68;
  case 8:
    return 0x7e;
  default:
    return 0xffffffff;
  }
}

// ==== CUserManager::helper_1404256a0  @1404256a0  [medium:callgraph-r3]  (orig: FUN_1404256a0)
undefined8 FUN_1404256a0(longlong param_1,int param_2)

{
  longlong lVar1;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_14002d940((longlong *)(param_1 + 8),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x38);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined8 *)(local_10 + 0x20);
  }
  return 0;
}

// ==== CUserManager::helper_140427340  @140427340  [medium:callgraph-r1]  (orig: FUN_140427340)
void FUN_140427340(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140427340(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CUserManager::helper_140428a50  @140428a50  [medium:callgraph-r0]  (orig: FUN_140428a50)
undefined8 FUN_140428a50(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_1404ddff0();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x29);
  while (cVar1 == '\0') {
    FUN_140427340(param_1 + 8,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  lVar5 = *(longlong *)(param_1 + 0x38);
  *(longlong *)(lVar5 + 0x10) = lVar5;
  return CONCAT71((int7)((ulonglong)lVar5 >> 8),1);
}

// ==== CUserManager::helper_140428f20  @140428f20  [medium:callgraph-r3]  (orig: FUN_140428f20)
longlong * FUN_140428f20(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14042907d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1404290ac;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14042907d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140427f90(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1404290ac:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CUserManager::helper_140429e00  @140429e00  [medium:callgraph-r2]  (orig: FUN_140429e00)
undefined8 FUN_140429e00(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  uint uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  uint local_80 [2];
  longlong local_78;
  undefined1 local_70 [24];
  longlong *local_58 [3];
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  
  local_58[0] = operator_new(8);
  if (local_58[0] == (longlong *)0x0) {
    local_58[0] = (longlong *)0x0;
  }
  else {
    *local_58[0] = (longlong)local_58;
  }
  local_40 = (longlong *)0x0;
  local_38 = (longlong *)0x0;
  local_30 = 0;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x54));
  lVar4 = *(longlong *)(lVar4 + 0x170);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = 0;
  }
  FUN_140313fc0(lVar4,local_58,*(undefined4 *)(param_1 + 0x50),0x27);
  plVar7 = local_40;
  plVar2 = local_58[0];
  if (local_38 < local_40) {
    _invalid_parameter_noinfo();
    plVar2 = local_58[0];
  }
  while( true ) {
    plVar1 = local_38;
    if (local_38 < local_40) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != local_58[0])) {
      _invalid_parameter_noinfo();
    }
    plVar5 = local_38;
    if (plVar7 == plVar1) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (*(longlong **)(lVar4 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar1 = (longlong *)*plVar7;
    if (plVar1 != (longlong *)0x0) {
      plVar5 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
      uVar3 = (**(code **)(*plVar5 + 0x40))(plVar5);
      if (uVar3 == 0) {
        (**(code **)*plVar1)(plVar1,1);
      }
      else {
        lVar4 = FUN_1404256a0(*(undefined8 *)(param_1 + 0x48),uVar3);
        if (lVar4 == 0) {
          (**(code **)*plVar1)(plVar1,1);
          log_InlineLogDBERROR("table:cq_activity_task_type, can not find activity_id(%u) data.");
        }
        else {
          lVar4 = FUN_1404debc0(*(undefined4 *)(param_1 + 0x54),plVar1,lVar4,0);
          if (lVar4 == 0) {
            (**(code **)*plVar1)(plVar1,1);
            log_InlineLogERROR(
                              "CActivityPlayer::Init, CActivityTask create user_id[%u] activity_id[%u] error."
                              );
          }
          else {
            local_80[0] = uVar3;
            local_78 = lVar4;
            lVar6 = FUN_140428f20(param_1 + 8,local_70,local_80);
            if (*(char *)(lVar6 + 0x10) == '\0') {
              FUN_1404ddff0(lVar4);
            }
          }
        }
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (*(longlong **)(lVar4 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  }
  if (local_38 < local_40) {
    _invalid_parameter_noinfo();
  }
  plVar2 = local_40;
  if (local_38 < local_40) {
    _invalid_parameter_noinfo();
  }
  if ((plVar2 < local_40) || (local_38 < plVar2)) {
    _invalid_parameter_noinfo();
  }
  plVar7 = local_58[0];
  if ((plVar5 < local_40) || (local_38 < plVar5)) {
    _invalid_parameter_noinfo();
  }
  if ((plVar7 == (longlong *)0x0) || (plVar7 != local_58[0])) {
    _invalid_parameter_noinfo();
  }
  plVar7 = local_38;
  if (plVar2 != plVar5) {
    lVar4 = (longlong)local_38 - (longlong)plVar5 >> 3;
    plVar7 = plVar2 + lVar4;
    if (0 < lVar4) {
      memmove_s(plVar2,lVar4 * 8,plVar5,lVar4 * 8);
    }
  }
  local_38 = plVar7;
  if (local_40 != (longlong *)0x0) {
    operator_delete(local_40);
  }
  local_40 = (longlong *)0x0;
  local_38 = (longlong *)0x0;
  local_30 = 0;
  operator_delete(local_58[0]);
  return 1;
}

// ==== CUserManager::helper_14042fd70  @14042fd70  [medium:callgraph-r3]  (orig: FUN_14042fd70)
void FUN_14042fd70(longlong param_1,uint param_2,char *param_3,int *param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong *plVar9;
  int iVar10;
  undefined8 *puVar11;
  int iVar12;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar11 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar4 = *(char *)((longlong)puVar11 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  while (cVar4 == '\0') {
    if (*(uint *)(puVar11 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar11[2];
      puVar11 = puVar2;
    }
    else {
      puVar7 = (undefined8 *)*puVar11;
    }
    puVar2 = puVar11;
    puVar11 = puVar7;
    cVar4 = *(char *)((longlong)puVar7 + 0x29);
  }
  puVar11 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar2;
  local_48 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar11) || (param_2 < *(uint *)(puVar2 + 3))) {
    plVar9 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar9 = &local_48;
  }
  plVar1 = (longlong *)*plVar9;
  lVar8 = *(longlong *)(param_1 + 0x38);
  local_28 = plVar1;
  local_20 = plVar9[1];
  if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_20;
  if (lVar8 != local_20) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (lVar3 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lVar3 + 0x20) != 0) {
      lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
      lVar8 = *(longlong *)(lVar8 + 0x200);
      if (lVar8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar8 = 0;
      }
      iVar5 = FUN_140268600(lVar8,param_2);
      iVar12 = 1;
      if (0 < iVar5) {
        iVar10 = param_2 * 100;
        do {
          iVar10 = iVar10 + 1;
          lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
          lVar8 = *(longlong *)(lVar8 + 0x200);
          if (lVar8 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar8 = 0;
          }
          iVar6 = FUN_140268d50(lVar8,iVar10);
          if ((iVar6 == 1) && (cVar4 = FUN_14042f000(param_1,iVar10), cVar4 != '\0')) {
            *param_4 = *param_4 + 1;
          }
          else {
            cVar4 = FUN_14042ee80(param_1,iVar10);
            if ((cVar4 != '\0') && (cVar4 = FUN_14042f000(param_1,iVar10), cVar4 == '\0')) {
              *param_3 = '\x01';
              return;
            }
          }
          iVar12 = iVar12 + 1;
        } while (iVar12 <= iVar5);
      }
      if (*param_3 == '\0') {
        cVar4 = FUN_14042ecb0(param_1,param_2);
        *param_3 = cVar4;
      }
    }
  }
  return;
}

// ==== CUserManager::helper_140431060  @140431060  [medium:callgraph-r2]  (orig: FUN_140431060)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140431060(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong *plVar3;
  byte bVar4;
  undefined4 uVar5;
  longlong *plVar6;
  char cVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  byte local_488 [4];
  undefined4 local_484;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == 0) {
    local_498 = 0x22d;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1404df8a0(local_478);
    cVar7 = FUN_1404df960(local_478);
    if (cVar7 != '\0') {
      lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x8c));
      lVar8 = *(longlong *)(lVar8 + 0x200);
      if (lVar8 == 0) {
        local_498 = 0x164;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar8 = 0;
      }
      plVar9 = (longlong *)FUN_140265690(lVar8);
      plVar10 = *(longlong **)plVar9[6];
      plVar2 = (longlong *)*plVar9;
      while( true ) {
        plVar3 = (longlong *)plVar9[6];
        if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar9)) {
          _invalid_parameter_noinfo();
        }
        if (plVar10 == plVar3) break;
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar2;
        }
        if (plVar10 == *(longlong **)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar1 = (undefined4)plVar10[3];
        cVar7 = FUN_14042e9f0(param_1,uVar1);
        if (cVar7 == '\0') {
          local_488[0] = 0;
          local_484 = 0;
          FUN_14042fd70(param_1,uVar1,local_488,&local_484);
          uVar5 = local_484;
          bVar4 = local_488[0];
          cVar7 = FUN_1404df9b0(local_478,uVar1,local_488[0],local_484);
          if (cVar7 == '\0') {
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                      ((longlong *)(param_2 + 0x10),local_478);
            cVar7 = FUN_1404df960(local_478);
            if (cVar7 == '\0') {
              FUN_1404df8f0(local_478);
              return;
            }
            FUN_1404df9b0(local_478,uVar1,bVar4,uVar5);
          }
        }
        else {
          cVar7 = FUN_1404dfa20(local_478,uVar1,1);
          if (cVar7 == '\0') {
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                      ((longlong *)(param_2 + 0x10),local_478);
            cVar7 = FUN_1404df960(local_478);
            if (cVar7 == '\0') {
              local_498 = 0x242;
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1404df8f0(local_478);
              return;
            }
            FUN_1404dfa20(local_478,uVar1,1);
          }
        }
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
          plVar3 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
            cVar7 = *(char *)(*plVar3 + 0x29);
            plVar10 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (cVar7 == '\0') {
              cVar7 = *(char *)(*plVar3 + 0x29);
              plVar10 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar7 = *(char *)(plVar10[1] + 0x29);
            plVar6 = (longlong *)plVar10[1];
            plVar3 = plVar10;
            while ((plVar10 = plVar6, cVar7 == '\0' && (plVar3 == (longlong *)plVar10[2]))) {
              cVar7 = *(char *)(plVar10[1] + 0x29);
              plVar6 = (longlong *)plVar10[1];
              plVar3 = plVar10;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_478);
      FUN_1404df8f0(local_478);
      return;
    }
    local_498 = 0x233;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1404df8f0(local_478);
  }
  return;
}

// ==== CUserManager::helper_14044a0a0  @14044a0a0  [medium:callgraph-r2]  (orig: FUN_14044a0a0)
void FUN_14044a0a0(longlong param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  longlong lVar3;
  
  srand(param_2);
  lVar3 = 0x100;
  piVar2 = (int *)(param_1 + 0x538);
  do {
    iVar1 = rand();
    lVar3 = lVar3 + -1;
    *piVar2 = iVar1;
    piVar2 = piVar2 + 1;
  } while (lVar3 != 0);
  return;
}

// ==== CUserManager::helper_14044a0e0  @14044a0e0  [medium:callgraph-r3]  (orig: FUN_14044a0e0)
undefined8 FUN_14044a0e0(longlong param_1,longlong *param_2,int param_3)

{
  int iVar1;
  longlong *plVar2;
  
  if (*(char *)(param_1 + 0x10) == '\0') {
    *(longlong **)(param_1 + 8) = param_2;
    if (param_2 != (longlong *)0x0) {
      plVar2 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,&DAT_140951730);
      iVar1 = (**(code **)(*plVar2 + 0x40))(plVar2);
      if (iVar1 != param_3) {
        plVar2 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                           (*(longlong **)(param_1 + 8),&DAT_140951730);
        (**(code **)(*plVar2 + 0xb8))(plVar2,param_3);
      }
      return 1;
    }
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CUserManager::helper_14044a190  @14044a190  [medium:callgraph-r1]  (orig: FUN_14044a190)
void FUN_14044a190(longlong param_1,undefined4 param_2)

{
  char cVar1;
  byte bVar2;
  undefined4 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  cVar1 = FUN_14008abd0(uVar5);
  if (cVar1 != '\0') {
    uVar3 = FUN_140374050(param_1 + 0xe78);
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    param_2 = FUN_1400a72a0(uVar5,uVar3);
  }
  iVar4 = FUN_140371e80(param_1 + 0xe78);
  if (2 < iVar4) {
    iVar4 = 2;
  }
  bVar2 = FUN_140373ed0(param_1 + 0xe78);
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar6 + 0x160) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    uVar5 = *(undefined8 *)(lVar6 + 0x160);
  }
  uVar3 = FUN_140371e50(param_1 + 0xe78);
  FUN_1402752f0(uVar5,*(undefined4 *)(param_1 + 0xe80),param_2,iVar4,uVar3,bVar2 & 1);
  return;
}

// ==== CUserManager::helper_14044a2b0  @14044a2b0  [medium:callgraph-r2]  (orig: FUN_14044a2b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14044a2b0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined1 auStack_8a8 [32];
  undefined4 local_888;
  undefined4 local_878;
  undefined4 local_874;
  longlong local_870;
  longlong *local_868;
  longlong local_860;
  longlong *local_858;
  longlong local_850;
  longlong local_848;
  undefined8 local_840;
  char local_838 [1023];
  undefined1 local_439;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_840 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_8a8;
  local_878 = param_2;
  local_874 = param_2;
  local_850 = param_1;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  if (*(longlong *)(lVar4 + 0x170) == 0) {
    local_888 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else {
    uVar10 = *(undefined8 *)(lVar4 + 0x170);
  }
  cVar2 = FUN_140313960(uVar10,param_2);
  if (cVar2 == '\0') {
    _snprintf(local_838,0x400,PTR_s_SELECT___FROM_cq_item_WHERE_play_140962ea0);
    local_439 = 0;
    plVar5 = (longlong *)InstanceGet();
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,local_838,2);
    if (plVar5 != (longlong *)0x0) {
      local_868 = plVar5;
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      if (*(longlong *)(lVar4 + 0x170) == 0) {
        local_888 = 0x151;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar10 = 0;
      }
      else {
        uVar10 = *(undefined8 *)(lVar4 + 0x170);
      }
      FUN_140313a50(uVar10,param_2);
      local_860 = (**(code **)(*plVar5 + 0x40))(plVar5);
      local_870 = 0;
      while (lVar4 = local_870, local_870 < local_860) {
        (**(code **)(*plVar5 + 0x30))(plVar5,local_870);
        plVar6 = (longlong *)(**(code **)(*plVar5 + 0x38))(plVar5);
        if (plVar6 == (longlong *)0x0) {
          local_888 = 0x2be;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
          if (*(longlong *)(lVar7 + 0x170) == 0) {
            local_888 = 0x151;
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar10 = 0;
          }
          else {
            uVar10 = *(undefined8 *)(lVar7 + 0x170);
          }
          FUN_1403141e0(uVar10,param_2,0x25,plVar6);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,1);
          uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
          cVar2 = FUN_1400ff940(uVar3);
          if (cVar2 != '\0') {
            plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,0);
            (**(code **)(*plVar6 + 0x40))(plVar6);
            _snprintf(local_438,0x400,PTR_s_SELECT___FROM_cq_itemstatus_WHER_140962f80);
            local_39 = 0;
            plVar6 = (longlong *)InstanceGet();
            plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_438,2);
            local_858 = plVar6;
            lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
            if (0 < lVar7) {
              local_848 = 0;
              while (lVar1 = local_848, lVar4 = local_870, local_848 < lVar7) {
                (**(code **)(*plVar6 + 0x30))(plVar6,local_848);
                lVar4 = (**(code **)(*plVar6 + 0x38))(plVar6);
                if (lVar4 == 0) {
                  local_888 = 0x2d7;
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
                  if (*(longlong *)(lVar9 + 0x170) == 0) {
                    local_888 = 0x151;
                    log_InlineLogERROR(&DAT_1406d9c10);
                    uVar10 = 0;
                  }
                  else {
                    uVar10 = *(undefined8 *)(lVar9 + 0x170);
                  }
                  FUN_1403141e0(uVar10,local_878,0x26,lVar4);
                }
                local_848 = lVar1 + 1;
              }
            }
            (**(code **)*plVar6)(plVar6);
            local_858 = (longlong *)0x0;
            param_2 = local_878;
          }
        }
        local_870 = lVar4 + 1;
      }
      if (plVar5 != (longlong *)0x0) {
        (**(code **)*plVar5)(plVar5);
      }
    }
  }
  return;
}

// ==== CUserManager::helper_14044a6a0  @14044a6a0  [medium:callgraph-r1]  (orig: FUN_14044a6a0)
void FUN_14044a6a0(longlong *param_1)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 uVar9;
  undefined4 uVar10;
  undefined8 uVar11;
  
  uVar11 = 0xfffffffffffffffe;
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    uVar5 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar9 = 0;
  uVar4 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar5,uVar2,uVar4,1,1,PTR_s_SELECT___FROM_cq_itemstatus_WHER_140962e98,
                        uVar11);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_FROM_ITEMSTATUS_BY_USERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,2,PTR_s_SELECT___FROM_ghostcontract_WHER_140962ea8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_GHOSTCONTRACT_BYOWNERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,3,PTR_s_SELECT___FROM_cq_sys_leaveword_W_140962eb0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_SYS_LEAVEWORD_BYUSERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,4,PTR_s_SELECT_cq_leaveword____cq_user_n_140962eb8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_LEAVEWORD_BYUSERNAME = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,5,PTR_s_SELECT___FROM_cq_ast_prof_level_w_140962ec0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_SYS_AST_PROF_LEVEL_BYUSERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,6,PTR_s_SELECT___FROM_cq_competesponsor_W_140962ec8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_COMPETE_BYUSERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,7,PTR_s_SELECT___FROM_cq_vipminetime_WHE_140962ed0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_VIPMINETIME_BYUSERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,8,PTR_s_SELECT___FROM_cq_weapon_skill_WH_140962ed8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_WEAPONSKILL = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x28,PTR_s_SELECT___FROM_cq_magic_WHERE_own_140962fd0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_USER_MAGIC = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,9,PTR_s_SELECT___FROM_task_detail_WHERE_u_140962ee0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_FROM_TASKDETAIL_BY_USERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,10,PTR_s_SELECT_cq_pk_statistic____cq_use_140962ee8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_STATISTIC = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0xb,PTR_s_SELECT_cq_friend____cq_user_name_140962ef0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_FRIEND_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0xc,PTR_s_SELECT_cq_business____cq_user_na_140962ef8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_BUSINESS_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0xc,PTR_s_SELECT_cq_business_id__cq_busine_140962f00);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_BUSINESS_BY_BUSINESS = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0xd,PTR_s_SELECT_cq_enemy____cq_user_name_F_140962f08);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_ENEMY_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0xe,PTR_s_SELECT___FROM_cq_pointrecord_WHE_140962f10);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_POINTRECORD_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x15,PTR_s_SELECT___FROM_cq_statistic_WHERE_140962f48);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_STATISTIC = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x16,PTR_s_SELECT___FROM_cq_killmonster_WHE_140962f50);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_KILLMONSTER = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x17,PTR_s_SELECT___FROM_cq_statistic_daily_140962f58);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_STATISTIC_DAILY = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x18,PTR_s_SELECT___FROM_cq_achievement_WHE_140962f60);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_ACHIEVEMENT_BYUSERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x19,PTR_s_SELECT___FROM_cq_mail_where_rece_140962f68);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_MAIL_BY_RECEIVERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x1a,PTR_s_SELECT___FROM_cq_fate_player_whe_140962f70);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_PLAYER_FATE_BY_PLAYERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x1b,PTR_s_SELECT___FROM_cq_fate_protect_wh_140962f78);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SELECT_PLAYER_FATE_PROTECT_BY_PLAYERID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x1d,PTR_s_SELECT___FROM_cq_golden_league_d_140962f88);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_GOLDEN_LEAGUE_DATA_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x1e,PTR_s_SELECT___FROM_cq_jianghu_player_W_140962f90)
  ;
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_JIANG_HU_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x20,PTR_s_SELECT___FROM_cq_jianghu_player__140962fa0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_JIANG_HU_POWER_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x1f,PTR_s_SELECT___FROM_cq_jianghu_caltiva_140962f98);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR(
                      "User[%u] PrepareRecordFail at SQL_SELECT_JIANG_HU_CALTIVATE_TIMES_BY_UID = %s"
                      );
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x21,PTR_s_SELECT___FROM_flower_WHERE_playe_140962fa8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_TODAY_FLOWER_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x22,PTR_s_SELECT___FROM_cq_operating_user__140962fb0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_OPERATING_USER_INFO_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x23,PTR_s_SELECT___FROM_cq_inner_strength__140962fb8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_INNER_STRENGTH_PLAYER_BY_UID = %s")
    ;
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x24,PTR_s_SELECT___FROM_cq_inner_strength__140962fc0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_INNER_STRENGTH_SECRET_BY_UID = %s")
    ;
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x2b,PTR_s_SELECT___FROM_cq_pk_bonus_WHERE_t_140962fe8)
  ;
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SELECT_PK_BONUS_TARGET_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  uVar10 = 0x2c;
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x2c,PTR_s_SELECT___FROM_cq_pk_bonus_WHERE_h_140962ff0)
  ;
  if (cVar1 == '\0') {
    uVar10 = 0x215;
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SELECT_PK_BONUS_HUNTER_BY_UID = %s");
  }
  lVar3 = param_1[0x1e2];
  lVar6 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    uVar10 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar6 + 0x170);
  }
  cVar1 = FUN_140314eb0(uVar11,(int)lVar3,0,PTR_s_SELECT___FROM_cq_bonus_WHERE_id__140963000,uVar10)
  ;
  if (cVar1 == '\0') {
    uVar10 = 0x21b;
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User:%u Account:%u PrepareRecordFail at SELECT_BONUS_BY_ACCOUNT_ID = %s");
  }
  lVar3 = param_1[0x1e2];
  lVar6 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    uVar10 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar6 + 0x170);
  }
  cVar1 = FUN_140314eb0(uVar11,(int)lVar3,1,PTR_s_SELECT___FROM_emoney_card_WHERE_a_140963008,uVar10
                       );
  if (cVar1 == '\0') {
    uVar10 = 0x220;
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR(
                      "User:%u Account:%u PrepareRecordFail at SELECT_EMONEY_CARD1_BY_ACCOUNT_ID = %s"
                      );
  }
  lVar3 = param_1[0x1e2];
  lVar6 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    uVar10 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar6 + 0x170);
  }
  cVar1 = FUN_140314eb0(uVar11,(int)lVar3,2,PTR_s_SELECT___FROM_emoney_card2_WHERE_140963010,uVar10)
  ;
  if (cVar1 == '\0') {
    uVar10 = 0x225;
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR(
                      "User:%u Account:%u PrepareRecordFail at SELECT_EMONEY_CARD2_BY_ACCOUNT_ID = %s"
                      );
  }
  lVar3 = param_1[0x1e2];
  lVar6 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    uVar10 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar6 + 0x170);
  }
  cVar1 = FUN_140314eb0(uVar11,(int)lVar3,3,PTR_s_SELECT___FROM_emoney_card3_WHERE_140963018,uVar10)
  ;
  if (cVar1 == '\0') {
    uVar10 = 0x22a;
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR(
                      "User:%u Account:%u PrepareRecordFail at SELECT_EMONEY_CARD3_BY_ACCOUNT_ID = %s"
                      );
  }
  lVar3 = param_1[0x1e2];
  lVar6 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar6 + 0x170) == 0) {
    uVar10 = 0x151;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar6 + 0x170);
  }
  cVar1 = FUN_140314eb0(uVar11,(int)lVar3,4,PTR_s_SELECT___FROM_emoney_card4_WHERE_140963020,uVar10)
  ;
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR(
                      "User:%u Account:%u PrepareRecordFail at SELECT_EMONEY_CARD4_BY_ACCOUNT_ID = %s"
                      );
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x27,PTR_s_SELECT___FROM_cq_activity_user_t_140962fc8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_ACTIVITY_USER_TASK_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x29,PTR_s_SELECT___FROM_cq_player_process__140962fd8);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_PROCESS_GOAL_BY_UID = %s");
  }
  lVar3 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar3 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = uVar9;
  }
  else {
    uVar11 = *(undefined8 *)(lVar3 + 0x170);
  }
  uVar5 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_140314a50(uVar11,uVar2,uVar5,1,0x2a,PTR_s_SELECT___FROM_cq_player_process__140962fe0);
  if (cVar1 == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_PROCESS_TASK_BY_UID = %s");
  }
  uVar11 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008ac00(uVar11);
  if (cVar1 != '\0') {
    lVar3 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar3 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar9 = *(undefined8 *)(lVar3 + 0x170);
    }
    uVar11 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    cVar1 = FUN_140314a50(uVar9,uVar2,uVar11,1,0x2d,PTR_s_SELECT___FROM_cq_sign_everyday_W_140962ff8
                         );
    if (cVar1 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogERROR("User[%u] PrepareRecordFail at SQL_SELECT_SIGN_BY_UID = %s");
    }
  }
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  FUN_14044a2b0(param_1,uVar2);
  uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  FUN_14044a2b0(param_1,uVar2);
  plVar7 = (longlong *)CurrentInstanceGet();
  if (plVar7 != (longlong *)0x0) {
    plVar8 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,0x10);
    if (plVar8 != (longlong *)0x0) {
      lVar3 = *plVar8;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar3 + 0xd0))(plVar8,uVar2);
    }
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,0x12);
    if (plVar7 != (longlong *)0x0) {
      lVar3 = *plVar7;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar3 + 0x90))(plVar7,uVar2);
    }
  }
  return;
}

// ==== CUserManager::helper_14044c9e0  @14044c9e0  [medium:callgraph-r2]  (orig: FUN_14044c9e0)
undefined8 FUN_14044c9e0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  puVar4 = (undefined8 *)param_2[3];
  if ((undefined8 *)param_2[4] < puVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  while( true ) {
    puVar2 = (undefined8 *)param_2[4];
    if (puVar2 < (undefined8 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar4 == puVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *plVar1;
    }
    if (*(undefined8 **)(lVar3 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    lVar3 = FUN_14039e180(*puVar4);
    if (lVar3 != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x1110) + 0x20))
                (*(longlong **)(param_1 + 0x1110),lVar3);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *plVar1;
    }
    if (*(undefined8 **)(lVar3 + 0x20) <= puVar4) {
      _invalid_parameter_noinfo();
    }
    puVar4 = puVar4 + 1;
  }
  return 1;
}

// ==== CUserManager::helper_14044cac0  @14044cac0  [medium:callgraph-r2]  (orig: FUN_14044cac0)
undefined8 FUN_14044cac0(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *local_res18;
  undefined4 local_res20;
  undefined4 uStackX_24;
  undefined8 local_60;
  longlong *local_58;
  longlong *local_50 [2];
  char local_40;
  
  FUN_140190030(param_1 + 0x40);
  plVar7 = (longlong *)param_2[3];
  lVar8 = 0;
  if ((longlong *)param_2[4] < plVar7) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  while( true ) {
    plVar4 = (longlong *)param_2[4];
    local_50[0] = (longlong *)0x0;
    if (plVar4 < (longlong *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_50[0] = (longlong *)*param_2;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_50[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar4) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    local_res18 = (longlong *)*plVar7;
    if (local_res18 != (longlong *)0x0) {
      plVar4 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,3);
      plVar5 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,2);
      uVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
      local_res20 = (**(code **)(*plVar5 + 0x40))(plVar5);
      local_60 = CONCAT44(uVar3,local_res20);
      local_58 = local_res18;
      uStackX_24 = uVar3;
      FUN_140384480(param_1 + 0x40,local_50,&local_60);
      if (local_40 == '\0') {
        lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        if (*(longlong *)(lVar6 + 0x210) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          lVar6 = lVar8;
        }
        else {
          lVar6 = *(longlong *)(lVar6 + 0x210);
        }
        cVar2 = FUN_14028dc40(lVar6,0,&local_res18,0);
        if (cVar2 == '\0') {
          (**(code **)(*local_res18 + 0x40))(local_res18,0);
          if (local_res18 != (longlong *)0x0) {
            (**(code **)*local_res18)(local_res18,1);
            local_res18 = (longlong *)0x0;
          }
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  }
  return 1;
}

// ==== CUserManager::helper_14044cd00  @14044cd00  [medium:callgraph-r2]  (orig: FUN_14044cd00)
undefined8 FUN_14044cd00(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *local_res18;
  undefined4 local_res20;
  undefined4 uStackX_24;
  undefined8 local_60;
  longlong *local_58;
  longlong *local_50 [2];
  char local_40;
  
  FUN_140190030(param_1 + 0x80);
  plVar7 = (longlong *)param_2[3];
  lVar8 = 0;
  if ((longlong *)param_2[4] < plVar7) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  while( true ) {
    plVar4 = (longlong *)param_2[4];
    local_50[0] = (longlong *)0x0;
    if (plVar4 < (longlong *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_50[0] = (longlong *)*param_2;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_50[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar4) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    local_res18 = (longlong *)*plVar7;
    if (local_res18 != (longlong *)0x0) {
      plVar4 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,3);
      plVar5 = (longlong *)(**(code **)(*local_res18 + 0x10))(local_res18,2);
      uVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
      local_res20 = (**(code **)(*plVar5 + 0x40))(plVar5);
      local_60 = CONCAT44(uVar3,local_res20);
      local_58 = local_res18;
      uStackX_24 = uVar3;
      FUN_140384480(param_1 + 0x80,local_50,&local_60);
      if (local_40 == '\0') {
        lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        if (*(longlong *)(lVar6 + 0x210) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          lVar6 = lVar8;
        }
        else {
          lVar6 = *(longlong *)(lVar6 + 0x210);
        }
        cVar2 = FUN_14028dc40(lVar6,6,&local_res18);
        if (cVar2 == '\0') {
          (**(code **)(*local_res18 + 0x40))(local_res18,0);
          if (local_res18 != (longlong *)0x0) {
            (**(code **)*local_res18)(local_res18,1);
            local_res18 = (longlong *)0x0;
          }
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar1;
    }
    if (*(longlong **)(lVar6 + 0x20) <= plVar7) {
      _invalid_parameter_noinfo();
    }
    plVar7 = plVar7 + 1;
  }
  return 1;
}

// ==== CUserManager::helper_14044cf50  @14044cf50  [medium:callgraph-r2]  (orig: FUN_14044cf50)
undefined8 FUN_14044cf50(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 local_60;
  longlong *local_58;
  longlong *local_50;
  longlong *local_40 [2];
  char local_30;
  
  FUN_1401900b0(param_1 + 0xc0);
  puVar8 = (undefined8 *)param_2[3];
  lVar10 = 0;
  local_50 = (longlong *)0x0;
  if ((undefined8 *)param_2[4] < puVar8) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  local_50 = plVar1;
  while( true ) {
    puVar2 = (undefined8 *)param_2[4];
    local_40[0] = (longlong *)0x0;
    if (puVar2 < (undefined8 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    local_40[0] = (longlong *)*param_2;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_40[0])) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 == puVar2) break;
    plVar6 = (longlong *)FUN_140383970(0);
    if (plVar6 == (longlong *)0x0) {
      log_InlineLogERROR(
                        "CUser::AsynCreateStatisticDailySet, failed in CUserStatisticDailyData::CreateNew"
                        );
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar1;
      }
      if (*(undefined8 **)(lVar9 + 0x20) <= puVar8) {
        _invalid_parameter_noinfo();
      }
      plVar7 = (longlong *)
               (**(code **)(*(longlong *)*puVar8 + 0x20))((longlong *)*puVar8,&DAT_140951730);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar10;
      }
      else {
        lVar9 = *plVar1;
      }
      if (*(undefined8 **)(lVar9 + 0x20) <= puVar8) {
        _invalid_parameter_noinfo();
      }
      uVar4 = (**(code **)(*plVar7 + 0x40))(plVar7);
      cVar3 = FUN_14044a0e0(plVar6,*puVar8,uVar4);
      if (cVar3 == '\0') {
        FUN_140382710(plVar6);
        log_InlineLogERROR(
                          "CUser::AsynCreateStatisticDailySet, failed in CUserStatisticDailyData::Create"
                          );
      }
      else {
        uVar4 = (**(code **)(*plVar6 + 0x10))(plVar6,3);
        uVar5 = (**(code **)(*plVar6 + 0x10))(plVar6,2);
        local_60 = CONCAT44(uVar4,uVar5);
        local_58 = plVar6;
        FUN_140384730(param_1 + 0xc0,local_40,&local_60);
        if (local_30 == '\0') {
          (**(code **)(*plVar6 + 0x48))(plVar6,0);
          FUN_140382710();
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar10;
    }
    else {
      lVar9 = *plVar1;
    }
    if (*(undefined8 **)(lVar9 + 0x20) <= puVar8) {
      _invalid_parameter_noinfo();
    }
    puVar8 = puVar8 + 1;
  }
  return 1;
}

// ==== CUserManager::helper_14044d150  @14044d150  [medium:callgraph-r2]  (orig: FUN_14044d150)
undefined8 FUN_14044d150(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  char cVar5;
  longlong *plVar6;
  char *pcVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined4 local_50 [2];
  longlong local_48;
  undefined1 local_40 [24];
  
  plVar9 = (longlong *)param_2[3];
  if ((longlong *)param_2[4] < plVar9) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  do {
    plVar2 = (longlong *)param_2[4];
    if (plVar2 < (longlong *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar2) {
      uVar3 = *(ulonglong *)(param_1 + 0xbf8);
      if (uVar3 < *(ulonglong *)(param_1 + 0xbf0)) {
        _invalid_parameter_noinfo();
      }
      lVar8 = *(longlong *)(param_1 + 0xbd8);
      uVar4 = *(ulonglong *)(param_1 + 0xbf0);
      if (*(ulonglong *)(param_1 + 0xbf8) < uVar4) {
        _invalid_parameter_noinfo();
      }
      if ((lVar8 == 0) || (lVar8 != *(longlong *)(param_1 + 0xbd8))) {
        _invalid_parameter_noinfo();
      }
      FUN_1401a5f70(uVar4,uVar3,(longlong)(uVar3 - uVar4) >> 3,FUN_1401603d0);
      return 1;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (*(longlong **)(lVar8 + 0x20) <= plVar9) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)*plVar9;
    if (plVar2 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,7);
      pcVar7 = (char *)(**(code **)(*plVar6 + 0x78))();
      lVar8 = -1;
      do {
        if (lVar8 == 0) break;
        lVar8 = lVar8 + -1;
        cVar5 = *pcVar7;
        pcVar7 = pcVar7 + 1;
      } while (cVar5 != '\0');
      if (lVar8 == -2) {
        (**(code **)(*plVar2 + 0x40))(plVar2,0);
        (**(code **)*plVar2)(plVar2);
      }
      else {
        lVar8 = FUN_1403b3a70();
        if (lVar8 != 0) {
          cVar5 = FUN_1403b34f0(lVar8);
          if (cVar5 == '\0') {
            FUN_1403b34d0(lVar8);
          }
          else {
            local_50[0] = FUN_1403b3660(lVar8,2);
            local_48 = lVar8;
            FUN_14019e540(param_1 + 0xb98,local_40,local_50);
            FUN_1401af280(param_1 + 0xbd8);
          }
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (*(longlong **)(lVar8 + 0x20) <= plVar9) {
      _invalid_parameter_noinfo();
    }
    plVar9 = plVar9 + 1;
  } while( true );
}

// ==== CUserManager::helper_14044d3a0  @14044d3a0  [medium:callgraph-r1]  (orig: FUN_14044d3a0)
undefined8 FUN_14044d3a0(longlong *param_1)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong lVar7;
  longlong *local_40 [3];
  longlong *local_28;
  longlong *local_20;
  undefined8 local_18;
  
  local_40[0] = operator_new(8);
  if (local_40[0] == (longlong *)0x0) {
    local_40[0] = (longlong *)0x0;
  }
  else {
    *local_40[0] = (longlong)local_40;
  }
  lVar7 = 0;
  local_28 = (longlong *)0x0;
  local_20 = (longlong *)0x0;
  local_18 = 0;
  lVar5 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar5 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar5 = lVar7;
  }
  else {
    lVar5 = *(longlong *)(lVar5 + 0x170);
  }
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(lVar5,local_40,uVar3,7);
  plVar1 = local_28;
  uVar6 = (longlong)local_20 - (longlong)local_28 >> 3;
  if (uVar6 == 1) {
    if (local_20 < local_28) {
      _invalid_parameter_noinfo();
    }
    if (local_40[0] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar7;
    }
    else {
      lVar5 = *local_40[0];
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar1) {
      _invalid_parameter_noinfo();
    }
    param_1[600] = *plVar1;
  }
  else if (1 < uVar6) {
    log_InlineLogWARNING("VipMineTime : vecRec.size() > 1.");
  }
  FUN_1400179f0(local_40);
  lVar5 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar5 + 0x170) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar5 = lVar7;
  }
  else {
    lVar5 = *(longlong *)(lVar5 + 0x170);
  }
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(lVar5,local_40,uVar3,10);
  cVar2 = FUN_14044d150(param_1,local_40);
  if (cVar2 == '\0') {
    (**(code **)(*param_1 + 8))(param_1);
    log_InlineLogERROR("CUser::Create, failed in LoadPKStatisticData(%u)");
    if (local_28 != (longlong *)0x0) {
      operator_delete(local_28);
    }
    local_28 = (longlong *)0x0;
    local_20 = (longlong *)0x0;
    local_18 = 0;
    operator_delete(local_40[0]);
  }
  else {
    FUN_1400179f0(local_40);
    lVar5 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar5 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = lVar7;
    }
    else {
      lVar5 = *(longlong *)(lVar5 + 0x170);
    }
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    FUN_140313fc0(lVar5,local_40,uVar3,8);
    iVar4 = FUN_14044c9e0(param_1,local_40);
    if (iVar4 == 0) {
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogERROR("CUser::Create, failed in AsynCreateWeaponSkill(%u)");
      if (local_28 != (longlong *)0x0) {
        operator_delete(local_28);
      }
      local_28 = (longlong *)0x0;
      local_20 = (longlong *)0x0;
      local_18 = 0;
      operator_delete(local_40[0]);
    }
    else {
      FUN_1400179f0(local_40);
      lVar5 = FUN_140008520((int)param_1[0x246]);
      if (*(longlong *)(lVar5 + 0x170) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar5 = lVar7;
      }
      else {
        lVar5 = *(longlong *)(lVar5 + 0x170);
      }
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      FUN_140313fc0(lVar5,local_40,uVar3,9);
      if (param_1[0x223] != 0) {
        uVar3 = (**(code **)(*param_1 + 8))(param_1);
        cVar2 = FUN_1403bb940(param_1[0x223],uVar3,local_40);
        if (cVar2 != '\0') {
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          FUN_14044a0a0(param_1,uVar3);
          FUN_1400179f0(local_40);
          lVar5 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar5 + 0x170) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar5 = lVar7;
          }
          else {
            lVar5 = *(longlong *)(lVar5 + 0x170);
          }
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          FUN_140313fc0(lVar5,local_40,uVar3,0x15);
          FUN_14044cac0(param_1,local_40);
          FUN_1400179f0(local_40);
          lVar5 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar5 + 0x170) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar5 = lVar7;
          }
          else {
            lVar5 = *(longlong *)(lVar5 + 0x170);
          }
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          FUN_140313fc0(lVar5,local_40,uVar3,0x16);
          FUN_14044cd00(param_1,local_40);
          FUN_1400179f0(local_40);
          lVar5 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar5 + 0x170) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            lVar7 = *(longlong *)(lVar5 + 0x170);
          }
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          FUN_140313fc0(lVar7,local_40,uVar3,0x17);
          FUN_14044cf50(param_1,local_40);
          if (local_28 != (longlong *)0x0) {
            operator_delete(local_28);
          }
          local_28 = (longlong *)0x0;
          local_20 = (longlong *)0x0;
          local_18 = 0;
          operator_delete(local_40[0]);
          return 1;
        }
      }
      (**(code **)(*param_1 + 8))(param_1);
      log_InlineLogERROR("CUser::Create, failed in m_pUserTaskDetail->Create(%u)");
      if (local_28 != (longlong *)0x0) {
        operator_delete(local_28);
      }
      local_28 = (longlong *)0x0;
      local_20 = (longlong *)0x0;
      local_18 = 0;
      operator_delete(local_40[0]);
    }
  }
  return 0;
}

// ==== CUserManager::helper_14044d940  @14044d940  [medium:callgraph-r0]  (orig: FUN_14044d940)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_14044d940(longlong param_1,uint param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
             )

{
  char cVar1;
  byte bVar2;
  undefined1 uVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  tm *ptVar8;
  undefined1 auStack_4f8 [32];
  int local_4d8;
  int local_4d0;
  int local_4c8;
  int local_4c0;
  int local_4b8;
  int local_4a8 [2];
  int local_4a0;
  undefined4 local_49c;
  undefined4 local_498;
  undefined4 local_490 [2];
  undefined4 local_488;
  undefined4 local_484;
  int local_480;
  __time32_t local_47c;
  undefined4 local_478;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_478 = param_4;
  if ((param_2 < 0xe) ||
     ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= (ulonglong)param_2)) {
    local_4d8 = 0x16;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  *(uint *)(param_1 + 0x1230) = param_2;
  *(undefined4 *)(param_1 + 0x122c) = param_3;
  FUN_140008520((ulonglong)param_2);
  InstanceGet();
  *(undefined4 *)(param_1 + 0x10e0) = 0;
  *(undefined4 *)(param_1 + 0x10e4) = 0;
  *(undefined2 *)(param_1 + 0x10e8) = 0;
  *(undefined4 *)(param_1 + 0x11e0) = 0;
  *(undefined4 *)(param_1 + 0x10ec) = 0;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  uVar5 = InstanceGet();
  cVar1 = FUN_1403756b0(param_1 + 0xe78,param_4,uVar5);
  if (cVar1 == '\0') {
    log_InlineLogERROR("CUser::Create, failed in create user(%u) data");
    return 0;
  }
  *(undefined2 *)(param_1 + 0xf94) = 100;
  *(undefined2 *)(param_1 + 0xf92) = 0;
  *(undefined1 *)(param_1 + 0xf90) = 1;
  local_4a8[0] = 0;
  if (*(int *)(param_1 + 0xfb0) == 1) {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    cVar1 = FUN_14008abf0(uVar5);
    if (cVar1 == '\0') {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      plVar6 = (longlong *)FUN_1400876b0(uVar5);
      lVar7 = (**(code **)(*plVar6 + 0x28))(plVar6,0x259);
      if (lVar7 == 0) {
        local_4d8 = 0x32;
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      FUN_1402c6f50(lVar7,local_4a8,&local_488);
      local_4a8[0] = 0x259;
      *(undefined4 *)(param_1 + 0x10d8) = local_488;
      *(undefined4 *)(param_1 + 0x10dc) = local_484;
      FUN_1401a41f0(param_1,0x259);
      goto LAB_14044db3d;
    }
  }
  *(uint *)(param_1 + 0x10d8) = (uint)*(ushort *)(param_1 + 0xf0c);
  *(uint *)(param_1 + 0x10dc) = (uint)*(ushort *)(param_1 + 0xf0e);
  local_4a8[0] = *(int *)(param_1 + 0xf08);
  FUN_1401a41f0(param_1);
LAB_14044db3d:
  local_4a0 = 0;
  local_49c = 0;
  local_498 = 0;
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  uVar5 = FUN_1400d6610(uVar5);
  FUN_140006c50(uVar5,&local_4a0);
  plVar6 = (longlong *)FUN_140087ed0();
  cVar1 = (**(code **)(*plVar6 + 0x668))(plVar6);
  if (cVar1 != '\0') {
    plVar6 = (longlong *)FUN_140087ed0();
    iVar4 = (**(code **)(*plVar6 + 0x510))(plVar6,param_4);
    if (iVar4 != 0) {
      plVar6 = (longlong *)FUN_140087ed0();
      cVar1 = (**(code **)(*plVar6 + 0x418))(plVar6,param_4);
      if (cVar1 == '\0') {
        local_480 = 0;
        local_490[0] = 0;
        local_488 = 0;
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        uVar5 = FUN_1400d6610(uVar5);
        FUN_140006d80(uVar5,&local_480,local_490,&local_488);
        if (local_4a8[0] == local_480) {
          *(undefined4 *)(param_1 + 0x10d8) = local_490[0];
          *(undefined4 *)(param_1 + 0x10dc) = local_488;
        }
      }
    }
  }
  cVar1 = FUN_1401a4030(param_1,local_4a8[0]);
  if (cVar1 == '\0') {
    *(undefined4 *)(param_1 + 0x10d8) = local_49c;
    *(undefined4 *)(param_1 + 0x10dc) = local_498;
    local_4a8[0] = local_4a0;
  }
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  plVar6 = (longlong *)FUN_1400876b0(uVar5);
  lVar7 = (**(code **)(*plVar6 + 0x28))(plVar6,local_4a8[0]);
  *(longlong *)(param_1 + 0x1100) = lVar7;
  if ((lVar7 == 0) ||
     (cVar1 = FUN_1402c3cc0(lVar7,*(undefined4 *)(param_1 + 0x10d8),
                            *(undefined4 *)(param_1 + 0x10dc)), cVar1 == '\0')) {
    iVar4 = local_4a0;
    *(undefined4 *)(param_1 + 0x10d8) = local_49c;
    *(undefined4 *)(param_1 + 0x10dc) = local_498;
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    plVar6 = (longlong *)FUN_1400876b0(uVar5);
    lVar7 = (**(code **)(*plVar6 + 0x28))(plVar6,iVar4);
    *(longlong *)(param_1 + 0x1100) = lVar7;
    if (lVar7 == 0) {
      local_4d8 = 0x69;
      log_InlineLogERROR(&DAT_1406d9c10);
      return 0;
    }
  }
  else if (*(int *)(param_1 + 0xfb0) != 1) {
    plVar6 = *(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1100) + 0x58) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    bVar2 = (**(code **)(*plVar6 + 0x58))(plVar6);
    iVar4 = local_4a0;
    if ((bVar2 >> 2 & 1) != 0) {
      *(undefined4 *)(param_1 + 0x10d8) = local_49c;
      *(undefined4 *)(param_1 + 0x10dc) = local_498;
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
      plVar6 = (longlong *)FUN_1400876b0(uVar5);
      lVar7 = (**(code **)(*plVar6 + 0x28))(plVar6,iVar4);
      *(longlong *)(param_1 + 0x1100) = lVar7;
      if (lVar7 == 0) {
        local_4d8 = 0x74;
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
    }
  }
  FUN_14044a190(param_1,param_5);
  FUN_14016eb60(param_1);
  FUN_14044a6a0(param_1);
  cVar1 = FUN_14044d3a0(param_1);
  uVar3 = 0;
  if (cVar1 != '\0') {
    if (*(longlong *)(param_1 + 0x1120) == 0) {
      log_InlineLogERROR("CUser::Create, failed in initializing m_pBattleSystem(%u)");
      uVar3 = 0;
    }
    else {
      cVar1 = FUN_1403b4190(param_1 + 0x3a0,param_2,param_1);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CUser::Create, failed in m_interact.Init(%u)");
        uVar3 = 0;
      }
      else {
        FUN_140371cf0(param_1 + 0xe78);
        FUN_140371d50(param_1 + 0xe78);
        local_47c = _time32((__time32_t *)0x0);
        ptVar8 = _localtime32(&local_47c);
        uVar3 = 0;
        if (ptVar8 != (tm *)0x0) {
          FUN_1403a6980(local_468);
          local_4b8 = ptVar8->tm_sec;
          local_4c0 = ptVar8->tm_min;
          local_4c8 = ptVar8->tm_hour;
          local_4d0 = ptVar8->tm_mday;
          local_4d8 = ptVar8->tm_yday;
          iVar4 = FUN_1403a6a30(local_468,0,ptVar8->tm_year,ptVar8->tm_mon);
          if (iVar4 == 0) {
            FUN_1403a69d0(local_468);
            uVar3 = 1;
          }
          else {
            (**(code **)(*(longlong *)(param_1 + 0x10) + 0x350))
                      ((longlong *)(param_1 + 0x10),local_468);
            FUN_1403a69d0(local_468);
            uVar3 = 1;
          }
        }
      }
    }
  }
  return uVar3;
}

// ==== CUserManager::helper_14044e030  @14044e030  [medium:callgraph-r0]  (orig: FUN_14044e030)
undefined8 FUN_14044e030(longlong param_1,int param_2,undefined4 *param_3,undefined4 param_4)

{
  ulong uVar1;
  uint uVar2;
  byte bVar3;
  
  if (param_2 == 0) {
    return 0;
  }
  FUN_1402b5600();
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = *param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = *(undefined2 *)((longlong)param_3 + 0x1da);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 10) = param_3[0xb];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = *(undefined2 *)(param_3 + 0xc);
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x10) = *(undefined8 *)(param_3 + 0xe);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_3[0x49];
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = *(undefined8 *)(param_3 + 0x14);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x24) = param_3[0x1c];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x28) = param_3[0x1e];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x2c) = param_3[0x1f];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x30) = param_3[0x2a];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x34) = param_3[0x4f];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x38) = *(undefined2 *)(param_3 + 0x16);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x3a) = *(undefined2 *)(param_3 + 0x17);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x3c) = *(undefined2 *)((longlong)param_3 + 0x5e)
  ;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x3e) = *(undefined2 *)(param_3 + 0x18);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x40) = *(undefined2 *)((longlong)param_3 + 0x62)
  ;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x42) = param_3[0x1a];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x46) = *(undefined2 *)(param_3 + 0x1b);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x48) = *(undefined2 *)(param_3 + 0x1d);
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x4a) = *(undefined1 *)(param_3 + 0x13);
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x4b) = *(undefined1 *)((longlong)param_3 + 0x6e)
  ;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x4d) = *(undefined1 *)((longlong)param_3 + 0x5b)
  ;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x4c) = *(undefined1 *)((longlong)param_3 + 0x5a)
  ;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x4e) = *(undefined1 *)((longlong)param_3 + 0x76)
  ;
  bVar3 = 2;
  if (*(byte *)(param_3 + 0x20) < 3) {
    bVar3 = *(byte *)(param_3 + 0x20);
  }
  *(byte *)(*(longlong *)(param_1 + 0x428) + 0x4f) = bVar3;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x50) = *(undefined1 *)(param_3 + 0x19);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x51) = param_3[0x30];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x55) = param_3[0x31];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x59) = *(undefined2 *)(param_3 + 0x59);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x5b) =
       *(undefined2 *)((longlong)param_3 + 0x166);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x5d) = *(undefined2 *)(param_3 + 0x5a);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x5f) =
       *(undefined2 *)((longlong)param_3 + 0x16a);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x61) = param_4;
  *(ushort *)(*(longlong *)(param_1 + 0x428) + 0x65) = (ushort)*(byte *)(param_3 + 0x6c);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x67) = param_3[0x6d];
  tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),(char *)(param_3 + 2));
  tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),(char *)(param_3 + 6));
  tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),(char *)(param_3 + 0x7a));
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x6b) = *(undefined1 *)(param_3 + 0x6f);
  *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x6c) = *(undefined8 *)(param_3 + 0x70);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x74) = param_3[0x6e];
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x78) = *(undefined2 *)(param_3 + 0x78);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x7a) = param_3[0x85];
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0x3ee;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar2 + 0x7e;
  return 1;
}

// ==== CUserManager::helper_14044e4c0  @14044e4c0  [medium:callgraph-r0]  (orig: FUN_14044e4c0)
undefined8 FUN_14044e4c0(longlong param_1,undefined4 param_2)

{
  FUN_1402b5600();
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(param_1 + 8) = 0x469;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return 1;
}

// ==== CUserManager::helper_14044e730  @14044e730  [medium:callgraph-r0]  (orig: FUN_14044e730)
undefined8 FUN_14044e730(longlong param_1)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  *(undefined4 *)(param_1 + 8) = 0x8d5;
  return 1;
}

// ==== CUserManager::helper_14044ed00  @14044ed00  [medium:callgraph-r1]  (orig: FUN_14044ed00)
undefined8 FUN_14044ed00(longlong param_1,undefined2 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  if (*(undefined2 **)(param_1 + 0x428) == (undefined2 *)0x0) {
    return 0;
  }
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = 0;
  *(undefined4 *)(param_1 + 8) = 0x9c52;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CUserManager::helper_14044ed40  @14044ed40  [medium:callgraph-r1]  (orig: FUN_14044ed40)
ulonglong FUN_14044ed40(longlong param_1,undefined4 param_2)

{
  ulonglong uVar1;
  int *piVar2;
  longlong lVar3;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 4;
  if (0x3ff < uVar1) {
    return uVar1 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 4;
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0xc +
   (longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 8) * 4) = param_2;
  lVar3 = *(longlong *)(param_1 + 0x428);
  piVar2 = (int *)(lVar3 + 8);
  *piVar2 = *piVar2 + 1;
  return CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
}

// ==== CUserManager::helper_140479610  @140479610  [medium:callgraph-r1]  (orig: FUN_140479610)
undefined8 FUN_140479610(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    uVar4 = 0;
  }
  else {
    local_60[0] = operator_new(8);
    if (local_60[0] == (longlong *)0x0) {
      local_60[0] = (longlong *)0x0;
    }
    else {
      *local_60[0] = (longlong)local_60;
    }
    lVar9 = 0;
    local_48 = (longlong *)0x0;
    local_40 = (longlong *)0x0;
    local_38 = 0;
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    lVar8 = *(longlong *)(lVar5 + 0x170);
    if (*(longlong *)(lVar5 + 0x170) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = lVar9;
    }
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 8))();
    FUN_140313fc0(lVar8,local_60,uVar3,0x1a);
    uVar10 = (longlong)local_40 - (longlong)local_48 >> 3;
    if (uVar10 == 0) {
      if (local_48 != (longlong *)0x0) {
        operator_delete(local_48);
      }
      local_48 = (longlong *)0x0;
      local_40 = (longlong *)0x0;
      local_38 = 0;
      operator_delete(local_60[0]);
      uVar4 = 0;
    }
    else {
      if (uVar10 == 1) {
        puVar6 = (undefined8 *)FUN_1400cfc10(local_60);
        *(undefined8 *)(param_1 + 0x20) = *puVar6;
      }
      else if (1 < uVar10) {
        puVar6 = (undefined8 *)FUN_1400cfc10(local_60);
        plVar7 = local_48;
        *(undefined8 *)(param_1 + 0x20) = *puVar6;
        if (((longlong)local_40 - (longlong)local_48 & 0xfffffffffffffff8U) != 0) {
          local_40 = local_40 + -1;
        }
        plVar1 = local_60[0];
        if (local_40 < local_48) {
          _invalid_parameter_noinfo();
          plVar1 = local_60[0];
        }
        while( true ) {
          plVar2 = local_40;
          if (local_40 < local_48) {
            _invalid_parameter_noinfo();
          }
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_60[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar7 == plVar2) break;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = lVar9;
          }
          else {
            lVar8 = *plVar1;
          }
          if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
            _invalid_parameter_noinfo();
          }
          puVar6 = (undefined8 *)*plVar7;
          if (puVar6 != (undefined8 *)0x0) {
            (**(code **)*puVar6)(puVar6,1);
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = lVar9;
          }
          else {
            lVar8 = *plVar1;
          }
          if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
            _invalid_parameter_noinfo();
          }
          plVar7 = plVar7 + 1;
        }
      }
      FUN_1400179f0(local_60);
      if (*(longlong *)(param_1 + 0x20) == 0) {
        if (local_48 != (longlong *)0x0) {
          operator_delete(local_48);
        }
        local_48 = (longlong *)0x0;
        local_40 = (longlong *)0x0;
        local_38 = 0;
        operator_delete(local_60[0]);
        uVar4 = 0;
      }
      else {
        plVar7 = (longlong *)InstanceGet();
        lVar8 = (**(code **)(*plVar7 + 0x20))(plVar7,"cq_fate_player");
        *(longlong *)(param_1 + 0x28) = lVar8;
        if (lVar8 == 0) {
          if (local_48 != (longlong *)0x0) {
            operator_delete(local_48);
          }
          local_48 = (longlong *)0x0;
          local_40 = (longlong *)0x0;
          local_38 = 0;
          operator_delete(local_60[0]);
          uVar4 = 0;
        }
        else {
          if (local_48 != (longlong *)0x0) {
            operator_delete(local_48);
          }
          local_48 = (longlong *)0x0;
          local_40 = (longlong *)0x0;
          local_38 = 0;
          operator_delete(local_60[0]);
          uVar4 = 1;
        }
      }
    }
  }
  return uVar4;
}

// ==== CUserManager::helper_14047c540  @14047c540  [medium:callgraph-r1]  (orig: FUN_14047c540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14047c540(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  __time64_t _Var8;
  longlong *plVar9;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    FUN_1404f65b0(local_468);
    cVar3 = FUN_1404f6670(local_468);
    if (cVar3 == '\0') {
      FUN_1404f6600(local_468);
    }
    else {
      plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x40);
      plVar1 = *(longlong **)(param_1 + 0x10);
      while( true ) {
        plVar6 = *(longlong **)(param_1 + 0x40);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
          _invalid_parameter_noinfo();
        }
        if (plVar9 == plVar6) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar1;
        }
        if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar6 = (longlong *)plVar9[4];
        if (plVar6 != (longlong *)0x0) {
          plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,3);
          uVar4 = (**(code **)(*plVar6 + 0x50))(plVar6);
          lVar7 = FUN_14047bd60(param_1,uVar4);
          _Var8 = _time64((__time64_t *)0x0);
          lVar7 = (lVar7 - _Var8) / 0xe10;
          if (lVar7 < 1) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar1;
            }
            if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_1404f66c0(local_468,(char)plVar9[3],1);
            if (cVar3 == '\0') {
              (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_468);
              FUN_1404f6710(local_468);
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar1;
              }
              if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              FUN_1404f66c0(local_468,(char)plVar9[3],1);
            }
          }
          else if (lVar7 < 0x48) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar1;
            }
            if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            cVar3 = FUN_1404f66c0(local_468,(char)plVar9[3],0);
            if (cVar3 == '\0') {
              (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                        ((longlong *)(param_2 + 0x10),local_468);
              FUN_1404f6710(local_468);
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar1;
              }
              if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              FUN_1404f66c0(local_468,(char)plVar9[3],0);
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
          plVar6 = (longlong *)plVar9[2];
          if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
            cVar3 = *(char *)(*plVar6 + 0x29);
            plVar9 = plVar6;
            plVar6 = (longlong *)*plVar6;
            while (cVar3 == '\0') {
              cVar3 = *(char *)(*plVar6 + 0x29);
              plVar9 = plVar6;
              plVar6 = (longlong *)*plVar6;
            }
          }
          else {
            cVar3 = *(char *)(plVar9[1] + 0x29);
            plVar2 = (longlong *)plVar9[1];
            plVar6 = plVar9;
            while ((plVar9 = plVar2, cVar3 == '\0' && (plVar6 == (longlong *)plVar9[2]))) {
              cVar3 = *(char *)(plVar9[1] + 0x29);
              plVar2 = (longlong *)plVar9[1];
              plVar6 = plVar9;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      iVar5 = FUN_1404f6730(local_468);
      if (iVar5 != 0) {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_468)
        ;
      }
      FUN_1404f6600(local_468);
    }
  }
  return;
}

// ==== CUserManager::helper_14047c860  @14047c860  [medium:callgraph-r1]  (orig: FUN_14047c860)
undefined8 FUN_14047c860(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined1 local_70 [8];
  longlong *local_68;
  undefined1 local_60 [24];
  longlong *local_48 [3];
  longlong *local_30;
  longlong *local_28;
  undefined8 local_20;
  
  plVar2 = operator_new(8);
  plVar7 = (longlong *)0x0;
  local_48[0] = plVar7;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)local_48;
    local_48[0] = plVar2;
  }
  local_30 = (longlong *)0x0;
  local_28 = (longlong *)0x0;
  local_20 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar2 = *(longlong **)(lVar3 + 0x170);
  if (*(longlong **)(lVar3 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = plVar7;
  }
  FUN_140313fc0(plVar2,local_48,*(undefined4 *)(param_1 + 0xc),0x1b);
  plVar2 = local_30;
  if ((longlong)local_28 - (longlong)local_30 >> 3 == 0) {
    if (local_30 != (longlong *)0x0) {
      operator_delete(local_30);
    }
    local_30 = (longlong *)0x0;
    local_28 = (longlong *)0x0;
    local_20 = 0;
    operator_delete(local_48[0]);
    uVar4 = 0;
  }
  else {
    plVar1 = local_48[0];
    if (local_28 < local_30) {
      _invalid_parameter_noinfo();
      plVar1 = local_48[0];
    }
    while( true ) {
      plVar6 = local_28;
      if (local_28 < local_30) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_48[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == plVar6) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar6 = plVar7;
      }
      else {
        plVar6 = (longlong *)*plVar1;
      }
      if ((longlong *)plVar6[4] <= plVar2) {
        _invalid_parameter_noinfo();
      }
      plVar6 = (longlong *)*plVar2;
      if (plVar6 != (longlong *)0x0) {
        plVar5 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,2);
        local_70[0] = (**(code **)(*plVar5 + 0x20))(plVar5);
        local_68 = plVar6;
        FUN_140156b30(param_1 + 0x10,local_60,local_70);
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar6 = plVar7;
      }
      else {
        plVar6 = (longlong *)*plVar1;
      }
      if ((longlong *)plVar6[4] <= plVar2) {
        _invalid_parameter_noinfo();
      }
      plVar2 = plVar2 + 1;
    }
    if (local_30 != (longlong *)0x0) {
      operator_delete(local_30);
    }
    local_30 = (longlong *)0x0;
    local_28 = (longlong *)0x0;
    local_20 = 0;
    operator_delete(local_48[0]);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CUserManager::helper_1404bf940  @1404bf940  [medium:callgraph-r3]  (orig: FUN_1404bf940)
bool FUN_1404bf940(longlong param_1,uint param_2)

{
  ulonglong *puVar1;
  char cVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  ulonglong *puVar7;
  bool bVar8;
  ulonglong local_38;
  undefined8 *local_30;
  ulonglong local_28;
  undefined8 local_20;
  ulonglong local_18;
  ulonglong local_10;
  
  puVar1 = (ulonglong *)(param_1 + 8);
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar2 = *(char *)((longlong)puVar6 + 0x21);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar4 = puVar6;
    puVar6 = puVar5;
    cVar2 = *(char *)((longlong)puVar5 + 0x21);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar4;
  local_38 = *puVar1;
  if (*puVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar6) || (param_2 < *(uint *)(puVar4 + 3))) {
    puVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *puVar1;
  }
  else {
    puVar7 = &local_38;
  }
  local_18 = *puVar7;
  uVar3 = *(ulonglong *)(param_1 + 0x38);
  local_10 = puVar7[1];
  if ((local_18 == 0) || (local_18 != *puVar1)) {
    _invalid_parameter_noinfo();
  }
  bVar8 = local_10 != uVar3;
  if (bVar8) {
    local_18 = *puVar7;
    local_10 = puVar7[1];
    FUN_1403fa3e0(puVar1,&local_28,&local_18);
  }
  return bVar8;
}

// ==== CUserManager::helper_1404ddff0  @1404ddff0  [medium:callgraph-r1]  (orig: FUN_1404ddff0)
void FUN_1404ddff0(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,0);
    param_1[1] = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404de021. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)*param_1)(param_1,1);
  return;
}

// ==== CUserManager::helper_1404df960  @1404df960  [medium:callgraph-r3]  (orig: FUN_1404df960)
ulonglong FUN_1404df960(longlong param_1)

{
  undefined2 *puVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0xb10;
  *(undefined4 *)(param_1 + 0xc) = 2;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CUserManager::helper_1404df9b0  @1404df9b0  [medium:callgraph-r3]  (orig: FUN_1404df9b0)
ulonglong FUN_1404df9b0(longlong param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4)

{
  ulonglong uVar1;
  short *psVar2;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 10;
  if (0x3fb < uVar1) {
    return uVar1 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 10;
  *(undefined4 *)(*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 1)
       = param_2;
  *(undefined1 *)
   ((longlong)*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 10 + 7) =
       param_3;
  *(undefined4 *)(*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 4)
       = param_4;
  psVar2 = *(short **)(param_1 + 0x428);
  *psVar2 = *psVar2 + 1;
  return CONCAT71((int7)((ulonglong)psVar2 >> 8),1);
}

// ==== CUserManager::helper_1404dfa20  @1404dfa20  [medium:callgraph-r3]  (orig: FUN_1404dfa20)
ulonglong FUN_1404dfa20(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  ulonglong uVar1;
  short *psVar2;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 10;
  if (0x3fb < uVar1) {
    return uVar1 & 0xffffffffffffff00;
  }
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 10;
  *(undefined4 *)(*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 1)
       = param_2;
  *(undefined1 *)(*(ushort **)(param_1 + 0x428) + (ulonglong)**(ushort **)(param_1 + 0x428) * 5 + 3)
       = param_3;
  psVar2 = *(short **)(param_1 + 0x428);
  *psVar2 = *psVar2 + 1;
  return CONCAT71((int7)((ulonglong)psVar2 >> 8),1);
}

// ==== CUserManager::helper_1404f6670  @1404f6670  [medium:callgraph-r2]  (orig: FUN_1404f6670)
ulonglong FUN_1404f6670(longlong param_1)

{
  undefined4 *puVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  puVar1 = *(undefined4 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9ea;
  *(undefined4 *)(param_1 + 0xc) = 4;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CUserManager::helper_1404f66c0  @1404f66c0  [medium:callgraph-r2]  (orig: FUN_1404f66c0)
ulonglong FUN_1404f66c0(longlong param_1,undefined1 param_2,undefined1 param_3)

{
  uint *puVar1;
  int *piVar2;
  ulonglong in_RAX;
  
  puVar1 = *(uint **)(param_1 + 0x428);
  if (puVar1 != (uint *)0x0) {
    in_RAX = (longlong)*(int *)(param_1 + 0xc) + 2;
    if (in_RAX < 0x3fc) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 2;
      *(undefined1 *)((longlong)puVar1 + (ulonglong)*puVar1 * 2 + 4) = param_2;
      *(undefined1 *)
       ((longlong)*(uint **)(param_1 + 0x428) + (ulonglong)**(uint **)(param_1 + 0x428) * 2 + 5) =
           param_3;
      piVar2 = *(int **)(param_1 + 0x428);
      *piVar2 = *piVar2 + 1;
      return CONCAT71((int7)((ulonglong)piVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CUserManager::helper_1404f6710  @1404f6710  [medium:callgraph-r2]  (orig: FUN_1404f6710)
void FUN_1404f6710(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) != (undefined4 *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = 4;
    **(undefined4 **)(param_1 + 0x428) = 0;
  }
  return;
}

// ==== CUserManager::helper_1404f6730  @1404f6730  [medium:callgraph-r2]  (orig: FUN_1404f6730)
undefined4 FUN_1404f6730(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    return 0;
  }
  return **(undefined4 **)(param_1 + 0x428);
}

