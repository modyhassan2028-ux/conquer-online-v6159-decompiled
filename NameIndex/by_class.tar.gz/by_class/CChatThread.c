// ==== CChatThread::ctor_or_dtor  @140001000  [high:vtable-assign]  (orig: FUN_140001000)
CThreadBase * FUN_140001000(CThreadBase *param_1,undefined8 param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CChatThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)(param_1 + 0x48) = param_2;
  return param_1;
}

// ==== CChatThread::ctor_or_dtor  @140001050  [high:vtable-assign]  (orig: FUN_140001050)
void FUN_140001050(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CChatThread::vftable;
                    /* WARNING: Could not recover jumptable at 0x000140001070. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CChatThread::vfunc_1  @1400010e0  [high:rtti-vtable]  (orig: FUN_1400010e0)
void FUN_1400010e0(longlong param_1)

{
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x20))();
  }
  *(undefined8 *)(param_1 + 0x40) = 0;
  return;
}

// ==== CChatThread::vfunc_2  @140001110  [high:rtti-vtable]  (orig: FUN_140001110)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140001110(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 8))();
  _snprintf(local_418,0x400,"#%u: chat thread is up and running");
  lVar2 = -1;
  local_19 = 0;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x48) + 0x50))
            (*(longlong **)(param_1 + 0x48),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CChatThread::vfunc_3  @1400011b0  [high:rtti-vtable]  (orig: FUN_1400011b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400011b0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined4 *local_4a0;
  char local_498;
  char local_497;
  ulong local_494;
  undefined4 local_490;
  uint local_48c;
  undefined4 local_488;
  longlong local_478;
  CTickAnalyst local_470 [24];
  undefined8 local_458;
  CTickAnalyst local_450 [24];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_478 = param_1;
  if ((DAT_1409754e4 & 1) == 0) {
    DAT_1409754e4 = DAT_1409754e4 | 1;
    DAT_1409754e0 = tq::TimeGet(0);
  }
  CTickAnalyst::CTickAnalyst((CTickAnalyst *)&local_490,0x49);
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x58))
                    (*(longlong **)(param_1 + 0x48),s___AVCThreadBase___140949040._20_4_);
  local_497 = cVar1;
  CTickAnalyst::~CTickAnalyst((CTickAnalyst *)&local_490);
  CTickAnalyst::CTickAnalyst(local_450,0x2f);
  uVar2 = tq::TimeGet(0);
  local_494 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_470,0x31);
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))(*(longlong **)(param_1 + 0x40),uVar2);
    CTickAnalyst::~CTickAnalyst(local_470);
    if (uVar2 - DAT_1409754e0 < 0x2711) {
      DAT_1409754e0 = DAT_1409754e0 + 2000;
    }
    else {
      log_InlineLogWARNING("resync CChatKernel::OnTimer cumulative deviation %dms");
      DAT_1409754e0 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4a0 = &local_490;
      local_4a8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x48))
                        (*(longlong **)(param_1 + 0x48),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_498 = 1;
      CTickAnalyst::CTickAnalyst(local_470,0x30);
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,local_490);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))
                        (*(longlong **)(param_1 + 0x40),local_48c,local_438,local_488);
      local_498 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_470);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CChatThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                           ,(ulonglong)local_48c);
      }
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_1409754e0) < 2000) {
    s___AVCThreadBase___140949040._20_4_ = 2000 - (uVar2 - DAT_1409754e0);
  }
  else {
    s___AVCThreadBase___140949040[0x14] = '\0';
    s___AVCThreadBase___140949040[0x15] = '\0';
    s___AVCThreadBase___140949040[0x16] = '\0';
    s___AVCThreadBase___140949040[0x17] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_450);
  return 1;
}

// ==== CChatThread::ctor_or_dtor  @1400013f0  [high:vtable-assign]  (orig: FUN_1400013f0)
CThreadBase * FUN_1400013f0(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CChatThread::vftable;
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

