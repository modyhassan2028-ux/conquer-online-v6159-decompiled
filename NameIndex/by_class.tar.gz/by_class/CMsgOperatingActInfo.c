// ==== CMsgOperatingActInfo::ctor_or_dtor  @14035b850  [high:vtable-assign]  (orig: FUN_14035b850)
undefined8 * FUN_14035b850(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgOperatingActInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgOperatingActInfo::ctor_or_dtor  @14035b8a0  [high:vtable-assign]  (orig: FUN_14035b8a0)
void FUN_14035b8a0(undefined8 *param_1)

{
  *param_1 = CMsgOperatingActInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgOperatingActInfo::vfunc_1  @14035b8d0  [high:rtti-vtable]  (orig: FUN_14035b8d0)
ulonglong FUN_14035b8d0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x524);
}

// ==== CMsgOperatingActInfo::vfunc_3  @14035bad0  [high:rtti-vtable]  (orig: FUN_14035bad0)
void FUN_14035bad0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgOperatingActInfo::ctor_or_dtor  @14035bb30  [high:vtable-assign]  (orig: FUN_14035bb30)
undefined8 * FUN_14035bb30(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgOperatingActInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

