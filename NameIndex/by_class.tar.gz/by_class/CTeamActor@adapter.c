// ==== CTeamActor@adapter::helper_1400ff2e0  @1400ff2e0  [medium:callgraph-r2]  (orig: FUN_1400ff2e0)
ulonglong FUN_1400ff2e0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  int iVar5;
  int local_res8 [2];
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if ((int)uVar3 == 0) {
    return uVar3;
  }
  uVar4 = 0;
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  local_res8[0] = (**(code **)(*plVar2 + 0x48))(plVar2);
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),9);
  local_res8[1] = (**(code **)(*plVar2 + 0x48))(plVar2);
  uVar3 = uVar4;
  do {
    iVar1 = local_res8[uVar4];
    if ((iVar1 != 0) && (iVar1 != 0xff)) {
      iVar5 = (int)uVar3;
      if (iVar1 == 0x1f) {
        uVar3 = (ulonglong)(iVar5 + 10);
      }
      else if (iVar1 == 0x20) {
        uVar3 = (ulonglong)(iVar5 + 0xf);
      }
      else if (iVar1 == 0x21) {
        uVar3 = (ulonglong)(iVar5 + 0x19);
      }
    }
    uVar4 = uVar4 + 1;
  } while ((longlong)uVar4 < 2);
  return uVar3;
}

// ==== CTeamActor@adapter::helper_140100850  @140100850  [medium:callgraph-r1]  (orig: FUN_140100850)
ulonglong FUN_140100850(longlong param_1,undefined8 param_2,char param_3)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  uint uVar4;
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if ((int)uVar3 == 0) {
    return uVar3;
  }
  if (param_3 == '\0') {
    uVar3 = FUN_1400ff2e0(param_1);
    return uVar3;
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  uVar4 = 0;
  if ((iVar1 != 0) && (uVar4 = 0, iVar1 != 0xff)) {
    if (iVar1 == 0x1f) {
      uVar4 = 10;
    }
    else {
      if (iVar1 == 0x20) {
        return 0xf;
      }
      if (iVar1 == 0x21) {
        return 0x19;
      }
    }
  }
  return (ulonglong)uVar4;
}

// ==== CTeamActor@adapter::helper_140180f80  @140180f80  [medium:callgraph-r0]  (orig: FUN_140180f80)
int FUN_140180f80(longlong *param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  ulonglong uVar4;
  longlong lVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  
  iVar7 = 0;
  if (param_1[0x220] != 0) {
    plVar3 = *(longlong **)(*(longlong *)(param_1[0x220] + 0x58) + 8);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
    uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
    if ((uVar4 >> 0x26 & 1) != 0) {
      uVar8 = 1;
      goto LAB_140180fd6;
    }
  }
  uVar8 = 0;
LAB_140180fd6:
  iVar6 = 1;
  do {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar5 = *plVar3;
    uVar1 = FUN_14032b4b0(param_1,iVar6);
    lVar5 = (**(code **)(lVar5 + 0x60))(plVar3,uVar1);
    if (lVar5 != 0) {
      uVar1 = (**(code **)(*param_1 + 8))(param_1);
      iVar2 = FUN_140100850(lVar5,uVar1,uVar8);
      iVar7 = iVar7 + iVar2;
    }
    iVar6 = iVar6 + 1;
  } while (iVar6 < 0x14);
  return iVar7;
}

// ==== CTeamActor@adapter::helper_140191c70  @140191c70  [medium:callgraph-r3]  (orig: FUN_140191c70)
undefined8 * FUN_140191c70(undefined8 *param_1,undefined8 *param_2,longlong *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)param_3[1];
  plVar2 = (longlong *)*param_3;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar2 = (longlong *)*param_3;
    lVar3 = 0;
    if (plVar2 == (longlong *)0x0) goto LAB_140191cb4;
  }
  lVar3 = *plVar2;
LAB_140191cb4:
  if (param_3[1] == *(longlong *)(lVar3 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  param_3[1] = *(longlong *)param_3[1];
  if (plVar1 != (longlong *)param_1[5]) {
    *(longlong *)plVar1[1] = *plVar1;
    *(longlong *)(*plVar1 + 8) = plVar1[1];
    operator_delete(plVar1);
    param_1[6] = param_1[6] + -1;
  }
  param_2[1] = param_3[1];
  *param_2 = *param_1;
  return param_2;
}

// ==== CTeamActor@adapter::helper_1401960d0  @1401960d0  [medium:callgraph-r2]  (orig: FUN_1401960d0)
longlong * FUN_1401960d0(longlong param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  ldiv_t lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  int local_res8;
  undefined8 *puStack_40;
  
  lVar4 = ldiv((*param_3 ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res8 = lVar4.quot;
  iVar3 = lVar4.rem * 0x41a7 + local_res8 * -0xb14;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x7fffffff;
  }
  uVar5 = (longlong)iVar3 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar5) {
    uVar5 = uVar5 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  puStack_40 = *(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + uVar5 * 0x10);
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar6 = 0;
  while( true ) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5 + 1
       ) {
      _invalid_parameter_noinfo();
    }
    if (*(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar5 + 1) * 0x10) == puStack_40) {
      param_2[1] = *(longlong *)(param_1 + 0x38);
      *param_2 = *plVar1;
      return param_2;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (*param_3 <= *(uint *)(puStack_40 + 2)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puStack_40 = (undefined8 *)*puStack_40;
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar2;
  }
  if (puStack_40 == *(undefined8 **)(lVar6 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*param_3 < *(uint *)(puStack_40 + 2)) {
    lVar6 = *(longlong *)(param_1 + 0x38);
    *param_2 = *plVar1;
    param_2[1] = lVar6;
  }
  else {
    *param_2 = (longlong)plVar2;
    param_2[1] = (longlong)puStack_40;
  }
  return param_2;
}

// ==== CTeamActor@adapter::helper_1401962c0  @1401962c0  [medium:callgraph-r1]  (orig: FUN_1401962c0)
longlong * FUN_1401962c0(longlong param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  ldiv_t lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  int local_res8;
  undefined8 *puStack_40;
  
  lVar4 = ldiv((*param_3 ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res8 = lVar4.quot;
  iVar3 = lVar4.rem * 0x41a7 + local_res8 * -0xb14;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x7fffffff;
  }
  uVar5 = (longlong)iVar3 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar5) {
    uVar5 = uVar5 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  puStack_40 = *(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + uVar5 * 0x10);
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar6 = 0;
  while( true ) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5 + 1
       ) {
      _invalid_parameter_noinfo();
    }
    if (*(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar5 + 1) * 0x10) == puStack_40) {
      param_2[1] = *(longlong *)(param_1 + 0x38);
      *param_2 = *plVar1;
      return param_2;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (*param_3 <= *(uint *)(puStack_40 + 2)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puStack_40 = (undefined8 *)*puStack_40;
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar2;
  }
  if (puStack_40 == *(undefined8 **)(lVar6 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*param_3 < *(uint *)(puStack_40 + 2)) {
    lVar6 = *(longlong *)(param_1 + 0x38);
    *param_2 = *plVar1;
    param_2[1] = lVar6;
  }
  else {
    *param_2 = (longlong)plVar2;
    param_2[1] = (longlong)puStack_40;
  }
  return param_2;
}

// ==== CTeamActor@adapter::helper_140197ae0  @140197ae0  [medium:callgraph-r3]  (orig: FUN_140197ae0)
undefined8 *
FUN_140197ae0(undefined8 *param_1,undefined8 *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = param_3[1];
  lVar2 = FUN_14018d2b0(param_1,lVar1,*(undefined8 *)(lVar1 + 8),param_4,*param_3);
  FUN_14018d330(param_1,1);
  *(longlong *)(lVar1 + 8) = lVar2;
  **(longlong **)(lVar2 + 8) = lVar2;
  if (*param_3 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *(longlong *)(param_3[1] + 8);
  param_3[1] = lVar1;
  if ((longlong *)*param_3 == (longlong *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = *(longlong *)*param_3;
  }
  if (lVar1 == *(longlong *)(lVar2 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  *param_2 = 0;
  param_2[1] = param_3[1];
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  *param_2 = *param_1;
  return param_2;
}

// ==== CTeamActor@adapter::helper_140198b30  @140198b30  [medium:callgraph-r0]  (orig: FUN_140198b30)
int FUN_140198b30(longlong param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  int iVar4;
  longlong lVar5;
  
  plVar1 = *(longlong **)(param_1 + 0x400);
  puVar3 = (undefined8 *)**(undefined8 **)(param_1 + 0x428);
  iVar4 = 0;
  while( true ) {
    puVar2 = *(undefined8 **)(param_1 + 0x428);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x400))) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 == puVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (puVar3 == *(undefined8 **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    iVar4 = iVar4 + *(int *)((longlong)puVar3 + 0x14);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (puVar3 == *(undefined8 **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar3 = (undefined8 *)*puVar3;
  }
  return iVar4;
}

// ==== CTeamActor@adapter::helper_140198bf0  @140198bf0  [medium:callgraph-r0]  (orig: FUN_140198bf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140198bf0(longlong *param_1,char param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong lVar12;
  undefined8 *puVar13;
  undefined1 auStack_4e8 [32];
  uint local_4c8;
  undefined2 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  char local_498;
  longlong *local_488;
  undefined8 *puStack_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  puVar13 = *(undefined8 **)param_1[0x85];
  plVar1 = (longlong *)param_1[0x80];
  lVar12 = 0;
  local_498 = param_2;
  while( true ) {
    puVar2 = (undefined8 *)param_1[0x85];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x80])) {
      _invalid_parameter_noinfo();
    }
    if (puVar13 == puVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar12;
    }
    else {
      lVar11 = *plVar1;
    }
    if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (0 < *(int *)((longlong)puVar13 + 0x14)) {
      FUN_14035f2f0(local_468);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = lVar12;
      }
      else {
        lVar11 = *plVar1;
      }
      if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = lVar12;
      }
      else {
        lVar11 = *plVar1;
      }
      if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      local_4a0 = 0;
      local_4a8 = *(undefined4 *)((longlong)puVar13 + 0x14);
      local_4b0 = *(undefined2 *)(puVar13 + 2);
      local_4b8 = 0;
      local_4c0 = 0;
      local_4c8 = local_4c8 & 0xffff0000;
      iVar4 = FUN_14035f4c0(local_468,0x20,uVar3,0);
      if (iVar4 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
      }
      FUN_14035f340(local_468);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar12;
    }
    else {
      lVar11 = *plVar1;
    }
    if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)((longlong)puVar13 + 0x14) = 0;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar12;
    }
    else {
      lVar11 = *plVar1;
    }
    if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar13 = (undefined8 *)*puVar13;
  }
  puVar13 = *(undefined8 **)param_1[0x97];
  plVar1 = (longlong *)param_1[0x92];
  iVar4 = 0;
  local_488 = plVar1;
  puStack_480 = puVar13;
  while( true ) {
    lVar12 = 0;
    puVar2 = (undefined8 *)param_1[0x97];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x92])) {
      _invalid_parameter_noinfo();
    }
    if (puVar13 == puVar2) break;
    uVar10 = (ulonglong)*(uint *)(param_1 + 0x246);
    iVar5 = FUN_1400084e0(uVar10);
    if (iVar5 == 0) {
      local_4c8 = 0x379;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar11 = lVar12;
    }
    else {
      if ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= uVar10) {
        _invalid_parameter_noinfo();
      }
      lVar11 = uVar10 * 0x850 + DAT_140975c20;
    }
    if (*(longlong *)(lVar11 + 0x90) == 0) {
      local_4c8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar6 = *(longlong **)(lVar11 + 0x90);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar12;
    }
    else {
      lVar11 = *plVar1;
    }
    if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,*(undefined4 *)(puVar13 + 2));
    if (plVar6 != (longlong *)0x0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = lVar12;
      }
      else {
        lVar11 = *plVar1;
      }
      if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      if (0 < *(int *)((longlong)puVar13 + 0x14)) {
        if (param_2 != '\0') {
          FUN_14035f2f0(local_468);
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = lVar12;
          }
          else {
            lVar11 = *plVar1;
          }
          if (puVar13 == *(undefined8 **)(lVar11 + 0x28)) {
            _invalid_parameter_noinfo();
          }
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          local_4a0 = 0;
          local_4a8 = *(undefined4 *)((longlong)puVar13 + 0x14);
          local_4b0 = 0;
          local_4b8 = 0;
          local_4c0 = 0;
          local_4c8 = local_4c8 & 0xffff0000;
          iVar5 = FUN_14035f4c0(local_468,0x23,uVar3,0);
          if (iVar5 != 0) {
            (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
          }
          FUN_14035f340(local_468);
        }
        pIVar7 = theInstance();
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar12 = *plVar1;
        }
        if (puVar13 == *(undefined8 **)(lVar12 + 0x28)) {
          _invalid_parameter_noinfo();
        }
        lVar12 = param_1[2];
        uVar8 = (**(code **)(plVar6[2] + 0x18))();
        uVar9 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEAM_STATISTIC");
        (**(code **)(lVar12 + 0x358))(param_1 + 2,uVar9,uVar8);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar1;
        }
        if (puVar13 == *(undefined8 **)(lVar12 + 0x28)) {
          _invalid_parameter_noinfo();
        }
        *(undefined4 *)((longlong)puVar13 + 0x14) = 0;
        iVar4 = iVar4 + 1;
        param_2 = local_498;
      }
    }
    lVar12 = 0;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar12 = *plVar1;
    }
    if (puVar13 == *(undefined8 **)(lVar12 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar13 = (undefined8 *)*puVar13;
  }
  if ((param_2 != '\0') && (0 < iVar4)) {
    FUN_14035f2f0(local_468);
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    local_4a0 = 0;
    local_4a8 = 0xffffffff;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = local_4c8 & 0xffff0000;
    iVar4 = FUN_14035f4c0(local_468,0x23,uVar3,0);
    if (iVar4 != 0) {
      (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_468);
    }
    FUN_14035f340(local_468);
  }
  return;
}

// ==== CTeamActor@adapter::helper_1401a3a80  @1401a3a80  [medium:callgraph-r0]  (orig: FUN_1401a3a80)
undefined4 FUN_1401a3a80(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401962c0(param_1 + 0x480,&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x4b8);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x490))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined4 *)(local_10 + 0x14);
  }
  return 0;
}

// ==== CTeamActor@adapter::helper_1401a3b20  @1401a3b20  [medium:callgraph-r0]  (orig: FUN_1401a3b20)
undefined4 FUN_1401a3b20(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401962c0(param_1 + 0x3f0,&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x428);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x400))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined4 *)(local_10 + 0x14);
  }
  return 0;
}

// ==== CTeamActor@adapter::helper_1401a5210  @1401a5210  [medium:callgraph-r3]  (orig: FUN_1401a5210)
void FUN_1401a5210(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  lVar6 = param_3[5];
  if ((*param_4 == 0) || (*param_4 != *param_3)) {
    _invalid_parameter_noinfo();
  }
  if (param_4[1] == lVar6) {
    return;
  }
  plVar1 = (longlong *)*param_4;
  plVar2 = (longlong *)param_4[1];
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar1;
  }
  if (plVar2 == *(longlong **)(lVar6 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  lVar6 = *plVar2;
  if (param_1 == param_3) {
    if ((*param_2 == 0) || (*param_2 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    if (param_2[1] == param_4[1]) {
      return;
    }
    if (((longlong *)*param_2 == (longlong *)0x0) || ((longlong *)*param_2 != plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_2[1] == lVar6) {
      return;
    }
  }
  lVar3 = param_4[1];
  lVar4 = param_2[1];
  if (param_1 != param_3) {
    FUN_14018d330(param_1,1);
    param_3[6] = param_3[6] + -1;
  }
  **(longlong **)(lVar3 + 8) = lVar6;
  **(longlong **)(lVar6 + 8) = lVar4;
  **(longlong **)(lVar4 + 8) = lVar3;
  uVar5 = *(undefined8 *)(lVar4 + 8);
  *(undefined8 *)(lVar4 + 8) = *(undefined8 *)(lVar6 + 8);
  *(undefined8 *)(lVar6 + 8) = *(undefined8 *)(lVar3 + 8);
  *(undefined8 *)(lVar3 + 8) = uVar5;
  return;
}

// ==== CTeamActor@adapter::helper_1401ca010  @1401ca010  [medium:callgraph-r2]  (orig: FUN_1401ca010)
longlong * FUN_1401ca010(longlong param_1,longlong *param_2,uint *param_3,longlong *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  ldiv_t lVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  float fVar12;
  float fVar13;
  int local_res18;
  longlong *local_78;
  longlong *plStack_70;
  longlong *local_68;
  longlong *plStack_60;
  undefined1 local_58 [24];
  
  lVar4 = ldiv((*param_3 ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res18 = lVar4.quot;
  iVar3 = lVar4.rem * 0x41a7 + local_res18 * -0xb14;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x7fffffff;
  }
  uVar8 = (longlong)iVar3 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar8) {
    uVar8 = uVar8 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8 + 1)
  {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  plVar9 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar8 + 1) * 0x10);
  plStack_70 = plVar9;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar11 = uVar8 * 0x10;
  local_78 = plVar2;
  do {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + lVar11);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar6) goto LAB_1401ca1e4;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)plVar9[1];
    lVar10 = 0;
    lVar5 = lVar10;
    if (plVar2 != (longlong *)0x0) {
      lVar5 = *plVar2;
    }
    plStack_70 = plVar9;
    if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar10;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
  } while (*param_3 < *(uint *)(plVar9 + 2));
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar10;
  }
  else {
    lVar5 = *plVar2;
  }
  if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*(uint *)(plVar9 + 2) < *param_3) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar10 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)*plVar9;
    plStack_70 = plVar9;
LAB_1401ca1e4:
    lVar10 = *(longlong *)(param_1 + 0x38);
    if ((*param_4 == 0) || (*param_4 != *plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar10) {
      local_68 = local_78;
      plStack_60 = plStack_70;
      plVar6 = (longlong *)FUN_140197ae0(plVar1,local_58,&local_68,param_3);
      *param_4 = *plVar6;
      param_4[1] = plVar6[1];
    }
    else {
      local_68 = (longlong *)*param_4;
      plStack_60 = (longlong *)param_4[1];
      FUN_1401a5210(plVar1,&local_78,plVar1,&local_68);
    }
    while( true ) {
      if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8)
      {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + lVar11);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 != plVar6) break;
      local_78 = (longlong *)*param_4;
      plStack_70 = (longlong *)param_4[1];
      if (local_78 == (longlong *)0x0) {
        local_68 = (longlong *)0x0;
      }
      else {
        local_68 = (longlong *)*local_78;
      }
      local_68 = (longlong *)*local_68;
      plStack_60 = plStack_70;
      if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8)
      {
        _invalid_parameter_noinfo();
      }
      lVar10 = *(longlong *)(param_1 + 0x60);
      *(longlong **)(lVar10 + lVar11) = local_68;
      *(longlong **)(lVar10 + 8 + lVar11) = plStack_60;
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      lVar11 = lVar11 + -0x10;
    }
    uVar8 = *(ulonglong *)(param_1 + 0x80);
    fVar12 = (float)*(longlong *)(param_1 + 0x40);
    if (*(longlong *)(param_1 + 0x40) < 0) {
      fVar12 = fVar12 + DAT_1406dc560;
    }
    fVar13 = (float)(longlong)uVar8;
    if ((longlong)uVar8 < 0) {
      fVar13 = fVar13 + DAT_1406dc560;
    }
    if (*(float *)(param_1 + 0x88) <= fVar12 / fVar13 &&
        fVar12 / fVar13 != *(float *)(param_1 + 0x88)) {
      iVar3 = 0;
      do {
        if (0x7fffffffffffffe < uVar8) break;
        iVar3 = iVar3 + 1;
        uVar8 = uVar8 * 2;
      } while (iVar3 < 3);
      plStack_60 = *(longlong **)(param_1 + 0x38);
      if ((undefined8 *)*plVar1 == (undefined8 *)0x0) {
        puVar7 = (undefined8 *)0x0;
      }
      else {
        puVar7 = *(undefined8 **)*plVar1;
      }
      local_68 = (longlong *)*puVar7;
      FUN_1401bea40(param_1 + 0x48,uVar8 + 1,&local_68);
      *(ulonglong *)(param_1 + 0x78) = uVar8 - 1;
      *(ulonglong *)(param_1 + 0x80) = uVar8;
      FUN_1401ca490(param_1);
    }
    *param_2 = *param_4;
    plStack_70 = (longlong *)param_4[1];
    *(undefined1 *)(param_2 + 2) = 1;
  }
  else {
    lVar11 = *(longlong *)(param_1 + 0x38);
    if ((*param_4 == 0) || (*param_4 != *plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] != lVar11) {
      local_68 = (longlong *)*param_4;
      plStack_60 = (longlong *)param_4[1];
      FUN_140191c70(plVar1,local_58,&local_68);
    }
    *(undefined1 *)(param_2 + 2) = 0;
    *param_2 = (longlong)local_78;
  }
  param_2[1] = (longlong)plStack_70;
  return param_2;
}

// ==== CTeamActor@adapter::helper_1401ca490  @1401ca490  [medium:callgraph-r3]  (orig: FUN_1401ca490)
void FUN_1401ca490(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [32];
  
  plVar1 = (longlong *)(param_1 + 0x10);
  while( true ) {
    plVar2 = (longlong *)*plVar1;
    lVar3 = **(longlong **)(param_1 + 0x38);
    if (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (lVar3 == lVar4) break;
    local_48 = SUB84(plVar2,0);
    uStack_44 = (undefined4)((ulonglong)plVar2 >> 0x20);
    uStack_40 = (undefined4)lVar3;
    uStack_3c = (undefined4)((ulonglong)lVar3 >> 0x20);
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = uStack_40;
    uStack_2c = uStack_3c;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (lVar3 == *(longlong *)(lVar4 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    FUN_1401ca010(param_1,local_28,lVar3 + 0x10,&local_38);
  }
  return;
}

// ==== CTeamActor@adapter::helper_1401d0c70  @1401d0c70  [medium:callgraph-r1]  (orig: FUN_1401d0c70)
longlong FUN_1401d0c70(longlong param_1,undefined4 *param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined4 local_res8;
  undefined4 local_resc;
  longlong *local_58;
  longlong local_50;
  undefined8 local_48;
  undefined8 uStack_40;
  longlong *local_38;
  longlong local_30;
  
  FUN_1401960d0(param_1,&local_58,param_2);
  plVar3 = local_58;
  lVar1 = *(longlong *)(param_1 + 0x38);
  if ((local_58 == (longlong *)0x0) || (local_58 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar2 = 0;
  if (local_50 == lVar1) {
    local_res8 = *param_2;
    uStack_40 = *(undefined8 *)(param_1 + 0x38);
    local_48 = *(undefined8 *)(param_1 + 0x10);
    local_resc = 0;
    FUN_1401ca010(param_1,&local_38,&local_res8,&local_48);
    local_58 = local_38;
    local_50 = local_30;
    plVar3 = local_38;
  }
  lVar1 = local_50;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar2 = *plVar3;
  }
  if (lVar1 == *(longlong *)(lVar2 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  return lVar1 + 0x14;
}

// ==== CTeamActor@adapter::helper_1401d1c80  @1401d1c80  [medium:callgraph-r0]  (orig: FUN_1401d1c80)
void FUN_1401d1c80(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_1401d0c70(param_1 + 0x480,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CTeamActor@adapter::helper_1401d1cb0  @1401d1cb0  [medium:callgraph-r0]  (orig: FUN_1401d1cb0)
void FUN_1401d1cb0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *puVar1;
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  puVar1 = (undefined4 *)FUN_1401d0c70(param_1 + 0x3f0,local_res10);
  *puVar1 = param_3;
  return;
}

// ==== CTeamActor@adapter::helper_140222170  @140222170  [medium:callgraph-r0]  (orig: FUN_140222170)
void FUN_140222170(longlong param_1,uint param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 8);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar2 = *(char *)((longlong)puVar7 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar7) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *plVar1;
  }
  else {
    plVar8 = &local_38;
  }
  plVar3 = (longlong *)*plVar8;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar3;
  local_10 = plVar8[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 != lVar9) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140416200(*(undefined8 *)(lVar5 + 0x20));
    local_18 = (longlong *)*plVar8;
    local_10 = plVar8[1];
    FUN_140220030(plVar1,&local_28,&local_18);
  }
  return;
}

// ==== CTeamActor@adapter::helper_140248280  @140248280  [medium:callgraph-r0]  (orig: FUN_140248280)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140248280(longlong param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined8 local_4b0;
  undefined8 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  lVar6 = FUN_1402464b0();
  if (lVar6 != 0) {
    iVar2 = FUN_140420ca0(lVar6);
    if (iVar2 == 1) {
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
      plVar8 = (longlong *)FUN_140087650(uVar7);
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x98))(plVar8,param_2);
      if (plVar8 == (longlong *)0x0) {
        local_4c8 = 0x210;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar3 = FUN_140420c80(lVar6);
        lVar9 = FUN_1402467e0(param_1,uVar3);
        if (lVar9 == 0) {
          local_4c8 = 0x213;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar2 = FUN_140421c00(lVar9);
          if (iVar2 == 0) {
            local_4c8 = 0x215;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
            plVar10 = (longlong *)FUN_140087650(uVar7);
            plVar10 = (longlong *)(**(code **)(*plVar10 + 0x98))(plVar10,iVar2);
            if (plVar10 == (longlong *)0x0) {
              local_4c8 = 0x217;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              plVar11 = (longlong *)FUN_140118320();
              if (plVar11 != (longlong *)0x0) {
                lVar9 = *plVar11;
                uVar4 = (**(code **)(*plVar10 + 8))(plVar10);
                uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
                cVar1 = (**(code **)(lVar9 + 0x20))(plVar11,uVar5,uVar4);
                if (cVar1 != '\0') {
                  FUN_140420f50(lVar6);
                  FUN_140422f50(local_488);
                  local_4a8 = 0;
                  local_4b0 = 0;
                  local_4b8 = 0;
                  local_4c0 = 0;
                  local_4c8 = 0;
                  cVar1 = FUN_140423040(local_488,4,uVar3,0);
                  if (cVar1 != '\0') {
                    (**(code **)(plVar8[2] + 0x350))(plVar8 + 2,local_488);
                  }
                  FUN_140422fd0(local_488);
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CTeamActor@adapter::helper_1402ebbc0  @1402ebbc0  [medium:callgraph-r0]  (orig: FUN_1402ebbc0)
void FUN_1402ebbc0(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  char cVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plStack_60;
  longlong *local_58;
  longlong *plStack_50;
  undefined1 local_48 [32];
  
  plVar6 = (longlong *)**(longlong **)(param_1 + 0x40);
  plVar1 = *(longlong **)(param_1 + 0x10);
  plStack_60 = plVar6;
  while( true ) {
    plVar3 = plStack_60;
    plVar2 = *(longlong **)(param_1 + 0x40);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x10))) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar6[4];
    if (lVar7 == 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        plVar2 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
          cVar5 = *(char *)(*plVar2 + 0x29);
          plVar6 = plVar2;
          plVar2 = (longlong *)*plVar2;
          while (plStack_60 = plVar6, cVar5 == '\0') {
            cVar5 = *(char *)(*plVar2 + 0x29);
            plVar6 = plVar2;
            plVar2 = (longlong *)*plVar2;
          }
        }
        else {
          cVar5 = *(char *)(plVar6[1] + 0x29);
          plVar3 = (longlong *)plVar6[1];
          plVar2 = plVar6;
          while ((plVar6 = plVar3, plStack_60 = plVar6, cVar5 == '\0' &&
                 (plVar2 == (longlong *)plVar6[2]))) {
            cVar5 = *(char *)(plVar6[1] + 0x29);
            plVar3 = (longlong *)plVar6[1];
            plVar2 = plVar6;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    else {
      cVar5 = FUN_1404801a0(lVar7,param_2);
      if ((cVar5 == '\0') || (cVar5 = FUN_14047e1c0(lVar7), cVar5 != '\0')) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
          plVar2 = (longlong *)plVar6[2];
          if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
            cVar5 = *(char *)(*plVar2 + 0x29);
            plVar6 = plVar2;
            plVar2 = (longlong *)*plVar2;
            while (plStack_60 = plVar6, cVar5 == '\0') {
              cVar5 = *(char *)(*plVar2 + 0x29);
              plVar6 = plVar2;
              plVar2 = (longlong *)*plVar2;
            }
          }
          else {
            cVar5 = *(char *)(plVar6[1] + 0x29);
            plVar3 = (longlong *)plVar6[1];
            plVar2 = plVar6;
            while ((plVar6 = plVar3, plStack_60 = plVar6, cVar5 == '\0' &&
                   (plVar2 == (longlong *)plVar6[2]))) {
              cVar5 = *(char *)(plVar6[1] + 0x29);
              plVar3 = (longlong *)plVar6[1];
              plVar2 = plVar6;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      else {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
          plVar2 = (longlong *)plVar6[2];
          if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
            cVar5 = *(char *)(*plVar2 + 0x29);
            plVar6 = plVar2;
            plVar2 = (longlong *)*plVar2;
            while (plStack_60 = plVar6, cVar5 == '\0') {
              cVar5 = *(char *)(*plVar2 + 0x29);
              plVar6 = plVar2;
              plVar2 = (longlong *)*plVar2;
            }
          }
          else {
            cVar5 = *(char *)(plVar6[1] + 0x29);
            plVar4 = (longlong *)plVar6[1];
            plVar2 = plVar6;
            while ((plVar6 = plVar4, plStack_60 = plVar6, cVar5 == '\0' &&
                   (plVar2 == (longlong *)plVar6[2]))) {
              cVar5 = *(char *)(plVar6[1] + 0x29);
              plVar4 = (longlong *)plVar6[1];
              plVar2 = plVar6;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        plStack_50 = plVar3;
        local_58 = plVar1;
        FUN_1402eae00(param_1 + 0x10,local_48,&local_58);
        FUN_14047ef60(lVar7);
      }
    }
  }
  return;
}

// ==== CTeamActor@adapter::helper_14038bc80  @14038bc80  [medium:callgraph-r0]  (orig: FUN_14038bc80)
ulonglong FUN_14038bc80(longlong param_1)

{
  uint uVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  
  if (*(undefined8 **)(param_1 + 0x140) == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = (longlong *)**(undefined8 **)(param_1 + 0x140);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,0x15);
  uVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return (ulonglong)CONCAT31((uint3)(uVar1 >> 0x1a),(char)(uVar1 >> 0x12)) & 0xffffffffffffff01;
}

// ==== CTeamActor@adapter::helper_1403a0cd0  @1403a0cd0  [medium:callgraph-r0]  (orig: FUN_1403a0cd0)
void FUN_1403a0cd0(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  longlong local_res8;
  
  if ((((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
      (*(int *)(param_1 + 8) != 0)) &&
     ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) != 0)) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    if (*(longlong *)(lVar1 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))
                       (*(longlong **)(lVar1 + 0x88),*(undefined4 *)(param_1 + 8));
    if (plVar2 != (longlong *)0x0) {
      local_res8 = 0;
      (**(code **)(*plVar2 + 0x298))(plVar2,0x1002,&local_res8);
      if (local_res8 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      FUN_140388710(local_res8,*(undefined4 *)(param_1 + 4),5);
    }
  }
  return;
}

// ==== CTeamActor@adapter::helper_1403a2130  @1403a2130  [medium:callgraph-r1]  (orig: FUN_1403a2130)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a2130(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  cVar1 = FUN_1403a2020();
  if (cVar1 != '\0') {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      local_4a8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))
                      (*(longlong **)(lVar3 + 0x90),param_2);
    if (lVar3 != 0) {
      FUN_140457e30(local_478);
      local_490 = *(undefined4 *)(param_1 + 0x14);
      local_498 = *(undefined4 *)(param_1 + 0x18);
      local_4a0 = *(undefined4 *)(param_1 + 0x10);
      local_4a8 = *(undefined4 *)(param_1 + 8);
      iVar2 = FUN_140457f00(local_478,6,*(undefined4 *)(param_1 + 4),param_2);
      if (iVar2 == 0) {
        FUN_140457ec0(local_478);
      }
      else {
        FUN_140458130(local_478,param_3);
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
        FUN_140457ec0(local_478);
      }
    }
  }
  return;
}

// ==== CTeamActor@adapter::helper_1403a3530  @1403a3530  [medium:callgraph-r0]  (orig: FUN_1403a3530)
void FUN_1403a3530(longlong param_1,int param_2,int param_3)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char cVar4;
  int iVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined4 *puVar8;
  longlong lVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  longlong local_res20;
  
  cVar4 = FUN_1403a2020();
  if ((cVar4 != '\0') || (param_2 == *(int *)(param_1 + 4))) {
    if ((param_3 == 9) && (*(int *)(param_1 + 4) == param_2)) {
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      plVar7 = (longlong *)FUN_1400875f0(uVar6);
      plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,*(undefined4 *)(param_1 + 8));
      if (plVar7 != (longlong *)0x0) {
        local_res20 = 0;
        (**(code **)(*plVar7 + 0x298))(plVar7,0x1002,&local_res20);
        if (local_res20 != 0) {
          FUN_140388710(local_res20,*(undefined4 *)(param_1 + 4),9);
          return;
        }
      }
    }
    else {
      uVar10 = *(ulonglong *)(param_1 + 0xb8);
      if (*(ulonglong *)(param_1 + 0xc0) < uVar10) {
        _invalid_parameter_noinfo();
      }
      plVar7 = *(longlong **)(param_1 + 0xa0);
      while( true ) {
        uVar1 = *(ulonglong *)(param_1 + 0xc0);
        if (uVar1 < *(ulonglong *)(param_1 + 0xb8)) {
          _invalid_parameter_noinfo();
        }
        if ((plVar7 == (longlong *)0x0) || (plVar7 != *(longlong **)(param_1 + 0xa0))) {
          _invalid_parameter_noinfo();
        }
        if (uVar10 == uVar1) goto LAB_1403a3773;
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar7;
        }
        if (*(ulonglong *)(lVar9 + 0x20) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        iVar5 = FUN_1404d9f10(uVar10);
        if (iVar5 == param_2) break;
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar7;
        }
        if (*(ulonglong *)(lVar9 + 0x20) <= uVar10) {
          _invalid_parameter_noinfo();
        }
        uVar10 = uVar10 + 0x40;
      }
      FUN_1403a2130(param_1,param_2,param_3);
      FUN_1404da3a0(uVar10);
      lVar2 = *(longlong *)(param_1 + 0xc0);
      lVar9 = uVar10 + 0x40;
      if (lVar9 != lVar2) {
        puVar8 = (undefined4 *)(uVar10 + 0xc);
        do {
          lVar9 = lVar9 + 0x40;
          *(undefined1 *)(puVar8 + -1) = *(undefined1 *)(puVar8 + 0xf);
          *puVar8 = puVar8[0x10];
          puVar8[1] = puVar8[0x11];
          puVar8[2] = puVar8[0x12];
          puVar8[3] = puVar8[0x13];
          puVar8[4] = puVar8[0x14];
          puVar8[5] = puVar8[0x15];
          *(undefined8 *)(puVar8 + 6) = *(undefined8 *)(puVar8 + 0x16);
          *(undefined1 *)(puVar8 + 8) = *(undefined1 *)(puVar8 + 0x18);
          puVar8[9] = puVar8[0x19];
          *(undefined1 *)(puVar8 + 10) = *(undefined1 *)(puVar8 + 0x1a);
          *(undefined8 *)(puVar8 + 0xb) = *(undefined8 *)(puVar8 + 0x1b);
          puVar8 = puVar8 + 0x10;
        } while (lVar9 != lVar2);
      }
      puVar3 = *(undefined8 **)(param_1 + 0xc0);
      for (puVar11 = puVar3 + -8; puVar11 != puVar3; puVar11 = puVar11 + 8) {
        (**(code **)*puVar11)(puVar11,0);
      }
      *(longlong *)(param_1 + 0xc0) = *(longlong *)(param_1 + 0xc0) + -0x40;
      if ((uVar10 < *(ulonglong *)(param_1 + 0xb8)) || (*(ulonglong *)(param_1 + 0xc0) < uVar10)) {
        _invalid_parameter_noinfo();
      }
LAB_1403a3773:
      if ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) == 0
         ) {
        lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
        if (*(longlong *)(lVar9 + 0x88) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar7 = (longlong *)
                 (**(code **)(**(longlong **)(lVar9 + 0x88) + 0x20))
                           (*(longlong **)(lVar9 + 0x88),*(undefined4 *)(param_1 + 8));
        if (plVar7 != (longlong *)0x0) {
          local_res20 = 0;
          (**(code **)(*plVar7 + 0x298))(plVar7,0x1002,&local_res20);
          if (local_res20 != 0) {
            FUN_140388710(local_res20,*(undefined4 *)(param_1 + 4),0xd);
          }
        }
      }
    }
  }
  return;
}

// ==== CTeamActor@adapter::helper_1403f0e90  @1403f0e90  [medium:callgraph-r0]  (orig: FUN_1403f0e90)
undefined8
FUN_1403f0e90(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined2 param_5)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  *(undefined4 *)(param_1 + 8) = 0x9c5e;
  **(undefined2 **)(param_1 + 0x428) = 0;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_5;
  return CONCAT71((uint7)(byte)((ushort)param_5 >> 8),1);
}

// ==== CTeamActor@adapter::helper_1403f0f20  @1403f0f20  [medium:callgraph-r0]  (orig: FUN_1403f0f20)
undefined8 FUN_1403f0f20(longlong param_1,undefined2 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  *(undefined4 *)(param_1 + 8) = 0x9c5e;
  **(undefined2 **)(param_1 + 0x428) = 1;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 0x10) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CTeamActor@adapter::helper_140420ca0  @140420ca0  [medium:callgraph-r1]  (orig: FUN_140420ca0)
undefined4 FUN_140420ca0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x14);
}

// ==== CTeamActor@adapter::helper_140420f50  @140420f50  [medium:callgraph-r1]  (orig: FUN_140420f50)
void FUN_140420f50(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  return;
}

// ==== CTeamActor@adapter::helper_1404da3a0  @1404da3a0  [medium:callgraph-r1]  (orig: FUN_1404da3a0)
void FUN_1404da3a0(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)FUN_1404da070();
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined1 *)(param_1 + 0x2c) = 1;
  if (*(longlong **)(param_1 + 0x38) != (longlong *)0x0) {
    lVar1 = **(longlong **)(param_1 + 0x38);
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    (**(code **)(lVar1 + 0x50))
              (*(undefined8 *)(param_1 + 0x38),uVar2,*(undefined4 *)(param_1 + 0x20),0);
    lVar1 = **(longlong **)(param_1 + 0x38);
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    (**(code **)(lVar1 + 0x60))
              (*(undefined8 *)(param_1 + 0x38),uVar2,*(undefined4 *)(param_1 + 0x20),5);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_1  @140582fb0  [high:rtti-vtable]  (orig: FUN_140582fb0)
void FUN_140582fb0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_7  @140582fd0  [high:rtti-vtable]  (orig: FUN_140582fd0)
undefined1 FUN_140582fd0(undefined8 param_1,undefined4 param_2)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x22);
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140582fff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar2 + 0x120))(plVar2,param_2);
    return uVar1;
  }
  return 1;
}

// ==== CTeamActor@adapter::vfunc_23  @140583010  [high:rtti-vtable]  (orig: FUN_140583010)
ulonglong FUN_140583010(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                       undefined8 param_5,undefined8 param_6)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,1);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_24  @1405830c0  [high:rtti-vtable]  (orig: FUN_1405830c0)
ulonglong FUN_1405830c0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                       undefined8 param_5,undefined8 param_6)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,1);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*plVar1 + 0x10))(plVar1,param_2,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_25  @140583170  [high:rtti-vtable]  (orig: FUN_140583170)
ulonglong FUN_140583170(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4,
                       undefined8 param_5,undefined8 param_6)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,1);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*plVar1 + 0x18))(plVar1,param_2,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_35  @140583220  [high:rtti-vtable]  (orig: FUN_140583220)
undefined8 FUN_140583220(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,8);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(*plVar1 + 0x188))(plVar1,param_2,param_3);
  return 1;
}

// ==== CTeamActor@adapter::vfunc_41  @1405832a0  [high:rtti-vtable]  (orig: FUN_1405832a0)
undefined1 FUN_1405832a0(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x22);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x28))(plVar1,param_3);
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x21);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x30))(plVar1,param_3);
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x24);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x38))(plVar1,param_3);
  }
  return 1;
}

// ==== CTeamActor@adapter::vfunc_45  @140583330  [high:rtti-vtable]  (orig: FUN_140583330)
ulonglong FUN_140583330(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined4 local_res18;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x21);
  if (plVar1 == (longlong *)0x0) {
    uVar2 = (ulonglong)local_res18;
  }
  else {
    uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2);
  }
  if ((int)uVar2 == 0) {
    plVar1 = (longlong *)CurrentInstanceGet();
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x24);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x00014058338f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 8))(plVar1,param_2);
      return uVar2;
    }
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_0  @1405833a0  [high:rtti-vtable]  (orig: FUN_1405833a0)
void FUN_1405833a0(longlong param_1)

{
  FUN_140583430(param_1 + -8);
  return;
}

// ==== CTeamActor@adapter::helper_140583430  @140583430  [medium:callgraph-r0]  (orig: FUN_140583430)
undefined8 * FUN_140583430(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CTeamActor::vftable;
  param_1[1] = adapter::CTeamActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTeamActor@adapter::vfunc_0  @140583480  [high:rtti-vtable]  (orig: FUN_140583480)
bool FUN_140583480(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  return lVar1 != 0;
}

// ==== CTeamActor@adapter::vfunc_1  @1405834f0  [high:rtti-vtable]  (orig: FUN_1405834f0)
ulonglong FUN_1405834f0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058359b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_2  @1405835b0  [high:rtti-vtable]  (orig: FUN_1405835b0)
bool FUN_1405835b0(longlong param_1,undefined4 param_2)

{
  uint uVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  uVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x70))(lVar2 + 0x10);
  return 0x45 < uVar1;
}

// ==== CTeamActor@adapter::vfunc_3  @140583670  [high:rtti-vtable]  (orig: FUN_140583670)
ulonglong FUN_140583670(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140382350(lVar1);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_4  @140583720  [high:rtti-vtable]  (orig: FUN_140583720)
bool FUN_140583720(longlong param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  return iVar1 == param_3;
}

// ==== CTeamActor@adapter::vfunc_5  @1405837f0  [high:rtti-vtable]  (orig: FUN_1405837f0)
ulonglong FUN_1405837f0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058389b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x230))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_6  @1405838b0  [high:rtti-vtable]  (orig: FUN_1405838b0)
ulonglong FUN_1405838b0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058395b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x238))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_8  @140583970  [high:rtti-vtable]  (orig: FUN_140583970)
undefined8 FUN_140583970(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140167b70(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_10  @140583a00  [high:rtti-vtable]  (orig: FUN_140583a00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140583a00(longlong param_1,undefined4 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong extraout_RAX;
  undefined8 local_res20;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if (param_3 == (char *)0x0) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    local_res20 = param_4;
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    if (*(longlong *)(lVar1 + 0x90) == 0) {
      local_438 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))
                       (*(longlong **)(lVar1 + 0x90),param_2);
    if (plVar2 == (longlong *)0x0) {
      local_438 = 0x97;
      log_InlineLogERROR(&DAT_1406d9c10);
      local_28 = extraout_RAX & 0xffffffffffffff00;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      local_28 = (**(code **)(*plVar2 + 0x150))(plVar2,0x7d5,local_428);
    }
  }
  return local_28;
}

// ==== CTeamActor@adapter::vfunc_9  @140583b20  [high:rtti-vtable]  (orig: FUN_140583b20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140583b20(longlong param_1,undefined4 param_2,undefined4 param_3,char *param_4)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong extraout_RAX;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if (param_4 == (char *)0x0) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    if (*(longlong *)(lVar1 + 0x90) == 0) {
      local_438 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))
                       (*(longlong **)(lVar1 + 0x90),param_2);
    if (plVar2 == (longlong *)0x0) {
      local_438 = 0xaf;
      log_InlineLogERROR(&DAT_1406d9c10);
      local_28 = extraout_RAX & 0xffffffffffffff00;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      local_28 = (**(code **)(*plVar2 + 0x150))(plVar2,param_3,local_428);
    }
  }
  return local_28;
}

// ==== CTeamActor@adapter::vfunc_13  @140583c40  [high:rtti-vtable]  (orig: FUN_140583c40)
undefined1 FUN_140583c40(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined1 uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar3 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(lVar2 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar4);
    if (puVar3 != (undefined8 *)0x0) {
      uVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
      (**(code **)*puVar3)(puVar3,1);
      return uVar1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_12  @140583d90  [high:rtti-vtable]  (orig: FUN_140583d90)
void FUN_140583d90(longlong *param_1,undefined8 param_2,longlong param_3)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310((int)param_1[2],0xffffffff,*(undefined2 *)(param_3 + 10),param_3 + 0xc,
                         *(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_1 + 0x58))(param_1,param_2,puVar1);
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_14  @140583e40  [high:rtti-vtable]  (orig: FUN_140583e40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140583e40(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_478 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (lVar3 == 0) {
    local_478 = 0x107;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14039e680(local_458);
    iVar2 = FUN_14039e700(local_458,param_2,0x34,param_3);
    if (iVar2 != 0) {
      uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))
                        ((longlong *)(lVar3 + 0x10),local_458);
      FUN_14039e6d0(local_458);
      return uVar1;
    }
    FUN_14039e6d0(local_458);
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_15  @140583f60  [high:rtti-vtable]  (orig: FUN_140583f60)
undefined8 FUN_140583f60(longlong param_1,undefined4 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x348))((longlong *)(lVar1 + 0x10),puVar2,param_4);
      (**(code **)*puVar2)(puVar2,1);
      return 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_17  @1405840c0  [high:rtti-vtable]  (orig: FUN_1405840c0)
bool FUN_1405840c0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    FUN_14018f460(lVar1,param_3,param_4,param_5);
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return lVar1 != 0;
}

// ==== CTeamActor@adapter::vfunc_19  @140584190  [high:rtti-vtable]  (orig: FUN_140584190)
uint FUN_140584190(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,0);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 1;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (uint)(uVar3 >> 5) & 1;
}

// ==== CTeamActor@adapter::vfunc_20  @140584260  [high:rtti-vtable]  (orig: FUN_140584260)
ulonglong FUN_140584260(longlong param_1,undefined4 param_2)

{
  uint extraout_var;
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,0);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)(extraout_var & 1);
}

// ==== CTeamActor@adapter::vfunc_21  @140584330  [high:rtti-vtable]  (orig: FUN_140584330)
bool FUN_140584330(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  lVar1 = (**(code **)(*plVar2 + 0x28))(plVar2,param_3);
  return lVar1 != 0;
}

// ==== CTeamActor@adapter::vfunc_22  @140584400  [high:rtti-vtable]  (orig: FUN_140584400)
ulonglong FUN_140584400(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140177530(lVar1,param_3,1);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_26  @1405844d0  [high:rtti-vtable]  (orig: FUN_1405844d0)
undefined8 FUN_1405844d0(longlong param_1,undefined4 param_2,char *param_3)

{
  longlong *plVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  char *pcVar6;
  char *pcVar7;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))(*(longlong **)(lVar5 + 0x90),param_2);
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(lVar5 + 0x10);
  pcVar6 = (char *)(**(code **)(*plVar1 + 0x18))(plVar1);
  pcVar7 = param_3;
  do {
    cVar2 = *pcVar6;
    pcVar6 = pcVar6 + 1;
    *pcVar7 = cVar2;
    pcVar7 = pcVar7 + 1;
  } while (cVar2 != '\0');
  *(undefined4 *)(param_3 + 0x10) = param_2;
  uVar4 = (**(code **)(*plVar1 + 0x30))(plVar1);
  *(undefined4 *)(param_3 + 0x14) = uVar4;
  uVar3 = (**(code **)(*plVar1 + 0x80))(plVar1);
  *(undefined2 *)(param_3 + 0x18) = uVar3;
  uVar3 = (**(code **)(*plVar1 + 0x78))(plVar1);
  *(undefined2 *)(param_3 + 0x1a) = uVar3;
  return 1;
}

// ==== CTeamActor@adapter::vfunc_27  @1405845e0  [high:rtti-vtable]  (orig: FUN_1405845e0)
undefined8 FUN_1405845e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140167b60(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_28  @140584670  [high:rtti-vtable]  (orig: FUN_140584670)
undefined1 FUN_140584670(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    return *(undefined1 *)(lVar1 + 0x12c8);
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_29  @1405846f0  [high:rtti-vtable]  (orig: FUN_1405846f0)
undefined8 FUN_1405846f0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2c8))((longlong *)(lVar1 + 0x10),param_3,1);
  return 1;
}

// ==== CTeamActor@adapter::vfunc_30  @1405847c0  [high:rtti-vtable]  (orig: FUN_1405847c0)
undefined8 FUN_1405847c0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2d0))((longlong *)(lVar1 + 0x10),param_3,1);
  return 1;
}

// ==== CTeamActor@adapter::vfunc_31  @140584890  [high:rtti-vtable]  (orig: FUN_140584890)
undefined8 FUN_140584890(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    uVar2 = FUN_140167b40(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_32  @140584920  [high:rtti-vtable]  (orig: FUN_140584920)
undefined8 FUN_140584920(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140584992. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*plVar2 + 0x38))(plVar2);
    return uVar3;
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_33  @1405849b0  [high:rtti-vtable]  (orig: FUN_1405849b0)
undefined8 FUN_1405849b0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0xa0))
                     (*(longlong **)(lVar1 + 0x90),param_3,param_2);
  if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x000140584a32. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(*plVar2 + 8))(plVar2);
    return uVar3;
  }
  return 0;
}

// ==== CTeamActor@adapter::vfunc_34  @140584a50  [high:rtti-vtable]  (orig: FUN_140584a50)
void FUN_140584a50(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2)
  ;
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140584af7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0xd8))(plVar2);
  return;
}

// ==== CTeamActor@adapter::vfunc_36  @140584b00  [high:rtti-vtable]  (orig: FUN_140584b00)
bool FUN_140584b00(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 != 0) {
    FUN_140194940(lVar1,param_3,param_4,0);
  }
  else {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return lVar1 != 0;
}

// ==== CTeamActor@adapter::vfunc_37  @140584bd0  [high:rtti-vtable]  (orig: FUN_140584bd0)
undefined8 FUN_140584bd0(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_140198bf0(lVar1,param_3);
  return 1;
}

// ==== CTeamActor@adapter::vfunc_38  @140584ca0  [high:rtti-vtable]  (orig: FUN_140584ca0)
undefined8 FUN_140584ca0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140198b30(lVar1);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_18  @140584d50  [high:rtti-vtable]  (orig: FUN_140584d50)
void FUN_140584d50(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  FUN_14008a9d0(uVar1,param_2,param_4,param_3);
  return;
}

// ==== CTeamActor@adapter::helper_140584d90  @140584d90  [medium:callgraph-r0]  (orig: FUN_140584d90)
undefined8 FUN_140584d90(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong local_res8;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2)
  ;
  if (plVar2 != (longlong *)0x0) {
    local_res8 = 0;
    (**(code **)(*plVar2 + 0x298))(plVar2,0x1002,&local_res8);
    if (local_res8 != 0) {
      uVar3 = FUN_1403887a0();
      return uVar3;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CTeamActor@adapter::vfunc_42  @140584e70  [high:rtti-vtable]  (orig: FUN_140584e70)
undefined1 FUN_140584e70(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  longlong lVar1;
  longlong *plVar2;
  
  if (param_4 != 0) {
    lVar1 = FUN_140584d90(param_1,param_4);
    if (lVar1 != 0) {
      FUN_1403a0cd0(lVar1);
    }
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x22);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x30))(plVar2,param_3);
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x21);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x38))(plVar2,param_3);
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x24);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x40))(plVar2,param_3);
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0xc0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140222170(*(undefined8 *)(lVar1 + 0xc0),param_2);
  return 1;
}

// ==== CTeamActor@adapter::vfunc_44  @140584f80  [high:rtti-vtable]  (orig: FUN_140584f80)
undefined1 FUN_140584f80(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  lVar2 = *(longlong *)(lVar2 + 0x138);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar2 = 0;
  }
  FUN_1402ebbc0(lVar2,param_3);
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x22);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x20))(plVar1,param_2,param_3);
  }
  return 1;
}

// ==== CTeamActor@adapter::vfunc_43  @140585010  [high:rtti-vtable]  (orig: FUN_140585010)
undefined1
FUN_140585010(undefined8 param_1,undefined4 param_2,undefined4 param_3,char param_4,int param_5)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  
  if (param_5 != 0) {
    lVar1 = FUN_140584d90();
    if (lVar1 != 0) {
      FUN_1403a3530(lVar1,param_3,6);
    }
  }
  if (param_4 == '\0') {
    plVar2 = (longlong *)CurrentInstanceGet();
    puVar3 = (undefined8 *)(**(code **)(*plVar2 + 0x20))(plVar2,0x21);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,param_3,param_2);
    }
    plVar2 = (longlong *)CurrentInstanceGet();
    puVar3 = (undefined8 *)(**(code **)(*plVar2 + 0x20))(plVar2,0x24);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,param_3,param_2);
    }
  }
  return 1;
}

// ==== CTeamActor@adapter::vfunc_46  @1405850c0  [high:rtti-vtable]  (orig: FUN_1405850c0)
undefined8 FUN_1405850c0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058516b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_47  @140585170  [high:rtti-vtable]  (orig: FUN_140585170)
undefined8 FUN_140585170(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058521b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_48  @140585230  [high:rtti-vtable]  (orig: FUN_140585230)
undefined1 FUN_140585230(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CTeamActor@adapter::vfunc_49  @1405852e0  [high:rtti-vtable]  (orig: FUN_1405852e0)
undefined8 FUN_1405852e0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140180f80(lVar1);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_51  @140585390  [high:rtti-vtable]  (orig: FUN_140585390)
bool FUN_140585390(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  int param_5)

{
  bool bVar1;
  int iVar2;
  longlong lVar3;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar1 = true;
  }
  else {
    iVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x158))
                      ((longlong *)(lVar3 + 0x10),param_3,param_4);
    bVar1 = param_5 < iVar2;
  }
  return bVar1;
}

// ==== CTeamActor@adapter::vfunc_50  @140585460  [high:rtti-vtable]  (orig: FUN_140585460)
bool FUN_140585460(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  longlong *plVar1;
  longlong lVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x98))(*(longlong **)(lVar6 + 0x90),param_2);
  if (lVar6 != 0) {
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    if (*(longlong *)(lVar7 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar7 = (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x98))
                      (*(longlong **)(lVar7 + 0x90),param_3);
    if (lVar7 != 0) {
      lVar2 = *(longlong *)(lVar6 + 0x10);
      plVar1 = (longlong *)(lVar7 + 0x10);
      uVar3 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x48))(plVar1);
      uVar4 = (**(code **)(*plVar1 + 0x40))(plVar1);
      iVar5 = (**(code **)(lVar2 + 0x158))(lVar6 + 0x10,uVar4,uVar3);
      return param_4 < iVar5;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return true;
}

// ==== CTeamActor@adapter::vfunc_52  @1405855c0  [high:rtti-vtable]  (orig: FUN_1405855c0)
void FUN_1405855c0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar1 = FUN_140385cf0(lVar2,param_3,param_4);
    iVar1 = iVar1 + 1;
    FUN_140385de0(lVar2,param_3,param_4,iVar1,1,iVar1 == (iVar1 / 200) * 200,0);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_53  @1405856c0  [high:rtti-vtable]  (orig: FUN_1405856c0)
void FUN_1405856c0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  iVar1 = FUN_1401a3a80(lVar2,param_3);
  FUN_1401d1c80(lVar2,param_3,iVar1 + 1);
  return;
}

// ==== CTeamActor@adapter::vfunc_54  @140585790  [high:rtti-vtable]  (orig: FUN_140585790)
void FUN_140585790(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  iVar1 = FUN_1401a3b20(lVar2,param_3);
  FUN_1401d1cb0(lVar2,param_3,iVar1 + 1);
  return;
}

// ==== CTeamActor@adapter::vfunc_55  @140585860  [high:rtti-vtable]  (orig: FUN_140585860)
undefined8 FUN_140585860(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2f8))
                    ((longlong *)(lVar1 + 0x10),param_3,1,0,1);
  return uVar2;
}

// ==== CTeamActor@adapter::vfunc_56  @140585940  [high:rtti-vtable]  (orig: FUN_140585940)
ulonglong FUN_140585940(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong local_res8;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2)
  ;
  uVar3 = 0;
  if (plVar2 != (longlong *)0x0) {
    local_res8 = 0;
    uVar3 = (**(code **)(*plVar2 + 0x298))(plVar2,0x1002,&local_res8);
    if (local_res8 != 0) {
      uVar3 = FUN_14038bc80();
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CTeamActor@adapter::vfunc_57  @1405859f0  [high:rtti-vtable]  (orig: FUN_1405859f0)
void FUN_1405859f0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  lVar1 = *(longlong *)(lVar1 + 0x120);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140248280(lVar1,param_3);
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x21);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x10))(plVar2,param_2,param_3);
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x22);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x18))(plVar2,param_2,param_3);
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x24);
  if (plVar2 != (longlong *)0x0) {
    (**(code **)(*plVar2 + 0x10))(plVar2,param_2,param_3);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_58  @140585ad0  [high:rtti-vtable]  (orig: FUN_140585ad0)
void FUN_140585ad0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  lVar1 = *(longlong *)(lVar1 + 0x120);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  thunk_FUN_1402478b0(lVar1,param_2);
  return;
}

// ==== CTeamActor@adapter::vfunc_39  @140585b30  [high:rtti-vtable]  (orig: FUN_140585b30)
void FUN_140585b30(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140170e90(lVar1,param_3);
  return;
}

// ==== CTeamActor@adapter::vfunc_40  @140585bf0  [high:rtti-vtable]  (orig: FUN_140585bf0)
void FUN_140585bf0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  int param_5)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x21);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x40))(plVar1,param_2,param_3,param_4);
  }
  plVar1 = (longlong *)CurrentInstanceGet();
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x24);
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x30))(plVar1,param_2,param_3,param_4);
  }
  if (param_5 != 0) {
    lVar2 = FUN_140584d90(param_1);
    if (lVar2 != 0) {
      FUN_1403a0cd0(lVar2);
    }
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_59  @140585ca0  [high:rtti-vtable]  (orig: FUN_140585ca0)
void FUN_140585ca0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,param_4,param_5);
  return;
}

// ==== CTeamActor@adapter::vfunc_60  @140585d20  [high:rtti-vtable]  (orig: FUN_140585d20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140585d20(longlong param_1,int param_2,undefined2 param_3,undefined4 param_4,int param_5,
                  undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
    if (param_5 != 0) {
      FUN_1403f0d80(local_468);
      local_488 = param_8;
      local_490 = param_7;
      local_498 = param_6;
      cVar1 = FUN_1403f0f90(local_468,param_3,param_4,param_5);
      if (cVar1 != '\0') {
        plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        (**(code **)(*plVar2 + 0x18))(plVar2,param_2,local_468);
      }
      FUN_1403f0dd0(local_468);
    }
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_61  @140585df0  [high:rtti-vtable]  (orig: FUN_140585df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140585df0(longlong param_1,undefined8 param_2,int param_3,ushort param_4,undefined4 param_5
                  ,undefined4 param_6)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_498 [32];
  uint local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_3 != 0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_478 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                       (*(longlong **)(lVar2 + 0x90),param_3);
    if (plVar3 != (longlong *)0x0) {
      FUN_1403f0d80(local_458);
      local_478 = (uint)param_4;
      cVar1 = FUN_1403f0e90(local_458,param_3,param_5,param_6);
      if (cVar1 != '\0') {
        (**(code **)(*plVar3 + 0x138))(plVar3,local_458,4);
      }
      FUN_1403f0dd0(local_458);
    }
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_62  @140585ef0  [high:rtti-vtable]  (orig: FUN_140585ef0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140585ef0(longlong param_1,int param_2,undefined2 param_3,undefined1 param_4)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_488 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                       (*(longlong **)(lVar2 + 0x90),param_2);
    if (plVar3 != (longlong *)0x0) {
      FUN_1403f0d80(local_468);
      cVar1 = FUN_1403f0f20(local_468,param_3,param_4);
      if (cVar1 != '\0') {
        (**(code **)(*plVar3 + 0x138))(plVar3,local_468,4);
      }
      FUN_1403f0dd0(local_468);
    }
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_11  @140585fe0  [high:rtti-vtable]  (orig: FUN_140585fe0)
void FUN_140585fe0(longlong param_1,longlong *param_2,longlong param_3)

{
  longlong *plVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  longlong *local_res18;
  longlong *local_res20;
  longlong *local_e8 [3];
  undefined4 *local_d0;
  undefined4 *local_c8;
  longlong local_c0;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  
  local_58 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_res18 = operator_new(8);
    if (local_res18 == (longlong *)0x0) {
      local_b8[0] = (longlong *)0x0;
    }
    else {
      *local_res18 = (longlong)local_b8;
      local_b8[0] = local_res18;
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    local_res20 = local_res18;
    local_res18 = operator_new(8);
    if (local_res18 == (longlong *)0x0) {
      local_e8[0] = (longlong *)0x0;
    }
    else {
      *local_res18 = (longlong)local_e8;
      local_e8[0] = local_res18;
    }
    local_d0 = (undefined4 *)0x0;
    local_c8 = (undefined4 *)0x0;
    local_c0 = 0;
    uVar9 = param_2[3];
    local_res20 = local_res18;
    if ((ulonglong)param_2[4] < uVar9) {
      _invalid_parameter_noinfo();
    }
    plVar7 = (longlong *)*param_2;
    while( true ) {
      uVar8 = param_2[4];
      if (uVar8 < (ulonglong)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar7 == (longlong *)0x0) || (plVar7 != (longlong *)*param_2)) {
        _invalid_parameter_noinfo();
      }
      if (uVar8 <= uVar9) break;
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      if (*(longlong *)(lVar5 + 0x90) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar1 = *(longlong **)(lVar5 + 0x90);
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar7;
      }
      if (*(ulonglong *)(lVar5 + 0x20) <= uVar9) {
        _invalid_parameter_noinfo();
      }
      lVar5 = (**(code **)(*plVar1 + 0x98))(plVar1);
      if (lVar5 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar4 = FUN_140167b70(lVar5);
        puVar2 = local_98;
        puVar3 = local_c8;
        if (cVar4 == '\0') {
          local_res18 = (longlong *)CONCAT44(local_res18._4_4_,*(undefined4 *)(lVar5 + 0x122c));
          if (local_a0 == (undefined4 *)0x0) {
            uVar8 = 0;
          }
          else {
            uVar8 = local_90 - (longlong)local_a0 >> 2;
          }
          if ((ulonglong)((longlong)local_98 - (longlong)local_a0 >> 2) < uVar8) {
            *local_98 = *(undefined4 *)(lVar5 + 0x122c);
            local_98 = local_98 + 1;
          }
          else {
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            puVar3 = local_a0;
            plVar1 = local_b8[0];
            local_78 = local_b8[0];
            uStack_70 = puVar2;
            if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) == 0) {
              lVar5 = 0;
            }
            else {
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar1 == (longlong *)0x0) || (plVar1 != local_b8[0])) {
                _invalid_parameter_noinfo();
              }
              lVar5 = (longlong)puVar2 - (longlong)puVar3 >> 2;
            }
            local_48 = (undefined4)local_78;
            uStack_44 = local_78._4_4_;
            uStack_40 = (undefined4)uStack_70;
            uStack_3c = uStack_70._4_4_;
            FUN_140036c20(local_b8,&local_48,1,&local_res18);
            puVar3 = local_a0;
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            plVar1 = local_b8[0];
            if (local_b8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *local_b8[0];
            }
            if (puVar3 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
              if (plVar1 == (longlong *)0x0) {
                lVar6 = 0;
              }
              else {
                lVar6 = *plVar1;
              }
              if (*(undefined4 **)(lVar6 + 0x18) <= puVar3 + lVar5) goto LAB_14058645b;
            }
            _invalid_parameter_noinfo();
          }
        }
        else {
          local_res18 = (longlong *)CONCAT44(local_res18._4_4_,*(undefined4 *)(lVar5 + 0x122c));
          if (local_d0 == (undefined4 *)0x0) {
            uVar8 = 0;
          }
          else {
            uVar8 = local_c0 - (longlong)local_d0 >> 2;
          }
          if ((ulonglong)((longlong)local_c8 - (longlong)local_d0 >> 2) < uVar8) {
            *local_c8 = *(undefined4 *)(lVar5 + 0x122c);
            local_c8 = local_c8 + 1;
          }
          else {
            if (local_c8 < local_d0) {
              _invalid_parameter_noinfo();
            }
            puVar2 = local_d0;
            plVar1 = local_e8[0];
            local_88 = local_e8[0];
            uStack_80 = puVar3;
            if (((longlong)local_c8 - (longlong)local_d0 & 0xfffffffffffffffcU) == 0) {
              lVar5 = 0;
            }
            else {
              if (local_c8 < local_d0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar1 == (longlong *)0x0) || (plVar1 != local_e8[0])) {
                _invalid_parameter_noinfo();
              }
              lVar5 = (longlong)puVar3 - (longlong)puVar2 >> 2;
            }
            local_68 = (undefined4)local_88;
            uStack_64 = local_88._4_4_;
            uStack_60 = (undefined4)uStack_80;
            uStack_5c = uStack_80._4_4_;
            FUN_140036c20(local_e8,&local_68,1,&local_res18);
            puVar3 = local_d0;
            if (local_c8 < local_d0) {
              _invalid_parameter_noinfo();
            }
            plVar1 = local_e8[0];
            if (local_e8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *local_e8[0];
            }
            if (puVar3 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
              if (plVar1 == (longlong *)0x0) {
                lVar6 = 0;
              }
              else {
                lVar6 = *plVar1;
              }
              if (*(undefined4 **)(lVar6 + 0x18) <= puVar3 + lVar5) goto LAB_14058645b;
            }
            _invalid_parameter_noinfo();
          }
        }
      }
LAB_14058645b:
      if (plVar7 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar7;
      }
      if (*(ulonglong *)(lVar5 + 0x20) <= uVar9) {
        _invalid_parameter_noinfo();
      }
      uVar9 = uVar9 + 4;
    }
    if ((longlong)local_98 - (longlong)local_a0 >> 2 != 0) {
      plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      (**(code **)(*plVar7 + 0x40))(plVar7,local_b8,param_3);
    }
    if ((longlong)local_c8 - (longlong)local_d0 >> 2 != 0) {
      plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      (**(code **)(*plVar7 + 0x48))(plVar7,local_e8,param_3);
    }
    if (local_d0 != (undefined4 *)0x0) {
      operator_delete(local_d0);
    }
    local_d0 = (undefined4 *)0x0;
    local_c8 = (undefined4 *)0x0;
    local_c0 = 0;
    operator_delete(local_e8[0]);
    if (local_a0 != (undefined4 *)0x0) {
      operator_delete(local_a0);
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    operator_delete(local_b8[0]);
  }
  return;
}

// ==== CTeamActor@adapter::vfunc_16  @140586570  [high:rtti-vtable]  (orig: FUN_140586570)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140586570(longlong *param_1,undefined4 param_2,longlong *param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  undefined4 *puVar14;
  undefined1 auStack_568 [32];
  uint local_548;
  undefined2 local_540;
  int local_538;
  undefined4 local_530;
  longlong *local_528 [3];
  undefined4 *local_510;
  undefined4 *local_508;
  longlong local_500;
  int local_4f8;
  longlong *local_4f0;
  undefined8 local_4e8;
  undefined8 uStack_4e0;
  undefined8 local_4d8;
  undefined8 uStack_4d0;
  undefined4 local_4c8;
  undefined4 uStack_4c4;
  undefined4 uStack_4c0;
  undefined4 uStack_4bc;
  undefined8 local_4b8;
  undefined4 local_4a8;
  undefined4 uStack_4a4;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  lVar8 = FUN_140008520((int)param_1[2]);
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    local_548 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar9 = (longlong *)
           (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))(*(longlong **)(lVar8 + 0x90),param_2)
  ;
  if (plVar9 == (longlong *)0x0) {
    local_548 = 299;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar5 = (**(code **)(plVar9[2] + 0x40))(plVar9 + 2);
    uVar6 = (**(code **)(plVar9[2] + 0x48))(plVar9 + 2);
    iVar7 = (**(code **)(plVar9[2] + 0x168))(plVar9 + 2);
    local_4f8 = iVar7;
    cVar4 = FUN_140167b70(plVar9);
    if (cVar4 != '\0') {
      param_2 = (**(code **)(*plVar9 + 0x38))(plVar9);
    }
    FUN_140362560();
    local_530 = 0;
    local_540 = 0x65;
    local_548 = local_548 & 0xffff0000;
    local_538 = iVar7;
    iVar7 = FUN_140362620(local_498,param_2,uVar5,uVar6);
    if (iVar7 != 0) {
      local_4f0 = operator_new(8);
      if (local_4f0 == (longlong *)0x0) {
        local_528[0] = (longlong *)0x0;
      }
      else {
        *local_4f0 = (longlong)local_528;
        local_528[0] = local_4f0;
      }
      local_510 = (undefined4 *)0x0;
      local_508 = (undefined4 *)0x0;
      local_500 = 0;
      puVar14 = (undefined4 *)param_3[3];
      local_4e8 = local_4f0;
      if ((undefined4 *)param_3[4] < puVar14) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_3;
      do {
        uVar12 = 0;
        puVar2 = (undefined4 *)param_3[4];
        if (puVar2 < (undefined4 *)param_3[3]) {
          _invalid_parameter_noinfo();
        }
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_3)) {
          _invalid_parameter_noinfo();
        }
        if (puVar2 <= puVar14) {
          (**(code **)(*param_1 + 0x58))(param_1,local_528,local_498);
          if (local_510 != (undefined4 *)0x0) {
            operator_delete(local_510);
          }
          local_510 = (undefined4 *)0x0;
          local_508 = (undefined4 *)0x0;
          local_500 = 0;
          operator_delete(local_528[0]);
          FUN_1403625e0(local_498);
          return 1;
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar13 = uVar12;
        }
        else {
          uVar13 = *puVar1;
        }
        if (*(undefined4 **)(uVar13 + 0x20) <= puVar14) {
          _invalid_parameter_noinfo();
        }
        uVar5 = *puVar14;
        local_4f0 = (longlong *)CONCAT44(local_4f0._4_4_,uVar5);
        lVar8 = FUN_140008520((int)param_1[2]);
        if (*(longlong *)(lVar8 + 0x90) == 0) {
          local_548 = 0x130;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))
                          (*(longlong **)(lVar8 + 0x90),uVar5);
        if ((lVar8 != 0) &&
           (iVar7 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x168))(), puVar2 = local_508,
           iVar7 == local_4f8)) {
          if (cVar4 == '\0') {
            if (*(char *)(lVar8 + 0x12c8) == '\0') {
              if (local_510 != (undefined4 *)0x0) {
                uVar12 = local_500 - (longlong)local_510 >> 2;
              }
              if ((ulonglong)((longlong)local_508 - (longlong)local_510 >> 2) < uVar12) {
                *local_508 = uVar5;
                local_508 = local_508 + 1;
              }
              else {
                if (local_508 < local_510) {
                  _invalid_parameter_noinfo();
                }
                puVar3 = local_510;
                plVar9 = local_528[0];
                local_4e8 = local_528[0];
                uStack_4e0 = puVar2;
                if (((longlong)local_508 - (longlong)local_510 & 0xfffffffffffffffcU) == 0) {
                  lVar8 = 0;
                }
                else {
                  if (local_508 < local_510) {
                    _invalid_parameter_noinfo();
                  }
                  if ((plVar9 == (longlong *)0x0) || (plVar9 != local_528[0])) {
                    _invalid_parameter_noinfo();
                  }
                  lVar8 = (longlong)puVar2 - (longlong)puVar3 >> 2;
                }
                local_4a8 = (undefined4)local_4e8;
                uStack_4a4 = local_4e8._4_4_;
                uStack_4a0 = (undefined4)uStack_4e0;
                uStack_49c = uStack_4e0._4_4_;
                FUN_140036c20(local_528,&local_4a8,1,&local_4f0);
                puVar2 = local_510;
                if (local_508 < local_510) {
                  _invalid_parameter_noinfo();
                }
                plVar9 = local_528[0];
                if (local_528[0] == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar10 = 0;
                }
                else {
                  lVar10 = *local_528[0];
                }
                if (puVar2 + lVar8 <= *(undefined4 **)(lVar10 + 0x20)) {
                  if (plVar9 == (longlong *)0x0) {
                    lVar10 = 0;
                  }
                  else {
                    lVar10 = *plVar9;
                  }
                  if (*(undefined4 **)(lVar10 + 0x18) <= puVar2 + lVar8) goto LAB_140586a93;
                }
                _invalid_parameter_noinfo();
              }
            }
          }
          else {
            if (local_510 != (undefined4 *)0x0) {
              uVar12 = local_500 - (longlong)local_510 >> 2;
            }
            if ((ulonglong)((longlong)local_508 - (longlong)local_510 >> 2) < uVar12) {
              *local_508 = uVar5;
              local_508 = local_508 + 1;
            }
            else {
              if (local_508 < local_510) {
                _invalid_parameter_noinfo();
              }
              puVar3 = local_510;
              plVar9 = local_528[0];
              local_4d8 = local_528[0];
              uStack_4d0 = puVar2;
              if (((longlong)local_508 - (longlong)local_510 & 0xfffffffffffffffcU) == 0) {
                lVar8 = 0;
              }
              else {
                if (local_508 < local_510) {
                  _invalid_parameter_noinfo();
                }
                if ((plVar9 == (longlong *)0x0) || (plVar9 != local_528[0])) {
                  _invalid_parameter_noinfo();
                }
                lVar8 = (longlong)puVar2 - (longlong)puVar3 >> 2;
              }
              local_4c8 = (undefined4)local_4d8;
              uStack_4c4 = local_4d8._4_4_;
              uStack_4c0 = (undefined4)uStack_4d0;
              uStack_4bc = uStack_4d0._4_4_;
              FUN_140036c20(local_528,&local_4c8,1,&local_4f0);
              puVar2 = local_510;
              if (local_508 < local_510) {
                _invalid_parameter_noinfo();
              }
              plVar9 = local_528[0];
              if (local_528[0] == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar10 = 0;
              }
              else {
                lVar10 = *local_528[0];
              }
              lVar11 = 0;
              if (puVar2 + lVar8 <= *(undefined4 **)(lVar10 + 0x20)) {
                if (plVar9 != (longlong *)0x0) {
                  lVar11 = *plVar9;
                }
                if (*(undefined4 **)(lVar11 + 0x18) <= puVar2 + lVar8) goto LAB_140586a93;
              }
              _invalid_parameter_noinfo();
            }
          }
        }
LAB_140586a93:
        uVar12 = 0;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          uVar12 = *puVar1;
        }
        if (*(undefined4 **)(uVar12 + 0x20) <= puVar14) {
          _invalid_parameter_noinfo();
        }
        puVar14 = puVar14 + 1;
      } while( true );
    }
    local_548 = 0x138;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1403625e0(local_498);
  }
  return 0;
}

