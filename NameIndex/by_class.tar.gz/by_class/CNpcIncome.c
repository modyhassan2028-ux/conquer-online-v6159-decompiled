// ==== CNpcIncome::ctor_or_dtor  @14014edc0  [high:vtable-assign]  (orig: FUN_14014edc0)
undefined8 * FUN_14014edc0(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x10);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CNpcIncome::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

// ==== CNpcIncome::ctor_or_dtor  @14014f310  [high:vtable-assign]  (orig: FUN_14014f310)
undefined8 * FUN_14014f310(undefined8 *param_1,byte param_2)

{
  *param_1 = CNpcIncome::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

