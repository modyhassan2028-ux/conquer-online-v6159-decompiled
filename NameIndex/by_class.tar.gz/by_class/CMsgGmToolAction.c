// ==== CMsgGmToolAction::ctor_or_dtor  @140451200  [high:vtable-assign]  (orig: FUN_140451200)
undefined8 * FUN_140451200(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGmToolAction::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x12),0x3fd,true);
  return param_1;
}

// ==== CMsgGmToolAction::ctor_or_dtor  @140451280  [high:vtable-assign]  (orig: FUN_140451280)
void FUN_140451280(undefined8 *param_1)

{
  *param_1 = CMsgGmToolAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgGmToolAction::vfunc_1  @1404512c0  [high:rtti-vtable]  (orig: FUN_1404512c0)
ulonglong FUN_1404512c0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x906);
}

// ==== CMsgGmToolAction::ctor_or_dtor  @1404512f0  [high:vtable-assign]  (orig: FUN_1404512f0)
undefined8 * FUN_1404512f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGmToolAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgGmToolAction::vfunc_3  @140451350  [high:rtti-vtable]  (orig: FUN_140451350)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140451350(longlong param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 uVar8;
  undefined1 auStack_68 [32];
  undefined8 local_48;
  char local_38 [16];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    local_48 = CONCAT44(local_48._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))(*(longlong **)(lVar4 + 0x90),param_1)
  ;
  if ((((plVar5 != (longlong *)0x0) &&
       (cVar1 = (**(code **)(plVar5[2] + 0x230))(plVar5 + 2), cVar1 != '\0')) &&
      (**(short **)(param_1 + 0x428) == 1)) &&
     (uVar2 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x430)), uVar2 != 0)) {
    tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_38,0x10);
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_140087650(uVar6);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x90))(plVar7,local_38,0);
    if (plVar7 != (longlong *)0x0) {
      uVar6 = (**(code **)(plVar7[2] + 0x18))(plVar7 + 2);
      uVar2 = (**(code **)(*plVar7 + 8))(plVar7);
      uVar8 = (**(code **)(plVar5[2] + 0x18))(plVar5 + 2);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      local_48 = uVar6;
      log_InlineLogWARNING
                ("gm [%u][%s] kickout user [%u][%s]",(ulonglong)uVar3,uVar8,(ulonglong)uVar2);
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar5 = (longlong *)FUN_140087650(uVar6);
      (**(code **)(*plVar5 + 0x50))(plVar5,plVar7,&DAT_14077db60);
    }
  }
  return;
}

