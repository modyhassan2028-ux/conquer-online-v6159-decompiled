// ==== CMsgRouletteWinningNumber::ctor_or_dtor  @1404ddcc0  [high:vtable-assign]  (orig: FUN_1404ddcc0)
undefined8 * FUN_1404ddcc0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRouletteWinningNumber::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRouletteWinningNumber::ctor_or_dtor  @1404ddd10  [high:vtable-assign]  (orig: FUN_1404ddd10)
void FUN_1404ddd10(undefined8 *param_1)

{
  *param_1 = CMsgRouletteWinningNumber::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRouletteWinningNumber::vfunc_1  @1404ddd40  [high:rtti-vtable]  (orig: FUN_1404ddd40)
ulonglong FUN_1404ddd40(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xaf1);
}

// ==== CMsgRouletteWinningNumber::vfunc_3  @1404ddd90  [high:rtti-vtable]  (orig: FUN_1404ddd90)
void FUN_1404ddd90(void)

{
  return;
}

// ==== CMsgRouletteWinningNumber::ctor_or_dtor  @1404ddda0  [high:vtable-assign]  (orig: FUN_1404ddda0)
undefined8 * FUN_1404ddda0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRouletteWinningNumber::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

