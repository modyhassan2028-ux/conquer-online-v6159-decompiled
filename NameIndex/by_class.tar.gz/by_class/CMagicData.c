// ==== CMagicData::ctor_or_dtor  @140418370  [high:vtable-assign]  (orig: FUN_140418370)
void FUN_140418370(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CMagicData::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    if ((*(char *)((longlong)param_1 + 0x24) == '\0') &&
       (*(char *)((longlong)param_1 + 0x26) == '\0')) {
      (**(code **)*puVar1)(puVar1,1);
      param_1[1] = 0;
      return;
    }
    (**(code **)*puVar1)(puVar1,0);
    param_1[1] = 0;
  }
  return;
}

// ==== CMagicData::helper_1404185b0  @1404185b0  [medium:callgraph-r0]  (orig: FUN_1404185b0)
void FUN_1404185b0(void *param_1)

{
  if ((DAT_140976388 & 1) == 0) {
    DAT_140976388 = DAT_140976388 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976380,"CMagicData");
    atexit((_func_5014 *)&LAB_1406d6d90);
  }
                    /* WARNING: Could not recover jumptable at 0x000140418605. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976380,param_1);
  return;
}

// ==== CMagicData::ctor_or_dtor  @140418670  [high:vtable-assign]  (orig: FUN_140418670)
undefined8 * FUN_140418670(undefined8 *param_1,ulonglong param_2)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  *param_1 = CMagicData::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    if ((*(char *)((longlong)param_1 + 0x24) == '\0') &&
       (*(char *)((longlong)param_1 + 0x26) == '\0')) {
      uVar2 = 1;
    }
    else {
      uVar2 = 0;
    }
    (**(code **)*puVar1)(puVar1,uVar2);
    param_1[1] = 0;
  }
  if ((param_2 & 1) != 0) {
    FUN_1404185b0(param_1);
  }
  return param_1;
}

// ==== CMagicData::ctor_or_dtor  @1404186d0  [high:vtable-assign]  (orig: FUN_1404186d0)
undefined8 * FUN_1404186d0(undefined4 param_1,undefined1 param_2)

{
  undefined8 *puVar1;
  
  if ((DAT_140976388 & 1) == 0) {
    DAT_140976388 = DAT_140976388 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976380,"CMagicData");
    atexit((_func_5014 *)&LAB_1406d6d90);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976380,0x28);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CMagicData::vftable;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar1[3] = 0;
    *(undefined4 *)(puVar1 + 4) = param_1;
    *(undefined1 *)((longlong)puVar1 + 0x24) = param_2;
    *(undefined1 *)((longlong)puVar1 + 0x25) = 1;
    *(undefined1 *)((longlong)puVar1 + 0x26) = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pMagicData",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\magic\\src\\magicdata.cpp"
                       ,0x2b);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

