// ==== CMapGroup::helper_14000a280  @14000a280  [medium:callgraph-r3]  (orig: FUN_14000a280)
undefined8 *
FUN_14000a280(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x18);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = param_3;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = *param_4;
  }
  return puVar1;
}

// ==== CMapGroup::helper_14000a300  @14000a300  [medium:callgraph-r3]  (orig: FUN_14000a300)
void FUN_14000a300(longlong param_1,ulonglong param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  if (0x1fffffffffffffffU - *(longlong *)(param_1 + 0x30) < param_2) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"list<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  *(ulonglong *)(param_1 + 0x30) = *(longlong *)(param_1 + 0x30) + param_2;
  return;
}

// ==== CMapGroup::helper_14000cae0  @14000cae0  [medium:callgraph-r2]  (orig: FUN_14000cae0)
undefined8 *
FUN_14000cae0(undefined8 *param_1,undefined8 *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = param_3[1];
  lVar2 = FUN_14000a280(param_1,lVar1,*(undefined8 *)(lVar1 + 8),param_4,*param_3);
  FUN_14000a300(param_1,1);
  *(longlong *)(lVar1 + 8) = lVar2;
  **(longlong **)(lVar2 + 8) = lVar2;
  if (*param_3 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *(longlong *)(param_3[1] + 8);
  param_3[1] = lVar1;
  if ((longlong *)*param_3 == (longlong *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = *(longlong *)*param_3;
  }
  if (lVar1 == *(longlong *)(lVar2 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  *param_2 = 0;
  param_2[1] = param_3[1];
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  *param_2 = *param_1;
  return param_2;
}

// ==== CMapGroup::helper_14000cbd0  @14000cbd0  [medium:callgraph-r2]  (orig: FUN_14000cbd0)
undefined8 * FUN_14000cbd0(undefined8 *param_1,undefined8 *param_2,longlong *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)param_3[1];
  plVar2 = (longlong *)*param_3;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar2 = (longlong *)*param_3;
    lVar3 = 0;
    if (plVar2 == (longlong *)0x0) goto LAB_14000cc14;
  }
  lVar3 = *plVar2;
LAB_14000cc14:
  if (param_3[1] == *(longlong *)(lVar3 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  param_3[1] = *(longlong *)param_3[1];
  if (plVar1 != (longlong *)param_1[5]) {
    *(longlong *)plVar1[1] = *plVar1;
    *(longlong *)(*plVar1 + 8) = plVar1[1];
    operator_delete(plVar1);
    param_1[6] = param_1[6] + -1;
  }
  param_2[1] = param_3[1];
  *param_2 = *param_1;
  return param_2;
}

// ==== CMapGroup::helper_14000f1c0  @14000f1c0  [medium:callgraph-r2]  (orig: FUN_14000f1c0)
void FUN_14000f1c0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  
  lVar6 = param_3[5];
  if ((*param_4 == 0) || (*param_4 != *param_3)) {
    _invalid_parameter_noinfo();
  }
  if (param_4[1] == lVar6) {
    return;
  }
  plVar1 = (longlong *)*param_4;
  plVar2 = (longlong *)param_4[1];
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar1;
  }
  if (plVar2 == *(longlong **)(lVar6 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  lVar6 = *plVar2;
  if (param_1 == param_3) {
    if ((*param_2 == 0) || (*param_2 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    if (param_2[1] == param_4[1]) {
      return;
    }
    if (((longlong *)*param_2 == (longlong *)0x0) || ((longlong *)*param_2 != plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_2[1] == lVar6) {
      return;
    }
  }
  lVar3 = param_4[1];
  lVar4 = param_2[1];
  if (param_1 != param_3) {
    FUN_14000a300(param_1,1);
    param_3[6] = param_3[6] + -1;
  }
  **(longlong **)(lVar3 + 8) = lVar6;
  **(longlong **)(lVar6 + 8) = lVar4;
  **(longlong **)(lVar4 + 8) = lVar3;
  uVar5 = *(undefined8 *)(lVar4 + 8);
  *(undefined8 *)(lVar4 + 8) = *(undefined8 *)(lVar6 + 8);
  *(undefined8 *)(lVar6 + 8) = *(undefined8 *)(lVar3 + 8);
  *(undefined8 *)(lVar3 + 8) = uVar5;
  return;
}

// ==== CMapGroup::helper_1400156f0  @1400156f0  [medium:callgraph-r1]  (orig: FUN_1400156f0)
void FUN_1400156f0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CMapGroup::helper_140015750  @140015750  [medium:callgraph-r2]  (orig: FUN_140015750)
undefined8 *
FUN_140015750(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    *(undefined1 *)(puVar1 + 4) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  }
  return puVar1;
}

// ==== CMapGroup::helper_140015f40  @140015f40  [medium:callgraph-r1]  (orig: FUN_140015f40)
undefined8 *
FUN_140015f40(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x1ffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140015750(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x20);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x21) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x20) == '\0') {
        *(undefined1 *)(plVar2 + 4) = 1;
        *(undefined1 *)(lVar4 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x21) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x20) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x20) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x21) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x20);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x20) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMapGroup::helper_1400173d0  @1400173d0  [medium:callgraph-r0]  (orig: FUN_1400173d0)
longlong * FUN_1400173d0(longlong *param_1,longlong *param_2,int *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  bool bVar7;
  undefined8 *puVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar8 = (undefined8 *)param_1[6];
  bVar7 = true;
  if (*(char *)((longlong)puVar8[1] + 0x21) == '\0') {
    puVar5 = (undefined8 *)puVar8[1];
    do {
      puVar8 = puVar5;
      bVar7 = *param_3 < *(int *)(puVar8 + 3);
      if (bVar7) {
        puVar5 = (undefined8 *)*puVar8;
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x21) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar8;
  local_38 = lVar2;
  puVar4 = puVar8;
  if (bVar7 == false) {
LAB_14001752d:
    local_30 = puVar4;
    if (*param_3 <= *(int *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14001755c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar8;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x21) == '\0') {
        puVar5 = (undefined8 *)*puVar8;
        if (*(char *)((longlong)puVar5 + 0x21) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x21);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x21);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x21);
          puVar4 = (undefined8 *)puVar8[1];
          puVar3 = puVar8;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x21);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar8[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x21) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14001752d;
    }
    bVar7 = true;
  }
  plVar6 = (longlong *)FUN_140015f40(param_1,&local_38,bVar7,puVar8,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14001755c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMapGroup::helper_1400189b0  @1400189b0  [medium:callgraph-r0]  (orig: FUN_1400189b0)
longlong * FUN_1400189b0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1400183c0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_140018aa4;
  }
  _invalid_parameter_noinfo();
LAB_140018aa4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMapGroup::helper_1400326f0  @1400326f0  [medium:callgraph-r3]  (orig: FUN_1400326f0)
void FUN_1400326f0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroup::helper_140033490  @140033490  [medium:callgraph-r3]  (orig: FUN_140033490)
void FUN_140033490(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x28)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x28);
  return;
}

// ==== CMapGroup::helper_14004e620  @14004e620  [medium:callgraph-r1]  (orig: FUN_14004e620)
void FUN_14004e620(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CMapGroup::helper_14004e680  @14004e680  [medium:callgraph-r3]  (orig: FUN_14004e680)
undefined8 *
FUN_14004e680(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    *(undefined1 *)(puVar1 + 4) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  }
  return puVar1;
}

// ==== CMapGroup::helper_140057310  @140057310  [medium:callgraph-r1]  (orig: FUN_140057310)
void FUN_140057310(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroup::helper_140058db0  @140058db0  [medium:callgraph-r1]  (orig: FUN_140058db0)
void FUN_140058db0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x30)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x30);
  return;
}

// ==== CMapGroup::vfunc_0  @140089140  [high:rtti-vtable]  (orig: FUN_140089140)
ulonglong FUN_140089140(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined4 uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendClientMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_3 + 0x414) = param_2;
  *(undefined4 *)(param_3 + 0x410) = uVar1;
  *(undefined4 *)(param_3 + 0x418) = 0;
  *(undefined4 *)(param_3 + 0x41c) = 0;
                    /* WARNING: Could not recover jumptable at 0x00014008918c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x70) + 8))(*(longlong **)(param_1 + 0x70),param_3)
  ;
  return uVar2;
}

// ==== CMapGroup::vfunc_2  @140089190  [high:rtti-vtable]  (orig: FUN_140089190)
ulonglong FUN_140089190(longlong param_1,int param_2,longlong param_3)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg user id is null!");
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg, NULL message");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x20))
                    (*(longlong **)(param_1 + 0x70),param_2,0xffffffff,*(undefined4 *)(param_3 + 8),
                     param_3 + 0x10,*(undefined4 *)(param_3 + 0xc),1);
  return uVar1;
}

// ==== CMapGroup::vfunc_1  @140089200  [high:rtti-vtable]  (orig: FUN_140089200)
ulonglong FUN_140089200(longlong param_1,longlong param_2)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x18))
                    (*(longlong **)(param_1 + 0x70),*(undefined4 *)(param_2 + 8),0xffffffff,
                     param_2 + 0x10,*(undefined4 *)(param_2 + 0xc),1);
  return uVar1;
}

// ==== CMapGroup::vfunc_3  @140089250  [high:rtti-vtable]  (orig: FUN_140089250)
ulonglong FUN_140089250(longlong param_1,undefined4 param_2,longlong param_3)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendGSOrOSS2SMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x18))
                    (*(longlong **)(param_1 + 0x70),*(undefined4 *)(param_3 + 8),param_2,
                     param_3 + 0x10,*(undefined4 *)(param_3 + 0xc),8);
  return uVar1;
}

// ==== CMapGroup::vfunc_5  @1400892a0  [high:rtti-vtable]  (orig: FUN_1400892a0)
ulonglong FUN_1400892a0(longlong param_1,int param_2,undefined4 param_3,longlong param_4,
                       undefined4 param_5)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg user id is null!");
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (param_4 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg, NULL message");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x20))
                    (*(longlong **)(param_1 + 0x70),param_2,param_3,*(undefined4 *)(param_4 + 8),
                     param_4 + 0x10,*(undefined4 *)(param_4 + 0xc),param_5);
  return uVar1;
}

// ==== CMapGroup::vfunc_4  @140089320  [high:rtti-vtable]  (orig: FUN_140089320)
ulonglong FUN_140089320(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendCrossMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x18))
                    (*(longlong **)(param_1 + 0x70),*(undefined4 *)(param_3 + 8),param_2,
                     param_3 + 0x10,*(undefined4 *)(param_3 + 0xc),param_4);
  return uVar1;
}

// ==== CMapGroup::vfunc_6  @140089370  [high:rtti-vtable]  (orig: FUN_140089370)
ulonglong FUN_140089370(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined4 uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendNpcMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = *(undefined4 *)(param_1 + 0x68);
  *(undefined4 *)(param_3 + 0x418) = param_2;
  *(undefined4 *)(param_3 + 0x414) = 0xffffffff;
  *(undefined4 *)(param_3 + 0x41c) = 0xffffffff;
  *(undefined4 *)(param_3 + 0x410) = uVar1;
                    /* WARNING: Could not recover jumptable at 0x0001400893c2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x70) + 8))(*(longlong **)(param_1 + 0x70),param_3)
  ;
  return uVar2;
}

// ==== CMapGroup::vfunc_11  @1400893d0  [high:rtti-vtable]  (orig: FUN_1400893d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400893d0(longlong param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_2 == 0) {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x8fd);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  local_434 = *(undefined4 *)(param_2 + 8);
  iVar1 = *(int *)(param_2 + 0xc);
  local_438 = param_3;
  memcpy(local_42c,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_448 = &local_438;
  local_430 = iVar1;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),1,0x753d,0x418);
  return 1;
}

// ==== CMapGroup::vfunc_10  @1400894a0  [high:rtti-vtable]  (orig: FUN_1400894a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400894a0(longlong param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_8f8 [32];
  undefined4 *local_8d8;
  undefined4 local_8d0;
  undefined2 local_8c8;
  undefined2 local_8c0;
  undefined4 local_8b8;
  undefined4 local_8b0;
  undefined1 local_8a8;
  undefined8 local_898;
  undefined1 local_888 [8];
  undefined4 local_880;
  int local_87c;
  undefined1 local_878 [1088];
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_898 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_8f8;
  if (param_2 == 0) {
    local_8d8 = (undefined4 *)CONCAT44(local_8d8._4_4_,0x90f);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_14015b240();
    local_8a8 = 1;
    local_8b0 = 0;
    local_8b8 = 0;
    local_8c0 = 0;
    local_8c8 = 2000;
    local_8d0 = 0xffffff;
    local_8d8 = (undefined4 *)0x0;
    iVar1 = FUN_14015b300(local_888,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 == 0) {
      FUN_14015b2c0(local_888);
      uVar2 = 0;
    }
    else {
      local_434 = local_880;
      local_438 = param_3;
      memcpy(local_42c,local_878,(longlong)local_87c);
      local_430 = local_87c;
      local_8d8 = &local_438;
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),1,0x753d,0x418);
      FUN_14015b2c0(local_888);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CMapGroup::vfunc_15  @140089610  [high:rtti-vtable]  (orig: FUN_140089610)
ulonglong FUN_140089610(longlong *param_1,longlong param_2)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014008965c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*param_1 + 0x20))(param_1,0,param_2,10);
  return uVar1;
}

// ==== CMapGroup::vfunc_14  @140089660  [high:rtti-vtable]  (orig: FUN_140089660)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140089660(longlong *param_1,longlong param_2,undefined8 param_3,undefined4 param_4,
             undefined2 param_5)

{
  undefined1 uVar1;
  int iVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_2 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x966);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = param_5;
    local_4d8 = param_3;
    local_4d0 = param_4;
    iVar2 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_2);
    if (iVar2 == 0) {
      log_InlineLogERROR("CMapGroup::BroadcastOtherServerMsg CMsgTalk Create Faild.");
      FUN_14015b2c0(local_488);
      uVar1 = 0;
    }
    else {
      uVar1 = (**(code **)(*param_1 + 0x20))(param_1,0,local_488,10);
      FUN_14015b2c0(local_488);
    }
  }
  return uVar1;
}

// ==== CMapGroup::vfunc_16  @140089780  [high:rtti-vtable]  (orig: FUN_140089780)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140089780(longlong param_1,longlong param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  undefined1 auStack_478 [32];
  int *local_458;
  int local_448;
  int local_444;
  undefined4 local_440;
  int local_43c;
  undefined4 local_438;
  undefined1 local_434 [1036];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if ((param_3 == -1) && (param_4 == 0)) {
    local_458 = (int *)CONCAT44(local_458._4_4_,0x976);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  local_440 = *(undefined4 *)(param_2 + 8);
  iVar2 = *(int *)(param_2 + 0xc);
  local_448 = param_3;
  local_444 = param_4;
  memcpy(local_434,(void *)(param_2 + 0x10),(longlong)iVar2);
  local_438 = *(undefined4 *)(param_2 + 0x424);
  uVar3 = 0xe;
  local_43c = iVar2;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  if (0xe < uVar1) {
    do {
      if (uVar3 != *(uint *)(param_1 + 0x68)) {
        local_458 = &local_448;
        (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                  (*(longlong **)(param_1 + 0x80),uVar3 & 0xffffffff,0x2715,0x418);
      }
      uVar3 = uVar3 + 1;
      iVar2 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
    } while (uVar3 < (ulonglong)(longlong)iVar2);
  }
  return 1;
}

// ==== CMapGroup::vfunc_28  @1400898a0  [high:rtti-vtable]  (orig: FUN_1400898a0)
void FUN_1400898a0(longlong param_1,longlong param_2)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  
  uVar3 = 0xe;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  if (0xe < uVar1) {
    do {
      if (uVar3 != *(uint *)(param_1 + 0x68)) {
        (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                  (*(longlong **)(param_1 + 0x80),uVar3 & 0xffffffff,0x271d,
                   *(undefined2 *)(param_2 + 4),param_2);
      }
      uVar3 = uVar3 + 1;
      iVar2 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
    } while (uVar3 < (ulonglong)(longlong)iVar2);
  }
  return;
}

// ==== CMapGroup::vfunc_21  @140089920  [high:rtti-vtable]  (orig: FUN_140089920)
undefined8 FUN_140089920(longlong param_1,char *param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  
  if (param_2 == (char *)0x0) {
    return 0;
  }
  if (*(longlong *)(param_1 + 0x80) != 0) {
    lVar2 = -1;
    pcVar3 = param_2;
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
              (*(longlong **)(param_1 + 0x80),2,0x4e21,~(uint)lVar2,param_2);
  }
  return 1;
}

// ==== CMapGroup::vfunc_20  @140089980  [high:rtti-vtable]  (orig: FUN_140089980)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140089980(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  undefined4 local_430;
  int local_42c;
  undefined4 local_428;
  undefined1 local_424 [1036];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_438 = *(undefined4 *)(param_2 + 0x414);
  iVar1 = *(int *)(param_2 + 0xc);
  local_434 = *(undefined4 *)(param_2 + 0x418);
  local_430 = *(undefined4 *)(param_2 + 8);
  memcpy(local_424,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_428 = *(undefined4 *)(param_2 + 0x424);
  local_448 = &local_438;
  local_42c = iVar1;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e29,0x418);
  return 1;
}

// ==== CMapGroup::vfunc_19  @140089a40  [high:rtti-vtable]  (orig: FUN_140089a40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140089a40(longlong param_1,longlong param_2,char *param_3)

{
  int iVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined4 local_444;
  int local_440;
  char local_43c [16];
  undefined1 local_42c [1028];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_448 = *(undefined4 *)(param_2 + 0x414);
  iVar1 = *(int *)(param_2 + 0xc);
  local_444 = *(undefined4 *)(param_2 + 8);
  memcpy(local_42c,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_440 = iVar1;
  tq::SafeCopy(local_43c,param_3,0x10);
  local_458 = &local_448;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e24,0x418);
  return 1;
}

// ==== CMapGroup::vfunc_18  @140089af0  [high:rtti-vtable]  (orig: FUN_140089af0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140089af0(longlong param_1,longlong param_2,char *param_3,undefined4 param_4)

{
  int iVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined4 local_444;
  int local_440;
  char local_43c [16];
  undefined1 local_42c [1028];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  iVar1 = *(int *)(param_2 + 0xc);
  local_444 = *(undefined4 *)(param_2 + 8);
  local_448 = param_4;
  memcpy(local_42c,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_440 = iVar1;
  tq::SafeCopy(local_43c,param_3,0x10);
  local_458 = &local_448;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e24,0x418);
  return 1;
}

// ==== CMapGroup::vfunc_17  @140089ba0  [high:rtti-vtable]  (orig: FUN_140089ba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140089ba0(longlong param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined4 local_42c;
  undefined1 local_428 [1040];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_438 = *(undefined4 *)(param_2 + 0x414);
  iVar1 = *(int *)(param_2 + 0xc);
  local_434 = *(undefined4 *)(param_2 + 8);
  memcpy(local_428,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_448 = &local_438;
  local_430 = iVar1;
  local_42c = param_3;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e25,0x418);
  return 1;
}

// ==== CMapGroup::vfunc_22  @140089c50  [high:rtti-vtable]  (orig: FUN_140089c50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140089c50(longlong param_1,undefined4 param_2,undefined4 param_3,void *param_4)

{
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438 [2];
  undefined1 local_430 [1048];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_438[0] = param_3;
  memcpy(local_430,param_4,0x228);
  local_448 = local_438;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),param_2,0x2713,0x230);
  return;
}

// ==== CMapGroup::vfunc_23  @140089ce0  [high:rtti-vtable]  (orig: FUN_140089ce0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140089ce0(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,
                       void *param_5,int param_6)

{
  ulonglong uVar1;
  ulonglong extraout_RAX;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  int local_434;
  undefined1 local_430 [1048];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_4 - 1U < 0x13) {
    local_438 = param_3;
    local_434 = param_4;
    memcpy(local_430,param_5,(longlong)param_6);
    local_448 = &local_438;
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                      (*(longlong **)(param_1 + 0x80),param_2,0x2714,0x418);
  }
  else {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x9f1);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = extraout_RAX & 0xffffffffffffff00;
  }
  return uVar1;
}

// ==== CMapGroup::vfunc_24  @140089db0  [high:rtti-vtable]  (orig: FUN_140089db0)
void FUN_140089db0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_5;
  local_c = param_6;
  local_18 = param_3;
  local_14 = param_4;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),param_2,0x271a,0x10,&local_18);
  return;
}

// ==== CMapGroup::vfunc_25  @140089e00  [high:rtti-vtable]  (orig: FUN_140089e00)
void FUN_140089e00(longlong param_1,char *param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  
  lVar2 = -1;
  pcVar3 = param_2;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),0,0x9c41,~(uint)lVar2,param_2);
  return;
}

// ==== CMapGroup::vfunc_31  @140089e40  [high:rtti-vtable]  (orig: FUN_140089e40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140089e40(longlong param_1,undefined4 param_2,char *param_3,char *param_4)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  ulonglong uVar4;
  longlong lVar5;
  char *pcVar6;
  ulonglong uVar7;
  undefined1 auStack_458 [32];
  undefined4 *local_438;
  undefined4 local_428;
  char local_424 [1020];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  pcVar6 = param_3;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
    pcVar6[(longlong)(local_424 + (-1 - (longlong)param_3))] = cVar1;
  } while (cVar1 != '\0');
  uVar4 = 0xffffffffffffffff;
  do {
    if (uVar4 == 0) break;
    uVar4 = uVar4 - 1;
    cVar1 = *param_3;
    param_3 = param_3 + 1;
  } while (cVar1 != '\0');
  pcVar6 = param_4;
  do {
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
    pcVar6[(longlong)(local_424 + ~uVar4 + (-1 - (longlong)param_4))] = cVar1;
  } while (cVar1 != '\0');
  lVar5 = -1;
  do {
    if (lVar5 == 0) break;
    lVar5 = lVar5 + -1;
    cVar1 = *param_4;
    param_4 = param_4 + 1;
  } while (cVar1 != '\0');
  uVar7 = 0xe;
  local_428 = param_2;
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  if (0xe < uVar2) {
    do {
      if (uVar7 != *(uint *)(param_1 + 0x68)) {
        local_438 = &local_428;
        (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                  (*(longlong **)(param_1 + 0x80),uVar7 & 0xffffffff,0x271e,
                   ((int)(local_424 + ~uVar4) + ~(uint)lVar5) - (int)&local_428);
      }
      uVar7 = uVar7 + 1;
      iVar3 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
    } while (uVar7 < (ulonglong)(longlong)iVar3);
  }
  return;
}

// ==== CMapGroup::vfunc_34  @140089f50  [high:rtti-vtable]  (orig: FUN_140089f50)
void FUN_140089f50(longlong param_1,longlong param_2)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  
  uVar3 = 0xe;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  if (0xe < uVar1) {
    do {
      if (uVar3 != *(uint *)(param_1 + 0x68)) {
        (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                  (*(longlong **)(param_1 + 0x80),uVar3 & 0xffffffff,0x2723,
                   (*(int *)(param_2 + 0x418) - (int)param_2) + -8,param_2 + 8);
      }
      uVar3 = uVar3 + 1;
      iVar2 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
    } while (uVar3 < (ulonglong)(longlong)iVar2);
  }
  return;
}

// ==== CMapGroup::vfunc_35  @140089fe0  [high:rtti-vtable]  (orig: FUN_140089fe0)
void FUN_140089fe0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_res8;
  undefined4 local_resc;
  
  local_res8 = param_2;
  local_resc = param_3;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),1,0x753c,8,&local_res8);
  return;
}

// ==== CMapGroup::vfunc_36  @14008a030  [high:rtti-vtable]  (orig: FUN_14008a030)
void FUN_14008a030(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),1,0x7542,0xea65,local_res10);
  return;
}

// ==== CMapGroup::vfunc_0  @14008a070  [high:rtti-vtable]  (orig: FUN_14008a070)
void FUN_14008a070(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  undefined4 local_res8;
  undefined4 local_resc;
  
  uVar3 = 0xe;
  local_res8 = param_2;
  local_resc = param_3;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x78) + 0x18))();
  if (0xe < uVar1) {
    do {
      if (uVar3 != *(uint *)(param_1 + 0x60)) {
        (**(code **)(**(longlong **)(param_1 + 0x78) + 0x50))
                  (*(longlong **)(param_1 + 0x78),uVar3 & 0xffffffff,0x2721,8,&local_res8);
      }
      uVar3 = uVar3 + 1;
      iVar2 = (**(code **)(**(longlong **)(param_1 + 0x78) + 0x18))();
    } while (uVar3 < (ulonglong)(longlong)iVar2);
  }
  return;
}

// ==== CMapGroup::vfunc_29  @14008a150  [high:rtti-vtable]  (orig: FUN_14008a150)
void FUN_14008a150(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e26,0xea65,local_res10);
  return;
}

// ==== CMapGroup::vfunc_30  @14008a190  [high:rtti-vtable]  (orig: FUN_14008a190)
void FUN_14008a190(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),2,0x4e27,0xea65,local_res10);
  return;
}

// ==== CMapGroup::helper_14008d050  @14008d050  [medium:callgraph-r2]  (orig: FUN_14008d050)
undefined8 FUN_14008d050(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  
  plVar1 = (longlong *)*param_1;
  uVar5 = param_1[1];
  lVar3 = 0;
  lVar2 = lVar3;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar4 = lVar3;
    if (plVar1 == (longlong *)0x0) goto LAB_14008d091;
  }
  lVar4 = *plVar1;
  if (plVar1 != (longlong *)0x0) {
    lVar2 = lVar4;
  }
LAB_14008d091:
  if ((ulonglong)(*(longlong *)(lVar2 + 0x38) + *(longlong *)(lVar4 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar2 = lVar3;
  if (param_1 != (longlong *)0x0) {
    lVar2 = *param_1;
  }
  if (*(ulonglong *)(lVar2 + 0x28) <= uVar5) {
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    uVar5 = uVar5 - *(longlong *)(lVar3 + 0x28);
  }
  lVar3 = lRam0000000000000020;
  if (param_1 != (longlong *)0x0) {
    lVar3 = *(longlong *)(*param_1 + 0x20);
  }
  return *(undefined8 *)(lVar3 + uVar5 * 8);
}

// ==== CMapGroup::helper_14008d100  @14008d100  [medium:callgraph-r2]  (orig: FUN_14008d100)
longlong * FUN_14008d100(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)*param_1;
  lVar3 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar2 = lVar3;
    if (plVar1 == (longlong *)0x0) goto LAB_14008d133;
  }
  lVar2 = *plVar1;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = lVar2;
  }
LAB_14008d133:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar2 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1[1] = param_1[1] + 1;
  return param_1;
}

// ==== CMapGroup::helper_14008d840  @14008d840  [medium:callgraph-r1]  (orig: FUN_14008d840)
void FUN_14008d840(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroup::helper_14008d8d0  @14008d8d0  [medium:callgraph-r1]  (orig: FUN_14008d8d0)
void FUN_14008d8d0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroup::helper_14008e150  @14008e150  [medium:callgraph-r3]  (orig: FUN_14008e150)
void FUN_14008e150(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x25) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_14008f060  @14008f060  [medium:callgraph-r3]  (orig: FUN_14008f060)
void FUN_14008f060(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x25) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x25) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x25);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x25);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x25);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x25);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014008f084. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::helper_14008f0f0  @14008f0f0  [medium:callgraph-r3]  (orig: FUN_14008f0f0)
void FUN_14008f0f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014008f114. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::helper_14008f210  @14008f210  [medium:callgraph-r3]  (orig: FUN_14008f210)
void FUN_14008f210(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x1f) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x1f) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x1f);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x1f);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x1f);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x1f);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014008f234. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::vfunc_13  @1400924e0  [high:rtti-vtable]  (orig: FUN_1400924e0)
undefined8 FUN_1400924e0(longlong param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    uVar4 = 0xe;
    while( true ) {
      iVar1 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
      if ((ulonglong)(longlong)iVar1 <= uVar4) break;
      if (uVar4 == *(uint *)(param_1 + 0x68)) {
        plVar3 = (longlong *)FUN_140008520(uVar4 & 0xffffffff);
        (**(code **)(*plVar3 + 0x58))(plVar3,param_2,param_3);
      }
      else {
        plVar3 = (longlong *)FUN_140008520(uVar4 & 0xffffffff);
        (**(code **)(*plVar3 + 0x58))(plVar3,param_2,0xffffffff);
      }
      uVar4 = uVar4 + 1;
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CMapGroup::vfunc_12  @1400925e0  [high:rtti-vtable]  (orig: FUN_1400925e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400925e0(longlong param_1,longlong param_2,undefined4 param_3,undefined8 param_4,
             undefined4 param_5,undefined2 param_6)

{
  ulonglong uVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined1 auStack_508 [32];
  undefined8 local_4e8;
  undefined4 local_4e0;
  undefined2 local_4d8;
  undefined2 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined1 local_4b8;
  undefined4 local_4a8;
  ulonglong local_4a0;
  longlong local_498;
  undefined8 local_490;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_4a8 = param_3;
  local_498 = param_1;
  if (param_2 == 0) {
    local_4e8 = CONCAT44(local_4e8._4_4_,0x93f);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    FUN_14015b240(local_488);
    local_4b8 = 1;
    local_4c0 = 0;
    local_4c8 = 0;
    local_4d0 = 0;
    local_4d8 = param_6;
    local_4e0 = param_5;
    local_4e8 = param_4;
    iVar2 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_2);
    if (iVar2 == 0) {
      FUN_14015b2c0(local_488);
      uVar3 = 0;
    }
    else {
      local_4a0 = 0xe;
      while( true ) {
        uVar1 = local_4a0;
        iVar2 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
        if ((ulonglong)(longlong)iVar2 <= uVar1) break;
        if (uVar1 == *(uint *)(param_1 + 0x68)) {
          plVar4 = (longlong *)FUN_140008520(uVar1 & 0xffffffff);
          (**(code **)(*plVar4 + 0x58))(plVar4,local_488,param_3);
        }
        else {
          plVar4 = (longlong *)FUN_140008520(uVar1 & 0xffffffff);
          (**(code **)(*plVar4 + 0x58))(plVar4,local_488,0xffffffff);
        }
        local_4a0 = uVar1 + 1;
      }
      FUN_14015b2c0(local_488);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CMapGroup::vfunc_27  @140092780  [high:rtti-vtable]  (orig: FUN_140092780)
void FUN_140092780(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),1,0x753b,0xea65,local_res10);
  return;
}

// ==== CMapGroup::helper_140094fb0  @140094fb0  [medium:callgraph-r3]  (orig: FUN_140094fb0)
void FUN_140094fb0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140095010  @140095010  [medium:callgraph-r3]  (orig: FUN_140095010)
void FUN_140095010(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_1400951c0  @1400951c0  [medium:callgraph-r1]  (orig: FUN_1400951c0)
void FUN_1400951c0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0xc)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0xc);
  return;
}

// ==== CMapGroup::helper_140095240  @140095240  [medium:callgraph-r1]  (orig: FUN_140095240)
void FUN_140095240(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x14)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x14);
  return;
}

// ==== CMapGroup::helper_1400952f0  @1400952f0  [medium:callgraph-r3]  (orig: FUN_1400952f0)
void FUN_1400952f0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x49) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140095350  @140095350  [medium:callgraph-r3]  (orig: FUN_140095350)
void FUN_140095350(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x49) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_140095410  @140095410  [medium:callgraph-r3]  (orig: FUN_140095410)
void FUN_140095410(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x25) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140095470  @140095470  [medium:callgraph-r3]  (orig: FUN_140095470)
void FUN_140095470(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x25) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_1400955c0  @1400955c0  [medium:callgraph-r3]  (orig: FUN_1400955c0)
void FUN_1400955c0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x1f) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140095620  @140095620  [medium:callgraph-r3]  (orig: FUN_140095620)
void FUN_140095620(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x1f) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_140095710  @140095710  [medium:callgraph-r3]  (orig: FUN_140095710)
void FUN_140095710(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140095770  @140095770  [medium:callgraph-r3]  (orig: FUN_140095770)
void FUN_140095770(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroup::helper_140095820  @140095820  [medium:callgraph-r3]  (orig: FUN_140095820)
void FUN_140095820(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140095844. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::helper_140095b90  @140095b90  [medium:callgraph-r3]  (orig: FUN_140095b90)
void FUN_140095b90(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x49) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x49) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x49);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x49);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x49);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x49);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140095bb4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::helper_140095c20  @140095c20  [medium:callgraph-r3]  (orig: FUN_140095c20)
void FUN_140095c20(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x25) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x25) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x25);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x25);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x25);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x25);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140095c44. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroup::helper_140096270  @140096270  [medium:callgraph-r3]  (orig: FUN_140096270)
void FUN_140096270(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x25) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroup::helper_140098b50  @140098b50  [medium:callgraph-r1]  (orig: FUN_140098b50)
void FUN_140098b50(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x25);
  while (cVar1 == '\0') {
    FUN_140098b50(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x25);
  }
  return;
}

// ==== CMapGroup::helper_140099bf0  @140099bf0  [medium:callgraph-r1]  (orig: FUN_140099bf0)
void FUN_140099bf0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x24) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  return;
}

// ==== CMapGroup::helper_140099c50  @140099c50  [medium:callgraph-r3]  (orig: FUN_140099c50)
undefined8 *
FUN_140099c50(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined1 *)((longlong)puVar1 + 0x24) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  }
  return puVar1;
}

// ==== CMapGroup::helper_140099d90  @140099d90  [medium:callgraph-r2]  (orig: FUN_140099d90)
undefined8 * FUN_140099d90(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14008f0f0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_140099f7c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_140099f7c:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140094fb0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140095010(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_140094fb0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140095010(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140094fb0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_140095010(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapGroup::helper_14009a150  @14009a150  [medium:callgraph-r1]  (orig: FUN_14009a150)
void FUN_14009a150(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CMapGroup::helper_14009a1e0  @14009a1e0  [medium:callgraph-r1]  (orig: FUN_14009a1e0)
void FUN_14009a1e0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 9) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x49) = 0;
  return;
}

// ==== CMapGroup::helper_14009a240  @14009a240  [medium:callgraph-r1]  (orig: FUN_14009a240)
void FUN_14009a240(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x24) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  return;
}

// ==== CMapGroup::helper_14009a2a0  @14009a2a0  [medium:callgraph-r1]  (orig: FUN_14009a2a0)
void FUN_14009a2a0(void)

{
  void *pvVar1;
  
  pvVar1 = operator_new(0x40);
  if (pvVar1 != (void *)0x0) {
    *(void **)pvVar1 = pvVar1;
  }
  if ((undefined8 *)((longlong)pvVar1 + 8) != (undefined8 *)0x0) {
    *(undefined8 *)((longlong)pvVar1 + 8) = pvVar1;
  }
  return;
}

// ==== CMapGroup::helper_14009a3a0  @14009a3a0  [medium:callgraph-r1]  (orig: FUN_14009a3a0)
void FUN_14009a3a0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x20);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x1e) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x1f) = 0;
  return;
}

// ==== CMapGroup::helper_14009a400  @14009a400  [medium:callgraph-r1]  (orig: FUN_14009a400)
void FUN_14009a400(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x24) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  return;
}

// ==== CMapGroup::helper_14009a460  @14009a460  [medium:callgraph-r3]  (orig: FUN_14009a460)
undefined8 *
FUN_14009a460(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined1 *)((longlong)puVar1 + 0x24) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x25) = 0;
  }
  return puVar1;
}

// ==== CMapGroup::helper_14009a4f0  @14009a4f0  [medium:callgraph-r1]  (orig: FUN_14009a4f0)
void FUN_14009a4f0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CMapGroup::helper_14009ac90  @14009ac90  [medium:callgraph-r3]  (orig: FUN_14009ac90)
void FUN_14009ac90(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x49);
  while (cVar1 == '\0') {
    FUN_14009ac90(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x49);
  }
  return;
}

// ==== CMapGroup::helper_14009ace0  @14009ace0  [medium:callgraph-r3]  (orig: FUN_14009ace0)
void FUN_14009ace0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14009ace0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x25);
  }
  return;
}

// ==== CMapGroup::helper_14009ae60  @14009ae60  [medium:callgraph-r3]  (orig: FUN_14009ae60)
void FUN_14009ae60(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x1f);
  while (cVar1 == '\0') {
    FUN_14009ae60(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x1f);
  }
  return;
}

// ==== CMapGroup::helper_14009aeb0  @14009aeb0  [medium:callgraph-r3]  (orig: FUN_14009aeb0)
void FUN_14009aeb0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14009aeb0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x25);
  }
  return;
}

// ==== CMapGroup::helper_14009af00  @14009af00  [medium:callgraph-r3]  (orig: FUN_14009af00)
void FUN_14009af00(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14009af00(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroup::helper_14009ce90  @14009ce90  [medium:callgraph-r0]  (orig: FUN_14009ce90)
void FUN_14009ce90(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_140098b50(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_14009e180  @14009e180  [medium:callgraph-r1]  (orig: FUN_14009e180)
longlong * FUN_14009e180(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14009cf70(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_140099d90(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_14009f630  @14009f630  [medium:callgraph-r2]  (orig: FUN_14009f630)
undefined8 * FUN_14009f630(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x49) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140095b90(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x49) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 9;
        plVar8 = plVar8 + 9;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14009f81c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x49);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x49) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x49);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x49);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14009f81c:
  if ((char)plVar2[9] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[9] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_1400952f0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(*plVar9 + 0x48) != '\x01') || (*(char *)(plVar9[2] + 0x48) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x48) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_140095350(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(plVar9[2] + 0x48) = 1;
              FUN_1400952f0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        else {
          if ((char)plVar9[9] == '\0') {
            *(undefined1 *)(plVar9 + 9) = 1;
            *(undefined1 *)(plVar8 + 9) = 0;
            FUN_140095350(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x49) == '\0') {
            if ((*(char *)(plVar9[2] + 0x48) != '\x01') || (*(char *)(*plVar9 + 0x48) != '\x01')) {
              if (*(char *)(*plVar9 + 0x48) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x48) = 1;
                *(undefined1 *)(plVar9 + 9) = 0;
                FUN_1400952f0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 9) = (char)plVar8[9];
              *(undefined1 *)(plVar8 + 9) = 1;
              *(undefined1 *)(*plVar9 + 0x48) = 1;
              FUN_140095350(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 9) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 9) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapGroup::helper_14009f9f0  @14009f9f0  [medium:callgraph-r2]  (orig: FUN_14009f9f0)
void FUN_14009f9f0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x49);
  while (cVar1 == '\0') {
    FUN_14009ac90(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x49);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_14009fac0  @14009fac0  [medium:callgraph-r2]  (orig: FUN_14009fac0)
undefined8 * FUN_14009fac0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x25) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14008f060(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x25) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x24);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x24);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_14009fcac;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x25);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x25);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_14009fcac:
  if (*(char *)((longlong)plVar5 + 0x24) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x24) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_140095410(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(*plVar11 + 0x24) != '\x01') || (*(char *)(plVar11[2] + 0x24) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x24) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_140095470(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(plVar11[2] + 0x24) = 1;
              FUN_140095410(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_140095470(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(plVar11[2] + 0x24) != '\x01') || (*(char *)(*plVar11 + 0x24) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x24) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_140095410(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(*plVar11 + 0x24) = 1;
              FUN_140095470(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x24) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMapGroup::helper_14009fe80  @14009fe80  [medium:callgraph-r2]  (orig: FUN_14009fe80)
void FUN_14009fe80(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14009ace0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_1400a0000  @1400a0000  [medium:callgraph-r2]  (orig: FUN_1400a0000)
undefined8 * FUN_1400a0000(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x1f) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14008f210(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x1f) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x1f) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x1f) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x1e);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x1e);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_1400a01ec;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x1f) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x1f) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x1f);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x1f);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x1f) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x1f);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x1f);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_1400a01ec:
  if (*(char *)((longlong)plVar5 + 0x1e) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x1e) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x1e) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x1e) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x1e) = 0;
            FUN_1400955c0(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x1f) == '\0') {
            if ((*(char *)(*plVar11 + 0x1e) != '\x01') || (*(char *)(plVar11[2] + 0x1e) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x1e) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x1e) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x1e) = 0;
                FUN_140095620(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x1e) = *(undefined1 *)((longlong)plVar10 + 0x1e);
              *(undefined1 *)((longlong)plVar10 + 0x1e) = 1;
              *(undefined1 *)(plVar11[2] + 0x1e) = 1;
              FUN_1400955c0(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x1e) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x1e) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x1e) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x1e) = 0;
            FUN_140095620(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x1f) == '\0') {
            if ((*(char *)(plVar11[2] + 0x1e) != '\x01') || (*(char *)(*plVar11 + 0x1e) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x1e) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x1e) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x1e) = 0;
                FUN_1400955c0(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x1e) = *(undefined1 *)((longlong)plVar10 + 0x1e);
              *(undefined1 *)((longlong)plVar10 + 0x1e) = 1;
              *(undefined1 *)(*plVar11 + 0x1e) = 1;
              FUN_140095620(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x1e) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x1e) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMapGroup::helper_1400a03c0  @1400a03c0  [medium:callgraph-r2]  (orig: FUN_1400a03c0)
void FUN_1400a03c0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x1f);
  while (cVar1 == '\0') {
    FUN_14009ae60(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x1f);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_1400a0490  @1400a0490  [medium:callgraph-r2]  (orig: FUN_1400a0490)
undefined8 * FUN_1400a0490(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x25) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140095c20(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x25) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x24);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x24);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_1400a067c;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x25);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x25) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x25);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x25);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_1400a067c:
  if (*(char *)((longlong)plVar5 + 0x24) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x24) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_140096270(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(*plVar11 + 0x24) != '\x01') || (*(char *)(plVar11[2] + 0x24) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x24) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_14008e150(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(plVar11[2] + 0x24) = 1;
              FUN_140096270(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x24) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x24) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x24) = 0;
            FUN_14008e150(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x25) == '\0') {
            if ((*(char *)(plVar11[2] + 0x24) != '\x01') || (*(char *)(*plVar11 + 0x24) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x24) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x24) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
                FUN_140096270(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x24) = *(undefined1 *)((longlong)plVar10 + 0x24);
              *(undefined1 *)((longlong)plVar10 + 0x24) = 1;
              *(undefined1 *)(*plVar11 + 0x24) = 1;
              FUN_14008e150(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x24) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x24) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMapGroup::helper_1400a0850  @1400a0850  [medium:callgraph-r2]  (orig: FUN_1400a0850)
void FUN_1400a0850(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x25);
  while (cVar1 == '\0') {
    FUN_14009aeb0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x25);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_1400a0920  @1400a0920  [medium:callgraph-r2]  (orig: FUN_1400a0920)
undefined8 * FUN_1400a0920(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_140095820(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400a0b0c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400a0b0c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140095710(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140095770(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_140095710(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_140095770(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_140095710(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_140095770(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapGroup::helper_1400a0ce0  @1400a0ce0  [medium:callgraph-r2]  (orig: FUN_1400a0ce0)
void FUN_1400a0ce0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14009af00(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroup::helper_1400a29f0  @1400a29f0  [medium:callgraph-r0]  (orig: FUN_1400a29f0)
void FUN_1400a29f0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14009e180((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a2a60  @1400a2a60  [medium:callgraph-r0]  (orig: FUN_1400a2a60)
void FUN_1400a2a60(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  lVar3 = *(longlong *)(param_1 + 0x38);
  while (lVar3 != 0) {
    if (*(longlong *)(param_1 + 0x38) != 0) {
      uVar2 = *(longlong *)(param_1 + 0x38) + -1 + *(longlong *)(param_1 + 0x30);
      if (*(ulonglong *)(param_1 + 0x28) <= uVar2) {
        uVar2 = uVar2 - *(ulonglong *)(param_1 + 0x28);
      }
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                 (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar2 * 8) + 0x10));
      plVar1 = (longlong *)(param_1 + 0x38);
      *plVar1 = *plVar1 + -1;
      if (*plVar1 == 0) {
        *(undefined8 *)(param_1 + 0x30) = 0;
      }
    }
    lVar3 = *(longlong *)(param_1 + 0x38);
  }
  lVar3 = *(longlong *)(param_1 + 0x28);
  while (lVar3 != 0) {
    lVar3 = lVar3 + -1;
    if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar3 * 8) != 0) {
      operator_delete(*(void **)(*(longlong *)(param_1 + 0x20) + lVar3 * 8));
    }
  }
  if (*(void **)(param_1 + 0x20) == (void *)0x0) {
    *(undefined8 *)(param_1 + 0x28) = 0;
    *(undefined8 *)(param_1 + 0x20) = 0;
  }
  else {
    operator_delete(*(void **)(param_1 + 0x20));
    *(undefined8 *)(param_1 + 0x28) = 0;
    *(undefined8 *)(param_1 + 0x20) = 0;
  }
  return;
}

// ==== CMapGroup::helper_1400a3600  @1400a3600  [medium:callgraph-r0]  (orig: FUN_1400a3600)
void FUN_1400a3600(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = (longlong *)param_1[5];
  plVar2 = (longlong *)*plVar1;
  *plVar1 = (longlong)plVar1;
  *(undefined8 *)(param_1[5] + 8) = param_1[5];
  param_1[6] = 0;
  if (plVar2 != (longlong *)param_1[5]) {
    do {
      plVar1 = (longlong *)*plVar2;
      operator_delete(plVar2);
      plVar2 = plVar1;
    } while (plVar1 != (longlong *)param_1[5]);
  }
  operator_delete((void *)param_1[5]);
  param_1[5] = 0;
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapGroup::helper_1400a4360  @1400a4360  [medium:callgraph-r1]  (orig: FUN_1400a4360)
longlong * FUN_1400a4360(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14009f9f0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x49) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x49) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x49);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x49);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x49);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x49);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14009f630(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_1400a4510  @1400a4510  [medium:callgraph-r1]  (orig: FUN_1400a4510)
longlong * FUN_1400a4510(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14009fe80(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x25) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x25);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x25);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x25);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x25);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14009fac0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_1400a4870  @1400a4870  [medium:callgraph-r1]  (orig: FUN_1400a4870)
longlong * FUN_1400a4870(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400a03c0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x1f) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x1f) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x1f);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x1f);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x1f);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x1f);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400a0000(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_1400a4bd0  @1400a4bd0  [medium:callgraph-r1]  (orig: FUN_1400a4bd0)
longlong * FUN_1400a4bd0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400a0850(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x25) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x25);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x25);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x25);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x25);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400a0490(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_1400a4d80  @1400a4d80  [medium:callgraph-r1]  (orig: FUN_1400a4d80)
longlong * FUN_1400a4d80(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400a0ce0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400a0920(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroup::helper_1400a5f80  @1400a5f80  [medium:callgraph-r2]  (orig: FUN_1400a5f80)
void FUN_1400a5f80(longlong param_1,undefined8 *param_2,longlong *param_3,longlong *param_4)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined **local_a0 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_88 [56];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  lVar4 = *param_3;
  lVar5 = param_3[1];
  do {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    if (param_3[1] == param_4[1]) {
      return;
    }
    uVar6 = *param_2;
    lVar3 = param_2[1];
    plVar2 = (longlong *)*param_3;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar2 = (longlong *)*param_3;
      lVar1 = 0;
      if (plVar2 != (longlong *)0x0) goto LAB_1400a6020;
    }
    else {
LAB_1400a6020:
      lVar1 = *plVar2;
    }
    if (param_3[1] == *(longlong *)(lVar1 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = FUN_14009ad30(param_1,lVar3,*(undefined8 *)(lVar3 + 8),param_3[1] + 0x10,lVar4,lVar5,
                          uVar6);
    if (*(longlong *)(param_1 + 0x30) == 0x555555555555555) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50,"list<T> too long");
      std::exception::exception((exception *)local_a0);
      local_a0[0] = std::logic_error::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>
                (local_88,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                           *)local_50);
      local_a0[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_a0,(ThrowInfo *)&DAT_140944488);
    }
    *(longlong *)(param_1 + 0x30) = *(longlong *)(param_1 + 0x30) + 1;
    *(longlong *)(lVar3 + 8) = lVar1;
    **(longlong **)(lVar1 + 8) = lVar1;
    plVar2 = (longlong *)*param_3;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar2 = (longlong *)*param_3;
      lVar3 = 0;
      if (plVar2 != (longlong *)0x0) goto LAB_1400a60ea;
    }
    else {
LAB_1400a60ea:
      lVar3 = *plVar2;
    }
    if (param_3[1] == *(longlong *)(lVar3 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    param_3[1] = *(longlong *)param_3[1];
  } while( true );
}

// ==== CMapGroup::vfunc_7  @1400a6190  [high:rtti-vtable]  (orig: FUN_1400a6190)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400a6190(undefined8 *param_1,longlong *param_2,longlong param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  uint uVar9;
  ulonglong uVar10;
  undefined1 auStack_518 [32];
  uint *local_4f8;
  undefined4 local_4f0;
  uint local_4e8;
  undefined4 local_4e4;
  uint local_4e0;
  uint local_4dc;
  undefined8 *local_4d8;
  longlong local_4d0;
  ulonglong *local_4c8;
  ulonglong *local_4b8;
  ulonglong *local_4a8;
  ulonglong *local_498;
  ulonglong *local_488;
  undefined8 local_478;
  uint local_468;
  uint local_464;
  uint local_460;
  undefined1 local_45c [1044];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_4d8 = param_1;
  local_4d0 = param_3;
  if (param_3 == 0) {
    log_InlineLogWARNING("null msg point found in CMapGroup::SendModMultiClientMsg.");
    uVar3 = 0;
  }
  else if ((int)(0x400 - (uint)*(ushort *)(param_3 + 8)) < 0) {
    log_InlineLogERROR("CMapGroup::SendModMultiClientMsg, (_MAX_MSGSIZE - pMsg->GetSize()) < 0.");
    uVar3 = 0;
  }
  else if ((param_2[4] - param_2[3] & 0xfffffffffffffffcU) == 0) {
    uVar3 = 0;
  }
  else {
    local_4c8 = (ulonglong *)
                ((ulonglong)(longlong)(int)(0x400 - (uint)*(ushort *)(param_3 + 8)) >> 2);
    if (((int)local_4c8 < 2) || ((ulonglong)(param_2[4] - param_2[3] >> 2) < 2)) {
      uVar10 = 0;
      local_4f0 = 0;
      local_4f8._0_4_ = (uint)*(ushort *)(param_3 + 8);
      puVar4 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0xd),0xffffffff,*(undefined2 *)(param_3 + 10)
                             ,param_3 + 0xc);
      if (puVar4 == (undefined8 *)0x0) {
        local_4f8 = (uint *)CONCAT44(local_4f8._4_4_,0x80e);
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      puVar5 = (undefined4 *)param_2[3];
      local_4c8 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar5) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e0 = 0;
      uVar8 = uVar10;
      local_4c8 = puVar1;
      while( true ) {
        puVar2 = (undefined4 *)param_2[4];
        local_488 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_488 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_488)) {
          _invalid_parameter_noinfo();
        }
        if (puVar5 == puVar2) goto LAB_1400a656e;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar7 = uVar10;
        }
        else {
          uVar7 = *puVar1;
        }
        if (*(undefined4 **)(uVar7 + 0x20) <= puVar5) {
          _invalid_parameter_noinfo();
        }
        (**(code **)*local_4d8)(local_4d8,*puVar5,puVar4);
        local_4e0 = (int)uVar8 + 1;
        uVar8 = (ulonglong)local_4e0;
        if (2000 < local_4e0) break;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar7 = uVar10;
        }
        else {
          uVar7 = *puVar1;
        }
        if (*(undefined4 **)(uVar7 + 0x20) <= puVar5) {
          _invalid_parameter_noinfo();
        }
        puVar5 = puVar5 + 1;
      }
      log_InlineLogERROR("CMapGroup::SendModMultiClientMsg. Dead Loop");
LAB_1400a656e:
      if (puVar4 != (undefined8 *)0x0) {
        (**(code **)*puVar4)(puVar4,1);
      }
    }
    else {
      local_464 = (uint)*(ushort *)(param_3 + 10);
      local_460 = (uint)*(ushort *)(param_3 + 8);
      memmove(local_45c,(void *)(param_3 + 0xc),(ulonglong)*(ushort *)(param_3 + 8));
      puVar5 = (undefined4 *)param_2[3];
      uVar10 = 0;
      local_498 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar5) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e8 = 0;
      local_4dc = 0;
      uVar8 = uVar10;
      local_498 = puVar1;
      do {
        puVar2 = (undefined4 *)param_2[4];
        local_4b8 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_4b8 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4b8)) {
          _invalid_parameter_noinfo();
        }
        if (puVar5 == puVar2) goto LAB_1400a6582;
        local_4e8 = 0;
        local_468 = 0;
        uVar7 = uVar10;
        do {
          uVar9 = (uint)uVar7;
          if ((int)local_4c8 <= (int)uVar9) break;
          local_4dc = (int)uVar8 + 1;
          uVar8 = (ulonglong)local_4dc;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar7 = uVar10;
          }
          else {
            uVar7 = *puVar1;
          }
          if (*(undefined4 **)(uVar7 + 0x20) <= puVar5) {
            _invalid_parameter_noinfo();
          }
          local_4e4 = *puVar5;
          memmove(local_45c + (longlong)(int)uVar9 * 4 + (longlong)(int)local_460,&local_4e4,4);
          uVar9 = uVar9 + 1;
          uVar7 = (ulonglong)uVar9;
          local_4e8 = uVar9;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar6 = uVar10;
          }
          else {
            uVar6 = *puVar1;
          }
          if (*(undefined4 **)(uVar6 + 0x20) <= puVar5) {
            _invalid_parameter_noinfo();
          }
          puVar5 = puVar5 + 1;
          puVar2 = (undefined4 *)param_2[4];
          local_4a8 = (ulonglong *)0x0;
          if (puVar2 < (undefined4 *)param_2[3]) {
            _invalid_parameter_noinfo();
          }
          local_4a8 = (ulonglong *)*param_2;
          if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4a8)) {
            _invalid_parameter_noinfo();
          }
        } while (puVar5 != puVar2);
        if (0 < (int)uVar9) {
          local_4f8 = &local_468;
          local_468 = uVar9;
          (**(code **)(*(longlong *)local_4d8[0x10] + 0x50))
                    ((longlong *)local_4d8[0x10],1,0x753e,0x418);
        }
      } while ((uint)uVar8 < 0x7d1);
      log_InlineLogERROR("CMapGroup::SendModMultiClientMsg. Dead Loop");
    }
LAB_1400a6582:
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CMapGroup::vfunc_8  @1400a65b0  [high:rtti-vtable]  (orig: FUN_1400a65b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400a65b0(undefined8 *param_1,longlong *param_2,longlong param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  undefined1 auStack_518 [32];
  uint *local_4f8;
  uint local_4e8;
  undefined4 local_4e4;
  uint local_4e0;
  uint local_4dc;
  undefined8 *local_4d8;
  longlong local_4d0;
  ulonglong *local_4c8;
  ulonglong *local_4b8;
  ulonglong *local_4a8;
  ulonglong *local_498;
  ulonglong *local_488;
  undefined8 local_478;
  uint local_468;
  undefined4 local_464;
  int local_460;
  undefined1 local_45c [1044];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_4d8 = param_1;
  local_4d0 = param_3;
  if (param_3 == 0) {
    log_InlineLogWARNING("null msg point found in CMapGroup::SendMultiClientMsg.");
    uVar3 = 0;
  }
  else if (0x400 - *(int *)(param_3 + 0xc) < 0) {
    log_InlineLogERROR("CMapGroup::SendMultiClientMsg, (_MAX_MSGSIZE - pMsg->GetSize()) < 0.");
    uVar3 = 0;
  }
  else if ((param_2[4] - param_2[3] & 0xfffffffffffffffcU) == 0) {
    uVar3 = 0;
  }
  else {
    local_4c8 = (ulonglong *)((ulonglong)(longlong)(0x400 - *(int *)(param_3 + 0xc)) >> 2);
    if (((int)local_4c8 < 2) || ((ulonglong)(param_2[4] - param_2[3] >> 2) < 2)) {
      puVar4 = (undefined4 *)param_2[3];
      uVar9 = 0;
      local_4c8 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar4) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e0 = 0;
      uVar7 = uVar9;
      local_4c8 = puVar1;
      while( true ) {
        puVar2 = (undefined4 *)param_2[4];
        local_488 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_488 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_488)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar2) goto LAB_1400a691e;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar6 = uVar9;
        }
        else {
          uVar6 = *puVar1;
        }
        if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        (**(code **)*local_4d8)(local_4d8,*puVar4,param_3);
        local_4e0 = (int)uVar7 + 1;
        uVar7 = (ulonglong)local_4e0;
        if (2000 < local_4e0) break;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar6 = uVar9;
        }
        else {
          uVar6 = *puVar1;
        }
        if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        puVar4 = puVar4 + 1;
      }
      log_InlineLogERROR("CMapGroup::SendMultiClientMsg. Dead Loop");
    }
    else {
      local_464 = *(undefined4 *)(param_3 + 8);
      local_460 = *(int *)(param_3 + 0xc);
      memmove(local_45c,(void *)(param_3 + 0x10),(longlong)local_460);
      puVar4 = (undefined4 *)param_2[3];
      uVar9 = 0;
      local_498 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar4) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e8 = 0;
      local_4dc = 0;
      uVar7 = uVar9;
      local_498 = puVar1;
      do {
        puVar2 = (undefined4 *)param_2[4];
        local_4b8 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_4b8 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4b8)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar2) goto LAB_1400a691e;
        local_4e8 = 0;
        local_468 = 0;
        uVar6 = uVar9;
        do {
          uVar8 = (uint)uVar6;
          if ((int)local_4c8 <= (int)uVar8) break;
          local_4dc = (int)uVar7 + 1;
          uVar7 = (ulonglong)local_4dc;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar6 = uVar9;
          }
          else {
            uVar6 = *puVar1;
          }
          if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
            _invalid_parameter_noinfo();
          }
          local_4e4 = *puVar4;
          memmove(local_45c + (longlong)(int)uVar8 * 4 + (longlong)local_460,&local_4e4,4);
          uVar8 = uVar8 + 1;
          uVar6 = (ulonglong)uVar8;
          local_4e8 = uVar8;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar5 = uVar9;
          }
          else {
            uVar5 = *puVar1;
          }
          if (*(undefined4 **)(uVar5 + 0x20) <= puVar4) {
            _invalid_parameter_noinfo();
          }
          puVar4 = puVar4 + 1;
          puVar2 = (undefined4 *)param_2[4];
          local_4a8 = (ulonglong *)0x0;
          if (puVar2 < (undefined4 *)param_2[3]) {
            _invalid_parameter_noinfo();
          }
          local_4a8 = (ulonglong *)*param_2;
          if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4a8)) {
            _invalid_parameter_noinfo();
          }
        } while (puVar4 != puVar2);
        if (0 < (int)uVar8) {
          local_4f8 = &local_468;
          local_468 = uVar8;
          (**(code **)(*(longlong *)local_4d8[0x10] + 0x50))
                    ((longlong *)local_4d8[0x10],1,0x753e,0x418);
        }
      } while ((uint)uVar7 < 0x7d1);
      log_InlineLogERROR("CMapGroup::SendMultiClientMsg. Dead Loop");
    }
LAB_1400a691e:
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CMapGroup::SendMultiOSClientMsg  @1400a6950  [high:log-string]  (orig: FUN_1400a6950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400a6950(longlong param_1,longlong *param_2,longlong param_3)

{
  uint *puVar1;
  ulonglong *puVar2;
  undefined4 *puVar3;
  ulonglong *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  uint *puVar8;
  ulonglong uVar9;
  undefined4 *puVar10;
  longlong lVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  uint uVar14;
  ulonglong uVar15;
  undefined1 auStack_508 [32];
  uint *local_4e8;
  uint local_4d8;
  uint local_4d4;
  undefined4 local_4d0 [2];
  longlong local_4c8;
  longlong local_4c0;
  longlong *local_4b8;
  longlong *local_4a8;
  ulonglong *local_498;
  ulonglong *local_488;
  undefined8 local_478;
  uint local_468 [3];
  undefined4 local_45c;
  int local_458;
  undefined1 local_454 [1036];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_4c8 = param_1;
  local_4c0 = param_3;
  if (param_3 == 0) {
    log_InlineLogERROR("CMapGroup::SendMultiOSClientMsg pMsg is NULL.");
    uVar5 = 0;
  }
  else if (0x400 - *(int *)(param_3 + 0xc) < 0) {
    log_InlineLogERROR("CMapGroup::SendMultiOSClientMsg (_MAX_MSGSIZE - pMsg->GetSize()) < 0.");
    uVar5 = 0;
  }
  else if ((param_2[4] - param_2[3] & 0xfffffffffffffffcU) == 0) {
    uVar5 = 0;
  }
  else {
    local_4b8 = (longlong *)((ulonglong)(longlong)(0x3fc - *(int *)(param_3 + 0xc)) >> 2);
    puVar8 = (uint *)param_2[3];
    if ((param_2[4] - (longlong)puVar8 & 0xfffffffffffffffcU) == 4) {
      uVar14 = *puVar8;
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,5);
      (**(code **)(*plVar6 + 0x28))(plVar6,uVar14 & 0xfffff,uVar14 >> 0x14,param_3);
      uVar5 = 1;
    }
    else if ((int)local_4b8 < 2) {
      local_4b8 = (longlong *)0x0;
      if ((uint *)param_2[4] < puVar8) {
        _invalid_parameter_noinfo();
      }
      plVar6 = (longlong *)*param_2;
      puVar1 = (uint *)param_2[4];
      local_4a8 = (longlong *)0x0;
      local_4b8 = plVar6;
      if (puVar1 < (uint *)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      param_2 = (longlong *)*param_2;
      local_4a8 = param_2;
      while( true ) {
        if ((plVar6 == (longlong *)0x0) || (plVar6 != param_2)) {
          _invalid_parameter_noinfo();
        }
        if (puVar8 == puVar1) break;
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar6;
        }
        if (*(uint **)(lVar11 + 0x20) <= puVar8) {
          _invalid_parameter_noinfo();
        }
        uVar14 = *puVar8;
        plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(local_4c8 + 0x68));
        local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,5);
        (**(code **)(*plVar7 + 0x28))(plVar7,uVar14 & 0xfffff,uVar14 >> 0x14,param_3);
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar6;
        }
        if (*(uint **)(lVar11 + 0x20) <= puVar8) {
          _invalid_parameter_noinfo();
        }
        puVar8 = puVar8 + 1;
      }
      uVar5 = 1;
    }
    else {
      uVar15 = 0;
      local_468[1] = 0;
      local_45c = 6;
      local_468[2] = *(undefined4 *)(param_3 + 8);
      local_458 = *(int *)(param_3 + 0xc);
      memmove(local_454,(void *)(param_3 + 0x10),(longlong)local_458);
      puVar10 = (undefined4 *)param_2[3];
      local_498 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar10) {
        _invalid_parameter_noinfo();
      }
      puVar2 = (ulonglong *)*param_2;
      puVar3 = (undefined4 *)param_2[4];
      local_488 = (ulonglong *)0x0;
      local_498 = puVar2;
      if (puVar3 < (undefined4 *)param_2[3]) {
        _invalid_parameter_noinfo();
      }
      puVar4 = (ulonglong *)*param_2;
      local_4d8 = 0;
      local_4d4 = 0;
      uVar9 = uVar15;
      local_488 = puVar4;
      do {
        if ((puVar2 == (ulonglong *)0x0) || (puVar2 != puVar4)) {
          _invalid_parameter_noinfo();
        }
        if (puVar10 == puVar3) goto LAB_1400a6cde;
        local_4d8 = 0;
        uVar12 = uVar15;
        do {
          uVar14 = (uint)uVar12;
          if ((int)local_4b8 <= (int)uVar14) break;
          local_4d4 = (int)uVar9 + 1;
          uVar9 = (ulonglong)local_4d4;
          if (puVar2 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar12 = uVar15;
          }
          else {
            uVar12 = *puVar2;
          }
          if (*(undefined4 **)(uVar12 + 0x20) <= puVar10) {
            _invalid_parameter_noinfo();
          }
          local_4d0[0] = *puVar10;
          memmove(local_454 + (longlong)(int)uVar14 * 4 + (longlong)local_458,local_4d0,4);
          uVar14 = uVar14 + 1;
          uVar12 = (ulonglong)uVar14;
          local_4d8 = uVar14;
          if (puVar2 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar13 = uVar15;
          }
          else {
            uVar13 = *puVar2;
          }
          if (*(undefined4 **)(uVar13 + 0x20) <= puVar10) {
            _invalid_parameter_noinfo();
          }
          puVar10 = puVar10 + 1;
          if ((puVar2 == (ulonglong *)0x0) || (puVar2 != puVar4)) {
            _invalid_parameter_noinfo();
          }
        } while (puVar10 != puVar3);
        if (0 < (int)uVar14) {
          local_4e8 = local_468;
          local_468[0] = uVar14;
          (**(code **)(**(longlong **)(local_4c8 + 0x80) + 0x50))
                    (*(longlong **)(local_4c8 + 0x80),6,0x3ff);
        }
      } while ((uint)uVar9 < 0x7d1);
      log_InlineLogERROR("CMapGroup::SendMultiOSClientMsg. Dead Loop");
LAB_1400a6cde:
      uVar5 = 1;
    }
  }
  return uVar5;
}

// ==== CMapGroup::vfunc_32  @1400a6d10  [high:rtti-vtable]  (orig: FUN_1400a6d10)
void FUN_1400a6d10(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7,char param_8)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  uint uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined4 local_48;
  undefined4 local_44;
  int local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
  if (*(longlong *)(lVar7 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar7 + 0x88) + 0xd0))();
  plVar2 = (longlong *)*plVar8;
  plVar9 = *(longlong **)plVar8[6];
  while( true ) {
    plVar3 = (longlong *)plVar8[6];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar9[4];
    if (lVar7 != 0) {
      if (*(longlong *)(lVar7 + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        iVar5 = 0;
      }
      else {
        iVar5 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 8))();
      }
      if ((iVar5 == param_4) && (*(char *)(lVar7 + 0x68) != '\0')) {
        FUN_1402beac0(lVar7,param_2,param_3,param_5,param_6,param_7);
        return;
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar9 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar9 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar9[1] + 0x29);
        plVar4 = (longlong *)plVar9[1];
        plVar3 = plVar9;
        while ((plVar9 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar9[2]))) {
          cVar1 = *(char *)(plVar9[1] + 0x29);
          plVar4 = (longlong *)plVar9[1];
          plVar3 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  if (param_8 == '\0') {
    return;
  }
  local_3c = param_5;
  local_38 = param_6;
  local_34 = param_7;
  uVar10 = 0xe;
  local_48 = param_2;
  local_44 = param_3;
  local_40 = param_4;
  uVar6 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  if (uVar6 < 0xf) {
    return;
  }
  do {
    if (uVar10 != *(uint *)(param_1 + 0x68)) {
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),uVar10 & 0xffffffff,0x2724,0x18,&local_48);
    }
    uVar10 = uVar10 + 1;
    iVar5 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
  } while (uVar10 < (ulonglong)(longlong)iVar5);
  return;
}

// ==== CMapGroup::vfunc_33  @1400a6f90  [high:rtti-vtable]  (orig: FUN_1400a6f90)
void FUN_1400a6f90(longlong param_1,int param_2,undefined4 param_3,int param_4,int param_5,
                  char param_6)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  int local_48;
  undefined4 local_44;
  int local_40;
  int local_3c;
  
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
  if (*(longlong *)(lVar7 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar7 + 0x88) + 0xd0))();
  plVar1 = (longlong *)*plVar8;
  plVar9 = *(longlong **)plVar8[6];
  do {
    plVar2 = (longlong *)plVar8[6];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar8)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar2) {
      if (param_6 != '\0') {
        local_3c = param_5;
        uVar10 = 0xe;
        local_48 = param_2;
        local_44 = param_3;
        local_40 = param_4;
        uVar6 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
        if (0xe < uVar6) {
          do {
            if (uVar10 != *(uint *)(param_1 + 0x68)) {
              (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                        (*(longlong **)(param_1 + 0x80),uVar10 & 0xffffffff,0x271f,0x10,&local_48);
            }
            uVar10 = uVar10 + 1;
            iVar5 = (**(code **)(**(longlong **)(param_1 + 0x80) + 0x18))();
          } while (uVar10 < (ulonglong)(longlong)iVar5);
        }
      }
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)plVar9[4];
    if ((plVar2 != (longlong *)0x0) &&
       (iVar5 = (**(code **)(*(longlong *)plVar2[0xc] + 0x10))((longlong *)plVar2[0xc],4),
       iVar5 == 0xf)) {
      if (plVar2[0xc] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        iVar5 = 0;
      }
      else {
        iVar5 = (**(code **)(*(longlong *)plVar2[0xc] + 0x10))((longlong *)plVar2[0xc],0x17);
      }
      if (iVar5 == param_4) {
        iVar5 = (**(code **)(*plVar2 + 8))(plVar2);
        if (param_5 == 0) {
          if (iVar5 == param_2) goto LAB_1400a70ed;
        }
        else if (iVar5 == param_2) {
LAB_1400a7126:
          iVar5 = (**(code **)(*plVar2 + 8))(plVar2);
          if (iVar5 == param_2) {
            if ((plVar2[0xc] == 0) || ((char)plVar2[0xd] == '\0')) {
LAB_1400a7172:
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              (**(code **)(*(longlong *)plVar2[0xc] + 0x60))((longlong *)plVar2[0xc],1,param_3);
            }
          }
        }
        else {
LAB_1400a70ed:
          if (*(int *)((longlong)plVar2 + 0xb4) == 0) {
            cVar4 = FUN_1402bf900(plVar2);
            if (cVar4 == '\0') goto LAB_1400a7172;
          }
          else if (param_5 != 0) goto LAB_1400a7126;
        }
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar4 = *(char *)(*plVar2 + 0x29);
        plVar9 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar4 == '\0') {
          cVar4 = *(char *)(*plVar2 + 0x29);
          plVar9 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar4 = *(char *)(plVar9[1] + 0x29);
        plVar3 = (longlong *)plVar9[1];
        plVar2 = plVar9;
        while ((plVar9 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar9[2]))) {
          cVar4 = *(char *)(plVar9[1] + 0x29);
          plVar3 = (longlong *)plVar9[1];
          plVar2 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMapGroup::helper_1400a96b0  @1400a96b0  [medium:callgraph-r0]  (orig: FUN_1400a96b0)
void FUN_1400a96b0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a3f50((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a9790  @1400a9790  [medium:callgraph-r3]  (orig: FUN_1400a9790)
void FUN_1400a9790(longlong param_1,ulonglong param_2)

{
  void *pvVar1;
  void *_Dst;
  ulonglong uVar2;
  ulonglong uVar3;
  void *_Dst_00;
  rsize_t rVar4;
  longlong lVar5;
  longlong lVar6;
  
  uVar2 = *(ulonglong *)(param_1 + 0x28);
  if (0x492492492492492 - uVar2 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_14008d710();
  }
  uVar3 = uVar2 >> 1;
  if (uVar3 < 8) {
    uVar3 = 8;
  }
  if ((param_2 < uVar3) && (uVar2 <= 0x492492492492492 - uVar3)) {
    param_2 = uVar3;
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30);
  _Dst_00 = (void *)FUN_1400950a0(param_1 + 0x10,uVar2 + param_2);
  lVar5 = uVar3 * 8;
  pvVar1 = (void *)(lVar5 + *(longlong *)(param_1 + 0x20));
  lVar6 = (*(longlong *)(param_1 + 0x28) * 8 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >>
          3;
  rVar4 = lVar6 * 8;
  _Dst = (void *)(rVar4 + lVar5 + (longlong)_Dst_00);
  if (lVar6 != 0) {
    memmove_s((void *)(lVar5 + (longlong)_Dst_00),rVar4,pvVar1,rVar4);
  }
  if (param_2 < uVar3) {
    lVar6 = (longlong)(param_2 * 8) >> 3;
    if (lVar6 != 0) {
      rVar4 = lVar6 << 3;
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    pvVar1 = (void *)(*(longlong *)(param_1 + 0x20) + param_2 * 8);
    lVar5 = (lVar5 - (longlong)pvVar1) + *(longlong *)(param_1 + 0x20) >> 3;
    rVar4 = lVar5 * 8;
    if (lVar5 != 0) {
      memmove_s(_Dst_00,rVar4,pvVar1,rVar4);
    }
    if (param_2 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst_00),0,param_2 << 3);
    }
  }
  else {
    rVar4 = (lVar5 >> 3) * 8;
    if (lVar5 >> 3 != 0) {
      memmove_s(_Dst,rVar4,*(void **)(param_1 + 0x20),rVar4);
    }
    if (param_2 - uVar3 != 0) {
      memset((void *)(rVar4 + (longlong)_Dst),0,(param_2 - uVar3) * 8);
    }
    if (uVar3 != 0) {
      memset(_Dst_00,0,uVar3 << 3);
    }
  }
  if (*(void **)(param_1 + 0x20) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x20));
  }
  *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + param_2;
  *(void **)(param_1 + 0x20) = _Dst_00;
  return;
}

// ==== CMapGroup::helper_1400a9ad0  @1400a9ad0  [medium:callgraph-r0]  (orig: FUN_1400a9ad0)
void FUN_1400a9ad0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a4360((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a9b40  @1400a9b40  [medium:callgraph-r0]  (orig: FUN_1400a9b40)
void FUN_1400a9b40(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a4510((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a9bb0  @1400a9bb0  [medium:callgraph-r0]  (orig: FUN_1400a9bb0)
void FUN_1400a9bb0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a4870((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a9f40  @1400a9f40  [medium:callgraph-r0]  (orig: FUN_1400a9f40)
void FUN_1400a9f40(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a4bd0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400a9fb0  @1400a9fb0  [medium:callgraph-r0]  (orig: FUN_1400a9fb0)
void FUN_1400a9fb0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400a4d80((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroup::helper_1400b4e00  @1400b4e00  [medium:callgraph-r2]  (orig: FUN_1400b4e00)
void FUN_1400b4e00(longlong param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  
  if (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 1U) {
    FUN_1400a9790(param_1,1,param_3,param_4,0xfffffffffffffffe);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  if (*(ulonglong *)(param_1 + 0x28) <= uVar3) {
    uVar3 = uVar3 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar3 * 8) == 0) {
    pvVar2 = operator_new(0x38);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar3 * 8) = pvVar2;
  }
  puVar1 = *(undefined8 **)(*(longlong *)(param_1 + 0x20) + uVar3 * 8);
  if (puVar1 == (undefined8 *)0x0) {
    *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  }
  else {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               (param_2 + 2));
    *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  }
  return;
}

// ==== CMapGroup::helper_1400b6290  @1400b6290  [medium:callgraph-r3]  (orig: FUN_1400b6290)
void FUN_1400b6290(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  undefined1 local_res8;
  undefined8 local_38;
  undefined8 local_30;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(longlong *)(param_1 + 0x28) - lVar4 >> 4;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar2 - lVar4 >> 4;
    if (0xfffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14008e820();
    }
    uVar7 = param_3 + lVar4;
    if (uVar6 < uVar7) {
      if (0xfffffffffffffff - (uVar6 >> 1) < uVar6) {
        uVar6 = 0;
      }
      else {
        uVar6 = uVar6 + (uVar6 >> 1);
      }
      if (uVar6 < uVar7) {
        uVar6 = uVar7;
      }
      lVar2 = FUN_140096be0(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      local_res8 = (undefined1)lVar2;
      FUN_14009cc60(lVar4 * 0x10 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140098660(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_140098660(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x10 + lVar2,param_1 + 0x10,local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x10 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar4 - (longlong)pvVar1 >> 4)) * 0x10 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)(lVar2 - *(longlong *)(param_2 + 8) >> 4) < param_3) {
      local_38 = *param_4;
      local_30 = param_4[1];
      FUN_140098660(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x10,
                    param_1 + 0x10);
      FUN_14009cc60(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4),
                    &local_38,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar5 = *(undefined8 **)(param_2 + 8); puVar5 != (undefined8 *)(lVar4 + param_3 * -0x10)
          ; puVar5 = puVar5 + 2) {
        *puVar5 = local_38;
        puVar5[1] = local_30;
      }
    }
    else {
      local_38 = *param_4;
      local_30 = param_4[1];
      lVar4 = lVar2 + param_3 * -0x10;
      uVar3 = FUN_140098660(lVar4,lVar2,lVar2,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_1400a17a0(*(undefined8 *)(param_2 + 8),lVar4,lVar2);
      puVar8 = *(undefined8 **)(param_2 + 8);
      puVar5 = puVar8 + param_3 * 2;
      for (; puVar8 != puVar5; puVar8 = puVar8 + 2) {
        *puVar8 = local_38;
        puVar8[1] = local_30;
      }
    }
  }
  return;
}

// ==== CMapGroup::helper_1400b85d0  @1400b85d0  [medium:callgraph-r0]  (orig: FUN_1400b85d0)
undefined8 * FUN_1400b85d0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a150(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400b8650  @1400b8650  [medium:callgraph-r0]  (orig: FUN_1400b8650)
undefined8 * FUN_1400b8650(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a1e0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x49) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400b86d0  @1400b86d0  [medium:callgraph-r0]  (orig: FUN_1400b86d0)
undefined8 * FUN_1400b86d0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a240(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400b87b0  @1400b87b0  [medium:callgraph-r0]  (orig: FUN_1400b87b0)
undefined8 * FUN_1400b87b0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a3a0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x1f) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400b8830  @1400b8830  [medium:callgraph-r0]  (orig: FUN_1400b8830)
undefined8 * FUN_1400b8830(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a400(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400b88b0  @1400b88b0  [medium:callgraph-r0]  (orig: FUN_1400b88b0)
undefined8 * FUN_1400b88b0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a4f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroup::helper_1400c2240  @1400c2240  [medium:callgraph-r0]  (orig: FUN_1400c2240)
longlong FUN_1400c2240(longlong param_1,undefined1 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *local_30;
  undefined8 local_28;
  
  uVar7 = 0xfffffffffffffffe;
  *(undefined1 *)(param_1 + 8) = *param_2;
  puVar1 = (undefined8 *)(param_1 + 0x10);
  local_30 = operator_new(8);
  plVar6 = (longlong *)0x0;
  plVar5 = plVar6;
  if (local_30 != (longlong *)0x0) {
    *local_30 = (longlong)puVar1;
    plVar5 = local_30;
  }
  *puVar1 = plVar5;
  uVar3 = FUN_14009a2a0(puVar1);
  *(undefined8 *)(param_1 + 0x38) = uVar3;
  *(undefined8 *)(param_1 + 0x40) = 0;
  puVar2 = (undefined8 *)(param_1 + 0x48);
  plVar4 = operator_new(8);
  plVar5 = plVar6;
  if (plVar4 != (longlong *)0x0) {
    *plVar4 = (longlong)puVar2;
    plVar5 = plVar4;
  }
  *puVar2 = plVar5;
  *(undefined8 *)(param_1 + 0x60) = 0;
  *(undefined8 *)(param_1 + 0x68) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined4 *)(param_1 + 0x88) = 0x40800000;
  local_28 = *(undefined8 *)(param_1 + 0x38);
  if ((undefined8 *)*puVar1 != (undefined8 *)0x0) {
    plVar6 = *(longlong **)*puVar1;
  }
  local_30 = (longlong *)*plVar6;
  FUN_1400c0570(puVar2,9,&local_30,param_4,uVar7);
  *(undefined8 *)(param_1 + 0x78) = 7;
  *(undefined8 *)(param_1 + 0x80) = 8;
  return param_1;
}

// ==== CMapGroup::ctor_or_dtor  @1400c4a90  [high:vtable-assign]  (orig: FUN_1400c4a90)
undefined8 * FUN_1400c4a90(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *local_res10;
  longlong *local_res18;
  longlong *local_res20;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  
  *param_1 = CMapGroup::vftable;
  param_1[1] = CMapGroup::vftable;
  *(undefined4 *)(param_1 + 2) = 500;
  puVar1 = param_1 + 3;
  local_res10 = puVar1;
  local_res18 = operator_new(8);
  plVar3 = (longlong *)0x0;
  plVar2 = plVar3;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)puVar1;
    plVar2 = local_res18;
  }
  *puVar1 = plVar2;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  *(undefined4 *)(param_1 + 0xb) = 0;
  *(undefined4 *)((longlong)param_1 + 0x5c) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)((longlong)param_1 + 100) = 0;
  param_1[0xf] = 0;
  param_1[0x1c] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x23] = 0;
  param_1[0x24] = 0;
  param_1[0x25] = 0;
  param_1[0x26] = 0;
  param_1[0x27] = 0;
  param_1[0x28] = 0;
  param_1[0x29] = 0;
  param_1[0x2a] = 0;
  param_1[0x2b] = 0;
  param_1[0x2c] = 0;
  param_1[0x2d] = 0;
  param_1[0x2f] = 0;
  param_1[0x30] = 0;
  param_1[0x31] = 0;
  param_1[0x32] = 0;
  param_1[0x33] = 0;
  param_1[0x34] = 0;
  param_1[0x35] = 0;
  param_1[0x36] = 0;
  param_1[0x37] = 0;
  param_1[0x38] = 0;
  param_1[0x39] = 0;
  param_1[0x3a] = 0;
  param_1[0x3b] = 0;
  param_1[0x3c] = 0;
  param_1[0x41] = 0;
  param_1[0x44] = 0;
  param_1[0x47] = 0;
  puVar1 = param_1 + 0x4d;
  local_res10 = puVar1;
  local_res20 = local_res18;
  local_res18 = operator_new(8);
  plVar2 = plVar3;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)puVar1;
    plVar2 = local_res18;
  }
  *puVar1 = plVar2;
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  *(undefined4 *)(param_1 + 0x53) = 0;
  *(undefined4 *)((longlong)param_1 + 0x29c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2dc) = 100;
  puVar1 = param_1 + 0x5c;
  local_res10 = puVar1;
  local_res20 = local_res18;
  local_res18 = operator_new(8);
  plVar2 = plVar3;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)puVar1;
    plVar2 = local_res18;
  }
  *puVar1 = plVar2;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  *(undefined4 *)(param_1 + 0x62) = 0;
  *(undefined4 *)((longlong)param_1 + 0x314) = 2;
  *(undefined1 *)(param_1 + 99) = 0;
  *(undefined4 *)((longlong)param_1 + 0x31c) = 0;
  *(undefined4 *)(param_1 + 100) = 0;
  local_res20 = local_res18;
  FUN_1400b85d0(param_1 + 0x69);
  puVar1 = param_1 + 0x71;
  local_res10 = puVar1;
  local_res18 = operator_new(8);
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)puVar1;
    plVar3 = local_res18;
  }
  *puVar1 = plVar3;
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  local_res20 = local_res18;
  FUN_1400194a0(param_1 + 0x78);
  *(undefined4 *)((longlong)param_1 + 0x404) = 0;
  memset(param_1 + 0x81,0,0x2c);
  FUN_1400b8650(param_1 + 0x87);
  FUN_1400b86d0(param_1 + 0x8f);
  local_res20 = param_1 + 0x97;
  FUN_1400c2240(local_res20,&local_res18,&local_res10);
  FUN_1400b86d0(param_1 + 0xa9);
  FUN_1400b86d0(param_1 + 0xb1);
  FUN_1400b8550(param_1 + 0xb9);
  FUN_1400b87b0(param_1 + 0xc1);
  FUN_1400546e0(param_1 + 0xc9);
  *(undefined4 *)(param_1 + 0xd1) = 0;
  *(undefined4 *)((longlong)param_1 + 0x68c) = 0;
  *(undefined4 *)(param_1 + 0xd2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x694) = 0;
  *(undefined4 *)(param_1 + 0xd3) = 0;
  *(undefined1 *)((longlong)param_1 + 0x69c) = 0;
  *(undefined1 *)((longlong)param_1 + 0x69d) = 0;
  *(undefined1 *)((longlong)param_1 + 0x69e) = 0;
  *(undefined1 *)((longlong)param_1 + 0x69f) = 0;
  *(undefined1 *)(param_1 + 0xd4) = 0;
  *(undefined1 *)((longlong)param_1 + 0x6a1) = 1;
  *(undefined1 *)((longlong)param_1 + 0x6a2) = 0;
  *(undefined1 *)((longlong)param_1 + 0x6a3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x6a4) = 0;
  *(undefined4 *)(param_1 + 0xd5) = 0;
  *(undefined4 *)((longlong)param_1 + 0x6ac) = 0;
  *(undefined4 *)(param_1 + 0xd6) = 0x4b0;
  *(undefined4 *)((longlong)param_1 + 0x6b4) = 0xf;
  *(undefined4 *)(param_1 + 0xd7) = 0x14;
  *(undefined4 *)((longlong)param_1 + 0x6bc) = 0x19;
  *(undefined4 *)(param_1 + 0xd8) = 0x28;
  *(undefined4 *)((longlong)param_1 + 0x6c4) = 10000;
  *(undefined4 *)(param_1 + 0xd9) = 5;
  *(undefined4 *)((longlong)param_1 + 0x6cc) = 0;
  *(undefined4 *)(param_1 + 0xda) = 0x5a;
  *(undefined4 *)((longlong)param_1 + 0x6d4) = 5;
  *(undefined4 *)(param_1 + 0xdb) = 3;
  FUN_1400b8830(param_1 + 0xdc);
  FUN_1400b84d0(param_1 + 0xe7);
  *(undefined4 *)(param_1 + 0xf0) = 3;
  FUN_1400b88b0(param_1 + 0x100);
  *(undefined4 *)(param_1 + 0x108) = 0x19;
  *(undefined4 *)((longlong)param_1 + 0x844) = 0x352;
  *(undefined4 *)(param_1 + 0x109) = 0x50;
  *(undefined4 *)(param_1 + 0xd) = 0;
  param_1[0xe] = 0;
  param_1[0x10] = 0;
  param_1[0x11] = 0;
  param_1[0x12] = 0;
  param_1[0x13] = 0;
  param_1[0x14] = 0;
  param_1[0x15] = 0;
  param_1[0x16] = 0;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  param_1[0x1a] = 0;
  param_1[0x45] = 0;
  *(undefined4 *)(param_1 + 0x54) = 1;
  *(undefined4 *)((longlong)param_1 + 0x2a4) = 0;
  param_1[0x48] = 0;
  param_1[0x49] = 0;
  param_1[0x4a] = 0;
  param_1[0x4b] = 0;
  param_1[0x4c] = 0;
  param_1[0x1d] = 0;
  param_1[0x3e] = 0;
  param_1[0x1e] = 0;
  param_1[0x3f] = 0;
  param_1[0x40] = 0;
  *(undefined4 *)(param_1 + 0x55) = 0;
  *(undefined1 *)((longlong)param_1 + 0x324) = 0;
  *(undefined1 *)((longlong)param_1 + 0x33c) = 0;
  *(undefined4 *)(param_1 + 0x68) = 0;
  *(undefined1 *)((longlong)param_1 + 0x344) = 0;
  *(undefined4 *)(param_1 + 0x77) = 0;
  *(undefined1 *)((longlong)param_1 + 0x3bc) = 0;
  *(undefined1 *)(param_1 + 0x80) = 0;
  param_1[0x1b] = 0;
  param_1[0x46] = 0;
  param_1[0x21] = 0;
  param_1[0x22] = 0;
  param_1[0x3d] = 0;
  *(undefined4 *)((longlong)param_1 + 0x2ac) = 0;
  *(undefined4 *)(param_1 + 0x56) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2b4) = 0;
  *(undefined4 *)(param_1 + 0x57) = 0;
  *(undefined4 *)((longlong)param_1 + 700) = 0;
  *(undefined4 *)(param_1 + 0x58) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2c4) = 0;
  *(undefined4 *)(param_1 + 0x59) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2cc) = 0;
  *(undefined1 *)(param_1 + 0x5a) = 1;
  *(undefined4 *)((longlong)param_1 + 0x2d4) = 0;
  *(undefined1 *)(param_1 + 0x5b) = 0x14;
  param_1[0x2e] = 0;
  param_1[0x42] = 0;
  param_1[0x43] = 0;
  *(undefined4 *)(param_1 + 0xe4) = 0x3ea;
  *(undefined4 *)((longlong)param_1 + 0x724) = 300;
  *(undefined4 *)(param_1 + 0xe5) = 0x120;
  *(undefined4 *)((longlong)param_1 + 0x72c) = 0x14;
  *(undefined1 *)((longlong)param_1 + 0x731) = 0;
  *(undefined4 *)(param_1 + 0xef) = 0;
  *(undefined1 *)((longlong)param_1 + 0x77c) = 0;
  *(undefined1 *)(param_1 + 0xe6) = 1;
  FUN_14009ce90(param_1 + 0xe7);
  *(undefined4 *)((longlong)param_1 + 0x7d4) = 100;
  local_70 = 100;
  local_6c = 0x5f;
  local_68 = 0x5a;
  local_64 = 0x55;
  local_60 = 0x50;
  local_5c = 0x4b;
  local_58 = 0x46;
  local_54 = 0x41;
  local_50 = 0x3c;
  local_4c = 0x37;
  local_48 = 3;
  local_44 = 7;
  local_40 = 10;
  local_3c = 0xd;
  local_38 = 0xf;
  local_34 = 0xf;
  local_30 = 0xd;
  local_2c = 10;
  local_28 = 9;
  local_24 = 5;
  memcpy((void *)((longlong)param_1 + 0x784),&local_70,0x28);
  memcpy((void *)((longlong)param_1 + 0x7ac),&local_48,0x28);
  *(undefined4 *)(param_1 + 0xfb) = 10;
  *(undefined4 *)((longlong)param_1 + 0x7dc) = 10;
  *(undefined4 *)(param_1 + 0xfc) = 500;
  *(undefined4 *)((longlong)param_1 + 0x7e4) = 10000;
  *(undefined4 *)((longlong)param_1 + 0x7fc) = 10000;
  *(undefined4 *)(param_1 + 0xfd) = 0xdac;
  *(undefined4 *)((longlong)param_1 + 0x7ec) = 6000;
  *(undefined4 *)(param_1 + 0xfe) = 8000;
  *(undefined4 *)((longlong)param_1 + 0x7f4) = 0x2134;
  *(undefined4 *)(param_1 + 0xff) = 10000;
  *(undefined4 *)(param_1 + 0x65) = 0;
  *(undefined4 *)((longlong)param_1 + 0x32c) = 0;
  *(undefined4 *)(param_1 + 0x66) = 0;
  *(undefined4 *)((longlong)param_1 + 0x334) = 0;
  *(undefined4 *)(param_1 + 0x67) = 0;
  return param_1;
}

// ==== CMapGroup::vfunc_26  @1400c5220  [high:rtti-vtable]  (orig: FUN_1400c5220)
void FUN_1400c5220(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001400c5227. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x70) + 0x28))();
  return;
}

// ==== CMapGroup::ctor_or_dtor  @1400c5230  [high:vtable-assign]  (orig: FUN_1400c5230)
void FUN_1400c5230(undefined8 *param_1)

{
  *param_1 = CMapGroup::vftable;
  param_1[1] = CMapGroup::vftable;
  FUN_1400a9fb0(param_1 + 0x100);
  operator_delete((void *)param_1[0x100]);
  FUN_1400a96b0(param_1 + 0xe7);
  operator_delete((void *)param_1[0xe7]);
  FUN_1400a9f40(param_1 + 0xdc);
  operator_delete((void *)param_1[0xdc]);
  FUN_140050610(param_1 + 0xc9);
  operator_delete((void *)param_1[0xc9]);
  FUN_1400a9bb0(param_1 + 0xc1);
  operator_delete((void *)param_1[0xc1]);
  FUN_1400a9720(param_1 + 0xb9);
  operator_delete((void *)param_1[0xb9]);
  FUN_1400a9b40(param_1 + 0xb1);
  operator_delete((void *)param_1[0xb1]);
  FUN_1400a9b40(param_1 + 0xa9);
  operator_delete((void *)param_1[0xa9]);
  if ((void *)param_1[0xa3] != (void *)0x0) {
    operator_delete((void *)param_1[0xa3]);
  }
  param_1[0xa3] = 0;
  param_1[0xa4] = 0;
  param_1[0xa5] = 0;
  operator_delete((void *)param_1[0xa0]);
  FUN_1400a3600(param_1 + 0x99);
  FUN_1400a9b40(param_1 + 0x8f);
  operator_delete((void *)param_1[0x8f]);
  FUN_1400a9ad0(param_1 + 0x87);
  operator_delete((void *)param_1[0x87]);
  FUN_140018350(param_1 + 0x78);
  operator_delete((void *)param_1[0x78]);
  if ((void *)param_1[0x74] != (void *)0x0) {
    operator_delete((void *)param_1[0x74]);
  }
  param_1[0x74] = 0;
  param_1[0x75] = 0;
  param_1[0x76] = 0;
  operator_delete((void *)param_1[0x71]);
  FUN_1400a29f0(param_1 + 0x69);
  operator_delete((void *)param_1[0x69]);
  if ((void *)param_1[0x5f] != (void *)0x0) {
    operator_delete((void *)param_1[0x5f]);
  }
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  operator_delete((void *)param_1[0x5c]);
  if (param_1[0x50] != 0) {
    FUN_140066540(param_1[0x50],param_1[0x51],param_1 + 0x4f,(ulonglong)param_1 & 0xff);
    operator_delete((void *)param_1[0x50]);
  }
  param_1[0x50] = 0;
  param_1[0x51] = 0;
  param_1[0x52] = 0;
  operator_delete((void *)param_1[0x4d]);
  FUN_1400a2a60(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CMapGroup::vfunc_37  @1400c54e0  [high:rtti-vtable]  (orig: FUN_1400c54e0)
void * FUN_1400c54e0(void *param_1,uint param_2)

{
  FUN_1400c5230();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMapGroup::helper_1400e4670  @1400e4670  [medium:callgraph-r3]  (orig: FUN_1400e4670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400e4670(undefined8 *param_1,undefined8 *param_2)

{
  undefined1 auStack_78 [32];
  undefined8 local_58;
  undefined8 local_50;
  undefined4 local_48;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  ulonglong local_18;
  
  if (param_1 != param_2) {
    local_58 = 0xfffffffffffffffe;
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_78;
    local_50 = *param_1;
    local_48 = *(undefined4 *)(param_1 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)(param_1 + 2));
    *param_1 = *param_2;
    *(undefined4 *)(param_1 + 1) = *(undefined4 *)(param_2 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               (param_2 + 2));
    *param_2 = local_50;
    *(undefined4 *)(param_2 + 1) = local_48;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               local_40);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_40);
  }
  return;
}

// ==== CMapGroup::helper_1400e5310  @1400e5310  [medium:callgraph-r3]  (orig: FUN_1400e5310)
undefined8 FUN_1400e5310(longlong *param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong uVar4;
  longlong lVar5;
  
  plVar1 = (longlong *)*param_1;
  lVar3 = param_1[1];
  lVar2 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *plVar1;
  }
  uVar4 = param_2 + lVar3;
  if (uVar4 <= (ulonglong)(*(longlong *)(lVar5 + 0x38) + *(longlong *)(lVar5 + 0x30))) {
    lVar3 = lVar2;
    if (plVar1 != (longlong *)0x0) {
      lVar3 = *plVar1;
    }
    if (*(ulonglong *)(lVar3 + 0x30) <= uVar4) goto LAB_1400e5383;
  }
  _invalid_parameter_noinfo();
LAB_1400e5383:
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar3 = lVar2;
  }
  else {
    lVar3 = *plVar1;
  }
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar3 + 0x30)) <= uVar4) {
    _invalid_parameter_noinfo();
  }
  lVar3 = lVar2;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = *plVar1;
  }
  if (*(ulonglong *)(lVar3 + 0x28) <= uVar4) {
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    uVar4 = uVar4 - *(longlong *)(lVar2 + 0x28);
  }
  lVar3 = lRam0000000000000020;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = *(longlong *)(*plVar1 + 0x20);
  }
  return *(undefined8 *)(lVar3 + uVar4 * 8);
}

// ==== CMapGroup::helper_1400e5420  @1400e5420  [medium:callgraph-r1]  (orig: FUN_1400e5420)
undefined4 * FUN_1400e5420(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 3) {
    if (param_3 != (undefined4 *)0x0) {
      *param_3 = *param_1;
      param_3[1] = param_1[1];
      param_3[2] = param_1[2];
    }
    param_3 = param_3 + 3;
  }
  return param_3;
}

// ==== CMapGroup::helper_1400e5480  @1400e5480  [medium:callgraph-r1]  (orig: FUN_1400e5480)
undefined4 * FUN_1400e5480(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 5) {
    if (param_3 != (undefined4 *)0x0) {
      *param_3 = *param_1;
      param_3[1] = param_1[1];
      param_3[2] = param_1[2];
      param_3[3] = param_1[3];
      param_3[4] = param_1[4];
    }
    param_3 = param_3 + 5;
  }
  return param_3;
}

// ==== CMapGroup::helper_1400e5650  @1400e5650  [medium:callgraph-r3]  (orig: FUN_1400e5650)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_1400e5650(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *param_1,
             basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x28) {
    if (param_3 != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_3,param_1);
    }
    param_3 = param_3 + 0x28;
  }
  return param_3;
}

// ==== CMapGroup::helper_1400e6380  @1400e6380  [medium:callgraph-r2]  (orig: FUN_1400e6380)
undefined8 * FUN_1400e6380(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x25) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140099c50(param_1,puVar3,param_3,puVar3,param_2 + 3,
                           *(undefined1 *)((longlong)param_2 + 0x24),0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6380(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6380(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e6410  @1400e6410  [medium:callgraph-r2]  (orig: FUN_1400e6410)
undefined8 * FUN_1400e6410(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x21) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140015750(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 4),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6410(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6410(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e64a0  @1400e64a0  [medium:callgraph-r2]  (orig: FUN_1400e64a0)
undefined8 * FUN_1400e64a0(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x21) == '\0') {
    puVar1 = (undefined8 *)
             FUN_14004e680(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 4),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e64a0(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e64a0(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e6530  @1400e6530  [medium:callgraph-r2]  (orig: FUN_1400e6530)
undefined8 * FUN_1400e6530(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x21) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140099010(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 4),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6530(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6530(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e65c0  @1400e65c0  [medium:callgraph-r2]  (orig: FUN_1400e65c0)
undefined8 * FUN_1400e65c0(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x21) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140099090(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 4),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e65c0(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e65c0(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e6650  @1400e6650  [medium:callgraph-r2]  (orig: FUN_1400e6650)
undefined8 * FUN_1400e6650(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x49) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140099220(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 9),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x49) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6650(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6650(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e66e0  @1400e66e0  [medium:callgraph-r2]  (orig: FUN_1400e66e0)
undefined8 * FUN_1400e66e0(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x25) == '\0') {
    puVar1 = (undefined8 *)
             FUN_1400992b0(param_1,puVar3,param_3,puVar3,param_2 + 3,
                           *(undefined1 *)((longlong)param_2 + 0x24),0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e66e0(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e66e0(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e6790  @1400e6790  [medium:callgraph-r2]  (orig: FUN_1400e6790)
undefined8 * FUN_1400e6790(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x1f) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140099450(param_1,puVar3,param_3,puVar3,param_2 + 3,
                           *(undefined1 *)((longlong)param_2 + 0x1e),0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x1f) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6790(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6790(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e6820  @1400e6820  [medium:callgraph-r2]  (orig: FUN_1400e6820)
undefined8 * FUN_1400e6820(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x25) == '\0') {
    puVar1 = (undefined8 *)
             FUN_14009a460(param_1,puVar3,param_3,puVar3,param_2 + 3,
                           *(undefined1 *)((longlong)param_2 + 0x24),0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e6820(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e6820(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e68b0  @1400e68b0  [medium:callgraph-r2]  (orig: FUN_1400e68b0)
undefined8 * FUN_1400e68b0(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x29) == '\0') {
    puVar1 = (undefined8 *)
             FUN_1400994d0(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 5),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1400e68b0(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1400e68b0(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMapGroup::helper_1400e7510  @1400e7510  [medium:callgraph-r1]  (orig: FUN_1400e7510)
void FUN_1400e7510(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6380(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x25) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x25);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x25);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x25);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x25);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e75c0  @1400e75c0  [medium:callgraph-r1]  (orig: FUN_1400e75c0)
void FUN_1400e75c0(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6410(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x21) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x21);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x21);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x21);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x21);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7670  @1400e7670  [medium:callgraph-r1]  (orig: FUN_1400e7670)
void FUN_1400e7670(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e64a0(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x21) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x21);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x21);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x21);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x21);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7720  @1400e7720  [medium:callgraph-r1]  (orig: FUN_1400e7720)
void FUN_1400e7720(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6530(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x21) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x21);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x21);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x21);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x21);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e77d0  @1400e77d0  [medium:callgraph-r1]  (orig: FUN_1400e77d0)
void FUN_1400e77d0(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e65c0(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x21) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x21);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x21);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x21);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x21);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7880  @1400e7880  [medium:callgraph-r1]  (orig: FUN_1400e7880)
void FUN_1400e7880(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6650(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x49) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x49);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x49);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x49);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x49);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7930  @1400e7930  [medium:callgraph-r1]  (orig: FUN_1400e7930)
void FUN_1400e7930(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e66e0(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x25) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x25);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x25);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x25);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x25);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e79e0  @1400e79e0  [medium:callgraph-r1]  (orig: FUN_1400e79e0)
void FUN_1400e79e0(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6790(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x1f) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x1f);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x1f);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x1f);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x1f);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7a90  @1400e7a90  [medium:callgraph-r1]  (orig: FUN_1400e7a90)
void FUN_1400e7a90(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e6820(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x25) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x25);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x25);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x25);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x25);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7b40  @1400e7b40  [medium:callgraph-r1]  (orig: FUN_1400e7b40)
void FUN_1400e7b40(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1400e68b0(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x29) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x29);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x29);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x29);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x29);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroup::helper_1400e7d60  @1400e7d60  [medium:callgraph-r2]  (orig: FUN_1400e7d60)
void FUN_1400e7d60(undefined8 *param_1,longlong param_2,longlong param_3)

{
  ulonglong uVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 local_18;
  ulonglong local_10;
  
  uVar1 = param_1[6];
  if (param_1[7] + uVar1 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_18 = *param_1;
  local_10 = uVar1;
  if (param_2 != param_3) {
    do {
      param_3 = param_3 + -1;
      if (param_2 == param_3) {
        return;
      }
      uVar2 = FUN_1400e5310(&local_18,param_3);
      uVar3 = FUN_1400e5310(&local_18,param_2);
      FUN_1400e4670(uVar3,uVar2);
      param_2 = param_2 + 1;
    } while (param_2 != param_3);
  }
  return;
}

// ==== CMapGroup::helper_1400e9030  @1400e9030  [medium:callgraph-r0]  (orig: FUN_1400e9030)
undefined8 * FUN_1400e9030(undefined8 *param_1,longlong param_2)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  puVar2 = operator_new(8);
  if (puVar2 == (undefined8 *)0x0) {
    puVar3 = (void *)0x0;
  }
  else {
    *puVar2 = param_1;
    puVar3 = puVar2;
  }
  *param_1 = puVar3;
  lVar4 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18);
  lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
  uVar5 = (lVar4 >> 1) - (lVar4 >> 0x3f);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar5 != 0) {
    if (0x1555555555555555 < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_14008d840();
    }
    lVar4 = FUN_1400951c0(param_1 + 2,uVar5);
    param_1[3] = lVar4;
    param_1[4] = lVar4;
    param_1[5] = lVar4 + uVar5 * 0xc;
    uVar5 = *(ulonglong *)(param_2 + 0x20);
    if (uVar5 < *(ulonglong *)(param_2 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar1 = *(ulonglong *)(param_2 + 0x18);
    if (*(ulonglong *)(param_2 + 0x20) < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_res18 = SUB81(puVar2,0);
    uVar6 = FUN_1400e5420(uVar1,uVar5,param_1[3],param_1 + 2,local_res18,0,uVar6);
    param_1[4] = uVar6;
  }
  return param_1;
}

// ==== CMapGroup::helper_1400e91a0  @1400e91a0  [medium:callgraph-r0]  (orig: FUN_1400e91a0)
undefined8 * FUN_1400e91a0(undefined8 *param_1,longlong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined1 local_res18;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  puVar3 = operator_new(8);
  if (puVar3 == (undefined8 *)0x0) {
    puVar4 = (void *)0x0;
  }
  else {
    *puVar3 = param_1;
    puVar4 = puVar3;
  }
  *param_1 = puVar4;
  uVar1 = (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x14;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar1 != 0) {
    if (0xccccccccccccccc < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_14008d8d0();
    }
    lVar5 = FUN_140095240(param_1 + 2,uVar1);
    param_1[3] = lVar5;
    param_1[4] = lVar5;
    param_1[5] = lVar5 + uVar1 * 0x14;
    uVar1 = *(ulonglong *)(param_2 + 0x20);
    if (uVar1 < *(ulonglong *)(param_2 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(ulonglong *)(param_2 + 0x18);
    if (*(ulonglong *)(param_2 + 0x20) < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_res18 = SUB81(puVar3,0);
    uVar6 = FUN_1400e5480(uVar2,uVar1,param_1[3],param_1 + 2,local_res18,0,uVar6);
    param_1[4] = uVar6;
  }
  return param_1;
}

// ==== CMapGroup::helper_1400ea840  @1400ea840  [medium:callgraph-r0]  (orig: FUN_1400ea840)
undefined8 *
FUN_1400ea840(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140099bf0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7510(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400ea8d0  @1400ea8d0  [medium:callgraph-r0]  (orig: FUN_1400ea8d0)
undefined8 *
FUN_1400ea8d0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1400156f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e75c0(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400ea960  @1400ea960  [medium:callgraph-r0]  (orig: FUN_1400ea960)
undefined8 *
FUN_1400ea960(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14004e620(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7670(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400ea9f0  @1400ea9f0  [medium:callgraph-r0]  (orig: FUN_1400ea9f0)
undefined8 *
FUN_1400ea9f0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140099ce0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7720(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eaa80  @1400eaa80  [medium:callgraph-r0]  (orig: FUN_1400eaa80)
undefined8 *
FUN_1400eaa80(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a150(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x21) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e77d0(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eab10  @1400eab10  [medium:callgraph-r0]  (orig: FUN_1400eab10)
undefined8 *
FUN_1400eab10(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a1e0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x49) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7880(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eaba0  @1400eaba0  [medium:callgraph-r0]  (orig: FUN_1400eaba0)
undefined8 *
FUN_1400eaba0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a240(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7930(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eac30  @1400eac30  [medium:callgraph-r0]  (orig: FUN_1400eac30)
undefined8 *
FUN_1400eac30(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a3a0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x1f) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e79e0(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eacc0  @1400eacc0  [medium:callgraph-r0]  (orig: FUN_1400eacc0)
undefined8 *
FUN_1400eacc0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a400(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x25) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7a90(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400ead50  @1400ead50  [medium:callgraph-r0]  (orig: FUN_1400ead50)
undefined8 *
FUN_1400ead50(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14009a4f0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1400e7b40(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroup::helper_1400eaf20  @1400eaf20  [medium:callgraph-r2]  (orig: FUN_1400eaf20)
void FUN_1400eaf20(longlong param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  void *pvVar2;
  longlong lVar3;
  
  if (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 1U) {
    FUN_1400a9790(param_1,1,param_3,param_4,0xfffffffffffffffe);
  }
  lVar3 = *(longlong *)(param_1 + 0x30);
  if (lVar3 == 0) {
    lVar3 = *(longlong *)(param_1 + 0x28);
  }
  lVar3 = lVar3 + -1;
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + lVar3 * 8) == 0) {
    pvVar2 = operator_new(0x38);
    *(void **)(*(longlong *)(param_1 + 0x20) + lVar3 * 8) = pvVar2;
  }
  puVar1 = *(undefined8 **)(*(longlong *)(param_1 + 0x20) + lVar3 * 8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = *param_2;
    *(undefined4 *)(puVar1 + 1) = *(undefined4 *)(param_2 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               (param_2 + 2));
  }
  *(longlong *)(param_1 + 0x30) = lVar3;
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CMapGroup::helper_1400eb3f0  @1400eb3f0  [medium:callgraph-r2]  (orig: FUN_1400eb3f0)
undefined8 * FUN_1400eb3f0(undefined8 *param_1,longlong param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined1 local_res18;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  puVar3 = operator_new(8);
  if (puVar3 == (undefined8 *)0x0) {
    puVar4 = (void *)0x0;
  }
  else {
    *puVar3 = param_1;
    puVar4 = puVar3;
  }
  *param_1 = puVar4;
  uVar1 = (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x28;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar1 != 0) {
    if (0x666666666666666 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_1400326f0();
    }
    lVar5 = FUN_140033490(param_1 + 2,uVar1);
    param_1[3] = lVar5;
    param_1[4] = lVar5;
    param_1[5] = lVar5 + uVar1 * 0x28;
    uVar1 = *(ulonglong *)(param_2 + 0x20);
    if (uVar1 < *(ulonglong *)(param_2 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(ulonglong *)(param_2 + 0x18);
    if (*(ulonglong *)(param_2 + 0x20) < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_res18 = SUB81(puVar3,0);
    uVar6 = FUN_1400e5650(uVar2,uVar1,param_1[3],param_1 + 2,local_res18,0,uVar6);
    param_1[4] = uVar6;
  }
  return param_1;
}

// ==== CMapGroup::helper_1400ec4f0  @1400ec4f0  [medium:callgraph-r2]  (orig: FUN_1400ec4f0)
void FUN_1400ec4f0(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  longlong local_28;
  undefined8 *puStack_20;
  
  puVar1 = (undefined8 *)param_1[4];
  puVar7 = (undefined8 *)param_1[3];
  uVar5 = (longlong)puVar1 - (longlong)puVar7 >> 4;
  if (uVar5 < param_2) {
    if (puVar1 < puVar7) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    puStack_20 = puVar1;
    FUN_1400b6290(param_1,&local_28,param_2 - (param_1[4] - param_1[3] >> 4),param_3);
    return;
  }
  if (uVar5 <= param_2) {
    return;
  }
  if (puVar1 < puVar7) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar9 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar8 = lVar9;
  }
  else {
    lVar8 = *plVar2;
  }
  puVar7 = (undefined8 *)(param_2 * 0x10 + uVar5);
  if (puVar7 <= *(undefined8 **)(lVar8 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar9 = *plVar2;
    }
    if (*(undefined8 **)(lVar9 + 0x18) <= puVar7) goto LAB_1400ec5de;
  }
  _invalid_parameter_noinfo();
LAB_1400ec5de:
  if ((puVar7 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar7)) {
    _invalid_parameter_noinfo();
  }
  lVar9 = *param_1;
  if ((puVar1 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar9 == 0) || (lVar9 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (puVar7 != puVar1) {
    puVar3 = (undefined8 *)param_1[4];
    puVar4 = puVar1;
    while (puVar4 != puVar3) {
      puVar6 = puVar4 + 2;
      *(undefined8 *)((longlong)puVar7 + (-0x10 - (longlong)puVar1) + (longlong)puVar6) = *puVar4;
      *(undefined8 *)((longlong)puVar7 + (-8 - (longlong)puVar1) + (longlong)puVar6) = puVar4[1];
      puVar4 = puVar6;
    }
    param_1[4] = ((longlong)puVar3 - (longlong)puVar1 & 0xfffffffffffffff0U) + (longlong)puVar7;
  }
  return;
}

// ==== CMapGroup::helper_1400ec670  @1400ec670  [medium:callgraph-r1]  (orig: FUN_1400ec670)
void FUN_1400ec670(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 local_60;
  undefined4 local_58;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  uVar4 = param_1[6];
  if (uVar4 + param_1[7] < uVar4) {
    _invalid_parameter_noinfo();
  }
  if ((*param_2 == 0) || (*param_2 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  uVar4 = param_2[1] - uVar4;
  uVar1 = param_1[7];
  if ((*param_3 == 0) || (*param_3 != *param_4)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] != param_4[1]) {
    if (uVar4 < uVar1 - uVar4) {
      while( true ) {
        if ((*param_3 == 0) || (*param_3 != *param_4)) {
          _invalid_parameter_noinfo();
        }
        if (param_3[1] == param_4[1]) break;
        puVar2 = (undefined8 *)FUN_14008d050(param_3);
        local_60 = *puVar2;
        local_58 = *(undefined4 *)(puVar2 + 1);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>
                  (local_50,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                             *)(puVar2 + 2));
        FUN_1400eaf20(param_1);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
        FUN_14008d100(param_3);
      }
      lVar3 = param_1[7] - uVar1;
      if (uVar4 == 0) {
        FUN_1400e7d60(param_1,0,lVar3);
      }
      else {
        FUN_1400e7d60(param_1,lVar3,lVar3 + uVar4);
        FUN_1400e7d60(param_1,0,lVar3 + uVar4);
      }
    }
    else {
      while( true ) {
        if ((*param_3 == 0) || (*param_3 != *param_4)) {
          _invalid_parameter_noinfo();
        }
        if (param_3[1] == param_4[1]) break;
        puVar2 = (undefined8 *)FUN_14008d050(param_3);
        local_60 = *puVar2;
        local_58 = *(undefined4 *)(puVar2 + 1);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>
                  (local_50,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                             *)(puVar2 + 2));
        FUN_1400b4e00(param_1,&local_60);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50);
        FUN_14008d100(param_3);
      }
      if (uVar4 < uVar1) {
        FUN_1400e7d60(param_1,uVar4,uVar1);
        FUN_1400e7d60(param_1,uVar1,param_1[7]);
        FUN_1400e7d60(param_1,uVar4,param_1[7]);
      }
    }
  }
  return;
}

// ==== CMapGroup::helper_1400ef8d0  @1400ef8d0  [medium:callgraph-r1]  (orig: FUN_1400ef8d0)
void FUN_1400ef8d0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined1 local_res10;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  uStack_60 = *(undefined8 **)(param_1 + 0x38);
  if (*(undefined8 **)(param_1 + 0x10) == (undefined8 *)0x0) {
    puVar5 = (undefined8 *)0x0;
  }
  else {
    puVar5 = (undefined8 *)**(undefined8 **)(param_1 + 0x10);
  }
  puVar9 = (undefined8 *)0x0;
  local_68 = *puVar5;
  FUN_1400ec4f0(param_1 + 0x48,*(longlong *)(param_2 + 0x68) - *(longlong *)(param_2 + 0x60) >> 4,
                &local_68);
  *(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_2 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = *(undefined8 *)(param_2 + 0x80);
  *(undefined4 *)(param_1 + 0x88) = *(undefined4 *)(param_2 + 0x88);
  plVar1 = *(longlong **)(param_1 + 0x38);
  plVar7 = (longlong *)*plVar1;
  *plVar1 = (longlong)plVar1;
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  if (plVar7 != *(longlong **)(param_1 + 0x38)) {
    do {
      plVar1 = (longlong *)*plVar7;
      operator_delete(plVar7);
      plVar7 = plVar1;
    } while (plVar1 != (longlong *)*(longlong *)(param_1 + 0x38));
  }
  puVar5 = *(undefined8 **)(param_1 + 0x38);
  uVar2 = *(undefined8 *)(param_1 + 0x10);
  uStack_50 = *(undefined8 *)(param_2 + 0x38);
  local_58 = *(undefined8 *)(param_2 + 0x10);
  local_78 = (undefined4)*(undefined8 *)(param_2 + 0x10);
  uStack_74 = (undefined4)((ulonglong)*(undefined8 *)(param_2 + 0x10) >> 0x20);
  uStack_70 = (undefined4)**(undefined8 **)(param_2 + 0x38);
  uStack_6c = (undefined4)((ulonglong)**(undefined8 **)(param_2 + 0x38) >> 0x20);
  local_48 = local_78;
  uStack_44 = uStack_74;
  uStack_40 = uStack_70;
  uStack_3c = uStack_6c;
  local_68._0_4_ = (undefined4)uVar2;
  local_68._4_4_ = (undefined4)((ulonglong)uVar2 >> 0x20);
  uStack_60._0_4_ = SUB84(puVar5,0);
  uStack_60._4_4_ = (undefined4)((ulonglong)puVar5 >> 0x20);
  local_38 = (undefined4)local_68;
  uStack_34 = local_68._4_4_;
  uStack_30 = (undefined4)uStack_60;
  uStack_2c = uStack_60._4_4_;
  local_res10 = (undefined1)param_2;
  local_68 = uVar2;
  uStack_60 = puVar5;
  FUN_1400a5f80(param_1 + 0x10,&local_38,&local_48,&local_58,local_res10);
  *(undefined1 *)(param_1 + 8) = *(undefined1 *)(param_2 + 8);
  puVar11 = (undefined8 *)**(undefined8 **)(param_1 + 0x38);
  puVar5 = *(undefined8 **)(param_1 + 0x10);
  puVar10 = (undefined8 *)**(undefined8 **)(param_2 + 0x38);
  puVar3 = *(undefined8 **)(param_2 + 0x10);
  puVar8 = puVar9;
  if (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4 != 0) {
    do {
      if ((undefined8 *)(*(longlong *)(param_2 + 0x68) - *(longlong *)(param_2 + 0x60) >> 4) <=
          puVar8) {
        _invalid_parameter_noinfo();
      }
      if (*(undefined8 **)(*(longlong *)(param_2 + 0x60) + 8 + (longlong)puVar8 * 0x10) == puVar10)
      {
        puVar6 = puVar9;
        if (puVar5 != (undefined8 *)0x0) {
          puVar6 = (undefined8 *)*puVar5;
        }
        local_68 = *puVar6;
        uStack_60 = puVar11;
        if ((undefined8 *)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <=
            puVar8) {
          _invalid_parameter_noinfo();
        }
        lVar4 = *(longlong *)(param_1 + 0x60);
        *(undefined8 *)(lVar4 + (longlong)puVar8 * 0x10) = local_68;
        *(undefined8 **)(lVar4 + 8 + (longlong)puVar8 * 0x10) = uStack_60;
        puVar8 = (undefined8 *)((longlong)puVar8 + 1);
      }
      else {
        if (puVar5 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          puVar6 = puVar9;
        }
        else {
          puVar6 = (undefined8 *)*puVar5;
        }
        if (puVar11 == (undefined8 *)puVar6[5]) {
          _invalid_parameter_noinfo();
        }
        puVar11 = (undefined8 *)*puVar11;
        if (puVar3 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          puVar6 = puVar9;
        }
        else {
          puVar6 = (undefined8 *)*puVar3;
        }
        if (puVar10 == (undefined8 *)puVar6[5]) {
          _invalid_parameter_noinfo();
        }
        puVar10 = (undefined8 *)*puVar10;
      }
    } while (puVar8 < (undefined8 *)
                      (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4));
  }
  return;
}

// ==== CMapGroup::helper_1400f0260  @1400f0260  [medium:callgraph-r0]  (orig: FUN_1400f0260)
undefined8 * FUN_1400f0260(undefined8 *param_1,undefined8 *param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined1 local_res18;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  ulonglong uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  puVar6 = operator_new(8);
  if (puVar6 == (undefined8 *)0x0) {
    puVar7 = (undefined8 *)0x0;
  }
  else {
    *puVar6 = param_1;
    puVar7 = puVar6;
  }
  *param_1 = puVar7;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  uVar2 = param_1[6];
  if (uVar2 + param_1[7] < uVar2) {
    _invalid_parameter_noinfo();
  }
  uVar3 = *param_1;
  uVar1 = param_2[6] + param_2[7];
  if (uVar1 < (ulonglong)param_2[6]) {
    _invalid_parameter_noinfo();
  }
  uVar4 = *param_2;
  uVar5 = param_2[6];
  if (uVar5 + param_2[7] < uVar5) {
    _invalid_parameter_noinfo();
  }
  local_68 = (undefined4)*param_2;
  uStack_64 = (undefined4)((ulonglong)*param_2 >> 0x20);
  uStack_60 = (undefined4)uVar5;
  uStack_5c = (undefined4)(uVar5 >> 0x20);
  local_38 = local_68;
  uStack_34 = uStack_64;
  uStack_30 = uStack_60;
  uStack_2c = uStack_5c;
  local_58 = (undefined4)uVar3;
  uStack_54 = (undefined4)((ulonglong)uVar3 >> 0x20);
  uStack_50 = (undefined4)uVar2;
  uStack_4c = (undefined4)(uVar2 >> 0x20);
  local_28 = local_58;
  uStack_24 = uStack_54;
  uStack_20 = uStack_50;
  uStack_1c = uStack_4c;
  local_res18 = SUB81(puVar6,0);
  local_48 = uVar4;
  uStack_40 = uVar1;
  FUN_1400ec670(param_1,&local_28,&local_38,&local_48,local_res18);
  return param_1;
}

// ==== CMapGroup::helper_1400f03b0  @1400f03b0  [medium:callgraph-r0]  (orig: FUN_1400f03b0)
longlong FUN_1400f03b0(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  *(undefined1 *)(param_1 + 8) = *(undefined1 *)(param_2 + 8);
  puVar1 = (undefined8 *)(param_1 + 0x10);
  plVar2 = operator_new(8);
  plVar5 = (longlong *)0x0;
  plVar4 = plVar5;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)puVar1;
    plVar4 = plVar2;
  }
  *puVar1 = plVar4;
  uVar3 = FUN_14009a2a0(puVar1);
  *(undefined8 *)(param_1 + 0x38) = uVar3;
  *(undefined8 *)(param_1 + 0x40) = 0;
  plVar4 = operator_new(8);
  if (plVar4 != (longlong *)0x0) {
    *plVar4 = param_1 + 0x48;
    plVar5 = plVar4;
  }
  *(longlong **)(param_1 + 0x48) = plVar5;
  *(undefined8 *)(param_1 + 0x60) = 0;
  *(undefined8 *)(param_1 + 0x68) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  FUN_1400ef8d0(param_1,param_2,param_3,param_4,uVar6);
  return param_1;
}

// ==== CMapGroup::helper_1400f04c0  @1400f04c0  [medium:callgraph-r1]  (orig: FUN_1400f04c0)
longlong FUN_1400f04c0(longlong param_1,longlong param_2,longlong param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x30) {
    if (param_3 != 0) {
      FUN_1400eb3f0(param_3,param_1);
    }
    param_3 = param_3 + 0x30;
  }
  return param_3;
}

// ==== CMapGroup::helper_1400f06b0  @1400f06b0  [medium:callgraph-r0]  (orig: FUN_1400f06b0)
undefined8 * FUN_1400f06b0(undefined8 *param_1,longlong param_2)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  puVar2 = operator_new(8);
  if (puVar2 == (undefined8 *)0x0) {
    puVar3 = (void *)0x0;
  }
  else {
    *puVar2 = param_1;
    puVar3 = puVar2;
  }
  *param_1 = puVar3;
  lVar4 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18);
  lVar4 = lVar4 / 6 + (lVar4 >> 0x3f);
  uVar5 = (lVar4 >> 3) - (lVar4 >> 0x3f);
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar5 != 0) {
    if (0x555555555555555 < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_140057310();
    }
    lVar4 = FUN_140058db0(param_1 + 2,uVar5);
    param_1[3] = lVar4;
    param_1[4] = lVar4;
    param_1[5] = uVar5 * 0x30 + lVar4;
    uVar5 = *(ulonglong *)(param_2 + 0x20);
    if (uVar5 < *(ulonglong *)(param_2 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar1 = *(ulonglong *)(param_2 + 0x18);
    if (*(ulonglong *)(param_2 + 0x20) < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_res18 = SUB81(puVar2,0);
    uVar6 = FUN_1400f04c0(uVar1,uVar5,param_1[3],param_1 + 2,local_res18,0,uVar6);
    param_1[4] = uVar6;
  }
  return param_1;
}

// ==== CMapGroup::ctor_or_dtor  @1400f0820  [high:vtable-assign]  (orig: FUN_1400f0820)
undefined8 *
FUN_1400f0820(undefined8 *param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = CMapGroup::vftable;
  param_1[1] = CMapGroup::vftable;
  *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_2 + 0x10);
  FUN_1400f0260(param_1 + 3,param_2 + 0x18,param_3,param_4,0xfffffffffffffffe);
  param_1[0xb] = *(undefined8 *)(param_2 + 0x58);
  param_1[0xc] = *(undefined8 *)(param_2 + 0x60);
  *(undefined4 *)(param_1 + 0xd) = *(undefined4 *)(param_2 + 0x68);
  param_1[0xe] = *(undefined8 *)(param_2 + 0x70);
  param_1[0xf] = *(undefined8 *)(param_2 + 0x78);
  param_1[0x10] = *(undefined8 *)(param_2 + 0x80);
  param_1[0x11] = *(undefined8 *)(param_2 + 0x88);
  param_1[0x12] = *(undefined8 *)(param_2 + 0x90);
  param_1[0x13] = *(undefined8 *)(param_2 + 0x98);
  param_1[0x14] = *(undefined8 *)(param_2 + 0xa0);
  param_1[0x15] = *(undefined8 *)(param_2 + 0xa8);
  param_1[0x16] = *(undefined8 *)(param_2 + 0xb0);
  param_1[0x17] = *(undefined8 *)(param_2 + 0xb8);
  param_1[0x18] = *(undefined8 *)(param_2 + 0xc0);
  param_1[0x19] = *(undefined8 *)(param_2 + 200);
  param_1[0x1a] = *(undefined8 *)(param_2 + 0xd0);
  param_1[0x1b] = *(undefined8 *)(param_2 + 0xd8);
  param_1[0x1c] = *(undefined8 *)(param_2 + 0xe0);
  param_1[0x1d] = *(undefined8 *)(param_2 + 0xe8);
  param_1[0x1e] = *(undefined8 *)(param_2 + 0xf0);
  param_1[0x1f] = *(undefined8 *)(param_2 + 0xf8);
  param_1[0x20] = *(undefined8 *)(param_2 + 0x100);
  param_1[0x21] = *(undefined8 *)(param_2 + 0x108);
  param_1[0x22] = *(undefined8 *)(param_2 + 0x110);
  param_1[0x23] = *(undefined8 *)(param_2 + 0x118);
  param_1[0x24] = *(undefined8 *)(param_2 + 0x120);
  param_1[0x25] = *(undefined8 *)(param_2 + 0x128);
  param_1[0x26] = *(undefined8 *)(param_2 + 0x130);
  param_1[0x27] = *(undefined8 *)(param_2 + 0x138);
  param_1[0x28] = *(undefined8 *)(param_2 + 0x140);
  param_1[0x29] = *(undefined8 *)(param_2 + 0x148);
  param_1[0x2a] = *(undefined8 *)(param_2 + 0x150);
  param_1[0x2b] = *(undefined8 *)(param_2 + 0x158);
  param_1[0x2c] = *(undefined8 *)(param_2 + 0x160);
  param_1[0x2d] = *(undefined8 *)(param_2 + 0x168);
  param_1[0x2e] = *(undefined8 *)(param_2 + 0x170);
  param_1[0x2f] = *(undefined8 *)(param_2 + 0x178);
  param_1[0x30] = *(undefined8 *)(param_2 + 0x180);
  param_1[0x31] = *(undefined8 *)(param_2 + 0x188);
  param_1[0x32] = *(undefined8 *)(param_2 + 400);
  param_1[0x33] = *(undefined8 *)(param_2 + 0x198);
  param_1[0x34] = *(undefined8 *)(param_2 + 0x1a0);
  param_1[0x35] = *(undefined8 *)(param_2 + 0x1a8);
  param_1[0x36] = *(undefined8 *)(param_2 + 0x1b0);
  param_1[0x37] = *(undefined8 *)(param_2 + 0x1b8);
  param_1[0x38] = *(undefined8 *)(param_2 + 0x1c0);
  param_1[0x39] = *(undefined8 *)(param_2 + 0x1c8);
  param_1[0x3a] = *(undefined8 *)(param_2 + 0x1d0);
  param_1[0x3b] = *(undefined8 *)(param_2 + 0x1d8);
  param_1[0x3c] = *(undefined8 *)(param_2 + 0x1e0);
  param_1[0x3d] = *(undefined8 *)(param_2 + 0x1e8);
  param_1[0x3e] = *(undefined8 *)(param_2 + 0x1f0);
  param_1[0x3f] = *(undefined8 *)(param_2 + 0x1f8);
  param_1[0x40] = *(undefined8 *)(param_2 + 0x200);
  param_1[0x41] = *(undefined8 *)(param_2 + 0x208);
  param_1[0x42] = *(undefined8 *)(param_2 + 0x210);
  param_1[0x43] = *(undefined8 *)(param_2 + 0x218);
  param_1[0x44] = *(undefined8 *)(param_2 + 0x220);
  param_1[0x45] = *(undefined8 *)(param_2 + 0x228);
  param_1[0x46] = *(undefined8 *)(param_2 + 0x230);
  param_1[0x47] = *(undefined8 *)(param_2 + 0x238);
  param_1[0x48] = *(undefined8 *)(param_2 + 0x240);
  param_1[0x49] = *(undefined8 *)(param_2 + 0x248);
  param_1[0x4a] = *(undefined8 *)(param_2 + 0x250);
  param_1[0x4b] = *(undefined8 *)(param_2 + 600);
  param_1[0x4c] = *(undefined8 *)(param_2 + 0x260);
  FUN_1400f06b0(param_1 + 0x4d,param_2 + 0x268);
  *(undefined4 *)(param_1 + 0x53) = *(undefined4 *)(param_2 + 0x298);
  *(undefined4 *)((longlong)param_1 + 0x29c) = *(undefined4 *)(param_2 + 0x29c);
  *(undefined4 *)(param_1 + 0x54) = *(undefined4 *)(param_2 + 0x2a0);
  *(undefined4 *)((longlong)param_1 + 0x2a4) = *(undefined4 *)(param_2 + 0x2a4);
  *(undefined4 *)(param_1 + 0x55) = *(undefined4 *)(param_2 + 0x2a8);
  *(undefined4 *)((longlong)param_1 + 0x2ac) = *(undefined4 *)(param_2 + 0x2ac);
  *(undefined4 *)(param_1 + 0x56) = *(undefined4 *)(param_2 + 0x2b0);
  *(undefined4 *)((longlong)param_1 + 0x2b4) = *(undefined4 *)(param_2 + 0x2b4);
  *(undefined4 *)(param_1 + 0x57) = *(undefined4 *)(param_2 + 0x2b8);
  *(undefined4 *)((longlong)param_1 + 700) = *(undefined4 *)(param_2 + 700);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x2c0);
  *(undefined4 *)((longlong)param_1 + 0x2c4) = *(undefined4 *)(param_2 + 0x2c4);
  *(undefined4 *)(param_1 + 0x59) = *(undefined4 *)(param_2 + 0x2c8);
  *(undefined4 *)((longlong)param_1 + 0x2cc) = *(undefined4 *)(param_2 + 0x2cc);
  *(undefined1 *)(param_1 + 0x5a) = *(undefined1 *)(param_2 + 0x2d0);
  *(undefined4 *)((longlong)param_1 + 0x2d4) = *(undefined4 *)(param_2 + 0x2d4);
  *(undefined1 *)(param_1 + 0x5b) = *(undefined1 *)(param_2 + 0x2d8);
  *(undefined4 *)((longlong)param_1 + 0x2dc) = *(undefined4 *)(param_2 + 0x2dc);
  FUN_1400e9030(param_1 + 0x5c,param_2 + 0x2e0);
  *(undefined4 *)(param_1 + 0x62) = *(undefined4 *)(param_2 + 0x310);
  *(undefined4 *)((longlong)param_1 + 0x314) = *(undefined4 *)(param_2 + 0x314);
  *(undefined1 *)(param_1 + 99) = *(undefined1 *)(param_2 + 0x318);
  *(undefined4 *)((longlong)param_1 + 0x31c) = *(undefined4 *)(param_2 + 0x31c);
  *(undefined4 *)(param_1 + 100) = *(undefined4 *)(param_2 + 800);
  *(undefined1 *)((longlong)param_1 + 0x324) = *(undefined1 *)(param_2 + 0x324);
  *(undefined4 *)(param_1 + 0x65) = *(undefined4 *)(param_2 + 0x328);
  *(undefined4 *)((longlong)param_1 + 0x32c) = *(undefined4 *)(param_2 + 0x32c);
  *(undefined4 *)(param_1 + 0x66) = *(undefined4 *)(param_2 + 0x330);
  *(undefined4 *)((longlong)param_1 + 0x334) = *(undefined4 *)(param_2 + 0x334);
  *(undefined4 *)(param_1 + 0x67) = *(undefined4 *)(param_2 + 0x338);
  *(undefined1 *)((longlong)param_1 + 0x33c) = *(undefined1 *)(param_2 + 0x33c);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_2 + 0x340);
  *(undefined1 *)((longlong)param_1 + 0x344) = *(undefined1 *)(param_2 + 0x344);
  FUN_1400eaa80(param_1 + 0x69,param_2 + 0x348);
  FUN_1400e91a0(param_1 + 0x71,param_2 + 0x388);
  *(undefined4 *)(param_1 + 0x77) = *(undefined4 *)(param_2 + 0x3b8);
  *(undefined1 *)((longlong)param_1 + 0x3bc) = *(undefined1 *)(param_2 + 0x3bc);
  FUN_1400ea8d0(param_1 + 0x78,param_2 + 0x3c0);
  *(undefined1 *)(param_1 + 0x80) = *(undefined1 *)(param_2 + 0x400);
  *(undefined4 *)((longlong)param_1 + 0x404) = *(undefined4 *)(param_2 + 0x404);
  memcpy(param_1 + 0x81,(void *)(param_2 + 0x408),0x2c);
  FUN_1400eab10(param_1 + 0x87,param_2 + 0x438);
  FUN_1400eaba0(param_1 + 0x8f,param_2 + 0x478);
  FUN_1400f03b0(param_1 + 0x97,param_2 + 0x4b8);
  FUN_1400eaba0(param_1 + 0xa9,param_2 + 0x548);
  FUN_1400eaba0(param_1 + 0xb1,param_2 + 0x588);
  FUN_1400ea9f0(param_1 + 0xb9,param_2 + 0x5c8);
  FUN_1400eac30(param_1 + 0xc1,param_2 + 0x608);
  FUN_1400ea960(param_1 + 0xc9,param_2 + 0x648);
  *(undefined4 *)(param_1 + 0xd1) = *(undefined4 *)(param_2 + 0x688);
  *(undefined4 *)((longlong)param_1 + 0x68c) = *(undefined4 *)(param_2 + 0x68c);
  *(undefined4 *)(param_1 + 0xd2) = *(undefined4 *)(param_2 + 0x690);
  *(undefined4 *)((longlong)param_1 + 0x694) = *(undefined4 *)(param_2 + 0x694);
  *(undefined4 *)(param_1 + 0xd3) = *(undefined4 *)(param_2 + 0x698);
  *(undefined1 *)((longlong)param_1 + 0x69c) = *(undefined1 *)(param_2 + 0x69c);
  *(undefined1 *)((longlong)param_1 + 0x69d) = *(undefined1 *)(param_2 + 0x69d);
  *(undefined1 *)((longlong)param_1 + 0x69e) = *(undefined1 *)(param_2 + 0x69e);
  *(undefined1 *)((longlong)param_1 + 0x69f) = *(undefined1 *)(param_2 + 0x69f);
  *(undefined1 *)(param_1 + 0xd4) = *(undefined1 *)(param_2 + 0x6a0);
  *(undefined1 *)((longlong)param_1 + 0x6a1) = *(undefined1 *)(param_2 + 0x6a1);
  *(undefined1 *)((longlong)param_1 + 0x6a2) = *(undefined1 *)(param_2 + 0x6a2);
  *(undefined1 *)((longlong)param_1 + 0x6a3) = *(undefined1 *)(param_2 + 0x6a3);
  *(undefined4 *)((longlong)param_1 + 0x6a4) = *(undefined4 *)(param_2 + 0x6a4);
  *(undefined4 *)(param_1 + 0xd5) = *(undefined4 *)(param_2 + 0x6a8);
  *(undefined4 *)((longlong)param_1 + 0x6ac) = *(undefined4 *)(param_2 + 0x6ac);
  *(undefined4 *)(param_1 + 0xd6) = *(undefined4 *)(param_2 + 0x6b0);
  *(undefined4 *)((longlong)param_1 + 0x6b4) = *(undefined4 *)(param_2 + 0x6b4);
  *(undefined4 *)(param_1 + 0xd7) = *(undefined4 *)(param_2 + 0x6b8);
  *(undefined4 *)((longlong)param_1 + 0x6bc) = *(undefined4 *)(param_2 + 0x6bc);
  *(undefined4 *)(param_1 + 0xd8) = *(undefined4 *)(param_2 + 0x6c0);
  *(undefined4 *)((longlong)param_1 + 0x6c4) = *(undefined4 *)(param_2 + 0x6c4);
  *(undefined4 *)(param_1 + 0xd9) = *(undefined4 *)(param_2 + 0x6c8);
  *(undefined4 *)((longlong)param_1 + 0x6cc) = *(undefined4 *)(param_2 + 0x6cc);
  *(undefined4 *)(param_1 + 0xda) = *(undefined4 *)(param_2 + 0x6d0);
  *(undefined4 *)((longlong)param_1 + 0x6d4) = *(undefined4 *)(param_2 + 0x6d4);
  *(undefined4 *)(param_1 + 0xdb) = *(undefined4 *)(param_2 + 0x6d8);
  FUN_1400eacc0(param_1 + 0xdc,param_2 + 0x6e0);
  *(undefined4 *)(param_1 + 0xe4) = *(undefined4 *)(param_2 + 0x720);
  *(undefined8 *)((longlong)param_1 + 0x724) = *(undefined8 *)(param_2 + 0x724);
  *(undefined4 *)((longlong)param_1 + 0x72c) = *(undefined4 *)(param_2 + 0x72c);
  *(undefined1 *)(param_1 + 0xe6) = *(undefined1 *)(param_2 + 0x730);
  *(undefined1 *)((longlong)param_1 + 0x731) = *(undefined1 *)(param_2 + 0x731);
  FUN_1400ea840(param_1 + 0xe7,param_2 + 0x738);
  *(undefined4 *)(param_1 + 0xef) = *(undefined4 *)(param_2 + 0x778);
  *(undefined1 *)((longlong)param_1 + 0x77c) = *(undefined1 *)(param_2 + 0x77c);
  *(undefined4 *)(param_1 + 0xf0) = *(undefined4 *)(param_2 + 0x780);
  memcpy((void *)((longlong)param_1 + 0x784),(void *)(param_2 + 0x784),0x28);
  memcpy((void *)((longlong)param_1 + 0x7ac),(void *)(param_2 + 0x7ac),0x28);
  *(undefined4 *)((longlong)param_1 + 0x7d4) = *(undefined4 *)(param_2 + 0x7d4);
  *(undefined4 *)(param_1 + 0xfb) = *(undefined4 *)(param_2 + 0x7d8);
  *(undefined4 *)((longlong)param_1 + 0x7dc) = *(undefined4 *)(param_2 + 0x7dc);
  *(undefined4 *)(param_1 + 0xfc) = *(undefined4 *)(param_2 + 0x7e0);
  *(undefined4 *)((longlong)param_1 + 0x7e4) = *(undefined4 *)(param_2 + 0x7e4);
  *(undefined4 *)(param_1 + 0xfd) = *(undefined4 *)(param_2 + 0x7e8);
  *(undefined4 *)((longlong)param_1 + 0x7ec) = *(undefined4 *)(param_2 + 0x7ec);
  *(undefined4 *)(param_1 + 0xfe) = *(undefined4 *)(param_2 + 0x7f0);
  *(undefined4 *)((longlong)param_1 + 0x7f4) = *(undefined4 *)(param_2 + 0x7f4);
  *(undefined4 *)(param_1 + 0xff) = *(undefined4 *)(param_2 + 0x7f8);
  *(undefined4 *)((longlong)param_1 + 0x7fc) = *(undefined4 *)(param_2 + 0x7fc);
  FUN_1400ead50(param_1 + 0x100,param_2 + 0x800);
  *(undefined4 *)(param_1 + 0x108) = *(undefined4 *)(param_2 + 0x840);
  *(undefined4 *)((longlong)param_1 + 0x844) = *(undefined4 *)(param_2 + 0x844);
  *(undefined4 *)(param_1 + 0x109) = *(undefined4 *)(param_2 + 0x848);
  return param_1;
}

// ==== CMapGroup::helper_1401642f0  @1401642f0  [medium:callgraph-r0]  (orig: FUN_1401642f0)
void FUN_1401642f0(longlong param_1)

{
  *(undefined1 *)(param_1 + 0x955) = 1;
  return;
}

// ==== CMapGroup::helper_14020c700  @14020c700  [medium:callgraph-r0]  (orig: FUN_14020c700)
bool FUN_14020c700(undefined8 param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_1400fda10(param_2,1,1);
  return iVar1 == 0xaffbc;
}

// ==== CMapGroup::helper_1402beac0  @1402beac0  [medium:callgraph-r0]  (orig: FUN_1402beac0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8
FUN_1402beac0(longlong param_1,undefined4 param_2,int param_3,ulonglong param_4,undefined4 param_5,
             undefined4 param_6)

{
  int iVar1;
  undefined4 uVar2;
  ulonglong uVar3;
  longlong *plVar4;
  
  uVar2 = 0;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    iVar1 = 0;
  }
  else {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),1);
  }
  if (param_3 == iVar1) {
    if ((*(longlong *)(param_1 + 0x60) == 0) || (*(char *)(param_1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pData && IsDynaNpc()",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    }
    else {
      if (*(int *)(param_1 + 0x58) == 0x334) {
        uVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                          (*(longlong **)(param_1 + 0x60),0x12);
        tq::MyLogSave("gmlog/npc_820",&DAT_1407026f0,uVar3 & 0xffffffff,param_4 & 0xffffffff);
      }
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x12,param_4 & 0xffffffff);
    }
    if ((*(longlong *)(param_1 + 0x60) == 0) || (*(char *)(param_1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pData && IsDynaNpc()",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    }
    else {
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x13,param_5);
    }
    if ((*(longlong *)(param_1 + 0x60) == 0) || (*(char *)(param_1 + 0x68) == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pData && IsDynaNpc()",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    }
    else {
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x14,param_6);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x70))();
    }
    plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
    if (*(longlong *)(param_1 + 0x60) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    }
    else {
      uVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
    }
    (**(code **)(*plVar4 + 0x108))(plVar4,param_2,param_3,uVar2);
    return 1;
  }
  plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h");
    uVar2 = 0;
  }
  else {
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
  }
  (**(code **)(*plVar4 + 0x108))(plVar4,param_2,param_3,uVar2);
  return 0;
}

// ==== CMapGroup::helper_1403418e0  @1403418e0  [medium:callgraph-r0]  (orig: FUN_1403418e0)
undefined4 FUN_1403418e0(longlong *param_1,int param_2,char param_3)

{
  longlong lVar1;
  bool bVar2;
  char cVar3;
  undefined2 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  int local_res10 [2];
  undefined4 local_res18 [4];
  
  plVar9 = DAT_140975b60;
  local_res10[0] = param_2;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar9 = (longlong *)0x0;
  }
  lVar1 = *plVar9;
  uVar5 = FUN_140337820(param_1,param_2);
  plVar9 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar9,uVar5);
  if (param_3 == '\0') {
    iVar7 = 1;
    if ((plVar9 != (longlong *)0x0) && (cVar3 = FUN_140102870(plVar9), iVar7 = 1, cVar3 != '\0')) {
      uVar4 = FUN_1400fda10(plVar9,0x16,1);
      uVar5 = FUN_1400ffda0(plVar9);
      uVar6 = FUN_1400fda10(plVar9,1,1);
      iVar7 = FUN_140339ba0(param_1,uVar6,uVar5,uVar4);
      if (iVar7 < 1) goto LAB_140341a1e;
    }
    if (0x28 < (ulonglong)((param_1[0x185] - param_1[0x184] >> 2) + (longlong)iVar7)) {
      if (plVar9 != (longlong *)0x0) {
        FUN_1400fda10(plVar9,1,1);
      }
      log_InlineLogWARNING("CUser::UnEquipOnly. idItemtype: %u, Position: %d");
      return 0;
    }
  }
LAB_140341a1e:
  if (0x14 < param_2) {
    param_2 = param_2 % 10;
  }
  if (0x12 < param_2 - 1U) {
    return 0;
  }
  plVar10 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar10 = (longlong *)0x0;
  }
  lVar1 = *plVar10;
  uVar5 = FUN_14032b4b0(param_1,param_2);
  plVar10 = (longlong *)(**(code **)(lVar1 + 0x60))(plVar10,uVar5);
  if (param_2 == 4) {
    plVar11 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar11;
    uVar5 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar1 + 0x10))(plVar11,uVar5,0x17);
  }
  if (plVar9 != (longlong *)0x0) {
    bVar2 = false;
    iVar7 = FUN_1400ff9e0(plVar9);
    if ((iVar7 == 0x26c) &&
       (iVar7 = *(int *)((longlong)param_1 + 0xda4), iVar8 = (**(code **)(*plVar9 + 8))(plVar9),
       iVar7 == iVar8)) {
      bVar2 = true;
    }
    FUN_140104140(plVar9,7,0);
    cVar3 = FUN_140102870(plVar9);
    if (cVar3 == '\0') {
      local_res18[0] = (**(code **)(*plVar9 + 8))(plVar9);
      FUN_140037fe0(param_1 + 0x181,local_res18);
    }
    else {
      uVar5 = FUN_1400ffda0();
      uVar4 = FUN_1400fda10(plVar9,0x16,1);
      uVar6 = FUN_1400fda10(plVar9,1,1);
      FUN_14033f6b0(param_1,uVar6,uVar5,uVar4,1,0,0);
    }
    FUN_14019e880(param_1 + 0x19f,local_res10);
    if (plVar9 == plVar10) {
      *(undefined4 *)((longlong)param_1 + (longlong)param_2 * 4 + 0xd94) = 0;
    }
    if (((param_2 == 4) && (iVar7 = FUN_1400ff9e0(plVar9), iVar7 == 0x265)) &&
       (cVar3 = (**(code **)(param_1[2] + 0x2d8))(param_1 + 2,0x91), cVar3 != '\0')) {
      plVar10 = (longlong *)FUN_1401181a0();
      lVar1 = *plVar10;
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0x10))(plVar10,uVar5,0x91);
    }
    if (bVar2) {
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      uVar12 = FUN_140008520((int)param_1[0x246]);
      uVar12 = FUN_1400877e0(uVar12);
      FUN_1402f27e0(uVar12,uVar5,0);
    }
  }
  FUN_140171820(param_1,param_2);
  if (plVar9 != (longlong *)0x0) {
    uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
    return uVar5;
  }
  return 0;
}

// ==== CMapGroup::helper_140358970  @140358970  [medium:callgraph-r1]  (orig: FUN_140358970)
longlong * FUN_140358970(longlong param_1,longlong *param_2,uint *param_3,longlong *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  ldiv_t lVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  float fVar12;
  float fVar13;
  int local_res18;
  longlong *local_78;
  longlong *plStack_70;
  longlong *local_68;
  longlong *plStack_60;
  undefined1 local_58 [24];
  
  lVar4 = ldiv((*param_3 ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res18 = lVar4.quot;
  iVar3 = lVar4.rem * 0x41a7 + local_res18 * -0xb14;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x7fffffff;
  }
  uVar8 = (longlong)iVar3 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar8) {
    uVar8 = uVar8 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8 + 1)
  {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  plVar9 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar8 + 1) * 0x10);
  plStack_70 = plVar9;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar11 = uVar8 * 0x10;
  local_78 = plVar2;
  do {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + lVar11);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar6) goto LAB_140358b44;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)plVar9[1];
    lVar10 = 0;
    lVar5 = lVar10;
    if (plVar2 != (longlong *)0x0) {
      lVar5 = *plVar2;
    }
    plStack_70 = plVar9;
    if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = lVar10;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
      _invalid_parameter_noinfo();
    }
  } while (*param_3 < *(uint *)(plVar9 + 2));
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar10;
  }
  else {
    lVar5 = *plVar2;
  }
  if (plVar9 == *(longlong **)(lVar5 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*(uint *)(plVar9 + 2) < *param_3) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar10 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)*plVar9;
    plStack_70 = plVar9;
LAB_140358b44:
    lVar10 = *(longlong *)(param_1 + 0x38);
    if ((*param_4 == 0) || (*param_4 != *plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar10) {
      local_68 = local_78;
      plStack_60 = plStack_70;
      plVar6 = (longlong *)FUN_14000cae0(plVar1,local_58,&local_68,param_3);
      *param_4 = *plVar6;
      param_4[1] = plVar6[1];
    }
    else {
      local_68 = (longlong *)*param_4;
      plStack_60 = (longlong *)param_4[1];
      FUN_14000f1c0(plVar1,&local_78,plVar1,&local_68);
    }
    while( true ) {
      if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8)
      {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x60) + 8 + lVar11);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 != plVar6) break;
      local_78 = (longlong *)*param_4;
      plStack_70 = (longlong *)param_4[1];
      if (local_78 == (longlong *)0x0) {
        local_68 = (longlong *)0x0;
      }
      else {
        local_68 = (longlong *)*local_78;
      }
      local_68 = (longlong *)*local_68;
      plStack_60 = plStack_70;
      if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar8)
      {
        _invalid_parameter_noinfo();
      }
      lVar10 = *(longlong *)(param_1 + 0x60);
      *(longlong **)(lVar10 + lVar11) = local_68;
      *(longlong **)(lVar10 + 8 + lVar11) = plStack_60;
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      lVar11 = lVar11 + -0x10;
    }
    uVar8 = *(ulonglong *)(param_1 + 0x80);
    fVar12 = (float)*(longlong *)(param_1 + 0x40);
    if (*(longlong *)(param_1 + 0x40) < 0) {
      fVar12 = fVar12 + DAT_1406dc560;
    }
    fVar13 = (float)(longlong)uVar8;
    if ((longlong)uVar8 < 0) {
      fVar13 = fVar13 + DAT_1406dc560;
    }
    if (*(float *)(param_1 + 0x88) <= fVar12 / fVar13 &&
        fVar12 / fVar13 != *(float *)(param_1 + 0x88)) {
      iVar3 = 0;
      do {
        if (0x7fffffffffffffe < uVar8) break;
        iVar3 = iVar3 + 1;
        uVar8 = uVar8 * 2;
      } while (iVar3 < 3);
      plStack_60 = *(longlong **)(param_1 + 0x38);
      if ((undefined8 *)*plVar1 == (undefined8 *)0x0) {
        puVar7 = (undefined8 *)0x0;
      }
      else {
        puVar7 = *(undefined8 **)*plVar1;
      }
      local_68 = (longlong *)*puVar7;
      FUN_1401beb70(param_1 + 0x48,uVar8 + 1,&local_68);
      *(ulonglong *)(param_1 + 0x78) = uVar8 - 1;
      *(ulonglong *)(param_1 + 0x80) = uVar8;
      FUN_140358df0(param_1);
    }
    *param_2 = *param_4;
    plStack_70 = (longlong *)param_4[1];
    *(undefined1 *)(param_2 + 2) = 1;
  }
  else {
    lVar11 = *(longlong *)(param_1 + 0x38);
    if ((*param_4 == 0) || (*param_4 != *plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] != lVar11) {
      local_68 = (longlong *)*param_4;
      plStack_60 = (longlong *)param_4[1];
      FUN_14000cbd0(plVar1,local_58,&local_68);
    }
    *(undefined1 *)(param_2 + 2) = 0;
    *param_2 = (longlong)local_78;
  }
  param_2[1] = (longlong)plStack_70;
  return param_2;
}

// ==== CMapGroup::helper_140358df0  @140358df0  [medium:callgraph-r2]  (orig: FUN_140358df0)
void FUN_140358df0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [32];
  
  plVar1 = (longlong *)(param_1 + 0x10);
  while( true ) {
    plVar2 = (longlong *)*plVar1;
    lVar3 = **(longlong **)(param_1 + 0x38);
    if (*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 8);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar1)) {
      _invalid_parameter_noinfo();
    }
    if (lVar3 == lVar4) break;
    local_48 = SUB84(plVar2,0);
    uStack_44 = (undefined4)((ulonglong)plVar2 >> 0x20);
    uStack_40 = (undefined4)lVar3;
    uStack_3c = (undefined4)((ulonglong)lVar3 >> 0x20);
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = uStack_40;
    uStack_2c = uStack_3c;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (lVar3 == *(longlong *)(lVar4 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    FUN_140358970(param_1,local_28,lVar3 + 0x10,&local_38);
  }
  return;
}

// ==== CMapGroup::helper_140358f20  @140358f20  [medium:callgraph-r0]  (orig: FUN_140358f20)
longlong FUN_140358f20(longlong param_1,undefined4 *param_2)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined4 local_res8;
  undefined4 local_resc;
  longlong *local_58;
  longlong local_50;
  undefined8 local_48;
  undefined8 uStack_40;
  longlong *local_38;
  longlong local_30;
  
  FUN_140335320(param_1,&local_58,param_2);
  plVar3 = local_58;
  lVar1 = *(longlong *)(param_1 + 0x38);
  if ((local_58 == (longlong *)0x0) || (local_58 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar2 = 0;
  if (local_50 == lVar1) {
    local_res8 = *param_2;
    uStack_40 = *(undefined8 *)(param_1 + 0x38);
    local_48 = *(undefined8 *)(param_1 + 0x10);
    local_resc = 0;
    FUN_140358970(param_1,&local_38,&local_res8,&local_48);
    local_58 = local_38;
    local_50 = local_30;
    plVar3 = local_38;
  }
  lVar1 = local_50;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar2 = *plVar3;
  }
  if (lVar1 == *(longlong *)(lVar2 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  return lVar1 + 0x14;
}

// ==== CMapGroup::IsValidMapGroupProcessID  @140359330  [high:log-string]  (orig: FUN_140359330)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140359330(longlong *param_1)

{
  uint uVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined4 *puVar11;
  longlong *plVar12;
  longlong *plVar13;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong *plVar17;
  longlong lVar18;
  longlong lVar19;
  rsize_t _DstSize;
  longlong *plVar20;
  longlong *plVar21;
  undefined8 *puVar22;
  longlong *local_res18;
  longlong *local_res20;
  longlong *local_188 [3];
  longlong *local_170;
  longlong *local_168;
  undefined8 local_160;
  longlong *local_158 [3];
  longlong *local_140;
  longlong *local_138;
  undefined8 local_130;
  undefined8 local_128;
  int local_120;
  longlong *local_118 [3];
  undefined8 *local_100;
  undefined8 *local_f8;
  undefined8 local_f0;
  longlong *local_e8;
  longlong *plStack_e0;
  longlong *local_d8 [3];
  longlong *local_c0;
  longlong *local_b8;
  longlong local_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  longlong *local_98;
  longlong *plStack_90;
  undefined8 local_88;
  longlong *local_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined1 local_68 [16];
  undefined1 local_58 [32];
  
  local_88 = 0xfffffffffffffffe;
  local_res18 = operator_new(8);
  if (local_res18 == (longlong *)0x0) {
    local_118[0] = (longlong *)0x0;
  }
  else {
    *local_res18 = (longlong)local_118;
    local_118[0] = local_res18;
  }
  plVar21 = (longlong *)0x0;
  local_100 = (undefined8 *)0x0;
  local_f8 = (undefined8 *)0x0;
  local_f0 = 0;
  local_res20 = local_res18;
  lVar8 = FUN_140008520((int)param_1[0x246]);
  plVar12 = *(longlong **)(lVar8 + 0x170);
  if (*(longlong **)(lVar8 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDBDataPrepare",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(plVar12,local_118,uVar4,2);
  puVar22 = local_100;
  plVar12 = local_118[0];
  if (local_f8 < local_100) {
    _invalid_parameter_noinfo();
    plVar12 = local_118[0];
  }
  while( true ) {
    puVar2 = local_f8;
    if (local_f8 < local_100) {
      _invalid_parameter_noinfo();
    }
    if ((plVar12 == (longlong *)0x0) || (plVar12 != local_118[0])) {
      _invalid_parameter_noinfo();
    }
    if (puVar22 == puVar2) break;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((undefined8 *)plVar9[4] <= puVar22) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar22 + 0x20))((longlong *)*puVar22,"timeout")
    ;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar10 = plVar21;
    }
    else {
      plVar10 = (longlong *)*plVar12;
    }
    if ((undefined8 *)plVar10[4] <= puVar22) {
      _invalid_parameter_noinfo();
    }
    plVar10 = (longlong *)
              (**(code **)(*(longlong *)*puVar22 + 0x20))((longlong *)*puVar22,"Item_id");
    uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
    uVar5 = (**(code **)(*plVar10 + 0x40))(plVar10);
    local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar5);
    puVar11 = (undefined4 *)FUN_140358f20(param_1 + 0x1bd,&local_res18);
    *puVar11 = uVar4;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((undefined8 *)plVar9[4] <= puVar22) {
      _invalid_parameter_noinfo();
    }
    (*(code *)**(undefined8 **)*puVar22)((undefined8 *)*puVar22,1);
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((undefined8 *)plVar9[4] <= puVar22) {
      _invalid_parameter_noinfo();
    }
    puVar22 = puVar22 + 1;
  }
  if ((DAT_140975c58 & 1) == 0) {
    DAT_140975c58 = DAT_140975c58 | 1;
    plVar12 = (longlong *)CurrentInstanceGet();
    DAT_140975c50 = (longlong *)(**(code **)(*plVar12 + 0x20))(plVar12,0x16);
  }
  if (DAT_140975c50 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","pProvider",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar12 = DAT_140975c50;
  lVar8 = *DAT_140975c50;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  local_120 = (**(code **)(lVar8 + 0xb0))(plVar12,uVar4);
  plVar12 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  iVar6 = (**(code **)(*plVar12 + 0xd0))();
  local_res18 = (longlong *)CONCAT44(local_res18._4_4_,iVar6);
  local_res20 = operator_new(8);
  local_158[0] = plVar21;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_158;
    local_158[0] = local_res20;
  }
  local_140 = (longlong *)0x0;
  local_138 = (longlong *)0x0;
  local_130 = 0;
  local_128 = local_res20;
  local_res20 = operator_new(8);
  local_188[0] = plVar21;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_188;
    local_188[0] = local_res20;
  }
  local_170 = (longlong *)0x0;
  local_168 = (longlong *)0x0;
  local_160 = 0;
  local_128 = local_res20;
  lVar8 = FUN_140008520((int)param_1[0x246]);
  plVar12 = *(longlong **)(lVar8 + 0x170);
  if (*(longlong **)(lVar8 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDBDataPrepare",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(plVar12,local_158,uVar4,0);
  lVar8 = FUN_140008520((int)param_1[0x246]);
  plVar12 = *(longlong **)(lVar8 + 0x170);
  if (*(longlong **)(lVar8 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDBDataPrepare",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(plVar12,local_188,uVar4,1);
  lVar8 = FUN_140008520((int)param_1[0x246]);
  plVar12 = *(longlong **)(lVar8 + 0x170);
  if (*(longlong **)(lVar8 + 0x170) == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDBDataPrepare",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  FUN_140313fc0(plVar12,param_1 + 0x18d,uVar4,0x1c);
  plVar12 = local_140;
  if (local_138 < local_140) {
    _invalid_parameter_noinfo();
  }
  plVar10 = local_158[0];
  plVar9 = local_170;
  if (local_168 < local_170) {
    _invalid_parameter_noinfo();
  }
  plVar20 = local_140;
  plVar17 = local_188[0];
  if (iVar6 == 0) {
    while( true ) {
      plVar20 = local_138;
      if (local_138 < local_140) {
        _invalid_parameter_noinfo();
      }
      if ((plVar10 == (longlong *)0x0) || (plVar10 != local_158[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar12 == plVar20) break;
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar20 = plVar21;
      }
      else {
        plVar20 = (longlong *)*plVar10;
      }
      if ((longlong *)plVar20[4] <= plVar12) {
        _invalid_parameter_noinfo();
      }
      (*(code *)**(undefined8 **)*plVar12)((undefined8 *)*plVar12,1);
      if (plVar10 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar20 = plVar21;
      }
      else {
        plVar20 = (longlong *)*plVar10;
      }
      if ((longlong *)plVar20[4] <= plVar12) {
        _invalid_parameter_noinfo();
      }
      plVar12 = plVar12 + 1;
    }
    while( true ) {
      plVar12 = local_168;
      if (local_168 < local_170) {
        _invalid_parameter_noinfo();
      }
      if ((plVar17 == (longlong *)0x0) || (plVar17 != local_188[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == plVar12) break;
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar21;
      }
      else {
        plVar12 = (longlong *)*plVar17;
      }
      if ((longlong *)plVar12[4] <= plVar9) {
        _invalid_parameter_noinfo();
      }
      (*(code *)**(undefined8 **)*plVar9)((undefined8 *)*plVar9,1);
      if (plVar17 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar21;
      }
      else {
        plVar12 = (longlong *)*plVar17;
      }
      if ((longlong *)plVar12[4] <= plVar9) {
        _invalid_parameter_noinfo();
      }
      plVar9 = plVar9 + 1;
    }
    if (local_170 != (longlong *)0x0) {
      operator_delete(local_170);
    }
    local_170 = (longlong *)0x0;
    local_168 = (longlong *)0x0;
    local_160 = 0;
    operator_delete(local_188[0]);
    if (local_140 != (longlong *)0x0) {
      operator_delete(local_140);
    }
    local_140 = (longlong *)0x0;
    local_138 = (longlong *)0x0;
    local_130 = 0;
    operator_delete(local_158[0]);
    if (local_100 != (undefined8 *)0x0) {
      operator_delete(local_100);
    }
    local_100 = (undefined8 *)0x0;
    local_f8 = (undefined8 *)0x0;
    local_f0 = 0;
    operator_delete(local_118[0]);
    return 0;
  }
  plVar12 = local_158[0];
  if (local_138 < local_140) {
    _invalid_parameter_noinfo();
    plVar12 = local_158[0];
  }
  while( true ) {
    plVar9 = local_138;
    if (local_138 < local_140) {
      _invalid_parameter_noinfo();
    }
    if ((plVar12 == (longlong *)0x0) || (plVar12 != local_158[0])) {
      _invalid_parameter_noinfo();
    }
    plVar10 = local_170;
    if (plVar9 <= plVar20) break;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar9[4] <= plVar20) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,2);
    iVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
    if (iVar6 == (int)local_res18) {
LAB_14035a583:
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar21;
      }
      else {
        plVar9 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar9[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      if (*plVar20 != 0) {
        (*(code *)**(undefined8 **)*plVar20)((undefined8 *)*plVar20,1);
        *plVar20 = 0;
      }
    }
    else {
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar21;
      }
      else {
        plVar9 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar9[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,7);
      iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
      if (iVar6 == 0xcc) goto LAB_14035a583;
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar21;
      }
      else {
        plVar9 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar9[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,7);
      iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
      if (iVar6 == 0xca) goto LAB_14035a583;
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar21;
      }
      else {
        plVar9 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar9[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,0);
      (**(code **)(*plVar9 + 0x40))(plVar9);
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar21;
      }
      else {
        plVar9 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar9[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,1);
      (**(code **)(*plVar9 + 0x40))(plVar9);
      plVar9 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        plVar9 = plVar21;
      }
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar21;
      }
      else {
        plVar10 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar10[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,*plVar20,0);
      if (plVar9 == (longlong *)0x0) {
        uVar16 = (**(code **)(param_1[2] + 0x18))();
        log_InlineLogERROR(&DAT_140756048,uVar16);
        goto LAB_14035a5d2;
      }
      if (plVar12 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar21;
      }
      else {
        plVar10 = (longlong *)*plVar12;
      }
      if ((longlong *)plVar10[4] <= plVar20) {
        _invalid_parameter_noinfo();
      }
      plVar10 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,7);
      iVar6 = (**(code **)(*plVar10 + 0x48))(plVar10);
      if (iVar6 < 0xc9) {
LAB_140359c96:
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar21;
        }
        else {
          plVar10 = (longlong *)*plVar12;
        }
        if ((longlong *)plVar10[4] <= plVar20) {
          _invalid_parameter_noinfo();
        }
        plVar10 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,7);
        iVar6 = (**(code **)(*plVar10 + 0x48))(plVar10);
        if (iVar6 == 0xd0) goto LAB_140359cd3;
        uVar4 = FUN_1400fda10(plVar9,1,1);
        cVar3 = FUN_1400ff940(uVar4);
        if (cVar3 != '\0') {
          local_res20 = operator_new(8);
          plVar10 = local_170;
          local_d8[0] = plVar21;
          if (local_res20 != (longlong *)0x0) {
            *local_res20 = (longlong)local_d8;
            local_d8[0] = local_res20;
          }
          local_c0 = (longlong *)0x0;
          local_b8 = (longlong *)0x0;
          local_b0 = 0;
          local_80 = local_res20;
          if (local_168 < local_170) {
            _invalid_parameter_noinfo();
          }
          local_98 = local_188[0];
          plStack_90 = plVar10;
          plVar17 = local_188[0];
          while( true ) {
            plVar13 = local_168;
            if (local_168 < local_170) {
              _invalid_parameter_noinfo();
            }
            if ((plVar17 == (longlong *)0x0) || (plVar17 != local_188[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar10 == plVar13) break;
            if (plVar17 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar13 = plVar21;
            }
            else {
              plVar13 = (longlong *)*plVar17;
            }
            if ((longlong *)plVar13[4] <= plVar10) {
              _invalid_parameter_noinfo();
            }
            plVar13 = (longlong *)
                      (**(code **)(*(longlong *)*plVar10 + 0x10))((longlong *)*plVar10,1);
            iVar6 = (**(code **)(*plVar13 + 0x40))(plVar13);
            iVar7 = (**(code **)(*plVar9 + 8))(plVar9);
            if (iVar6 == iVar7) {
              if (plVar17 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar17 = plVar21;
              }
              else {
                plVar17 = (longlong *)*plVar17;
              }
              if ((longlong *)plVar17[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              plVar17 = local_b8;
              if ((local_c0 == (longlong *)0x0) ||
                 ((ulonglong)(local_b0 - (longlong)local_c0 >> 3) <=
                  (ulonglong)((longlong)local_b8 - (longlong)local_c0 >> 3))) {
                if (local_b8 < local_c0) {
                  _invalid_parameter_noinfo();
                }
                local_a8 = local_d8[0];
                plVar13 = local_a8;
                uStack_a0 = plVar17;
                local_a8._0_4_ = SUB84(local_d8[0],0);
                local_a8._4_4_ = (undefined4)((ulonglong)local_d8[0] >> 0x20);
                uStack_a0._0_4_ = SUB84(plVar17,0);
                uStack_a0._4_4_ = (undefined4)((ulonglong)plVar17 >> 0x20);
                local_78 = (undefined4)local_a8;
                uStack_74 = local_a8._4_4_;
                uStack_70 = (undefined4)uStack_a0;
                uStack_6c = uStack_a0._4_4_;
                local_a8 = plVar13;
                uStack_a0 = plVar17;
                FUN_1400189b0(local_d8,local_68,&local_78);
              }
              else {
                *local_b8 = *plVar10;
                local_b8 = local_b8 + 1;
              }
              lVar8 = (longlong)local_168 - (longlong)(plVar10 + 1) >> 3;
              if (0 < lVar8) {
                _DstSize = lVar8 << 3;
                memmove_s(plVar10,_DstSize,plVar10 + 1,_DstSize);
              }
              local_168 = local_168 + -1;
              if ((plVar10 < local_170) || (local_168 < plVar10)) {
                _invalid_parameter_noinfo();
              }
              local_e8 = local_188[0];
              plVar17 = local_188[0];
              plStack_e0 = plVar10;
            }
            else {
              if (plVar17 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar13 = plVar21;
              }
              else {
                plVar13 = (longlong *)*plVar17;
              }
              if ((longlong *)plVar13[4] <= plVar10) {
                _invalid_parameter_noinfo();
              }
              plVar10 = plVar10 + 1;
            }
          }
          FUN_140108580(plVar9,local_d8,1);
          if (local_c0 != (longlong *)0x0) {
            operator_delete(local_c0);
          }
          local_c0 = (longlong *)0x0;
          local_b8 = (longlong *)0x0;
          local_b0 = 0;
          operator_delete(local_d8[0]);
        }
        plVar10 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          plVar10 = plVar21;
        }
        lVar8 = *plVar10;
        uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
        iVar6 = (**(code **)(lVar8 + 0x150))(plVar10,uVar4);
        if (iVar6 == 3) {
          iVar6 = FUN_1400fda10(plVar9,0x17,1);
          if (iVar6 != 0) {
            plVar10 = (longlong *)FUN_140087f50();
            lVar8 = *plVar10;
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            uVar5 = (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(lVar8 + 0x48))(plVar10,uVar5,uVar4);
          }
          plVar10 = (longlong *)FUN_140087d40();
          (**(code **)(*plVar10 + 0x130))(plVar10,param_1,plVar9);
          FUN_1400fe700(plVar9,param_1,0);
          plVar10 = (longlong *)FUN_140087d40();
          lVar8 = *plVar10;
          uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
          (**(code **)(lVar8 + 0x30))(plVar10,uVar4);
        }
        else {
          iVar6 = FUN_1400fda10(plVar9,0x17,1);
          if ((iVar6 != 0) && (iVar6 = FUN_1400fda10(plVar9,0x17,1), iVar6 != local_120)) {
            plVar10 = (longlong *)FUN_140087f50();
            lVar8 = *plVar10;
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            uVar5 = (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(lVar8 + 0x48))(plVar10,uVar5,uVar4);
            FUN_140104140(plVar9,0x17,0);
          }
          iVar6 = FUN_1400ffda0(plVar9);
          if (iVar6 < 1) {
            FUN_1400ffda0(plVar9);
            uVar14 = FUN_1400fda10(plVar9,1,1);
            uVar15 = (**(code **)(*plVar9 + 8))(plVar9);
            log_InlineLogERROR("CUser::CreateAllItem. Item[%u] Type[%d] AccumulateNum[%d] at %s, %d"
                               ,uVar15 & 0xffffffff,uVar14 & 0xffffffff);
          }
          cVar3 = FUN_1400ffcb0(plVar9);
          if (cVar3 == '\0') {
            (**(code **)(*param_1 + 8))(param_1);
            (**(code **)(param_1[2] + 0x18))(param_1 + 2);
            (**(code **)(*plVar9 + 8))(plVar9);
            tq::MyLogSave("gmlog/invalid_item","invalid item:[%u] found in user:[%s][%u]");
            plVar10 = (longlong *)FUN_140087d40();
            lVar8 = *plVar10;
            uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
            (**(code **)(lVar8 + 0x58))(plVar10,uVar4);
          }
          else {
            iVar6 = FUN_1400fda10(plVar9,7,1);
            if (((0 < iVar6) && (iVar6 < 0x14)) || (iVar6 - 0x15U < 8 || iVar6 == 0x1d)) {
              plVar10 = (longlong *)FUN_140087d40();
              lVar8 = *plVar10;
              uVar4 = FUN_140337820(param_1,iVar6);
              lVar8 = (**(code **)(lVar8 + 0x60))(plVar10,uVar4);
              if (lVar8 == 0) {
                local_128 = (longlong *)CONCAT44(local_128._4_4_,iVar6);
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                local_128 = (longlong *)CONCAT44(uVar4,(undefined4)local_128);
                FUN_1400173d0(param_1 + 0x19f,local_58);
                if (iVar6 < 0x14) {
                  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                  *(undefined4 *)((longlong)param_1 + (longlong)iVar6 * 4 + 0xd94) = uVar4;
                  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                  FUN_140171670(param_1,uVar4);
                }
                goto LAB_14035a5d2;
              }
              log_InlineLogWARNING("Found same position of user equip.");
            }
            if (((ulonglong)(param_1[0x185] - param_1[0x184] >> 2) < 0x28) &&
               (iVar6 = FUN_1400fda10(plVar9,7,1), iVar6 < 200)) {
              iVar6 = FUN_1400fda10(plVar9,7);
              if (iVar6 != 0) {
                FUN_140104140(plVar9,7);
              }
              uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
              local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar4);
              FUN_140037fe0(param_1 + 0x181,&local_res20);
              uVar16 = FUN_140008520((int)param_1[0x246]);
              uVar16 = FUN_140117f70(uVar16);
              cVar3 = FUN_14020c700(uVar16,plVar9);
              if (cVar3 != '\0') {
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                uVar16 = FUN_140008520((int)param_1[0x246]);
                uVar16 = FUN_140117f70(uVar16);
                FUN_14020f360(uVar16,uVar4);
              }
            }
            else {
              iVar6 = FUN_1400fda10(plVar9,7);
              if (iVar6 == 0xcd) {
                plVar10 = (longlong *)FUN_140087d40();
                lVar8 = *plVar10;
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                (**(code **)(lVar8 + 0x180))(plVar10,uVar4);
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar4);
                FUN_140037fe0(param_1 + 0x193,&local_res20);
              }
              else {
                iVar6 = FUN_1400fda10(plVar9,7);
                if (iVar6 == 0xce) {
                  plVar10 = (longlong *)FUN_140087d40();
                  lVar8 = *plVar10;
                  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                  (**(code **)(lVar8 + 0x180))(plVar10,uVar4);
                  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                  local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar4);
                  FUN_140037fe0(param_1 + 0x1a7,&local_res20);
                }
                else {
                  cVar3 = FUN_1400ff650(plVar9,2);
                  if ((cVar3 == '\0') || (iVar6 = FUN_1400fda10(plVar9,7), iVar6 == 0xcc)) {
                    plVar10 = (longlong *)FUN_140087d40();
                    lVar8 = *plVar10;
                    uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                    (**(code **)(lVar8 + 0x58))(plVar10,uVar4);
                  }
                  else {
                    plVar10 = (longlong *)FUN_140087d40();
                    lVar8 = *plVar10;
                    uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                    (**(code **)(lVar8 + 0x180))(plVar10,uVar4);
                    uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                    local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar4);
                    FUN_140037fe0(param_1 + 0x199,&local_res20);
                  }
                }
              }
            }
          }
        }
      }
      else {
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar10 = plVar21;
        }
        else {
          plVar10 = (longlong *)*plVar12;
        }
        if ((longlong *)plVar10[4] <= plVar20) {
          _invalid_parameter_noinfo();
        }
        plVar10 = (longlong *)(**(code **)(*(longlong *)*plVar20 + 0x10))((longlong *)*plVar20,7);
        iVar6 = (**(code **)(*plVar10 + 0x48))(plVar10);
        if (0xcb < iVar6) goto LAB_140359c96;
LAB_140359cd3:
        uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
        local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar4);
        FUN_140037fe0(param_1 + 0x187,&local_res20);
      }
    }
LAB_14035a5d2:
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar9[4] <= plVar20) {
      _invalid_parameter_noinfo();
    }
    plVar20 = plVar20 + 1;
  }
  if (local_168 < local_170) {
    _invalid_parameter_noinfo();
  }
  plVar12 = local_188[0];
  local_e8 = local_188[0];
  plStack_e0 = plVar10;
  while( true ) {
    plVar9 = local_168;
    if (local_168 < local_170) {
      _invalid_parameter_noinfo();
    }
    if ((plVar12 == (longlong *)0x0) || (plVar12 != local_188[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar9) break;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar9[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)(**(code **)(*(longlong *)*plVar10 + 0x10))((longlong *)*plVar10,2);
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar17 = plVar21;
    }
    else {
      plVar17 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar17[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    plVar17 = (longlong *)(**(code **)(*(longlong *)*plVar10 + 0x10))((longlong *)*plVar10,1);
    uVar14 = (**(code **)(*plVar9 + 0x40))(plVar9);
    uVar15 = (**(code **)(*plVar17 + 0x40))(plVar17);
    log_InlineLogWARNING
              ("Item[%u] userid[%u] ItemStatus is not Load",uVar15 & 0xffffffff,uVar14 & 0xffffffff)
    ;
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar9[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    if (*plVar10 != 0) {
      (*(code *)**(undefined8 **)*plVar10)((undefined8 *)*plVar10,1);
      *plVar10 = 0;
    }
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar9 = plVar21;
    }
    else {
      plVar9 = (longlong *)*plVar12;
    }
    if ((longlong *)plVar9[4] <= plVar10) {
      _invalid_parameter_noinfo();
    }
    plVar10 = plVar10 + 1;
  }
  uVar1 = *(uint *)(param_1 + 0x246);
  if ((uVar1 < 0xe) || ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= (ulonglong)uVar1)) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","CMapGroup::IsValidMapGroupProcessID(idProcess)",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  else {
    plVar12 = (longlong *)((ulonglong)uVar1 * 0x850 + DAT_140975c20);
  }
  plVar9 = (longlong *)plVar12[0x20];
  if ((longlong *)plVar12[0x20] == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMagicManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar9 = plVar21;
  }
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  lVar8 = FUN_1402f2760(plVar9,uVar4,0x2847);
  plVar12 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  lVar18 = (**(code **)(*plVar12 + 0x60))(plVar12,(int)param_1[0x1b5]);
  if (lVar18 != 0) {
    uVar4 = FUN_1400fda10(lVar18,1,1);
    iVar6 = FUN_1400ff680(uVar4);
    if (iVar6 == 5) {
      uVar4 = FUN_1400fda10(lVar18,7,1);
      FUN_1403418e0(param_1,uVar4,0);
    }
  }
  plVar12 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  lVar18 = (**(code **)(*plVar12 + 0x60))(plVar12,*(undefined4 *)((longlong)param_1 + 0xda4));
  plVar12 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar12 = plVar21;
  }
  lVar19 = (**(code **)(*plVar12 + 0x60))(plVar12,(int)param_1[0x1b5]);
  if (lVar18 != 0) {
    uVar4 = FUN_1400fda10(lVar18,1,1);
    iVar6 = FUN_1400ff680(uVar4);
    if ((iVar6 == 5) && (lVar19 != 0)) {
      iVar6 = FUN_1400fda10(lVar18,1,1);
      if (((iVar6 % 10000000) / 100000 == 5) && (((iVar6 % 100000) / 1000) * 1000 == 0)) {
        uVar4 = FUN_1400fda10(lVar19,1,1);
        iVar6 = FUN_1400ff680(uVar4);
        if (iVar6 == 0) {
          uVar4 = FUN_1400fda10(lVar19,1,1);
          iVar6 = FUN_1400fecd0(uVar4);
          if (iVar6 == 50000) goto LAB_14035aa68;
        }
      }
      if (lVar8 == 0) {
        uVar4 = FUN_1400fda10(lVar19,7,1);
        FUN_1403418e0(param_1,uVar4,0);
      }
    }
  }
LAB_14035aa68:
  FUN_1401642f0(param_1);
  if (local_170 != (longlong *)0x0) {
    operator_delete(local_170);
  }
  local_170 = (longlong *)0x0;
  local_168 = (longlong *)0x0;
  local_160 = 0;
  operator_delete(local_188[0]);
  if (local_140 != (longlong *)0x0) {
    operator_delete(local_140);
  }
  local_140 = (longlong *)0x0;
  local_138 = (longlong *)0x0;
  local_130 = 0;
  operator_delete(local_158[0]);
  if (local_100 != (undefined8 *)0x0) {
    operator_delete(local_100);
  }
  local_100 = (undefined8 *)0x0;
  local_f8 = (undefined8 *)0x0;
  local_f0 = 0;
  operator_delete(local_118[0]);
  return 1;
}

