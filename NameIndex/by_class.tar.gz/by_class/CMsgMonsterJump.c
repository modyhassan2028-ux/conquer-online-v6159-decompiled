// ==== CMsgMonsterJump::ctor_or_dtor  @14044f5d0  [high:vtable-assign]  (orig: FUN_14044f5d0)
undefined8 * FUN_14044f5d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMonsterJump::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMonsterJump::ctor_or_dtor  @14044f620  [high:vtable-assign]  (orig: FUN_14044f620)
void FUN_14044f620(undefined8 *param_1)

{
  *param_1 = CMsgMonsterJump::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMonsterJump::vfunc_1  @14044f650  [high:rtti-vtable]  (orig: FUN_14044f650)
ulonglong FUN_14044f650(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x4e22);
}

// ==== CMsgMonsterJump::ctor_or_dtor  @14044f700  [high:vtable-assign]  (orig: FUN_14044f700)
undefined8 * FUN_14044f700(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMonsterJump::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMonsterJump::vfunc_3  @14044f750  [high:rtti-vtable]  (orig: FUN_14044f750)
void FUN_14044f750(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  longlong local_res8;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    local_res8 = 0;
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar1 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar2 = (longlong *)
             (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x18))
                       (*(longlong **)(lVar1 + 0x88),param_1,**(undefined4 **)(param_1 + 0x428));
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x298))(plVar2,0x1002,&local_res8);
      if (local_res8 != 0) {
        (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x378))
                  (local_res8 + 0x10,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4),
                   *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6));
      }
    }
  }
  return;
}

