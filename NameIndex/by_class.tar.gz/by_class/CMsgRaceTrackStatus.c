// ==== CMsgRaceTrackStatus::ctor_or_dtor  @1403b5d30  [high:vtable-assign]  (orig: FUN_1403b5d30)
undefined8 * FUN_1403b5d30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgRaceTrackStatus::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgRaceTrackStatus::ctor_or_dtor  @1403b5d80  [high:vtable-assign]  (orig: FUN_1403b5d80)
void FUN_1403b5d80(undefined8 *param_1)

{
  *param_1 = CMsgRaceTrackStatus::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgRaceTrackStatus::vfunc_1  @1403b5db0  [high:rtti-vtable]  (orig: FUN_1403b5db0)
undefined8 FUN_1403b5db0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgRaceTrackStatus::vfunc_3  @1403b5fa0  [high:rtti-vtable]  (orig: FUN_1403b5fa0)
void FUN_1403b5fa0(void)

{
  return;
}

// ==== CMsgRaceTrackStatus::ctor_or_dtor  @1403b5fb0  [high:vtable-assign]  (orig: FUN_1403b5fb0)
undefined8 * FUN_1403b5fb0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgRaceTrackStatus::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

