// ==== CopyingInputStreamAdaptor@io@protobuf@google::helper_14055c630  @14055c630  [medium:callgraph-r0]  (orig: FUN_14055c630)
void FUN_14055c630(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = google::protobuf::io::CopyingInputStreamAdaptor::vftable;
  if ((*(char *)(param_1 + 2) != '\0') &&
     (puVar1 = (undefined8 *)param_1[1], puVar1 != (undefined8 *)0x0)) {
    (**(code **)*puVar1)(puVar1,1);
  }
  FUN_14055d6d0(param_1 + 4);
  FUN_14055d8b0(param_1);
  return;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::vfunc_1  @14055c6d0  [high:rtti-vtable]  (orig: FUN_14055c6d0)
undefined8 FUN_14055c6d0(longlong param_1,longlong *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (*(char *)(param_1 + 0x11) == '\0') {
    FUN_14055cca0(param_1);
    if (*(int *)(param_1 + 0x30) < 1) {
      uVar3 = FUN_14055d750(param_1 + 0x20);
      uVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 8))
                        (*(undefined8 *)(param_1 + 8),uVar3,*(undefined4 *)(param_1 + 0x28));
      *(undefined4 *)(param_1 + 0x2c) = uVar1;
      if (*(int *)(param_1 + 0x2c) < 1) {
        if (*(int *)(param_1 + 0x2c) < 0) {
          *(undefined1 *)(param_1 + 0x11) = 1;
        }
        FUN_14055ccf0(param_1);
        uVar3 = 0;
      }
      else {
        *(longlong *)(param_1 + 0x18) =
             (longlong)*(int *)(param_1 + 0x2c) + *(longlong *)(param_1 + 0x18);
        *param_3 = *(undefined4 *)(param_1 + 0x2c);
        lVar2 = FUN_14055d750(param_1 + 0x20);
        *param_2 = lVar2;
        uVar3 = 1;
      }
    }
    else {
      lVar2 = FUN_14055d750(param_1 + 0x20);
      *param_2 = (lVar2 + *(int *)(param_1 + 0x2c)) - (longlong)*(int *)(param_1 + 0x30);
      *param_3 = *(undefined4 *)(param_1 + 0x30);
      *(undefined4 *)(param_1 + 0x30) = 0;
      uVar3 = 1;
    }
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::vfunc_2  @14055c820  [high:rtti-vtable]  (orig: FUN_14055c820)
void FUN_14055c820(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined1 *puVar3;
  undefined1 local_128 [8];
  undefined1 local_120 [64];
  undefined1 local_e0 [8];
  undefined1 local_d8 [64];
  undefined1 local_98 [8];
  undefined1 local_90 [64];
  uint local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_48 = 0xfffffffffffffffe;
  local_50 = 0;
  if ((*(int *)(param_1 + 0x30) != 0) || (lVar1 = FUN_14055d750(param_1 + 0x20), lVar1 == 0)) {
    puVar3 = local_128;
    for (lVar1 = 1; lVar1 != 0; lVar1 = lVar1 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_40 = FUN_140556890(local_120,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x10c);
    local_50 = local_50 | 1;
    local_38 = local_40;
    uVar2 = FUN_1405564f0(local_40,"CHECK failed: backup_bytes_ == 0 && buffer_.get() != NULL: ");
    uVar2 = FUN_1405564f0(uVar2," BackUp() can only be called after Next().");
    FUN_140556a40(local_128,uVar2);
  }
  if ((local_50 & 1) != 0) {
    local_50 = local_50 & 0xfffffffe;
    FUN_140556900(local_120);
  }
  if (*(int *)(param_1 + 0x2c) < param_2) {
    puVar3 = local_e0;
    for (lVar1 = 1; lVar1 != 0; lVar1 = lVar1 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_30 = FUN_140556890(local_d8,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x10e);
    local_50 = local_50 | 2;
    local_28 = local_30;
    uVar2 = FUN_1405564f0(local_30,"CHECK failed: (count) <= (buffer_used_): ");
    uVar2 = FUN_1405564f0(uVar2,
                          " Can\'t back up over more bytes than were returned by the last call to Next()."
                         );
    FUN_140556a40(local_e0,uVar2);
  }
  if ((local_50 & 2) != 0) {
    local_50 = local_50 & 0xfffffffd;
    FUN_140556900(local_d8);
  }
  if (param_2 < 0) {
    puVar3 = local_98;
    for (lVar1 = 1; lVar1 != 0; lVar1 = lVar1 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_20 = FUN_140556890(local_90,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x111);
    local_50 = local_50 | 4;
    local_18 = local_20;
    uVar2 = FUN_1405564f0(local_20,"CHECK failed: (count) >= (0): ");
    uVar2 = FUN_1405564f0(uVar2," Parameter to BackUp() can\'t be negative.");
    FUN_140556a40(local_98,uVar2);
  }
  if ((local_50 & 4) != 0) {
    local_50 = local_50 & 0xfffffffb;
    FUN_140556900(local_90);
  }
  *(int *)(param_1 + 0x30) = param_2;
  return;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::vfunc_3  @14055cac0  [high:rtti-vtable]  (orig: FUN_14055cac0)
bool FUN_14055cac0(longlong param_1,int param_2)

{
  int iVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 *puVar4;
  bool bVar5;
  undefined1 local_74 [4];
  undefined1 local_70 [64];
  uint local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_28 = 0xfffffffffffffffe;
  local_30 = 0;
  if (param_2 < 0) {
    puVar4 = local_74;
    for (lVar3 = 1; lVar3 != 0; lVar3 = lVar3 + -1) {
      *puVar4 = 0;
      puVar4 = puVar4 + 1;
    }
    local_20 = FUN_140556890(local_70,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x118);
    local_30 = local_30 | 1;
    local_18 = local_20;
    uVar2 = FUN_1405564f0(local_20,"CHECK failed: (count) >= (0): ");
    FUN_140556a40(local_74,uVar2);
  }
  if ((local_30 & 1) != 0) {
    local_30 = local_30 & 0xfffffffe;
    FUN_140556900(local_70);
  }
  if (*(char *)(param_1 + 0x11) == '\0') {
    if (*(int *)(param_1 + 0x30) < param_2) {
      param_2 = param_2 - *(int *)(param_1 + 0x30);
      *(undefined4 *)(param_1 + 0x30) = 0;
      iVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 0x10))
                        (*(undefined8 *)(param_1 + 8),param_2);
      *(longlong *)(param_1 + 0x18) = (longlong)iVar1 + *(longlong *)(param_1 + 0x18);
      bVar5 = iVar1 == param_2;
    }
    else {
      *(int *)(param_1 + 0x30) = *(int *)(param_1 + 0x30) - param_2;
      bVar5 = true;
    }
  }
  else {
    bVar5 = false;
  }
  return bVar5;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::vfunc_4  @14055cc70  [high:rtti-vtable]  (orig: FUN_14055cc70)
longlong FUN_14055cc70(longlong param_1)

{
  return *(longlong *)(param_1 + 0x18) - (longlong)*(int *)(param_1 + 0x30);
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::helper_14055cca0  @14055cca0  [medium:callgraph-r0]  (orig: FUN_14055cca0)
void FUN_14055cca0(longlong param_1)

{
  longlong lVar1;
  void *pvVar2;
  
  lVar1 = FUN_14055d750(param_1 + 0x20);
  if (lVar1 == 0) {
    pvVar2 = operator_new__((longlong)*(int *)(param_1 + 0x28));
    FUN_14055d700(param_1 + 0x20,pvVar2);
  }
  return;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::helper_14055ccf0  @14055ccf0  [medium:callgraph-r0]  (orig: FUN_14055ccf0)
void FUN_14055ccf0(longlong param_1)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined1 *puVar3;
  undefined1 local_78 [8];
  undefined1 local_70 [64];
  uint local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_28 = 0xfffffffffffffffe;
  local_30 = 0;
  if (*(int *)(param_1 + 0x30) != 0) {
    puVar3 = local_78;
    for (lVar2 = 1; lVar2 != 0; lVar2 = lVar2 + -1) {
      *puVar3 = 0;
      puVar3 = puVar3 + 1;
    }
    local_20 = FUN_140556890(local_70,3,
                             "F:\\cq\\64\\develop\\protobuf\\src\\google\\protobuf\\io\\zero_copy_stream_impl_lite.cc"
                             ,0x139);
    local_30 = local_30 | 1;
    local_18 = local_20;
    uVar1 = FUN_1405564f0(local_20,"CHECK failed: (backup_bytes_) == (0): ");
    FUN_140556a40(local_78,uVar1);
  }
  if ((local_30 & 1) != 0) {
    local_30 = local_30 & 0xfffffffe;
    FUN_140556900(local_70);
  }
  *(undefined4 *)(param_1 + 0x2c) = 0;
  FUN_14055d700(param_1 + 0x20,0);
  return;
}

// ==== CopyingInputStreamAdaptor@io@protobuf@google::vfunc_0  @14055d5f0  [high:rtti-vtable]  (orig: FUN_14055d5f0)
void * FUN_14055d5f0(void *param_1,uint param_2)

{
  FUN_14055c630(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

