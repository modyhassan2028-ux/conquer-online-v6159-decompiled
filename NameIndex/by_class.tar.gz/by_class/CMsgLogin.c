// ==== CMsgLogin::ctor_or_dtor  @140083d70  [high:vtable-assign]  (orig: FUN_140083d70)
undefined8 * FUN_140083d70(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgLogin::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgLogin::ctor_or_dtor  @140083dc0  [high:vtable-assign]  (orig: FUN_140083dc0)
void FUN_140083dc0(undefined8 *param_1)

{
  *param_1 = CMsgLogin::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgLogin::vfunc_1  @140083ef0  [high:rtti-vtable]  (orig: FUN_140083ef0)
ulonglong FUN_140083ef0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3ea);
}

// ==== CMsgLogin::vfunc_3  @140083f20  [high:rtti-vtable]  (orig: FUN_140083f20)
void FUN_140083f20(void)

{
  return;
}

// ==== CMsgLogin::ctor_or_dtor  @1400842d0  [high:vtable-assign]  (orig: FUN_1400842d0)
undefined8 * FUN_1400842d0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgLogin::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

