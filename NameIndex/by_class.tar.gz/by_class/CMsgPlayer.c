// ==== CMsgPlayer::ctor_or_dtor  @14039ed70  [high:vtable-assign]  (orig: FUN_14039ed70)
undefined8 * FUN_14039ed70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgPlayer::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf((CStringPacker *)(param_1 + 0x86),(char *)(param_1 + 0x25),0x2e8,true);
  return param_1;
}

// ==== CMsgPlayer::ctor_or_dtor  @14039edf0  [high:vtable-assign]  (orig: FUN_14039edf0)
void FUN_14039edf0(undefined8 *param_1)

{
  *param_1 = CMsgPlayer::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgPlayer::vfunc_1  @14039ee30  [high:rtti-vtable]  (orig: FUN_14039ee30)
ulonglong FUN_14039ee30(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x271e);
}

// ==== CMsgPlayer::vfunc_3  @14039ee80  [high:rtti-vtable]  (orig: FUN_14039ee80)
void FUN_14039ee80(void)

{
  return;
}

// ==== CMsgPlayer::ctor_or_dtor  @14039ee90  [high:vtable-assign]  (orig: FUN_14039ee90)
undefined8 * FUN_14039ee90(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgPlayer::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

