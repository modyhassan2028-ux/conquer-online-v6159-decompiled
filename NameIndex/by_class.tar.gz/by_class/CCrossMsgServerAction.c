// ==== CCrossMsgServerAction::helper_140168dd0  @140168dd0  [medium:callgraph-r0]  (orig: FUN_140168dd0)
void FUN_140168dd0(longlong *param_1,int param_2,int param_3,char *param_4)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  if (((0xee69a15e < uVar1) && (*(int *)((longlong)param_1 + 0x12fc) != 0)) &&
     (*(int *)((longlong)param_1 + 0x12fc) == param_2)) {
    iVar2 = FUN_140373290(param_1 + 0x1cf);
    if (iVar2 == param_3) {
      strncpy((char *)((longlong)param_1 + 0x133a),param_4,0x20);
    }
  }
  return;
}

// ==== CCrossMsgServerAction::helper_140168e50  @140168e50  [medium:callgraph-r0]  (orig: FUN_140168e50)
void FUN_140168e50(longlong *param_1,int param_2,undefined4 param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = (**(code **)(*param_1 + 8))();
  if (((0xee69a15e < uVar1) && (*(int *)((longlong)param_1 + 0x12fc) != 0)) &&
     (*(int *)((longlong)param_1 + 0x12fc) == param_2)) {
    iVar2 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
    if (iVar2 == param_4) {
      FUN_1403732a0(param_1 + 0x1cf,param_3);
    }
  }
  return;
}

// ==== CCrossMsgServerAction::helper_1403732a0  @1403732a0  [medium:callgraph-r1]  (orig: FUN_1403732a0)
void FUN_1403732a0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x220) = param_2;
  return;
}

// ==== CCrossMsgServerAction::ctor_or_dtor  @140433120  [high:vtable-assign]  (orig: FUN_140433120)
undefined8 * FUN_140433120(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgServerAction::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf((CStringPacker *)(param_1 + 0x86),(char *)(param_1 + 6),0x3d9,true);
  return param_1;
}

// ==== CCrossMsgServerAction::ctor_or_dtor  @1404331a0  [high:vtable-assign]  (orig: FUN_1404331a0)
void FUN_1404331a0(undefined8 *param_1)

{
  *param_1 = CCrossMsgServerAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CCrossMsgServerAction::vfunc_1  @1404331e0  [high:rtti-vtable]  (orig: FUN_1404331e0)
undefined8 FUN_1404331e0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgServerAction::ctor_or_dtor  @140433650  [high:vtable-assign]  (orig: FUN_140433650)
undefined8 * FUN_140433650(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgServerAction::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgServerAction::vfunc_3  @1404336b0  [high:rtti-vtable]  (orig: FUN_1404336b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404336b0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  uint uVar11;
  bool bVar12;
  bool bVar13;
  undefined1 auStack_578 [32];
  char *local_558;
  char *local_550;
  undefined4 local_548;
  uint local_538;
  uint local_534;
  undefined8 local_530;
  undefined1 local_528 [1104];
  char local_d8 [40];
  longlong local_b0;
  char local_a8;
  undefined7 uStack_a7;
  undefined1 uStack_a0;
  undefined4 local_9f;
  undefined2 local_9b;
  undefined1 local_99;
  char local_98 [88];
  longlong local_40;
  ulonglong local_38;
  
  local_530 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_558 = (char *)CONCAT44(local_558._4_4_,0x9a);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgserveraction.cpp"
                      );
  }
  else {
    switch(**(undefined2 **)(param_1 + 0x428)) {
    case 0:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar7 = (longlong *)FUN_140087650(uVar9);
        lVar8 = (**(code **)(*plVar7 + 0x98))(plVar7);
        if (((lVar8 != 0) && (cVar3 = FUN_140167b70(lVar8), cVar3 == '\0')) &&
           (iVar6 = FUN_140168b90(lVar8), iVar6 == 1)) {
          local_98[0x20] = 0;
          local_98[0x21] = '\0';
          local_98[0x22] = '\0';
          local_98[0x23] = '\0';
          local_98[0x24] = '\0';
          local_98[0x25] = '\0';
          local_98[0x26] = '\0';
          local_98[0x27] = '\0';
          local_98[0x28] = '\0';
          local_98[0x29] = '\0';
          local_98[0x2a] = '\0';
          local_98[0x2b] = '\0';
          local_98[0x2c] = '\0';
          local_98[0x2d] = '\0';
          local_98[0x2e] = '\0';
          local_98[0x2f] = 0;
          local_98[0x10] = 0;
          local_98[0x11] = '\0';
          local_98[0x12] = '\0';
          local_98[0x13] = '\0';
          local_98[0x14] = '\0';
          local_98[0x15] = '\0';
          local_98[0x16] = '\0';
          local_98[0x17] = '\0';
          local_98[0x18] = '\0';
          local_98[0x19] = '\0';
          local_98[0x1a] = '\0';
          local_98[0x1b] = '\0';
          local_98[0x1c] = '\0';
          local_98[0x1d] = '\0';
          local_98[0x1e] = '\0';
          local_98[0x1f] = 0;
          tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_98 + 0x20,0x10);
          tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,local_98 + 0x10,0x10);
          FUN_140434560(local_528);
          lVar2 = *plVar10;
          lVar1 = *(longlong *)(param_1 + 0x428);
          uVar4 = FUN_1401657c0(lVar8);
          uVar4 = (**(code **)(lVar2 + 0x430))(plVar10,uVar4);
          local_550 = (char *)CONCAT44(local_550._4_4_,*(undefined4 *)(lVar1 + 8));
          local_558 = local_98 + 0x10;
          cVar3 = FUN_1404346f0(local_528,2,uVar4,local_98 + 0x20);
          if (cVar3 == '\0') {
            local_558 = (char *)CONCAT44(local_558._4_4_,0xb9);
            log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                               "msgInfo.Create(HAND_BRICK_TYPE_HAND_IN_BY_NPC, pSynProvider->GetLeagueBrick(pUser->GetLeagueID()), szName, szTitle, m_pInfo->unData)"
                               ,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgserveraction.cpp"
                              );
          }
          else {
            (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))((longlong *)(lVar8 + 0x10),local_528)
            ;
          }
          FUN_1404345e0(local_528);
        }
      }
      break;
    case 1:
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar10 = (longlong *)FUN_140087650(uVar9);
      lVar8 = (**(code **)(*plVar10 + 0x98))
                        (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14));
      if (((lVar8 != 0) && (cVar3 = FUN_140167b70(lVar8), cVar3 == '\0')) &&
         (iVar6 = FUN_140168b90(lVar8), iVar6 == 2)) {
        plVar10 = (longlong *)FUN_1401181a0();
        cVar3 = (**(code **)(*plVar10 + 0x138))
                          (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14));
        if (cVar3 == '\0') {
          FUN_14017b2b0(lVar8,1,*(int *)(*(longlong *)(param_1 + 0x428) + 8) == 0,
                        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c));
          lVar8 = *(longlong *)(param_1 + 0x428);
          local_550 = (char *)CONCAT44(local_550._4_4_,*(undefined4 *)(lVar8 + 0x10));
          local_558 = (char *)CONCAT44(local_558._4_4_,*(undefined4 *)(lVar8 + 0x18));
          tq::GmLogSave("HandInBrick",
                        "user_id[%lu], brick_quality[%d], source_server[%lu], source_league[%lu]",
                        (ulonglong)*(uint *)(lVar8 + 0x14),(ulonglong)*(uint *)(lVar8 + 0x1c));
        }
      }
      break;
    case 3:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        (**(code **)(*plVar10 + 0x4c0))
                  (plVar10,1,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
      }
      break;
    case 4:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        (**(code **)(*plVar10 + 0x4c8))(plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8))
        ;
      }
      break;
    case 7:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_d8,0x20);
        uVar11 = 0;
        local_534 = 0;
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar9 = FUN_140087650(uVar9);
        FUN_1402ac340(uVar9,local_98 + 0x30);
        while (cVar3 = FUN_1400cf370(local_98 + 0x30), cVar3 != '\0') {
          uVar11 = uVar11 + 1;
          local_534 = uVar11;
          if (10000 < uVar11) {
            local_558 = (char *)CONCAT44(local_558._4_4_,0x102);
            log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgserveraction.cpp"
                              );
            break;
          }
          if (local_40 != 0) {
            FUN_140168dd0(local_40,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                          *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10),local_d8);
          }
        }
        (**(code **)(*plVar10 + 0x618))
                  (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                   *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10),local_d8);
      }
      break;
    case 8:
      lVar8 = FUN_140087ed0();
      if (lVar8 != 0) {
        uVar11 = 0;
        local_538 = 0;
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar9 = FUN_140087650(uVar9);
        FUN_1402ac340(uVar9,local_d8);
        while (cVar3 = FUN_1400cf370(local_d8), cVar3 != '\0') {
          uVar11 = uVar11 + 1;
          local_538 = uVar11;
          if (10000 < uVar11) {
            local_558 = (char *)CONCAT44(local_558._4_4_,0x11a);
            log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\crossmsgserveraction.cpp"
                              );
            return;
          }
          if (local_b0 != 0) {
            lVar8 = *(longlong *)(param_1 + 0x428);
            FUN_140168e50(local_b0,*(undefined4 *)(lVar8 + 8),*(undefined4 *)(lVar8 + 0x10),
                          *(undefined4 *)(lVar8 + 0x14));
          }
        }
      }
      break;
    case 9:
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar10 = (longlong *)FUN_140087650(uVar9);
      lVar8 = (**(code **)(*plVar10 + 0xa0))
                        (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14),
                         *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if ((lVar8 != 0) && (cVar3 = FUN_140167b70(lVar8), cVar3 != '\0')) {
        FUN_1401657b0(lVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
        iVar6 = FUN_1401657c0(lVar8);
        if ((iVar6 != 0) &&
           ((*(int *)(*(longlong *)(param_1 + 0x428) + 8) == 0 &&
            (iVar6 = FUN_140161f90(lVar8), iVar6 == 9)))) {
          FUN_140161fa0(lVar8,10);
          FUN_140362560(local_528);
          cVar3 = FUN_140362910(local_528,0x60,
                                *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14),10);
          if (cVar3 != '\0') {
            (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))((longlong *)(lVar8 + 0x10),local_528)
            ;
          }
          FUN_1403625e0(local_528);
        }
      }
      break;
    case 10:
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar10 = (longlong *)FUN_140087650(uVar9);
      lVar8 = (**(code **)(*plVar10 + 0xa0))
                        (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14),
                         *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
      if ((lVar8 != 0) && (cVar3 = FUN_140167b70(lVar8), cVar3 != '\0')) {
        FUN_140165790(lVar8,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
      }
      break;
    case 0xb:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar7 = (longlong *)FUN_140087650(uVar9);
        plVar7 = (longlong *)
                 (**(code **)(*plVar7 + 0xa0))
                           (plVar7,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c)
                           );
        if (plVar7 != (longlong *)0x0) {
          lVar8 = *plVar10;
          lVar2 = *(longlong *)(param_1 + 0x428);
          uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
          (**(code **)(lVar8 + 0x558))(plVar10,uVar4,*(undefined4 *)(lVar2 + 8));
        }
      }
      break;
    case 0xc:
      plVar10 = (longlong *)FUN_140087ed0();
      if (plVar10 != (longlong *)0x0) {
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar7 = (longlong *)FUN_140087650(uVar9);
        lVar8 = (**(code **)(*plVar7 + 0xa0))
                          (plVar7,*(undefined4 *)(param_1 + 0x420),*(undefined4 *)(param_1 + 0x41c))
        ;
        local_a8 = (char)lVar8;
        uStack_a7 = (undefined7)((ulonglong)lVar8 >> 8);
        if (lVar8 != 0) {
          uVar11 = *(uint *)(*(longlong *)(param_1 + 0x428) + 8);
          local_d8[0] = '\0';
          local_d8[1] = '\0';
          local_d8[2] = '\0';
          local_d8[3] = '\0';
          local_d8[4] = '\0';
          local_d8[5] = '\0';
          local_d8[6] = '\0';
          local_d8[7] = '\0';
          local_d8[8] = '\0';
          local_d8[9] = '\0';
          local_d8[10] = '\0';
          local_d8[0xb] = '\0';
          local_d8[0xc] = '\0';
          local_d8[0xd] = '\0';
          local_d8[0xe] = '\0';
          local_d8[0xf] = '\0';
          local_d8[0x10] = '\0';
          local_d8[0x11] = '\0';
          local_d8[0x12] = '\0';
          local_d8[0x13] = '\0';
          local_d8[0x14] = '\0';
          local_d8[0x15] = '\0';
          local_d8[0x16] = '\0';
          local_d8[0x17] = '\0';
          local_d8[0x18] = '\0';
          local_d8[0x19] = '\0';
          local_d8[0x1a] = '\0';
          local_d8[0x1b] = '\0';
          local_d8[0x1c] = '\0';
          local_d8[0x1d] = '\0';
          local_d8[0x1e] = '\0';
          local_d8[0x1f] = 0;
          tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_d8,0x20);
          uVar4 = *(undefined4 *)(param_1 + 0x41c);
          lVar8 = *plVar10;
          lVar2 = *(longlong *)(param_1 + 0x428);
          uVar5 = (**(code **)(*(longlong *)CONCAT71(uStack_a7,local_a8) + 8))();
          local_550 = local_d8;
          local_558 = (char *)CONCAT71(local_558._1_7_,(uVar11 & 0xffff0000) != 0);
          local_548 = uVar4;
          (**(code **)(lVar8 + 0x560))
                    (plVar10,uVar5,*(undefined4 *)(lVar2 + 0x10),(short)uVar11 != 0);
        }
      }
      break;
    case 0xd:
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      iVar6 = FUN_14008b420(uVar9);
      if ((*(int *)(*(longlong *)(param_1 + 0x428) + 0x18) != iVar6) &&
         (plVar10 = (longlong *)FUN_140087ed0(), plVar10 != (longlong *)0x0)) {
        uVar11 = *(uint *)(*(longlong *)(param_1 + 0x428) + 8);
        bVar12 = (short)uVar11 != 0;
        bVar13 = (uVar11 & 0xffff0000) != 0;
        local_98[0x30] = 0;
        local_98[0x31] = '\0';
        local_98[0x32] = '\0';
        local_98[0x33] = '\0';
        local_98[0x34] = '\0';
        local_98[0x35] = '\0';
        local_98[0x36] = '\0';
        local_98[0x37] = '\0';
        local_98[0x38] = '\0';
        local_98[0x39] = '\0';
        local_98[0x3a] = '\0';
        local_98[0x3b] = '\0';
        local_98[0x3c] = '\0';
        local_98[0x3d] = '\0';
        local_98[0x3e] = '\0';
        local_98[0x3f] = '\0';
        local_98[0x40] = '\0';
        local_98[0x41] = '\0';
        local_98[0x42] = '\0';
        local_98[0x43] = '\0';
        local_98[0x44] = '\0';
        local_98[0x45] = '\0';
        local_98[0x46] = '\0';
        local_98[0x47] = '\0';
        local_98[0x48] = '\0';
        local_98[0x49] = '\0';
        local_98[0x4a] = '\0';
        local_98[0x4b] = '\0';
        local_98[0x4c] = '\0';
        local_98[0x4d] = '\0';
        local_98[0x4e] = '\0';
        local_98[0x4f] = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_98 + 0x30,0x20);
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar9 = FUN_140087650(uVar9);
        FUN_1402ac340(uVar9,local_d8);
        while (cVar3 = FUN_1400cf370(local_d8), cVar3 != '\0') {
          if (local_b0 == 0) {
            local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
            log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                              );
          }
          iVar6 = FUN_140167b40(local_b0);
          if (iVar6 == *(int *)(*(longlong *)(param_1 + 0x428) + 0x18)) {
            if (local_b0 == 0) {
              local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
              log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                );
            }
            iVar6 = (**(code **)(*(longlong *)(local_b0 + 0x10) + 0x170))();
            if (iVar6 == *(int *)(*(longlong *)(param_1 + 0x428) + 0x14)) {
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_1401657b0(local_b0,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_140167d20(local_b0,bVar12);
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_140167dd0(local_b0,bVar13);
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_140167c80(local_b0,local_98 + 0x30);
            }
          }
        }
        lVar8 = *(longlong *)(param_1 + 0x428);
        local_548 = *(undefined4 *)(lVar8 + 0x18);
        local_550 = local_98 + 0x30;
        local_558 = (char *)CONCAT71(local_558._1_7_,bVar13);
        (**(code **)(*plVar10 + 0x568))
                  (plVar10,*(undefined4 *)(lVar8 + 0x14),*(undefined4 *)(lVar8 + 0x10),bVar12);
      }
      break;
    case 0xe:
      uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      iVar6 = FUN_14008b420(uVar9);
      if ((*(int *)(*(longlong *)(param_1 + 0x428) + 0x18) != iVar6) &&
         (plVar10 = (longlong *)FUN_140087ed0(), plVar10 != (longlong *)0x0)) {
        local_98[0] = '\0';
        local_98[1] = '\0';
        local_98[2] = '\0';
        local_98[3] = '\0';
        local_98[4] = '\0';
        local_98[5] = '\0';
        local_98[6] = '\0';
        local_98[7] = '\0';
        local_98[8] = '\0';
        local_98[9] = '\0';
        local_98[10] = '\0';
        local_98[0xb] = '\0';
        local_98[0xc] = '\0';
        local_98[0xd] = '\0';
        local_98[0xe] = '\0';
        local_98[0xf] = 0;
        local_a8 = '\0';
        uStack_a7 = 0;
        uStack_a0 = 0;
        local_9f = 0;
        local_9b = 0;
        local_99 = 0;
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,local_98,0x10);
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,&local_a8,0x10);
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar9 = FUN_140087650(uVar9);
        FUN_1402ac340(uVar9,local_d8);
        while (cVar3 = FUN_1400cf370(local_d8), cVar3 != '\0') {
          if (local_b0 == 0) {
            local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
            log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                              );
          }
          iVar6 = FUN_140167b40(local_b0);
          if (iVar6 == *(int *)(*(longlong *)(param_1 + 0x428) + 0x18)) {
            if (local_b0 == 0) {
              local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
              log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                );
            }
            iVar6 = FUN_1401657c0(local_b0);
            if (iVar6 == *(int *)(*(longlong *)(param_1 + 0x428) + 0x14)) {
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_140167dd0(local_b0,0);
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              FUN_140167c80(local_b0);
            }
            else {
              if (local_b0 == 0) {
                local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                  );
              }
              iVar6 = FUN_1401657c0(local_b0);
              if (iVar6 == *(int *)(*(longlong *)(param_1 + 0x428) + 0x10)) {
                if (local_b0 == 0) {
                  local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                  log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                    );
                }
                FUN_140167dd0(local_b0,1);
                if (local_b0 == 0) {
                  local_558 = (char *)CONCAT44(local_558._4_4_,0x2b);
                  log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pUser",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\usermanager.h"
                                    );
                }
                FUN_140167c80(local_b0,&local_a8);
              }
            }
          }
        }
        lVar8 = *(longlong *)(param_1 + 0x428);
        local_550 = &local_a8;
        local_558 = local_98;
        (**(code **)(*plVar10 + 0x570))
                  (plVar10,*(undefined4 *)(lVar8 + 0x14),*(undefined4 *)(lVar8 + 0x10),
                   *(undefined4 *)(lVar8 + 0x18));
      }
    }
  }
  return;
}

// ==== CCrossMsgServerAction::helper_1404346f0  @1404346f0  [medium:callgraph-r0]  (orig: FUN_1404346f0)
ulonglong FUN_1404346f0(longlong param_1,undefined2 param_2,undefined4 param_3,char *param_4,
                       char *param_5,undefined4 param_6)

{
  uint uVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  char *pcVar3;
  
  if ((*(longlong *)(param_1 + 0x428) == 0) || (param_4 == (char *)0x0)) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    pcVar3 = "";
    if (param_5 != (char *)0x0) {
      pcVar3 = param_5;
    }
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0xbb9;
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 6) = param_6;
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_4);
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),pcVar3);
    uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(uint *)(param_1 + 0xc) = uVar1 + 10;
    uVar2 = CONCAT71((uint7)(uint3)(uVar1 + 10 >> 8),1);
  }
  return uVar2;
}

