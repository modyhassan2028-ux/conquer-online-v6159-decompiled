// ==== CCrossMsgTeam::ctor_or_dtor  @1403f0d80  [high:vtable-assign]  (orig: FUN_1403f0d80)
undefined8 * FUN_1403f0d80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgTeam::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgTeam::ctor_or_dtor  @1403f0dd0  [high:vtable-assign]  (orig: FUN_1403f0dd0)
void FUN_1403f0dd0(undefined8 *param_1)

{
  *param_1 = CCrossMsgTeam::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgTeam::vfunc_5  @1403f0e00  [high:rtti-vtable]  (orig: FUN_1403f0e00)
bool FUN_1403f0e00(longlong param_1,void *param_2,ushort param_3)

{
  if (param_2 == (void *)0x0) {
    return false;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return *(int *)(param_1 + 8) == 0x9c5e;
}

// ==== CCrossMsgTeam::ctor_or_dtor  @1403f1040  [high:vtable-assign]  (orig: FUN_1403f1040)
undefined8 * FUN_1403f1040(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgTeam::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgTeam::ctor_or_dtor  @1403f1090  [high:vtable-assign]  (orig: FUN_1403f1090)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403f1090(longlong param_1)

{
  short sVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_478;
  undefined **local_468 [2];
  undefined1 local_458 [1048];
  undefined1 *local_40;
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  sVar1 = **(short **)(param_1 + 0x428);
  if (sVar1 == 0) {
    plVar10 = (longlong *)FUN_140118320();
    lVar2 = *(longlong *)(param_1 + 0x428);
    local_490 = *(undefined4 *)(lVar2 + 0x14);
    local_498 = *(undefined4 *)(lVar2 + 8);
    (**(code **)(*plVar10 + 0x110))
              (plVar10,*(undefined4 *)(param_1 + 0x420),*(undefined2 *)(lVar2 + 2),
               *(undefined4 *)(lVar2 + 0x10));
  }
  else if (sVar1 == 1) {
    plVar10 = (longlong *)FUN_140118320();
    (**(code **)(*plVar10 + 0x118))
              (plVar10,*(undefined4 *)(param_1 + 0x420),
               *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 2),
               *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10));
  }
  else if (sVar1 == 2) {
    plVar10 = (longlong *)FUN_140118320();
    lVar2 = *(longlong *)(param_1 + 0x428);
    local_488 = *(undefined4 *)(lVar2 + 0x10);
    local_490 = *(undefined4 *)(lVar2 + 0x18);
    local_498 = *(undefined4 *)(lVar2 + 0xc);
    (**(code **)(*plVar10 + 0x100))
              (plVar10,*(undefined4 *)(param_1 + 0x41c),*(undefined2 *)(lVar2 + 2),
               *(undefined4 *)(lVar2 + 4));
  }
  else if (sVar1 == 3) {
    uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar10 = (longlong *)FUN_140087650(uVar9);
    plVar10 = (longlong *)
              (**(code **)(*plVar10 + 0x98))
                        (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10));
    if (plVar10 != (longlong *)0x0) {
      plVar11 = (longlong *)FUN_140118320();
      lVar2 = *plVar11;
      uVar4 = (**(code **)(*plVar10 + 8))(plVar10);
      iVar5 = (**(code **)(lVar2 + 0x28))(plVar11,uVar4);
      if (iVar5 != 0) {
        iVar6 = FUN_140167b60(plVar10);
        if (iVar6 != 0) {
          FUN_1402ba1c0(local_468);
          local_468[0] = CCrossMsgTeam::vftable;
          FUN_1402b5600(local_468);
          local_40 = local_458;
          plVar11 = (longlong *)FUN_140118320();
          plVar12 = (longlong *)FUN_140118320();
          uVar4 = (**(code **)(*plVar11 + 0x48))(plVar11,iVar5,0);
          uVar7 = (**(code **)(*plVar12 + 0x50))(plVar12,iVar5,0);
          uVar8 = (**(code **)(*plVar10 + 8))(plVar10);
          local_488 = 0;
          local_498 = uVar7;
          local_490 = uVar4;
          cVar3 = FUN_1403f0f90(local_468,0,uVar8,iVar5);
          if (cVar3 != '\0') {
            plVar11 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            lVar2 = *plVar11;
            uVar4 = FUN_140167b60(plVar10);
            (**(code **)(lVar2 + 0x18))(plVar11,uVar4,local_468);
          }
          local_468[0] = CCrossMsgTeam::vftable;
          FUN_1402b55f0(local_468);
        }
      }
    }
  }
  else {
    log_InlineLogERROR("CCrossMsgTeam::Process. Action[%d] not found");
  }
  return;
}

