// ==== CMsgTQP::helper_14008b260  @14008b260  [medium:callgraph-r0]  (orig: FUN_14008b260)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14008b260(longlong param_1,undefined4 param_2,undefined4 param_3,uint param_4,void *param_5
                  )

{
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined4 local_444;
  uint local_440;
  undefined1 local_43c [1044];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  memset((void *)((longlong)&local_448 + 1),0,0x417);
  if (param_4 < 0x40a) {
    local_448 = param_2;
    local_444 = param_3;
    local_440 = param_4;
    memcpy(local_43c,param_5,(ulonglong)param_4);
    if (*(longlong *)(param_1 + 0x80) != 0) {
      local_458 = &local_448;
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),2,0x4e30,0x418);
    }
  }
  return;
}

// ==== CMsgTQP::ctor_or_dtor  @14035ca70  [high:vtable-assign]  (orig: FUN_14035ca70)
undefined8 * FUN_14035ca70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTQP::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTQP::ctor_or_dtor  @14035cac0  [high:vtable-assign]  (orig: FUN_14035cac0)
void FUN_14035cac0(undefined8 *param_1)

{
  *param_1 = CMsgTQP::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTQP::vfunc_1  @14035caf0  [high:rtti-vtable]  (orig: FUN_14035caf0)
ulonglong FUN_14035caf0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xa97);
}

// ==== CMsgTQP::ctor_or_dtor  @14035cba0  [high:vtable-assign]  (orig: FUN_14035cba0)
undefined8 * FUN_14035cba0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTQP::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTQP::vfunc_3  @14035cbf0  [high:rtti-vtable]  (orig: FUN_14035cbf0)
void FUN_14035cbf0(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))
                       (*(longlong **)(lVar4 + 0x90),param_1);
    if (plVar5 != (longlong *)0x0) {
      iVar1 = *(int *)(param_1 + 0xc);
      lVar2 = plVar5[0x1e2];
      lVar4 = *(longlong *)(param_1 + 0x428);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      FUN_14008b260(uVar6,uVar3,(int)lVar2,iVar1 + -7,lVar4 + 4);
    }
  }
  return;
}

