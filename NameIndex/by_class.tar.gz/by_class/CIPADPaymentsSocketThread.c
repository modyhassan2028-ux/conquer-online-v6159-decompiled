// ==== CIPADPaymentsSocketThread::ctor_or_dtor  @14050ff20  [high:vtable-assign]  (orig: FUN_14050ff20)
CThreadBase * FUN_14050ff20(CThreadBase *param_1,longlong param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CIPADPaymentsSocketThread::vftable;
  *(longlong *)(param_1 + 0x40) = param_2;
  param_1[0x48] = (CThreadBase)0x0;
  param_1[0x49] = (CThreadBase)0x0;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pMsgPort",
                       "f:\\version\\cqserver-78.0.11-1204\\ipadpaymentssocket\\ipadpaymentssocketthread.cpp"
                       ,0x13);
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x40))(*(longlong **)(param_1 + 0x40),1);
  return param_1;
}

// ==== CIPADPaymentsSocketThread::ctor_or_dtor  @14050ffc0  [high:vtable-assign]  (orig: FUN_14050ffc0)
void FUN_14050ffc0(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CIPADPaymentsSocketThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
                    /* WARNING: Could not recover jumptable at 0x00014050fff3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CIPADPaymentsSocketThread::vfunc_4  @140510000  [high:rtti-vtable]  (orig: FUN_140510000)
bool FUN_140510000(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  
  bVar1 = CThreadBase::CreateThread(param_1,"IPADPaymentsSocketThread",param_2);
  return bVar1;
}

// ==== CIPADPaymentsSocketThread::vfunc_2  @140510020  [high:rtti-vtable]  (orig: FUN_140510020)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140510020(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
  _snprintf(local_418,0x3ff,"#%u: IPADPaymentsSocketThread running.");
  lVar2 = -1;
  local_19 = 0;
  pcVar3 = local_418;
  do {
    if (lVar2 == 0) break;
    lVar2 = lVar2 + -1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_428 = local_418;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
  return;
}

// ==== CIPADPaymentsSocketThread::helper_1405100d0  @1405100d0  [medium:callgraph-r2]  (orig: FUN_1405100d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1405100d0(longlong param_1,void *param_2,int param_3)

{
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined4 local_448;
  undefined1 local_444 [1052];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (*(char *)(param_1 + 0x48) == '\0') {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    memset((void *)((longlong)&local_448 + 1),0,0x417);
    local_448 = param_3;
    memcpy(local_444,param_2,(longlong)param_3);
    local_458 = &local_448;
    local_28 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                         (*(longlong **)(param_1 + 0x40),1,0x7572,0x418);
  }
  return local_28;
}

// ==== CIPADPaymentsSocketThread::helper_140510170  @140510170  [medium:callgraph-r2]  (orig: FUN_140510170)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140510170(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  char *param_5)

{
  char cVar1;
  undefined1 auStack_78 [32];
  undefined4 *local_58;
  char *local_50;
  undefined8 local_48;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  char local_34 [36];
  ulonglong local_10;
  
  local_48 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  local_40 = param_2;
  local_3c = param_3;
  local_38 = param_4;
  strncpy(local_34,param_5,0x20);
  local_58 = &local_40;
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                    (*(longlong **)(param_1 + 0x40),0xe,0x2739,0x2c);
  if (cVar1 == '\0') {
    local_50 = local_34;
    local_58 = (undefined4 *)CONCAT44(local_58._4_4_,local_38);
    tq::MyLogSave("gmlog/IPADPayments",
                  "send web server payments result to msgport failure, iduser:%u, idacount:%u, action:%u, szTransactionId:%s"
                 );
  }
  return;
}

// ==== CIPADPaymentsSocketThread::helper_140510230  @140510230  [medium:callgraph-r2]  (orig: FUN_140510230)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140510230(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                    (*(longlong **)(param_1 + 0x40),0xe,0x273b,0x10);
  if (cVar1 == '\0') {
    tq::MyLogSave("gmlog/IPADPayments",
                  "receive query ipad payments info message from web server and send to msgport failure, unUserID:%u, unAccoutID:%u, unCurrentMoney:%u, unConstraintMoney:%u"
                  ,param_3,param_2);
  }
  else {
    tq::MyLogSave("gmlog/IPADPayments",
                  "receive query ipad payments info message from web server and send to msgport succeed, unUserID:%u, unAccoutID:%u, unCurrentMoney:%u, unConstraintMoney:%u"
                  ,param_3,param_2);
  }
  return;
}

// ==== CIPADPaymentsSocketThread::helper_1405102f0  @1405102f0  [medium:callgraph-r1]  (orig: FUN_1405102f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405102f0(longlong param_1,char param_2)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if ((*(char *)(param_1 + 0x48) != param_2) || (*(char *)(param_1 + 0x49) == '\0')) {
    *(char *)(param_1 + 0x48) = param_2;
    if (param_2 == '\0') {
      tq::MyLogSave("gmlog/IPADPayments","Web server connection broken.");
      local_418[0] = '\0';
      memset(local_418 + 1,0,0x3ff);
      pcVar3 = "Web server connection broken.";
    }
    else {
      tq::MyLogSave("gmlog/IPADPayments","Connect to web server OK.");
      local_418[0] = '\0';
      memset(local_418 + 1,0,0x3ff);
      pcVar3 = "Connect to web server OK.";
    }
    _snprintf(local_418,0x3ff,pcVar3);
    lVar2 = -1;
    pcVar3 = local_418;
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    local_428 = local_418;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
    *(undefined1 *)(param_1 + 0x49) = 1;
  }
  return;
}

// ==== CIPADPaymentsSocketThread::ctor_or_dtor  @140510400  [high:vtable-assign]  (orig: FUN_140510400)
CThreadBase * FUN_140510400(CThreadBase *param_1,uint param_2)

{
  *(undefined ***)param_1 = CIPADPaymentsSocketThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  CThreadBase::~CThreadBase(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CIPADPaymentsSocketThread::vfunc_1  @140510460  [high:rtti-vtable]  (orig: FUN_140510460)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140510460(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if ((*(char *)(param_1 + 0x48) != '\0') || (*(char *)(param_1 + 0x49) == '\0')) {
    *(undefined1 *)(param_1 + 0x48) = 0;
    tq::MyLogSave("gmlog/IPADPayments","Web server connection broken.");
    local_418[0] = '\0';
    memset(local_418 + 1,0,0x3ff);
    _snprintf(local_418,0x3ff,"Web server connection broken.");
    lVar2 = -1;
    pcVar3 = local_418;
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    local_428 = local_418;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
    *(undefined1 *)(param_1 + 0x49) = 1;
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  return;
}

// ==== CIPADPaymentsSocketThread::helper_140510540  @140510540  [medium:callgraph-r1]  (orig: FUN_140510540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_140510540(undefined8 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined1 auStack_468 [32];
  char *local_448;
  uint local_440;
  char *local_438;
  uint local_430;
  undefined8 local_428;
  undefined2 local_418;
  undefined2 local_416;
  undefined4 local_414;
  undefined4 local_410;
  undefined4 local_40c;
  undefined4 local_408;
  char local_404 [32];
  ushort local_3e4;
  byte local_3e2;
  char local_3e1 [969];
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_418 = local_418 & 0xff00;
  memset((void *)((longlong)&local_418 + 1),0,0x3ff);
  local_414 = 0;
  local_410 = param_2[2];
  local_40c = param_2[1];
  local_408 = *param_2;
  strncpy(local_404,(char *)((longlong)param_2 + 0xd),0x20);
  local_3e4 = *(ushort *)((longlong)param_2 + 0x2e);
  local_3e2 = *(byte *)(param_2 + 3);
  strncpy(local_3e1,(char *)(param_2 + 0xc),900);
  local_418 = 0x3bb;
  local_416 = 0x65;
  cVar1 = FUN_1405100d0(param_1,&local_418);
  if (cVar1 == '\0') {
    local_430 = (uint)local_3e4;
    local_438 = local_404;
    local_440 = (uint)local_3e2;
    local_448 = (char *)CONCAT44(local_448._4_4_,local_410);
    tq::MyLogSave("gmlog/IPADPayments",
                  "send client payments message to web server failure,iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                 );
    local_448 = local_404;
    FUN_140510170(param_1,local_408,local_40c,2);
  }
  else {
    local_430 = (uint)local_3e4;
    local_438 = local_404;
    local_440 = (uint)local_3e2;
    local_448 = (char *)CONCAT44(local_448._4_4_,local_410);
    tq::MyLogSave("gmlog/IPADPayments",
                  "send client payments message to web server succeed, iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                 );
  }
  return cVar1 != '\0';
}

// ==== CIPADPaymentsSocketThread::helper_1405106f0  @1405106f0  [medium:callgraph-r1]  (orig: FUN_1405106f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405106f0(undefined8 param_1,undefined4 *param_2)

{
  char cVar1;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  undefined8 local_428;
  undefined2 local_418;
  undefined2 local_416;
  undefined4 local_414;
  undefined4 local_410;
  undefined4 local_40c;
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  local_418 = local_418 & 0xff00;
  memset((void *)((longlong)&local_418 + 1),0,0x3ff);
  local_414 = *param_2;
  local_40c = param_2[2];
  local_410 = param_2[1];
  local_418 = 0x18;
  local_416 = 0x66;
  cVar1 = FUN_1405100d0(param_1,&local_418);
  if (cVar1 == '\0') {
    local_438 = local_414;
    tq::MyLogSave("gmlog/IPADPayments",
                  "send client query payments info message to web server failure,iduser:%u, idacount:%u, unServerID:%u"
                 );
    local_438 = 0;
    FUN_140510230(param_1,local_410,local_40c,0);
  }
  else {
    local_438 = local_414;
    tq::MyLogSave("gmlog/IPADPayments",
                  "send client query payments info message to web server succeed, iduser:%u, idacount:%u, unServerID:%u"
                 );
  }
  return cVar1 != '\0';
}

// ==== CIPADPaymentsSocketThread::helper_140510810  @140510810  [medium:callgraph-r1]  (orig: FUN_140510810)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140510810(undefined8 param_1,short *param_2)

{
  if (param_2[1] == 0x65) {
    if (*param_2 == 0x3bb) {
      tq::MyLogSave("gmlog/IPADPayments",
                    "receive ipad payments message from web server succeed, iduser:%u, idacount:%u, action:%u, szTransactionId:%s"
                    ,*(undefined4 *)(param_2 + 8),*(undefined4 *)(param_2 + 6));
      FUN_140510170(param_1,*(undefined4 *)(param_2 + 8),*(undefined4 *)(param_2 + 6),
                    *(undefined4 *)(param_2 + 2));
    }
  }
  if (param_2[1] == 0x66) {
    if (*param_2 == 0x18) {
      FUN_140510230(param_1,*(undefined4 *)(param_2 + 4),*(undefined4 *)(param_2 + 6),
                    *(undefined4 *)(param_2 + 8));
    }
  }
  return 1;
}

// ==== CIPADPaymentsSocketThread::helper_1405108d0  @1405108d0  [medium:callgraph-r0]  (orig: FUN_1405108d0)
undefined8 FUN_1405108d0(undefined8 param_1,int param_2,int *param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  if (param_3 == (int *)0x0) {
    log_InlineLogERROR("CIPADPaymentsSocketThread::ProcessMsg. buf is NULL");
    uVar1 = 0;
  }
  else {
    if (param_2 == 0x186a1) {
      FUN_140510540(param_1,param_3,param_3,param_4,0xfffffffffffffffe);
    }
    else if (param_2 == 0x186a2) {
      FUN_1405106f0(param_1,param_3);
    }
    else if (param_2 == 0x186a8) {
      FUN_1405102f0(param_1,*param_3 == 1);
    }
    else if (param_2 == 0x186a9) {
      FUN_140510810(param_1,param_3 + 1);
    }
    else {
      tq::MyLogSave("gmlog/IPADPayments","invalid packet:%d, port:%d");
    }
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CIPADPaymentsSocketThread::vfunc_3  @140510960  [high:rtti-vtable]  (orig: FUN_140510960)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140510960(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined4 *local_4a0;
  char local_498;
  ulong local_494;
  undefined4 local_490;
  uint local_48c;
  undefined4 local_488;
  longlong local_480;
  CTickAnalyst local_478 [24];
  undefined8 local_460;
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_460 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_480 = param_1;
  if ((DAT_14097675c & 1) == 0) {
    DAT_14097675c = DAT_14097675c | 1;
    DAT_140976758 = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x58))
                    (*(longlong **)(param_1 + 0x40),DAT_140970740);
  CTickAnalyst::CTickAnalyst(local_458,0x35);
  uVar2 = tq::TimeGet(0);
  local_494 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_478,0x37);
    CTickAnalyst::~CTickAnalyst(local_478);
    if (uVar2 - DAT_140976758 < 0x2711) {
      DAT_140976758 = DAT_140976758 + 1000;
    }
    else {
      log_InlineLogWARNING("resync CIPADPaymentsSocketThread::OnTimer cumulative deviation %dms");
      DAT_140976758 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4a0 = &local_490;
      local_4a8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x48))
                        (*(longlong **)(param_1 + 0x40),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      CTickAnalyst::CTickAnalyst(local_478,0x36);
      local_498 = 1;
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,local_490);
      local_498 = FUN_1405108d0(param_1,local_48c,local_438,local_488);
      if (local_498 == '\0') {
        log_InlineLogERROR("CIPADPaymentsSocketThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                           ,(ulonglong)local_48c);
      }
      CTickAnalyst::~CTickAnalyst(local_478);
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_140976758) < 1000) {
    DAT_140970740 = 1000 - (uVar2 - DAT_140976758);
  }
  else {
    DAT_140970740 = 0;
  }
  CTickAnalyst::~CTickAnalyst(local_458);
  return 1;
}

