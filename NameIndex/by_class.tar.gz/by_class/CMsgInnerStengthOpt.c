// ==== CMsgInnerStengthOpt::helper_140006ee0  @140006ee0  [medium:callgraph-r1]  (orig: FUN_140006ee0)
void FUN_140006ee0(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                  undefined4 *param_5)

{
  *param_2 = *(undefined4 *)(param_1 + 0x224);
  *param_3 = *(undefined4 *)(param_1 + 0x228);
  *param_4 = *(undefined4 *)(param_1 + 0x22c);
  *param_5 = *(undefined4 *)(param_1 + 0x230);
  return;
}

// ==== CMsgInnerStengthOpt::helper_140087c90  @140087c90  [medium:callgraph-r1]  (orig: FUN_140087c90)
longlong FUN_140087c90(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x218);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgInnerStengthOpt::helper_1401600f0  @1401600f0  [medium:callgraph-r2]  (orig: FUN_1401600f0)
longlong FUN_1401600f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x1d0);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgInnerStengthOpt::helper_14017bda0  @14017bda0  [medium:callgraph-r1]  (orig: FUN_14017bda0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_14017bda0(longlong *param_1,uint param_2,undefined4 param_3,char param_4)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  
  uVar5 = (ulonglong)param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","dwEMoneyCost > 0",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp");
    return 0;
  }
  uVar2 = FUN_140371860(param_1 + 0x1cf);
  uVar7 = (ulonglong)uVar2;
  if (param_4 == '\x01') {
    if (*(uint *)((longlong)param_1 + 0xfa4) < param_2) {
      return 0;
    }
  }
  else if (param_4 == '\x02') {
    if (uVar2 < param_2) {
      return 0;
    }
  }
  else {
    if (param_4 != '\x03') {
      return 0;
    }
    if (*(uint *)((longlong)param_1 + 0xfa4) + uVar2 < param_2) {
      return 0;
    }
  }
  uVar6 = 0;
  if (param_4 == '\x01') {
LAB_14017bf39:
    if ((int)uVar5 != 0) {
      cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,-uVar5,1);
      if (cVar1 == '\0') goto LAB_14017bf6d;
      uVar3 = (**(code **)(*param_1 + 8))(param_1);
      FUN_1401742b0(param_1,param_3,uVar3,0);
      uVar4 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      uVar5 = (**(code **)(*param_1 + 8))(param_1);
      tq::MyLogSave("gmlog/emoney_buy","%lu\t%s\t%lu\t%d\t%d\t%lu\t%lu\t1\t",uVar5 & 0xffffffff,
                    uVar4);
    }
    uVar4 = 1;
  }
  else {
    if (param_4 == '\x02') {
      uVar7 = (ulonglong)param_2;
LAB_14017be80:
      uVar5 = uVar6;
      if ((int)uVar7 != 0) {
        cVar1 = (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x2d,-uVar7,1);
        if (cVar1 == '\0') goto LAB_14017bf6d;
        uVar3 = (**(code **)(*param_1 + 8))(param_1);
        FUN_140174470(param_1,param_3,uVar3,0);
        uVar4 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
        uVar7 = (**(code **)(*param_1 + 8))(param_1);
        tq::MyLogSave("gmlog/emoney_mono_buy","%lu\t%s\t%lu\t%d\t%d\t%lu\t%lu\t1\t",
                      uVar7 & 0xffffffff,uVar4);
      }
      goto LAB_14017bf39;
    }
    if (param_4 == '\x03') {
      if (uVar2 < param_2) {
        uVar6 = (ulonglong)(param_2 - uVar2);
      }
      else {
        uVar7 = (ulonglong)param_2;
      }
      goto LAB_14017be80;
    }
LAB_14017bf6d:
    uVar4 = 0;
  }
  return uVar4;
}

// ==== CMsgInnerStengthOpt::helper_1401e25f0  @1401e25f0  [medium:callgraph-r2]  (orig: FUN_1401e25f0)
longlong * FUN_1401e25f0(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(byte *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgInnerStengthOpt::helper_1401f1cc0  @1401f1cc0  [medium:callgraph-r0]  (orig: FUN_1401f1cc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401f1cc0(undefined8 param_1,longlong param_2,ushort param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_168 [32];
  uint local_148;
  undefined8 local_140;
  ushort local_138;
  longlong local_130;
  undefined8 local_128;
  char local_118;
  undefined1 local_117 [254];
  undefined1 local_19;
  ulonglong local_18;
  
  local_128 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_168;
  local_138 = param_3;
  local_130 = param_2;
  if (param_2 == 0) {
    local_148 = 0x2ef;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_118 = '\0';
    memset(local_117,0,0xff);
    local_148 = (uint)param_3;
    _snprintf(&local_118,0x100,"</F>%s</N>%u");
    local_19 = 0;
    lVar2 = DAT_140975bf0;
    if (DAT_140975bf0 == 0) {
      local_148 = 0x3cd;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar2 = 0;
    }
    local_140 = 0;
    local_148 = 0;
    cVar1 = FUN_1402863b0(lVar2,&local_118,param_2,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                (
                "Lua return fault, Call From:CInnerStrengthMgr::ProcessInnerStrengthLearnByClient, lua function:%s."
                );
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f1e10  @1401f1e10  [medium:callgraph-r2]  (orig: FUN_1401f1e10)
void FUN_1401f1e10(longlong param_1)

{
  FUN_140402620(*(undefined8 *)(param_1 + 0x10));
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f2ee0  @1401f2ee0  [medium:callgraph-r0]  (orig: FUN_1401f2ee0)
undefined8 FUN_1401f2ee0(longlong param_1,longlong *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  IStringManager *pIVar8;
  
  if (((param_2 == (longlong *)0x0) || (param_3 == 0)) ||
     (iVar3 = (**(code **)(*param_2 + 8))(param_2), iVar3 == param_3)) {
    return 0;
  }
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar6 = (longlong *)FUN_140087650(uVar5);
  lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,param_3);
  if (((lVar7 != 0) && (cVar2 = FUN_140167b70(param_2), cVar2 == '\0')) &&
     (((char)param_2[0x259] == '\0' &&
      ((cVar2 = FUN_140167b70(lVar7), cVar2 == '\0' && (*(char *)(lVar7 + 0x12c8) == '\0')))))) {
    plVar6 = (longlong *)FUN_1401183a0();
    lVar1 = *plVar6;
    uVar4 = (**(code **)(*param_2 + 8))(param_2);
    cVar2 = (**(code **)(lVar1 + 0x170))(plVar6,uVar4,param_3);
    if (cVar2 != '\0') {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      uVar5 = FUN_140087c90(uVar5);
      cVar2 = FUN_14027a410(uVar5,param_3,9,uVar4);
      if (cVar2 != '\0') {
        pIVar8 = theInstance();
        lVar1 = *(longlong *)(lVar7 + 0x10);
        uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_REFUSE");
        (**(code **)(lVar1 + 0x358))(lVar7 + 0x10,uVar5);
        return 1;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_1401f63c0  @1401f63c0  [medium:callgraph-r2]  (orig: FUN_1401f63c0)
undefined1 * FUN_1401f63c0(longlong param_1,undefined2 param_2)

{
  longlong lVar1;
  undefined2 local_res10 [4];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401f5620((longlong *)(param_1 + 0x58),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x88);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return (undefined1 *)(local_10 + 0x38);
  }
  return &DAT_1406dd892;
}

// ==== CMsgInnerStengthOpt::helper_1401f6460  @1401f6460  [medium:callgraph-r2]  (orig: FUN_1401f6460)
undefined4 FUN_1401f6460(longlong param_1,undefined2 param_2)

{
  longlong lVar1;
  undefined2 local_res10 [4];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401f5620((longlong *)(param_1 + 0x58),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x88);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined4 *)(local_10 + 0x28);
  }
  return 0xffffffff;
}

// ==== CMsgInnerStengthOpt::helper_1401f6e70  @1401f6e70  [medium:callgraph-r0]  (orig: FUN_1401f6e70)
void FUN_1401f6e70(longlong param_1,longlong *param_2,undefined2 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  char cVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  undefined2 local_res18;
  longlong *local_48 [2];
  longlong *local_38;
  longlong lStack_30;
  
  local_res18 = param_3;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar4 = FUN_140167b70(param_2);
    if (cVar4 == '\0') {
      lVar7 = 0;
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      plVar1 = (longlong *)(param_1 + 0x18);
      plVar5 = (longlong *)FUN_1401f5550(plVar1,&local_38,local_res10);
      plVar2 = (longlong *)*plVar5;
      lVar3 = plVar5[1];
      lVar6 = *(longlong *)(param_1 + 0x48);
      local_48[0] = (longlong *)*plVar1;
      if ((plVar2 == (longlong *)0x0) || (plVar2 != local_48[0])) {
        _invalid_parameter_noinfo();
      }
      if (lVar3 != lVar6) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = lVar7;
        }
        else {
          lVar6 = *plVar2;
        }
        if (lVar3 == *(longlong *)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lVar3 + 0x20) == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CInnerStrengthMgr::ProcessInnerStrengthFinish data pointer is null, idUser:%u type:%u."
                            );
          local_38 = plVar2;
          lStack_30 = lVar3;
          FUN_1401f5190(plVar1,local_48,&local_38);
        }
        else {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar7 = *plVar2;
          }
          if (lVar3 == *(longlong *)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_140408e20(*(undefined8 *)(lVar3 + 0x20),param_2,param_3);
        }
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f7010  @1401f7010  [medium:callgraph-r0]  (orig: FUN_1401f7010)
void FUN_1401f7010(longlong param_1,longlong *param_2,undefined2 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  char cVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  undefined2 local_res18;
  longlong *local_48 [2];
  longlong *local_38;
  longlong lStack_30;
  
  local_res18 = param_3;
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar4 = FUN_140167b70(param_2);
    if ((cVar4 == '\0') && (*(char *)((longlong)param_2 + 0x51c) != '\0')) {
      lVar7 = 0;
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      plVar1 = (longlong *)(param_1 + 0x18);
      plVar5 = (longlong *)FUN_1401f5550(plVar1,&local_38,local_res10);
      plVar2 = (longlong *)*plVar5;
      lVar3 = plVar5[1];
      lVar6 = *(longlong *)(param_1 + 0x48);
      local_48[0] = (longlong *)*plVar1;
      if ((plVar2 == (longlong *)0x0) || (plVar2 != local_48[0])) {
        _invalid_parameter_noinfo();
      }
      if (lVar3 != lVar6) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = lVar7;
        }
        else {
          lVar6 = *plVar2;
        }
        if (lVar3 == *(longlong *)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lVar3 + 0x20) == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CInnerStrengthMgr::ProcessInnerStrengthAbolish data pointer is null, idUser:%u type:%u."
                            );
          local_38 = plVar2;
          lStack_30 = lVar3;
          FUN_1401f5190(plVar1,local_48,&local_38);
        }
        else {
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar7 = *plVar2;
          }
          if (lVar3 == *(longlong *)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_1404071e0(*(undefined8 *)(lVar3 + 0x20),param_2,param_3);
        }
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f71c0  @1401f71c0  [medium:callgraph-r0]  (orig: FUN_1401f71c0)
void FUN_1401f71c0(longlong param_1,longlong param_2,int param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  int local_res18 [4];
  longlong *local_48;
  longlong lStack_40;
  longlong *local_38 [2];
  
  local_res18[0] = param_3;
  if ((param_2 == 0) || (param_3 == 0)) {
    log_InlineLogERROR(
                      "CInnerStrengthMgr::SendPlayerInnerStrengthTotalInfo param is error, idUser:%d."
                      );
  }
  else {
    plVar1 = (longlong *)(param_1 + 0x18);
    FUN_1401f5550(plVar1,&local_48,local_res18,param_4,0xfffffffffffffffe);
    lVar2 = *(longlong *)(param_1 + 0x48);
    lVar3 = 0;
    local_38[0] = (longlong *)*plVar1;
    if ((local_48 == (longlong *)0x0) || (local_48 != local_38[0])) {
      _invalid_parameter_noinfo();
    }
    if (lStack_40 != lVar2) {
      if (local_48 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar3;
      }
      else {
        lVar2 = *local_48;
      }
      if (lStack_40 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(lStack_40 + 0x20) == 0) {
        log_InlineLogERROR(
                          "CInnerStrengthMgr::SendPlayerInnerStrengthTotalInfo data pointer is null, idUser:%u."
                          );
        FUN_1401f5190(plVar1,local_38,&local_48);
      }
      else {
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar3 = *local_48;
        }
        if (lStack_40 == *(longlong *)(lVar3 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_140404b60(*(undefined8 *)(lStack_40 + 0x20),param_2);
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f7300  @1401f7300  [medium:callgraph-r0]  (orig: FUN_1401f7300)
void FUN_1401f7300(longlong param_1,longlong param_2,int param_3,undefined1 param_4)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  int local_res18 [2];
  undefined1 local_res20;
  longlong *local_48;
  longlong lStack_40;
  longlong *local_38 [2];
  
  local_res18[0] = param_3;
  local_res20 = param_4;
  if ((param_2 == 0) || (param_3 == 0)) {
    log_InlineLogERROR("CInnerStrengthMgr::SendPlayerInnerStrengthInfo param is error, idUser:%d.");
  }
  else {
    plVar1 = (longlong *)(param_1 + 0x18);
    FUN_1401f5550(plVar1,&local_48,local_res18,param_4,0xfffffffffffffffe);
    lVar2 = *(longlong *)(param_1 + 0x48);
    lVar3 = 0;
    local_38[0] = (longlong *)*plVar1;
    if ((local_48 == (longlong *)0x0) || (local_48 != local_38[0])) {
      _invalid_parameter_noinfo();
    }
    if (lStack_40 != lVar2) {
      if (local_48 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar2 = lVar3;
      }
      else {
        lVar2 = *local_48;
      }
      if (lStack_40 == *(longlong *)(lVar2 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong *)(lStack_40 + 0x20) == 0) {
        log_InlineLogERROR(
                          "CInnerStrengthMgr::SendPlayerInnerStrengthInfo data pointer is null, idUser:%u."
                          );
        FUN_1401f5190(plVar1,local_38,&local_48);
      }
      else {
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar3 = *local_48;
        }
        if (lStack_40 == *(longlong *)(lVar3 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_140407b10(*(undefined8 *)(lStack_40 + 0x20),param_2,local_res20);
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401f7440  @1401f7440  [medium:callgraph-r3]  (orig: FUN_1401f7440)
undefined1 FUN_1401f7440(longlong param_1,undefined2 param_2)

{
  longlong lVar1;
  undefined2 local_res10 [4];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401f5620((longlong *)(param_1 + 0x58),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x88);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined1 *)(local_10 + 0x22);
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_1401f74e0  @1401f74e0  [medium:callgraph-r2]  (orig: FUN_1401f74e0)
longlong FUN_1401f74e0(longlong param_1,undefined1 param_2)

{
  longlong lVar1;
  undefined1 local_res10 [8];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401f56f0((longlong *)(param_1 + 0x98),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 200);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x98))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar1) {
    return 0;
  }
  if (local_18 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar1 = 0;
  }
  else {
    lVar1 = *local_18;
  }
  if (local_10 == *(longlong *)(lVar1 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return local_10 + 0x20;
}

// ==== CMsgInnerStengthOpt::helper_1401f7580  @1401f7580  [medium:callgraph-r0]  (orig: FUN_1401f7580)
ulonglong FUN_1401f7580(longlong param_1,longlong *param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *extraout_RAX_00;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined4 local_res10 [2];
  longlong *local_48;
  longlong lStack_40;
  longlong *local_38 [2];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    uVar2 = FUN_140167b70(param_2);
    if ((char)uVar2 == '\0') {
      local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
      plVar4 = (longlong *)(param_1 + 0x18);
      FUN_1401f5550(plVar4,&local_48,local_res10);
      lVar1 = *(longlong *)(param_1 + 0x48);
      lVar5 = 0;
      plVar3 = (longlong *)*plVar4;
      local_38[0] = plVar3;
      if ((local_48 == (longlong *)0x0) || (local_48 != plVar3)) {
        _invalid_parameter_noinfo();
        plVar3 = extraout_RAX_00;
      }
      if (lStack_40 == lVar1) {
        uVar2 = (ulonglong)plVar3 & 0xffffffffffffff00;
      }
      else {
        if (local_48 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar5 = *local_48;
        }
        if (lStack_40 == *(longlong *)(lVar5 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(longlong *)(lStack_40 + 0x20) == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CInnerStrengthMgr::ProcessExercise data pointer is null, idUser:%u.");
          uVar2 = FUN_1401f5190(plVar4,local_38,&local_48);
          uVar2 = uVar2 & 0xffffffffffffff00;
        }
        else {
          uVar2 = FUN_1404095b0(*(longlong *)(lStack_40 + 0x20),param_2,param_3,param_4);
        }
      }
    }
    else {
      uVar2 = uVar2 & 0xffffffffffffff00;
    }
  }
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1401f76f0  @1401f76f0  [medium:callgraph-r2]  (orig: FUN_1401f76f0)
undefined4 FUN_1401f76f0(longlong param_1,undefined2 param_2)

{
  longlong *plVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined2 local_res10 [4];
  undefined1 local_18 [16];
  
  local_res10[0] = param_2;
  plVar3 = (longlong *)FUN_1401f5620((longlong *)(param_1 + 0x58),local_18,local_res10);
  lVar4 = *(longlong *)(param_1 + 0x88);
  plVar1 = (longlong *)*plVar3;
  lVar2 = plVar3[1];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  if (lVar2 == lVar4) {
    return 0;
  }
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = 0;
  }
  else {
    lVar4 = *plVar1;
  }
  if (lVar2 == *(longlong *)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return *(undefined4 *)(lVar2 + 0x24);
}

// ==== CMsgInnerStengthOpt::helper_1401f7c00  @1401f7c00  [medium:callgraph-r2]  (orig: FUN_1401f7c00)
undefined4 FUN_1401f7c00(longlong param_1,undefined2 param_2,byte param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined4 uVar7;
  undefined8 *puVar8;
  longlong **pplVar9;
  longlong lVar10;
  undefined8 *puVar11;
  longlong lVar12;
  undefined2 local_res10 [4];
  longlong *local_48;
  undefined8 *local_40;
  longlong *local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong *local_20;
  
  local_res10[0] = param_2;
  FUN_1401f5620((longlong *)(param_1 + 0x58),&local_48,local_res10);
  plVar3 = local_48;
  lVar10 = *(longlong *)(param_1 + 0x88);
  if ((local_48 == (longlong *)0x0) || (local_48 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  puVar5 = local_40;
  if (local_40 == (undefined8 *)lVar10) {
    return 0;
  }
  lVar10 = 0;
  if (local_48 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar10;
  }
  else {
    lVar12 = *local_48;
  }
  if (local_40 == (undefined8 *)*(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  puVar11 = (undefined8 *)(*(undefined8 **)((longlong)local_40 + 0xe8))[1];
  cVar2 = *(char *)((longlong)puVar11 + 0x21);
  puVar4 = *(undefined8 **)((longlong)local_40 + 0xe8);
  while (cVar2 == '\0') {
    if (*(byte *)(puVar11 + 3) < param_3) {
      puVar8 = (undefined8 *)puVar11[2];
      puVar11 = puVar4;
    }
    else {
      puVar8 = (undefined8 *)*puVar11;
    }
    puVar4 = puVar11;
    puVar11 = puVar8;
    cVar2 = *(char *)((longlong)puVar8 + 0x21);
  }
  plVar1 = (longlong *)((longlong)local_40 + 0xb8);
  puVar11 = *(undefined8 **)((longlong)local_40 + 0xe8);
  local_40 = puVar4;
  local_48 = (longlong *)*plVar1;
  if ((longlong *)*plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar11) || (param_3 < *(byte *)(puVar4 + 3))) {
    pplVar9 = &local_38;
    local_30 = *(undefined8 *)((longlong)puVar5 + 0xe8);
    local_38 = *(longlong **)((longlong)puVar5 + 0xb8);
  }
  else {
    pplVar9 = &local_48;
  }
  local_28 = *pplVar9;
  local_20 = pplVar9[1];
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar10;
  }
  else {
    lVar12 = *plVar3;
  }
  if (puVar5 == (undefined8 *)*(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  plVar1 = local_28;
  plVar3 = *(longlong **)((longlong)puVar5 + 0xe8);
  if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)((longlong)puVar5 + 0xb8))) {
    _invalid_parameter_noinfo();
  }
  plVar6 = local_20;
  if (local_20 == plVar3) {
    uVar7 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar6 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar7 = *(undefined4 *)((longlong)plVar6 + 0x1c);
  }
  return uVar7;
}

// ==== CMsgInnerStengthOpt::helper_1401f7dc0  @1401f7dc0  [medium:callgraph-r1]  (orig: FUN_1401f7dc0)
int FUN_1401f7dc0(longlong param_1,uint param_2,int param_3)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  ulong uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x108))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x21);
  puVar4 = *(undefined8 **)(param_1 + 0x108);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x21);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x108);
  local_30 = puVar4;
  local_38 = *(longlong *)(param_1 + 0xd8);
  if (*(longlong *)(param_1 + 0xd8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x108);
    local_28 = *(longlong *)(param_1 + 0xd8);
  }
  else {
    plVar8 = &local_38;
  }
  plVar3 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x108);
  local_18 = plVar3;
  local_10 = plVar8[1];
  if ((*(longlong **)(param_1 + 0xd8) == (longlong *)0x0) ||
     (*(longlong **)(param_1 + 0xd8) != plVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (lVar10 != local_10) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    iVar2 = *(int *)(lVar5 + 0x1c);
    uVar6 = tq::TimeGet(1);
    if (uVar6 < (uint)(param_3 * 0x3c + iVar2)) {
      return iVar2 + (param_3 * 0x3c - uVar6);
    }
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_1401f7f00  @1401f7f00  [medium:callgraph-r0]  (orig: FUN_1401f7f00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_1401f7f00(longlong param_1,longlong *param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  IStringManager *pIVar8;
  char *pcVar9;
  longlong lVar10;
  longlong lVar11;
  undefined1 auStack_928 [32];
  uint *local_908;
  uint local_8f8;
  uint local_8f4;
  uint local_8f0;
  uint local_8ec;
  undefined4 local_8e8 [2];
  longlong local_8e0;
  longlong *local_8d8;
  longlong local_8d0;
  undefined8 local_8c8;
  undefined1 local_8b8 [1136];
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_8c8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_928;
  local_8e0 = CONCAT44(local_8e0._4_4_,param_3);
  if (((param_2 == (longlong *)0x0) || (param_3 == 0)) ||
     (iVar2 = (**(code **)(*param_2 + 8))(param_2), iVar2 == param_3)) {
    return 0;
  }
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar6 = (longlong *)FUN_140087650(uVar5);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,param_3);
  if (plVar6 == (longlong *)0x0) {
    return 0;
  }
  cVar1 = FUN_140167b70(param_2);
  if ((cVar1 != '\0') || ((char)param_2[0x259] != '\0')) {
    pIVar8 = theInstance();
    lVar10 = param_2[2];
    uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_ERROR_USER_OS");
    (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar5);
    return 0;
  }
  cVar1 = FUN_140167b70(plVar6);
  if ((cVar1 != '\0') || ((char)plVar6[0x259] != '\0')) {
    pIVar8 = theInstance();
    lVar10 = param_2[2];
    uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_ERROR_TARGET_OS");
    (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar5);
    return 0;
  }
  plVar7 = (longlong *)FUN_1401183a0();
  lVar10 = *plVar7;
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  cVar1 = (**(code **)(lVar10 + 0x170))(plVar7,uVar3,param_3);
  if (cVar1 == '\0') {
    return 0;
  }
  local_8e8[0] = (**(code **)(*param_2 + 8))(param_2);
  FUN_1401f5550(param_1 + 0x18,&local_8d8,local_8e8);
  plVar7 = local_8d8;
  lVar10 = *(longlong *)(param_1 + 0x48);
  if ((local_8d8 == (longlong *)0x0) || (local_8d8 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar11 = local_8d0;
  if (local_8d0 == lVar10) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CInnerStrengthMgr::ApplyInnerStrengthExchange can\'t found user data, idUser:%lu."
                      );
    return 0;
  }
  FUN_1401f5550(param_1 + 0x18,&local_8d8,&local_8e0);
  local_8e0 = *(longlong *)(param_1 + 0x48);
  if ((local_8d8 == (longlong *)0x0) || (local_8d8 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  if (local_8d0 == local_8e0) {
    log_InlineLogERROR(
                      "CInnerStrengthMgr::ApplyInnerStrengthExchange can\'t found user data, idUser:%lu."
                      );
    return 0;
  }
  if (plVar7 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar10 = 0;
  }
  else {
    lVar10 = *plVar7;
  }
  if (lVar11 == *(longlong *)(lVar10 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  lVar10 = *(longlong *)(lVar11 + 0x20);
  if (local_8d8 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar11 = 0;
  }
  else {
    lVar11 = *local_8d8;
  }
  if (local_8d0 == *(longlong *)(lVar11 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar10 == 0) || (*(longlong *)(local_8d0 + 0x20) == 0)) {
    return 0;
  }
  if (*(char *)((longlong)param_2 + 0x51c) == '\0') {
    pIVar8 = theInstance();
    lVar10 = param_2[2];
    uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_USER_PWD");
    (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar5);
    return 0;
  }
  if (*(char *)((longlong)plVar6 + 0x51c) == '\0') {
    pIVar8 = theInstance();
    lVar10 = param_2[2];
    uVar5 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_TARGET_PWD");
    (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar5);
    return 0;
  }
  local_8f8 = 0;
  local_8f4 = local_8f8;
  local_8f0 = local_8f8;
  local_8ec = local_8f8;
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar5 = FUN_1400d6610(uVar5);
  local_908 = &local_8f4;
  FUN_140006ee0(uVar5,&local_8ec,&local_8f0,&local_8f8);
  if (local_8ec == 0) {
    log_InlineLogERROR("Exchange InnerStrength cost is 0 !");
    return 0;
  }
  uVar4 = (**(code **)(*param_2 + 0x108))(param_2);
  if ((((uVar4 < local_8f8) || (uVar4 = (**(code **)(*plVar6 + 0x108))(plVar6), uVar4 < local_8f8))
      || (uVar4 = (**(code **)(param_2[2] + 0x70))(param_2 + 2), uVar4 < local_8f4)) ||
     (uVar4 = (**(code **)(plVar6[2] + 0x70))(plVar6 + 2), uVar4 < local_8f4)) {
    local_448 = '\0';
    memset(local_447,0,0x3ff);
    pIVar8 = theInstance();
    pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar8)
                               (pIVar8,"STR_EXCHANGE_INNERSTRENGTH_LEV_ERROR");
    local_908 = (uint *)CONCAT44(local_908._4_4_,local_8f4);
    _snprintf(&local_448,0x3ff,pcVar9);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_448);
    return 0;
  }
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  iVar2 = FUN_1401f7dc0(param_1,uVar3,local_8f0);
  if (iVar2 != 0) {
    local_448 = '\0';
    memset(local_447,0,0x3ff);
    pIVar8 = theInstance();
    ceil((double)iVar2 / _DAT_140727618);
    pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_EXCHANGE_INNERSTRENGTH_USER_CD")
    ;
    _snprintf(&local_448,0x3ff,pcVar9);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_448);
    return 0;
  }
  iVar2 = FUN_1401f7dc0(param_1,param_3,local_8f0);
  if (iVar2 != 0) {
    local_448 = '\0';
    memset(local_447,0,0x3ff);
    pIVar8 = theInstance();
    ceil((double)iVar2 / _DAT_140727618);
    pcVar9 = (char *)(*(code *)**(undefined8 **)pIVar8)
                               (pIVar8,"STR_EXCHANGE_INNERSTRENGTH_TARGET_CD");
    _snprintf(&local_448,0x3ff,pcVar9);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_448);
    return 0;
  }
  if (*(uint *)((longlong)param_2 + 0xfa4) < local_8ec) {
    return 0;
  }
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar5 = FUN_140087c90(uVar5);
  FUN_14027a130(uVar5,uVar3,9,param_3);
  FUN_14040a430(local_8b8);
  uVar5 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  cVar1 = FUN_14040a4c0(local_8b8,uVar3,uVar5);
  if (cVar1 == '\0') {
    FUN_14040a480(local_8b8);
    return 0;
  }
  cVar1 = FUN_14040a530(local_8b8);
  if (cVar1 == '\0') {
    FUN_14040a480(local_8b8);
    return 0;
  }
  (**(code **)(plVar6[2] + 0x350))(plVar6 + 2,local_8b8);
  FUN_14040a480(local_8b8);
  return 1;
}

// ==== CMsgInnerStengthOpt::helper_1401f88b0  @1401f88b0  [medium:callgraph-r0]  (orig: FUN_1401f88b0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_1401f88b0(longlong param_1,longlong *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  ulong uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  char *pcVar12;
  ulong *puVar13;
  longlong lVar14;
  longlong lVar15;
  undefined1 auStack_1768 [32];
  uint *local_1748;
  undefined8 local_1740;
  undefined4 local_1738;
  undefined4 local_1730;
  int local_1728;
  uint local_1724;
  uint local_1720;
  int local_171c;
  undefined4 local_1718 [4];
  longlong *local_1708;
  longlong lStack_1700;
  int local_16f8 [2];
  longlong local_16f0;
  longlong local_16e8;
  longlong *local_16d8;
  longlong lStack_16d0;
  undefined1 local_16c8 [24];
  undefined8 local_16b0;
  undefined1 local_16a8 [1072];
  undefined1 local_1278 [1072];
  char local_e48;
  undefined1 local_e47 [1023];
  char local_a48;
  undefined1 local_a47 [510];
  undefined1 local_849;
  char local_848;
  undefined1 local_847 [1023];
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x1401f88c6;
  local_16b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1768;
  if (((param_2 == (longlong *)0x0) || (param_3 == 0)) ||
     (local_16f8[0] = param_3, iVar3 = (**(code **)(*param_2 + 8))(param_2), iVar3 == param_3)) {
    return 0;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar9 = (longlong *)FUN_140087650(uVar8);
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x98))(plVar9,param_3);
  if (plVar9 == (longlong *)0x0) {
    return 0;
  }
  cVar2 = FUN_140167b70(param_2);
  if ((cVar2 != '\0') || ((char)param_2[0x259] != '\0')) {
    pIVar11 = theInstance();
    lVar14 = param_2[2];
    uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_EXCHANGE_INNERSTRENGTH_ERROR_USER_OS");
    (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
    return 0;
  }
  cVar2 = FUN_140167b70(plVar9);
  if ((cVar2 != '\0') || ((char)plVar9[0x259] != '\0')) {
    pIVar11 = theInstance();
    lVar14 = param_2[2];
    uVar8 = (*(code *)**(undefined8 **)pIVar11)
                      (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_ERROR_TARGET_OS");
    (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
    return 0;
  }
  plVar10 = (longlong *)FUN_1401183a0();
  lVar14 = *plVar10;
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  cVar2 = (**(code **)(lVar14 + 0x170))(plVar10,uVar4,param_3);
  if (cVar2 == '\0') {
    return 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar8 = FUN_140087c90(uVar8);
  cVar2 = FUN_14027a410(uVar8,param_3,9,uVar4);
  if (cVar2 == '\0') {
    return 0;
  }
  local_1728 = (**(code **)(*param_2 + 8))(param_2);
  FUN_1401f5550(param_1 + 0x18,&local_1708,&local_1728);
  lVar14 = *(longlong *)(param_1 + 0x48);
  if ((local_1708 == (longlong *)0x0) || (local_1708 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  if (lStack_1700 == lVar14) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CInnerStrengthMgr::ExchangeInnerStrength can\'t found user data, idUser:%lu."
                      );
    return 0;
  }
  FUN_1401f5550(param_1 + 0x18,&local_16d8,local_16f8);
  plVar10 = local_16d8;
  local_16f0 = *(longlong *)(param_1 + 0x48);
  if ((local_16d8 == (longlong *)0x0) || (local_16d8 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  if (lStack_16d0 == local_16f0) {
    log_InlineLogERROR(
                      "CInnerStrengthMgr::ExchangeInnerStrength can\'t found user data, idUser:%lu."
                      );
    return 0;
  }
  if (local_1708 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar14 = 0;
  }
  else {
    lVar14 = *local_1708;
  }
  if (lStack_1700 == *(longlong *)(lVar14 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  lVar14 = *(longlong *)(lStack_1700 + 0x20);
  local_16f0 = lVar14;
  if (plVar10 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar15 = 0;
  }
  else {
    lVar15 = *plVar10;
  }
  lVar1 = lStack_16d0;
  if (lStack_16d0 == *(longlong *)(lVar15 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  local_16e8 = *(longlong *)(lVar1 + 0x20);
  if ((lVar14 == 0) || (local_16e8 == 0)) {
    return 0;
  }
  if (*(char *)((longlong)param_2 + 0x51c) == '\0') {
    pIVar11 = theInstance();
    lVar14 = param_2[2];
    uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_EXCHANGE_INNERSTRENGTH_USER_PWD");
    (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
    return 0;
  }
  if (*(char *)((longlong)plVar9 + 0x51c) == '\0') {
    pIVar11 = theInstance();
    lVar14 = param_2[2];
    uVar8 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_EXCHANGE_INNERSTRENGTH_TARGET_PWD");
    (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
    return 0;
  }
  local_171c = 0;
  local_1718[0] = 0;
  local_1724 = 0;
  local_1720 = 0;
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar8 = FUN_1400d6610(uVar8);
  local_1748 = &local_1720;
  FUN_140006ee0(uVar8,&local_171c,local_1718,&local_1724);
  if (local_171c == 0) {
    log_InlineLogERROR("Exchange InnerStrength cost is 0 !");
    return 0;
  }
  uVar5 = (**(code **)(*param_2 + 0x108))(param_2);
  if ((((uVar5 < local_1724) || (uVar5 = (**(code **)(*plVar9 + 0x108))(plVar9), uVar5 < local_1724)
       ) || (uVar5 = (**(code **)(param_2[2] + 0x70))(param_2 + 2), uVar5 < local_1720)) ||
     (uVar5 = (**(code **)(plVar9[2] + 0x70))(plVar9 + 2), uVar5 < local_1720)) {
    local_e48 = '\0';
    memset(local_e47,0,0x3ff);
    pIVar11 = theInstance();
    pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_LEV_ERROR");
    local_1748 = (uint *)CONCAT44(local_1748._4_4_,local_1720);
    _snprintf(&local_e48,0x3ff,pcVar12);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_e48);
    return 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  local_1728 = FUN_1401f7dc0(param_1,uVar4,local_1718[0]);
  if (local_1728 != 0) {
    local_e48 = '\0';
    memset(local_e47,0,0x3ff);
    pIVar11 = theInstance();
    ceil((double)local_1728 / _DAT_140727618);
    pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_USER_CD");
    _snprintf(&local_e48,0x3ff,pcVar12);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_e48);
    return 0;
  }
  local_1728 = FUN_1401f7dc0(param_1,param_3,local_1718[0]);
  if (local_1728 != 0) {
    local_e48 = '\0';
    memset(local_e47,0,0x3ff);
    pIVar11 = theInstance();
    ceil((double)local_1728 / _DAT_140727618);
    pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_TARGET_CD");
    _snprintf(&local_e48,0x3ff,pcVar12);
    (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_e48);
    return 0;
  }
  local_1730 = 0;
  local_1738 = 0;
  local_1740 = CONCAT44(local_1740._4_4_,0x10e4);
  local_1748 = (uint *)CONCAT44(local_1748._4_4_,0x15e);
  cVar2 = FUN_14017bda0(plVar9,local_171c,0x4b,1);
  if (cVar2 == '\0') {
    return 0;
  }
  cVar2 = FUN_140406330(lVar14,param_3);
  if (cVar2 == '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CInnerStrengthMgr::ExchangeInnerStrength error, idUser:%lu, idTarget:%lu");
    return 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  cVar2 = FUN_140406330(local_16e8,uVar4);
  if (cVar2 == '\0') {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CInnerStrengthMgr::ExchangeInnerStrength error, idTarget:%lu, idUser:%lu");
    return 0;
  }
  FUN_1401f5190(param_1 + 0x18,local_16c8,&local_1708);
  local_1708 = local_16d8;
  lStack_1700 = lStack_16d0;
  FUN_1401f5190(param_1 + 0x18,local_16c8,&local_1708);
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  lStack_1700 = local_16e8;
  local_1708._0_4_ = uVar4;
  FUN_1401f4fe0(param_1 + 0x18,local_16c8,&local_1708);
  local_1708 = (longlong *)CONCAT44(local_1708._4_4_,param_3);
  lStack_1700 = lVar14;
  FUN_1401f4fe0(param_1 + 0x18,local_16c8,&local_1708);
  uVar6 = tq::TimeGet(1);
  local_1728 = (**(code **)(*param_2 + 8))(param_2);
  puVar13 = (ulong *)FUN_140053460(param_1 + 0xd8,&local_1728);
  *puVar13 = uVar6;
  puVar13 = (ulong *)FUN_140053460(param_1 + 0xd8);
  *puVar13 = uVar6;
  local_848 = '\0';
  memset(local_847,0,0x3ff);
  pIVar11 = theInstance();
  (**(code **)(param_2[2] + 0x18))(param_2 + 2);
  pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)
                              (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_SUC_APPLY");
  _snprintf(&local_848,0x3ff,pcVar12);
  (**(code **)(plVar9[2] + 0x358))(plVar9 + 2);
  local_448 = '\0';
  memset(local_447,0,0x3ff);
  pIVar11 = theInstance();
  (**(code **)(plVar9[2] + 0x18))(plVar9 + 2);
  pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar11)
                              (pIVar11,"STR_EXCHANGE_INNERSTRENGTH_SUC_ACCEPT");
  _snprintf(&local_448,0x3ff,pcVar12);
  (**(code **)(param_2[2] + 0x358))(param_2 + 2,&local_448);
  FUN_14040a650(local_1278);
  lVar14 = local_16e8;
  uVar4 = FUN_140405d80(local_16e8,1);
  cVar2 = FUN_14040a710(local_1278,7,uVar4);
  if (cVar2 != '\0') {
    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_1278);
  }
  FUN_14040a650(local_16a8);
  uVar4 = FUN_140405d80(local_16f0,1);
  cVar2 = FUN_14040a710(local_16a8,7,uVar4);
  if (cVar2 != '\0') {
    (**(code **)(plVar9[2] + 0x350))(plVar9 + 2,local_16a8);
  }
  plVar10 = (longlong *)CurrentInstanceGet();
  plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10);
  if (plVar10 != (longlong *)0x0) {
    lVar15 = *plVar10;
    uVar4 = FUN_140402ec0(lVar14);
    uVar8 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
    uVar7 = (**(code **)(*param_2 + 8))(param_2);
    (**(code **)(lVar15 + 0x78))(plVar10,uVar7,uVar8,uVar4);
    lVar14 = *plVar10;
    uVar4 = FUN_140402ec0(local_16f0);
    uVar8 = (**(code **)(plVar9[2] + 0x18))(plVar9 + 2);
    uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
    (**(code **)(lVar14 + 0x78))(plVar10,uVar7,uVar8,uVar4);
  }
  local_a48 = '\0';
  memset(local_a47,0,0x1ff);
  (**(code **)(*param_2 + 8))(param_2);
  _snprintf(&local_a48,0x200,"</F>InnerStrength_Exchange</N>%lu");
  local_849 = 0;
  uVar8 = FUN_140087e30();
  local_1740 = 0;
  local_1748 = (uint *)((ulonglong)local_1748 & 0xffffffff00000000);
  cVar2 = FUN_1402863b0(uVar8,&local_a48,plVar9,0);
  if (cVar2 == '\0') {
    log_InlineLogLuaERROR
              (
              "Lua return fault, Call From:CInnerStrengthMgr::AcceptExchangeInnerStrength, lua function:%s."
              );
    FUN_14040a6a0(local_16a8);
    FUN_14040a6a0(local_1278);
    return 0;
  }
  FUN_14040a6a0(local_16a8);
  FUN_14040a6a0(local_1278);
  return 1;
}

// ==== CMsgInnerStengthOpt::helper_1401fb6f0  @1401fb6f0  [medium:callgraph-r2]  (orig: FUN_1401fb6f0)
void FUN_1401fb6f0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1401fb460((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMsgInnerStengthOpt::helper_1401fbb60  @1401fbb60  [medium:callgraph-r2]  (orig: FUN_1401fbb60)
undefined8 * FUN_1401fbb60(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1401f4060(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x69) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMsgInnerStengthOpt::helper_1401fbd20  @1401fbd20  [medium:callgraph-r3]  (orig: FUN_1401fbd20)
undefined2 * FUN_1401fbd20(undefined2 *param_1,undefined2 *param_2)

{
  undefined8 *puVar1;
  undefined2 *puVar2;
  undefined1 *puVar3;
  longlong lVar4;
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  *param_1 = *param_2;
  *(undefined1 *)(param_1 + 1) = *(undefined1 *)(param_2 + 1);
  *(undefined4 *)(param_1 + 2) = *(undefined4 *)(param_2 + 2);
  *(undefined4 *)(param_1 + 4) = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 6) = *(undefined4 *)(param_2 + 6);
  lVar4 = 0x40;
  *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_2 + 8);
  *(undefined4 *)(param_1 + 10) = *(undefined4 *)(param_2 + 10);
  puVar2 = param_1 + 0xc;
  puVar3 = (undefined1 *)((longlong)param_2 + 0x19);
  do {
    lVar4 = lVar4 + -1;
    *(undefined1 *)puVar2 =
         *(undefined1 *)(((longlong)param_2 - (longlong)param_1) + (longlong)puVar2);
    *(undefined1 *)((longlong)puVar2 + 1) = *puVar3;
    puVar2 = puVar2 + 1;
    puVar3 = puVar3 + 2;
  } while (lVar4 != 0);
  puVar1 = (undefined8 *)(param_1 + 0x4c);
  if (puVar1 != (undefined8 *)(param_2 + 0x4c)) {
    local_38 = *puVar1;
    puStack_30 = *(undefined8 **)(param_1 + 100);
    puStack_20 = (undefined8 *)*puStack_30;
    local_28 = local_38;
    FUN_1401dff20(puVar1,local_18,&local_28,&local_38);
    FUN_1401e0110(puVar1,param_2 + 0x4c);
  }
  puVar1 = (undefined8 *)(param_1 + 0x6c);
  if (puVar1 != (undefined8 *)(param_2 + 0x6c)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x84);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1401fb460(puVar1,local_18,&local_38,&local_28);
    FUN_1401fb640(puVar1,param_2 + 0x6c);
  }
  return param_1;
}

// ==== CMsgInnerStengthOpt::helper_1401fc020  @1401fc020  [medium:callgraph-r2]  (orig: FUN_1401fc020)
undefined1 FUN_1401fc020(longlong param_1,undefined2 param_2,undefined8 param_3)

{
  undefined1 uVar1;
  longlong lVar2;
  undefined2 local_res10 [4];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1401f5620((longlong *)(param_1 + 0x58),&local_18,local_res10);
  lVar2 = *(longlong *)(param_1 + 0x88);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar2) {
    uVar1 = 0;
  }
  else {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar2 = 0;
    }
    else {
      lVar2 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar2 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_1401fbd20(param_3,local_10 + 0x20);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CMsgInnerStengthOpt::helper_140402620  @140402620  [medium:callgraph-r3]  (orig: FUN_140402620)
undefined1 FUN_140402620(longlong param_1,byte param_2,uint param_3)

{
  char cVar1;
  longlong *plVar2;
  bool bVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined1 uVar6;
  uint uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  longlong lVar13;
  uint uVar14;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong local_30;
  
  puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar12 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar12 + 3) < param_2) {
      puVar8 = (undefined8 *)puVar12[2];
      puVar12 = puVar4;
    }
    else {
      puVar8 = (undefined8 *)*puVar12;
    }
    puVar4 = puVar12;
    puVar12 = puVar8;
    cVar1 = *(char *)((longlong)puVar8 + 0x51);
  }
  puVar12 = *(undefined8 **)(param_1 + 0x38);
  local_50 = puVar4;
  local_58 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar12) || (param_2 < *(byte *)(puVar4 + 3))) {
    plVar11 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x38);
    local_48 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar11 = &local_58;
  }
  plVar2 = (longlong *)*plVar11;
  lVar13 = *(longlong *)(param_1 + 0x38);
  local_38 = plVar2;
  local_30 = plVar11[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_30;
  if (local_30 != lVar13) {
    uVar6 = 0;
    uVar14 = 0;
    bVar3 = true;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar13 = 0;
    }
    else {
      lVar13 = *plVar2;
    }
    if (lVar5 == *(longlong *)(lVar13 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar11 = *(longlong **)(lVar5 + 0x38);
    if (*(longlong **)(lVar5 + 0x40) < plVar11) {
      _invalid_parameter_noinfo();
    }
    plVar2 = *(longlong **)(lVar5 + 0x20);
    while( true ) {
      plVar10 = *(longlong **)(lVar5 + 0x40);
      if (plVar10 < *(longlong **)(lVar5 + 0x38)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(lVar5 + 0x20))) {
        _invalid_parameter_noinfo();
      }
      if (plVar11 == plVar10) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar2;
      }
      if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
        _invalid_parameter_noinfo();
      }
      plVar10 = (longlong *)*plVar11;
      if (plVar10 != (longlong *)0x0) {
        plVar9 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,2);
        uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
        if (param_3 <= uVar7) {
          if (bVar3) {
            plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,1);
            uVar6 = (**(code **)(*plVar10 + 0x20))(plVar10);
            bVar3 = false;
            uVar14 = uVar7;
          }
          else if (uVar7 < uVar14) {
            plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,1);
            uVar6 = (**(code **)(*plVar10 + 0x20))(plVar10);
            uVar14 = uVar7;
          }
        }
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar2;
      }
      if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
        _invalid_parameter_noinfo();
      }
      plVar11 = plVar11 + 1;
    }
    return uVar6;
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_140403b00  @140403b00  [medium:callgraph-r3]  (orig: FUN_140403b00)
undefined8 * FUN_140403b00(undefined8 *param_1,undefined8 *param_2,ushort *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(ushort *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(ushort *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(ushort *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgInnerStengthOpt::helper_140404b60  @140404b60  [medium:callgraph-r1]  (orig: FUN_140404b60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140404b60(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  byte bVar5;
  short sVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined1 local_478;
  uint local_477;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_2 == 0) {
    local_488 = 0x2cb;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1404dc0c0(local_468);
    cVar4 = FUN_1404dc180(local_468);
    if (cVar4 == '\0') {
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::SendPlayerInnerStrengthTotalInfo create failed, idUser:%u."
                        );
      FUN_1404dc110(local_468);
    }
    else {
      plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x80);
      plVar1 = *(longlong **)(param_1 + 0x50);
      while( true ) {
        plVar2 = *(longlong **)(param_1 + 0x80);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x50))) {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == plVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = 0;
        }
        else {
          lVar8 = *plVar1;
        }
        if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar8 = plVar7[4];
        if (lVar8 == 0) {
          log_InlineLogERROR(
                            "CInnerStrengthPlayer::SendPlayerInnerStrengthTotalInfo pInnerStrengthData is NULL, idUser:%u."
                            );
        }
        else {
          local_478 = 0;
          local_477 = 0;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar9 = 0;
          }
          else {
            lVar9 = *plVar1;
          }
          if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          local_478 = (undefined1)plVar7[3];
          bVar5 = FUN_1404db810(lVar8);
          local_477 = (uint)bVar5;
          cVar4 = FUN_1404dc1d0(local_468,&local_478);
          if (cVar4 == '\0') {
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                      ((longlong *)(param_2 + 0x10),local_468);
            FUN_1404dc280(local_468);
            FUN_1404dc1d0(local_468,&local_478);
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
          plVar2 = (longlong *)plVar7[2];
          if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
            cVar4 = *(char *)(*plVar2 + 0x29);
            plVar7 = plVar2;
            plVar2 = (longlong *)*plVar2;
            while (cVar4 == '\0') {
              cVar4 = *(char *)(*plVar2 + 0x29);
              plVar7 = plVar2;
              plVar2 = (longlong *)*plVar2;
            }
          }
          else {
            cVar4 = *(char *)(plVar7[1] + 0x29);
            plVar3 = (longlong *)plVar7[1];
            plVar2 = plVar7;
            while ((plVar7 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
              cVar4 = *(char *)(plVar7[1] + 0x29);
              plVar3 = (longlong *)plVar7[1];
              plVar2 = plVar7;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      sVar6 = FUN_1404dc260(local_468);
      if (sVar6 != 0) {
        (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))((longlong *)(param_2 + 0x10),local_468)
        ;
      }
      FUN_1404dc110(local_468);
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404060b0  @1404060b0  [medium:callgraph-r2]  (orig: FUN_1404060b0)
longlong FUN_1404060b0(longlong param_1,ushort param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  plVar1 = (longlong *)(param_1 + 0x50);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar2 = *(char *)((longlong)puVar7 + 0x29);
  puVar4 = *(undefined8 **)(param_1 + 0x80);
  while (cVar2 == '\0') {
    if (*(ushort *)(puVar7 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar4;
  local_38 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar7) || (param_2 < *(ushort *)(puVar4 + 3))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *plVar1;
  }
  else {
    plVar8 = &local_38;
  }
  plVar3 = (longlong *)*plVar8;
  lVar9 = *(longlong *)(param_1 + 0x80);
  local_18 = plVar3;
  local_10 = plVar8[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 != lVar9) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar9 = *(longlong *)(lVar5 + 0x20);
    if (lVar9 != 0) {
      return lVar9;
    }
    local_18 = (longlong *)*plVar8;
    local_10 = plVar8[1];
    FUN_140404f80(plVar1,&local_28,&local_18);
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_1404061f0  @1404061f0  [medium:callgraph-r3]  (orig: FUN_1404061f0)
bool FUN_1404061f0(longlong param_1,ushort param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar4 = *(char *)((longlong)puVar7 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x80);
  while (cVar4 == '\0') {
    if (*(ushort *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar2 = puVar7;
    puVar7 = puVar5;
    cVar4 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar2;
  local_38 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar7) || (param_2 < *(ushort *)(puVar2 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar6 = &local_38;
  }
  plVar1 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x80);
  local_18 = plVar1;
  local_10 = plVar6[1];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_10;
  if (local_10 != lVar8) {
    lVar8 = 0;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar8;
    }
    else {
      lVar9 = *plVar1;
    }
    if (lVar3 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(lVar3 + 0x20) != 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar8 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      cVar4 = FUN_1404db910(*(undefined8 *)(lVar3 + 0x20));
      return cVar4 != '\0';
    }
  }
  return false;
}

// ==== CMsgInnerStengthOpt::helper_140406330  @140406330  [medium:callgraph-r1]  (orig: FUN_140406330)
undefined8 FUN_140406330(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  if ((param_2 == 0) || (*(char *)(param_1 + 0xd4) != '\0')) {
    return 0;
  }
  *(int *)(param_1 + 0xd0) = param_2;
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x80);
  plVar2 = *(longlong **)(param_1 + 0x50);
  while( true ) {
    plVar5 = *(longlong **)(param_1 + 0x80);
    if ((*(longlong **)(param_1 + 0x50) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0x50) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar4) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_1404dbb10(plVar4[4],param_2);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar5 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar5 + 0x29);
        plVar4 = plVar5;
        plVar5 = (longlong *)*plVar5;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar4 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar3 = (longlong *)plVar4[1];
        plVar5 = plVar4;
        while ((plVar4 = plVar3, cVar1 == '\0' && (plVar5 == (longlong *)plVar4[2]))) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar3 = (longlong *)plVar4[1];
          plVar5 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(param_1 + 0x90);
  plVar2 = (longlong *)**(undefined8 **)(param_1 + 0xc0);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar2;
          plVar2 = *(longlong **)(param_1 + 0xc0);
          if ((*(longlong **)(param_1 + 0x90) == (longlong *)0x0) ||
             (*(longlong **)(param_1 + 0x90) != plVar4)) {
            _invalid_parameter_noinfo();
          }
          if (plVar2 == plVar5) {
            return 1;
          }
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar4;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar2 = (longlong *)plVar5[4];
          if (plVar2 != (longlong *)0x0) {
            plVar3 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,1);
            (**(code **)(*plVar3 + 0xb8))(plVar3,param_2);
            (**(code **)(*plVar2 + 0x38))(plVar2,1);
          }
          if (plVar4 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar2 = plVar5;
        }
        plVar2 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar2 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar5 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar2 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar2 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar2 + 0x29) != '\0');
    do {
      plVar3 = plVar2;
      plVar2 = plVar3;
      if (plVar5 != (longlong *)plVar3[2]) break;
      plVar2 = (longlong *)plVar3[1];
      plVar5 = plVar3;
    } while (*(char *)((longlong)plVar2 + 0x29) == '\0');
  } while( true );
}

// ==== CMsgInnerStengthOpt::helper_140406640  @140406640  [medium:callgraph-r2]  (orig: FUN_140406640)
longlong FUN_140406640(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140403b00(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140405470(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgInnerStengthOpt::helper_1404071e0  @1404071e0  [medium:callgraph-r1]  (orig: FUN_1404071e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404071e0(longlong param_1,longlong *param_2,undefined2 param_3)

{
  longlong lVar1;
  char cVar2;
  byte bVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  longlong lVar12;
  undefined8 uVar13;
  longlong *plVar14;
  char *pcVar15;
  IStringManager *pIVar16;
  undefined4 *puVar17;
  longlong lVar18;
  longlong lVar19;
  undefined1 auStack_928 [32];
  undefined8 local_908;
  ulonglong local_900;
  undefined2 local_8f8;
  undefined2 local_8f6;
  char local_8f4 [4];
  longlong local_8f0;
  longlong *local_8e8;
  IStringManager *local_8e0;
  longlong local_8d8;
  int local_8d0;
  longlong *local_8c8;
  IStringManager *local_8c0;
  IStringManager *local_8b8 [2];
  longlong *local_8a8 [2];
  undefined8 local_898;
  undefined1 local_888 [1088];
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_898 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_928;
  local_8f8 = param_3;
  local_8f6 = param_3;
  local_8f0 = param_1;
  local_8e8 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_908 = CONCAT44(local_908._4_4_,0x249);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar19 = 0;
  local_8e0 = (IStringManager *)0x0;
  plVar9 = (longlong *)FUN_140405340(param_1 + 0x50,local_8a8,&local_8f6);
  pIVar10 = (IStringManager *)*plVar9;
  local_8d8 = plVar9[1];
  lVar12 = *(longlong *)(param_1 + 0x80);
  local_8b8[0] = *(IStringManager **)(param_1 + 0x50);
  local_8e0 = pIVar10;
  if ((pIVar10 == (IStringManager *)0x0) || (pIVar10 != local_8b8[0])) {
    _invalid_parameter_noinfo();
  }
  lVar1 = local_8d8;
  if (local_8d8 == lVar12) {
    pIVar10 = theInstance();
    lVar12 = param_2[2];
    uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_INNER_STRENGTH_NOT_LEARN");
    (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
    return;
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  if (*(longlong *)(lVar1 + 0x20) == 0) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CInnerStrengthPlayer::ProcessInnerStrengthAbolish pointer is null, idUser:%u, type:%u."
                      );
    FUN_140406640(param_1 + 0x50,&local_8f6);
    return;
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  cVar2 = FUN_1404dba10(*(undefined8 *)(lVar1 + 0x20));
  if (cVar2 != '\x01') {
    return;
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  cVar2 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
  if (cVar2 == 'd') {
    pIVar10 = theInstance();
    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar12 + 0x1d0) == 0) {
      local_908 = CONCAT44(local_908._4_4_,0x15e);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar19 = *(longlong *)(lVar12 + 0x1d0);
    }
    lVar12 = param_2[2];
    uVar11 = FUN_1401f63c0(lVar19,local_8f8);
    uVar13 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_INNER_STRENGTH_ABOLISH_FAILED_MAX");
    (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar13,uVar11);
    return;
  }
  local_900 = local_900 & 0xffffffffffffff00;
  local_908._0_4_ = 1;
  cVar2 = FUN_140338940(param_2,0x2ddbe4,0x2ddbe4,1);
  if (cVar2 == '\0') {
    pIVar10 = theInstance();
    lVar12 = param_2[2];
    uVar11 = (*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_INNER_STRENGTH_ABOLISH_NOT_ITEM");
    (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar11);
    return;
  }
  local_900 = local_900 & 0xffffffffffffff00;
  local_908 = CONCAT44(local_908._4_4_,1);
  cVar2 = FUN_140350360(param_2,0x2ddbe4,0x2ddbe4,1);
  if (cVar2 == '\0') {
    log_InlineLogERROR("CInnerStrengthPlayer::ProcessInnerStrengthAbolish MultiDelItem failed.");
    return;
  }
  local_8c8 = (longlong *)0x0;
  local_8d0 = 8;
  while (iVar6 = local_8d0, local_8d0 < 0x16) {
    if (pIVar10 == (IStringManager *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar19;
    }
    else {
      lVar12 = *(longlong *)pIVar10;
    }
    if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = FUN_1404db6c0(*(undefined8 *)(lVar1 + 0x20));
    lVar12 = local_8f0;
    if (uVar5 != 0) {
      local_8f4[0] = (char)iVar6 + -7;
      plVar14 = (longlong *)FUN_1401e25f0(local_8f0 + 0x10,local_8b8,local_8f4);
      plVar9 = (longlong *)*plVar14;
      local_8c0 = (IStringManager *)plVar14[1];
      local_8e0 = *(IStringManager **)(lVar12 + 0x40);
      local_8a8[0] = *(longlong **)(lVar12 + 0x10);
      local_8c8 = plVar9;
      if ((plVar9 == (longlong *)0x0) || (plVar9 != local_8a8[0])) {
        _invalid_parameter_noinfo();
      }
      pIVar16 = local_8c0;
      if (local_8c0 == local_8e0) {
        log_InlineLogERROR(
                          "CInnerStrengthPlayer::ProcessInnerStrengthAbolish m_mapAttribTypeTotalValue not find data, key:%u."
                          );
      }
      else {
        if (plVar9 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = lVar19;
        }
        else {
          lVar12 = *plVar9;
        }
        if (pIVar16 == *(IStringManager **)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(uint *)(pIVar16 + 0x1c) < uVar5) {
          if (plVar9 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = lVar19;
          }
          else {
            lVar12 = *plVar9;
          }
          if (pIVar16 == *(IStringManager **)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          *(undefined4 *)(pIVar16 + 0x1c) = 0;
        }
        else {
          if (plVar9 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = lVar19;
          }
          else {
            lVar12 = *plVar9;
          }
          if (pIVar16 == *(IStringManager **)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          *(uint *)(pIVar16 + 0x1c) = *(int *)(pIVar16 + 0x1c) - uVar5;
        }
      }
    }
    local_8d0 = iVar6 + 1;
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  FUN_1404dbc10(*(undefined8 *)(lVar1 + 0x20));
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  bVar3 = FUN_1404db810(*(undefined8 *)(lVar1 + 0x20));
  lVar12 = local_8f0;
  *(int *)(local_8f0 + 0xdc) = *(int *)(local_8f0 + 0xdc) - (uint)bVar3;
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar18 = lVar19;
  }
  else {
    lVar18 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar18 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  FUN_1404db870(*(undefined8 *)(lVar1 + 0x20),0);
  lVar12 = FUN_140008520(*(undefined4 *)(lVar12 + 8));
  if (*(longlong *)(lVar12 + 0x1d0) == 0) {
    local_908 = CONCAT44(local_908._4_4_,0x15e);
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)(lVar12 + 0x1d0);
  }
  iVar6 = FUN_1401f76f0(lVar12,local_8f8);
  plVar9 = local_8e8;
  if ((iVar6 != 0) && (cVar2 = FUN_140166ac0(local_8e8,iVar6,1), cVar2 == '\0')) {
    log_InlineLogERROR(
                      "CInnerStrengthPlayer::ProcessInnerStrengthAbolish AddCultureValue failed, culture num:%u."
                      );
    return;
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  plVar9 = plVar9 + 2;
  bVar3 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
  uVar4 = FUN_1404db500(*(undefined8 *)(lVar1 + 0x20));
  (**(code **)(*plVar9 + 0x18))(plVar9);
  (**(code **)(*local_8e8 + 8))();
  local_900 = CONCAT44(local_900._4_4_,(uint)bVar3);
  local_908 = CONCAT44(local_908._4_4_,(uint)uVar4);
  tq::MyLogSave("gmlog/inner_strength","InnerStrength abolish, Uesr:%u, %s; type:%u; value:%u;");
  local_448 = '\0';
  memset(local_447,0,0x3ff);
  if (pIVar10 == (IStringManager *)0x0) {
    _invalid_parameter_noinfo();
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)pIVar10;
  }
  if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  bVar3 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
  if (0x59 < bVar3) {
    if (pIVar10 == (IStringManager *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar19;
    }
    else {
      lVar12 = *(longlong *)pIVar10;
    }
    if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    bVar3 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
    if (bVar3 < 0x65) {
      local_8e0 = theInstance();
      lVar12 = FUN_140008520(*(undefined4 *)(local_8f0 + 8));
      if (*(longlong *)(lVar12 + 0x1d0) == 0) {
        local_908 = CONCAT44(local_908._4_4_,0x15e);
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar12 = lVar19;
      }
      else {
        lVar12 = *(longlong *)(lVar12 + 0x1d0);
      }
      if (pIVar10 == (IStringManager *)0x0) {
        _invalid_parameter_noinfo();
        lVar18 = lVar19;
      }
      else {
        lVar18 = *(longlong *)pIVar10;
      }
      if (lVar1 == *(longlong *)(lVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar11 = FUN_1401f63c0(lVar12,local_8f8);
      bVar3 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
      (**(code **)(*plVar9 + 0x18))(plVar9);
      pcVar15 = (char *)(*(code *)**(undefined8 **)local_8e0)
                                  (local_8e0,"STR_INNER_STRENGTH_ABOLISH_SUCCESS2");
      local_908 = CONCAT44(local_908._4_4_,(uint)bVar3);
      local_900 = uVar11;
      _snprintf(&local_448,0x400,pcVar15);
      goto LAB_1404079a9;
    }
  }
  pIVar16 = theInstance();
  lVar12 = FUN_140008520(*(undefined4 *)(local_8f0 + 8));
  if (*(longlong *)(lVar12 + 0x1d0) == 0) {
    local_908 = CONCAT44(local_908._4_4_,0x15e);
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar12 = lVar19;
  }
  else {
    lVar12 = *(longlong *)(lVar12 + 0x1d0);
  }
  uVar11 = FUN_1401f63c0(lVar12,local_8f8);
  (**(code **)(*plVar9 + 0x18))(plVar9);
  pcVar15 = (char *)(*(code *)**(undefined8 **)pIVar16)
                              (pIVar16,"STR_INNER_STRENGTH_ABOLISH_SUCCESS1");
  local_908 = uVar11;
  _snprintf(&local_448,0x400,pcVar15);
LAB_1404079a9:
  lVar12 = local_8f0;
  local_49 = 0;
  plVar14 = (longlong *)FUN_140008520(*(undefined4 *)(local_8f0 + 8));
  local_900 = CONCAT44(local_900._4_4_,0x7eb);
  local_908._0_4_ = 0xff0000;
  (**(code **)(*plVar14 + 0x60))(plVar14,&local_448,0xffffffff,0);
  FUN_1404dc330(local_888);
  local_8f8 = CONCAT11(local_8f8._1_1_,1);
  puVar17 = (undefined4 *)FUN_140406b20(lVar12 + 0x10,&local_8f8);
  uVar7 = (**(code **)(*local_8e8 + 8))(local_8e8);
  local_908 = CONCAT44(local_908._4_4_,*puVar17);
  cVar2 = FUN_1404dc3f0(local_888,uVar7,3,*(undefined4 *)(lVar12 + 0xdc));
  if (cVar2 != '\0') {
    if (pIVar10 == (IStringManager *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar19 = *(longlong *)pIVar10;
    }
    if (lVar1 == *(longlong *)(lVar19 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    cVar2 = FUN_1404dc560(local_888,*(undefined8 *)(lVar1 + 0x20));
    if (cVar2 != '\0') {
      (**(code **)(*plVar9 + 0x350))(plVar9,local_888);
    }
  }
  plVar14 = (longlong *)CurrentInstanceGet();
  plVar14 = (longlong *)(**(code **)(*plVar14 + 0x20))(plVar14,0x11);
  if (plVar14 != (longlong *)0x0) {
    lVar19 = *plVar14;
    uVar7 = *(undefined4 *)(lVar12 + 0xdc);
    uVar11 = (**(code **)(*plVar9 + 0x18))(plVar9);
    uVar8 = (**(code **)(*local_8e8 + 8))(local_8e8);
    (**(code **)(lVar19 + 0x78))(plVar14,uVar8,uVar11,uVar7);
  }
  FUN_1404dc380(local_888);
  return;
}

// ==== CMsgInnerStengthOpt::helper_140407b10  @140407b10  [medium:callgraph-r1]  (orig: FUN_140407b10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140407b10(longlong param_1,longlong *param_2,char param_3)

{
  ushort uVar1;
  int iVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  char cVar7;
  int iVar8;
  undefined4 *puVar9;
  undefined8 uVar10;
  longlong lVar11;
  undefined8 *puVar12;
  longlong **pplVar13;
  longlong *plVar14;
  undefined8 *puVar15;
  longlong lVar16;
  undefined8 *puVar17;
  undefined1 auStack_518 [32];
  undefined4 local_4f8;
  undefined1 local_4e8 [8];
  longlong *local_4e0;
  undefined8 *local_4d8;
  longlong *local_4c8;
  undefined8 *puStack_4c0;
  longlong *local_4b8;
  undefined8 *local_4b0;
  longlong *local_4a8;
  longlong *local_4a0;
  longlong *local_498;
  undefined8 local_490;
  undefined1 local_488 [1088];
  ulonglong local_48;
  
  local_490 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_498 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_4f8 = 0x2f6;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar8 = (**(code **)(*param_2 + 8))(param_2);
    iVar2 = *(int *)(param_1 + 0xd0);
    FUN_1404dc330(local_488);
    local_4e8[0] = 1;
    puVar9 = (undefined4 *)FUN_140406b20(param_1 + 0x10,local_4e8);
    local_4f8 = *puVar9;
    cVar7 = FUN_1404dc3f0(local_488,*(undefined4 *)(param_1 + 0xd0),iVar2 != iVar8,
                          *(undefined4 *)(param_1 + 0xdc));
    if (cVar7 == '\0') {
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::SendPlayerInnerStrengthInfo create failed, idUser:%u, action:%u."
                        );
      FUN_1404dc380(local_488);
    }
    else {
      if (param_3 != '\0') {
        uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 8));
        uVar10 = FUN_1401600f0(uVar10);
        lVar11 = FUN_1401f74e0(uVar10,param_3);
        if (lVar11 == 0) {
          FUN_1404dc380(local_488);
          return;
        }
        local_4d8 = *(undefined8 **)(lVar11 + 0x38);
        puVar15 = (undefined8 *)*local_4d8;
        plVar14 = *(longlong **)(lVar11 + 8);
        local_4e0 = plVar14;
        while( true ) {
          puVar17 = local_4d8;
          lVar16 = 0;
          if (plVar14 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (puVar15 == puVar17) break;
          if (plVar14 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar16 = *plVar14;
          }
          if (puVar15 == *(undefined8 **)(lVar16 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar1 = *(ushort *)(puVar15 + 3);
          puVar17 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
          cVar7 = *(char *)((longlong)puVar17 + 0x29);
          puVar5 = *(undefined8 **)(param_1 + 0x80);
          while (cVar7 == '\0') {
            if (*(ushort *)(puVar17 + 3) < uVar1) {
              puVar12 = (undefined8 *)puVar17[2];
              puVar17 = puVar5;
            }
            else {
              puVar12 = (undefined8 *)*puVar17;
            }
            puVar5 = puVar17;
            puVar17 = puVar12;
            cVar7 = *(char *)((longlong)puVar12 + 0x29);
          }
          local_4b0 = puVar5;
          local_4b8 = *(longlong **)(param_1 + 0x50);
          puVar17 = *(undefined8 **)(param_1 + 0x80);
          if (*(longlong **)(param_1 + 0x50) == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if ((puVar5 == puVar17) || (uVar1 < *(ushort *)(puVar5 + 3))) {
            puStack_4c0 = *(undefined8 **)(param_1 + 0x80);
            local_4c8 = *(longlong **)(param_1 + 0x50);
            pplVar13 = &local_4c8;
          }
          else {
            pplVar13 = &local_4b8;
          }
          plVar3 = *pplVar13;
          local_4a8 = plVar3;
          local_4a0 = pplVar13[1];
          plVar4 = *(longlong **)(param_1 + 0x80);
          if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x50))) {
            _invalid_parameter_noinfo();
          }
          plVar6 = local_4a0;
          if (local_4a0 != plVar4) {
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar16 = 0;
            }
            else {
              lVar16 = *plVar3;
            }
            if (plVar6 == *(longlong **)(lVar16 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar6[4] != 0) {
              if (plVar3 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar16 = 0;
              }
              else {
                lVar16 = *plVar3;
              }
              if (plVar6 == *(longlong **)(lVar16 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              cVar7 = FUN_1404dc560(local_488,plVar6[4]);
              if (cVar7 == '\0') {
                log_InlineLogERROR(
                                  "CInnerStrengthPlayer::SendPlayerInnerStrengthInfo msg append failed, idUser:%u, secret type:%u."
                                  );
                FUN_1404dc380(local_488);
                return;
              }
            }
          }
          if (plVar14 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar15 + 0x1b) == '\0') {
            puVar17 = (undefined8 *)puVar15[2];
            if (*(char *)((longlong)puVar17 + 0x1b) == '\0') {
              cVar7 = *(char *)((longlong)*puVar17 + 0x1b);
              puVar15 = puVar17;
              puVar17 = (undefined8 *)*puVar17;
              while (cVar7 == '\0') {
                cVar7 = *(char *)((longlong)*puVar17 + 0x1b);
                puVar15 = puVar17;
                puVar17 = (undefined8 *)*puVar17;
              }
            }
            else {
              cVar7 = *(char *)((longlong)puVar15[1] + 0x1b);
              puVar5 = (undefined8 *)puVar15[1];
              puVar17 = puVar15;
              while ((puVar15 = puVar5, cVar7 == '\0' && (puVar17 == (undefined8 *)puVar15[2]))) {
                cVar7 = *(char *)((longlong)puVar15[1] + 0x1b);
                puVar5 = (undefined8 *)puVar15[1];
                puVar17 = puVar15;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
        }
        puVar15 = (undefined8 *)**(undefined8 **)(lVar11 + 0x38);
        plVar3 = *(longlong **)(lVar11 + 8);
        local_4c8 = plVar3;
        puStack_4c0 = puVar15;
        while( true ) {
          lVar11 = 0;
          if ((plVar3 == (longlong *)0x0) || (plVar3 != plVar14)) {
            _invalid_parameter_noinfo();
          }
          param_2 = local_498;
          if (puVar15 == puVar17) break;
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar11 = *plVar3;
          }
          if (puVar15 == *(undefined8 **)(lVar11 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar1 = *(ushort *)(puVar15 + 3);
          puVar17 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
          cVar7 = *(char *)((longlong)puVar17 + 0x29);
          puVar5 = *(undefined8 **)(param_1 + 0x80);
          while (cVar7 == '\0') {
            if (*(ushort *)(puVar17 + 3) < uVar1) {
              puVar12 = (undefined8 *)puVar17[2];
              puVar17 = puVar5;
            }
            else {
              puVar12 = (undefined8 *)*puVar17;
            }
            puVar5 = puVar17;
            puVar17 = puVar12;
            cVar7 = *(char *)((longlong)puVar12 + 0x29);
          }
          puStack_4c0 = puVar5;
          local_4c8 = *(longlong **)(param_1 + 0x50);
          puVar17 = *(undefined8 **)(param_1 + 0x80);
          if (*(longlong **)(param_1 + 0x50) == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if ((puVar5 == puVar17) || (uVar1 < *(ushort *)(puVar5 + 3))) {
            local_4b0 = *(undefined8 **)(param_1 + 0x80);
            local_4b8 = *(longlong **)(param_1 + 0x50);
            pplVar13 = &local_4b8;
          }
          else {
            pplVar13 = &local_4c8;
          }
          plVar14 = *pplVar13;
          local_4a8 = plVar14;
          local_4a0 = pplVar13[1];
          plVar4 = *(longlong **)(param_1 + 0x80);
          if ((plVar14 == (longlong *)0x0) || (plVar14 != *(longlong **)(param_1 + 0x50))) {
            _invalid_parameter_noinfo();
          }
          plVar6 = local_4a0;
          if (local_4a0 != plVar4) {
            if (plVar14 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar14;
            }
            if (plVar6 == *(longlong **)(lVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar6[4] != 0) {
              if (plVar14 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = 0;
              }
              else {
                lVar11 = *plVar14;
              }
              if (plVar6 == *(longlong **)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              cVar7 = FUN_1404dc6b0(local_488,plVar6[4]);
              if (cVar7 == '\0') {
                log_InlineLogERROR(
                                  "CInnerStrengthPlayer::SendPlayerInnerStrengthInfo msg AppendAttrib failed, idUser:%u, inner type:%u."
                                  );
                FUN_1404dc380(local_488);
                return;
              }
            }
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar15 + 0x1b) == '\0') {
            puVar5 = (undefined8 *)puVar15[2];
            puVar17 = local_4d8;
            plVar14 = local_4e0;
            if (*(char *)((longlong)puVar5 + 0x1b) == '\0') {
              cVar7 = *(char *)((longlong)*puVar5 + 0x1b);
              puVar15 = puVar5;
              puVar5 = (undefined8 *)*puVar5;
              while (cVar7 == '\0') {
                cVar7 = *(char *)((longlong)*puVar5 + 0x1b);
                puVar15 = puVar5;
                puVar5 = (undefined8 *)*puVar5;
              }
            }
            else {
              cVar7 = *(char *)((longlong)puVar15[1] + 0x1b);
              puVar12 = (undefined8 *)puVar15[1];
              puVar5 = puVar15;
              while ((puVar15 = puVar12, cVar7 == '\0' && (puVar5 == (undefined8 *)puVar15[2]))) {
                cVar7 = *(char *)((longlong)puVar15[1] + 0x1b);
                puVar12 = (undefined8 *)puVar15[1];
                puVar5 = puVar15;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
            plVar14 = local_4e0;
            puVar17 = local_4d8;
          }
        }
      }
      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_488);
      FUN_1404dc380(local_488);
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404082b0  @1404082b0  [medium:callgraph-r2]  (orig: FUN_1404082b0)
void FUN_1404082b0(longlong param_1,short param_2)

{
  undefined8 *puVar1;
  byte bVar2;
  char cVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong local_50;
  undefined8 *local_48;
  longlong local_40;
  undefined8 local_38;
  longlong local_28;
  longlong *local_20;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  lVar4 = *(longlong *)(lVar4 + 0x1d0);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = 0;
  }
  bVar2 = FUN_1401f7440(lVar4,param_2);
  puVar1 = *(undefined8 **)(param_1 + 0xc0);
  lVar4 = *(longlong *)(param_1 + 0x90);
  cVar3 = *(char *)((longlong)puVar1[1] + 0x29);
  puVar9 = puVar1;
  puVar8 = (undefined8 *)puVar1[1];
  while (cVar3 == '\0') {
    if (*(byte *)(puVar8 + 3) < bVar2) {
      puVar7 = (undefined8 *)puVar8[2];
      puVar8 = puVar9;
    }
    else {
      puVar7 = (undefined8 *)*puVar8;
    }
    puVar9 = puVar8;
    puVar8 = puVar7;
    cVar3 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_48 = puVar9;
  local_50 = lVar4;
  if (lVar4 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar9 == puVar1) || (bVar2 < *(byte *)(puVar9 + 3))) {
    local_38 = *(undefined8 *)(param_1 + 0xc0);
    local_40 = *(longlong *)(param_1 + 0x90);
    plVar5 = &local_40;
  }
  else {
    plVar5 = &local_50;
  }
  local_28 = *plVar5;
  local_20 = (longlong *)plVar5[1];
  if ((local_28 == 0) || (local_28 != lVar4)) {
    _invalid_parameter_noinfo();
  }
  if (local_20 == puVar1) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    lVar4 = *(longlong *)(lVar4 + 0x1d0);
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar4 = 0;
    }
    lVar4 = FUN_1401f74e0(lVar4,bVar2);
    if (lVar4 == 0) {
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::ProcessSecretAttribByFinish GetSecretInfo failed, inner strength:%u, secret type:%u."
                        );
    }
    else {
      puVar1 = *(undefined8 **)(lVar4 + 0x38);
      puVar9 = (undefined8 *)*puVar1;
      plVar5 = *(longlong **)(lVar4 + 8);
      while( true ) {
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar9 == puVar1) break;
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar4 = 0;
        }
        else {
          lVar4 = *plVar5;
        }
        if (puVar9 == *(undefined8 **)(lVar4 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((*(short *)(puVar9 + 3) != param_2) && (cVar3 = FUN_1404061f0(param_1), cVar3 == '\0'))
        {
          return;
        }
        if (plVar5 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar9 + 0x1b) == '\0') {
          puVar8 = (undefined8 *)puVar9[2];
          if (*(char *)((longlong)puVar8 + 0x1b) == '\0') {
            cVar3 = *(char *)((longlong)*puVar8 + 0x1b);
            puVar9 = puVar8;
            puVar8 = (undefined8 *)*puVar8;
            while (cVar3 == '\0') {
              cVar3 = *(char *)((longlong)*puVar8 + 0x1b);
              puVar9 = puVar8;
              puVar8 = (undefined8 *)*puVar8;
            }
          }
          else {
            cVar3 = *(char *)((longlong)puVar9[1] + 0x1b);
            puVar7 = (undefined8 *)puVar9[1];
            puVar8 = puVar9;
            while ((puVar9 = puVar7, cVar3 == '\0' && (puVar8 == (undefined8 *)puVar9[2]))) {
              cVar3 = *(char *)((longlong)puVar9[1] + 0x1b);
              puVar7 = (undefined8 *)puVar9[1];
              puVar8 = puVar9;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      plVar5 = (longlong *)InstanceGet();
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,"cq_inner_strength_secret");
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,1);
      (**(code **)(*plVar6 + 0xb8))(plVar6,*(undefined4 *)(param_1 + 0xd0));
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,2);
      (**(code **)(*plVar6 + 0xd8))(plVar6,bVar2);
      cVar3 = (**(code **)(*plVar5 + 0x50))(plVar5,1);
      if (cVar3 == '\0') {
        log_InlineLogERROR(
                          "CInnerStrengthPlayer::ProcessSecretAttribByFinish pRec insert failed, idUser:%u, ucSecretType:%u."
                          );
        (**(code **)*plVar5)(plVar5,1);
      }
      else {
        local_28 = CONCAT71(local_28._1_7_,bVar2);
        local_20 = plVar5;
        FUN_140156b30(param_1 + 0x90,&local_40,&local_28);
        FUN_140408110(param_1,bVar2);
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_140408e20  @140408e20  [medium:callgraph-r1]  (orig: FUN_140408e20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140408e20(longlong param_1,longlong *param_2,undefined2 param_3)

{
  longlong lVar1;
  char cVar2;
  byte bVar3;
  byte bVar4;
  ushort uVar5;
  uint uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  longlong lVar11;
  longlong lVar12;
  char *pcVar13;
  IStringManager *pIVar14;
  longlong *plVar15;
  undefined4 *puVar16;
  IStringManager *pIVar17;
  longlong lVar18;
  undefined1 auStack_908 [32];
  undefined8 local_8e8;
  uint local_8e0;
  uint local_8d8;
  byte local_8c8;
  byte local_8c7;
  undefined2 local_8c6;
  undefined2 local_8c4 [2];
  longlong local_8c0;
  IStringManager *local_8b8;
  longlong local_8b0;
  IStringManager *local_8a8 [2];
  longlong *local_898;
  undefined8 local_890;
  undefined1 local_888 [1088];
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_890 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  local_8c6 = param_3;
  local_8c4[0] = param_3;
  local_8c0 = param_1;
  local_898 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_8e8 = CONCAT44(local_8e8._4_4_,0x1e5);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar18 = 0;
    local_8b8 = (IStringManager *)0x0;
    plVar15 = (longlong *)(param_1 + 0x50);
    plVar8 = (longlong *)FUN_140405340(plVar15,local_8a8,local_8c4);
    pIVar9 = (IStringManager *)*plVar8;
    local_8b0 = plVar8[1];
    lVar12 = *(longlong *)(param_1 + 0x80);
    local_8a8[0] = (IStringManager *)*plVar15;
    local_8b8 = pIVar9;
    if ((pIVar9 == (IStringManager *)0x0) || (pIVar9 != local_8a8[0])) {
      _invalid_parameter_noinfo();
    }
    lVar1 = local_8b0;
    if (local_8b0 == lVar12) {
      pIVar9 = theInstance();
      lVar12 = param_2[2];
      uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INNER_STRENGTH_NOT_LEARN");
      (**(code **)(lVar12 + 0x358))(param_2 + 2,uVar10);
    }
    else {
      if (pIVar9 == (IStringManager *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar18;
      }
      else {
        lVar12 = *(longlong *)pIVar9;
      }
      if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      cVar2 = FUN_1404dba10(*(undefined8 *)(lVar1 + 0x20));
      if (cVar2 != '\x01') {
        if (pIVar9 == (IStringManager *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = lVar18;
        }
        else {
          lVar12 = *(longlong *)pIVar9;
        }
        if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar12 = local_8c0;
        if (*(longlong *)(lVar1 + 0x20) == 0) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CInnerStrengthPlayer::ProcessInnerStrengthFinish pointer is null, idUser:%u, type:%u."
                            );
          FUN_140406640(plVar15,local_8c4);
        }
        else {
          lVar11 = FUN_140008520(*(undefined4 *)(local_8c0 + 8));
          if (*(longlong *)(lVar11 + 0x1d0) == 0) {
            local_8e8 = CONCAT44(local_8e8._4_4_,0x15e);
            log_InlineLogERROR(&DAT_1406d9c10);
            lVar11 = lVar18;
          }
          else {
            lVar11 = *(longlong *)(lVar11 + 0x1d0);
          }
          uVar6 = FUN_1401f6460(lVar11,param_3);
          if (uVar6 == 0xffffffff) {
            (**(code **)(*param_2 + 8))(param_2);
            log_InlineLogERROR(
                              "CInnerStrengthPlayer::ProcessInnerStrengthFinish max lev is fault, idUser:%u, type:%u."
                              );
          }
          else {
            if (pIVar9 == (IStringManager *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = lVar18;
            }
            else {
              lVar11 = *(longlong *)pIVar9;
            }
            if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            bVar3 = FUN_1404db5c0(*(undefined8 *)(lVar1 + 0x20));
            if (uVar6 < bVar3) {
              if (pIVar9 == (IStringManager *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                lVar18 = *(longlong *)pIVar9;
              }
              if (lVar1 == *(longlong *)(lVar18 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              FUN_1404db5c0(*(undefined8 *)(lVar1 + 0x20));
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "CInnerStrengthPlayer::ProcessInnerStrengthFinish user lev exceeds max lev, idUser:%u, type:%u, lev:%u."
                                );
            }
            else {
              if (pIVar9 == (IStringManager *)0x0) {
                _invalid_parameter_noinfo();
                lVar11 = lVar18;
              }
              else {
                lVar11 = *(longlong *)pIVar9;
              }
              if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              bVar3 = FUN_1404db5c0(*(undefined8 *)(lVar1 + 0x20));
              if (uVar6 <= bVar3) {
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar11 = lVar18;
                }
                else {
                  lVar11 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                local_8c7 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar11 = lVar18;
                }
                else {
                  lVar11 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                bVar3 = FUN_1404db810(*(undefined8 *)(lVar1 + 0x20));
                local_8c8 = bVar3;
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar11 = lVar18;
                }
                else {
                  lVar11 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                FUN_1404db970(*(undefined8 *)(lVar1 + 0x20),bVar3);
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar11 = lVar18;
                }
                else {
                  lVar11 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar11 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                FUN_1404dba70(*(undefined8 *)(lVar1 + 0x20),1);
                if ((local_8c7 == 0) && (bVar3 != 0)) {
                  FUN_1404082b0(lVar12,param_3);
                }
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar12 = lVar18;
                }
                else {
                  lVar12 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                if (pIVar9 == (IStringManager *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar12 = lVar18;
                }
                else {
                  lVar12 = *(longlong *)pIVar9;
                }
                if (lVar1 == *(longlong *)(lVar12 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                pIVar14 = (IStringManager *)(param_2 + 2);
                local_8a8[0] = pIVar14;
                bVar4 = FUN_1404db910(*(undefined8 *)(lVar1 + 0x20));
                bVar3 = local_8c7;
                uVar5 = FUN_1404db500(*(undefined8 *)(lVar1 + 0x20));
                (**(code **)(*(longlong *)pIVar14 + 0x18))(pIVar14);
                (**(code **)(*local_898 + 8))();
                local_8d8 = (uint)bVar4;
                local_8e0 = (uint)bVar3;
                local_8e8._0_4_ = (uint)uVar5;
                tq::MyLogSave("gmlog/inner_strength",
                              "InnerStrength finish, Uesr:%u, %s; type:%u; value old:%u, new:%u;");
                local_448 = '\0';
                memset(local_447,0,0x3ff);
                bVar3 = local_8c8;
                if (local_8c8 < 0x5a) {
                  local_8b8 = theInstance();
                  lVar12 = FUN_140008520(*(undefined4 *)(local_8c0 + 8));
                  if (*(longlong *)(lVar12 + 0x1d0) == 0) {
                    local_8e8._0_4_ = 0x15e;
                    log_InlineLogERROR(&DAT_1406d9c10);
                    lVar12 = lVar18;
                  }
                  else {
                    lVar12 = *(longlong *)(lVar12 + 0x1d0);
                  }
                  uVar10 = FUN_1401f63c0(lVar12,local_8c6);
                  pIVar17 = local_8a8[0];
                  (**(code **)(*(longlong *)local_8a8[0] + 0x18))(local_8a8[0]);
                  pcVar13 = (char *)(*(code *)**(undefined8 **)local_8b8)
                                              (local_8b8,"STR_INNER_STRENGTH_FINISH_SUCCESS1");
                  local_8e0 = (uint)bVar3;
                  local_8e8 = uVar10;
                  _snprintf(&local_448,0x400,pcVar13);
                }
                else if (local_8c8 < 100) {
                  local_8b8 = theInstance();
                  lVar12 = FUN_140008520(*(undefined4 *)(local_8c0 + 8));
                  if (*(longlong *)(lVar12 + 0x1d0) == 0) {
                    local_8e8._0_4_ = 0x15e;
                    log_InlineLogERROR(&DAT_1406d9c10);
                    lVar12 = lVar18;
                  }
                  else {
                    lVar12 = *(longlong *)(lVar12 + 0x1d0);
                  }
                  uVar10 = FUN_1401f63c0(lVar12,local_8c6);
                  pIVar17 = local_8a8[0];
                  (**(code **)(*(longlong *)local_8a8[0] + 0x18))(local_8a8[0]);
                  pcVar13 = (char *)(*(code *)**(undefined8 **)local_8b8)
                                              (local_8b8,"STR_INNER_STRENGTH_FINISH_SUCCESS2");
                  local_8e0 = (uint)bVar3;
                  local_8e8 = uVar10;
                  _snprintf(&local_448,0x400,pcVar13);
                }
                else {
                  pIVar14 = theInstance();
                  lVar12 = FUN_140008520(*(undefined4 *)(local_8c0 + 8));
                  if (*(longlong *)(lVar12 + 0x1d0) == 0) {
                    local_8e8._0_4_ = 0x15e;
                    log_InlineLogERROR(&DAT_1406d9c10);
                    lVar12 = lVar18;
                  }
                  else {
                    lVar12 = *(longlong *)(lVar12 + 0x1d0);
                  }
                  uVar10 = FUN_1401f63c0(lVar12,local_8c6);
                  pIVar17 = local_8a8[0];
                  (**(code **)(*(longlong *)local_8a8[0] + 0x18))(local_8a8[0]);
                  pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar14)
                                              (pIVar14,"STR_INNER_STRENGTH_FINISH_SUCCESS_MAX");
                  local_8e8 = uVar10;
                  _snprintf(&local_448,0x400,pcVar13);
                }
                lVar12 = local_8c0;
                local_49 = 0;
                plVar15 = (longlong *)FUN_140008520(*(undefined4 *)(local_8c0 + 8));
                local_8e0 = 0x7eb;
                local_8e8._0_4_ = 0xff0000;
                (**(code **)(*plVar15 + 0x60))(plVar15,&local_448,0xffffffff,0);
                FUN_1404dc330(local_888);
                local_8c8 = 1;
                puVar16 = (undefined4 *)FUN_140406b20(lVar12 + 0x10,&local_8c8);
                uVar7 = (**(code **)(*local_898 + 8))(local_898);
                local_8e8 = CONCAT44(local_8e8._4_4_,*puVar16);
                cVar2 = FUN_1404dc3f0(local_888,uVar7,2,*(undefined4 *)(lVar12 + 0xdc));
                if (cVar2 != '\0') {
                  if (pIVar9 == (IStringManager *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar18 = *(longlong *)pIVar9;
                  }
                  if (lVar1 == *(longlong *)(lVar18 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  cVar2 = FUN_1404dc560(local_888,*(undefined8 *)(lVar1 + 0x20));
                  if (cVar2 != '\0') {
                    (**(code **)(*(longlong *)pIVar17 + 0x350))(pIVar17,local_888);
                  }
                }
                FUN_1404dc380(local_888);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404095b0  @1404095b0  [medium:callgraph-r1]  (orig: FUN_1404095b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_1404095b0(longlong param_1,longlong *param_2,uint param_3,char param_4)

{
  longlong ****pppplVar1;
  longlong **pplVar2;
  double dVar3;
  longlong **pplVar4;
  char cVar5;
  byte bVar6;
  byte bVar7;
  int iVar8;
  int iVar9;
  ulong uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  longlong lVar16;
  longlong lVar17;
  longlong ****pppplVar18;
  undefined8 uVar19;
  int *piVar20;
  undefined4 *puVar21;
  longlong *plVar22;
  longlong lVar23;
  longlong *****ppppplVar24;
  longlong **pplVar25;
  longlong ****pppplVar26;
  longlong ***ppplVar27;
  longlong ****pppplVar28;
  longlong ***ppplVar29;
  longlong **pplVar30;
  int iVar31;
  ulonglong uVar32;
  longlong ***ppplVar33;
  int iVar34;
  longlong *plVar35;
  int iVar36;
  double dVar37;
  double dVar38;
  undefined1 auStack_698 [32];
  uint local_678;
  byte local_668;
  byte local_667;
  uint local_664;
  uint local_660;
  int local_65c;
  longlong ****local_658;
  longlong ****local_650;
  longlong local_648;
  longlong *local_640;
  uint local_638;
  int local_634;
  longlong local_630;
  longlong ****local_628;
  longlong ****local_620;
  uint local_618;
  uint local_614;
  longlong ****local_610;
  longlong ****local_608;
  longlong ****local_600;
  longlong ****local_5f8;
  longlong ***local_5f0;
  longlong **local_5e8;
  longlong ***local_5e0;
  longlong **local_5d8;
  longlong ***local_5d0;
  longlong **local_5c8;
  undefined8 local_5c0;
  undefined2 local_5b8;
  undefined1 local_5b6;
  undefined4 local_5b4;
  uint local_5b0;
  uint local_5ac;
  uint local_5a8;
  uint local_5a4;
  undefined1 local_5a0 [128];
  longlong ***local_520 [6];
  longlong **local_4f0;
  longlong ****local_4e0 [6];
  longlong ****local_4b0;
  undefined1 local_498 [1088];
  ulonglong local_58;
  
  local_5c0 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_698;
  if (param_2 != (longlong *)0x0) {
    local_664 = param_3;
    local_640 = param_2;
    local_630 = param_1;
    lVar16 = FUN_1404060b0();
    local_648 = lVar16;
    if (lVar16 == 0) {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR(
                        "CInnerStrengthPlayer::ProcessExercise cannot find the type, idUser:%u, type:%d."
                        );
    }
    else {
      FUN_1401eb7e0(local_520);
      FUN_1401fbb60(local_4e0);
      local_5b8 = 0;
      local_5b6 = 0;
      local_5b4 = 0;
      local_5b0 = 0xffffffff;
      local_5ac = 10;
      local_5a8 = 10;
      local_5a4 = 10;
      memset(local_5a0,0,0x80);
      lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      lVar23 = *(longlong *)(lVar17 + 0x1d0);
      if (*(longlong *)(lVar17 + 0x1d0) == 0) {
        local_678 = 0x15e;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar23 = 0;
      }
      cVar5 = FUN_1401fc020(lVar23,param_3 & 0xffff,&local_5b8);
      if (cVar5 == '\0') {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR(
                          "CInnerStrengthPlayer::ProcessExercise cannot find the type attr, idUser:%u, type:%d."
                          );
        local_658 = (longlong ****)local_4e0;
        FUN_1401fb6f0(local_4e0);
        operator_delete(local_4e0[0]);
        local_658 = local_520;
        FUN_1401e0500(local_520);
        operator_delete(local_520[0]);
      }
      else {
        local_660 = local_5b0;
        if (local_5b0 == 0xffffffff) {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR(
                            "CInnerStrengthPlayer::ProcessExercise max lev is fault, idUser:%u, type:%u."
                            );
          local_658 = (longlong ****)local_4e0;
          FUN_1401fb6f0(local_4e0);
          operator_delete(local_4e0[0]);
          local_658 = local_520;
          FUN_1401e0500(local_520);
          operator_delete(local_520[0]);
        }
        else {
          cVar5 = FUN_1404dbbb0(lVar16);
          local_638 = local_5ac;
          if ((cVar5 != '\0') && (local_638 = local_5a4, cVar5 == '\x01')) {
            local_638 = local_5a8;
          }
          if (local_638 - 10 < 0xb) {
            bVar6 = FUN_1404db5c0(lVar16);
            uVar12 = local_660;
            if (bVar6 < local_660) {
              bVar7 = FUN_1404db910(lVar16);
              local_614 = (uint)bVar7;
              if (local_614 < 100) {
                iVar36 = 1;
                if (param_4 != '\0') {
                  iVar36 = uVar12 - bVar6;
                }
                iVar8 = FUN_140166ab0(param_2);
                iVar34 = 0;
                local_65c = 0;
                iVar31 = 0;
                pppplVar26 = local_4b0;
                if (0 < iVar36) {
                  do {
                    uVar11 = local_664;
                    if (uVar12 <= iVar31 + (uint)bVar6) break;
                    bVar7 = (char)iVar31 + bVar6;
                    cVar5 = *(char *)((longlong)pppplVar26[1] + 0x69);
                    pppplVar18 = (longlong ****)pppplVar26[1];
                    pppplVar1 = pppplVar26;
                    while (pppplVar28 = pppplVar18, cVar5 == '\0') {
                      if (*(byte *)(pppplVar28 + 3) < bVar7) {
                        pppplVar18 = (longlong ****)pppplVar28[2];
                        pppplVar28 = pppplVar1;
                      }
                      else {
                        pppplVar18 = (longlong ****)*pppplVar28;
                      }
                      cVar5 = *(char *)((longlong)pppplVar18 + 0x69);
                      pppplVar1 = pppplVar28;
                    }
                    local_620 = pppplVar1;
                    local_628 = local_4e0[0];
                    pppplVar18 = pppplVar26;
                    if (local_4e0[0] == (longlong ****)0x0) {
                      _invalid_parameter_noinfo();
                      pppplVar18 = local_4b0;
                    }
                    if ((pppplVar1 == pppplVar26) || (bVar7 < *(byte *)(pppplVar1 + 3))) {
                      local_650 = pppplVar18;
                      local_658 = local_4e0[0];
                      ppppplVar24 = &local_658;
                    }
                    else {
                      ppppplVar24 = &local_628;
                    }
                    pppplVar1 = *ppppplVar24;
                    local_610 = pppplVar1;
                    local_608 = ppppplVar24[1];
                    if ((pppplVar1 == (longlong ****)0x0) ||
                       (pppplVar26 = pppplVar18, pppplVar1 != local_4e0[0])) {
                      _invalid_parameter_noinfo();
                      pppplVar26 = local_4b0;
                    }
                    pppplVar28 = local_608;
                    uVar11 = local_664;
                    if (local_608 == pppplVar18) {
                      log_InlineLogERROR(
                                        "CInnerStrengthPlayer::ProcessExercise type and lev is fault, type:%u, level:%u "
                                        );
                      uVar12 = local_660;
                      break;
                    }
                    if (pppplVar1 == (longlong ****)0x0) {
                      _invalid_parameter_noinfo();
                      ppplVar33 = (longlong ***)0x0;
                      pppplVar26 = local_4b0;
                    }
                    else {
                      ppplVar33 = *pppplVar1;
                    }
                    if (pppplVar28 == (longlong ****)ppplVar33[6]) {
                      _invalid_parameter_noinfo();
                      pppplVar26 = local_4b0;
                    }
                    iVar9 = *(int *)((longlong)pppplVar28 + 0x24);
                    if (iVar9 < 1) {
                      log_InlineLogERROR("CInnerStrengthMgr::ProcessExercise culture cost error.");
                      uVar12 = local_660;
                      uVar11 = local_664;
                      break;
                    }
                    iVar9 = iVar9 + iVar34;
                    uVar12 = local_660;
                    uVar11 = local_664;
                    if (iVar8 < iVar9) break;
                    local_65c = local_65c + 1;
                    iVar31 = iVar31 + 1;
                    iVar34 = iVar9;
                  } while (iVar31 < iVar36);
                  plVar35 = local_640;
                  iVar36 = local_65c;
                  if ((0 < local_65c) && (0 < iVar34)) {
                    cVar5 = FUN_140166ac0(local_640,(longlong)-iVar34,1);
                    dVar3 = _DAT_1406f9568;
                    if (cVar5 == '\0') {
                      local_658 = (longlong ****)local_4e0;
                      FUN_1401fb6f0(local_4e0);
                      operator_delete(local_4e0[0]);
                      local_658 = local_520;
                      FUN_1401e0500(local_520);
                      operator_delete(local_520[0]);
                      return 0;
                    }
                    local_634 = 0;
                    lVar16 = local_648;
                    if (0 < iVar36) {
                      do {
                        bVar6 = FUN_1404db5c0(lVar16);
                        pppplVar26 = local_4b0;
                        local_618 = (uint)bVar6;
                        plVar35 = local_640;
                        if (uVar12 <= local_618) break;
                        cVar5 = *(char *)((longlong)local_4b0[1] + 0x69);
                        pppplVar18 = (longlong ****)local_4b0[1];
                        pppplVar1 = local_4b0;
                        while (pppplVar28 = pppplVar18, cVar5 == '\0') {
                          if (*(byte *)(pppplVar28 + 3) < bVar6) {
                            pppplVar18 = (longlong ****)pppplVar28[2];
                            pppplVar28 = pppplVar1;
                          }
                          else {
                            pppplVar18 = (longlong ****)*pppplVar28;
                          }
                          cVar5 = *(char *)((longlong)pppplVar18 + 0x69);
                          pppplVar1 = pppplVar28;
                        }
                        local_608 = pppplVar1;
                        local_610 = local_4e0[0];
                        if (local_4e0[0] == (longlong ****)0x0) {
                          _invalid_parameter_noinfo();
                        }
                        pppplVar18 = local_4b0;
                        if ((pppplVar1 == pppplVar26) || (bVar6 < *(byte *)(pppplVar1 + 3))) {
                          local_5f8 = local_4b0;
                          local_600 = local_4e0[0];
                          pppplVar26 = (longlong ****)&local_600;
                        }
                        else {
                          pppplVar26 = (longlong ****)&local_610;
                        }
                        pppplVar1 = (longlong ****)*pppplVar26;
                        local_628 = pppplVar1;
                        local_620 = (longlong ****)pppplVar26[1];
                        if ((pppplVar1 == (longlong ****)0x0) || (pppplVar1 != local_4e0[0])) {
                          _invalid_parameter_noinfo();
                        }
                        pppplVar26 = local_620;
                        if (local_620 == pppplVar18) {
                          log_InlineLogERROR(
                                            "CInnerStrengthPlayer::ProcessExercise type and lev is fault, type:%u, level:%u "
                                            );
                          plVar35 = local_640;
                          break;
                        }
                        if (pppplVar1 == (longlong ****)0x0) {
                          _invalid_parameter_noinfo();
                          ppplVar33 = (longlong ***)0x0;
                        }
                        else {
                          ppplVar33 = *pppplVar1;
                        }
                        if (pppplVar26 == (longlong ****)ppplVar33[6]) {
                          _invalid_parameter_noinfo();
                        }
                        uVar10 = tq::TimeGet(0);
                        iVar36 = rand();
                        srand(iVar36 + uVar10);
                        iVar36 = tq::RandGet(100000);
                        uVar19 = FUN_140008520(*(undefined4 *)(local_630 + 8));
                        uVar19 = FUN_1401600f0(uVar19);
                        local_667 = FUN_1401f1e10(uVar19,local_638 & 0xff,iVar36 + 1);
                        if (local_667 == 0) {
                          log_InlineLogERROR(
                                            "CInnerStrengthPlayer::ProcessExercise cannot find FATE_NO, type:%u"
                                            );
                          plVar35 = local_640;
                          break;
                        }
                        ppplVar33 = (longlong ***)*pppplVar26[0xb];
                        pppplVar18 = (longlong ****)pppplVar26[5];
                        local_658 = pppplVar18;
                        while( true ) {
                          bVar6 = local_667;
                          ppplVar27 = pppplVar26[0xb];
                          if ((pppplVar18 == (longlong ****)0x0) ||
                             (pppplVar18 != (longlong ****)pppplVar26[5])) {
                            _invalid_parameter_noinfo();
                          }
                          uVar11 = local_664;
                          if (ppplVar33 == ppplVar27) goto LAB_140409ff5;
                          if (pppplVar18 == (longlong ****)0x0) {
                            _invalid_parameter_noinfo();
                            ppplVar27 = (longlong ***)0x0;
                          }
                          else {
                            ppplVar27 = *pppplVar18;
                          }
                          ppplVar29 = (longlong ***)0x0;
                          if (ppplVar33 == (longlong ***)ppplVar27[6]) {
                            _invalid_parameter_noinfo();
                          }
                          bVar7 = *(byte *)(ppplVar33 + 3);
                          if (pppplVar18 == (longlong ****)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          else {
                            ppplVar29 = *pppplVar18;
                          }
                          if (ppplVar33 == (longlong ***)ppplVar29[6]) {
                            _invalid_parameter_noinfo();
                          }
                          iVar36 = *(int *)((longlong)ppplVar33 + 0x1c);
                          if (iVar36 == 0) {
                            log_InlineLogERROR(
                                              "CInnerStrengthPlayer::ProcessExercise Attr is zero, type:%u"
                                              );
                            uVar11 = local_664;
                            goto LAB_140409ff5;
                          }
                          uVar12 = (iVar36 * local_614) / 100;
                          dVar38 = (double)((uint)bVar6 * (iVar36 - uVar12)) +
                                   (double)(uVar12 * 100);
                          dVar37 = (double)(uint)(iVar36 * 100);
                          if (dVar38 <= (double)(uint)(iVar36 * 100)) {
                            dVar37 = dVar38;
                          }
                          dVar37 = ceil(dVar37 / dVar3);
                          iVar36 = FUN_1404db6c0(lVar16,bVar7 + 7);
                          pplVar4 = local_4f0;
                          cVar5 = *(char *)((longlong)local_4f0[1] + 0x21);
                          pplVar25 = (longlong **)local_4f0[1];
                          pplVar2 = local_4f0;
                          while (pplVar30 = pplVar25, cVar5 == '\0') {
                            if (*(byte *)(pplVar30 + 3) < bVar7) {
                              pplVar25 = (longlong **)pplVar30[2];
                              pplVar30 = pplVar2;
                            }
                            else {
                              pplVar25 = (longlong **)*pplVar30;
                            }
                            cVar5 = *(char *)((longlong)pplVar25 + 0x21);
                            pplVar2 = pplVar30;
                          }
                          local_5c8 = pplVar2;
                          local_5d0 = local_520[0];
                          if (local_520[0] == (longlong ***)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          pplVar25 = local_4f0;
                          if ((pplVar2 == pplVar4) || (bVar7 < *(byte *)(pplVar2 + 3))) {
                            local_5e8 = local_4f0;
                            local_5f0 = local_520[0];
                            ppplVar27 = (longlong ***)&local_5f0;
                          }
                          else {
                            ppplVar27 = (longlong ***)&local_5d0;
                          }
                          ppplVar29 = (longlong ***)*ppplVar27;
                          local_5e0 = ppplVar29;
                          local_5d8 = ppplVar27[1];
                          if ((ppplVar29 == (longlong ***)0x0) || (ppplVar29 != local_520[0])) {
                            _invalid_parameter_noinfo();
                          }
                          pplVar2 = local_5d8;
                          uVar11 = local_664;
                          if (local_5d8 == pplVar25) break;
                          if (ppplVar29 == (longlong ***)0x0) {
                            _invalid_parameter_noinfo();
                            pplVar25 = (longlong **)0x0;
                          }
                          else {
                            pplVar25 = *ppplVar29;
                          }
                          if (pplVar2 == (longlong **)pplVar25[6]) {
                            _invalid_parameter_noinfo();
                          }
                          uVar12 = *(uint *)((longlong)pplVar2 + 0x1c);
                          uVar11 = iVar36 + (int)(longlong)dVar37;
                          if (uVar11 < uVar12) {
                            uVar12 = uVar11;
                          }
                          FUN_1404db730(local_648,bVar7 + 7,uVar12,0);
                          local_668 = bVar7;
                          piVar20 = (int *)FUN_140406b20(local_630 + 0x10,&local_668);
                          pppplVar18 = local_658;
                          *piVar20 = *piVar20 + (uVar12 - iVar36);
                          if (local_658 == (longlong ****)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          if (*(char *)((longlong)ppplVar33 + 0x21) == '\0') {
                            ppplVar27 = (longlong ***)ppplVar33[2];
                            pppplVar26 = local_620;
                            lVar16 = local_648;
                            if (*(char *)((longlong)ppplVar27 + 0x21) == '\0') {
                              cVar5 = *(char *)((longlong)*ppplVar27 + 0x21);
                              ppplVar33 = ppplVar27;
                              ppplVar27 = (longlong ***)*ppplVar27;
                              while (cVar5 == '\0') {
                                cVar5 = *(char *)((longlong)*ppplVar27 + 0x21);
                                ppplVar33 = ppplVar27;
                                ppplVar27 = (longlong ***)*ppplVar27;
                              }
                            }
                            else {
                              cVar5 = *(char *)((longlong)ppplVar33[1] + 0x21);
                              ppplVar29 = (longlong ***)ppplVar33[1];
                              ppplVar27 = ppplVar33;
                              while ((ppplVar33 = ppplVar29, cVar5 == '\0' &&
                                     (ppplVar27 == (longlong ***)ppplVar33[2]))) {
                                cVar5 = *(char *)((longlong)ppplVar33[1] + 0x21);
                                ppplVar29 = (longlong ***)ppplVar33[1];
                                ppplVar27 = ppplVar33;
                              }
                            }
                          }
                          else {
                            _invalid_parameter_noinfo();
                            pppplVar26 = local_620;
                            lVar16 = local_648;
                          }
                        }
                        log_InlineLogERROR(
                                          "CInnerStrengthPlayer::ProcessExercise stAttr.m_mapAttribTypeValue can\'t find type:%u, Attr:%u "
                                          );
                        lVar16 = local_648;
LAB_140409ff5:
                        FUN_1404db620(lVar16,(char)local_618 + '\x01');
                        local_634 = local_634 + 1;
                        plVar35 = local_640;
                        uVar12 = local_660;
                      } while (local_634 < local_65c);
                    }
                    uVar32 = 0;
                    iVar36 = 8;
                    do {
                      if ((char)uVar32 != '\0') break;
                      uVar12 = FUN_1404db6c0(lVar16,iVar36);
                      if (uVar12 != 0) {
                        uVar19 = FUN_140008520(*(undefined4 *)(local_630 + 8));
                        uVar19 = FUN_1401600f0(uVar19);
                        uVar13 = FUN_1401f7c00(uVar19,uVar11 & 0xffff,iVar36 + -7);
                        if (uVar13 != 0) {
                          dVar37 = ceil(((double)uVar12 * dVar3) / (double)uVar13);
                          uVar32 = (ulonglong)dVar37;
                          if (100 < (byte)uVar32) {
                            (**(code **)(*plVar35 + 8))(plVar35);
                            local_678 = uVar13;
                            log_InlineLogERROR(
                                              "CInnerStrengthPlayer::ProcessExercise inner strength value over max, idUser:%u, attrib power:%u, type:%u, power:%u."
                                              );
                            uVar32 = 0;
                            break;
                          }
                        }
                      }
                      iVar36 = iVar36 + 1;
                    } while (iVar36 < 0x16);
                    bVar6 = FUN_1404db810(lVar16);
                    FUN_1404db870(lVar16,uVar32 & 0xff);
                    lVar23 = local_630;
                    *(int *)(local_630 + 0xdc) =
                         *(int *)(local_630 + 0xdc) + (((uint)uVar32 & 0xff) - (uint)bVar6);
                    FUN_1404db560(lVar16);
                    FUN_1404dc330(local_498);
                    local_668 = 1;
                    puVar21 = (undefined4 *)FUN_140406b20(lVar23 + 0x10,&local_668);
                    uVar14 = (**(code **)(*plVar35 + 8))(plVar35);
                    local_678 = *puVar21;
                    cVar5 = FUN_1404dc3f0(local_498,uVar14,4,*(undefined4 *)(lVar23 + 0xdc));
                    if (cVar5 == '\0') {
                      (**(code **)(*plVar35 + 8))(plVar35);
                      log_InlineLogERROR(
                                        "CInnerStrengthPlayer::ProcessExercise CMsgInnerStengthInfo create failed, idUser:%u, type:%u"
                                        );
                    }
                    else {
                      cVar5 = FUN_1404dc560(local_498,lVar16);
                      if ((cVar5 != '\0') &&
                         (cVar5 = FUN_1404dc6b0(local_498,lVar16), cVar5 != '\0')) {
                        (**(code **)(plVar35[2] + 0x350))(plVar35 + 2,local_498);
                      }
                    }
                    plVar22 = (longlong *)CurrentInstanceGet();
                    plVar22 = (longlong *)(**(code **)(*plVar22 + 0x20))(plVar22,0x11);
                    if (plVar22 != (longlong *)0x0) {
                      lVar16 = *plVar22;
                      uVar14 = *(undefined4 *)(lVar23 + 0xdc);
                      uVar19 = (**(code **)(plVar35[2] + 0x18))();
                      uVar15 = (**(code **)(*plVar35 + 8))(plVar35);
                      (**(code **)(lVar16 + 0x78))(plVar22,uVar15,uVar19,uVar14);
                    }
                    FUN_1404dc380(local_498);
                    local_658 = (longlong ****)local_4e0;
                    FUN_1401fb6f0(local_4e0);
                    operator_delete(local_4e0[0]);
                    local_658 = local_520;
                    FUN_1401e0500(local_520);
                    operator_delete(local_520[0]);
                    return 1;
                  }
                }
                local_658 = (longlong ****)local_4e0;
                FUN_1401fb6f0(local_4e0);
                operator_delete(local_4e0[0]);
                local_658 = local_520;
                FUN_1401e0500(local_520);
                operator_delete(local_520[0]);
              }
              else {
                local_658 = (longlong ****)local_4e0;
                FUN_1401fb6f0(local_4e0);
                operator_delete(local_4e0[0]);
                local_658 = local_520;
                FUN_1401e0500(local_520);
                operator_delete(local_520[0]);
              }
            }
            else {
              local_658 = (longlong ****)local_4e0;
              FUN_1401fb6f0(local_4e0);
              operator_delete(local_4e0[0]);
              local_658 = local_520;
              FUN_1401e0500(local_520);
              operator_delete(local_520[0]);
            }
          }
          else {
            log_InlineLogERROR("CInnerStrengthPlayer::ProcessExercise Error FATE_NO, type:%u");
            local_658 = (longlong ****)local_4e0;
            FUN_1401fb6f0(local_4e0);
            operator_delete(local_4e0[0]);
            local_658 = local_520;
            FUN_1401e0500(local_520);
            operator_delete(local_520[0]);
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgInnerStengthOpt::helper_14040a3c0  @14040a3c0  [medium:callgraph-r2]  (orig: FUN_14040a3c0)
void FUN_14040a3c0(longlong param_1,char *param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar1;
  
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
  if (*(longlong *)(param_1 + 0x38) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar1 = 0;
    }
    else {
      uVar1 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x38) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040a421. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::assign
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x38),
             param_2);
  return;
}

// ==== CMsgInnerStengthOpt::helper_14040a4c0  @14040a4c0  [medium:callgraph-r1]  (orig: FUN_14040a4c0)
undefined1 FUN_14040a4c0(longlong param_1,undefined4 param_2,longlong param_3)

{
  if (param_3 == 0) {
    return 0;
  }
  FUN_1402b5600();
  *(uint *)(param_1 + 0x458) = *(uint *)(param_1 + 0x458) | 1;
  *(undefined4 *)(param_1 + 0x468) = param_2;
  FUN_14040a3c0(param_1 + 0x428,param_3);
  *(undefined4 *)(param_1 + 8) = 0xa35;
  return 1;
}

// ==== CMsgInnerStengthOpt::helper_14040a530  @14040a530  [medium:callgraph-r1]  (orig: FUN_14040a530)
undefined8 FUN_14040a530(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 uVar4;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  cVar1 = FUN_1405551c0(param_1 + 0x428,param_1 + 0x10,0x400,param_4,0xfffffffffffffffe);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x20))(param_1 + 0x428);
    if (cVar1 == '\0') {
      lVar3 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x28))(param_1 + 0x428,local_30);
      if (*(ulonglong *)(lVar3 + 0x20) < 0x10) {
        lVar3 = lVar3 + 8;
      }
      else {
        lVar3 = *(longlong *)(lVar3 + 8);
      }
      log_InlineLogERROR(&DAT_1407711a0,lVar3);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_30);
    }
    else {
      log_InlineLogERROR("CMsgExchangeInnerStrength::Serialize SerializeToArray failed.");
    }
    uVar4 = 0;
  }
  else {
    uVar2 = (**(code **)(*(longlong *)(param_1 + 0x428) + 0x40))(param_1 + 0x428);
    *(undefined4 *)(param_1 + 0xc) = uVar2;
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMsgInnerStengthOpt::ctor_or_dtor  @14040a650  [high:vtable-assign]  (orig: FUN_14040a650)
undefined8 * FUN_14040a650(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInnerStengthOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgInnerStengthOpt::ctor_or_dtor  @14040a6a0  [high:vtable-assign]  (orig: FUN_14040a6a0)
void FUN_14040a6a0(undefined8 *param_1)

{
  *param_1 = CMsgInnerStengthOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgInnerStengthOpt::vfunc_5  @14040a6d0  [high:rtti-vtable]  (orig: FUN_14040a6d0)
bool FUN_14040a6d0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa32;
    }
  }
  return false;
}

// ==== CMsgInnerStengthOpt::helper_14040a710  @14040a710  [medium:callgraph-r1]  (orig: FUN_14040a710)
ulonglong FUN_14040a710(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 1) = param_3;
  *(undefined4 *)(param_1 + 0xc) = 9;
  *(undefined4 *)(param_1 + 8) = 0xa32;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgInnerStengthOpt::ctor_or_dtor  @14040a780  [high:vtable-assign]  (orig: FUN_14040a780)
undefined8 * FUN_14040a780(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInnerStengthOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgInnerStengthOpt::vfunc_3  @14040a7d0  [high:rtti-vtable]  (orig: FUN_14040a7d0)
void FUN_14040a7d0(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x88))(plVar3,param_1);
    if (((lVar4 != 0) &&
        (cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(), cVar1 != '\0')) &&
       ((cVar1 = FUN_140167b70(lVar4), cVar1 == '\0' ||
        ((**(char **)(param_1 + 0x428) == '\0' || (**(char **)(param_1 + 0x428) == '\x05')))))) {
      switch(**(undefined1 **)(param_1 + 0x428)) {
      case 0:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f7300(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1),
                      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 5));
        break;
      case 1:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f6e70(uVar2,lVar4,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 2:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f7010(uVar2,lVar4,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 3:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f7580(uVar2,lVar4,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 1),
                      *(int *)(*(longlong *)(param_1 + 0x428) + 5) != 0);
        break;
      case 4:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f1cc0(uVar2,lVar4,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 5:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f71c0(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 6:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f7f00(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 7:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f88b0(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        break;
      case 8:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1d0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar5 + 0x1d0);
        }
        FUN_1401f2ee0(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
      }
    }
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404db560  @1404db560  [medium:callgraph-r2]  (orig: FUN_1404db560)
void FUN_1404db560(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(char *)(param_1 + 0x10) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404db5c0  @1404db5c0  [medium:callgraph-r2]  (orig: FUN_1404db5c0)
ulonglong FUN_1404db5c0(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
                    /* WARNING: Could not recover jumptable at 0x0001404db615. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404db620  @1404db620  [medium:callgraph-r2]  (orig: FUN_1404db620)
void FUN_1404db620(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (*(longlong *)(param_1 + 8) != 0) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
      }
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404db6c0  @1404db6c0  [medium:callgraph-r2]  (orig: FUN_1404db6c0)
undefined8 FUN_1404db6c0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (0xd < param_2 - 8U) {
    log_InlineLogERROR("CInnerStrengthData::GetAttribPower unIndex error, index:%u.");
    return 0;
  }
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 8) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001404db718. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404db870  @1404db870  [medium:callgraph-r2]  (orig: FUN_1404db870)
void FUN_1404db870(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (*(longlong *)(param_1 + 8) != 0) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
      }
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404db910  @1404db910  [medium:callgraph-r2]  (orig: FUN_1404db910)
ulonglong FUN_1404db910(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
                    /* WARNING: Could not recover jumptable at 0x0001404db965. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404db970  @1404db970  [medium:callgraph-r2]  (orig: FUN_1404db970)
void FUN_1404db970(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (*(longlong *)(param_1 + 8) != 0) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
      }
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404dba10  @1404dba10  [medium:callgraph-r2]  (orig: FUN_1404dba10)
ulonglong FUN_1404dba10(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
                    /* WARNING: Could not recover jumptable at 0x0001404dba65. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404dba70  @1404dba70  [medium:callgraph-r2]  (orig: FUN_1404dba70)
void FUN_1404dba70(longlong param_1,undefined1 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
    (**(code **)(*plVar1 + 0xd8))(plVar1,param_2);
    if (*(longlong *)(param_1 + 8) != 0) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
      }
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404dbb10  @1404dbb10  [medium:callgraph-r2]  (orig: FUN_1404dbb10)
void FUN_1404dbb10(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),1);
    (**(code **)(*plVar1 + 0xb8))(plVar1,param_2);
    if (*(longlong *)(param_1 + 8) != 0) {
      if (*(char *)(param_1 + 0x10) == '\0') {
        (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
      }
      return;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404dbbb0  @1404dbbb0  [medium:callgraph-r2]  (orig: FUN_1404dbbb0)
ulonglong FUN_1404dbbb0(longlong param_1)

{
  ulonglong extraout_RAX;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
                    /* WARNING: Could not recover jumptable at 0x0001404dbc05. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404dbc10  @1404dbc10  [medium:callgraph-r2]  (orig: FUN_1404dbc10)
void FUN_1404dbc10(longlong param_1)

{
  longlong lVar1;
  byte bVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
  (**(code **)(*plVar3 + 0xb0))(plVar3,0);
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
  (**(code **)(*plVar3 + 0xb0))(plVar3,0);
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
  lVar1 = *plVar4;
  bVar2 = (**(code **)(*plVar3 + 0x20))(plVar3);
  (**(code **)(lVar1 + 0xb0))(plVar4,bVar2 + 1);
  iVar5 = 8;
  do {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),iVar5);
    (**(code **)(*plVar3 + 0xb0))(plVar3,0);
    iVar5 = iVar5 + 1;
  } while (iVar5 < 0x16);
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(char *)(param_1 + 0x10) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  }
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404dc180  @1404dc180  [medium:callgraph-r2]  (orig: FUN_1404dc180)
ulonglong FUN_1404dc180(longlong param_1)

{
  undefined2 *puVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0xa34;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgInnerStengthOpt::helper_1404dc1d0  @1404dc1d0  [medium:callgraph-r2]  (orig: FUN_1404dc1d0)
ulonglong FUN_1404dc1d0(longlong param_1,undefined4 *param_2)

{
  ushort uVar1;
  ushort *puVar2;
  short *psVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  
  puVar2 = *(ushort **)(param_1 + 0x428);
  if (puVar2 == (ushort *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = extraout_RAX;
  }
  else {
    uVar4 = (longlong)*(int *)(param_1 + 0xc) + 5;
    if (uVar4 < 0x400) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
      uVar1 = *puVar2;
      *(undefined4 *)((longlong)puVar2 + (ulonglong)uVar1 * 5 + 2) = *param_2;
      *(undefined1 *)((longlong)puVar2 + (ulonglong)uVar1 * 5 + 6) = *(undefined1 *)(param_2 + 1);
      psVar3 = *(short **)(param_1 + 0x428);
      *psVar3 = *psVar3 + 1;
      return CONCAT71((int7)((ulonglong)psVar3 >> 8),1);
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMsgInnerStengthOpt::helper_1404dc260  @1404dc260  [medium:callgraph-r2]  (orig: FUN_1404dc260)
undefined8 FUN_1404dc260(longlong param_1)

{
  undefined2 *puVar1;
  
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  if (puVar1 == (undefined2 *)0x0) {
    return 0;
  }
  return CONCAT62((int6)((ulonglong)puVar1 >> 0x10),*puVar1);
}

// ==== CMsgInnerStengthOpt::helper_1404dc280  @1404dc280  [medium:callgraph-r2]  (orig: FUN_1404dc280)
void FUN_1404dc280(longlong param_1)

{
  if (*(undefined2 **)(param_1 + 0x428) == (undefined2 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  *(undefined4 *)(param_1 + 0xc) = 2;
  **(undefined2 **)(param_1 + 0x428) = 0;
  return;
}

// ==== CMsgInnerStengthOpt::helper_1404dc3f0  @1404dc3f0  [medium:callgraph-r2]  (orig: FUN_1404dc3f0)
ulonglong FUN_1404dc3f0(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                       undefined4 param_5)

{
  longlong lVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  ulonglong uVar3;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 0xc) = 0x12;
    *(undefined4 *)(param_1 + 8) = 0xa33;
    **(undefined4 **)(param_1 + 0x428) = param_2;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_5;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = 0;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = 0;
    uVar3 = (ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 0xe);
    lVar1 = *(longlong *)(param_1 + 0x428) + uVar3 * 4;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
    *(ulonglong *)(param_1 + 0x430) = uVar3 + 0x12 + lVar1;
  }
  return uVar2;
}

// ==== CMsgInnerStengthOpt::helper_1404dc560  @1404dc560  [medium:callgraph-r2]  (orig: FUN_1404dc560)
ulonglong FUN_1404dc560(longlong param_1,longlong param_2)

{
  short *psVar1;
  longlong lVar2;
  undefined1 uVar3;
  undefined2 uVar4;
  ulonglong extraout_RAX;
  ulonglong uVar5;
  ulonglong extraout_RAX_00;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = extraout_RAX;
  }
  else {
    if (*(longlong *)(param_1 + 0x428) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return extraout_RAX_00 & 0xffffffffffffff00;
    }
    uVar5 = (longlong)*(int *)(param_1 + 0xc) + 5;
    if (uVar5 < 0x400) {
      lVar2 = *(longlong *)(param_1 + 0x428);
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 5;
      uVar4 = FUN_1404db500(param_2);
      *(undefined2 *)((ulonglong)*(ushort *)(lVar2 + 0xe) * 5 + 0x12 + lVar2) = uVar4;
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar3 = FUN_1404db5c0(param_2);
      *(undefined1 *)((ulonglong)*(ushort *)(lVar2 + 0xe) * 5 + lVar2 + 0x14) = uVar3;
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar3 = FUN_1404db810(param_2);
      *(undefined1 *)((ulonglong)*(ushort *)(lVar2 + 0xe) * 5 + 0x15 + lVar2) = uVar3;
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar3 = FUN_1404dba10(param_2);
      *(undefined1 *)((ulonglong)*(ushort *)(lVar2 + 0xe) * 5 + 0x16 + lVar2) = uVar3;
      psVar1 = (short *)(*(longlong *)(param_1 + 0x428) + 0xe);
      *psVar1 = *psVar1 + 1;
      uVar5 = (ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 0xe);
      lVar2 = *(longlong *)(param_1 + 0x428) + uVar5 * 4;
      *(ulonglong *)(param_1 + 0x430) = uVar5 + 0x12 + lVar2;
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return uVar5 & 0xffffffffffffff00;
}

// ==== CMsgInnerStengthOpt::helper_1404dc6b0  @1404dc6b0  [medium:callgraph-r2]  (orig: FUN_1404dc6b0)
undefined8 FUN_1404dc6b0(longlong param_1,longlong param_2)

{
  short *psVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar2 = FUN_1404db500(param_2);
    iVar4 = 8;
    do {
      if (0x3ff < (longlong)*(int *)(param_1 + 0xc) + 7U) {
        return 0;
      }
      iVar3 = FUN_1404db6c0(param_2,iVar4);
      if (iVar3 != 0) {
        *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 7;
        *(char *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 0x10) * 7 + 2 +
                 *(longlong *)(param_1 + 0x430)) = (char)iVar4 + -7;
        *(int *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 0x10) * 7 + 3 +
                *(longlong *)(param_1 + 0x430)) = iVar3;
        *(undefined2 *)
         ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 0x10) * 7 +
         *(longlong *)(param_1 + 0x430)) = uVar2;
        psVar1 = (short *)(*(longlong *)(param_1 + 0x428) + 0x10);
        *psVar1 = *psVar1 + 1;
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < 0x16);
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

