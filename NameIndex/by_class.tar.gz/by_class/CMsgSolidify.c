// ==== CMsgSolidify::helper_140100190  @140100190  [medium:callgraph-r2]  (orig: FUN_140100190)
void FUN_140100190(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  if (param_2 != 0) {
    if ((param_1[8] != 0) && (param_1[8] = 0, param_1[10] == 0)) {
      plVar3 = (longlong *)FUN_140087d40();
      lVar1 = *plVar3;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0x180))(plVar3,uVar2);
    }
    param_1[9] = param_2;
  }
  return;
}

// ==== CMsgSolidify::helper_1401002b0  @1401002b0  [medium:callgraph-r2]  (orig: FUN_1401002b0)
void FUN_1401002b0(longlong *param_1,longlong param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  if (param_2 != 0) {
    if ((param_1[10] != 0) && (param_1[10] = 0, param_1[8] == 0)) {
      plVar3 = (longlong *)FUN_140087d40();
      lVar1 = *plVar3;
      uVar2 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0x180))(plVar3,uVar2);
    }
    param_1[0xb] = param_2;
  }
  return;
}

// ==== CMsgSolidify::helper_14032b1a0  @14032b1a0  [medium:callgraph-r1]  (orig: FUN_14032b1a0)
undefined4 FUN_14032b1a0(undefined8 param_1)

{
  int iVar1;
  
  iVar1 = FUN_1400fda10(param_1,1,1);
  if (iVar1 != 0xb0aee) {
    iVar1 = FUN_1400fda10(param_1,1,1);
    if (iVar1 != 0xb0aef) {
      return 0;
    }
  }
  return 1;
}

// ==== CMsgSolidify::helper_140340620  @140340620  [medium:callgraph-r1]  (orig: FUN_140340620)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140340620(longlong *param_1,longlong *param_2,int param_3,longlong param_4,
                  longlong *param_5)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    if ((param_4 != 0) && (param_5 != (longlong *)0x0)) {
      lVar9 = 0;
      local_488 = param_2;
      if (0 < param_3) {
        do {
          uVar3 = *(undefined4 *)(param_4 + lVar9 * 4);
          cVar2 = FUN_140340190(param_1,uVar3,1,1);
          if (cVar2 == '\0') {
            (**(code **)(param_1[2] + 0x18))();
            (**(code **)(*param_1 + 8))(param_1);
            local_4b8 = uVar3;
            tq::MyLogSave("gmlog/ForgeItem","User[%u][%s] ForgeItem Erase SolidifyItem[%u] failed");
            return;
          }
          lVar9 = lVar9 + 1;
        } while (lVar9 < param_3);
      }
      FUN_140100210(param_2,1);
      (**(code **)(*param_5 + 0x38))(param_5,7,0);
      (**(code **)(*param_5 + 0x50))(param_5);
      FUN_1401002b0(param_2,param_5);
      FUN_1403b6000(local_478);
      uVar3 = (**(code **)(*param_5 + 0x18))(param_5);
      uVar4 = (**(code **)(*param_5 + 0x10))(param_5);
      uVar5 = (**(code **)(*param_5 + 0x30))(param_5,4);
      uVar6 = (**(code **)(*param_5 + 0x30))(param_5,3);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      local_498 = 0;
      local_4a0 = 0;
      local_4b8 = uVar5;
      local_4b0 = uVar4;
      local_4a8 = uVar3;
      iVar8 = FUN_1403b60f0(local_478,uVar7,9,uVar6);
      if (iVar8 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
      }
      uVar3 = (**(code **)(*param_5 + 0x30))(param_5,0);
      plVar1 = local_488;
      uVar4 = FUN_1400fda10(local_488,1,1);
      uVar5 = (**(code **)(*plVar1 + 8))(plVar1);
      (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      local_4b8 = uVar5;
      local_4b0 = uVar4;
      local_4a8 = uVar3;
      tq::MyLogSave("gmlog/ForgeItem","%s(%u) Solidify ForgeItem [id=%u, type=%u,idStatus=%d]");
      lVar9 = FUN_140008520((int)param_1[0x246]);
      lVar9 = *(longlong *)(lVar9 + 0x1f8);
      if (lVar9 == 0) {
        local_4b8 = 0x163;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar9 = 0;
      }
      FUN_140261810(lVar9,param_1,0xd);
      FUN_1403b6050(local_478);
    }
  }
  return;
}

// ==== CMsgSolidify::helper_140349de0  @140349de0  [medium:callgraph-r1]  (orig: FUN_140349de0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140349de0(longlong *param_1,longlong *param_2,int param_3,longlong param_4,
                  longlong *param_5)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_480 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    if ((param_4 != 0) && (param_5 != (longlong *)0x0)) {
      lVar9 = 0;
      local_488 = param_2;
      if (0 < param_3) {
        do {
          cVar2 = FUN_140340190(param_1,*(undefined4 *)(param_4 + lVar9 * 4),1,1);
          if (cVar2 == '\0') {
            return;
          }
          lVar9 = lVar9 + 1;
        } while (lVar9 < param_3);
      }
      FUN_140100090(param_2,1);
      (**(code **)(*param_5 + 0x38))(param_5,7,0);
      (**(code **)(*param_5 + 0x50))(param_5);
      FUN_140100190(param_2,param_5);
      FUN_1403b6000(local_478);
      uVar3 = (**(code **)(*param_5 + 0x18))(param_5);
      uVar4 = (**(code **)(*param_5 + 0x10))(param_5);
      uVar5 = (**(code **)(*param_5 + 0x30))(param_5,4);
      uVar6 = (**(code **)(*param_5 + 0x30))(param_5,3);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      local_498 = 0;
      local_4a0 = 0;
      local_4b8 = uVar5;
      local_4b0 = uVar4;
      local_4a8 = uVar3;
      iVar8 = FUN_1403b60f0(local_478,uVar7,4,uVar6);
      if (iVar8 != 0) {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_478);
      }
      uVar3 = (**(code **)(*param_5 + 0x30))(param_5,0);
      plVar1 = local_488;
      uVar4 = FUN_1400fda10(local_488,1,1);
      uVar5 = (**(code **)(*plVar1 + 8))(plVar1);
      (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(param_1[2] + 0x18))(param_1 + 2);
      local_4b8 = uVar5;
      local_4b0 = uVar4;
      local_4a8 = uVar3;
      tq::MyLogSave("gmlog/SolidifyItem","%s(%u) SolidifyItem [id=%u, type=%u,idStatus=%d]");
      lVar9 = FUN_140008520((int)param_1[0x246]);
      lVar9 = *(longlong *)(lVar9 + 0x1f8);
      if (lVar9 == 0) {
        local_4b8 = 0x163;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar9 = 0;
      }
      FUN_140261810(lVar9,param_1,0xd);
      FUN_1403b6050(local_478);
    }
  }
  return;
}

// ==== CMsgSolidify::helper_14034a620  @14034a620  [medium:callgraph-r0]  (orig: FUN_14034a620)
void FUN_14034a620(undefined8 param_1,undefined4 param_2,int param_3,longlong param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  int iVar12;
  bool bVar13;
  int aiStack_5c [13];
  
  cVar2 = FUN_140332fe0();
  if (cVar2 != '\0') {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    lVar7 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (((lVar7 != 0) && (param_4 != 0)) && (0 < param_3)) {
      iVar12 = 0;
      if (0x27 < param_3) {
        param_3 = 0x27;
      }
      lVar11 = 0;
      if (0 < param_3) {
        do {
          uVar1 = *(undefined4 *)(param_4 + lVar11 * 4);
          cVar2 = FUN_140332fe0(param_1,uVar1);
          if (cVar2 == '\0') {
            return;
          }
          plVar9 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar9 = (longlong *)0x0;
          }
          lVar8 = (**(code **)(*plVar9 + 0x60))(plVar9,uVar1);
          if (lVar8 == 0) {
            return;
          }
          cVar2 = FUN_1400ffc20(lVar8);
          if (cVar2 != '\0') {
            return;
          }
          cVar2 = FUN_14032b1a0(lVar8);
          if (cVar2 == '\0') {
            return;
          }
          cVar2 = FUN_1400ffbe0(lVar8);
          if ((cVar2 != '\0') && (cVar2 = FUN_1400ffbe0(lVar7), cVar2 == '\0')) {
            return;
          }
          iVar3 = FUN_1400fda10(lVar8,0x81,1);
          lVar11 = lVar11 + 1;
          iVar12 = iVar12 + iVar3;
        } while (lVar11 < param_3);
      }
      aiStack_5c[1] = 10;
      aiStack_5c[2] = 0x1e;
      aiStack_5c[3] = 0x3c;
      aiStack_5c[4] = 100;
      aiStack_5c[5] = 0x96;
      aiStack_5c[6] = 200;
      aiStack_5c[7] = 300;
      aiStack_5c[8] = 400;
      aiStack_5c[9] = 600;
      aiStack_5c[10] = 800;
      plVar9 = (longlong *)FUN_140100290(lVar7);
      if ((plVar9 != (longlong *)0x0) &&
         (iVar3 = (**(code **)(*plVar9 + 0x30))(plVar9,4), iVar3 < 0xb)) {
        iVar3 = aiStack_5c[iVar3];
        plVar10 = (longlong *)FUN_1401002a0(lVar7);
        if (plVar10 == (longlong *)0x0) {
          if (iVar12 < iVar3) {
            return;
          }
        }
        else {
          iVar4 = (**(code **)(*plVar10 + 0x30))(plVar10,4);
          if (10 < iVar4) {
            return;
          }
          iVar5 = (**(code **)(*plVar10 + 0x30))(plVar10,4);
          iVar6 = (**(code **)(*plVar9 + 0x30))(plVar9,4);
          if (iVar5 < iVar6) {
            iVar3 = iVar3 - aiStack_5c[iVar4];
            bVar13 = SBORROW4(iVar12,iVar3);
            iVar3 = -iVar3;
          }
          else {
            bVar13 = SBORROW4(iVar12,10);
            iVar3 = -10;
          }
          if (bVar13 != iVar12 + iVar3 < 0) {
            return;
          }
        }
        FUN_140340620(param_1,lVar7,param_3,param_4,plVar9);
      }
    }
  }
  return;
}

// ==== CMsgSolidify::helper_1403555c0  @1403555c0  [medium:callgraph-r0]  (orig: FUN_1403555c0)
void FUN_1403555c0(undefined8 param_1,undefined4 param_2,int param_3,longlong param_4)

{
  undefined4 uVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  int iVar12;
  bool bVar13;
  int aiStack_6c [13];
  
  cVar2 = FUN_140333220();
  if (cVar2 != '\0') {
    plVar9 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar9 = (longlong *)0x0;
    }
    lVar7 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
    if (lVar7 != 0) goto LAB_140355690;
  }
  cVar2 = FUN_140332fe0(param_1,param_2);
  if (cVar2 == '\0') {
    return;
  }
  plVar9 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar9 = (longlong *)0x0;
  }
  lVar7 = (**(code **)(*plVar9 + 0x60))(plVar9,param_2);
  if (lVar7 == 0) {
    return;
  }
LAB_140355690:
  if ((param_4 != 0) && (0 < param_3)) {
    iVar12 = 0;
    if (0x27 < param_3) {
      param_3 = 0x27;
    }
    lVar11 = 0;
    if (0 < param_3) {
      do {
        uVar1 = *(undefined4 *)(param_4 + lVar11 * 4);
        cVar2 = FUN_140332fe0(param_1,uVar1);
        if (cVar2 == '\0') {
          return;
        }
        plVar9 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar9 = (longlong *)0x0;
        }
        lVar8 = (**(code **)(*plVar9 + 0x60))(plVar9,uVar1);
        if (lVar8 == 0) {
          return;
        }
        iVar3 = FUN_1400fda10(lVar8,1,1);
        if ((iVar3 != 0xb0aee) && (iVar3 = FUN_1400fda10(lVar8,1,1), iVar3 != 0xb0aef)) {
          return;
        }
        cVar2 = FUN_1400ffbe0(lVar8);
        if ((cVar2 != '\0') && (cVar2 = FUN_1400ffbe0(lVar7), cVar2 == '\0')) {
          return;
        }
        cVar2 = FUN_1400ffc20(lVar8);
        if (cVar2 != '\0') {
          return;
        }
        iVar3 = FUN_1400fda10(lVar8,0x81,1);
        lVar11 = lVar11 + 1;
        iVar12 = iVar12 + iVar3;
      } while (lVar11 < param_3);
    }
    aiStack_6c[1] = 10;
    aiStack_6c[2] = 0x1e;
    aiStack_6c[3] = 0x46;
    aiStack_6c[4] = 0x96;
    aiStack_6c[5] = 0x10e;
    aiStack_6c[6] = 0x1ae;
    aiStack_6c[7] = 0x262;
    aiStack_6c[8] = 800;
    aiStack_6c[9] = 1000;
    aiStack_6c[10] = 0x4b0;
    plVar9 = (longlong *)FUN_140100070(lVar7);
    if (plVar9 != (longlong *)0x0) {
      iVar4 = (**(code **)(*plVar9 + 0x30))(plVar9,4);
      iVar3 = aiStack_6c[iVar4];
      plVar10 = (longlong *)FUN_140100080(lVar7);
      if (iVar4 < 0xb) {
        if (plVar10 == (longlong *)0x0) {
          if (iVar12 < iVar3) {
            return;
          }
        }
        else {
          iVar4 = (**(code **)(*plVar10 + 0x30))(plVar10,4);
          if (10 < iVar4) {
            return;
          }
          iVar5 = (**(code **)(*plVar10 + 0x30))(plVar10,4);
          iVar6 = (**(code **)(*plVar9 + 0x30))(plVar9,4);
          if (iVar5 < iVar6) {
            iVar3 = iVar3 - aiStack_6c[iVar4];
            bVar13 = SBORROW4(iVar12,iVar3);
            iVar3 = -iVar3;
          }
          else {
            bVar13 = SBORROW4(iVar12,10);
            iVar3 = -10;
          }
          if (bVar13 != iVar12 + iVar3 < 0) {
            return;
          }
        }
        FUN_140349de0(param_1,lVar7,param_3,param_4,plVar9);
      }
    }
  }
  return;
}

// ==== CMsgSolidify::ctor_or_dtor  @1404557e0  [high:vtable-assign]  (orig: FUN_1404557e0)
undefined8 * FUN_1404557e0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSolidify::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSolidify::ctor_or_dtor  @140455830  [high:vtable-assign]  (orig: FUN_140455830)
void FUN_140455830(undefined8 *param_1)

{
  *param_1 = CMsgSolidify::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSolidify::vfunc_1  @140455860  [high:rtti-vtable]  (orig: FUN_140455860)
ulonglong FUN_140455860(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x40e);
}

// ==== CMsgSolidify::ctor_or_dtor  @1404558c0  [high:vtable-assign]  (orig: FUN_1404558c0)
undefined8 * FUN_1404558c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSolidify::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSolidify::vfunc_3  @140455910  [high:rtti-vtable]  (orig: FUN_140455910)
void FUN_140455910(longlong param_1)

{
  int iVar1;
  short *psVar2;
  longlong lVar3;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1);
  if ((lVar3 != 0) &&
     ((iVar1 = *(int *)(*(longlong *)(param_1 + 0x428) + 8), iVar1 < 1 ||
      ((longlong)(iVar1 + -1) * 4 + 0x10U < 0x3fd)))) {
    psVar2 = *(short **)(param_1 + 0x428);
    if (*psVar2 == 0) {
      FUN_1403555c0(lVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4),psVar2 + 6);
    }
    else if (*psVar2 == 1) {
      FUN_14034a620(lVar3,*(undefined4 *)(psVar2 + 2),*(undefined4 *)(psVar2 + 4),psVar2 + 6);
    }
    else {
      log_InlineLogERROR("Receive Error MsgSolidify");
    }
  }
  return;
}

