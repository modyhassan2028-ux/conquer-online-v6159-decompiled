// ==== CRoleManager::helper_1400959e0  @1400959e0  [medium:callgraph-r3]  (orig: FUN_1400959e0)
void FUN_1400959e0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140095a04. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CRoleManager::vfunc_7  @1402f5260  [high:rtti-vtable]  (orig: FUN_1402f5260)
undefined4 FUN_1402f5260(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CRoleManager::vfunc_26  @1402f5270  [high:rtti-vtable]  (orig: FUN_1402f5270)
longlong FUN_1402f5270(longlong param_1)

{
  return param_1 + 0x98;
}

// ==== CRoleManager::helper_1402f5a50  @1402f5a50  [medium:callgraph-r0]  (orig: FUN_1402f5a50)
void FUN_1402f5a50(void *param_1)

{
  if ((DAT_140975fc8 & 1) == 0) {
    DAT_140975fc8 = DAT_140975fc8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975fc0,"CRoleManager");
    atexit((_func_5014 *)&LAB_1406d6a20);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402f5aa5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975fc0,param_1);
  return;
}

// ==== CRoleManager::vfunc_16  @1402f5b10  [high:rtti-vtable]  (orig: FUN_1402f5b10)
undefined8 FUN_1402f5b10(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  int iVar5;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar3 = (longlong *)InstanceGet();
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,"SELECT * FROM cq_pet",2);
    if (plVar3 != (longlong *)0x0) {
      iVar5 = 0;
      iVar2 = (**(code **)(*plVar3 + 0x40))(plVar3);
      if (0 < iVar2) {
        do {
          (**(code **)(*plVar3 + 0x30))(plVar3,(longlong)iVar5);
          lVar4 = FUN_140391b90();
          if (lVar4 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            cVar1 = FUN_14038fa90(lVar4,*(undefined4 *)(param_1 + 0x10),plVar3);
            if (cVar1 == '\0') {
              (**(code **)(*(longlong *)(lVar4 + 0x10) + 8))(lVar4 + 0x10);
            }
            else {
              (**(code **)(**(longlong **)(param_1 + 8) + 0x28))
                        (*(longlong **)(param_1 + 8),lVar4 + 0x10);
              FUN_14038b420(lVar4);
            }
          }
          iVar5 = iVar5 + 1;
          iVar2 = (**(code **)(*plVar3 + 0x40))(plVar3);
        } while (iVar5 < iVar2);
      }
      (**(code **)*plVar3)(plVar3);
    }
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CRoleManager::vfunc_3  @1402f5c60  [high:rtti-vtable]  (orig: FUN_1402f5c60)
longlong FUN_1402f5c60(longlong *param_1,longlong param_2,int param_3)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*(int *)(param_2 + 0x414) == -1) {
    plVar2 = (longlong *)(**(code **)(*param_1 + 0x30))();
                    /* WARNING: Could not recover jumptable at 0x0001402f5d49. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2,*(undefined4 *)(param_2 + 0x418));
    return lVar3;
  }
  if ((*(int *)(param_2 + 0x420) == 0) && (*(int *)(param_2 + 0x41c) == 0)) {
    uVar1 = FUN_140008520((int)param_1[2]);
    plVar2 = (longlong *)FUN_140087650(uVar1);
    lVar3 = (**(code **)(*plVar2 + 0xa8))(plVar2,*(undefined4 *)(param_2 + 0x414));
  }
  else {
    uVar1 = FUN_140008520((int)param_1[2]);
    plVar2 = (longlong *)FUN_140087650(uVar1);
    lVar3 = (**(code **)(*plVar2 + 0xa0))
                      (plVar2,*(undefined4 *)(param_2 + 0x420),*(undefined4 *)(param_2 + 0x41c));
  }
  if (lVar3 != 0) {
    if (param_3 - 0xaae61U < 99999) {
      lVar4 = FUN_1401aaa20(lVar3,param_3);
      if (lVar4 != 0) {
        return lVar4 + 0x10;
      }
    }
    return lVar3 + 0x10;
  }
  return 0;
}

// ==== CRoleManager::vfunc_5  @1402f5d50  [high:rtti-vtable]  (orig: FUN_1402f5d50)
void FUN_1402f5d50(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402f5db6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x90))(*(longlong **)(lVar1 + 0x90),param_2,0);
  return;
}

// ==== CRoleManager::helper_1402f5e30  @1402f5e30  [medium:callgraph-r3]  (orig: FUN_1402f5e30)
void FUN_1402f5e30(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CRoleManager::helper_1402f5e90  @1402f5e90  [medium:callgraph-r3]  (orig: FUN_1402f5e90)
void FUN_1402f5e90(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CRoleManager::helper_1402f6110  @1402f6110  [medium:callgraph-r1]  (orig: FUN_1402f6110)
void FUN_1402f6110(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402f6110(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CRoleManager::helper_1402f6180  @1402f6180  [medium:callgraph-r2]  (orig: FUN_1402f6180)
undefined8 *
FUN_1402f6180(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    puVar1[4] = param_5[1];
    *(undefined1 *)(puVar1 + 5) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  }
  return puVar1;
}

// ==== CRoleManager::helper_1402f6260  @1402f6260  [medium:callgraph-r1]  (orig: FUN_1402f6260)
void FUN_1402f6260(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CRoleManager::helper_1402f6720  @1402f6720  [medium:callgraph-r1]  (orig: FUN_1402f6720)
void FUN_1402f6720(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CRoleManager::helper_1402f6850  @1402f6850  [medium:callgraph-r0]  (orig: FUN_1402f6850)
void FUN_1402f6850(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402f6110(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CRoleManager::helper_1402f6950  @1402f6950  [medium:callgraph-r2]  (orig: FUN_1402f6950)
undefined8 * FUN_1402f6950(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400959e0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402f6b3c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402f6b3c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402f5e30(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402f5e90(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1402f5e30(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402f5e90(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402f5e30(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1402f5e90(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CRoleManager::helper_1402f6d10  @1402f6d10  [medium:callgraph-r1]  (orig: FUN_1402f6d10)
undefined8 * FUN_1402f6d10(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CRoleManager::vfunc_30  @1402f7080  [high:rtti-vtable]  (orig: FUN_1402f7080)
undefined1 FUN_1402f7080(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_1402f6850(param_1 + 0x18);
  FUN_1402f6850(param_1 + 0x58);
  FUN_1402f6850(param_1 + 0x98);
  return 1;
}

// ==== CRoleManager::vfunc_15  @1402f70f0  [high:rtti-vtable]  (orig: FUN_1402f70f0)
void FUN_1402f70f0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),&local_38);
  while( true ) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x18))
                       (*(longlong **)(param_1 + 8),local_18);
    if ((CONCAT44(uStack_34,local_38) == 0) || (CONCAT44(uStack_34,local_38) != *plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_30 == (longlong *)plVar3[1]) break;
    local_28 = local_38;
    uStack_24 = uStack_34;
    uStack_20 = (undefined4)uStack_30;
    uStack_1c = uStack_30._4_4_;
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                       (*(longlong **)(param_1 + 8),&local_28);
    if (plVar3 != (longlong *)0x0) {
      (**(code **)(*plVar3 + 0x338))(plVar3);
    }
    if (CONCAT44(uStack_34,local_38) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_30 + 0x29) == '\0') {
      plVar3 = (longlong *)uStack_30[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        uStack_30 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          uStack_30 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(uStack_30[1] + 0x29);
        plVar2 = (longlong *)uStack_30[1];
        plVar3 = uStack_30;
        while ((uStack_30 = plVar2, cVar1 == '\0' && (plVar3 == (longlong *)uStack_30[2]))) {
          cVar1 = *(char *)(uStack_30[1] + 0x29);
          plVar2 = (longlong *)uStack_30[1];
          plVar3 = uStack_30;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CRoleManager::vfunc_22  @1402f7200  [high:rtti-vtable]  (orig: FUN_1402f7200)
int FUN_1402f7200(longlong param_1,int param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  char *pcVar6;
  int iVar7;
  longlong lVar8;
  longlong local_res8;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  iVar7 = 0;
  (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),&local_48);
  do {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x18))
                       (*(longlong **)(param_1 + 8),local_28);
    if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar5)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_40 == (longlong *)plVar5[1]) {
      return iVar7;
    }
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                       (*(longlong **)(param_1 + 8),&local_38);
    if ((plVar5 != (longlong *)0x0) &&
       (cVar3 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1002,&local_res8), cVar3 != '\0')) {
      plVar5 = (longlong *)
               (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x160))(local_res8 + 0x10);
      iVar4 = (**(code **)(*plVar5 + 8))(plVar5);
      if (iVar4 == param_2) {
        pcVar6 = (char *)(**(code **)(*(longlong *)(local_res8 + 0x10) + 0x18))(local_res8 + 0x10);
        lVar8 = param_3 - (longlong)pcVar6;
        do {
          cVar3 = *pcVar6;
          cVar1 = pcVar6[lVar8];
          if (cVar3 != cVar1) break;
          pcVar6 = pcVar6 + 1;
        } while (cVar1 != '\0');
        if ((cVar3 == cVar1) &&
           (cVar3 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x220))(local_res8 + 0x10),
           cVar3 != '\0')) {
          iVar7 = iVar7 + 1;
        }
      }
    }
    if (CONCAT44(uStack_44,local_48) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
      plVar5 = (longlong *)uStack_40[2];
      if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar5 + 0x29);
        uStack_40 = plVar5;
        plVar5 = (longlong *)*plVar5;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar5 + 0x29);
          uStack_40 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        cVar3 = *(char *)(uStack_40[1] + 0x29);
        plVar2 = (longlong *)uStack_40[1];
        plVar5 = uStack_40;
        while ((uStack_40 = plVar2, cVar3 == '\0' && (plVar5 == (longlong *)uStack_40[2]))) {
          cVar3 = *(char *)(uStack_40[1] + 0x29);
          plVar2 = (longlong *)uStack_40[1];
          plVar5 = uStack_40;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CRoleManager::vfunc_23  @1402f73b0  [high:rtti-vtable]  (orig: FUN_1402f73b0)
int FUN_1402f73b0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  int iVar5;
  longlong local_res8;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  iVar5 = 0;
  (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),&local_48);
  while( true ) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x18))
                       (*(longlong **)(param_1 + 8),local_28);
    if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar4)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_40 == (longlong *)plVar4[1]) break;
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                       (*(longlong **)(param_1 + 8),&local_38);
    if ((plVar4 != (longlong *)0x0) &&
       (cVar2 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1002,&local_res8), cVar2 != '\0')) {
      plVar4 = (longlong *)
               (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x160))(local_res8 + 0x10);
      iVar3 = (**(code **)(*plVar4 + 8))(plVar4);
      if ((iVar3 == param_2) &&
         ((*(int *)(local_res8 + 0x164) == param_3 &&
          (cVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x220))(local_res8 + 0x10),
          cVar2 != '\0')))) {
        iVar5 = iVar5 + 1;
      }
    }
    if (CONCAT44(uStack_44,local_48) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
      plVar4 = (longlong *)uStack_40[2];
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar4 + 0x29);
        uStack_40 = plVar4;
        plVar4 = (longlong *)*plVar4;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar4 + 0x29);
          uStack_40 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar2 = *(char *)(uStack_40[1] + 0x29);
        plVar1 = (longlong *)uStack_40[1];
        plVar4 = uStack_40;
        while ((uStack_40 = plVar1, cVar2 == '\0' && (plVar4 == (longlong *)uStack_40[2]))) {
          cVar2 = *(char *)(uStack_40[1] + 0x29);
          plVar1 = (longlong *)uStack_40[1];
          plVar4 = uStack_40;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return iVar5;
}

// ==== CRoleManager::vfunc_29  @1402f7530  [high:rtti-vtable]  (orig: FUN_1402f7530)
void FUN_1402f7530(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 local_res8;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined8 uStack_30;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined1 local_18 [16];
  
  (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),&local_38);
  while( true ) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x18))
                       (*(longlong **)(param_1 + 8),local_18);
    if ((CONCAT44(uStack_34,local_38) == 0) || (CONCAT44(uStack_34,local_38) != *plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_30 == (longlong *)plVar3[1]) break;
    local_res8 = 0;
    local_28 = local_38;
    uStack_24 = uStack_34;
    uStack_20 = (undefined4)uStack_30;
    uStack_1c = uStack_30._4_4_;
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                       (*(longlong **)(param_1 + 8),&local_28);
    if ((plVar3 != (longlong *)0x0) &&
       (cVar2 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1002,&local_res8), cVar2 != '\0')) {
      FUN_140388b80(local_res8);
    }
    if (CONCAT44(uStack_34,local_38) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_30 + 0x29) == '\0') {
      plVar3 = (longlong *)uStack_30[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar3 + 0x29);
        uStack_30 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar3 + 0x29);
          uStack_30 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar2 = *(char *)(uStack_30[1] + 0x29);
        plVar1 = (longlong *)uStack_30[1];
        plVar3 = uStack_30;
        while ((uStack_30 = plVar1, cVar2 == '\0' && (plVar3 == (longlong *)uStack_30[2]))) {
          cVar2 = *(char *)(uStack_30[1] + 0x29);
          plVar1 = (longlong *)uStack_30[1];
          plVar3 = uStack_30;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CRoleManager::helper_1402f7740  @1402f7740  [medium:callgraph-r1]  (orig: FUN_1402f7740)
longlong * FUN_1402f7740(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402f6850(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402f6950(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CRoleManager::helper_1402f7950  @1402f7950  [medium:callgraph-r1]  (orig: FUN_1402f7950)
undefined8 *
FUN_1402f7950(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402f6180(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CRoleManager::helper_1402f7c90  @1402f7c90  [medium:callgraph-r0]  (orig: FUN_1402f7c90)
void FUN_1402f7c90(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402f7740((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CRoleManager::vfunc_18  @1402f8060  [high:rtti-vtable]  (orig: FUN_1402f8060)
ulonglong FUN_1402f8060(longlong param_1,int param_2)

{
  ulonglong *puVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  bool bVar8;
  
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 200);
  puVar1 = *(ulonglong **)(param_1 + 0x98);
  uVar7 = 0;
  do {
    while( true ) {
      while( true ) {
        plVar5 = *(longlong **)(param_1 + 200);
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != *(ulonglong **)(param_1 + 0x98))) {
          _invalid_parameter_noinfo();
        }
        if (plVar4 == plVar5) {
          return uVar7;
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar6 = 0;
        }
        else {
          uVar6 = *puVar1;
        }
        if (plVar4 == *(longlong **)(uVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((plVar4[4] != 0) &&
           (iVar3 = (**(code **)(*(longlong *)(plVar4[4] + 0x10) + 0x168))(), iVar3 == param_2)) {
          uVar7 = (ulonglong)((int)uVar7 + 1);
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar4;
      plVar2 = (longlong *)plVar4[2];
      if (*(char *)(plVar4[2] + 0x29) != '\0') break;
      do {
        plVar4 = plVar2;
        plVar2 = (longlong *)*plVar4;
      } while (*(char *)(*plVar4 + 0x29) == '\0');
    }
    do {
      plVar4 = (longlong *)plVar5[1];
      if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
      bVar8 = plVar5 == (longlong *)plVar4[2];
      plVar5 = plVar4;
    } while (bVar8);
  } while( true );
}

// ==== CRoleManager::vfunc_19  @1402f81c0  [high:rtti-vtable]  (orig: FUN_1402f81c0)
ulonglong FUN_1402f81c0(longlong param_1,int param_2)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong *plVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  bool bVar9;
  
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 200);
  puVar1 = *(ulonglong **)(param_1 + 0x98);
  uVar8 = 0;
  do {
    while( true ) {
      while( true ) {
        plVar6 = *(longlong **)(param_1 + 200);
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != *(ulonglong **)(param_1 + 0x98))) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar6) {
          return uVar8;
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar7 = 0;
        }
        else {
          uVar7 = *puVar1;
        }
        if (plVar5 == *(longlong **)(uVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar2 = plVar5[4];
        if (((lVar2 != 0) &&
            (iVar4 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x168))(), iVar4 == param_2)) &&
           ((iVar4 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                               (*(longlong **)(lVar2 + 0x60),4), iVar4 == 0x19 ||
            (iVar4 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                               (*(longlong **)(lVar2 + 0x60),4), iVar4 == 0x65)))) {
          uVar8 = (ulonglong)((int)uVar8 + 1);
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar5;
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)(plVar5[2] + 0x29) != '\0') break;
      do {
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar5;
      } while (*(char *)(*plVar5 + 0x29) == '\0');
    }
    do {
      plVar5 = (longlong *)plVar6[1];
      if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
      bVar9 = plVar6 == (longlong *)plVar5[2];
      plVar6 = plVar5;
    } while (bVar9);
  } while( true );
}

// ==== CRoleManager::vfunc_20  @1402f8350  [high:rtti-vtable]  (orig: FUN_1402f8350)
int FUN_1402f8350(longlong param_1,int param_2,longlong param_3)

{
  char cVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  char *pcVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  int iVar10;
  bool bVar11;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar10 = 0;
  }
  else {
    iVar10 = 0;
    plVar7 = (longlong *)**(undefined8 **)(param_1 + 200);
    plVar3 = *(longlong **)(param_1 + 0x98);
LAB_1402f83e0:
    plVar8 = *(longlong **)(param_1 + 200);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x98))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 != plVar8) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar7[4] != 0) {
        plVar8 = (longlong *)(plVar7[4] + 0x10);
        iVar5 = (**(code **)(*plVar8 + 0x168))(plVar8);
        if (iVar5 == param_2) {
          pcVar6 = (char *)(**(code **)(*plVar8 + 0x18))(plVar8);
          lVar9 = param_3 - (longlong)pcVar6;
          do {
            cVar1 = *pcVar6;
            cVar2 = pcVar6[lVar9];
            if (cVar1 != cVar2) break;
            pcVar6 = pcVar6 + 1;
          } while (cVar2 != '\0');
          if (cVar1 == cVar2) {
            iVar10 = iVar10 + 1;
          }
        }
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        plVar8 = plVar7;
        plVar4 = (longlong *)plVar7[2];
        if (*(char *)(plVar7[2] + 0x29) == '\0') {
          do {
            plVar7 = plVar4;
            plVar4 = (longlong *)*plVar7;
          } while (*(char *)(*plVar7 + 0x29) == '\0');
        }
        else {
          do {
            plVar7 = (longlong *)plVar8[1];
            if (*(char *)((longlong)plVar7 + 0x29) != '\0') break;
            bVar11 = plVar8 == (longlong *)plVar7[2];
            plVar8 = plVar7;
          } while (bVar11);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1402f83e0;
    }
  }
  return iVar10;
}

// ==== CRoleManager::vfunc_21  @1402f8520  [high:rtti-vtable]  (orig: FUN_1402f8520)
int FUN_1402f8520(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  int iVar7;
  bool bVar8;
  
  iVar7 = 0;
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 200);
  plVar1 = *(longlong **)(param_1 + 0x98);
  do {
    while( true ) {
      while( true ) {
        plVar5 = *(longlong **)(param_1 + 200);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x98))) {
          _invalid_parameter_noinfo();
        }
        if (plVar4 == plVar5) {
          return iVar7;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar6 = plVar4[4];
        if (((lVar6 != 0) &&
            (iVar3 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x168))(), iVar3 == param_2)) &&
           (iVar3 = (**(code **)(**(longlong **)(lVar6 + 0x60) + 0x10))
                              (*(longlong **)(lVar6 + 0x60),4), iVar3 == param_3)) {
          iVar7 = iVar7 + 1;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar4;
      plVar2 = (longlong *)plVar4[2];
      if (*(char *)(plVar4[2] + 0x29) != '\0') break;
      do {
        plVar4 = plVar2;
        plVar2 = (longlong *)*plVar4;
      } while (*(char *)(*plVar4 + 0x29) == '\0');
    }
    do {
      plVar4 = (longlong *)plVar5[1];
      if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
      bVar8 = plVar5 == (longlong *)plVar4[2];
      plVar5 = plVar4;
    } while (bVar8);
  } while( true );
}

// ==== CRoleManager::vfunc_12  @1402f86a0  [high:rtti-vtable]  (orig: FUN_1402f86a0)
void FUN_1402f86a0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  bool bVar7;
  
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  plVar1 = *(longlong **)(param_1 + 0x18);
  do {
    while( true ) {
      while( true ) {
        plVar5 = *(longlong **)(param_1 + 0x48);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x18))) {
          _invalid_parameter_noinfo();
        }
        if (plVar4 == plVar5) {
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar5 = (longlong *)plVar4[4];
        if ((plVar5 != (longlong *)0x0) &&
           (iVar3 = (**(code **)(*(longlong *)plVar5[0xc] + 0x10))((longlong *)plVar5[0xc],4),
           iVar3 == 0x1f)) {
          (**(code **)(*plVar5 + 0x48))(plVar5,0);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar4;
      plVar2 = (longlong *)plVar4[2];
      if (*(char *)(plVar4[2] + 0x29) != '\0') break;
      do {
        plVar4 = plVar2;
        plVar2 = (longlong *)*plVar4;
      } while (*(char *)(*plVar4 + 0x29) == '\0');
    }
    do {
      plVar4 = (longlong *)plVar5[1];
      if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
      bVar7 = plVar5 == (longlong *)plVar4[2];
      plVar5 = plVar4;
    } while (bVar7);
  } while( true );
}

// ==== CRoleManager::vfunc_13  @1402f87f0  [high:rtti-vtable]  (orig: FUN_1402f87f0)
ulonglong FUN_1402f87f0(longlong param_1,int param_2)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong *plVar3;
  int iVar4;
  uint uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  longlong *plVar8;
  ulonglong uVar9;
  bool bVar10;
  
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  uVar6 = 0;
  puVar1 = *(ulonglong **)(param_1 + 0x18);
  do {
    while( true ) {
      while( true ) {
        plVar8 = *(longlong **)(param_1 + 0x48);
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != *(ulonglong **)(param_1 + 0x18))) {
          _invalid_parameter_noinfo();
        }
        if (plVar7 == plVar8) {
          return 0;
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar9 = uVar6;
        }
        else {
          uVar9 = *puVar1;
        }
        if (plVar7 == *(longlong **)(uVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar2 = plVar7[4];
        if ((lVar2 != 0) &&
           (iVar4 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                              (*(longlong **)(lVar2 + 0x60),4), iVar4 == 0x1f)) {
          if (*(longlong *)(lVar2 + 0x60) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            iVar4 = 0;
          }
          else {
            iVar4 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                              (*(longlong **)(lVar2 + 0x60),1);
          }
          if (iVar4 == param_2) {
            if (*(longlong *)(lVar2 + 0x60) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              iVar4 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                                (*(longlong **)(lVar2 + 0x60),2);
              if (iVar4 == 4) {
                if (*(longlong *)(lVar2 + 0x60) == 0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  uVar5 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 8))();
                  uVar6 = (ulonglong)uVar5;
                }
                return uVar6;
              }
            }
          }
        }
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar7 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar7;
      plVar3 = (longlong *)plVar7[2];
      if (*(char *)(plVar7[2] + 0x29) != '\0') break;
      do {
        plVar7 = plVar3;
        plVar3 = (longlong *)*plVar7;
      } while (*(char *)(*plVar7 + 0x29) == '\0');
    }
    do {
      plVar7 = (longlong *)plVar8[1];
      if (*(char *)((longlong)plVar7 + 0x29) != '\0') break;
      bVar10 = plVar8 == (longlong *)plVar7[2];
      plVar8 = plVar7;
    } while (bVar10);
  } while( true );
}

// ==== CRoleManager::vfunc_14  @1402f8a00  [high:rtti-vtable]  (orig: FUN_1402f8a00)
longlong FUN_1402f8a00(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  bool bVar7;
  
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  plVar1 = *(longlong **)(param_1 + 0x18);
  do {
    while( true ) {
      while( true ) {
        plVar5 = *(longlong **)(param_1 + 0x48);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x18))) {
          _invalid_parameter_noinfo();
        }
        if (plVar4 == plVar5) {
          return 0;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar6 = plVar4[4];
        if (((lVar6 != 0) &&
            (iVar3 = (**(code **)(**(longlong **)(lVar6 + 0x60) + 0x10))
                               (*(longlong **)(lVar6 + 0x60),4), iVar3 == 0x28)) &&
           (iVar3 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x168))(), iVar3 == param_2)) {
          return lVar6;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar4;
      plVar2 = (longlong *)plVar4[2];
      if (*(char *)(plVar4[2] + 0x29) != '\0') break;
      do {
        plVar4 = plVar2;
        plVar2 = (longlong *)*plVar4;
      } while (*(char *)(*plVar4 + 0x29) == '\0');
    }
    do {
      plVar4 = (longlong *)plVar5[1];
      if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
      bVar7 = plVar5 == (longlong *)plVar4[2];
      plVar5 = plVar4;
    } while (bVar7);
  } while( true );
}

// ==== CRoleManager::helper_1402f8b50  @1402f8b50  [medium:callgraph-r0]  (orig: FUN_1402f8b50)
longlong * FUN_1402f8b50(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402f8cad:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402f8cdc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402f8cad;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402f7950(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402f8cdc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CRoleManager::helper_1402f8d00  @1402f8d00  [medium:callgraph-r0]  (orig: FUN_1402f8d00)
longlong FUN_1402f8d00(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1402f6d10(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1402f7740(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CRoleManager::helper_1402f8e40  @1402f8e40  [medium:callgraph-r0]  (orig: FUN_1402f8e40)
longlong * FUN_1402f8e40(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CRoleManager::vfunc_27  @1402f9040  [high:rtti-vtable]  (orig: FUN_1402f9040)
void FUN_1402f9040(longlong param_1,longlong *param_2,char param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 local_38 [2];
  longlong *local_30;
  undefined1 local_28 [32];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar1 = (**(code **)(*param_2 + 8))(param_2);
  local_38[0] = uVar1;
  local_30 = param_2;
  FUN_1402f8b50(param_1 + 0x98,local_28,local_38);
  if (param_3 != '\0') {
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      uVar2 = (**(code **)(*(longlong *)param_2[0xc] + 8))();
    }
    local_38[0] = uVar1;
    local_30 = param_2;
    FUN_1402f8b50(param_1 + 0x18,local_28,local_38);
    local_38[0] = uVar2;
    local_30 = param_2;
    FUN_1402f8b50(param_1 + 0x58,local_28,local_38);
  }
  return;
}

// ==== CRoleManager::vfunc_28  @1402f9160  [high:rtti-vtable]  (orig: FUN_1402f9160)
void FUN_1402f9160(longlong param_1,longlong *param_2)

{
  undefined4 local_res10 [2];
  undefined4 local_res18 [4];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
    if ((char)param_2[0xd] == '\0') {
      FUN_1402f8d00(param_1 + 0x98,local_res10);
    }
    else {
      if (param_2[0xc] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        local_res18[0] = 0;
      }
      else {
        local_res18[0] = (**(code **)(*(longlong *)param_2[0xc] + 8))();
      }
      FUN_1402f8d00(param_1 + 0x18,local_res10);
      FUN_1402f8d00(param_1 + 0x58,local_res18);
      FUN_1402f8d00(param_1 + 0x98,local_res10);
    }
  }
  return;
}

// ==== CRoleManager::vfunc_17  @1402f9250  [high:rtti-vtable]  (orig: FUN_1402f9250)
undefined8 FUN_1402f9250(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x88);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x88);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x58) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x88);
    local_28 = *(longlong *)(param_1 + 0x58);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x88);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CRoleManager::vfunc_8  @1402f9360  [high:rtti-vtable]  (orig: FUN_1402f9360)
undefined8
FUN_1402f9360(longlong param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
             char *param_5,undefined4 *param_6,undefined4 *param_7,undefined4 *param_8,
             undefined4 *param_9)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  char *_Source;
  ulonglong uVar8;
  ulonglong uVar9;
  undefined4 local_res10 [2];
  ulonglong *local_50;
  longlong local_48;
  ulonglong *local_40;
  
  local_res10[0] = param_2;
  FUN_1402f8e40(param_1 + 0x58,&local_50,local_res10);
  lVar7 = *(longlong *)(param_1 + 0x88);
  uVar8 = 0;
  local_40 = *(ulonglong **)(param_1 + 0x58);
  if ((local_50 == (ulonglong *)0x0) || (local_50 != local_40)) {
    _invalid_parameter_noinfo();
  }
  if (local_48 == lVar7) {
    uVar5 = 0;
  }
  else {
    if (local_50 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar9 = uVar8;
    }
    else {
      uVar9 = *local_50;
    }
    if (local_48 == *(longlong *)(uVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = *(longlong *)(local_48 + 0x20);
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = 0;
    }
    else {
      iVar1 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))(*(longlong **)(lVar7 + 0x60),4);
      if (iVar1 == 0x1f) {
        uVar3 = 0;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = uVar3;
        }
        else {
          uVar2 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),1);
        }
        *param_3 = uVar2;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = uVar3;
        }
        else {
          uVar2 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x14);
        }
        *param_4 = uVar2;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = uVar3;
        }
        else {
          uVar2 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x10);
        }
        *param_6 = uVar2;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = uVar3;
        }
        else {
          uVar2 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x15);
        }
        *param_8 = uVar2;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = uVar3;
        }
        else {
          uVar2 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x21);
        }
        *param_7 = uVar2;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar3 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x11);
        }
        *param_9 = uVar3;
        if (*(longlong *)(lVar7 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar4 = (**(code **)(**(longlong **)(lVar7 + 0x60) + 0x10))
                            (*(longlong **)(lVar7 + 0x60),0x13);
          uVar8 = (ulonglong)uVar4;
        }
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        plVar6 = (longlong *)FUN_1400876b0(uVar5);
        lVar7 = (**(code **)(*plVar6 + 0x20))(plVar6,uVar8,0);
        if (lVar7 != 0) {
          _Source = (char *)(**(code **)(**(longlong **)(lVar7 + 0x58) + 0x18))
                                      (*(longlong **)(lVar7 + 0x58),1);
          strncpy(param_5,_Source,0x24);
        }
        uVar5 = 1;
      }
      else {
        uVar5 = 0;
      }
    }
  }
  return uVar5;
}

// ==== CRoleManager::vfunc_9  @1402f96c0  [high:rtti-vtable]  (orig: FUN_1402f96c0)
void FUN_1402f96c0(longlong param_1,int param_2,undefined4 param_3,longlong param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  tm *ptVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined4 *puVar12;
  longlong lVar13;
  longlong *plVar14;
  int local_res10 [2];
  int local_98;
  __time32_t local_94;
  longlong *local_90 [3];
  undefined4 *local_78;
  undefined4 *local_70;
  undefined8 local_68;
  longlong *local_60;
  longlong local_58;
  longlong *local_50;
  longlong *local_40;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  local_res10[0] = param_2;
  FUN_1402f8e40(param_1 + 0x58,&local_60,local_res10);
  lVar13 = *(longlong *)(param_1 + 0x88);
  local_50 = *(longlong **)(param_1 + 0x58);
  if ((local_60 == (longlong *)0x0) || (local_60 != local_50)) {
    _invalid_parameter_noinfo();
  }
  if (local_58 == lVar13) {
    log_InlineLogWARNING("CRoleManager::OccupyFamilyNpc, can not find family npc!");
  }
  else {
    if (local_60 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar13 = 0;
    }
    else {
      lVar13 = *local_60;
    }
    if (local_58 == *(longlong *)(lVar13 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar13 = *(longlong *)(local_58 + 0x20);
    if (lVar13 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar6 = (**(code **)(**(longlong **)(lVar13 + 0x60) + 0x10))(*(longlong **)(lVar13 + 0x60),4);
      if (iVar6 == 0x1f) {
        if ((*(longlong *)(lVar13 + 0x60) == 0) || (*(char *)(lVar13 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar13 + 0x60) + 0x60))
                    (*(longlong **)(lVar13 + 0x60),1,param_3);
        }
        if ((*(longlong *)(lVar13 + 0x60) == 0) || (*(char *)(lVar13 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar13 + 0x60) + 0x60))(*(longlong **)(lVar13 + 0x60),2,4);
        }
        if (param_4 == 0) {
          if ((*(longlong *)(lVar13 + 0x60) == 0) || (*(char *)(lVar13 + 0x68) == '\0')) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            (**(code **)(**(longlong **)(lVar13 + 0x60) + 0x68))
                      (*(longlong **)(lVar13 + 0x60),0x1d,&DAT_1406dd892);
          }
        }
        else if ((*(longlong *)(lVar13 + 0x60) == 0) || (*(char *)(lVar13 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar13 + 0x60) + 0x68))
                    (*(longlong **)(lVar13 + 0x60),0x1d,param_4);
        }
        local_94 = _time32((__time32_t *)0x0);
        local_98 = local_94 + 0x15180;
        ptVar8 = _localtime32(&local_94);
        if (ptVar8 == (tm *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar6 = ptVar8->tm_year;
          iVar1 = ptVar8->tm_mon;
          iVar2 = ptVar8->tm_mday;
          iVar3 = ptVar8->tm_hour;
          iVar4 = ptVar8->tm_min;
          uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          iVar7 = FUN_14008a6c0(uVar9);
          if (iVar3 * 0x3c + iVar4 < iVar7) {
            FUN_1400922d0(lVar13,0x11,(iVar6 * 100 + -9999 + iVar1) * 100 + iVar2,1);
          }
          else {
            ptVar8 = _localtime32(&local_98);
            if (ptVar8 == (tm *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              return;
            }
            FUN_1400922d0(lVar13,0x11,
                          (ptVar8->tm_year * 100 + -9999 + ptVar8->tm_mon) * 100 + ptVar8->tm_mday,1
                         );
          }
          plVar14 = (longlong *)0x0;
          iVar6 = 0;
          if (param_2 == 0x272a) {
            iVar6 = 0x2841;
          }
          else if (param_2 == 0x272c) {
            iVar6 = 0x2845;
          }
          else if (param_2 == 0x272e) {
            iVar6 = 0x2844;
          }
          else if (param_2 == 0x2730) {
            iVar6 = 0x2843;
          }
          else if (param_2 == 0x2732) {
            iVar6 = 0x2842;
          }
          plVar10 = (longlong *)CurrentInstanceGet();
          if (((plVar10 != (longlong *)0x0) && (iVar6 != 0)) &&
             (plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,8),
             plVar10 != (longlong *)0x0)) {
            local_60 = operator_new(8);
            local_90[0] = plVar14;
            if (local_60 != (longlong *)0x0) {
              *local_60 = (longlong)local_90;
              local_90[0] = local_60;
            }
            local_78 = (undefined4 *)0x0;
            local_70 = (undefined4 *)0x0;
            local_68 = 0;
            local_50 = local_60;
            (**(code **)(*plVar10 + 0x1e8))(plVar10,param_3,local_90);
            puVar12 = local_78;
            local_60 = (longlong *)0x0;
            if (local_70 < local_78) {
              _invalid_parameter_noinfo();
            }
            plVar10 = local_90[0];
            local_60 = local_90[0];
            while( true ) {
              puVar5 = local_70;
              local_40 = (longlong *)0x0;
              if (local_70 < local_78) {
                _invalid_parameter_noinfo();
              }
              local_40 = local_90[0];
              if ((plVar10 == (longlong *)0x0) || (plVar10 != local_90[0])) {
                _invalid_parameter_noinfo();
              }
              if (puVar12 == puVar5) break;
              if (plVar10 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar11 = plVar14;
              }
              else {
                plVar11 = (longlong *)*plVar10;
              }
              if ((undefined4 *)plVar11[4] <= puVar12) {
                _invalid_parameter_noinfo();
              }
              plVar11 = DAT_140975b68;
              if (DAT_140975b68 == (longlong *)0x0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar11 = plVar14;
              }
              FUN_1401143f0(plVar11,*puVar12,iVar6);
              if (plVar10 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar11 = plVar14;
              }
              else {
                plVar11 = (longlong *)*plVar10;
              }
              if ((undefined4 *)plVar11[4] <= puVar12) {
                _invalid_parameter_noinfo();
              }
              puVar12 = puVar12 + 1;
            }
            if (local_78 != (undefined4 *)0x0) {
              operator_delete(local_78);
            }
            local_78 = (undefined4 *)0x0;
            local_70 = (undefined4 *)0x0;
            local_68 = 0;
            operator_delete(local_90[0]);
          }
        }
      }
      else {
        log_InlineLogWARNING("CRoleManager::OccupyFamilyNpc, can not find family npc!");
      }
    }
  }
  return;
}

// ==== CRoleManager::vfunc_10  @1402f9c30  [high:rtti-vtable]  (orig: FUN_1402f9c30)
void FUN_1402f9c30(longlong param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  int iVar6;
  int iVar7;
  tm *ptVar8;
  undefined8 uVar9;
  longlong lVar10;
  undefined4 local_res10 [2];
  __time32_t local_res18 [2];
  int local_res20 [2];
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  
  local_res10[0] = param_2;
  FUN_1402f8e40(param_1 + 0x58,&local_50,local_res10);
  lVar5 = *(longlong *)(param_1 + 0x88);
  lVar10 = 0;
  local_40 = *(longlong **)(param_1 + 0x58);
  if ((local_50 == (longlong *)0x0) || (local_50 != local_40)) {
    _invalid_parameter_noinfo();
  }
  if (local_48 == lVar5) {
    log_InlineLogWARNING("CRoleManager::AbandonFamilyNpc, can not find family npc!");
  }
  else {
    if (local_50 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar10 = *local_50;
    }
    if (local_48 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar5 = *(longlong *)(local_48 + 0x20);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar6 = (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x10))(*(longlong **)(lVar5 + 0x60),4);
      if (iVar6 == 0x1f) {
        if ((*(longlong *)(lVar5 + 0x60) == 0) || (*(char *)(lVar5 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x60))(*(longlong **)(lVar5 + 0x60),1);
        }
        if ((*(longlong *)(lVar5 + 0x60) == 0) || (*(char *)(lVar5 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x60))(*(longlong **)(lVar5 + 0x60),2);
        }
        if ((*(longlong *)(lVar5 + 0x60) == 0) || (*(char *)(lVar5 + 0x68) == '\0')) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x68))
                    (*(longlong **)(lVar5 + 0x60),0x1d,&DAT_1406dd892);
        }
        local_res18[0] = _time32((__time32_t *)0x0);
        local_res20[0] = local_res18[0] + 0x15180;
        ptVar8 = _localtime32(local_res18);
        if (ptVar8 == (tm *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          iVar6 = ptVar8->tm_hour;
          iVar1 = ptVar8->tm_year;
          iVar2 = ptVar8->tm_mon;
          iVar3 = ptVar8->tm_mday;
          iVar4 = ptVar8->tm_min;
          uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          iVar7 = FUN_14008a6c0(uVar9);
          if (iVar6 * 0x3c + iVar4 < iVar7) {
            if ((*(longlong *)(lVar5 + 0x60) == 0) || (*(char *)(lVar5 + 0x68) == '\0')) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x60))
                        (*(longlong **)(lVar5 + 0x60),0x10,
                         ((iVar1 * 100 + -9999 + iVar2) * 100 + iVar3) * 100 + iVar6);
            }
          }
          else {
            ptVar8 = _localtime32(local_res20);
            if (ptVar8 == (tm *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              return;
            }
            if ((*(longlong *)(lVar5 + 0x60) == 0) || (*(char *)(lVar5 + 0x68) == '\0')) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              (**(code **)(**(longlong **)(lVar5 + 0x60) + 0x60))
                        (*(longlong **)(lVar5 + 0x60),0x10,
                         ((ptVar8->tm_year * 100 + -9999 + ptVar8->tm_mon) * 100 + ptVar8->tm_mday)
                         * 100);
            }
          }
          FUN_1400922d0(lVar5,0x11,0,1);
        }
      }
      else {
        log_InlineLogWARNING("CRoleManager::AbandonFamilyNpc, can not find family npc!");
      }
    }
  }
  return;
}

// ==== CRoleManager::vfunc_11  @1402f9fc0  [high:rtti-vtable]  (orig: FUN_1402f9fc0)
void FUN_1402f9fc0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  int iVar2;
  longlong lVar3;
  undefined4 local_res10 [2];
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  
  local_res10[0] = param_2;
  FUN_1402f8e40((longlong *)(param_1 + 0x58),&local_40,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x88);
  lVar3 = 0;
  local_30 = *(longlong **)(param_1 + 0x58);
  if ((local_40 == (longlong *)0x0) || (local_40 != local_30)) {
    _invalid_parameter_noinfo();
  }
  if (local_38 == lVar1) {
    log_InlineLogWARNING("CRoleManager::SetFamilyNpcHarvestDate, can not find family npc!");
  }
  else {
    if (local_40 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar3 = *local_40;
    }
    if (local_38 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *(longlong *)(local_38 + 0x20);
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar2 = (**(code **)(**(longlong **)(lVar1 + 0x60) + 0x10))(*(longlong **)(lVar1 + 0x60),4);
      if (iVar2 == 0x1f) {
        FUN_1400922d0(lVar1,0x21,param_3,1);
      }
      else {
        log_InlineLogWARNING("CRoleManager::SetFamilyNpcHarvestDate, can not find family npc!");
      }
    }
  }
  return;
}

// ==== CRoleManager::ctor_or_dtor  @1402fa270  [high:vtable-assign]  (orig: FUN_1402fa270)
void FUN_1402fa270(undefined8 *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  
  *param_1 = CRoleManager::vftable;
  puVar1 = param_1 + 3;
  FUN_1402f6850(puVar1);
  puVar2 = param_1 + 0xb;
  FUN_1402f6850(puVar2);
  puVar3 = param_1 + 0x13;
  FUN_1402f6850(puVar3);
  if ((longlong *)param_1[1] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[1] + 8))();
    param_1[1] = 0;
  }
  FUN_1402f7c90(puVar3);
  operator_delete((void *)*puVar3);
  FUN_1402f7c90(puVar2);
  operator_delete((void *)*puVar2);
  FUN_1402f7c90(puVar1);
  operator_delete((void *)*puVar1);
  *param_1 = IRoleManager::vftable;
  return;
}

// ==== CRoleManager::vfunc_4  @1402fa340  [high:rtti-vtable]  (orig: FUN_1402fa340)
void FUN_1402fa340(longlong *param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(*param_1 + 0x30))();
                    /* WARNING: Could not recover jumptable at 0x0001402fa35b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,param_2);
  return;
}

// ==== CRoleManager::vfunc_6  @1402fa360  [high:rtti-vtable]  (orig: FUN_1402fa360)
undefined8 FUN_1402fa360(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 8);
  }
  return *(undefined8 *)(param_1 + 8);
}

// ==== CRoleManager::vfunc_24  @1402fa3b0  [high:rtti-vtable]  (orig: FUN_1402fa3b0)
void FUN_1402fa3b0(longlong *param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(*param_1 + 0x30))();
                    /* WARNING: Could not recover jumptable at 0x0001402fa3cb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2);
  return;
}

// ==== CRoleManager::vfunc_1  @1402fa3d0  [high:rtti-vtable]  (orig: FUN_1402fa3d0)
void FUN_1402fa3d0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CRoleManager::helper_1402fa3f0  @1402fa3f0  [medium:callgraph-r0]  (orig: FUN_1402fa3f0)
undefined8 * FUN_1402fa3f0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402f6260(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRoleManager::helper_1402fa4a0  @1402fa4a0  [medium:callgraph-r0]  (orig: FUN_1402fa4a0)
undefined8 * FUN_1402fa4a0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402f6720(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CRoleManager::vfunc_0  @1402fa520  [high:rtti-vtable]  (orig: FUN_1402fa520)
undefined8 FUN_1402fa520(undefined8 param_1,uint param_2)

{
  FUN_1402fa270();
  if ((param_2 & 1) != 0) {
    FUN_1402f5a50(param_1);
  }
  return param_1;
}

// ==== CRoleManager::vfunc_2  @1402fa550  [high:rtti-vtable]  (orig: FUN_1402fa550)
void FUN_1402fa550(longlong param_1,int param_2)

{
  undefined4 *puVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  longlong lVar8;
  longlong *local_res18;
  longlong *local_res20;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined8 uStack_90;
  longlong *local_88 [3];
  undefined4 *local_70;
  undefined4 *local_68;
  undefined8 local_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  local_res18 = operator_new(8);
  if (local_res18 == (longlong *)0x0) {
    local_88[0] = (longlong *)0x0;
  }
  else {
    *local_res18 = (longlong)local_88;
    local_88[0] = local_res18;
  }
  local_70 = (undefined4 *)0x0;
  local_68 = (undefined4 *)0x0;
  local_60 = 0;
  local_res20 = local_res18;
  (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),&local_98);
  while( true ) {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x18))
                       (*(longlong **)(param_1 + 8),local_40);
    if ((CONCAT44(uStack_94,local_98) == 0) || (CONCAT44(uStack_94,local_98) != *plVar5)) {
      _invalid_parameter_noinfo();
    }
    puVar7 = local_70;
    if (uStack_90 == (longlong *)plVar5[1]) break;
    local_58 = local_98;
    uStack_54 = uStack_94;
    uStack_50 = (undefined4)uStack_90;
    uStack_4c = uStack_90._4_4_;
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x20))
                       (*(longlong **)(param_1 + 8),&local_58);
    if (CONCAT44(uStack_94,local_98) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_90 + 0x29) == '\0') {
      plVar6 = (longlong *)uStack_90[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar6 + 0x29);
        uStack_90 = plVar6;
        plVar6 = (longlong *)*plVar6;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar6 + 0x29);
          uStack_90 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      else {
        cVar3 = *(char *)(uStack_90[1] + 0x29);
        plVar2 = (longlong *)uStack_90[1];
        plVar6 = uStack_90;
        while ((uStack_90 = plVar2, cVar3 == '\0' && (plVar6 == (longlong *)uStack_90[2]))) {
          cVar3 = *(char *)(uStack_90[1] + 0x29);
          plVar2 = (longlong *)uStack_90[1];
          plVar6 = uStack_90;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    if (plVar5 != (longlong *)0x0) {
      (**(code **)(*plVar5 + 0x10))(plVar5);
      plVar6 = (longlong *)(**(code **)(*plVar5 + 0x2a0))(plVar5);
      if (plVar6 != (longlong *)0x0) {
        (**(code **)(*plVar6 + 0x18))(plVar6);
      }
      (**(code **)(*plVar5 + 0x360))(plVar5,(longlong)param_2);
      cVar3 = (**(code **)(*plVar5 + 0x248))(plVar5);
      if (cVar3 != '\0') {
        iVar4 = (**(code **)(*plVar5 + 0x10))(plVar5);
        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,iVar4);
        if (iVar4 != 0) {
          FUN_140037fe0(local_88,&local_res18);
        }
      }
    }
  }
  plVar5 = local_88[0];
  if (local_68 < local_70) {
    _invalid_parameter_noinfo();
    plVar5 = local_88[0];
  }
  while( true ) {
    puVar1 = local_68;
    if (local_68 < local_70) {
      _invalid_parameter_noinfo();
    }
    if ((plVar5 == (longlong *)0x0) || (plVar5 != local_88[0])) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 == puVar1) break;
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar5;
    }
    if (*(undefined4 **)(lVar8 + 0x20) <= puVar7) {
      _invalid_parameter_noinfo();
    }
    (**(code **)(**(longlong **)(param_1 + 8) + 0x30))(*(longlong **)(param_1 + 8),*puVar7);
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar5;
    }
    if (*(undefined4 **)(lVar8 + 0x20) <= puVar7) {
      _invalid_parameter_noinfo();
    }
    puVar7 = puVar7 + 1;
  }
  if (local_70 != (undefined4 *)0x0) {
    operator_delete(local_70);
  }
  local_70 = (undefined4 *)0x0;
  local_68 = (undefined4 *)0x0;
  local_60 = 0;
  operator_delete(local_88[0]);
  return;
}

// ==== CRoleManager::vfunc_25  @1402fa820  [high:rtti-vtable]  (orig: FUN_1402fa820)
void FUN_1402fa820(longlong param_1,int param_2,int param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  bool bVar7;
  undefined4 local_58 [2];
  longlong *local_50;
  undefined8 local_48;
  longlong *local_40;
  longlong *local_30;
  
  local_48 = 0xfffffffffffffffe;
  if ((param_2 == 0) || (param_3 < 1)) {
    log_InlineLogERROR("Invalid map(%d) or npcType(%d)");
  }
  else {
    FUN_140036640(param_4);
    plVar4 = (longlong *)**(undefined8 **)(param_1 + 200);
    plVar1 = *(longlong **)(param_1 + 0x98);
    local_40 = plVar1;
LAB_1402fa890:
    plVar5 = *(longlong **)(param_1 + 200);
    local_30 = *(longlong **)(param_1 + 0x98);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 != plVar5) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5 = (longlong *)plVar4[4];
      if (((plVar5 != (longlong *)0x0) &&
          (iVar3 = (**(code **)(plVar5[2] + 0x168))(), iVar3 == param_2)) &&
         (iVar3 = (**(code **)(*(longlong *)plVar5[0xc] + 0x10))((longlong *)plVar5[0xc],4),
         iVar3 == param_3)) {
        local_58[0] = (**(code **)(*plVar5 + 8))(plVar5);
        FUN_140037fe0(param_4,local_58);
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        plVar5 = plVar4;
        plVar2 = (longlong *)plVar4[2];
        if (*(char *)(plVar4[2] + 0x29) == '\0') {
          do {
            plVar4 = plVar2;
            plVar2 = (longlong *)*plVar4;
            local_50 = plVar4;
          } while (*(char *)(*plVar4 + 0x29) == '\0');
        }
        else {
          do {
            plVar4 = (longlong *)plVar5[1];
            if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
            bVar7 = plVar5 == (longlong *)plVar4[2];
            plVar5 = plVar4;
          } while (bVar7);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1402fa890;
    }
  }
  return;
}

// ==== CRoleManager::ctor_or_dtor  @1402fc120  [high:vtable-assign]  (orig: FUN_1402fc120)
undefined8 * FUN_1402fc120(undefined8 *param_1,undefined4 param_2)

{
  undefined8 *puVar1;
  
  *param_1 = IRoleManager::vftable;
  *param_1 = CRoleManager::vftable;
  *(undefined4 *)(param_1 + 2) = param_2;
  FUN_1402fa3f0(param_1 + 3);
  FUN_1402fa3f0(param_1 + 0xb);
  FUN_1402fa3f0(param_1 + 0x13);
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = ISingleMap<IRole>::vftable;
    *puVar1 = CSingleMap<IRole>::vftable;
    FUN_1402fa4a0(puVar1 + 2);
    *(undefined1 *)(puVar1 + 1) = 1;
  }
  param_1[1] = puVar1;
  return param_1;
}

// ==== CRoleManager::helper_140388b80  @140388b80  [medium:callgraph-r0]  (orig: FUN_140388b80)
void FUN_140388b80(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x30) != 0) {
    FUN_1404cf180();
  }
  return;
}

// ==== CRoleManager::helper_1404cf180  @1404cf180  [medium:callgraph-r1]  (orig: FUN_1404cf180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404cf180(longlong param_1)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined2 *puVar3;
  undefined8 *_Dst;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong lVar7;
  rsize_t rVar8;
  longlong lVar9;
  undefined1 auStack_4f8 [32];
  uint local_4d8;
  undefined2 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 uStack_4a4;
  undefined8 *puStack_4a0;
  undefined4 *local_498;
  longlong local_490;
  undefined8 local_488;
  undefined8 *puStack_480;
  undefined8 local_478;
  undefined8 *puStack_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  puVar1 = *(undefined8 **)(param_1 + 0x20);
  local_490 = param_1;
  if (*(undefined8 **)(param_1 + 0x28) < puVar1) {
    _invalid_parameter_noinfo();
  }
  plVar6 = *(longlong **)(param_1 + 8);
  lVar9 = 0;
  puStack_4a0 = puVar1;
  while( true ) {
    _Dst = puStack_4a0;
    puVar1 = *(undefined8 **)(param_1 + 0x28);
    if (puVar1 < *(undefined8 **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst == puVar1) break;
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar9;
    }
    else {
      lVar7 = *plVar6;
    }
    if (*(undefined8 **)(lVar7 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (undefined4 *)*_Dst;
    local_498 = puVar2;
    if (puVar2 == (undefined4 *)0x0) {
      local_4d8 = 0xbe1;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar7 = *(longlong *)(param_1 + 0x28) - (longlong)(_Dst + 1) >> 3;
      if (0 < lVar7) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,_Dst + 1,rVar8);
      }
      *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -8;
      if ((_Dst < *(undefined8 **)(param_1 + 0x20)) || (*(undefined8 **)(param_1 + 0x28) < _Dst)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(param_1 + 8);
      local_488._0_4_ = SUB84(plVar6,0);
      local_4a8 = (undefined4)local_488;
      local_488._4_4_ = (undefined4)((ulonglong)plVar6 >> 0x20);
      uStack_4a4 = local_488._4_4_;
      puStack_4a0 = _Dst;
      local_488 = plVar6;
      puStack_480 = _Dst;
    }
    else {
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
      lVar7 = *(longlong *)(lVar5 + 0x100);
      if (*(longlong *)(lVar5 + 0x100) == 0) {
        local_4d8 = 0x144;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar7 = lVar9;
      }
      lVar7 = FUN_1402f0fe0(lVar7,*puVar2,0);
      *(longlong *)(puVar2 + 0x10) = lVar7;
      if (lVar7 == 0) {
        log_InlineLogERROR("CMonsterMagic::Reload: magic %u is not exist");
        if (puVar2 == *(undefined4 **)(param_1 + 0x40)) {
          if (*(longlong *)(param_1 + 0x60) != 0) {
            FUN_14035f2f0(local_458);
            puVar3 = *(undefined2 **)(param_1 + 0x40);
            uVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
            local_4b0 = 0;
            local_4b8 = 0;
            local_4c0 = 0;
            local_4c8 = *puVar3;
            local_4d0 = 0;
            local_4d8 = local_4d8 & 0xffff0000;
            FUN_14035f4c0(local_458,0x36,uVar4,0);
            plVar6 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
            (**(code **)(*plVar6 + 0x348))(plVar6,local_458,1);
            FUN_14035f340(local_458);
          }
          *(undefined8 *)(param_1 + 0x40) = 0;
          *(undefined4 *)(param_1 + 0x4c) = 0;
          *(undefined4 *)(param_1 + 0x48) = 0;
          *(undefined4 *)(param_1 + 0x38) = 0;
          FUN_14009ce90(param_1 + 0x70);
          *(undefined4 *)(param_1 + 0x68) = 0;
        }
        FUN_1404cd720(&local_498);
        lVar7 = *(longlong *)(param_1 + 0x28) - (longlong)(_Dst + 1) >> 3;
        if (0 < lVar7) {
          rVar8 = lVar7 << 3;
          memmove_s(_Dst,rVar8,_Dst + 1,rVar8);
        }
        *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -8;
        if ((_Dst < *(undefined8 **)(param_1 + 0x20)) || (*(undefined8 **)(param_1 + 0x28) < _Dst))
        {
          _invalid_parameter_noinfo();
        }
        plVar6 = *(longlong **)(param_1 + 8);
        local_478._0_4_ = SUB84(plVar6,0);
        local_478._4_4_ = (undefined4)((ulonglong)plVar6 >> 0x20);
        local_4a8 = (undefined4)local_478;
        uStack_4a4 = local_478._4_4_;
        puStack_4a0 = _Dst;
        local_478 = plVar6;
        puStack_470 = _Dst;
      }
      else {
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = lVar9;
        }
        else {
          lVar7 = *plVar6;
        }
        if (*(undefined8 **)(lVar7 + 0x20) <= _Dst) {
          _invalid_parameter_noinfo();
        }
        puStack_4a0 = _Dst + 1;
      }
    }
  }
  return;
}

