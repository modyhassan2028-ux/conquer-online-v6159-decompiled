// ==== CCompetionActor@adapter::helper_1401ad760  @1401ad760  [medium:callgraph-r0]  (orig: FUN_1401ad760)
undefined8 FUN_1401ad760(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  
  if (*(longlong *)(param_1 + 0x1100) != 0) {
    plVar1 = *(longlong **)(*(longlong *)(*(longlong *)(param_1 + 0x1100) + 0x58) + 8);
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
    uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
    if ((uVar2 >> 0x28 & 1) != 0) {
      return 0;
    }
  }
  uVar3 = FUN_140382f00(param_1,param_2);
  FUN_1401a7e10(param_1,uVar3,0,1);
  return uVar3;
}

// ==== CCompetionActor@adapter::helper_140373040  @140373040  [medium:callgraph-r0]  (orig: FUN_140373040)
undefined4 FUN_140373040(longlong param_1)

{
  return *(undefined4 *)(param_1 + 200);
}

// ==== CCompetionActor@adapter::vfunc_1  @1405b3a60  [high:rtti-vtable]  (orig: FUN_1405b3a60)
void FUN_1405b3a60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_0  @1405b3ad0  [high:rtti-vtable]  (orig: FUN_1405b3ad0)
undefined8 FUN_1405b3ad0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b3af2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CCompetionActor@adapter::vfunc_8  @1405b3b00  [high:rtti-vtable]  (orig: FUN_1405b3b00)
int FUN_1405b3b00(void)

{
  int *piVar1;
  
  piVar1 = tq::CQLanguageGet();
  return *piVar1;
}

// ==== CCompetionActor@adapter::vfunc_1  @1405b3b20  [high:rtti-vtable]  (orig: FUN_1405b3b20)
undefined8 FUN_1405b3b20(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140373040(lVar1 + 0xe78);
    return uVar2;
  }
  return 0;
}

// ==== CCompetionActor@adapter::vfunc_2  @1405b3b50  [high:rtti-vtable]  (orig: FUN_1405b3b50)
void FUN_1405b3b50(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1401a6420(lVar1,0x28,param_3,1);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_6  @1405b3b90  [high:rtti-vtable]  (orig: FUN_1405b3b90)
void FUN_1405b3b90(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140170e90(lVar1,0x2788);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_7  @1405b3bc0  [high:rtti-vtable]  (orig: FUN_1405b3bc0)
void FUN_1405b3bc0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_1401ad760(lVar1,param_3);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_5  @1405b3bf0  [high:rtti-vtable]  (orig: FUN_1405b3bf0)
void FUN_1405b3bf0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140167b70(lVar1);
  return;
}

// ==== CCompetionActor@adapter::vfunc_9  @1405b3c20  [high:rtti-vtable]  (orig: FUN_1405b3c20)
undefined8 FUN_1405b3c20(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b3c42. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CCompetionActor@adapter::vfunc_11  @1405b3c50  [high:rtti-vtable]  (orig: FUN_1405b3c50)
void FUN_1405b3c50(longlong param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 != (longlong *)0x0) {
    (**(code **)(*plVar1 + 0x150))(plVar1,param_5,param_3,param_4);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_15  @1405b3ca0  [high:rtti-vtable]  (orig: FUN_1405b3ca0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b3ca0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_3 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar5 != 0) {
      plVar1 = (longlong *)(lVar5 + 0x10);
      plVar6 = (longlong *)(**(code **)(*plVar1 + 0x160))(plVar1);
      if (plVar6 != (longlong *)0x0) {
        FUN_14015b240();
        local_498 = 1;
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = 0;
        local_4b8 = 2000;
        local_4c0 = 0xffffff;
        local_4c8 = 0;
        iVar2 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_3);
        if (iVar2 != 0) {
          lVar5 = *plVar6;
          uVar3 = (**(code **)(*plVar1 + 0x48))(plVar1);
          uVar4 = (**(code **)(*plVar1 + 0x40))(plVar1);
          (**(code **)(lVar5 + 0x28))(plVar6,uVar4,uVar3,local_478);
        }
        FUN_14015b2c0(local_478);
      }
    }
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_18  @1405b3dc0  [high:rtti-vtable]  (orig: FUN_1405b3dc0)
void FUN_1405b3dc0(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CCompetionActor@adapter::vfunc_0  @1405b3dd0  [high:rtti-vtable]  (orig: FUN_1405b3dd0)
void FUN_1405b3dd0(longlong param_1)

{
  FUN_1405b3e30(param_1 + -8);
  return;
}

// ==== CCompetionActor@adapter::helper_1405b3e30  @1405b3e30  [medium:callgraph-r0]  (orig: FUN_1405b3e30)
undefined8 * FUN_1405b3e30(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CCompetionActor::vftable;
  param_1[1] = adapter::CCompetionActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCompetionActor@adapter::vfunc_10  @1405b3e80  [high:rtti-vtable]  (orig: FUN_1405b3e80)
void FUN_1405b3e80(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140261720(lVar1,param_2,0x10);
  return;
}

// ==== CCompetionActor@adapter::vfunc_12  @1405b3ee0  [high:rtti-vtable]  (orig: FUN_1405b3ee0)
void FUN_1405b3ee0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_13  @1405b3fb0  [high:rtti-vtable]  (orig: FUN_1405b3fb0)
void FUN_1405b3fb0(longlong param_1,longlong param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar1 + 0x60))(plVar1,param_2,0,0,param_3,param_4);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_16  @1405b4010  [high:rtti-vtable]  (orig: FUN_1405b4010)
void FUN_1405b4010(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(ushort *)(param_2 + 8) - 4,0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 0x68))(plVar2,puVar1,0xffffffff);
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_14  @1405b4090  [high:rtti-vtable]  (orig: FUN_1405b4090)
void FUN_1405b4090(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 uVar7;
  
  uVar7 = 0xfffffffffffffffe;
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 != 0) {
    plVar1 = (longlong *)(lVar4 + 0x10);
    plVar5 = (longlong *)(**(code **)(*plVar1 + 0x160))(plVar1);
    if (plVar5 != (longlong *)0x0) {
      puVar6 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar4 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(ushort *)(param_3 + 8) - 4,0,uVar7);
      if (puVar6 != (undefined8 *)0x0) {
        lVar4 = *plVar5;
        uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
        uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
        (**(code **)(lVar4 + 0x28))(plVar5,uVar3,uVar2,puVar6);
        (**(code **)*puVar6)(puVar6,1);
      }
    }
  }
  return;
}

// ==== CCompetionActor@adapter::vfunc_3  @1405b4180  [high:rtti-vtable]  (orig: FUN_1405b4180)
void FUN_1405b4180(longlong param_1,longlong *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  longlong *plVar3;
  char cVar4;
  longlong lVar5;
  ulonglong uVar6;
  longlong lVar7;
  undefined4 local_res8 [2];
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined1 local_38 [8];
  undefined1 local_30 [24];
  longlong *local_18;
  longlong *local_10;
  
  FUN_1402ac340(*(undefined8 *)(param_1 + 0x10),local_38);
LAB_1405b41b2:
  while( true ) {
    do {
      do {
        cVar4 = FUN_1400ce310(local_30);
        while( true ) {
          if (cVar4 == '\0') {
            return;
          }
          cVar4 = (**(code **)(*local_18 + 0x298))(local_18,0x1001,&local_10);
          if (cVar4 != '\0') break;
          cVar4 = FUN_1400ce310(local_30);
        }
        if (local_10 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        cVar4 = FUN_140167b70(local_10);
      } while (cVar4 != '\0');
      if (local_10 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    } while ((char)local_10[0x259] != '\0');
    local_res8[0] = (**(code **)(*local_10 + 8))();
    puVar1 = (undefined4 *)param_2[3];
    if (puVar1 == (undefined4 *)0x0) {
      uVar6 = 0;
    }
    else {
      uVar6 = param_2[5] - (longlong)puVar1 >> 2;
    }
    puVar2 = (undefined4 *)param_2[4];
    if (uVar6 <= (ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2)) break;
    *puVar2 = local_res8[0];
    param_2[4] = (longlong)(puVar2 + 1);
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  uVar6 = param_2[3];
  lVar5 = *param_2;
  if ((param_2[4] - uVar6 & 0xfffffffffffffffc) == 0) {
    lVar7 = 0;
  }
  else {
    if ((ulonglong)param_2[4] < uVar6) {
      _invalid_parameter_noinfo();
    }
    if ((lVar5 == 0) || (lVar5 != *param_2)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = (longlong)((longlong)puVar2 - uVar6) >> 2;
  }
  local_58 = (undefined4)lVar5;
  uStack_54 = (undefined4)((ulonglong)lVar5 >> 0x20);
  uStack_50 = SUB84(puVar2,0);
  uStack_4c = (undefined4)((ulonglong)puVar2 >> 0x20);
  local_48 = local_58;
  uStack_44 = uStack_54;
  uStack_40 = uStack_50;
  uStack_3c = uStack_4c;
  FUN_140036c20(param_2,&local_48,1,local_res8);
  uVar6 = param_2[3];
  if ((ulonglong)param_2[4] < uVar6) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_2;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar3;
  }
  uVar6 = uVar6 + lVar7 * 4;
  if (uVar6 <= *(ulonglong *)(lVar5 + 0x20)) goto code_r0x0001405b438f;
  goto LAB_1405b43a5;
code_r0x0001405b438f:
  if (plVar3 == (longlong *)0x0) {
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar3;
  }
  if (uVar6 < *(ulonglong *)(lVar5 + 0x18)) {
LAB_1405b43a5:
    _invalid_parameter_noinfo();
  }
  goto LAB_1405b41b2;
}

// ==== CCompetionActor@adapter::vfunc_4  @1405b43b0  [high:rtti-vtable]  (orig: FUN_1405b43b0)
void FUN_1405b43b0(longlong param_1,undefined8 param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *local_res8;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined1 local_88 [8];
  undefined1 local_80 [24];
  longlong *local_68;
  longlong local_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 local_38;
  
  local_38 = 0xfffffffffffffffe;
  FUN_1402ac340(*(undefined8 *)(param_1 + 0x10),local_88);
  local_res8 = operator_new(8);
  plVar5 = (longlong *)0x0;
  local_b8[0] = plVar5;
  if (local_res8 != (longlong *)0x0) {
    *local_res8 = (longlong)local_b8;
    local_b8[0] = local_res8;
  }
  local_a0 = (undefined4 *)0x0;
  local_98 = (undefined4 *)0x0;
  local_90 = 0;
LAB_1405b4430:
  while( true ) {
    do {
      do {
        cVar3 = FUN_1400ce310(local_80);
        while( true ) {
          if (cVar3 == '\0') {
            local_60 = 0;
            plVar5 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
            (**(code **)(*plVar5 + 0x38))(plVar5,local_b8,param_2);
            if (local_a0 != (undefined4 *)0x0) {
              operator_delete(local_a0);
            }
            local_a0 = (undefined4 *)0x0;
            local_98 = (undefined4 *)0x0;
            local_90 = 0;
            operator_delete(local_b8[0]);
            return;
          }
          cVar3 = (**(code **)(*local_68 + 0x298))(local_68,0x1001,&local_60);
          if (cVar3 != '\0') break;
          cVar3 = FUN_1400ce310(local_80);
        }
        if (local_60 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        cVar3 = FUN_140167b70(local_60);
      } while (cVar3 != '\0');
      if (local_60 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      puVar2 = local_98;
    } while (*(char *)(local_60 + 0x12c8) != '\0');
    local_res8 = (longlong *)CONCAT44(local_res8._4_4_,*(undefined4 *)(local_60 + 0x122c));
    plVar6 = plVar5;
    if (local_a0 != (undefined4 *)0x0) {
      plVar6 = (longlong *)(local_90 - (longlong)local_a0 >> 2);
    }
    if (plVar6 <= (longlong *)((longlong)local_98 - (longlong)local_a0 >> 2)) break;
    *local_98 = *(undefined4 *)(local_60 + 0x122c);
    local_98 = local_98 + 1;
  }
  if (local_98 < local_a0) {
    _invalid_parameter_noinfo();
  }
  puVar1 = local_a0;
  plVar6 = local_b8[0];
  local_58 = local_b8[0];
  uStack_50 = puVar2;
  plVar7 = plVar5;
  if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) != 0) {
    if (local_98 < local_a0) {
      _invalid_parameter_noinfo();
    }
    if ((plVar6 == (longlong *)0x0) || (plVar6 != local_b8[0])) {
      _invalid_parameter_noinfo();
    }
    plVar7 = (longlong *)((longlong)puVar2 - (longlong)puVar1 >> 2);
  }
  local_48 = (undefined4)local_58;
  uStack_44 = local_58._4_4_;
  uStack_40 = (undefined4)uStack_50;
  uStack_3c = uStack_50._4_4_;
  FUN_140036c20(local_b8,&local_48,1,&local_res8);
  puVar2 = local_a0;
  if (local_98 < local_a0) {
    _invalid_parameter_noinfo();
  }
  plVar6 = local_b8[0];
  if (local_b8[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar4 = plVar5;
  }
  else {
    plVar4 = (longlong *)*local_b8[0];
  }
  if (puVar2 + (longlong)plVar7 <= (undefined4 *)plVar4[4]) goto code_r0x0001405b462e;
  goto LAB_1405b4645;
code_r0x0001405b462e:
  plVar4 = plVar5;
  if (plVar6 != (longlong *)0x0) {
    plVar4 = (longlong *)*plVar6;
  }
  if (puVar2 + (longlong)plVar7 < (undefined4 *)plVar4[3]) {
LAB_1405b4645:
    _invalid_parameter_noinfo();
  }
  goto LAB_1405b4430;
}

// ==== CCompetionActor@adapter::vfunc_17  @1405b46c0  [high:rtti-vtable]  (orig: FUN_1405b46c0)
void FUN_1405b46c0(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58 [3];
  undefined4 *local_40;
  undefined4 *local_38;
  longlong local_30;
  
  local_res20 = operator_new(8);
  local_58[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_58;
    local_58[0] = local_res20;
  }
  local_40 = (undefined4 *)0x0;
  local_38 = (undefined4 *)0x0;
  local_30 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar6 + 0x38))(plVar6,local_58,param_3);
      if (local_40 != (undefined4 *)0x0) {
        operator_delete(local_40);
      }
      local_40 = (undefined4 *)0x0;
      local_38 = (undefined4 *)0x0;
      local_30 = 0;
      operator_delete(local_58[0]);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),*puVar9);
    puVar2 = local_38;
    if (lVar4 != 0) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar4 + 0x122c));
      if (local_40 != (undefined4 *)0x0) {
        uVar7 = local_30 - (longlong)local_40 >> 2;
      }
      if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar7) {
        *local_38 = *(undefined4 *)(lVar4 + 0x122c);
        local_38 = local_38 + 1;
      }
      else {
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_40;
        plVar6 = local_58[0];
        if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
          lVar4 = 0;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_58[0])) {
            _invalid_parameter_noinfo();
          }
          lVar4 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_78 = SUB84(plVar6,0);
        uStack_74 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_70 = SUB84(puVar2,0);
        uStack_6c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_68 = local_78;
        uStack_64 = uStack_74;
        uStack_60 = uStack_70;
        uStack_5c = uStack_6c;
        FUN_140036c20(local_58,&local_68,1,&local_res20);
        puVar2 = local_40;
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_58[0];
        if (local_58[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_58[0];
        }
        if (puVar2 + lVar4 <= *(undefined4 **)(lVar5 + 0x20)) {
          if (plVar6 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar6;
          }
          if (*(undefined4 **)(lVar5 + 0x18) <= puVar2 + lVar4) goto LAB_1405b48d0;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_1405b48d0:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

