// ==== CWeatherRegion::helper_1402c3d40  @1402c3d40  [medium:callgraph-r0]  (orig: FUN_1402c3d40)
undefined8 FUN_1402c3d40(longlong *param_1,int param_2,int param_3,int param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(*param_1 + 0x10))(param_1,1);
  if ((param_2 == iVar1) && (iVar1 = (**(code **)(*param_1 + 0x10))(param_1,3), iVar1 <= param_3)) {
    iVar1 = (**(code **)(*param_1 + 0x10))(param_1,5);
    iVar2 = (**(code **)(*param_1 + 0x10))(param_1,3);
    if ((param_3 < iVar1 + iVar2) &&
       (iVar1 = (**(code **)(*param_1 + 0x10))(param_1,4), iVar1 <= param_4)) {
      iVar1 = (**(code **)(*param_1 + 0x10))(param_1,6);
      iVar2 = (**(code **)(*param_1 + 0x10))(param_1,4);
      if (param_4 < iVar1 + iVar2) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CWeatherRegion::ctor_or_dtor  @1404719c0  [high:vtable-assign]  (orig: FUN_1404719c0)
void FUN_1404719c0(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  *param_1 = CWeatherRegion::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CWeatherRegion::helper_140471c10  @140471c10  [medium:callgraph-r0]  (orig: FUN_140471c10)
void FUN_140471c10(void *param_1)

{
  if ((DAT_140976478 & 1) == 0) {
    DAT_140976478 = DAT_140976478 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976470,"CWeatherRegion");
    atexit((_func_5014 *)&LAB_1406d6e80);
  }
                    /* WARNING: Could not recover jumptable at 0x000140471c65. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976470,param_1);
  return;
}

// ==== CWeatherRegion::ctor_or_dtor  @140471cd0  [high:vtable-assign]  (orig: FUN_140471cd0)
undefined8 * FUN_140471cd0(undefined8 *param_1)

{
  *param_1 = CWeatherRegion::vftable;
  param_1[1] = 0;
  param_1[2] = 0;
  return param_1;
}

// ==== CWeatherRegion::ctor_or_dtor  @140471cf0  [high:vtable-assign]  (orig: FUN_140471cf0)
undefined8 * FUN_140471cf0(undefined8 *param_1,uint param_2)

{
  undefined8 *puVar1;
  
  *param_1 = CWeatherRegion::vftable;
  puVar1 = (undefined8 *)param_1[1];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  if ((param_2 & 1) != 0) {
    FUN_140471c10(param_1);
  }
  return param_1;
}

// ==== CWeatherRegion::vfunc_0  @140471d40  [high:rtti-vtable]  (orig: FUN_140471d40)
void FUN_140471d40(longlong param_1,undefined8 param_2,longlong *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  uint uVar13;
  longlong *plVar15;
  longlong *local_res8;
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  undefined1 local_98 [8];
  undefined1 local_90 [24];
  longlong *local_78;
  longlong *local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  longlong *plVar14;
  
  local_48 = 0xfffffffffffffffe;
  lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar9 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar9 + 0x90),local_98);
  plVar11 = (longlong *)0x0;
  local_res8 = operator_new(8);
  local_c8[0] = plVar11;
  if (local_res8 != (longlong *)0x0) {
    *local_res8 = (longlong)local_c8;
    local_c8[0] = local_res8;
  }
  local_b0 = (undefined4 *)0x0;
  local_a8 = (undefined4 *)0x0;
  local_a0 = 0;
  plVar14 = plVar11;
LAB_140471e05:
  do {
    cVar3 = FUN_1400ce310(local_90);
    while( true ) {
      if (cVar3 == '\0') {
        local_70 = (longlong *)0x0;
        goto LAB_14047213d;
      }
      cVar3 = (**(code **)(*local_78 + 0x298))(local_78,0x1001,&local_70);
      if (cVar3 != '\0') break;
      cVar3 = FUN_1400ce310(local_90);
    }
    uVar13 = (int)plVar14 + 1;
    plVar14 = (longlong *)(ulonglong)uVar13;
    if (1000000 < uVar13) {
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_14047213d:
      plVar11 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar11 + 0x40))(plVar11,local_c8,param_2);
      if (local_b0 != (undefined4 *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (undefined4 *)0x0;
      local_a8 = (undefined4 *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      return;
    }
  } while (local_70 == (longlong *)0x0);
  if (param_3 != (longlong *)0x0) goto code_r0x000140471e76;
  goto LAB_140471ea0;
code_r0x000140471e76:
  iVar4 = (**(code **)(*param_3 + 8))(param_3);
  iVar5 = (**(code **)(*local_70 + 8))();
  if (iVar5 != iVar4) {
LAB_140471ea0:
    if (local_70 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar12 = local_70 + 2;
    if (local_70 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar15 = local_70 + 2;
    if (local_70 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar10 = local_70;
    uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
    uVar7 = (**(code **)(*plVar15 + 0x40))(plVar15);
    uVar8 = (**(code **)(plVar10[2] + 0x168))(plVar10 + 2);
    cVar3 = FUN_1402c3d40(*(undefined8 *)(param_1 + 0x10),uVar8,uVar7,uVar6);
    if (cVar3 != '\0') {
      if (local_70 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      puVar2 = local_a8;
      local_res8 = (longlong *)
                   CONCAT44(local_res8._4_4_,*(undefined4 *)((longlong)local_70 + 0x122c));
      plVar12 = plVar11;
      if (local_b0 != (undefined4 *)0x0) {
        plVar12 = (longlong *)(local_a0 - (longlong)local_b0 >> 2);
      }
      if ((longlong *)((longlong)local_a8 - (longlong)local_b0 >> 2) < plVar12) {
        *local_a8 = *(undefined4 *)((longlong)local_70 + 0x122c);
        local_a8 = local_a8 + 1;
        goto LAB_140471e05;
      }
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
      }
      puVar1 = local_b0;
      plVar12 = local_c8[0];
      local_68 = local_c8[0];
      uStack_60 = puVar2;
      plVar15 = plVar11;
      if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) != 0) {
        if (local_a8 < local_b0) {
          _invalid_parameter_noinfo();
        }
        if ((plVar12 == (longlong *)0x0) || (plVar12 != local_c8[0])) {
          _invalid_parameter_noinfo();
        }
        plVar15 = (longlong *)((longlong)puVar2 - (longlong)puVar1 >> 2);
      }
      local_58 = (undefined4)local_68;
      uStack_54 = local_68._4_4_;
      uStack_50 = (undefined4)uStack_60;
      uStack_4c = uStack_60._4_4_;
      FUN_140036c20(local_c8,&local_58,1,&local_res8);
      puVar2 = local_b0;
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
      }
      plVar12 = local_c8[0];
      if (local_c8[0] == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar11;
      }
      else {
        plVar10 = (longlong *)*local_c8[0];
      }
      if (puVar2 + (longlong)plVar15 <= (undefined4 *)plVar10[4]) {
        plVar10 = plVar11;
        if (plVar12 != (longlong *)0x0) {
          plVar10 = (longlong *)*plVar12;
        }
        if ((undefined4 *)plVar10[3] <= puVar2 + (longlong)plVar15) goto LAB_140471e05;
      }
      _invalid_parameter_noinfo();
    }
  }
  goto LAB_140471e05;
}

