// ==== CLuaScript::vfunc_1  @140510dc0  [high:rtti-vtable]  (orig: FUN_140510dc0)
undefined4 FUN_140510dc0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  CSingleLock local_20 [24];
  
  uVar3 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  iVar1 = FUN_1405146d0(*(undefined8 *)(param_1 + 8),param_2,param_3,param_4,0);
  if (iVar1 == 0) {
    iVar1 = FUN_140524b30(*(undefined8 *)(param_1 + 8),0,0xffffffff,0,0,0,uVar3);
    if (iVar1 == 0) {
      CSingleLock::Unlock(local_20);
      uVar2 = 1;
    }
    else {
      CSingleLock::Unlock(local_20);
      uVar2 = 0;
    }
  }
  else {
    CSingleLock::Unlock(local_20);
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CLuaScript::vfunc_2  @140510e90  [high:rtti-vtable]  (orig: FUN_140510e90)
ulonglong FUN_140510e90(longlong param_1,undefined8 param_2)

{
  int iVar1;
  undefined4 extraout_var;
  undefined4 extraout_var_00;
  undefined8 uVar2;
  CSingleLock local_20 [24];
  
  uVar2 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  iVar1 = FUN_140514700(*(undefined8 *)(param_1 + 8),param_2);
  if ((iVar1 == 0) &&
     (iVar1 = FUN_140524b30(*(undefined8 *)(param_1 + 8),0,0xffffffff,0,0,0,uVar2), iVar1 == 0)) {
    iVar1 = CSingleLock::Unlock(local_20);
    return CONCAT71((int7)(CONCAT44(extraout_var,iVar1) >> 8),1);
  }
  log_InlineLogLuaERROR(&DAT_14079ce78);
  log_InlineLogERROR(&DAT_1406d9c10);
  iVar1 = CSingleLock::Unlock(local_20);
  return CONCAT44(extraout_var_00,iVar1) & 0xffffffffffffff00;
}

// ==== CLuaScript::vfunc_3  @140510f60  [high:rtti-vtable]  (orig: FUN_140510f60)
ulonglong FUN_140510f60(longlong param_1,undefined8 param_2)

{
  int iVar1;
  undefined4 extraout_var;
  undefined4 extraout_var_00;
  undefined8 uVar2;
  CSingleLock local_20 [24];
  
  uVar2 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  iVar1 = FUN_1405143c0(*(undefined8 *)(param_1 + 8),param_2,0);
  if ((iVar1 == 0) &&
     (iVar1 = FUN_140524b30(*(undefined8 *)(param_1 + 8),0,0xffffffff,0,0,0,uVar2), iVar1 == 0)) {
    iVar1 = CSingleLock::Unlock(local_20);
    return CONCAT71((int7)(CONCAT44(extraout_var,iVar1) >> 8),1);
  }
  iVar1 = CSingleLock::Unlock(local_20);
  return CONCAT44(extraout_var_00,iVar1) & 0xffffffffffffff00;
}

// ==== CLuaScript::CallScriptFunc  @140510ff0  [high:log-string]  (orig: FUN_140510ff0)
int FUN_140510ff0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  undefined8 uVar2;
  CSingleLock local_20 [24];
  
  uVar2 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  iVar1 = FUN_140524b30(*(undefined8 *)(param_1 + 8),param_2,param_3,0,0,0,uVar2);
  if (iVar1 != 0) {
    FUN_140523460(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    log_InlineLogLuaERROR("CLuaScript::CallScriptFunc(), LuaScript: %s");
  }
  CSingleLock::Unlock(local_20);
  return iVar1;
}

// ==== CLuaScript::helper_140511090  @140511090  [medium:callgraph-r0]  (orig: FUN_140511090)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_140511090(longlong param_1,undefined4 param_2,int param_3,longlong param_4)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  double dVar6;
  undefined8 uVar7;
  CSingleLock local_40 [24];
  
  uVar7 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_40,*(CSyncObject **)(param_1 + 0x10),1);
  _DAT_140976768 = tq::TimeGet(0);
  DAT_140976760 = DAT_140976760 + 1;
  lVar5 = 0;
  iVar1 = FUN_140524b30(*(undefined8 *)(param_1 + 8),param_2,param_3,0,0,0,uVar7);
  DAT_140976760 = DAT_140976760 + 1;
  if (((iVar1 == 0) && (0 < param_3)) && (param_4 != 0)) {
    if (0 < param_3) {
      iVar4 = -1;
      do {
        iVar2 = FUN_140522d70(*(undefined8 *)(param_1 + 8),iVar4);
        if (iVar2 == 0) {
          iVar2 = FUN_140522ba0(*(undefined8 *)(param_1 + 8),iVar4);
          if (iVar2 == 1) {
            uVar3 = FUN_1405233c0(*(undefined8 *)(param_1 + 8),iVar4);
            *(undefined4 *)(param_4 + lVar5 * 4) = uVar3;
          }
        }
        else {
          dVar6 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),iVar4,0);
          *(int *)(param_4 + lVar5 * 4) = (int)dVar6;
        }
        iVar4 = iVar4 + -1;
        lVar5 = lVar5 + 1;
      } while (lVar5 < param_3);
    }
    FUN_140522720(*(undefined8 *)(param_1 + 8),-1 - param_3);
  }
  CSingleLock::Unlock(local_40);
  return iVar1;
}

// ==== CLuaScript::helper_1405111c0  @1405111c0  [medium:callgraph-r0]  (orig: FUN_1405111c0)
void FUN_1405111c0(undefined8 param_1)

{
  FUN_140525910(param_1,0,0,0);
  if (DAT_140976764 == DAT_140976760) {
    FUN_1405139e0(param_1,"script timeout.");
  }
  return;
}

// ==== CLuaScript::vfunc_8  @140511200  [high:rtti-vtable]  (orig: FUN_140511200)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140511200(longlong param_1)

{
  ulong uVar1;
  
  if (((DAT_140976760 & 1) != 0) && (DAT_140976764 != DAT_140976760)) {
    uVar1 = tq::TimeGet(0);
    if (15000 < uVar1 - _DAT_140976768) {
      DAT_140976764 = DAT_140976760;
      FUN_140525910(*(undefined8 *)(param_1 + 8),FUN_1405111c0,0xf);
    }
  }
  return;
}

// ==== CLuaScript::GetInt  @140511260  [high:log-string]  (orig: FUN_140511260)
int FUN_140511260(longlong param_1,undefined8 param_2)

{
  int iVar1;
  double dVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xffffffff);
  if (iVar1 == 0) {
    iVar1 = FUN_140522ba0(*(undefined8 *)(param_1 + 8),0xffffffff);
    if (iVar1 == 1) {
      iVar1 = FUN_1405233c0(*(undefined8 *)(param_1 + 8),0xffffffff);
      FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
      CSingleLock::Unlock(local_20);
    }
    else {
      log_InlineLogLuaERROR("CLuaScript::GetInt(), Invalid var_name in CLuaScript::GetInt(%s)");
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_140522720(*(undefined8 *)(param_1 + 8),0);
      CSingleLock::Unlock(local_20);
      iVar1 = 0;
    }
  }
  else {
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    iVar1 = (int)dVar2;
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
  }
  return iVar1;
}

// ==== CLuaScript::GetStr  @140511380  [high:log-string]  (orig: FUN_140511380)
undefined1 * FUN_140511380(longlong param_1,undefined8 param_2)

{
  int iVar1;
  undefined1 *puVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  iVar1 = FUN_140522e10(*(undefined8 *)(param_1 + 8),0xffffffff);
  if (iVar1 == 0) {
    log_InlineLogLuaERROR("CLuaScript::GetStr(), Invalid var_name in CLuaScript::GetStr(%s)");
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140522720(*(undefined8 *)(param_1 + 8),0);
    CSingleLock::Unlock(local_20);
    puVar2 = &DAT_1406dd892;
  }
  else {
    puVar2 = (undefined1 *)FUN_140523460(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
  }
  return puVar2;
}

// ==== CLuaScript::vfunc_9  @140511460  [high:rtti-vtable]  (orig: FUN_140511460)
int FUN_140511460(longlong param_1,undefined8 param_2,int param_3,int param_4)

{
  int iVar1;
  double dVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_3);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_4);
  FUN_140510ff0(param_1,2,1);
  iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xffffffff);
  if (iVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
    iVar1 = 0;
  }
  else {
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    iVar1 = (int)dVar2;
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
  }
  return iVar1;
}

// ==== CLuaScript::vfunc_11  @140511580  [high:rtti-vtable]  (orig: FUN_140511580)
ulonglong FUN_140511580(longlong param_1,undefined8 param_2,int param_3,int param_4,int *param_5,
                       int *param_6)

{
  int iVar1;
  undefined4 extraout_var;
  undefined4 extraout_var_00;
  double dVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_3);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_4);
  FUN_140510ff0(param_1,2,2);
  iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xffffffff);
  if ((iVar1 != 0) && (iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xfffffffe), iVar1 != 0))
  {
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xfffffffe);
    *param_5 = (int)dVar2;
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    *param_6 = (int)dVar2;
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffd);
    iVar1 = CSingleLock::Unlock(local_20);
    return CONCAT71((int7)(CONCAT44(extraout_var,iVar1) >> 8),1);
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffd);
  iVar1 = CSingleLock::Unlock(local_20);
  return CONCAT44(extraout_var_00,iVar1) & 0xffffffffffffff00;
}

// ==== CLuaScript::vfunc_12  @1405116e0  [high:rtti-vtable]  (orig: FUN_1405116e0)
int FUN_1405116e0(longlong param_1,undefined8 param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  double dVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_3);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_4);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_5);
  FUN_140510ff0(param_1,3,1);
  iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xffffffff);
  if (iVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
    iVar1 = 0;
  }
  else {
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    iVar1 = (int)dVar2;
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
  }
  return iVar1;
}

// ==== CLuaScript::helper_140511810  @140511810  [medium:callgraph-r0]  (orig: FUN_140511810)
undefined8 FUN_140511810(undefined8 param_1)

{
  int iVar1;
  
  iVar1 = FUN_140515720(param_1,1);
  FUN_140523930(param_1,(double)(iVar1 * iVar1));
  return 1;
}

// ==== CLuaScript::vfunc_5  @1405118b0  [high:rtti-vtable]  (orig: FUN_1405118b0)
undefined8 FUN_1405118b0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  CSingleLock local_20 [24];
  
  uVar1 = 0xfffffffffffffffe;
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  FUN_140510ff0(param_1,0,0,param_4,uVar1);
  CSingleLock::Unlock(local_20);
  return 0;
}

// ==== CLuaScript::vfunc_10  @140511910  [high:rtti-vtable]  (orig: FUN_140511910)
int FUN_140511910(longlong param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  double dVar2;
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  FUN_140523c10(*(undefined8 *)(param_1 + 8),param_2);
  FUN_140523930(*(undefined8 *)(param_1 + 8),(double)param_3);
  FUN_140510ff0(param_1,1,1);
  iVar1 = FUN_140522d70(*(undefined8 *)(param_1 + 8),0xffffffff);
  if (iVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_140522720(*(undefined8 *)(param_1 + 8),0);
    CSingleLock::Unlock(local_20);
    iVar1 = 0;
  }
  else {
    dVar2 = (double)FUN_140523240(*(undefined8 *)(param_1 + 8),0xffffffff,0);
    iVar1 = (int)dVar2;
    FUN_140522720(*(undefined8 *)(param_1 + 8),0xfffffffe);
    CSingleLock::Unlock(local_20);
  }
  return iVar1;
}

// ==== CLuaScript::vfunc_6  @140511a10  [high:rtti-vtable]  (orig: FUN_140511a10)
void FUN_140511a10(longlong param_1,longlong param_2,char *param_3)

{
  CSingleLock local_20 [24];
  
  CSingleLock::CSingleLock(local_20,*(CSyncObject **)(param_1 + 0x10),1);
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    CSingleLock::Unlock(local_20);
  }
  else if ((param_3 == (char *)0x0) || (*param_3 == '\0')) {
    log_InlineLogERROR(&DAT_1406d9c10);
    CSingleLock::Unlock(local_20);
  }
  else {
    FUN_140523ad0(*(undefined8 *)(param_1 + 8),param_2,0);
    FUN_140524320(*(undefined8 *)(param_1 + 8),param_3);
    CSingleLock::Unlock(local_20);
  }
  return;
}

// ==== CLuaScript::vfunc_7  @140511b00  [high:rtti-vtable]  (orig: FUN_140511b00)
undefined1 * FUN_140511b00(longlong param_1)

{
  undefined1 *puVar1;
  
  if ((*(longlong *)(param_1 + 8) != 0) &&
     (puVar1 = (undefined1 *)FUN_140523460(*(longlong *)(param_1 + 8),0xffffffff,0),
     puVar1 != (undefined1 *)0x0)) {
    return puVar1;
  }
  return &DAT_1406dd892;
}

// ==== CLuaScript::ctor_or_dtor  @140511b60  [high:vtable-assign]  (orig: FUN_140511b60)
undefined8 * FUN_140511b60(undefined8 *param_1)

{
  int iVar1;
  CSyncObject *this;
  undefined8 uVar2;
  CSingleLock local_20 [24];
  
  *param_1 = CLuaScript::vftable;
  this = operator_new(0x38);
  if (this == (CSyncObject *)0x0) {
    this = (CSyncObject *)0x0;
  }
  else {
    CSyncObject::CSyncObject(this,(char *)0x0);
    *(undefined ***)this = CCriticalSection::vftable;
    iVar1 = CCriticalSection::Init((CCriticalSection *)this);
    if (iVar1 == 0) {
      AfxThrowMemoryException();
    }
  }
  param_1[2] = this;
  uVar2 = FUN_1405150e0();
  param_1[1] = uVar2;
  FUN_1405158e0(uVar2);
  CSingleLock::CSingleLock(local_20,(CSyncObject *)param_1[2],1);
  FUN_140523ad0(param_1[1],FUN_140511810,0);
  FUN_140524320(param_1[1],"Square");
  CSingleLock::Unlock(local_20);
  return param_1;
}

// ==== CLuaScript::ctor_or_dtor  @140511c30  [high:vtable-assign]  (orig: FUN_140511c30)
void FUN_140511c30(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  *param_1 = CLuaScript::vftable;
  FUN_1405274d0(param_1[1]);
  if (param_1[2] != 0) {
    plVar1 = (longlong *)param_1[2];
    if (plVar1 != (longlong *)0x0) {
      (**(code **)(*plVar1 + 8))(plVar1,1,param_3,param_4,uVar2);
    }
    param_1[2] = 0;
  }
  return;
}

// ==== CLuaScript::CallScriptFuncEx  @140511c80  [high:log-string]  (orig: FUN_140511c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140511c80(longlong param_1,longlong param_2,undefined4 *param_3)

{
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *pbVar1;
  char cVar2;
  bool bVar3;
  undefined4 *puVar4;
  long lVar5;
  undefined8 uVar6;
  char *_Str;
  ulonglong uVar7;
  longlong lVar8;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *pbVar9;
  longlong lVar10;
  undefined8 ***pppuVar11;
  int iVar12;
  ulonglong uVar13;
  uint uVar14;
  undefined1 auStack_b8 [32];
  undefined4 *local_98;
  undefined8 local_90;
  CSingleLock local_88 [24];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [8];
  undefined8 **local_68 [3];
  ulonglong local_50;
  ulonglong local_48;
  ulonglong uVar15;
  
  local_90 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  local_98 = param_3;
  CSingleLock::CSingleLock(local_88,*(CSyncObject **)(param_1 + 0x10),1);
  iVar12 = 0;
  bVar3 = false;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"");
  uVar13 = 0;
  uVar7 = (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x30;
  if (uVar7 != 0) {
    lVar10 = 0;
    uVar15 = uVar13;
    do {
      if (uVar7 <= uVar13) {
        _invalid_parameter_noinfo();
      }
      lVar8 = *(longlong *)(param_2 + 0x18);
      cVar2 = *(char *)(lVar10 + lVar8);
      if (cVar2 == '\0') {
        pbVar1 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 (lVar10 + 8 + lVar8);
        if (*(ulonglong *)(pbVar1 + 0x20) < 0x10) {
          pbVar9 = pbVar1 + 8;
        }
        else {
          pbVar9 = *(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> **
                    )(pbVar1 + 8);
        }
        FUN_140523c10(*(undefined8 *)(param_1 + 8),pbVar9);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                  (local_70,pbVar1);
        bVar3 = true;
      }
      else if (cVar2 == '\x01') {
        if (*(ulonglong *)(lVar10 + 0x28 + lVar8) < 0x10) {
          _Str = (char *)(lVar10 + 0x10 + lVar8);
        }
        else {
          _Str = *(char **)(lVar10 + 0x10 + lVar8);
        }
        lVar5 = strtol(_Str,(char **)0x0,10);
        FUN_140523950(*(undefined8 *)(param_1 + 8),(longlong)lVar5);
        iVar12 = iVar12 + 1;
      }
      else if (cVar2 == '\x02') {
        if (*(ulonglong *)(lVar10 + 0x28 + lVar8) < 0x10) {
          lVar8 = lVar10 + 0x10 + lVar8;
        }
        else {
          lVar8 = *(longlong *)(lVar10 + 0x10 + lVar8);
        }
        FUN_1405239d0(*(undefined8 *)(param_1 + 8),lVar8);
        iVar12 = iVar12 + 1;
      }
      puVar4 = local_98;
      uVar14 = (int)uVar15 + 1;
      uVar15 = (ulonglong)uVar14;
      uVar13 = uVar13 + 1;
      lVar10 = lVar10 + 0x30;
      uVar7 = (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18)) / 0x30;
    } while ((ulonglong)(longlong)(int)uVar14 < uVar7);
    if (bVar3) {
      local_98 = (undefined4 *)((ulonglong)local_98 & 0xffffffff00000000);
      uVar14 = FUN_140511090(param_1,iVar12,1,&local_98);
      if (uVar14 == 0) {
        if (puVar4 != (undefined4 *)0x0) {
          *puVar4 = local_98._0_4_;
        }
      }
      else {
        pppuVar11 = local_68;
        if (0xf < local_50) {
          pppuVar11 = (undefined8 ***)local_68[0];
        }
        uVar6 = FUN_140523460(*(undefined8 *)(param_1 + 8),0xffffffff,0);
        log_InlineLogLuaERROR
                  ("CLuaScript::CallScriptFuncEx(), Function: %s, Ret:%d, LuaScript: %s",pppuVar11,
                   (ulonglong)uVar14,uVar6);
      }
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70);
      CSingleLock::Unlock(local_88);
      return (ulonglong)uVar14;
    }
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70);
  CSingleLock::Unlock(local_88);
  return 0xffffffff;
}

// ==== CLuaScript::vfunc_0  @140511fb0  [high:rtti-vtable]  (orig: FUN_140511fb0)
void FUN_140511fb0(void *param_1)

{
  if (param_1 != (void *)0x0) {
    FUN_140511c30();
    operator_delete(param_1);
  }
  return;
}

// ==== CLuaScript::helper_1405134e0  @1405134e0  [medium:callgraph-r3]  (orig: FUN_1405134e0)
undefined8 FUN_1405134e0(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  int iVar2;
  char *_Str1;
  undefined8 uVar3;
  
  iVar1 = FUN_140522700();
  FUN_1405269c0(param_1,&DAT_14079d480,param_2);
  FUN_140523d50(param_1,0xfff0b9d8,"_LOADED");
  iVar2 = FUN_1405133b0(param_1,iVar1 + 1,2);
  if (iVar2 == 0) {
    FUN_140522720(param_1,iVar1);
    uVar3 = 0;
  }
  else {
    _Str1 = (char *)FUN_140523460(param_1,0xffffffff,0);
    iVar2 = strncmp(_Str1,"_G.",3);
    if (iVar2 == 0) {
      FUN_1405239d0(param_1,_Str1 + 3);
      FUN_1405227e0(param_1,0xfffffffe);
      FUN_140522720(param_1,0xfffffffe);
    }
    FUN_140522980(param_1,0xffffffff,iVar1 + 1);
    FUN_140522720(param_1,0xfffffffd);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CLuaScript::helper_140513950  @140513950  [medium:callgraph-r2]  (orig: FUN_140513950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140513950(undefined8 param_1,undefined8 param_2)

{
  int iVar1;
  undefined1 auStack_b8 [32];
  undefined1 local_98 [40];
  int local_70;
  undefined1 local_60 [72];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  iVar1 = FUN_140525990(param_1,param_2,local_98);
  if ((iVar1 != 0) && (FUN_1405269c0(param_1,&DAT_14079d528,local_98), 0 < local_70)) {
    FUN_140523a90(param_1,"%s:%d: ",local_60);
    return;
  }
  FUN_1405239d0(param_1,&DAT_1406dd892);
  return;
}

// ==== CLuaScript::helper_1405139e0  @1405139e0  [medium:callgraph-r1]  (orig: FUN_1405139e0)
void FUN_1405139e0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res18 = param_3;
  local_res20 = param_4;
  FUN_140513950(param_1,1);
  FUN_140523a40(param_1,param_2,&local_res18);
  FUN_140525020(param_1,2);
  FUN_140524f60(param_1);
  return;
}

// ==== CLuaScript::helper_140514180  @140514180  [medium:callgraph-r1]  (orig: FUN_140514180)
int * FUN_140514180(undefined8 param_1,int *param_2,size_t *param_3)

{
  int iVar1;
  size_t sVar2;
  
  if (0 < *param_2) {
    *param_3 = (longlong)*param_2;
    *param_2 = 0;
    return param_2 + 4;
  }
  iVar1 = feof(*(FILE **)(param_2 + 2));
  if (iVar1 != 0) {
    return (int *)0x0;
  }
  sVar2 = fread(param_2 + 4,1,0x200,*(FILE **)(param_2 + 2));
  *param_3 = sVar2;
  return param_2 + 4;
}

// ==== CLuaScript::helper_140514200  @140514200  [medium:callgraph-r1]  (orig: FUN_140514200)
undefined8 FUN_140514200(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  int *piVar1;
  char *pcVar2;
  longlong lVar3;
  
  piVar1 = _errno();
  pcVar2 = strerror(*piVar1);
  lVar3 = FUN_140523460(param_1,param_3,0);
  FUN_140523a90(param_1,"cannot %s %s: %s",param_2,lVar3 + 1,pcVar2);
  FUN_1405227e0(param_1,param_3,0xffffffff);
  FUN_140522720(param_1,0xfffffffe);
  return 7;
}

// ==== CLuaScript::helper_1405143c0  @1405143c0  [medium:callgraph-r0]  (orig: FUN_1405143c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1405143c0(undefined8 param_1,char *param_2,undefined8 param_3)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  ulonglong uVar5;
  undefined8 uVar6;
  byte *pbVar7;
  byte *pbVar8;
  undefined1 auStack_288 [32];
  undefined8 local_268;
  int local_258 [2];
  FILE *local_250;
  undefined1 auStack_248 [512];
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_288;
  iVar2 = FUN_140522700();
  iVar2 = iVar2 + 1;
  if (param_2 == (char *)0x0) {
    FUN_1405239d0(param_1,"=stdin");
    local_250 = __iob_func();
  }
  else {
    FUN_140523a90(param_1,&DAT_14079d5a8,param_2);
    local_250 = fopen(param_2,"r");
    if (local_250 == (FILE *)0x0) {
      uVar5 = FUN_140514200(param_1,&DAT_14073de10,iVar2);
      return uVar5;
    }
  }
  pbVar8 = &DAT_14079d594;
  pbVar7 = &DAT_14079d594;
  local_258[0] = 0;
  do {
    uVar3 = getc(local_250);
    if ((uVar3 == 0xffffffff) || (bVar1 = *pbVar7, pbVar7 = pbVar7 + 1, uVar3 != bVar1))
    goto LAB_1405144d0;
    auStack_248[local_258[0]] = (char)uVar3;
    local_258[0] = local_258[0] + 1;
  } while (*pbVar7 != 0);
  local_258[0] = 0;
  uVar3 = getc(local_250);
LAB_1405144d0:
  if (uVar3 == 0x23) {
    do {
      iVar4 = getc(local_250);
      if (iVar4 == -1) break;
    } while (iVar4 != 10);
    uVar3 = getc(local_250);
    auStack_248[local_258[0]] = 10;
    local_258[0] = local_258[0] + 1;
  }
  if (uVar3 == 0x1b) {
    if (param_2 != (char *)0x0) {
      local_250 = freopen(param_2,"rb",local_250);
      if (local_250 == (FILE *)0x0) {
        uVar5 = FUN_140514200(param_1,"reopen",iVar2);
        return uVar5;
      }
      local_258[0] = 0;
      do {
        uVar3 = getc(local_250);
        if ((uVar3 == 0xffffffff) || (bVar1 = *pbVar8, pbVar8 = pbVar8 + 1, uVar3 != bVar1))
        goto LAB_1405145a9;
        auStack_248[local_258[0]] = (char)uVar3;
        local_258[0] = local_258[0] + 1;
      } while (*pbVar8 != 0);
      local_258[0] = 0;
      uVar3 = getc(local_250);
LAB_1405145a9:
      if (uVar3 == 0x23) {
        do {
          iVar4 = getc(local_250);
          if (iVar4 == -1) break;
        } while (iVar4 != 10);
        uVar3 = getc(local_250);
      }
      goto LAB_1405145d3;
    }
  }
  else {
LAB_1405145d3:
    if (uVar3 == 0xffffffff) goto LAB_1405145e7;
  }
  auStack_248[local_258[0]] = (char)uVar3;
  local_258[0] = local_258[0] + 1;
LAB_1405145e7:
  uVar6 = FUN_140523460(param_1,0xffffffff,0);
  local_268 = param_3;
  uVar3 = FUN_140524c50(param_1,FUN_140514180,local_258,uVar6);
  uVar5 = (ulonglong)uVar3;
  iVar4 = ferror(local_250);
  if (param_2 != (char *)0x0) {
    fclose(local_250);
  }
  if (iVar4 == 0) {
    FUN_1405227e0(param_1,iVar2,0xffffffff);
    FUN_140522720(param_1,0xfffffffe);
  }
  else {
    FUN_140522720(param_1,iVar2);
    uVar5 = FUN_140514200(param_1,&DAT_14079d598,iVar2);
  }
  return uVar5;
}

// ==== CLuaScript::helper_1405146d0  @1405146d0  [medium:callgraph-r0]  (orig: FUN_1405146d0)
void FUN_1405146d0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  undefined8 param_5)

{
  undefined8 local_18;
  undefined8 local_10;
  
  local_18 = param_2;
  local_10 = param_3;
  FUN_140524c50(param_1,&LAB_1405146b0,&local_18,param_4,param_5);
  return;
}

// ==== CLuaScript::helper_140514700  @140514700  [medium:callgraph-r0]  (orig: FUN_140514700)
void FUN_140514700(undefined8 param_1,char *param_2)

{
  char cVar1;
  ulonglong uVar2;
  char *pcVar3;
  char *local_18;
  longlong local_10;
  
  uVar2 = 0xffffffffffffffff;
  pcVar3 = param_2;
  do {
    if (uVar2 == 0) break;
    uVar2 = uVar2 - 1;
    cVar1 = *pcVar3;
    pcVar3 = pcVar3 + 1;
  } while (cVar1 != '\0');
  local_10 = ~uVar2 - 1;
  local_18 = param_2;
  FUN_140524c50(param_1,&LAB_1405146b0,&local_18,param_2,0);
  return;
}

// ==== CLuaScript::helper_140514bb0  @140514bb0  [medium:callgraph-r1]  (orig: FUN_140514bb0)
void FUN_140514bb0(undefined8 param_1,undefined8 param_2,undefined8 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_140523d50(param_1,0xfff0b9d8,"_LOADED");
  if (iVar1 != 5) {
    FUN_140522720(param_1,0xfffffffe);
    uVar2 = FUN_1405226d0(param_1,0xfff0b9d8);
    FUN_140524140(param_1,0,0);
    FUN_140522ac0(param_1,0xffffffff);
    FUN_140524450(param_1,uVar2,"_LOADED");
  }
  FUN_140523d50(param_1,0xffffffff,param_2);
  iVar1 = FUN_1405233c0(param_1,0xffffffff);
  if (iVar1 == 0) {
    FUN_140522720(param_1,0xfffffffe);
    FUN_140523ad0(param_1,param_3,0);
    FUN_1405239d0(param_1,param_2);
    FUN_140524aa0(param_1,1,1,0,0);
    FUN_140522ac0(param_1,0xffffffff);
    FUN_140524450(param_1,0xfffffffd,param_2);
  }
  FUN_1405227e0(param_1,0xfffffffe);
  FUN_140522720(param_1,0xfffffffe);
  if (param_4 != 0) {
    FUN_140522ac0(param_1,0xffffffff);
    FUN_140524320(param_1,param_2);
  }
  return;
}

// ==== CLuaScript::helper_140515060  @140515060  [medium:callgraph-r1]  (orig: FUN_140515060)
void * FUN_140515060(undefined8 param_1,void *param_2,undefined8 param_3,size_t param_4)

{
  void *pvVar1;
  
  if (param_4 == 0) {
    free(param_2);
    return (void *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140515086. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  pvVar1 = realloc(param_2,param_4);
  return pvVar1;
}

// ==== CLuaScript::helper_140515090  @140515090  [medium:callgraph-r1]  (orig: FUN_140515090)
undefined8 FUN_140515090(undefined8 param_1)

{
  FILE *pFVar1;
  
  FUN_140523460(param_1,0xffffffff,0);
  pFVar1 = __iob_func();
  fprintf(pFVar1 + 2,"PANIC: unprotected error in call to Lua API (%s)\n");
  pFVar1 = __iob_func();
  fflush(pFVar1 + 2);
  return 0;
}

// ==== CLuaScript::helper_1405150e0  @1405150e0  [medium:callgraph-r0]  (orig: FUN_1405150e0)
longlong FUN_1405150e0(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1405272d0(FUN_140515060,0);
  if (lVar1 != 0) {
    FUN_140522690(lVar1,FUN_140515090);
  }
  return lVar1;
}

// ==== CLuaScript::helper_1405151c0  @1405151c0  [medium:callgraph-r2]  (orig: FUN_1405151c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405151c0(undefined8 param_1,int param_2,undefined8 param_3)

{
  int iVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 uVar4;
  undefined1 auStack_e8 [32];
  undefined8 local_c8;
  undefined1 local_b8 [8];
  undefined *local_b0;
  char *local_a8;
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  iVar1 = FUN_140525990(param_1,0,local_b8);
  uVar4 = iVar1 == 0;
  if ((bool)uVar4) {
    FUN_1405139e0(param_1,"bad argument #%d (%s)",param_2,param_3);
  }
  else {
    FUN_1405269c0(param_1,&DAT_14079d728,local_b8);
    lVar2 = 7;
    pcVar3 = "method";
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      uVar4 = *local_a8 == *pcVar3;
      local_a8 = local_a8 + 1;
      pcVar3 = pcVar3 + 1;
    } while ((bool)uVar4);
    if (((bool)uVar4) && (param_2 = param_2 + -1, param_2 == 0)) {
      FUN_1405139e0(param_1,"calling \'%s\' on bad self (%s)",local_b0,param_3);
    }
    else {
      if (local_b0 == (undefined *)0x0) {
        iVar1 = FUN_1405134e0(param_1,local_b8);
        if (iVar1 == 0) {
          local_b0 = &DAT_14079d484;
        }
        else {
          local_b0 = (undefined *)FUN_140523460(param_1,0xffffffff,0);
        }
      }
      local_c8 = param_3;
      FUN_1405139e0(param_1,"bad argument #%d to \'%s\' (%s)",param_2,local_b0);
    }
  }
  return;
}

// ==== CLuaScript::helper_1405152f0  @1405152f0  [medium:callgraph-r2]  (orig: FUN_1405152f0)
void FUN_1405152f0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  undefined4 uVar2;
  char *pcVar3;
  undefined8 uVar4;
  
  iVar1 = FUN_1405241b0();
  if (iVar1 != 0) {
    FUN_1405239d0(param_1,"__name");
    iVar1 = FUN_140523ef0(param_1,0xfffffffe);
    if (iVar1 == 0) {
      FUN_140522720(param_1,0xfffffffd);
    }
    else {
      FUN_1405227e0(param_1,0xfffffffe);
      FUN_140522720(param_1,0xfffffffe);
      if (iVar1 == 4) {
        pcVar3 = (char *)FUN_140523460(param_1,0xffffffff,0);
        goto LAB_14051539d;
      }
    }
  }
  iVar1 = FUN_140522ba0(param_1,param_2);
  if (iVar1 == 2) {
    pcVar3 = "light userdata";
  }
  else {
    uVar2 = FUN_140522ba0(param_1,param_2);
    pcVar3 = (char *)FUN_140522c20(param_1,uVar2);
  }
LAB_14051539d:
  uVar4 = FUN_140523a90(param_1,"%s expected, got %s",param_3,pcVar3);
  FUN_1405151c0(param_1,param_2,uVar4);
  return;
}

// ==== CLuaScript::helper_140515720  @140515720  [medium:callgraph-r1]  (orig: FUN_140515720)
undefined8 FUN_140515720(undefined8 param_1,ulonglong param_2)

{
  int iVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  int local_res18 [4];
  
  uVar2 = FUN_140523300(param_1,param_2,local_res18);
  if (local_res18[0] == 0) {
    iVar1 = FUN_140522d70(param_1,param_2 & 0xffffffff);
    if (iVar1 != 0) {
      FUN_1405151c0(param_1,param_2 & 0xffffffff,"number has no integer representation");
      return uVar2;
    }
    uVar3 = FUN_140522c20(param_1,3);
    FUN_1405152f0(param_1,param_2 & 0xffffffff,uVar3);
  }
  return uVar2;
}

// ==== CLuaScript::helper_1405158e0  @1405158e0  [medium:callgraph-r0]  (orig: FUN_1405158e0)
void FUN_1405158e0(undefined8 param_1)

{
  undefined **ppuVar1;
  undefined *puVar2;
  undefined **ppuVar3;
  
  ppuVar3 = &PTR_DAT_14079d810;
  puVar2 = PTR_FUN_14079d818;
  while (puVar2 != (undefined *)0x0) {
    FUN_140514bb0(param_1,*ppuVar3,puVar2,1);
    FUN_140522720(param_1,0xfffffffe);
    ppuVar1 = ppuVar3 + 3;
    ppuVar3 = ppuVar3 + 2;
    puVar2 = *ppuVar1;
  }
  return;
}

// ==== CLuaScript::helper_140522520  @140522520  [medium:callgraph-r1]  (orig: FUN_140522520)
undefined8 * FUN_140522520(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  if (param_2 < 1) {
    if (-0xf4628 < param_2) {
      return (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
    if (param_2 == -0xf4628) {
      return (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
    }
    plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
    if (((int)plVar1[1] != 0x16) &&
       (lVar2 = *plVar1, -param_2 + -0xf4628 <= (int)(uint)*(byte *)(lVar2 + 10))) {
      return (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
    }
  }
  else {
    puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    if (puVar3 < *(undefined8 **)(param_1 + 0x10)) {
      return puVar3;
    }
  }
  return &DAT_14079fb60;
}

// ==== CLuaScript::helper_140522690  @140522690  [medium:callgraph-r1]  (orig: FUN_140522690)
undefined8 FUN_140522690(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  uVar1 = *(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0xd8);
  *(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0xd8) = param_2;
  return uVar1;
}

// ==== CLuaScript::helper_1405226b0  @1405226b0  [medium:callgraph-r3]  (orig: FUN_1405226b0)
undefined * FUN_1405226b0(longlong param_1)

{
  if (param_1 == 0) {
    return &DAT_14079f8e8;
  }
  return *(undefined **)(*(longlong *)(param_1 + 0x18) + 0xe8);
}

// ==== CLuaScript::helper_1405226d0  @1405226d0  [medium:callgraph-r2]  (orig: FUN_1405226d0)
int FUN_1405226d0(longlong param_1,int param_2)

{
  if (param_2 + 0xf4627U < 0xf4628) {
    return param_2 + (int)(*(longlong *)(param_1 + 0x10) - **(longlong **)(param_1 + 0x20) >> 4);
  }
  return param_2;
}

// ==== CLuaScript::helper_140522700  @140522700  [medium:callgraph-r1]  (orig: FUN_140522700)
longlong FUN_140522700(longlong param_1)

{
  return (*(longlong *)(param_1 + 0x10) - **(longlong **)(param_1 + 0x20)) + -0x10 >> 4;
}

// ==== CLuaScript::helper_140522720  @140522720  [medium:callgraph-r0]  (orig: FUN_140522720)
void FUN_140522720(longlong param_1,int param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  
  if (-1 < param_2) {
    uVar2 = **(longlong **)(param_1 + 0x20) + ((longlong)param_2 + 1) * 0x10;
    uVar1 = *(ulonglong *)(param_1 + 0x10);
    while (uVar1 < uVar2) {
      *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8) = 0;
      *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
      uVar1 = *(ulonglong *)(param_1 + 0x10);
    }
    *(ulonglong *)(param_1 + 0x10) = uVar2;
    return;
  }
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + (longlong)(param_2 + 1) * 0x10;
  return;
}

// ==== CLuaScript::helper_1405227e0  @1405227e0  [medium:callgraph-r1]  (orig: FUN_1405227e0)
void FUN_1405227e0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  
  puVar7 = *(undefined8 **)(param_1 + 0x10);
  puVar10 = puVar7 + -2;
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar6 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar5 = *plVar1, (int)(uint)*(byte *)(lVar5 + 10) < -param_2 + -0xf4628)) {
          puVar6 = &DAT_14079fb60;
        }
        else {
          puVar6 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar5);
        }
      }
    }
    else {
      puVar6 = puVar7 + (longlong)param_2 * 2;
    }
  }
  else {
    puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar6 = &DAT_14079fb60;
    if (puVar4 < puVar7) {
      puVar6 = puVar4;
    }
  }
  lVar5 = (longlong)param_3;
  puVar7 = puVar10;
  if (param_3 < 0) {
    lVar5 = lVar5 + 1;
    puVar7 = puVar6;
  }
  puVar7 = puVar7 + lVar5 * -2;
  puVar4 = puVar7;
  puVar9 = puVar6;
  if (puVar6 < puVar7) {
    do {
      uVar2 = *puVar9;
      puVar8 = puVar4 + -2;
      uVar3 = puVar9[1];
      puVar11 = puVar9 + 2;
      *puVar9 = *puVar4;
      puVar9[1] = puVar4[1];
      *puVar4 = uVar2;
      puVar4[1] = uVar3;
      puVar4 = puVar8;
      puVar9 = puVar11;
    } while (puVar11 < puVar8);
  }
  puVar4 = puVar7 + 2;
  puVar9 = puVar10;
  if (puVar7 + 2 < puVar10) {
    do {
      uVar2 = *puVar4;
      puVar8 = puVar9 + -2;
      uVar3 = puVar4[1];
      puVar7 = puVar4 + 2;
      *puVar4 = *puVar9;
      puVar4[1] = puVar9[1];
      *puVar9 = uVar2;
      puVar9[1] = uVar3;
      puVar4 = puVar7;
      puVar9 = puVar8;
    } while (puVar7 < puVar8);
  }
  if (puVar6 < puVar10) {
    do {
      uVar2 = *puVar6;
      puVar4 = puVar10 + -2;
      uVar3 = puVar6[1];
      puVar7 = puVar6 + 2;
      *puVar6 = *puVar10;
      puVar6[1] = puVar10[1];
      *puVar10 = uVar2;
      puVar10[1] = uVar3;
      puVar6 = puVar7;
      puVar10 = puVar4;
    } while (puVar7 < puVar4);
  }
  return;
}

// ==== CLuaScript::helper_140522ac0  @140522ac0  [medium:callgraph-r2]  (orig: FUN_140522ac0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140522ac0(longlong param_1,int param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  if (0 < param_2) {
    puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar5 = &DAT_14079fb60;
    if (puVar4 < puVar1) {
      puVar5 = puVar4;
    }
    *puVar1 = *puVar5;
    puVar1[1] = puVar5[1];
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return;
  }
  if (-0xf4628 < param_2) {
    *puVar1 = puVar1[(longlong)param_2 * 2];
    puVar1[1] = (puVar1 + (longlong)param_2 * 2)[1];
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return;
  }
  if (param_2 == -0xf4628) {
    lVar2 = *(longlong *)(param_1 + 0x18);
    *puVar1 = *(undefined8 *)(lVar2 + 0x40);
    puVar1[1] = *(undefined8 *)(lVar2 + 0x48);
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return;
  }
  plVar3 = (longlong *)**(longlong **)(param_1 + 0x20);
  if (((int)plVar3[1] != 0x16) &&
     (lVar2 = *plVar3, -param_2 + -0xf4628 <= (int)(uint)*(byte *)(lVar2 + 10))) {
    puVar5 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
    *puVar1 = *puVar5;
    puVar1[1] = puVar5[1];
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return;
  }
  *puVar1 = DAT_14079fb60;
  puVar1[1] = _DAT_14079fb68;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return;
}

// ==== CLuaScript::helper_140522ba0  @140522ba0  [medium:callgraph-r0]  (orig: FUN_140522ba0)
uint FUN_140522ba0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar3 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if ((int)plVar1[1] == 0x16) {
          return 0xffffffff;
        }
        lVar2 = *plVar1;
        if ((int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628) {
          return 0xffffffff;
        }
        puVar3 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
      }
    }
    else {
      puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    if (*(undefined8 **)(param_1 + 0x10) <= puVar3) {
      return 0xffffffff;
    }
  }
  if (puVar3 == &DAT_14079fb60) {
    return 0xffffffff;
  }
  return *(uint *)(puVar3 + 1) & 0xf;
}

// ==== CLuaScript::helper_140522c20  @140522c20  [medium:callgraph-r2]  (orig: FUN_140522c20)
undefined * FUN_140522c20(undefined8 param_1,int param_2)

{
  return (&PTR_DAT_14079fdf8)[param_2];
}

// ==== CLuaScript::helper_140522d70  @140522d70  [medium:callgraph-r0]  (orig: FUN_140522d70)
undefined8 FUN_140522d70(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  undefined8 *puVar5;
  undefined1 local_res8 [32];
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar5 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          puVar5 = &DAT_14079fb60;
        }
        else {
          puVar5 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      puVar5 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar5 = &DAT_14079fb60;
    if (puVar3 < *(undefined8 **)(param_1 + 0x10)) {
      puVar5 = puVar3;
    }
  }
  if (*(int *)(puVar5 + 1) != 3) {
    uVar4 = FUN_14052c080(puVar5,local_res8);
    return uVar4;
  }
  return 1;
}

// ==== CLuaScript::helper_140522e10  @140522e10  [medium:callgraph-r0]  (orig: FUN_140522e10)
undefined8 FUN_140522e10(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar4 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          puVar4 = &DAT_14079fb60;
        }
        else {
          puVar4 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar4 = &DAT_14079fb60;
    if (puVar3 < *(undefined8 **)(param_1 + 0x10)) {
      puVar4 = puVar3;
    }
  }
  if (((*(uint *)(puVar4 + 1) & 0xf) != 4) && ((*(uint *)(puVar4 + 1) & 0xf) != 3)) {
    return 0;
  }
  return 1;
}

// ==== CLuaScript::helper_140523240  @140523240  [medium:callgraph-r0]  (orig: FUN_140523240)
undefined8 FUN_140523240(longlong param_1,int param_2,int *param_3)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_res8 [4];
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar5 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          puVar5 = &DAT_14079fb60;
        }
        else {
          puVar5 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      puVar5 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar5 = &DAT_14079fb60;
    if (puVar4 < *(undefined8 **)(param_1 + 0x10)) {
      puVar5 = puVar4;
    }
  }
  if (*(int *)(puVar5 + 1) == 3) {
    local_res8[0] = *puVar5;
    iVar3 = 1;
  }
  else {
    iVar3 = FUN_14052c080(puVar5,local_res8);
    if (iVar3 == 0) {
      local_res8[0] = 0;
    }
  }
  if (param_3 != (int *)0x0) {
    *param_3 = iVar3;
  }
  return local_res8[0];
}

// ==== CLuaScript::helper_140523300  @140523300  [medium:callgraph-r2]  (orig: FUN_140523300)
undefined8 FUN_140523300(longlong param_1,int param_2,int *param_3)

{
  longlong *plVar1;
  longlong lVar2;
  int iVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 local_res8 [4];
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar5 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          puVar5 = &DAT_14079fb60;
        }
        else {
          puVar5 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      puVar5 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar5 = &DAT_14079fb60;
    if (puVar4 < *(undefined8 **)(param_1 + 0x10)) {
      puVar5 = puVar4;
    }
  }
  if (*(int *)(puVar5 + 1) == 0x13) {
    local_res8[0] = *puVar5;
    iVar3 = 1;
  }
  else {
    iVar3 = FUN_14052c120(puVar5,local_res8,0);
    if (iVar3 == 0) {
      local_res8[0] = 0;
    }
  }
  if (param_3 != (int *)0x0) {
    *param_3 = iVar3;
  }
  return local_res8[0];
}

// ==== CLuaScript::helper_1405233c0  @1405233c0  [medium:callgraph-r0]  (orig: FUN_1405233c0)
undefined8 FUN_1405233c0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        piVar4 = (int *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          piVar4 = (int *)&DAT_14079fb60;
        }
        else {
          piVar4 = (int *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      piVar4 = (int *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    piVar3 = (int *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    piVar4 = (int *)&DAT_14079fb60;
    if (piVar3 < *(int **)(param_1 + 0x10)) {
      piVar4 = piVar3;
    }
  }
  if ((piVar4[2] != 0) && ((piVar4[2] != 1 || (*piVar4 != 0)))) {
    return 1;
  }
  return 0;
}

// ==== CLuaScript::helper_140523460  @140523460  [medium:callgraph-r0]  (orig: FUN_140523460)
longlong FUN_140523460(longlong param_1,int param_2,ulonglong *param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong *plVar3;
  ulonglong uVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        plVar3 = (longlong *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar3 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar3[1] == 0x16) ||
           (lVar1 = *plVar3, (int)(uint)*(byte *)(lVar1 + 10) < -param_2 + -0xf4628)) {
          plVar3 = &DAT_14079fb60;
        }
        else {
          plVar3 = (longlong *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar1);
        }
      }
    }
    else {
      plVar3 = (longlong *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    plVar2 = (longlong *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    plVar3 = &DAT_14079fb60;
    if (plVar2 < *(longlong **)(param_1 + 0x10)) {
      plVar3 = plVar2;
    }
  }
  if ((*(uint *)(plVar3 + 1) & 0xf) != 4) {
    if ((*(uint *)(plVar3 + 1) & 0xf) != 3) {
      if (param_3 != (ulonglong *)0x0) {
        *param_3 = 0;
      }
      return 0;
    }
    if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
      FUN_14052b920(param_1);
    }
    plVar3 = (longlong *)FUN_140522520(param_1,param_2);
    FUN_1405292c0(param_1,plVar3);
  }
  if (param_3 != (ulonglong *)0x0) {
    lVar1 = *plVar3;
    if (*(char *)(lVar1 + 8) == '\x04') {
      uVar4 = (ulonglong)*(byte *)(lVar1 + 0xb);
    }
    else {
      uVar4 = *(ulonglong *)(lVar1 + 0x10);
    }
    *param_3 = uVar4;
  }
  return *plVar3 + 0x18;
}

// ==== CLuaScript::helper_140523930  @140523930  [medium:callgraph-r0]  (orig: FUN_140523930)
void FUN_140523930(longlong param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  *puVar1 = param_2;
  *(undefined4 *)(puVar1 + 1) = 3;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return;
}

// ==== CLuaScript::helper_140523950  @140523950  [medium:callgraph-r0]  (orig: FUN_140523950)
void FUN_140523950(longlong param_1,undefined8 param_2)

{
  undefined8 *puVar1;
  
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  *puVar1 = param_2;
  *(undefined4 *)(puVar1 + 1) = 0x13;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return;
}

// ==== CLuaScript::helper_1405239d0  @1405239d0  [medium:callgraph-r0]  (orig: FUN_1405239d0)
longlong FUN_1405239d0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (param_2 == 0) {
    *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8) = 0;
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return 0;
  }
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920();
  }
  lVar2 = FUN_140530a40(param_1,param_2);
  plVar1 = *(longlong **)(param_1 + 0x10);
  *plVar1 = lVar2;
  *(uint *)(plVar1 + 1) = *(byte *)(lVar2 + 8) | 0x40;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return lVar2 + 0x18;
}

// ==== CLuaScript::helper_140523a40  @140523a40  [medium:callgraph-r2]  (orig: FUN_140523a40)
void FUN_140523a40(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920();
  }
  FUN_1405293c0(param_1,param_2,param_3);
  return;
}

// ==== CLuaScript::helper_140523a90  @140523a90  [medium:callgraph-r1]  (orig: FUN_140523a90)
void FUN_140523a90(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res18 = param_3;
  local_res20 = param_4;
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920();
  }
  FUN_1405293c0(param_1,param_2,&local_res18);
  return;
}

// ==== CLuaScript::helper_140523ad0  @140523ad0  [medium:callgraph-r0]  (orig: FUN_140523ad0)
void FUN_140523ad0(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined8 *puVar4;
  uint uVar5;
  ulonglong uVar6;
  longlong lVar7;
  
  uVar6 = (ulonglong)param_3;
  if (param_3 == 0) {
    puVar4 = *(undefined8 **)(param_1 + 0x10);
    *puVar4 = param_2;
    *(undefined4 *)(puVar4 + 1) = 0x16;
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    return;
  }
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920();
  }
  lVar3 = FUN_140530bc0(param_1,param_3);
  *(undefined8 *)(lVar3 + 0x18) = param_2;
  lVar7 = uVar6 << 4;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + uVar6 * -0x10;
  puVar4 = (undefined8 *)((uVar6 + 2) * 0x10 + lVar3);
  do {
    lVar1 = *(longlong *)(param_1 + 0x10);
    lVar7 = lVar7 + -0x10;
    uVar5 = (int)uVar6 - 1;
    uVar6 = (ulonglong)uVar5;
    puVar4[-2] = *(undefined8 *)(lVar1 + lVar7);
    puVar4[-1] = *(undefined8 *)(lVar1 + 8 + lVar7);
    puVar4 = puVar4 + -2;
  } while (uVar5 != 0);
  plVar2 = *(longlong **)(param_1 + 0x10);
  *plVar2 = lVar3;
  *(undefined4 *)(plVar2 + 1) = 0x66;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return;
}

// ==== CLuaScript::helper_140523c10  @140523c10  [medium:callgraph-r0]  (orig: FUN_140523c10)
uint FUN_140523c10(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  
  uVar2 = FUN_14052faf0(*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40),2);
  plVar1 = *(longlong **)(param_1 + 0x10);
  lVar3 = FUN_140530a40(param_1,param_2);
  *plVar1 = lVar3;
  *(uint *)(plVar1 + 1) = *(byte *)(lVar3 + 8) | 0x40;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  lVar3 = *(longlong *)(param_1 + 0x10) + -0x10;
  FUN_14052c2e0(param_1,uVar2,lVar3,lVar3);
  return *(uint *)(*(longlong *)(param_1 + 0x10) + -8) & 0xf;
}

// ==== CLuaScript::helper_140523d50  @140523d50  [medium:callgraph-r2]  (orig: FUN_140523d50)
uint FUN_140523d50(longlong param_1,int param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar4 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar3 = *plVar1, (int)(uint)*(byte *)(lVar3 + 10) < -param_2 + -0xf4628)) {
          puVar4 = &DAT_14079fb60;
        }
        else {
          puVar4 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar3);
        }
      }
    }
    else {
      puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar2 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar4 = &DAT_14079fb60;
    if (puVar2 < *(undefined8 **)(param_1 + 0x10)) {
      puVar4 = puVar2;
    }
  }
  plVar1 = *(longlong **)(param_1 + 0x10);
  lVar3 = FUN_140530a40(param_1,param_3);
  *plVar1 = lVar3;
  *(uint *)(plVar1 + 1) = *(byte *)(lVar3 + 8) | 0x40;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  lVar3 = *(longlong *)(param_1 + 0x10) + -0x10;
  FUN_14052c2e0(param_1,puVar4,lVar3,lVar3);
  return *(uint *)(*(longlong *)(param_1 + 0x10) + -8) & 0xf;
}

// ==== CLuaScript::helper_140523ef0  @140523ef0  [medium:callgraph-r3]  (orig: FUN_140523ef0)
uint FUN_140523ef0(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar4 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar2 = *plVar1, (int)(uint)*(byte *)(lVar2 + 10) < -param_2 + -0xf4628)) {
          puVar4 = &DAT_14079fb60;
        }
        else {
          puVar4 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar2);
        }
      }
    }
    else {
      puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar3 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar4 = &DAT_14079fb60;
    if (puVar3 < *(undefined8 **)(param_1 + 0x10)) {
      puVar4 = puVar3;
    }
  }
  lVar2 = *(longlong *)(param_1 + 0x10);
  puVar4 = (undefined8 *)FUN_14052fbb0(*puVar4,lVar2 + -0x10);
  *(undefined8 *)(lVar2 + -0x10) = *puVar4;
  *(undefined8 *)(lVar2 + -8) = puVar4[1];
  return *(uint *)(*(longlong *)(param_1 + 0x10) + -8) & 0xf;
}

// ==== CLuaScript::helper_140524140  @140524140  [medium:callgraph-r2]  (orig: FUN_140524140)
void FUN_140524140(longlong param_1,int param_2,int param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920();
  }
  uVar2 = FUN_14052fa10(param_1);
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  *puVar1 = uVar2;
  *(undefined4 *)(puVar1 + 1) = 0x45;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  if ((0 < param_2) || (0 < param_3)) {
    FUN_14052ff70(param_1,uVar2,param_2,param_3);
  }
  return;
}

// ==== CLuaScript::helper_1405241b0  @1405241b0  [medium:callgraph-r3]  (orig: FUN_1405241b0)
undefined8 FUN_1405241b0(longlong param_1,int param_2)

{
  uint uVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        plVar3 = (longlong *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar3 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar3[1] == 0x16) ||
           (lVar4 = *plVar3, (int)(uint)*(byte *)(lVar4 + 10) < -param_2 + -0xf4628)) {
          plVar3 = &DAT_14079fb60;
        }
        else {
          plVar3 = (longlong *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar4);
        }
      }
    }
    else {
      plVar3 = (longlong *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    plVar2 = (longlong *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    plVar3 = &DAT_14079fb60;
    if (plVar2 < *(longlong **)(param_1 + 0x10)) {
      plVar3 = plVar2;
    }
  }
  uVar1 = *(uint *)(plVar3 + 1) & 0xf;
  if (uVar1 == 5) {
    lVar4 = *(longlong *)(*plVar3 + 0x28);
  }
  else if (uVar1 == 7) {
    lVar4 = *(longlong *)(*plVar3 + 0x10);
  }
  else {
    lVar4 = *(longlong *)
             (*(longlong *)(param_1 + 0x18) + 0x1b8 + (ulonglong)(*(uint *)(plVar3 + 1) & 0xf) * 8);
  }
  if (lVar4 == 0) {
    return 0;
  }
  plVar3 = *(longlong **)(param_1 + 0x10);
  *plVar3 = lVar4;
  *(undefined4 *)(plVar3 + 1) = 0x45;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  return 1;
}

// ==== CLuaScript::helper_140524320  @140524320  [medium:callgraph-r0]  (orig: FUN_140524320)
void FUN_140524320(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  
  uVar2 = FUN_14052faf0(*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40),2);
  plVar1 = *(longlong **)(param_1 + 0x10);
  lVar3 = FUN_140530a40(param_1,param_2);
  *plVar1 = lVar3;
  *(uint *)(plVar1 + 1) = *(byte *)(lVar3 + 8) | 0x40;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  FUN_14052c400(param_1,uVar2,*(longlong *)(param_1 + 0x10) + -0x10,
                *(longlong *)(param_1 + 0x10) + -0x20);
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + -0x20;
  return;
}

// ==== CLuaScript::helper_140524450  @140524450  [medium:callgraph-r2]  (orig: FUN_140524450)
void FUN_140524450(longlong param_1,int param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  if (param_2 < 1) {
    if (param_2 < -0xf4627) {
      if (param_2 == -0xf4628) {
        puVar4 = (undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40);
      }
      else {
        plVar1 = (longlong *)**(longlong **)(param_1 + 0x20);
        if (((int)plVar1[1] == 0x16) ||
           (lVar3 = *plVar1, (int)(uint)*(byte *)(lVar3 + 10) < -param_2 + -0xf4628)) {
          puVar4 = &DAT_14079fb60;
        }
        else {
          puVar4 = (undefined8 *)(((longlong)(-param_2 + -0xf4629) + 2) * 0x10 + lVar3);
        }
      }
    }
    else {
      puVar4 = (undefined8 *)((longlong)param_2 * 0x10 + *(longlong *)(param_1 + 0x10));
    }
  }
  else {
    puVar2 = (undefined8 *)((longlong)param_2 * 0x10 + **(longlong **)(param_1 + 0x20));
    puVar4 = &DAT_14079fb60;
    if (puVar2 < *(undefined8 **)(param_1 + 0x10)) {
      puVar4 = puVar2;
    }
  }
  plVar1 = *(longlong **)(param_1 + 0x10);
  lVar3 = FUN_140530a40(param_1,param_3);
  *plVar1 = lVar3;
  *(uint *)(plVar1 + 1) = *(byte *)(lVar3 + 8) | 0x40;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  FUN_14052c400(param_1,puVar4,*(longlong *)(param_1 + 0x10) + -0x10,
                *(longlong *)(param_1 + 0x10) + -0x20);
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + -0x20;
  return;
}

// ==== CLuaScript::helper_140524aa0  @140524aa0  [medium:callgraph-r2]  (orig: FUN_140524aa0)
void FUN_140524aa0(longlong param_1,int param_2,int param_3,undefined8 param_4,longlong param_5)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x10);
  if ((param_5 == 0) || (*(short *)(param_1 + 0xc4) != 0)) {
    uVar2 = 0;
  }
  else {
    *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x20) = param_5;
    *(undefined8 *)(*(longlong *)(param_1 + 0x20) + 0x30) = param_4;
    uVar2 = 1;
  }
  FUN_140528670(param_1,lVar1 + (longlong)(param_2 + 1) * -0x10,param_3,uVar2);
  if (param_3 == -1) {
    if (*(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) < *(ulonglong *)(param_1 + 0x10)) {
      *(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) = *(ulonglong *)(param_1 + 0x10);
    }
  }
  return;
}

// ==== CLuaScript::helper_140524b30  @140524b30  [medium:callgraph-r0]  (orig: FUN_140524b30)
ulonglong FUN_140524b30(longlong param_1,int param_2,int param_3,int param_4,undefined8 param_5,
                       longlong param_6)

{
  uint uVar1;
  longlong lVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  longlong local_18;
  int local_10;
  
  uVar3 = 0;
  uVar4 = uVar3;
  if (param_4 != 0) {
    lVar2 = FUN_140522520(param_1,param_4);
    uVar4 = lVar2 - *(longlong *)(param_1 + 0x38);
  }
  local_18 = *(longlong *)(param_1 + 0x10) + (longlong)(param_2 + 1) * -0x10;
  if ((param_6 == 0) || (*(short *)(param_1 + 0xc4) != 0)) {
    local_10 = param_3;
    uVar1 = FUN_140527fe0(param_1,&LAB_140524b20,&local_18,local_18 - *(longlong *)(param_1 + 0x38),
                          uVar4);
    uVar3 = (ulonglong)uVar1;
  }
  else {
    lVar2 = *(longlong *)(param_1 + 0x20);
    *(longlong *)(lVar2 + 0x20) = param_6;
    *(undefined8 *)(lVar2 + 0x30) = param_5;
    *(longlong *)(lVar2 + 0x38) = local_18 - *(longlong *)(param_1 + 0x38);
    *(undefined8 *)(lVar2 + 0x28) = *(undefined8 *)(param_1 + 0xb0);
    *(ulonglong *)(param_1 + 0xb0) = uVar4;
    *(byte *)(lVar2 + 0x42) = *(byte *)(param_1 + 0xc9) | *(byte *)(lVar2 + 0x42) & 0xfe | 0x10;
    FUN_140528670(param_1,local_18,param_3,1);
    *(byte *)(lVar2 + 0x42) = *(byte *)(lVar2 + 0x42) & 0xef;
    *(undefined8 *)(param_1 + 0xb0) = *(undefined8 *)(lVar2 + 0x28);
  }
  if (param_3 == -1) {
    if (*(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) < *(ulonglong *)(param_1 + 0x10)) {
      *(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) = *(ulonglong *)(param_1 + 0x10);
    }
  }
  return uVar3;
}

// ==== CLuaScript::helper_140524c50  @140524c50  [medium:callgraph-r1]  (orig: FUN_140524c50)
ulonglong FUN_140524c50(longlong param_1,undefined8 param_2,undefined8 param_3,undefined *param_4,
                       undefined8 param_5)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  undefined *puVar6;
  ulonglong uVar7;
  undefined1 local_38 [48];
  
  puVar6 = &DAT_14079d484;
  if (param_4 != (undefined *)0x0) {
    puVar6 = param_4;
  }
  FUN_140530fa0(param_1,local_38,param_2,param_3);
  uVar4 = FUN_140528240(param_1,local_38,puVar6,param_5);
  uVar7 = uVar4 & 0xffffffff;
  if (((int)uVar4 == 0) &&
     (lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x10) + -0x10), *(char *)(lVar1 + 10) != '\0'))
  {
    puVar5 = (undefined8 *)FUN_14052faf0(*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x40),2);
    puVar2 = (undefined8 *)**(longlong **)(lVar1 + 0x20);
    *puVar2 = *puVar5;
    puVar2[1] = puVar5[1];
    plVar3 = *(longlong **)(lVar1 + 0x20);
    uVar4 = uVar7;
    if (((*(byte *)(*plVar3 + 8) & 0x40) != 0) && ((longlong *)*plVar3 == plVar3 + 2)) {
      FUN_14052ad70(param_1);
    }
  }
  return uVar4;
}

// ==== CLuaScript::helper_140524f60  @140524f60  [medium:callgraph-r2]  (orig: FUN_140524f60)
void FUN_140524f60(void)

{
  code *pcVar1;
  
  FUN_1405265b0();
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

// ==== CLuaScript::helper_140525020  @140525020  [medium:callgraph-r2]  (orig: FUN_140525020)
void FUN_140525020(longlong param_1,int param_2)

{
  longlong *plVar1;
  longlong lVar2;
  
  if (1 < param_2) {
    if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
      FUN_14052b920();
    }
    FUN_14052cc00(param_1,param_2);
    return;
  }
  if (param_2 == 0) {
    plVar1 = *(longlong **)(param_1 + 0x10);
    lVar2 = FUN_1405309a0(param_1,&DAT_1406dd892,0);
    *plVar1 = lVar2;
    *(uint *)(plVar1 + 1) = *(byte *)(lVar2 + 8) | 0x40;
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  }
  return;
}

// ==== CLuaScript::helper_140525910  @140525910  [medium:callgraph-r0]  (orig: FUN_140525910)
void FUN_140525910(longlong param_1,ulonglong param_2,uint param_3,undefined4 param_4)

{
  ulonglong uVar1;
  
  if ((param_2 == 0) || (uVar1 = (ulonglong)param_3, param_3 == 0)) {
    param_2 = 0;
    uVar1 = param_2;
  }
  if ((*(byte *)(*(longlong *)(param_1 + 0x20) + 0x42) & 2) != 0) {
    *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(*(longlong *)(param_1 + 0x20) + 0x28);
  }
  *(ulonglong *)(param_1 + 0xa8) = param_2;
  *(undefined4 *)(param_1 + 0xbc) = param_4;
  *(undefined4 *)(param_1 + 0xc0) = param_4;
  *(char *)(param_1 + 200) = (char)uVar1;
  return;
}

// ==== CLuaScript::helper_140525990  @140525990  [medium:callgraph-r3]  (orig: FUN_140525990)
undefined8 FUN_140525990(longlong param_1,int param_2,longlong param_3)

{
  longlong lVar1;
  
  if (-1 < param_2) {
    lVar1 = *(longlong *)(param_1 + 0x20);
    if (0 < param_2) {
      do {
        if (lVar1 == param_1 + 0x60) break;
        lVar1 = *(longlong *)(lVar1 + 0x10);
        param_2 = param_2 + -1;
      } while (0 < param_2);
    }
    if ((param_2 == 0) && (lVar1 != param_1 + 0x60)) {
      *(longlong *)(param_3 + 0x78) = lVar1;
      return 1;
    }
  }
  return 0;
}

// ==== CLuaScript::helper_140526400  @140526400  [medium:callgraph-r3]  (orig: FUN_140526400)
undefined1 * FUN_140526400(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  char *pcVar4;
  undefined1 *puVar5;
  undefined8 *puVar6;
  ulonglong uVar7;
  int iVar8;
  undefined *local_res8;
  
  puVar1 = *(undefined8 **)(param_1 + 0x20);
  iVar8 = 0;
  local_res8 = (undefined *)0x0;
  if ((*(byte *)((longlong)puVar1 + 0x42) & 2) != 0) {
    lVar2 = *(longlong *)*puVar1;
    if (*(byte *)(lVar2 + 10) != 0) {
      puVar6 = (undefined8 *)(lVar2 + 0x20);
      do {
        if (*(longlong *)*puVar6 == param_2) {
          lVar2 = *(longlong *)
                   (*(longlong *)(*(longlong *)(lVar2 + 0x18) + 0x58) + (longlong)iVar8 * 0x10);
          if (lVar2 == 0) {
            pcVar4 = "upvalue";
            local_res8 = &DAT_14079d484;
          }
          else {
            local_res8 = (undefined *)(lVar2 + 0x18);
            pcVar4 = "upvalue";
          }
          goto LAB_1405264c0;
        }
        iVar8 = iVar8 + 1;
        puVar6 = puVar6 + 1;
      } while (iVar8 < (int)(uint)*(byte *)(lVar2 + 10));
    }
    lVar3 = puVar1[4];
    uVar7 = param_2 - lVar3 >> 4;
    if ((((-1 < (longlong)uVar7) && ((longlong)uVar7 < puVar1[1] - lVar3 >> 4)) &&
        (uVar7 * 0x10 + lVar3 == param_2)) &&
       (pcVar4 = (char *)FUN_140525f70(*(longlong *)(lVar2 + 0x18),
                                       (int)(puVar1[5] -
                                             *(longlong *)(*(longlong *)(lVar2 + 0x18) + 0x38) >> 2)
                                       + -1,uVar7 & 0xffffffff,&local_res8), pcVar4 != (char *)0x0))
    {
LAB_1405264c0:
      puVar5 = (undefined1 *)FUN_140529770(param_1," (%s \'%s\')",pcVar4,local_res8);
      return puVar5;
    }
  }
  return &DAT_1406dd892;
}

// ==== CLuaScript::helper_140526530  @140526530  [medium:callgraph-r3]  (orig: FUN_140526530)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140526530(undefined8 param_1,undefined8 param_2,longlong param_3,undefined4 param_4)

{
  undefined1 auStack_98 [32];
  undefined8 local_78;
  undefined1 local_68;
  undefined1 local_67;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  if (param_3 == 0) {
    local_68 = 0x3f;
    local_67 = 0;
  }
  else {
    FUN_1405297a0(&local_68,param_3 + 0x18,0x3c);
  }
  local_78 = param_2;
  FUN_140529770(param_1,"%s:%d: %s",&local_68,param_4);
  return;
}

// ==== CLuaScript::helper_1405265b0  @1405265b0  [medium:callgraph-r3]  (orig: FUN_1405265b0)
void FUN_1405265b0(longlong param_1)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong lVar4;
  
  lVar1 = *(longlong *)(param_1 + 0xb0);
  if (lVar1 != 0) {
    puVar2 = *(undefined8 **)(param_1 + 0x10);
    lVar3 = *(longlong *)(param_1 + 0x38);
    *puVar2 = puVar2[-2];
    puVar2[1] = puVar2[-1];
    lVar4 = *(longlong *)(param_1 + 0x10);
    *(undefined8 *)(lVar4 + -0x10) = *(undefined8 *)(lVar1 + lVar3);
    *(undefined8 *)(lVar4 + -8) = *(undefined8 *)(lVar1 + 8 + lVar3);
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
    FUN_140528670(param_1,*(longlong *)(param_1 + 0x10) + -0x20,1);
  }
                    /* WARNING: Subroutine does not return */
  FUN_140527580(param_1,2);
}

// ==== CLuaScript::helper_140526620  @140526620  [medium:callgraph-r2]  (orig: FUN_140526620)
void FUN_140526620(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  code *pcVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  undefined8 local_res18;
  undefined8 local_res20;
  
  puVar1 = *(undefined8 **)(param_1 + 0x20);
  local_res18 = param_3;
  local_res20 = param_4;
  uVar4 = FUN_1405293c0(param_1,param_2,&local_res18);
  if ((*(byte *)((longlong)puVar1 + 0x42) & 2) != 0) {
    lVar2 = *(longlong *)(*(longlong *)*puVar1 + 0x18);
    if (*(longlong *)(lVar2 + 0x48) == 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = *(undefined4 *)
               (*(longlong *)(lVar2 + 0x48) + -4 +
               (longlong)(int)(puVar1[5] - *(longlong *)(lVar2 + 0x38) >> 2) * 4);
    }
    FUN_140526530(param_1,uVar4,*(undefined8 *)(lVar2 + 0x68),uVar5);
  }
  FUN_1405265b0(param_1);
  pcVar3 = (code *)swi(3);
  (*pcVar3)();
  return;
}

// ==== CLuaScript::helper_1405266a0  @1405266a0  [medium:callgraph-r3]  (orig: FUN_1405266a0)
void FUN_1405266a0(longlong param_1)

{
  byte bVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  bool bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  
  bVar1 = *(byte *)(param_1 + 200);
  plVar2 = *(longlong **)(param_1 + 0x20);
  if (((bVar1 & 8) == 0) || (*(int *)(param_1 + 0xc0) != 0)) {
    bVar5 = false;
  }
  else {
    bVar5 = true;
    *(undefined4 *)(param_1 + 0xc0) = *(undefined4 *)(param_1 + 0xbc);
  }
  if ((*(byte *)((longlong)plVar2 + 0x42) & 0x40) != 0) {
    *(byte *)((longlong)plVar2 + 0x42) = *(byte *)((longlong)plVar2 + 0x42) & 0xbf;
    return;
  }
  iVar8 = -1;
  iVar7 = -1;
  if (bVar5) {
    FUN_140527990(param_1,3,0xffffffff);
  }
  if ((bVar1 & 4) != 0) {
    lVar3 = *(longlong *)(*(longlong *)(*(longlong *)*plVar2 + 0x18) + 0x38);
    lVar4 = *(longlong *)(*(longlong *)(*(longlong *)*plVar2 + 0x18) + 0x48);
    iVar6 = (int)(plVar2[5] - lVar3 >> 2) + -1;
    if (lVar4 != 0) {
      iVar8 = *(int *)(lVar4 + (longlong)iVar6 * 4);
    }
    if ((iVar6 != 0) && (*(ulonglong *)(param_1 + 0x28) < (ulonglong)plVar2[5])) {
      if (lVar4 != 0) {
        iVar7 = *(int *)(lVar4 + -4 +
                        (longlong)(int)((longlong)(*(ulonglong *)(param_1 + 0x28) - lVar3) >> 2) * 4
                        );
      }
      if (iVar8 == iVar7) goto LAB_14052678e;
    }
    FUN_140527990(param_1,2);
  }
LAB_14052678e:
  *(longlong *)(param_1 + 0x28) = plVar2[5];
  if (*(char *)(param_1 + 10) != '\x01') {
    return;
  }
  if (bVar5) {
    *(undefined4 *)(param_1 + 0xc0) = 1;
  }
  plVar2[5] = plVar2[5] + -4;
  *(byte *)((longlong)plVar2 + 0x42) = *(byte *)((longlong)plVar2 + 0x42) | 0x40;
  *plVar2 = *(longlong *)(param_1 + 0x10) + -0x10;
                    /* WARNING: Subroutine does not return */
  FUN_140527580(param_1,1);
}

// ==== CLuaScript::helper_1405269c0  @1405269c0  [medium:callgraph-r3]  (orig: FUN_1405269c0)
undefined4 FUN_1405269c0(longlong param_1,char *param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined4 uVar3;
  char *pcVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  
  if (*(char *)(param_1 + 10) == '\x01') {
    plVar1 = *(longlong **)(param_1 + 0x20);
    lVar2 = *plVar1;
    *plVar1 = *(longlong *)(param_1 + 0x38) + plVar1[7];
    plVar1[7] = lVar2 - *(longlong *)(param_1 + 0x38);
  }
  puVar6 = (undefined8 *)0x0;
  if (*param_2 == '>') {
    puVar7 = (undefined8 *)(*(longlong *)(param_1 + 0x10) + -0x10);
    param_2 = param_2 + 1;
    *(undefined8 **)(param_1 + 0x10) = puVar7;
    puVar5 = puVar6;
  }
  else {
    puVar5 = *(undefined8 **)(param_3 + 0x78);
    puVar7 = (undefined8 *)*puVar5;
  }
  if (((byte)*(undefined4 *)(puVar7 + 1) & 0x1f) == 6) {
    puVar6 = (undefined8 *)*puVar7;
  }
  uVar3 = FUN_1405267e0(param_1,param_2,param_3,puVar6,puVar5);
  pcVar4 = strchr(param_2,0x66);
  if (pcVar4 != (char *)0x0) {
    puVar5 = *(undefined8 **)(param_1 + 0x10);
    *puVar5 = *puVar7;
    puVar5[1] = puVar7[1];
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  }
  if (*(char *)(param_1 + 10) == '\x01') {
    plVar1 = *(longlong **)(param_1 + 0x20);
    lVar2 = *plVar1;
    *plVar1 = plVar1[7] + *(longlong *)(param_1 + 0x38);
    plVar1[7] = lVar2 - *(longlong *)(param_1 + 0x38);
  }
  pcVar4 = strchr(param_2,0x4c);
  if (pcVar4 != (char *)0x0) {
    FUN_140525d20(param_1,puVar6);
  }
  return uVar3;
}

// ==== CLuaScript::helper_140526ad0  @140526ad0  [medium:callgraph-r2]  (orig: FUN_140526ad0)
void FUN_140526ad0(undefined8 param_1,longlong param_2,undefined8 param_3)

{
  undefined *puVar1;
  undefined8 uVar2;
  
  puVar1 = (&PTR_DAT_14079fdf8)[*(uint *)(param_2 + 8) & 0xf];
  uVar2 = FUN_140526400();
                    /* WARNING: Subroutine does not return */
  FUN_140526620(param_1,"attempt to %s a %s value%s",param_3,puVar1,uVar2);
}

// ==== CLuaScript::helper_140526ca0  @140526ca0  [medium:callgraph-r2]  (orig: FUN_140526ca0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140526ca0(undefined8 param_1)

{
  ulonglong uVar1;
  undefined1 auStack_58 [32];
  undefined4 local_38 [2];
  undefined8 local_30;
  undefined4 *local_28;
  undefined8 *local_20;
  code *local_18;
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  uVar1 = _time64((__time64_t *)0x0);
  local_28 = local_38;
  local_20 = &DAT_14079fb60;
  local_18 = FUN_1405272d0;
  local_38[0] = (int)uVar1;
  local_30 = param_1;
  FUN_140530600(&local_30,0x20,uVar1 & 0xffffffff);
  return;
}

// ==== CLuaScript::helper_140526d10  @140526d10  [medium:callgraph-r2]  (orig: FUN_140526d10)
void FUN_140526d10(longlong param_1,longlong param_2)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  *(longlong *)(param_1 + 0x18) = param_2;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + (lVar1 - param_2);
  return;
}

// ==== CLuaScript::helper_140526d20  @140526d20  [medium:callgraph-r3]  (orig: FUN_140526d20)
void FUN_140526d20(longlong param_1)

{
  undefined8 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_140531b40(param_1,0,0,0x48);
  *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x18) = lVar2;
  uVar1 = *(undefined8 *)(param_1 + 0x20);
  *(undefined8 *)(lVar2 + 0x18) = 0;
  *(undefined8 *)(lVar2 + 0x10) = uVar1;
  return;
}

// ==== CLuaScript::helper_140526d60  @140526d60  [medium:callgraph-r3]  (orig: FUN_140526d60)
void FUN_140526d60(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x18);
  *(undefined8 *)(*(longlong *)(param_1 + 0x20) + 0x18) = 0;
  while (lVar1 != 0) {
    lVar2 = *(longlong *)(lVar1 + 0x18);
    FUN_140531b40(param_1,lVar1,0x48);
    lVar1 = lVar2;
  }
  return;
}

// ==== CLuaScript::helper_140526dc0  @140526dc0  [medium:callgraph-r3]  (orig: FUN_140526dc0)
void FUN_140526dc0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x20) + 0x18);
  lVar3 = *(longlong *)(param_1 + 0x20);
  while( true ) {
    if (lVar1 == 0) {
      return;
    }
    lVar2 = *(longlong *)(*(longlong *)(lVar3 + 0x18) + 0x18);
    if (lVar2 == 0) break;
    FUN_140531b40(param_1,*(longlong *)(lVar3 + 0x18),0x48);
    *(longlong *)(lVar3 + 0x18) = lVar2;
    *(longlong *)(lVar2 + 0x10) = lVar3;
    lVar1 = *(longlong *)(lVar2 + 0x18);
    lVar3 = lVar2;
  }
  return;
}

// ==== CLuaScript::helper_140526e20  @140526e20  [medium:callgraph-r3]  (orig: FUN_140526e20)
void FUN_140526e20(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = FUN_140531b40(param_2,0,0,0x280);
  *(undefined4 *)(param_1 + 0xb8) = 0x28;
  *(undefined8 *)(param_1 + 0x38) = uVar1;
  lVar2 = 0;
  do {
    lVar3 = lVar2 + 0x20;
    *(undefined4 *)(lVar2 + 8 + *(longlong *)(param_1 + 0x38)) = 0;
    *(undefined4 *)(lVar2 + 0x18 + *(longlong *)(param_1 + 0x38)) = 0;
    lVar2 = lVar3;
  } while (lVar3 < 0x280);
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x38);
  *(longlong *)(param_1 + 0x30) =
       ((longlong)*(int *)(param_1 + 0xb8) + -5) * 0x10 + *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined8 *)(param_1 + 0x78) = 0;
  *(undefined1 *)(param_1 + 0xa2) = 0;
  *(undefined8 *)(param_1 + 0x60) = *(undefined8 *)(param_1 + 0x10);
  *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8) = 0;
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  *(longlong *)(param_1 + 0x68) = *(longlong *)(param_1 + 0x10) + 0x140;
  *(undefined8 **)(param_1 + 0x20) = (undefined8 *)(param_1 + 0x60);
  return;
}

// ==== CLuaScript::helper_140526ee0  @140526ee0  [medium:callgraph-r2]  (orig: FUN_140526ee0)
void FUN_140526ee0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  if (*(longlong *)(param_1 + 0x38) != 0) {
    *(longlong *)(param_1 + 0x20) = param_1 + 0x60;
    lVar1 = *(longlong *)(param_1 + 0x78);
    *(undefined8 *)(param_1 + 0x78) = 0;
    while (lVar1 != 0) {
      lVar2 = *(longlong *)(lVar1 + 0x18);
      FUN_140531b40(param_1,lVar1,0x48);
      lVar1 = lVar2;
    }
    FUN_140531b40(param_1,*(undefined8 *)(param_1 + 0x38),(longlong)*(int *)(param_1 + 0xb8) << 4,0)
    ;
  }
  return;
}

// ==== CLuaScript::helper_140526f60  @140526f60  [medium:callgraph-r3]  (orig: FUN_140526f60)
void FUN_140526f60(undefined8 param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined8 local_18;
  undefined4 local_10;
  
  uVar1 = FUN_14052fa10();
  *(undefined8 *)(param_2 + 0x40) = uVar1;
  *(undefined4 *)(param_2 + 0x48) = 0x45;
  FUN_14052ff70(param_1,uVar1,2);
  local_10 = 0x48;
  local_18 = param_1;
  FUN_140530510(param_1,uVar1,1,&local_18);
  local_18 = FUN_14052fa10(param_1);
  local_10 = 0x45;
  FUN_140530510(param_1,uVar1,2,&local_18);
  return;
}

// ==== CLuaScript::helper_140527000  @140527000  [medium:callgraph-r2]  (orig: FUN_140527000)
void FUN_140527000(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  FUN_140526e20(param_1,param_1);
  FUN_140526f60(param_1,lVar1);
  FUN_140530b50(param_1);
  FUN_14052bba0(param_1);
  FUN_140531ce0(param_1);
  *(undefined1 *)(lVar1 + 0x57) = 1;
  uVar2 = FUN_1405226b0(0);
  *(undefined8 *)(lVar1 + 0xe8) = uVar2;
  return;
}

// ==== CLuaScript::helper_1405270c0  @1405270c0  [medium:callgraph-r1]  (orig: FUN_1405270c0)
void FUN_1405270c0(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  puVar1 = *(undefined8 **)(param_1 + 0x18);
  FUN_140530d60(param_1,*(undefined8 *)(param_1 + 0x38));
  FUN_14052a9c0(param_1);
  FUN_140531b40(param_1,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x30),
                (longlong)*(int *)(*(longlong *)(param_1 + 0x18) + 0x3c) << 3,0);
  uVar2 = FUN_140531b40(param_1,puVar1[0x16],puVar1[0x18],0);
  puVar1[0x18] = 0;
  puVar1[0x16] = uVar2;
  FUN_140526ee0(param_1);
                    /* WARNING: Could not recover jumptable at 0x00014052714e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)*puVar1)(puVar1[1],param_1 + -8,0x6d0,0);
  return;
}

// ==== CLuaScript::helper_1405272d0  @1405272d0  [medium:callgraph-r1]  (orig: FUN_1405272d0)
undefined8 * FUN_1405272d0(code *param_1,undefined8 param_2)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  lVar3 = (*param_1)(param_2,0,8,0x6d0);
  if (lVar3 == 0) {
    return (undefined8 *)0x0;
  }
  *(undefined1 *)(lVar3 + 0x10) = 8;
  puVar4 = (undefined8 *)(lVar3 + 8);
  *puVar4 = 0;
  *(undefined1 *)(lVar3 + 300) = 1;
  *(undefined1 *)(lVar3 + 0x11) = 1;
  *(undefined8 **)(lVar3 + 0x20) = (undefined8 *)(lVar3 + 0xd8);
  *(undefined8 *)(lVar3 + 0x40) = 0;
  *(undefined8 *)(lVar3 + 0x28) = 0;
  *(undefined4 *)(lVar3 + 0xc0) = 0;
  *(undefined8 **)(lVar3 + 0x58) = puVar4;
  *(undefined8 *)(lVar3 + 0x60) = 0;
  *(undefined2 *)(lVar3 + 0xce) = 0;
  *(undefined8 *)(lVar3 + 0xb0) = 0;
  *(undefined1 *)(lVar3 + 0xd0) = 0;
  *(undefined4 *)(lVar3 + 0xc4) = 0;
  *(undefined1 *)(lVar3 + 0xd1) = 1;
  *(undefined4 *)(lVar3 + 200) = 0;
  *(undefined8 *)(lVar3 + 0x48) = 0;
  *(undefined2 *)(lVar3 + 0xcc) = 1;
  *(undefined1 *)(lVar3 + 0x12) = 0;
  *(undefined8 *)(lVar3 + 0xb8) = 0;
  *(undefined8 *)(lVar3 + 0xd8) = param_1;
  *(undefined8 *)(lVar3 + 0xe0) = param_2;
  *(undefined8 **)(lVar3 + 0x1b8) = puVar4;
  uVar1 = FUN_140526ca0(puVar4);
  *(undefined1 *)(lVar3 + 0x12f) = 0;
  *(undefined8 *)(lVar3 + 0x100) = 0;
  *(undefined4 *)(lVar3 + 0x110) = 0;
  *(undefined4 *)(lVar3 + 0x114) = 0;
  *(undefined4 *)(lVar3 + 0x128) = uVar1;
  *(undefined8 *)(lVar3 + 0x108) = 0;
  *(undefined4 *)(lVar3 + 0x120) = 0;
  *(undefined8 *)(lVar3 + 0x188) = 0;
  *(undefined8 *)(lVar3 + 0x198) = 0;
  *(undefined8 *)(lVar3 + 0x1b0) = 0;
  *(undefined8 *)(lVar3 + 0x1c0) = 0;
  *(undefined1 *)(lVar3 + 0x12d) = 7;
  *(undefined1 *)(lVar3 + 0x12e) = 0;
  *(undefined8 *)(lVar3 + 0x178) = 0;
  *(undefined8 *)(lVar3 + 0x170) = 0;
  *(undefined8 *)(lVar3 + 0x140) = 0;
  *(undefined8 *)(lVar3 + 0x130) = 0;
  *(undefined8 *)(lVar3 + 0x138) = 0;
  *(undefined8 *)(lVar3 + 0x150) = 0;
  *(undefined8 *)(lVar3 + 0x148) = 0;
  *(undefined8 *)(lVar3 + 0x168) = 0;
  *(undefined8 *)(lVar3 + 0x160) = 0;
  *(undefined8 *)(lVar3 + 0x158) = 0;
  *(undefined8 *)(lVar3 + 0x180) = 0;
  *(undefined8 *)(lVar3 + 0xe8) = 0x6d0;
  *(undefined8 *)(lVar3 + 0xf0) = 0;
  *(undefined4 *)(lVar3 + 0x1a0) = 0;
  *(undefined4 *)(lVar3 + 0x1a4) = 200;
  *(undefined4 *)(lVar3 + 0x1a8) = 200;
  *(undefined8 *)(lVar3 + 0x290) = 0;
  *(undefined8 *)(lVar3 + 0x298) = 0;
  *(undefined8 *)(lVar3 + 0x2a0) = 0;
  *(undefined8 *)(lVar3 + 0x2a8) = 0;
  *(undefined8 *)(lVar3 + 0x2b0) = 0;
  *(undefined8 *)(lVar3 + 0x2b8) = 0;
  *(undefined8 *)(lVar3 + 0x2c0) = 0;
  *(undefined8 *)(lVar3 + 0x2c8) = 0;
  *(undefined8 *)(lVar3 + 0x2d0) = 0;
  iVar2 = FUN_140527650(puVar4,FUN_140527000,0);
  if (iVar2 != 0) {
    FUN_1405270c0(puVar4);
    puVar4 = (undefined8 *)0x0;
  }
  return puVar4;
}

// ==== CLuaScript::helper_1405274d0  @1405274d0  [medium:callgraph-r0]  (orig: FUN_1405274d0)
void FUN_1405274d0(longlong param_1)

{
  FUN_1405270c0(*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0xe0));
  return;
}

// ==== CLuaScript::helper_1405274e0  @1405274e0  [medium:callgraph-r2]  (orig: FUN_1405274e0)
void FUN_1405274e0(longlong param_1,int param_2,longlong *param_3)

{
  longlong lVar1;
  
  if (param_2 == 4) {
    lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x18) + 0xf0);
    *param_3 = lVar1;
    *(uint *)(param_3 + 1) = *(byte *)(lVar1 + 8) | 0x40;
    *(longlong **)(param_1 + 0x10) = param_3 + 2;
    return;
  }
  if (param_2 != 6) {
    lVar1 = *(longlong *)(param_1 + 0x10);
    *param_3 = *(longlong *)(lVar1 + -0x10);
    param_3[1] = *(longlong *)(lVar1 + -8);
    *(longlong **)(param_1 + 0x10) = param_3 + 2;
    return;
  }
  lVar1 = FUN_1405309a0(param_1,"error in error handling",0x17);
  *param_3 = lVar1;
  *(uint *)(param_3 + 1) = *(byte *)(lVar1 + 8) | 0x40;
  *(longlong **)(param_1 + 0x10) = param_3 + 2;
  return;
}

// ==== CLuaScript::helper_140527580  @140527580  [medium:callgraph-r2]  (orig: FUN_140527580)
void FUN_140527580(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  lVar1 = *(longlong *)(param_1 + 0x58);
  while( true ) {
    if (lVar1 != 0) {
      *(undefined4 *)(*(longlong *)(param_1 + 0x58) + 0x110) = param_2;
                    /* WARNING: Subroutine does not return */
      longjmp((_JBTYPE *)(*(longlong *)(param_1 + 0x58) + 0x10),1);
    }
    lVar1 = *(longlong *)(param_1 + 0x18);
    *(char *)(param_1 + 10) = (char)param_2;
    lVar2 = *(longlong *)(lVar1 + 0xe0);
    if (*(longlong *)(lVar2 + 0x58) == 0) break;
    puVar3 = *(undefined8 **)(lVar2 + 0x10);
    *(undefined8 **)(lVar2 + 0x10) = puVar3 + 2;
    lVar2 = *(longlong *)(param_1 + 0x10);
    *puVar3 = *(undefined8 *)(lVar2 + -0x10);
    puVar3[1] = *(undefined8 *)(lVar2 + -8);
    param_1 = *(longlong *)(lVar1 + 0xe0);
    lVar1 = *(longlong *)(param_1 + 0x58);
  }
  if (*(longlong *)(lVar1 + 0xd8) != 0) {
    FUN_1405274e0(param_1,param_2,*(undefined8 *)(param_1 + 0x10));
    if (*(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) < *(ulonglong *)(param_1 + 0x10)) {
      *(ulonglong *)(*(longlong *)(param_1 + 0x20) + 8) = *(ulonglong *)(param_1 + 0x10);
    }
    (**(code **)(lVar1 + 0xd8))(param_1);
  }
                    /* WARNING: Could not recover jumptable at 0x000140527643. Too many branches */
                    /* WARNING: Subroutine does not return */
                    /* WARNING: Treating indirect jump as call */
  abort();
  return;
}

// ==== CLuaScript::helper_140527650  @140527650  [medium:callgraph-r2]  (orig: FUN_140527650)
undefined4 FUN_140527650(longlong param_1,code *param_2,undefined8 param_3)

{
  undefined2 uVar1;
  int iVar2;
  undefined8 local_128 [2];
  _JBTYPE local_118 [16];
  undefined4 local_18;
  
  uVar1 = *(undefined2 *)(param_1 + 0xc6);
  local_128[0] = *(undefined8 *)(param_1 + 0x58);
  local_18 = 0;
  *(undefined8 **)(param_1 + 0x58) = local_128;
  iVar2 = _setjmp(local_118);
  if (iVar2 == 0) {
    (*param_2)(param_1,param_3);
  }
  *(undefined8 *)(param_1 + 0x58) = local_128[0];
  *(undefined2 *)(param_1 + 0xc6) = uVar1;
  return local_18;
}

// ==== CLuaScript::helper_140527780  @140527780  [medium:callgraph-r3]  (orig: FUN_140527780)
void FUN_140527780(longlong param_1,int param_2)

{
  undefined8 uVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  
  lVar4 = (longlong)*(int *)(param_1 + 0xb8);
  uVar1 = *(undefined8 *)(param_1 + 0x38);
  lVar3 = (longlong)param_2;
  uVar2 = FUN_140531b40(param_1,uVar1,lVar4 << 4,lVar3 << 4);
  *(undefined8 *)(param_1 + 0x38) = uVar2;
  if (lVar4 < lVar3) {
    lVar5 = lVar3 - lVar4;
    lVar4 = lVar4 << 4;
    do {
      lVar5 = lVar5 + -1;
      *(undefined4 *)(lVar4 + 8 + *(longlong *)(param_1 + 0x38)) = 0;
      lVar4 = lVar4 + 0x10;
    } while (lVar5 != 0);
  }
  *(int *)(param_1 + 0xb8) = param_2;
  *(longlong *)(param_1 + 0x30) = (lVar3 + -5) * 0x10 + *(longlong *)(param_1 + 0x38);
  FUN_1405276e0(param_1,uVar1);
  return;
}

// ==== CLuaScript::helper_140527830  @140527830  [medium:callgraph-r3]  (orig: FUN_140527830)
void FUN_140527830(longlong param_1,int param_2)

{
  int iVar1;
  
  if (1000000 < *(int *)(param_1 + 0xb8)) {
                    /* WARNING: Subroutine does not return */
    FUN_140527580(param_1,6);
  }
  param_2 = (int)(*(longlong *)(param_1 + 0x10) - *(longlong *)(param_1 + 0x38) >> 4) + 5 + param_2;
  iVar1 = *(int *)(param_1 + 0xb8) * 2;
  if (1000000 < iVar1) {
    iVar1 = 1000000;
  }
  if (iVar1 < param_2) {
    iVar1 = param_2;
  }
  if (1000000 < iVar1) {
    FUN_140527780(param_1,0xf4308);
                    /* WARNING: Subroutine does not return */
    FUN_140526620(param_1,"stack overflow");
  }
  FUN_140527780(param_1);
  return;
}

// ==== CLuaScript::helper_1405278e0  @1405278e0  [medium:callgraph-r2]  (orig: FUN_1405278e0)
void FUN_1405278e0(longlong param_1)

{
  ulonglong *puVar1;
  longlong lVar2;
  ulonglong uVar3;
  int iVar4;
  int iVar5;
  
  lVar2 = *(longlong *)(param_1 + 0x20);
  uVar3 = *(ulonglong *)(param_1 + 0x10);
  while (lVar2 != 0) {
    puVar1 = (ulonglong *)(lVar2 + 8);
    lVar2 = *(longlong *)(lVar2 + 0x10);
    if (uVar3 < *puVar1) {
      uVar3 = *puVar1;
    }
  }
  iVar4 = (int)((longlong)(uVar3 - *(longlong *)(param_1 + 0x38)) >> 4) + 1;
  iVar5 = ((int)(iVar4 + (iVar4 >> 0x1f & 7U)) >> 3) + 10 + iVar4;
  if (1000000 < iVar5) {
    iVar5 = 1000000;
  }
  if (*(int *)(param_1 + 0xb8) < 0xf4241) {
    FUN_140526dc0();
  }
  else {
    FUN_140526d60();
  }
  if ((iVar4 < 0xf4241) && (iVar5 < *(int *)(param_1 + 0xb8))) {
    FUN_140527780(param_1,iVar5);
  }
  return;
}

// ==== CLuaScript::helper_140527990  @140527990  [medium:callgraph-r3]  (orig: FUN_140527990)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140527990(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  code *pcVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 auStack_d8 [32];
  undefined4 local_b8 [10];
  undefined4 local_90;
  longlong local_40;
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_d8;
  pcVar1 = *(code **)(param_1 + 0xa8);
  if ((pcVar1 != (code *)0x0) && (*(char *)(param_1 + 0xc9) != '\0')) {
    lVar2 = *(longlong *)(param_1 + 0x38);
    lVar3 = *(longlong *)(param_1 + 0x20);
    lVar4 = *(longlong *)(param_1 + 0x10);
    lVar5 = *(longlong *)(lVar3 + 8);
    local_b8[0] = param_2;
    local_90 = param_3;
    local_40 = lVar3;
    if ((longlong)(*(longlong *)(param_1 + 0x30) - lVar4 & 0xfffffffffffffff0U) < 0x141) {
      FUN_140527830(param_1,0x14);
    }
    *(longlong *)(lVar3 + 8) = *(longlong *)(param_1 + 0x10) + 0x140;
    *(undefined1 *)(param_1 + 0xc9) = 0;
    *(byte *)(lVar3 + 0x42) = *(byte *)(lVar3 + 0x42) | 4;
    (*pcVar1)(param_1,local_b8);
    *(undefined1 *)(param_1 + 0xc9) = 1;
    *(longlong *)(lVar3 + 8) = (lVar5 - lVar2) + *(longlong *)(param_1 + 0x38);
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x38) + (lVar4 - lVar2);
    *(byte *)(lVar3 + 0x42) = *(byte *)(lVar3 + 0x42) & 0xfb;
  }
  return;
}

// ==== CLuaScript::helper_140527af0  @140527af0  [medium:callgraph-r3]  (orig: FUN_140527af0)
longlong FUN_140527af0(longlong param_1,longlong param_2,int param_3)

{
  byte bVar1;
  longlong lVar2;
  undefined8 *puVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  
  bVar1 = *(byte *)(param_2 + 10);
  uVar4 = (ulonglong)bVar1;
  if (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) >> 4 <=
      (longlong)(ulonglong)*(byte *)(param_2 + 0xc)) {
    FUN_140527830(param_1,*(byte *)(param_2 + 0xc));
  }
  lVar2 = *(longlong *)(param_1 + 0x10);
  puVar5 = (undefined8 *)(lVar2 + (longlong)param_3 * -0x10);
  if (bVar1 != 0) {
    do {
      puVar3 = *(undefined8 **)(param_1 + 0x10);
      uVar4 = uVar4 - 1;
      *(undefined8 **)(param_1 + 0x10) = puVar3 + 2;
      *puVar3 = *puVar5;
      puVar3[1] = puVar5[1];
      *(undefined4 *)(puVar5 + 1) = 0;
      puVar5 = puVar5 + 2;
    } while (uVar4 != 0);
  }
  return lVar2;
}

// ==== CLuaScript::helper_140527b90  @140527b90  [medium:callgraph-r3]  (orig: FUN_140527b90)
void FUN_140527b90(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  
  puVar2 = (undefined8 *)FUN_14052bc50(param_1,param_2,0x17);
  if (((byte)*(undefined4 *)(puVar2 + 1) & 0xf) != 6) {
                    /* WARNING: Subroutine does not return */
    FUN_140526ad0(param_1,param_2,&DAT_14079d9b4);
  }
  puVar3 = *(undefined8 **)(param_1 + 0x10);
  puVar1 = puVar3;
  for (; param_2 < puVar3; puVar3 = puVar3 + -2) {
    *puVar3 = puVar1[-2];
    puVar3[1] = puVar1[-1];
    puVar1 = puVar1 + -2;
  }
  *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
  *param_2 = *puVar2;
  param_2[1] = puVar2[1];
  return;
}

// ==== CLuaScript::helper_140527c20  @140527c20  [medium:callgraph-r3]  (orig: FUN_140527c20)
int FUN_140527c20(longlong param_1,undefined8 *param_2,int param_3)

{
  short sVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  int iVar5;
  int iVar6;
  
  puVar4 = *(undefined8 **)(param_1 + 0x20);
  if ((*(byte *)(param_1 + 200) & 6) != 0) {
    if ((*(byte *)(param_1 + 200) & 2) != 0) {
      lVar2 = *(longlong *)(param_1 + 0x38);
      FUN_140527990(param_1,1);
      param_2 = (undefined8 *)((longlong)param_2 + (*(longlong *)(param_1 + 0x38) - lVar2));
    }
    *(undefined8 *)(param_1 + 0x28) = *(undefined8 *)(puVar4[2] + 0x28);
  }
  sVar1 = *(short *)(puVar4 + 8);
  iVar6 = (int)sVar1;
  puVar3 = (undefined8 *)*puVar4;
  *(undefined8 *)(param_1 + 0x20) = puVar4[2];
  iVar5 = iVar6;
  puVar4 = puVar3;
  if (sVar1 != 0) {
    do {
      puVar4 = puVar3;
      if (param_3 < 1) break;
      *puVar3 = *param_2;
      puVar4 = puVar3 + 2;
      iVar5 = iVar5 + -1;
      puVar3[1] = param_2[1];
      puVar3 = puVar4;
      param_2 = param_2 + 2;
      param_3 = param_3 + -1;
    } while (iVar5 != 0);
  }
  for (; 0 < iVar5; iVar5 = iVar5 + -1) {
    *(undefined4 *)(puVar4 + 1) = 0;
    puVar4 = puVar4 + 2;
  }
  *(undefined8 **)(param_1 + 0x10) = puVar4;
  return iVar6 + 1;
}

// ==== CLuaScript::helper_140527fe0  @140527fe0  [medium:callgraph-r1]  (orig: FUN_140527fe0)
ulonglong FUN_140527fe0(longlong param_1,undefined8 param_2,undefined8 param_3,longlong param_4,
                       undefined8 param_5)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  
  uVar3 = *(undefined8 *)(param_1 + 0xb0);
  uVar4 = *(undefined8 *)(param_1 + 0x20);
  uVar1 = *(undefined1 *)(param_1 + 0xc9);
  uVar2 = *(undefined2 *)(param_1 + 0xc4);
  *(undefined8 *)(param_1 + 0xb0) = param_5;
  uVar5 = FUN_140527650();
  if ((int)uVar5 != 0) {
    param_4 = param_4 + *(longlong *)(param_1 + 0x38);
    FUN_140530d60(param_1,param_4);
    FUN_1405274e0(param_1,uVar5 & 0xffffffff,param_4);
    *(undefined8 *)(param_1 + 0x20) = uVar4;
    *(undefined1 *)(param_1 + 0xc9) = uVar1;
    *(undefined2 *)(param_1 + 0xc4) = uVar2;
    FUN_1405278e0(param_1);
    uVar5 = uVar5 & 0xffffffff;
  }
  *(undefined8 *)(param_1 + 0xb0) = uVar3;
  return uVar5;
}

// ==== CLuaScript::helper_140528110  @140528110  [medium:callgraph-r3]  (orig: FUN_140528110)
void FUN_140528110(undefined8 param_1,longlong *param_2)

{
  longlong lVar1;
  byte *pbVar2;
  char *pcVar3;
  uint uVar4;
  char *pcVar5;
  undefined8 uVar6;
  
  lVar1 = *(longlong *)*param_2;
  *(longlong *)*param_2 = lVar1 + -1;
  if (lVar1 == 0) {
    uVar4 = FUN_140530f50(*param_2);
  }
  else {
    pbVar2 = *(byte **)(*param_2 + 8);
    uVar4 = (uint)*pbVar2;
    *(byte **)(*param_2 + 8) = pbVar2 + 1;
  }
  if (uVar4 == 0x1b) {
    pcVar3 = (char *)param_2[10];
    if (pcVar3 != (char *)0x0) {
      pcVar5 = strchr(pcVar3,0x62);
      if (pcVar5 == (char *)0x0) {
        FUN_140529770(param_1,"attempt to load a %s chunk (mode is \'%s\')","binary",pcVar3);
                    /* WARNING: Subroutine does not return */
        FUN_140527580(param_1,3);
      }
    }
    uVar6 = FUN_140539e80(param_1,*param_2,param_2 + 1,param_2[0xb]);
  }
  else {
    pcVar3 = (char *)param_2[10];
    if (pcVar3 != (char *)0x0) {
      pcVar5 = strchr(pcVar3,0x74);
      if (pcVar5 == (char *)0x0) {
        FUN_140529770(param_1,"attempt to load a %s chunk (mode is \'%s\')",&DAT_14079fb04,pcVar3);
                    /* WARNING: Subroutine does not return */
        FUN_140527580(param_1,3);
      }
    }
    uVar6 = FUN_140538c10(param_1,*param_2,param_2 + 1,param_2 + 4,param_2[0xb],uVar4);
  }
  FUN_140530c40(param_1,uVar6);
  return;
}

// ==== CLuaScript::helper_140528240  @140528240  [medium:callgraph-r2]  (orig: FUN_140528240)
int FUN_140528240(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 local_88;
  undefined8 local_80;
  undefined8 local_70;
  undefined8 local_68;
  int local_5c;
  undefined8 local_58;
  int local_4c;
  undefined8 local_48;
  int local_3c;
  undefined8 local_38;
  undefined8 local_30;
  
  lVar7 = *(longlong *)(param_1 + 0x10);
  *(short *)(param_1 + 0xc4) = *(short *)(param_1 + 0xc4) + 1;
  uVar3 = *(undefined8 *)(param_1 + 0x20);
  lVar4 = *(longlong *)(param_1 + 0x38);
  uVar2 = *(undefined2 *)(param_1 + 0xc4);
  uVar1 = *(undefined1 *)(param_1 + 0xc9);
  uVar5 = *(undefined8 *)(param_1 + 0xb0);
  local_68 = 0;
  local_5c = 0;
  local_58 = 0;
  local_4c = 0;
  local_48 = 0;
  local_3c = 0;
  local_80 = 0;
  local_70 = 0;
  local_88 = param_2;
  local_38 = param_4;
  local_30 = param_3;
  iVar6 = FUN_140527650(param_1,FUN_140528110,&local_88);
  if (iVar6 != 0) {
    lVar7 = (lVar7 - lVar4) + *(longlong *)(param_1 + 0x38);
    FUN_140530d60(param_1,lVar7);
    FUN_1405274e0(param_1,iVar6,lVar7);
    *(undefined8 *)(param_1 + 0x20) = uVar3;
    *(undefined1 *)(param_1 + 0xc9) = uVar1;
    *(undefined2 *)(param_1 + 0xc4) = uVar2;
    FUN_1405278e0(param_1);
  }
  *(undefined8 *)(param_1 + 0xb0) = uVar5;
  local_80 = FUN_140531b40(param_1,local_80,local_70,0);
  local_70 = 0;
  FUN_140531b40(param_1,local_68,(longlong)local_5c * 2,0);
  FUN_140531b40(param_1,local_58,(longlong)local_4c * 0x18,0);
  FUN_140531b40(param_1,local_48,(longlong)local_3c * 0x18,0);
  *(short *)(param_1 + 0xc4) = *(short *)(param_1 + 0xc4) + -1;
  return iVar6;
}

// ==== CLuaScript::helper_1405283c0  @1405283c0  [medium:callgraph-r2]  (orig: FUN_1405283c0)
undefined8 FUN_1405283c0(longlong param_1,longlong *param_2,undefined2 param_3)

{
  uint uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong lVar5;
  int iVar6;
  code *pcVar7;
  undefined4 uVar8;
  
  uVar1 = *(uint *)(param_2 + 1);
  lVar5 = (longlong)param_2 - *(longlong *)(param_1 + 0x38);
  while( true ) {
    uVar1 = uVar1 & 0x3f;
    if (uVar1 == 6) {
      lVar2 = *(longlong *)(*param_2 + 0x18);
      iVar6 = (int)(*(longlong *)(param_1 + 0x10) - (longlong)param_2 >> 4) + -1;
      if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
        FUN_14052b920(param_1);
      }
      if (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) >> 4 <=
          (longlong)(ulonglong)*(byte *)(lVar2 + 0xc)) {
        FUN_140527830(param_1,*(byte *)(lVar2 + 0xc));
      }
      if (iVar6 < (int)(uint)*(byte *)(lVar2 + 10)) {
        do {
          iVar6 = iVar6 + 1;
          *(undefined4 *)(*(longlong *)(param_1 + 0x10) + 8) = 0;
          *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x10;
        } while (iVar6 < (int)(uint)*(byte *)(lVar2 + 10));
      }
      if (*(char *)(lVar2 + 0xb) == '\0') {
        lVar5 = *(longlong *)(param_1 + 0x38) + lVar5;
        lVar4 = lVar5 + 0x10;
      }
      else {
        lVar4 = FUN_140527af0(param_1,lVar2,iVar6);
        lVar5 = *(longlong *)(param_1 + 0x38) + lVar5;
      }
      plVar3 = *(longlong **)(*(longlong *)(param_1 + 0x20) + 0x18);
      if (plVar3 == (longlong *)0x0) {
        plVar3 = (longlong *)FUN_140526d20(param_1);
      }
      *(longlong **)(param_1 + 0x20) = plVar3;
      *plVar3 = lVar5;
      plVar3[4] = lVar4;
      *(undefined2 *)(plVar3 + 8) = param_3;
      lVar4 = (ulonglong)*(byte *)(lVar2 + 0xc) * 0x10 + lVar4;
      plVar3[1] = lVar4;
      plVar3[5] = *(longlong *)(lVar2 + 0x38);
      *(undefined1 *)((longlong)plVar3 + 0x42) = 2;
      *(longlong *)(param_1 + 0x10) = lVar4;
      if ((*(byte *)(param_1 + 200) & 1) != 0) {
        plVar3[5] = plVar3[5] + 4;
        uVar8 = 0;
        if (((*(byte *)(plVar3[2] + 0x42) & 2) != 0) &&
           (uVar8 = 0, ((byte)*(undefined4 *)(*(longlong *)(plVar3[2] + 0x28) + -4) & 0x3f) == 0x25)
           ) {
          *(byte *)((longlong)plVar3 + 0x42) = *(byte *)((longlong)plVar3 + 0x42) | 0x20;
          uVar8 = 4;
        }
        FUN_140527990(param_1,uVar8,0xffffffff);
        plVar3[5] = plVar3[5] + -4;
      }
      return 0;
    }
    if (uVar1 == 0x16) break;
    if (uVar1 == 0x26) {
      pcVar7 = *(code **)(*param_2 + 0x18);
      goto LAB_1405284f0;
    }
    if ((longlong)
        (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) & 0xfffffffffffffff0U) < 0x11
       ) {
      FUN_140527830(param_1,1);
    }
    param_2 = (longlong *)(*(longlong *)(param_1 + 0x38) + lVar5);
    FUN_140527b90(param_1,param_2);
    uVar1 = *(uint *)(param_2 + 1);
    lVar5 = (longlong)param_2 - *(longlong *)(param_1 + 0x38);
  }
  pcVar7 = (code *)*param_2;
LAB_1405284f0:
  if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
    FUN_14052b920(param_1);
  }
  if ((longlong)
      (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) & 0xfffffffffffffff0U) < 0x141)
  {
    FUN_140527830(param_1,0x14);
  }
  plVar3 = *(longlong **)(*(longlong *)(param_1 + 0x20) + 0x18);
  if (plVar3 == (longlong *)0x0) {
    plVar3 = (longlong *)FUN_140526d20(param_1);
  }
  *(longlong **)(param_1 + 0x20) = plVar3;
  *(undefined2 *)(plVar3 + 8) = param_3;
  *plVar3 = *(longlong *)(param_1 + 0x38) + lVar5;
  lVar5 = *(longlong *)(param_1 + 0x10);
  *(undefined1 *)((longlong)plVar3 + 0x42) = 0;
  plVar3[1] = lVar5 + 0x140;
  if ((*(byte *)(param_1 + 200) & 1) != 0) {
    FUN_140527990(param_1,0,0xffffffff);
  }
  iVar6 = (*pcVar7)(param_1);
  FUN_140527c20(param_1,*(longlong *)(param_1 + 0x10) + (longlong)iVar6 * -0x10,iVar6);
  return 1;
}

// ==== CLuaScript::helper_140528670  @140528670  [medium:callgraph-r1]  (orig: FUN_140528670)
void FUN_140528670(longlong param_1,undefined8 param_2,undefined8 param_3,int param_4)

{
  ushort uVar1;
  int iVar2;
  
  *(short *)(param_1 + 0xc6) = *(short *)(param_1 + 0xc6) + 1;
  uVar1 = *(ushort *)(param_1 + 0xc6);
  if (199 < uVar1) {
    if (uVar1 == 200) {
                    /* WARNING: Subroutine does not return */
      FUN_140526620(param_1,"C stack overflow");
    }
    if (0xe0 < uVar1) {
                    /* WARNING: Subroutine does not return */
      FUN_140527580(param_1,6);
    }
  }
  if (param_4 == 0) {
    *(short *)(param_1 + 0xc4) = *(short *)(param_1 + 0xc4) + 1;
  }
  iVar2 = FUN_1405283c0(param_1);
  if (iVar2 == 0) {
    FUN_14052d370(param_1);
  }
  if (param_4 == 0) {
    *(short *)(param_1 + 0xc4) = *(short *)(param_1 + 0xc4) + -1;
  }
  *(short *)(param_1 + 0xc6) = *(short *)(param_1 + 0xc6) + -1;
  return;
}

// ==== CLuaScript::helper_1405289b0  @1405289b0  [medium:callgraph-r3]  (orig: FUN_1405289b0)
uint FUN_1405289b0(uint param_1)

{
  uint uVar1;
  
  uVar1 = (int)param_1 >> 3 & 0x1f;
  if (uVar1 != 0) {
    param_1 = (param_1 & 7) + 8 << ((char)uVar1 - 1U & 0x1f);
  }
  return param_1;
}

// ==== CLuaScript::helper_140528dc0  @140528dc0  [medium:callgraph-r3]  (orig: FUN_140528dc0)
void FUN_140528dc0(byte *param_1,undefined8 *param_2)

{
  byte bVar1;
  byte bVar2;
  bool bVar3;
  bool bVar4;
  lconv *plVar5;
  ulonglong uVar6;
  int iVar7;
  int iVar8;
  byte *pbVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  double _X;
  
  plVar5 = localeconv();
  iVar13 = 0;
  _X = 0.0;
  bVar1 = *plVar5->decimal_point;
  *param_2 = param_1;
  bVar2 = (&DAT_1407a0c11)[*param_1];
  while ((bVar2 & 8) != 0) {
    pbVar9 = param_1 + 1;
    param_1 = param_1 + 1;
    bVar2 = (&DAT_1407a0c11)[*pbVar9];
  }
  bVar3 = false;
  if (*param_1 == 0x2d) {
    param_1 = param_1 + 1;
    bVar4 = true;
  }
  else {
    bVar4 = bVar3;
    if (*param_1 == 0x2b) {
      param_1 = param_1 + 1;
    }
  }
  if ((*param_1 == 0x30) && ((param_1[1] == 0x78 || (param_1[1] == 0x58)))) {
    param_1 = param_1 + 2;
    iVar12 = iVar13;
    iVar10 = iVar13;
    iVar8 = iVar13;
    iVar11 = iVar13;
    while( true ) {
      while( true ) {
        bVar2 = *param_1;
        if (bVar2 != bVar1) break;
        if (iVar12 != 0) goto LAB_140528eef;
        iVar12 = 1;
        param_1 = param_1 + 1;
      }
      if (((&DAT_1407a0c11)[bVar2] & 0x10) == 0) break;
      if ((iVar11 == 0) && (bVar2 == 0x30)) {
        iVar10 = iVar10 + 1;
      }
      else {
        iVar11 = iVar11 + 1;
        if (iVar11 < 0x1f) {
          if (((&DAT_1407a0c11)[(char)bVar2] & 2) == 0) {
            iVar7 = ((int)(char)bVar2 | 0x20U) - 0x57;
          }
          else {
            iVar7 = (int)(char)bVar2 - 0x30;
          }
          _X = _X * DAT_14079e4b0 + (double)iVar7;
        }
        else {
          iVar8 = iVar8 + 1;
        }
      }
      if (iVar12 != 0) {
        iVar8 = iVar8 + -1;
      }
      param_1 = param_1 + 1;
    }
LAB_140528eef:
    if (iVar10 + iVar11 != 0) {
      *param_2 = param_1;
      iVar8 = iVar8 * 4;
      if ((*param_1 == 0x70) || (*param_1 == 0x50)) {
        pbVar9 = param_1 + 1;
        if (param_1[1] == 0x2d) {
          pbVar9 = param_1 + 2;
          bVar3 = true;
        }
        else if (param_1[1] == 0x2b) {
          pbVar9 = param_1 + 2;
        }
        uVar6 = (ulonglong)*pbVar9;
        if (((&DAT_1407a0c11)[uVar6] & 2) == 0) {
          return;
        }
        do {
          pbVar9 = pbVar9 + 1;
          iVar13 = (char)uVar6 + -0x30 + iVar13 * 10;
          uVar6 = (ulonglong)*pbVar9;
        } while (((&DAT_1407a0c11)[uVar6] & 2) != 0);
        if (bVar3) {
          iVar13 = -iVar13;
        }
        iVar8 = iVar8 + iVar13;
        *param_2 = pbVar9;
      }
      if (bVar4) {
        _X = (double)((ulonglong)_X ^ DAT_14078bc70);
      }
      ldexp(_X,iVar8);
    }
  }
  return;
}

// ==== CLuaScript::helper_140529050  @140529050  [medium:callgraph-r3]  (orig: FUN_140529050)
byte * FUN_140529050(byte *param_1,longlong *param_2)

{
  byte *pbVar1;
  byte bVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  char cVar6;
  ulonglong uVar7;
  int iVar8;
  longlong lVar9;
  
  lVar9 = 0;
  bVar3 = true;
  bVar2 = (&DAT_1407a0c11)[*param_1];
  while ((bVar2 & 8) != 0) {
    pbVar1 = param_1 + 1;
    param_1 = param_1 + 1;
    bVar2 = (&DAT_1407a0c11)[*pbVar1];
  }
  bVar4 = false;
  if (*param_1 == 0x2d) {
    param_1 = param_1 + 1;
    bVar5 = bVar3;
  }
  else {
    bVar5 = bVar4;
    if (*param_1 == 0x2b) {
      param_1 = param_1 + 1;
    }
  }
  bVar2 = *param_1;
  uVar7 = (ulonglong)bVar2;
  if ((bVar2 == 0x30) && ((param_1[1] == 0x78 || (param_1[1] == 0x58)))) {
    uVar7 = (ulonglong)param_1[2];
    param_1 = param_1 + 2;
    bVar2 = (&DAT_1407a0c11)[uVar7];
    while ((bVar2 & 0x10) != 0) {
      cVar6 = (char)uVar7;
      if (((&DAT_1407a0c11)[cVar6] & 2) == 0) {
        iVar8 = ((int)cVar6 | 0x20U) - 0x57;
      }
      else {
        iVar8 = (int)cVar6 - 0x30;
      }
      param_1 = param_1 + 1;
      lVar9 = lVar9 * 0x10 + (longlong)iVar8;
      uVar7 = (ulonglong)*param_1;
      bVar3 = bVar4;
      bVar2 = (&DAT_1407a0c11)[uVar7];
    }
  }
  else if (((&DAT_1407a0c11)[bVar2] & 2) != 0) {
    bVar3 = false;
    do {
      param_1 = param_1 + 1;
      cVar6 = (char)uVar7;
      uVar7 = (ulonglong)*param_1;
      lVar9 = (longlong)cVar6 + -0x30 + lVar9 * 10;
    } while (((&DAT_1407a0c11)[uVar7] & 2) != 0);
  }
  bVar2 = (&DAT_1407a0c11)[*param_1];
  while ((bVar2 & 8) != 0) {
    pbVar1 = param_1 + 1;
    param_1 = param_1 + 1;
    bVar2 = (&DAT_1407a0c11)[*pbVar1];
  }
  if ((!bVar3) && (*param_1 == 0)) {
    if (bVar5) {
      lVar9 = -lVar9;
    }
    *param_2 = lVar9;
    return param_1;
  }
  return (byte *)0x0;
}

// ==== CLuaScript::helper_140529180  @140529180  [medium:callgraph-r2]  (orig: FUN_140529180)
byte * FUN_140529180(byte *param_1,double *param_2)

{
  byte bVar1;
  longlong lVar2;
  char *pcVar3;
  byte *pbVar4;
  double dVar5;
  byte *local_res18 [2];
  
  lVar2 = FUN_140529050(param_1,local_res18);
  if (lVar2 != 0) {
    *(undefined4 *)(param_2 + 1) = 0x13;
    *param_2 = (double)local_res18[0];
    return (byte *)((lVar2 - (longlong)param_1) + 1);
  }
  pcVar3 = strpbrk((char *)param_1,"nN");
  if (pcVar3 == (char *)0x0) {
    pcVar3 = strpbrk((char *)param_1,"xX");
    if (pcVar3 == (char *)0x0) {
      dVar5 = strtod((char *)param_1,(char **)local_res18);
    }
    else {
      dVar5 = (double)FUN_140528dc0();
    }
    if (local_res18[0] != param_1) {
      bVar1 = (&DAT_1407a0c11)[*local_res18[0]];
      while ((bVar1 & 8) != 0) {
        local_res18[0] = local_res18[0] + 1;
        bVar1 = (&DAT_1407a0c11)[*local_res18[0]];
      }
      pbVar4 = (byte *)0x0;
      if (*local_res18[0] == 0) {
        pbVar4 = local_res18[0];
      }
      if (pbVar4 != (byte *)0x0) {
        *param_2 = dVar5;
        *(undefined4 *)(param_2 + 1) = 3;
        return pbVar4 + (1 - (longlong)param_1);
      }
    }
  }
  return (byte *)0x0;
}

// ==== CLuaScript::helper_1405292c0  @1405292c0  [medium:callgraph-r1]  (orig: FUN_1405292c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405292c0(undefined8 param_1,longlong *param_2)

{
  int iVar1;
  size_t sVar2;
  lconv *plVar3;
  longlong lVar4;
  longlong lVar5;
  undefined1 auStack_68 [32];
  char local_48 [56];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_68;
  if ((int)param_2[1] == 0x13) {
    iVar1 = sprintf(local_48,"%lld");
    lVar4 = (longlong)iVar1;
  }
  else {
    iVar1 = sprintf(local_48,"%.14g");
    lVar5 = (longlong)iVar1;
    sVar2 = strspn(local_48,"-0123456789");
    lVar4 = lVar5;
    if (local_48[sVar2] == '\0') {
      plVar3 = localeconv();
      lVar4 = lVar5 + 2;
      local_48[lVar5] = *plVar3->decimal_point;
      local_48[lVar5 + 1] = '0';
    }
  }
  lVar4 = FUN_1405309a0(param_1,local_48,lVar4);
  *param_2 = lVar4;
  *(uint *)(param_2 + 1) = *(byte *)(lVar4 + 8) | 0x40;
  return;
}

// ==== CLuaScript::helper_1405293c0  @1405293c0  [medium:callgraph-r2]  (orig: FUN_1405293c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

longlong FUN_1405293c0(longlong param_1,char *param_2,longlong param_3)

{
  undefined8 *puVar1;
  byte bVar2;
  char cVar3;
  undefined8 uVar4;
  int iVar5;
  char *pcVar6;
  longlong lVar7;
  uint uVar8;
  uint uVar9;
  longlong *plVar10;
  ulonglong uVar11;
  uint uVar12;
  byte *pbVar13;
  byte *pbVar14;
  longlong lVar15;
  int iVar16;
  undefined1 auStack_98 [32];
  byte local_78 [12];
  byte abStack_6c [44];
  ulonglong local_40;
  
  local_40 = DAT_1409707c0 ^ (ulonglong)auStack_98;
  iVar16 = 0;
  pcVar6 = strchr(param_2,0x25);
  if (pcVar6 != (char *)0x0) {
    param_3 = param_3 + -8;
    do {
      if ((longlong)
          (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) & 0xfffffffffffffff0U) <
          0x21) {
        FUN_140527830(param_1,2);
      }
      plVar10 = *(longlong **)(param_1 + 0x10);
      *(longlong **)(param_1 + 0x10) = plVar10 + 2;
      lVar7 = FUN_1405309a0(param_1,param_2,(longlong)pcVar6 - (longlong)param_2);
      *plVar10 = lVar7;
      *(uint *)(plVar10 + 1) = *(byte *)(lVar7 + 8) | 0x40;
      switch(pcVar6[1]) {
      case '%':
        pbVar13 = &DAT_14079fcb4;
LAB_140529600:
        lVar7 = 1;
        break;
      default:
                    /* WARNING: Subroutine does not return */
        FUN_140526620(param_1,"invalid option \'%%%c\' to \'lua_pushfstring\'",(int)pcVar6[1]);
      case 'I':
        plVar10 = *(longlong **)(param_1 + 0x10);
        *(longlong **)(param_1 + 0x10) = plVar10 + 2;
        lVar7 = *(longlong *)(param_3 + 8);
        goto LAB_1405294fd;
      case 'U':
        uVar8 = *(uint *)(param_3 + 8);
        param_3 = param_3 + 8;
        iVar5 = 1;
        lVar15 = 1;
        if (uVar8 < 0x80) {
          lVar7 = 1;
          abStack_6c[3] = (byte)uVar8;
          pbVar13 = abStack_6c + 3;
        }
        else {
          uVar12 = 0x3f;
          pbVar13 = abStack_6c + 3;
          do {
            uVar12 = uVar12 >> 1;
            uVar9 = uVar8 >> 6;
            iVar5 = iVar5 + 1;
            lVar15 = lVar15 + 1;
            *pbVar13 = (byte)uVar8 & 0x3f | 0x80;
            pbVar13 = pbVar13 + -1;
            uVar8 = uVar9;
          } while (uVar12 < uVar9);
          lVar7 = (longlong)iVar5;
          abStack_6c[4 - lVar15] = ~(byte)uVar12 * '\x02' | (byte)uVar9;
          pbVar13 = abStack_6c + (4 - lVar7);
        }
        break;
      case 'c':
        local_78[0] = *(byte *)(param_3 + 8);
        param_3 = param_3 + 8;
        if (((&DAT_1407a0c11)[local_78[0]] & 4) != 0) {
          pbVar13 = local_78;
          goto LAB_140529600;
        }
        FUN_140529770(param_1,"<\\%d>",local_78[0]);
        goto LAB_140529627;
      case 'd':
        plVar10 = *(longlong **)(param_1 + 0x10);
        *(longlong **)(param_1 + 0x10) = plVar10 + 2;
        lVar7 = (longlong)*(int *)(param_3 + 8);
LAB_1405294fd:
        *plVar10 = lVar7;
        *(undefined4 *)(plVar10 + 1) = 0x13;
LAB_140529507:
        param_3 = param_3 + 8;
        FUN_1405292c0(param_1,*(longlong *)(param_1 + 0x10) + -0x10);
        goto LAB_140529627;
      case 'f':
        puVar1 = *(undefined8 **)(param_1 + 0x10);
        *(undefined8 **)(param_1 + 0x10) = puVar1 + 2;
        uVar4 = *(undefined8 *)(param_3 + 8);
        *(undefined4 *)(puVar1 + 1) = 3;
        *puVar1 = uVar4;
        goto LAB_140529507;
      case 'p':
        param_3 = param_3 + 8;
        iVar5 = sprintf((char *)(abStack_6c + 4),"%p");
        plVar10 = *(longlong **)(param_1 + 0x10);
        pbVar13 = abStack_6c + 4;
        lVar7 = (longlong)iVar5;
        *(longlong **)(param_1 + 0x10) = plVar10 + 2;
        goto LAB_140529612;
      case 's':
        puVar1 = (undefined8 *)(param_3 + 8);
        param_3 = param_3 + 8;
        pbVar13 = (byte *)"(null)";
        if ((byte *)*puVar1 != (byte *)0x0) {
          pbVar13 = (byte *)*puVar1;
        }
        uVar11 = 0xffffffffffffffff;
        pbVar14 = pbVar13;
        do {
          if (uVar11 == 0) break;
          uVar11 = uVar11 - 1;
          bVar2 = *pbVar14;
          pbVar14 = pbVar14 + 1;
        } while (bVar2 != 0);
        lVar7 = ~uVar11 - 1;
      }
      plVar10 = *(longlong **)(param_1 + 0x10);
      *(longlong **)(param_1 + 0x10) = plVar10 + 2;
LAB_140529612:
      lVar7 = FUN_1405309a0(param_1,pbVar13,lVar7);
      *plVar10 = lVar7;
      *(uint *)(plVar10 + 1) = *(byte *)(lVar7 + 8) | 0x40;
LAB_140529627:
      param_2 = pcVar6 + 2;
      iVar16 = iVar16 + 2;
      pcVar6 = strchr(param_2,0x25);
    } while (pcVar6 != (char *)0x0);
  }
  if ((longlong)
      (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) & 0xfffffffffffffff0U) < 0x11)
  {
    FUN_140527830(param_1,1);
  }
  uVar11 = 0xffffffffffffffff;
  pcVar6 = param_2;
  do {
    if (uVar11 == 0) break;
    uVar11 = uVar11 - 1;
    cVar3 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar3 != '\0');
  plVar10 = *(longlong **)(param_1 + 0x10);
  *(longlong **)(param_1 + 0x10) = plVar10 + 2;
  lVar7 = FUN_1405309a0(param_1,param_2,~uVar11 - 1);
  *plVar10 = lVar7;
  *(uint *)(plVar10 + 1) = *(byte *)(lVar7 + 8) | 0x40;
  if (0 < iVar16) {
    FUN_14052cc00(param_1,iVar16 + 1);
  }
  return *(longlong *)(*(longlong *)(param_1 + 0x10) + -0x10) + 0x18;
}

// ==== CLuaScript::helper_140529770  @140529770  [medium:callgraph-r3]  (orig: FUN_140529770)
void FUN_140529770(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 local_res18;
  undefined8 local_res20;
  
  local_res18 = param_3;
  local_res20 = param_4;
  FUN_1405293c0(param_1,param_2,&local_res18);
  return;
}

// ==== CLuaScript::helper_140529950  @140529950  [medium:callgraph-r2]  (orig: FUN_140529950)
void FUN_140529950(longlong param_1,longlong param_2)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) & 0xfb;
  *(undefined8 *)(param_2 + 0x30) = *(undefined8 *)(lVar1 + 0x78);
  *(longlong *)(lVar1 + 0x78) = param_2;
  return;
}

// ==== CLuaScript::helper_1405299a0  @1405299a0  [medium:callgraph-r2]  (orig: FUN_1405299a0)
void FUN_1405299a0(longlong param_1,byte param_2,undefined8 param_3)

{
  byte bVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  lVar2 = *(longlong *)(param_1 + 0x18);
  puVar3 = (undefined8 *)FUN_140531b40(param_1,0,param_2 & 0xf,param_3);
  bVar1 = *(byte *)(lVar2 + 0x54);
  *(byte *)(puVar3 + 1) = param_2;
  *(byte *)((longlong)puVar3 + 9) = bVar1 & 3;
  *puVar3 = *(undefined8 *)(lVar2 + 0x58);
  *(undefined8 **)(lVar2 + 0x58) = puVar3;
  return;
}

// ==== CLuaScript::helper_1405299f0  @1405299f0  [medium:callgraph-r3]  (orig: FUN_1405299f0)
void FUN_1405299f0(longlong param_1,longlong param_2)

{
  byte *pbVar1;
  uint uVar2;
  
  *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) & 0xfc;
  uVar2 = *(byte *)(param_2 + 8) - 4;
  if (0x22 < uVar2) {
    return;
  }
LAB_140529a20:
  switch(uVar2) {
  case 0:
    *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) | 4;
    *(longlong *)(param_1 + 0x20) =
         *(longlong *)(param_1 + 0x20) + (longlong)(int)(*(byte *)(param_2 + 0xb) + 1) + 0x18;
    return;
  case 1:
    *(undefined8 *)(param_2 + 0x30) = *(undefined8 *)(param_1 + 0x70);
    break;
  case 2:
  case 0x22:
    *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)(param_1 + 0x70);
    break;
  case 3:
    goto switchD_140529a34_caseD_3;
  case 4:
    *(undefined8 *)(param_2 + 0x48) = *(undefined8 *)(param_1 + 0x70);
    break;
  case 5:
    *(undefined8 *)(param_2 + 0x70) = *(undefined8 *)(param_1 + 0x70);
    break;
  default:
    goto LAB_140529b11;
  case 0x10:
    *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) | 4;
    *(longlong *)(param_1 + 0x20) =
         *(longlong *)(param_1 + 0x20) + *(longlong *)(param_2 + 0x10) + 0x19;
    return;
  }
  *(longlong *)(param_1 + 0x70) = param_2;
LAB_140529b11:
  return;
switchD_140529a34_caseD_3:
  if ((*(longlong *)(param_2 + 0x10) != 0) &&
     ((*(byte *)(*(longlong *)(param_2 + 0x10) + 9) & 3) != 0)) {
    FUN_1405299f0(param_1);
  }
  *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) | 4;
  *(longlong *)(param_1 + 0x20) =
       *(longlong *)(param_1 + 0x20) + *(longlong *)(param_2 + 0x18) + 0x28;
  pbVar1 = (byte *)(param_2 + 10);
  param_2 = *(longlong *)(param_2 + 0x20);
  if ((*pbVar1 & 0x40) == 0) {
    return;
  }
  if ((*(byte *)(param_2 + 9) & 3) == 0) {
    return;
  }
  *(byte *)(param_2 + 9) = *(byte *)(param_2 + 9) & 0xfc;
  uVar2 = *(byte *)(param_2 + 8) - 4;
  if (0x22 < uVar2) {
    return;
  }
  goto LAB_140529a20;
}

// ==== CLuaScript::helper_140529c60  @140529c60  [medium:callgraph-r3]  (orig: FUN_140529c60)
void FUN_140529c60(longlong param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  
  *(undefined8 *)(param_1 + 0x78) = 0;
  *(undefined8 *)(param_1 + 0x70) = 0;
  *(undefined8 *)(param_1 + 0x88) = 0;
  *(undefined8 *)(param_1 + 0x90) = 0;
  *(undefined8 *)(param_1 + 0x80) = 0;
  if ((*(byte *)(*(longlong *)(param_1 + 0xe0) + 9) & 3) != 0) {
    FUN_1405299f0();
  }
  if (((*(byte *)(param_1 + 0x48) & 0x40) != 0) &&
     ((*(byte *)(*(longlong *)(param_1 + 0x40) + 9) & 3) != 0)) {
    FUN_1405299f0(param_1);
  }
  plVar1 = (longlong *)(param_1 + 0x1b8);
  lVar3 = 9;
  do {
    if ((*plVar1 != 0) && ((*(byte *)(*plVar1 + 9) & 3) != 0)) {
      FUN_1405299f0(param_1);
    }
    plVar1 = plVar1 + 1;
    lVar3 = lVar3 + -1;
  } while (lVar3 != 0);
  for (puVar2 = *(undefined8 **)(param_1 + 0x98); puVar2 != (undefined8 *)0x0;
      puVar2 = (undefined8 *)*puVar2) {
    if ((*(byte *)((longlong)puVar2 + 9) & 3) != 0) {
      FUN_1405299f0(param_1,puVar2);
    }
  }
  return;
}

// ==== CLuaScript::helper_14052a1b0  @14052a1b0  [medium:callgraph-r3]  (orig: FUN_14052a1b0)
void FUN_14052a1b0(undefined8 param_1,longlong param_2)

{
  longlong lVar1;
  
  switch(*(undefined1 *)(param_2 + 8)) {
  case 4:
    FUN_1405307f0(param_1);
    lVar1 = (longlong)(int)(*(byte *)(param_2 + 0xb) + 1) + 0x18;
    break;
  case 5:
    FUN_14052fa50(param_1);
    return;
  case 6:
    FUN_14052a120(param_1);
    return;
  case 7:
    lVar1 = *(longlong *)(param_2 + 0x18) + 0x28;
    break;
  case 8:
    FUN_140527280(param_1);
    return;
  case 9:
    FUN_140530e40(param_1);
    return;
  default:
    goto switchD_14052a1ec_caseD_a;
  case 0x14:
    lVar1 = *(longlong *)(param_2 + 0x10) + 0x19;
    break;
  case 0x26:
    lVar1 = (longlong)(int)((*(byte *)(param_2 + 10) + 2) * 0x10);
  }
  FUN_140531b40(param_1,param_2,lVar1,0);
switchD_14052a1ec_caseD_a:
  return;
}

// ==== CLuaScript::helper_14052a460  @14052a460  [medium:callgraph-r3]  (orig: FUN_14052a460)
void FUN_14052a460(undefined8 param_1,longlong param_2)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (*(char *)(param_2 + 0x56) != '\x01') {
    lVar2 = *(longlong *)(param_2 + 0x18);
    uVar3 = FUN_140531b40(param_1,*(undefined8 *)(param_2 + 0xb0),*(undefined8 *)(param_2 + 0xc0),0)
    ;
    iVar1 = *(int *)(param_2 + 0x3c);
    *(undefined8 *)(param_2 + 0xc0) = 0;
    *(undefined8 *)(param_2 + 0xb0) = uVar3;
    if (*(int *)(param_2 + 0x38) < (int)(iVar1 + (iVar1 >> 0x1f & 3U)) >> 2) {
      FUN_140530640(param_1,iVar1 / 2);
    }
    *(longlong *)(param_2 + 0x28) =
         *(longlong *)(param_2 + 0x28) + (*(longlong *)(param_2 + 0x18) - lVar2);
  }
  return;
}

// ==== CLuaScript::helper_14052a560  @14052a560  [medium:callgraph-r3]  (orig: FUN_14052a560)
void FUN_14052a560(longlong param_1,int param_2)

{
  undefined1 uVar1;
  undefined1 uVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong lVar5;
  int iVar6;
  undefined8 *puVar7;
  char *pcVar8;
  undefined8 *local_18;
  uint local_10;
  undefined4 uStack_c;
  
  lVar3 = *(longlong *)(param_1 + 0x18);
  local_18 = *(undefined8 **)(lVar3 + 0x98);
  *(undefined8 *)(lVar3 + 0x98) = *local_18;
  *local_18 = *(undefined8 *)(lVar3 + 0x58);
  *(undefined8 **)(lVar3 + 0x58) = local_18;
  *(byte *)((longlong)local_18 + 9) = *(byte *)((longlong)local_18 + 9) & 0xf7;
  if ((1 < *(byte *)(lVar3 + 0x55)) && (*(byte *)(lVar3 + 0x55) < 6)) {
    *(byte *)((longlong)local_18 + 9) =
         *(byte *)(lVar3 + 0x54) & 3 | *(byte *)((longlong)local_18 + 9) & 0xf8;
  }
  local_10 = *(byte *)(local_18 + 1) | 0x40;
  puVar7 = (undefined8 *)FUN_14052bc50(param_1,&local_18,2);
  if ((puVar7 != (undefined8 *)0x0) && (((byte)*(undefined4 *)(puVar7 + 1) & 0xf) == 6)) {
    uVar1 = *(undefined1 *)(lVar3 + 0x57);
    uVar2 = *(undefined1 *)(param_1 + 0xc9);
    *(undefined1 *)(param_1 + 0xc9) = 0;
    *(undefined1 *)(lVar3 + 0x57) = 0;
    puVar4 = *(undefined8 **)(param_1 + 0x10);
    *puVar4 = *puVar7;
    puVar4[1] = puVar7[1];
    lVar5 = *(longlong *)(param_1 + 0x10);
    *(undefined8 **)(lVar5 + 0x10) = local_18;
    *(ulonglong *)(lVar5 + 0x18) = CONCAT44(uStack_c,local_10);
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + 0x20;
    iVar6 = FUN_140527fe0(param_1,&LAB_14052a540,0,
                          (*(longlong *)(param_1 + 0x10) - *(longlong *)(param_1 + 0x38)) + -0x20,0)
    ;
    *(undefined1 *)(param_1 + 0xc9) = uVar2;
    *(undefined1 *)(lVar3 + 0x57) = uVar1;
    if ((iVar6 != 0) && (param_2 != 0)) {
      if (iVar6 == 2) {
        if (((byte)*(undefined4 *)(*(longlong *)(param_1 + 0x10) + -8) & 0xf) == 4) {
          pcVar8 = (char *)(*(longlong *)(*(longlong *)(param_1 + 0x10) + -0x10) + 0x18);
        }
        else {
          pcVar8 = "no message";
        }
        FUN_140529770(param_1,"error in __gc metamethod (%s)",pcVar8);
        iVar6 = 5;
      }
                    /* WARNING: Subroutine does not return */
      FUN_140527580(param_1,iVar6);
    }
  }
  return;
}

// ==== CLuaScript::helper_14052a6f0  @14052a6f0  [medium:callgraph-r2]  (orig: FUN_14052a6f0)
uint FUN_14052a6f0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  uint uVar3;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  lVar2 = *(longlong *)(lVar1 + 0x98);
  for (uVar3 = 0; (lVar2 != 0 && (uVar3 < *(uint *)(lVar1 + 200))); uVar3 = uVar3 + 1) {
    FUN_14052a560(param_1,1);
    lVar2 = *(longlong *)(lVar1 + 0x98);
  }
  if (*(longlong *)(lVar1 + 0x98) != 0) {
    *(int *)(lVar1 + 200) = *(int *)(lVar1 + 200) * 2;
    return uVar3;
  }
  *(undefined4 *)(lVar1 + 200) = 0;
  return uVar3;
}

// ==== CLuaScript::helper_14052a980  @14052a980  [medium:callgraph-r3]  (orig: FUN_14052a980)
undefined4 FUN_14052a980(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  undefined4 local_res8 [8];
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  local_res8[0] = 0;
  *(undefined1 *)(lVar1 + 0x55) = 2;
  uVar2 = FUN_14052a390(param_1,lVar1 + 0x58,local_res8);
  *(undefined8 *)(lVar1 + 0x60) = uVar2;
  return local_res8[0];
}

// ==== CLuaScript::helper_14052a9c0  @14052a9c0  [medium:callgraph-r2]  (orig: FUN_14052a9c0)
void FUN_14052a9c0(longlong param_1)

{
  longlong *plVar1;
  byte bVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  lVar3 = *(longlong *)(param_1 + 0x18);
  plVar1 = (longlong *)(lVar3 + 0x68);
  plVar8 = (longlong *)(lVar3 + 0x98);
  for (plVar6 = *(longlong **)(lVar3 + 0x98); plVar6 != (longlong *)0x0;
      plVar6 = (longlong *)*plVar6) {
    plVar8 = plVar6;
  }
  plVar6 = (longlong *)*plVar1;
  while (plVar7 = plVar6, plVar7 != (longlong *)0x0) {
    *plVar1 = *plVar7;
    *plVar7 = *plVar8;
    *plVar8 = (longlong)plVar7;
    plVar8 = plVar7;
    plVar6 = (longlong *)*plVar1;
  }
  lVar4 = *(longlong *)(param_1 + 0x18);
  lVar5 = *(longlong *)(lVar4 + 0x98);
  while (lVar5 != 0) {
    FUN_14052a560(param_1,0);
    lVar5 = *(longlong *)(lVar4 + 0x98);
  }
  *(undefined1 *)(lVar3 + 0x54) = 3;
  *(undefined1 *)(lVar3 + 0x56) = 0;
  bVar2 = *(byte *)(*(longlong *)(param_1 + 0x18) + 0x54);
  lVar4 = *plVar1;
  lVar5 = -1;
  while ((lVar4 != 0 && (lVar5 != 0))) {
    plVar8 = (longlong *)*plVar1;
    if ((byte)((bVar2 ^ 3) & (*(byte *)((longlong)plVar8 + 9) ^ 3)) == 0) {
      *plVar1 = *plVar8;
      FUN_14052a1b0(param_1,plVar8);
      plVar8 = plVar1;
    }
    else {
      *(byte *)((longlong)plVar8 + 9) = *(byte *)((longlong)plVar8 + 9) & 0xf8 | bVar2 & 3;
    }
    lVar4 = *plVar8;
    plVar1 = plVar8;
    lVar5 = lVar5 + -1;
  }
  bVar2 = *(byte *)(*(longlong *)(param_1 + 0x18) + 0x54);
  lVar4 = *(longlong *)(lVar3 + 0x58);
  plVar1 = (longlong *)(lVar3 + 0x58);
  lVar5 = -1;
  while ((lVar4 != 0 && (lVar5 != 0))) {
    plVar8 = (longlong *)*plVar1;
    if ((byte)((bVar2 ^ 3) & (*(byte *)((longlong)plVar8 + 9) ^ 3)) == 0) {
      *plVar1 = *plVar8;
      FUN_14052a1b0(param_1,plVar8);
      plVar8 = plVar1;
    }
    else {
      *(byte *)((longlong)plVar8 + 9) = *(byte *)((longlong)plVar8 + 9) & 0xf8 | bVar2 & 3;
    }
    lVar4 = *plVar8;
    plVar1 = plVar8;
    lVar5 = lVar5 + -1;
  }
  bVar2 = *(byte *)(*(longlong *)(param_1 + 0x18) + 0x54);
  lVar4 = *(longlong *)(lVar3 + 0xa0);
  lVar5 = -1;
  plVar1 = (longlong *)(lVar3 + 0xa0);
  while ((lVar4 != 0 && (lVar5 != 0))) {
    plVar8 = (longlong *)*plVar1;
    if ((byte)((bVar2 ^ 3) & (*(byte *)((longlong)plVar8 + 9) ^ 3)) == 0) {
      *plVar1 = *plVar8;
      FUN_14052a1b0(param_1);
      plVar8 = plVar1;
    }
    else {
      *(byte *)((longlong)plVar8 + 9) = *(byte *)((longlong)plVar8 + 9) & 0xf8 | bVar2 & 3;
    }
    lVar4 = *plVar8;
    lVar5 = lVar5 + -1;
    plVar1 = plVar8;
  }
  return;
}

// ==== CLuaScript::helper_14052abb0  @14052abb0  [medium:callgraph-r3]  (orig: FUN_14052abb0)
undefined8 FUN_14052abb0(longlong param_1,longlong param_2,undefined1 param_3,undefined8 param_4)

{
  byte bVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  plVar6 = *(longlong **)(param_2 + 0x60);
  if (plVar6 != (longlong *)0x0) {
    lVar2 = *(longlong *)(param_2 + 0x18);
    bVar1 = *(byte *)(*(longlong *)(param_1 + 0x18) + 0x54);
    lVar3 = *plVar6;
    lVar4 = 0x55;
    while ((lVar3 != 0 && (lVar4 != 0))) {
      plVar5 = (longlong *)*plVar6;
      if ((byte)((bVar1 ^ 3) & (*(byte *)((longlong)plVar5 + 9) ^ 3)) == 0) {
        *plVar6 = *plVar5;
        FUN_14052a1b0(param_1,plVar5);
        plVar5 = plVar6;
      }
      else {
        *(byte *)((longlong)plVar5 + 9) = *(byte *)((longlong)plVar5 + 9) & 0xf8 | bVar1 & 3;
      }
      lVar3 = *plVar5;
      plVar6 = plVar5;
      lVar4 = lVar4 + -1;
    }
    if (*plVar6 == 0) {
      plVar6 = (longlong *)0x0;
    }
    *(longlong **)(param_2 + 0x60) = plVar6;
    *(longlong *)(param_2 + 0x28) =
         *(longlong *)(param_2 + 0x28) + (*(longlong *)(param_2 + 0x18) - lVar2);
    if (plVar6 != (longlong *)0x0) {
      return 0x253;
    }
  }
  *(undefined1 *)(param_2 + 0x55) = param_3;
  *(undefined8 *)(param_2 + 0x60) = param_4;
  return 0;
}

// ==== CLuaScript::helper_14052ad70  @14052ad70  [medium:callgraph-r2]  (orig: FUN_14052ad70)
void FUN_14052ad70(longlong param_1,undefined8 *param_2)

{
  if ((*(byte *)(*(longlong *)(param_1 + 0x18) + 0x55) < 2) &&
     ((*(byte *)(*(longlong *)*param_2 + 9) & 3) != 0)) {
    FUN_1405299f0();
  }
  return;
}

// ==== CLuaScript::helper_14052b130  @14052b130  [medium:callgraph-r3]  (orig: FUN_14052b130)
void FUN_14052b130(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  int iVar4;
  
  lVar2 = *(longlong *)(param_1 + 0x70);
  cVar1 = *(char *)(lVar2 + 8);
  *(byte *)(lVar2 + 9) = *(byte *)(lVar2 + 9) | 4;
  if (cVar1 == '\x05') {
    *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar2 + 0x30);
    lVar2 = FUN_14052b010(param_1,lVar2);
    *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + lVar2;
  }
  else {
    if (cVar1 == '\x06') {
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar2 + 0x10);
      lVar2 = FUN_140529f90(param_1,lVar2);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + lVar2;
      return;
    }
    if (cVar1 == '\b') {
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar2 + 0x48);
      *(undefined8 *)(lVar2 + 0x48) = *(undefined8 *)(param_1 + 0x78);
      *(longlong *)(param_1 + 0x78) = lVar2;
      *(byte *)(lVar2 + 9) = *(byte *)(lVar2 + 9) & 0xfb;
      lVar2 = FUN_14052a020(param_1,lVar2);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + lVar2;
      return;
    }
    if (cVar1 == '\t') {
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar2 + 0x70);
      iVar4 = FUN_140529de0(param_1,lVar2);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + (longlong)iVar4;
      return;
    }
    if (cVar1 == '&') {
      iVar4 = 0;
      *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(lVar2 + 0x10);
      if (*(char *)(lVar2 + 10) != '\0') {
        plVar3 = (longlong *)(lVar2 + 0x20);
        do {
          if (((*(byte *)(plVar3 + 1) & 0x40) != 0) && ((*(byte *)(*plVar3 + 9) & 3) != 0)) {
            FUN_1405299f0(param_1);
          }
          iVar4 = iVar4 + 1;
          plVar3 = plVar3 + 2;
        } while (iVar4 < (int)(uint)*(byte *)(lVar2 + 10));
      }
      *(longlong *)(param_1 + 0x20) =
           *(longlong *)(param_1 + 0x20) + (longlong)(int)((*(byte *)(lVar2 + 10) + 2) * 0x10);
      return;
    }
  }
  return;
}

// ==== CLuaScript::helper_14052b4e0  @14052b4e0  [medium:callgraph-r3]  (orig: FUN_14052b4e0)
longlong FUN_14052b4e0(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  lVar2 = *(longlong *)(lVar1 + 0x78);
  *(undefined1 *)(lVar1 + 0x55) = 8;
  *(undefined8 *)(lVar1 + 0x20) = 0;
  if ((*(byte *)(param_1 + 9) & 3) != 0) {
    FUN_1405299f0(lVar1,param_1);
  }
  if (((*(byte *)(lVar1 + 0x48) & 0x40) != 0) &&
     ((*(byte *)(*(longlong *)(lVar1 + 0x40) + 9) & 3) != 0)) {
    FUN_1405299f0(lVar1);
  }
  plVar8 = (longlong *)(lVar1 + 0x1b8);
  lVar10 = 9;
  do {
    if ((*plVar8 != 0) && ((*(byte *)(*plVar8 + 9) & 3) != 0)) {
      FUN_1405299f0(lVar1);
    }
    plVar8 = plVar8 + 1;
    lVar10 = lVar10 + -1;
  } while (lVar10 != 0);
  FUN_140529be0(lVar1);
  lVar10 = *(longlong *)(lVar1 + 0x70);
  while (lVar10 != 0) {
    FUN_14052b130(lVar1);
    lVar10 = *(longlong *)(lVar1 + 0x70);
  }
  lVar10 = *(longlong *)(lVar1 + 0x20);
  *(longlong *)(lVar1 + 0x70) = lVar2;
  while (lVar2 != 0) {
    FUN_14052b130(lVar1);
    lVar2 = *(longlong *)(lVar1 + 0x70);
  }
  *(undefined8 *)(lVar1 + 0x20) = 0;
  FUN_14052b270(lVar1);
  FUN_14052b3c0(lVar1,*(undefined8 *)(lVar1 + 0x80),0);
  FUN_14052b3c0(lVar1,*(undefined8 *)(lVar1 + 0x90),0);
  lVar2 = *(longlong *)(lVar1 + 0x20);
  uVar3 = *(undefined8 *)(lVar1 + 0x80);
  uVar4 = *(undefined8 *)(lVar1 + 0x90);
  puVar6 = *(undefined8 **)(lVar1 + 0x98);
  puVar7 = (undefined8 *)(lVar1 + 0x98);
  while (puVar9 = puVar6, puVar9 != (undefined8 *)0x0) {
    puVar7 = puVar9;
    puVar6 = (undefined8 *)*puVar9;
  }
  puVar6 = (undefined8 *)(lVar1 + 0x68);
  for (puVar9 = *(undefined8 **)(lVar1 + 0x68); puVar9 != (undefined8 *)0x0;
      puVar9 = (undefined8 *)*puVar9) {
    if ((*(byte *)((longlong)puVar9 + 9) & 3) != 0) {
      *puVar6 = *puVar9;
      *puVar9 = *puVar7;
      *puVar7 = puVar9;
      puVar7 = puVar9;
      puVar9 = puVar6;
    }
    puVar6 = puVar9;
  }
  puVar7 = *(undefined8 **)(lVar1 + 0x98);
  *(undefined4 *)(lVar1 + 200) = 1;
  for (; puVar7 != (undefined8 *)0x0; puVar7 = (undefined8 *)*puVar7) {
    if ((*(byte *)((longlong)puVar7 + 9) & 3) != 0) {
      FUN_1405299f0(lVar1,puVar7);
    }
  }
  lVar5 = *(longlong *)(lVar1 + 0x70);
  while (lVar5 != 0) {
    FUN_14052b130(lVar1);
    lVar5 = *(longlong *)(lVar1 + 0x70);
  }
  *(undefined8 *)(lVar1 + 0x20) = 0;
  FUN_14052b270(lVar1);
  FUN_14052b300(lVar1,*(undefined8 *)(lVar1 + 0x88),0);
  FUN_14052b300(lVar1,*(undefined8 *)(lVar1 + 0x90),0);
  FUN_14052b3c0(lVar1,*(undefined8 *)(lVar1 + 0x80),uVar3);
  FUN_14052b3c0(lVar1,*(undefined8 *)(lVar1 + 0x90),uVar4);
  FUN_140530760(lVar1);
  *(byte *)(lVar1 + 0x54) = *(byte *)(lVar1 + 0x54) ^ 3;
  return *(longlong *)(lVar1 + 0x20) + lVar10 + lVar2;
}

// ==== CLuaScript::helper_14052b700  @14052b700  [medium:callgraph-r2]  (orig: FUN_14052b700)
longlong FUN_14052b700(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar3 = *(longlong *)(param_1 + 0x18);
  switch(*(undefined1 *)(lVar3 + 0x55)) {
  case 0:
    *(undefined8 *)(lVar3 + 0x20) = 0;
    FUN_14052b130(lVar3);
    if (*(longlong *)(lVar3 + 0x70) == 0) {
      *(undefined1 *)(lVar3 + 0x55) = 1;
    }
    return *(longlong *)(lVar3 + 0x20);
  case 1:
    lVar2 = *(longlong *)(lVar3 + 0x70);
    while (lVar2 != 0) {
      FUN_14052b130(lVar3);
      lVar2 = *(longlong *)(lVar3 + 0x70);
    }
    lVar2 = FUN_14052b4e0(param_1);
    iVar1 = FUN_14052a980(param_1);
    *(longlong *)(lVar3 + 0x28) = *(longlong *)(lVar3 + 0x18) + *(longlong *)(lVar3 + 0x10);
    return (longlong)iVar1 * 7 + lVar2;
  case 2:
    lVar3 = FUN_14052abb0(param_1,lVar3,3,lVar3 + 0x68);
    return lVar3;
  case 3:
    lVar3 = FUN_14052abb0(param_1,lVar3,4,lVar3 + 0x98);
    return lVar3;
  case 4:
    lVar3 = FUN_14052abb0(param_1,lVar3,5);
    return lVar3;
  case 5:
    *(byte *)(*(longlong *)(lVar3 + 0xe0) + 9) =
         *(byte *)(lVar3 + 0x54) & 3 | *(byte *)(*(longlong *)(lVar3 + 0xe0) + 9) & 0xf8;
    FUN_14052a460(param_1,lVar3);
    *(undefined1 *)(lVar3 + 0x55) = 6;
    return 0;
  case 6:
    if ((*(longlong *)(lVar3 + 0x98) != 0) && (*(char *)(lVar3 + 0x56) != '\x01')) {
      iVar1 = FUN_14052a6f0(param_1);
      return (longlong)iVar1 * 7;
    }
    *(undefined1 *)(lVar3 + 0x55) = 7;
    break;
  case 7:
    *(longlong *)(lVar3 + 0x20) = (longlong)*(int *)(lVar3 + 0x3c) << 3;
    FUN_140529c60(lVar3);
    *(undefined1 *)(lVar3 + 0x55) = 0;
    return *(longlong *)(lVar3 + 0x20);
  }
  return 0;
}

// ==== CLuaScript::helper_14052b920  @14052b920  [medium:callgraph-r1]  (orig: FUN_14052b920)
void FUN_14052b920(longlong param_1)

{
  longlong lVar1;
  undefined1 auVar2 [16];
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  lVar6 = SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816(*(longlong *)(lVar1 + 0x18)),8) +
          *(longlong *)(lVar1 + 0x18);
  lVar6 = ((lVar6 >> 7) + 1) - (lVar6 >> 0x3f);
  auVar3._8_8_ = 0;
  auVar3._0_8_ = SUB168(SEXT816(0x7fffffffffffffff),8);
  if (lVar6 < SUB168((auVar3 << 0x40 | ZEXT816(0x7fffffffffffffff)) /
                     SEXT816((longlong)*(int *)(lVar1 + 0xd0)),0)) {
    lVar6 = lVar6 * *(int *)(lVar1 + 0xd0);
  }
  else {
    lVar6 = 0x7fffffffffffffff;
  }
  if (*(char *)(lVar1 + 0x57) == '\0') {
    FUN_140526d10(lVar1,0xffffffffffffa240);
    return;
  }
  do {
    lVar5 = FUN_14052b700(param_1);
    lVar6 = lVar6 - lVar5;
    if (lVar6 < -0x95f) break;
  } while (*(char *)(lVar1 + 0x55) != '\a');
  if (*(char *)(lVar1 + 0x55) == '\a') {
    auVar4._8_8_ = 0;
    auVar4._0_8_ = *(ulonglong *)(lVar1 + 0x28);
    lVar6 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar4,8);
    uVar7 = (*(ulonglong *)(lVar1 + 0x28) - lVar6 >> 1) + lVar6 >> 6;
    auVar2._8_8_ = 0;
    auVar2._0_8_ = SUB168(SEXT816(0x7fffffffffffffff),8);
    if ((longlong)*(int *)(lVar1 + 0xcc) <
        SUB168((auVar2 << 0x40 | ZEXT816(0x7fffffffffffffff)) / SEXT816((longlong)uVar7),0)) {
      lVar6 = (longlong)*(int *)(lVar1 + 0xcc) * uVar7;
    }
    else {
      lVar6 = 0x7fffffffffffffff;
    }
    FUN_140526d10(lVar1,(*(longlong *)(lVar1 + 0x18) + *(longlong *)(lVar1 + 0x10)) - lVar6);
    return;
  }
  FUN_140526d10(lVar1,(lVar6 / (longlong)*(int *)(lVar1 + 0xd0)) * 200);
  FUN_14052a6f0(param_1);
  return;
}

// ==== CLuaScript::helper_14052ba20  @14052ba20  [medium:callgraph-r3]  (orig: FUN_14052ba20)
void FUN_14052ba20(longlong param_1,int param_2)

{
  byte bVar1;
  longlong lVar2;
  undefined1 auVar3 [16];
  undefined1 auVar4 [16];
  char cVar5;
  undefined8 uVar6;
  longlong lVar7;
  ulonglong uVar8;
  undefined4 local_res10 [2];
  
  lVar2 = *(longlong *)(param_1 + 0x18);
  if (param_2 != 0) {
    *(undefined1 *)(lVar2 + 0x56) = 1;
  }
  if (*(byte *)(lVar2 + 0x55) < 2) {
    lVar7 = *(longlong *)(param_1 + 0x18);
    local_res10[0] = 0;
    *(undefined1 *)(lVar7 + 0x55) = 2;
    uVar6 = FUN_14052a390(param_1,lVar7 + 0x58,local_res10);
    *(undefined8 *)(lVar7 + 0x60) = uVar6;
  }
  lVar7 = *(longlong *)(param_1 + 0x18);
  cVar5 = (char)(1 << (*(byte *)(lVar7 + 0x55) & 0x1f));
  while (-1 < cVar5) {
    FUN_14052b700(param_1);
    cVar5 = (char)(1 << (*(byte *)(lVar7 + 0x55) & 0x1f));
  }
  lVar7 = *(longlong *)(param_1 + 0x18);
  bVar1 = *(byte *)(lVar7 + 0x55);
  while ((1 << (bVar1 & 0x1f) & 0xffffff7fU) == 0) {
    FUN_14052b700(param_1);
    bVar1 = *(byte *)(lVar7 + 0x55);
  }
  lVar7 = *(longlong *)(param_1 + 0x18);
  bVar1 = *(byte *)(lVar7 + 0x55);
  while ((1 << (bVar1 & 0x1f) & 0x40U) == 0) {
    FUN_14052b700(param_1);
    bVar1 = *(byte *)(lVar7 + 0x55);
  }
  lVar7 = *(longlong *)(param_1 + 0x18);
  cVar5 = (char)(1 << (*(byte *)(lVar7 + 0x55) & 0x1f));
  while (-1 < cVar5) {
    FUN_14052b700(param_1);
    cVar5 = (char)(1 << (*(byte *)(lVar7 + 0x55) & 0x1f));
  }
  *(undefined1 *)(lVar2 + 0x56) = 0;
  auVar4._8_8_ = 0;
  auVar4._0_8_ = *(ulonglong *)(lVar2 + 0x28);
  lVar7 = SUB168(ZEXT816(0x47ae147ae147ae15) * auVar4,8);
  uVar8 = (*(ulonglong *)(lVar2 + 0x28) - lVar7 >> 1) + lVar7 >> 6;
  auVar3._8_8_ = 0;
  auVar3._0_8_ = SUB168(SEXT816(0x7fffffffffffffff),8);
  if ((longlong)*(int *)(lVar2 + 0xcc) <
      SUB168((auVar3 << 0x40 | ZEXT816(0x7fffffffffffffff)) / SEXT816((longlong)uVar8),0)) {
    lVar7 = (longlong)*(int *)(lVar2 + 0xcc) * uVar8;
  }
  else {
    lVar7 = 0x7fffffffffffffff;
  }
  FUN_140526d10(lVar2,(*(longlong *)(lVar2 + 0x18) + *(longlong *)(lVar2 + 0x10)) - lVar7);
  return;
}

// ==== CLuaScript::helper_14052bba0  @14052bba0  [medium:callgraph-r3]  (orig: FUN_14052bba0)
void FUN_14052bba0(longlong param_1)

{
  undefined8 uVar1;
  longlong lVar2;
  
  lVar2 = 0xf8;
  do {
    uVar1 = FUN_140530a40(param_1,*(undefined8 *)("__bxor" + lVar2 + 4));
    *(undefined8 *)(lVar2 + *(longlong *)(param_1 + 0x18)) = uVar1;
    FUN_140529970(param_1,*(undefined8 *)(lVar2 + *(longlong *)(param_1 + 0x18)));
    lVar2 = lVar2 + 8;
  } while (lVar2 < 0x1b8);
  return;
}

// ==== CLuaScript::helper_14052bc10  @14052bc10  [medium:callgraph-r2]  (orig: FUN_14052bc10)
longlong FUN_14052bc10(longlong param_1,byte param_2,undefined8 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_14052fb60(param_1,param_3);
  if (*(int *)(lVar1 + 8) == 0) {
    *(byte *)(param_1 + 10) = *(byte *)(param_1 + 10) | '\x01' << (param_2 & 0x1f);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CLuaScript::helper_14052bc50  @14052bc50  [medium:callgraph-r2]  (orig: FUN_14052bc50)
undefined8 * FUN_14052bc50(longlong param_1,longlong *param_2,int param_3)

{
  uint uVar1;
  undefined8 *puVar2;
  longlong lVar3;
  
  uVar1 = *(uint *)(param_2 + 1) & 0xf;
  if (uVar1 == 5) {
    lVar3 = *(longlong *)(*param_2 + 0x28);
  }
  else if (uVar1 == 7) {
    lVar3 = *(longlong *)(*param_2 + 0x10);
  }
  else {
    lVar3 = *(longlong *)
             (*(longlong *)(param_1 + 0x18) + 0x1b8 + (ulonglong)(*(uint *)(param_2 + 1) & 0xf) * 8)
    ;
  }
  if (lVar3 != 0) {
    puVar2 = (undefined8 *)
             FUN_14052fb60(lVar3,*(undefined8 *)
                                  (*(longlong *)(param_1 + 0x18) + 0xf8 + (longlong)param_3 * 8));
    return puVar2;
  }
  return &DAT_14079fb60;
}

// ==== CLuaScript::helper_14052bcb0  @14052bcb0  [medium:callgraph-r2]  (orig: FUN_14052bcb0)
void FUN_14052bcb0(longlong param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4,
                  undefined8 *param_5,int param_6)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  lVar2 = *(longlong *)(param_1 + 0x38);
  *(undefined8 **)(param_1 + 0x10) = puVar1 + 2;
  *puVar1 = *param_2;
  puVar1[1] = param_2[1];
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  *(undefined8 **)(param_1 + 0x10) = puVar1 + 2;
  *puVar1 = *param_3;
  puVar1[1] = param_3[1];
  puVar1 = *(undefined8 **)(param_1 + 0x10);
  *(undefined8 **)(param_1 + 0x10) = puVar1 + 2;
  *puVar1 = *param_4;
  puVar1[1] = param_4[1];
  if (param_6 == 0) {
    puVar1 = *(undefined8 **)(param_1 + 0x10);
    *(undefined8 **)(param_1 + 0x10) = puVar1 + 2;
    *puVar1 = *param_5;
    puVar1[1] = param_5[1];
  }
  FUN_140528670(param_1,*(longlong *)(param_1 + 0x10) + (longlong)(4 - param_6) * -0x10,param_6,
                *(byte *)(*(longlong *)(param_1 + 0x20) + 0x42) & 2);
  if (param_6 != 0) {
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + -0x10;
    puVar1 = *(undefined8 **)(param_1 + 0x10);
    lVar3 = *(longlong *)(param_1 + 0x38);
    *(undefined8 *)((longlong)param_5 + (lVar3 - lVar2)) = *puVar1;
    *(undefined8 *)((longlong)param_5 + lVar3 + (8 - lVar2)) = puVar1[1];
  }
  return;
}

// ==== CLuaScript::helper_14052bf40  @14052bf40  [medium:callgraph-r3]  (orig: FUN_14052bf40)
void FUN_14052bf40(undefined8 param_1,undefined8 *param_2,undefined8 *param_3,undefined8 param_4,
                  int param_5)

{
  code *pcVar1;
  int iVar2;
  int iVar3;
  undefined8 local_18 [2];
  
  iVar3 = param_5;
  iVar2 = FUN_14052bda0();
  if (iVar2 != 0) {
    return;
  }
  if (param_5 < 0xd) {
LAB_14052c004:
    FUN_140526b80(param_1,param_2,param_3,"perform arithmetic on",iVar3);
    pcVar1 = (code *)swi(3);
    (*pcVar1)();
    return;
  }
  if ((0x11 < param_5) && (param_5 != 0x13)) {
    if (param_5 == 0x16) {
      FUN_140526b20(param_1,param_2,param_3);
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
    goto LAB_14052c004;
  }
  if (*(int *)(param_2 + 1) == 3) {
    local_18[0] = *param_2;
  }
  else {
    iVar2 = FUN_14052c080(param_2,local_18);
    if (iVar2 == 0) goto LAB_14052bfee;
  }
  if (*(int *)(param_3 + 1) == 3) {
    local_18[0] = *param_3;
  }
  else {
    iVar2 = FUN_14052c080(param_3,local_18);
    if (iVar2 == 0) {
LAB_14052bfee:
      FUN_140526b80(param_1,param_2,param_3,"perform bitwise operation on",iVar3);
      pcVar1 = (code *)swi(3);
      (*pcVar1)();
      return;
    }
  }
  FUN_140526be0(param_1,param_2,param_3);
  pcVar1 = (code *)swi(3);
  (*pcVar1)();
  return;
}

// ==== CLuaScript::helper_14052c080  @14052c080  [medium:callgraph-r1]  (orig: FUN_14052c080)
undefined8 FUN_14052c080(longlong *param_1,double *param_2)

{
  longlong lVar1;
  ulonglong uVar2;
  double local_18;
  int local_10;
  
  if ((int)param_1[1] == 0x13) {
    *param_2 = (double)*param_1;
    return 1;
  }
  if (((byte)(int)param_1[1] & 0xf) == 4) {
    lVar1 = *param_1;
    if (*(char *)(lVar1 + 8) == '\x04') {
      uVar2 = (ulonglong)*(byte *)(lVar1 + 0xb);
    }
    else {
      uVar2 = *(ulonglong *)(lVar1 + 0x10);
    }
    lVar1 = FUN_140529180(lVar1 + 0x18,&local_18);
    if (lVar1 == uVar2 + 1) {
      if (local_10 == 0x13) {
        *param_2 = (double)(longlong)local_18;
        return 1;
      }
      *param_2 = local_18;
      return 1;
    }
  }
  return 0;
}

// ==== CLuaScript::helper_14052c120  @14052c120  [medium:callgraph-r3]  (orig: FUN_14052c120)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_14052c120(double *param_1,double *param_2,int param_3)

{
  double dVar1;
  int iVar2;
  longlong lVar3;
  ulonglong uVar4;
  double dVar5;
  double local_28;
  int local_20;
  
  iVar2 = *(int *)(param_1 + 1);
  while (iVar2 != 3) {
    if (*(int *)(param_1 + 1) == 0x13) {
      *param_2 = *param_1;
      return 1;
    }
    if (((byte)*(int *)(param_1 + 1) & 0xf) != 4) {
      return 0;
    }
    dVar1 = *param_1;
    if (*(char *)((longlong)dVar1 + 8) == '\x04') {
      uVar4 = (ulonglong)*(byte *)((longlong)dVar1 + 0xb);
    }
    else {
      uVar4 = *(ulonglong *)((longlong)dVar1 + 0x10);
    }
    lVar3 = FUN_140529180((longlong)dVar1 + 0x18,&local_28);
    if (lVar3 != uVar4 + 1) {
      return 0;
    }
    param_1 = &local_28;
    iVar2 = local_20;
  }
  dVar1 = *param_1;
  dVar5 = floor(dVar1);
  if (dVar1 != dVar5) {
    if (param_3 == 0) {
      return 0;
    }
    if (1 < param_3) {
      dVar5 = dVar5 + DAT_14075cb60;
    }
  }
  if ((_DAT_14079e098 <= dVar5) && (dVar5 < DAT_14079e090)) {
    *param_2 = (double)(longlong)dVar5;
    return 1;
  }
  return 0;
}

// ==== CLuaScript::helper_14052c2e0  @14052c2e0  [medium:callgraph-r1]  (orig: FUN_14052c2e0)
void FUN_14052c2e0(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 *param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  int iVar4;
  
  iVar4 = 0;
  do {
    if ((int)param_2[1] == 0x45) {
      lVar1 = *param_2;
      puVar2 = (undefined8 *)FUN_14052fbb0(lVar1,param_3);
      if ((((*(int *)(puVar2 + 1) != 0) || (lVar1 = *(longlong *)(lVar1 + 0x28), lVar1 == 0)) ||
          ((*(byte *)(lVar1 + 10) & 1) != 0)) ||
         (plVar3 = (longlong *)FUN_14052bc10(lVar1,0), plVar3 == (longlong *)0x0)) {
        *param_4 = *puVar2;
        param_4[1] = puVar2[1];
        return;
      }
    }
    else {
      plVar3 = (longlong *)FUN_14052bc50(param_1,param_2,0);
      if ((int)plVar3[1] == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_140526ad0(param_1,param_2,"index");
      }
    }
    if (((byte)(int)plVar3[1] & 0xf) == 6) {
      FUN_14052bcb0(param_1,plVar3,param_2,param_3,param_4,1);
      return;
    }
    iVar4 = iVar4 + 1;
    param_2 = plVar3;
  } while (iVar4 < 2000);
                    /* WARNING: Subroutine does not return */
  FUN_140526620(param_1,"gettable chain too long; possible loop");
}

// ==== CLuaScript::helper_14052c400  @14052c400  [medium:callgraph-r1]  (orig: FUN_14052c400)
void FUN_14052c400(longlong param_1,longlong *param_2,undefined8 param_3,longlong *param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  
  iVar5 = 0;
  do {
    if ((int)param_2[1] == 0x45) {
      lVar1 = *param_2;
      plVar3 = (longlong *)FUN_14052fbb0(lVar1,param_3);
      if ((int)plVar3[1] != 0) {
LAB_14052c49f:
        *plVar3 = *param_4;
        plVar3[1] = param_4[1];
        *(undefined1 *)(lVar1 + 10) = 0;
        if ((((*(byte *)(param_4 + 1) & 0x40) != 0) && ((*(byte *)(lVar1 + 9) & 4) != 0)) &&
           ((*(byte *)(*param_4 + 9) & 3) != 0)) {
          FUN_140529950(param_1,lVar1);
        }
        return;
      }
      lVar2 = *(longlong *)(lVar1 + 0x28);
      if (((lVar2 == 0) || ((*(byte *)(lVar2 + 10) & 2) != 0)) ||
         (plVar4 = (longlong *)
                   FUN_14052bc10(lVar2,1,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x100)),
         plVar4 == (longlong *)0x0)) {
        if (plVar3 == &DAT_14079fb60) {
          plVar3 = (longlong *)FUN_140530310(param_1,lVar1,param_3);
        }
        goto LAB_14052c49f;
      }
    }
    else {
      plVar4 = (longlong *)FUN_14052bc50(param_1,param_2,1);
      if ((int)plVar4[1] == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_140526ad0(param_1,param_2,"index");
      }
    }
    if (((byte)(int)plVar4[1] & 0xf) == 6) {
      FUN_14052bcb0(param_1,plVar4,param_2,param_3,param_4,0);
      return;
    }
    iVar5 = iVar5 + 1;
    param_2 = plVar4;
    if (1999 < iVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_140526620(param_1,"settable chain too long; possible loop");
    }
  } while( true );
}

// ==== CLuaScript::helper_14052c7f0  @14052c7f0  [medium:callgraph-r3]  (orig: FUN_14052c7f0)
ulonglong FUN_14052c7f0(undefined8 param_1,undefined8 *param_2,undefined8 *param_3)

{
  code *pcVar1;
  int iVar2;
  ulonglong uVar3;
  
  if (((*(uint *)(param_2 + 1) & 0xf) == 3) && (((byte)*(undefined4 *)(param_3 + 1) & 0xf) == 3)) {
    uVar3 = FUN_14052c6f0(param_2,param_3);
  }
  else {
    if (((*(uint *)(param_2 + 1) & 0xf) == 4) && (((byte)*(undefined4 *)(param_3 + 1) & 0xf) == 4))
    {
      iVar2 = FUN_14052c570(*param_2,*param_3);
      return (ulonglong)(iVar2 < 0);
    }
    uVar3 = FUN_14052c030(param_1,param_2,param_3,0x14);
    if ((int)uVar3 < 0) {
      FUN_140526c40(param_1,param_2,param_3);
      pcVar1 = (code *)swi(3);
      uVar3 = (*pcVar1)();
      return uVar3;
    }
  }
  return uVar3;
}

// ==== CLuaScript::helper_14052c890  @14052c890  [medium:callgraph-r3]  (orig: FUN_14052c890)
ulonglong FUN_14052c890(longlong param_1,undefined8 *param_2,undefined8 *param_3)

{
  byte *pbVar1;
  code *pcVar2;
  int iVar3;
  ulonglong uVar4;
  
  if (((*(uint *)(param_2 + 1) & 0xf) == 3) && (((byte)*(undefined4 *)(param_3 + 1) & 0xf) == 3)) {
    uVar4 = FUN_14052c770(param_2,param_3);
    return uVar4;
  }
  if (((*(uint *)(param_2 + 1) & 0xf) == 4) && (((byte)*(undefined4 *)(param_3 + 1) & 0xf) == 4)) {
    iVar3 = FUN_14052c570(*param_2,*param_3);
    return (ulonglong)(iVar3 < 1);
  }
  uVar4 = FUN_14052c030(param_1,param_2,param_3,0x15);
  if ((int)uVar4 < 0) {
    pbVar1 = (byte *)(*(longlong *)(param_1 + 0x20) + 0x42);
    *pbVar1 = *pbVar1 | 0x80;
    iVar3 = FUN_14052c030(param_1,param_3,param_2,0x14);
    pbVar1 = (byte *)(*(longlong *)(param_1 + 0x20) + 0x42);
    *pbVar1 = *pbVar1 ^ 0x80;
    if (iVar3 < 0) {
      FUN_140526c40(param_1,param_2,param_3);
      pcVar2 = (code *)swi(3);
      uVar4 = (*pcVar2)();
      return uVar4;
    }
    uVar4 = (ulonglong)(iVar3 == 0);
  }
  return uVar4;
}

// ==== CLuaScript::helper_14052c970  @14052c970  [medium:callgraph-r3]  (orig: FUN_14052c970)
/* WARNING: Type propagation algorithm not settling */

ulonglong FUN_14052c970(longlong param_1,double *param_2,double *param_3)

{
  uint uVar1;
  int iVar2;
  ulonglong uVar3;
  longlong lVar4;
  double dVar5;
  bool bVar6;
  double local_res10;
  
  uVar1 = *(uint *)(param_2 + 1);
  if ((uVar1 & 0x3f) != (*(uint *)(param_3 + 1) & 0x3f)) {
    if ((uVar1 & 0xf) != (*(uint *)(param_3 + 1) & 0xf)) {
      return 0;
    }
    if ((uVar1 & 0xf) != 3) {
      return 0;
    }
    if (uVar1 == 0x13) {
      dVar5 = *param_2;
    }
    else {
      iVar2 = FUN_14052c120(param_2,&local_res10,0);
      dVar5 = local_res10;
      if (iVar2 == 0) {
        return 0;
      }
    }
    if (*(int *)(param_3 + 1) == 0x13) {
      local_res10 = *param_3;
    }
    else {
      iVar2 = FUN_14052c120(param_3,&local_res10,0);
      if (iVar2 == 0) {
        return 0;
      }
    }
    bVar6 = dVar5 == local_res10;
LAB_14052ca08:
    if (!bVar6) {
      return 0;
    }
    return 1;
  }
  switch(uVar1 & 0x3f) {
  case 0:
    return 1;
  case 1:
    bVar6 = *(int *)param_2 == *(int *)param_3;
    break;
  case 2:
  case 4:
  case 0x13:
  case 0x16:
    bVar6 = *param_2 == *param_3;
    break;
  case 3:
    bVar6 = *param_2 == *param_3;
    if (NAN(*param_2) || NAN(*param_3)) {
      return 0;
    }
    goto LAB_14052ca08;
  case 5:
    if (*param_2 == *param_3) {
      return 1;
    }
    if (param_1 == 0) {
      return 0;
    }
    lVar4 = *(longlong *)((longlong)*param_2 + 0x28);
    if (((lVar4 != 0) && ((*(byte *)(lVar4 + 10) & 0x20) == 0)) &&
       (lVar4 = FUN_14052bc10(lVar4,5,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x120)),
       lVar4 != 0)) goto LAB_14052cb42;
    lVar4 = *(longlong *)((longlong)*param_3 + 0x28);
    goto LAB_14052cb0e;
  default:
    bVar6 = *param_2 == *param_3;
    break;
  case 7:
    if (*param_2 == *param_3) {
      return 1;
    }
    if (param_1 == 0) {
      return 0;
    }
    lVar4 = *(longlong *)((longlong)*param_2 + 0x10);
    if (((lVar4 != 0) && ((*(byte *)(lVar4 + 10) & 0x20) == 0)) &&
       (lVar4 = FUN_14052bc10(lVar4,5,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x120)),
       lVar4 != 0)) goto LAB_14052cb42;
    lVar4 = *(longlong *)((longlong)*param_3 + 0x10);
LAB_14052cb0e:
    if (((lVar4 == 0) || ((*(byte *)(lVar4 + 10) & 0x20) != 0)) ||
       (lVar4 = FUN_14052bc10(lVar4,5,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x120)),
       lVar4 == 0)) {
      return 0;
    }
LAB_14052cb42:
    FUN_14052bcb0(param_1,lVar4,param_2,param_3,*(undefined8 *)(param_1 + 0x10),1);
    iVar2 = (*(int **)(param_1 + 0x10))[2];
    if (iVar2 != 0) {
      if (iVar2 != 1) {
        return 1;
      }
      if (**(int **)(param_1 + 0x10) != 0) {
        return 1;
      }
    }
    return 0;
  case 0x14:
    uVar3 = FUN_1405305c0(*param_2,*param_3);
    return uVar3;
  }
  return (ulonglong)bVar6;
}

// ==== CLuaScript::helper_14052cc00  @14052cc00  [medium:callgraph-r3]  (orig: FUN_14052cc00)
void FUN_14052cc00(longlong param_1,int param_2)

{
  longlong lVar1;
  uint uVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  size_t _Size;
  longlong lVar8;
  longlong lVar9;
  longlong lVar10;
  int iVar11;
  
  do {
    lVar4 = *(longlong *)(param_1 + 0x10);
    iVar11 = 2;
    uVar2 = *(uint *)(lVar4 + -0x18) & 0xf;
    if ((uVar2 == 4) || (uVar2 == 3)) {
      uVar2 = *(uint *)(lVar4 + -8) & 0xf;
      if (uVar2 != 4) {
        if (uVar2 != 3) goto LAB_14052cca3;
        FUN_1405292c0(param_1,lVar4 + -0x10);
      }
      if ((*(int *)(lVar4 + -8) == 0x44) && (*(char *)(*(longlong *)(lVar4 + -0x10) + 0xb) == '\0'))
      {
        uVar2 = *(uint *)(lVar4 + -0x18) & 0xf;
        if ((uVar2 != 4) && (uVar2 == 3)) {
          FUN_1405292c0(param_1,lVar4 + -0x20);
        }
      }
      else if ((*(int *)(lVar4 + -0x18) == 0x44) &&
              (*(char *)(*(longlong *)(lVar4 + -0x20) + 0xb) == '\0')) {
        *(undefined8 *)(lVar4 + -0x20) = *(undefined8 *)(lVar4 + -0x10);
        *(undefined8 *)(lVar4 + -0x18) = *(undefined8 *)(lVar4 + -8);
      }
      else {
        lVar8 = *(longlong *)(lVar4 + -0x10);
        if (*(char *)(lVar8 + 8) == '\x04') {
          uVar6 = (ulonglong)*(byte *)(lVar8 + 0xb);
        }
        else {
          uVar6 = *(ulonglong *)(lVar8 + 0x10);
        }
        lVar8 = 1;
        iVar11 = 1;
        if (1 < (longlong)param_2) {
          plVar7 = (longlong *)(lVar4 + -0x20);
          do {
            if ((*(uint *)(plVar7 + 1) & 0xf) != 4) {
              if ((*(uint *)(plVar7 + 1) & 0xf) != 3) break;
              FUN_1405292c0(param_1,lVar4 + ((longlong)iVar11 + 1) * -0x10);
            }
            lVar9 = *plVar7;
            if (*(char *)(lVar9 + 8) == '\x04') {
              uVar5 = (ulonglong)*(byte *)(lVar9 + 0xb);
            }
            else {
              uVar5 = *(ulonglong *)(lVar9 + 0x10);
            }
            if (0x7fffffffffffffff - uVar6 <= uVar5) {
                    /* WARNING: Subroutine does not return */
              FUN_140526620(param_1,"string length overflow");
            }
            lVar8 = lVar8 + 1;
            uVar6 = uVar6 + uVar5;
            iVar11 = iVar11 + 1;
            plVar7 = plVar7 + -2;
          } while (lVar8 < param_2);
        }
        lVar3 = FUN_140531080(param_1,*(longlong *)(param_1 + 0x18) + 0xb0,uVar6);
        lVar10 = 0;
        plVar7 = (longlong *)(lVar4 + lVar8 * -0x10);
        lVar9 = lVar8;
        do {
          lVar1 = *plVar7;
          if (*(char *)(lVar1 + 8) == '\x04') {
            _Size = (size_t)*(byte *)(lVar1 + 0xb);
          }
          else {
            _Size = *(size_t *)(lVar1 + 0x10);
          }
          memcpy((void *)(lVar3 + lVar10),(void *)(lVar1 + 0x18),_Size);
          lVar9 = lVar9 + -1;
          lVar10 = lVar10 + _Size;
          plVar7 = plVar7 + 2;
        } while (0 < lVar9);
        plVar7 = (longlong *)(lVar4 + lVar8 * -0x10);
        lVar4 = FUN_1405309a0(param_1,lVar3,lVar10);
        *plVar7 = lVar4;
        *(uint *)(plVar7 + 1) = *(byte *)(lVar4 + 8) | 0x40;
      }
    }
    else {
LAB_14052cca3:
      FUN_14052bf40(param_1,lVar4 + -0x20,lVar4 + -0x10,lVar4 + -0x20,0x16);
    }
    param_2 = param_2 + (1 - iVar11);
    *(longlong *)(param_1 + 0x10) = *(longlong *)(param_1 + 0x10) + (longlong)(iVar11 + -1) * -0x10;
    if (param_2 < 2) {
      return;
    }
  } while( true );
}

// ==== CLuaScript::helper_14052ce60  @14052ce60  [medium:callgraph-r3]  (orig: FUN_14052ce60)
void FUN_14052ce60(longlong param_1,ulonglong *param_2,longlong *param_3)

{
  byte bVar1;
  ulonglong uVar2;
  longlong lVar3;
  int iVar4;
  longlong lVar5;
  uint uVar6;
  
  uVar6 = *(uint *)(param_3 + 1) & 0x3f;
  if (uVar6 == 4) {
    bVar1 = *(byte *)(*param_3 + 0xb);
    *(undefined4 *)(param_2 + 1) = 0x13;
    *param_2 = (ulonglong)bVar1;
    return;
  }
  if (uVar6 == 5) {
    lVar3 = *param_3;
    lVar5 = *(longlong *)(lVar3 + 0x28);
    if (((lVar5 == 0) || ((*(byte *)(lVar5 + 10) & 0x10) != 0)) ||
       (lVar5 = FUN_14052bc10(lVar5,4,*(undefined8 *)(*(longlong *)(param_1 + 0x18) + 0x118)),
       lVar5 == 0)) {
      iVar4 = FUN_14052fef0(lVar3);
      *(undefined4 *)(param_2 + 1) = 0x13;
      *param_2 = (longlong)iVar4;
      return;
    }
  }
  else {
    if (uVar6 == 0x14) {
      uVar2 = *(ulonglong *)(*param_3 + 0x10);
      *(undefined4 *)(param_2 + 1) = 0x13;
      *param_2 = uVar2;
      return;
    }
    lVar5 = FUN_14052bc50(param_1,param_3,4);
    if (*(int *)(lVar5 + 8) == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_140526ad0(param_1,param_3,"get length of");
    }
  }
  FUN_14052bcb0(param_1,lVar5,param_3,param_3,param_2,1);
  return;
}

// ==== CLuaScript::helper_14052d040  @14052d040  [medium:callgraph-r3]  (orig: FUN_14052d040)
longlong FUN_14052d040(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  byte *pbVar3;
  longlong lVar4;
  undefined8 *puVar5;
  
  lVar1 = *(longlong *)(param_1 + 0x60);
  if (lVar1 != 0) {
    lVar4 = 0;
    if (0 < (longlong)*(int *)(param_1 + 0x10)) {
      puVar5 = (undefined8 *)(lVar1 + 0x20);
      pbVar3 = (byte *)(*(longlong *)(param_1 + 0x58) + 9);
      do {
        if (pbVar3[-1] == 0) {
          lVar2 = **(longlong **)(param_2 + (ulonglong)*pbVar3 * 8);
        }
        else {
          lVar2 = (ulonglong)*pbVar3 * 0x10 + param_3;
        }
        if (*(longlong *)*puVar5 != lVar2) {
          return 0;
        }
        lVar4 = lVar4 + 1;
        puVar5 = puVar5 + 1;
        pbVar3 = pbVar3 + 0x10;
      } while (lVar4 < *(int *)(param_1 + 0x10));
    }
  }
  return lVar1;
}

// ==== CLuaScript::helper_14052d0d0  @14052d0d0  [medium:callgraph-r3]  (orig: FUN_14052d0d0)
void FUN_14052d0d0(undefined8 param_1,longlong param_2,longlong param_3,longlong param_4,
                  longlong *param_5)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  byte *pbVar5;
  longlong *plVar6;
  
  iVar1 = *(int *)(param_2 + 0x10);
  lVar4 = (longlong)iVar1;
  lVar3 = *(longlong *)(param_2 + 0x58);
  lVar2 = FUN_140530bf0(param_1,iVar1);
  *(longlong *)(lVar2 + 0x18) = param_2;
  *param_5 = lVar2;
  *(undefined4 *)(param_5 + 1) = 0x46;
  if (0 < iVar1) {
    pbVar5 = (byte *)(lVar3 + 9);
    plVar6 = (longlong *)(lVar2 + 0x20);
    do {
      if (pbVar5[-1] == 0) {
        *plVar6 = *(longlong *)(param_3 + (ulonglong)*pbVar5 * 8);
      }
      else {
        lVar3 = FUN_140530cd0(param_1,(ulonglong)*pbVar5 * 0x10 + param_4);
        *plVar6 = lVar3;
      }
      lVar3 = *plVar6;
      plVar6 = plVar6 + 1;
      pbVar5 = pbVar5 + 0x10;
      *(longlong *)(lVar3 + 8) = *(longlong *)(lVar3 + 8) + 1;
      lVar4 = lVar4 + -1;
    } while (lVar4 != 0);
  }
  if ((*(byte *)(param_2 + 9) & 4) == 0) {
    *(longlong *)(param_2 + 0x60) = lVar2;
  }
  return;
}

// ==== CLuaScript::helper_14052d370  @14052d370  [medium:callgraph-r2]  (orig: FUN_14052d370)
void FUN_14052d370(longlong param_1)

{
  int *piVar1;
  longlong lVar2;
  longlong lVar3;
  ulonglong *puVar4;
  longlong *plVar5;
  ulonglong uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  double dVar9;
  longlong lVar10;
  double dVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  ulonglong uVar14;
  double dVar15;
  double *pdVar16;
  uint uVar17;
  int iVar18;
  double *pdVar19;
  longlong *plVar20;
  longlong lVar21;
  double *pdVar22;
  uint uVar23;
  int iVar24;
  uint uVar25;
  longlong *plVar26;
  bool bVar27;
  double local_res18;
  double local_res20;
  undefined8 uVar28;
  double local_188;
  double local_180;
  double local_178;
  double local_170;
  double local_168;
  double local_160;
  double local_158;
  double local_150;
  double local_148;
  double local_140;
  double local_138;
  double local_130;
  double local_128;
  double local_120;
  double local_118;
  double local_110;
  double local_108;
  double local_100;
  double local_f8;
  double local_f0;
  double local_e8;
  double local_e0;
  double local_d8;
  double local_d0;
  double local_c8;
  double local_c0;
  double local_b8;
  int local_b0;
  double local_a8;
  int local_a0;
  double local_98;
  int local_90;
  
  uVar6 = DAT_14078bc70;
  plVar26 = *(longlong **)(param_1 + 0x20);
LAB_14052d3c0:
  lVar10 = plVar26[4];
  lVar2 = *(longlong *)*plVar26;
  lVar3 = *(longlong *)(*(longlong *)(lVar2 + 0x18) + 0x30);
switchD_14052d45d_default:
  uVar25 = *(uint *)plVar26[5];
  plVar26[5] = (longlong)((uint *)plVar26[5] + 1);
  if ((*(byte *)(param_1 + 200) & 0xc) != 0) {
    piVar1 = (int *)(param_1 + 0xc0);
    *piVar1 = *piVar1 + -1;
    if ((*piVar1 == 0) || ((*(byte *)(param_1 + 200) & 4) != 0)) {
      FUN_1405266a0(param_1);
      lVar10 = plVar26[4];
    }
  }
  uVar17 = uVar25 >> 6 & 0xff;
  lVar21 = (longlong)(int)uVar17;
  pdVar22 = (double *)(lVar10 + lVar21 * 0x10);
  switch(uVar25 & 0x3f) {
  case 0:
    *pdVar22 = *(double *)(lVar10 + (ulonglong)(uVar25 >> 0x17) * 0x10);
    pdVar22[1] = *(double *)(lVar10 + 8 + (ulonglong)(uVar25 >> 0x17) * 0x10);
    goto switchD_14052d45d_default;
  case 1:
    *pdVar22 = *(double *)(lVar3 + (ulonglong)(uVar25 >> 0xe) * 0x10);
    pdVar22[1] = *(double *)(lVar3 + 8 + (ulonglong)(uVar25 >> 0xe) * 0x10);
    goto switchD_14052d45d_default;
  case 2:
    uVar25 = *(uint *)plVar26[5];
    plVar26[5] = (longlong)((uint *)plVar26[5] + 1);
    uVar14 = (ulonglong)(uVar25 >> 6);
    *pdVar22 = *(double *)(lVar3 + uVar14 * 0x10);
    pdVar22[1] = *(double *)(lVar3 + 8 + uVar14 * 0x10);
    goto switchD_14052d45d_default;
  case 3:
    *(undefined4 *)(pdVar22 + 1) = 1;
    *(uint *)pdVar22 = uVar25 >> 0x17;
    if ((uVar25 & 0x7fc000) != 0) {
      plVar26[5] = plVar26[5] + 4;
    }
    goto switchD_14052d45d_default;
  case 4:
    pdVar22 = pdVar22 + 1;
    uVar25 = uVar25 >> 0x17;
    do {
      *(undefined4 *)pdVar22 = 0;
      pdVar22 = pdVar22 + 2;
      bVar27 = uVar25 != 0;
      uVar25 = uVar25 - 1;
    } while (bVar27);
    goto switchD_14052d45d_default;
  case 5:
    pdVar16 = (double *)**(undefined8 **)(lVar2 + 0x20 + (ulonglong)(uVar25 >> 0x17) * 8);
    *pdVar22 = *pdVar16;
    pdVar22[1] = pdVar16[1];
    goto switchD_14052d45d_default;
  case 6:
    if ((uVar25 >> 0x16 & 1) == 0) {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10;
    }
    else {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3;
    }
    pdVar16 = (double *)**(undefined8 **)(lVar2 + 0x20 + (ulonglong)(uVar25 >> 0x17) * 8);
    goto LAB_14052d55a;
  case 7:
    if ((uVar25 >> 0x16 & 1) == 0) {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10;
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    else {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3;
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    goto LAB_14052d55a;
  case 8:
    if ((uVar25 >> 0x16 & 1) == 0) {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10;
    }
    else {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3;
    }
    if ((int)uVar25 < 0) {
      lVar10 = (ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3;
    }
    else {
      lVar10 = (ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10;
    }
    FUN_14052c400(param_1,**(undefined8 **)(lVar2 + 0x20 + (longlong)(int)uVar17 * 8),lVar10,lVar21)
    ;
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 9:
    puVar12 = *(undefined8 **)(lVar2 + 0x20 + (ulonglong)(uVar25 >> 0x17) * 8);
    pdVar16 = (double *)*puVar12;
    *pdVar16 = *pdVar22;
    pdVar16[1] = pdVar22[1];
    if (((*(byte *)((undefined8 *)*puVar12 + 1) & 0x40) != 0) &&
       ((undefined8 *)*puVar12 == puVar12 + 2)) {
      FUN_14052ad70(param_1);
    }
    goto switchD_14052d45d_default;
  case 10:
    if ((uVar25 >> 0x16 & 1) == 0) {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10;
    }
    else {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3;
    }
    if ((int)uVar25 < 0) {
      FUN_14052c400(param_1,pdVar22,(ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3,lVar21);
      lVar10 = plVar26[4];
    }
    else {
      FUN_14052c400(param_1,pdVar22,(ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10,lVar21);
      lVar10 = plVar26[4];
    }
    goto switchD_14052d45d_default;
  case 0xb:
    uVar17 = uVar25 >> 0xe & 0x1ff;
    dVar11 = (double)FUN_14052fa10(param_1);
    *(undefined4 *)(pdVar22 + 1) = 0x45;
    *pdVar22 = dVar11;
    if ((uVar25 >> 0x17 != 0) || (uVar17 != 0)) {
      uVar7 = FUN_1405289b0(uVar17);
      uVar8 = FUN_1405289b0(uVar25 >> 0x17);
      FUN_14052ff70(param_1,dVar11,uVar8,uVar7);
    }
    if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
      *(double **)(param_1 + 0x10) = pdVar22 + 2;
      FUN_14052b920(param_1);
      *(longlong *)(param_1 + 0x10) = plVar26[1];
    }
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 0xc:
    pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    pdVar22[2] = *pdVar16;
    pdVar22[3] = pdVar16[1];
    if ((uVar25 >> 0x16 & 1) == 0) {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10;
    }
    else {
      lVar21 = (ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3;
    }
LAB_14052d55a:
    FUN_14052c2e0(param_1,pdVar16,lVar21,pdVar22);
    goto LAB_14052d565;
  case 0xd:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if ((*(int *)(pdVar16 + 1) == 0x13) && (*(int *)(pdVar19 + 1) == 0x13)) {
      dVar11 = *pdVar19;
      dVar15 = *pdVar16;
      *(undefined4 *)(pdVar22 + 1) = 0x13;
      *pdVar22 = (double)((longlong)dVar11 + (longlong)dVar15);
      goto switchD_14052d45d_default;
    }
    if (*(int *)(pdVar16 + 1) == 3) {
      local_res20 = *pdVar16;
LAB_14052d888:
      dVar11 = local_res20;
      if (*(int *)(pdVar19 + 1) == 3) {
        local_180 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_180 + local_res20;
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c080(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_180 + dVar11;
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c080(pdVar16);
      if (iVar24 != 0) goto LAB_14052d888;
    }
    uVar28 = 6;
    break;
  case 0xe:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if ((*(int *)(pdVar16 + 1) == 0x13) && (*(int *)(pdVar19 + 1) == 0x13)) {
      dVar11 = *pdVar16;
      dVar15 = *pdVar19;
      *(undefined4 *)(pdVar22 + 1) = 0x13;
      *pdVar22 = (double)((longlong)dVar11 - (longlong)dVar15);
      goto switchD_14052d45d_default;
    }
    if (*(int *)(pdVar16 + 1) == 3) {
      local_110 = *pdVar16;
LAB_14052d9c0:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_170 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_110 - local_170;
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c080(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_110 - local_170;
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c080(pdVar16);
      if (iVar24 != 0) goto LAB_14052d9c0;
    }
    uVar28 = 7;
    break;
  case 0xf:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if ((*(int *)(pdVar16 + 1) == 0x13) && (*(int *)(pdVar19 + 1) == 0x13)) {
      dVar11 = *pdVar19;
      dVar15 = *pdVar16;
      *(undefined4 *)(pdVar22 + 1) = 0x13;
      *pdVar22 = (double)((longlong)dVar11 * (longlong)dVar15);
      goto switchD_14052d45d_default;
    }
    if (*(int *)(pdVar16 + 1) == 3) {
      local_c8 = *pdVar16;
LAB_14052dad5:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_160 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_160 * local_c8;
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c080(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = local_160 * local_c8;
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c080(pdVar16);
      if (iVar24 != 0) goto LAB_14052dad5;
    }
    uVar28 = 8;
    break;
  case 0x10:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if ((*(int *)(pdVar16 + 1) == 0x13) && (*(int *)(pdVar19 + 1) == 0x13)) {
      dVar11 = *pdVar19;
      if ((longlong)dVar11 + 1U < 2) {
        if (dVar11 == 0.0) {
                    /* WARNING: Subroutine does not return */
          FUN_140526620(param_1,"attempt to perform \'n%%0\'");
        }
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = 0.0;
      }
      else {
        dVar15 = (double)((longlong)*pdVar16 % (longlong)dVar11);
        if ((dVar15 != 0.0) && ((longlong)((ulonglong)dVar11 ^ (ulonglong)*pdVar16) < 0)) {
          dVar15 = (double)((longlong)dVar15 + (longlong)dVar11);
        }
        *pdVar22 = dVar15;
        *(undefined4 *)(pdVar22 + 1) = 0x13;
      }
      goto switchD_14052d45d_default;
    }
    if (*(int *)(pdVar16 + 1) == 3) {
      local_168 = *pdVar16;
      uVar7 = SUB84(local_168,0);
      uVar8 = (undefined4)((ulonglong)local_168 >> 0x20);
LAB_14052e23c:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_158 = *pdVar19;
      }
      else {
        iVar24 = FUN_14052c080(pdVar19);
        if (iVar24 == 0) goto LAB_14052e2a4;
      }
      dVar11 = fmod((double)CONCAT44(uVar8,uVar7),local_158);
      if (dVar11 * local_158 < 0.0) {
        dVar11 = dVar11 + local_158;
      }
      *pdVar22 = dVar11;
      *(undefined4 *)(pdVar22 + 1) = 3;
      goto switchD_14052d45d_default;
    }
    iVar24 = FUN_14052c080(pdVar16);
    if (iVar24 != 0) {
      uVar7 = SUB84(local_168,0);
      uVar8 = (undefined4)((ulonglong)local_168 >> 0x20);
      goto LAB_14052e23c;
    }
LAB_14052e2a4:
    uVar28 = 9;
    break;
  case 0x11:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    iVar24 = *(int *)(pdVar16 + 1);
    if (iVar24 == 3) {
      dVar11 = *pdVar16;
LAB_14052e4a9:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_128 = *pdVar19;
      }
      else {
        iVar24 = FUN_14052c080(pdVar19);
        if (iVar24 == 0) goto LAB_14052e503;
      }
      dVar11 = pow(dVar11,local_128);
      *(undefined4 *)(pdVar22 + 1) = 3;
      *pdVar22 = dVar11;
      goto switchD_14052d45d_default;
    }
    if (iVar24 == 0x13) {
      dVar11 = (double)(longlong)*pdVar16;
      goto LAB_14052e4a9;
    }
    if (((byte)iVar24 & 0xf) == 4) {
      dVar11 = *pdVar16;
      if (*(char *)((longlong)dVar11 + 8) == '\x04') {
        uVar14 = (ulonglong)*(byte *)((longlong)dVar11 + 0xb);
      }
      else {
        uVar14 = *(ulonglong *)((longlong)dVar11 + 0x10);
      }
      lVar21 = FUN_140529180((longlong)dVar11 + 0x18);
      if (lVar21 == uVar14 + 1) {
        dVar11 = local_a8;
        if (local_a0 == 0x13) {
          dVar11 = (double)(longlong)local_a8;
        }
        goto LAB_14052e4a9;
      }
    }
LAB_14052e503:
    uVar28 = 10;
    break;
  case 0x12:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    iVar24 = *(int *)(pdVar16 + 1);
    if (iVar24 == 3) {
      dVar11 = *pdVar16;
LAB_14052dc12:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_100 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = dVar11 / local_100;
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c080(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 3;
        *pdVar22 = dVar11 / local_100;
        goto switchD_14052d45d_default;
      }
    }
    else {
      if (iVar24 == 0x13) {
        dVar11 = (double)(longlong)*pdVar16;
        goto LAB_14052dc12;
      }
      if (((byte)iVar24 & 0xf) == 4) {
        dVar11 = *pdVar16;
        if (*(char *)((longlong)dVar11 + 8) == '\x04') {
          uVar14 = (ulonglong)*(byte *)((longlong)dVar11 + 0xb);
        }
        else {
          uVar14 = *(ulonglong *)((longlong)dVar11 + 0x10);
        }
        lVar21 = FUN_140529180((longlong)dVar11 + 0x18);
        if (lVar21 == uVar14 + 1) {
          dVar11 = local_b8;
          if (local_b0 == 0x13) {
            dVar11 = (double)(longlong)local_b8;
          }
          goto LAB_14052dc12;
        }
      }
    }
    uVar28 = 0xb;
    break;
  case 0x13:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if ((*(int *)(pdVar16 + 1) == 0x13) && (*(int *)(pdVar19 + 1) == 0x13)) {
      dVar11 = *pdVar19;
      dVar15 = *pdVar16;
      if ((longlong)dVar11 + 1U < 2) {
        if (dVar11 == 0.0) {
                    /* WARNING: Subroutine does not return */
          FUN_140526620(param_1,"attempt to divide by zero");
        }
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)-(longlong)dVar15;
      }
      else {
        dVar9 = (double)((longlong)dVar15 / (longlong)dVar11);
        if (((longlong)((ulonglong)dVar11 ^ (ulonglong)dVar15) < 0) &&
           ((longlong)dVar15 % (longlong)dVar11 != 0)) {
          dVar9 = (double)((longlong)dVar9 + -1);
        }
        *pdVar22 = dVar9;
        *(undefined4 *)(pdVar22 + 1) = 0x13;
      }
      goto switchD_14052d45d_default;
    }
    if (*(int *)(pdVar16 + 1) == 3) {
      local_148 = *pdVar16;
LAB_14052e37f:
      if (*(int *)(pdVar19 + 1) == 3) {
        local_138 = *pdVar19;
      }
      else {
        iVar24 = FUN_14052c080(pdVar19);
        if (iVar24 == 0) goto LAB_14052e3dd;
      }
      dVar11 = floor(local_148 / local_138);
      *(undefined4 *)(pdVar22 + 1) = 3;
      *pdVar22 = dVar11;
      goto switchD_14052d45d_default;
    }
    iVar24 = FUN_14052c080(pdVar16);
    if (iVar24 != 0) goto LAB_14052e37f;
LAB_14052e3dd:
    uVar28 = 0xc;
    break;
  case 0x14:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_150 = *pdVar16;
LAB_14052dd04:
      if (*(int *)(pdVar19 + 1) == 0x13) {
        local_d0 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_d0 & (ulonglong)local_150);
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c120(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_d0 & (ulonglong)local_150);
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c120(pdVar16);
      if (iVar24 != 0) goto LAB_14052dd04;
    }
    uVar28 = 0xd;
    break;
  case 0x15:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_140 = *pdVar16;
LAB_14052ddf2:
      if (*(int *)(pdVar19 + 1) == 0x13) {
        local_f0 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_f0 | (ulonglong)local_140);
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c120(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_f0 | (ulonglong)local_140);
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c120(pdVar16);
      if (iVar24 != 0) goto LAB_14052ddf2;
    }
    uVar28 = 0xe;
    break;
  case 0x16:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_130 = *pdVar16;
LAB_14052dee9:
      if (*(int *)(pdVar19 + 1) == 0x13) {
        local_c0 = *pdVar19;
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_c0 ^ (ulonglong)local_130);
        goto switchD_14052d45d_default;
      }
      iVar24 = FUN_14052c120(pdVar19);
      if (iVar24 != 0) {
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((ulonglong)local_c0 ^ (ulonglong)local_130);
        goto switchD_14052d45d_default;
      }
    }
    else {
      iVar24 = FUN_14052c120(pdVar16);
      if (iVar24 != 0) goto LAB_14052dee9;
    }
    uVar28 = 0xf;
    break;
  case 0x17:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_120 = *pdVar16;
LAB_14052dfe4:
      if (*(int *)(pdVar19 + 1) == 0x13) {
        local_e0 = *pdVar19;
      }
      else {
        iVar24 = FUN_14052c120(pdVar19);
        if (iVar24 == 0) goto LAB_14052e0af;
      }
      bVar27 = (longlong)local_e0 < 0;
      dVar15 = local_e0;
      dVar11 = local_120;
LAB_14052e01d:
      if (bVar27) {
        if ((longlong)dVar15 < -0x3f) {
          *(undefined4 *)(pdVar22 + 1) = 0x13;
          *pdVar22 = 0.0;
        }
        else {
          *(undefined4 *)(pdVar22 + 1) = 0x13;
          *pdVar22 = (double)((ulonglong)dVar11 >> (-SUB81(dVar15,0) & 0x3f));
        }
      }
      else if ((longlong)dVar15 < 0x40) {
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = (double)((longlong)dVar11 << (SUB81(dVar15,0) & 0x3f));
      }
      else {
        *(undefined4 *)(pdVar22 + 1) = 0x13;
        *pdVar22 = 0.0;
      }
      goto switchD_14052d45d_default;
    }
    iVar24 = FUN_14052c120(pdVar16);
    if (iVar24 != 0) goto LAB_14052dfe4;
LAB_14052e0af:
    uVar28 = 0x10;
    break;
  case 0x18:
    if ((int)uVar25 < 0) {
      pdVar16 = (double *)((ulonglong)(byte)(uVar25 >> 0x17) * 0x10 + lVar3);
    }
    else {
      pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    }
    if ((uVar25 >> 0x16 & 1) == 0) {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0x1ff) * 0x10 + lVar10);
    }
    else {
      pdVar19 = (double *)((ulonglong)(uVar25 >> 0xe & 0xff) * 0x10 + lVar3);
    }
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_188 = *pdVar16;
LAB_14052e12b:
      dVar11 = local_188;
      if (*(int *)(pdVar19 + 1) == 0x13) {
        local_178 = *pdVar19;
        bVar27 = -(longlong)local_178 < 0;
        dVar15 = (double)-(longlong)local_178;
      }
      else {
        iVar24 = FUN_14052c120(pdVar19);
        if (iVar24 == 0) goto LAB_14052e162;
        bVar27 = -(longlong)local_178 < 0;
        dVar15 = (double)-(longlong)local_178;
      }
      goto LAB_14052e01d;
    }
    iVar24 = FUN_14052c120(pdVar16);
    if (iVar24 != 0) goto LAB_14052e12b;
LAB_14052e162:
    uVar28 = 0x11;
    break;
  case 0x19:
    pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    if (*(int *)(pdVar16 + 1) == 0x13) {
      dVar11 = *pdVar16;
      *(undefined4 *)(pdVar22 + 1) = 0x13;
      *pdVar22 = (double)-(longlong)dVar11;
    }
    else {
      if (*(int *)(pdVar16 + 1) == 3) {
        local_118 = *pdVar16;
      }
      else {
        iVar24 = FUN_14052c080(pdVar16);
        if (iVar24 == 0) {
          uVar28 = 0x12;
          pdVar19 = pdVar16;
          break;
        }
      }
      *(undefined4 *)(pdVar22 + 1) = 3;
      *pdVar22 = (double)((ulonglong)local_118 ^ uVar6);
    }
    goto switchD_14052d45d_default;
  case 0x1a:
    pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    if (*(int *)(pdVar16 + 1) == 0x13) {
      local_108 = *pdVar16;
LAB_14052e5e3:
      *(undefined4 *)(pdVar22 + 1) = 0x13;
      *pdVar22 = (double)~(ulonglong)local_108;
      goto switchD_14052d45d_default;
    }
    iVar24 = FUN_14052c120(pdVar16);
    if (iVar24 != 0) goto LAB_14052e5e3;
    uVar28 = 0x13;
    pdVar19 = pdVar16;
    break;
  case 0x1b:
    iVar24 = *(int *)(lVar10 + 8 + (ulonglong)(uVar25 >> 0x17) * 0x10);
    if ((iVar24 == 0) ||
       ((iVar24 == 1 && (*(int *)(lVar10 + (ulonglong)(uVar25 >> 0x17) * 0x10) == 0)))) {
      *(undefined4 *)pdVar22 = 1;
      *(undefined4 *)(pdVar22 + 1) = 1;
    }
    else {
      *(undefined4 *)(pdVar22 + 1) = 1;
      *(undefined4 *)pdVar22 = 0;
    }
    goto switchD_14052d45d_default;
  case 0x1c:
    FUN_14052ce60(param_1);
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 0x1d:
    uVar17 = uVar25 >> 0xe & 0x1ff;
    *(longlong *)(param_1 + 0x10) = ((longlong)(int)uVar17 + 1) * 0x10 + lVar10;
    FUN_14052cc00(param_1,(uVar17 - (uVar25 >> 0x17)) + 1);
    puVar13 = (undefined8 *)(plVar26[4] + lVar21 * 0x10);
    puVar12 = (undefined8 *)((ulonglong)(uVar25 >> 0x17) * 0x10 + plVar26[4]);
    *puVar13 = *puVar12;
    puVar13[1] = puVar12[1];
    if (0 < *(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18)) {
      if (puVar12 <= puVar13) {
        puVar12 = puVar13 + 2;
      }
      *(undefined8 **)(param_1 + 0x10) = puVar12;
      FUN_14052b920(param_1);
      *(longlong *)(param_1 + 0x10) = plVar26[1];
    }
    lVar10 = plVar26[4];
    *(longlong *)(param_1 + 0x10) = plVar26[1];
    goto switchD_14052d45d_default;
  case 0x1e:
    if (uVar17 != 0) {
      FUN_140530d60(param_1);
    }
    plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1ffff) * 4;
    goto switchD_14052d45d_default;
  case 0x1f:
    uVar25 = FUN_14052c970(param_1);
    if (uVar25 == uVar17) goto LAB_14052e7c0;
    plVar26[5] = plVar26[5] + 4;
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 0x20:
    uVar25 = FUN_14052c7f0(param_1);
    if (uVar25 == uVar17) goto LAB_14052e7c0;
    plVar26[5] = plVar26[5] + 4;
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 0x21:
    uVar25 = FUN_14052c890(param_1);
    if (uVar25 == uVar17) {
LAB_14052e7c0:
      uVar25 = *(uint *)plVar26[5];
      if ((uVar25 >> 6 & 0xff) != 0) {
        FUN_140530d60(param_1);
      }
      lVar10 = plVar26[4];
      plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1fffe) * 4;
    }
    else {
      plVar26[5] = plVar26[5] + 4;
      lVar10 = plVar26[4];
    }
    goto switchD_14052d45d_default;
  case 0x22:
    iVar24 = *(int *)(pdVar22 + 1);
    if ((uVar25 & 0x7fc000) == 0) {
      if ((iVar24 == 0) || ((iVar24 == 1 && (*(int *)pdVar22 == 0)))) goto LAB_14052e965;
    }
    else if ((iVar24 != 0) && ((iVar24 != 1 || (*(int *)pdVar22 != 0)))) goto LAB_14052e965;
    plVar26[5] = plVar26[5] + 4;
    goto switchD_14052d45d_default;
  case 0x23:
    pdVar16 = (double *)((ulonglong)(uVar25 >> 0x17) * 0x10 + lVar10);
    iVar24 = *(int *)(pdVar16 + 1);
    if ((uVar25 & 0x7fc000) == 0) {
      if ((iVar24 != 0) && ((iVar24 != 1 || (*(int *)pdVar16 != 0)))) goto LAB_14052e9c0;
    }
    else if ((iVar24 == 0) || ((iVar24 == 1 && (*(int *)pdVar16 == 0)))) {
LAB_14052e9c0:
      plVar26[5] = plVar26[5] + 4;
      goto switchD_14052d45d_default;
    }
    *pdVar22 = *pdVar16;
    pdVar22[1] = pdVar16[1];
LAB_14052e965:
    uVar25 = *(uint *)plVar26[5];
    if ((uVar25 >> 6 & 0xff) != 0) {
      FUN_140530d60(param_1);
    }
    plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1fffe) * 4;
    goto switchD_14052d45d_default;
  case 0x24:
    iVar24 = (uVar25 >> 0xe & 0x1ff) - 1;
    if (uVar25 >> 0x17 != 0) {
      *(double **)(param_1 + 0x10) = pdVar22 + (ulonglong)(uVar25 >> 0x17) * 2;
    }
    iVar18 = FUN_1405283c0(param_1,pdVar22,iVar24);
    if (iVar18 == 0) {
      plVar26 = *(longlong **)(param_1 + 0x20);
      *(byte *)((longlong)plVar26 + 0x42) = *(byte *)((longlong)plVar26 + 0x42) | 8;
      goto LAB_14052d3c0;
    }
    if (iVar24 < 0) goto LAB_14052d565;
    *(longlong *)(param_1 + 0x10) = plVar26[1];
    lVar10 = plVar26[4];
    goto switchD_14052d45d_default;
  case 0x25:
    if (uVar25 >> 0x17 != 0) {
      *(double **)(param_1 + 0x10) = pdVar22 + (ulonglong)(uVar25 >> 0x17) * 2;
    }
    iVar24 = FUN_1405283c0(param_1,pdVar22,0xffffffff);
    if (iVar24 != 0) goto LAB_14052d565;
    puVar4 = *(ulonglong **)(param_1 + 0x20);
    plVar5 = (longlong *)*puVar4;
    plVar26 = (longlong *)puVar4[2];
    puVar12 = (undefined8 *)*plVar26;
    plVar20 = (longlong *)
              ((ulonglong)*(byte *)(*(longlong *)(*plVar5 + 0x18) + 10) * 0x10 + puVar4[4]);
    if (0 < *(int *)(*(longlong *)(lVar2 + 0x18) + 0x20)) {
      FUN_140530d60(param_1);
    }
    iVar24 = 0;
    if (plVar5 < plVar20) {
      puVar13 = puVar12;
      do {
        iVar24 = iVar24 + 1;
        *puVar13 = *(undefined8 *)(((longlong)plVar5 - (longlong)puVar12) + (longlong)puVar13);
        puVar13[1] = *(undefined8 *)
                      (((longlong)plVar5 - (longlong)puVar12) + -8 + (longlong)(puVar13 + 2));
        puVar13 = puVar13 + 2;
      } while (plVar5 + (longlong)iVar24 * 2 < plVar20);
    }
    plVar26[4] = (puVar4[4] - (longlong)plVar5 & 0xfffffffffffffff0) + (longlong)puVar12;
    lVar10 = (*(longlong *)(param_1 + 0x10) - (longlong)plVar5 & 0xfffffffffffffff0U) +
             (longlong)puVar12;
    *(longlong *)(param_1 + 0x10) = lVar10;
    plVar26[1] = lVar10;
    uVar14 = puVar4[5];
    *(byte *)((longlong)plVar26 + 0x42) = *(byte *)((longlong)plVar26 + 0x42) | 0x20;
    plVar26[5] = uVar14;
    *(longlong **)(param_1 + 0x20) = plVar26;
    goto LAB_14052d3c0;
  case 0x26:
    goto switchD_14052d45d_caseD_26;
  case 0x27:
    if (*(int *)(pdVar22 + 1) == 0x13) {
      dVar15 = pdVar22[2];
      dVar11 = (double)((longlong)pdVar22[4] + (longlong)*pdVar22);
      if ((longlong)pdVar22[4] < 1) {
        bVar27 = SBORROW8((longlong)dVar15,(longlong)dVar11);
        lVar21 = (longlong)dVar15 - (longlong)dVar11;
      }
      else {
        bVar27 = SBORROW8((longlong)dVar11,(longlong)dVar15);
        lVar21 = (longlong)dVar11 - (longlong)dVar15;
      }
      if (dVar11 == dVar15 || bVar27 != lVar21 < 0) {
        plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1ffff) * 4;
        *pdVar22 = dVar11;
        pdVar22[6] = dVar11;
        *(undefined4 *)(pdVar22 + 7) = 0x13;
      }
    }
    else {
      dVar11 = pdVar22[4] + *pdVar22;
      if (pdVar22[4] <= 0.0) {
        bVar27 = dVar11 < pdVar22[2];
      }
      else {
        bVar27 = pdVar22[2] < dVar11;
      }
      if (!bVar27) {
        plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1ffff) * 4;
        *pdVar22 = dVar11;
        pdVar22[6] = dVar11;
        *(undefined4 *)(pdVar22 + 7) = 3;
      }
    }
    goto switchD_14052d45d_default;
  case 0x28:
    if ((*(int *)(pdVar22 + 1) == 0x13) && (*(int *)(pdVar22 + 5) == 0x13)) {
      dVar11 = pdVar22[4];
      iVar24 = FUN_14052c120(pdVar22 + 2,&local_res18,((longlong)dVar11 < 0) + '\x01');
      if (iVar24 == 0) {
        if (*(int *)(pdVar22 + 3) == 3) {
          local_f8 = pdVar22[2];
        }
        else {
          iVar24 = FUN_14052c080();
          if (iVar24 == 0) goto LAB_14052ec7e;
        }
        if (local_f8 <= 0.0) {
          local_res18 = -0.0;
          if ((longlong)dVar11 < 0) goto LAB_14052ec5d;
          dVar11 = 0.0;
        }
        else {
          local_res18 = NAN;
          if (-1 < (longlong)dVar11) goto LAB_14052ec5d;
          dVar11 = 0.0;
        }
      }
      else {
LAB_14052ec5d:
        dVar11 = *pdVar22;
      }
      pdVar22[2] = local_res18;
      *(undefined4 *)(pdVar22 + 3) = 0x13;
      *pdVar22 = (double)((longlong)dVar11 - (longlong)pdVar22[4]);
      *(undefined4 *)(pdVar22 + 1) = 0x13;
    }
    else {
LAB_14052ec7e:
      iVar24 = *(int *)(pdVar22 + 3);
      if (iVar24 == 3) {
        dVar11 = pdVar22[2];
      }
      else if (iVar24 == 0x13) {
        dVar11 = (double)(longlong)pdVar22[2];
      }
      else {
        if (((byte)iVar24 & 0xf) != 4) {
LAB_14052f146:
                    /* WARNING: Subroutine does not return */
          FUN_140526620(param_1,"\'for\' limit must be a number");
        }
        dVar11 = pdVar22[2];
        if (*(char *)((longlong)dVar11 + 8) == '\x04') {
          uVar14 = (ulonglong)*(byte *)((longlong)dVar11 + 0xb);
        }
        else {
          uVar14 = *(ulonglong *)((longlong)dVar11 + 0x10);
        }
        lVar21 = FUN_140529180((longlong)dVar11 + 0x18);
        if (lVar21 != uVar14 + 1) goto LAB_14052f146;
        dVar11 = local_98;
        if (local_90 == 0x13) {
          dVar11 = (double)(longlong)local_98;
        }
      }
      pdVar22[2] = dVar11;
      *(undefined4 *)(pdVar22 + 3) = 3;
      if (*(int *)(pdVar22 + 5) == 3) {
        local_e8 = pdVar22[4];
      }
      else {
        iVar24 = FUN_14052c080(pdVar22 + 4);
        if (iVar24 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_140526620(param_1,"\'for\' step must be a number");
        }
      }
      pdVar22[4] = local_e8;
      *(undefined4 *)(pdVar22 + 5) = 3;
      if (*(int *)(pdVar22 + 1) == 3) {
        local_d8 = *pdVar22;
      }
      else {
        iVar24 = FUN_14052c080(pdVar22);
        if (iVar24 == 0) {
                    /* WARNING: Subroutine does not return */
          FUN_140526620(param_1,"\'for\' initial value must be a number");
        }
      }
      *(undefined4 *)(pdVar22 + 1) = 3;
      *pdVar22 = local_d8 - local_e8;
    }
    plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1ffff) * 4;
    goto switchD_14052d45d_default;
  case 0x29:
    pdVar22[10] = pdVar22[4];
    pdVar22[0xb] = pdVar22[5];
    pdVar22[8] = pdVar22[2];
    pdVar22[9] = pdVar22[3];
    pdVar22[6] = *pdVar22;
    pdVar22[7] = pdVar22[1];
    *(double **)(param_1 + 0x10) = pdVar22 + 0xc;
    FUN_140528670(param_1,pdVar22 + 6,uVar25 >> 0xe & 0x1ff,1);
    lVar10 = plVar26[4];
    *(longlong *)(param_1 + 0x10) = plVar26[1];
    uVar25 = *(uint *)plVar26[5];
    plVar26[5] = (longlong)((uint *)plVar26[5] + 1);
    pdVar22 = (double *)((ulonglong)(uVar25 >> 6 & 0xff) * 0x10 + lVar10);
  case 0x2a:
    if (*(int *)(pdVar22 + 3) != 0) {
      *pdVar22 = pdVar22[2];
      pdVar22[1] = pdVar22[3];
      plVar26[5] = plVar26[5] + (longlong)(int)((uVar25 >> 0xe) - 0x1ffff) * 4;
    }
    goto switchD_14052d45d_default;
  case 0x2b:
    uVar17 = uVar25 >> 0x17;
    uVar23 = uVar25 >> 0xe & 0x1ff;
    if (uVar25 >> 0x17 == 0) {
      uVar17 = (int)(*(longlong *)(param_1 + 0x10) - (longlong)pdVar22 >> 4) - 1;
    }
    if (uVar23 == 0) {
      uVar23 = *(uint *)plVar26[5] >> 6;
      plVar26[5] = (longlong)((uint *)plVar26[5] + 1);
    }
    dVar11 = *pdVar22;
    uVar25 = (uVar23 - 1) * 0x32 + uVar17;
    if (*(uint *)((longlong)dVar11 + 0xc) < uVar25) {
      FUN_140530110(param_1,dVar11,uVar25);
    }
    lVar21 = (longlong)(int)uVar17;
    if (0 < (int)uVar17) {
      pdVar22 = pdVar22 + lVar21 * 2;
      do {
        FUN_140530510(param_1,dVar11,uVar25,pdVar22);
        uVar25 = uVar25 - 1;
        if (((((ulonglong)pdVar22[1] & 0x40) != 0) && ((*(byte *)((longlong)dVar11 + 9) & 4) != 0))
           && ((*(byte *)((longlong)*pdVar22 + 9) & 3) != 0)) {
          FUN_140529950(param_1);
        }
        lVar21 = lVar21 + -1;
        pdVar22 = pdVar22 + -2;
      } while (0 < lVar21);
    }
    *(longlong *)(param_1 + 0x10) = plVar26[1];
    goto switchD_14052d45d_default;
  case 0x2c:
    uVar28 = *(undefined8 *)
              (*(longlong *)(*(longlong *)(lVar2 + 0x18) + 0x40) + (ulonglong)(uVar25 >> 0xe) * 8);
    dVar11 = (double)FUN_14052d040(uVar28,lVar2 + 0x20,lVar10);
    if (dVar11 == 0.0) {
      FUN_14052d0d0(param_1,uVar28,lVar2 + 0x20,lVar10,pdVar22);
    }
    else {
      *pdVar22 = dVar11;
      *(undefined4 *)(pdVar22 + 1) = 0x46;
    }
    if (*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x18) < 1) {
LAB_14052d565:
      lVar10 = plVar26[4];
    }
    else {
      *(double **)(param_1 + 0x10) = pdVar22 + 2;
      FUN_14052b920(param_1);
      *(longlong *)(param_1 + 0x10) = plVar26[1];
      lVar10 = plVar26[4];
    }
    goto switchD_14052d45d_default;
  case 0x2d:
    iVar18 = ((int)(lVar10 - *plVar26 >> 4) - (uint)*(byte *)(*(longlong *)(lVar2 + 0x18) + 10)) +
             -1;
    iVar24 = (uVar25 >> 0x17) - 1;
    if (iVar24 < 0) {
      if (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x10) >> 4 <= (longlong)iVar18) {
        FUN_140527830();
      }
      lVar10 = plVar26[4];
      pdVar22 = (double *)(lVar10 + lVar21 * 0x10);
      *(double **)(param_1 + 0x10) = pdVar22 + (longlong)iVar18 * 2;
      iVar24 = iVar18;
    }
    lVar21 = 0;
    if (0 < iVar24) {
      pdVar16 = (double *)(lVar10 + (longlong)iVar18 * -0x10);
      do {
        if (lVar21 < iVar18) {
          *pdVar22 = *pdVar16;
          pdVar22[1] = pdVar16[1];
        }
        else {
          *(undefined4 *)(pdVar22 + 1) = 0;
        }
        lVar21 = lVar21 + 1;
        pdVar16 = pdVar16 + 2;
        pdVar22 = pdVar22 + 2;
      } while (lVar21 < iVar24);
    }
  default:
    goto switchD_14052d45d_default;
  }
  FUN_14052bf40(param_1,pdVar16,pdVar19,pdVar22,uVar28);
  lVar10 = plVar26[4];
  goto switchD_14052d45d_default;
switchD_14052d45d_caseD_26:
  if (0 < *(int *)(*(longlong *)(lVar2 + 0x18) + 0x20)) {
    FUN_140530d60(param_1,lVar10);
  }
  if (uVar25 >> 0x17 == 0) {
    iVar24 = (int)(*(longlong *)(param_1 + 0x10) - (longlong)pdVar22 >> 4);
  }
  else {
    iVar24 = (uVar25 >> 0x17) - 1;
  }
  iVar24 = FUN_140527c20(param_1,pdVar22,iVar24);
  if ((*(byte *)((longlong)plVar26 + 0x42) & 8) == 0) {
    return;
  }
  plVar26 = *(longlong **)(param_1 + 0x20);
  if (iVar24 != 0) {
    *(longlong *)(param_1 + 0x10) = plVar26[1];
  }
  goto LAB_14052d3c0;
}

// ==== CLuaScript::helper_14052f290  @14052f290  [medium:callgraph-r3]  (orig: FUN_14052f290)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_14052f290(longlong param_1,double *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  double dVar3;
  int local_res10 [2];
  
  switch(*(uint *)(param_2 + 1) & 0x3f) {
  case 1:
  case 0x13:
    return (longlong)(int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U & *(uint *)param_2) * 0x20
           + *(longlong *)(param_1 + 0x18);
  default:
    return ((ulonglong)*(uint *)param_2 %
           (ulonglong)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U | 1)) * 0x20 +
           *(longlong *)(param_1 + 0x18);
  case 3:
    dVar3 = frexp(*param_2,local_res10);
    dVar3 = dVar3 * _DAT_1407a0090;
    if ((dVar3 < _DAT_14079e098) || (DAT_14079e090 <= dVar3)) {
      uVar1 = 0;
    }
    else {
      uVar1 = (int)(longlong)dVar3 + local_res10[0];
      if (0x7fffffff < uVar1) {
        uVar1 = ~uVar1;
      }
    }
    break;
  case 4:
    return (longlong)
           (int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U & *(uint *)((longlong)*param_2 + 0xc)
                ) * 0x20 + *(longlong *)(param_1 + 0x18);
  case 0x14:
    dVar3 = *param_2;
    if (*(char *)((longlong)dVar3 + 10) == '\0') {
      uVar2 = FUN_140530600((longlong)dVar3 + 0x18,*(undefined8 *)((longlong)dVar3 + 0x10),
                            *(undefined4 *)((longlong)dVar3 + 0xc));
      *(undefined1 *)((longlong)dVar3 + 10) = 1;
      *(undefined4 *)((longlong)dVar3 + 0xc) = uVar2;
    }
    return (longlong)
           (int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U & *(uint *)((longlong)*param_2 + 0xc)
                ) * 0x20 + *(longlong *)(param_1 + 0x18);
  }
  return (longlong)((int)uVar1 % (int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U | 1)) * 0x20 +
         *(longlong *)(param_1 + 0x18);
}

// ==== CLuaScript::helper_14052fa10  @14052fa10  [medium:callgraph-r3]  (orig: FUN_14052fa10)
void FUN_14052fa10(undefined8 param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_1405299a0(param_1,5,0x38);
  *(undefined8 *)(lVar1 + 0x28) = 0;
  *(undefined8 *)(lVar1 + 0x10) = 0;
  *(undefined4 *)(lVar1 + 0xc) = 0;
  *(undefined1 *)(lVar1 + 10) = 0xff;
  *(undefined1 *)(lVar1 + 0xb) = 0;
  *(undefined **)(lVar1 + 0x18) = &DAT_1407a0070;
  *(undefined **)(lVar1 + 0x20) = &DAT_1407a0070;
  return;
}

// ==== CLuaScript::helper_14052faf0  @14052faf0  [medium:callgraph-r1]  (orig: FUN_14052faf0)
undefined8 * FUN_14052faf0(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  
  if (param_2 - 1U < (ulonglong)*(uint *)(param_1 + 0xc)) {
    return (undefined8 *)(*(longlong *)(param_1 + 0x10) + -0x10 + param_2 * 0x10);
  }
  for (puVar1 = (undefined8 *)
                ((longlong)(int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U & (uint)param_2) *
                 0x20 + *(longlong *)(param_1 + 0x18));
      (*(int *)(puVar1 + 3) != 0x13 || (puVar1[2] != param_2));
      puVar1 = puVar1 + (longlong)*(int *)((longlong)puVar1 + 0x1c) * 4) {
    if (*(int *)((longlong)puVar1 + 0x1c) == 0) {
      return &DAT_14079fb60;
    }
  }
  return puVar1;
}

// ==== CLuaScript::helper_14052fb60  @14052fb60  [medium:callgraph-r3]  (orig: FUN_14052fb60)
undefined8 * FUN_14052fb60(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  
  for (puVar1 = (undefined8 *)
                ((longlong)
                 (int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U & *(uint *)(param_2 + 0xc)) *
                 0x20 + *(longlong *)(param_1 + 0x18));
      (*(int *)(puVar1 + 3) != 0x44 || (puVar1[2] != param_2));
      puVar1 = puVar1 + (longlong)*(int *)((longlong)puVar1 + 0x1c) * 4) {
    if (*(int *)((longlong)puVar1 + 0x1c) == 0) {
      return &DAT_14079fb60;
    }
  }
  return puVar1;
}

// ==== CLuaScript::helper_14052fbb0  @14052fbb0  [medium:callgraph-r2]  (orig: FUN_14052fbb0)
undefined8 * FUN_14052fbb0(longlong param_1,longlong *param_2)

{
  int iVar1;
  undefined8 *puVar2;
  uint uVar3;
  undefined8 local_res10 [3];
  
  uVar3 = *(uint *)(param_2 + 1) & 0x3f;
  if (uVar3 != 0) {
    if (uVar3 == 3) {
      iVar1 = FUN_14052c120(param_2,local_res10,0);
      if (iVar1 != 0) {
        puVar2 = (undefined8 *)FUN_14052faf0(param_1,local_res10[0]);
        return puVar2;
      }
    }
    else {
      if (uVar3 == 4) {
        for (puVar2 = (undefined8 *)
                      ((longlong)
                       (int)((1 << (*(byte *)(param_1 + 0xb) & 0x1f)) - 1U &
                            *(uint *)(*param_2 + 0xc)) * 0x20 + *(longlong *)(param_1 + 0x18));
            (*(int *)(puVar2 + 3) != 0x44 || (puVar2[2] != *param_2));
            puVar2 = puVar2 + (longlong)*(int *)((longlong)puVar2 + 0x1c) * 4) {
          if (*(int *)((longlong)puVar2 + 0x1c) == 0) {
            return &DAT_14079fb60;
          }
        }
        return puVar2;
      }
      if (uVar3 == 0x13) {
        puVar2 = (undefined8 *)FUN_14052faf0(param_1,*param_2);
        return puVar2;
      }
    }
    puVar2 = (undefined8 *)FUN_14052f290(param_1,param_2);
    iVar1 = FUN_14052c970(0,puVar2 + 2,param_2);
    while( true ) {
      if (iVar1 != 0) {
        return puVar2;
      }
      if (*(int *)((longlong)puVar2 + 0x1c) == 0) break;
      puVar2 = puVar2 + (longlong)*(int *)((longlong)puVar2 + 0x1c) * 4;
      iVar1 = FUN_14052c970(0,puVar2 + 2,param_2);
    }
  }
  return &DAT_14079fb60;
}

// ==== CLuaScript::helper_14052fce0  @14052fce0  [medium:callgraph-r3]  (orig: FUN_14052fce0)
void FUN_14052fce0(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)FUN_14052fbb0(param_2,param_3);
  if (puVar1 == &DAT_14079fb60) {
    FUN_140530310(param_1,param_2,param_3);
  }
  return;
}

// ==== CLuaScript::helper_14052ff70  @14052ff70  [medium:callgraph-r3]  (orig: FUN_14052ff70)
void FUN_14052ff70(undefined8 param_1,longlong param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  byte bVar2;
  uint uVar3;
  uint uVar4;
  undefined *puVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined *puVar10;
  int iVar11;
  ulonglong uVar12;
  
  uVar3 = *(uint *)(param_2 + 0xc);
  bVar2 = *(byte *)(param_2 + 0xb);
  puVar5 = *(undefined **)(param_2 + 0x18);
  uVar12 = (ulonglong)param_3;
  if (uVar3 < param_3) {
    uVar6 = FUN_140531b40(param_1,*(undefined8 *)(param_2 + 0x10),(ulonglong)uVar3 << 4,uVar12 << 4)
    ;
    uVar4 = *(uint *)(param_2 + 0xc);
    *(undefined8 *)(param_2 + 0x10) = uVar6;
    if (uVar4 < param_3) {
      lVar8 = (longlong)(int)uVar4 << 4;
      uVar9 = (ulonglong)(param_3 - uVar4);
      do {
        lVar8 = lVar8 + 0x10;
        uVar9 = uVar9 - 1;
        *(undefined4 *)(*(longlong *)(param_2 + 0x10) + -8 + lVar8) = 0;
      } while (uVar9 != 0);
    }
    *(uint *)(param_2 + 0xc) = param_3;
  }
  FUN_14052f930(param_1,param_2,param_4);
  if (param_3 < uVar3) {
    *(uint *)(param_2 + 0xc) = param_3;
    lVar8 = (longlong)(int)param_3 << 4;
    do {
      if (*(int *)(lVar8 + 8 + *(longlong *)(param_2 + 0x10)) != 0) {
        FUN_140530510(param_1,param_2,param_3 + 1,
                      (ulonglong)param_3 * 0x10 + *(longlong *)(param_2 + 0x10));
      }
      param_3 = param_3 + 1;
      lVar8 = lVar8 + 0x10;
    } while (param_3 < uVar3);
    uVar6 = FUN_140531b40(param_1,*(undefined8 *)(param_2 + 0x10),(ulonglong)uVar3 << 4,uVar12 << 4)
    ;
    *(undefined8 *)(param_2 + 0x10) = uVar6;
  }
  iVar11 = 1 << (bVar2 & 0x1f);
  iVar1 = iVar11 + -1;
  lVar8 = (longlong)iVar1;
  if (-1 < iVar1) {
    puVar10 = puVar5 + lVar8 * 0x20 + 0x10;
    do {
      if (*(int *)(puVar10 + -8) != 0) {
        puVar7 = (undefined8 *)FUN_14052fbb0(param_2,puVar10);
        if (puVar7 == &DAT_14079fb60) {
          puVar7 = (undefined8 *)FUN_140530310(param_1,param_2,puVar10);
        }
        *puVar7 = *(undefined8 *)(puVar10 + -0x10);
        puVar7[1] = *(undefined8 *)(puVar10 + -8);
      }
      puVar10 = puVar10 + -0x20;
      lVar8 = lVar8 + -1;
    } while (-1 < lVar8);
  }
  if (puVar5 != &DAT_1407a0070) {
    FUN_140531b40(param_1,puVar5,(longlong)iVar11 << 5,0);
  }
  return;
}

// ==== CLuaScript::helper_140530110  @140530110  [medium:callgraph-r3]  (orig: FUN_140530110)
void FUN_140530110(undefined8 param_1,longlong param_2,undefined8 param_3)

{
  if (*(undefined **)(param_2 + 0x18) == &DAT_1407a0070) {
    FUN_14052ff70(param_1,param_2,param_3,0);
    return;
  }
  FUN_14052ff70(param_1,param_2,param_3,1 << (*(byte *)(param_2 + 0xb) & 0x1f));
  return;
}

// ==== CLuaScript::helper_140530140  @140530140  [medium:callgraph-r3]  (orig: FUN_140530140)
void FUN_140530140(undefined8 param_1,longlong param_2,ulonglong *param_3)

{
  longlong lVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  int *piVar7;
  uint uVar8;
  uint uVar9;
  longlong lVar10;
  int iVar11;
  longlong lVar12;
  uint uVar13;
  uint uVar15;
  ulonglong uVar16;
  int iVar17;
  ulonglong uVar18;
  uint uVar19;
  int local_b8 [32];
  ulonglong uVar14;
  
  memset(local_b8,0,0x80);
  uVar9 = *(uint *)(param_2 + 0xc);
  uVar18 = 1;
  uVar6 = 0;
  uVar13 = 1;
  uVar8 = 1;
  iVar4 = 0;
  lVar12 = 1;
  uVar16 = uVar6;
  uVar14 = uVar6;
  do {
    uVar19 = (uint)uVar14;
    if (uVar9 < uVar13) {
      uVar15 = uVar9;
      if (uVar9 < uVar8) break;
LAB_1405301aa:
      uVar15 = (uVar15 - uVar8) + 1;
      piVar7 = (int *)(*(longlong *)(param_2 + 0x10) + -8 + lVar12 * 0x10);
      uVar5 = (ulonglong)uVar15;
      uVar8 = uVar8 + uVar15;
      lVar12 = lVar12 + uVar5;
      uVar14 = uVar6;
      do {
        if (*piVar7 != 0) {
          uVar14 = (ulonglong)((int)uVar14 + 1);
        }
        piVar7 = piVar7 + 4;
        uVar5 = uVar5 - 1;
        iVar3 = (int)uVar14;
      } while (uVar5 != 0);
    }
    else {
      uVar15 = uVar13;
      iVar3 = iVar4;
      if (uVar8 <= uVar13) goto LAB_1405301aa;
    }
    local_b8[uVar16] = local_b8[uVar16] + iVar3;
    uVar16 = uVar16 + 1;
    uVar19 = uVar19 + iVar3;
    uVar14 = (ulonglong)uVar19;
    uVar13 = uVar13 * 2;
  } while ((longlong)uVar16 < 0x20);
  iVar2 = 1 << (*(byte *)(param_2 + 0xb) & 0x1f);
  iVar17 = 0;
  lVar12 = (longlong)iVar2;
  iVar3 = iVar17;
  iVar11 = iVar4;
  if (iVar2 != 0) {
    lVar10 = lVar12 << 5;
    uVar16 = uVar6;
    uVar14 = uVar6;
    do {
      lVar1 = *(longlong *)(param_2 + 0x18);
      lVar12 = lVar12 + -1;
      if (*(int *)(lVar10 + -0x18 + lVar1) != 0) {
        iVar3 = iVar4;
        if ((((*(int *)(lVar10 + -8 + lVar1) == 0x13) &&
             (uVar5 = *(ulonglong *)(lVar10 + -0x10 + lVar1), 0 < (longlong)uVar5)) &&
            (uVar5 < 0x80000001)) && ((int)uVar5 != 0)) {
          iVar3 = FUN_1405289d0(uVar5 & 0xffffffff);
          local_b8[iVar3] = local_b8[iVar3] + 1;
          iVar3 = 1;
        }
        uVar14 = (ulonglong)(uint)((int)uVar14 + iVar3);
        uVar16 = (ulonglong)((int)uVar16 + 1);
      }
      iVar11 = (int)uVar16;
      iVar3 = (int)uVar14;
      lVar10 = lVar10 + -0x20;
    } while (lVar12 != 0);
  }
  if ((((int)param_3[1] == 0x13) && (uVar16 = *param_3, 0 < (longlong)uVar16)) &&
     ((uVar16 < 0x80000001 && ((int)uVar16 != 0)))) {
    iVar4 = FUN_1405289d0(uVar16 & 0xffffffff);
    local_b8[iVar4] = local_b8[iVar4] + 1;
    iVar4 = 1;
  }
  uVar9 = iVar3 + uVar19 + iVar4;
  uVar16 = uVar6;
  if (uVar9 != 0) {
    piVar7 = local_b8;
    uVar14 = uVar6;
    uVar5 = uVar6;
    do {
      if (*piVar7 != 0) {
        uVar13 = (int)uVar14 + *piVar7;
        uVar14 = (ulonglong)uVar13;
        if ((uint)uVar6 < uVar13) {
          uVar5 = (ulonglong)uVar13;
          uVar16 = uVar18;
        }
      }
      iVar17 = (int)uVar5;
      uVar13 = (uint)uVar18;
      piVar7 = piVar7 + 1;
      uVar18 = (ulonglong)(uVar13 * 2);
      uVar13 = uVar13 & 0x7fffffff;
      uVar6 = (ulonglong)uVar13;
    } while (uVar13 < uVar9);
  }
  FUN_14052ff70(param_1,param_2,uVar16,(iVar11 + 1 + uVar19) - iVar17);
  return;
}

// ==== CLuaScript::helper_140530310  @140530310  [medium:callgraph-r2]  (orig: FUN_140530310)
undefined8 * FUN_140530310(undefined8 param_1,longlong param_2,double *param_3)

{
  int iVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  double local_res18 [2];
  double local_28;
  undefined4 local_20;
  
  if (*(int *)(param_3 + 1) == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_140526620(param_1,"table index is nil");
  }
  if (*(int *)(param_3 + 1) == 3) {
    iVar1 = FUN_14052c120(param_3,local_res18,0);
    if (iVar1 == 0) {
      if (NAN(*param_3)) {
                    /* WARNING: Subroutine does not return */
        FUN_140526620(param_1,"table index is NaN");
      }
    }
    else {
      local_20 = 0x13;
      param_3 = &local_28;
      local_28 = local_res18[0];
    }
  }
  puVar2 = (undefined8 *)FUN_14052f290(param_2,param_3);
  if ((*(int *)(puVar2 + 1) != 0) || (puVar5 = puVar2, puVar2 == (undefined8 *)&DAT_1407a0070)) {
    puVar5 = *(undefined8 **)(param_2 + 0x20);
    do {
      if (puVar5 <= *(undefined8 **)(param_2 + 0x18)) goto LAB_1405303c4;
      *(longlong *)(param_2 + 0x20) = *(longlong *)(param_2 + 0x20) + -0x20;
      puVar5 = *(undefined8 **)(param_2 + 0x20);
    } while (*(int *)(puVar5 + 3) != 0);
    if (puVar5 == (undefined8 *)0x0) {
LAB_1405303c4:
      FUN_140530140(param_1,param_2,param_3);
      puVar2 = (undefined8 *)FUN_14052fce0(param_1,param_2,param_3);
      return puVar2;
    }
    puVar3 = (undefined8 *)FUN_14052f290(param_2,puVar2 + 2);
    if (puVar3 == puVar2) {
      if (*(int *)((longlong)puVar2 + 0x1c) != 0) {
        *(int *)((longlong)puVar5 + 0x1c) =
             (int)((longlong)
                   (((longlong)*(int *)((longlong)puVar2 + 0x1c) * 0x20 - (longlong)puVar5) +
                   (longlong)puVar2) >> 5);
      }
      *(int *)((longlong)puVar2 + 0x1c) = (int)((longlong)puVar5 - (longlong)puVar2 >> 5);
    }
    else {
      puVar4 = puVar3 + (longlong)*(int *)((longlong)puVar3 + 0x1c) * 4;
      while (puVar4 != puVar2) {
        puVar3 = puVar3 + (longlong)*(int *)((longlong)puVar3 + 0x1c) * 4;
        puVar4 = puVar3 + (longlong)*(int *)((longlong)puVar3 + 0x1c) * 4;
      }
      *(int *)((longlong)puVar3 + 0x1c) = (int)((longlong)puVar5 - (longlong)puVar3 >> 5);
      *puVar5 = *puVar2;
      puVar5[1] = puVar2[1];
      puVar5[2] = puVar2[2];
      puVar5[3] = puVar2[3];
      if (*(int *)((longlong)puVar2 + 0x1c) != 0) {
        *(int *)((longlong)puVar5 + 0x1c) =
             *(int *)((longlong)puVar5 + 0x1c) + (int)((longlong)puVar2 - (longlong)puVar5 >> 5);
        *(undefined4 *)((longlong)puVar2 + 0x1c) = 0;
      }
      *(undefined4 *)(puVar2 + 1) = 0;
      puVar5 = puVar2;
    }
  }
  puVar5[2] = *param_3;
  *(undefined4 *)(puVar5 + 3) = *(undefined4 *)(param_3 + 1);
  if (((((ulonglong)param_3[1] & 0x40) != 0) && ((*(byte *)(param_2 + 9) & 4) != 0)) &&
     ((*(byte *)((longlong)*param_3 + 9) & 3) != 0)) {
    FUN_140529950(param_1,param_2);
  }
  return puVar5;
}

// ==== CLuaScript::helper_140530510  @140530510  [medium:callgraph-r3]  (orig: FUN_140530510)
void FUN_140530510(undefined8 param_1,longlong param_2,longlong param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  longlong local_18;
  undefined4 local_10;
  
  if (param_3 - 1U < (ulonglong)*(uint *)(param_2 + 0xc)) {
    puVar1 = (undefined8 *)(*(longlong *)(param_2 + 0x10) + -0x10 + param_3 * 0x10);
LAB_140530538:
    if (puVar1 != &DAT_14079fb60) goto LAB_140530561;
  }
  else {
    puVar1 = (undefined8 *)
             ((longlong)(int)((1 << (*(byte *)(param_2 + 0xb) & 0x1f)) - 1U & (uint)param_3) * 0x20
             + *(longlong *)(param_2 + 0x18));
    while( true ) {
      if ((*(int *)(puVar1 + 3) == 0x13) && (puVar1[2] == param_3)) goto LAB_140530538;
      if (*(int *)((longlong)puVar1 + 0x1c) == 0) break;
      puVar1 = puVar1 + (longlong)*(int *)((longlong)puVar1 + 0x1c) * 4;
    }
  }
  local_10 = 0x13;
  local_18 = param_3;
  puVar1 = (undefined8 *)FUN_140530310(param_1,param_2,&local_18);
LAB_140530561:
  *puVar1 = *param_4;
  puVar1[1] = param_4[1];
  return;
}

// ==== CLuaScript::helper_140530600  @140530600  [medium:callgraph-r3]  (orig: FUN_140530600)
uint FUN_140530600(longlong param_1,ulonglong param_2,uint param_3)

{
  ulonglong uVar1;
  
  param_3 = (uint)param_2 ^ param_3;
  uVar1 = (param_2 >> 5) + 1;
  for (; uVar1 <= param_2; param_2 = param_2 - uVar1) {
    param_3 = param_3 ^ (uint)*(byte *)(param_1 + -1 + param_2) + param_3 * 0x20 + (param_3 >> 2);
  }
  return param_3;
}

// ==== CLuaScript::helper_140530830  @140530830  [medium:callgraph-r3]  (orig: FUN_140530830)
longlong FUN_140530830(longlong param_1,void *param_2,ulonglong param_3)

{
  int iVar1;
  longlong lVar2;
  byte bVar3;
  int iVar4;
  longlong lVar5;
  uint uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  longlong *plVar9;
  
  lVar2 = *(longlong *)(param_1 + 0x18);
  uVar6 = *(uint *)(lVar2 + 0x50) ^ (uint)param_3;
  uVar8 = (param_3 >> 5) + 1;
  for (uVar7 = param_3; uVar8 <= uVar7; uVar7 = uVar7 - uVar8) {
    uVar6 = uVar6 ^ (uint)*(byte *)((uVar7 - 1) + (longlong)param_2) + uVar6 * 0x20 + (uVar6 >> 2);
  }
  iVar1 = *(int *)(lVar2 + 0x3c);
  plVar9 = (longlong *)(*(longlong *)(lVar2 + 0x30) + (longlong)(int)(iVar1 - 1U & uVar6) * 8);
  lVar5 = *plVar9;
  while( true ) {
    if (lVar5 == 0) {
      if ((iVar1 <= *(int *)(lVar2 + 0x38)) && (iVar1 < 0x40000000)) {
        FUN_140530640(param_1,iVar1 * 2);
        plVar9 = (longlong *)
                 (*(longlong *)(lVar2 + 0x30) +
                 (longlong)(int)(*(int *)(lVar2 + 0x3c) - 1U & uVar6) * 8);
      }
      lVar5 = FUN_1405299a0(param_1,4,param_3 + 0x19);
      *(uint *)(lVar5 + 0xc) = uVar6;
      *(undefined1 *)(lVar5 + 10) = 0;
      memcpy((void *)(lVar5 + 0x18),param_2,param_3);
      *(undefined1 *)(lVar5 + 0x18 + param_3) = 0;
      *(char *)(lVar5 + 0xb) = (char)param_3;
      *(longlong *)(lVar5 + 0x10) = *plVar9;
      *plVar9 = lVar5;
      *(int *)(lVar2 + 0x38) = *(int *)(lVar2 + 0x38) + 1;
      return lVar5;
    }
    if ((param_3 == *(byte *)(lVar5 + 0xb)) &&
       (iVar4 = memcmp(param_2,(void *)(lVar5 + 0x18),param_3), iVar4 == 0)) break;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  bVar3 = *(byte *)(lVar5 + 9) ^ 3;
  if ((bVar3 & (*(byte *)(lVar2 + 0x54) ^ 3)) != 0) {
    return lVar5;
  }
  *(byte *)(lVar5 + 9) = bVar3;
  return lVar5;
}

// ==== CLuaScript::helper_1405309a0  @1405309a0  [medium:callgraph-r2]  (orig: FUN_1405309a0)
longlong FUN_1405309a0(longlong param_1,void *param_2,ulonglong param_3)

{
  undefined4 uVar1;
  code *pcVar2;
  longlong lVar3;
  
  if (param_3 < 0x29) {
    lVar3 = FUN_140530830();
    return lVar3;
  }
  if (0x7fffffffffffffe7 < param_3 + 1) {
    FUN_140531b20();
    pcVar2 = (code *)swi(3);
    lVar3 = (*pcVar2)();
    return lVar3;
  }
  uVar1 = *(undefined4 *)(*(longlong *)(param_1 + 0x18) + 0x50);
  lVar3 = FUN_1405299a0(param_1,0x14,param_3 + 0x19);
  *(undefined4 *)(lVar3 + 0xc) = uVar1;
  *(undefined1 *)(lVar3 + 10) = 0;
  memcpy((void *)(lVar3 + 0x18),param_2,param_3);
  *(undefined1 *)(lVar3 + 0x18 + param_3) = 0;
  *(ulonglong *)(lVar3 + 0x10) = param_3;
  return lVar3;
}

// ==== CLuaScript::helper_140530a40  @140530a40  [medium:callgraph-r1]  (orig: FUN_140530a40)
longlong FUN_140530a40(longlong param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  longlong lVar3;
  uint uVar4;
  longlong lVar5;
  char *pcVar6;
  ulonglong uVar7;
  int iVar8;
  
  lVar3 = *(longlong *)(param_1 + 0x18);
  iVar8 = (int)(((ulonglong)param_2 & 0xffffffff) * 0x2040811 >> 0x20);
  uVar4 = (int)param_2 + (((uint)((int)param_2 - iVar8) >> 1) + iVar8 >> 6) * -0x7f;
  lVar5 = *(longlong *)(lVar3 + 0x200 + (ulonglong)uVar4 * 8);
  pcVar6 = param_2;
  do {
    cVar1 = *pcVar6;
    cVar2 = pcVar6[(lVar5 + 0x18) - (longlong)param_2];
    if (cVar1 != cVar2) break;
    pcVar6 = pcVar6 + 1;
  } while (cVar2 != '\0');
  if (cVar1 == cVar2) {
    return lVar5;
  }
  uVar7 = 0xffffffffffffffff;
  pcVar6 = param_2;
  do {
    if (uVar7 == 0) break;
    uVar7 = uVar7 - 1;
    cVar1 = *pcVar6;
    pcVar6 = pcVar6 + 1;
  } while (cVar1 != '\0');
  lVar5 = FUN_1405309a0(param_1,param_2,~uVar7 - 1);
  *(longlong *)(lVar3 + 0x200 + (ulonglong)uVar4 * 8) = lVar5;
  return lVar5;
}

// ==== CLuaScript::helper_140530b50  @140530b50  [medium:callgraph-r3]  (orig: FUN_140530b50)
void FUN_140530b50(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined8 *puVar4;
  
  lVar1 = *(longlong *)(param_1 + 0x18);
  FUN_140530640(param_1,0x80);
  uVar2 = FUN_140530830(param_1,"not enough memory",0x11);
  *(undefined8 *)(lVar1 + 0xf0) = uVar2;
  FUN_140529970(param_1,uVar2);
  lVar3 = 0x7f;
  puVar4 = (undefined8 *)(lVar1 + 0x200);
  do {
    lVar3 = lVar3 + -1;
    *puVar4 = *(undefined8 *)(lVar1 + 0xf0);
    puVar4 = puVar4 + 1;
  } while (lVar3 != 0);
  return;
}

// ==== CLuaScript::helper_140530bc0  @140530bc0  [medium:callgraph-r1]  (orig: FUN_140530bc0)
void FUN_140530bc0(undefined8 param_1,int param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_1405299a0(param_1,0x26,(longlong)((param_2 + 2) * 0x10));
  *(char *)(lVar1 + 10) = (char)param_2;
  return;
}

// ==== CLuaScript::helper_140530d60  @140530d60  [medium:callgraph-r2]  (orig: FUN_140530d60)
void FUN_140530d60(longlong param_1,ulonglong param_2)

{
  longlong lVar1;
  ulonglong *puVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x40);
  while ((lVar1 != 0 && (puVar2 = *(ulonglong **)(param_1 + 0x40), param_2 <= *puVar2))) {
    *(ulonglong *)(param_1 + 0x40) = puVar2[2];
    if (puVar2[1] == 0) {
      FUN_140531b40(param_1,puVar2,0x20);
    }
    else {
      puVar2[2] = *(ulonglong *)*puVar2;
      puVar2[3] = ((ulonglong *)*puVar2)[1];
      *puVar2 = (ulonglong)(puVar2 + 2);
      if ((puVar2[3] & 0x40) != 0) {
        FUN_14052ad70(param_1);
      }
    }
    lVar1 = *(longlong *)(param_1 + 0x40);
  }
  return;
}

// ==== CLuaScript::helper_140530fa0  @140530fa0  [medium:callgraph-r2]  (orig: FUN_140530fa0)
void FUN_140530fa0(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  param_2[4] = param_1;
  param_2[2] = param_3;
  *param_2 = 0;
  param_2[1] = 0;
  param_2[3] = param_4;
  return;
}

// ==== CLuaScript::helper_140531b20  @140531b20  [medium:callgraph-r3]  (orig: FUN_140531b20)
void FUN_140531b20(undefined8 param_1)

{
                    /* WARNING: Subroutine does not return */
  FUN_140526620(param_1,"memory allocation error: block too big");
}

// ==== CLuaScript::helper_140531b40  @140531b40  [medium:callgraph-r2]  (orig: FUN_140531b40)
void FUN_140531b40(longlong param_1,longlong param_2,longlong param_3,longlong param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong lVar3;
  
  puVar1 = *(undefined8 **)(param_1 + 0x18);
  lVar3 = 0;
  if (param_2 != 0) {
    lVar3 = param_3;
  }
  lVar2 = (*(code *)*puVar1)(puVar1[1]);
  if ((lVar2 == 0) && (param_4 != 0)) {
    if (puVar1[0x1d] != 0) {
      FUN_14052ba20(param_1,1);
      lVar2 = (*(code *)*puVar1)(puVar1[1],param_2,param_3,param_4);
      if (lVar2 != 0) goto LAB_140531bb7;
    }
                    /* WARNING: Subroutine does not return */
    FUN_140527580(param_1,4);
  }
LAB_140531bb7:
  puVar1[3] = puVar1[3] + (param_4 - lVar3);
  return;
}

// ==== CLuaScript::helper_140531ce0  @140531ce0  [medium:callgraph-r3]  (orig: FUN_140531ce0)
void FUN_140531ce0(undefined8 param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined **ppuVar4;
  int iVar5;
  
  uVar2 = FUN_1405309a0(param_1,&DAT_14079f968,4);
  FUN_140529970(param_1,uVar2);
  iVar5 = 0;
  ppuVar4 = &PTR_DAT_1407a0570;
  do {
    lVar3 = FUN_140530a40(param_1,*ppuVar4);
    FUN_140529970(param_1,lVar3);
    cVar1 = (char)iVar5;
    iVar5 = iVar5 + 1;
    ppuVar4 = ppuVar4 + 1;
    *(char *)(lVar3 + 10) = cVar1 + '\x01';
  } while (iVar5 < 0x16);
  return;
}

