// ==== CChatMsgTalk::helper_140032160  @140032160  [medium:callgraph-r0]  (orig: FUN_140032160)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140032160(longlong param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_2 == 0) {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x37a);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  local_434 = *(undefined4 *)(param_2 + 8);
  iVar1 = *(int *)(param_2 + 0xc);
  local_438 = param_3;
  memcpy(local_42c,(void *)(param_2 + 0x10),(longlong)iVar1);
  local_448 = &local_438;
  local_430 = iVar1;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))
            (*(longlong **)(param_1 + 0x10),1,0x753d,0x418);
  return 1;
}

// ==== CChatMsgTalk::helper_140032240  @140032240  [medium:callgraph-r0]  (orig: FUN_140032240)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140032240(longlong param_1,longlong param_2,undefined4 param_3)

{
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  if (param_2 != 0) {
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
    memset(&local_438,0,0x418);
    local_430 = *(int *)(param_2 + 0xc);
    local_434 = *(undefined4 *)(param_2 + 8);
    local_438 = param_3;
    memmove(local_42c,(void *)(param_2 + 0x10),(longlong)local_430);
    local_448 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x50))(*(longlong **)(param_1 + 0x10),0xe,0x3e9);
  }
  return;
}

// ==== CChatMsgTalk::helper_140032320  @140032320  [medium:callgraph-r0]  (orig: FUN_140032320)
byte FUN_140032320(longlong param_1)

{
  return *(byte *)(param_1 + 0xc0) >> 1 & 1;
}

// ==== CChatMsgTalk::helper_1400330d0  @1400330d0  [medium:callgraph-r0]  (orig: FUN_1400330d0)
ulonglong FUN_1400330d0(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined4 uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR("CChatKernel::SendClientMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = *(undefined4 *)(param_1 + 8);
  *(undefined4 *)(param_3 + 0x414) = param_2;
  *(undefined4 *)(param_3 + 0x410) = uVar1;
  *(undefined4 *)(param_3 + 0x418) = 0;
  uVar2 = FUN_140031f10(param_1,param_2,*(undefined4 *)(param_3 + 8),param_3 + 0x10,
                        *(undefined4 *)(param_3 + 0xc));
  return uVar2;
}

// ==== CChatMsgTalk::helper_140033130  @140033130  [medium:callgraph-r0]  (orig: FUN_140033130)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140033130(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [8];
  undefined4 local_470;
  undefined4 local_46c;
  undefined1 local_468 [1024];
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  ulonglong local_38;
  
  lVar3 = DAT_140975aa0;
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x1f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_140042e80(*(undefined8 *)(lVar3 + 0x18),param_2);
  if (lVar3 != 0) {
    FUN_1400409f0(local_478);
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = 0;
    local_4b8 = 0x7d5;
    local_4c0 = 0xff0000;
    local_4c8 = 0;
    iVar2 = FUN_140040ab0(local_478,"SYSTEM",lVar3 + 0x30,param_3);
    if (iVar2 != 0) {
      if (&stack0x00000000 == (undefined1 *)0x478) {
        log_InlineLogERROR("CChatKernel::SendClientMsg, NULL message");
        uVar1 = 0;
      }
      else {
        local_68 = *(undefined4 *)(param_1 + 8);
        local_60 = 0;
        local_4c8 = CONCAT44(local_4c8._4_4_,local_46c);
        local_64 = param_2;
        uVar1 = FUN_140031f10(param_1,param_2,local_470,local_468);
      }
      FUN_140040a70(local_478);
      return uVar1;
    }
    FUN_140040a70(local_478);
  }
  return 0;
}

// ==== CChatMsgTalk::helper_140035030  @140035030  [medium:callgraph-r0]  (orig: FUN_140035030)
undefined1 FUN_140035030(longlong param_1,char *param_2)

{
  char *pcVar1;
  ulonglong uVar2;
  char *pcVar3;
  longlong *plVar4;
  longlong *plVar5;
  char *pcVar6;
  longlong lVar7;
  char *pcVar8;
  char *pcVar9;
  bool bVar10;
  
  if (*(char *)(param_1 + 0x4c) == '\0') {
    return 0;
  }
  _strlwr(param_2);
  uVar2 = *(ulonglong *)(param_1 + 0x68);
  if (*(ulonglong *)(param_1 + 0x70) < uVar2) {
    _invalid_parameter_noinfo();
  }
  pcVar3 = *(char **)(param_1 + 0x70);
  plVar4 = *(longlong **)(param_1 + 0x50);
  if (pcVar3 < *(char **)(param_1 + 0x68)) {
    _invalid_parameter_noinfo();
  }
  plVar5 = *(longlong **)(param_1 + 0x50);
  pcVar8 = (char *)(uVar2 + 8);
  do {
    if ((plVar4 == (longlong *)0x0) || (plVar4 != plVar5)) {
      _invalid_parameter_noinfo();
    }
    pcVar1 = pcVar8 + -8;
    if (pcVar1 == pcVar3) {
      return 0;
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar4;
    }
    if (*(char **)(lVar7 + 0x20) <= pcVar1) {
      _invalid_parameter_noinfo();
    }
    bVar10 = *(ulonglong *)(pcVar8 + 0x18) == 0x10;
    pcVar6 = pcVar8;
    if (0xf < *(ulonglong *)(pcVar8 + 0x18)) {
      pcVar6 = *(char **)pcVar8;
    }
    lVar7 = 1;
    pcVar9 = "";
    do {
      if (lVar7 == 0) break;
      lVar7 = lVar7 + -1;
      bVar10 = *pcVar6 == *pcVar9;
      pcVar6 = pcVar6 + 1;
      pcVar9 = pcVar9 + 1;
    } while (bVar10);
    if (!bVar10) {
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar4;
      }
      if (*(char **)(lVar7 + 0x20) <= pcVar1) {
        _invalid_parameter_noinfo();
      }
      pcVar6 = pcVar8;
      if (0xf < *(ulonglong *)(pcVar8 + 0x18)) {
        pcVar6 = *(char **)pcVar8;
      }
      pcVar6 = strstr(param_2,pcVar6);
      if (pcVar6 != (char *)0x0) {
        return 1;
      }
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar4;
    }
    if (*(char **)(lVar7 + 0x20) <= pcVar1) {
      _invalid_parameter_noinfo();
    }
    pcVar8 = pcVar8 + 0x28;
  } while( true );
}

// ==== CChatMsgTalk::helper_140035b50  @140035b50  [medium:callgraph-r1]  (orig: FUN_140035b50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140035b50(longlong param_1,longlong *param_2,longlong param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined8 uVar3;
  undefined4 *puVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  undefined1 auStack_518 [32];
  uint *local_4f8;
  uint local_4e8;
  undefined4 local_4e4;
  uint local_4e0;
  uint local_4dc;
  longlong local_4d8;
  longlong local_4d0;
  ulonglong *local_4c8;
  ulonglong *local_4b8;
  ulonglong *local_4a8;
  ulonglong *local_498;
  ulonglong *local_488;
  undefined8 local_478;
  uint local_468;
  undefined4 local_464;
  int local_460;
  undefined1 local_45c [1044];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_4d8 = param_1;
  local_4d0 = param_3;
  if (param_3 == 0) {
    log_InlineLogWARNING("null msg point found in CChatKernel::SendMultiClientMsg.");
    uVar3 = 0;
  }
  else if (0x400 - *(int *)(param_3 + 0xc) < 0) {
    log_InlineLogERROR("CChatKernel::SendMultiClientMsg, (_MAX_MSGSIZE - pMsg->GetSize()) < 0.");
    uVar3 = 0;
  }
  else if ((param_2[4] - param_2[3] & 0xfffffffffffffffcU) == 0) {
    uVar3 = 0;
  }
  else {
    local_4c8 = (ulonglong *)((ulonglong)(longlong)(0x400 - *(int *)(param_3 + 0xc)) >> 2);
    if (((int)local_4c8 < 2) || ((ulonglong)(param_2[4] - param_2[3] >> 2) < 2)) {
      puVar4 = (undefined4 *)param_2[3];
      uVar9 = 0;
      local_4c8 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar4) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e0 = 0;
      uVar7 = uVar9;
      local_4c8 = puVar1;
      while( true ) {
        puVar2 = (undefined4 *)param_2[4];
        local_488 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_488 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_488)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar2) goto LAB_140035ebe;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar6 = uVar9;
        }
        else {
          uVar6 = *puVar1;
        }
        if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        FUN_1400330d0(local_4d8,*puVar4,param_3);
        local_4e0 = (int)uVar7 + 1;
        uVar7 = (ulonglong)local_4e0;
        if (2000 < local_4e0) break;
        if (puVar1 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar6 = uVar9;
        }
        else {
          uVar6 = *puVar1;
        }
        if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
          _invalid_parameter_noinfo();
        }
        puVar4 = puVar4 + 1;
      }
      log_InlineLogERROR("CChatKernel::SendMultiClientMsg. Dead Loop");
    }
    else {
      local_464 = *(undefined4 *)(param_3 + 8);
      local_460 = *(int *)(param_3 + 0xc);
      memmove(local_45c,(void *)(param_3 + 0x10),(longlong)local_460);
      puVar4 = (undefined4 *)param_2[3];
      uVar9 = 0;
      local_498 = (ulonglong *)0x0;
      if ((undefined4 *)param_2[4] < puVar4) {
        _invalid_parameter_noinfo();
      }
      puVar1 = (ulonglong *)*param_2;
      local_4e8 = 0;
      local_4dc = 0;
      uVar7 = uVar9;
      local_498 = puVar1;
      do {
        puVar2 = (undefined4 *)param_2[4];
        local_4b8 = (ulonglong *)0x0;
        if (puVar2 < (undefined4 *)param_2[3]) {
          _invalid_parameter_noinfo();
        }
        local_4b8 = (ulonglong *)*param_2;
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4b8)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar2) goto LAB_140035ebe;
        local_4e8 = 0;
        local_468 = 0;
        uVar6 = uVar9;
        do {
          uVar8 = (uint)uVar6;
          if ((int)local_4c8 <= (int)uVar8) break;
          local_4dc = (int)uVar7 + 1;
          uVar7 = (ulonglong)local_4dc;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar6 = uVar9;
          }
          else {
            uVar6 = *puVar1;
          }
          if (*(undefined4 **)(uVar6 + 0x20) <= puVar4) {
            _invalid_parameter_noinfo();
          }
          local_4e4 = *puVar4;
          memmove(local_45c + (longlong)(int)uVar8 * 4 + (longlong)local_460,&local_4e4,4);
          uVar8 = uVar8 + 1;
          uVar6 = (ulonglong)uVar8;
          local_4e8 = uVar8;
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar5 = uVar9;
          }
          else {
            uVar5 = *puVar1;
          }
          if (*(undefined4 **)(uVar5 + 0x20) <= puVar4) {
            _invalid_parameter_noinfo();
          }
          puVar4 = puVar4 + 1;
          puVar2 = (undefined4 *)param_2[4];
          local_4a8 = (ulonglong *)0x0;
          if (puVar2 < (undefined4 *)param_2[3]) {
            _invalid_parameter_noinfo();
          }
          local_4a8 = (ulonglong *)*param_2;
          if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_4a8)) {
            _invalid_parameter_noinfo();
          }
        } while (puVar4 != puVar2);
        if (0 < (int)uVar8) {
          local_4f8 = &local_468;
          local_468 = uVar8;
          (**(code **)(**(longlong **)(local_4d8 + 0x10) + 0x50))
                    (*(longlong **)(local_4d8 + 0x10),1,0x753e,0x418);
        }
      } while ((uint)uVar7 < 0x7d1);
      log_InlineLogERROR("CChatKernel::SendMultiClientMsg. Dead Loop");
    }
LAB_140035ebe:
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CChatMsgTalk::helper_140037000  @140037000  [medium:callgraph-r1]  (orig: FUN_140037000)
bool FUN_140037000(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0xb0))[1];
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
    puVar3 = *(undefined8 **)(param_1 + 0xb0);
    while (cVar1 == '\0') {
      if ((longlong)puVar6[3] < CONCAT44(param_2,param_3)) {
        puVar4 = (undefined8 *)puVar6[2];
        puVar6 = puVar3;
      }
      else {
        puVar4 = (undefined8 *)*puVar6;
      }
      puVar3 = puVar6;
      puVar6 = puVar4;
      cVar1 = *(char *)((longlong)puVar4 + 0x21);
    }
    puVar6 = *(undefined8 **)(param_1 + 0xb0);
    local_30 = puVar3;
    local_38 = *(longlong *)(param_1 + 0x80);
    if (*(longlong *)(param_1 + 0x80) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar6) || (CONCAT44(param_2,param_3) < (longlong)puVar3[3])) {
      plVar5 = &local_28;
      local_20 = *(undefined8 *)(param_1 + 0xb0);
      local_28 = *(longlong *)(param_1 + 0x80);
    }
    else {
      plVar5 = &local_38;
    }
    local_18 = *plVar5;
    lVar2 = *(longlong *)(param_1 + 0xb0);
    local_10 = plVar5[1];
    if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 0x80))) {
      _invalid_parameter_noinfo();
    }
    return local_10 != lVar2;
  }
  return false;
}

// ==== CChatMsgTalk::helper_140038390  @140038390  [medium:callgraph-r0]  (orig: FUN_140038390)
undefined8
FUN_140038390(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined8 param_5,undefined4 param_6)

{
  longlong *plVar1;
  void *pvVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  void *pvVar6;
  longlong *plVar7;
  longlong *local_c8 [3];
  void *local_b0;
  void *local_a8;
  undefined8 local_a0;
  longlong *local_98;
  longlong *local_88;
  longlong *local_78 [3];
  void *local_60;
  longlong local_58;
  undefined8 local_50;
  longlong *local_48 [3];
  void *local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  local_18 = 0xfffffffffffffffe;
  lVar3 = FUN_1400472c0(*(undefined8 *)(param_1 + 0x20),param_4);
  if (lVar3 == 0) {
    uVar4 = 0;
  }
  else {
    local_98 = operator_new(8);
    if (local_98 == (longlong *)0x0) {
      local_c8[0] = (longlong *)0x0;
    }
    else {
      *local_98 = (longlong)local_c8;
      local_c8[0] = local_98;
    }
    plVar5 = (longlong *)0x0;
    local_b0 = (void *)0x0;
    local_a8 = (void *)0x0;
    local_a0 = 0;
    local_88 = local_98;
    local_98 = operator_new(8);
    local_78[0] = plVar5;
    if (local_98 != (longlong *)0x0) {
      *local_98 = (longlong)local_78;
      local_78[0] = local_98;
    }
    local_60 = (void *)0x0;
    local_58 = 0;
    local_50 = 0;
    local_88 = local_98;
    FUN_14003d0e0(lVar3,param_2,param_3,local_c8,local_78,param_6);
    if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) != 0) {
      local_88 = operator_new(8);
      pvVar6 = local_b0;
      local_48[0] = plVar5;
      if (local_88 != (longlong *)0x0) {
        *local_88 = (longlong)local_48;
        local_48[0] = local_88;
      }
      local_30 = (void *)0x0;
      local_28 = 0;
      local_20 = 0;
      local_98 = (longlong *)0x0;
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
      }
      plVar1 = local_c8[0];
      local_98 = local_c8[0];
      while( true ) {
        pvVar2 = local_a8;
        local_88 = (longlong *)0x0;
        if (local_a8 < local_b0) {
          _invalid_parameter_noinfo();
        }
        local_88 = local_c8[0];
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_c8[0])) {
          _invalid_parameter_noinfo();
        }
        if (pvVar6 == pvVar2) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar5;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((void *)plVar7[4] <= pvVar6) {
          _invalid_parameter_noinfo();
        }
        FUN_140037fe0(local_48,pvVar6);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar5;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((void *)plVar7[4] <= pvVar6) {
          _invalid_parameter_noinfo();
        }
        pvVar6 = (void *)((longlong)pvVar6 + 4);
      }
      FUN_140035b50(param_1,local_48,param_5);
      if (local_30 != (void *)0x0) {
        operator_delete(local_30);
      }
      local_30 = (void *)0x0;
      local_28 = 0;
      local_20 = 0;
      operator_delete(local_48[0]);
    }
    if ((local_58 - (longlong)local_60 & 0xfffffffffffffffcU) != 0) {
      FUN_140035ef0(param_1,local_78,param_5);
    }
    if (local_60 != (void *)0x0) {
      operator_delete(local_60);
    }
    local_60 = (void *)0x0;
    local_58 = 0;
    local_50 = 0;
    operator_delete(local_78[0]);
    if (local_b0 != (void *)0x0) {
      operator_delete(local_b0);
    }
    local_b0 = (void *)0x0;
    local_a8 = (void *)0x0;
    local_a0 = 0;
    operator_delete(local_c8[0]);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CChatMsgTalk::helper_1400386d0  @1400386d0  [medium:callgraph-r0]  (orig: FUN_1400386d0)
BADSPACEBASE * FUN_1400386d0(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong *local_res10;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58 [3];
  int *local_40;
  int *local_38;
  longlong local_30;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_res10 = operator_new(8);
    plVar8 = (longlong *)0x0;
    local_58[0] = plVar8;
    if (local_res10 != (longlong *)0x0) {
      *local_res10 = (longlong)local_58;
      local_58[0] = local_res10;
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    while( true ) {
      lVar5 = DAT_140975aa0;
      uVar7 = 0;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = FUN_1400423a0(*(undefined8 *)(lVar5 + 0x18));
      lVar5 = DAT_140975aa0;
      if (iVar4 <= (int)plVar8) break;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar5 = FUN_1400423b0(*(undefined8 *)(lVar5 + 0x18),plVar8);
      piVar3 = local_38;
      if (((lVar5 != 0) && (*(int *)(lVar5 + 0x10) == param_3)) &&
         (iVar4 = *(int *)(lVar5 + 0xc), param_4 != iVar4)) {
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,iVar4);
        if (local_40 != (int *)0x0) {
          uVar7 = local_30 - (longlong)local_40 >> 2;
        }
        if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar7) {
          *local_38 = iVar4;
          local_38 = local_38 + 1;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          piVar2 = local_40;
          plVar1 = local_58[0];
          if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
            lVar5 = 0;
          }
          else {
            if (local_38 < local_40) {
              _invalid_parameter_noinfo();
            }
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
              _invalid_parameter_noinfo();
            }
            lVar5 = (longlong)piVar3 - (longlong)piVar2 >> 2;
          }
          local_78 = SUB84(plVar1,0);
          uStack_74 = (undefined4)((ulonglong)plVar1 >> 0x20);
          uStack_70 = SUB84(piVar3,0);
          uStack_6c = (undefined4)((ulonglong)piVar3 >> 0x20);
          local_68 = local_78;
          uStack_64 = uStack_74;
          uStack_60 = uStack_70;
          uStack_5c = uStack_6c;
          FUN_140036c20(local_58,&local_68,1,&local_res10);
          piVar3 = local_40;
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_58[0];
          if (local_58[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *local_58[0];
          }
          if (piVar3 + lVar5 <= *(int **)(lVar6 + 0x20)) {
            if (plVar1 == (longlong *)0x0) {
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar1;
            }
            if (*(int **)(lVar6 + 0x18) <= piVar3 + lVar5) goto LAB_14003893c;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_14003893c:
      plVar8 = (longlong *)(ulonglong)((int)plVar8 + 1);
    }
    FUN_140035b50(param_1,local_58,param_2);
    if (local_40 != (int *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
    register0x00000020 = (BADSPACEBASE *)0x1;
  }
  return register0x00000020;
}

// ==== CChatMsgTalk::helper_1400389b0  @1400389b0  [medium:callgraph-r0]  (orig: FUN_1400389b0)
BADSPACEBASE * FUN_1400389b0(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  longlong *plVar1;
  longlong lVar2;
  int *piVar3;
  longlong *plVar4;
  int *piVar5;
  longlong *plVar6;
  longlong *local_c8 [3];
  int *local_b0;
  int *local_a8;
  longlong local_a0;
  longlong *local_98 [3];
  int *local_80;
  int *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  if ((param_2 != 0) && (param_3 != 0)) {
    local_68 = operator_new(8);
    plVar6 = (longlong *)0x0;
    local_c8[0] = plVar6;
    if (local_68 != (longlong *)0x0) {
      *local_68 = (longlong)local_c8;
      local_c8[0] = local_68;
    }
    local_b0 = (int *)0x0;
    local_a8 = (int *)0x0;
    local_a0 = 0;
    local_68 = operator_new(8);
    local_98[0] = plVar6;
    if (local_68 != (longlong *)0x0) {
      *local_68 = (longlong)local_98;
      local_98[0] = local_68;
    }
    lVar2 = DAT_140975aa0;
    local_80 = (int *)0x0;
    local_78 = (int *)0x0;
    local_70 = 0;
    if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1400438a0(*(undefined8 *)(lVar2 + 0x18),param_3,local_98);
    piVar5 = local_80;
    plVar1 = local_98[0];
    if (local_78 < local_80) {
      _invalid_parameter_noinfo();
      plVar1 = local_98[0];
    }
    while( true ) {
      piVar3 = local_78;
      if (local_78 < local_80) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_98[0])) {
        _invalid_parameter_noinfo();
      }
      if (piVar5 == piVar3) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar4 = plVar6;
      }
      else {
        plVar4 = (longlong *)*plVar1;
      }
      if ((int *)plVar4[4] <= piVar5) {
        _invalid_parameter_noinfo();
      }
      if (param_4 != *piVar5) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar4 = plVar6;
        }
        else {
          plVar4 = (longlong *)*plVar1;
        }
        if ((int *)plVar4[4] <= piVar5) {
          _invalid_parameter_noinfo();
        }
        piVar3 = local_a8;
        plVar4 = plVar6;
        if (local_b0 != (int *)0x0) {
          plVar4 = (longlong *)(local_a0 - (longlong)local_b0 >> 2);
        }
        if ((longlong *)((longlong)local_a8 - (longlong)local_b0 >> 2) < plVar4) {
          *local_a8 = *piVar5;
          local_a8 = local_a8 + 1;
        }
        else {
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          local_68 = local_c8[0];
          plVar4 = local_68;
          uStack_60 = piVar3;
          local_68._0_4_ = SUB84(local_c8[0],0);
          local_68._4_4_ = (undefined4)((ulonglong)local_c8[0] >> 0x20);
          uStack_60._0_4_ = SUB84(piVar3,0);
          uStack_60._4_4_ = (undefined4)((ulonglong)piVar3 >> 0x20);
          local_58 = (undefined4)local_68;
          uStack_54 = local_68._4_4_;
          uStack_50 = (undefined4)uStack_60;
          uStack_4c = uStack_60._4_4_;
          local_68 = plVar4;
          uStack_60 = piVar3;
          FUN_1400375c0(local_c8,local_40,&local_58,piVar5);
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar4 = plVar6;
      }
      else {
        plVar4 = (longlong *)*plVar1;
      }
      if ((int *)plVar4[4] <= piVar5) {
        _invalid_parameter_noinfo();
      }
      piVar5 = piVar5 + 1;
    }
    FUN_140035b50(param_1,local_c8,param_2);
    if (local_80 != (int *)0x0) {
      operator_delete(local_80);
    }
    local_80 = (int *)0x0;
    local_78 = (int *)0x0;
    local_70 = 0;
    operator_delete(local_98[0]);
    if (local_b0 != (int *)0x0) {
      operator_delete(local_b0);
    }
    local_b0 = (int *)0x0;
    local_a8 = (int *)0x0;
    local_a0 = 0;
    operator_delete(local_c8[0]);
    register0x00000020 = (BADSPACEBASE *)0x1;
  }
  return register0x00000020;
}

// ==== CChatMsgTalk::helper_140038ca0  @140038ca0  [medium:callgraph-r0]  (orig: FUN_140038ca0)
BADSPACEBASE * FUN_140038ca0(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  longlong *plVar1;
  longlong lVar2;
  int *piVar3;
  longlong *plVar4;
  int *piVar5;
  longlong *plVar6;
  longlong *local_c8 [3];
  int *local_b0;
  int *local_a8;
  longlong local_a0;
  longlong *local_98 [3];
  int *local_80;
  int *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  if ((param_2 != 0) && (param_3 != 0)) {
    local_68 = operator_new(8);
    plVar6 = (longlong *)0x0;
    local_c8[0] = plVar6;
    if (local_68 != (longlong *)0x0) {
      *local_68 = (longlong)local_c8;
      local_c8[0] = local_68;
    }
    local_b0 = (int *)0x0;
    local_a8 = (int *)0x0;
    local_a0 = 0;
    local_68 = operator_new(8);
    local_98[0] = plVar6;
    if (local_68 != (longlong *)0x0) {
      *local_68 = (longlong)local_98;
      local_98[0] = local_68;
    }
    lVar2 = DAT_140975aa0;
    local_80 = (int *)0x0;
    local_78 = (int *)0x0;
    local_70 = 0;
    if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1400439c0(*(undefined8 *)(lVar2 + 0x18),param_3,local_98);
    piVar5 = local_80;
    plVar1 = local_98[0];
    if (local_78 < local_80) {
      _invalid_parameter_noinfo();
      plVar1 = local_98[0];
    }
    while( true ) {
      piVar3 = local_78;
      if (local_78 < local_80) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_98[0])) {
        _invalid_parameter_noinfo();
      }
      if (piVar5 == piVar3) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar4 = plVar6;
      }
      else {
        plVar4 = (longlong *)*plVar1;
      }
      if ((int *)plVar4[4] <= piVar5) {
        _invalid_parameter_noinfo();
      }
      if (param_4 != *piVar5) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar4 = plVar6;
        }
        else {
          plVar4 = (longlong *)*plVar1;
        }
        if ((int *)plVar4[4] <= piVar5) {
          _invalid_parameter_noinfo();
        }
        piVar3 = local_a8;
        plVar4 = plVar6;
        if (local_b0 != (int *)0x0) {
          plVar4 = (longlong *)(local_a0 - (longlong)local_b0 >> 2);
        }
        if ((longlong *)((longlong)local_a8 - (longlong)local_b0 >> 2) < plVar4) {
          *local_a8 = *piVar5;
          local_a8 = local_a8 + 1;
        }
        else {
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          local_68 = local_c8[0];
          plVar4 = local_68;
          uStack_60 = piVar3;
          local_68._0_4_ = SUB84(local_c8[0],0);
          local_68._4_4_ = (undefined4)((ulonglong)local_c8[0] >> 0x20);
          uStack_60._0_4_ = SUB84(piVar3,0);
          uStack_60._4_4_ = (undefined4)((ulonglong)piVar3 >> 0x20);
          local_58 = (undefined4)local_68;
          uStack_54 = local_68._4_4_;
          uStack_50 = (undefined4)uStack_60;
          uStack_4c = uStack_60._4_4_;
          local_68 = plVar4;
          uStack_60 = piVar3;
          FUN_1400375c0(local_c8,local_40,&local_58,piVar5);
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar4 = plVar6;
      }
      else {
        plVar4 = (longlong *)*plVar1;
      }
      if ((int *)plVar4[4] <= piVar5) {
        _invalid_parameter_noinfo();
      }
      piVar5 = piVar5 + 1;
    }
    FUN_140035b50(param_1,local_c8,param_2);
    if (local_80 != (int *)0x0) {
      operator_delete(local_80);
    }
    local_80 = (int *)0x0;
    local_78 = (int *)0x0;
    local_70 = 0;
    operator_delete(local_98[0]);
    if (local_b0 != (int *)0x0) {
      operator_delete(local_b0);
    }
    local_b0 = (int *)0x0;
    local_a8 = (int *)0x0;
    local_a0 = 0;
    operator_delete(local_c8[0]);
    register0x00000020 = (BADSPACEBASE *)0x1;
  }
  return register0x00000020;
}

// ==== CChatMsgTalk::helper_140038f90  @140038f90  [medium:callgraph-r0]  (orig: FUN_140038f90)
undefined8 FUN_140038f90(undefined8 param_1,longlong param_2,int param_3)

{
  longlong *plVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined4 *puVar9;
  longlong *plVar10;
  longlong *local_res10 [2];
  longlong *local_res20;
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  longlong *local_98 [3];
  undefined4 *local_80;
  undefined4 *local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  if ((param_2 == 0) || (param_3 == 0)) {
    uVar6 = 0;
  }
  else {
    local_res10[0] = operator_new(8);
    plVar10 = (longlong *)0x0;
    local_c8[0] = plVar10;
    if (local_res10[0] != (longlong *)0x0) {
      *local_res10[0] = (longlong)local_c8;
      local_c8[0] = local_res10[0];
    }
    local_b0 = (undefined4 *)0x0;
    local_a8 = (undefined4 *)0x0;
    local_a0 = 0;
    local_res20 = local_res10[0];
    local_res10[0] = operator_new(8);
    local_98[0] = plVar10;
    if (local_res10[0] != (longlong *)0x0) {
      *local_res10[0] = (longlong)local_98;
      local_98[0] = local_res10[0];
    }
    lVar4 = DAT_140975aa0;
    local_80 = (undefined4 *)0x0;
    local_78 = (undefined4 *)0x0;
    local_70 = 0;
    local_res20 = local_res10[0];
    if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = FUN_140042da0(*(undefined8 *)(lVar4 + 0x18),param_3);
    if (lVar4 == 0) {
      if (local_80 != (undefined4 *)0x0) {
        operator_delete(local_80);
      }
      local_80 = (undefined4 *)0x0;
      local_78 = (undefined4 *)0x0;
      local_70 = 0;
      operator_delete(local_98[0]);
      if (local_b0 != (undefined4 *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (undefined4 *)0x0;
      local_a8 = (undefined4 *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      uVar6 = 0;
    }
    else {
      FUN_140036640(local_98);
      FUN_140037140(local_98,lVar4 + 0x70);
      puVar9 = local_80;
      plVar1 = local_98[0];
      if (local_78 < local_80) {
        _invalid_parameter_noinfo();
        plVar1 = local_98[0];
      }
      while( true ) {
        puVar3 = local_78;
        if (local_78 < local_80) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_98[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar9 == puVar3) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar10;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((undefined4 *)plVar7[4] <= puVar9) {
          _invalid_parameter_noinfo();
        }
        lVar4 = DAT_140975aa0;
        if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar4 = FUN_140042da0(*(undefined8 *)(lVar4 + 0x18),*puVar9);
        puVar3 = local_a8;
        if (lVar4 != 0) {
          local_res10[0] = (longlong *)CONCAT44(local_res10[0]._4_4_,*(undefined4 *)(lVar4 + 0xc));
          plVar7 = plVar10;
          if (local_b0 != (undefined4 *)0x0) {
            plVar7 = (longlong *)(local_a0 - (longlong)local_b0 >> 2);
          }
          if ((longlong *)((longlong)local_a8 - (longlong)local_b0 >> 2) < plVar7) {
            *local_a8 = *(undefined4 *)(lVar4 + 0xc);
            local_a8 = local_a8 + 1;
          }
          else {
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            puVar2 = local_b0;
            plVar7 = local_c8[0];
            local_68 = local_c8[0];
            uStack_60 = puVar3;
            plVar8 = plVar10;
            if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) != 0) {
              if (local_a8 < local_b0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar7 == (longlong *)0x0) || (plVar7 != local_c8[0])) {
                _invalid_parameter_noinfo();
              }
              plVar8 = (longlong *)((longlong)puVar3 - (longlong)puVar2 >> 2);
            }
            local_58 = (undefined4)local_68;
            uStack_54 = local_68._4_4_;
            uStack_50 = (undefined4)uStack_60;
            uStack_4c = uStack_60._4_4_;
            FUN_140036c20(local_c8,&local_58,1,local_res10);
            puVar3 = local_b0;
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            plVar7 = local_c8[0];
            if (local_c8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar5 = plVar10;
            }
            else {
              plVar5 = (longlong *)*local_c8[0];
            }
            if (puVar3 + (longlong)plVar8 <= (undefined4 *)plVar5[4]) {
              plVar5 = plVar10;
              if (plVar7 != (longlong *)0x0) {
                plVar5 = (longlong *)*plVar7;
              }
              if ((undefined4 *)plVar5[3] <= puVar3 + (longlong)plVar8) goto LAB_1400392b8;
            }
            _invalid_parameter_noinfo();
          }
        }
LAB_1400392b8:
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar10;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((undefined4 *)plVar7[4] <= puVar9) {
          _invalid_parameter_noinfo();
        }
        puVar9 = puVar9 + 1;
      }
      FUN_140035b50(param_1,local_c8,param_2);
      if (local_80 != (undefined4 *)0x0) {
        operator_delete(local_80);
      }
      local_80 = (undefined4 *)0x0;
      local_78 = (undefined4 *)0x0;
      local_70 = 0;
      operator_delete(local_98[0]);
      if (local_b0 != (undefined4 *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (undefined4 *)0x0;
      local_a8 = (undefined4 *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      uVar6 = 1;
    }
  }
  return uVar6;
}

// ==== CChatMsgTalk::helper_1400393e0  @1400393e0  [medium:callgraph-r0]  (orig: FUN_1400393e0)
BADSPACEBASE * FUN_1400393e0(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  longlong *plVar1;
  int *piVar2;
  char cVar3;
  int iVar4;
  int *piVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *local_res10;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58 [3];
  int *local_40;
  int *local_38;
  longlong local_30;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_res10 = operator_new(8);
    plVar8 = (longlong *)0x0;
    local_58[0] = plVar8;
    if (local_res10 != (longlong *)0x0) {
      *local_res10 = (longlong)local_58;
      local_58[0] = local_res10;
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    while( true ) {
      lVar9 = DAT_140975aa0;
      uVar7 = 0;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = FUN_1400423a0(*(undefined8 *)(lVar9 + 0x18));
      lVar9 = DAT_140975aa0;
      if (iVar4 <= (int)plVar8) break;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      piVar5 = (int *)FUN_1400423b0(*(undefined8 *)(lVar9 + 0x18),plVar8);
      if (((piVar5 != (int *)0x0) &&
          ((piVar5[4] == param_3 || (cVar3 = FUN_140037000(param_1,param_3), cVar3 != '\0')))) &&
         ((piVar2 = local_38, param_4 == 0 || (param_4 != *piVar5)))) {
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,piVar5[3]);
        if (local_40 != (int *)0x0) {
          uVar7 = local_30 - (longlong)local_40 >> 2;
        }
        if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar7) {
          *local_38 = piVar5[3];
          local_38 = local_38 + 1;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          piVar5 = local_40;
          plVar1 = local_58[0];
          if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
            lVar9 = 0;
          }
          else {
            if (local_38 < local_40) {
              _invalid_parameter_noinfo();
            }
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
              _invalid_parameter_noinfo();
            }
            lVar9 = (longlong)piVar2 - (longlong)piVar5 >> 2;
          }
          local_78 = SUB84(plVar1,0);
          uStack_74 = (undefined4)((ulonglong)plVar1 >> 0x20);
          uStack_70 = SUB84(piVar2,0);
          uStack_6c = (undefined4)((ulonglong)piVar2 >> 0x20);
          local_68 = local_78;
          uStack_64 = uStack_74;
          uStack_60 = uStack_70;
          uStack_5c = uStack_6c;
          FUN_140036c20(local_58,&local_68,1,&local_res10);
          piVar5 = local_40;
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_58[0];
          if (local_58[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *local_58[0];
          }
          if (piVar5 + lVar9 <= *(int **)(lVar6 + 0x20)) {
            if (plVar1 == (longlong *)0x0) {
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar1;
            }
            if (*(int **)(lVar6 + 0x18) <= piVar5 + lVar9) goto LAB_140039666;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_140039666:
      plVar8 = (longlong *)(ulonglong)((int)plVar8 + 1);
    }
    FUN_140035b50(param_1,local_58,param_2);
    if (local_40 != (int *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
    register0x00000020 = (BADSPACEBASE *)0x1;
  }
  return register0x00000020;
}

// ==== CChatMsgTalk::helper_140039720  @140039720  [medium:callgraph-r0]  (orig: FUN_140039720)
BADSPACEBASE * FUN_140039720(undefined8 param_1,longlong param_2,int param_3,int param_4)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong *local_res10;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  longlong *local_58 [3];
  int *local_40;
  int *local_38;
  longlong local_30;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_res10 = operator_new(8);
    plVar8 = (longlong *)0x0;
    local_58[0] = plVar8;
    if (local_res10 != (longlong *)0x0) {
      *local_res10 = (longlong)local_58;
      local_58[0] = local_res10;
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    while( true ) {
      lVar5 = DAT_140975aa0;
      uVar7 = 0;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = FUN_1400423a0(*(undefined8 *)(lVar5 + 0x18));
      lVar5 = DAT_140975aa0;
      if (iVar4 <= (int)plVar8) break;
      if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar5 = FUN_1400423b0(*(undefined8 *)(lVar5 + 0x18),plVar8);
      piVar3 = local_38;
      if (((lVar5 != 0) && (*(int *)(lVar5 + 0x58) == param_3)) &&
         (iVar4 = *(int *)(lVar5 + 0xc), param_4 != iVar4)) {
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,iVar4);
        if (local_40 != (int *)0x0) {
          uVar7 = local_30 - (longlong)local_40 >> 2;
        }
        if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar7) {
          *local_38 = iVar4;
          local_38 = local_38 + 1;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          piVar2 = local_40;
          plVar1 = local_58[0];
          if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
            lVar5 = 0;
          }
          else {
            if (local_38 < local_40) {
              _invalid_parameter_noinfo();
            }
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
              _invalid_parameter_noinfo();
            }
            lVar5 = (longlong)piVar3 - (longlong)piVar2 >> 2;
          }
          local_78 = SUB84(plVar1,0);
          uStack_74 = (undefined4)((ulonglong)plVar1 >> 0x20);
          uStack_70 = SUB84(piVar3,0);
          uStack_6c = (undefined4)((ulonglong)piVar3 >> 0x20);
          local_68 = local_78;
          uStack_64 = uStack_74;
          uStack_60 = uStack_70;
          uStack_5c = uStack_6c;
          FUN_140036c20(local_58,&local_68,1,&local_res10);
          piVar3 = local_40;
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_58[0];
          if (local_58[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *local_58[0];
          }
          if (piVar3 + lVar5 <= *(int **)(lVar6 + 0x20)) {
            if (plVar1 == (longlong *)0x0) {
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar1;
            }
            if (*(int **)(lVar6 + 0x18) <= piVar3 + lVar5) goto LAB_14003998c;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_14003998c:
      plVar8 = (longlong *)(ulonglong)((int)plVar8 + 1);
    }
    FUN_140035b50(param_1,local_58,param_2);
    if (local_40 != (int *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (int *)0x0;
    local_38 = (int *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
    register0x00000020 = (BADSPACEBASE *)0x1;
  }
  return register0x00000020;
}

// ==== CChatMsgTalk::helper_14003d0e0  @14003d0e0  [medium:callgraph-r1]  (orig: FUN_14003d0e0)
void FUN_14003d0e0(longlong param_1,int param_2,int param_3,undefined8 param_4,undefined8 param_5,
                  uint param_6)

{
  int iVar1;
  uint *puVar2;
  int iVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong lVar7;
  int local_48;
  uint local_44;
  uint local_40;
  int local_3c;
  int local_38;
  undefined8 local_30;
  
  local_30 = 0xfffffffffffffffe;
  FUN_140036640(param_4);
  iVar1 = param_2 / 0x12 + -1;
  local_48 = 0;
  if (0 < iVar1) {
    local_48 = iVar1;
  }
  for (; (local_48 <= param_2 / 0x12 + 1 && (local_48 < *(int *)(param_1 + 0xc)));
      local_48 = local_48 + 1) {
    iVar1 = param_3 / 0x12 + -1;
    local_38 = 0;
    if (0 < iVar1) {
      local_38 = iVar1;
    }
    while ((iVar1 = local_38, local_38 <= param_3 / 0x12 + 1 &&
           (local_38 < *(int *)(param_1 + 0x10)))) {
      if ((ulonglong)((*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30)) / 0x30) <=
          (ulonglong)(longlong)local_48) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (longlong)local_48 * 0x30 + *(longlong *)(param_1 + 0x30);
      if ((ulonglong)((*(longlong *)(lVar7 + 0x20) - *(longlong *)(lVar7 + 0x18)) / 0x30) <=
          (ulonglong)(longlong)iVar1) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (longlong)iVar1 * 0x30 + *(longlong *)(lVar7 + 0x18);
      local_3c = 0;
      while (iVar3 = local_3c,
            uVar5 = *(longlong *)(lVar7 + 0x20) - *(longlong *)(lVar7 + 0x18) >> 3,
            local_3c < (int)uVar5) {
        if (-1 < local_3c) {
          uVar6 = (ulonglong)local_3c;
          if (uVar5 <= uVar6) {
            _invalid_parameter_noinfo();
          }
          puVar2 = *(uint **)(*(longlong *)(lVar7 + 0x18) + uVar6 * 8);
          if (((puVar2 != (uint *)0x0) && (puVar2[3] != param_6)) &&
             (iVar4 = FUN_140045c50(puVar2,param_2,param_3), iVar4 < 0x13)) {
            if (((puVar2[2] == 0) || (puVar2[2] == 0xffffffff)) || (*puVar2 < 0xee69a15f)) {
              local_40 = puVar2[3];
              FUN_140037fe0(param_4,&local_40);
            }
            else {
              local_44 = puVar2[3];
              FUN_140037fe0(param_5,&local_44);
            }
          }
        }
        local_3c = iVar3 + 1;
      }
      local_38 = iVar1 + 1;
    }
  }
  return;
}

// ==== CChatMsgTalk::helper_140040060  @140040060  [medium:callgraph-r0]  (orig: FUN_140040060)
undefined8 FUN_140040060(longlong param_1,int param_2,longlong param_3)

{
  longlong lVar1;
  ulong uVar2;
  undefined8 uVar3;
  uint *puVar4;
  longlong *plVar5;
  longlong *plVar6;
  
  lVar1 = DAT_140975aa0;
  if (*(int *)(param_1 + 0x10) == 0) {
    uVar3 = 1;
  }
  else if ((param_2 == 0) || (param_3 == 0)) {
    uVar3 = 0;
  }
  else {
    if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    puVar4 = (uint *)FUN_140042da0(*(undefined8 *)(lVar1 + 0x18),param_2);
    uVar3 = 0;
    if (puVar4 != (uint *)0x0) {
      if ((*puVar4 < 0xee69a15f) || (puVar4[2] == 0)) {
        plVar5 = (longlong *)InstanceGet();
        plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,"cq_talktogm");
        uVar3 = 0;
        if (plVar5 != (longlong *)0x0) {
          plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0);
          (**(code **)(*plVar6 + 0xb0))(plVar6,0);
          plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,1);
          (**(code **)(*plVar6 + 0xb8))(plVar6,param_2);
          plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,2);
          (**(code **)(*plVar6 + 0xb0))(plVar6,puVar4[0x14]);
          plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,3);
          (**(code **)(*plVar6 + 0x80))(plVar6,param_3);
          plVar6 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
          lVar1 = *plVar6;
          uVar2 = tq::TimeGet(1);
          (**(code **)(lVar1 + 0xb8))(plVar6,uVar2);
          (**(code **)(*plVar5 + 0x50))(plVar5,0);
          (**(code **)*plVar5)(plVar5,1);
          uVar3 = 1;
        }
      }
      else {
        uVar3 = 0;
      }
    }
  }
  return uVar3;
}

// ==== CChatMsgTalk::ctor_or_dtor  @1400409f0  [high:vtable-assign]  (orig: FUN_1400409f0)
undefined8 * FUN_1400409f0(undefined8 *param_1)

{
  FUN_14003fc90();
  *param_1 = CChatMsgTalk::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f910(param_1);
  param_1[0x84] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x85),(char *)((longlong)param_1 + 0x2d),0x3e1,true);
  return param_1;
}

// ==== CChatMsgTalk::ctor_or_dtor  @140040a70  [high:vtable-assign]  (orig: FUN_140040a70)
void FUN_140040a70(undefined8 *param_1)

{
  *param_1 = CChatMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f900(param_1);
  return;
}

// ==== CChatMsgTalk::helper_140040ab0  @140040ab0  [medium:callgraph-r0]  (orig: FUN_140040ab0)
bool FUN_140040ab0(longlong param_1,char *param_2,char *param_3,char *param_4,char *param_5,
                  undefined4 param_6,undefined2 param_7,undefined2 param_8,undefined4 param_9,
                  undefined4 param_10,undefined1 param_11)

{
  char cVar1;
  bool bVar2;
  bool bVar3;
  bool bVar4;
  bool bVar5;
  ulong uVar6;
  uint uVar7;
  ulonglong uVar8;
  char *pcVar9;
  
  if (param_2 != (char *)0x0) {
    uVar8 = 0xffffffffffffffff;
    pcVar9 = param_2;
    do {
      if (uVar8 == 0) break;
      uVar8 = uVar8 - 1;
      cVar1 = *pcVar9;
      pcVar9 = pcVar9 + 1;
    } while (cVar1 != '\0');
    if ((~uVar8 - 1 < 0x10) && (param_3 != (char *)0x0)) {
      uVar8 = 0xffffffffffffffff;
      pcVar9 = param_3;
      do {
        if (uVar8 == 0) break;
        uVar8 = uVar8 - 1;
        cVar1 = *pcVar9;
        pcVar9 = pcVar9 + 1;
      } while (cVar1 != '\0');
      if ((~uVar8 - 1 < 0x10) && (param_4 != (char *)0x0)) {
        uVar8 = 0xffffffffffffffff;
        pcVar9 = param_4;
        do {
          if (uVar8 == 0) break;
          uVar8 = uVar8 - 1;
          cVar1 = *pcVar9;
          pcVar9 = pcVar9 + 1;
        } while (cVar1 != '\0');
        if (~uVar8 - 1 < 0x100) {
          if (param_5 != (char *)0x0) {
            uVar8 = 0xffffffffffffffff;
            pcVar9 = param_5;
            do {
              if (uVar8 == 0) break;
              uVar8 = uVar8 - 1;
              cVar1 = *pcVar9;
              pcVar9 = pcVar9 + 1;
            } while (cVar1 != '\0');
            if (0xf < ~uVar8 - 1) {
              return false;
            }
          }
          FUN_14003f910(param_1);
          *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 4) = param_6;
          *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8) = param_7;
          *(undefined2 *)(*(longlong *)(param_1 + 0x420) + 10) = param_8;
          *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 0x14) = param_9;
          *(undefined4 *)(*(longlong *)(param_1 + 0x420) + 0x18) = param_10;
          *(undefined1 *)(*(longlong *)(param_1 + 0x420) + 0x1c) = param_11;
          uVar6 = tq::SysTimeGet();
          *(ulong *)(*(longlong *)(param_1 + 0x420) + 0xc) = uVar6;
          bVar2 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_2);
          bVar3 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_3);
          bVar4 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_5);
          bVar5 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_4);
          uVar6 = tq::TimeGet(0);
          **(ulong **)(param_1 + 0x420) = uVar6;
          *(undefined4 *)(param_1 + 8) = 0x3ec;
          uVar7 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
          *(uint *)(param_1 + 0xc) = uVar7 + 0x1f;
          return ((bVar2 && bVar3) && bVar4) && bVar5;
        }
      }
    }
  }
  return false;
}

// ==== CChatMsgTalk::vfunc_1  @140040c80  [high:rtti-vtable]  (orig: FUN_140040c80)
undefined8 FUN_140040c80(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CChatMsgTalk::helper_140040cb0  @140040cb0  [medium:callgraph-r0]  (orig: FUN_140040cb0)
undefined8 FUN_140040cb0(longlong param_1,char *param_2)

{
  bool bVar1;
  uint uVar2;
  
  bVar1 = tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x428),param_2);
  if (bVar1) {
    uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x428));
    *(uint *)(param_1 + 0xc) = uVar2 + 0x1f;
    return 1;
  }
  return 0;
}

// ==== CChatMsgTalk::vfunc_3  @140040d00  [high:rtti-vtable]  (orig: FUN_140040d00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140040d00(longlong param_1)

{
  uint *puVar1;
  longlong *plVar2;
  undefined4 uVar3;
  char cVar4;
  undefined1 uVar5;
  ushort uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  ulong uVar11;
  uint *puVar12;
  uint *puVar13;
  longlong lVar14;
  char *pcVar15;
  IStringManager *pIVar16;
  undefined4 *puVar17;
  uint uVar18;
  undefined1 auStack_cb8 [32];
  uint *local_c98;
  char *local_c90;
  undefined2 local_c88;
  undefined2 local_c80;
  undefined4 local_c78;
  undefined4 local_c70;
  undefined1 local_c68;
  uint local_c58;
  int local_c54;
  uint local_c50;
  longlong local_c48;
  undefined8 local_c40;
  uint local_c38 [264];
  longlong local_818;
  char local_7f8 [48];
  char local_7c8 [65];
  undefined8 local_787;
  undefined8 local_77f;
  undefined8 local_777;
  undefined8 local_76f;
  undefined8 local_767;
  undefined8 local_75f;
  undefined8 local_757;
  undefined4 local_74f;
  undefined2 local_74b;
  undefined1 local_749;
  char local_748 [16];
  uint local_738 [4];
  char local_728 [255];
  undefined1 local_629;
  char local_628;
  undefined1 local_627 [255];
  undefined1 local_528;
  undefined1 local_527 [255];
  char local_428;
  undefined1 local_427 [1023];
  ulonglong local_28;
  
  local_c40 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_cb8;
  local_c48 = param_1;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),0,local_7f8 + 0x20,0x10);
  uVar18 = 1;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),1,local_748,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),2,(char *)local_738,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),3,local_728,0x100);
  lVar14 = DAT_140975aa0;
  uVar3 = *(undefined4 *)(param_1 + 0x414);
  if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
    local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h");
  }
  puVar12 = (uint *)FUN_140042e80(*(undefined8 *)(lVar14 + 0x18),uVar3);
  if (puVar12 == (uint *)0x0) {
    if (*(short *)(*(longlong *)(param_1 + 0x420) + 8) != 0x89e) {
      local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x76);
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK",
                         "pUser || m_pInfo->unTxtAttribute==_TXTATR_MSG_SYSTEM",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgtalk.cpp"
                        );
      return;
    }
  }
  else {
    puVar1 = puVar12 + 0xc;
    puVar13 = puVar1;
    do {
      uVar9 = *puVar13;
      cVar4 = *(char *)((longlong)puVar13 + (longlong)(local_7f8 + (0x20 - (longlong)puVar1)));
      if ((char)uVar9 != cVar4) break;
      puVar13 = (uint *)((longlong)puVar13 + 1);
    } while (cVar4 != '\0');
    if (((char)uVar9 != cVar4) && (cVar4 = FUN_1400459a0(puVar12), cVar4 == '\0')) {
      tq::GmLogSave("gm",&DAT_1406e8b68,puVar1,local_7f8 + 0x20);
      return;
    }
    cVar4 = FUN_140045b40(puVar12,*(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8));
    if (cVar4 != '\0') {
      return;
    }
    if (*(char *)((longlong)puVar12 + 0x41) != '\0') {
      return;
    }
  }
  cVar4 = FUN_140035030(DAT_140975aa0,local_728);
  if (cVar4 != '\0') {
    tq::MyLogSave("gmlog/MonitorTalkKeyword","userid:%u, talk:%s",(ulonglong)*puVar12,local_728);
  }
  if (puVar12 != (uint *)0x0) {
    uVar9 = *(uint *)(*(longlong *)(param_1 + 0x420) + 0x10);
    if ((999999 < uVar9) && (uVar9 < 0x1e8481)) {
      plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
      if (*plVar2 == 0) {
        local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
        log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                          );
      }
      if (*(longlong *)(*plVar2 + 0x30) == 0) {
        return;
      }
      plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
      if (*plVar2 == 0) {
        local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
        log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                          );
      }
      FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(*(longlong *)(*plVar2 + 0x30) + 0xc),param_1);
      return;
    }
    if (local_728[0] == '/') {
      iVar7 = _stricmp(local_728,"/afgetghserveraaversion");
      if (iVar7 == 0) {
        local_7c8[0x40] = 0;
        local_787 = 0;
        local_77f = 0;
        local_777 = 0;
        local_76f = 0;
        local_767 = 0;
        local_75f = 0;
        local_757 = 0;
        local_74f = 0;
        local_74b = 0;
        local_749 = 0;
        _snprintf(local_7c8 + 0x40,0x40,
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgtalk.cpp"
                 );
        local_749 = 0;
        FUN_140033130(DAT_140975aa0,puVar12[3],local_7c8 + 0x40);
        return;
      }
      iVar7 = _stricmp(local_728,"/afgetghserveraaip");
      if (iVar7 == 0) {
        local_528 = 0;
        memset(local_527,0,0xfe);
        iVar7 = Ordinal_57(&local_528,0xff);
        if (iVar7 == -1) {
          return;
        }
        lVar14 = Ordinal_52(&local_528);
        if (lVar14 == 0) {
          return;
        }
        local_7c8[0] = '\0';
        local_7c8[1] = '\0';
        local_7c8[2] = '\0';
        local_7c8[3] = '\0';
        local_7c8[4] = '\0';
        local_7c8[5] = '\0';
        local_7c8[6] = '\0';
        local_7c8[7] = '\0';
        local_7c8[8] = '\0';
        local_7c8[9] = '\0';
        local_7c8[10] = '\0';
        local_7c8[0xb] = '\0';
        local_7c8[0xc] = '\0';
        local_7c8[0xd] = '\0';
        local_7c8[0xe] = '\0';
        local_7c8[0xf] = '\0';
        local_7c8[0x10] = '\0';
        local_7c8[0x11] = '\0';
        local_7c8[0x12] = '\0';
        local_7c8[0x13] = '\0';
        local_7c8[0x14] = '\0';
        local_7c8[0x15] = '\0';
        local_7c8[0x16] = '\0';
        local_7c8[0x17] = '\0';
        local_7c8[0x18] = '\0';
        local_7c8[0x19] = '\0';
        local_7c8[0x1a] = '\0';
        local_7c8[0x1b] = '\0';
        local_7c8[0x1c] = '\0';
        local_7c8[0x1d] = '\0';
        local_7c8[0x1e] = '\0';
        local_7c8[0x1f] = '\0';
        local_7c8[0x20] = '\0';
        local_7c8[0x21] = '\0';
        local_7c8[0x22] = '\0';
        local_7c8[0x23] = '\0';
        local_7c8[0x24] = '\0';
        local_7c8[0x25] = '\0';
        local_7c8[0x26] = '\0';
        local_7c8[0x27] = '\0';
        local_7c8[0x28] = '\0';
        local_7c8[0x29] = '\0';
        local_7c8[0x2a] = '\0';
        local_7c8[0x2b] = '\0';
        local_7c8[0x2c] = '\0';
        local_7c8[0x2d] = '\0';
        local_7c8[0x2e] = '\0';
        local_7c8[0x2f] = '\0';
        local_7c8[0x30] = '\0';
        local_7c8[0x31] = '\0';
        local_7c8[0x32] = '\0';
        local_7c8[0x33] = '\0';
        local_7c8[0x34] = '\0';
        local_7c8[0x35] = '\0';
        local_7c8[0x36] = '\0';
        local_7c8[0x37] = '\0';
        local_7c8[0x38] = '\0';
        local_7c8[0x39] = '\0';
        local_7c8[0x3a] = '\0';
        local_7c8[0x3b] = '\0';
        local_7c8[0x3c] = '\0';
        local_7c8[0x3d] = '\0';
        local_7c8[0x3e] = '\0';
        local_7c8[0x3f] = 0;
        local_c54 = 0;
        while( true ) {
          iVar7 = local_c54;
          if (*(longlong *)(*(longlong *)(lVar14 + 0x18) + (longlong)local_c54 * 8) == 0) break;
          pcVar15 = (char *)Ordinal_12(**(undefined4 **)
                                         (*(longlong *)(lVar14 + 0x18) + (longlong)local_c54 * 8));
          iVar8 = _stricmp(pcVar15,"127.0.0.1");
          if (iVar8 != 0) {
            local_c98 = (uint *)pcVar15;
            _snprintf(local_7c8,0x40,"%s%s ",local_7c8);
            local_7c8[0x3f] = 0;
          }
          local_c54 = iVar7 + 1;
        }
        FUN_140033130(DAT_140975aa0,puVar12[3],local_7c8);
        return;
      }
    }
  }
  cVar4 = FUN_140045c80(puVar12);
  if ((cVar4 != '\0') && (cVar4 = FUN_140045cd0(puVar12), cVar4 == '\0')) {
    local_7f8[1] = '\0';
    local_7f8[2] = '\0';
    local_7f8[3] = '\0';
    local_7f8[4] = '\0';
    local_7f8[5] = '\0';
    local_7f8[6] = '\0';
    local_7f8[7] = '\0';
    local_7f8[8] = '\0';
    local_7f8[9] = '\0';
    local_7f8[10] = '\0';
    local_7f8[0xb] = '\0';
    local_7f8[0xc] = '\0';
    local_7f8[0xd] = '\0';
    local_7f8[0xe] = '\0';
    local_7f8[0xf] = '\0';
    local_7f8[0x10] = '\0';
    local_7f8[0x11] = '\0';
    local_7f8[0x12] = '\0';
    local_7f8[0x13] = '\0';
    local_7f8[0x14] = '\0';
    local_7f8[0x15] = '\0';
    local_7f8[0x16] = '\0';
    local_7f8[0x17] = '\0';
    local_7f8[0x18] = '\0';
    local_7f8[0x19] = '\0';
    local_7f8[0x1a] = '\0';
    local_7f8[0x1b] = '\0';
    local_7f8[0x1c] = '\0';
    local_7f8[0x1d] = '\0';
    local_7f8[0x1e] = '\0';
    local_7f8[0x1f] = 0;
    local_7f8[0] = cVar4;
    pIVar16 = theInstance();
    uVar6 = FUN_140045cf0(puVar12);
    pcVar15 = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_SHIELDED_TIMES");
    _snprintf(local_7f8,0x20,pcVar15,(ulonglong)uVar6);
    local_7f8[0x1f] = 0;
    local_c98 = (uint *)local_7f8;
    _snprintf(local_728,0x100,"%s%s",local_728);
    local_629 = 0;
  }
  FUN_1400409f0(local_c38);
  lVar14 = *(longlong *)(param_1 + 0x420);
  uVar5 = FUN_140045d10(puVar12);
  local_c70 = FUN_140045d00(puVar12);
  local_c78 = *(undefined4 *)(lVar14 + 0x14);
  local_c80 = *(undefined2 *)(lVar14 + 10);
  local_c88 = *(undefined2 *)(lVar14 + 8);
  local_c90 = (char *)CONCAT44(local_c90._4_4_,*(undefined4 *)(lVar14 + 4));
  local_c98 = local_738;
  local_c68 = uVar5;
  iVar7 = FUN_140040ab0(local_c38,local_7f8 + 0x20,local_748,local_728);
  if (iVar7 == 0) {
    local_c98 = (uint *)CONCAT44(local_c98._4_4_,0xdd);
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT",
                       "msgChatTalk.Create(szSender, szReceiver, szWords, szEmotion, m_pInfo->dwWordsColor, m_pInfo->unTxtAttribute, m_pInfo->unTxtStyle, m_pInfo->dwLookFace, pUser->GetAllOfficial(), pUser->GetSex())"
                       ,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgtalk.cpp"
                      );
    FUN_140040a70(local_c38);
  }
  else {
    local_c58 = 1;
    uVar9 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x428));
    if (4 < uVar9) {
      local_c50 = 4;
      while (uVar9 = local_c50,
            uVar10 = tq::CStringPacker::GetStrAmount((CStringPacker *)(param_1 + 0x428)),
            uVar9 < uVar10) {
        local_628 = '\0';
        memset(local_627,0,0xff);
        tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x428),uVar9,&local_628,0x100);
        uVar10 = FUN_140040cb0(local_c38);
        uVar18 = uVar18 & uVar10;
        local_c58 = uVar18;
        local_c50 = uVar9 + 1;
      }
      if (uVar18 == 0) {
        local_c98 = (uint *)CONCAT44(local_c98._4_4_,0xec);
        log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","bSucMake",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgtalk.cpp"
                          );
        FUN_140040a70(local_c38);
        return;
      }
    }
    lVar14 = DAT_140975aa0;
    if ((puVar12 == (uint *)0x0) || ((char)puVar12[0x10] != '\0')) {
      switch(*(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8)) {
      case 2000:
        local_c90 = (char *)CONCAT44(local_c90._4_4_,puVar12[3]);
        local_c98 = local_c38;
        FUN_140038390(DAT_140975aa0,puVar12[7],puVar12[8],puVar12[6]);
        plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
        if (*plVar2 == 0) {
          local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                            );
        }
        if (*(longlong *)(*plVar2 + 0x30) != 0) {
          plVar2 = (longlong *)(DAT_140975aa0 + 0x28);
          if (*plVar2 == 0) {
            local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x21);
            log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGMTool",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                              );
          }
          lVar14 = DAT_140975aa0;
          if (*plVar2 != 0) {
            uVar18 = puVar12[8];
            uVar9 = puVar12[7];
            uVar10 = puVar12[6];
            if (*(longlong *)(DAT_140975aa0 + 0x28) == 0) {
              local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x21);
              log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGMTool",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                );
            }
            cVar4 = FUN_14004ad20(*(undefined8 *)(lVar14 + 0x28),uVar10,uVar9,uVar18);
            if (cVar4 != '\0') {
              plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
              if (*plVar2 == 0) {
                local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
                log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                  );
              }
              FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(*(longlong *)(*plVar2 + 0x30) + 0xc),
                            local_c38);
            }
          }
        }
        break;
      case 0x7d1:
        if (*(longlong *)(DAT_140975aa0 + 0x18) == 0) {
          local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                            );
        }
        puVar17 = (undefined4 *)FUN_140042f50(*(undefined8 *)(lVar14 + 0x18),local_748);
        if (puVar17 == (undefined4 *)0x0) {
          FUN_140032240(DAT_140975aa0,local_c38,puVar12[3]);
        }
        else {
          if (puVar12 != (uint *)0x0) {
            if (puVar12[6] == 0x40c) {
              plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
              if (*plVar2 == 0) {
                local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
                log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                  );
              }
              if (*(longlong *)(*plVar2 + 0x30) != 0) {
                plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
                if (*plVar2 == 0) {
                  local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
                  log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                    );
                }
                FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(*(longlong *)(*plVar2 + 0x30) + 0xc),
                              local_c38);
              }
            }
            else if ((puVar12[6] == 0x1772) &&
                    (cVar4 = FUN_140046100(puVar12,*puVar17), cVar4 != '\0')) {
              FUN_140040a70(local_c38);
              return;
            }
            *(uint *)(local_818 + 0x14) = puVar12[0xb];
          }
          FUN_1400330d0(DAT_140975aa0,puVar17[3],local_c38);
        }
        break;
      default:
        FUN_140032240(DAT_140975aa0,local_c38,puVar12[3]);
        break;
      case 0x7d3:
        if (puVar12 != (uint *)0x0) {
          FUN_140038ca0(DAT_140975aa0,local_c38,puVar12[10],puVar12[3]);
        }
        break;
      case 0x7d4:
        FUN_1400386d0(DAT_140975aa0,local_c38,puVar12[4],puVar12[3]);
        break;
      case 0x7d5:
        break;
      case 0x7d6:
        if (puVar12 != (uint *)0x0) {
          FUN_1400389b0(DAT_140975aa0,local_c38,puVar12[5],puVar12[3]);
        }
        break;
      case 0x7d9:
        if (puVar12 != (uint *)0x0) {
          FUN_140038f90(DAT_140975aa0,local_c38,*puVar12);
        }
        break;
      case 0x7de:
        uVar18 = *puVar12;
        if (*(longlong *)(DAT_140975aa0 + 0x38) == 0) {
          local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x23);
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGMTalkMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                            );
        }
        FUN_140040060(*(undefined8 *)(lVar14 + 0x38),uVar18,local_728);
        break;
      case 0x7e5:
        if ((puVar12 != (uint *)0x0) && (cVar4 = FUN_140045bd0(puVar12), cVar4 != '\0')) {
          FUN_140032160(DAT_140975aa0,local_c38,puVar12[3]);
          uVar11 = tq::TimeGet(0);
          puVar12[0x11] = uVar11;
          plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
          if (*plVar2 == 0) {
            local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
            log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                              );
          }
          if (*(longlong *)(*plVar2 + 0x30) != 0) {
            plVar2 = (longlong *)(DAT_140975aa0 + 0x28);
            if (*plVar2 == 0) {
              local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x21);
              log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGMTool",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                );
            }
            lVar14 = DAT_140975aa0;
            if (*plVar2 != 0) {
              uVar18 = puVar12[8];
              uVar9 = puVar12[7];
              uVar10 = puVar12[6];
              if (*(longlong *)(DAT_140975aa0 + 0x28) == 0) {
                local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x21);
                log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pGMTool",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                  );
              }
              cVar4 = FUN_14004ad20(*(undefined8 *)(lVar14 + 0x28),uVar10,uVar9,uVar18);
              if (cVar4 != '\0') {
                plVar2 = (longlong *)(DAT_140975aa0 + 0x18);
                if (*plVar2 == 0) {
                  local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x1f);
                  log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pChatPlayerMgr",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\chatkernel.h"
                                    );
                }
                FUN_1400330d0(DAT_140975aa0,*(undefined4 *)(*(longlong *)(*plVar2 + 0x30) + 0xc),
                              local_c38);
              }
            }
          }
        }
        break;
      case 0x7e9:
        FUN_1400393e0(DAT_140975aa0,local_c38,puVar12[4],*puVar12);
        break;
      case 0x7ec:
        if (puVar12 != (uint *)0x0) {
          FUN_140039720(DAT_140975aa0,local_c38,puVar12[0x16],puVar12[3]);
        }
        break;
      case 0x89e:
        local_c98 = (uint *)CONCAT44(local_c98._4_4_,0x17d);
        log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"_TXTATR_MSG_OTHER\"",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\chatkernel\\network3\\chatmsgtalk.cpp"
                          );
        break;
      case 0x89f:
        if ((puVar12 == (uint *)0x0) || (cVar4 = FUN_140032320(DAT_140975aa0), cVar4 == '\0')) {
          FUN_140040a70(local_c38);
          return;
        }
        local_428 = '\0';
        memset(local_427,0,0x3ff);
        local_c98 = puVar12 + 0xc;
        local_c90 = local_728;
        _snprintf(&local_428,0x3ff,"UserID[%u] Name[%s] Suggest:%s",(ulonglong)*puVar12);
        tq::GmLogSave("user_suggest",&local_428);
      }
      FUN_140040a70(local_c38);
    }
    else {
      switch(*(undefined2 *)(*(longlong *)(param_1 + 0x420) + 8)) {
      case 0x7d3:
        if (0 < (int)puVar12[10]) {
          FUN_140038ca0(DAT_140975aa0,local_c38,puVar12[10],puVar12[3]);
        }
        break;
      case 0x7d4:
        FUN_1400386d0(DAT_140975aa0,local_c38,puVar12[4],puVar12[3]);
        break;
      default:
        *(undefined2 *)(local_818 + 8) = 0x7dd;
        local_c90 = (char *)CONCAT44(local_c90._4_4_,puVar12[3]);
        local_c98 = local_c38;
        FUN_140038390(DAT_140975aa0,puVar12[7],puVar12[8],puVar12[6]);
        break;
      case 0x7d6:
        FUN_1400389b0(DAT_140975aa0,local_c38,puVar12[5],puVar12[3]);
        break;
      case 0x7d9:
        FUN_140038f90(DAT_140975aa0,local_c38,*puVar12);
        break;
      case 0x7e9:
        FUN_1400393e0(DAT_140975aa0,local_c38,puVar12[4],*puVar12);
        break;
      case 0x7ec:
        FUN_140039720(DAT_140975aa0,local_c38,puVar12[0x16],puVar12[3]);
      }
      FUN_140040a70(local_c38);
    }
  }
  return;
}

// ==== CChatMsgTalk::ctor_or_dtor  @140041df0  [high:vtable-assign]  (orig: FUN_140041df0)
undefined8 * FUN_140041df0(undefined8 *param_1,uint param_2)

{
  *param_1 = CChatMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x85));
  FUN_14003f900(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CChatMsgTalk::helper_1400423b0  @1400423b0  [medium:callgraph-r1]  (orig: FUN_1400423b0)
undefined8 FUN_1400423b0(longlong param_1,int param_2)

{
  ulonglong uVar1;
  
  if ((-1 < param_2) &&
     (uVar1 = *(longlong *)(param_1 + 0x20) - *(longlong *)(param_1 + 0x18) >> 3,
     param_2 < (int)uVar1)) {
    if (uVar1 <= (ulonglong)(longlong)param_2) {
      _invalid_parameter_noinfo();
    }
    return *(undefined8 *)(*(longlong *)(param_1 + 0x18) + (longlong)param_2 * 8);
  }
  return 0;
}

// ==== CChatMsgTalk::helper_140042f50  @140042f50  [medium:callgraph-r0]  (orig: FUN_140042f50)
longlong FUN_140042f50(longlong *param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  char *pcVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if (param_2 == (char *)0x0) {
    return 0;
  }
  plVar6 = (longlong *)param_1[3];
  if ((longlong *)param_1[4] < plVar6) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)param_1[4];
  plVar4 = (longlong *)*param_1;
  if (plVar3 < (longlong *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  do {
    if ((plVar4 == (longlong *)0x0) || (plVar4 != param_1)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar3) {
      return 0;
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar4;
    }
    if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
      _invalid_parameter_noinfo();
    }
    lVar7 = *plVar6;
    if (lVar7 != 0) {
      pcVar5 = param_2;
      do {
        cVar1 = *pcVar5;
        cVar2 = pcVar5[(lVar7 + 0x30) - (longlong)param_2];
        if (cVar1 != cVar2) break;
        pcVar5 = pcVar5 + 1;
      } while (cVar2 != '\0');
      if (cVar1 == cVar2) {
        return lVar7;
      }
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar4;
    }
    if (*(longlong **)(lVar7 + 0x20) <= plVar6) {
      _invalid_parameter_noinfo();
    }
    plVar6 = plVar6 + 1;
  } while( true );
}

// ==== CChatMsgTalk::helper_1400438a0  @1400438a0  [medium:callgraph-r1]  (orig: FUN_1400438a0)
void FUN_1400438a0(longlong param_1,uint param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  FUN_140036640(param_3);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x68))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x51);
  puVar3 = *(undefined8 **)(param_1 + 0x68);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x51);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x68);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x38);
  if (*(longlong *)(param_1 + 0x38) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x68);
    local_28 = *(longlong *)(param_1 + 0x38);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x68);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x38))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140037140(param_3,lVar4 + 0x20);
  }
  return;
}

// ==== CChatMsgTalk::helper_1400439c0  @1400439c0  [medium:callgraph-r1]  (orig: FUN_1400439c0)
void FUN_1400439c0(longlong param_1,uint param_2,undefined8 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  FUN_140036640(param_3);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0xa8))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x51);
  puVar3 = *(undefined8 **)(param_1 + 0xa8);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x51);
  }
  puVar7 = *(undefined8 **)(param_1 + 0xa8);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x78);
  if (*(longlong *)(param_1 + 0x78) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xa8);
    local_28 = *(longlong *)(param_1 + 0x78);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0xa8);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x78))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar8) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140037140(param_3,lVar4 + 0x20);
  }
  return;
}

// ==== CChatMsgTalk::helper_140045b40  @140045b40  [medium:callgraph-r0]  (orig: FUN_140045b40)
char * FUN_140045b40(longlong param_1,int param_2)

{
  ulong uVar1;
  char *pcVar2;
  undefined4 extraout_var;
  uint uVar3;
  
  pcVar2 = strstr((char *)(param_1 + 0x30),"[GM]");
  if ((pcVar2 == (char *)0x0) &&
     (pcVar2 = strstr((char *)(param_1 + 0x30),"[PM]"), pcVar2 == (char *)0x0)) {
    if (param_2 == 0x7d1) {
      uVar3 = 500;
    }
    else {
      uVar3 = *(uint *)(DAT_140975aa0 + 0x48);
      pcVar2 = DAT_140975aa0;
      if (param_2 == 0x83e) goto LAB_140045bbc;
    }
    uVar1 = tq::TimeGet(0);
    pcVar2 = (char *)CONCAT71((int7)(CONCAT44(extraout_var,uVar1) >> 8),1);
    if (uVar1 - *(int *)(param_1 + 0x48) <= uVar3) {
      return pcVar2;
    }
    *(ulong *)(param_1 + 0x48) = uVar1;
  }
LAB_140045bbc:
  return (char *)((ulonglong)pcVar2 & 0xffffffffffffff00);
}

// ==== CChatMsgTalk::helper_140045bd0  @140045bd0  [medium:callgraph-r0]  (orig: FUN_140045bd0)
undefined8 FUN_140045bd0(longlong param_1)

{
  int iVar1;
  ulong uVar2;
  uint uVar3;
  
  if (*(short *)(param_1 + 0x4c) == 0) {
    iVar1 = *(int *)(param_1 + 0x24);
    if (iVar1 < 0x46) {
      return 0;
    }
    if (iVar1 < 0x78) {
      if (iVar1 < 100) {
        uVar3 = 60000;
        if (0x59 < iVar1) {
          uVar3 = 45000;
        }
      }
      else {
        uVar3 = 30000;
      }
    }
    else {
      uVar3 = 15000;
    }
  }
  else {
    uVar3 = 15000;
  }
  if ((*(int *)(param_1 + 0x44) != 0) &&
     (uVar2 = tq::TimeGet(0), uVar2 - *(int *)(param_1 + 0x44) < uVar3)) {
    return 0;
  }
  return 1;
}

// ==== CChatMsgTalk::helper_140045c50  @140045c50  [medium:callgraph-r2]  (orig: FUN_140045c50)
int FUN_140045c50(longlong param_1,int param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  
  uVar1 = *(int *)(param_1 + 0x1c) - param_2;
  uVar4 = (int)uVar1 >> 0x1f;
  uVar2 = *(int *)(param_1 + 0x20) - param_3;
  iVar5 = (uVar1 ^ uVar4) - uVar4;
  uVar1 = (int)uVar2 >> 0x1f;
  iVar3 = (uVar2 ^ uVar1) - uVar1;
  if (iVar3 < iVar5) {
    iVar3 = iVar5;
  }
  return iVar3;
}

// ==== CChatMsgTalk::helper_140045c80  @140045c80  [medium:callgraph-r0]  (orig: FUN_140045c80)
ulonglong FUN_140045c80(longlong param_1)

{
  ushort uVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  uVar1 = *(ushort *)(param_1 + 0x4c);
  uVar3 = (ulonglong)uVar1;
  if (uVar1 == 0) {
    uVar2 = *(uint *)(param_1 + 0x24);
    uVar4 = (ulonglong)uVar2;
    if ((((0x32 < (int)uVar2) || (*(ushort *)(param_1 + 0x5c) < 10)) &&
        ((100 < (int)uVar2 || (*(ushort *)(param_1 + 0x5c) < 0x14)))) &&
       (uVar3 = uVar4, *(ushort *)(param_1 + 0x5c) < 0x1e)) {
LAB_140045cc2:
      return uVar3 & 0xffffffffffffff00;
    }
  }
  else if ((uVar1 != 1) || (uVar4 = 0, *(ushort *)(param_1 + 0x5c) < 0x32)) {
    if (99 < *(ushort *)(param_1 + 0x5c)) {
      return CONCAT71((uint7)(byte)(uVar1 >> 8),1);
    }
    goto LAB_140045cc2;
  }
  return CONCAT71((int7)(uVar4 >> 8),1);
}

// ==== CChatMsgTalk::helper_140045cd0  @140045cd0  [medium:callgraph-r0]  (orig: FUN_140045cd0)
bool FUN_140045cd0(longlong param_1)

{
  if ((*(int *)(param_1 + 0x50) < 6) && (*(longlong *)(param_1 + 0x60) < 30000000)) {
    return 0xf9 < *(int *)(param_1 + 0x68);
  }
  return true;
}

// ==== CChatMsgTalk::helper_140045cf0  @140045cf0  [medium:callgraph-r0]  (orig: FUN_140045cf0)
undefined2 FUN_140045cf0(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x5c);
}

// ==== CChatMsgTalk::helper_140045d00  @140045d00  [medium:callgraph-r0]  (orig: FUN_140045d00)
undefined4 FUN_140045d00(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6c);
}

// ==== CChatMsgTalk::helper_140045d10  @140045d10  [medium:callgraph-r0]  (orig: FUN_140045d10)
ulonglong FUN_140045d10(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = (ulonglong)(*(uint *)(param_1 + 0x2c) % 10000);
  return CONCAT71((int7)(uVar1 * 0x10624dd3 >> 8),(char)(uVar1 / 1000)) & 0xffffffff;
}

// ==== CChatMsgTalk::helper_140046100  @140046100  [medium:callgraph-r0]  (orig: FUN_140046100)
bool FUN_140046100(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  int *piVar3;
  
  piVar1 = *(int **)(param_1 + 0x90);
  if (piVar1 < *(int **)(param_1 + 0x88)) {
    _invalid_parameter_noinfo();
  }
  piVar3 = *(int **)(param_1 + 0x88);
  if (*(int **)(param_1 + 0x90) < piVar3) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0x70);
  for (; (piVar3 != piVar1 && (*piVar3 != param_2)); piVar3 = piVar3 + 1) {
  }
  piVar1 = *(int **)(param_1 + 0x90);
  if (piVar1 < *(int **)(param_1 + 0x88)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0x70))) {
    _invalid_parameter_noinfo();
  }
  return piVar3 != piVar1;
}

// ==== CChatMsgTalk::helper_14004ad20  @14004ad20  [medium:callgraph-r0]  (orig: FUN_14004ad20)
undefined4 FUN_14004ad20(longlong param_1,int param_2,LONG param_3,LONG param_4)

{
  longlong *plVar1;
  int *piVar2;
  POINT pt;
  BOOL BVar3;
  int *piVar4;
  longlong lVar5;
  
  piVar4 = *(int **)(param_1 + 0x48);
  if (*(int **)(param_1 + 0x50) < piVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x30);
  pt.y = param_4;
  pt.x = param_3;
  do {
    piVar2 = *(int **)(param_1 + 0x50);
    if (piVar2 < *(int **)(param_1 + 0x48)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x30))) {
      _invalid_parameter_noinfo();
    }
    if (piVar4 == piVar2) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(int **)(lVar5 + 0x20) <= piVar4) {
      _invalid_parameter_noinfo();
    }
    if (param_2 == *piVar4) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *plVar1;
      }
      if (*(int **)(lVar5 + 0x20) <= piVar4) {
        _invalid_parameter_noinfo();
      }
      BVar3 = PtInRect((RECT *)(piVar4 + 1),pt);
      if (BVar3 != 0) {
        return 1;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(int **)(lVar5 + 0x20) <= piVar4) {
      _invalid_parameter_noinfo();
    }
    piVar4 = piVar4 + 5;
  } while( true );
}

