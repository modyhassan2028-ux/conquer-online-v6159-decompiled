// ==== CCrossMsgLeagueList::ctor_or_dtor  @14045c010  [high:vtable-assign]  (orig: FUN_14045c010)
undefined8 * FUN_14045c010(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueList::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLeagueList::ctor_or_dtor  @14045c060  [high:vtable-assign]  (orig: FUN_14045c060)
void FUN_14045c060(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueList::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLeagueList::vfunc_1  @14045c090  [high:rtti-vtable]  (orig: FUN_14045c090)
undefined8 FUN_14045c090(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLeagueList::vfunc_3  @14045c0c0  [high:rtti-vtable]  (orig: FUN_14045c0c0)
void FUN_14045c0c0(longlong param_1)

{
  short *psVar1;
  longlong *plVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)FUN_140087ed0();
    if (plVar2 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      psVar1 = *(short **)(param_1 + 0x428);
      if (*psVar1 == 0) {
        (**(code **)(*plVar2 + 0x660))(plVar2,psVar1[2],psVar1 + 4);
      }
      else {
        log_InlineLogERROR("CCrossMsgLeagueList::Process wrong action[%u]");
      }
    }
  }
  return;
}

// ==== CCrossMsgLeagueList::ctor_or_dtor  @14045c180  [high:vtable-assign]  (orig: FUN_14045c180)
undefined8 * FUN_14045c180(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueList::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

