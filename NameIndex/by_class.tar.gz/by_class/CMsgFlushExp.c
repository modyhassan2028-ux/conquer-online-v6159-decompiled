// ==== CMsgFlushExp::ctor_or_dtor  @1403eff70  [high:vtable-assign]  (orig: FUN_1403eff70)
undefined8 * FUN_1403eff70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgFlushExp::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgFlushExp::ctor_or_dtor  @1403effc0  [high:vtable-assign]  (orig: FUN_1403effc0)
void FUN_1403effc0(undefined8 *param_1)

{
  *param_1 = CMsgFlushExp::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgFlushExp::vfunc_1  @1403efff0  [high:rtti-vtable]  (orig: FUN_1403efff0)
ulonglong FUN_1403efff0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x450);
}

// ==== CMsgFlushExp::vfunc_3  @1403f00a0  [high:rtti-vtable]  (orig: FUN_1403f00a0)
void FUN_1403f00a0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgFlushExp::ctor_or_dtor  @1403f00e0  [high:vtable-assign]  (orig: FUN_1403f00e0)
undefined8 * FUN_1403f00e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgFlushExp::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

