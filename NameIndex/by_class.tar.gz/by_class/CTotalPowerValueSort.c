// ==== CTotalPowerValueSort::helper_1403f9090  @1403f9090  [medium:callgraph-r1]  (orig: FUN_1403f9090)
longlong FUN_1403f9090(void *param_1,void *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - (longlong)param_1;
    do {
      memcpy((void *)(lVar1 + (longlong)param_1),param_1,0x2c);
      param_1 = (void *)((longlong)param_1 + 0x2c);
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x2c) * 0x2c + param_3;
}

// ==== CTotalPowerValueSort::helper_1403fbe70  @1403fbe70  [medium:callgraph-r0]  (orig: FUN_1403fbe70)
void FUN_1403fbe70(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_1403f9090(uVar1,param_1[4],uVar2,local_res8,local_res8,0);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CTotalPowerValueSort::ctor_or_dtor  @1403fc510  [high:vtable-assign]  (orig: FUN_1403fc510)
void FUN_1403fc510(undefined8 *param_1)

{
  *param_1 = CTotalPowerValueSort::vftable;
  FUN_1403fba40(param_1 + 8);
  operator_delete((void *)param_1[8]);
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CTotalPowerValueSort::ctor_or_dtor  @1403fcaf0  [high:vtable-assign]  (orig: FUN_1403fcaf0)
undefined8 * FUN_1403fcaf0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  *param_1 = CTotalPowerValueSort::vftable;
  puVar1 = param_1 + 1;
  plVar2 = operator_new(8);
  plVar3 = (longlong *)0x0;
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)puVar1;
    plVar3 = plVar2;
  }
  *puVar1 = plVar3;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  FUN_1403fc8a0(param_1 + 8);
  FUN_1403fbe70(puVar1);
  FUN_1403f9e60(param_1 + 8);
  return param_1;
}

// ==== CTotalPowerValueSort::vfunc_0  @1403fcb80  [high:rtti-vtable]  (orig: FUN_1403fcb80)
void * FUN_1403fcb80(void *param_1,uint param_2)

{
  FUN_1403fc510();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

