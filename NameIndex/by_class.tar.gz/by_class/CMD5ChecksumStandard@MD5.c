// ==== CMD5ChecksumStandard@MD5::vfunc_6  @140509240  [high:rtti-vtable]  (orig: FUN_140509240)
undefined8 * FUN_140509240(undefined8 *param_1,byte param_2)

{
  *param_1 = MD5::CMD5Checksum::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMD5ChecksumStandard@MD5::helper_140509c00  @140509c00  [medium:callgraph-r1]  (orig: FUN_140509c00)
void FUN_140509c00(longlong param_1,longlong param_2)

{
  int iVar1;
  uint uVar2;
  undefined2 *puVar3;
  uint uVar4;
  uint uVar5;
  int *piVar6;
  uint uVar7;
  longlong lVar8;
  uint uVar9;
  int local_78 [4];
  int local_68;
  int local_64;
  int local_60;
  int local_5c;
  int local_58;
  int local_54;
  int local_50;
  int local_4c;
  int local_48;
  int local_44;
  int local_40;
  int local_3c;
  
  iVar1 = *(int *)(param_1 + 0x50);
  uVar9 = *(uint *)(param_1 + 0x54);
  uVar7 = *(uint *)(param_1 + 0x58);
  uVar4 = *(uint *)(param_1 + 0x5c);
  lVar8 = 0x10;
  puVar3 = (undefined2 *)(param_2 + 2);
  piVar6 = local_78;
  do {
    lVar8 = lVar8 + -1;
    *piVar6 = CONCAT31(CONCAT21(*puVar3,*(undefined1 *)((longlong)puVar3 + -1)),
                       *(undefined1 *)(puVar3 + -1));
    puVar3 = puVar3 + 2;
    piVar6 = piVar6 + 1;
  } while (lVar8 != 0);
  uVar2 = (~uVar9 & uVar4 | uVar7 & uVar9) + local_78[0] + -0x28955b88 + iVar1;
  uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar9;
  uVar4 = (~uVar2 & uVar7 | uVar9 & uVar2) + local_78[1] + -0x173848aa + uVar4;
  uVar4 = (uVar4 * 0x1000 | uVar4 >> 0x14) + uVar2;
  uVar7 = (~uVar4 & uVar9 | uVar4 & uVar2) + local_78[2] + 0x242070db + uVar7;
  uVar7 = (uVar7 >> 0xf | uVar7 * 0x20000) + uVar4;
  uVar9 = (~uVar7 & uVar2 | uVar4 & uVar7) + local_78[3] + -0x3e423112 + uVar9;
  uVar9 = (uVar9 >> 10 | uVar9 * 0x400000) + uVar7;
  uVar2 = (~uVar9 & uVar4 | uVar7 & uVar9) + local_68 + -0xa83f051 + uVar2;
  uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar9;
  uVar4 = (~uVar2 & uVar7 | uVar9 & uVar2) + local_64 + 0x4787c62a + uVar4;
  uVar4 = (uVar4 * 0x1000 | uVar4 >> 0x14) + uVar2;
  uVar7 = (~uVar4 & uVar9 | uVar4 & uVar2) + local_60 + -0x57cfb9ed + uVar7;
  uVar7 = (uVar7 >> 0xf | uVar7 * 0x20000) + uVar4;
  uVar9 = (~uVar7 & uVar2 | uVar4 & uVar7) + local_5c + -0x2b96aff + uVar9;
  uVar9 = (uVar9 >> 10 | uVar9 * 0x400000) + uVar7;
  uVar2 = (~uVar9 & uVar4 | uVar7 & uVar9) + local_58 + 0x698098d8 + uVar2;
  uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar9;
  uVar4 = (~uVar2 & uVar7 | uVar9 & uVar2) + local_54 + -0x74bb0851 + uVar4;
  uVar4 = (uVar4 * 0x1000 | uVar4 >> 0x14) + uVar2;
  uVar7 = (~uVar4 & uVar9 | uVar4 & uVar2) + local_50 + -0xa44f + uVar7;
  uVar7 = (uVar7 >> 0xf | uVar7 * 0x20000) + uVar4;
  uVar9 = (~uVar7 & uVar2 | uVar4 & uVar7) + local_4c + -0x76a32842 + uVar9;
  uVar9 = (uVar9 >> 10 | uVar9 * 0x400000) + uVar7;
  uVar2 = (~uVar9 & uVar4 | uVar7 & uVar9) + local_48 + 0x6b901122 + uVar2;
  uVar2 = (uVar2 * 0x80 | uVar2 >> 0x19) + uVar9;
  uVar4 = (~uVar2 & uVar7 | uVar9 & uVar2) + local_44 + -0x2678e6d + uVar4;
  uVar4 = (uVar4 * 0x1000 | uVar4 >> 0x14) + uVar2;
  uVar7 = (~uVar4 & uVar9 | uVar4 & uVar2) + local_40 + -0x5986bc72 + uVar7;
  uVar7 = (uVar7 >> 0xf | uVar7 * 0x20000) + uVar4;
  uVar9 = (~uVar7 & uVar2 | uVar4 & uVar7) + local_3c + 0x49b40821 + uVar9;
  uVar9 = (uVar9 >> 10 | uVar9 * 0x400000) + uVar7;
  uVar2 = (~uVar4 & uVar7 | uVar4 & uVar9) + local_78[1] + -0x9e1da9e + uVar2;
  uVar2 = (uVar2 * 0x20 | uVar2 >> 0x1b) + uVar9;
  uVar4 = (~uVar7 & uVar9 | uVar7 & uVar2) + local_60 + -0x3fbf4cc0 + uVar4;
  uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar2;
  uVar7 = (~uVar9 & uVar2 | uVar4 & uVar9) + local_4c + 0x265e5a51 + uVar7;
  uVar7 = (uVar7 * 0x4000 | uVar7 >> 0x12) + uVar4;
  uVar9 = (~uVar2 & uVar4 | uVar7 & uVar2) + local_78[0] + -0x16493856 + uVar9;
  uVar9 = (uVar9 >> 0xc | uVar9 * 0x100000) + uVar7;
  uVar2 = (~uVar4 & uVar7 | uVar4 & uVar9) + local_64 + -0x29d0efa3 + uVar2;
  uVar2 = (uVar2 * 0x20 | uVar2 >> 0x1b) + uVar9;
  uVar4 = (~uVar7 & uVar9 | uVar7 & uVar2) + local_50 + 0x2441453 + uVar4;
  uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar2;
  uVar7 = (~uVar9 & uVar2 | uVar4 & uVar9) + local_3c + -0x275e197f + uVar7;
  uVar7 = (uVar7 * 0x4000 | uVar7 >> 0x12) + uVar4;
  uVar9 = (~uVar2 & uVar4 | uVar7 & uVar2) + local_68 + -0x182c0438 + uVar9;
  uVar9 = (uVar9 >> 0xc | uVar9 * 0x100000) + uVar7;
  uVar2 = (~uVar4 & uVar7 | uVar4 & uVar9) + local_54 + 0x21e1cde6 + uVar2;
  uVar2 = (uVar2 * 0x20 | uVar2 >> 0x1b) + uVar9;
  uVar4 = (~uVar7 & uVar9 | uVar7 & uVar2) + local_40 + -0x3cc8f82a + uVar4;
  uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar2;
  uVar7 = (~uVar9 & uVar2 | uVar4 & uVar9) + local_78[3] + -0xb2af279 + uVar7;
  uVar7 = (uVar7 * 0x4000 | uVar7 >> 0x12) + uVar4;
  uVar9 = (~uVar2 & uVar4 | uVar7 & uVar2) + local_58 + 0x455a14ed + uVar9;
  uVar9 = (uVar9 >> 0xc | uVar9 * 0x100000) + uVar7;
  uVar2 = (~uVar4 & uVar7 | uVar4 & uVar9) + local_44 + -0x561c16fb + uVar2;
  uVar2 = (uVar2 * 0x20 | uVar2 >> 0x1b) + uVar9;
  uVar4 = (~uVar7 & uVar9 | uVar7 & uVar2) + local_78[2] + -0x3105c08 + uVar4;
  uVar4 = (uVar4 * 0x200 | uVar4 >> 0x17) + uVar2;
  uVar7 = (~uVar9 & uVar2 | uVar4 & uVar9) + local_5c + 0x676f02d9 + uVar7;
  uVar7 = (uVar7 * 0x4000 | uVar7 >> 0x12) + uVar4;
  uVar9 = (~uVar2 & uVar4 | uVar7 & uVar2) + local_48 + -0x72d5b376 + uVar9;
  uVar9 = (uVar9 >> 0xc | uVar9 * 0x100000) + uVar7;
  uVar2 = (uVar4 ^ uVar7 ^ uVar9) + local_64 + -0x5c6be + uVar2;
  uVar2 = (uVar2 * 0x10 | uVar2 >> 0x1c) + uVar9;
  uVar4 = (uVar7 ^ uVar9 ^ uVar2) + local_58 + -0x788e097f + uVar4;
  uVar4 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar2;
  uVar7 = (uVar4 ^ uVar9 ^ uVar2) + local_4c + 0x6d9d6122 + uVar7;
  uVar7 = (uVar7 * 0x10000 | uVar7 >> 0x10) + uVar4;
  uVar9 = (uVar4 ^ uVar7 ^ uVar2) + local_40 + -0x21ac7f4 + uVar9;
  uVar9 = (uVar9 >> 9 | uVar9 * 0x800000) + uVar7;
  uVar2 = (uVar4 ^ uVar7 ^ uVar9) + local_78[1] + -0x5b4115bc + uVar2;
  uVar2 = (uVar2 * 0x10 | uVar2 >> 0x1c) + uVar9;
  uVar4 = (uVar7 ^ uVar9 ^ uVar2) + local_68 + 0x4bdecfa9 + uVar4;
  uVar4 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar2;
  uVar7 = (uVar4 ^ uVar9 ^ uVar2) + local_5c + -0x944b4a0 + uVar7;
  uVar7 = (uVar7 * 0x10000 | uVar7 >> 0x10) + uVar4;
  uVar9 = (uVar4 ^ uVar7 ^ uVar2) + local_50 + -0x41404390 + uVar9;
  uVar9 = (uVar9 >> 9 | uVar9 * 0x800000) + uVar7;
  uVar2 = (uVar4 ^ uVar7 ^ uVar9) + local_44 + 0x289b7ec6 + uVar2;
  uVar2 = (uVar2 * 0x10 | uVar2 >> 0x1c) + uVar9;
  uVar4 = (uVar7 ^ uVar9 ^ uVar2) + local_78[0] + -0x155ed806 + uVar4;
  uVar4 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar2;
  uVar7 = (uVar4 ^ uVar9 ^ uVar2) + local_78[3] + -0x2b10cf7b + uVar7;
  uVar7 = (uVar7 * 0x10000 | uVar7 >> 0x10) + uVar4;
  uVar9 = (uVar4 ^ uVar7 ^ uVar2) + local_60 + 0x4881d05 + uVar9;
  uVar9 = (uVar9 >> 9 | uVar9 * 0x800000) + uVar7;
  uVar2 = (uVar4 ^ uVar7 ^ uVar9) + local_54 + -0x262b2fc7 + uVar2;
  uVar2 = (uVar2 * 0x10 | uVar2 >> 0x1c) + uVar9;
  uVar4 = (uVar7 ^ uVar9 ^ uVar2) + local_48 + -0x1924661b + uVar4;
  uVar4 = (uVar4 * 0x800 | uVar4 >> 0x15) + uVar2;
  uVar7 = (uVar4 ^ uVar9 ^ uVar2) + local_3c + 0x1fa27cf8 + uVar7;
  uVar7 = (uVar7 * 0x10000 | uVar7 >> 0x10) + uVar4;
  uVar9 = (uVar4 ^ uVar7 ^ uVar2) + local_78[2] + -0x3b53a99b + uVar9;
  uVar9 = (uVar9 >> 9 | uVar9 * 0x800000) + uVar7;
  uVar2 = ((~uVar4 | uVar9) ^ uVar7) + local_78[0] + -0xbd6ddbc + uVar2;
  uVar2 = (uVar2 * 0x40 | uVar2 >> 0x1a) + uVar9;
  uVar4 = ((~uVar7 | uVar2) ^ uVar9) + local_5c + 0x432aff97 + uVar4;
  uVar4 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar2;
  uVar7 = ((~uVar9 | uVar4) ^ uVar2) + local_40 + -0x546bdc59 + uVar7;
  uVar7 = (uVar7 * 0x8000 | uVar7 >> 0x11) + uVar4;
  uVar9 = ((~uVar2 | uVar7) ^ uVar4) + local_64 + -0x36c5fc7 + uVar9;
  uVar9 = (uVar9 >> 0xb | uVar9 * 0x200000) + uVar7;
  uVar2 = ((~uVar4 | uVar9) ^ uVar7) + local_48 + 0x655b59c3 + uVar2;
  uVar2 = (uVar2 * 0x40 | uVar2 >> 0x1a) + uVar9;
  uVar4 = ((~uVar7 | uVar2) ^ uVar9) + local_78[3] + -0x70f3336e + uVar4;
  uVar4 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar2;
  uVar7 = ((~uVar9 | uVar4) ^ uVar2) + local_50 + -0x100b83 + uVar7;
  uVar7 = (uVar7 * 0x8000 | uVar7 >> 0x11) + uVar4;
  uVar9 = ((~uVar2 | uVar7) ^ uVar4) + local_78[1] + -0x7a7ba22f + uVar9;
  uVar9 = (uVar9 >> 0xb | uVar9 * 0x200000) + uVar7;
  uVar2 = ((~uVar4 | uVar9) ^ uVar7) + local_58 + 0x6fa87e4f + uVar2;
  uVar2 = (uVar2 * 0x40 | uVar2 >> 0x1a) + uVar9;
  uVar4 = ((~uVar7 | uVar2) ^ uVar9) + local_3c + -0x1d31920 + uVar4;
  uVar4 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar2;
  uVar7 = ((~uVar9 | uVar4) ^ uVar2) + local_60 + -0x5cfebcec + uVar7;
  uVar7 = (uVar7 * 0x8000 | uVar7 >> 0x11) + uVar4;
  uVar9 = ((~uVar2 | uVar7) ^ uVar4) + local_44 + 0x4e0811a1 + uVar9;
  uVar9 = (uVar9 >> 0xb | uVar9 * 0x200000) + uVar7;
  uVar2 = ((~uVar4 | uVar9) ^ uVar7) + local_68 + -0x8ac817e + uVar2;
  uVar5 = (uVar2 * 0x40 | uVar2 >> 0x1a) + uVar9;
  uVar4 = ((~uVar7 | uVar5) ^ uVar9) + local_4c + -0x42c50dcb + uVar4;
  uVar2 = (uVar4 * 0x400 | uVar4 >> 0x16) + uVar5;
  uVar7 = ((~uVar9 | uVar2) ^ uVar5) + local_78[2] + 0x2ad7d2bb + uVar7;
  uVar4 = (uVar7 * 0x8000 | uVar7 >> 0x11) + uVar2;
  *(uint *)(param_1 + 0x50) = iVar1 + uVar5;
  uVar9 = ((~uVar5 | uVar4) ^ uVar2) + local_54 + -0x14792c6f + uVar9;
  *(uint *)(param_1 + 0x54) = (uVar9 >> 0xb | uVar9 * 0x200000) + *(int *)(param_1 + 0x54) + uVar4;
  *(uint *)(param_1 + 0x58) = *(int *)(param_1 + 0x58) + uVar4;
  *(uint *)(param_1 + 0x5c) = *(int *)(param_1 + 0x5c) + uVar2;
  return;
}

// ==== CMD5ChecksumStandard@MD5::helper_14050a4a0  @14050a4a0  [medium:callgraph-r0]  (orig: FUN_14050a4a0)
void FUN_14050a4a0(longlong param_1,void *param_2,uint param_3)

{
  uint uVar1;
  uint uVar3;
  uint uVar4;
  ulonglong uVar2;
  
  uVar1 = *(uint *)(param_1 + 0x48);
  uVar3 = uVar1 + param_3 * 8;
  *(uint *)(param_1 + 0x48) = uVar3;
  uVar1 = uVar1 >> 3 & 0x3f;
  uVar2 = (ulonglong)uVar1;
  if (uVar3 < param_3 * 8) {
    *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + 1;
  }
  uVar1 = -uVar1;
  uVar3 = uVar1 + 0x40;
  *(int *)(param_1 + 0x4c) = *(int *)(param_1 + 0x4c) + (param_3 >> 0x1d);
  if (param_3 < uVar3) {
    uVar4 = 0;
  }
  else {
    memcpy((void *)(uVar2 + 8 + param_1),param_2,(ulonglong)uVar3);
    FUN_140509c00(param_1,param_1 + 8);
    while (uVar4 = uVar3, uVar1 + 0x7f < param_3) {
      FUN_140509c00(param_1,(ulonglong)uVar4 + (longlong)param_2);
      uVar3 = uVar4 + 0x40;
      uVar1 = uVar4;
    }
    uVar2 = 0;
  }
  memcpy((void *)(uVar2 + 8 + param_1),(void *)((ulonglong)uVar4 + (longlong)param_2),
         (ulonglong)(param_3 - uVar4));
  return;
}

// ==== CMD5ChecksumStandard@MD5::helper_14050a5d0  @14050a5d0  [medium:callgraph-r0]  (orig: FUN_14050a5d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_14050a5d0(longlong param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  byte bVar1;
  uint uVar2;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *pbVar3;
  byte *pbVar4;
  longlong lVar5;
  int iVar6;
  byte *pbVar7;
  longlong lVar8;
  undefined1 auStack_1b8 [32];
  undefined4 local_198;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_190;
  undefined8 local_188;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_180 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_158 [40];
  byte local_130 [24];
  char local_118 [256];
  ulonglong local_18;
  
  local_188 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_1b8;
  lVar5 = 0;
  local_198 = 0;
  pbVar4 = local_130 + 1;
  pbVar7 = (byte *)(param_1 + 0x4a);
  lVar8 = 2;
  do {
    pbVar4[-1] = pbVar7[-2];
    *pbVar4 = pbVar7[-1];
    pbVar4[1] = *pbVar7;
    pbVar4[2] = pbVar7[1];
    pbVar7 = pbVar7 + 4;
    pbVar4 = pbVar4 + 4;
    lVar8 = lVar8 + -1;
  } while (lVar8 != 0);
  uVar2 = *(uint *)(param_1 + 0x48) >> 3 & 0x3f;
  if (uVar2 < 0x38) {
    iVar6 = 0x38 - uVar2;
  }
  else {
    iVar6 = 0x78 - uVar2;
  }
  local_190 = param_2;
  FUN_14050a4a0(param_1,&DAT_1409703a0,iVar6);
  FUN_14050a4a0(param_1,local_130,8);
  pbVar4 = local_130 + 1;
  pbVar7 = (byte *)(param_1 + 0x52);
  lVar8 = 4;
  do {
    pbVar4[-1] = pbVar7[-2];
    *pbVar4 = pbVar7[-1];
    pbVar4[1] = *pbVar7;
    pbVar4[2] = pbVar7[1];
    pbVar7 = pbVar7 + 4;
    pbVar4 = pbVar4 + 4;
    lVar8 = lVar8 + -1;
  } while (lVar8 != 0);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2);
  local_198 = 1;
  do {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_158);
    bVar1 = local_130[lVar5];
    if (bVar1 == 0) {
      pbVar3 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
               basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_180,"00");
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                (local_158,pbVar3);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_180);
    }
    else if (bVar1 < 0x10) {
      sprintf(local_118,"0%x",(ulonglong)bVar1);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                (local_158,local_118);
    }
    else {
      sprintf(local_118,"%x",(ulonglong)bVar1);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                (local_158,local_118);
    }
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
              (param_2,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                        *)local_158);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_158);
    lVar5 = lVar5 + 1;
  } while (lVar5 < 0x10);
  return param_2;
}

// ==== CMD5ChecksumStandard@MD5::vfunc_1  @14050a7f0  [high:rtti-vtable]  (orig: FUN_14050a7f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14050a7f0(undefined8 param_1,char *param_2)

{
  char cVar1;
  char ****ppppcVar2;
  undefined1 auStack_c8 [32];
  undefined8 local_a8;
  undefined **local_98;
  undefined8 local_90;
  undefined8 local_88;
  undefined8 local_80;
  undefined8 local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined8 local_60;
  undefined8 local_58;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_38 [8];
  char ***local_30 [3];
  ulonglong local_18;
  ulonglong local_10;
  
  local_a8 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_c8;
  local_98 = MD5::CMD5Checksum::vftable;
  local_90 = 0;
  local_88 = 0;
  local_80 = 0;
  local_78 = 0;
  local_70 = 0;
  local_68 = 0;
  local_60 = 0;
  local_58 = 0;
  local_4c = 0;
  local_50 = 0;
  local_48 = 0x67452301;
  local_44 = 0xefcdab89;
  local_40 = 0x98badcfe;
  local_3c = 0x10325476;
  FUN_14050a4a0(&local_98);
  FUN_14050a5d0(&local_98,local_38);
  ppppcVar2 = local_30;
  if (0xf < local_18) {
    ppppcVar2 = (char ****)local_30[0];
  }
  do {
    cVar1 = *(char *)ppppcVar2;
    *param_2 = cVar1;
    param_2 = param_2 + 1;
    ppppcVar2 = (char ****)((longlong)ppppcVar2 + 1);
  } while (cVar1 != '\0');
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_38);
  return 0;
}

