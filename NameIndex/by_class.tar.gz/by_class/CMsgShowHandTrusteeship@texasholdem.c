// ==== CMsgShowHandTrusteeship@texasholdem::helper_1403d7360  @1403d7360  [medium:callgraph-r0]  (orig: FUN_1403d7360)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403d7360(longlong param_1,longlong *param_2,byte param_3,char param_4)

{
  longlong lVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong lVar6;
  undefined1 auStack_4c8 [32];
  byte local_4a8 [8];
  longlong *local_4a0;
  longlong local_498;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if ((param_2 == (longlong *)0x0) || (*(int *)(param_1 + 0x210) == 0)) {
    uVar5 = 0;
  }
  else if (param_3 < 9) {
    local_4a8[0] = param_3;
    FUN_1403ccc50(param_1 + 0x108,&local_4a0,local_4a8);
    lVar1 = *(longlong *)(param_1 + 0x138);
    lVar6 = 0;
    local_490 = *(longlong **)(param_1 + 0x108);
    if ((local_4a0 == (longlong *)0x0) || (local_4a0 != local_490)) {
      _invalid_parameter_noinfo();
    }
    if (local_498 == lVar1) {
      uVar5 = 0;
    }
    else {
      if (local_4a0 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar6 = *local_4a0;
      }
      if (local_498 == *(longlong *)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar3 = (**(code **)(*param_2 + 8))(param_2);
      if (iVar3 == *(int *)(local_498 + 0x20)) {
        if (*(char *)(local_498 + 0x78) == param_4) {
          uVar5 = 0;
        }
        else {
          *(char *)(local_498 + 0x78) = param_4;
          FUN_140453510(local_478);
          uVar4 = (**(code **)(*param_2 + 8))(param_2);
          cVar2 = FUN_140453590(local_478,uVar4,param_4);
          if (cVar2 == '\0') {
            FUN_140453560(local_478);
            uVar5 = 0;
          }
          else {
            FUN_1403d63a0(param_1,local_478,uVar4);
            FUN_140453560(local_478);
            uVar5 = 1;
          }
        }
      }
      else {
        uVar5 = 0;
      }
    }
  }
  else {
    uVar5 = 0;
  }
  return uVar5;
}

// ==== CMsgShowHandTrusteeship@texasholdem::helper_140453510  @140453510  [medium:callgraph-r1]  (orig: FUN_140453510)
undefined8 * FUN_140453510(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgShowHandTrusteeship::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgShowHandTrusteeship@texasholdem::helper_140453560  @140453560  [medium:callgraph-r1]  (orig: FUN_140453560)
void FUN_140453560(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandTrusteeship::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgShowHandTrusteeship@texasholdem::helper_140453590  @140453590  [medium:callgraph-r1]  (orig: FUN_140453590)
undefined8 FUN_140453590(longlong param_1,undefined4 param_2,undefined1 param_3)

{
  undefined1 *puVar1;
  
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *puVar1 = param_3;
  *(undefined4 *)(param_1 + 8) = 0x833;
  *(undefined4 *)(param_1 + 0xc) = 8;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgShowHandTrusteeship@texasholdem::vfunc_1  @1404535c0  [high:rtti-vtable]  (orig: FUN_1404535c0)
ulonglong FUN_1404535c0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x833);
}

// ==== CMsgShowHandTrusteeship@texasholdem::vfunc_0  @1404535f0  [high:rtti-vtable]  (orig: FUN_1404535f0)
undefined8 * FUN_1404535f0(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandTrusteeship::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandTrusteeship@texasholdem::vfunc_3  @140453640  [high:rtti-vtable]  (orig: FUN_140453640)
void FUN_140453640(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))(*(longlong **)(lVar2 + 0x90),param_1);
  if ((lVar2 != 0) && (*(int *)(lVar2 + 0x1240) != 0)) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar3 = *(longlong *)(lVar3 + 0x108);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    cVar1 = FUN_140215360(lVar3,lVar2,*(undefined4 *)(lVar2 + 0x1240));
    if (cVar1 != '\0') {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar4 = FUN_140087830(uVar4);
      lVar3 = FUN_140214ce0(uVar4,*(undefined4 *)(lVar2 + 0x1240));
      if (lVar3 != 0) {
        FUN_1403d7360(lVar3,lVar2,*(undefined1 *)(lVar2 + 0x1244),**(undefined1 **)(param_1 + 0x428)
                     );
      }
    }
  }
  return;
}

