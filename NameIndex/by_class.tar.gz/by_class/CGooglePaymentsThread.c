// ==== CGooglePaymentsThread::vfunc_4  @140013010  [high:rtti-vtable]  (orig: FUN_140013010)
bool FUN_140013010(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  
  bVar1 = CThreadBase::CreateThread(param_1,"GooglePaymentsThread",param_2);
  return bVar1;
}

// ==== CGooglePaymentsThread::helper_140013040  @140013040  [medium:callgraph-r2]  (orig: FUN_140013040)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140013040(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  char *param_5)

{
  char cVar1;
  undefined1 auStack_78 [32];
  undefined4 *local_58;
  char *local_50;
  undefined8 local_48;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  char local_34 [36];
  ulonglong local_10;
  
  local_48 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  local_40 = param_2;
  local_3c = param_3;
  local_38 = param_4;
  strncpy(local_34,param_5,0x20);
  local_58 = &local_40;
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                    (*(longlong **)(param_1 + 0x40),0xe,0x186a5,0x2c);
  if (cVar1 == '\0') {
    local_50 = local_34;
    local_58 = (undefined4 *)CONCAT44(local_58._4_4_,local_38);
    tq::MyLogSave("gmlog/GooglePayments",
                  "send web server payments result to msgport failure, iduser:%u, idacount:%u, action:%u, szTransactionId:%s"
                 );
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140013100  @140013100  [medium:callgraph-r3]  (orig: FUN_140013100)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140013100(undefined8 param_1,char *param_2)

{
  char cVar1;
  undefined8 uVar2;
  char *pcVar3;
  ulonglong uVar4;
  longlong lVar5;
  longlong lVar6;
  char *pcVar7;
  undefined1 auStack_e8 [32];
  undefined4 local_c8;
  char local_b8 [16];
  undefined1 local_a8 [96];
  char local_48 [40];
  undefined1 local_20 [16];
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  if (param_2 == (char *)0x0) {
    local_c8 = 0x2c6;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_48[0] = '\0';
    local_48[1] = '\0';
    local_48[2] = '\0';
    local_48[3] = '\0';
    local_48[4] = '\0';
    local_48[5] = '\0';
    local_48[6] = '\0';
    local_48[7] = '\0';
    local_48[8] = '\0';
    local_48[9] = '\0';
    local_48[10] = '\0';
    local_48[0xb] = '\0';
    local_48[0xc] = '\0';
    local_48[0xd] = '\0';
    local_48[0xe] = '\0';
    local_48[0xf] = '\0';
    local_48[0x10] = '\0';
    local_48[0x11] = '\0';
    local_48[0x12] = '\0';
    local_48[0x13] = '\0';
    local_48[0x14] = '\0';
    local_48[0x15] = '\0';
    local_48[0x16] = '\0';
    local_48[0x17] = '\0';
    local_48[0x18] = '\0';
    local_48[0x19] = '\0';
    local_48[0x1a] = '\0';
    local_48[0x1b] = '\0';
    local_48[0x1c] = '\0';
    local_48[0x1d] = '\0';
    local_48[0x1e] = '\0';
    local_48[0x1f] = '\0';
    local_48[0x20] = '\0';
    local_b8[0] = '\0';
    local_b8[1] = '\0';
    local_b8[2] = '\0';
    MD5_Init();
    uVar4 = 0xffffffffffffffff;
    pcVar3 = param_2;
    do {
      if (uVar4 == 0) break;
      uVar4 = uVar4 - 1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    MD5_Update(local_a8,param_2,~uVar4 - 1);
    MD5_Final(local_20,local_a8);
    lVar6 = 0;
    do {
      sprintf(local_b8,"%02X");
      lVar5 = -1;
      pcVar3 = local_48;
      do {
        pcVar7 = pcVar3;
        if (lVar5 == 0) break;
        lVar5 = lVar5 + -1;
        pcVar7 = pcVar3 + 1;
        cVar1 = *pcVar3;
        pcVar3 = pcVar7;
      } while (cVar1 != '\0');
      lVar5 = 0;
      do {
        cVar1 = local_b8[lVar5];
        pcVar7[lVar5 + -1] = cVar1;
        lVar5 = lVar5 + 1;
      } while (cVar1 != '\0');
      lVar6 = lVar6 + 1;
    } while (lVar6 < 0x10);
    pcVar3 = _strlwr(local_48);
    *(undefined8 *)param_2 = *(undefined8 *)pcVar3;
    *(undefined8 *)(param_2 + 8) = *(undefined8 *)(pcVar3 + 8);
    *(undefined8 *)(param_2 + 0x10) = *(undefined8 *)(pcVar3 + 0x10);
    uVar2 = *(undefined8 *)(pcVar3 + 0x18);
    param_2[0x20] = '\0';
    *(undefined8 *)(param_2 + 0x18) = uVar2;
  }
  return;
}

// ==== CGooglePaymentsThread::helper_1400132b0  @1400132b0  [medium:callgraph-r3]  (orig: FUN_1400132b0)
/* WARNING: Removing unreachable block (ram,0x000140013482) */

basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_1400132b0(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2,
             longlong param_3)

{
  ulonglong uVar1;
  byte bVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  uVar6 = 0;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2,"");
  uVar1 = *(ulonglong *)(param_3 + 0x18);
  if (uVar1 != 0) {
    do {
      if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
        _invalid_parameter_noinfo();
      }
      if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
        lVar5 = param_3 + 8;
      }
      else {
        lVar5 = *(longlong *)(param_3 + 8);
      }
      iVar4 = isalnum((uint)*(byte *)(lVar5 + uVar6));
      if (iVar4 == 0) {
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        if (*(char *)(lVar5 + uVar6) == '-') goto LAB_14001349e;
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        if (*(char *)(lVar5 + uVar6) == '_') goto LAB_14001349e;
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        if (*(char *)(lVar5 + uVar6) == '.') goto LAB_14001349e;
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        if (*(char *)(lVar5 + uVar6) == '~') goto LAB_14001349e;
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        if (*(char *)(lVar5 + uVar6) == ' ') {
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
                    (param_2,"+");
        }
        else {
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
                    (param_2,'%');
          if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
            _invalid_parameter_noinfo();
          }
          if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
            lVar5 = param_3 + 8;
          }
          else {
            lVar5 = *(longlong *)(param_3 + 8);
          }
          bVar2 = *(byte *)(lVar5 + uVar6) >> 4;
          if (bVar2 < 10) {
            cVar3 = bVar2 + 0x30;
          }
          else {
            cVar3 = bVar2 + 0x37;
          }
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
                    (param_2,cVar3);
          if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
            _invalid_parameter_noinfo();
          }
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
                    (param_2,'0');
        }
      }
      else {
LAB_14001349e:
        if (*(ulonglong *)(param_3 + 0x18) < uVar6) {
          _invalid_parameter_noinfo();
        }
        if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
          lVar5 = param_3 + 8;
        }
        else {
          lVar5 = *(longlong *)(param_3 + 8);
        }
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator+=
                  (param_2,*(char *)(lVar5 + uVar6));
      }
      uVar6 = uVar6 + 1;
    } while (uVar6 < uVar1);
  }
  return param_2;
}

// ==== CGooglePaymentsThread::helper_1400134f0  @1400134f0  [medium:callgraph-r2]  (orig: FUN_1400134f0)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_1400134f0(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2,
             longlong param_3)

{
  undefined1 auVar1 [16];
  int iVar2;
  __uint64 _Var3;
  LPCWSTR lpWideCharStr;
  char *lpMultiByteStr;
  LPCSTR lpMultiByteStr_00;
  LPCSTR lpMultiByteStr_01;
  
  if (*(ulonglong *)(param_3 + 0x20) < 0x10) {
    lpMultiByteStr_01 = (LPCSTR)(param_3 + 8);
  }
  else {
    lpMultiByteStr_01 = *(LPCSTR *)(param_3 + 8);
  }
  lpMultiByteStr_00 = (LPCSTR)(param_3 + 8);
  iVar2 = MultiByteToWideChar(0xfde9,0,lpMultiByteStr_01,-1,(LPWSTR)0x0,0);
  auVar1._8_8_ = 0;
  auVar1._0_8_ = (longlong)(iVar2 + 1);
  _Var3 = SUB168(ZEXT816(2) * auVar1,0);
  if (SUB168(ZEXT816(2) * auVar1,8) != 0) {
    _Var3 = 0xffffffffffffffff;
  }
  lpWideCharStr = operator_new__(_Var3);
  memset(lpWideCharStr,0,(longlong)(iVar2 * 2 + 2));
  if (0xf < *(ulonglong *)(param_3 + 0x20)) {
    lpMultiByteStr_00 = *(LPCSTR *)lpMultiByteStr_00;
  }
  MultiByteToWideChar(0xfde9,0,lpMultiByteStr_00,-1,lpWideCharStr,iVar2);
  iVar2 = WideCharToMultiByte(0,0,lpWideCharStr,-1,(LPSTR)0x0,0,(LPCSTR)0x0,(LPBOOL)0x0);
  lpMultiByteStr = operator_new__((longlong)(iVar2 + 1));
  memset(lpMultiByteStr,0,(longlong)(iVar2 + 1));
  WideCharToMultiByte(0,0,lpWideCharStr,-1,lpMultiByteStr,iVar2,(LPCSTR)0x0,(LPBOOL)0x0);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2,lpMultiByteStr);
  operator_delete__(lpMultiByteStr);
  operator_delete__(lpWideCharStr);
  return param_2;
}

// ==== CGooglePaymentsThread::helper_140014390  @140014390  [medium:callgraph-r2]  (orig: FUN_140014390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140014390(longlong param_1,undefined4 *param_2,char *param_3,int param_4,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_5)

{
  ulong uVar1;
  undefined8 uVar2;
  __uint64 _Var3;
  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *pbVar4;
  __uint64 _Var5;
  char ***_Str;
  undefined1 auStack_578 [32];
  ulong local_558;
  longlong local_550;
  ulong local_548;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_540;
  char *local_538;
  undefined8 **local_530;
  longlong local_528;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_518 [40];
  undefined8 local_4f0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_4e8 [8];
  undefined8 **local_4e0 [2];
  longlong local_4d0;
  ulonglong local_4c8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_4c0 [24];
  longlong local_4a8;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_498 [24];
  longlong local_480;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_470 [8];
  char **local_468 [3];
  ulonglong local_450;
  char local_448;
  undefined1 local_447 [1023];
  ulonglong local_48;
  
  local_4f0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  if (((param_2 == (undefined4 *)0x0) || (param_3 == (char *)0x0)) || (param_4 < 1)) {
    tq::MyLogSave("gmlog/GooglePayments","CGooglePaymentsThread::AssembleHttpMessage. Point is NULL"
                 );
    uVar2 = 0;
  }
  else {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_4c0,(char *)(param_2 + 0xc));
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
    if (local_4a8 == 0) {
      tq::MyLogSave("gmlog/GooglePayments",
                    "CGooglePaymentsThread::AssembleHttpMessage. PaymentsInfo is empty");
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
      uVar2 = 0;
    }
    else {
      _Var3 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::find
                        (local_4c0,"}Signature:",0,0xb);
      if (_Var3 == 0xffffffffffffffff) {
        tq::MyLogSave("gmlog/GooglePayments",
                      "CGooglePaymentsThread::AssembleHttpMessage. PlainText Mark is not Found");
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
        uVar2 = 0;
      }
      else {
        pbVar4 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::substr
                           (local_4c0,(__uint64)local_518,0);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                  (local_4e8,pbVar4);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_518);
        pbVar4 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
                 std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::substr
                           (local_4c0,(__uint64)local_518,_Var3 + 0xb);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                  (local_498,pbVar4);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_518);
        if ((local_4d0 == 0) || (local_480 == 0)) {
          tq::MyLogSave("gmlog/GooglePayments",
                        "CGooglePaymentsThread::AssembleHttpMessage. PlainText Or EncyptText is Empty"
                       );
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
          uVar2 = 0;
        }
        else {
          _Var3 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::find
                            (local_4e8,"\"productId\":\"",0,0xd);
          if (_Var3 == 0xffffffffffffffff) {
            tq::MyLogSave("gmlog/GooglePayments",
                          "CGooglePaymentsThread::AssembleHttpMessage. productId Start is not Found"
                         );
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
            uVar2 = 0;
          }
          else {
            _Var5 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::find
                              (local_4e8,"\"",_Var3 + 0xe,1);
            if (_Var5 == 0xffffffffffffffff) {
              tq::MyLogSave("gmlog/GooglePayments",
                            "CGooglePaymentsThread::AssembleHttpMessage. productId End is not Found"
                           );
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
              uVar2 = 0;
            }
            else {
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::substr
                        (local_4e8,(__uint64)local_470,_Var3 + 0xd);
              _Str = local_468;
              if (0xf < local_450) {
                _Str = (char ***)local_468[0];
              }
              uVar1 = strtoul((char *)_Str,(char **)0x0,10);
              _Var3 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::find
                                (local_4e8,"\"orderId\":\"",0,0xb);
              if (_Var3 == 0xffffffffffffffff) {
                tq::MyLogSave("gmlog/GooglePayments",
                              "CGooglePaymentsThread::AssembleHttpMessage. orderId Start is not Found"
                             );
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
                std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
                uVar2 = 0;
              }
              else {
                _Var5 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::find
                                  (local_4e8,"\"",_Var3 + 0xc,1);
                if (_Var5 == 0xffffffffffffffff) {
                  tq::MyLogSave("gmlog/GooglePayments",
                                "CGooglePaymentsThread::AssembleHttpMessage. orderId End is not Found"
                               );
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
                  uVar2 = 0;
                }
                else {
                  pbVar4 = (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                            *)std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                              substr(local_4e8,(__uint64)local_518,_Var3 + 0xb);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                            (param_5,pbVar4);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_518);
                  local_448 = '\0';
                  memset(local_447,0,0x3ff);
                  local_550 = param_1 + 0x44a;
                  local_558 = uVar1;
                  _snprintf(&local_448,0x3ff,"%u_0_1_%u_%s",(ulonglong)(uint)param_2[1]);
                  FUN_140013100(param_1,&local_448);
                  local_528 = FUN_1400132b0(param_1,local_518,local_498);
                  if (*(ulonglong *)(local_528 + 0x20) < 0x10) {
                    local_528 = local_528 + 8;
                  }
                  else {
                    local_528 = *(longlong *)(local_528 + 8);
                  }
                  local_530 = local_4e0;
                  if (0xf < local_4c8) {
                    local_530 = local_4e0[0];
                  }
                  if (*(ulonglong *)(param_5 + 0x20) < 0x10) {
                    local_540 = param_5 + 8;
                  }
                  else {
                    local_540 = *(basic_string<char,std::char_traits<char>,std::allocator<char>_> **
                                 )(param_5 + 8);
                  }
                  local_538 = &local_448;
                  local_550 = CONCAT44(local_550._4_4_,*param_2);
                  local_558 = param_2[2];
                  local_548 = uVar1;
                  _snprintf(param_3,(longlong)(param_4 + -1),
                            "action=charge&buyerId=%u&CallbackInfo=%u|%u|2|100098|0&ProductId=%u&Productname=CQServer_Google_Pay&CooOrderSerial=%s&ProductCount=1&ProductPrice=0&Sign=%s&appStoreSign=%s&signature=%s"
                            ,(ulonglong)(uint)param_2[1]);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_518);
                  param_3[(longlong)param_4 + -1] = '\0';
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_498);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4e8);
                  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
                  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_4c0);
                  uVar2 = 1;
                }
              }
            }
          }
        }
      }
    }
  }
  return uVar2;
}

// ==== CGooglePaymentsThread::helper_140015d70  @140015d70  [medium:callgraph-r3]  (orig: FUN_140015d70)
undefined8 *
FUN_140015d70(undefined8 *param_1,undefined8 *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  bool bVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  
  puVar7 = (undefined8 *)param_1[6];
  cVar1 = *(char *)((longlong)puVar7[1] + 0x41);
  puVar3 = puVar7;
  puVar5 = (undefined8 *)puVar7[1];
  while (cVar1 == '\0') {
    bVar4 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar5 + 3),param_3);
    if (bVar4) {
      puVar6 = (undefined8 *)puVar5[2];
      puVar5 = puVar3;
    }
    else {
      if ((*(char *)((longlong)puVar7 + 0x41) != '\0') &&
         (bVar4 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                            (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_>
                                      *)(puVar5 + 3)), bVar4)) {
        puVar7 = puVar5;
      }
      puVar6 = (undefined8 *)*puVar5;
    }
    puVar3 = puVar5;
    puVar5 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x41);
  }
  if (*(char *)((longlong)puVar7 + 0x41) == '\0') {
    puVar5 = (undefined8 *)*puVar7;
  }
  else {
    puVar5 = *(undefined8 **)(param_1[6] + 8);
  }
  cVar1 = *(char *)((longlong)puVar5 + 0x41);
  while (cVar1 == '\0') {
    bVar4 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                               (puVar5 + 3));
    if (bVar4) {
      puVar6 = (undefined8 *)*puVar5;
      puVar7 = puVar5;
    }
    else {
      puVar6 = (undefined8 *)puVar5[2];
    }
    puVar5 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x41);
  }
  uVar2 = *param_1;
  *param_2 = uVar2;
  param_2[1] = puVar3;
  param_2[2] = uVar2;
  param_2[3] = puVar7;
  return param_2;
}

// ==== CGooglePaymentsThread::helper_140016c20  @140016c20  [medium:callgraph-r0]  (orig: FUN_140016c20)
void FUN_140016c20(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x41);
  while (cVar1 == '\0') {
    FUN_140016c20(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x41);
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140016c90  @140016c90  [medium:callgraph-r3]  (orig: FUN_140016c90)
undefined8 *
FUN_140016c90(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x666666666666664 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140015420(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x40);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x40) == '\0') {
        *(undefined1 *)(plVar2 + 8) = 1;
        *(undefined1 *)(lVar4 + 0x40) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x40) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x41) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x40) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x40) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x41) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x40) == '\0') {
        *(undefined1 *)(plVar2 + 8) = 1;
        *(undefined1 *)(lVar4 + 0x40) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x40) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x41) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x40) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x40) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x41) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x40);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x40) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CGooglePaymentsThread::helper_140017580  @140017580  [medium:callgraph-r2]  (orig: FUN_140017580)
longlong * FUN_140017580(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_140016690(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x21) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x21);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x21);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x21);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x21);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400162d0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CGooglePaymentsThread::vfunc_1  @140017840  [high:rtti-vtable]  (orig: FUN_140017840)
void FUN_140017840(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  plVar4 = *(longlong **)(param_1 + 0x868);
  if (*(longlong **)(param_1 + 0x870) < plVar4) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0x850);
  while( true ) {
    plVar2 = *(longlong **)(param_1 + 0x870);
    if (plVar2 < *(longlong **)(param_1 + 0x868)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x850))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    puVar3 = (undefined8 *)*plVar4;
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar1;
    }
    if (*(longlong **)(lVar5 + 0x20) <= plVar4) {
      _invalid_parameter_noinfo();
    }
    plVar4 = plVar4 + 1;
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140017ab0  @140017ab0  [medium:callgraph-r2]  (orig: FUN_140017ab0)
longlong *
FUN_140017ab0(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  bool bVar5;
  bool bVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong local_38;
  undefined8 *local_30;
  
  puVar9 = (undefined8 *)((undefined8 *)param_1[6])[1];
  bVar5 = true;
  cVar1 = *(char *)((longlong)puVar9 + 0x41);
  puVar3 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar5 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                               (puVar9 + 3));
    if (bVar5) {
      puVar8 = (undefined8 *)*puVar9;
    }
    else {
      puVar8 = (undefined8 *)puVar9[2];
    }
    puVar3 = puVar9;
    puVar9 = puVar8;
    cVar1 = *(char *)((longlong)puVar8 + 0x41);
  }
  lVar2 = *param_1;
  puVar9 = puVar3;
  local_38 = lVar2;
  puVar8 = puVar3;
  if (bVar5 == false) {
LAB_140017bfd:
    local_30 = puVar8;
    bVar6 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar9 + 3),param_3);
    if (!bVar6) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_140017c35;
    }
  }
  else {
    puVar9 = *(undefined8 **)param_1[6];
    local_30 = puVar3;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 != puVar9) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar3 + 0x41) == '\0') {
        puVar9 = (undefined8 *)*puVar3;
        if (*(char *)((longlong)puVar9 + 0x41) == '\0') {
          cVar1 = *(char *)((longlong)puVar9[2] + 0x41);
          puVar4 = (undefined8 *)puVar9[2];
          while (puVar8 = puVar9, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar4[2] + 0x41);
            puVar9 = puVar4;
            puVar4 = (undefined8 *)puVar4[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar3[1] + 0x41);
          puVar8 = (undefined8 *)puVar3[1];
          puVar4 = puVar3;
          while ((puVar9 = puVar8, cVar1 == '\0' && (puVar4 == (undefined8 *)*puVar9))) {
            cVar1 = *(char *)((longlong)puVar9[1] + 0x41);
            puVar8 = (undefined8 *)puVar9[1];
            puVar4 = puVar9;
            local_30 = puVar9;
          }
          puVar8 = puVar9;
          if (*(char *)((longlong)puVar4 + 0x41) != '\0') {
            _invalid_parameter_noinfo();
            puVar9 = puVar4;
            puVar8 = local_30;
          }
        }
      }
      else {
        puVar9 = (undefined8 *)puVar3[2];
        puVar8 = puVar9;
        if (*(char *)((longlong)puVar9 + 0x41) != '\0') {
          local_30 = puVar9;
          _invalid_parameter_noinfo();
          puVar8 = local_30;
        }
      }
      goto LAB_140017bfd;
    }
    bVar5 = true;
  }
  plVar7 = (longlong *)FUN_140016c90(param_1,&local_38,bVar5,puVar3,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar7[1];
  *param_2 = *plVar7;
LAB_140017c35:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CGooglePaymentsThread::helper_140017ca0  @140017ca0  [medium:callgraph-r2]  (orig: FUN_140017ca0)
longlong * FUN_140017ca0(longlong *param_1,longlong *param_2,int *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(int *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CGooglePaymentsThread::helper_140017fc0  @140017fc0  [medium:callgraph-r0]  (orig: FUN_140017fc0)
void FUN_140017fc0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140017de0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CGooglePaymentsThread::helper_140018740  @140018740  [medium:callgraph-r2]  (orig: FUN_140018740)
longlong FUN_140018740(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140015d70(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x41) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x41) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x41);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x41);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x41);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x41);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140017de0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CGooglePaymentsThread::ctor_or_dtor  @140018c10  [high:vtable-assign]  (orig: FUN_140018c10)
void FUN_140018c10(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CGooglePaymentsThread::vftable;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))();
  FUN_140017fc0(param_1 + 0x898);
  operator_delete(*(void **)(param_1 + 0x898));
  if (*(void **)(param_1 + 0x868) != (void *)0x0) {
    operator_delete(*(void **)(param_1 + 0x868));
  }
  *(undefined8 *)(param_1 + 0x868) = 0;
  *(undefined8 *)(param_1 + 0x870) = 0;
  *(undefined8 *)(param_1 + 0x878) = 0;
  operator_delete(*(void **)(param_1 + 0x850));
                    /* WARNING: Could not recover jumptable at 0x000140018c9c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CGooglePaymentsThread::helper_140018cb0  @140018cb0  [medium:callgraph-r2]  (orig: FUN_140018cb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140018cb0(longlong param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  char *pcVar9;
  undefined1 auStack_4e8 [32];
  undefined4 *local_4c8;
  char *local_4c0;
  char *local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  int local_4a4;
  uint local_4a0;
  undefined4 local_498;
  uint local_494;
  undefined1 local_490;
  longlong local_488;
  undefined8 local_480;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_478 [48];
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if ((param_2 != 0) && (param_3 != 0)) {
    local_448 = '\0';
    local_488 = param_1;
    memset(local_447,0,0x3ff);
    local_4c8 = (undefined4 *)CONCAT44(local_4c8._4_4_,param_3);
    _snprintf(&local_448,0x400,"SELECT * FROM %s WHERE account_id=%u AND used=0",
              "emoney_card_google");
    local_49 = 0;
    plVar6 = (longlong *)InstanceGet();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_448,2);
    if (plVar6 != (longlong *)0x0) {
      lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
      if (lVar7 == 0) {
        (**(code **)*plVar6)(plVar6);
      }
      else {
        local_4a4 = 0;
        while( true ) {
          iVar1 = local_4a4;
          iVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
          if (iVar2 <= iVar1) break;
          (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar1);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"ref_id");
          uVar3 = (**(code **)(*plVar8 + 0x40))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"chk_sum");
          local_4a0 = (**(code **)(*plVar8 + 0x50))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&DAT_1406de6d4);
          uVar4 = (**(code **)(*plVar8 + 0x50))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"itemcount");
          iVar2 = (**(code **)(*plVar8 + 0x48))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"account_id");
          uVar5 = (**(code **)(*plVar8 + 0x40))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"roleid");
          local_4a8 = (**(code **)(*plVar8 + 0x40))(plVar8);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"ordernumber");
          pcVar9 = (char *)(**(code **)(*plVar8 + 0x78))(plVar8);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_478,pcVar9);
          FUN_140018740(local_488 + 0x898,local_478);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_478);
          if ((uVar5 ^ uVar4) + uVar3 >> 1 == local_4a0) {
            if ((uVar4 != 0) && (0 < iVar2)) {
              local_498 = local_4a8;
              local_490 = 0;
              local_4c8 = &local_498;
              local_494 = uVar5;
              (**(code **)(**(longlong **)(local_488 + 0x40) + 0x50))
                        (*(longlong **)(local_488 + 0x40),0xe,0x186a6,0xc);
              break;
            }
            local_4b8 = (char *)CONCAT44(local_4b8._4_4_,0x1ee);
            local_4c0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
            local_4c8 = (undefined4 *)CONCAT44(local_4c8._4_4_,iVar2);
            log_InlineLogERROR("CGooglePaymentsThread::ProcessPayResultData. ProcessGooglePayQueryMessage failed. AccountID=%u, RefID=%u, Type=%u, ItemCount=%d at %s, %d"
                               ,(ulonglong)uVar5,(ulonglong)uVar3,(ulonglong)uVar4);
          }
          else {
            local_4b0 = 0x1e8;
            local_4b8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
            local_4c0 = (char *)CONCAT44(local_4c0._4_4_,local_4a0);
            local_4c8 = (undefined4 *)CONCAT44(local_4c8._4_4_,uVar4);
            log_InlineLogERROR("CGooglePaymentsThread::ProcessPayResultData. Check %s chksum failed. AccountID=%u, RefID=%u, Type=%u, Chksum=%u at %s, %d"
                               ,"emoney_card_google",(ulonglong)uVar5,(ulonglong)uVar3);
          }
          local_4a4 = iVar1 + 1;
        }
        (**(code **)*plVar6)(plVar6);
      }
    }
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140018fb0  @140018fb0  [medium:callgraph-r2]  (orig: FUN_140018fb0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140018fb0(longlong param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  char *pcVar8;
  ulonglong uVar9;
  undefined1 auStack_508 [32];
  uint *local_4e8;
  char *local_4e0;
  char *local_4d8;
  undefined4 local_4d0;
  undefined4 local_4c8;
  undefined4 local_4b8;
  uint local_4b4;
  undefined4 local_4b0;
  int local_4ac;
  uint local_4a8;
  int local_4a4;
  longlong local_4a0;
  uint local_498;
  int local_494;
  uint local_490;
  undefined4 local_48c;
  undefined4 local_488;
  uint local_484;
  int local_480;
  undefined8 local_478;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_470 [40];
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  uVar9 = (ulonglong)param_3;
  if ((param_2 != 0) && (param_3 != 0)) {
    local_448 = '\0';
    local_4a4 = param_2;
    local_4a0 = param_1;
    memset(local_447,0,0x3ff);
    local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,param_3);
    _snprintf(&local_448,0x400,"SELECT * FROM %s WHERE account_id=%u AND used=0",
              "emoney_card_google");
    local_49 = 0;
    plVar5 = (longlong *)InstanceGet();
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&local_448,2);
    if (plVar5 != (longlong *)0x0) {
      lVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
      if (lVar6 == 0) {
        (**(code **)*plVar5)(plVar5);
      }
      else {
        local_4ac = 0;
        while( true ) {
          iVar1 = local_4ac;
          iVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
          if (iVar2 <= iVar1) break;
          (**(code **)(*plVar5 + 0x30))(plVar5,(longlong)iVar1);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&DAT_1406de8d4);
          local_4b4 = (**(code **)(*plVar7 + 0x40))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"ref_id");
          uVar3 = (**(code **)(*plVar7 + 0x40))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"chk_sum");
          local_4a8 = (**(code **)(*plVar7 + 0x50))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&DAT_1406de6d4);
          uVar4 = (**(code **)(*plVar7 + 0x50))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"itemcount");
          iVar2 = (**(code **)(*plVar7 + 0x48))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,&DAT_1406de8cc);
          local_4b8 = (**(code **)(*plVar7 + 0x48))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"systemtype");
          local_4b0 = (**(code **)(*plVar7 + 0x48))(plVar7);
          plVar7 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,"ordernumber");
          pcVar8 = (char *)(**(code **)(*plVar7 + 0x78))(plVar7);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470,pcVar8);
          FUN_140018740(local_4a0 + 0x898,local_470);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_470);
          if ((param_3 ^ uVar4) + uVar3 >> 1 == local_4a8) {
            if ((uVar4 == 0) || (iVar2 < 1)) {
              local_4d8 = (char *)CONCAT44(local_4d8._4_4_,0x237);
              local_4e0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
              local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,iVar2);
              log_InlineLogERROR("ProcessGooglePayQueryMessage failed. AccountID=%u, RefID=%u, Type=%u, ItemCount=%d at %s, %d"
                                 ,uVar9,(ulonglong)uVar3,(ulonglong)uVar4);
            }
            else {
              local_4c8 = local_4b0;
              local_4d0 = local_4b8;
              local_4d8 = (char *)CONCAT44(local_4d8._4_4_,iVar2);
              local_4e0 = (char *)CONCAT44(local_4e0._4_4_,uVar4);
              local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,uVar3);
              tq::MyLogSave("gmlog/GooglePayments",
                            "checkout emoney_card_google idEmoneyCard:%u, idAccount:%u, idRef:%u, nType:%d, nItemCount:%d, flag:%d, systemType:%d"
                            ,(ulonglong)local_4b4,uVar9);
              local_498 = local_4b4;
              local_494 = local_4a4;
              local_48c = local_4b8;
              local_488 = local_4b0;
              local_4e8 = &local_498;
              local_490 = uVar3;
              local_484 = uVar4;
              local_480 = iVar2;
              (**(code **)(**(longlong **)(local_4a0 + 0x40) + 0x50))
                        (*(longlong **)(local_4a0 + 0x40),0xe,0x186a7,0x1c);
            }
          }
          else {
            local_4d0 = 0x231;
            local_4d8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
            local_4e0 = (char *)CONCAT44(local_4e0._4_4_,local_4a8);
            local_4e8 = (uint *)CONCAT44(local_4e8._4_4_,uVar4);
            log_InlineLogERROR("Check %s chksum failed. AccountID=%u, RefID=%u, Type=%u, Chksum=%u at %s, %d"
                               ,"emoney_card_google",uVar9,(ulonglong)uVar3);
          }
          local_4ac = iVar1 + 1;
        }
        (**(code **)*plVar5)(plVar5);
      }
    }
  }
  return;
}

// ==== CGooglePaymentsThread::ctor_or_dtor  @140019520  [high:vtable-assign]  (orig: FUN_140019520)
CThreadBase * FUN_140019520(CThreadBase *param_1,undefined8 param_2)

{
  ulong uVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CGooglePaymentsThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = param_2;
  param_1[0x48] = (CThreadBase)0x0;
  param_1[0x49] = (CThreadBase)0x0;
  plVar3 = (longlong *)0x0;
  *(undefined4 *)(param_1 + 0x84c) = 0;
  plVar2 = operator_new(8);
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 0x850);
    plVar3 = plVar2;
  }
  *(longlong **)(param_1 + 0x850) = plVar3;
  *(undefined8 *)(param_1 + 0x868) = 0;
  *(undefined8 *)(param_1 + 0x870) = 0;
  *(undefined8 *)(param_1 + 0x878) = 0;
  *(undefined4 *)(param_1 + 0x880) = 0;
  *(undefined4 *)(param_1 + 0x884) = 0;
  *(undefined4 *)(param_1 + 0x888) = 0;
  *(undefined4 *)(param_1 + 0x88c) = 0;
  *(undefined4 *)(param_1 + 0x890) = 0;
  FUN_140019420(param_1 + 0x898);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","m_pMsgPort",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp",
                       0x22);
  }
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))();
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x40))();
  memset(param_1 + 0x44a,0,0x400);
  memset(param_1 + 0x4a,0,0x400);
  *(undefined4 *)(param_1 + 0x880) = 300;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x884) = uVar1 / 1000;
  *(undefined4 *)(param_1 + 0x888) = 5;
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x88c) = uVar1 / 1000;
  FUN_140016c20(param_1 + 0x898,*(undefined8 *)(*(longlong *)(param_1 + 0x8c8) + 8));
  *(longlong *)(*(longlong *)(param_1 + 0x8c8) + 8) = *(longlong *)(param_1 + 0x8c8);
  *(undefined8 *)(param_1 + 0x8d0) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x8c8) = *(undefined8 *)(param_1 + 0x8c8);
  *(longlong *)(*(longlong *)(param_1 + 0x8c8) + 0x10) = *(longlong *)(param_1 + 0x8c8);
  return param_1;
}

// ==== CGooglePaymentsThread::vfunc_0  @1400196d0  [high:rtti-vtable]  (orig: FUN_1400196d0)
void * FUN_1400196d0(void *param_1,uint param_2)

{
  FUN_140018c10();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CGooglePaymentsThread::vfunc_2  @140019700  [high:rtti-vtable]  (orig: FUN_140019700)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140019700(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  ulonglong uVar6;
  longlong *plVar7;
  longlong lVar8;
  char *pcVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined1 auStack_ca8 [32];
  char *local_c88;
  longlong local_c78;
  longlong local_c70;
  undefined8 local_c68;
  undefined8 uStack_c60;
  undefined4 local_c58;
  undefined4 uStack_c54;
  undefined4 uStack_c50;
  undefined4 uStack_c4c;
  undefined8 local_c48;
  CIniFile local_c38 [1024];
  char local_838 [1023];
  undefined1 local_439;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_c48 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_ca8;
  local_c70 = param_1;
  CIniFile::CIniFile(local_c38,"shell.ini","GooglePaymentsClient");
  CIniFile::GetString(local_c38,(char *)(param_1 + 0x4a),"URL",0x400);
  CIniFile::GetString(local_c38,(char *)(param_1 + 0x44a),"MD5KEY",0x400);
  *(undefined1 *)(param_1 + 0x49) = 1;
  FUN_1400179f0(param_1 + 0x850);
  uVar3 = (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
  _snprintf(local_438,0x3ff,"#%u: GooglePaymentsSocketThread running.",(ulonglong)uVar3);
  local_39 = 0;
  lVar8 = -1;
  pcVar9 = local_438;
  do {
    if (lVar8 == 0) break;
    lVar8 = lVar8 + -1;
    cVar1 = *pcVar9;
    pcVar9 = pcVar9 + 1;
  } while (cVar1 != '\0');
  local_c88 = local_438;
  (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
            (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar8);
  _snprintf(local_838,0x400,"SELECT * FROM cq_online_payments WHERE type = %u",1);
  local_439 = 0;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,local_838,2);
  if (plVar5 != (longlong *)0x0) {
    uVar3 = 0;
    lVar8 = (**(code **)(*plVar5 + 0x40))(plVar5);
    if (lVar8 != 0) {
      uVar10 = 0;
      do {
        (**(code **)(*plVar5 + 0x30))(plVar5,uVar10);
        local_c78 = (**(code **)(*plVar5 + 0x38))(plVar5);
        if (local_c78 == 0) {
          local_c88 = (char *)CONCAT44(local_c88._4_4_,0x72);
          log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pRec != NULL",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp"
                            );
        }
        else {
          plVar7 = *(longlong **)(param_1 + 0x870);
          plVar2 = *(longlong **)(param_1 + 0x868);
          if ((plVar2 == (longlong *)0x0) ||
             ((ulonglong)(*(longlong *)(param_1 + 0x878) - (longlong)plVar2 >> 3) <=
              (ulonglong)((longlong)plVar7 - (longlong)plVar2 >> 3))) {
            if (plVar7 < plVar2) {
              _invalid_parameter_noinfo();
            }
            lVar8 = *(longlong *)(param_1 + 0x850);
            uVar10 = *(ulonglong *)(param_1 + 0x868);
            local_c68 = lVar8;
            uStack_c60 = plVar7;
            if ((*(ulonglong *)(param_1 + 0x870) - uVar10 & 0xfffffffffffffff8) == 0) {
              lVar8 = 0;
            }
            else {
              if (*(ulonglong *)(param_1 + 0x870) < uVar10) {
                _invalid_parameter_noinfo();
              }
              if ((lVar8 == 0) || (lVar8 != *(longlong *)(param_1 + 0x850))) {
                _invalid_parameter_noinfo();
              }
              lVar8 = (longlong)((longlong)plVar7 - uVar10) >> 3;
            }
            local_c58 = (undefined4)local_c68;
            uStack_c54 = local_c68._4_4_;
            uStack_c50 = (undefined4)uStack_c60;
            uStack_c4c = uStack_c60._4_4_;
            FUN_1400183c0(param_1 + 0x850,&local_c58,1,&local_c78);
            uVar10 = *(ulonglong *)(param_1 + 0x868);
            if (*(ulonglong *)(param_1 + 0x870) < uVar10) {
              _invalid_parameter_noinfo();
            }
            plVar7 = *(longlong **)(param_1 + 0x850);
            if (plVar7 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar7;
            }
            uVar10 = uVar10 + lVar8 * 8;
            if (uVar10 <= *(ulonglong *)(lVar11 + 0x20)) {
              if (plVar7 == (longlong *)0x0) {
                lVar8 = 0;
              }
              else {
                lVar8 = *plVar7;
              }
              if (*(ulonglong *)(lVar8 + 0x18) <= uVar10) goto LAB_1400199e6;
            }
            _invalid_parameter_noinfo();
          }
          else {
            *plVar7 = local_c78;
            *(longlong **)(param_1 + 0x870) = plVar7 + 1;
          }
        }
LAB_1400199e6:
        uVar3 = uVar3 + 1;
        uVar10 = (ulonglong)uVar3;
        uVar6 = (**(code **)(*plVar5 + 0x40))(plVar5);
      } while (uVar10 < uVar6);
    }
  }
  if (plVar5 != (longlong *)0x0) {
    (**(code **)*plVar5)(plVar5);
  }
  _snprintf(local_838,0x400,"SELECT MAX(id) FROM %s LIMIT 1","emoney_card_google");
  local_439 = 0;
  plVar5 = (longlong *)InstanceGet();
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,local_838,1);
  if ((plVar5 != (longlong *)0x0) && (lVar8 = (**(code **)(*plVar5 + 0x40))(plVar5), lVar8 != 0)) {
    plVar7 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0);
    uVar4 = (**(code **)(*plVar7 + 0x40))(plVar7);
    *(undefined4 *)(param_1 + 0x84c) = uVar4;
    (**(code **)*plVar5)(plVar5);
    CIniFile::~CIniFile(local_c38);
    return;
  }
  if (plVar5 != (longlong *)0x0) {
    (**(code **)*plVar5)(plVar5);
  }
  log_InlineLogDBERROR("emoney_card_google not found");
  CIniFile::~CIniFile(local_c38);
  return;
}

// ==== CGooglePaymentsThread::helper_140019b00  @140019b00  [medium:callgraph-r1]  (orig: FUN_140019b00)
void FUN_140019b00(undefined8 param_1,int *param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  
  if (param_2 != (int *)0x0) {
    iVar1 = *param_2;
    if ((iVar1 != 0) && (param_2[1] != 0)) {
      if ((char)param_2[2] == '\0') {
        FUN_140018fb0(param_1,iVar1,param_2[1],param_4,0xfffffffffffffffe);
      }
      else {
        FUN_140018cb0(param_1,iVar1);
      }
    }
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140019b40  @140019b40  [medium:callgraph-r2]  (orig: FUN_140019b40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140019b40(longlong param_1,undefined4 *param_2)

{
  longlong lVar1;
  char cVar2;
  ulong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *local_res10;
  
  if (param_2 != (undefined4 *)0x0) {
    plVar4 = (longlong *)InstanceGet();
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,"cq_online_payments");
    if (plVar4 != (longlong *)0x0) {
      local_res10 = plVar4;
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,1);
      (**(code **)(*plVar5 + 0xb0))(plVar5,1);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,2);
      (**(code **)(*plVar5 + 0xb8))(plVar5,*param_2);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,3);
      (**(code **)(*plVar5 + 0xb8))(plVar5,param_2[1]);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
      (**(code **)(*plVar5 + 0xa8))(plVar5,param_2[2]);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,5);
      (**(code **)(*plVar5 + 0x80))(plVar5,(longlong)param_2 + 0xd);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,6);
      (**(code **)(*plVar5 + 0x80))(plVar5,param_2 + 0xc);
      plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,7);
      lVar1 = *plVar5;
      uVar3 = tq::TimeStampGet();
      (**(code **)(lVar1 + 0xb8))(plVar5,uVar3);
      cVar2 = (**(code **)(*plVar4 + 0x50))(plVar4,1);
      if (cVar2 == '\0') {
        tq::MyLogSave("gmlog/GooglePayments",
                      "send client payments message to web server failure insert db fail, iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                      ,*param_2,param_2[1]);
        (**(code **)*plVar4)(plVar4,1);
      }
      else {
        FUN_140019370(param_1 + 0x850,&local_res10);
      }
    }
  }
  return;
}

// ==== CGooglePaymentsThread::helper_140019d20  @140019d20  [medium:callgraph-r1]  (orig: FUN_140019d20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140019d20(longlong param_1)

{
  undefined8 uVar1;
  ulonglong *puVar2;
  undefined8 *puVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *plVar10;
  char *pcVar11;
  undefined4 *puVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  ulonglong uVar15;
  int iVar16;
  ulonglong uVar17;
  bool bVar18;
  undefined1 auStack_638 [32];
  undefined4 *local_618;
  char *local_610;
  char *local_608;
  undefined4 local_600;
  int local_5f8;
  undefined4 local_5f0;
  undefined4 local_5ec;
  undefined1 local_5e8;
  uint local_5e0;
  undefined4 local_5dc;
  uint local_5d8;
  uint local_5d4;
  uint local_5d0;
  uint local_5cc;
  ulonglong *local_5c8 [6];
  undefined8 *local_598;
  undefined8 local_590;
  undefined8 local_588;
  undefined8 uStack_580;
  ulonglong *local_578;
  undefined8 uStack_570;
  ulonglong *local_568;
  undefined8 uStack_560;
  undefined8 local_558;
  undefined8 uStack_550;
  undefined4 local_548;
  undefined4 uStack_544;
  undefined4 uStack_540;
  undefined4 uStack_53c;
  undefined8 local_538;
  undefined8 uStack_530;
  ulonglong *local_528;
  undefined8 uStack_520;
  undefined8 *local_518;
  ulonglong *local_510 [2];
  CTickAnalyst local_500 [24];
  ulonglong *local_4e8;
  undefined4 local_4d8;
  undefined4 uStack_4d4;
  undefined4 uStack_4d0;
  undefined4 uStack_4cc;
  ulonglong *local_4c8;
  undefined4 local_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined4 local_4a8;
  undefined4 uStack_4a4;
  undefined4 uStack_4a0;
  undefined4 uStack_49c;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_468 [48];
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_638;
  local_558 = (ulonglong *)param_1;
  CTickAnalyst::CTickAnalyst(local_500,0x3b);
  *(int *)(param_1 + 0x890) = *(int *)(param_1 + 0x890) + 1;
  if (0x1d < *(int *)(param_1 + 0x890)) {
    FUN_140016c20(param_1 + 0x898);
    *(longlong *)(*(longlong *)(param_1 + 0x8c8) + 8) = *(longlong *)(param_1 + 0x8c8);
    *(undefined8 *)(param_1 + 0x8d0) = 0;
    *(undefined8 *)*(undefined8 *)(param_1 + 0x8c8) = *(undefined8 *)(param_1 + 0x8c8);
    *(longlong *)(*(longlong *)(param_1 + 0x8c8) + 0x10) = *(longlong *)(param_1 + 0x8c8);
  }
  uVar15 = 0;
  FUN_1400194a0(local_5c8);
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  local_618 = (undefined4 *)CONCAT44(local_618._4_4_,*(undefined4 *)(param_1 + 0x84c));
  _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE id > %u AND used=0","emoney_card_google");
  local_39 = 0;
  plVar8 = (longlong *)InstanceGet();
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,&local_438,2);
  if (plVar8 == (longlong *)0x0) {
    uStack_550 = local_598;
    puVar13 = uStack_550;
    local_558 = local_5c8[0];
    puVar2 = local_558;
    uVar1 = *local_598;
    local_568 = local_5c8[0];
    local_558._0_4_ = SUB84(local_5c8[0],0);
    local_558._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
    uStack_550._0_4_ = SUB84(local_598,0);
    uStack_550._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
    local_478 = (undefined4)local_558;
    uStack_474 = local_558._4_4_;
    uStack_470 = (undefined4)uStack_550;
    uStack_46c = uStack_550._4_4_;
    uStack_560._0_4_ = (undefined4)uVar1;
    uStack_560._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
    local_4a8 = (undefined4)local_558;
    uStack_4a4 = local_558._4_4_;
    uStack_4a0 = (undefined4)uStack_560;
    uStack_49c = uStack_560._4_4_;
    uStack_560 = uVar1;
    local_558 = puVar2;
    uStack_550 = puVar13;
    FUN_140017580(local_5c8,&local_548,&local_4a8,&local_478);
    operator_delete(local_598);
    local_598 = (undefined8 *)0x0;
    local_590 = 0;
    operator_delete(local_5c8[0]);
    CTickAnalyst::~CTickAnalyst(local_500);
  }
  else {
    lVar9 = (**(code **)(*plVar8 + 0x40))(plVar8);
    if (lVar9 == 0) {
      (**(code **)*plVar8)(plVar8);
      uStack_580 = local_598;
      puVar13 = uStack_580;
      local_588 = local_5c8[0];
      puVar2 = local_588;
      uVar1 = *local_598;
      local_578 = local_5c8[0];
      local_588._0_4_ = SUB84(local_5c8[0],0);
      local_588._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
      uStack_580._0_4_ = SUB84(local_598,0);
      uStack_580._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
      local_4d8 = (undefined4)local_588;
      uStack_4d4 = local_588._4_4_;
      uStack_4d0 = (undefined4)uStack_580;
      uStack_4cc = uStack_580._4_4_;
      uStack_570._0_4_ = (undefined4)uVar1;
      uStack_570._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
      local_4b8 = (undefined4)local_588;
      uStack_4b4 = local_588._4_4_;
      uStack_4b0 = (undefined4)uStack_570;
      uStack_4ac = uStack_570._4_4_;
      local_588 = puVar2;
      uStack_580 = puVar13;
      uStack_570 = uVar1;
      FUN_140017580(local_5c8,&local_548,&local_4b8,&local_4d8);
      operator_delete(local_598);
      local_598 = (undefined8 *)0x0;
      local_590 = 0;
      operator_delete(local_5c8[0]);
      CTickAnalyst::~CTickAnalyst(local_500);
    }
    else {
      local_5e0 = 0;
      uVar17 = uVar15;
      while( true ) {
        iVar4 = (**(code **)(*plVar8 + 0x40))(plVar8);
        iVar16 = (int)uVar17;
        if (iVar4 <= iVar16) break;
        (**(code **)(*plVar8 + 0x30))(plVar8,(longlong)iVar16);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,&DAT_1406de8d4);
        uVar5 = (**(code **)(*plVar10 + 0x40))(plVar10);
        if (*(uint *)(param_1 + 0x84c) < uVar5) {
          plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,&DAT_1406de8d4);
          uVar6 = (**(code **)(*plVar10 + 0x40))(plVar10);
          *(undefined4 *)(param_1 + 0x84c) = uVar6;
        }
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"ref_id");
        local_5d8 = (**(code **)(*plVar10 + 0x40))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"chk_sum");
        local_5cc = (**(code **)(*plVar10 + 0x50))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,&DAT_1406de6d4);
        uVar5 = (**(code **)(*plVar10 + 0x50))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"itemcount");
        local_5f8 = (**(code **)(*plVar10 + 0x48))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"account_id");
        uVar7 = (**(code **)(*plVar10 + 0x40))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"roleid");
        local_5dc = (**(code **)(*plVar10 + 0x40))(plVar10);
        plVar10 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,"ordernumber");
        pcVar11 = (char *)(**(code **)(*plVar10 + 0x78))(plVar10);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468,pcVar11);
        FUN_140018740(param_1 + 0x898,local_468);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_468);
        local_568 = local_598;
        local_578 = local_5c8[0];
        local_4c8 = local_5c8[0];
        local_5d0 = uVar7;
        local_588 = (ulonglong *)FUN_140017ca0(local_5c8,&local_548,&local_5d0);
        if (((ulonglong *)*local_588 == (ulonglong *)0x0) || ((ulonglong *)*local_588 != local_578))
        {
          _invalid_parameter_noinfo();
        }
        if ((undefined8 *)local_588[1] == local_568) {
          if ((uVar7 ^ uVar5) + local_5d8 >> 1 == local_5cc) {
            if ((uVar5 == 0) || (local_5f8 < 1)) {
              local_608 = (char *)CONCAT44(local_608._4_4_,0x3af);
              local_610 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
              local_618 = (undefined4 *)CONCAT44(local_618._4_4_,local_5f8);
              log_InlineLogERROR("CGooglePaymentsThread::ProcessPayResultData. ProcessGooglePayQueryMessage failed. AccountID=%u, RefID=%u, Type=%u, ItemCount=%d at %s, %d"
                                 ,(ulonglong)uVar7,(ulonglong)local_5d8,(ulonglong)uVar5);
            }
            else {
              local_5d4 = uVar7;
              puVar12 = (undefined4 *)FUN_140018880(local_5c8,&local_5d4);
              *puVar12 = local_5dc;
            }
          }
          else {
            local_600 = 0x3a9;
            local_608 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\googlepaymentsthread.cpp";
            local_610 = (char *)CONCAT44(local_610._4_4_,local_5cc);
            local_618 = (undefined4 *)CONCAT44(local_618._4_4_,uVar5);
            log_InlineLogERROR("CGooglePaymentsThread::ProcessPayResultData. Check %s chksum failed. AccountID=%u, RefID=%u, Type=%u, Chksum=%u at %s, %d"
                               ,"emoney_card_google",(ulonglong)uVar7,(ulonglong)local_5d8);
          }
        }
        local_5e0 = iVar16 + 1;
        uVar17 = (ulonglong)local_5e0;
      }
      (**(code **)*plVar8)(plVar8);
      puVar2 = local_5c8[0];
      local_5f0 = 0;
      local_5ec = 0;
      local_5e8 = 0;
      puVar13 = (undefined8 *)*local_598;
      local_4e8 = local_5c8[0];
LAB_14001a2e0:
      puVar14 = local_598;
      local_510[0] = local_5c8[0];
      if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_5c8[0])) {
        _invalid_parameter_noinfo();
      }
      if (puVar13 != puVar14) {
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar17 = uVar15;
        }
        else {
          uVar17 = *puVar2;
        }
        if (puVar13 == *(undefined8 **)(uVar17 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_5f0 = *(undefined4 *)((longlong)puVar13 + 0x1c);
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar17 = uVar15;
        }
        else {
          uVar17 = *puVar2;
        }
        if (puVar13 == *(undefined8 **)(uVar17 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_5ec = *(undefined4 *)(puVar13 + 3);
        local_5e8 = 0;
        local_618 = &local_5f0;
        (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
                  (*(longlong **)(param_1 + 0x40),0xe,0x186a6,0xc);
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar13 + 0x21) == '\0') {
          puVar14 = puVar13;
          puVar3 = (undefined8 *)puVar13[2];
          if (*(char *)((longlong)puVar13[2] + 0x21) == '\0') {
            do {
              puVar13 = puVar3;
              puVar3 = (undefined8 *)*puVar13;
              local_518 = puVar13;
            } while (*(char *)((longlong)*puVar13 + 0x21) == '\0');
          }
          else {
            do {
              puVar13 = (undefined8 *)puVar14[1];
              if (*(char *)((longlong)puVar13 + 0x21) != '\0') break;
              bVar18 = puVar14 == (undefined8 *)puVar13[2];
              puVar14 = puVar13;
            } while (bVar18);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        goto LAB_14001a2e0;
      }
      uStack_530 = local_598;
      puVar13 = uStack_530;
      local_538 = local_5c8[0];
      puVar2 = local_538;
      uVar1 = *local_598;
      local_528 = local_5c8[0];
      local_538._0_4_ = SUB84(local_5c8[0],0);
      local_538._4_4_ = (undefined4)((ulonglong)local_5c8[0] >> 0x20);
      uStack_530._0_4_ = SUB84(local_598,0);
      uStack_530._4_4_ = (undefined4)((ulonglong)local_598 >> 0x20);
      local_498 = (undefined4)local_538;
      uStack_494 = local_538._4_4_;
      uStack_490 = (undefined4)uStack_530;
      uStack_48c = uStack_530._4_4_;
      uStack_520._0_4_ = (undefined4)uVar1;
      uStack_520._4_4_ = (undefined4)((ulonglong)uVar1 >> 0x20);
      local_548 = (undefined4)local_538;
      uStack_544 = local_538._4_4_;
      uStack_540 = (undefined4)uStack_520;
      uStack_53c = uStack_520._4_4_;
      local_538 = puVar2;
      uStack_530 = puVar13;
      uStack_520 = uVar1;
      FUN_140017580(local_5c8,local_510,&local_548,&local_498);
      operator_delete(local_598);
      local_598 = (undefined8 *)0x0;
      local_590 = 0;
      operator_delete(local_5c8[0]);
      CTickAnalyst::~CTickAnalyst(local_500);
    }
  }
  return;
}

// ==== CGooglePaymentsThread::helper_14001a4f0  @14001a4f0  [medium:callgraph-r1]  (orig: FUN_14001a4f0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14001a4f0(longlong param_1,uint *param_2,char param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  char *pcVar4;
  char *pcVar5;
  bool bVar6;
  undefined1 auStack_1138 [32];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_1118;
  uint local_1110;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_1108;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *local_1100;
  longlong local_10f8;
  uint local_10f0;
  uint local_10e8 [2];
  undefined8 local_10e0;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_10d8 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_10b0 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_1088 [48];
  undefined1 local_1058 [3120];
  char local_428 [1024];
  ulonglong local_28;
  undefined8 uStack_20;
  
  uStack_20 = 0x14001a4ff;
  local_10e0 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_1138;
  if (param_2 == (uint *)0x0) {
    uVar2 = 1;
  }
  else {
    local_428[0] = '\0';
    memset(local_428 + 1,0,0x3ff);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
    local_1118 = local_1088;
    cVar1 = FUN_140014390(param_1,param_2,local_428,0x400);
    if (cVar1 == '\0') {
      local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   CONCAT44(local_1100._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
      local_1110 = (uint)(byte)param_2[3];
      local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   CONCAT44(local_1118._4_4_,param_2[2]);
      local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   ((longlong)param_2 + 0xd);
      tq::MyLogSave("gmlog/GooglePayments",
                    "send client payments message to web server failure AssembleHttpMessage,iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                    ,(ulonglong)*param_2,(ulonglong)param_2[1]);
      tq::MyLogSave("gmlog/GooglePayments",
                    "send client payments message to web server failure AssembleHttpMessage, PaymentsInfo[%s]"
                    ,param_2 + 0xc);
      local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   ((longlong)param_2 + 0xd);
      FUN_140013040(param_1,*param_2,param_2[1],6);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
      uVar2 = 1;
    }
    else {
      FUN_1400c6fd0(local_1058);
      cVar1 = FUN_1400c7080(local_1058,param_1 + 0x4a,"get by CQServer");
      if (cVar1 == '\0') {
        if (param_3 == '\0') {
          FUN_140019b40(param_1,param_2);
          local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       CONCAT44(local_1100._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
          local_1110 = (uint)(byte)param_2[3];
          local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       CONCAT44(local_1118._4_4_,param_2[2]);
          local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       ((longlong)param_2 + 0xd);
          tq::MyLogSave("gmlog/GooglePayments",
                        "send client payments message to web server failure Http Init,iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                        ,(ulonglong)*param_2,(ulonglong)param_2[1]);
          local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       ((longlong)param_2 + 0xd);
          FUN_140013040(param_1,*param_2,param_2[1],6);
        }
        FUN_1400c7020(local_1058);
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
        uVar2 = 0;
      }
      else {
        local_10e8[0] = 9999;
        cVar1 = FUN_1400c7390(local_1058,local_428,0x400,local_10e8);
        if (cVar1 == '\0') {
          if (param_3 == '\0') {
            FUN_140019b40(param_1,param_2);
            local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1100._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
            local_1110 = (uint)(byte)param_2[3];
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1118._4_4_,param_2[2]);
            local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            tq::MyLogSave("gmlog/GooglePayments",
                          "send client payments message to web server failure Http Post,iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                          ,(ulonglong)*param_2,(ulonglong)param_2[1]);
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            FUN_140013040(param_1,*param_2,param_2[1],6);
          }
          FUN_1400c7020(local_1058);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
          uVar2 = 0;
        }
        else if (local_10e8[0] == 200) {
          lVar3 = 8;
          bVar6 = true;
          pcVar4 = local_428;
          pcVar5 = "success";
          do {
            if (lVar3 == 0) break;
            lVar3 = lVar3 + -1;
            bVar6 = *pcVar4 == *pcVar5;
            pcVar4 = pcVar4 + 1;
            pcVar5 = pcVar5 + 1;
          } while (bVar6);
          if (bVar6) {
            local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1100._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
            local_1110 = (uint)(byte)param_2[3];
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1118._4_4_,param_2[2]);
            local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            tq::MyLogSave("gmlog/GooglePayments",
                          "send client payments message to web server Ret succeed, iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u"
                          ,(ulonglong)*param_2,(ulonglong)param_2[1]);
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            FUN_140013040(param_1,*param_2,param_2[1],5);
            FUN_140017ab0(param_1 + 0x898,local_10d8,local_1088);
            *(undefined4 *)(param_1 + 0x890) = 0;
          }
          else {
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_10d8,local_428);
            local_10f8 = FUN_1400134f0(param_1,local_10b0,local_10d8);
            if (*(ulonglong *)(local_10f8 + 0x20) < 0x10) {
              local_10f8 = local_10f8 + 8;
            }
            else {
              local_10f8 = *(longlong *)(local_10f8 + 8);
            }
            local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1100._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
            local_1110 = (uint)(byte)param_2[3];
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1118._4_4_,param_2[2]);
            local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            tq::MyLogSave("gmlog/GooglePayments",
                          "send client payments message to web server Ret failure, iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u,Ret:%s"
                          ,(ulonglong)*param_2,(ulonglong)param_2[1]);
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_10b0);
            std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
            ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_10d8);
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            FUN_140013040(param_1,*param_2,param_2[1],6);
          }
          FUN_1400c7020(local_1058);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
          uVar2 = 1;
        }
        else {
          if (param_3 == '\0') {
            local_10f0 = local_10e8[0];
            local_10f8 = CONCAT44(local_10f8._4_4_,(uint)*(ushort *)((longlong)param_2 + 0x2e));
            local_1108 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1108._4_4_,(uint)(byte)param_2[3]);
            local_1110 = param_2[2];
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         CONCAT44(local_1118._4_4_,param_2[1]);
            local_1100 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            tq::MyLogSave("gmlog/GooglePayments",
                          "send client payments message to web server failure StatusCode[%d], iduser:%u, idacount:%u, unServerID:%u, ismessageend:%d, szTransactionId:%s,usSerialNumber:%u,InternetCode:%d"
                          ,(ulonglong)local_10e8[0],(ulonglong)*param_2);
            FUN_140019b40(param_1,param_2);
            local_1118 = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         ((longlong)param_2 + 0xd);
            FUN_140013040(param_1,*param_2,param_2[1],6);
          }
          FUN_1400c7020(local_1058);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1088);
          uVar2 = 0;
        }
      }
    }
  }
  return uVar2;
}

// ==== CGooglePaymentsThread::helper_14001a9c0  @14001a9c0  [medium:callgraph-r1]  (orig: FUN_14001a9c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14001a9c0(longlong param_1)

{
  longlong *_Dst;
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  void *_Src;
  longlong lVar4;
  rsize_t rVar5;
  longlong *plVar6;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  undefined4 uStack_434;
  longlong *plStack_430;
  longlong local_428;
  undefined8 local_418;
  longlong *plStack_410;
  undefined8 local_408;
  longlong *plStack_400;
  undefined8 local_3f8;
  undefined4 local_3e8;
  undefined4 local_3e4;
  undefined4 local_3e0;
  undefined1 local_3dc;
  undefined8 local_3db;
  undefined8 local_3d3;
  undefined8 local_3cb;
  undefined8 local_3c3;
  undefined2 local_3ba;
  undefined1 local_3b8 [912];
  ulonglong local_28;
  
  local_3f8 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  _Dst = *(longlong **)(param_1 + 0x868);
  local_428 = param_1;
  if (*(longlong **)(param_1 + 0x870) < _Dst) {
    _invalid_parameter_noinfo();
  }
  plVar6 = *(longlong **)(param_1 + 0x850);
  while( true ) {
    plVar2 = *(longlong **)(param_1 + 0x870);
    plStack_430 = _Dst;
    if (plVar2 < *(longlong **)(param_1 + 0x868)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0x850))) {
      _invalid_parameter_noinfo();
    }
    if (_Dst == plVar2) break;
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar6;
    }
    if (*(longlong **)(lVar4 + 0x20) <= _Dst) {
      _invalid_parameter_noinfo();
    }
    plVar6 = (longlong *)*_Dst;
    if (plVar6 == (longlong *)0x0) {
      lVar4 = *(longlong *)(param_1 + 0x870) - (longlong)(_Dst + 1) >> 3;
      if (0 < lVar4) {
        rVar5 = lVar4 << 3;
        memmove_s(_Dst,rVar5,_Dst + 1,rVar5);
      }
      *(longlong *)(param_1 + 0x870) = *(longlong *)(param_1 + 0x870) + -8;
      if ((_Dst < *(longlong **)(param_1 + 0x868)) || (*(longlong **)(param_1 + 0x870) < _Dst)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(param_1 + 0x850);
      local_418._0_4_ = SUB84(plVar6,0);
      local_438 = (undefined4)local_418;
      local_418._4_4_ = (undefined4)((ulonglong)plVar6 >> 0x20);
      uStack_434 = local_418._4_4_;
      local_418 = plVar6;
      plStack_410 = _Dst;
    }
    else {
      plVar2 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,2);
      local_3e8 = (**(code **)(*plVar2 + 0x40))(plVar2);
      plVar2 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,3);
      local_3e4 = (**(code **)(*plVar2 + 0x40))(plVar2);
      plVar2 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
      local_3e0 = (**(code **)(*plVar2 + 0x50))(plVar2);
      local_3dc = 1;
      local_3ba = 0;
      plVar2 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,5);
      puVar3 = (undefined8 *)(**(code **)(*plVar2 + 0x78))(plVar2);
      local_3db = *puVar3;
      local_3d3 = puVar3[1];
      local_3cb = puVar3[2];
      local_3c3 = puVar3[3];
      plVar2 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,6);
      _Src = (void *)(**(code **)(*plVar2 + 0x78))(plVar2);
      memcpy(local_3b8,_Src,900);
      cVar1 = FUN_14001a4f0(param_1,&local_3e8,1);
      if (cVar1 == '\0') {
        return;
      }
      (**(code **)(*plVar6 + 0x40))(plVar6,0);
      (**(code **)*plVar6)(plVar6,1);
      lVar4 = *(longlong *)(param_1 + 0x870) - (longlong)(_Dst + 1) >> 3;
      if (0 < lVar4) {
        rVar5 = lVar4 << 3;
        memmove_s(_Dst,rVar5,_Dst + 1,rVar5);
      }
      *(longlong *)(param_1 + 0x870) = *(longlong *)(param_1 + 0x870) + -8;
      if ((_Dst < *(longlong **)(param_1 + 0x868)) || (*(longlong **)(param_1 + 0x870) < _Dst)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(param_1 + 0x850);
      local_408._0_4_ = SUB84(plVar6,0);
      local_408._4_4_ = (undefined4)((ulonglong)plVar6 >> 0x20);
      local_438 = (undefined4)local_408;
      uStack_434 = local_408._4_4_;
      local_408 = plVar6;
      plStack_400 = _Dst;
    }
  }
  return;
}

// ==== CGooglePaymentsThread::helper_14001ac90  @14001ac90  [medium:callgraph-r0]  (orig: FUN_14001ac90)
undefined8 FUN_14001ac90(undefined8 param_1,int param_2,undefined8 param_3)

{
  char cVar1;
  
  if (param_2 == 0x186a3) {
    cVar1 = FUN_14001a4f0(param_1,param_3,0);
    if (cVar1 != '\0') {
      FUN_14001a9c0(param_1);
    }
    return 1;
  }
  if (param_2 != 0x186a4) {
    tq::MyLogSave("gmlog/GooglePayments","invalid packet:%d, port:%d");
    return 1;
  }
  FUN_140019b00(param_1,param_3);
  return 1;
}

// ==== CGooglePaymentsThread::helper_14001ad00  @14001ad00  [medium:callgraph-r0]  (orig: FUN_14001ad00)
ulonglong FUN_14001ad00(longlong param_1)

{
  ulong uVar1;
  ulonglong uVar2;
  
  uVar1 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x884) + *(int *)(param_1 + 0x880)) <= uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x884) = uVar1 / 1000;
    FUN_14001a9c0(param_1);
  }
  uVar1 = tq::TimeGet(0);
  uVar2 = (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
  if ((uint)(*(int *)(param_1 + 0x888) + *(int *)(param_1 + 0x88c)) <= uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    uVar2 = (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
    *(uint *)(param_1 + 0x88c) = uVar1 / 1000;
    if ((*(longlong *)(param_1 + 0x8d0) != 0) && (*(int *)(param_1 + 0x890) < 0x1e)) {
      uVar2 = FUN_140019d20(param_1);
    }
  }
  return uVar2;
}

// ==== CGooglePaymentsThread::vfunc_3  @14001adc0  [high:rtti-vtable]  (orig: FUN_14001adc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14001adc0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined4 *local_4a0;
  char local_498;
  char local_497;
  ulong local_494;
  undefined4 local_490;
  uint local_48c;
  undefined4 local_488;
  longlong local_480;
  CTickAnalyst local_478 [24];
  undefined8 local_460;
  CTickAnalyst local_458 [32];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_460 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_480 = param_1;
  if ((DAT_1409754f4 & 1) == 0) {
    DAT_1409754f4 = DAT_1409754f4 | 1;
    DAT_1409754f0 = tq::TimeGet(0);
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x58))
                    (*(longlong **)(param_1 + 0x40),s___AVCGooglePaymentsThread___1409493d8._28_4_);
  local_497 = cVar1;
  CTickAnalyst::CTickAnalyst(local_458,0x38);
  uVar2 = tq::TimeGet(0);
  local_494 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_478,0x3a);
    FUN_14001ad00(param_1);
    CTickAnalyst::~CTickAnalyst(local_478);
    if (uVar2 - DAT_1409754f0 < 0x2711) {
      DAT_1409754f0 = DAT_1409754f0 + 2000;
    }
    else {
      log_InlineLogWARNING("resync CGooglePaymentsThread::OnTimer cumulative deviation %dms");
      DAT_1409754f0 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4a0 = &local_490;
      local_4a8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x48))
                        (*(longlong **)(param_1 + 0x40),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_498 = 1;
      CTickAnalyst::CTickAnalyst(local_478,0x39);
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,local_490);
      cVar1 = FUN_14001ac90(param_1,local_48c,local_438,local_488);
      local_498 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_478);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CGooglePaymentsThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                           ,(ulonglong)local_48c);
      }
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_1409754f0) < 2000) {
    s___AVCGooglePaymentsThread___1409493d8._28_4_ = 2000 - (uVar2 - DAT_1409754f0);
  }
  else {
    s___AVCGooglePaymentsThread___1409493d8[0x1c] = '\0';
    s___AVCGooglePaymentsThread___1409493d8[0x1d] = '\0';
    s___AVCGooglePaymentsThread___1409493d8[0x1e] = '\0';
    s___AVCGooglePaymentsThread___1409493d8[0x1f] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_458);
  return 1;
}

// ==== CGooglePaymentsThread::helper_1400c7080  @1400c7080  [medium:callgraph-r2]  (orig: FUN_1400c7080)
undefined4 FUN_1400c7080(longlong param_1,longlong param_2,undefined8 param_3)

{
  undefined8 uVar1;
  char cVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 in_stack_ffffffffffffffc8;
  uint uVar6;
  
  uVar6 = (uint)((ulonglong)in_stack_ffffffffffffffc8 >> 0x20);
  log_InlineLogFACEBOOK("CHttpService::Init, URL:%s, AgentString:%s");
  if (param_2 == 0) {
    uVar4 = 0;
  }
  else {
    cVar2 = FUN_140329cd0(param_1 + 8,param_2);
    if (cVar2 == '\0') {
      log_InlineLogFACEBOOK("CHttpService::Init, Failed in parse url");
      uVar4 = 0;
    }
    else {
      lVar5 = InternetOpenA(param_3,0,0,0,(ulonglong)uVar6 << 0x20);
      *(longlong *)(param_1 + 0xc18) = lVar5;
      if (lVar5 == 0) {
        log_InlineLogFACEBOOK("CHttpService::Init, failed in opening internet");
        uVar4 = 0;
      }
      else {
        uVar3 = FUN_140329e60(param_1 + 8);
        uVar1 = FUN_140329e50(param_1 + 8);
        lVar5 = InternetConnectA(*(undefined8 *)(param_1 + 0xc18),uVar1,uVar3,0,0,3,0,0);
        *(longlong *)(param_1 + 0xc20) = lVar5;
        if (lVar5 == 0) {
          log_InlineLogFACEBOOK("CHttpService::Init, failed in connecting internet");
          uVar4 = 0;
        }
        else {
          uVar4 = 1;
        }
      }
    }
  }
  return uVar4;
}

// ==== CGooglePaymentsThread::helper_1400c7390  @1400c7390  [medium:callgraph-r2]  (orig: FUN_1400c7390)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400c7390(longlong param_1,char *param_2,int param_3,ulong *param_4)

{
  char cVar1;
  int iVar2;
  ulong uVar3;
  undefined8 uVar4;
  longlong lVar5;
  int iVar6;
  longlong lVar7;
  char *pcVar8;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined8 local_470;
  undefined4 local_468;
  undefined8 local_460;
  int local_458 [2];
  undefined8 local_450;
  char local_448 [1023];
  undefined1 local_49;
  ulonglong local_48;
  
  local_450 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if ((*(longlong *)(param_1 + 0xc18) == 0) || (*(longlong *)(param_1 + 0xc20) == 0)) {
    uVar4 = 0;
  }
  else {
    uVar4 = FUN_140329e80(param_1 + 8);
    FUN_140329e40(param_1 + 8);
    local_478 = uVar4;
    _snprintf(local_448,0x400,"%s%s");
    local_49 = 0;
    local_460 = 0;
    local_468 = 0x80000000;
    local_470 = 0;
    local_478 = 0;
    lVar5 = HttpOpenRequestA(*(undefined8 *)(param_1 + 0xc20),&DAT_1406fd240,local_448,"HTTP/1.1");
    if (lVar5 == 0) {
      log_InlineLogFACEBOOK("CHttpService::Post, failed in opening request");
      uVar4 = 0;
    }
    else {
      if ((param_2 != (char *)0x0) &&
         (iVar2 = HttpAddRequestHeadersA
                            (lVar5,"Content-Type: application/x-www-form-urlencoded",0x2f,0x10000000
                            ), iVar2 == 0)) {
        log_InlineLogFACEBOOK("CHttpService::Post, failed in adding header");
        return 0;
      }
      iVar2 = 0;
      if (param_2 != (char *)0x0) {
        lVar7 = -1;
        pcVar8 = param_2;
        do {
          if (lVar7 == 0) break;
          lVar7 = lVar7 + -1;
          cVar1 = *pcVar8;
          pcVar8 = pcVar8 + 1;
        } while (cVar1 != '\0');
        iVar6 = ~(uint)lVar7 - 1;
        iVar2 = param_3;
        if (iVar6 < param_3) {
          iVar2 = iVar6;
        }
      }
      local_478 = CONCAT44(local_478._4_4_,iVar2);
      iVar2 = HttpSendRequestA(lVar5,0,0,param_2);
      if (iVar2 == 0) {
        GetLastError();
        log_InlineLogFACEBOOK("CHttpService::Post, failed in sending request Error[%u]");
        InternetCloseHandle(lVar5);
        uVar4 = 0;
      }
      else {
        if (param_4 != (ulong *)0x0) {
          local_458[0] = param_3;
          memset(param_2,0,(longlong)param_3);
          local_478 = 0;
          iVar2 = HttpQueryInfoA(lVar5,0x13,param_2,local_458);
          if (iVar2 != 0) {
            uVar3 = strtoul(param_2,(char **)0x0,10);
            *param_4 = uVar3;
            memset(param_2,0,(longlong)param_3);
            local_458[0] = param_3;
            if ((*param_4 == 200) &&
               (iVar2 = InternetReadFile(lVar5,param_2,param_3,local_458), iVar2 == 0)) {
              GetLastError();
              log_InlineLogFACEBOOK("CHttpService::Post, failed in InternetReadFile Error[%u]");
            }
          }
        }
        InternetCloseHandle(lVar5);
        log_InlineLogFACEBOOK("CHttpService::Post, successfully");
        uVar4 = 1;
      }
    }
  }
  return uVar4;
}

// ==== CGooglePaymentsThread::helper_140329cd0  @140329cd0  [medium:callgraph-r3]  (orig: FUN_140329cd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140329cd0(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined1 auStack_ca8 [32];
  undefined4 local_c88 [2];
  undefined1 local_c80 [12];
  undefined4 local_c74;
  char *local_c70;
  undefined4 local_c68;
  ushort local_c64;
  char *local_c40;
  undefined4 local_c38;
  char *local_c30;
  undefined4 local_c28;
  char local_c18 [1024];
  char local_818 [1024];
  char local_418 [1024];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_ca8;
  if (param_2 != 0) {
    memset(local_c80,0,0x60);
    memset(local_c18,0,0x400);
    memset(local_818,0,0x400);
    memset(local_418,0,0x400);
    local_c70 = local_c18;
    local_c40 = local_818;
    local_c30 = local_418;
    local_c88[0] = 0x68;
    local_c68 = 0x400;
    local_c38 = 0x400;
    local_c28 = 0x400;
    iVar1 = InternetCrackUrlA(param_2,0,0x80000000,local_c88);
    if (iVar1 != 0) {
      *(undefined4 *)(param_1 + 8) = local_c74;
      *(uint *)(param_1 + 0x40c) = (uint)local_c64;
      strncpy((char *)(param_1 + 0xc),local_c18,0x400);
      strncpy((char *)(param_1 + 0x410),local_818,0x400);
      strncpy((char *)(param_1 + 0x810),local_418,0x400);
      return 1;
    }
  }
  return 0;
}

// ==== CGooglePaymentsThread::helper_140329e40  @140329e40  [medium:callgraph-r3]  (orig: FUN_140329e40)
longlong FUN_140329e40(longlong param_1)

{
  return param_1 + 0x410;
}

// ==== CGooglePaymentsThread::helper_140329e50  @140329e50  [medium:callgraph-r3]  (orig: FUN_140329e50)
longlong FUN_140329e50(longlong param_1)

{
  return param_1 + 0xc;
}

// ==== CGooglePaymentsThread::helper_140329e60  @140329e60  [medium:callgraph-r3]  (orig: FUN_140329e60)
undefined4 FUN_140329e60(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x40c);
}

// ==== CGooglePaymentsThread::helper_140329e80  @140329e80  [medium:callgraph-r3]  (orig: FUN_140329e80)
longlong FUN_140329e80(longlong param_1)

{
  return param_1 + 0x810;
}

