// ==== CCrossMsgExitServer::ctor_or_dtor  @1403f0820  [high:vtable-assign]  (orig: FUN_1403f0820)
undefined8 * FUN_1403f0820(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgExitServer::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgExitServer::ctor_or_dtor  @1403f0870  [high:vtable-assign]  (orig: FUN_1403f0870)
void FUN_1403f0870(undefined8 *param_1)

{
  *param_1 = CCrossMsgExitServer::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgExitServer::vfunc_1  @1403f08a0  [high:rtti-vtable]  (orig: FUN_1403f08a0)
undefined8 FUN_1403f08a0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgExitServer::ctor_or_dtor  @1403f0900  [high:vtable-assign]  (orig: FUN_1403f0900)
undefined8 * FUN_1403f0900(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgExitServer::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgExitServer::vfunc_3  @1403f0950  [high:rtti-vtable]  (orig: FUN_1403f0950)
void FUN_1403f0950(longlong param_1)

{
  short sVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if (*(short **)(param_1 + 0x428) != (short *)0x0) {
    sVar1 = **(short **)(param_1 + 0x428);
    if (sVar1 == 0) {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      lVar4 = (**(code **)(*plVar3 + 0x98))
                        (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar4 != 0) {
        FUN_1401c8990(lVar4,0);
      }
    }
    else if (sVar1 == 1) {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar3 = (longlong *)FUN_140087650(uVar2);
      lVar4 = (**(code **)(*plVar3 + 0x98))
                        (plVar3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
      if (lVar4 != 0) {
        FUN_1401c8990(lVar4,1);
        return;
      }
    }
  }
  return;
}

