// ==== CMsgIOSServerConfig::ctor_or_dtor  @1403686d0  [high:vtable-assign]  (orig: FUN_1403686d0)
undefined8 * FUN_1403686d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgIOSServerConfig::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgIOSServerConfig::ctor_or_dtor  @140368720  [high:vtable-assign]  (orig: FUN_140368720)
void FUN_140368720(undefined8 *param_1)

{
  *param_1 = CMsgIOSServerConfig::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgIOSServerConfig::vfunc_1  @140368750  [high:rtti-vtable]  (orig: FUN_140368750)
ulonglong FUN_140368750(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x41a);
}

// ==== CMsgIOSServerConfig::vfunc_3  @1403687d0  [high:rtti-vtable]  (orig: FUN_1403687d0)
void FUN_1403687d0(void)

{
                    /* WARNING: Could not recover jumptable at 0x0001403687d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogERROR("CMsgIOSServerConfig::Process Enter.");
  return;
}

// ==== CMsgIOSServerConfig::ctor_or_dtor  @1403687e0  [high:vtable-assign]  (orig: FUN_1403687e0)
undefined8 * FUN_1403687e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgIOSServerConfig::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

