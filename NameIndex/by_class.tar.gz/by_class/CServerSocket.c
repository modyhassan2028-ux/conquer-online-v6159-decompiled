// ==== CServerSocket::helper_1404f96b0  @1404f96b0  [medium:callgraph-r2]  (orig: FUN_1404f96b0)
undefined8 * FUN_1404f96b0(undefined8 *param_1,undefined8 *param_2,longlong *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if ((longlong)puVar2[3] < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < (longlong)puVar2[3])) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < (longlong)puVar2[3]) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CServerSocket::helper_1404fae40  @1404fae40  [medium:callgraph-r1]  (orig: FUN_1404fae40)
longlong FUN_1404fae40(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1404f96b0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1404fa310(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CServerSocket::helper_1404fc390  @1404fc390  [medium:callgraph-r0]  (orig: FUN_1404fc390)
void FUN_1404fc390(longlong param_1,undefined8 param_2)

{
  undefined8 local_res10 [3];
  
  local_res10[0] = param_2;
  FUN_1404fae40(param_1 + 0x138,local_res10);
  return;
}

// ==== CServerSocket::ctor_or_dtor  @1404fff40  [high:vtable-assign]  (orig: FUN_1404fff40)
void FUN_1404fff40(undefined8 *param_1)

{
  *param_1 = CServerSocket::vftable;
  if (param_1[0x121] != 0) {
    FUN_140544e70();
    param_1[0x121] = 0;
    param_1[0x120] = 0xffffffffffffffff;
  }
  param_1[0x119] = tq::CString::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0x11a));
  FUN_140503a80((longlong)param_1 + 0x824);
  *param_1 = IServerSocket::vftable;
  return;
}

// ==== CServerSocket::vfunc_1  @140500120  [high:rtti-vtable]  (orig: FUN_140500120)
longlong FUN_140500120(longlong param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 8);
  return param_1 + 0x1b;
}

// ==== CServerSocket::vfunc_14  @140500370  [high:rtti-vtable]  (orig: FUN_140500370)
void FUN_140500370(longlong param_1)

{
  *(undefined1 *)(param_1 + 0x18) = 1;
  return;
}

// ==== CServerSocket::vfunc_15  @140500380  [high:rtti-vtable]  (orig: FUN_140500380)
void FUN_140500380(longlong param_1)

{
  if (*(char *)(param_1 + 0x18) != '\0') {
    *(int *)(param_1 + 0x10) = *(int *)(param_1 + 0x10) + 1;
  }
  return;
}

// ==== CServerSocket::vfunc_13  @140500390  [high:rtti-vtable]  (orig: FUN_140500390)
void FUN_140500390(longlong param_1)

{
  if (*(int *)(param_1 + 0xc) < *(int *)(param_1 + 0x10)) {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0x10);
  }
  *(undefined4 *)(param_1 + 0x10) = 0;
  return;
}

// ==== CServerSocket::vfunc_9  @1405003b0  [high:rtti-vtable]  (orig: FUN_1405003b0)
undefined4 FUN_1405003b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CServerSocket::vfunc_2  @1405003c0  [high:rtti-vtable]  (orig: FUN_1405003c0)
undefined8 FUN_1405003c0(longlong param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 8) < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar2 = *(int *)(param_1 + 8) - param_2;
  if (0 < iVar2) {
    memcpy((void *)(param_1 + 0x1b),(void *)((longlong)param_2 + 0x1b + param_1),(longlong)iVar2);
  }
  piVar1 = (int *)(param_1 + 8);
  *piVar1 = *piVar1 - param_2;
  if (*piVar1 < 0) {
    *(undefined4 *)(param_1 + 8) = 0;
    return 0;
  }
  return 1;
}

// ==== CServerSocket::vfunc_4  @140500450  [high:rtti-vtable]  (orig: FUN_140500450)
bool FUN_140500450(longlong param_1)

{
  return *(longlong *)(param_1 + 0x900) != -1;
}

// ==== CServerSocket::vfunc_5  @140500460  [high:rtti-vtable]  (orig: FUN_140500460)
void FUN_140500460(longlong *param_1)

{
  undefined8 uVar1;
  
  if ((param_1[0x11f] != 0) && (*(int *)((longlong)param_1 + 0x14) == 0)) {
    uVar1 = (**(code **)(*param_1 + 0x38))();
    FUN_1404fc390(param_1[0x11f],uVar1);
  }
  if (param_1[0x121] != 0) {
    FUN_140544e70();
    param_1[0x121] = 0;
    param_1[0x120] = -1;
  }
  return;
}

// ==== CServerSocket::vfunc_6  @1405004d0  [high:rtti-vtable]  (orig: FUN_1405004d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_1405004d0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined1 auStack_48 [32];
  undefined4 local_28 [2];
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  ulonglong local_10;
  
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_48;
  cVar1 = (**(code **)(*param_1 + 0x20))();
  if (cVar1 != '\0') {
    local_20 = 0;
    local_1c = 0;
    local_18 = 0;
    local_14 = 0;
    local_28[0] = 0x10;
    iVar2 = Ordinal_5(param_1[0x120],&local_20,local_28);
    if (iVar2 == 0) {
      return local_1c;
    }
    (**(code **)(*param_1 + 0x28))(param_1);
  }
  return 0;
}

// ==== CServerSocket::vfunc_16  @140500560  [high:rtti-vtable]  (orig: FUN_140500560)
undefined8 FUN_140500560(longlong *param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  int local_res8 [2];
  
  cVar1 = (**(code **)(*param_1 + 0x20))();
  if (cVar1 == '\0') {
    return 0;
  }
  if ((param_2 == 0) ||
     (local_res8[0] = param_2, iVar2 = Ordinal_21(param_1[0x120],0xffff,0x1001,local_res8,4),
     iVar2 == 0)) {
    if (param_3 == 0) {
      return 1;
    }
    local_res8[0] = param_3;
    iVar2 = Ordinal_21(param_1[0x120],0xffff,0x1002,local_res8,4);
    if (iVar2 == 0) {
      return 1;
    }
    FUN_140545950(param_1[0x120]);
    pcVar3 = "setsockopt() set SO_RCVBUF failed[%d].";
  }
  else {
    FUN_140545950(param_1[0x120]);
    pcVar3 = "setsockopt() set SO_SNDBUF failed[%d].";
  }
  log_InlineLogERROR(pcVar3);
  (**(code **)(*param_1 + 0x28))(param_1);
  return 0;
}

// ==== CServerSocket::vfunc_3  @140500670  [high:rtti-vtable]  (orig: FUN_140500670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140500670(longlong *param_1,undefined8 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  longlong lVar4;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined8 local_480;
  ulong local_478;
  char *local_470;
  undefined4 local_468;
  char local_458 [32];
  undefined1 local_438 [1040];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar4 = (longlong)param_3;
  cVar1 = (**(code **)(*param_1 + 0x20))();
  if ((cVar1 == '\0') || (0x400 < param_3)) {
    return 0;
  }
  if (*(int *)((longlong)param_1 + 0x14) == 0) {
    if (*(char *)((longlong)param_1 + 0x1a) != '\0') {
      local_438[0] = 0;
      memset(local_438 + 1,0,0x407);
      cVar1 = FUN_140504b80((longlong)param_1 + 0x824,param_2,local_438,param_3);
      if (cVar1 == '\0') {
        local_488 = (longlong *)CONCAT44(local_488._4_4_,0x2a2);
      }
      else {
        cVar1 = FUN_140504b80((longlong)param_1 + 0x824,"TQServer",local_438 + lVar4,8);
        if (cVar1 != '\0') {
          iVar2 = FUN_140544000(param_1[0x121],local_438,(longlong)(param_3 + 8));
          if (-1 < iVar2) {
            return 1;
          }
          iVar2 = FUN_140545950(param_1[0x120]);
          if ((iVar2 != 0x2733) && (iVar2 != 0x2746)) {
            if ((ulonglong)param_1[0x11e] < 0x10) {
              local_488 = param_1 + 0x11b;
            }
            else {
              local_488 = (longlong *)param_1[0x11b];
            }
            local_478 = 0x2c4;
            local_480 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\serversocket.cpp";
            tq::SysLogSave("socket",&DAT_140796400);
            (**(code **)(*param_1 + 0x28))(param_1);
            return 0;
          }
          goto LAB_1405009bb;
        }
        local_488 = (longlong *)CONCAT44(local_488._4_4_,0x2ae);
      }
      tq::SysLogSave("socket","socket:%lu, m_Security.EncryptData() encrypt data failed at %s, %d");
      (**(code **)(*param_1 + 0x28))(param_1);
      return 0;
    }
    iVar2 = FUN_140544000(param_1[0x121],param_2,lVar4);
    if (iVar2 < 0) {
      iVar2 = FUN_140545950(param_1[0x120]);
      local_458[0] = '\0';
      local_458[1] = '\0';
      local_458[2] = '\0';
      local_458[3] = '\0';
      local_458[4] = '\0';
      local_458[5] = '\0';
      local_458[6] = '\0';
      local_458[7] = '\0';
      local_458[8] = '\0';
      local_458[9] = '\0';
      local_458[10] = '\0';
      local_458[0xb] = '\0';
      local_458[0xc] = '\0';
      local_458[0xd] = '\0';
      local_458[0xe] = '\0';
      local_458[0xf] = '\0';
      local_458[0x10] = '\0';
      local_458[0x11] = '\0';
      local_458[0x12] = '\0';
      local_458[0x13] = '\0';
      local_458[0x14] = '\0';
      local_458[0x15] = '\0';
      local_458[0x16] = '\0';
      local_458[0x17] = '\0';
      local_458[0x18] = '\0';
      local_458[0x19] = '\0';
      local_458[0x1a] = '\0';
      local_458[0x1b] = '\0';
      local_458[0x1c] = '\0';
      local_458[0x1d] = 0;
      uVar3 = (**(code **)(*param_1 + 0x30))(param_1);
      if (uVar3 != 0) {
        local_478 = uVar3 >> 0x18;
        local_480 = (char *)(CONCAT44(local_480._4_4_,uVar3 >> 0x10) & 0xffffffff000000ff);
        local_488 = (longlong *)(CONCAT44(local_488._4_4_,uVar3 >> 8) & 0xffffffff000000ff);
        sprintf_s(local_458,0x1e,"%d.%d.%d.%d");
      }
      if ((iVar2 != 0x2733) && (iVar2 != 0x2746)) {
        local_478 = tq::TimeGet(0);
        local_468 = 0x2f3;
        local_470 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\serversocket.cpp";
        local_480 = (char *)CONCAT44(local_480._4_4_,iVar2);
        local_488 = (longlong *)CONCAT44(local_488._4_4_,param_3);
        tq::SysLogSave("socket",&DAT_1407963a0);
      }
LAB_1405009bb:
      (**(code **)(*param_1 + 0x28))(param_1);
      return 0;
    }
  }
  else {
    if (1 < *(int *)((longlong)param_1 + 0x14) - 1U) {
      tq::TimeGet(0);
      tq::SysLogSave("socket",&DAT_140796498);
      (**(code **)(*param_1 + 0x28))(param_1);
      return 0;
    }
    iVar2 = FUN_140544000(param_1[0x121],param_2,lVar4);
    if (iVar2 < 0) {
      iVar2 = FUN_140545950(param_1[0x120]);
      if ((iVar2 != 0x2733) && (iVar2 != 0x2746)) {
        local_478 = tq::TimeGet(0);
        local_468 = 0x314;
        local_470 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\serversocket.cpp";
        local_480 = (char *)CONCAT44(local_480._4_4_,iVar2);
        local_488 = (longlong *)CONCAT44(local_488._4_4_,param_3);
        tq::SysLogSave("socket",&DAT_1407964d0);
      }
      (**(code **)(*param_1 + 0x28))(param_1);
      return 0;
    }
  }
  return 1;
}

// ==== CServerSocket::vfunc_11  @1405009f0  [high:rtti-vtable]  (orig: FUN_1405009f0)
undefined1 FUN_1405009f0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x1a);
}

// ==== CServerSocket::vfunc_8  @140500a00  [high:rtti-vtable]  (orig: FUN_140500a00)
undefined4 FUN_140500a00(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x81c);
}

// ==== CServerSocket::vfunc_18  @140500a10  [high:rtti-vtable]  (orig: FUN_140500a10)
void FUN_140500a10(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x81c) = param_2;
  return;
}

// ==== CServerSocket::vfunc_10  @140500a20  [high:rtti-vtable]  (orig: FUN_140500a20)
undefined4 FUN_140500a20(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x820);
}

// ==== CServerSocket::vfunc_12  @140500a40  [high:rtti-vtable]  (orig: FUN_140500a40)
undefined1 FUN_140500a40(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x19);
}

// ==== CServerSocket::vfunc_17  @140500a50  [high:rtti-vtable]  (orig: FUN_140500a50)
void FUN_140500a50(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x19) = param_2;
  return;
}

// ==== CServerSocket::vfunc_19  @140500a60  [high:rtti-vtable]  (orig: FUN_140500a60)
void FUN_140500a60(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x8c0) = param_2;
  return;
}

// ==== CServerSocket::vfunc_7  @140500af0  [high:rtti-vtable]  (orig: FUN_140500af0)
undefined8 FUN_140500af0(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x900);
}

// ==== CServerSocket::helper_140500bc0  @140500bc0  [medium:callgraph-r0]  (orig: FUN_140500bc0)
void FUN_140500bc0(void *param_1)

{
  if ((DAT_140976580 & 1) == 0) {
    DAT_140976580 = DAT_140976580 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976578,"CServerSocket");
    atexit((_func_5014 *)&LAB_1406d6f60);
  }
                    /* WARNING: Could not recover jumptable at 0x000140500c15. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976578,param_1);
  return;
}

// ==== CServerSocket::ctor_or_dtor  @140500d30  [high:vtable-assign]  (orig: FUN_140500d30)
undefined8 *
FUN_140500d30(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined4 param_4)

{
  ulong uVar1;
  
  *param_1 = IServerSocket::vftable;
  *param_1 = CServerSocket::vftable;
  FUN_140503a60((longlong)param_1 + 0x824);
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 0x11a));
  param_1[0x119] = tq::CString::vftable;
  param_1[0x11f] = param_2;
  param_1[0x120] = param_3;
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined1 *)((longlong)param_1 + 0x1a) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = param_4;
  param_1[0x121] = 0;
  *(undefined1 *)((longlong)param_1 + 0x19) = 0;
  *(undefined4 *)((longlong)param_1 + 0x81c) = 0;
  uVar1 = tq::TimeGet(0);
  *(ulong *)(param_1 + 0x104) = uVar1;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x118) = 0xffffffff;
  memset((void *)((longlong)param_1 + 0x1b),0,0x800);
  return param_1;
}

// ==== CServerSocket::vfunc_0  @140500e30  [high:rtti-vtable]  (orig: FUN_140500e30)
undefined8 FUN_140500e30(undefined8 param_1,uint param_2)

{
  FUN_1404fff40();
  if ((param_2 & 1) != 0) {
    FUN_140500bc0(param_1);
  }
  return param_1;
}

// ==== CServerSocket::helper_140503a60  @140503a60  [medium:callgraph-r0]  (orig: FUN_140503a60)
undefined4 * FUN_140503a60(undefined4 *param_1)

{
  *(undefined8 *)(param_1 + 4) = 0;
  param_1[1] = 0;
  *(undefined8 *)(param_1 + 2) = 0;
  *param_1 = 0;
  return param_1;
}

// ==== CServerSocket::helper_140503a80  @140503a80  [medium:callgraph-r0]  (orig: FUN_140503a80)
void FUN_140503a80(void)

{
  return;
}

// ==== CServerSocket::helper_140504b80  @140504b80  [medium:callgraph-r0]  (orig: FUN_140504b80)
undefined8 FUN_140504b80(longlong param_1,longlong param_2,longlong param_3,int param_4)

{
  if ((((DAT_140976588 != '\0') && (DAT_140976590 != 0)) && (param_3 != 0)) &&
     ((param_2 != 0 && (0 < param_4)))) {
    CAST_cfb64_encrypt(param_2,param_3,param_4,param_1 + 0x18,param_1 + 0x10,param_1 + 4,1);
    return 1;
  }
  return 0;
}

