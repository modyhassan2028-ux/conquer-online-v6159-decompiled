// ==== CMsgSyncAction::ctor_or_dtor  @1403ece80  [high:vtable-assign]  (orig: FUN_1403ece80)
undefined8 * FUN_1403ece80(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSyncAction::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSyncAction::ctor_or_dtor  @1403eced0  [high:vtable-assign]  (orig: FUN_1403eced0)
void FUN_1403eced0(undefined8 *param_1)

{
  *param_1 = CMsgSyncAction::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSyncAction::ctor_or_dtor  @1403ecfc0  [high:vtable-assign]  (orig: FUN_1403ecfc0)
undefined8 * FUN_1403ecfc0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSyncAction::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

