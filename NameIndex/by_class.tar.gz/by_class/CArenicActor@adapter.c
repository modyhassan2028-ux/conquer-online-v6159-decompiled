// ==== CArenicActor@adapter::helper_140118d90  @140118d90  [medium:callgraph-r3]  (orig: FUN_140118d90)
void FUN_140118d90(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CArenicActor@adapter::helper_14011d730  @14011d730  [medium:callgraph-r3]  (orig: FUN_14011d730)
void FUN_14011d730(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CArenicActor@adapter::helper_14011e490  @14011e490  [medium:callgraph-r3]  (orig: FUN_14011e490)
void * FUN_14011e490(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 3;
  _Dst = (void *)(param_3 + lVar1 * -8);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 8,param_1,lVar1 * 8);
  }
  return _Dst;
}

// ==== CArenicActor@adapter::helper_140126f20  @140126f20  [medium:callgraph-r3]  (orig: FUN_140126f20)
void * FUN_140126f20(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 3;
  _DstSize = lVar1 * 8;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CArenicActor@adapter::helper_14013adb0  @14013adb0  [medium:callgraph-r2]  (orig: FUN_14013adb0)
void FUN_14013adb0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140118d90();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_14011d730(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_140126f20(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_140126f20(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_14011e490(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CArenicActor@adapter::helper_14013b490  @14013b490  [medium:callgraph-r1]  (orig: FUN_14013b490)
longlong * FUN_14013b490(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14013adb0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14013b584;
  }
  _invalid_parameter_noinfo();
LAB_14013b584:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CArenicActor@adapter::helper_14013b730  @14013b730  [medium:callgraph-r0]  (orig: FUN_14013b730)
void FUN_14013b730(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14013b490(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CArenicActor@adapter::helper_1401657f0  @1401657f0  [medium:callgraph-r0]  (orig: FUN_1401657f0)
void FUN_1401657f0(longlong param_1)

{
  FUN_1403732d0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165800  @140165800  [medium:callgraph-r0]  (orig: FUN_140165800)
void FUN_140165800(longlong param_1)

{
  FUN_1403732e0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165810  @140165810  [medium:callgraph-r0]  (orig: FUN_140165810)
void FUN_140165810(longlong param_1)

{
  FUN_140373350(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165820  @140165820  [medium:callgraph-r0]  (orig: FUN_140165820)
void FUN_140165820(longlong param_1)

{
  FUN_140373360(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165830  @140165830  [medium:callgraph-r0]  (orig: FUN_140165830)
void FUN_140165830(longlong param_1)

{
  FUN_1403733d0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165840  @140165840  [medium:callgraph-r0]  (orig: FUN_140165840)
void FUN_140165840(longlong param_1)

{
  FUN_1403733e0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165850  @140165850  [medium:callgraph-r0]  (orig: FUN_140165850)
void FUN_140165850(longlong param_1)

{
  FUN_140373450(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165860  @140165860  [medium:callgraph-r0]  (orig: FUN_140165860)
void FUN_140165860(longlong param_1)

{
  FUN_140373460(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165870  @140165870  [medium:callgraph-r0]  (orig: FUN_140165870)
void FUN_140165870(longlong param_1)

{
  FUN_1403734d0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_140165880  @140165880  [medium:callgraph-r0]  (orig: FUN_140165880)
void FUN_140165880(longlong param_1)

{
  FUN_1403734e0(param_1 + 0xe78);
  return;
}

// ==== CArenicActor@adapter::helper_1403732d0  @1403732d0  [medium:callgraph-r1]  (orig: FUN_1403732d0)
undefined4 FUN_1403732d0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x174);
}

// ==== CArenicActor@adapter::helper_140373350  @140373350  [medium:callgraph-r1]  (orig: FUN_140373350)
undefined4 FUN_140373350(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x17c);
}

// ==== CArenicActor@adapter::helper_140373360  @140373360  [medium:callgraph-r1]  (orig: FUN_140373360)
void FUN_140373360(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x17c) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"athlete_history_wins");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CArenicActor@adapter::helper_1403733d0  @1403733d0  [medium:callgraph-r1]  (orig: FUN_1403733d0)
undefined4 FUN_1403733d0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x180);
}

// ==== CArenicActor@adapter::helper_1403733e0  @1403733e0  [medium:callgraph-r1]  (orig: FUN_1403733e0)
void FUN_1403733e0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x180) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"athlete_history_loses");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CArenicActor@adapter::helper_140373450  @140373450  [medium:callgraph-r1]  (orig: FUN_140373450)
undefined4 FUN_140373450(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x184);
}

// ==== CArenicActor@adapter::helper_140373460  @140373460  [medium:callgraph-r1]  (orig: FUN_140373460)
void FUN_140373460(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x184) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"athlete_day_wins");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CArenicActor@adapter::helper_1403734d0  @1403734d0  [medium:callgraph-r1]  (orig: FUN_1403734d0)
undefined4 FUN_1403734d0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x188);
}

// ==== CArenicActor@adapter::helper_1403734e0  @1403734e0  [medium:callgraph-r1]  (orig: FUN_1403734e0)
void FUN_1403734e0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x188) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"athlete_day_loses");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_1  @1405a5a30  [high:rtti-vtable]  (orig: FUN_1405a5a30)
void FUN_1405a5a30(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_7  @1405a5a50  [high:rtti-vtable]  (orig: FUN_1405a5a50)
undefined8 FUN_1405a5a50(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165970(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_8  @1405a5ab0  [high:rtti-vtable]  (orig: FUN_1405a5ab0)
undefined8 FUN_1405a5ab0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a5b03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_9  @1405a5b10  [high:rtti-vtable]  (orig: FUN_1405a5b10)
undefined8 FUN_1405a5b10(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a5b61. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_10  @1405a5b70  [high:rtti-vtable]  (orig: FUN_1405a5b70)
int FUN_1405a5b70(undefined8 param_1,ulonglong param_2)

{
  ulonglong uVar1;
  
  uVar1 = (param_2 & 0xffffffff) / 1000;
  return (int)uVar1 + (int)(uVar1 / 10) * -10;
}

// ==== CArenicActor@adapter::vfunc_11  @1405a5ba0  [high:rtti-vtable]  (orig: FUN_1405a5ba0)
undefined8 FUN_1405a5ba0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a5bf3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_53  @1405a5c00  [high:rtti-vtable]  (orig: FUN_1405a5c00)
void FUN_1405a5c00(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165820(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_54  @1405a5c60  [high:rtti-vtable]  (orig: FUN_1405a5c60)
void FUN_1405a5c60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165840(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_55  @1405a5cc0  [high:rtti-vtable]  (orig: FUN_1405a5cc0)
void FUN_1405a5cc0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165860(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_56  @1405a5d20  [high:rtti-vtable]  (orig: FUN_1405a5d20)
void FUN_1405a5d20(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165880(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_57  @1405a5d80  [high:rtti-vtable]  (orig: FUN_1405a5d80)
void FUN_1405a5d80(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165800(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_58  @1405a5de0  [high:rtti-vtable]  (orig: FUN_1405a5de0)
void FUN_1405a5de0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140165950(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_59  @1405a5e40  [high:rtti-vtable]  (orig: FUN_1405a5e40)
void FUN_1405a5e40(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140177500(lVar1,param_3,1);
  return;
}

// ==== CArenicActor@adapter::vfunc_52  @1405a5ea0  [high:rtti-vtable]  (orig: FUN_1405a5ea0)
void FUN_1405a5ea0(void)

{
  return;
}

// ==== CArenicActor@adapter::vfunc_67  @1405a5eb0  [high:rtti-vtable]  (orig: FUN_1405a5eb0)
undefined8 FUN_1405a5eb0(void)

{
  return 0;
}

// ==== CArenicActor@adapter::vfunc_60  @1405a5ec0  [high:rtti-vtable]  (orig: FUN_1405a5ec0)
undefined8 FUN_1405a5ec0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165810(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_61  @1405a5f20  [high:rtti-vtable]  (orig: FUN_1405a5f20)
undefined8 FUN_1405a5f20(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165830(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_62  @1405a5f80  [high:rtti-vtable]  (orig: FUN_1405a5f80)
undefined8 FUN_1405a5f80(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165850(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_63  @1405a5fe0  [high:rtti-vtable]  (orig: FUN_1405a5fe0)
undefined8 FUN_1405a5fe0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165870(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_64  @1405a6040  [high:rtti-vtable]  (orig: FUN_1405a6040)
undefined8 FUN_1405a6040(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165940(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_65  @1405a60a0  [high:rtti-vtable]  (orig: FUN_1405a60a0)
undefined8 FUN_1405a60a0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140165930(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_66  @1405a6100  [high:rtti-vtable]  (orig: FUN_1405a6100)
undefined8 FUN_1405a6100(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1401657f0(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_4  @1405a6160  [high:rtti-vtable]  (orig: FUN_1405a6160)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405a6160(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x101);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xffff00;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CArenicActor@adapter::vfunc_5  @1405a62c0  [high:rtti-vtable]  (orig: FUN_1405a62c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405a62c0(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x11b);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CArenicActor@adapter::vfunc_6  @1405a6420  [high:rtti-vtable]  (orig: FUN_1405a6420)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405a6420(longlong param_1,undefined2 param_2,undefined4 param_3,int param_4)

{
  char cVar1;
  undefined1 uVar2;
  longlong lVar3;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),param_3);
  if (lVar3 == 0) {
    local_4a8 = 0x12f;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_140362560(local_488);
    cVar1 = FUN_140362910(local_488,param_2,param_3,(longlong)param_4);
    if (cVar1 == '\0') {
      FUN_1403625e0(local_488);
      uVar2 = 0;
    }
    else {
      uVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))
                        ((longlong *)(lVar3 + 0x10),local_488);
      FUN_1403625e0(local_488);
    }
  }
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_22  @1405a6510  [high:rtti-vtable]  (orig: FUN_1405a6510)
bool FUN_1405a6510(longlong param_1)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_140166ec0(lVar2);
  return iVar1 != 0;
}

// ==== CArenicActor@adapter::vfunc_43  @1405a6570  [high:rtti-vtable]  (orig: FUN_1405a6570)
undefined8 FUN_1405a6570(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a65c3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_20  @1405a65d0  [high:rtti-vtable]  (orig: FUN_1405a65d0)
undefined8 FUN_1405a65d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14018eb30(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_21  @1405a6630  [high:rtti-vtable]  (orig: FUN_1405a6630)
ulonglong FUN_1405a6630(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a66a1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_12  @1405a66b0  [high:rtti-vtable]  (orig: FUN_1405a66b0)
undefined1 * FUN_1405a66b0(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6708. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CArenicActor@adapter::vfunc_13  @1405a6710  [high:rtti-vtable]  (orig: FUN_1405a6710)
undefined8 FUN_1405a6710(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6763. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_14  @1405a6770  [high:rtti-vtable]  (orig: FUN_1405a6770)
undefined1 FUN_1405a6770(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CArenicActor@adapter::vfunc_17  @1405a67d0  [high:rtti-vtable]  (orig: FUN_1405a67d0)
bool FUN_1405a67d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CArenicActor@adapter::vfunc_18  @1405a67f0  [high:rtti-vtable]  (orig: FUN_1405a67f0)
ulonglong FUN_1405a67f0(longlong param_1,int param_2)

{
  ulonglong in_RAX;
  longlong lVar1;
  ulonglong uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    in_RAX = 0;
    if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405a681d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x250))(lVar1 + 0x10);
      return uVar2;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CArenicActor@adapter::vfunc_19  @1405a6830  [high:rtti-vtable]  (orig: FUN_1405a6830)
void FUN_1405a6830(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401732e0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CArenicActor@adapter::vfunc_15  @1405a68b0  [high:rtti-vtable]  (orig: FUN_1405a68b0)
undefined8 FUN_1405a68b0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6903. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_16  @1405a6910  [high:rtti-vtable]  (orig: FUN_1405a6910)
undefined8 FUN_1405a6910(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6963. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_23  @1405a6970  [high:rtti-vtable]  (orig: FUN_1405a6970)
ulonglong FUN_1405a6970(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7e10(lVar1,param_3);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_25  @1405a69d0  [high:rtti-vtable]  (orig: FUN_1405a69d0)
ulonglong FUN_1405a69d0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6a23. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_26  @1405a6a30  [high:rtti-vtable]  (orig: FUN_1405a6a30)
void FUN_1405a6a30(longlong param_1,undefined8 param_2,undefined1 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  uint in_stack_ffffffffffffffe8;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401c6d40(lVar1,param_3,param_4,param_5,in_stack_ffffffffffffffe8 & 0xffffff00);
  return;
}

// ==== CArenicActor@adapter::vfunc_27  @1405a6ab0  [high:rtti-vtable]  (orig: FUN_1405a6ab0)
undefined8 FUN_1405a6ab0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_28  @1405a6b10  [high:rtti-vtable]  (orig: FUN_1405a6b10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405a6b10(longlong param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    local_498 = 0x24f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140161fa0(lVar2,param_3);
    FUN_140362560(local_478);
    cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
    if (cVar1 != '\0') {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
    }
    FUN_1403625e0(local_478);
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_29  @1405a6bf0  [high:rtti-vtable]  (orig: FUN_1405a6bf0)
void FUN_1405a6bf0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401a6420(lVar1,param_3,param_4,param_5);
  return;
}

// ==== CArenicActor@adapter::vfunc_30  @1405a6c70  [high:rtti-vtable]  (orig: FUN_1405a6c70)
void FUN_1405a6c70(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_140162110(lVar1,1,param_3);
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_31  @1405a6cb0  [high:rtti-vtable]  (orig: FUN_1405a6cb0)
undefined8 FUN_1405a6cb0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6d03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_32  @1405a6d10  [high:rtti-vtable]  (orig: FUN_1405a6d10)
undefined8 FUN_1405a6d10(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6d61. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x88))(plVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_33  @1405a6d70  [high:rtti-vtable]  (orig: FUN_1405a6d70)
undefined8 FUN_1405a6d70(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1403837b0(lVar1);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_37  @1405a6dd0  [high:rtti-vtable]  (orig: FUN_1405a6dd0)
ulonglong FUN_1405a6dd0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_38  @1405a6e50  [high:rtti-vtable]  (orig: FUN_1405a6e50)
undefined8
FUN_1405a6e50(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
             undefined1 param_5,undefined1 param_6)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140340e50(lVar1,param_3,param_4,param_5,1,0,param_6);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_39  @1405a6ef0  [high:rtti-vtable]  (orig: FUN_1405a6ef0)
undefined8 FUN_1405a6ef0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6f43. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_69  @1405a6f50  [high:rtti-vtable]  (orig: FUN_1405a6f50)
ulonglong FUN_1405a6f50(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a6fe7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x248))(plVar1,param_2);
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_70  @1405a6ff0  [high:rtti-vtable]  (orig: FUN_1405a6ff0)
undefined1 * FUN_1405a6ff0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined1 *puVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x16);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a7091. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*plVar1 + 0x290))(plVar1,param_2);
  return puVar2;
}

// ==== CArenicActor@adapter::vfunc_41  @1405a70a0  [high:rtti-vtable]  (orig: FUN_1405a70a0)
void FUN_1405a70a0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x0001405a70ba. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2);
  return;
}

// ==== CArenicActor@adapter::vfunc_40  @1405a70c0  [high:rtti-vtable]  (orig: FUN_1405a70c0)
void FUN_1405a70c0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar2 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x0001405a7122. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar2 + 0x10))(plVar2,param_2,2);
  return;
}

// ==== CArenicActor@adapter::vfunc_35  @1405a7130  [high:rtti-vtable]  (orig: FUN_1405a7130)
undefined8 FUN_1405a7130(undefined8 param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)CurrentInstanceGet();
  if (plVar3 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x22);
  if (plVar3 == (longlong *)0x0) {
    return 0;
  }
  cVar1 = (**(code **)(*plVar3 + 0x128))(plVar3,param_2);
  if (cVar1 == '\0') {
    iVar2 = (**(code **)(*plVar3 + 0x130))(plVar3,param_2);
    if (iVar2 == 0) {
      return 0;
    }
    if (iVar2 == 5) {
      return 0;
    }
  }
  return 1;
}

// ==== CArenicActor@adapter::vfunc_34  @1405a71e0  [high:rtti-vtable]  (orig: FUN_1405a71e0)
void FUN_1405a71e0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar3 = (longlong *)FUN_1401181a0();
  cVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2,0x6a);
  if (cVar1 != '\0') {
    plVar3 = (longlong *)FUN_1401181a0();
    (**(code **)(*plVar3 + 0x10))(plVar3,param_2,0x6a);
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_24  @1405a7270  [high:rtti-vtable]  (orig: FUN_1405a7270)
undefined8 FUN_1405a7270(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_1401a4030(lVar2,param_3);
  if (cVar1 == '\0') {
    FUN_140179040(lVar2,param_3);
    return 0;
  }
  return 1;
}

// ==== CArenicActor@adapter::vfunc_73  @1405a7300  [high:rtti-vtable]  (orig: FUN_1405a7300)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a7300(undefined8 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_148 [32];
  undefined4 local_128;
  undefined8 local_120;
  char local_118;
  undefined1 local_117 [254];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    local_118 = '\0';
    memset(local_117,0,0xff);
    local_128 = param_3;
    _snprintf(&local_118,0x100,"</F>UserArenicWins</N>%lu</N>%u");
    local_19 = 0;
    lVar3 = DAT_140975bf0;
    if (DAT_140975bf0 == 0) {
      local_128 = 0x3cd;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    local_120 = 0;
    local_128 = 0;
    cVar1 = FUN_140286530(lVar3,&local_118,param_2,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                ("Lua return fault, Call From:CArenicActor::OnUserArenicWin, lua function:%s.");
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_74  @1405a7400  [high:rtti-vtable]  (orig: FUN_1405a7400)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a7400(undefined8 param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_148 [32];
  undefined4 local_128;
  undefined8 local_120;
  char local_118;
  undefined1 local_117 [254];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_148;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    local_118 = '\0';
    memset(local_117,0,0xff);
    local_128 = param_3;
    _snprintf(&local_118,0x100,"</F>UserArenicCompetes</N>%lu</N>%u");
    local_19 = 0;
    lVar3 = DAT_140975bf0;
    if (DAT_140975bf0 == 0) {
      local_128 = 0x3cd;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    local_120 = 0;
    local_128 = 0;
    cVar1 = FUN_140286530(lVar3,&local_118,param_2,0);
    if (cVar1 == '\0') {
      log_InlineLogLuaERROR
                ("Lua return fault, Call From:CArenicActor::OnUserArenicCompete, lua function:%s.");
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CArenicActor@adapter::vfunc_0  @1405a7500  [high:rtti-vtable]  (orig: FUN_1405a7500)
void FUN_1405a7500(longlong param_1)

{
  FUN_1405a7560(param_1 + -8);
  return;
}

// ==== CArenicActor@adapter::helper_1405a7560  @1405a7560  [medium:callgraph-r0]  (orig: FUN_1405a7560)
undefined8 * FUN_1405a7560(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CArenicActor::vftable;
  param_1[1] = adapter::CArenicActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CArenicActor@adapter::vfunc_3  @1405a7660  [high:rtti-vtable]  (orig: FUN_1405a7660)
void FUN_1405a7660(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_45  @1405a7720  [high:rtti-vtable]  (orig: FUN_1405a7720)
bool FUN_1405a7720(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CArenicActor@adapter::vfunc_46  @1405a77a0  [high:rtti-vtable]  (orig: FUN_1405a77a0)
ulonglong FUN_1405a77a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x14) & 1);
}

// ==== CArenicActor@adapter::vfunc_47  @1405a7870  [high:rtti-vtable]  (orig: FUN_1405a7870)
ulonglong FUN_1405a7870(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x1e) & 1);
}

// ==== CArenicActor@adapter::vfunc_48  @1405a7940  [high:rtti-vtable]  (orig: FUN_1405a7940)
ulonglong FUN_1405a7940(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 2) & 1);
}

// ==== CArenicActor@adapter::vfunc_49  @1405a7a10  [high:rtti-vtable]  (orig: FUN_1405a7a10)
void FUN_1405a7a10(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a7a71. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0xf8))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CArenicActor@adapter::vfunc_50  @1405a7a80  [high:rtti-vtable]  (orig: FUN_1405a7a80)
ulonglong FUN_1405a7a80(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (ulonglong)((uint)(uVar3 >> 0x15) & 1);
}

// ==== CArenicActor@adapter::vfunc_51  @1405a7b50  [high:rtti-vtable]  (orig: FUN_1405a7b50)
void FUN_1405a7b50(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a7ba4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x80))();
  return;
}

// ==== CArenicActor@adapter::vfunc_36  @1405a7bb0  [high:rtti-vtable]  (orig: FUN_1405a7bb0)
undefined8 FUN_1405a7bb0(longlong param_1)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  uint in_stack_ffffffffffffffd8;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar1 = *(undefined2 *)(lVar5 + 0xf0e);
  uVar2 = *(undefined2 *)(lVar5 + 0xf0c);
  uVar3 = FUN_140161f50(lVar5);
  in_stack_ffffffffffffffd8 = in_stack_ffffffffffffffd8 & 0xffffff00;
  iVar4 = FUN_1401c55b0(lVar5,uVar3,uVar2,uVar1,in_stack_ffffffffffffffd8);
  if (iVar4 != 0) {
    local_18 = 0;
    local_14 = 0;
    local_10 = 0;
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar6 = FUN_1400d6610(uVar6);
    FUN_140006c50(uVar6,&local_18);
    FUN_1401c55b0(lVar5,local_18,local_14,local_10,in_stack_ffffffffffffffd8 & 0xffffff00);
  }
  return 1;
}

// ==== CArenicActor@adapter::vfunc_1  @1405a7ca0  [high:rtti-vtable]  (orig: FUN_1405a7ca0)
void FUN_1405a7ca0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar4);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_0  @1405a7d90  [high:rtti-vtable]  (orig: FUN_1405a7d90)
void FUN_1405a7d90(longlong param_1,undefined8 param_2,undefined4 param_3,int param_4)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 uVar3;
  
  if (param_4 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_4);
    if (lVar1 != 0) {
      uVar3 = *(undefined4 *)(lVar1 + 0x122c);
      goto LAB_1405a7dd2;
    }
  }
  uVar3 = 0xffffffff;
LAB_1405a7dd2:
  plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar2 + 0x60))(plVar2,param_2,uVar3,0,param_3,0x7e6);
  return;
}

// ==== CArenicActor@adapter::vfunc_44  @1405a7e10  [high:rtti-vtable]  (orig: FUN_1405a7e10)
ulonglong FUN_1405a7e10(longlong param_1)

{
  uint extraout_var;
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX;
  }
  else {
    lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(lVar1 + 0x10);
    uVar2 = 0;
    if (lVar1 != 0) {
      plVar3 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,4);
      (**(code **)(*plVar3 + 0x58))(plVar3);
      return (ulonglong)(extraout_var & 1);
    }
  }
  return uVar2 & 0xffffffffffffff00;
}

// ==== CArenicActor@adapter::vfunc_42  @1405a7ea0  [high:rtti-vtable]  (orig: FUN_1405a7ea0)
void FUN_1405a7ea0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x1f8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140261720(lVar1,param_2,5);
  return;
}

// ==== CArenicActor@adapter::vfunc_71  @1405a7f00  [high:rtti-vtable]  (orig: FUN_1405a7f00)
void FUN_1405a7f00(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008abf0(uVar1);
  return;
}

// ==== CArenicActor@adapter::vfunc_72  @1405a7f20  [high:rtti-vtable]  (orig: FUN_1405a7f20)
void FUN_1405a7f20(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x200);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140269300(lVar1,param_2,param_3,param_4,param_5);
  return;
}

// ==== CArenicActor@adapter::vfunc_68  @1405a7fa0  [high:rtti-vtable]  (orig: FUN_1405a7fa0)
void FUN_1405a7fa0(longlong param_1,int param_2)

{
  longlong *plVar1;
  ulonglong *puVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  ulonglong uVar10;
  longlong *plVar11;
  uint uVar12;
  ulonglong uVar13;
  ulonglong *local_res18;
  ulonglong *local_res20;
  ulonglong *local_c0 [3];
  longlong *local_a8;
  longlong *local_a0;
  undefined8 local_98;
  ulonglong *local_90;
  undefined8 local_80;
  ulonglong *local_78;
  undefined1 local_68 [40];
  ulonglong *local_40;
  
  local_80 = 0xfffffffffffffffe;
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar8 = (longlong *)FUN_1400876b0(uVar7);
  lVar9 = (**(code **)(*plVar8 + 0x20))(plVar8,param_2,1);
  if (lVar9 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar8 = *(longlong **)(*(longlong *)(lVar9 + 0x58) + 8);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
    uVar10 = (**(code **)(*plVar8 + 0x58))(plVar8);
    if ((uVar10 >> 0x15 & 1) != 0) {
      local_res18 = operator_new(8);
      if (local_res18 == (ulonglong *)0x0) {
        local_c0[0] = (ulonglong *)0x0;
      }
      else {
        *local_res18 = (ulonglong)local_c0;
        local_c0[0] = local_res18;
      }
      uVar13 = 0;
      local_a8 = (longlong *)0x0;
      local_a0 = (longlong *)0x0;
      local_98 = 0;
      local_res20 = local_res18;
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar7 = FUN_140087650(uVar7);
      FUN_1402ac340(uVar7,local_68);
      uVar10 = uVar13;
      while (cVar4 = FUN_1400cf370(local_68), cVar4 != '\0') {
        uVar12 = (int)uVar10 + 1;
        uVar10 = (ulonglong)uVar12;
        if (1000000 < uVar12) {
          log_InlineLogERROR(&DAT_1406d9c10);
          break;
        }
        if ((local_40 != (ulonglong *)0x0) &&
           (iVar5 = (**(code **)(local_40[2] + 0x168))(), iVar5 == param_2)) {
          local_res18 = local_40;
          FUN_14013b730(local_c0,&local_res18);
        }
      }
      plVar8 = local_a8;
      local_90 = (ulonglong *)0x0;
      if (local_a0 < local_a8) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_a0;
      puVar2 = local_c0[0];
      local_res18 = local_c0[0];
      local_90 = local_c0[0];
      local_78 = (ulonglong *)0x0;
      if (local_a0 < local_a8) {
        _invalid_parameter_noinfo();
      }
      local_78 = local_c0[0];
      local_res18 = local_c0[0];
      while( true ) {
        if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_res18)) {
          _invalid_parameter_noinfo();
        }
        if (plVar8 == plVar3) break;
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar10 = uVar13;
        }
        else {
          uVar10 = *puVar2;
        }
        if (*(longlong **)(uVar10 + 0x20) <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar1 = (longlong *)*plVar8;
        if (plVar1 != (longlong *)0x0) {
          plVar11 = (longlong *)CurrentInstanceGet();
          if (plVar11 != (longlong *)0x0) {
            plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,4);
            lVar9 = *plVar11;
            uVar6 = (**(code **)(*plVar1 + 8))(plVar1);
            (**(code **)(lVar9 + 0x18))(plVar11,uVar6);
          }
          (**(code **)(*plVar1 + 8))(plVar1);
          log_InlineLogERROR("CArenicSystem::BeginAthletics error map:%u, has user:%u, status:%d");
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
          plVar11 = (longlong *)FUN_140087650(uVar7);
          (**(code **)(*plVar11 + 0x50))
                    (plVar11,plVar1,"CArenicSystem::BeginAthletics fault in arenic map");
        }
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar10 = uVar13;
        }
        else {
          uVar10 = *puVar2;
        }
        if (*(longlong **)(uVar10 + 0x20) <= plVar8) {
          _invalid_parameter_noinfo();
        }
        plVar8 = plVar8 + 1;
      }
      if (local_a8 != (longlong *)0x0) {
        operator_delete(local_a8);
      }
      local_a8 = (longlong *)0x0;
      local_a0 = (longlong *)0x0;
      local_98 = 0;
      operator_delete(local_c0[0]);
    }
  }
  return;
}

// ==== CArenicActor@adapter::vfunc_2  @1405a82f0  [high:rtti-vtable]  (orig: FUN_1405a82f0)
void FUN_1405a82f0(longlong param_1,longlong *param_2,undefined8 param_3)

{
  ulonglong *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  undefined4 *puVar9;
  longlong *local_res20;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  local_res20 = operator_new(8);
  local_68[0] = (longlong *)0x0;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_68;
    local_68[0] = local_res20;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  puVar9 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar9) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (ulonglong *)*param_2;
  do {
    uVar7 = 0;
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != (ulonglong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar2) {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar6 + 0x38))(plVar6,local_68,param_3);
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      if ((void *)param_2[3] != (void *)0x0) {
        operator_delete((void *)param_2[3]);
      }
      param_2[3] = 0;
      param_2[4] = 0;
      param_2[5] = 0;
      operator_delete((void *)*param_2);
      return;
    }
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar8 = uVar7;
    }
    else {
      uVar8 = *puVar1;
    }
    if (*(undefined4 **)(uVar8 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),*puVar9);
    puVar2 = local_48;
    if (lVar4 != 0) {
      local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar4 + 0x122c));
      if (local_50 != (undefined4 *)0x0) {
        uVar7 = local_40 - (longlong)local_50 >> 2;
      }
      if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar7) {
        *local_48 = *(undefined4 *)(lVar4 + 0x122c);
        local_48 = local_48 + 1;
      }
      else {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_50;
        plVar6 = local_68[0];
        if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
          lVar4 = 0;
        }
        else {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
            _invalid_parameter_noinfo();
          }
          lVar4 = (longlong)puVar2 - (longlong)puVar3 >> 2;
        }
        local_88 = SUB84(plVar6,0);
        uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_80 = SUB84(puVar2,0);
        uStack_7c = (undefined4)((ulonglong)puVar2 >> 0x20);
        local_78 = local_88;
        uStack_74 = uStack_84;
        uStack_70 = uStack_80;
        uStack_6c = uStack_7c;
        FUN_140036c20(local_68,&local_78,1,&local_res20);
        puVar2 = local_50;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_68[0];
        if (local_68[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *local_68[0];
        }
        if (puVar2 + lVar4 <= *(undefined4 **)(lVar5 + 0x20)) {
          if (plVar6 == (longlong *)0x0) {
            lVar5 = 0;
          }
          else {
            lVar5 = *plVar6;
          }
          if (*(undefined4 **)(lVar5 + 0x18) <= puVar2 + lVar4) goto LAB_1405a8500;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_1405a8500:
    uVar7 = 0;
    if (puVar1 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      uVar7 = *puVar1;
    }
    if (*(undefined4 **)(uVar7 + 0x20) <= puVar9) {
      _invalid_parameter_noinfo();
    }
    puVar9 = puVar9 + 1;
  } while( true );
}

