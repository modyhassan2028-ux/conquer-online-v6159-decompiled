// ==== CGameObj::ctor_or_dtor  @1402b5540  [high:vtable-assign]  (orig: FUN_1402b5540)
undefined8 * FUN_1402b5540(undefined8 *param_1)

{
  *(undefined4 *)(param_1 + 1) = 0;
  *param_1 = CGameObj::vftable;
  return param_1;
}

// ==== CGameObj::vfunc_1  @1402b5560  [high:rtti-vtable]  (orig: FUN_1402b5560)
undefined8 FUN_1402b5560(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CGameObj::ctor_or_dtor  @1402b55a0  [high:vtable-assign]  (orig: FUN_1402b55a0)
void FUN_1402b55a0(undefined8 *param_1)

{
  *param_1 = CGameObj::vftable;
  return;
}

// ==== CGameObj::ctor_or_dtor  @1402b55b0  [high:vtable-assign]  (orig: FUN_1402b55b0)
undefined8 * FUN_1402b55b0(undefined8 *param_1,byte param_2)

{
  *param_1 = CGameObj::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

