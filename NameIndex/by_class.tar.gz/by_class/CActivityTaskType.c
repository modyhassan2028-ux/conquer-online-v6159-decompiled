// ==== CActivityTaskType::Create  @140425b40  [high:log-string]  (orig: FUN_140425b40)
undefined8 FUN_140425b40(longlong param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  int iVar11;
  undefined4 local_res10 [2];
  longlong *local_res18;
  void **local_res20;
  longlong *local_e0 [3];
  void *local_c8;
  undefined8 local_c0;
  undefined8 local_b8;
  longlong *local_b0 [3];
  undefined4 local_98 [2];
  longlong *local_90;
  longlong *local_88;
  longlong local_80;
  undefined4 local_78 [2];
  void *local_70 [3];
  void *local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"SELECT * FROM cq_activity_task_type",1)
  ;
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR("CActivityTaskType::Create(), CreateRecordset() error.");
    uVar7 = 0;
  }
  else {
    lVar8 = (**(code **)(*plVar6 + 0x40))(plVar6);
    if (lVar8 == 0) {
      log_InlineLogDBERROR("table:cq_activity_task_type not config data.");
      (**(code **)*plVar6)(plVar6);
      uVar7 = 1;
    }
    else {
      for (iVar11 = 0; iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6), iVar11 < iVar3;
          iVar11 = iVar11 + 1) {
        (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar11);
        plVar9 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
        local_res18 = plVar9;
        if (plVar9 != (longlong *)0x0) {
          plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0);
          uVar4 = (**(code **)(*plVar10 + 0x40))(plVar10);
          plVar10 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,3);
          uVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
          local_res10[0] = uVar5;
          local_98[0] = uVar4;
          local_90 = plVar9;
          FUN_14002d3d0(param_1 + 8,local_b0,local_98);
          puVar1 = (undefined8 *)(param_1 + 0x48);
          FUN_140267440(puVar1,&local_88,local_res10);
          plVar9 = local_88;
          lVar8 = *(longlong *)(param_1 + 0x78);
          local_b0[0] = (longlong *)*puVar1;
          if ((local_88 == (longlong *)0x0) || (local_88 != local_b0[0])) {
            _invalid_parameter_noinfo();
          }
          lVar2 = local_80;
          if (local_80 == lVar8) {
            local_res20 = operator_new(8);
            if (local_res20 == (void **)0x0) {
              local_e0[0] = (longlong *)0x0;
            }
            else {
              *local_res20 = local_e0;
              local_e0[0] = (longlong *)local_res20;
            }
            local_c8 = (void *)0x0;
            local_c0 = 0;
            local_b8 = 0;
            local_b0[0] = (longlong *)local_res20;
            FUN_140019370(local_e0,&local_res18);
            local_78[0] = uVar5;
            FUN_140267b90(local_70,local_e0);
            FUN_140269d60(puVar1,local_b0,local_78);
            local_res20 = local_70;
            if (local_58 != (void *)0x0) {
              operator_delete(local_58);
            }
            local_58 = (void *)0x0;
            local_50 = 0;
            local_48 = 0;
            operator_delete(local_70[0]);
            if (local_c8 != (void *)0x0) {
              operator_delete(local_c8);
            }
            local_c8 = (void *)0x0;
            local_c0 = 0;
            local_b8 = 0;
            operator_delete(local_e0[0]);
          }
          else {
            if (plVar9 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = 0;
            }
            else {
              lVar8 = *plVar9;
            }
            if (lVar2 == *(longlong *)(lVar8 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140019370(lVar2 + 0x20,&local_res18);
          }
        }
      }
      (**(code **)*plVar6)(plVar6);
      uVar7 = 1;
    }
  }
  return uVar7;
}

// ==== CActivityTaskType::helper_140425e50  @140425e50  [medium:callgraph-r0]  (orig: FUN_140425e50)
void FUN_140425e50(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = *(longlong **)param_1[7];
  plVar2 = (longlong *)param_1[1];
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = (longlong *)param_1[7];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      (*(code *)**(undefined8 **)plVar4[4])((undefined8 *)plVar4[4],1);
      plVar4[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar4 = *(longlong **)(param_1[7] + 8);
  while (cVar1 == '\0') {
    FUN_14002ca30(param_1 + 1,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  FUN_140269f10(param_1 + 9,*(undefined8 *)(param_1[0xf] + 8));
  *(undefined8 *)(param_1[0xf] + 8) = param_1[0xf];
  param_1[0x10] = 0;
  *(undefined8 *)param_1[0xf] = param_1[0xf];
  *(undefined8 *)(param_1[0xf] + 0x10) = param_1[0xf];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CActivityTaskType::ctor_or_dtor  @140426020  [high:vtable-assign]  (orig: FUN_140426020)
void FUN_140426020(undefined8 *param_1)

{
  *param_1 = CActivityTaskType::vftable;
  FUN_14026a6f0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14002de90(param_1 + 1);
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CActivityTaskType::ctor_or_dtor  @140426090  [high:vtable-assign]  (orig: FUN_140426090)
undefined8 * FUN_140426090(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CActivityTaskType::vftable;
  FUN_14002e1c0(param_1 + 1);
  FUN_14026a890(param_1 + 9);
  *(undefined4 *)(param_1 + 0x11) = param_2;
  return param_1;
}

// ==== CActivityTaskType::ctor_or_dtor  @1404260e0  [high:vtable-assign]  (orig: FUN_1404260e0)
undefined8 * FUN_1404260e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CActivityTaskType::vftable;
  FUN_14026a6f0(param_1 + 9);
  operator_delete((void *)param_1[9]);
  FUN_14002de90(param_1 + 1);
  operator_delete((void *)param_1[1]);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CActivityTaskType::ctor_or_dtor  @140426170  [high:vtable-assign]  (orig: FUN_140426170)
undefined8 * FUN_140426170(undefined4 param_1)

{
  char cVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x90);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CActivityTaskType::vftable;
    FUN_14002e1c0(puVar2 + 1);
    FUN_14026a890(puVar2 + 9);
    *(undefined4 *)(puVar2 + 0x11) = param_1;
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140425b40(puVar2);
    if (cVar1 == '\0') {
      FUN_140425e50(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

