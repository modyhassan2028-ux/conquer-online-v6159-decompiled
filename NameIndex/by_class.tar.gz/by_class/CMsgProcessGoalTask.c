// ==== CMsgProcessGoalTask::ctor_or_dtor  @1404df690  [high:vtable-assign]  (orig: FUN_1404df690)
undefined8 * FUN_1404df690(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgProcessGoalTask::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgProcessGoalTask::ctor_or_dtor  @1404df6e0  [high:vtable-assign]  (orig: FUN_1404df6e0)
void FUN_1404df6e0(undefined8 *param_1)

{
  *param_1 = CMsgProcessGoalTask::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgProcessGoalTask::vfunc_1  @1404df710  [high:rtti-vtable]  (orig: FUN_1404df710)
bool FUN_1404df710(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xb0f;
    }
  }
  return false;
}

// ==== CMsgProcessGoalTask::vfunc_3  @1404df840  [high:rtti-vtable]  (orig: FUN_1404df840)
void FUN_1404df840(void)

{
  return;
}

// ==== CMsgProcessGoalTask::ctor_or_dtor  @1404df850  [high:vtable-assign]  (orig: FUN_1404df850)
undefined8 * FUN_1404df850(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgProcessGoalTask::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

