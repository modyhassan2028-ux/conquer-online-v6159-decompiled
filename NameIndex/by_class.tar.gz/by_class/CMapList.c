// ==== CMapList::ctor_or_dtor  @140074450  [high:vtable-assign]  (orig: FUN_140074450)
undefined8 * FUN_140074450(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CMapList::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}

// ==== CMapList::ctor_or_dtor  @1400744c0  [high:vtable-assign]  (orig: FUN_1400744c0)
void FUN_1400744c0(undefined8 *param_1)

{
  int iVar1;
  ulonglong uVar2;
  
  *param_1 = CMapList::vftable;
  iVar1 = 0;
  uVar2 = 0;
  if (0 < (int)((longlong)(param_1[5] - param_1[4]) >> 3)) {
    do {
      if ((ulonglong)((longlong)(param_1[5] - param_1[4]) >> 3) <= uVar2) {
        _invalid_parameter_noinfo();
      }
      operator_delete(*(void **)(param_1[4] + uVar2 * 8));
      iVar1 = iVar1 + 1;
      uVar2 = uVar2 + 1;
    } while (iVar1 < (int)((longlong)(param_1[5] - param_1[4]) >> 3));
  }
  if ((void *)param_1[4] != (void *)0x0) {
    operator_delete((void *)param_1[4]);
  }
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  operator_delete((void *)param_1[1]);
  return;
}

// ==== CMapList::vfunc_0  @140074860  [high:rtti-vtable]  (orig: FUN_140074860)
void * FUN_140074860(void *param_1,uint param_2)

{
  FUN_1400744c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

