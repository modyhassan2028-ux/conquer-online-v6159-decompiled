// ==== CAdapter@adapter::vfunc_2  @140578750  [high:rtti-vtable]  (orig: FUN_140578750)
undefined8 FUN_140578750(void)

{
  return 0;
}

// ==== CAdapter@adapter::vfunc_3  @1405787b0  [high:rtti-vtable]  (orig: FUN_1405787b0)
undefined8 * FUN_1405787b0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CAdapter::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAdapter@adapter::vfunc_1  @1405787e0  [high:rtti-vtable]  (orig: FUN_1405787e0)
longlong FUN_1405787e0(longlong param_1,undefined4 param_2)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong lVar6;
  void *pvVar7;
  
  plVar2 = (longlong *)CurrentInstanceGet();
  switch(param_2) {
  case 4:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405a7510(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 5:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405b3de0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  default:
    log_InlineLogERROR(&DAT_1407a7d88);
    break;
  case 8:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x28);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405b73c0(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 9:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405b5ab0(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 10:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405b2410(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0xb:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405baa70(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0xc:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405ba060(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0xd:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405b32a0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0xe:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405b62a0(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0xf:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if ((lVar6 != 0) && (lVar6 = FUN_1405bbb70(lVar6,*(undefined4 *)(param_1 + 8)), lVar6 != 0)) {
      (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
      return lVar6;
    }
    break;
  case 0x10:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405b8ee0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x11:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405b4dd0(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x12:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405a3340(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x13:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405a1180(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x14:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    lVar6 = (**(code **)(*plVar2 + 0x20))(plVar2,0x11);
    lVar3 = (**(code **)(*plVar2 + 0x20))(plVar2,9);
    if (((plVar4 != (longlong *)0x0) && (lVar6 != 0)) && (lVar3 != 0)) {
      pvVar7 = operator_new(0x30);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_14059f1d0(pvVar7,plVar4,lVar3,lVar6,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x15:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14059e050(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x16:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405aacb0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x17:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14059c860(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x18:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_1405997c0(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x19:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405971c0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x1a:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_1405956e0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x1b:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_140593e60(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x1c:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14058fef0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x1d:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14058ede0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x1e:
    pvVar7 = operator_new(0x18);
    if (pvVar7 == (void *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = FUN_1405833e0(pvVar7,*(undefined4 *)(param_1 + 8));
    }
    if (lVar6 != 0) {
      (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
      return lVar6;
    }
    break;
  case 0x1f:
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    if (plVar4 != (longlong *)0x0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
        lVar6 = FUN_14058de90(pvVar7,plVar4,uVar1);
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x20:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14058d380(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x21:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14058b2d0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x22:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_140581cf0(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x23:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14057f570(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x24:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_140588510(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
    break;
  case 0x25:
    uVar5 = FUN_140008520(0xe);
    lVar6 = FUN_140087650(uVar5);
    if (lVar6 != 0) {
      pvVar7 = operator_new(0x20);
      if (pvVar7 == (void *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = FUN_14057c890(pvVar7,lVar6,*(undefined4 *)(param_1 + 8));
      }
      if (lVar6 != 0) {
        (**(code **)(*plVar2 + 0x28))(plVar2,param_2,lVar6);
        return lVar6;
      }
    }
  }
  return 0;
}

// ==== CAdapter@adapter::helper_14057c890  @14057c890  [medium:callgraph-r0]  (orig: FUN_14057c890)
undefined8 * FUN_14057c890(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = frontier_flag_war::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CFrontierFlagWarActor::vftable;
  param_1[1] = adapter::CFrontierFlagWarActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14057f570  @14057f570  [medium:callgraph-r0]  (orig: FUN_14057f570)
undefined8 * FUN_14057f570(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = anticheat::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CAntiCheatActor::vftable;
  param_1[1] = adapter::CAntiCheatActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_140581cf0  @140581cf0  [medium:callgraph-r0]  (orig: FUN_140581cf0)
undefined8 * FUN_140581cf0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = team_arenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTeamArenicActor::vftable;
  param_1[1] = adapter::CTeamArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405833e0  @1405833e0  [medium:callgraph-r0]  (orig: FUN_1405833e0)
undefined8 * FUN_1405833e0(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = team::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTeamActor::vftable;
  param_1[1] = adapter::CTeamActor::vftable;
  *(undefined4 *)(param_1 + 2) = param_2;
  return param_1;
}

// ==== CAdapter@adapter::helper_140588510  @140588510  [medium:callgraph-r0]  (orig: FUN_140588510)
undefined8 * FUN_140588510(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = pop_pk_arenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CPopPKArenicActor::vftable;
  param_1[1] = adapter::CPopPKArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14058b2d0  @14058b2d0  [medium:callgraph-r0]  (orig: FUN_14058b2d0)
undefined8 * FUN_14058b2d0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = clan_pk_arenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CClanPKArenicActor::vftable;
  param_1[1] = adapter::CClanPKArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14058d380  @14058d380  [medium:callgraph-r0]  (orig: FUN_14058d380)
undefined8 * FUN_14058d380(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = relation::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CRelationActor::vftable;
  param_1[1] = adapter::CRelationActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14058de90  @14058de90  [medium:callgraph-r0]  (orig: FUN_14058de90)
undefined8 * FUN_14058de90(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = wanted::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CWantedActor::vftable;
  param_1[1] = adapter::CWantedActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14058ede0  @14058ede0  [medium:callgraph-r0]  (orig: FUN_14058ede0)
undefined8 * FUN_14058ede0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = leaveword::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CLeaveWordActor::vftable;
  param_1[1] = adapter::CLeaveWordActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14058fef0  @14058fef0  [medium:callgraph-r0]  (orig: FUN_14058fef0)
undefined8 * FUN_14058fef0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = vexillumarenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CVexillumArenicActor::vftable;
  param_1[1] = adapter::CVexillumArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_140593e60  @140593e60  [medium:callgraph-r0]  (orig: FUN_140593e60)
undefined8 * FUN_140593e60(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = booth::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CBoothActor::vftable;
  param_1[1] = adapter::CBoothActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405956e0  @1405956e0  [medium:callgraph-r0]  (orig: FUN_1405956e0)
undefined8 * FUN_1405956e0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = sponsor::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CSponsorActor::vftable;
  param_1[1] = adapter::CSponsorActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405971c0  @1405971c0  [medium:callgraph-r0]  (orig: FUN_1405971c0)
undefined8 * FUN_1405971c0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = elitepkarenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CElitePKArenicActor::vftable;
  param_1[1] = adapter::CElitePKArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405997c0  @1405997c0  [medium:callgraph-r0]  (orig: FUN_1405997c0)
undefined8 * FUN_1405997c0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = factionmatch::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CFactionMatchActor::vftable;
  param_1[1] = adapter::CFactionMatchActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14059c860  @14059c860  [medium:callgraph-r0]  (orig: FUN_14059c860)
undefined8 * FUN_14059c860(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = trade::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTradeActor::vftable;
  param_1[1] = adapter::CTradeActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14059e050  @14059e050  [medium:callgraph-r0]  (orig: FUN_14059e050)
undefined8 * FUN_14059e050(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = totem::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTotemActor::vftable;
  param_1[1] = adapter::CTotemActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_14059f1d0  @14059f1d0  [medium:callgraph-r0]  (orig: FUN_14059f1d0)
undefined8 *
FUN_14059f1d0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 param_5)

{
  *param_1 = status::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CStatusActor::vftable;
  param_1[1] = adapter::CStatusActor::vftable;
  param_1[2] = param_2;
  param_1[3] = param_3;
  param_1[4] = param_4;
  *(undefined4 *)(param_1 + 5) = param_5;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405a1180  @1405a1180  [medium:callgraph-r0]  (orig: FUN_1405a1180)
undefined8 * FUN_1405a1180(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = detainequip::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CDetainEquipActor::vftable;
  param_1[1] = adapter::CDetainEquipActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405a3340  @1405a3340  [medium:callgraph-r0]  (orig: FUN_1405a3340)
undefined8 * FUN_1405a3340(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = storage::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CStorageActor::vftable;
  param_1[1] = adapter::CStorageActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405a7510  @1405a7510  [medium:callgraph-r0]  (orig: FUN_1405a7510)
undefined8 * FUN_1405a7510(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = arenic::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CArenicActor::vftable;
  param_1[1] = adapter::CArenicActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405aacb0  @1405aacb0  [medium:callgraph-r0]  (orig: FUN_1405aacb0)
undefined8 * FUN_1405aacb0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = syndicate::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CSyndicateActor::vftable;
  param_1[1] = adapter::CSyndicateActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b2410  @1405b2410  [medium:callgraph-r0]  (orig: FUN_1405b2410)
undefined8 * FUN_1405b2410(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = lottery::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CLotteryActor::vftable;
  param_1[1] = adapter::CLotteryActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b32a0  @1405b32a0  [medium:callgraph-r0]  (orig: FUN_1405b32a0)
undefined8 * FUN_1405b32a0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = taskdetail::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTaskDetailActor::vftable;
  param_1[1] = adapter::CTaskDetailActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b3de0  @1405b3de0  [medium:callgraph-r0]  (orig: FUN_1405b3de0)
undefined8 * FUN_1405b3de0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = competion::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CCompetionActor::vftable;
  param_1[1] = adapter::CCompetionActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b4dd0  @1405b4dd0  [medium:callgraph-r0]  (orig: FUN_1405b4dd0)
undefined8 * FUN_1405b4dd0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = rank::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CRankActor::vftable;
  param_1[1] = adapter::CRankActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b5ab0  @1405b5ab0  [medium:callgraph-r0]  (orig: FUN_1405b5ab0)
undefined8 * FUN_1405b5ab0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = flower::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CFlowerActor::vftable;
  param_1[1] = adapter::CFlowerActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b62a0  @1405b62a0  [medium:callgraph-r0]  (orig: FUN_1405b62a0)
undefined8 * FUN_1405b62a0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = title::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CTitleActor::vftable;
  param_1[1] = adapter::CTitleActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b73c0  @1405b73c0  [medium:callgraph-r0]  (orig: FUN_1405b73c0)
undefined8 *
FUN_1405b73c0(undefined8 *param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  *param_1 = family::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CFamilyActor::vftable;
  param_1[1] = adapter::CFamilyActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  plVar1 = (longlong *)CurrentInstanceGet();
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1,1,*plVar1,param_4,uVar2);
  param_1[4] = uVar2;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405b8ee0  @1405b8ee0  [medium:callgraph-r0]  (orig: FUN_1405b8ee0)
undefined8 * FUN_1405b8ee0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = guide::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CGuideActor::vftable;
  param_1[1] = adapter::CGuideActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405ba060  @1405ba060  [medium:callgraph-r0]  (orig: FUN_1405ba060)
undefined8 * FUN_1405ba060(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = pigeon::IConsumer::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CPigeonActor::vftable;
  param_1[1] = adapter::CPigeonActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405baa70  @1405baa70  [medium:callgraph-r0]  (orig: FUN_1405baa70)
undefined8 * FUN_1405baa70(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  *param_1 = peerage::IPeerageLogic::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = adapter::CPeerageActor::vftable;
  param_1[1] = adapter::CPeerageActor::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = param_3;
  return param_1;
}

// ==== CAdapter@adapter::helper_1405bbb70  @1405bbb70  [medium:callgraph-r0]  (orig: FUN_1405bbb70)
undefined8 * FUN_1405bbb70(undefined8 param_1,int param_2)

{
  undefined8 *puVar1;
  
  if (param_2 == 0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1 = operator_new(0x20);
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = training::ITrainingLogic::vftable;
      puVar1[1] = adapter::IActor::vftable;
      *puVar1 = adapter::CTrainActor::vftable;
      puVar1[1] = adapter::CTrainActor::vftable;
      puVar1[2] = param_1;
      *(undefined4 *)(puVar1 + 3) = 0xe;
    }
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      puVar1 = (undefined8 *)0x0;
    }
  }
  return puVar1;
}

