// ==== CMsgActivityTask::ctor_or_dtor  @14042bb20  [high:vtable-assign]  (orig: FUN_14042bb20)
undefined8 * FUN_14042bb20(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgActivityTask::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgActivityTask::ctor_or_dtor  @14042bb70  [high:vtable-assign]  (orig: FUN_14042bb70)
void FUN_14042bb70(undefined8 *param_1)

{
  *param_1 = CMsgActivityTask::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgActivityTask::vfunc_1  @14042bba0  [high:rtti-vtable]  (orig: FUN_14042bba0)
bool FUN_14042bba0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xb04;
    }
  }
  return false;
}

// ==== CMsgActivityTask::vfunc_3  @14042bcf0  [high:rtti-vtable]  (orig: FUN_14042bcf0)
void FUN_14042bcf0(void)

{
  return;
}

// ==== CMsgActivityTask::ctor_or_dtor  @14042bd00  [high:vtable-assign]  (orig: FUN_14042bd00)
undefined8 * FUN_14042bd00(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgActivityTask::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

