// ==== CAuctionSearchThread::ctor_or_dtor  @1400f3060  [high:vtable-assign]  (orig: FUN_1400f3060)
CThreadBase * FUN_1400f3060(CThreadBase *param_1,undefined8 param_2)

{
  CThreadBase::CThreadBase(param_1);
  *(undefined ***)param_1 = CAuctionSearchThread::vftable;
  *(undefined8 *)(param_1 + 0x40) = param_2;
  *(undefined8 *)(param_1 + 0x48) = 0;
  return param_1;
}

// ==== CAuctionSearchThread::vfunc_4  @1400f30b0  [high:rtti-vtable]  (orig: FUN_1400f30b0)
bool FUN_1400f30b0(CThreadBase *param_1,bool param_2)

{
  bool bVar1;
  longlong lVar2;
  
  lVar2 = FUN_14036e510(*(undefined8 *)(param_1 + 0x40));
  *(longlong *)(param_1 + 0x48) = lVar2;
  if (lVar2 == 0) {
    log_InlineLogERROR("CAuctionSearchThread::CreateThread failed");
    return false;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400f3104. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  bVar1 = CThreadBase::CreateThread(param_1,"AuctionSearchThread",param_2);
  return bVar1;
}

// ==== CAuctionSearchThread::vfunc_1  @1400f3110  [high:rtti-vtable]  (orig: FUN_1400f3110)
void FUN_1400f3110(void)

{
  return;
}

// ==== CAuctionSearchThread::vfunc_2  @1400f3120  [high:rtti-vtable]  (orig: FUN_1400f3120)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f3120(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  char *pcVar3;
  undefined1 auStack_448 [32];
  char *local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if (*(longlong *)(param_1 + 0x40) == 0) {
    local_428 = (char *)CONCAT44(local_428._4_4_,0x2f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
    _snprintf(local_418,0x400,"#%u: auction search thread is up and running");
    lVar2 = -1;
    local_19 = 0;
    pcVar3 = local_418;
    do {
      if (lVar2 == 0) break;
      lVar2 = lVar2 + -1;
      cVar1 = *pcVar3;
      pcVar3 = pcVar3 + 1;
    } while (cVar1 != '\0');
    local_428 = local_418;
    (**(code **)(**(longlong **)(param_1 + 0x40) + 0x50))
              (*(longlong **)(param_1 + 0x40),0,0x9c41,~(uint)lVar2);
  }
  return;
}

// ==== CAuctionSearchThread::vfunc_3  @1400f31f0  [high:rtti-vtable]  (orig: FUN_1400f31f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400f31f0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined1 auStack_4c8 [32];
  undefined1 *local_4a8;
  undefined4 *local_4a0;
  char local_498;
  char local_497;
  ulong local_494;
  undefined4 local_490;
  uint local_48c;
  undefined4 local_488;
  longlong local_478;
  CTickAnalyst local_470 [24];
  undefined8 local_458;
  CTickAnalyst local_450 [24];
  undefined1 local_438 [1056];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_478 = param_1;
  if ((DAT_140975cac & 1) == 0) {
    DAT_140975cac = DAT_140975cac | 1;
    DAT_140975ca8 = tq::TimeGet(0);
  }
  local_498 = 0;
  CTickAnalyst::CTickAnalyst((CTickAnalyst *)&local_490,0x4a);
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x58))
                    (*(longlong **)(param_1 + 0x40),s___AVCAuctionSearchThread___14094b928._28_4_);
  local_498 = cVar1;
  CTickAnalyst::~CTickAnalyst((CTickAnalyst *)&local_490);
  CTickAnalyst::CTickAnalyst(local_450,0x32);
  uVar2 = tq::TimeGet(0);
  local_494 = uVar2;
  if (cVar1 == '\0') {
    CTickAnalyst::CTickAnalyst(local_470,0x34);
    (**(code **)(**(longlong **)(param_1 + 0x48) + 0x18))(*(longlong **)(param_1 + 0x48),uVar2);
    CTickAnalyst::~CTickAnalyst(local_470);
    if (uVar2 - DAT_140975ca8 < 0x2711) {
      DAT_140975ca8 = DAT_140975ca8 + 2000;
    }
    else {
      log_InlineLogWARNING("resync CAuctionSearchService::OnTimer cumulative deviation %dms");
      DAT_140975ca8 = uVar2;
    }
  }
  else {
    while( true ) {
      local_4a0 = &local_490;
      local_4a8 = local_438;
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x48))
                        (*(longlong **)(param_1 + 0x40),0xffffffff,0xffffffff,0x418);
      if (cVar1 == '\0') break;
      local_497 = 1;
      CTickAnalyst::CTickAnalyst(local_470,0x33);
      local_4a8 = (undefined1 *)CONCAT44(local_4a8._4_4_,local_490);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x10))
                        (*(longlong **)(param_1 + 0x48),local_48c,local_438,local_488);
      local_497 = cVar1;
      CTickAnalyst::~CTickAnalyst(local_470);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CAuctionSearchThread::OnProcess ProcessMsg returned error with packet:%d, port:%d"
                           ,(ulonglong)local_48c);
      }
    }
  }
  uVar2 = tq::TimeGet(0);
  if ((int)(uVar2 - DAT_140975ca8) < 2000) {
    s___AVCAuctionSearchThread___14094b928._28_4_ = 2000 - (uVar2 - DAT_140975ca8);
  }
  else {
    s___AVCAuctionSearchThread___14094b928[0x1c] = '\0';
    s___AVCAuctionSearchThread___14094b928[0x1d] = '\0';
    s___AVCAuctionSearchThread___14094b928[0x1e] = '\0';
    s___AVCAuctionSearchThread___14094b928[0x1f] = '\0';
  }
  CTickAnalyst::~CTickAnalyst(local_450);
  return 1;
}

// ==== CAuctionSearchThread::ctor_or_dtor  @1400f3460  [high:vtable-assign]  (orig: FUN_1400f3460)
void FUN_1400f3460(CThreadBase *param_1)

{
  *(undefined ***)param_1 = CAuctionSearchThread::vftable;
  if (*(longlong *)(param_1 + 0x48) != 0) {
    (**(code **)(**(longlong **)(param_1 + 0x48) + 0x20))();
    *(undefined8 *)(param_1 + 0x48) = 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400f34a8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CThreadBase::~CThreadBase(param_1);
  return;
}

// ==== CAuctionSearchThread::vfunc_0  @1400f34b0  [high:rtti-vtable]  (orig: FUN_1400f34b0)
void * FUN_1400f34b0(void *param_1,uint param_2)

{
  FUN_1400f3460();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CAuctionSearchThread::helper_14036e510  @14036e510  [medium:callgraph-r0]  (orig: FUN_14036e510)
longlong *
FUN_14036e510(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  void *pvVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  if ((DAT_140976130 & 1) == 0) {
    DAT_140976130 = DAT_140976130 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976128,"CAuctionSearchService");
    atexit((_func_5014 *)&LAB_1406d6b00);
  }
  pvVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_140976128,0x3f8);
  if (pvVar2 == (void *)0x0) {
    plVar3 = (longlong *)0x0;
  }
  else {
    plVar3 = (longlong *)FUN_14036e400(pvVar2);
  }
  if ((plVar3 == (longlong *)0x0) ||
     (cVar1 = (**(code **)(*plVar3 + 8))(plVar3,param_1,param_3,param_4,uVar4), cVar1 == '\0')) {
    plVar3 = (longlong *)0x0;
  }
  return plVar3;
}

