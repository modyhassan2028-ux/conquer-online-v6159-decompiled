// ==== CMsgTaskReward::helper_140258b60  @140258b60  [medium:callgraph-r1]  (orig: FUN_140258b60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1
FUN_140258b60(undefined8 param_1,longlong *param_2,longlong *param_3,undefined4 param_4,int param_5)

{
  byte bVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  longlong *plVar9;
  longlong *plVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  longlong lVar13;
  uint uVar14;
  undefined1 auStack_4d8 [32];
  uint local_4b8;
  uint local_4b0;
  undefined8 local_4a8;
  uint local_4a0;
  char local_498;
  byte local_497;
  uint local_494;
  undefined4 local_490;
  longlong *local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (((param_2 == (longlong *)0x0) || (param_3 == (longlong *)0x0)) || (param_5 < 0)) {
    return 0;
  }
  if (param_5 == 0) {
    return 1;
  }
  plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,1);
  bVar1 = (**(code **)(*plVar9 + 0x20))(plVar9);
  local_497 = bVar1;
  plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,2);
  cVar2 = (**(code **)(*plVar9 + 0x20))(plVar9);
  local_494 = 0;
  if (bVar1 == 0) {
    plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,4);
    iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
    uVar14 = iVar4 * (param_5 + -1) + 1;
  }
  else {
    plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,3);
    plVar10 = (longlong *)(**(code **)(*param_3 + 8))(param_3,4);
    iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
    iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
    uVar14 = iVar4 * (param_5 + -1) + iVar5;
  }
  local_494 = uVar14;
  plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,5);
  iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
  if (iVar4 <= (int)uVar14) {
    plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,5);
    uVar14 = (**(code **)(*plVar9 + 0x48))(plVar9);
  }
  if ((int)uVar14 < 1) {
    return 0;
  }
  if (cVar2 == '\0') {
    return 0;
  }
  local_498 = 0;
  uVar6 = 0;
  local_490 = 0;
  local_494 = uVar14;
  switch(local_497) {
  case 0:
    plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,3);
    uVar6 = (**(code **)(*plVar9 + 0x40))(plVar9);
    local_490 = uVar6;
    if (cVar2 == '\x01') {
      local_4b0 = local_4b0 & 0xffffff00;
      local_4b8 = 0;
      cVar3 = FUN_140338940(param_2,uVar6,uVar6,uVar14);
      if (cVar3 != '\0') {
        local_4b0 = local_4b0 & 0xffffff00;
        local_4b8 = 0;
        cVar2 = FUN_140350360(param_2,uVar6,uVar6,uVar14);
        if (cVar2 == '\0') {
          (**(code **)(*param_2 + 8))(param_2);
          local_4a0 = 0x1f0;
          local_4a8 = 
          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\roulette\\taskrewardmgr.cpp"
          ;
          local_4b8 = uVar6;
          local_4b0 = uVar14;
          log_InlineLogERROR(
                            "CTaskRewardMgr::LotteryConsume, user(id:%lu, account:%lu) idTask[%lu] MultiDelItem ItemType[%lu] Num(%d) Failed at %s, %d"
                            );
          return 0;
        }
        goto LAB_140259323;
      }
    }
    else if (cVar2 == '\x02') {
      local_4b0 = (uint)local_4b0._1_3_ << 8;
      local_4b8 = 2;
      cVar2 = FUN_140338940(param_2,uVar6,uVar6,uVar14);
      if (cVar2 != '\0') {
        local_4b0 = local_4b0 & 0xffffff00;
        local_4b8 = 2;
        cVar2 = FUN_140350360(param_2,uVar6,uVar6,uVar14);
        if (cVar2 == '\0') {
          (**(code **)(*param_2 + 8))(param_2);
          local_4a0 = 0x1ff;
          local_4a8 = 
          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\roulette\\taskrewardmgr.cpp"
          ;
          local_4b8 = uVar6;
          local_4b0 = uVar14;
          log_InlineLogERROR(
                            "CTaskRewardMgr::LotteryConsume, user(id:%lu, account:%lu) idTask[%lu] MultiDelItem ItemType[%lu] Num(%d) Failed at %s, %d"
                            );
          return 0;
        }
        goto LAB_140259323;
      }
      local_498 = '\x01';
      cVar2 = local_498;
    }
    else {
      if (cVar2 != '\x03') {
        plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0);
        (**(code **)(*plVar9 + 0x40))(plVar9);
        local_4b8 = 0x214;
        log_InlineLogDBERROR
                  ("table:cq_task_reward_type, ID[%lu] can not find ucAttribute[%d] at %s, %d");
        return 0;
      }
      local_4b0 = (uint)local_4b0._1_3_ << 8;
      local_4b8 = 1;
      cVar2 = FUN_140338940(param_2,uVar6,uVar6,uVar14);
      if (cVar2 != '\0') {
        local_4b8 = local_4b8 & 0xffffff00;
        cVar2 = FUN_140345840(param_2,uVar6,uVar6,uVar14);
        if (cVar2 == '\0') {
          (**(code **)(*param_2 + 8))(param_2);
          local_4a0 = 0x20e;
          local_4a8 = 
          "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\roulette\\taskrewardmgr.cpp"
          ;
          local_4b8 = uVar6;
          local_4b0 = uVar14;
          log_InlineLogERROR(
                            "CTaskRewardMgr::LotteryConsume, user(id:%lu, account:%lu) idTask[%lu] MultiDelItemMonoPrioriy ItemType[%lu] Num(%d) Failed at %s, %d"
                            );
          return 0;
        }
        goto LAB_140259323;
      }
      local_498 = '\x01';
      cVar2 = local_498;
    }
    break;
  case 1:
    lVar13 = (**(code **)(*param_2 + 0x60))(param_2);
    if ((int)uVar14 <= lVar13) {
      cVar2 = (**(code **)(*param_2 + 0x178))(param_2,(longlong)(int)uVar14,1);
      if (cVar2 == '\0') {
        return 0;
      }
LAB_140259323:
      (**(code **)(*param_2 + 8))(param_2);
      local_4a8 = (char *)CONCAT44(local_4a8._4_4_,uVar6);
      local_4b0 = (uint)local_497;
      local_4b8 = param_5;
      local_4a0 = uVar14;
      tq::MyLogSave("gmlog/task_reward_cost",
                    "user_id[%lu] task_id[%lu] lottery_num[%d] cost_Type[%d] item_type[%lu] cost_num[%d]."
                   );
      return 1;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  case 2:
    if (*(char *)((longlong)param_2 + 0x51c) == '\0') {
      pIVar11 = theInstance();
      lVar13 = param_2[2];
      uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TASK_REWARD_NO_OPEN_PWD");
      (**(code **)(lVar13 + 0x358))(param_2 + 2,uVar12);
      return 0;
    }
    plVar9 = (longlong *)FUN_140118220();
    local_488 = plVar9;
    cVar3 = (**(code **)(*plVar9 + 0x28))(plVar9,param_4);
    if (cVar3 != '\0') {
      lVar13 = *plVar9;
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      iVar4 = (**(code **)(lVar13 + 0x38))(local_488,uVar7,param_4,4);
      uVar14 = uVar14 * (iVar4 + 1);
      local_494 = uVar14;
    }
    if ((int)uVar14 < 1) {
      return 0;
    }
    if (cVar2 == '\x02') {
      local_4a0 = 0x1092;
      local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x15e);
      local_4b0 = 0;
      local_4b8 = 0;
      cVar2 = FUN_14017bda0(param_2,uVar14,0x3d,2);
      if (cVar2 != '\0') goto LAB_140259323;
      local_498 = '\x01';
      cVar2 = local_498;
    }
    else if (cVar2 == '\x01') {
      local_4a0 = 0;
      local_4a8 = (char *)((ulonglong)local_4a8._4_4_ << 0x20);
      local_4b0 = 0x1091;
      local_4b8 = 0x15e;
      cVar3 = FUN_14017bda0(param_2,uVar14,0x3d,1);
      if (cVar3 != '\0') goto LAB_140259323;
    }
    else {
      if (cVar2 != '\x03') {
        plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0);
        (**(code **)(*plVar9 + 0x40))(plVar9);
        local_4b8 = 0x25a;
        log_InlineLogDBERROR
                  ("table:cq_task_reward_type, ID[%lu] can not find ucAttribute[%d] at %s, %d");
        return 0;
      }
      local_4a0 = 0x1093;
      local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x1092);
      local_4b0 = 0x1091;
      local_4b8 = 0x1090;
      cVar2 = FUN_14017bda0(param_2,uVar14,0x3d,3);
      if (cVar2 != '\0') goto LAB_140259323;
      local_498 = '\x01';
      cVar2 = local_498;
    }
    break;
  case 3:
    uVar8 = FUN_140165930(param_2);
    if (uVar14 <= uVar8) {
      iVar4 = FUN_140165930(param_2);
      FUN_140177500(param_2,iVar4 - uVar14,1);
      goto LAB_140259323;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  case 4:
    uVar8 = (**(code **)(*param_2 + 0x70))(param_2);
    if (uVar14 <= uVar8) {
      cVar2 = FUN_140162b60(param_2,-uVar14);
      if (cVar2 == '\0') {
        local_4b8 = 0x274;
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      goto LAB_140259323;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  case 5:
    lVar13 = FUN_1401669e0(param_2);
    if ((int)uVar14 <= lVar13) {
      cVar2 = FUN_1401669f0(param_2,(longlong)(int)-uVar14,1);
      if (cVar2 == '\0') {
        local_4b8 = 0x280;
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      goto LAB_140259323;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  case 6:
    uVar8 = FUN_140166bf0(param_2);
    if (uVar14 <= uVar8) {
      iVar4 = FUN_140166bf0(param_2);
      FUN_140166c00(param_2,iVar4 - uVar14,1);
      goto LAB_140259323;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  case 7:
    uVar8 = FUN_140168d50(param_2);
    if (uVar14 <= uVar8) {
      iVar4 = FUN_140168d50(param_2);
      cVar2 = FUN_140168d70(param_2,iVar4 - uVar14);
      if (cVar2 == '\0') {
        local_4b8 = 0x298;
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
      FUN_140168ce0(param_2);
      goto LAB_140259323;
    }
    local_498 = '\x01';
    cVar2 = local_498;
    break;
  default:
    plVar9 = (longlong *)(**(code **)(*param_3 + 8))(param_3,0);
    (**(code **)(*plVar9 + 0x40))(plVar9);
    log_InlineLogDBERROR("table:cq_task_reward_type, ID[%lu] can not find type[%d] define.");
    return 0;
  }
  local_498 = cVar2;
  FUN_1404249a0(local_478);
  cVar2 = FUN_140424a20(local_478,6,param_4);
  if (cVar2 == '\0') {
    local_4b8 = 0x2a5;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1404249f0(local_478);
  }
  else {
    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
    FUN_1404249f0(local_478);
  }
  return 0;
}

// ==== CMsgTaskReward::helper_14025b4b0  @14025b4b0  [medium:callgraph-r3]  (orig: FUN_14025b4b0)
undefined8 *
FUN_14025b4b0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xcccccccccccccca < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14025ac00(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x2c);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x2d) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x2d) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x2c);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x2c) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgTaskReward::helper_14025c660  @14025c660  [medium:callgraph-r3]  (orig: FUN_14025c660)
longlong * FUN_14025c660(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x2d) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x2d) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14025c7bd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14025c7ec;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x2d) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x2d);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x2d);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x2d);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x2d);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x2d) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x2d) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14025c7bd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14025b4b0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14025c7ec:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgTaskReward::helper_14025d0f0  @14025d0f0  [medium:callgraph-r1]  (orig: FUN_14025d0f0)
longlong * FUN_14025d0f0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x2d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x2d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgTaskReward::helper_14025d5a0  @14025d5a0  [medium:callgraph-r2]  (orig: FUN_14025d5a0)
undefined8 * FUN_14025d5a0(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14025b4b0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14025b4b0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14025b4b0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x2d) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x2d) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x2d);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x2d);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x2d);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x2d);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x2d) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x2d) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x2d) != '\0') {
              FUN_14025b4b0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14025b4b0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x2d) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x2d) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x2d);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x2d);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x2d);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x2d);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x2d) != '\0') {
              FUN_14025b4b0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14025b4b0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14025c660(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMsgTaskReward::helper_14025dac0  @14025dac0  [medium:callgraph-r1]  (orig: FUN_14025dac0)
undefined8 FUN_14025dac0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgTaskReward::helper_14025dbc0  @14025dbc0  [medium:callgraph-r1]  (orig: FUN_14025dbc0)
undefined4 FUN_14025dbc0(longlong param_1,int param_2)

{
  longlong lVar1;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_14025cee0((longlong *)(param_1 + 0x90),&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0xc0);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x90))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined4 *)(local_10 + 0x1c);
  }
  return 0;
}

// ==== CMsgTaskReward::helper_14025dc70  @14025dc70  [medium:callgraph-r0]  (orig: FUN_14025dc70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14025dc70(longlong param_1,longlong *param_2,int param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  longlong local_498;
  undefined8 local_490;
  longlong *local_488;
  longlong local_480;
  longlong local_478;
  undefined8 *local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if ((param_2 == (longlong *)0x0) || (param_3 == 0)) {
    uVar6 = 0;
  }
  else {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
    cVar4 = *(char *)((longlong)puVar9 + 0x2d);
    puVar2 = *(undefined8 **)(param_1 + 0x80);
    while (cVar4 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar5) {
        puVar7 = (undefined8 *)puVar9[2];
        puVar9 = puVar2;
      }
      else {
        puVar7 = (undefined8 *)*puVar9;
      }
      puVar2 = puVar9;
      puVar9 = puVar7;
      cVar4 = *(char *)((longlong)puVar7 + 0x2d);
    }
    local_470 = puVar2;
    local_478 = *(longlong *)(param_1 + 0x50);
    puVar9 = *(undefined8 **)(param_1 + 0x80);
    if (*(longlong *)(param_1 + 0x50) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar9) || (uVar5 < *(uint *)(puVar2 + 3))) {
      local_490 = *(undefined8 *)(param_1 + 0x80);
      local_498 = *(longlong *)(param_1 + 0x50);
      plVar8 = &local_498;
    }
    else {
      plVar8 = &local_478;
    }
    plVar1 = (longlong *)*plVar8;
    local_488 = plVar1;
    local_480 = plVar8[1];
    lVar10 = *(longlong *)(param_1 + 0x80);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x50))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_480;
    if (local_480 != lVar10) {
      FUN_1404249a0(local_458);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      cVar4 = FUN_140424a70(local_458,1,*(undefined1 *)(lVar3 + 0x20));
      if (cVar4 == '\0') {
        local_4a8 = 0x2be;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_1404249f0(local_458);
        return 0;
      }
      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_458);
      FUN_1404249f0(local_458);
    }
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgTaskReward::helper_14025de40  @14025de40  [medium:callgraph-r0]  (orig: FUN_14025de40)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_14025de40(longlong param_1,longlong *param_2,int param_3,char param_4)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong lVar12;
  undefined4 local_res10 [2];
  undefined8 local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong local_30;
  
  if ((param_2 == (longlong *)0x0) || ((param_4 == '\0' && (param_3 == 0)))) {
    return 0;
  }
  uVar5 = (**(code **)(*param_2 + 8))(param_2);
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar4 = *(char *)((longlong)puVar10 + 0x2d);
  puVar2 = *(undefined8 **)(param_1 + 0x80);
  while (cVar4 == '\0') {
    if (*(uint *)(puVar10 + 3) < uVar5) {
      puVar8 = (undefined8 *)puVar10[2];
      puVar10 = puVar2;
    }
    else {
      puVar8 = (undefined8 *)*puVar10;
    }
    puVar2 = puVar10;
    puVar10 = puVar8;
    cVar4 = *(char *)((longlong)puVar8 + 0x2d);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x80);
  local_50 = puVar2;
  local_58 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar10) || (uVar5 < *(uint *)(puVar2 + 3))) {
    plVar9 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x80);
    local_48 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar9 = &local_58;
  }
  plVar1 = (longlong *)*plVar9;
  lVar11 = *(longlong *)(param_1 + 0x80);
  local_38 = plVar1;
  local_30 = plVar9[1];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_30;
  if (local_30 == lVar11) {
LAB_14025df7d:
    uVar6 = 0;
  }
  else {
    lVar11 = 0;
    if (param_4 == '\0') {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar11;
      }
      else {
        lVar12 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(lVar3 + 0x1c) != param_3) goto LAB_14025df7d;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar1;
    }
    if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_58 = *(ulonglong *)(lVar3 + 0x1c);
    local_50 = *(undefined8 **)(lVar3 + 0x24);
    local_res10[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_14025cfb0(param_1 + 0x50,local_res10);
    cVar4 = FUN_140259bb0(param_1,param_2,local_58._5_1_,(ulonglong)local_50 & 0xffffffff);
    if (cVar4 == '\0') {
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/task_reward",
                    "CTaskRewardMgr::ObtainTaskReward, get task reward error, user_id[%u] task_id[%u] reward_type[%d] reward_value[%u] reward_index[%d] lottery_num[%d]."
                    ,uVar7 & 0xffffffff,local_58 & 0xffffffff);
    }
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgTaskReward::helper_14025e070  @14025e070  [medium:callgraph-r0]  (orig: FUN_14025e070)
ulonglong FUN_14025e070(longlong param_1,longlong param_2,int param_3)

{
  ulonglong in_RAX;
  longlong *plVar1;
  ulonglong extraout_RAX;
  undefined8 uVar2;
  ulonglong uVar3;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    in_RAX = FUN_140258b00();
    if ((char)in_RAX != '\0') {
      plVar1 = (longlong *)FUN_14025dac0(param_1,param_3);
      if (plVar1 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        in_RAX = extraout_RAX;
      }
      else {
        plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,0x1e);
        in_RAX = (**(code **)(*plVar1 + 0x40))(plVar1);
        if ((int)in_RAX != 0) {
          uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          uVar2 = FUN_140087730(uVar2);
          uVar3 = FUN_140145f60(uVar2,in_RAX & 0xffffffff,param_2,0,0,0);
          return uVar3;
        }
      }
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgTaskReward::helper_14025e270  @14025e270  [medium:callgraph-r1]  (orig: FUN_14025e270)
longlong FUN_14025e270(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  uint local_28 [8];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x2d) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x2d) == '\0');
  }
  plVar4 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar4 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar4,0);
    uStack_54 = (undefined4)((ulonglong)plVar4 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48 = 0;
    local_44 = 0;
    local_40 = 0;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_3c = 0;
    local_28[0] = *param_2;
    local_28[1] = 0;
    local_28[2] = 0;
    local_28[3] = 0;
    local_28[4] = 0;
    puVar3 = (undefined8 *)FUN_14025d5a0(param_1,&local_48,&local_38,local_28);
    plVar4 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar4 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar4;
  }
  if (puVar3 == *(undefined8 **)(lVar5 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar3 + 0x1c;
}

// ==== CMsgTaskReward::helper_14025e5c0  @14025e5c0  [medium:callgraph-r0]  (orig: FUN_14025e5c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14025e5c0(longlong param_1,longlong *param_2,int param_3,char param_4)

{
  ulonglong *puVar1;
  longlong lVar2;
  byte bVar3;
  uint uVar4;
  char cVar5;
  undefined1 uVar6;
  undefined4 uVar7;
  ulong uVar8;
  int iVar9;
  longlong *plVar10;
  longlong *plVar11;
  int *piVar12;
  ulonglong uVar13;
  byte bVar14;
  ulonglong uVar15;
  undefined1 auStack_518 [32];
  uint local_4f8;
  undefined4 local_4f0;
  uint local_4e8;
  undefined4 local_4e0;
  byte local_4d8;
  char local_4d7;
  int local_4d4;
  uint local_4d0 [2];
  int local_4c8;
  byte bStack_4c4;
  undefined1 uStack_4c3;
  undefined2 uStack_4c2;
  int local_4c0;
  int iStack_4bc;
  uint local_4b8;
  undefined4 local_4b4;
  longlong local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a4;
  undefined4 local_4a0;
  undefined4 local_49c;
  longlong local_498;
  undefined8 local_490;
  ulonglong *local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_490 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  if ((param_2 == (longlong *)0x0) || (param_3 == 0)) {
    uVar6 = 0;
  }
  else {
    local_4d7 = param_4;
    local_498 = param_1;
    cVar5 = FUN_140258b00();
    uVar6 = 0;
    if (cVar5 != '\0') {
      plVar10 = (longlong *)FUN_14025dac0(param_1,param_3);
      if (plVar10 == (longlong *)0x0) {
        local_4f8 = 0x152;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar6 = 0;
      }
      else {
        local_4d0[0] = FUN_14025dbc0(param_1,param_3);
        uVar6 = 0;
        if (local_4d0[0] != 0) {
          uVar13 = 0;
          local_4d4 = 0;
          local_4b4 = (**(code **)(*param_2 + 8))(param_2);
          FUN_14025d0f0(param_1 + 0x50,&local_4c8,&local_4b4);
          local_4b0 = *(longlong *)(param_1 + 0x80);
          local_488 = *(ulonglong **)(param_1 + 0x50);
          puVar1 = (ulonglong *)
                   CONCAT26(uStack_4c2,CONCAT15(uStack_4c3,CONCAT14(bStack_4c4,local_4c8)));
          if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_488)) {
            _invalid_parameter_noinfo();
          }
          lVar2 = CONCAT44(iStack_4bc,local_4c0);
          if (lVar2 != local_4b0) {
            if (puVar1 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar13;
            }
            else {
              uVar15 = *puVar1;
            }
            if (lVar2 == *(longlong *)(uVar15 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)(lVar2 + 0x1c) == param_3) {
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar15 = uVar13;
              }
              else {
                uVar15 = *puVar1;
              }
              if (lVar2 == *(longlong *)(uVar15 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              local_4d4 = *(int *)(lVar2 + 0x28);
              if (local_4d4 < 0) {
                return 0;
              }
            }
            else {
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar15 = uVar13;
              }
              else {
                uVar15 = *puVar1;
              }
              if (lVar2 == *(longlong *)(uVar15 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              local_4a8 = *(undefined4 *)(lVar2 + 0x1c);
              local_4a4 = *(uint *)(lVar2 + 0x20);
              local_4a0 = *(undefined4 *)(lVar2 + 0x24);
              local_49c = *(undefined4 *)(lVar2 + 0x28);
              uVar7 = (**(code **)(*param_2 + 8))(param_2);
              local_4b0 = CONCAT44(local_4b0._4_4_,uVar7);
              FUN_14025cfb0(param_1 + 0x50,&local_4b0);
              bVar14 = local_4a4._1_1_;
              cVar5 = FUN_140259bb0(param_1,param_2,local_4a4._1_1_,local_4a0);
              uVar4 = local_4a4;
              if (cVar5 == '\0') {
                (**(code **)(*param_2 + 8))(param_2);
                local_4e0 = local_49c;
                local_4e8 = uVar4 & 0xff;
                local_4f0 = local_4a0;
                local_4f8 = (uint)bVar14;
                tq::MyLogSave("gmlog/task_reward",
                              "CTaskRewardMgr::LotteryTaskReward, get task reward error, user_id[%u] task_id[%u] reward_type[%d] reward_value[%u] reward_index[%d] lottery_num[%d]."
                             );
              }
            }
          }
          local_4f8 = local_4d4;
          cVar5 = FUN_140258b60(param_1,param_2,plVar10,param_3);
          uVar6 = 0;
          if (cVar5 != '\0') {
            uVar8 = tq::TimeGet(0);
            iVar9 = rand();
            srand(uVar8 + iVar9);
            bVar14 = 0;
            local_4b8 = 0;
            local_4d0[0] = tq::RandGet(local_4d0[0]);
            local_4d8 = 0x16;
            while (bVar3 = local_4d8, local_4d8 < 0x1e) {
              plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,local_4d8);
              iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
              if (0 < iVar9) {
                local_4b8 = (int)uVar13 + iVar9;
                uVar13 = (ulonglong)local_4b8;
                if (local_4d0[0] <= local_4b8) {
                  bVar14 = bVar3 - 0x16;
                  break;
                }
              }
              local_4d8 = bVar3 + 1;
            }
            if (bVar14 < 8) {
              local_4c8 = param_3;
              bStack_4c4 = bVar14;
              plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,bVar14 + 6);
              uStack_4c3 = (**(code **)(*plVar11 + 0x20))(plVar11);
              plVar10 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,bVar14 + 0xe);
              local_4c0 = (**(code **)(*plVar10 + 0x50))(plVar10);
              iStack_4bc = local_4d4 + 1;
              local_4d0[0] = (**(code **)(*param_2 + 8))(param_2);
              piVar12 = (int *)FUN_14025e270(local_498 + 0x50,local_4d0);
              *piVar12 = local_4c8;
              piVar12[1] = CONCAT22(uStack_4c2,CONCAT11(uStack_4c3,bStack_4c4));
              piVar12[2] = local_4c0;
              piVar12[3] = iStack_4bc;
              if (local_4d7 != '\0') {
                FUN_1404249a0(local_478);
                cVar5 = FUN_140424a70(local_478,1,bVar14);
                if (cVar5 == '\0') {
                  local_4f8 = 0x1a9;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  FUN_1404249f0(local_478);
                  return 0;
                }
                (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
                FUN_1404249f0(local_478);
              }
              uVar6 = 1;
            }
            else {
              local_4f8 = 0x198;
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar6 = 0;
            }
          }
        }
      }
    }
  }
  return uVar6;
}

// ==== CMsgTaskReward::ctor_or_dtor  @1404249a0  [high:vtable-assign]  (orig: FUN_1404249a0)
undefined8 * FUN_1404249a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTaskReward::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTaskReward::ctor_or_dtor  @1404249f0  [high:vtable-assign]  (orig: FUN_1404249f0)
void FUN_1404249f0(undefined8 *param_1)

{
  *param_1 = CMsgTaskReward::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTaskReward::helper_140424a70  @140424a70  [medium:callgraph-r1]  (orig: FUN_140424a70)
undefined8 FUN_140424a70(longlong param_1,undefined1 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 5;
  *(undefined4 *)(param_1 + 8) = 0xafb;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 1) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgTaskReward::ctor_or_dtor  @140424b00  [high:vtable-assign]  (orig: FUN_140424b00)
undefined8 * FUN_140424b00(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTaskReward::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTaskReward::vfunc_3  @140424b50  [high:rtti-vtable]  (orig: FUN_140424b50)
void FUN_140424b50(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar2 + 0x1f0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else if (*(longlong *)(lVar2 + 0x1f0) != 0) {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      plVar4 = (longlong *)FUN_140087650(uVar3);
      lVar2 = (**(code **)(*plVar4 + 0x88))(plVar4,param_1);
      if (lVar2 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      cVar1 = **(char **)(param_1 + 0x428);
      if (cVar1 == '\x02') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1f0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar3 = 0;
        }
        else {
          uVar3 = *(undefined8 *)(lVar5 + 0x1f0);
        }
        FUN_14025dc70(uVar3,lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        return;
      }
      if (cVar1 == '\x03') {
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1f0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar3 = 0;
        }
        else {
          uVar3 = *(undefined8 *)(lVar5 + 0x1f0);
        }
        FUN_14025de40(uVar3,lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1),0);
        return;
      }
      if (cVar1 != '\x04') {
        if (cVar1 != '\x05') {
          return;
        }
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x1f0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar3 = 0;
        }
        else {
          uVar3 = *(undefined8 *)(lVar5 + 0x1f0);
        }
        FUN_14025e070(uVar3,lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1));
        return;
      }
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      if (*(longlong *)(lVar5 + 0x1f0) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = 0;
      }
      else {
        uVar3 = *(undefined8 *)(lVar5 + 0x1f0);
      }
      FUN_14025e5c0(uVar3,lVar2,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1),1);
      return;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return;
}

