// ==== CMsgVipUserHandle::helper_14021e940  @14021e940  [medium:callgraph-r3]  (orig: FUN_14021e940)
undefined8 *
FUN_14021e940(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14021e310(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgVipUserHandle::helper_14021ecc0  @14021ecc0  [medium:callgraph-r3]  (orig: FUN_14021ecc0)
undefined8 *
FUN_14021ecc0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xffffffffffffffd < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_14021e470(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x28);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x29) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x28) == '\0') {
        *(undefined1 *)(plVar2 + 5) = 1;
        *(undefined1 *)(lVar4 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x29) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x28) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x28) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x29) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x28);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x28) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgVipUserHandle::helper_14021f810  @14021f810  [medium:callgraph-r3]  (orig: FUN_14021f810)
longlong * FUN_14021f810(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14021f96d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14021f99c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14021f96d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14021e940(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14021f99c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgVipUserHandle::helper_14021f9c0  @14021f9c0  [medium:callgraph-r3]  (orig: FUN_14021f9c0)
longlong * FUN_14021f9c0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x29) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x29) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14021fb1d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14021fb4c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x29) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x29);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x29);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x29);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x29);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x29) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x29) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14021fb1d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_14021ecc0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14021fb4c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgVipUserHandle::helper_14021fe10  @14021fe10  [medium:callgraph-r0]  (orig: FUN_14021fe10)
undefined8 FUN_14021fe10(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgVipUserHandle::helper_140220e40  @140220e40  [medium:callgraph-r2]  (orig: FUN_140220e40)
undefined8 * FUN_140220e40(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14021e940(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14021e940(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14021e940(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_14021e940(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14021e940(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_14021e940(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14021e940(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14021f810(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMsgVipUserHandle::helper_140221160  @140221160  [medium:callgraph-r2]  (orig: FUN_140221160)
undefined8 * FUN_140221160(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14021ecc0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14021ecc0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14021ecc0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_14021ecc0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14021ecc0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_14021ecc0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14021ecc0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14021f9c0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMsgVipUserHandle::helper_140221480  @140221480  [medium:callgraph-r3]  (orig: FUN_140221480)
undefined8 * FUN_140221480(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14021f040(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14021f040(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14021f040(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x29);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x29);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x29);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x29) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x29) != '\0') {
              FUN_14021f040(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14021f040(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x29) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x29);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x29);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x29);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x29);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x29) != '\0') {
              FUN_14021f040(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14021f040(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14021fb70(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMsgVipUserHandle::helper_1402222b0  @1402222b0  [medium:callgraph-r1]  (orig: FUN_1402222b0)
undefined8 * FUN_1402222b0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_140220e40(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CMsgVipUserHandle::helper_1402223b0  @1402223b0  [medium:callgraph-r1]  (orig: FUN_1402223b0)
undefined8 * FUN_1402223b0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_140221160(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CMsgVipUserHandle::helper_1402224b0  @1402224b0  [medium:callgraph-r2]  (orig: FUN_1402224b0)
undefined8 * FUN_1402224b0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  uint local_48 [2];
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(uint *)(puVar3 + 3))) {
    local_58 = SUB84(plVar5,0);
    uStack_54 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_50 = SUB84(puVar3,0);
    uStack_4c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_48[0] = *param_2;
    local_38 = local_58;
    uStack_34 = uStack_54;
    uStack_30 = uStack_50;
    uStack_2c = uStack_4c;
    local_40 = 0;
    puVar3 = (undefined8 *)FUN_140221480(param_1,local_28,&local_38,local_48);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar3 + 4;
}

// ==== CMsgVipUserHandle::helper_140222880  @140222880  [medium:callgraph-r0]  (orig: FUN_140222880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140222880(longlong param_1,longlong *param_2,undefined4 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uVar6;
  ulong uVar7;
  undefined8 uVar8;
  IStringManager *pIVar9;
  IStringManager *pIVar10;
  char *pcVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined4 **ppuVar14;
  longlong lVar15;
  undefined4 *puVar16;
  longlong lVar17;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined4 *local_478;
  undefined8 *local_470;
  undefined4 *local_468;
  undefined8 local_460;
  longlong *local_458;
  undefined4 *local_450;
  undefined8 local_448;
  char local_438 [1024];
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_2 == (longlong *)0x0) {
    uVar8 = 0;
  }
  else {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar12 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
    cVar1 = *(char *)((longlong)puVar12 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x78);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar12 + 3) < uVar5) {
        puVar13 = (undefined8 *)puVar12[2];
        puVar12 = puVar3;
      }
      else {
        puVar13 = (undefined8 *)*puVar12;
      }
      puVar3 = puVar12;
      puVar12 = puVar13;
      cVar1 = *(char *)((longlong)puVar13 + 0x29);
    }
    local_470 = puVar3;
    local_478 = *(undefined4 **)(param_1 + 0x48);
    puVar12 = *(undefined8 **)(param_1 + 0x78);
    if (*(undefined4 **)(param_1 + 0x48) == (undefined4 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar12) || (uVar5 < *(uint *)(puVar3 + 3))) {
      local_460 = *(undefined8 *)(param_1 + 0x78);
      local_468 = *(undefined4 **)(param_1 + 0x48);
      ppuVar14 = &local_468;
    }
    else {
      ppuVar14 = &local_478;
    }
    plVar2 = (longlong *)*ppuVar14;
    local_458 = plVar2;
    local_450 = ppuVar14[1];
    puVar16 = *(undefined4 **)(param_1 + 0x78);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    puVar4 = local_450;
    if (local_450 == puVar16) {
      local_478 = operator_new(0x10);
      if (local_478 == (undefined4 *)0x0) {
        puVar16 = (undefined4 *)0x0;
      }
      else {
        local_478[3] = 0;
        *local_478 = 0;
        local_478[1] = 0;
        local_478[2] = 0xb4;
        puVar16 = local_478;
      }
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      *puVar16 = uVar6;
      puVar16[1] = param_3;
      uVar7 = tq::TimeGet(0);
      puVar16[3] = uVar7 / 1000;
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      local_478 = (undefined4 *)CONCAT44(local_478._4_4_,uVar6);
      puVar12 = (undefined8 *)FUN_1402223b0(param_1 + 0x48,&local_478);
      *puVar12 = puVar16;
      uVar8 = 1;
    }
    else {
      memset(local_438,0,0x400);
      lVar15 = 0;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar17 = lVar15;
      }
      else {
        lVar17 = *plVar2;
      }
      if (puVar4 == *(undefined4 **)(lVar17 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(*(longlong *)(puVar4 + 8) + 4) == 0) {
        pIVar9 = theInstance();
        pIVar10 = theInstance();
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar15 = *plVar2;
        }
        if (puVar4 == *(undefined4 **)(lVar15 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
        (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_USER_TRANSMIT_TRANS");
        pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_USER_TRANSMITING");
        local_488 = uVar6;
        _snprintf(local_438,0x3ff,pcVar11);
      }
      else {
        pIVar9 = theInstance();
        pIVar10 = theInstance();
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar15 = *plVar2;
        }
        if (puVar4 == *(undefined4 **)(lVar15 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
        (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_USER_TRANSMIT_TPSCROLL");
        pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_USER_TRANSMITING");
        local_488 = uVar6;
        _snprintf(local_438,0x3ff,pcVar11);
      }
      (**(code **)(param_2[2] + 0x358))(param_2 + 2,local_438);
      uVar8 = 0;
    }
  }
  return uVar8;
}

// ==== CMsgVipUserHandle::helper_140222b70  @140222b70  [medium:callgraph-r0]  (orig: FUN_140222b70)
void FUN_140222b70(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  uint uVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  uint local_res10 [2];
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong local_28;
  longlong local_20;
  
  if (param_2 != 0) {
    uVar4 = FUN_140416220(param_2);
    plVar6 = (longlong *)(param_1 + 8);
    puVar5 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar5 + 3) < uVar4) {
        puVar7 = (undefined8 *)puVar5[2];
        puVar5 = puVar3;
      }
      else {
        puVar7 = (undefined8 *)*puVar5;
      }
      puVar3 = puVar5;
      puVar5 = puVar7;
      cVar1 = *(char *)((longlong)puVar7 + 0x29);
    }
    puVar5 = *(undefined8 **)(param_1 + 0x38);
    local_40 = puVar3;
    local_48 = *plVar6;
    local_res10[0] = uVar4;
    if (*plVar6 == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar5) || (uVar4 < *(uint *)(puVar3 + 3))) {
      plVar8 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x38);
      local_38 = *plVar6;
    }
    else {
      plVar8 = &local_48;
    }
    local_28 = *plVar8;
    lVar2 = *(longlong *)(param_1 + 0x38);
    local_20 = plVar8[1];
    if ((local_28 == 0) || (local_28 != *plVar6)) {
      _invalid_parameter_noinfo();
    }
    if (local_20 != lVar2) {
      puVar5 = (undefined8 *)FUN_1402222b0(plVar6,local_res10);
      FUN_140416200(*puVar5);
    }
    plVar6 = (longlong *)FUN_1402222b0(plVar6,local_res10);
    *plVar6 = param_2;
  }
  return;
}

// ==== CMsgVipUserHandle::helper_140222c90  @140222c90  [medium:callgraph-r1]  (orig: FUN_140222c90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140222c90(longlong param_1,longlong *param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  uint uVar5;
  undefined4 uVar6;
  ulong uVar7;
  IStringManager *pIVar8;
  IStringManager *pIVar9;
  IStringManager *pIVar10;
  undefined8 uVar11;
  char *pcVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined4 **ppuVar15;
  longlong lVar16;
  undefined4 *puVar17;
  longlong lVar18;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_480;
  undefined4 *local_478;
  undefined8 *local_470;
  undefined4 *local_468;
  undefined8 local_460;
  longlong *local_458;
  undefined4 *local_450;
  undefined8 local_448;
  char local_438 [1024];
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_2 == (longlong *)0x0) {
    uVar11 = 0;
  }
  else {
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    puVar13 = (undefined8 *)(*(undefined8 **)(param_1 + 0xb8))[1];
    cVar1 = *(char *)((longlong)puVar13 + 0x29);
    puVar3 = *(undefined8 **)(param_1 + 0xb8);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar13 + 3) < uVar5) {
        puVar14 = (undefined8 *)puVar13[2];
        puVar13 = puVar3;
      }
      else {
        puVar14 = (undefined8 *)*puVar13;
      }
      puVar3 = puVar13;
      puVar13 = puVar14;
      cVar1 = *(char *)((longlong)puVar14 + 0x29);
    }
    local_470 = puVar3;
    local_478 = *(undefined4 **)(param_1 + 0x88);
    puVar13 = *(undefined8 **)(param_1 + 0xb8);
    if (*(undefined4 **)(param_1 + 0x88) == (undefined4 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar13) || (uVar5 < *(uint *)(puVar3 + 3))) {
      local_460 = *(undefined8 *)(param_1 + 0xb8);
      local_468 = *(undefined4 **)(param_1 + 0x88);
      ppuVar15 = &local_468;
    }
    else {
      ppuVar15 = &local_478;
    }
    plVar2 = (longlong *)*ppuVar15;
    local_458 = plVar2;
    local_450 = ppuVar15[1];
    puVar17 = *(undefined4 **)(param_1 + 0xb8);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x88))) {
      _invalid_parameter_noinfo();
    }
    puVar4 = local_450;
    if (local_450 == puVar17) {
      local_478 = operator_new(0x10);
      if (local_478 == (undefined4 *)0x0) {
        puVar17 = (undefined4 *)0x0;
      }
      else {
        local_478[3] = 0;
        *local_478 = 0;
        local_478[1] = 0;
        local_478[2] = 300;
        puVar17 = local_478;
      }
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      *puVar17 = uVar6;
      puVar17[1] = param_3;
      uVar7 = tq::TimeGet(0);
      puVar17[3] = uVar7 / 1000;
      uVar6 = (**(code **)(*param_2 + 8))(param_2);
      local_478 = (undefined4 *)CONCAT44(local_478._4_4_,uVar6);
      puVar13 = (undefined8 *)FUN_1402224b0(param_1 + 0x88,&local_478);
      *puVar13 = puVar17;
      uVar11 = 1;
    }
    else {
      memset(local_438,0,0x400);
      lVar16 = 0;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar18 = lVar16;
      }
      else {
        lVar18 = *plVar2;
      }
      if (puVar4 == *(undefined4 **)(lVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(*(longlong *)(puVar4 + 8) + 4) == 1) {
        if (param_3 == 1) {
          pIVar8 = theInstance();
          pIVar9 = theInstance();
          pIVar10 = theInstance();
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar16 = *plVar2;
          }
          if (puVar4 == *(undefined4 **)(lVar16 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar11 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
          uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
          (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
          pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_TEAM_TRANSMITING");
          local_488 = uVar6;
          local_480 = uVar11;
          _snprintf(local_438,0x3ff,pcVar12);
        }
        else {
          pIVar8 = theInstance();
          pIVar9 = theInstance();
          pIVar10 = theInstance();
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar16 = *plVar2;
          }
          if (puVar4 == *(undefined4 **)(lVar16 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          uVar11 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_VIP_TEAM_TRANSMIT_TRANS");
          uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
          (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
          pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_TEAM_TRANSMITING");
          local_488 = uVar6;
          local_480 = uVar11;
          _snprintf(local_438,0x3ff,pcVar12);
        }
      }
      else if (param_3 == 1) {
        pIVar8 = theInstance();
        pIVar9 = theInstance();
        pIVar10 = theInstance();
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar16 = *plVar2;
        }
        if (puVar4 == *(undefined4 **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar11 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
        uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
        (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_TEAM_TRANSMIT_TRANS");
        pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_TEAM_TRANSMITING");
        local_488 = uVar6;
        local_480 = uVar11;
        _snprintf(local_438,0x3ff,pcVar12);
      }
      else {
        pIVar8 = theInstance();
        pIVar9 = theInstance();
        pIVar10 = theInstance();
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar16 = *plVar2;
        }
        if (puVar4 == *(undefined4 **)(lVar16 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar11 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_VIP_TEAM_TRANSMIT_TRANS");
        uVar6 = FUN_14016b120(*(longlong *)(puVar4 + 8) + 8);
        (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_VIP_TEAM_TRANSMIT_TRANS");
        pcVar12 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_VIP_TEAM_TRANSMITING");
        local_488 = uVar6;
        local_480 = uVar11;
        _snprintf(local_438,0x3ff,pcVar12);
      }
      (**(code **)(param_2[2] + 0x358))(param_2 + 2,local_438);
      uVar11 = 0;
    }
  }
  return uVar11;
}

// ==== CMsgVipUserHandle::helper_140319a20  @140319a20  [medium:callgraph-r0]  (orig: FUN_140319a20)
undefined8 FUN_140319a20(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgVipUserHandle::helper_140416150  @140416150  [medium:callgraph-r0]  (orig: FUN_140416150)
undefined8 FUN_140416150(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xc0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 0xc0);
  }
  return *(undefined8 *)(param_1 + 0xc0);
}

// ==== CMsgVipUserHandle::helper_1404161b0  @1404161b0  [medium:callgraph-r0]  (orig: FUN_1404161b0)
longlong FUN_1404161b0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x130);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMsgVipUserHandle::helper_140416220  @140416220  [medium:callgraph-r1]  (orig: FUN_140416220)
undefined4 FUN_140416220(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x38);
}

// ==== CMsgVipUserHandle::helper_140416480  @140416480  [medium:callgraph-r0]  (orig: FUN_140416480)
undefined1 FUN_140416480(longlong param_1,int param_2)

{
  longlong *plVar1;
  int *piVar2;
  int *piVar3;
  longlong lVar4;
  
  piVar3 = *(int **)(param_1 + 0x20);
  if (*(int **)(param_1 + 0x28) < piVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 8);
  while( true ) {
    piVar2 = *(int **)(param_1 + 0x28);
    if (piVar2 < *(int **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (piVar3 == piVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(int **)(lVar4 + 0x20) <= piVar3) {
      _invalid_parameter_noinfo();
    }
    if (*piVar3 == param_2) {
      return 1;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(int **)(lVar4 + 0x20) <= piVar3) {
      _invalid_parameter_noinfo();
    }
    piVar3 = piVar3 + 1;
  }
  return 0;
}

// ==== CMsgVipUserHandle::helper_140416550  @140416550  [medium:callgraph-r0]  (orig: FUN_140416550)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140416550(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  char cVar2;
  undefined2 uVar3;
  ulong uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  IStringManager *pIVar12;
  undefined1 auStack_908 [32];
  uint local_8e8;
  undefined2 local_8e0;
  undefined4 local_8d8;
  undefined4 local_8d0;
  undefined8 local_8c8;
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_8c8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  if (param_2 == (longlong *)0x0) {
    local_8e8 = 0x79;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(int *)(param_1 + 0x5c) != 0) {
    uVar4 = tq::TimeGet(0);
    if (uVar4 / 1000 < (uint)(*(int *)(param_1 + 0x5c) + *(int *)(param_1 + 0x58))) {
      cVar2 = (**(code **)(param_2[2] + 0x220))(param_2 + 2);
      if (cVar2 != '\0') {
        uVar5 = (**(code **)(*param_2 + 8))(param_2);
        cVar2 = FUN_140416480(param_1,uVar5);
        if ((cVar2 != '\0') && (*(longlong *)(param_1 + 0x50) != 0)) {
          uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
          plVar10 = (longlong *)FUN_1400876b0(uVar9);
          lVar11 = (**(code **)(*plVar10 + 0x10))
                             (plVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 8),1);
          if (lVar11 != 0) {
            cVar2 = FUN_1402c3cc0(lVar11,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0xc),
                                  *(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0x10));
            if (cVar2 != '\0') {
              lVar11 = (**(code **)(param_2[2] + 0x160))(param_2 + 2);
              if (lVar11 != 0) {
                uVar5 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
                uVar6 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
                cVar2 = FUN_1402c3cc0(lVar11,uVar6,uVar5);
                if (cVar2 == '\0') {
                  pIVar12 = theInstance();
                  lVar1 = param_2[2];
                  uVar9 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_INVALID_COORDINATE");
                  (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar9);
                  cVar2 = FUN_14016cbd0(lVar11);
                  if (cVar2 == '\0') {
                    uVar5 = (**(code **)(**(longlong **)(lVar11 + 0x58) + 0x10))
                                      (*(longlong **)(lVar11 + 0x58),0xb);
                    uVar6 = (**(code **)(**(longlong **)(lVar11 + 0x58) + 0x10))
                                      (*(longlong **)(lVar11 + 0x58),0xc);
                    cVar2 = FUN_1402c3cc0(lVar11,uVar5,uVar6);
                    if (cVar2 != '\0') {
                      uVar7 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
                      local_8e8 = 0;
                      FUN_1401732e0(param_2,uVar7,uVar5,uVar6);
                    }
                  }
                  pIVar12 = theInstance();
                  uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
                  plVar10 = (longlong *)FUN_140087650(uVar9);
                  lVar11 = *plVar10;
                  uVar9 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_INVALID_COORDINATE");
                  (**(code **)(lVar11 + 0x50))(plVar10,param_2,uVar9);
                }
                else {
                  cVar2 = FUN_14016cbd0(lVar11);
                  if (cVar2 == '\0') {
                    uVar5 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
                    uVar6 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
                    uVar7 = (**(code **)(param_2[2] + 0x168))(param_2 + 2);
                    local_8e8 = 1;
                    FUN_1401732e0(param_2,uVar7,uVar6,uVar5);
                  }
                  lVar11 = *(longlong *)(param_1 + 0x50);
                  local_8e8 = local_8e8 & 0xffffff00;
                  iVar8 = FUN_1401c55b0(param_2,*(undefined4 *)(lVar11 + 8),
                                        *(undefined4 *)(lVar11 + 0xc),*(undefined4 *)(lVar11 + 0x10)
                                       );
                  if (iVar8 == 0) {
                    FUN_14045a870(local_8b8);
                    local_8e8 = 0;
                    iVar8 = FUN_14045a920(local_8b8,3,**(undefined4 **)(param_1 + 0x50));
                    if (iVar8 == 0) {
                      local_8e8 = 0xbf;
                      log_InlineLogERROR(&DAT_1406d9c10);
                    }
                    else {
                      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8b8);
                    }
                    FUN_140362560(local_488);
                    uVar3 = (**(code **)(param_2[2] + 0x50))(param_2 + 2);
                    uVar5 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
                    uVar6 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
                    uVar7 = (**(code **)(*param_2 + 8))(param_2);
                    local_8d0 = 0;
                    local_8d8 = 1;
                    local_8e0 = 1000;
                    local_8e8 = CONCAT22(local_8e8._2_2_,uVar3);
                    iVar8 = FUN_140362620(local_488,uVar7,uVar6,uVar5);
                    if (iVar8 != 0) {
                      (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_488);
                    }
                    FUN_1403625e0(local_488);
                    FUN_14045a8c0(local_8b8);
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgVipUserHandle::helper_140416a50  @140416a50  [medium:callgraph-r0]  (orig: FUN_140416a50)
longlong FUN_140416a50(undefined4 param_1)

{
  void *pvVar1;
  longlong lVar2;
  
  if ((DAT_140976378 & 1) == 0) {
    DAT_140976378 = DAT_140976378 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976370,"CVipTeamTrans");
    atexit((_func_5014 *)&LAB_1406d6d80);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976370,0x68);
  if (pvVar1 == (void *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = FUN_140416940(pvVar1,param_1);
  }
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pVipTeamTrans",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\vipteamtrans.cpp"
                       ,0x22);
    lVar2 = 0;
  }
  return lVar2;
}

// ==== CMsgVipUserHandle::helper_140416c30  @140416c30  [medium:callgraph-r0]  (orig: FUN_140416c30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140416c30(longlong param_1)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  int iVar5;
  ulong uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined4 *puVar11;
  longlong *plVar12;
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  longlong *local_4d8 [3];
  undefined4 *local_4c0;
  undefined4 *local_4b8;
  longlong local_4b0;
  longlong *local_4a8 [2];
  undefined8 local_498;
  undefined8 uStack_490;
  undefined8 local_488;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  FUN_14045a870(local_468);
  local_4e8 = 10;
  iVar5 = FUN_14045a920(local_468,2,**(undefined4 **)(param_1 + 0x50),param_1 + 0x40);
  if (iVar5 == 0) {
    local_4e8 = 0x5e;
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_14045a8c0(local_468);
  }
  else {
    local_4a8[0] = operator_new(8);
    plVar9 = (longlong *)0x0;
    local_4d8[0] = plVar9;
    if (local_4a8[0] != (longlong *)0x0) {
      *local_4a8[0] = (longlong)local_4d8;
      local_4d8[0] = local_4a8[0];
    }
    local_4c0 = (undefined4 *)0x0;
    local_4b8 = (undefined4 *)0x0;
    local_4b0 = 0;
    puVar11 = *(undefined4 **)(param_1 + 0x20);
    local_498 = local_4a8[0];
    if (*(undefined4 **)(param_1 + 0x28) < puVar11) {
      _invalid_parameter_noinfo();
    }
    puVar1 = *(undefined8 **)(param_1 + 8);
    while( true ) {
      puVar2 = *(undefined4 **)(param_1 + 0x28);
      if (puVar2 < *(undefined4 **)(param_1 + 0x20)) {
        _invalid_parameter_noinfo();
      }
      if ((puVar1 == (undefined8 *)0x0) || (puVar1 != *(undefined8 **)(param_1 + 8))) {
        _invalid_parameter_noinfo();
      }
      if (puVar11 == puVar2) break;
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
      if (*(longlong *)(lVar7 + 0x90) == 0) {
        local_4e8 = 0x130;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar10 = *(longlong **)(lVar7 + 0x90);
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar12 = plVar9;
      }
      else {
        plVar12 = (longlong *)*puVar1;
      }
      if ((undefined4 *)plVar12[4] <= puVar11) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (**(code **)(*plVar10 + 0x98))(plVar10,*puVar11);
      if (((lVar7 != 0) && (iVar5 = FUN_140166ec0(lVar7), iVar5 == 0)) &&
         (cVar4 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x220))(), puVar2 = local_4b8,
         cVar4 != '\0')) {
        local_4a8[0] = (longlong *)CONCAT44(local_4a8[0]._4_4_,*(undefined4 *)(lVar7 + 0x122c));
        plVar10 = plVar9;
        if (local_4c0 != (undefined4 *)0x0) {
          plVar10 = (longlong *)(local_4b0 - (longlong)local_4c0 >> 2);
        }
        if ((longlong *)((longlong)local_4b8 - (longlong)local_4c0 >> 2) < plVar10) {
          *local_4b8 = *(undefined4 *)(lVar7 + 0x122c);
          local_4b8 = local_4b8 + 1;
        }
        else {
          if (local_4b8 < local_4c0) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_4c0;
          plVar10 = local_4d8[0];
          local_498 = local_4d8[0];
          uStack_490 = puVar2;
          plVar12 = plVar9;
          if (((longlong)local_4b8 - (longlong)local_4c0 & 0xfffffffffffffffcU) != 0) {
            if (local_4b8 < local_4c0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar10 == (longlong *)0x0) || (plVar10 != local_4d8[0])) {
              _invalid_parameter_noinfo();
            }
            plVar12 = (longlong *)((longlong)puVar2 - (longlong)puVar3 >> 2);
          }
          local_478 = (undefined4)local_498;
          uStack_474 = local_498._4_4_;
          uStack_470 = (undefined4)uStack_490;
          uStack_46c = uStack_490._4_4_;
          FUN_140036c20(local_4d8,&local_478,1,local_4a8);
          puVar2 = local_4c0;
          if (local_4b8 < local_4c0) {
            _invalid_parameter_noinfo();
          }
          plVar10 = local_4d8[0];
          if (local_4d8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar9;
          }
          else {
            plVar8 = (longlong *)*local_4d8[0];
          }
          if (puVar2 + (longlong)plVar12 <= (undefined4 *)plVar8[4]) {
            plVar8 = plVar9;
            if (plVar10 != (longlong *)0x0) {
              plVar8 = (longlong *)*plVar10;
            }
            if ((undefined4 *)plVar8[3] <= puVar2 + (longlong)plVar12) goto LAB_140416f29;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_140416f29:
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar10 = plVar9;
      }
      else {
        plVar10 = (longlong *)*puVar1;
      }
      if ((undefined4 *)plVar10[4] <= puVar11) {
        _invalid_parameter_noinfo();
      }
      puVar11 = puVar11 + 1;
    }
    plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x60));
    (**(code **)(*plVar9 + 0x40))(plVar9,local_4d8,local_468);
    uVar6 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x5c) = uVar6 / 1000;
    if (local_4c0 != (undefined4 *)0x0) {
      operator_delete(local_4c0);
    }
    local_4c0 = (undefined4 *)0x0;
    local_4b8 = (undefined4 *)0x0;
    local_4b0 = 0;
    operator_delete(local_4d8[0]);
    FUN_14045a8c0(local_468);
  }
  return;
}

// ==== CMsgVipUserHandle::helper_140416ff0  @140416ff0  [medium:callgraph-r0]  (orig: FUN_140416ff0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140416ff0(longlong param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  int *piVar3;
  char cVar4;
  uint uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong lVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  char *pcVar13;
  longlong *plVar14;
  longlong *plVar15;
  IStringManager *pIVar16;
  ulonglong uVar17;
  longlong *plVar18;
  int *piVar19;
  undefined1 auStack_4c8 [32];
  ulonglong local_4a8;
  longlong *local_498 [3];
  int *local_480;
  int *local_478;
  undefined8 local_470;
  int local_468;
  longlong *local_460;
  longlong *local_458;
  undefined8 local_450;
  char local_448 [1024];
  ulonglong local_48;
  
  local_450 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 != 0) {
    *(int *)(param_1 + 0x3c) = param_2;
    local_468 = param_2;
    lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
    if (*(longlong *)(lVar9 + 0x90) == 0) {
      local_4a8 = CONCAT44(local_4a8._4_4_,0x130);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar9 = (**(code **)(**(longlong **)(lVar9 + 0x90) + 0x98))
                      (*(longlong **)(lVar9 + 0x90),param_2);
    if (lVar9 != 0) {
      lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
      plVar14 = (longlong *)0x0;
      plVar18 = *(longlong **)(lVar10 + 0x130);
      if (*(longlong **)(lVar10 + 0x130) == (longlong *)0x0) {
        local_4a8 = CONCAT44(local_4a8._4_4_,0x14b);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar18 = plVar14;
      }
      lVar10 = FUN_140319a20(plVar18,param_3);
      *(longlong *)(param_1 + 0x50) = lVar10;
      if (lVar10 == 0) {
        pIVar11 = theInstance();
        lVar10 = *(longlong *)(lVar9 + 0x10);
        uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_USER_VIP_NOT_EXIST_POINT");
        (**(code **)(lVar10 + 0x358))((longlong *)(lVar9 + 0x10),uVar12);
      }
      else {
        plVar18 = (longlong *)(lVar9 + 0x10);
        pcVar13 = (char *)(**(code **)(*plVar18 + 0x18))(plVar18);
        tq::SafeCopy((char *)(param_1 + 0x40),pcVar13,0x10);
        lVar10 = (**(code **)(*plVar18 + 0x160))(plVar18);
        if ((lVar10 != 0) && (cVar4 = FUN_140382350(lVar9), cVar4 == '\0')) {
          uVar12 = (**(code **)(*plVar18 + 0x160))(plVar18);
          cVar4 = FUN_140119510(uVar12);
          if (cVar4 == '\0') {
            iVar6 = *(int *)(*(longlong *)(param_1 + 0x50) + 4);
            if (iVar6 == 1) {
              uVar5 = FUN_1401649c0(lVar9);
              if (uVar5 < 3) {
                memset(local_448,0,0x400);
                pIVar11 = theInstance();
                FUN_1401649c0(lVar9);
                pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                            (pIVar11,"STR_USER_VIP_TOO_LOWER");
                local_4a8 = CONCAT44(local_4a8._4_4_,3);
                _snprintf(local_448,0x3ff,pcVar13);
                (**(code **)(*plVar18 + 0x358))(plVar18,local_448);
                return 0;
              }
            }
            else {
              if (iVar6 != 0) {
                return 0;
              }
              uVar5 = FUN_1401649c0(lVar9);
              if (uVar5 < 6) {
                memset(local_448,0,0x400);
                pIVar11 = theInstance();
                FUN_1401649c0(lVar9);
                pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar11)
                                            (pIVar11,"STR_USER_VIP_TOO_LOWER");
                local_4a8 = CONCAT44(local_4a8._4_4_,6);
                _snprintf(local_448,0x3ff,pcVar13);
                (**(code **)(*plVar18 + 0x358))(plVar18,local_448);
                return 0;
              }
            }
            local_460 = operator_new(8);
            if (local_460 != (longlong *)0x0) {
              *local_460 = (longlong)local_498;
              plVar14 = local_460;
            }
            local_480 = (int *)0x0;
            local_478 = (int *)0x0;
            local_470 = 0;
            local_498[0] = plVar14;
            local_458 = local_460;
            plVar14 = (longlong *)FUN_140118320();
            if (plVar14 == (longlong *)0x0) {
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            (**(code **)(*plVar14 + 0x38))(plVar14,param_2,local_498);
            if (((longlong)local_478 - (longlong)local_480 & 0xfffffffffffffffcU) == 0) {
              pIVar11 = theInstance();
              lVar9 = *plVar18;
              uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_USER_VIP_NO_TEAM");
              (**(code **)(lVar9 + 0x358))(plVar18,uVar12);
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            iVar6 = (**(code **)(*plVar14 + 0x28))(plVar14,param_2);
            *(int *)(param_1 + 0x38) = iVar6;
            if (iVar6 == 0) {
              pIVar11 = theInstance();
              lVar9 = *plVar18;
              uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_USER_VIP_NO_TEAM");
              (**(code **)(lVar9 + 0x358))(plVar18,uVar12);
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
            plVar14 = (longlong *)FUN_1400876b0(uVar12);
            lVar10 = (**(code **)(*plVar14 + 0x10))
                               (plVar14,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 8),1);
            if ((lVar10 == 0) ||
               (cVar4 = FUN_1402c3cc0(lVar10,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0xc),
                                      *(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0x10)),
               cVar4 == '\0')) {
              pIVar11 = theInstance();
              lVar9 = *plVar18;
              uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_CAN_STAND");
              (**(code **)(lVar9 + 0x358))(plVar18,uVar12);
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            lVar10 = *(longlong *)(param_1 + 0x50);
            uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
            uVar12 = FUN_140416150(uVar12);
            cVar4 = FUN_140222c90(uVar12,lVar9,*(undefined4 *)(lVar10 + 4));
            if (cVar4 == '\0') {
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            lVar10 = *(longlong *)(param_1 + 0x50);
            local_4a8 = local_4a8 & 0xffffffffffffff00;
            iVar6 = FUN_1401c55b0(lVar9,*(undefined4 *)(lVar10 + 8),*(undefined4 *)(lVar10 + 0xc),
                                  *(undefined4 *)(lVar10 + 0x10));
            if (iVar6 != 0) {
              pIVar11 = theInstance();
              lVar9 = *plVar18;
              uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_CAN_STAND");
              (**(code **)(lVar9 + 0x358))(plVar18,uVar12);
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
            plVar14 = (longlong *)FUN_1400876b0(uVar12);
            local_460 = plVar14;
            if (plVar14 == (longlong *)0x0) {
              if (local_480 != (int *)0x0) {
                operator_delete(local_480);
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              operator_delete(local_498[0]);
              return 0;
            }
            FUN_140036640(param_1 + 8);
            piVar19 = local_480;
            plVar2 = local_498[0];
            if (local_478 < local_480) {
              _invalid_parameter_noinfo();
              plVar2 = local_498[0];
            }
            do {
              piVar3 = local_478;
              if (local_478 < local_480) {
                _invalid_parameter_noinfo();
              }
              if ((plVar2 == (longlong *)0x0) || (plVar2 != local_498[0])) {
                _invalid_parameter_noinfo();
              }
              if (piVar19 == piVar3) {
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 1;
              }
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar2;
              }
              if (*(int **)(lVar9 + 0x20) <= piVar19) {
                _invalid_parameter_noinfo();
              }
              if (*piVar19 != param_2) {
                if (plVar2 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar9 = 0;
                }
                else {
                  lVar9 = *plVar2;
                }
                if (*(int **)(lVar9 + 0x20) <= piVar19) {
                  _invalid_parameter_noinfo();
                }
                if (*piVar19 != 0) {
                  uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
                  plVar15 = (longlong *)FUN_140087650(uVar12);
                  if (plVar2 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar9 = 0;
                  }
                  else {
                    lVar9 = *plVar2;
                  }
                  if (*(int **)(lVar9 + 0x20) <= piVar19) {
                    _invalid_parameter_noinfo();
                  }
                  plVar15 = (longlong *)(**(code **)(*plVar15 + 0x98))(plVar15,*piVar19);
                  if (plVar15 != (longlong *)0x0) {
                    lVar9 = *plVar14;
                    plVar1 = plVar15 + 2;
                    uVar7 = (**(code **)(*plVar1 + 0x168))(plVar1);
                    lVar9 = (**(code **)(lVar9 + 0x10))(plVar14,uVar7,1);
                    if (lVar9 == 0) {
                      if (local_480 != (int *)0x0) {
                        operator_delete(local_480);
                      }
                      local_480 = (int *)0x0;
                      local_478 = (int *)0x0;
                      local_470 = 0;
                      operator_delete(local_498[0]);
                      return 0;
                    }
                    uVar7 = (**(code **)(*plVar1 + 0x48))(plVar1);
                    uVar8 = (**(code **)(*plVar1 + 0x40))(plVar1);
                    cVar4 = FUN_1402c68a0(lVar9,7,uVar8,uVar7);
                    if (((cVar4 == '\0') && (cVar4 = FUN_14016ccf0(lVar9), cVar4 == '\0')) &&
                       (cVar4 = FUN_140382350(plVar15), cVar4 == '\0')) {
                      uVar12 = (**(code **)(*plVar1 + 0x160))(plVar1);
                      cVar4 = FUN_140119510(uVar12);
                      if (cVar4 == '\0') {
                        uVar7 = (**(code **)(*plVar15 + 8))(plVar15);
                        cVar4 = FUN_140416480(param_1,uVar7);
                        plVar14 = local_460;
                        param_2 = local_468;
                        if (cVar4 == '\0') {
                          uVar7 = (**(code **)(*plVar15 + 8))(plVar15);
                          local_458 = (longlong *)CONCAT44(local_458._4_4_,uVar7);
                          FUN_140037fe0(param_1 + 8,&local_458);
                          plVar14 = local_460;
                          param_2 = local_468;
                        }
                        goto LAB_14041783f;
                      }
                    }
                    memset(local_448,0,0x400);
                    if (*(int *)(*(longlong *)(param_1 + 0x50) + 4) == 1) {
                      pIVar11 = theInstance();
                      pIVar16 = theInstance();
                      uVar17 = (*(code *)**(undefined8 **)pIVar11)
                                         (pIVar11,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
                      (**(code **)(*plVar18 + 0x18))(plVar18);
                      pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar16)
                                                  (pIVar16,"STR_USER_VIP_ERROR_MAP");
                      local_4a8 = uVar17;
                      _snprintf(local_448,0x3ff,pcVar13);
                    }
                    else {
                      pIVar11 = theInstance();
                      pIVar16 = theInstance();
                      uVar17 = (*(code *)**(undefined8 **)pIVar11)
                                         (pIVar11,"STR_VIP_TEAM_TRANSMIT_TRANS");
                      (**(code **)(*plVar18 + 0x18))(plVar18);
                      pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar16)
                                                  (pIVar16,"STR_USER_VIP_ERROR_MAP");
                      local_4a8 = uVar17;
                      _snprintf(local_448,0x3ff,pcVar13);
                    }
                    (**(code **)(*plVar1 + 0x358))(plVar1,local_448);
                    plVar14 = local_460;
                    param_2 = local_468;
                  }
                }
              }
LAB_14041783f:
              if (plVar2 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar2;
              }
              if (*(int **)(lVar9 + 0x20) <= piVar19) {
                _invalid_parameter_noinfo();
              }
              piVar19 = piVar19 + 1;
            } while( true );
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMsgVipUserHandle::helper_140417960  @140417960  [medium:callgraph-r0]  (orig: FUN_140417960)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140417960(longlong param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  int *piVar4;
  char cVar5;
  ulong uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong lVar12;
  IStringManager *pIVar13;
  char *pcVar14;
  undefined8 uVar15;
  longlong lVar16;
  longlong *plVar17;
  longlong *plVar18;
  IStringManager *pIVar19;
  ulonglong uVar20;
  int *piVar21;
  undefined1 auStack_4c8 [32];
  ulonglong local_4a8;
  longlong *local_498 [3];
  int *local_480;
  int *local_478;
  undefined8 local_470;
  int local_468;
  longlong *local_460;
  longlong *local_458;
  undefined8 local_450;
  char local_448 [1024];
  ulonglong local_48;
  
  local_450 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 != 0) {
    local_468 = param_2;
    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
    if (*(longlong *)(lVar12 + 0x90) == 0) {
      local_4a8 = CONCAT44(local_4a8._4_4_,0x130);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar12 = (**(code **)(**(longlong **)(lVar12 + 0x90) + 0x98))
                       (*(longlong **)(lVar12 + 0x90),param_2);
    if ((*(int *)(param_1 + 0x5c) == 0) ||
       (uVar6 = tq::TimeGet(0),
       (uint)(*(int *)(param_1 + 0x5c) + *(int *)(param_1 + 0x58)) <= uVar6 / 1000)) {
      *(int *)(param_1 + 0x3c) = param_2;
      if (lVar12 != 0) {
        uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
        uVar15 = FUN_1404161b0(uVar15);
        lVar16 = FUN_140319a20(uVar15,param_3);
        *(longlong *)(param_1 + 0x50) = lVar16;
        if (lVar16 == 0) {
          pIVar13 = theInstance();
          lVar16 = *(longlong *)(lVar12 + 0x10);
          uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_USER_VIP_NOT_EXIST_POINT");
          (**(code **)(lVar16 + 0x358))((longlong *)(lVar12 + 0x10),uVar15);
        }
        else {
          plVar1 = (longlong *)(lVar12 + 0x10);
          pcVar14 = (char *)(**(code **)(*plVar1 + 0x18))(plVar1);
          tq::SafeCopy((char *)(param_1 + 0x40),pcVar14,0x10);
          lVar16 = (**(code **)(*plVar1 + 0x160))(plVar1);
          if ((lVar16 != 0) && (cVar5 = FUN_140382350(lVar12), cVar5 == '\0')) {
            uVar15 = (**(code **)(*plVar1 + 0x160))(plVar1);
            cVar5 = FUN_140119510(uVar15);
            if (cVar5 == '\0') {
              iVar8 = *(int *)(*(longlong *)(param_1 + 0x50) + 4);
              if (iVar8 == 1) {
                uVar7 = FUN_1401649c0(lVar12);
                if (uVar7 < 3) {
                  memset(local_448,0,0x400);
                  pIVar13 = theInstance();
                  FUN_1401649c0(lVar12);
                  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                              (pIVar13,"STR_USER_VIP_TOO_LOWER");
                  local_4a8 = CONCAT44(local_4a8._4_4_,3);
                  _snprintf(local_448,0x3ff,pcVar14);
                  (**(code **)(*plVar1 + 0x358))(plVar1,local_448);
                  return 0;
                }
              }
              else {
                if (iVar8 != 0) {
                  return 0;
                }
                uVar7 = FUN_1401649c0(lVar12);
                if (uVar7 < 6) {
                  memset(local_448,0,0x400);
                  pIVar13 = theInstance();
                  FUN_1401649c0(lVar12);
                  pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                              (pIVar13,"STR_USER_VIP_TOO_LOWER");
                  local_4a8 = CONCAT44(local_4a8._4_4_,6);
                  _snprintf(local_448,0x3ff,pcVar14);
                  (**(code **)(*plVar1 + 0x358))(plVar1,local_448);
                  return 0;
                }
              }
              local_460 = operator_new(8);
              local_498[0] = (longlong *)0x0;
              if (local_460 != (longlong *)0x0) {
                *local_460 = (longlong)local_498;
                local_498[0] = local_460;
              }
              local_480 = (int *)0x0;
              local_478 = (int *)0x0;
              local_470 = 0;
              local_458 = local_460;
              plVar17 = (longlong *)FUN_140118320();
              if (plVar17 == (longlong *)0x0) {
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              (**(code **)(*plVar17 + 0x38))(plVar17,param_2,local_498);
              if (((longlong)local_478 - (longlong)local_480 & 0xfffffffffffffffcU) == 0) {
                pIVar13 = theInstance();
                lVar12 = *plVar1;
                uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_USER_VIP_NO_TEAM");
                (**(code **)(lVar12 + 0x358))(plVar1,uVar15);
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              iVar8 = (**(code **)(*plVar17 + 0x28))(plVar17,param_2);
              iVar9 = (**(code **)(*plVar17 + 0x28))(plVar17,param_2);
              *(int *)(param_1 + 0x38) = iVar9;
              if (iVar9 != iVar8) {
                pIVar13 = theInstance();
                lVar12 = *plVar1;
                uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_USER_VIP_ERROR_TEAM");
                (**(code **)(lVar12 + 0x358))(plVar1,uVar15);
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
              plVar17 = (longlong *)FUN_1400876b0(uVar15);
              lVar16 = (**(code **)(*plVar17 + 0x10))
                                 (plVar17,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 8),1);
              if ((lVar16 == 0) ||
                 (cVar5 = FUN_1402c3cc0(lVar16,*(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0xc),
                                        *(undefined4 *)(*(longlong *)(param_1 + 0x50) + 0x10)),
                 cVar5 == '\0')) {
                pIVar13 = theInstance();
                lVar12 = *plVar1;
                uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_CAN_STAND");
                (**(code **)(lVar12 + 0x358))(plVar1,uVar15);
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              lVar16 = *(longlong *)(param_1 + 0x50);
              uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
              uVar15 = FUN_140416150(uVar15);
              cVar5 = FUN_140222c90(uVar15,lVar12,*(undefined4 *)(lVar16 + 4));
              if (cVar5 == '\0') {
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              lVar16 = *(longlong *)(param_1 + 0x50);
              local_4a8 = local_4a8 & 0xffffffffffffff00;
              iVar8 = FUN_1401c55b0(lVar12,*(undefined4 *)(lVar16 + 8),*(undefined4 *)(lVar16 + 0xc)
                                    ,*(undefined4 *)(lVar16 + 0x10));
              if (iVar8 != 0) {
                pIVar13 = theInstance();
                lVar12 = *plVar1;
                uVar15 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_CAN_STAND");
                (**(code **)(lVar12 + 0x358))(plVar1,uVar15);
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
              plVar17 = (longlong *)FUN_1400876b0(uVar15);
              local_460 = plVar17;
              if (plVar17 == (longlong *)0x0) {
                if (local_480 != (int *)0x0) {
                  operator_delete(local_480);
                }
                local_480 = (int *)0x0;
                local_478 = (int *)0x0;
                local_470 = 0;
                operator_delete(local_498[0]);
                return 0;
              }
              FUN_140036640(param_1 + 8);
              piVar21 = local_480;
              plVar3 = local_498[0];
              if (local_478 < local_480) {
                _invalid_parameter_noinfo();
                plVar3 = local_498[0];
              }
              do {
                piVar4 = local_478;
                if (local_478 < local_480) {
                  _invalid_parameter_noinfo();
                }
                if ((plVar3 == (longlong *)0x0) || (plVar3 != local_498[0])) {
                  _invalid_parameter_noinfo();
                }
                if (piVar21 == piVar4) {
                  if (local_480 != (int *)0x0) {
                    operator_delete(local_480);
                  }
                  local_480 = (int *)0x0;
                  local_478 = (int *)0x0;
                  local_470 = 0;
                  operator_delete(local_498[0]);
                  return 1;
                }
                if (plVar3 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar12 = 0;
                }
                else {
                  lVar12 = *plVar3;
                }
                if (*(int **)(lVar12 + 0x20) <= piVar21) {
                  _invalid_parameter_noinfo();
                }
                if (*piVar21 != param_2) {
                  if (plVar3 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar12 = 0;
                  }
                  else {
                    lVar12 = *plVar3;
                  }
                  if (*(int **)(lVar12 + 0x20) <= piVar21) {
                    _invalid_parameter_noinfo();
                  }
                  if (*piVar21 != 0) {
                    uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
                    plVar18 = (longlong *)FUN_140087650(uVar15);
                    if (plVar3 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar12 = 0;
                    }
                    else {
                      lVar12 = *plVar3;
                    }
                    if (*(int **)(lVar12 + 0x20) <= piVar21) {
                      _invalid_parameter_noinfo();
                    }
                    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x98))(plVar18,*piVar21);
                    if (plVar18 != (longlong *)0x0) {
                      lVar12 = *plVar17;
                      plVar2 = plVar18 + 2;
                      uVar10 = (**(code **)(*plVar2 + 0x168))(plVar2);
                      lVar12 = (**(code **)(lVar12 + 0x10))(plVar17,uVar10,1);
                      if (lVar12 == 0) {
                        if (local_480 != (int *)0x0) {
                          operator_delete(local_480);
                        }
                        local_480 = (int *)0x0;
                        local_478 = (int *)0x0;
                        local_470 = 0;
                        operator_delete(local_498[0]);
                        return 0;
                      }
                      uVar10 = (**(code **)(*plVar2 + 0x48))(plVar2);
                      uVar11 = (**(code **)(*plVar2 + 0x40))(plVar2);
                      cVar5 = FUN_1402c68a0(lVar12,7,uVar11,uVar10);
                      if (((cVar5 == '\0') && (cVar5 = FUN_14016ccf0(lVar12), cVar5 == '\0')) &&
                         (cVar5 = FUN_140382350(plVar18), cVar5 == '\0')) {
                        uVar15 = (**(code **)(*plVar2 + 0x160))(plVar2);
                        cVar5 = FUN_140119510(uVar15);
                        if (cVar5 == '\0') {
                          uVar10 = (**(code **)(*plVar18 + 8))(plVar18);
                          cVar5 = FUN_140416480(param_1,uVar10);
                          plVar17 = local_460;
                          param_2 = local_468;
                          if (cVar5 == '\0') {
                            uVar10 = (**(code **)(*plVar18 + 8))(plVar18);
                            local_458 = (longlong *)CONCAT44(local_458._4_4_,uVar10);
                            FUN_140037fe0(param_1 + 8,&local_458);
                            plVar17 = local_460;
                            param_2 = local_468;
                          }
                          goto LAB_14041821f;
                        }
                      }
                      memset(local_448,0,0x400);
                      if (*(int *)(*(longlong *)(param_1 + 0x50) + 4) == 1) {
                        pIVar13 = theInstance();
                        pIVar19 = theInstance();
                        uVar20 = (*(code *)**(undefined8 **)pIVar13)
                                           (pIVar13,"STR_VIP_TEAM_TRANSMIT_TPSCROLL");
                        (**(code **)(*plVar1 + 0x18))(plVar1);
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar19)
                                                    (pIVar19,"STR_USER_VIP_ERROR_MAP");
                        local_4a8 = uVar20;
                        _snprintf(local_448,0x3ff,pcVar14);
                      }
                      else {
                        pIVar13 = theInstance();
                        pIVar19 = theInstance();
                        uVar20 = (*(code *)**(undefined8 **)pIVar13)
                                           (pIVar13,"STR_VIP_TEAM_TRANSMIT_TRANS");
                        (**(code **)(*plVar1 + 0x18))(plVar1);
                        pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar19)
                                                    (pIVar19,"STR_USER_VIP_ERROR_MAP");
                        local_4a8 = uVar20;
                        _snprintf(local_448,0x3ff,pcVar14);
                      }
                      (**(code **)(*plVar2 + 0x358))(plVar2,local_448);
                      plVar17 = local_460;
                      param_2 = local_468;
                    }
                  }
                }
LAB_14041821f:
                if (plVar3 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar12 = 0;
                }
                else {
                  lVar12 = *plVar3;
                }
                if (*(int **)(lVar12 + 0x20) <= piVar21) {
                  _invalid_parameter_noinfo();
                }
                piVar21 = piVar21 + 1;
              } while( true );
            }
          }
        }
      }
    }
    else {
      memset(local_448,0,0x400);
      pIVar13 = theInstance();
      pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar13)
                                  (pIVar13,"STR_USER_VIP_COUNT_DOWN_NOT_OVER");
      _snprintf(local_448,0x3ff,pcVar14);
      (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x358))((longlong *)(lVar12 + 0x10),local_448);
    }
  }
  return 0;
}

// ==== CMsgVipUserHandle::ctor_or_dtor  @14045a870  [high:vtable-assign]  (orig: FUN_14045a870)
undefined8 * FUN_14045a870(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgVipUserHandle::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgVipUserHandle::ctor_or_dtor  @14045a8c0  [high:vtable-assign]  (orig: FUN_14045a8c0)
void FUN_14045a8c0(undefined8 *param_1)

{
  *param_1 = CMsgVipUserHandle::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgVipUserHandle::vfunc_1  @14045a8f0  [high:rtti-vtable]  (orig: FUN_14045a8f0)
ulonglong FUN_14045a8f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x468);
}

// ==== CMsgVipUserHandle::helper_14045a920  @14045a920  [medium:callgraph-r1]  (orig: FUN_14045a920)
undefined8
FUN_14045a920(longlong param_1,undefined1 param_2,undefined4 param_3,char *param_4,
             undefined4 param_5)

{
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_5;
  if (param_4 != (char *)0x0) {
    tq::SafeCopy((char *)(*(longlong *)(param_1 + 0x428) + 0xc),param_4,0x10);
  }
  *(undefined4 *)(param_1 + 8) = 0x468;
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  return 1;
}

// ==== CMsgVipUserHandle::ctor_or_dtor  @14045a9b0  [high:vtable-assign]  (orig: FUN_14045a9b0)
undefined8 * FUN_14045a9b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgVipUserHandle::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgVipUserHandle::vfunc_3  @14045aa00  [high:rtti-vtable]  (orig: FUN_14045aa00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14045aa00(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  longlong *plVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong lVar12;
  char *pcVar13;
  undefined1 auStack_468 [32];
  uint local_448;
  undefined4 local_438;
  undefined4 local_434;
  undefined4 local_430;
  char local_428 [1024];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    local_448 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = *(longlong **)(lVar5 + 0x90);
  if (plVar6 == (longlong *)0x0) {
    return;
  }
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x88))(plVar6,param_1);
  if (plVar6 == (longlong *)0x0) {
    return;
  }
  plVar11 = plVar6 + 2;
  cVar1 = (**(code **)(plVar6[2] + 0x220))(plVar11);
  if (cVar1 == '\0') {
    pIVar7 = theInstance();
    lVar5 = *plVar11;
    uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_DIE");
    (**(code **)(lVar5 + 0x358))(plVar11,uVar8);
    return;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  lVar5 = FUN_140416150(uVar8);
  if (lVar5 == 0) {
    return;
  }
  pcVar13 = *(char **)(param_1 + 0x428);
  cVar1 = *pcVar13;
  if (cVar1 == '\0') {
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar8 = FUN_1404161b0(uVar8);
    lVar10 = FUN_140319a20(uVar8,*(undefined4 *)(pcVar13 + 4));
    if (lVar10 != 0) {
      if (*(int *)(lVar10 + 4) == 0) {
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        cVar1 = FUN_14008ab60(uVar8);
        if (cVar1 == '\0') {
          return;
        }
        uVar4 = FUN_1401649c0(plVar6);
        if (uVar4 < 3) {
          memset(local_428,0,0x400);
          pIVar7 = theInstance();
          FUN_1401649c0(plVar6);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_USER_VIP_TOO_LOWER");
          local_448 = 3;
LAB_14045ae07:
          _snprintf(local_428,0x3ff,pcVar13);
          (**(code **)(*plVar11 + 0x358))(plVar11,local_428);
          return;
        }
      }
      else {
        if (*(int *)(lVar10 + 4) != 1) {
          return;
        }
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        cVar1 = FUN_14008ab60(uVar8);
        if (cVar1 == '\0') {
          return;
        }
        uVar4 = FUN_1401649c0(plVar6);
        if (uVar4 < 2) {
          memset(local_428,0,0x400);
          pIVar7 = theInstance();
          FUN_1401649c0(plVar6);
          pcVar13 = (char *)(*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_USER_VIP_TOO_LOWER");
          local_448 = 2;
          goto LAB_14045ae07;
        }
      }
      cVar1 = FUN_140382350(plVar6);
      if (cVar1 == '\0') {
        lVar12 = (**(code **)(*plVar11 + 0x160))(plVar11);
        if (lVar12 != 0) {
          uVar8 = (**(code **)(*plVar11 + 0x160))(plVar11);
          cVar1 = FUN_140119510(uVar8);
          if (cVar1 == '\0') {
            cVar1 = FUN_140222880(lVar5,plVar6,*(undefined4 *)(lVar10 + 4));
            if (cVar1 == '\0') {
              return;
            }
            uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            plVar9 = (longlong *)FUN_1400876b0(uVar8);
            lVar5 = (**(code **)(*plVar9 + 0x10))(plVar9,*(undefined4 *)(lVar10 + 8),1);
            if ((lVar5 != 0) &&
               (cVar1 = FUN_1402c3cc0(lVar5,*(undefined4 *)(lVar10 + 0xc),
                                      *(undefined4 *)(lVar10 + 0x10)), cVar1 != '\0')) {
              local_448 = local_448 & 0xffffff00;
              iVar3 = FUN_1401c55b0(plVar6,*(undefined4 *)(lVar10 + 8),*(undefined4 *)(lVar10 + 0xc)
                                    ,*(undefined4 *)(lVar10 + 0x10));
              if (iVar3 == 0) {
                return;
              }
              local_438 = 0;
              local_434 = 0;
              local_430 = 0;
              uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              uVar8 = FUN_1400d6610(uVar8);
              FUN_140006c50(uVar8,&local_438);
              local_448 = local_448 & 0xffffff00;
              FUN_1401c55b0(plVar6,local_438,local_434,local_430);
              log_InlineLogDBERROR(&DAT_140780860);
              uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              plVar11 = (longlong *)FUN_140087650(uVar8);
              (**(code **)(*plVar11 + 0x50))(plVar11,plVar6,&DAT_140780840);
              return;
            }
            pIVar7 = theInstance();
            pcVar13 = "STR_CAN_STAND";
            goto LAB_14045af9a;
          }
        }
        pIVar7 = theInstance();
        pcVar13 = "STR_MAP_NOT_TRANSMIT";
      }
      else {
        pIVar7 = theInstance();
        pcVar13 = "STR_IN_CURSE";
      }
      goto LAB_14045af9a;
    }
  }
  else {
    if (cVar1 != '\x01') {
      if (cVar1 != '\x03') {
        return;
      }
      plVar9 = (longlong *)FUN_140118320();
      if (plVar9 == (longlong *)0x0) {
        return;
      }
      lVar10 = *plVar9;
      uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
      iVar3 = (**(code **)(lVar10 + 0x28))(plVar9,uVar2);
      if (iVar3 != 0) {
        lVar5 = FUN_14021fe10(lVar5,iVar3);
        if (lVar5 == 0) {
          return;
        }
        uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
        cVar1 = FUN_140416480(lVar5,uVar2);
        if (cVar1 == '\0') {
          return;
        }
        FUN_140416550(lVar5,plVar6);
        return;
      }
      pIVar7 = theInstance();
      pcVar13 = "STR_USER_VIP_NO_TEAM";
      goto LAB_14045af9a;
    }
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar8 = FUN_1404161b0(uVar8);
    lVar10 = FUN_140319a20(uVar8,*(undefined4 *)(pcVar13 + 4));
    if (lVar10 != 0) {
      if (*(int *)(lVar10 + 4) == 0) {
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        cVar1 = FUN_14008ab60(uVar8,5);
      }
      else {
        if (*(int *)(lVar10 + 4) != 1) {
          return;
        }
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        cVar1 = FUN_14008ab60(uVar8,7);
      }
      if (cVar1 == '\0') {
        return;
      }
      plVar11 = (longlong *)FUN_140118320();
      if (plVar11 == (longlong *)0x0) {
        return;
      }
      lVar10 = *plVar11;
      uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
      iVar3 = (**(code **)(lVar10 + 0x28))(plVar11,uVar2);
      if (iVar3 == 0) {
        return;
      }
      lVar10 = FUN_14021fe10(lVar5,iVar3);
      if (lVar10 != 0) {
        lVar5 = *(longlong *)(param_1 + 0x428);
        uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
        cVar1 = FUN_140417960(lVar10,uVar2,*(undefined4 *)(lVar5 + 4));
        if (cVar1 == '\0') {
          return;
        }
        FUN_140416c30(lVar10);
        return;
      }
      uVar8 = FUN_140416a50(*(undefined4 *)(param_1 + 0x410));
      lVar10 = *(longlong *)(param_1 + 0x428);
      uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
      cVar1 = FUN_140416ff0(uVar8,uVar2,*(undefined4 *)(lVar10 + 4));
      if (cVar1 == '\0') {
        FUN_140416200(uVar8);
        return;
      }
      FUN_140222b70(lVar5,uVar8);
      FUN_140416c30(uVar8);
      return;
    }
  }
  pIVar7 = theInstance();
  pcVar13 = "STR_USER_VIP_NOT_EXIST_POINT";
LAB_14045af9a:
  lVar5 = *plVar11;
  uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,pcVar13);
  (**(code **)(lVar5 + 0x358))(plVar11,uVar8);
  return;
}

