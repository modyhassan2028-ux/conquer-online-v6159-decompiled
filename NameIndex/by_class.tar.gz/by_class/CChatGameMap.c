// ==== CChatGameMap::helper_14003e750  @14003e750  [medium:callgraph-r0]  (orig: FUN_14003e750)
void FUN_14003e750(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  for (; param_1 != param_2; param_1 = param_1 + 6) {
    puVar2 = (undefined8 *)param_1[3];
    if (puVar2 != (undefined8 *)0x0) {
      puVar1 = (undefined8 *)param_1[4];
      for (; puVar2 != puVar1; puVar2 = puVar2 + 6) {
        if ((void *)puVar2[3] != (void *)0x0) {
          operator_delete((void *)puVar2[3]);
        }
        puVar2[3] = 0;
        puVar2[4] = 0;
        puVar2[5] = 0;
        operator_delete((void *)*puVar2);
      }
      operator_delete((void *)param_1[3]);
    }
    param_1[3] = 0;
    param_1[4] = 0;
    param_1[5] = 0;
    operator_delete((void *)*param_1);
  }
  return;
}

// ==== CChatGameMap::ctor_or_dtor  @14003f4e0  [high:vtable-assign]  (orig: FUN_14003f4e0)
undefined8 * FUN_14003f4e0(undefined8 *param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CChatGameMap::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 3);
    plVar2 = plVar1;
  }
  param_1[3] = plVar2;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  *(undefined4 *)(param_1 + 1) = param_2;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  return param_1;
}

// ==== CChatGameMap::ctor_or_dtor  @14003f560  [high:vtable-assign]  (orig: FUN_14003f560)
void FUN_14003f560(undefined8 *param_1)

{
  *param_1 = CChatGameMap::vftable;
  if (param_1[6] != 0) {
    FUN_14003e750(param_1[6],param_1[7],param_1 + 5,(ulonglong)(param_1 + 3) & 0xff,
                  0xfffffffffffffffe);
    operator_delete((void *)param_1[6]);
  }
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CChatGameMap::vfunc_0  @14003f660  [high:rtti-vtable]  (orig: FUN_14003f660)
void * FUN_14003f660(void *param_1,uint param_2)

{
  FUN_14003f560();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

