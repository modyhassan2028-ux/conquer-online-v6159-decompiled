// ==== CMapData::helper_14008f180  @14008f180  [medium:callgraph-r1]  (orig: FUN_14008f180)
void FUN_14008f180(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x21) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x21) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x21);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x21);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x21);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x21);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014008f1a4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapData::helper_140094ea0  @140094ea0  [medium:callgraph-r1]  (orig: FUN_140094ea0)
void FUN_140094ea0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x21) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapData::helper_140094f00  @140094f00  [medium:callgraph-r1]  (orig: FUN_140094f00)
void FUN_140094f00(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x21) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapData::helper_14009f1a0  @14009f1a0  [medium:callgraph-r0]  (orig: FUN_14009f1a0)
undefined8 * FUN_14009f1a0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x21) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14008f180(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x21) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 4;
        plVar8 = plVar8 + 4;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14009f38c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x21);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x21) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x21);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x21);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14009f38c:
  if ((char)plVar2[4] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[4] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140094ea0(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(*plVar9 + 0x20) != '\x01') || (*(char *)(plVar9[2] + 0x20) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x20) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140094f00(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(plVar9[2] + 0x20) = 1;
              FUN_140094ea0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        else {
          if ((char)plVar9[4] == '\0') {
            *(undefined1 *)(plVar9 + 4) = 1;
            *(undefined1 *)(plVar8 + 4) = 0;
            FUN_140094f00(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
            if ((*(char *)(plVar9[2] + 0x20) != '\x01') || (*(char *)(*plVar9 + 0x20) != '\x01')) {
              if (*(char *)(*plVar9 + 0x20) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x20) = 1;
                *(undefined1 *)(plVar9 + 4) = 0;
                FUN_140094ea0(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 4) = (char)plVar8[4];
              *(undefined1 *)(plVar8 + 4) = 1;
              *(undefined1 *)(*plVar9 + 0x20) = 1;
              FUN_140094f00(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 4) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 4) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapData::helper_140337060  @140337060  [medium:callgraph-r1]  (orig: FUN_140337060)
undefined8 * FUN_140337060(longlong *param_1,undefined8 *param_2,longlong *param_3,int *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1400a26b0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(int *)(lVar3 + 0x18)) {
        FUN_1400a26b0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(int *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1400a26b0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        iVar7 = *param_4;
        if (iVar7 < *(int *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x21) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x21) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x21);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x21);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x21);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x21);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x21) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x21) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          iVar7 = *param_4;
          if ((int)plVar8[3] < iVar7) {
            if (*(char *)(plVar8[2] + 0x21) != '\0') {
              FUN_1400a26b0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1400a26b0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(int *)(param_3[1] + 0x18) < iVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x21) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x21) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x21);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x21);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x21);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x21);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < (int)plVar9[3])) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x21) != '\0') {
              FUN_1400a26b0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1400a26b0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1400a85a0(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CMapData::helper_14033a2d0  @14033a2d0  [medium:callgraph-r0]  (orig: FUN_14033a2d0)
longlong FUN_14033a2d0(longlong *param_1,int *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  longlong *plVar5;
  int local_res8 [2];
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar3 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar3[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      if (*(int *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar3 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  lVar4 = 0;
  if ((puVar3 == puVar1) || (*param_2 < *(int *)(puVar3 + 3))) {
    local_48 = SUB84(plVar5,0);
    uStack_44 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_40 = SUB84(puVar3,0);
    uStack_3c = (undefined4)((ulonglong)puVar3 >> 0x20);
    local_res8[0] = *param_2;
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = uStack_40;
    uStack_2c = uStack_3c;
    local_res8[1] = 0;
    puVar3 = (undefined8 *)FUN_140337060(param_1,local_28,&local_38,local_res8);
    plVar5 = (longlong *)*puVar3;
    puVar3 = (undefined8 *)puVar3[1];
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar4 = *plVar5;
  }
  if (puVar3 == *(undefined8 **)(lVar4 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar3 + 0x1c;
}

// ==== CMapData::vfunc_12  @14055df90  [high:rtti-vtable]  (orig: FUN_14055df90)
void FUN_14055df90(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapData::helper_14055e4f0  @14055e4f0  [medium:callgraph-r2]  (orig: FUN_14055e4f0)
void FUN_14055e4f0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapData::helper_14055e6c0  @14055e6c0  [medium:callgraph-r1]  (orig: FUN_14055e6c0)
void FUN_14055e6c0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapData::helper_14055f380  @14055f380  [medium:callgraph-r2]  (orig: FUN_14055f380)
void FUN_14055f380(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x30)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x30);
  return;
}

// ==== CMapData::helper_14055f510  @14055f510  [medium:callgraph-r1]  (orig: FUN_14055f510)
void FUN_14055f510(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CMapData::helper_14055f6f0  @14055f6f0  [medium:callgraph-r1]  (orig: FUN_14055f6f0)
void FUN_14055f6f0(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x10)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 << 4);
  return;
}

// ==== CMapData::helper_14055f840  @14055f840  [medium:callgraph-r0]  (orig: FUN_14055f840)
void FUN_14055f840(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CMapData::helper_14055f8d0  @14055f8d0  [medium:callgraph-r1]  (orig: FUN_14055f8d0)
void FUN_14055f8d0(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CMapData::helper_14055f960  @14055f960  [medium:callgraph-r1]  (orig: FUN_14055f960)
void FUN_14055f960(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CMapData::vfunc_4  @14055fbc0  [high:rtti-vtable]  (orig: FUN_14055fbc0)
void FUN_14055fbc0(longlong param_1)

{
  FUN_14056aaf0(*(undefined8 *)(param_1 + 0x100));
  return;
}

// ==== CMapData::vfunc_5  @14055fbd0  [high:rtti-vtable]  (orig: FUN_14055fbd0)
void FUN_14055fbd0(longlong param_1)

{
  FUN_14056ab00(*(undefined8 *)(param_1 + 0x100));
  return;
}

// ==== CMapData::vfunc_6  @14055fbe0  [high:rtti-vtable]  (orig: FUN_14055fbe0)
void FUN_14055fbe0(longlong param_1)

{
  FUN_14056d600(*(undefined8 *)(param_1 + 0x100));
  return;
}

// ==== CMapData::vfunc_7  @14055fbf0  [high:rtti-vtable]  (orig: FUN_14055fbf0)
void FUN_14055fbf0(longlong param_1)

{
  FUN_14056b2e0(*(undefined8 *)(param_1 + 0x100));
  return;
}

// ==== CMapData::vfunc_8  @14055fc00  [high:rtti-vtable]  (orig: FUN_14055fc00)
void FUN_14055fc00(longlong param_1)

{
  FUN_14056d710(*(undefined8 *)(param_1 + 0x100));
  return;
}

// ==== CMapData::helper_14055fca0  @14055fca0  [medium:callgraph-r2]  (orig: FUN_14055fca0)
void FUN_14055fca0(longlong param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  plVar3 = *(longlong **)(param_1 + 8);
  if (plVar3 != (longlong *)0x0) {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
    }
  }
  return;
}

// ==== CMapData::helper_14055fff0  @14055fff0  [medium:callgraph-r0]  (orig: FUN_14055fff0)
void FUN_14055fff0(void)

{
  void *pvVar1;
  
  pvVar1 = operator_new(0x20);
  if (pvVar1 != (void *)0x0) {
    *(void **)pvVar1 = pvVar1;
  }
  if ((undefined8 *)((longlong)pvVar1 + 8) != (undefined8 *)0x0) {
    *(undefined8 *)((longlong)pvVar1 + 8) = pvVar1;
  }
  return;
}

// ==== CMapData::helper_140560070  @140560070  [medium:callgraph-r0]  (orig: FUN_140560070)
void FUN_140560070(void)

{
  void *pvVar1;
  
  pvVar1 = operator_new(0x20);
  if (pvVar1 != (void *)0x0) {
    *(void **)pvVar1 = pvVar1;
  }
  if ((undefined8 *)((longlong)pvVar1 + 8) != (undefined8 *)0x0) {
    *(undefined8 *)((longlong)pvVar1 + 8) = pvVar1;
  }
  return;
}

// ==== CMapData::helper_1405600b0  @1405600b0  [medium:callgraph-r1]  (orig: FUN_1405600b0)
void FUN_1405600b0(undefined8 *param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  LOCK();
  plVar1 = plVar3 + 2;
  *(int *)plVar1 = (int)*plVar1 + -1;
  UNLOCK();
  if ((int)*plVar1 == 0) {
    (**(code **)*plVar3)(plVar3);
    LOCK();
    piVar2 = (int *)((longlong)plVar3 + 0x14);
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
      (**(code **)(*plVar3 + 8))(plVar3);
    }
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}

// ==== CMapData::helper_140560230  @140560230  [medium:callgraph-r3]  (orig: FUN_140560230)
undefined8 FUN_140560230(longlong param_1,ulonglong param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0;
  *(undefined8 *)(param_1 + 0x18) = 0;
  *(undefined8 *)(param_1 + 0x20) = 0;
  *(undefined8 *)(param_1 + 0x28) = 0;
  if (param_2 != 0) {
    if (0xfffffffffffffff < param_2) {
                    /* WARNING: Subroutine does not return */
      FUN_14055e6c0();
    }
    lVar1 = FUN_14055f6f0(param_1 + 0x10);
    *(longlong *)(param_1 + 0x18) = lVar1;
    *(longlong *)(param_1 + 0x20) = lVar1;
    *(ulonglong *)(param_1 + 0x28) = param_2 * 0x10 + lVar1;
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CMapData::helper_1405602f0  @1405602f0  [medium:callgraph-r1]  (orig: FUN_1405602f0)
void FUN_1405602f0(longlong param_1,ulonglong param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  if (0xfffffffffffffffU - *(longlong *)(param_1 + 0x30) < param_2) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"list<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  *(ulonglong *)(param_1 + 0x30) = *(longlong *)(param_1 + 0x30) + param_2;
  return;
}

// ==== CMapData::helper_140560380  @140560380  [medium:callgraph-r0]  (orig: FUN_140560380)
void FUN_140560380(longlong param_1,ulonglong param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  if (0xfffffffffffffffU - *(longlong *)(param_1 + 0x30) < param_2) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"list<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  *(ulonglong *)(param_1 + 0x30) = *(longlong *)(param_1 + 0x30) + param_2;
  return;
}

// ==== CMapData::helper_140561780  @140561780  [medium:callgraph-r0]  (orig: FUN_140561780)
ulonglong FUN_140561780(longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 - 0x30;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1405617f7;
  }
  _invalid_parameter_noinfo();
LAB_1405617f7:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMapData::helper_140561830  @140561830  [medium:callgraph-r0]  (orig: FUN_140561830)
ulonglong FUN_140561830(longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 - 0x10;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1405618a7;
  }
  _invalid_parameter_noinfo();
LAB_1405618a7:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMapData::helper_140561b20  @140561b20  [medium:callgraph-r1]  (orig: FUN_140561b20)
undefined8 *
FUN_140561b20(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x20);
  if (puVar2 != (undefined8 *)0x0) {
    *puVar2 = param_2;
  }
  if (puVar2 + 1 != (undefined8 *)0x0) {
    puVar2[1] = param_3;
  }
  puVar1 = puVar2 + 2;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
    puVar2[3] = 0;
    FUN_14055f510(puVar1,*param_4,param_4[1]);
  }
  return puVar2;
}

// ==== CMapData::helper_140561cf0  @140561cf0  [medium:callgraph-r1]  (orig: FUN_140561cf0)
void FUN_140561cf0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count<NodeInfo>::vftable;
  }
  FUN_14055f510(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CMapData::helper_140561e00  @140561e00  [medium:callgraph-r3]  (orig: FUN_140561e00)
undefined8 * FUN_140561e00(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 2) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = 0;
      param_3[1] = 0;
      FUN_14055f960(param_3,*param_1,param_1[1]);
    }
    param_3 = param_3 + 2;
  }
  return param_3;
}

// ==== CMapData::helper_140561e90  @140561e90  [medium:callgraph-r3]  (orig: FUN_140561e90)
longlong FUN_140561e90(longlong param_1,longlong param_2,longlong param_3)

{
  undefined1 local_res8;
  
  FUN_140560a40(param_1,param_2,param_3,local_res8,0,0);
  return param_3 + (param_2 - param_1 & 0xfffffffffffffff0U);
}

// ==== CMapData::helper_140561f90  @140561f90  [medium:callgraph-r3]  (orig: FUN_140561f90)
undefined8 * FUN_140561f90(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 2) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = 0;
      param_3[1] = 0;
      FUN_14055f960(param_3,*param_1,param_1[1]);
    }
    param_3 = param_3 + 2;
  }
  return param_3;
}

// ==== CMapData::vfunc_1  @140562020  [high:rtti-vtable]  (orig: FUN_140562020)
ulonglong FUN_140562020(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  short sVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  cVar4 = FUN_14056ab10(*(undefined8 *)(param_1 + 0x100));
  if (cVar4 != '\0') {
    iVar6 = FUN_14056ab30(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1c0))[1];
    cVar4 = *(char *)((longlong)puVar7 + 0x21);
    puVar2 = *(undefined8 **)(param_1 + 0x1c0);
    while (cVar4 == '\0') {
      if (*(int *)(puVar7 + 3) < iVar6) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar2;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar2 = puVar7;
      puVar7 = puVar8;
      cVar4 = *(char *)((longlong)puVar8 + 0x21);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x1c0);
    local_40 = puVar2;
    local_48 = *(longlong *)(param_1 + 400);
    if (*(longlong *)(param_1 + 400) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar7) || (iVar6 < *(int *)(puVar2 + 3))) {
      plVar9 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x1c0);
      local_38 = *(longlong *)(param_1 + 400);
    }
    else {
      plVar9 = &local_48;
    }
    plVar1 = (longlong *)*plVar9;
    lVar11 = *(longlong *)(param_1 + 0x1c0);
    local_28 = plVar1;
    local_20 = plVar9[1];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 400))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_20;
    if (local_20 == lVar11) {
      uVar10 = FUN_14056d310(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar10 = (ulonglong)*(int *)(lVar3 + 0x1c);
      if ((ulonglong)((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8)) / 0x30) <=
          uVar10) {
        _invalid_parameter_noinfo();
      }
      puVar7 = (undefined8 *)FUN_140561830(uVar10 * 0x30 + *(longlong *)(param_1 + 0xb8));
      sVar5 = FUN_140570940(*puVar7);
      uVar10 = (ulonglong)(uint)(int)sVar5;
    }
    return uVar10;
  }
  return 0x7fff;
}

// ==== CMapData::vfunc_2  @1405621e0  [high:rtti-vtable]  (orig: FUN_1405621e0)
ulonglong FUN_1405621e0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  cVar4 = FUN_14056ab10(*(undefined8 *)(param_1 + 0x100));
  if (cVar4 != '\0') {
    iVar6 = FUN_14056ab30(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1c0))[1];
    cVar4 = *(char *)((longlong)puVar7 + 0x21);
    puVar2 = *(undefined8 **)(param_1 + 0x1c0);
    while (cVar4 == '\0') {
      if (*(int *)(puVar7 + 3) < iVar6) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar2;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar2 = puVar7;
      puVar7 = puVar8;
      cVar4 = *(char *)((longlong)puVar8 + 0x21);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x1c0);
    local_40 = puVar2;
    local_48 = *(longlong *)(param_1 + 400);
    if (*(longlong *)(param_1 + 400) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar7) || (iVar6 < *(int *)(puVar2 + 3))) {
      plVar9 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x1c0);
      local_38 = *(longlong *)(param_1 + 400);
    }
    else {
      plVar9 = &local_48;
    }
    plVar1 = (longlong *)*plVar9;
    lVar11 = *(longlong *)(param_1 + 0x1c0);
    local_28 = plVar1;
    local_20 = plVar9[1];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 400))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_20;
    if (local_20 == lVar11) {
      uVar10 = FUN_14056d410(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar10 = (ulonglong)*(int *)(lVar3 + 0x1c);
      if ((ulonglong)((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8)) / 0x30) <=
          uVar10) {
        _invalid_parameter_noinfo();
      }
      puVar7 = (undefined8 *)FUN_140561830(uVar10 * 0x30 + *(longlong *)(param_1 + 0xb8));
      uVar5 = FUN_140570960(*puVar7);
      uVar10 = (ulonglong)uVar5;
    }
    return uVar10;
  }
  return 0;
}

// ==== CMapData::vfunc_3  @1405623a0  [high:rtti-vtable]  (orig: FUN_1405623a0)
ulonglong FUN_1405623a0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  cVar4 = FUN_14056ab10(*(undefined8 *)(param_1 + 0x100));
  if (cVar4 != '\0') {
    iVar6 = FUN_14056ab30(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1c0))[1];
    cVar4 = *(char *)((longlong)puVar7 + 0x21);
    puVar2 = *(undefined8 **)(param_1 + 0x1c0);
    while (cVar4 == '\0') {
      if (*(int *)(puVar7 + 3) < iVar6) {
        puVar8 = (undefined8 *)puVar7[2];
        puVar7 = puVar2;
      }
      else {
        puVar8 = (undefined8 *)*puVar7;
      }
      puVar2 = puVar7;
      puVar7 = puVar8;
      cVar4 = *(char *)((longlong)puVar8 + 0x21);
    }
    puVar7 = *(undefined8 **)(param_1 + 0x1c0);
    local_40 = puVar2;
    local_48 = *(longlong *)(param_1 + 400);
    if (*(longlong *)(param_1 + 400) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar2 == puVar7) || (iVar6 < *(int *)(puVar2 + 3))) {
      plVar9 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x1c0);
      local_38 = *(longlong *)(param_1 + 400);
    }
    else {
      plVar9 = &local_48;
    }
    plVar1 = (longlong *)*plVar9;
    lVar11 = *(longlong *)(param_1 + 0x1c0);
    local_28 = plVar1;
    local_20 = plVar9[1];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 400))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_20;
    if (local_20 == lVar11) {
      uVar10 = FUN_14056d500(*(undefined8 *)(param_1 + 0x100),param_2,param_3);
    }
    else {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar1;
      }
      if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar10 = (ulonglong)*(int *)(lVar3 + 0x1c);
      if ((ulonglong)((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8)) / 0x30) <=
          uVar10) {
        _invalid_parameter_noinfo();
      }
      puVar7 = (undefined8 *)FUN_140561830(uVar10 * 0x30 + *(longlong *)(param_1 + 0xb8));
      uVar5 = FUN_140570950(*puVar7);
      uVar10 = (ulonglong)uVar5;
    }
    return uVar10;
  }
  return 1;
}

// ==== CMapData::helper_1405625c0  @1405625c0  [medium:callgraph-r0]  (orig: FUN_1405625c0)
undefined8 * FUN_1405625c0(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar1 = operator_new(8);
  plVar3 = (longlong *)0x0;
  plVar2 = plVar3;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)param_1;
    plVar2 = plVar1;
  }
  *param_1 = plVar2;
  param_1[2] = 0;
  plVar2 = operator_new(8);
  if (plVar2 != (longlong *)0x0) {
    *plVar2 = (longlong)(param_1 + 3);
    plVar3 = plVar2;
  }
  param_1[3] = plVar3;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  return param_1;
}

// ==== CMapData::helper_140562650  @140562650  [medium:callgraph-r1]  (orig: FUN_140562650)
void FUN_140562650(undefined8 *param_1)

{
  param_1[2] = 0;
  if ((void *)param_1[6] != (void *)0x0) {
    operator_delete((void *)param_1[6]);
  }
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)param_1[3]);
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapData::helper_140562870  @140562870  [medium:callgraph-r2]  (orig: FUN_140562870)
/* WARNING: Removing unreachable block (ram,0x000140562884) */

void FUN_140562870(longlong param_1,ulonglong param_2)

{
  longlong *plVar1;
  void *_Dst;
  uint *puVar2;
  rsize_t _DstSize;
  void *_Src;
  ulonglong uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  ulonglong uVar7;
  
  plVar1 = (longlong *)(param_1 + 0x18);
  uVar7 = param_2 + 0x1f >> 5;
  if ((ulonglong)(*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) >> 2) <= uVar7)
  goto LAB_1405629a2;
  _Src = *(void **)(param_1 + 0x38);
  if (_Src < *(void **)(param_1 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  uVar3 = *(ulonglong *)(param_1 + 0x30);
  if (*(ulonglong *)(param_1 + 0x38) < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar4 = (longlong *)*plVar1;
  lVar5 = 0;
  if (plVar4 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = lVar5;
  }
  else {
    lVar6 = *plVar4;
  }
  _Dst = (void *)(uVar3 + uVar7 * 4);
  if (*(void **)(lVar6 + 0x20) < _Dst) {
LAB_14056291d:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar4 != (longlong *)0x0) {
      lVar5 = *plVar4;
    }
    if (_Dst < *(void **)(lVar5 + 0x18)) goto LAB_14056291d;
  }
  if (((plVar1 == (longlong *)0x0) || (_Dst < *(void **)(param_1 + 0x30))) ||
     (*(void **)(param_1 + 0x38) < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = *plVar1;
  if ((_Src < *(void **)(param_1 + 0x30)) || (*(void **)(param_1 + 0x38) < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar5 == 0) || (lVar5 != *plVar1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar5 = *(longlong *)(param_1 + 0x38) - (longlong)_Src >> 2;
    _DstSize = lVar5 * 4;
    if (0 < lVar5) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    *(void **)(param_1 + 0x38) = (void *)(_DstSize + (longlong)_Dst);
  }
LAB_1405629a2:
  *(ulonglong *)(param_1 + 0x10) = param_2;
  if ((param_2 & 0x1f) != 0) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x38) - *(longlong *)(param_1 + 0x30) >> 2) <= uVar7 - 1
       ) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (uint *)(*(longlong *)(param_1 + 0x30) + (uVar7 - 1) * 4);
    *puVar2 = *puVar2 & (1 << ((byte)param_2 & 0x1f)) - 1U;
  }
  return;
}

// ==== CMapData::helper_1405629f0  @1405629f0  [medium:callgraph-r1]  (orig: FUN_1405629f0)
void FUN_1405629f0(longlong param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar3 = *(longlong **)(param_1 + 0x28);
  plVar5 = (longlong *)*plVar3;
  *plVar3 = (longlong)plVar3;
  *(longlong *)(*(longlong *)(param_1 + 0x28) + 8) = *(longlong *)(param_1 + 0x28);
  *(undefined8 *)(param_1 + 0x30) = 0;
  if (plVar5 != *(longlong **)(param_1 + 0x28)) {
    do {
      plVar3 = (longlong *)*plVar5;
      plVar4 = (longlong *)plVar5[3];
      if (plVar4 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar4 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*plVar4)(plVar4);
          LOCK();
          piVar2 = (int *)((longlong)plVar4 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar4 + 8))(plVar4);
          }
        }
      }
      operator_delete(plVar5);
      plVar5 = plVar3;
    } while (plVar3 != (longlong *)*(longlong *)(param_1 + 0x28));
  }
  return;
}

// ==== CMapData::helper_140562aa0  @140562aa0  [medium:callgraph-r0]  (orig: FUN_140562aa0)
undefined8 *
FUN_140562aa0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 *param_4)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  
  puVar2 = operator_new(0x20);
  if (puVar2 != (undefined8 *)0x0) {
    *puVar2 = param_2;
  }
  if (puVar2 + 1 != (undefined8 *)0x0) {
    puVar2[1] = param_3;
  }
  puVar1 = puVar2 + 2;
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
    puVar2[3] = 0;
    FUN_14055f8d0(puVar1,*param_4,param_4[1]);
  }
  return puVar2;
}

// ==== CMapData::helper_140562d30  @140562d30  [medium:callgraph-r0]  (orig: FUN_140562d30)
void FUN_140562d30(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = 0;
      param_1[1] = 0;
      FUN_14055f960(param_1,*param_3,param_3[1]);
    }
    param_1 = param_1 + 2;
  }
  return;
}

// ==== CMapData::helper_140562ea0  @140562ea0  [medium:callgraph-r1]  (orig: FUN_140562ea0)
/* WARNING: Removing unreachable block (ram,0x000140562f73) */
/* WARNING: Removing unreachable block (ram,0x000140562f7c) */
/* WARNING: Removing unreachable block (ram,0x000140562f90) */
/* WARNING: Removing unreachable block (ram,0x000140562fa5) */

undefined8 * FUN_140562ea0(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  for (; param_1 != param_2; param_1 = param_1 + 2) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = 0;
      param_3[1] = 0;
      FUN_14055f960(param_3,0,0);
    }
    puVar1 = param_1 + 1;
    puVar2 = param_3 + 1;
    if (puVar2 != puVar1) {
      uVar3 = *puVar2;
      *puVar2 = *puVar1;
      *puVar1 = uVar3;
    }
    if (param_3 != param_1) {
      uVar3 = *param_3;
      *param_3 = *param_1;
      *param_1 = uVar3;
    }
    param_3 = param_3 + 2;
  }
  return param_3;
}

// ==== CMapData::helper_140563220  @140563220  [medium:callgraph-r1]  (orig: FUN_140563220)
void FUN_140563220(longlong param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar3 = *(longlong **)(param_1 + 0x28);
  plVar5 = (longlong *)*plVar3;
  *plVar3 = (longlong)plVar3;
  *(longlong *)(*(longlong *)(param_1 + 0x28) + 8) = *(longlong *)(param_1 + 0x28);
  *(undefined8 *)(param_1 + 0x30) = 0;
  if (plVar5 != *(longlong **)(param_1 + 0x28)) {
    do {
      plVar3 = (longlong *)*plVar5;
      plVar4 = (longlong *)plVar5[3];
      if (plVar4 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar4 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*plVar4)(plVar4);
          LOCK();
          piVar2 = (int *)((longlong)plVar4 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar4 + 8))(plVar4);
          }
        }
      }
      operator_delete(plVar5);
      plVar5 = plVar3;
    } while (plVar3 != (longlong *)*(longlong *)(param_1 + 0x28));
  }
  return;
}

// ==== CMapData::helper_140563490  @140563490  [medium:callgraph-r1]  (orig: FUN_140563490)
longlong FUN_140563490(longlong *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  longlong lVar3;
  longlong lVar4;
  
  if ((*param_1 == 0) || (param_1[1] == 0)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = param_1[2];
  lVar4 = 0;
  lVar3 = lVar4;
  if ((longlong *)*param_1 != (longlong *)0x0) {
    lVar3 = *(longlong *)*param_1;
  }
  uVar2 = *(ulonglong *)(lVar3 + 0x30);
  if (*(ulonglong *)(lVar3 + 0x38) < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((longlong *)*param_1 != (longlong *)0x0) {
    lVar4 = *(longlong *)*param_1;
  }
  if (*(ulonglong *)(lVar4 + 0x10) <=
      (ulonglong)(lVar1 + ((longlong)(param_1[1] - uVar2) >> 2) * 0x20)) {
    _invalid_parameter_noinfo();
  }
  return param_1[1];
}

// ==== CMapData::helper_140563720  @140563720  [medium:callgraph-r3]  (orig: FUN_140563720)
void FUN_140563720(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_140561f90(param_2,param_3,param_4,param_1 + 0x10);
  return;
}

// ==== CMapData::helper_140563780  @140563780  [medium:callgraph-r2]  (orig: FUN_140563780)
void FUN_140563780(longlong param_1,longlong *param_2)

{
  int *piVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  uint uVar8;
  longlong local_a8;
  longlong *local_a0;
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar5 = (longlong *)param_2[1];
  lVar7 = *param_2;
  if (plVar5 != (longlong *)0x0) {
    LOCK();
    *(int *)(plVar5 + 2) = (int)plVar5[2] + 1;
    UNLOCK();
  }
  uVar8 = 1;
  do {
    plVar6 = plVar5;
    local_a8 = lVar7;
    local_a0 = plVar5;
    if (*(longlong *)(lVar7 + 0x18) == 0) goto LAB_140563929;
    lVar2 = **(longlong **)(param_1 + 0x90);
    lVar4 = FUN_140561b20(param_1 + 0x68,lVar2,*(undefined8 *)(lVar2 + 8),&local_a8);
    plVar3 = local_a0;
    if (*(longlong *)(param_1 + 0x98) == 0xfffffffffffffff) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_50,"list<T> too long");
      std::exception::exception((exception *)local_90);
      local_90[0] = std::logic_error::vftable;
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>
                (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                           *)local_50);
      local_90[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
      _CxxThrowException(local_90,(ThrowInfo *)&DAT_140944488);
    }
    *(longlong *)(param_1 + 0x98) = *(longlong *)(param_1 + 0x98) + 1;
    *(longlong *)(lVar2 + 8) = lVar4;
    **(longlong **)(lVar4 + 8) = lVar4;
    plVar6 = *(longlong **)(lVar7 + 0x20);
    lVar7 = *(longlong *)(lVar7 + 0x18);
    if (plVar6 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
      UNLOCK();
      plVar5 = local_a0;
    }
    if (plVar5 != (longlong *)0x0) {
      LOCK();
      plVar5 = plVar5 + 2;
      *(int *)plVar5 = (int)*plVar5 + -1;
      UNLOCK();
      if ((int)*plVar5 == 0) {
        (**(code **)*local_a0)(local_a0);
        LOCK();
        piVar1 = (int *)((longlong)plVar3 + 0x14);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
          (**(code **)(*local_a0 + 8))();
        }
      }
    }
    uVar8 = uVar8 + 1;
    plVar5 = plVar6;
  } while (uVar8 < 0x10000);
  local_a8 = lVar7;
  local_a0 = plVar6;
  log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                     "f:\\version\\cqserver-78.0.11-1204\\mapdata\\source\\mapdata.cpp",0x275);
LAB_140563929:
  plVar5 = local_a0;
  if (plVar6 != (longlong *)0x0) {
    LOCK();
    plVar6 = plVar6 + 2;
    *(int *)plVar6 = (int)*plVar6 + -1;
    UNLOCK();
    if ((int)*plVar6 == 0) {
      (**(code **)*local_a0)(local_a0);
      LOCK();
      piVar1 = (int *)((longlong)plVar5 + 0x14);
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (*piVar1 == 0) {
        (**(code **)(*local_a0 + 8))();
      }
    }
  }
  plVar5 = (longlong *)param_2[1];
  if (plVar5 != (longlong *)0x0) {
    LOCK();
    plVar6 = plVar5 + 2;
    *(int *)plVar6 = (int)*plVar6 + -1;
    UNLOCK();
    if ((int)*plVar6 == 0) {
      (**(code **)*plVar5)(plVar5);
      LOCK();
      piVar1 = (int *)((longlong)plVar5 + 0x14);
      *piVar1 = *piVar1 + -1;
      UNLOCK();
      if (*piVar1 == 0) {
        (**(code **)(*plVar5 + 8))(plVar5);
      }
    }
  }
  return;
}

// ==== CMapData::helper_140563d60  @140563d60  [medium:callgraph-r2]  (orig: FUN_140563d60)
undefined8 * FUN_140563d60(undefined8 *param_1,longlong param_2)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  undefined8 uVar6;
  
  uVar6 = 0xfffffffffffffffe;
  puVar2 = operator_new(8);
  if (puVar2 == (undefined8 *)0x0) {
    puVar3 = (void *)0x0;
  }
  else {
    *puVar2 = param_1;
    puVar3 = puVar2;
  }
  *param_1 = puVar3;
  uVar5 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 4;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  if (uVar5 != 0) {
    if (0xfffffffffffffff < uVar5) {
                    /* WARNING: Subroutine does not return */
      FUN_14055e6c0();
    }
    lVar4 = FUN_14055f6f0(param_1 + 2,uVar5);
    param_1[3] = lVar4;
    param_1[4] = lVar4;
    param_1[5] = uVar5 * 0x10 + lVar4;
    uVar5 = *(ulonglong *)(param_2 + 0x20);
    if (uVar5 < *(ulonglong *)(param_2 + 0x18)) {
      _invalid_parameter_noinfo();
    }
    uVar1 = *(ulonglong *)(param_2 + 0x18);
    if (*(ulonglong *)(param_2 + 0x20) < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_res18 = SUB81(puVar2,0);
    uVar6 = FUN_140561e00(uVar1,uVar5,param_1[3],param_1 + 2,local_res18,0,uVar6);
    param_1[4] = uVar6;
  }
  return param_1;
}

// ==== CMapData::helper_140564070  @140564070  [medium:callgraph-r1]  (orig: FUN_140564070)
longlong FUN_140564070(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined8 *puVar4;
  longlong lVar6;
  undefined8 *puVar5;
  
  lVar3 = (longlong)param_3 - ((longlong)param_2 - (longlong)param_1 & 0xfffffffffffffff0U);
  if (param_1 != param_2) {
    lVar6 = (longlong)param_3 - (longlong)param_2;
    puVar4 = param_2 + 1;
    do {
      puVar5 = puVar4 + -2;
      param_3 = param_3 + -2;
      puVar1 = (undefined8 *)((longlong)puVar5 + lVar6);
      if (puVar1 != puVar5) {
        uVar2 = *puVar1;
        *puVar1 = *puVar5;
        *puVar5 = uVar2;
      }
      puVar1 = puVar4 + -3;
      if (param_3 != puVar1) {
        uVar2 = *param_3;
        *param_3 = *puVar1;
        *puVar1 = uVar2;
      }
      puVar4 = puVar5;
    } while (puVar1 != param_1);
  }
  return lVar3;
}

// ==== CMapData::helper_140564340  @140564340  [medium:callgraph-r1]  (orig: FUN_140564340)
undefined8 * FUN_140564340(undefined8 *param_1,undefined8 *param_2,undefined8 param_3)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  undefined8 *local_38;
  ulonglong local_30;
  undefined8 local_28;
  undefined8 *local_20;
  ulonglong local_18;
  undefined8 local_10;
  
  uVar1 = param_1[6];
  if ((ulonglong)param_1[7] < uVar1) {
    _invalid_parameter_noinfo();
  }
  puVar2 = (undefined8 *)0x0;
  local_10 = 0;
  local_18 = uVar1;
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  local_38 = (undefined8 *)*param_1;
  local_30 = local_18;
  local_28 = local_10;
  local_20 = local_38;
  FUN_140562ba0(&local_38,param_3);
  if (local_38 != (undefined8 *)0x0) {
    puVar2 = (undefined8 *)*local_38;
  }
  *param_2 = 0;
  param_2[1] = local_30;
  param_2[2] = local_28;
  if (puVar2 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  *param_2 = *puVar2;
  return param_2;
}

// ==== CMapData::helper_140564460  @140564460  [medium:callgraph-r0]  (orig: FUN_140564460)
void FUN_140564460(longlong param_1,longlong param_2,ulonglong param_3,longlong *param_4)

{
  int *piVar1;
  longlong *plVar2;
  ulonglong uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 local_res8;
  longlong local_60;
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  lVar10 = *(longlong *)(param_1 + 0x18);
  if (lVar10 == 0) {
    uVar11 = 0;
  }
  else {
    uVar11 = *(longlong *)(param_1 + 0x28) - lVar10 >> 4;
  }
  uVar12 = 0;
  if (param_3 != 0) {
    lVar10 = *(longlong *)(param_1 + 0x20) - lVar10 >> 4;
    if (0xfffffffffffffffU - lVar10 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14055e6c0();
    }
    uVar3 = lVar10 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar11 < uVar3) {
      if (uVar11 <= 0xfffffffffffffff - (uVar11 >> 1)) {
        uVar12 = uVar11 + (uVar11 >> 1);
      }
      if (uVar12 < uVar3) {
        uVar12 = uVar3;
      }
      lVar8 = FUN_14055f6f0(param_1 + 0x10,uVar12);
      lVar10 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      FUN_140562d30(lVar10 * 0x10 + lVar8,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140562ea0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar8,
                    param_1 + 0x10,local_res8,0);
      FUN_140562ea0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar10 + param_3) * 0x10 + lVar8,param_1 + 0x10,local_res8,0);
      lVar10 = *(longlong *)(param_1 + 0x18);
      lVar5 = *(longlong *)(param_1 + 0x20);
      if (lVar10 != 0) {
        FUN_140563af0(param_1,lVar10,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar12 * 0x10 + lVar8;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar5 - lVar10 >> 4)) * 0x10 + lVar8;
      *(longlong *)(param_1 + 0x18) = lVar8;
    }
    else if ((ulonglong)(*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4) < param_3)
    {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      local_60 = lVar10;
      local_58 = plVar6;
      FUN_140562ea0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x10,param_1 + 0x10,local_res8,0);
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = param_3 - (lVar5 - *(longlong *)(param_2 + 8) >> 4);
      FUN_140562d30(lVar5,lVar8,&local_60,param_1 + 0x10,local_res8,0,0,lVar5,lVar8);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar5 = *(longlong *)(param_1 + 0x20);
      for (plVar13 = *(longlong **)(param_2 + 8); plVar13 != (longlong *)(lVar5 + param_3 * -0x10);
          plVar13 = plVar13 + 2) {
        if (plVar6 != (longlong *)0x0) {
          LOCK();
          *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
          UNLOCK();
        }
        plVar14 = (longlong *)plVar13[1];
        if (plVar14 != (longlong *)0x0) {
          LOCK();
          plVar7 = plVar14 + 2;
          *(int *)plVar7 = (int)*plVar7 + -1;
          UNLOCK();
          if ((int)*plVar7 == 0) {
            (**(code **)*plVar14)(plVar14);
            LOCK();
            piVar1 = (int *)((longlong)plVar14 + 0x14);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
              (**(code **)(*plVar14 + 8))(plVar14);
            }
          }
        }
        plVar13[1] = (longlong)plVar6;
        *plVar13 = lVar10;
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
    else {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = lVar5 + param_3 * -0x10;
      local_50 = lVar10;
      local_48 = plVar6;
      uVar9 = FUN_140562ea0(lVar8,lVar5,lVar5,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar9;
      FUN_140564070(*(undefined8 *)(param_2 + 8),lVar8,lVar5);
      plVar13 = *(longlong **)(param_2 + 8);
      if (plVar13 != plVar13 + param_3 * 2) {
        plVar14 = plVar13 + 1;
        do {
          if (plVar6 != (longlong *)0x0) {
            LOCK();
            *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
            UNLOCK();
          }
          plVar7 = (longlong *)*plVar14;
          if (plVar7 != (longlong *)0x0) {
            LOCK();
            plVar2 = plVar7 + 2;
            *(int *)plVar2 = (int)*plVar2 + -1;
            UNLOCK();
            if ((int)*plVar2 == 0) {
              (**(code **)*plVar7)(plVar7);
              LOCK();
              piVar1 = (int *)((longlong)plVar7 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*plVar7 + 8))(plVar7);
              }
            }
          }
          *plVar14 = (longlong)plVar6;
          plVar14[-1] = lVar10;
          plVar7 = plVar14 + 1;
          plVar14 = plVar14 + 2;
        } while (plVar7 != plVar13 + param_3 * 2);
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
  }
  return;
}

// ==== CMapData::helper_140564a30  @140564a30  [medium:callgraph-r3]  (orig: FUN_140564a30)
void FUN_140564a30(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined1 local_res8;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = param_1[4];
    FUN_140560a40(uVar1,lVar3,uVar2,local_res8,0,0);
    lVar3 = (lVar3 - uVar1 & 0xfffffffffffffff0) + uVar2;
    FUN_140563af0(param_1,lVar3,param_1[4]);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CMapData::helper_140564b00  @140564b00  [medium:callgraph-r2]  (orig: FUN_140564b00)
longlong * FUN_140564b00(longlong *param_1,longlong *param_2,undefined8 param_3,longlong *param_4)

{
  uint *puVar1;
  uint *puVar2;
  longlong lVar3;
  ulonglong uVar4;
  char cVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  cVar5 = FUN_14055fa30(param_2,param_3);
  while (cVar5 != '\0') {
    if ((undefined8 *)*param_2 == (undefined8 *)0x0) {
      plVar8 = (longlong *)0x0;
    }
    else {
      plVar8 = *(longlong **)*param_2;
    }
    puVar1 = (uint *)param_2[1];
    lVar7 = param_2[2];
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar8 = (longlong *)*plVar8;
    if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
      plVar9 = (longlong *)0x0;
    }
    else {
      plVar9 = *(longlong **)*param_4;
    }
    puVar2 = (uint *)param_4[1];
    lVar3 = param_4[2];
    if (plVar9 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)*plVar9;
    if ((plVar8 == (longlong *)0x0) || (puVar1 == (uint *)0x0)) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar8;
    }
    uVar4 = *(ulonglong *)(lVar6 + 0x30);
    if (*(ulonglong *)(lVar6 + 0x38) < uVar4) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar8;
    }
    if (*(ulonglong *)(lVar6 + 0x10) <=
        (ulonglong)(((longlong)((longlong)puVar1 - uVar4) >> 2) * 0x20 + lVar7)) {
      _invalid_parameter_noinfo();
    }
    if ((*puVar1 & 1 << ((byte)lVar7 & 0x1f)) == 0) {
      if ((plVar9 == (longlong *)0x0) || (puVar2 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar9;
      }
      uVar4 = *(ulonglong *)(lVar7 + 0x30);
      if (*(ulonglong *)(lVar7 + 0x38) < uVar4) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar9;
      }
      if (*(ulonglong *)(lVar7 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar2 - uVar4) >> 2) * 0x20 + lVar3)) {
        _invalid_parameter_noinfo();
      }
      *puVar2 = *puVar2 & ~(1 << ((byte)lVar3 & 0x1f));
    }
    else {
      if ((plVar9 == (longlong *)0x0) || (puVar2 == (uint *)0x0)) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar9;
      }
      uVar4 = *(ulonglong *)(lVar7 + 0x30);
      if (*(ulonglong *)(lVar7 + 0x38) < uVar4) {
        _invalid_parameter_noinfo();
      }
      if (plVar9 == (longlong *)0x0) {
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar9;
      }
      if (*(ulonglong *)(lVar7 + 0x10) <=
          (ulonglong)(((longlong)((longlong)puVar2 - uVar4) >> 2) * 0x20 + lVar3)) {
        _invalid_parameter_noinfo();
      }
      *puVar2 = *puVar2 | 1 << ((byte)lVar3 & 0x1f);
    }
    FUN_140562de0(param_4);
    FUN_140562de0(param_2);
    cVar5 = FUN_14055fa30(param_2,param_3);
  }
  *param_1 = *param_4;
  param_1[1] = param_4[1];
  param_1[2] = param_4[2];
  return param_1;
}

// ==== CMapData::helper_1405650a0  @1405650a0  [medium:callgraph-r1]  (orig: FUN_1405650a0)
undefined8 FUN_1405650a0(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  int *piVar2;
  undefined8 uVar3;
  longlong *plVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  uint *puVar9;
  void *pvVar10;
  longlong lVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  int local_res18 [2];
  longlong local_res20;
  int *local_f8;
  longlong *local_f0;
  undefined8 local_e8;
  undefined8 local_e0;
  undefined8 local_d8;
  undefined8 local_d0;
  int local_c8 [18];
  void *local_80;
  undefined1 local_78 [24];
  undefined1 local_60 [32];
  
  local_c8[0x10] = -2;
  local_c8[0x11] = -1;
  uVar18 = 0;
  local_c8[0] = 0;
  local_c8[1] = 0xffffffff;
  local_c8[2] = 0xffffffff;
  local_c8[3] = 0xffffffff;
  local_c8[4] = 0;
  local_c8[5] = 1;
  local_c8[6] = 1;
  local_c8[7] = 1;
  local_c8[8] = 1;
  local_c8[9] = 1;
  local_c8[10] = 0;
  local_c8[0xb] = 0xffffffff;
  local_c8[0xc] = 0xffffffff;
  local_c8[0xd] = 0xffffffff;
  local_c8[0xe] = 0;
  local_c8[0xf] = 1;
  iVar6 = (**(code **)(*param_1 + 8))(param_1,*(undefined4 *)*param_2,((undefined4 *)*param_2)[1]);
  uVar19 = uVar18;
  do {
    iVar17 = *(int *)((longlong)local_c8 + uVar19) + *(int *)*param_2;
    iVar16 = *(int *)((longlong)local_c8 + uVar19 + 0x20) + ((int *)*param_2)[1];
    cVar5 = FUN_14056ab10(param_1[0x20],iVar17,iVar16);
    if (cVar5 != '\0') {
      local_res18[0] = FUN_14056ab30(param_1[0x20],iVar17,iVar16);
      local_res20 = (longlong)local_res18[0];
      lVar8 = FUN_140564340(param_1 + 0x22,local_78,local_res20);
      uVar3 = *(undefined8 *)(lVar8 + 0x10);
      puVar9 = (uint *)FUN_140563490(lVar8);
      if ((((*puVar9 & 1 << ((byte)uVar3 & 0x1f)) == 0) &&
          (iVar7 = (**(code **)(*param_1 + 0x18))(param_1,iVar17,iVar16), iVar7 == 0)) &&
         (iVar7 = (**(code **)(*param_1 + 8))(param_1,iVar17,iVar16), uVar12 = iVar6 - iVar7 >> 0x1f
         , (int)((iVar6 - iVar7 ^ uVar12) - uVar12) < 0x1a)) {
        pvVar10 = operator_new(0x28);
        local_80 = pvVar10;
        if (pvVar10 == (void *)0x0) {
          pvVar10 = (void *)0x0;
        }
        else {
          *(undefined8 *)((longlong)pvVar10 + 0x18) = 0;
          *(undefined8 *)((longlong)pvVar10 + 0x20) = 0;
          FUN_1405600b0();
        }
        local_f8 = (int *)0x0;
        local_f0 = (longlong *)0x0;
        FUN_140561cf0(&local_f8,pvVar10);
        plVar4 = local_f0;
        piVar2 = local_f8;
        if (local_f8 == (int *)0x0) {
          if (local_f0 != (longlong *)0x0) {
            LOCK();
            plVar1 = local_f0 + 2;
            lVar8 = *plVar1;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)lVar8 == 1) {
              (**(code **)*local_f0)(local_f0);
              LOCK();
              piVar2 = (int *)((longlong)plVar4 + 0x14);
              iVar6 = *piVar2;
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (iVar6 == 1) {
                (**(code **)(*local_f0 + 8))();
              }
            }
          }
          plVar4 = (longlong *)param_2[1];
          if (plVar4 != (longlong *)0x0) {
            LOCK();
            plVar1 = plVar4 + 2;
            lVar8 = *plVar1;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)lVar8 == 1) {
              (**(code **)*plVar4)(plVar4);
              LOCK();
              piVar2 = (int *)((longlong)plVar4 + 0x14);
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (*piVar2 == 0) {
                (**(code **)(*plVar4 + 8))(plVar4);
              }
            }
          }
          return 0;
        }
        *local_f8 = iVar17;
        local_f8[1] = iVar16;
        iVar7 = 1000;
        if ((uVar18 & 1) != 0) {
          iVar7 = 0x586;
        }
        local_f8[2] = iVar7 + *(int *)(*param_2 + 8);
        uVar12 = *(int *)((longlong)param_1 + 0x24) - iVar17;
        uVar13 = (int)uVar12 >> 0x1f;
        iVar17 = (uVar12 ^ uVar13) - uVar13;
        uVar12 = (int)param_1[5] - iVar16;
        uVar13 = (int)uVar12 >> 0x1f;
        iVar16 = (uVar12 ^ uVar13) - uVar13;
        if (iVar17 < iVar16) {
          iVar17 = iVar16;
        }
        local_f8[3] = iVar17 * 1000;
        local_f8[4] = *(int *)(*param_2 + 0x10) + 1;
        local_f8[5] = (int)uVar18;
        FUN_14055f510(local_f8 + 6,*param_2,param_2[1]);
        lVar8 = FUN_140564340(param_1 + 0x22,local_60,local_res20);
        puVar9 = (uint *)FUN_140563490(lVar8);
        *puVar9 = *puVar9 | 1 << ((byte)*(undefined8 *)(lVar8 + 0x10) & 0x1f);
        FUN_14000f0a0(param_1 + 0x1a,local_res18);
        lVar8 = param_1[0xb];
        lVar11 = FUN_140561b20(param_1 + 6,lVar8,*(undefined8 *)(lVar8 + 8),&local_f8);
        FUN_1405602f0(param_1 + 6,1);
        plVar4 = local_f0;
        *(longlong *)(lVar8 + 8) = lVar11;
        **(longlong **)(lVar11 + 8) = lVar11;
        iVar16 = *(int *)((longlong)param_1 + 0x24);
        iVar7 = *(int *)((longlong)param_1 + 0x14) - iVar16;
        iVar17 = (int)param_1[5];
        iVar14 = (int)param_1[3] - iVar17;
        iVar15 = iVar14 * iVar14 + iVar7 * iVar7;
        iVar7 = *piVar2;
        iVar14 = (piVar2[1] - iVar17) * (piVar2[1] - iVar17) + (iVar7 - iVar16) * (iVar7 - iVar16);
        if ((int)param_1[2] == 1) {
          if (iVar14 < iVar15) {
            *(int *)((longlong)param_1 + 0x14) = iVar7;
            *(int *)(param_1 + 3) = piVar2[1];
          }
          if ((*piVar2 == iVar16) && (piVar2[1] == iVar17)) {
            local_d8 = 0;
            local_d0 = 0;
            FUN_14055f510(&local_d8,piVar2,local_f0);
            FUN_140563780(param_1,&local_d8);
            plVar1 = local_f0;
            if (plVar4 != (longlong *)0x0) {
              LOCK();
              plVar4 = plVar4 + 2;
              lVar8 = *plVar4;
              *(int *)plVar4 = (int)*plVar4 + -1;
              UNLOCK();
              if ((int)lVar8 == 1) {
                (**(code **)*local_f0)(local_f0);
                LOCK();
                piVar2 = (int *)((longlong)plVar1 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 == 0) {
                  (**(code **)(*local_f0 + 8))();
                }
              }
            }
            FUN_14055fca0(param_2);
            return 1;
          }
        }
        else if (iVar15 < iVar14) {
          *(int *)((longlong)param_1 + 0x14) = iVar7;
          *(int *)(param_1 + 3) = piVar2[1];
          if (*(int *)((longlong)param_1 + 0xc) * *(int *)((longlong)param_1 + 0xc) <= iVar14) {
            local_e8 = 0;
            local_e0 = 0;
            FUN_14055f510(&local_e8,piVar2,local_f0);
            FUN_140563780(param_1,&local_e8);
            plVar1 = local_f0;
            if (plVar4 != (longlong *)0x0) {
              LOCK();
              plVar4 = plVar4 + 2;
              lVar8 = *plVar4;
              *(int *)plVar4 = (int)*plVar4 + -1;
              UNLOCK();
              if ((int)lVar8 == 1) {
                (**(code **)*local_f0)(local_f0);
                LOCK();
                piVar2 = (int *)((longlong)plVar1 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 == 0) {
                  (**(code **)(*local_f0 + 8))();
                }
              }
            }
            FUN_14055fca0(param_2);
            return 1;
          }
        }
        if (local_f0 != (longlong *)0x0) {
          LOCK();
          plVar1 = local_f0 + 2;
          lVar8 = *plVar1;
          *(int *)plVar1 = (int)*plVar1 + -1;
          UNLOCK();
          if ((int)lVar8 == 1) {
            (**(code **)*local_f0)(local_f0);
            LOCK();
            piVar2 = (int *)((longlong)plVar4 + 0x14);
            iVar16 = *piVar2;
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (iVar16 == 1) {
              (**(code **)(*local_f0 + 8))();
            }
          }
        }
      }
    }
    uVar12 = (int)uVar18 + 1;
    uVar18 = (ulonglong)uVar12;
    uVar19 = uVar19 + 4;
    if (7 < (int)uVar12) {
      plVar4 = (longlong *)param_2[1];
      if (plVar4 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar4 + 2;
        lVar8 = *plVar1;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)lVar8 == 1) {
          (**(code **)*plVar4)(plVar4);
          LOCK();
          piVar2 = (int *)((longlong)plVar4 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar4 + 8))(plVar4);
          }
        }
      }
      return 0;
    }
  } while( true );
}

// ==== CMapData::vfunc_10  @140565660  [high:rtti-vtable]  (orig: FUN_140565660)
undefined8 FUN_140565660(longlong param_1,int param_2)

{
  int *piVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong lVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  ulonglong *puVar12;
  ulonglong uVar13;
  undefined8 *puVar14;
  undefined8 *puVar15;
  longlong *plVar16;
  longlong *plVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  longlong lVar20;
  uint uVar21;
  ulonglong uVar22;
  longlong *plVar23;
  uint local_res20;
  longlong *local_148;
  ulonglong *local_138;
  ulonglong local_128;
  undefined8 local_e0;
  longlong *local_d8;
  undefined8 local_d0;
  longlong *local_c8;
  longlong local_c0;
  undefined8 *local_b8;
  longlong local_b0;
  undefined8 local_a8;
  ulonglong *local_98;
  longlong *plStack_90;
  longlong *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong local_68;
  longlong local_60;
  undefined1 local_58 [24];
  
  local_78 = 0xfffffffffffffffe;
  puVar12 = *(ulonglong **)(param_1 + 0x158);
  local_148 = (longlong *)**(undefined8 **)(param_1 + 0x180);
  local_138 = puVar12;
  while( true ) {
    uVar13 = 0;
    plVar16 = *(longlong **)(param_1 + 0x180);
    if ((puVar12 == (ulonglong *)0x0) || (puVar12 != *(ulonglong **)(param_1 + 0x158))) {
      _invalid_parameter_noinfo();
    }
    if (local_148 == plVar16) break;
    if (puVar12 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar19 = uVar13;
    }
    else {
      uVar19 = *puVar12;
    }
    if (local_148 == *(longlong **)(uVar19 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    plVar16 = (longlong *)local_148[3];
    lVar3 = local_148[2];
    if (plVar16 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar16 + 2) = (int)plVar16[2] + 1;
      UNLOCK();
    }
    local_c8 = plVar16;
    iVar9 = FUN_140571650(lVar3);
    if (iVar9 == param_2) {
      iVar9 = FUN_140571a80(lVar3);
      local_res20 = 0;
      if (0 < iVar9) {
        do {
          FUN_140572280(lVar3,&local_e0,uVar13);
          puVar12 = (ulonglong *)FUN_140570bf0(local_e0);
          uVar19 = *puVar12;
          puVar12 = (ulonglong *)FUN_140570bd0(local_e0);
          uVar18 = *puVar12;
          uVar21 = (uint)uVar13;
          local_d0 = uVar18;
          if (0 < (int)uVar19) {
            uVar13 = uVar19 & 0xffffffff;
            do {
              local_128 = uVar19 >> 0x20;
              if (0 < (int)(uVar19 >> 0x20)) {
                iVar11 = local_d0._4_4_;
                do {
                  cVar8 = FUN_14056ab10(*(undefined8 *)(param_1 + 0x100),uVar18 & 0xffffffff,iVar11)
                  ;
                  if (cVar8 != '\0') {
                    iVar10 = FUN_14056ab30(*(undefined8 *)(param_1 + 0x100),uVar18 & 0xffffffff,
                                           iVar11);
                    plVar16 = (longlong *)(param_1 + 400);
                    puVar15 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1c0))[1];
                    cVar8 = *(char *)((longlong)puVar15 + 0x21);
                    puVar6 = *(undefined8 **)(param_1 + 0x1c0);
                    while (cVar8 == '\0') {
                      if (*(int *)(puVar15 + 3) < iVar10) {
                        puVar14 = (undefined8 *)puVar15[2];
                        puVar15 = puVar6;
                      }
                      else {
                        puVar14 = (undefined8 *)*puVar15;
                      }
                      puVar6 = puVar15;
                      puVar15 = puVar14;
                      cVar8 = *(char *)((longlong)puVar14 + 0x21);
                    }
                    local_b8 = puVar6;
                    local_c0 = *plVar16;
                    puVar15 = *(undefined8 **)(param_1 + 0x1c0);
                    if (*plVar16 == 0) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar6 == puVar15) || (iVar10 < *(int *)(puVar6 + 3))) {
                      local_a8 = *(undefined8 *)(param_1 + 0x1c0);
                      local_b0 = *plVar16;
                      plVar23 = &local_b0;
                    }
                    else {
                      plVar23 = &local_c0;
                    }
                    plVar4 = (longlong *)*plVar23;
                    local_80 = plVar23[1];
                    lVar20 = *(longlong *)(param_1 + 0x1c0);
                    local_88 = plVar4;
                    if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar16)) {
                      _invalid_parameter_noinfo();
                    }
                    lVar7 = local_80;
                    if (local_80 != lVar20) {
                      if (plVar4 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar20 = 0;
                      }
                      else {
                        lVar20 = *plVar4;
                      }
                      if (lVar7 == *(longlong *)(lVar20 + 0x30)) {
                        _invalid_parameter_noinfo();
                      }
                      uVar22 = (ulonglong)*(int *)(lVar7 + 0x1c);
                      if ((ulonglong)
                          ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8)) / 0x30)
                          <= uVar22) {
                        _invalid_parameter_noinfo();
                      }
                      lVar20 = uVar22 * 0x30 + *(longlong *)(param_1 + 0xb8);
                      plVar4 = *(longlong **)(lVar20 + 0x20);
                      if (((longlong)plVar4 - *(longlong *)(lVar20 + 0x18) & 0xfffffffffffffff0U) !=
                          0) {
                        if (plVar4 + -2 != plVar4) {
                          plVar17 = plVar4 + -1;
                          do {
                            plVar5 = (longlong *)*plVar17;
                            if (plVar5 != (longlong *)0x0) {
                              LOCK();
                              plVar2 = plVar5 + 2;
                              *(int *)plVar2 = (int)*plVar2 + -1;
                              UNLOCK();
                              if ((int)*plVar2 == 0) {
                                (**(code **)*plVar5)(plVar5);
                                LOCK();
                                piVar1 = (int *)((longlong)plVar5 + 0x14);
                                *piVar1 = *piVar1 + -1;
                                UNLOCK();
                                if (*piVar1 == 0) {
                                  (**(code **)(*plVar5 + 8))(plVar5);
                                }
                              }
                            }
                            plVar5 = plVar17 + 1;
                            plVar17 = plVar17 + 2;
                          } while (plVar5 != plVar4);
                        }
                        *(longlong *)(lVar20 + 0x20) = *(longlong *)(lVar20 + 0x20) + -0x10;
                      }
                      if ((ulonglong)
                          ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8)) / 0x30)
                          <= uVar22) {
                        _invalid_parameter_noinfo();
                      }
                      lVar20 = uVar22 * 0x30 + *(longlong *)(param_1 + 0xb8);
                      if ((*(longlong *)(lVar20 + 0x20) - *(longlong *)(lVar20 + 0x18) &
                          0xfffffffffffffff0U) == 0) {
                        local_68 = *plVar23;
                        local_60 = plVar23[1];
                        FUN_14009f1a0(plVar16,local_58,&local_68);
                      }
                    }
                  }
                  iVar11 = iVar11 + -1;
                  local_128 = local_128 - 1;
                } while (local_128 != 0);
              }
              uVar18 = (ulonglong)((int)uVar18 - 1);
              uVar13 = uVar13 - 1;
              uVar21 = local_res20;
            } while (uVar13 != 0);
          }
          plVar16 = local_d8;
          if (local_d8 != (longlong *)0x0) {
            LOCK();
            plVar23 = local_d8 + 2;
            *(int *)plVar23 = (int)*plVar23 + -1;
            UNLOCK();
            if ((int)*plVar23 == 0) {
              (**(code **)*local_d8)(local_d8);
              LOCK();
              piVar1 = (int *)((longlong)plVar16 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*plVar16 + 8))(plVar16);
              }
            }
          }
          local_res20 = uVar21 + 1;
          uVar13 = (ulonglong)local_res20;
          plVar16 = local_c8;
          puVar12 = local_138;
        } while ((int)local_res20 < iVar9);
      }
      uVar13 = 0;
      if (puVar12 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        uVar13 = *puVar12;
      }
      if (local_148 == *(longlong **)(uVar13 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      plVar23 = (longlong *)*local_148;
      if (local_148 != *(longlong **)(param_1 + 0x180)) {
        *(longlong **)local_148[1] = plVar23;
        *(longlong *)(*local_148 + 8) = local_148[1];
        plVar4 = (longlong *)local_148[3];
        if (plVar4 != (longlong *)0x0) {
          LOCK();
          plVar17 = plVar4 + 2;
          *(int *)plVar17 = (int)*plVar17 + -1;
          UNLOCK();
          if ((int)*plVar17 == 0) {
            (**(code **)*plVar4)(plVar4);
            LOCK();
            piVar1 = (int *)((longlong)plVar4 + 0x14);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
              (**(code **)(*plVar4 + 8))(plVar4);
            }
          }
        }
        operator_delete(local_148);
        *(longlong *)(param_1 + 0x188) = *(longlong *)(param_1 + 0x188) + -1;
      }
      puVar12 = *(ulonglong **)(param_1 + 0x158);
      local_148 = plVar23;
      local_138 = puVar12;
      local_98 = puVar12;
      plStack_90 = plVar23;
      if (plVar16 != (longlong *)0x0) {
        LOCK();
        plVar23 = plVar16 + 2;
        *(int *)plVar23 = (int)*plVar23 + -1;
        UNLOCK();
        if ((int)*plVar23 == 0) {
          (**(code **)*plVar16)(plVar16);
          LOCK();
          piVar1 = (int *)((longlong)plVar16 + 0x14);
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (*piVar1 == 0) {
            (**(code **)(*plVar16 + 8))(plVar16);
          }
        }
      }
    }
    else {
      if (puVar12 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        uVar13 = *puVar12;
      }
      if (local_148 == *(longlong **)(uVar13 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      local_148 = (longlong *)*local_148;
      if (plVar16 != (longlong *)0x0) {
        LOCK();
        plVar23 = plVar16 + 2;
        *(int *)plVar23 = (int)*plVar23 + -1;
        UNLOCK();
        if ((int)*plVar23 == 0) {
          (**(code **)*plVar16)(plVar16);
          LOCK();
          piVar1 = (int *)((longlong)plVar16 + 0x14);
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (*piVar1 == 0) {
            (**(code **)(*plVar16 + 8))(plVar16);
          }
        }
      }
    }
  }
  return 1;
}

// ==== CMapData::helper_140565c60  @140565c60  [medium:callgraph-r0]  (orig: FUN_140565c60)
/* WARNING: Removing unreachable block (ram,0x000140566484) */
/* WARNING: Removing unreachable block (ram,0x00014056648b) */
/* WARNING: Removing unreachable block (ram,0x00014056649a) */

void FUN_140565c60(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  uint *puVar1;
  int *piVar2;
  longlong *plVar3;
  uint *puVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong **pplVar7;
  char cVar8;
  uint uVar9;
  int iVar10;
  void *pvVar11;
  longlong lVar12;
  longlong lVar13;
  uint *puVar14;
  void *pvVar15;
  int iVar16;
  void *pvVar17;
  uint uVar18;
  longlong *plVar19;
  longlong **pplVar20;
  uint uVar21;
  void *local_res8;
  longlong *local_108;
  uint *local_100;
  undefined4 *local_f8;
  longlong *local_f0;
  longlong *local_e8;
  uint *puStack_e0;
  longlong *local_d8;
  uint *local_d0;
  undefined8 local_c8;
  longlong **pplStack_c0;
  undefined4 local_b8;
  undefined4 uStack_b4;
  longlong **pplStack_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  longlong *local_98;
  uint *puStack_90;
  longlong local_88;
  longlong **local_78;
  longlong *local_70;
  uint *local_68;
  longlong local_60;
  undefined8 local_58;
  undefined1 local_50 [24];
  
  local_58 = 0xfffffffffffffffe;
  *(undefined8 *)(param_1 + 0x14) = param_2;
  *(undefined8 *)(param_1 + 0x1c) = param_2;
  *(undefined8 *)(param_1 + 0x24) = param_3;
  if (((int)param_2 == (int)param_3) &&
     ((int)((ulonglong)param_2 >> 0x20) == (int)((ulonglong)param_3 >> 0x20))) {
    return;
  }
  FUN_140563220(param_1 + 0x30);
  FUN_140563220(param_1 + 0x68);
  *(undefined4 *)(param_1 + 8) = 0;
  puVar14 = *(uint **)(param_1 + 0xe8);
  if (*(uint **)(param_1 + 0xf0) < puVar14) {
    _invalid_parameter_noinfo();
  }
  plVar3 = *(longlong **)(param_1 + 0xd0);
  uVar21 = 1;
  local_e8 = plVar3;
  puStack_e0 = puVar14;
  while( true ) {
    pvVar15 = (void *)0x0;
    puVar4 = *(uint **)(param_1 + 0xf0);
    if (puVar4 < *(uint **)(param_1 + 0xe8)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xd0))) {
      _invalid_parameter_noinfo();
    }
    if (puVar14 == puVar4) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      pvVar15 = (void *)*plVar3;
    }
    if (*(uint **)((longlong)pvVar15 + 0x20) <= puVar14) {
      _invalid_parameter_noinfo();
    }
    uVar9 = *puVar14;
    puVar4 = *(uint **)(param_1 + 0x140);
    if (*(uint **)(param_1 + 0x148) < puVar4) {
      _invalid_parameter_noinfo();
    }
    local_88 = 0;
    puStack_90 = puVar4;
    if ((longlong *)(param_1 + 0x110) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    local_98 = *(longlong **)(param_1 + 0x110);
    local_68 = puStack_90;
    local_60 = local_88;
    local_70 = local_98;
    FUN_140562ba0(&local_70,(longlong)(int)uVar9);
    if (local_70 == (longlong *)0x0) {
      plVar19 = (longlong *)0x0;
LAB_140565e07:
      _invalid_parameter_noinfo();
    }
    else {
      plVar19 = (longlong *)*local_70;
      if (plVar19 == (longlong *)0x0) goto LAB_140565e07;
    }
    puVar4 = local_68;
    plVar19 = (longlong *)*plVar19;
    if ((plVar19 == (longlong *)0x0) || (local_68 == (uint *)0x0)) {
      _invalid_parameter_noinfo();
    }
    if (plVar19 == (longlong *)0x0) {
      lVar13 = 0;
    }
    else {
      lVar13 = *plVar19;
    }
    uVar5 = *(ulonglong *)(lVar13 + 0x30);
    if (*(ulonglong *)(lVar13 + 0x38) < uVar5) {
      _invalid_parameter_noinfo();
    }
    lVar13 = local_60;
    if (plVar19 == (longlong *)0x0) {
      lVar12 = 0;
    }
    else {
      lVar12 = *plVar19;
    }
    if (*(ulonglong *)(lVar12 + 0x10) <=
        (ulonglong)(((longlong)((longlong)puVar4 - uVar5) >> 2) * 0x20 + local_60)) {
      _invalid_parameter_noinfo();
    }
    *puVar4 = *puVar4 & ~(1 << ((byte)lVar13 & 0x1f));
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar13 = 0;
    }
    else {
      lVar13 = *plVar3;
    }
    if (*(uint **)(lVar13 + 0x20) <= puVar14) {
      _invalid_parameter_noinfo();
    }
    puVar14 = puVar14 + 1;
  }
  FUN_14019de20(param_1 + 0xd0);
  pvVar11 = operator_new(0x28);
  pvVar17 = pvVar15;
  local_res8 = pvVar11;
  if (pvVar11 != (void *)0x0) {
    *(undefined8 *)((longlong)pvVar11 + 0x18) = 0;
    *(undefined8 *)((longlong)pvVar11 + 0x20) = 0;
    FUN_1405600b0();
    pvVar17 = pvVar11;
  }
  local_f8 = (undefined4 *)0x0;
  local_f0 = (longlong *)0x0;
  FUN_140561cf0(&local_f8,pvVar17);
  if (local_f8 != (undefined4 *)0x0) {
    *local_f8 = *(undefined4 *)(param_1 + 0x1c);
    local_f8[1] = *(undefined4 *)(param_1 + 0x20);
    local_f8[2] = 0;
    uVar9 = *(int *)(param_1 + 0x24) - *(int *)(param_1 + 0x1c);
    uVar18 = (int)uVar9 >> 0x1f;
    iVar16 = (uVar9 ^ uVar18) - uVar18;
    uVar9 = *(int *)(param_1 + 0x28) - *(int *)(param_1 + 0x20);
    uVar18 = (int)uVar9 >> 0x1f;
    iVar10 = (uVar9 ^ uVar18) - uVar18;
    if (iVar16 < iVar10) {
      iVar16 = iVar10;
    }
    local_f8[3] = iVar16 * 1000;
    local_f8[4] = 0;
    local_a0 = 0;
    local_a8 = 0;
    FUN_14055f510(local_f8 + 6,0,0);
    lVar13 = *(longlong *)(param_1 + 0x58);
    lVar12 = FUN_140561b20(param_1 + 0x30,lVar13,*(undefined8 *)(lVar13 + 8),&local_f8);
    FUN_1405602f0(param_1 + 0x30,1);
    *(longlong *)(lVar13 + 8) = lVar12;
    **(longlong **)(lVar12 + 8) = lVar12;
  }
  cVar8 = FUN_14056ab10(*(undefined8 *)(param_1 + 0x100),*(undefined4 *)(param_1 + 0x1c),
                        *(undefined4 *)(param_1 + 0x20));
  if (cVar8 != '\0') {
    uVar9 = FUN_14056ab30(*(undefined8 *)(param_1 + 0x100),*(undefined4 *)(param_1 + 0x1c),
                          *(undefined4 *)(param_1 + 0x20));
    local_res8 = (void *)CONCAT44(local_res8._4_4_,uVar9);
    lVar13 = FUN_140564340(param_1 + 0x110,local_50,(longlong)(int)uVar9);
    puVar14 = (uint *)FUN_140563490(lVar13);
    *puVar14 = *puVar14 | 1 << ((byte)*(undefined8 *)(lVar13 + 0x10) & 0x1f);
    puVar14 = *(uint **)(param_1 + 0xe8);
    pvVar17 = pvVar15;
    if (puVar14 != (uint *)0x0) {
      pvVar17 = (void *)(*(longlong *)(param_1 + 0xf8) - (longlong)puVar14 >> 2);
    }
    puVar4 = *(uint **)(param_1 + 0xf0);
    if ((void *)((longlong)puVar4 - (longlong)puVar14 >> 2) < pvVar17) {
      *puVar4 = uVar9;
      *(uint **)(param_1 + 0xf0) = puVar4 + 1;
    }
    else {
      if (puVar4 < puVar14) {
        _invalid_parameter_noinfo();
      }
      plVar3 = *(longlong **)(param_1 + 0xd0);
      uVar5 = *(ulonglong *)(param_1 + 0xe8);
      pvVar17 = pvVar15;
      local_e8 = plVar3;
      puStack_e0 = puVar4;
      if ((*(ulonglong *)(param_1 + 0xf0) - uVar5 & 0xfffffffffffffffc) != 0) {
        if (*(ulonglong *)(param_1 + 0xf0) < uVar5) {
          _invalid_parameter_noinfo();
        }
        if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xd0))) {
          _invalid_parameter_noinfo();
        }
        pvVar17 = (void *)((longlong)((longlong)puVar4 - uVar5) >> 2);
      }
      local_98 = local_e8;
      puStack_90 = puStack_e0;
      FUN_14000df40(param_1 + 0xd0,&local_98,1,&local_res8);
      uVar5 = *(ulonglong *)(param_1 + 0xe8);
      if (*(ulonglong *)(param_1 + 0xf0) < uVar5) {
        _invalid_parameter_noinfo();
      }
      puVar6 = *(undefined8 **)(param_1 + 0xd0);
      if (puVar6 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        pvVar11 = pvVar15;
      }
      else {
        pvVar11 = (void *)*puVar6;
      }
      uVar5 = uVar5 + (longlong)pvVar17 * 4;
      if (uVar5 <= *(ulonglong *)((longlong)pvVar11 + 0x20)) {
        if (puVar6 != (undefined8 *)0x0) {
          pvVar15 = (void *)*puVar6;
        }
        if (*(ulonglong *)((longlong)pvVar15 + 0x18) <= uVar5) goto LAB_140566160;
      }
      _invalid_parameter_noinfo();
    }
  }
LAB_140566160:
  while( true ) {
    plVar3 = local_f0;
    if (0x3f < *(int *)(param_1 + 8)) {
      if (local_f0 == (longlong *)0x0) {
        return;
      }
      LOCK();
      plVar19 = local_f0 + 2;
      *(int *)plVar19 = (int)*plVar19 + -1;
      UNLOCK();
      if ((int)*plVar19 != 0) {
        return;
      }
      (**(code **)*local_f0)(local_f0);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 != 0) {
        return;
      }
      (**(code **)(*local_f0 + 8))();
      return;
    }
    if (*(longlong *)(param_1 + 0x60) == 0) break;
    pplVar20 = (longlong **)**(longlong **)(param_1 + 0x58);
    plVar3 = *(longlong **)(param_1 + 0x30);
    local_c8 = plVar3;
    pplStack_c0 = pplVar20;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar13 = 0;
    }
    else {
      lVar13 = *plVar3;
    }
    lVar12 = 0;
    if (pplVar20 == *(longlong ***)(lVar13 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar14 = (uint *)pplVar20[3];
    local_108 = pplVar20[2];
    if (puVar14 != (uint *)0x0) {
      LOCK();
      puVar14[4] = puVar14[4] + 1;
      UNLOCK();
    }
    local_b8 = (undefined4)local_c8;
    uStack_b4 = local_c8._4_4_;
    pplStack_b0 = pplStack_c0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar12 = *plVar3;
    }
    if (pplVar20 == *(longlong ***)(lVar12 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    pplVar20 = (longlong **)*pplVar20;
    plVar3 = (longlong *)CONCAT44(uStack_b4,local_b8);
    local_100 = puVar14;
    while( true ) {
      lVar13 = 0;
      pplVar7 = *(longlong ***)(param_1 + 0x58);
      pplStack_b0 = pplVar20;
      if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x30))) {
        _invalid_parameter_noinfo();
      }
      if (pplVar20 == pplVar7) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar13 = *plVar3;
      }
      if (pplVar20 == *(longlong ***)(lVar13 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      puVar4 = (uint *)pplVar20[3];
      plVar19 = pplVar20[2];
      if (puVar4 != (uint *)0x0) {
        LOCK();
        puVar4[4] = puVar4[4] + 1;
        UNLOCK();
        puVar14 = local_100;
      }
      local_e8 = plVar19;
      puStack_e0 = puVar4;
      if (*(int *)(param_1 + 0x10) == 1) {
        if (*(int *)((longlong)plVar19 + 0xc) < *(int *)((longlong)local_108 + 0xc)) {
          if (puVar4 != (uint *)0x0) {
            LOCK();
            puVar4[4] = puVar4[4] + 1;
            UNLOCK();
            puVar14 = local_100;
          }
          if (puVar14 != (uint *)0x0) {
            LOCK();
            puVar14 = puVar14 + 4;
            *puVar14 = *puVar14 - 1;
            UNLOCK();
            if (*puVar14 == 0) {
              (*(code *)**(undefined8 **)local_100)(local_100);
              LOCK();
              puVar14 = local_100 + 5;
              *puVar14 = *puVar14 - 1;
              UNLOCK();
              if (*puVar14 == 0) {
                (**(code **)(*(longlong *)local_100 + 8))();
              }
            }
          }
          local_c8 = (longlong *)CONCAT44(uStack_b4,local_b8);
          pplStack_c0 = pplStack_b0;
          puVar14 = puVar4;
          local_108 = plVar19;
          local_100 = puVar4;
        }
      }
      else if (*(int *)((longlong)local_108 + 0xc) < *(int *)((longlong)plVar19 + 0xc)) {
        if (puVar4 != (uint *)0x0) {
          LOCK();
          puVar4[4] = puVar4[4] + 1;
          UNLOCK();
          puVar14 = local_100;
        }
        if (puVar14 != (uint *)0x0) {
          LOCK();
          puVar14 = puVar14 + 4;
          *puVar14 = *puVar14 - 1;
          UNLOCK();
          if (*puVar14 == 0) {
            (*(code *)**(undefined8 **)local_100)(local_100);
            LOCK();
            puVar14 = local_100 + 5;
            *puVar14 = *puVar14 - 1;
            UNLOCK();
            if (*puVar14 == 0) {
              (**(code **)(*(longlong *)local_100 + 8))();
            }
          }
        }
        local_c8 = (longlong *)CONCAT44(uStack_b4,local_b8);
        pplStack_c0 = pplStack_b0;
        puVar14 = puVar4;
        local_108 = plVar19;
        local_100 = puVar4;
      }
      if (puVar4 != (uint *)0x0) {
        LOCK();
        puVar1 = puVar4 + 4;
        *puVar1 = *puVar1 - 1;
        UNLOCK();
        puVar14 = local_100;
        if (*puVar1 == 0) {
          (*(code *)**(undefined8 **)puVar4)(puVar4);
          LOCK();
          puVar1 = puVar4 + 5;
          *puVar1 = *puVar1 - 1;
          UNLOCK();
          if (*puVar1 == 0) {
            (**(code **)(*(longlong *)puVar4 + 8))(puVar4);
          }
        }
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar13 = 0;
      }
      else {
        lVar13 = *plVar3;
      }
      if (pplVar20 == *(longlong ***)(lVar13 + 0x28)) {
        _invalid_parameter_noinfo();
      }
      pplVar20 = (longlong **)*pplVar20;
    }
    if (local_c8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar13 = *local_c8;
    }
    pplVar20 = pplStack_c0;
    if (pplStack_c0 == *(longlong ***)(lVar13 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    local_78 = pplVar20;
    if (pplVar20 != *(longlong ***)(param_1 + 0x58)) {
      *pplVar20[1] = (longlong)*pplVar20;
      (*pplVar20)[1] = (longlong)pplVar20[1];
      plVar3 = pplVar20[3];
      if (plVar3 != (longlong *)0x0) {
        LOCK();
        plVar19 = plVar3 + 2;
        *(int *)plVar19 = (int)*plVar19 + -1;
        UNLOCK();
        puVar14 = local_100;
        if ((int)*plVar19 == 0) {
          (**(code **)*plVar3)(plVar3);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar3 + 8))(plVar3);
          }
        }
      }
      operator_delete(pplVar20);
      *(longlong *)(param_1 + 0x60) = *(longlong *)(param_1 + 0x60) + -1;
    }
    if ((int)local_108[2] < 0x40) {
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      local_78 = &local_d8;
      if (puVar14 != (uint *)0x0) {
        LOCK();
        puVar14[4] = puVar14[4] + 1;
        UNLOCK();
        puVar14 = local_100;
      }
      local_d8 = local_108;
      local_d0 = puVar14;
      cVar8 = FUN_1405650a0(param_1,&local_d8);
      if (cVar8 != '\0') {
        if (puVar14 != (uint *)0x0) {
          LOCK();
          puVar14 = puVar14 + 4;
          *puVar14 = *puVar14 - 1;
          UNLOCK();
          if (*puVar14 == 0) {
            (*(code *)**(undefined8 **)local_100)(local_100);
            LOCK();
            puVar14 = local_100 + 5;
            *puVar14 = *puVar14 - 1;
            UNLOCK();
            if (*puVar14 == 0) {
              (**(code **)(*(longlong *)local_100 + 8))();
            }
          }
        }
        plVar3 = local_f0;
        if (local_f0 == (longlong *)0x0) {
          return;
        }
        LOCK();
        plVar19 = local_f0 + 2;
        *(int *)plVar19 = (int)*plVar19 + -1;
        UNLOCK();
        if ((int)*plVar19 != 0) {
          return;
        }
        (**(code **)*local_f0)(local_f0);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 != 0) {
          return;
        }
        (**(code **)(*local_f0 + 8))();
        return;
      }
    }
    if (puVar14 != (uint *)0x0) {
      LOCK();
      puVar14 = puVar14 + 4;
      *puVar14 = *puVar14 - 1;
      UNLOCK();
      if (*puVar14 == 0) {
        (*(code *)**(undefined8 **)local_100)(local_100);
        LOCK();
        puVar14 = local_100 + 5;
        *puVar14 = *puVar14 - 1;
        UNLOCK();
        if (*puVar14 == 0) {
          (**(code **)(*(longlong *)local_100 + 8))();
        }
      }
    }
    uVar21 = uVar21 + 1;
    if (0x10000 < uVar21) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = local_f0;
      if (local_f0 != (longlong *)0x0) {
        LOCK();
        plVar19 = local_f0 + 2;
        *(int *)plVar19 = (int)*plVar19 + -1;
        UNLOCK();
        if ((int)*plVar19 == 0) {
          (**(code **)*local_f0)(local_f0);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*local_f0 + 8))();
          }
        }
      }
      return;
    }
  }
  if (local_f0 == (longlong *)0x0) {
    return;
  }
  LOCK();
  plVar19 = local_f0 + 2;
  *(int *)plVar19 = (int)*plVar19 + -1;
  UNLOCK();
  if ((int)*plVar19 != 0) {
    return;
  }
  (**(code **)*local_f0)(local_f0);
  LOCK();
  piVar2 = (int *)((longlong)plVar3 + 0x14);
  *piVar2 = *piVar2 + -1;
  UNLOCK();
  if (*piVar2 != 0) {
    return;
  }
  (**(code **)(*local_f0 + 8))();
  return;
}

// ==== CMapData::vfunc_11  @140566670  [high:rtti-vtable]  (orig: FUN_140566670)
undefined8
FUN_140566670(longlong param_1,undefined8 *param_2,int param_3,undefined8 *param_4,
             undefined8 *param_5,int param_6)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong lVar8;
  undefined1 *puVar9;
  
  *(int *)(param_1 + 0xc) = param_6;
  *(uint *)(param_1 + 0x10) = (param_6 != 0) + 1;
  FUN_140565c60(param_1,*param_4,*param_5,param_4,0xfffffffffffffffe);
  if ((*(longlong *)(param_1 + 0x98) == 0) || (*(int *)(param_1 + 0x10) == 2)) {
    if (*(int *)(param_1 + 0x10) == 2) {
      *(undefined4 *)(param_1 + 0x10) = 1;
      FUN_140565c60(param_1,*param_4,*(undefined8 *)(param_1 + 0x14));
      *(undefined4 *)(param_1 + 0x10) = 2;
    }
    else {
      FUN_140565c60(param_1,*param_4,*(undefined8 *)(param_1 + 0x14));
    }
  }
  puVar9 = (undefined1 *)((longlong)param_2 + 0x14);
  memset(param_2,0,(longlong)param_3);
  param_3 = param_3 + -0x18;
  puVar7 = (undefined8 *)**(undefined8 **)(param_1 + 0x90);
  plVar3 = *(longlong **)(param_1 + 0x68);
  while( true ) {
    puVar4 = *(undefined8 **)(param_1 + 0x90);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x68))) {
      _invalid_parameter_noinfo();
    }
    if ((puVar7 == puVar4) || (param_3 < 0)) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar3;
    }
    if (puVar7 == *(undefined8 **)(lVar8 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    plVar5 = (longlong *)puVar7[3];
    lVar8 = puVar7[2];
    if (plVar5 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar5 + 2) = (int)plVar5[2] + 1;
      UNLOCK();
    }
    *puVar9 = *(undefined1 *)(lVar8 + 0x14);
    puVar9 = puVar9 + 1;
    if (plVar5 != (longlong *)0x0) {
      LOCK();
      plVar1 = plVar5 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*plVar5)(plVar5);
        LOCK();
        piVar2 = (int *)((longlong)plVar5 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*plVar5 + 8))(plVar5);
        }
      }
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar3;
    }
    if (puVar7 == *(undefined8 **)(lVar8 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puVar7 = (undefined8 *)*puVar7;
    param_3 = param_3 + -1;
  }
  *(int *)(param_2 + 2) = ((int)puVar9 - (int)param_2) + -0x14;
  *param_2 = *param_4;
  uVar6 = *(undefined8 *)(param_1 + 0x14);
  param_2[1] = uVar6;
  return CONCAT71((int7)((ulonglong)uVar6 >> 8),1);
}

// ==== CMapData::helper_140566c60  @140566c60  [medium:callgraph-r2]  (orig: FUN_140566c60)
longlong FUN_140566c60(longlong param_1,longlong param_2)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined1 local_res8;
  
  if (param_1 == param_2) {
    return param_1;
  }
  lVar1 = *(longlong *)(param_2 + 0x18);
  uVar4 = *(longlong *)(param_2 + 0x20) - lVar1 >> 4;
  if (uVar4 == 0) {
    FUN_140564a30(param_1);
    return param_1;
  }
  lVar2 = *(longlong *)(param_1 + 0x18);
  uVar7 = *(longlong *)(param_1 + 0x20) - lVar2 >> 4;
  if (uVar4 <= uVar7) {
    uVar5 = FUN_140561e90(lVar1,*(longlong *)(param_2 + 0x20),lVar2);
    FUN_140563af0(param_1,uVar5,*(undefined8 *)(param_1 + 0x20));
    *(ulonglong *)(param_1 + 0x20) =
         (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) & 0xfffffffffffffff0U) +
         *(longlong *)(param_1 + 0x18);
    return param_1;
  }
  if (lVar2 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(longlong *)(param_1 + 0x28) - lVar2 >> 4;
  }
  if (uVar4 <= uVar6) {
    lVar8 = uVar7 * 0x10 + lVar1;
    FUN_140561e90(lVar1,lVar8,lVar2);
    uVar5 = FUN_140561f90(lVar8,*(undefined8 *)(param_2 + 0x20),*(undefined8 *)(param_1 + 0x20),
                          param_1 + 0x10,local_res8,0);
    *(undefined8 *)(param_1 + 0x20) = uVar5;
    return param_1;
  }
  if (lVar2 != 0) {
    FUN_140563af0(param_1);
    operator_delete(*(void **)(param_1 + 0x18));
  }
  cVar3 = FUN_140560230(param_1,*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 4);
  if (cVar3 != '\0') {
    uVar5 = FUN_140563720(param_1,*(undefined8 *)(param_2 + 0x18),*(undefined8 *)(param_2 + 0x20),
                          *(undefined8 *)(param_1 + 0x18));
    *(undefined8 *)(param_1 + 0x20) = uVar5;
  }
  return param_1;
}

// ==== CMapData::helper_1405672c0  @1405672c0  [medium:callgraph-r1]  (orig: FUN_1405672c0)
longlong FUN_1405672c0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_140566c60(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMapData::helper_1405673f0  @1405673f0  [medium:callgraph-r1]  (orig: FUN_1405673f0)
undefined8 *
FUN_1405673f0(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3,undefined8 *param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined1 local_res8;
  undefined8 local_c8;
  ulonglong local_c0;
  longlong local_b8;
  undefined8 local_a8;
  ulonglong local_a0;
  longlong local_98;
  undefined8 local_88;
  ulonglong local_80;
  longlong local_78;
  undefined8 local_68;
  ulonglong local_60;
  longlong local_58;
  undefined8 local_48;
  ulonglong local_40;
  longlong local_38;
  
  local_c8 = *param_3;
  uVar6 = param_1[6];
  local_c0 = param_3[1];
  local_b8 = param_3[2];
  if ((ulonglong)param_1[7] < uVar6) {
    _invalid_parameter_noinfo();
  }
  local_78 = 0;
  local_80 = uVar6;
  if (param_1 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
  }
  local_88 = *param_1;
  lVar5 = 0;
  if (param_1[2] != 0) {
    uVar6 = param_1[6];
    if ((ulonglong)param_1[7] < uVar6) {
      _invalid_parameter_noinfo();
    }
    FUN_140562ba0(&local_88,((longlong)(local_c0 - uVar6) >> 2) * 0x20 + local_b8);
    lVar5 = local_78;
    uVar6 = local_80;
  }
  local_c8 = *param_4;
  local_c0 = param_4[1];
  local_b8 = param_4[2];
  uVar1 = param_1[6];
  if ((ulonglong)param_1[7] < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_a8 = *param_1;
  local_98 = 0;
  local_a0 = uVar1;
  if (param_1[2] != 0) {
    uVar1 = param_1[6];
    if ((ulonglong)param_1[7] < uVar1) {
      _invalid_parameter_noinfo();
    }
    FUN_140562ba0(&local_a8,((longlong)(local_c0 - uVar1) >> 2) * 0x20 + local_b8);
  }
  lVar4 = local_98;
  uVar3 = local_a0;
  uVar1 = param_1[6];
  if ((ulonglong)param_1[7] < uVar1) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[6];
  if ((ulonglong)param_1[7] < uVar2) {
    _invalid_parameter_noinfo();
  }
  local_68 = *param_1;
  local_58 = 0;
  local_60 = uVar2;
  if (param_1[2] != 0) {
    FUN_140562ba0(&local_68);
  }
  local_c8 = local_88;
  local_c0 = local_80;
  local_b8 = local_78;
  FUN_140562ba0(&local_c8,local_58 + (((longlong)(local_60 - uVar3) >> 2) * 0x20 - lVar4));
  local_48 = local_88;
  local_40 = local_80;
  local_38 = local_78;
  local_88 = local_68;
  local_80 = local_60;
  local_78 = local_58;
  local_68 = local_a8;
  local_60 = local_a0;
  local_58 = local_98;
  FUN_140564b00(&local_a8,&local_68,&local_88,&local_48,local_res8,0,0);
  uVar3 = param_1[6];
  if ((ulonglong)param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  FUN_140562870(param_1,((longlong)(local_c0 - uVar3) >> 2) * 0x20 + local_b8);
  uVar3 = param_1[6];
  if ((ulonglong)param_1[7] < uVar3) {
    _invalid_parameter_noinfo();
  }
  local_c8 = *param_1;
  local_b8 = 0;
  local_98 = 0;
  local_c0 = uVar3;
  local_a8 = local_c8;
  local_a0 = uVar3;
  FUN_140562ba0(&local_a8,((longlong)(uVar6 - uVar1) >> 2) * 0x20 + lVar5);
  *param_2 = local_a8;
  param_2[1] = local_a0;
  param_2[2] = local_98;
  return param_2;
}

// ==== CMapData::helper_140567aa0  @140567aa0  [medium:callgraph-r2]  (orig: FUN_140567aa0)
void FUN_140567aa0(longlong param_1,longlong param_2,undefined8 param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != 0) {
      FUN_140563d60(param_1,param_3);
    }
    param_1 = param_1 + 0x30;
  }
  return;
}

// ==== CMapData::helper_140567cc0  @140567cc0  [medium:callgraph-r2]  (orig: FUN_140567cc0)
longlong * FUN_140567cc0(longlong *param_1,longlong *param_2,longlong *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  void *pvVar4;
  void *pvVar5;
  longlong *local_d8 [3];
  void *local_c0;
  void *local_b8;
  undefined8 local_b0;
  longlong *local_a8;
  longlong *local_a0;
  longlong *local_98;
  longlong *local_90;
  longlong *local_88;
  longlong *local_80;
  undefined8 local_78;
  longlong local_70;
  undefined8 local_68;
  longlong *local_60;
  undefined8 *local_58;
  longlong *local_50;
  longlong local_48;
  longlong local_40;
  longlong *local_38;
  undefined8 *local_30;
  
  local_68 = 0xfffffffffffffffe;
  local_98 = param_3;
  local_a8 = operator_new(8);
  if (local_a8 == (longlong *)0x0) {
    local_d8[0] = (longlong *)0x0;
  }
  else {
    *local_a8 = (longlong)local_d8;
    local_d8[0] = local_a8;
  }
  local_c0 = (void *)0x0;
  local_b8 = (void *)0x0;
  local_b0 = 0;
  local_a0 = local_a8;
  for (; pvVar5 = local_b8, param_1 != param_2; param_1 = param_1 + 6) {
    local_a8 = param_3;
    local_a0 = param_3;
    if (param_3 != (longlong *)0x0) {
      FUN_140563d60(param_3,local_d8);
    }
    if (param_3 != param_1) {
      local_30 = (undefined8 *)*param_3;
      *param_3 = *param_1;
      *param_1 = (longlong)local_30;
      local_58 = (undefined8 *)*param_3;
      if (local_58 != local_30) {
        local_78 = *local_58;
        *local_58 = *local_30;
        *local_30 = local_78;
      }
      local_38 = param_1 + 3;
      local_90 = param_3 + 3;
      if (local_90 != local_38) {
        local_48 = *local_90;
        *local_90 = *local_38;
        *local_38 = local_48;
      }
      local_88 = param_1 + 4;
      local_80 = param_3 + 4;
      if (local_80 != local_88) {
        local_70 = *local_80;
        *local_80 = *local_88;
        *local_88 = local_70;
      }
      local_60 = param_1 + 5;
      local_50 = param_3 + 5;
      if (local_50 != local_60) {
        local_40 = *local_50;
        *local_50 = *local_60;
        *local_60 = local_40;
      }
    }
    param_3 = param_3 + 6;
  }
  pvVar4 = local_c0;
  if (local_c0 != (void *)0x0) {
    for (; pvVar4 != pvVar5; pvVar4 = (void *)((longlong)pvVar4 + 0x10)) {
      plVar3 = *(longlong **)((longlong)pvVar4 + 8);
      if (plVar3 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar3 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*plVar3)(plVar3);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar3 + 8))(plVar3);
          }
        }
      }
    }
    operator_delete(local_c0);
  }
  local_c0 = (void *)0x0;
  local_b8 = (void *)0x0;
  local_b0 = 0;
  operator_delete(local_d8[0]);
  return param_3;
}

// ==== CMapData::helper_140567ed0  @140567ed0  [medium:callgraph-r3]  (orig: FUN_140567ed0)
longlong * FUN_140567ed0(longlong *param_1,longlong *param_2,longlong *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  
  if (param_1 != param_2) {
    plVar7 = param_3 + 4;
    plVar9 = param_2 + 4;
    do {
      param_2 = param_2 + -6;
      plVar10 = plVar9 + -6;
      param_3 = param_3 + -6;
      plVar8 = plVar7 + -6;
      if (param_3 != param_2) {
        puVar3 = (undefined8 *)*param_3;
        *param_3 = *param_2;
        *param_2 = (longlong)puVar3;
        puVar4 = (undefined8 *)*param_3;
        if (puVar4 != puVar3) {
          uVar5 = *puVar4;
          *puVar4 = *puVar3;
          *puVar3 = uVar5;
        }
        plVar1 = plVar9 + -7;
        plVar2 = plVar7 + -7;
        if (plVar2 != plVar1) {
          lVar6 = *plVar2;
          *plVar2 = *plVar1;
          *plVar1 = lVar6;
        }
        if (plVar8 != plVar10) {
          lVar6 = *plVar8;
          *plVar8 = *plVar10;
          *plVar10 = lVar6;
        }
        plVar9 = plVar9 + -5;
        plVar7 = plVar7 + -5;
        if (plVar7 != plVar9) {
          lVar6 = *plVar7;
          *plVar7 = *plVar9;
          *plVar9 = lVar6;
        }
      }
      plVar7 = plVar8;
      plVar9 = plVar10;
    } while (param_2 != param_1);
  }
  return param_3;
}

// ==== CMapData::helper_140567f90  @140567f90  [medium:callgraph-r0]  (orig: FUN_140567f90)
void FUN_140567f90(undefined8 *param_1,ulonglong param_2,undefined1 param_3)

{
  ulonglong uVar1;
  undefined8 local_68;
  ulonglong local_60;
  undefined8 local_58;
  undefined8 local_48;
  ulonglong local_40;
  undefined8 local_38;
  undefined8 local_28;
  ulonglong local_20;
  undefined8 local_18;
  
  if ((ulonglong)param_1[2] < param_2) {
    uVar1 = param_1[6];
    if ((ulonglong)param_1[7] < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_68 = *param_1;
    local_58 = 0;
    local_60 = uVar1;
    if (param_1[2] != 0) {
      FUN_140562ba0(&local_68);
    }
    local_28 = local_68;
    local_20 = local_60;
    local_18 = local_58;
    FUN_140567b20(param_1,&local_28,param_2 - param_1[2],param_3);
  }
  else if (param_2 < (ulonglong)param_1[2]) {
    uVar1 = param_1[6];
    if ((ulonglong)param_1[7] < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_68 = *param_1;
    local_58 = 0;
    local_60 = uVar1;
    if (param_1[2] != 0) {
      FUN_140562ba0(&local_68);
    }
    uVar1 = param_1[6];
    if ((ulonglong)param_1[7] < uVar1) {
      _invalid_parameter_noinfo();
    }
    local_48 = *param_1;
    local_38 = 0;
    local_18 = 0;
    local_40 = uVar1;
    local_28 = local_48;
    local_20 = uVar1;
    FUN_140562ba0(&local_28,param_2);
    local_48 = local_68;
    local_40 = local_60;
    local_38 = local_58;
    local_68 = local_28;
    local_60 = local_20;
    local_58 = local_18;
    FUN_1405673f0(param_1,&local_28,&local_68,&local_48);
  }
  return;
}

// ==== CMapData::helper_1405683c0  @1405683c0  [medium:callgraph-r2]  (orig: FUN_1405683c0)
longlong FUN_1405683c0(longlong param_1,longlong param_2,longlong param_3)

{
  FUN_140567ed0();
  return param_3 + ((param_2 - param_1) / 0x30) * -0x30;
}

// ==== CMapData::helper_140568490  @140568490  [medium:callgraph-r1]  (orig: FUN_140568490)
void FUN_140568490(ulonglong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  int *piVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong *plVar4;
  longlong *plVar5;
  void *pvVar6;
  void *pvVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong lVar13;
  longlong *plVar14;
  undefined1 local_res8;
  void *local_a0 [3];
  void *local_88;
  void *local_80;
  undefined8 local_78;
  void *local_70 [3];
  longlong *local_58;
  longlong *local_50;
  undefined8 local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  lVar10 = *(longlong *)(param_1 + 0x18);
  if (lVar10 == 0) {
    uVar11 = 0;
  }
  else {
    lVar13 = *(longlong *)(param_1 + 0x28) - lVar10;
    lVar13 = lVar13 / 6 + (lVar13 >> 0x3f);
    uVar11 = (lVar13 >> 3) - (lVar13 >> 0x3f);
  }
  uVar12 = 0;
  if (param_3 != 0) {
    lVar10 = (*(longlong *)(param_1 + 0x20) - lVar10) / 0x30;
    if (0x555555555555555U - lVar10 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14055e4f0();
    }
    uVar3 = lVar10 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar11 < uVar3) {
      if (uVar11 <= 0x555555555555555 - (uVar11 >> 1)) {
        uVar12 = uVar11 + (uVar11 >> 1);
      }
      if (uVar12 < uVar3) {
        uVar12 = uVar3;
      }
      lVar8 = FUN_14055f380(param_1 + 0x10,uVar12);
      lVar10 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar10 = lVar10 / 6 + (lVar10 >> 0x3f);
      lVar10 = (lVar10 >> 3) - (lVar10 >> 0x3f);
      FUN_140567aa0(lVar10 * 0x30 + lVar8,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140567cc0(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar8,
                    param_1 + 0x10,local_res8,0);
      FUN_140567cc0(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar10 + param_3) * 0x30 + lVar8,param_1 + 0x10,local_res8,0);
      lVar10 = *(longlong *)(param_1 + 0x18);
      lVar13 = *(longlong *)(param_1 + 0x20);
      if (lVar10 != 0) {
        FUN_1405679d0(lVar10,*(undefined8 *)(param_1 + 0x20),param_1 + 0x10,param_1 & 0xff);
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar12 * 0x30 + lVar8;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar13 - lVar10) / 0x30) * 0x30 + lVar8;
      *(longlong *)(param_1 + 0x18) = lVar8;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x30) <
             param_3) {
      FUN_140563d60(local_a0,param_4);
      FUN_140567cc0(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x30,param_1 + 0x10,local_res8,0);
      lVar10 = *(longlong *)(param_1 + 0x20);
      lVar13 = param_3 - (lVar10 - *(longlong *)(param_2 + 8)) / 0x30;
      FUN_140567aa0(lVar10,lVar13,local_a0,param_1 + 0x10,local_res8,0,0,lVar10,lVar13);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x30;
      lVar10 = *(longlong *)(param_1 + 0x20);
      pvVar6 = local_80;
      for (lVar13 = *(longlong *)(param_2 + 8); lVar13 != lVar10 + param_3 * -0x30;
          lVar13 = lVar13 + 0x30) {
        local_80 = pvVar6;
        FUN_140566c60(lVar13,local_a0);
        pvVar6 = local_80;
      }
      pvVar7 = local_88;
      if (local_88 != (void *)0x0) {
        for (; pvVar7 != pvVar6; pvVar7 = (void *)((longlong)pvVar7 + 0x10)) {
          plVar4 = *(longlong **)((longlong)pvVar7 + 8);
          if (plVar4 != (longlong *)0x0) {
            LOCK();
            plVar14 = plVar4 + 2;
            *(int *)plVar14 = (int)*plVar14 + -1;
            UNLOCK();
            if ((int)*plVar14 == 0) {
              (**(code **)*plVar4)(plVar4);
              LOCK();
              piVar1 = (int *)((longlong)plVar4 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*plVar4 + 8))(plVar4);
              }
            }
          }
        }
        operator_delete(local_88);
      }
      local_88 = (void *)0x0;
      local_80 = (void *)0x0;
      local_78 = 0;
      operator_delete(local_a0[0]);
    }
    else {
      FUN_140563d60(local_70,param_4);
      lVar10 = *(longlong *)(param_1 + 0x20);
      lVar13 = lVar10 + param_3 * -0x30;
      uVar9 = FUN_140567cc0(lVar13,lVar10,lVar10,param_1 + 0x10,0,0);
      *(undefined8 *)(param_1 + 0x20) = uVar9;
      FUN_1405683c0(*(undefined8 *)(param_2 + 8),lVar13,lVar10);
      lVar13 = *(longlong *)(param_2 + 8);
      lVar10 = lVar13 + param_3 * 0x30;
      plVar4 = local_50;
      for (; lVar13 != lVar10; lVar13 = lVar13 + 0x30) {
        local_50 = plVar4;
        FUN_140566c60(lVar13,local_70);
        plVar4 = local_50;
      }
      if (local_58 != (longlong *)0x0) {
        if (local_58 != plVar4) {
          plVar14 = local_58 + 1;
          do {
            plVar5 = (longlong *)*plVar14;
            if (plVar5 != (longlong *)0x0) {
              LOCK();
              plVar2 = plVar5 + 2;
              *(int *)plVar2 = (int)*plVar2 + -1;
              UNLOCK();
              if ((int)*plVar2 == 0) {
                (**(code **)*plVar5)(plVar5);
                LOCK();
                piVar1 = (int *)((longlong)plVar5 + 0x14);
                *piVar1 = *piVar1 + -1;
                UNLOCK();
                if (*piVar1 == 0) {
                  (**(code **)(*plVar5 + 8))(plVar5);
                }
              }
            }
            plVar5 = plVar14 + 1;
            plVar14 = plVar14 + 2;
          } while (plVar5 != plVar4);
        }
        operator_delete(local_58);
      }
      local_58 = (longlong *)0x0;
      local_50 = (longlong *)0x0;
      local_48 = 0;
      operator_delete(local_70[0]);
    }
  }
  return;
}

// ==== CMapData::ctor_or_dtor  @140568960  [high:vtable-assign]  (orig: FUN_140568960)
undefined8 *
FUN_140568960(undefined8 *param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 uVar9;
  
  uVar9 = 0xfffffffffffffffe;
  *param_1 = IMapData::vftable;
  *param_1 = CMapData::vftable;
  puVar1 = param_1 + 6;
  plVar5 = operator_new(8);
  plVar8 = (longlong *)0x0;
  plVar7 = plVar8;
  if (plVar5 != (longlong *)0x0) {
    *plVar5 = (longlong)puVar1;
    plVar7 = plVar5;
  }
  *puVar1 = plVar7;
  uVar6 = FUN_14055fff0(puVar1);
  param_1[0xb] = uVar6;
  param_1[0xc] = 0;
  puVar1 = param_1 + 0xd;
  plVar5 = operator_new(8);
  plVar7 = plVar8;
  if (plVar5 != (longlong *)0x0) {
    *plVar5 = (longlong)puVar1;
    plVar7 = plVar5;
  }
  *puVar1 = plVar7;
  uVar6 = FUN_14055fff0(puVar1);
  param_1[0x12] = uVar6;
  param_1[0x13] = 0;
  plVar5 = operator_new(8);
  plVar7 = plVar8;
  if (plVar5 != (longlong *)0x0) {
    *plVar5 = (longlong)(param_1 + 0x14);
    plVar7 = plVar5;
  }
  param_1[0x14] = plVar7;
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  plVar5 = operator_new(8);
  plVar7 = plVar8;
  if (plVar5 != (longlong *)0x0) {
    *plVar5 = (longlong)(param_1 + 0x1a);
    plVar7 = plVar5;
  }
  param_1[0x1a] = plVar7;
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  param_1[0x20] = 0;
  param_1[0x21] = 0;
  FUN_14055f840(param_1 + 0x20,*param_2,param_2[1],param_4,uVar9,plVar5);
  FUN_1405625c0(param_1 + 0x22);
  puVar1 = param_1 + 0x2b;
  plVar7 = operator_new(8);
  if (plVar7 != (longlong *)0x0) {
    *plVar7 = (longlong)puVar1;
    plVar8 = plVar7;
  }
  *puVar1 = plVar8;
  uVar6 = FUN_140560070(puVar1);
  param_1[0x30] = uVar6;
  param_1[0x31] = 0;
  FUN_1400b8550(param_1 + 0x32);
  *(undefined4 *)(param_1 + 1) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  uVar6 = param_1[0x20];
  iVar3 = FUN_14056aaf0(uVar6);
  iVar4 = FUN_14056ab00(uVar6);
  FUN_140567f90(param_1 + 0x22,(longlong)(iVar3 * iVar4),0,param_4,uVar9,plVar7);
  plVar8 = (longlong *)param_2[1];
  if (plVar8 != (longlong *)0x0) {
    LOCK();
    plVar7 = plVar8 + 2;
    *(int *)plVar7 = (int)*plVar7 + -1;
    UNLOCK();
    if ((int)*plVar7 == 0) {
      (**(code **)*plVar8)(plVar8);
      LOCK();
      piVar2 = (int *)((longlong)plVar8 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar8 + 8))(plVar8);
      }
    }
  }
  return param_1;
}

// ==== CMapData::helper_140568bd0  @140568bd0  [medium:callgraph-r0]  (orig: FUN_140568bd0)
void FUN_140568bd0(undefined8 *param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  FUN_1400a9720(param_1 + 0x32);
  operator_delete((void *)param_1[0x32]);
  FUN_1405629f0(param_1 + 0x2b);
  operator_delete((void *)param_1[0x30]);
  param_1[0x30] = 0;
  operator_delete((void *)param_1[0x2b]);
  FUN_140562650(param_1 + 0x22);
  plVar3 = (longlong *)param_1[0x21];
  if (plVar3 != (longlong *)0x0) {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
    }
  }
  if ((void *)param_1[0x1d] != (void *)0x0) {
    operator_delete((void *)param_1[0x1d]);
  }
  param_1[0x1d] = 0;
  param_1[0x1e] = 0;
  param_1[0x1f] = 0;
  operator_delete((void *)param_1[0x1a]);
  if (param_1[0x17] != 0) {
    FUN_1405679d0(param_1[0x17],param_1[0x18],param_1 + 0x16,(ulonglong)param_1 & 0xff);
    operator_delete((void *)param_1[0x17]);
  }
  param_1[0x17] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  operator_delete((void *)param_1[0x14]);
  FUN_140563220(param_1 + 0xd);
  operator_delete((void *)param_1[0x12]);
  param_1[0x12] = 0;
  operator_delete((void *)param_1[0xd]);
  FUN_140563220(param_1 + 6);
  operator_delete((void *)param_1[0xb]);
  param_1[0xb] = 0;
  operator_delete((void *)param_1[6]);
  *param_1 = IMapData::vftable;
  return;
}

// ==== CMapData::helper_140568e70  @140568e70  [medium:callgraph-r0]  (orig: FUN_140568e70)
void FUN_140568e70(longlong *param_1,ulonglong param_2,undefined8 *param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined1 local_res18;
  longlong local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x30;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    uStack_20 = uVar1;
    FUN_140568490(param_1,&local_28,param_2 - (param_1[4] - param_1[3]) / 0x30,param_3);
    goto LAB_140569015;
  }
  if (uVar3 <= param_2) goto LAB_140569015;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = 0;
  }
  else {
    lVar4 = *plVar2;
  }
  uVar5 = uVar5 + param_2 * 0x30;
  if (*(ulonglong *)(lVar4 + 0x20) < uVar5) {
LAB_140568f89:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar4 + 0x18)) goto LAB_140568f89;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    local_res18 = SUB81(param_3,0);
    lVar4 = FUN_1405672c0(uVar1,param_1[4],uVar5,(ulonglong)param_3 & 0xff,local_res18,0);
    FUN_1405679d0(lVar4,param_1[4],param_1 + 2,(ulonglong)param_3 & 0xff);
    param_1[4] = lVar4;
  }
LAB_140569015:
  if (param_3[3] != 0) {
    FUN_140563af0(param_3,param_3[3],param_3[4]);
    operator_delete((void *)param_3[3]);
  }
  param_3[3] = 0;
  param_3[4] = 0;
  param_3[5] = 0;
  operator_delete((void *)*param_3);
  return;
}

// ==== CMapData::vfunc_0  @140569070  [high:rtti-vtable]  (orig: FUN_140569070)
void * FUN_140569070(void *param_1,uint param_2)

{
  FUN_140568bd0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMapData::vfunc_9  @140569130  [high:rtti-vtable]  (orig: FUN_140569130)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140569130(longlong *param_1,uint param_2,undefined4 param_3,undefined4 param_4,uint param_5)

{
  longlong *plVar1;
  longlong *plVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  char cVar6;
  undefined2 uVar7;
  int iVar8;
  int iVar9;
  CIniMgr *this;
  char *pcVar10;
  undefined8 uVar11;
  undefined8 *puVar12;
  int *piVar13;
  longlong *plVar14;
  longlong lVar15;
  undefined8 *puVar16;
  ulonglong uVar17;
  int iVar18;
  ulonglong uVar19;
  longlong lVar20;
  int iVar21;
  undefined8 *puVar22;
  longlong *plVar23;
  int iVar24;
  undefined1 auStack_418 [32];
  longlong local_3d0;
  int local_3c0;
  int local_3b8;
  int local_3b4;
  undefined1 local_3b0;
  undefined1 local_3af;
  longlong *local_3a8;
  int local_3a0;
  longlong local_398;
  longlong *local_390;
  longlong *local_388;
  int local_380;
  longlong *local_378;
  longlong *local_370;
  undefined8 local_368;
  longlong *local_360;
  undefined8 local_358;
  longlong *local_350;
  undefined8 local_348;
  undefined8 local_338;
  undefined8 uStack_330;
  undefined8 local_328;
  longlong local_320;
  longlong local_318;
  longlong local_310;
  undefined8 *local_308;
  longlong local_300;
  undefined8 *local_2f8;
  undefined8 local_2e8;
  undefined8 uStack_2e0;
  undefined8 local_2d8;
  undefined8 uStack_2d0;
  longlong *local_2c8 [3];
  undefined8 local_2b0;
  undefined8 local_2a8;
  undefined8 local_2a0;
  undefined8 local_298;
  undefined4 local_288;
  undefined4 uStack_284;
  undefined4 uStack_280;
  undefined4 uStack_27c;
  undefined4 local_278;
  undefined4 uStack_274;
  undefined4 uStack_270;
  undefined4 uStack_26c;
  undefined4 local_268;
  undefined4 uStack_264;
  undefined4 uStack_260;
  undefined4 uStack_25c;
  char local_258 [255];
  undefined1 local_159;
  char local_158 [255];
  undefined1 local_59;
  ulonglong local_58;
  
  local_298 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_418;
  _snprintf(local_158,0x100,"NpcType%lu",(ulonglong)(param_5 / 10));
  local_59 = 0;
  _snprintf(local_258,0x100,"Dir%lu",(ulonglong)(param_5 % 10));
  local_159 = 0;
  this = tq::GetInstance();
  pcVar10 = tq::CIniMgr::GetString(this,"ini\\TerrainNpc.ini",local_158,local_258,false);
  if (pcVar10 == (char *)0x0) {
    log_InlineLogERROR("CMapData cannot find item %d, key %s, field %s",(ulonglong)param_5,local_158
                       ,local_258);
    uVar11 = 0;
  }
  else {
    FUN_1405733c0(&local_378,pcVar10,param_2);
    if (local_378 == (longlong *)0x0) {
      log_InlineLogERROR("CMapData cannot create item from file %s for owner %u",pcVar10,
                         (ulonglong)param_2);
      if (local_370 != (longlong *)0x0) {
        LOCK();
        plVar14 = local_370 + 2;
        lVar20 = *plVar14;
        *(int *)plVar14 = (int)*plVar14 + -1;
        UNLOCK();
        if ((int)lVar20 == 1) {
          (**(code **)*local_370)(local_370);
          LOCK();
          piVar13 = (int *)((longlong)local_370 + 0x14);
          *piVar13 = *piVar13 + -1;
          UNLOCK();
          if (*piVar13 == 0) {
            (**(code **)(*local_370 + 8))(local_370);
          }
        }
      }
      uVar11 = 0;
    }
    else {
      (**(code **)(*local_378 + 8))(local_378,param_3,param_4);
      local_380 = FUN_140571a80(local_378);
      local_3a0 = 0;
      if (0 < local_380) {
        do {
          iVar18 = local_3a0;
          FUN_140572280(local_378,&local_368,local_3a0);
          puVar12 = (undefined8 *)FUN_140570bd0(local_368);
          uVar11 = *puVar12;
          local_328 = uVar11;
          puVar12 = (undefined8 *)FUN_140570bf0();
          local_348 = *puVar12;
          local_3b8 = 0;
          iVar21 = (int)local_348;
          if (0 < iVar21) {
            do {
              local_3c0 = 0;
              if (0 < local_348._4_4_) {
                iVar18 = (int)uVar11 - local_3b8;
                do {
                  iVar24 = local_328._4_4_ - local_3c0;
                  cVar6 = FUN_14056ab10(param_1[0x20],iVar18,iVar24);
                  if (cVar6 != '\0') {
                    FUN_140570f90(local_368,&local_358,local_3b8,local_3c0);
                    FUN_140570b20(&local_398);
                    uVar5 = local_358;
                    local_3a8 = (longlong *)local_398;
                    if (local_398 == 0) {
                      log_InlineLogERROR("CMapData cannot create layer data");
                      if (local_390 != (longlong *)0x0) {
                        LOCK();
                        plVar14 = local_390 + 2;
                        lVar20 = *plVar14;
                        *(int *)plVar14 = (int)*plVar14 + -1;
                        UNLOCK();
                        if ((int)lVar20 == 1) {
                          (**(code **)*local_390)(local_390);
                          LOCK();
                          piVar13 = (int *)((longlong)local_390 + 0x14);
                          iVar18 = *piVar13;
                          *piVar13 = *piVar13 + -1;
                          UNLOCK();
                          if (iVar18 == 1) {
                            (**(code **)(*local_390 + 8))(local_390);
                          }
                        }
                      }
                      if (local_350 != (longlong *)0x0) {
                        LOCK();
                        plVar14 = local_350 + 2;
                        lVar20 = *plVar14;
                        *(int *)plVar14 = (int)*plVar14 + -1;
                        UNLOCK();
                        if ((int)lVar20 == 1) {
                          (**(code **)*local_350)(local_350);
                          LOCK();
                          piVar13 = (int *)((longlong)local_350 + 0x14);
                          iVar18 = *piVar13;
                          *piVar13 = *piVar13 + -1;
                          UNLOCK();
                          if (iVar18 == 1) {
                            (**(code **)(*local_350 + 8))(local_350);
                          }
                        }
                      }
                      if (local_360 != (longlong *)0x0) {
                        LOCK();
                        plVar14 = local_360 + 2;
                        lVar20 = *plVar14;
                        *(int *)plVar14 = (int)*plVar14 + -1;
                        UNLOCK();
                        if ((int)lVar20 == 1) {
                          (**(code **)*local_360)(local_360);
                          LOCK();
                          piVar13 = (int *)((longlong)local_360 + 0x14);
                          iVar18 = *piVar13;
                          *piVar13 = *piVar13 + -1;
                          UNLOCK();
                          if (iVar18 == 1) {
                            (**(code **)(*local_360 + 8))(local_360);
                          }
                        }
                      }
                      if (local_370 != (longlong *)0x0) {
                        LOCK();
                        plVar14 = local_370 + 2;
                        lVar20 = *plVar14;
                        *(int *)plVar14 = (int)*plVar14 + -1;
                        UNLOCK();
                        if ((int)lVar20 == 1) {
                          (**(code **)*local_370)(local_370);
                          LOCK();
                          piVar13 = (int *)((longlong)local_370 + 0x14);
                          iVar18 = *piVar13;
                          *piVar13 = *piVar13 + -1;
                          UNLOCK();
                          if (iVar18 == 1) {
                            (**(code **)(*local_370 + 8))(local_370);
                          }
                        }
                      }
                      return 0;
                    }
                    iVar8 = (**(code **)(*param_1 + 8))(param_1,iVar18,iVar24);
                    iVar9 = FUN_140570940(uVar5);
                    FUN_140570970(local_3a8,iVar9 + iVar8);
                    lVar20 = local_398;
                    uVar7 = FUN_140570950(local_358);
                    FUN_140570980(lVar20,uVar7);
                    lVar20 = local_398;
                    uVar7 = FUN_140570960(local_358);
                    FUN_140570990(lVar20,uVar7);
                    iVar24 = FUN_14056ab30(param_1[0x20],iVar18,iVar24);
                    local_3a8 = param_1 + 0x32;
                    puVar12 = (undefined8 *)param_1[0x38];
                    lVar20 = *local_3a8;
                    cVar6 = *(char *)((longlong)puVar12[1] + 0x21);
                    puVar4 = puVar12;
                    puVar22 = (undefined8 *)puVar12[1];
                    while (cVar6 == '\0') {
                      if (*(int *)(puVar22 + 3) < iVar24) {
                        puVar16 = (undefined8 *)puVar22[2];
                        puVar22 = puVar4;
                      }
                      else {
                        puVar16 = (undefined8 *)*puVar22;
                      }
                      puVar4 = puVar22;
                      puVar22 = puVar16;
                      cVar6 = *(char *)((longlong)puVar16 + 0x21);
                    }
                    local_2f8 = puVar4;
                    local_300 = lVar20;
                    local_3b4 = iVar24;
                    if (lVar20 == 0) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar4 == puVar12) || (iVar24 < *(int *)(puVar4 + 3))) {
                      local_318 = local_3a8[6];
                      local_320 = *local_3a8;
                      plVar14 = &local_320;
                    }
                    else {
                      plVar14 = &local_300;
                    }
                    local_310 = *plVar14;
                    local_308 = (undefined8 *)plVar14[1];
                    if ((local_310 == 0) || (local_310 != lVar20)) {
                      _invalid_parameter_noinfo();
                    }
                    if (local_308 == puVar12) {
                      plVar23 = param_1 + 0x14;
                      plVar14 = (longlong *)param_1[0x17];
                      if ((longlong *)param_1[0x18] < plVar14) {
                        _invalid_parameter_noinfo();
                      }
                      plVar1 = (longlong *)*plVar23;
                      while( true ) {
                        plVar2 = (longlong *)param_1[0x18];
                        if (plVar2 < (longlong *)param_1[0x17]) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar23)) {
                          _invalid_parameter_noinfo();
                        }
                        if (plVar14 == plVar2) goto LAB_1405697ec;
                        if (plVar1 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar20 = 0;
                        }
                        else {
                          lVar20 = *plVar1;
                        }
                        if (*(longlong **)(lVar20 + 0x20) <= plVar14) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar14[4] - plVar14[3] & 0xfffffffffffffff0U) == 0) break;
                        if (plVar1 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar20 = 0;
                        }
                        else {
                          lVar20 = *plVar1;
                        }
                        if (*(longlong **)(lVar20 + 0x20) <= plVar14) {
                          _invalid_parameter_noinfo();
                        }
                        plVar14 = plVar14 + 6;
                      }
                      if (plVar1 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar20 = 0;
                      }
                      else {
                        lVar20 = *plVar1;
                      }
                      if (*(longlong **)(lVar20 + 0x20) <= plVar14) {
                        _invalid_parameter_noinfo();
                      }
                      uVar19 = plVar14[3];
                      if (uVar19 == 0) {
                        uVar17 = 0;
                      }
                      else {
                        uVar17 = (longlong)(plVar14[5] - uVar19) >> 4;
                      }
                      uVar3 = plVar14[4];
                      if ((ulonglong)((longlong)(uVar3 - uVar19) >> 4) < uVar17) {
                        FUN_140562d30(uVar3,1,&local_398,plVar14 + 2);
                        plVar14[4] = uVar3 + 0x10;
                      }
                      else {
                        if (uVar3 < uVar19) {
                          _invalid_parameter_noinfo();
                        }
                        local_338 = *plVar14;
                        uVar19 = plVar14[3];
                        uStack_330 = uVar3;
                        if ((plVar14[4] - uVar19 & 0xfffffffffffffff0) == 0) {
                          local_3d0 = 0;
                        }
                        else {
                          if ((ulonglong)plVar14[4] < uVar19) {
                            _invalid_parameter_noinfo();
                          }
                          if ((local_338 == 0) || (local_338 != *plVar14)) {
                            _invalid_parameter_noinfo();
                          }
                          local_3d0 = (longlong)(uVar3 - uVar19) >> 4;
                        }
                        local_288 = (undefined4)local_338;
                        uStack_284 = local_338._4_4_;
                        uStack_280 = (undefined4)uStack_330;
                        uStack_27c = uStack_330._4_4_;
                        FUN_140564460(plVar14,&local_288,1,&local_398);
                        local_388 = (longlong *)plVar14[3];
                        if ((ulonglong)plVar14[4] < local_388) {
                          _invalid_parameter_noinfo();
                        }
                        plVar2 = (longlong *)*plVar14;
                        if (plVar2 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar20 = 0;
                        }
                        else {
                          lVar20 = *plVar2;
                        }
                        uVar19 = (longlong)local_388 + local_3d0 * 0x10;
                        if (uVar19 <= *(ulonglong *)(lVar20 + 0x20)) {
                          if (plVar2 == (longlong *)0x0) {
                            lVar20 = 0;
                          }
                          else {
                            lVar20 = *plVar2;
                          }
                          if (*(ulonglong *)(lVar20 + 0x18) <= uVar19) goto LAB_140569783;
                        }
                        _invalid_parameter_noinfo();
                      }
LAB_140569783:
                      local_388 = (longlong *)param_1[0x17];
                      if ((longlong *)param_1[0x18] < local_388) {
                        _invalid_parameter_noinfo();
                      }
                      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar23)) {
                        _invalid_parameter_noinfo();
                      }
                      lVar20 = ((longlong)plVar14 - (longlong)local_388) / 6 +
                               ((longlong)plVar14 - (longlong)local_388 >> 0x3f);
                      piVar13 = (int *)FUN_14033a2d0(local_3a8,&local_3b4);
                      *piVar13 = (int)(lVar20 >> 3) - (int)(lVar20 >> 0x3f);
LAB_1405697ec:
                      plVar2 = (longlong *)param_1[0x18];
                      if (plVar2 < (longlong *)param_1[0x17]) {
                        _invalid_parameter_noinfo();
                      }
                      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar23)) {
                        _invalid_parameter_noinfo();
                      }
                      if (plVar14 == plVar2) {
                        lVar20 = (param_1[0x18] - param_1[0x17]) / 6 +
                                 (param_1[0x18] - param_1[0x17] >> 0x3f);
                        iVar24 = (int)(lVar20 >> 3) - (int)(lVar20 >> 0x3f);
                        piVar13 = (int *)FUN_14033a2d0(local_3a8,&local_3b4);
                        *piVar13 = iVar24;
                        local_388 = operator_new(8);
                        if (local_388 == (longlong *)0x0) {
                          local_2c8[0] = (longlong *)0x0;
                        }
                        else {
                          *local_388 = (longlong)local_2c8;
                          local_2c8[0] = local_388;
                        }
                        uVar17 = 0;
                        local_2b0 = 0;
                        local_2a8 = 0;
                        local_2a0 = 0;
                        FUN_140568e70(plVar23,(longlong)(iVar24 + 1),local_2c8);
                        plVar14 = (longlong *)FUN_140561780(plVar23);
                        uVar19 = plVar14[3];
                        if (uVar19 != 0) {
                          uVar17 = (longlong)(plVar14[5] - uVar19) >> 4;
                        }
                        uVar3 = plVar14[4];
                        if ((ulonglong)((longlong)(uVar3 - uVar19) >> 4) < uVar17) {
                          local_3af = 0;
                          FUN_140562d30(uVar3,1,&local_398,plVar14 + 2);
                          plVar14[4] = uVar3 + 0x10;
                        }
                        else {
                          if (uVar3 < uVar19) {
                            _invalid_parameter_noinfo();
                          }
                          lVar20 = *plVar14;
                          uVar19 = plVar14[3];
                          local_2e8 = lVar20;
                          uStack_2e0 = uVar3;
                          if ((plVar14[4] - uVar19 & 0xfffffffffffffff0) == 0) {
                            lVar20 = 0;
                          }
                          else {
                            if ((ulonglong)plVar14[4] < uVar19) {
                              _invalid_parameter_noinfo();
                            }
                            if ((lVar20 == 0) || (lVar20 != *plVar14)) {
                              _invalid_parameter_noinfo();
                            }
                            lVar20 = (longlong)(uVar3 - uVar19) >> 4;
                          }
                          local_278 = (undefined4)local_2e8;
                          uStack_274 = local_2e8._4_4_;
                          uStack_270 = (undefined4)uStack_2e0;
                          uStack_26c = uStack_2e0._4_4_;
                          FUN_140564460(plVar14,&local_278,1,&local_398);
                          uVar19 = plVar14[3];
                          if ((ulonglong)plVar14[4] < uVar19) {
                            _invalid_parameter_noinfo();
                          }
                          plVar14 = (longlong *)*plVar14;
                          if (plVar14 == (longlong *)0x0) {
                            _invalid_parameter_noinfo();
                            lVar15 = 0;
                          }
                          else {
                            lVar15 = *plVar14;
                          }
                          uVar19 = uVar19 + lVar20 * 0x10;
                          if (uVar19 <= *(ulonglong *)(lVar15 + 0x20)) {
                            if (plVar14 == (longlong *)0x0) {
                              lVar20 = 0;
                            }
                            else {
                              lVar20 = *plVar14;
                            }
                            if (*(ulonglong *)(lVar20 + 0x18) <= uVar19) goto LAB_140569bb4;
                          }
                          _invalid_parameter_noinfo();
                        }
                      }
                    }
                    else {
                      piVar13 = (int *)FUN_14033a2d0(local_3a8,&local_3b4);
                      iVar24 = *piVar13;
                      if ((ulonglong)((param_1[0x18] - param_1[0x17]) / 0x30) <=
                          (ulonglong)(longlong)iVar24) {
                        _invalid_parameter_noinfo();
                      }
                      plVar14 = (longlong *)((longlong)iVar24 * 0x30 + param_1[0x17]);
                      uVar19 = plVar14[3];
                      if (uVar19 == 0) {
                        uVar17 = 0;
                      }
                      else {
                        uVar17 = (longlong)(plVar14[5] - uVar19) >> 4;
                      }
                      uVar3 = plVar14[4];
                      if ((ulonglong)((longlong)(uVar3 - uVar19) >> 4) < uVar17) {
                        local_3b0 = 0;
                        FUN_140562d30(uVar3,1,&local_398,plVar14 + 2);
                        plVar14[4] = uVar3 + 0x10;
                      }
                      else {
                        if (uVar3 < uVar19) {
                          _invalid_parameter_noinfo();
                        }
                        lVar20 = *plVar14;
                        uVar19 = plVar14[3];
                        local_2d8 = lVar20;
                        uStack_2d0 = uVar3;
                        if ((plVar14[4] - uVar19 & 0xfffffffffffffff0) == 0) {
                          lVar20 = 0;
                        }
                        else {
                          if ((ulonglong)plVar14[4] < uVar19) {
                            _invalid_parameter_noinfo();
                          }
                          if ((lVar20 == 0) || (lVar20 != *plVar14)) {
                            _invalid_parameter_noinfo();
                          }
                          lVar20 = (longlong)(uVar3 - uVar19) >> 4;
                        }
                        local_268 = (undefined4)local_2d8;
                        uStack_264 = local_2d8._4_4_;
                        uStack_260 = (undefined4)uStack_2d0;
                        uStack_25c = uStack_2d0._4_4_;
                        FUN_140564460(plVar14,&local_268,1,&local_398);
                        uVar19 = plVar14[3];
                        if ((ulonglong)plVar14[4] < uVar19) {
                          _invalid_parameter_noinfo();
                        }
                        plVar14 = (longlong *)*plVar14;
                        if (plVar14 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar15 = 0;
                        }
                        else {
                          lVar15 = *plVar14;
                        }
                        uVar19 = uVar19 + lVar20 * 0x10;
                        if (uVar19 <= *(ulonglong *)(lVar15 + 0x20)) {
                          if (plVar14 == (longlong *)0x0) {
                            lVar20 = 0;
                          }
                          else {
                            lVar20 = *plVar14;
                          }
                          if (*(ulonglong *)(lVar20 + 0x18) <= uVar19) goto LAB_140569bb4;
                        }
                        _invalid_parameter_noinfo();
                      }
                    }
LAB_140569bb4:
                    plVar14 = local_390;
                    if (local_390 != (longlong *)0x0) {
                      LOCK();
                      plVar23 = local_390 + 2;
                      *(int *)plVar23 = (int)*plVar23 + -1;
                      UNLOCK();
                      if ((int)*plVar23 == 0) {
                        (**(code **)*local_390)(local_390);
                        LOCK();
                        piVar13 = (int *)((longlong)plVar14 + 0x14);
                        *piVar13 = *piVar13 + -1;
                        UNLOCK();
                        if (*piVar13 == 0) {
                          (**(code **)(*plVar14 + 8))(plVar14);
                        }
                      }
                    }
                    plVar14 = local_350;
                    if (local_350 != (longlong *)0x0) {
                      LOCK();
                      plVar23 = local_350 + 2;
                      lVar20 = *plVar23;
                      *(int *)plVar23 = (int)*plVar23 + -1;
                      UNLOCK();
                      if ((int)lVar20 == 1) {
                        (**(code **)*local_350)(local_350);
                        LOCK();
                        piVar13 = (int *)((longlong)plVar14 + 0x14);
                        iVar24 = *piVar13;
                        *piVar13 = *piVar13 + -1;
                        UNLOCK();
                        if (iVar24 == 1) {
                          (**(code **)(*plVar14 + 8))(plVar14);
                        }
                      }
                    }
                  }
                  local_3c0 = local_3c0 + 1;
                } while (local_3c0 < local_348._4_4_);
              }
              local_3b8 = local_3b8 + 1;
              iVar18 = local_3a0;
            } while (local_3b8 < iVar21);
          }
          plVar14 = local_360;
          if (local_360 != (longlong *)0x0) {
            LOCK();
            plVar23 = local_360 + 2;
            lVar20 = *plVar23;
            *(int *)plVar23 = (int)*plVar23 + -1;
            UNLOCK();
            if ((int)lVar20 == 1) {
              (**(code **)*local_360)(local_360);
              LOCK();
              piVar13 = (int *)((longlong)plVar14 + 0x14);
              iVar21 = *piVar13;
              *piVar13 = *piVar13 + -1;
              UNLOCK();
              if (iVar21 == 1) {
                (**(code **)(*plVar14 + 8))(plVar14);
              }
            }
          }
          local_3a0 = iVar18 + 1;
        } while (local_3a0 < local_380);
      }
      lVar20 = param_1[0x30];
      lVar15 = FUN_140562aa0(param_1 + 0x2b,lVar20,*(undefined8 *)(lVar20 + 8),&local_378);
      FUN_140560380(param_1 + 0x2b,1);
      *(longlong *)(lVar20 + 8) = lVar15;
      **(longlong **)(lVar15 + 8) = lVar15;
      if (local_370 != (longlong *)0x0) {
        LOCK();
        plVar14 = local_370 + 2;
        lVar20 = *plVar14;
        *(int *)plVar14 = (int)*plVar14 + -1;
        UNLOCK();
        if ((int)lVar20 == 1) {
          (**(code **)*local_370)(local_370);
          LOCK();
          piVar13 = (int *)((longlong)local_370 + 0x14);
          iVar18 = *piVar13;
          *piVar13 = *piVar13 + -1;
          UNLOCK();
          if (iVar18 == 1) {
            (**(code **)(*local_370 + 8))(local_370);
          }
        }
      }
      uVar11 = 1;
    }
  }
  return uVar11;
}

// ==== CMapData::vfunc_13  @140569e60  [high:rtti-vtable]  (orig: FUN_140569e60)
undefined8
FUN_140569e60(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             longlong param_5)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  char cVar5;
  undefined2 uVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  undefined8 *puVar10;
  int *piVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong lVar14;
  undefined8 *puVar15;
  ulonglong uVar16;
  ulonglong uVar17;
  longlong lVar18;
  int iVar19;
  undefined8 *puVar20;
  int iVar21;
  longlong *plVar22;
  longlong **pplVar23;
  longlong *plVar24;
  longlong local_198;
  int local_190;
  int local_18c;
  int local_188;
  undefined1 local_184;
  undefined1 local_183;
  int local_180;
  longlong *local_178;
  int local_170;
  longlong local_168;
  longlong *local_160;
  longlong *local_158;
  longlong *local_150;
  longlong *local_148;
  int local_140;
  undefined8 local_138;
  longlong *local_130;
  undefined8 local_128;
  undefined8 local_120;
  longlong *local_118;
  undefined8 local_108;
  undefined8 uStack_100;
  undefined8 local_f8;
  longlong local_f0;
  longlong local_e8;
  longlong local_e0;
  undefined8 *local_d8;
  longlong local_d0;
  undefined8 *local_c8;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined8 local_a8;
  undefined8 uStack_a0;
  longlong *local_98 [3];
  undefined8 local_80;
  undefined8 local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_68 = 0xfffffffffffffffe;
  if (param_5 == 0) {
    log_InlineLogERROR("CMapData::AddTerrainObj file name is null, owner:%u.");
    uVar9 = 0;
  }
  else {
    FUN_1405733c0(&local_150,param_5,param_2);
    if (local_150 == (longlong *)0x0) {
      log_InlineLogERROR("CMapData::AddTerrainObj cannot create item from file %s for owner %u");
      if (local_148 != (longlong *)0x0) {
        LOCK();
        plVar12 = local_148 + 2;
        lVar18 = *plVar12;
        *(int *)plVar12 = (int)*plVar12 + -1;
        UNLOCK();
        if ((int)lVar18 == 1) {
          (**(code **)*local_148)(local_148);
          LOCK();
          piVar11 = (int *)((longlong)local_148 + 0x14);
          *piVar11 = *piVar11 + -1;
          UNLOCK();
          if (*piVar11 == 0) {
            (**(code **)(*local_148 + 8))(local_148);
          }
        }
      }
      uVar9 = 0;
    }
    else {
      (**(code **)(*local_150 + 8))(local_150,param_3,param_4);
      local_140 = FUN_140571a80(local_150);
      local_170 = 0;
      if (0 < local_140) {
        do {
          iVar21 = local_170;
          FUN_140572280(local_150,&local_138,local_170);
          puVar10 = (undefined8 *)FUN_140570bd0(local_138);
          uVar9 = *puVar10;
          local_f8 = uVar9;
          puVar10 = (undefined8 *)FUN_140570bf0();
          local_128 = *puVar10;
          local_190 = 0;
          iVar19 = (int)local_128;
          if (0 < iVar19) {
            do {
              local_180 = 0;
              if (0 < local_128._4_4_) {
                local_188 = (int)uVar9 - local_190;
                do {
                  iVar21 = local_f8._4_4_ - local_180;
                  cVar5 = FUN_14056ab10(param_1[0x20],local_188,iVar21);
                  if (cVar5 != '\0') {
                    FUN_140570f90(local_138,&local_120,local_190,local_180);
                    FUN_140570b20(&local_168);
                    uVar4 = local_120;
                    local_178 = (longlong *)local_168;
                    if (local_168 == 0) {
                      log_InlineLogERROR("CMapData::AddTerrainObj cannot create layer data");
                      if (local_160 != (longlong *)0x0) {
                        LOCK();
                        plVar12 = local_160 + 2;
                        lVar18 = *plVar12;
                        *(int *)plVar12 = (int)*plVar12 + -1;
                        UNLOCK();
                        if ((int)lVar18 == 1) {
                          (**(code **)*local_160)(local_160);
                          LOCK();
                          piVar11 = (int *)((longlong)local_160 + 0x14);
                          iVar21 = *piVar11;
                          *piVar11 = *piVar11 + -1;
                          UNLOCK();
                          if (iVar21 == 1) {
                            (**(code **)(*local_160 + 8))(local_160);
                          }
                        }
                      }
                      if (local_118 != (longlong *)0x0) {
                        LOCK();
                        plVar12 = local_118 + 2;
                        lVar18 = *plVar12;
                        *(int *)plVar12 = (int)*plVar12 + -1;
                        UNLOCK();
                        if ((int)lVar18 == 1) {
                          (**(code **)*local_118)(local_118);
                          LOCK();
                          piVar11 = (int *)((longlong)local_118 + 0x14);
                          iVar21 = *piVar11;
                          *piVar11 = *piVar11 + -1;
                          UNLOCK();
                          if (iVar21 == 1) {
                            (**(code **)(*local_118 + 8))(local_118);
                          }
                        }
                      }
                      if (local_130 != (longlong *)0x0) {
                        LOCK();
                        plVar12 = local_130 + 2;
                        lVar18 = *plVar12;
                        *(int *)plVar12 = (int)*plVar12 + -1;
                        UNLOCK();
                        if ((int)lVar18 == 1) {
                          (**(code **)*local_130)(local_130);
                          LOCK();
                          piVar11 = (int *)((longlong)local_130 + 0x14);
                          iVar21 = *piVar11;
                          *piVar11 = *piVar11 + -1;
                          UNLOCK();
                          if (iVar21 == 1) {
                            (**(code **)(*local_130 + 8))(local_130);
                          }
                        }
                      }
                      if (local_148 != (longlong *)0x0) {
                        LOCK();
                        plVar12 = local_148 + 2;
                        lVar18 = *plVar12;
                        *(int *)plVar12 = (int)*plVar12 + -1;
                        UNLOCK();
                        if ((int)lVar18 == 1) {
                          (**(code **)*local_148)(local_148);
                          LOCK();
                          piVar11 = (int *)((longlong)local_148 + 0x14);
                          iVar21 = *piVar11;
                          *piVar11 = *piVar11 + -1;
                          UNLOCK();
                          if (iVar21 == 1) {
                            (**(code **)(*local_148 + 8))(local_148);
                          }
                        }
                      }
                      return 0;
                    }
                    iVar7 = (**(code **)(*param_1 + 8))(param_1,local_188,iVar21);
                    iVar8 = FUN_140570940(uVar4);
                    FUN_140570970(local_178,iVar8 + iVar7);
                    lVar18 = local_168;
                    uVar6 = FUN_140570950(local_120);
                    FUN_140570980(lVar18,uVar6);
                    lVar18 = local_168;
                    uVar6 = FUN_140570960(local_120);
                    FUN_140570990(lVar18,uVar6);
                    iVar21 = FUN_14056ab30(param_1[0x20],local_188,iVar21);
                    local_178 = param_1 + 0x32;
                    puVar10 = (undefined8 *)param_1[0x38];
                    lVar18 = *local_178;
                    cVar5 = *(char *)((longlong)puVar10[1] + 0x21);
                    puVar3 = puVar10;
                    puVar20 = (undefined8 *)puVar10[1];
                    while (cVar5 == '\0') {
                      if (*(int *)(puVar20 + 3) < iVar21) {
                        puVar15 = (undefined8 *)puVar20[2];
                        puVar20 = puVar3;
                      }
                      else {
                        puVar15 = (undefined8 *)*puVar20;
                      }
                      puVar3 = puVar20;
                      puVar20 = puVar15;
                      cVar5 = *(char *)((longlong)puVar15 + 0x21);
                    }
                    local_c8 = puVar3;
                    local_d0 = lVar18;
                    local_18c = iVar21;
                    if (lVar18 == 0) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar3 == puVar10) || (iVar21 < *(int *)(puVar3 + 3))) {
                      local_e8 = local_178[6];
                      local_f0 = *local_178;
                      plVar12 = &local_f0;
                    }
                    else {
                      plVar12 = &local_d0;
                    }
                    local_e0 = *plVar12;
                    local_d8 = (undefined8 *)plVar12[1];
                    if ((local_e0 == 0) || (local_e0 != lVar18)) {
                      _invalid_parameter_noinfo();
                    }
                    if (local_d8 == puVar10) {
                      plVar13 = param_1 + 0x14;
                      plVar12 = (longlong *)param_1[0x17];
                      plVar22 = plVar13;
                      if ((longlong *)param_1[0x18] < plVar12) {
                        _invalid_parameter_noinfo();
                      }
                      plVar1 = (longlong *)*plVar13;
                      while( true ) {
                        plVar24 = (longlong *)param_1[0x18];
                        if (plVar24 < (longlong *)param_1[0x17]) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar13)) {
                          _invalid_parameter_noinfo();
                        }
                        if (plVar12 == plVar24) goto LAB_14056a479;
                        if (plVar1 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar18 = 0;
                        }
                        else {
                          lVar18 = *plVar1;
                        }
                        if (*(longlong **)(lVar18 + 0x20) <= plVar12) {
                          _invalid_parameter_noinfo();
                        }
                        if ((plVar12[4] - plVar12[3] & 0xfffffffffffffff0U) == 0) break;
                        if (plVar1 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar18 = 0;
                        }
                        else {
                          lVar18 = *plVar1;
                        }
                        if (*(longlong **)(lVar18 + 0x20) <= plVar12) {
                          _invalid_parameter_noinfo();
                        }
                        plVar12 = plVar12 + 6;
                      }
                      if (plVar1 == (longlong *)0x0) {
                        _invalid_parameter_noinfo();
                        lVar18 = 0;
                      }
                      else {
                        lVar18 = *plVar1;
                      }
                      if (*(longlong **)(lVar18 + 0x20) <= plVar12) {
                        _invalid_parameter_noinfo();
                      }
                      uVar17 = plVar12[3];
                      if (uVar17 == 0) {
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = (longlong)(plVar12[5] - uVar17) >> 4;
                      }
                      uVar2 = plVar12[4];
                      if ((ulonglong)((longlong)(uVar2 - uVar17) >> 4) < uVar16) {
                        FUN_140562d30(uVar2,1,&local_168,plVar12 + 2,(undefined1)param_5,0);
                        plVar12[4] = uVar2 + 0x10;
                      }
                      else {
                        if (uVar2 < uVar17) {
                          _invalid_parameter_noinfo();
                        }
                        local_108 = *plVar12;
                        uVar17 = plVar12[3];
                        uStack_100 = uVar2;
                        if ((plVar12[4] - uVar17 & 0xfffffffffffffff0) == 0) {
                          local_198 = 0;
                        }
                        else {
                          if ((ulonglong)plVar12[4] < uVar17) {
                            _invalid_parameter_noinfo();
                          }
                          if ((local_108 == 0) || (local_108 != *plVar12)) {
                            _invalid_parameter_noinfo();
                          }
                          local_198 = (longlong)(uVar2 - uVar17) >> 4;
                        }
                        local_38 = (undefined4)local_108;
                        uStack_34 = local_108._4_4_;
                        uStack_30 = (undefined4)uStack_100;
                        uStack_2c = uStack_100._4_4_;
                        FUN_140564460(plVar12,&local_38,1,&local_168);
                        local_158 = (longlong *)plVar12[3];
                        if ((ulonglong)plVar12[4] < local_158) {
                          _invalid_parameter_noinfo();
                        }
                        plVar24 = (longlong *)*plVar12;
                        if (plVar24 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar18 = 0;
                        }
                        else {
                          lVar18 = *plVar24;
                        }
                        uVar17 = (longlong)local_158 + local_198 * 0x10;
                        if (uVar17 <= *(ulonglong *)(lVar18 + 0x20)) {
                          if (plVar24 == (longlong *)0x0) {
                            lVar18 = 0;
                          }
                          else {
                            lVar18 = *plVar24;
                          }
                          if (*(ulonglong *)(lVar18 + 0x18) <= uVar17) goto LAB_14056a410;
                        }
                        _invalid_parameter_noinfo();
                      }
LAB_14056a410:
                      local_158 = (longlong *)param_1[0x17];
                      if ((longlong *)param_1[0x18] < local_158) {
                        _invalid_parameter_noinfo();
                      }
                      if ((plVar1 == (longlong *)0x0) ||
                         (plVar24 = (longlong *)*plVar13, plVar13 = plVar22, plVar1 != plVar24)) {
                        _invalid_parameter_noinfo();
                        plVar13 = plVar22;
                      }
                      lVar18 = ((longlong)plVar12 - (longlong)local_158) / 6 +
                               ((longlong)plVar12 - (longlong)local_158 >> 0x3f);
                      piVar11 = (int *)FUN_14033a2d0(local_178,&local_18c);
                      *piVar11 = (int)(lVar18 >> 3) - (int)(lVar18 >> 0x3f);
LAB_14056a479:
                      plVar22 = (longlong *)plVar13[4];
                      if (plVar22 < (longlong *)plVar13[3]) {
                        _invalid_parameter_noinfo();
                      }
                      if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar13)) {
                        _invalid_parameter_noinfo();
                      }
                      if (plVar12 == plVar22) {
                        lVar18 = (plVar13[4] - plVar13[3]) / 6 + (plVar13[4] - plVar13[3] >> 0x3f);
                        iVar21 = (int)(lVar18 >> 3) - (int)(lVar18 >> 0x3f);
                        piVar11 = (int *)FUN_14033a2d0(local_178,&local_18c);
                        *piVar11 = iVar21;
                        pplVar23 = local_98;
                        plVar12 = operator_new(8);
                        if (plVar12 == (longlong *)0x0) {
                          local_98[0] = (longlong *)0x0;
                        }
                        else {
                          *plVar12 = (longlong)local_98;
                          local_98[0] = plVar12;
                        }
                        uVar16 = 0;
                        local_80 = 0;
                        local_78 = 0;
                        local_70 = 0;
                        local_158 = plVar12;
                        FUN_140568e70(plVar13,(longlong)(iVar21 + 1),local_98);
                        plVar13 = (longlong *)FUN_140561780(plVar13);
                        uVar17 = plVar13[3];
                        if (uVar17 != 0) {
                          uVar16 = (longlong)(plVar13[5] - uVar17) >> 4;
                        }
                        uVar2 = plVar13[4];
                        if ((ulonglong)((longlong)(uVar2 - uVar17) >> 4) < uVar16) {
                          local_183 = 0;
                          FUN_140562d30(uVar2,1,&local_168,plVar13 + 2,(undefined1)param_5,0,
                                        pplVar23,plVar12);
                          plVar13[4] = uVar2 + 0x10;
                        }
                        else {
                          if (uVar2 < uVar17) {
                            _invalid_parameter_noinfo();
                          }
                          lVar18 = *plVar13;
                          uVar17 = plVar13[3];
                          local_b8 = lVar18;
                          uStack_b0 = uVar2;
                          if ((plVar13[4] - uVar17 & 0xfffffffffffffff0) == 0) {
                            lVar18 = 0;
                          }
                          else {
                            if ((ulonglong)plVar13[4] < uVar17) {
                              _invalid_parameter_noinfo();
                            }
                            if ((lVar18 == 0) || (lVar18 != *plVar13)) {
                              _invalid_parameter_noinfo();
                            }
                            lVar18 = (longlong)(uVar2 - uVar17) >> 4;
                          }
                          local_48 = (undefined4)local_b8;
                          uStack_44 = local_b8._4_4_;
                          uStack_40 = (undefined4)uStack_b0;
                          uStack_3c = uStack_b0._4_4_;
                          FUN_140564460(plVar13,&local_48,1,&local_168);
                          uVar17 = plVar13[3];
                          if ((ulonglong)plVar13[4] < uVar17) {
                            _invalid_parameter_noinfo();
                          }
                          plVar13 = (longlong *)*plVar13;
                          if (plVar13 == (longlong *)0x0) {
                            _invalid_parameter_noinfo();
                            lVar14 = 0;
                          }
                          else {
                            lVar14 = *plVar13;
                          }
                          uVar17 = uVar17 + lVar18 * 0x10;
                          if (uVar17 <= *(ulonglong *)(lVar14 + 0x20)) {
                            if (plVar13 == (longlong *)0x0) {
                              lVar18 = 0;
                            }
                            else {
                              lVar18 = *plVar13;
                            }
                            if (*(ulonglong *)(lVar18 + 0x18) <= uVar17) goto LAB_14056a838;
                          }
                          _invalid_parameter_noinfo();
                        }
                      }
                    }
                    else {
                      piVar11 = (int *)FUN_14033a2d0(local_178,&local_18c);
                      iVar21 = *piVar11;
                      if ((ulonglong)((param_1[0x18] - param_1[0x17]) / 0x30) <=
                          (ulonglong)(longlong)iVar21) {
                        _invalid_parameter_noinfo();
                      }
                      plVar12 = (longlong *)((longlong)iVar21 * 0x30 + param_1[0x17]);
                      uVar17 = plVar12[3];
                      if (uVar17 == 0) {
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = (longlong)(plVar12[5] - uVar17) >> 4;
                      }
                      uVar2 = plVar12[4];
                      if ((ulonglong)((longlong)(uVar2 - uVar17) >> 4) < uVar16) {
                        local_184 = 0;
                        FUN_140562d30(uVar2,1,&local_168,plVar12 + 2,(undefined1)param_5,0);
                        plVar12[4] = uVar2 + 0x10;
                      }
                      else {
                        if (uVar2 < uVar17) {
                          _invalid_parameter_noinfo();
                        }
                        lVar18 = *plVar12;
                        uVar17 = plVar12[3];
                        local_a8 = lVar18;
                        uStack_a0 = uVar2;
                        if ((plVar12[4] - uVar17 & 0xfffffffffffffff0) == 0) {
                          lVar18 = 0;
                        }
                        else {
                          if ((ulonglong)plVar12[4] < uVar17) {
                            _invalid_parameter_noinfo();
                          }
                          if ((lVar18 == 0) || (lVar18 != *plVar12)) {
                            _invalid_parameter_noinfo();
                          }
                          lVar18 = (longlong)(uVar2 - uVar17) >> 4;
                        }
                        local_58 = (undefined4)local_a8;
                        uStack_54 = local_a8._4_4_;
                        uStack_50 = (undefined4)uStack_a0;
                        uStack_4c = uStack_a0._4_4_;
                        FUN_140564460(plVar12,&local_58,1,&local_168);
                        uVar17 = plVar12[3];
                        if ((ulonglong)plVar12[4] < uVar17) {
                          _invalid_parameter_noinfo();
                        }
                        plVar12 = (longlong *)*plVar12;
                        if (plVar12 == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar14 = 0;
                        }
                        else {
                          lVar14 = *plVar12;
                        }
                        uVar17 = uVar17 + lVar18 * 0x10;
                        if (uVar17 <= *(ulonglong *)(lVar14 + 0x20)) {
                          if (plVar12 == (longlong *)0x0) {
                            lVar18 = 0;
                          }
                          else {
                            lVar18 = *plVar12;
                          }
                          if (*(ulonglong *)(lVar18 + 0x18) <= uVar17) goto LAB_14056a838;
                        }
                        _invalid_parameter_noinfo();
                      }
                    }
LAB_14056a838:
                    plVar12 = local_160;
                    if (local_160 != (longlong *)0x0) {
                      LOCK();
                      plVar13 = local_160 + 2;
                      *(int *)plVar13 = (int)*plVar13 + -1;
                      UNLOCK();
                      if ((int)*plVar13 == 0) {
                        (**(code **)*local_160)(local_160);
                        LOCK();
                        piVar11 = (int *)((longlong)plVar12 + 0x14);
                        *piVar11 = *piVar11 + -1;
                        UNLOCK();
                        if (*piVar11 == 0) {
                          (**(code **)(*plVar12 + 8))(plVar12);
                        }
                      }
                    }
                    plVar12 = local_118;
                    if (local_118 != (longlong *)0x0) {
                      LOCK();
                      plVar13 = local_118 + 2;
                      lVar18 = *plVar13;
                      *(int *)plVar13 = (int)*plVar13 + -1;
                      UNLOCK();
                      if ((int)lVar18 == 1) {
                        (**(code **)*local_118)(local_118);
                        LOCK();
                        piVar11 = (int *)((longlong)plVar12 + 0x14);
                        iVar21 = *piVar11;
                        *piVar11 = *piVar11 + -1;
                        UNLOCK();
                        if (iVar21 == 1) {
                          (**(code **)(*plVar12 + 8))(plVar12);
                        }
                      }
                    }
                  }
                  local_180 = local_180 + 1;
                } while (local_180 < local_128._4_4_);
              }
              local_190 = local_190 + 1;
              iVar21 = local_170;
            } while (local_190 < iVar19);
          }
          plVar12 = local_130;
          if (local_130 != (longlong *)0x0) {
            LOCK();
            plVar13 = local_130 + 2;
            lVar18 = *plVar13;
            *(int *)plVar13 = (int)*plVar13 + -1;
            UNLOCK();
            if ((int)lVar18 == 1) {
              (**(code **)*local_130)(local_130);
              LOCK();
              piVar11 = (int *)((longlong)plVar12 + 0x14);
              iVar19 = *piVar11;
              *piVar11 = *piVar11 + -1;
              UNLOCK();
              if (iVar19 == 1) {
                (**(code **)(*plVar12 + 8))(plVar12);
              }
            }
          }
          local_170 = iVar21 + 1;
        } while (local_170 < local_140);
      }
      lVar18 = param_1[0x30];
      lVar14 = FUN_140562aa0(param_1 + 0x2b,lVar18,*(undefined8 *)(lVar18 + 8),&local_150);
      FUN_140560380(param_1 + 0x2b,1);
      *(longlong *)(lVar18 + 8) = lVar14;
      **(longlong **)(lVar14 + 8) = lVar14;
      if (local_148 != (longlong *)0x0) {
        LOCK();
        plVar12 = local_148 + 2;
        lVar18 = *plVar12;
        *(int *)plVar12 = (int)*plVar12 + -1;
        UNLOCK();
        if ((int)lVar18 == 1) {
          (**(code **)*local_148)(local_148);
          LOCK();
          piVar11 = (int *)((longlong)local_148 + 0x14);
          iVar21 = *piVar11;
          *piVar11 = *piVar11 + -1;
          UNLOCK();
          if (iVar21 == 1) {
            (**(code **)(*local_148 + 8))(local_148);
          }
        }
      }
      uVar9 = 1;
    }
  }
  return uVar9;
}

// ==== CMapData::helper_14056aaf0  @14056aaf0  [medium:callgraph-r0]  (orig: FUN_14056aaf0)
undefined4 FUN_14056aaf0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 4);
}

// ==== CMapData::helper_14056ab00  @14056ab00  [medium:callgraph-r0]  (orig: FUN_14056ab00)
undefined4 FUN_14056ab00(undefined4 *param_1)

{
  return *param_1;
}

// ==== CMapData::helper_14056ab10  @14056ab10  [medium:callgraph-r0]  (orig: FUN_14056ab10)
undefined1 FUN_14056ab10(int *param_1,int param_2,int param_3)

{
  if ((((-1 < param_2) && (-1 < param_3)) && (param_2 < *param_1)) && (param_3 < param_1[1])) {
    return 1;
  }
  return 0;
}

// ==== CMapData::helper_14056ab30  @14056ab30  [medium:callgraph-r0]  (orig: FUN_14056ab30)
int FUN_14056ab30(int *param_1,int param_2,int param_3)

{
  return *param_1 * param_3 + param_2;
}

// ==== CMapData::helper_14056b2e0  @14056b2e0  [medium:callgraph-r0]  (orig: FUN_14056b2e0)
void FUN_14056b2e0(int *param_1,int param_2,int param_3)

{
  FUN_1405737c0(*(longlong *)(param_1 + 4) + (longlong)(*param_1 * param_3 + param_2) * 4);
  return;
}

// ==== CMapData::helper_14056d310  @14056d310  [medium:callgraph-r0]  (orig: FUN_14056d310)
ulonglong FUN_14056d310(int *param_1,int param_2,int param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  short sVar4;
  int iVar5;
  ulonglong uVar6;
  longlong lVar7;
  
  lVar7 = *(longlong *)(param_1 + 4) + (longlong)(*param_1 * param_3 + param_2) * 4;
  iVar5 = FUN_1405737d0(lVar7);
  if (iVar5 == 0xffff) {
    uVar6 = FUN_1405737c0(lVar7);
  }
  else {
    if ((ulonglong)((*(longlong *)(param_1 + 0x1e) - *(longlong *)(param_1 + 0x1c)) / 0x30) <=
        (ulonglong)(longlong)iVar5) {
      _invalid_parameter_noinfo();
    }
    lVar7 = FUN_140561830();
    plVar3 = *(longlong **)(lVar7 + 8);
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar3 + 2) = (int)plVar3[2] + 1;
      UNLOCK();
    }
    sVar4 = FUN_140570940();
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      plVar1 = plVar3 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*plVar3)(plVar3);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*plVar3 + 8))(plVar3);
        }
      }
    }
    uVar6 = (ulonglong)(uint)(int)sVar4;
  }
  return uVar6;
}

// ==== CMapData::helper_14056d410  @14056d410  [medium:callgraph-r0]  (orig: FUN_14056d410)
undefined2 FUN_14056d410(int *param_1,int param_2,int param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  undefined2 uVar4;
  int iVar5;
  longlong lVar6;
  
  iVar5 = FUN_1405737d0(*(longlong *)(param_1 + 4) + (longlong)(*param_1 * param_3 + param_2) * 4);
  if (iVar5 == 0xffff) {
    uVar4 = 0;
  }
  else {
    if ((ulonglong)((*(longlong *)(param_1 + 0x1e) - *(longlong *)(param_1 + 0x1c)) / 0x30) <=
        (ulonglong)(longlong)iVar5) {
      _invalid_parameter_noinfo();
    }
    lVar6 = FUN_140561830();
    plVar3 = *(longlong **)(lVar6 + 8);
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar3 + 2) = (int)plVar3[2] + 1;
      UNLOCK();
    }
    uVar4 = FUN_140570960();
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      plVar1 = plVar3 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*plVar3)(plVar3);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*plVar3 + 8))(plVar3);
        }
      }
    }
  }
  return uVar4;
}

// ==== CMapData::helper_14056d500  @14056d500  [medium:callgraph-r0]  (orig: FUN_14056d500)
ushort FUN_14056d500(int *param_1,int param_2,int param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  char cVar4;
  ushort uVar5;
  int iVar6;
  longlong lVar7;
  
  lVar7 = *(longlong *)(param_1 + 4) + (longlong)(*param_1 * param_3 + param_2) * 4;
  iVar6 = FUN_1405737d0(lVar7);
  if (iVar6 == 0xffff) {
    cVar4 = FUN_1405737e0(lVar7);
    uVar5 = (ushort)(cVar4 != '\0');
  }
  else {
    if ((ulonglong)((*(longlong *)(param_1 + 0x1e) - *(longlong *)(param_1 + 0x1c)) / 0x30) <=
        (ulonglong)(longlong)iVar6) {
      _invalid_parameter_noinfo();
    }
    lVar7 = FUN_140561830();
    plVar3 = *(longlong **)(lVar7 + 8);
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar3 + 2) = (int)plVar3[2] + 1;
      UNLOCK();
    }
    uVar5 = FUN_140570950();
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      plVar1 = plVar3 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*plVar3)(plVar3);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*plVar3 + 8))(plVar3);
        }
      }
    }
  }
  return uVar5;
}

// ==== CMapData::helper_14056d600  @14056d600  [medium:callgraph-r0]  (orig: FUN_14056d600)
undefined4 FUN_14056d600(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  ulonglong uVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  uVar9 = (longlong)param_3 << 0x20 | (longlong)param_2;
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if ((longlong)puVar8[3] < (longlong)uVar9) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || ((longlong)uVar9 < (longlong)puVar3[3])) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar10 = *(longlong *)(param_1 + 0x48);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar10) {
    uVar5 = 0xffffffff;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x20);
  }
  return uVar5;
}

// ==== CMapData::helper_14056d710  @14056d710  [medium:callgraph-r0]  (orig: FUN_14056d710)
undefined8 FUN_14056d710(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  ulonglong uVar9;
  int local_a8 [10];
  int local_80 [10];
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong local_38;
  undefined8 *local_30;
  
  lVar8 = 0;
  local_a8[1] = 1;
  local_a8[2] = 0xffffffff;
  local_a8[3] = 1;
  local_a8[0] = 0;
  local_a8[4] = 0;
  local_a8[8] = 0;
  local_80[0] = 0;
  local_80[3] = 0;
  local_80[7] = 0;
  local_a8[5] = 1;
  local_a8[6] = 0xffffffff;
  local_a8[7] = 0xffffffff;
  local_80[1] = 1;
  local_80[2] = 0xffffffff;
  local_80[4] = 1;
  local_80[5] = 0xffffffff;
  local_80[6] = 1;
  local_80[8] = 0xffffffff;
  while( true ) {
    puVar2 = *(undefined8 **)(param_1 + 0x48);
    lVar3 = *(longlong *)(param_1 + 0x18);
    uVar9 = (longlong)(*(int *)((longlong)local_80 + lVar8) + param_3) << 0x20 |
            (longlong)(*(int *)((longlong)local_a8 + lVar8) + param_2);
    cVar1 = *(char *)((longlong)puVar2[1] + 0x29);
    puVar4 = puVar2;
    puVar7 = (undefined8 *)puVar2[1];
    while (cVar1 == '\0') {
      if ((longlong)puVar7[3] < (longlong)uVar9) {
        puVar5 = (undefined8 *)puVar7[2];
        puVar7 = puVar4;
      }
      else {
        puVar5 = (undefined8 *)*puVar7;
      }
      puVar4 = puVar7;
      puVar7 = puVar5;
      cVar1 = *(char *)((longlong)puVar5 + 0x29);
    }
    local_30 = puVar4;
    local_38 = lVar3;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar4 == puVar2) || ((longlong)uVar9 < (longlong)puVar4[3])) {
      plVar6 = &local_48;
      local_40 = *(undefined8 *)(param_1 + 0x48);
      local_48 = *(longlong *)(param_1 + 0x18);
    }
    else {
      plVar6 = &local_38;
    }
    local_58 = *plVar6;
    local_50 = (undefined8 *)plVar6[1];
    if ((local_58 == 0) || (local_58 != lVar3)) {
      _invalid_parameter_noinfo();
    }
    if (local_50 != puVar2) break;
    lVar8 = lVar8 + 4;
    if (0x23 < lVar8) {
      return 0;
    }
  }
  return 1;
}

// ==== CMapData::helper_140570940  @140570940  [medium:callgraph-r0]  (orig: FUN_140570940)
undefined2 FUN_140570940(undefined2 *param_1)

{
  return *param_1;
}

// ==== CMapData::helper_140570950  @140570950  [medium:callgraph-r0]  (orig: FUN_140570950)
undefined2 FUN_140570950(longlong param_1)

{
  return *(undefined2 *)(param_1 + 2);
}

// ==== CMapData::helper_140570960  @140570960  [medium:callgraph-r0]  (orig: FUN_140570960)
undefined2 FUN_140570960(longlong param_1)

{
  return *(undefined2 *)(param_1 + 4);
}

// ==== CMapData::helper_140570970  @140570970  [medium:callgraph-r0]  (orig: FUN_140570970)
void FUN_140570970(undefined2 *param_1,undefined2 param_2)

{
  *param_1 = param_2;
  return;
}

// ==== CMapData::helper_140570980  @140570980  [medium:callgraph-r0]  (orig: FUN_140570980)
void FUN_140570980(longlong param_1,undefined2 param_2)

{
  *(undefined2 *)(param_1 + 2) = param_2;
  return;
}

// ==== CMapData::helper_140570990  @140570990  [medium:callgraph-r0]  (orig: FUN_140570990)
void FUN_140570990(longlong param_1,undefined2 param_2)

{
  *(undefined2 *)(param_1 + 4) = param_2;
  return;
}

// ==== CMapData::helper_140570a80  @140570a80  [medium:callgraph-r1]  (orig: FUN_140570a80)
void FUN_140570a80(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count<CLayer>::vftable;
  }
  FUN_14055f960(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CMapData::helper_140570b20  @140570b20  [medium:callgraph-r0]  (orig: FUN_140570b20)
undefined8 *
FUN_140570b20(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined2 *puVar1;
  undefined2 *puVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  puVar2 = (undefined2 *)0x0;
  uVar3 = 0;
  puVar1 = operator_new(6);
  if (puVar1 != (undefined2 *)0x0) {
    *puVar1 = 0;
    puVar1[1] = 0;
    puVar1[2] = 0;
    puVar2 = puVar1;
  }
  *param_1 = 0;
  param_1[1] = 0;
  FUN_140570a80(param_1,puVar2,param_3,param_4,uVar3,uVar4);
  return param_1;
}

// ==== CMapData::helper_140570bd0  @140570bd0  [medium:callgraph-r0]  (orig: FUN_140570bd0)
longlong FUN_140570bd0(longlong param_1)

{
  return param_1 + 0xc;
}

// ==== CMapData::helper_140570bf0  @140570bf0  [medium:callgraph-r0]  (orig: FUN_140570bf0)
longlong FUN_140570bf0(longlong param_1)

{
  return param_1 + 0x18;
}

// ==== CMapData::helper_140570d20  @140570d20  [medium:callgraph-r1]  (orig: FUN_140570d20)
void FUN_140570d20(undefined8 *param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  if (param_3 != 0) {
    LOCK();
    *(int *)(param_3 + 0x10) = *(int *)(param_3 + 0x10) + 1;
    UNLOCK();
  }
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = param_3;
    *param_1 = param_2;
  }
  else {
    LOCK();
    plVar1 = plVar3 + 2;
    *(int *)plVar1 = (int)*plVar1 + -1;
    UNLOCK();
    if ((int)*plVar1 == 0) {
      (**(code **)*plVar3)(plVar3);
      LOCK();
      piVar2 = (int *)((longlong)plVar3 + 0x14);
      *piVar2 = *piVar2 + -1;
      UNLOCK();
      if (*piVar2 == 0) {
        (**(code **)(*plVar3 + 8))(plVar3);
      }
      param_1[1] = param_3;
      *param_1 = param_2;
    }
    else {
      param_1[1] = param_3;
      *param_1 = param_2;
    }
  }
  return;
}

// ==== CMapData::helper_140570e40  @140570e40  [medium:callgraph-r2]  (orig: FUN_140570e40)
void FUN_140570e40(undefined8 *param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  LOCK();
  plVar1 = plVar3 + 2;
  *(int *)plVar1 = (int)*plVar1 + -1;
  UNLOCK();
  if ((int)*plVar1 == 0) {
    (**(code **)*plVar3)(plVar3);
    LOCK();
    piVar2 = (int *)((longlong)plVar3 + 0x14);
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
      (**(code **)(*plVar3 + 8))(plVar3);
    }
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}

// ==== CMapData::helper_140570ed0  @140570ed0  [medium:callgraph-r2]  (orig: FUN_140570ed0)
void FUN_140570ed0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count<CTerrainObjPart>::vftable;
  }
  FUN_140570d20(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CMapData::helper_140570f90  @140570f90  [medium:callgraph-r0]  (orig: FUN_140570f90)
undefined8 * FUN_140570f90(longlong param_1,undefined8 *param_2,int param_3,int param_4)

{
  ulonglong uVar1;
  undefined8 *puVar2;
  
  uVar1 = (ulonglong)(*(int *)(param_1 + 0x18) * param_4 + param_3);
  if ((ulonglong)(*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40) >> 4) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  puVar2 = (undefined8 *)(uVar1 * 0x10 + *(longlong *)(param_1 + 0x40));
  *param_2 = 0;
  param_2[1] = 0;
  FUN_14055f960(param_2,*puVar2,puVar2[1]);
  return param_2;
}

// ==== CMapData::helper_140571170  @140571170  [medium:callgraph-r1]  (orig: FUN_140571170)
undefined8 * FUN_140571170(undefined8 *param_1,FILE *param_2)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  int iVar6;
  void *pvVar7;
  undefined8 uVar8;
  longlong lVar9;
  ulonglong uVar10;
  int iVar11;
  longlong lVar12;
  int iVar13;
  undefined1 local_res18;
  undefined4 local_res20 [2];
  int local_a4;
  longlong local_90;
  longlong *local_88;
  longlong local_80;
  longlong *local_78;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  
  pvVar7 = operator_new(0x58);
  if (pvVar7 == (void *)0x0) {
    uVar8 = 0;
  }
  else {
    uVar8 = FUN_140571030(pvVar7);
  }
  local_90 = 0;
  local_88 = (longlong *)0x0;
  FUN_140570ed0(&local_90,uVar8);
  lVar9 = local_90;
  if (local_90 == 0) {
    log_InlineLogERROR("CTerrainObjPart cannot create terrain obj part data");
    *param_1 = 0;
    param_1[1] = 0;
    FUN_140570e40(param_1);
    plVar3 = local_88;
    if (local_88 != (longlong *)0x0) {
      LOCK();
      plVar1 = local_88 + 2;
      *(int *)plVar1 = (int)*plVar1 + -1;
      UNLOCK();
      if ((int)*plVar1 == 0) {
        (**(code **)*local_88)(local_88);
        LOCK();
        piVar2 = (int *)((longlong)plVar3 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*local_88 + 8))();
        }
      }
    }
  }
  else {
    fseek(param_2,0x14c,1);
    fread((void *)(lVar9 + 0x18),4,1,param_2);
    fread((void *)(lVar9 + 0x1c),4,1,param_2);
    fseek(param_2,4,1);
    fread((void *)(lVar9 + 0x20),4,1,param_2);
    fread((void *)(lVar9 + 0x24),4,1,param_2);
    fseek(param_2,4,1);
    uVar8 = *(undefined8 *)(lVar9 + 0x18);
    local_a4 = 0;
    iVar6 = (int)((ulonglong)uVar8 >> 0x20);
    if (0 < iVar6) {
      local_res18 = SUB81(pvVar7,0);
      do {
        iVar13 = 0;
        iVar11 = (int)uVar8;
        if (0 < iVar11) {
          do {
            FUN_140570b20(&local_80);
            if (local_80 == 0) {
              log_InlineLogERROR("CTerrainObjPart cannot create layer data");
              param_1[1] = 0;
              *param_1 = 0;
              if (local_78 != (longlong *)0x0) {
                LOCK();
                plVar3 = local_78 + 2;
                *(int *)plVar3 = (int)*plVar3 + -1;
                UNLOCK();
                if ((int)*plVar3 == 0) {
                  (**(code **)*local_78)(local_78);
                  LOCK();
                  piVar2 = (int *)((longlong)local_78 + 0x14);
                  *piVar2 = *piVar2 + -1;
                  UNLOCK();
                  if (*piVar2 == 0) {
                    (**(code **)(*local_78 + 8))(local_78);
                  }
                }
              }
              plVar3 = local_88;
              if (local_88 == (longlong *)0x0) {
                return param_1;
              }
              LOCK();
              plVar1 = local_88 + 2;
              *(int *)plVar1 = (int)*plVar1 + -1;
              UNLOCK();
              if ((int)*plVar1 != 0) {
                return param_1;
              }
              (**(code **)*local_88)(local_88);
              LOCK();
              piVar2 = (int *)((longlong)plVar3 + 0x14);
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (*piVar2 != 0) {
                return param_1;
              }
              (**(code **)(*local_88 + 8))();
              return param_1;
            }
            local_res20[0] = 0;
            fread(local_res20,4,1,param_2);
            FUN_140570980(local_80,(undefined2)local_res20[0]);
            fread(local_res20,4,1,param_2);
            FUN_140570990(local_80,(undefined2)local_res20[0]);
            fread(local_res20,4,1,param_2);
            FUN_140570970(local_80,(undefined2)local_res20[0]);
            plVar3 = (longlong *)(lVar9 + 0x28);
            uVar4 = *(ulonglong *)(lVar9 + 0x40);
            if (uVar4 == 0) {
              uVar10 = 0;
            }
            else {
              uVar10 = (longlong)(*(longlong *)(lVar9 + 0x50) - uVar4) >> 4;
            }
            uVar5 = *(ulonglong *)(lVar9 + 0x48);
            if ((ulonglong)((longlong)(uVar5 - uVar4) >> 4) < uVar10) {
              FUN_140562d30(uVar5,1,&local_80,lVar9 + 0x38,local_res18,0);
              *(ulonglong *)(lVar9 + 0x48) = uVar5 + 0x10;
            }
            else {
              if (uVar5 < uVar4) {
                _invalid_parameter_noinfo();
              }
              lVar12 = *plVar3;
              uVar4 = *(ulonglong *)(lVar9 + 0x40);
              local_68 = lVar12;
              uStack_60 = uVar5;
              if ((*(ulonglong *)(lVar9 + 0x48) - uVar4 & 0xfffffffffffffff0) == 0) {
                lVar12 = 0;
              }
              else {
                if (*(ulonglong *)(lVar9 + 0x48) < uVar4) {
                  _invalid_parameter_noinfo();
                }
                if ((lVar12 == 0) || (lVar12 != *plVar3)) {
                  _invalid_parameter_noinfo();
                }
                lVar12 = (longlong)(uVar5 - uVar4) >> 4;
              }
              local_58 = (undefined4)local_68;
              uStack_54 = local_68._4_4_;
              uStack_50 = (undefined4)uStack_60;
              uStack_4c = uStack_60._4_4_;
              FUN_140564460(plVar3,&local_58,1,&local_80);
              uVar4 = *(ulonglong *)(lVar9 + 0x40);
              if (*(ulonglong *)(lVar9 + 0x48) < uVar4) {
                _invalid_parameter_noinfo();
              }
              plVar3 = (longlong *)*plVar3;
              if (plVar3 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar3;
              }
              uVar4 = uVar4 + lVar12 * 0x10;
              if (uVar4 <= *(ulonglong *)(lVar9 + 0x20)) {
                if (plVar3 == (longlong *)0x0) {
                  lVar9 = 0;
                }
                else {
                  lVar9 = *plVar3;
                }
                if (*(ulonglong *)(lVar9 + 0x18) <= uVar4) goto LAB_1405714f7;
              }
              _invalid_parameter_noinfo();
            }
LAB_1405714f7:
            plVar3 = local_78;
            if (local_78 != (longlong *)0x0) {
              LOCK();
              plVar1 = local_78 + 2;
              *(int *)plVar1 = (int)*plVar1 + -1;
              UNLOCK();
              if ((int)*plVar1 == 0) {
                (**(code **)*local_78)(local_78);
                LOCK();
                piVar2 = (int *)((longlong)plVar3 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 == 0) {
                  (**(code **)(*plVar3 + 8))(plVar3);
                }
              }
            }
            iVar13 = iVar13 + 1;
            lVar9 = local_90;
          } while (iVar13 < iVar11);
        }
        local_a4 = local_a4 + 1;
      } while (local_a4 < iVar6);
    }
    plVar3 = local_88;
    *param_1 = 0;
    param_1[1] = 0;
    FUN_140570d20(param_1,lVar9,local_88);
    plVar1 = local_88;
    if (plVar3 != (longlong *)0x0) {
      LOCK();
      plVar3 = plVar3 + 2;
      *(int *)plVar3 = (int)*plVar3 + -1;
      UNLOCK();
      if ((int)*plVar3 == 0) {
        (**(code **)*local_88)(local_88);
        LOCK();
        piVar2 = (int *)((longlong)plVar1 + 0x14);
        *piVar2 = *piVar2 + -1;
        UNLOCK();
        if (*piVar2 == 0) {
          (**(code **)(*local_88 + 8))();
        }
      }
    }
  }
  return param_1;
}

// ==== CMapData::helper_140571650  @140571650  [medium:callgraph-r0]  (orig: FUN_140571650)
undefined4 FUN_140571650(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x18);
}

// ==== CMapData::helper_140571a80  @140571a80  [medium:callgraph-r0]  (orig: FUN_140571a80)
longlong FUN_140571a80(longlong param_1)

{
  return *(longlong *)(param_1 + 0x40) - *(longlong *)(param_1 + 0x38) >> 4;
}

// ==== CMapData::helper_140571d30  @140571d30  [medium:callgraph-r1]  (orig: FUN_140571d30)
void FUN_140571d30(undefined8 *param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)param_1[1];
  if (plVar3 == (longlong *)0x0) {
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  LOCK();
  plVar1 = plVar3 + 2;
  *(int *)plVar1 = (int)*plVar1 + -1;
  UNLOCK();
  if ((int)*plVar1 == 0) {
    (**(code **)*plVar3)(plVar3);
    LOCK();
    piVar2 = (int *)((longlong)plVar3 + 0x14);
    *piVar2 = *piVar2 + -1;
    UNLOCK();
    if (*piVar2 == 0) {
      (**(code **)(*plVar3 + 8))(plVar3);
    }
    param_1[1] = 0;
    *param_1 = 0;
    return;
  }
  param_1[1] = 0;
  *param_1 = 0;
  return;
}

// ==== CMapData::helper_140571f00  @140571f00  [medium:callgraph-r1]  (orig: FUN_140571f00)
void FUN_140571f00(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = std::tr1::_Ref_count_base::vftable;
    puVar1[1] = param_2;
    *(undefined4 *)(puVar1 + 2) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 1;
    *puVar1 = std::tr1::_Ref_count<CTerrainObj>::vftable;
  }
  FUN_14055f8d0(param_1,param_2,puVar1,param_4,uVar2);
  return;
}

// ==== CMapData::helper_140572280  @140572280  [medium:callgraph-r0]  (orig: FUN_140572280)
undefined8 * FUN_140572280(longlong param_1,undefined8 *param_2,int param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  uVar2 = 0;
  if ((ulonglong)(*(longlong *)(param_1 + 0x40) - *(longlong *)(param_1 + 0x38) >> 4) <=
      (ulonglong)(longlong)param_3) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (undefined8 *)((longlong)param_3 * 0x10 + *(longlong *)(param_1 + 0x38));
  *param_2 = 0;
  param_2[1] = 0;
  FUN_140570d20(param_2,*puVar1,puVar1[1],param_4,uVar2,uVar3);
  return param_2;
}

// ==== CMapData::helper_140572640  @140572640  [medium:callgraph-r2]  (orig: FUN_140572640)
void FUN_140572640(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = 0;
      param_1[1] = 0;
      FUN_140570d20(param_1,*param_3,param_3[1]);
    }
    param_1 = param_1 + 2;
  }
  return;
}

// ==== CMapData::helper_140572ba0  @140572ba0  [medium:callgraph-r3]  (orig: FUN_140572ba0)
void FUN_140572ba0(longlong param_1,longlong param_2,ulonglong param_3,longlong *param_4)

{
  int *piVar1;
  longlong *plVar2;
  ulonglong uVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  ulonglong uVar11;
  ulonglong uVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 local_res8;
  longlong local_60;
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  undefined8 local_40;
  
  local_40 = 0xfffffffffffffffe;
  lVar10 = *(longlong *)(param_1 + 0x18);
  if (lVar10 == 0) {
    uVar11 = 0;
  }
  else {
    uVar11 = *(longlong *)(param_1 + 0x28) - lVar10 >> 4;
  }
  uVar12 = 0;
  if (param_3 != 0) {
    lVar10 = *(longlong *)(param_1 + 0x20) - lVar10 >> 4;
    if (0xfffffffffffffffU - lVar10 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1405717a0();
    }
    uVar3 = lVar10 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar11 < uVar3) {
      if (uVar11 <= 0xfffffffffffffff - (uVar11 >> 1)) {
        uVar12 = uVar11 + (uVar11 >> 1);
      }
      if (uVar12 < uVar3) {
        uVar12 = uVar3;
      }
      lVar8 = FUN_140571b70(param_1 + 0x10,uVar12);
      lVar10 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      FUN_140572640(lVar10 * 0x10 + lVar8,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140572730(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar8,
                    param_1 + 0x10,local_res8,0);
      FUN_140572730(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar10 + param_3) * 0x10 + lVar8,param_1 + 0x10,local_res8,0);
      lVar10 = *(longlong *)(param_1 + 0x18);
      lVar5 = *(longlong *)(param_1 + 0x20);
      if (lVar10 != 0) {
        FUN_140572a30(param_1,lVar10,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar12 * 0x10 + lVar8;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar5 - lVar10 >> 4)) * 0x10 + lVar8;
      *(longlong *)(param_1 + 0x18) = lVar8;
    }
    else if ((ulonglong)(*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4) < param_3)
    {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      local_60 = lVar10;
      local_58 = plVar6;
      FUN_140572730(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x10,param_1 + 0x10,local_res8,0);
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = param_3 - (lVar5 - *(longlong *)(param_2 + 8) >> 4);
      FUN_140572640(lVar5,lVar8,&local_60,param_1 + 0x10,local_res8,0,0,lVar5,lVar8);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar5 = *(longlong *)(param_1 + 0x20);
      for (plVar13 = *(longlong **)(param_2 + 8); plVar13 != (longlong *)(lVar5 + param_3 * -0x10);
          plVar13 = plVar13 + 2) {
        if (plVar6 != (longlong *)0x0) {
          LOCK();
          *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
          UNLOCK();
        }
        plVar14 = (longlong *)plVar13[1];
        if (plVar14 != (longlong *)0x0) {
          LOCK();
          plVar7 = plVar14 + 2;
          *(int *)plVar7 = (int)*plVar7 + -1;
          UNLOCK();
          if ((int)*plVar7 == 0) {
            (**(code **)*plVar14)(plVar14);
            LOCK();
            piVar1 = (int *)((longlong)plVar14 + 0x14);
            *piVar1 = *piVar1 + -1;
            UNLOCK();
            if (*piVar1 == 0) {
              (**(code **)(*plVar14 + 8))(plVar14);
            }
          }
        }
        plVar13[1] = (longlong)plVar6;
        *plVar13 = lVar10;
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
    else {
      plVar6 = (longlong *)param_4[1];
      lVar10 = *param_4;
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
        UNLOCK();
      }
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar8 = lVar5 + param_3 * -0x10;
      local_50 = lVar10;
      local_48 = plVar6;
      uVar9 = FUN_140572730(lVar8,lVar5,lVar5,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar9;
      FUN_140572ae0(*(undefined8 *)(param_2 + 8),lVar8,lVar5);
      plVar13 = *(longlong **)(param_2 + 8);
      if (plVar13 != plVar13 + param_3 * 2) {
        plVar14 = plVar13 + 1;
        do {
          if (plVar6 != (longlong *)0x0) {
            LOCK();
            *(int *)(plVar6 + 2) = (int)plVar6[2] + 1;
            UNLOCK();
          }
          plVar7 = (longlong *)*plVar14;
          if (plVar7 != (longlong *)0x0) {
            LOCK();
            plVar2 = plVar7 + 2;
            *(int *)plVar2 = (int)*plVar2 + -1;
            UNLOCK();
            if ((int)*plVar2 == 0) {
              (**(code **)*plVar7)(plVar7);
              LOCK();
              piVar1 = (int *)((longlong)plVar7 + 0x14);
              *piVar1 = *piVar1 + -1;
              UNLOCK();
              if (*piVar1 == 0) {
                (**(code **)(*plVar7 + 8))(plVar7);
              }
            }
          }
          *plVar14 = (longlong)plVar6;
          plVar14[-1] = lVar10;
          plVar7 = plVar14 + 1;
          plVar14 = plVar14 + 2;
        } while (plVar7 != plVar13 + param_3 * 2);
      }
      if (plVar6 != (longlong *)0x0) {
        LOCK();
        plVar13 = plVar6 + 2;
        lVar10 = *plVar13;
        *(int *)plVar13 = (int)*plVar13 + -1;
        UNLOCK();
        if ((int)lVar10 == 1) {
          (**(code **)*plVar6)(plVar6);
          LOCK();
          piVar1 = (int *)((longlong)plVar6 + 0x14);
          iVar4 = *piVar1;
          *piVar1 = *piVar1 + -1;
          UNLOCK();
          if (iVar4 == 1) {
            (**(code **)(*plVar6 + 8))(plVar6);
          }
        }
      }
    }
  }
  return;
}

// ==== CMapData::helper_140573020  @140573020  [medium:callgraph-r2]  (orig: FUN_140573020)
longlong * FUN_140573020(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  longlong lVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar1 = 0;
  uVar3 = param_1[3];
  lVar2 = lVar1;
  if ((param_1[4] - uVar3 & 0xfffffffffffffff0) != 0) {
    if ((ulonglong)param_1[4] < uVar3) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar3) >> 4;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140572ba0(param_1,&local_28,1,param_4);
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar3;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar1;
  }
  else {
    lVar4 = *param_1;
  }
  uVar3 = lVar2 * 0x10 + uVar3;
  if (uVar3 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar1 = *param_1;
    }
    if (*(ulonglong *)(lVar1 + 0x18) <= uVar3) goto LAB_140573117;
  }
  _invalid_parameter_noinfo();
LAB_140573117:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar3;
  return param_2;
}

// ==== CMapData::helper_140573260  @140573260  [medium:callgraph-r1]  (orig: FUN_140573260)
void FUN_140573260(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 4;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 4) < uVar3) {
    FUN_140572640(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x10;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140573020(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMapData::helper_1405733c0  @1405733c0  [medium:callgraph-r0]  (orig: FUN_1405733c0)
undefined8 * FUN_1405733c0(undefined8 *param_1,char *param_2,undefined4 param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  FILE *_File;
  void *pvVar4;
  ulonglong uVar5;
  uint uVar6;
  int local_res20 [2];
  longlong local_68;
  longlong *local_60;
  undefined8 local_58;
  longlong *local_50;
  undefined8 local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  ulonglong uVar7;
  
  uVar7 = 0;
  _File = fopen(param_2,"rb");
  if (_File == (FILE *)0x0) {
    log_InlineLogERROR("CTerrainObj cannot open file %s");
    *param_1 = 0;
    param_1[1] = 0;
    FUN_140571d30(param_1);
  }
  else {
    local_58 = 0;
    local_50 = (longlong *)0x0;
    FUN_1404fa1f0(&local_58,_File,fclose_exref);
    pvVar4 = operator_new(0x50);
    uVar5 = uVar7;
    if (pvVar4 != (void *)0x0) {
      uVar5 = FUN_140573160(pvVar4,param_3);
    }
    local_68 = 0;
    local_60 = (longlong *)0x0;
    FUN_140571f00(&local_68,uVar5);
    if (local_68 == 0) {
      log_InlineLogERROR("CTerrainObj cannot create terrain data");
      *param_1 = 0;
      param_1[1] = 0;
      FUN_140571d30(param_1);
      plVar3 = local_60;
      if (local_60 != (longlong *)0x0) {
        LOCK();
        plVar1 = local_60 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*local_60)(local_60);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*local_60 + 8))();
          }
        }
      }
      plVar3 = local_50;
      if (local_50 != (longlong *)0x0) {
        LOCK();
        plVar1 = local_50 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*local_50)(local_50);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*local_50 + 8))();
          }
        }
      }
    }
    else {
      local_res20[0] = 0;
      fread(local_res20,4,1,_File);
      if (0 < local_res20[0]) {
        do {
          FUN_140571170(&local_38,_File);
          if (local_38 == 0) {
            log_InlineLogERROR("CTerrainObj %s added %d of %d parts");
            *param_1 = 0;
            param_1[1] = 0;
            FUN_140571d30(param_1);
            if (local_30 != (longlong *)0x0) {
              LOCK();
              plVar3 = local_30 + 2;
              *(int *)plVar3 = (int)*plVar3 + -1;
              UNLOCK();
              if ((int)*plVar3 == 0) {
                (**(code **)*local_30)(local_30);
                LOCK();
                piVar2 = (int *)((longlong)local_30 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 == 0) {
                  (**(code **)(*local_30 + 8))(local_30);
                }
              }
            }
            plVar3 = local_60;
            if (local_60 != (longlong *)0x0) {
              LOCK();
              plVar1 = local_60 + 2;
              *(int *)plVar1 = (int)*plVar1 + -1;
              UNLOCK();
              if ((int)*plVar1 == 0) {
                (**(code **)*local_60)(local_60);
                LOCK();
                piVar2 = (int *)((longlong)plVar3 + 0x14);
                *piVar2 = *piVar2 + -1;
                UNLOCK();
                if (*piVar2 == 0) {
                  (**(code **)(*local_60 + 8))();
                }
              }
            }
            plVar3 = local_50;
            if (local_50 == (longlong *)0x0) {
              return param_1;
            }
            LOCK();
            plVar1 = local_50 + 2;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)*plVar1 != 0) {
              return param_1;
            }
            (**(code **)*local_50)(local_50);
            LOCK();
            piVar2 = (int *)((longlong)plVar3 + 0x14);
            *piVar2 = *piVar2 + -1;
            UNLOCK();
            if (*piVar2 != 0) {
              return param_1;
            }
            (**(code **)(*local_50 + 8))();
            return param_1;
          }
          local_48 = 0;
          local_40 = (longlong *)0x0;
          FUN_140570d20(&local_48,local_38,local_30);
          FUN_140573260(local_68 + 0x20,&local_48);
          plVar3 = local_40;
          if (local_40 != (longlong *)0x0) {
            LOCK();
            plVar1 = local_40 + 2;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)*plVar1 == 0) {
              (**(code **)*local_40)(local_40);
              LOCK();
              piVar2 = (int *)((longlong)plVar3 + 0x14);
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (*piVar2 == 0) {
                (**(code **)(*plVar3 + 8))(plVar3);
              }
            }
          }
          plVar3 = local_30;
          if (local_30 != (longlong *)0x0) {
            LOCK();
            plVar1 = local_30 + 2;
            *(int *)plVar1 = (int)*plVar1 + -1;
            UNLOCK();
            if ((int)*plVar1 == 0) {
              (**(code **)*local_30)(local_30);
              LOCK();
              piVar2 = (int *)((longlong)plVar3 + 0x14);
              *piVar2 = *piVar2 + -1;
              UNLOCK();
              if (*piVar2 == 0) {
                (**(code **)(*plVar3 + 8))(plVar3);
              }
            }
          }
          uVar6 = (int)uVar7 + 1;
          uVar7 = (ulonglong)uVar6;
        } while ((int)uVar6 < local_res20[0]);
      }
      plVar3 = local_60;
      *param_1 = 0;
      param_1[1] = 0;
      FUN_14055f8d0(param_1,local_68,local_60);
      plVar1 = local_60;
      if (plVar3 != (longlong *)0x0) {
        LOCK();
        plVar3 = plVar3 + 2;
        *(int *)plVar3 = (int)*plVar3 + -1;
        UNLOCK();
        if ((int)*plVar3 == 0) {
          (**(code **)*local_60)(local_60);
          LOCK();
          piVar2 = (int *)((longlong)plVar1 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*local_60 + 8))();
          }
        }
      }
      plVar3 = local_50;
      if (local_50 != (longlong *)0x0) {
        LOCK();
        plVar1 = local_50 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*local_50)(local_50);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*local_50 + 8))();
          }
        }
      }
    }
  }
  return param_1;
}

// ==== CMapData::helper_1405737c0  @1405737c0  [medium:callgraph-r1]  (orig: FUN_1405737c0)
ushort FUN_1405737c0(ushort *param_1)

{
  return *param_1 >> 1;
}

// ==== CMapData::helper_1405737d0  @1405737d0  [medium:callgraph-r1]  (orig: FUN_1405737d0)
undefined2 FUN_1405737d0(longlong param_1)

{
  return *(undefined2 *)(param_1 + 2);
}

// ==== CMapData::helper_1405737e0  @1405737e0  [medium:callgraph-r1]  (orig: FUN_1405737e0)
bool FUN_1405737e0(byte *param_1)

{
  return (*param_1 & 1) == 1;
}

