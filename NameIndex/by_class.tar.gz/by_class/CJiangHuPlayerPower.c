// ==== CJiangHuPlayerPower::helper_1403feff0  @1403feff0  [medium:callgraph-r0]  (orig: FUN_1403feff0)
void FUN_1403feff0(void *param_1)

{
  if ((DAT_140976338 & 1) == 0) {
    DAT_140976338 = DAT_140976338 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976330,"CJiangHuPlayerPower");
    atexit((_func_5014 *)&LAB_1406d6d40);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403ff045. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976330,param_1);
  return;
}

// ==== CJiangHuPlayerPower::ctor_or_dtor  @140400700  [high:vtable-assign]  (orig: FUN_140400700)
void FUN_140400700(undefined8 *param_1)

{
  *param_1 = CJiangHuPlayerPower::vftable;
  FUN_140157090(param_1 + 2);
  operator_delete((void *)param_1[2]);
  return;
}

// ==== CJiangHuPlayerPower::ctor_or_dtor  @140400740  [high:vtable-assign]  (orig: FUN_140400740)
undefined8 *
FUN_140400740(undefined8 *param_1,undefined4 param_2,undefined4 param_3,undefined1 param_4)

{
  *param_1 = CJiangHuPlayerPower::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  *(undefined4 *)((longlong)param_1 + 0xc) = param_3;
  FUN_140159140(param_1 + 2);
  *(undefined1 *)(param_1 + 10) = 0;
  *(undefined1 *)((longlong)param_1 + 0x51) = 0;
  *(undefined1 *)((longlong)param_1 + 0x52) = 0;
  *(undefined1 *)((longlong)param_1 + 0x53) = 0;
  *(undefined1 *)((longlong)param_1 + 0x54) = param_4;
  FUN_1401543a0(param_1 + 2);
  return param_1;
}

// ==== CJiangHuPlayerPower::ctor_or_dtor  @1404007b0  [high:vtable-assign]  (orig: FUN_1404007b0)
undefined8 * FUN_1404007b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CJiangHuPlayerPower::vftable;
  FUN_140157090(param_1 + 2);
  operator_delete((void *)param_1[2]);
  if ((param_2 & 1) != 0) {
    FUN_1403feff0(param_1);
  }
  return param_1;
}

