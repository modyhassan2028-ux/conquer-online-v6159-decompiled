// ==== CMsgName::ctor_or_dtor  @14037dfb0  [high:vtable-assign]  (orig: FUN_14037dfb0)
undefined8 * FUN_14037dfb0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgName::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x19),0x3f5,true);
  return param_1;
}

// ==== CMsgName::ctor_or_dtor  @14037e030  [high:vtable-assign]  (orig: FUN_14037e030)
void FUN_14037e030(undefined8 *param_1)

{
  *param_1 = CMsgName::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgName::vfunc_1  @14037e070  [high:rtti-vtable]  (orig: FUN_14037e070)
ulonglong FUN_14037e070(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f7);
}

// ==== CMsgName::ctor_or_dtor  @14037e310  [high:vtable-assign]  (orig: FUN_14037e310)
undefined8 * FUN_14037e310(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgName::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgName::vfunc_3  @14037e370  [high:rtti-vtable]  (orig: FUN_14037e370)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14037e370(longlong *param_1)

{
  longlong *plVar1;
  byte bVar2;
  undefined4 *puVar3;
  longlong lVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  uint uVar11;
  undefined8 uVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined1 *puVar15;
  longlong *plVar16;
  char *pcVar17;
  longlong lVar18;
  undefined1 auStack_958 [32];
  undefined4 local_938;
  undefined4 local_930;
  char *local_928;
  undefined8 *local_920;
  char *local_918;
  undefined4 local_910;
  undefined4 local_908;
  longlong *local_8f8;
  longlong *local_8f0;
  undefined8 local_8e8;
  undefined1 local_8d8 [1104];
  char local_488 [40];
  undefined8 local_460;
  undefined8 local_458;
  undefined8 local_450;
  undefined8 local_448;
  undefined4 local_440;
  char local_438 [256];
  char local_338 [255];
  undefined1 local_239;
  char local_238 [255];
  undefined1 local_139;
  char local_138 [255];
  undefined1 local_39;
  ulonglong local_38;
  
  local_8e8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  local_8f0 = param_1;
  uVar12 = FUN_140008520((int)param_1[0x82]);
  plVar13 = (longlong *)FUN_140087650(uVar12);
  plVar13 = (longlong *)(**(code **)(*plVar13 + 0x88))(plVar13);
  if (plVar13 == (longlong *)0x0) {
    if (*(char *)(param_1[0x85] + 8) != '7') {
      return;
    }
  }
  else {
    plVar14 = (longlong *)FUN_1400e1e60();
    lVar4 = plVar13[0x1e2];
    lVar18 = *plVar14;
    puVar3 = (undefined4 *)param_1[0x85];
    uVar6 = (**(code **)(*plVar13 + 8))(plVar13);
    (**(code **)(lVar18 + 0x108))(plVar14,uVar6,(int)lVar4,*puVar3);
  }
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x86),0,local_438,0x100);
  lVar18 = param_1[0x85];
  switch(*(undefined1 *)(lVar18 + 8)) {
  case 1:
    (**(code **)(plVar13[2] + 0x348))(plVar13 + 2,param_1,0);
    break;
  case 2:
    local_938 = 0xac;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!\"NAMEACT_CREATE_SYN\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                      );
    break;
  case 3:
    local_938 = 0xb1;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!\"NAMEACT_SYNDICATE\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                      );
    break;
  case 4:
    local_938 = 0xb6;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!\"NAMEACT_CHANGE_TITLE\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                      );
    break;
  case 5:
    local_938 = 0xbb;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!\"NAMEACT_DELROLE\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                      );
    break;
  case 6:
    local_938 = 0xc0;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","!\"NAMEACT_MATE\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                      );
    break;
  case 7:
    iVar7 = *(int *)(lVar18 + 4);
    if (iVar7 != 0) {
      uVar12 = FUN_140008520((int)param_1[0x82]);
      plVar14 = (longlong *)FUN_1400875f0(uVar12);
      plVar14 = (longlong *)(**(code **)(*plVar14 + 0x30))(plVar14);
      plVar14 = (longlong *)(**(code **)(*plVar14 + 0x40))(plVar14,iVar7);
      if ((plVar14 != (longlong *)0x0) &&
         (cVar5 = (**(code **)(*plVar14 + 0x298))(plVar14,0x1040,&local_8f8), cVar5 != '\0')) {
        uVar12 = (**(code **)(local_8f8[2] + 0x18))();
        iVar7 = FUN_14037e0a0(param_1,7,uVar12,iVar7);
        if (iVar7 != 0) {
          (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,param_1);
        }
      }
    }
    break;
  case 0x10:
    uVar12 = FUN_140008520((int)param_1[0x82]);
    plVar13 = (longlong *)FUN_140087650(uVar12);
    plVar13 = (longlong *)(**(code **)(*plVar13 + 0x98))(plVar13,*(undefined4 *)(param_1[0x85] + 4))
    ;
    if (plVar13 != (longlong *)0x0) {
      lVar18 = param_1[0x85];
      uVar12 = (**(code **)(*plVar13 + 0x40))(plVar13);
      iVar7 = FUN_14037e0a0(param_1,0x10,uVar12,*(undefined4 *)(lVar18 + 4));
      if (iVar7 == 0) {
        local_938 = 0xd8;
        log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                           "Create(NAMEACT_QUERY_MATE, pTarget->GetMateName(), m_pInfo->idTarget)",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                          );
      }
      else {
        (**(code **)(*param_1 + 0x20))(param_1,param_1);
      }
    }
    break;
  case 0x11:
    plVar14 = (longlong *)(**(code **)(plVar13[2] + 0x2a8))(plVar13 + 2,*(undefined4 *)(lVar18 + 4))
    ;
    if (((plVar14 != (longlong *)0x0) &&
        (cVar5 = (**(code **)(*plVar14 + 0x298))(plVar14,0x1040,&local_8f8), cVar5 != '\0')) &&
       (cVar5 = (**(code **)(*local_8f8 + 0xa8))(), cVar5 != '\0')) {
      uVar12 = (**(code **)(*local_8f8 + 0xb0))();
      FUN_140469ab0(uVar12,plVar13);
    }
    break;
  case 0x12:
    FUN_14037dfb0(local_8d8);
    lVar18 = param_1[0x85];
    uVar12 = (**(code **)(plVar13[2] + 0x18))(plVar13 + 2);
    iVar7 = FUN_14037e0a0(local_8d8,0x12,uVar12,*(undefined4 *)(lVar18 + 4));
    if (iVar7 == 0) {
      local_938 = 0xea;
      log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",
                         "msg.Create(NAMEACT_DELDICE_PLAYER, pUser->GetName(), m_pInfo->idTarget)",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                        );
    }
    else {
      (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,local_8d8);
    }
    uVar12 = FUN_140008520((int)param_1[0x82]);
    plVar14 = (longlong *)FUN_1400875f0(uVar12);
    plVar14 = (longlong *)(**(code **)(*plVar14 + 0x20))(plVar14,*(undefined4 *)(param_1[0x85] + 4))
    ;
    if (((plVar14 != (longlong *)0x0) &&
        (cVar5 = (**(code **)(*plVar14 + 0x298))(plVar14,0x1040,&local_8f8), cVar5 != '\0')) &&
       (cVar5 = (**(code **)(*local_8f8 + 0xa8))(), cVar5 != '\0')) {
      uVar12 = (**(code **)(*local_8f8 + 0xb0))();
      FUN_1404689c0(uVar12,plVar13);
    }
    FUN_14037e030(local_8d8);
    break;
  case 0x1a:
    if (local_438[0] != '\0') {
      uVar12 = FUN_140008520((int)param_1[0x82]);
      plVar14 = (longlong *)FUN_140087650(uVar12);
      plVar14 = (longlong *)(**(code **)(*plVar14 + 0x90))(plVar14,local_438,0);
      local_8f8 = plVar14;
      if (plVar14 == (longlong *)0x0) {
        _snprintf(local_138,0x100,"%u",0);
        local_39 = 0;
        FUN_14037e280(param_1,local_138);
        (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,param_1);
      }
      else {
        local_488[0] = '\0';
        local_488[1] = '\0';
        local_488[2] = '\0';
        local_488[3] = '\0';
        local_488[4] = '\0';
        local_488[5] = '\0';
        local_488[6] = '\0';
        local_488[7] = '\0';
        local_488[8] = '\0';
        local_488[9] = '\0';
        local_488[10] = '\0';
        local_488[0xb] = '\0';
        local_488[0xc] = '\0';
        local_488[0xd] = '\0';
        local_488[0xe] = '\0';
        local_488[0xf] = '\0';
        local_488[0x10] = '\0';
        local_488[0x11] = '\0';
        local_488[0x12] = '\0';
        local_488[0x13] = '\0';
        local_488[0x14] = '\0';
        local_488[0x15] = '\0';
        local_488[0x16] = '\0';
        local_488[0x17] = '\0';
        local_488[0x18] = '\0';
        local_488[0x19] = '\0';
        local_488[0x1a] = '\0';
        local_488[0x1b] = '\0';
        local_488[0x1c] = '\0';
        local_488[0x1d] = '\0';
        local_488[0x1e] = '\0';
        local_488[0x1f] = '\0';
        local_488[0x20] = '\0';
        local_488[0x21] = '\0';
        local_488[0x22] = '\0';
        local_488[0x23] = '\0';
        plVar1 = plVar14 + 2;
        iVar7 = (**(code **)(*plVar1 + 0x170))(plVar1);
        if (iVar7 != 0) {
          plVar16 = (longlong *)FUN_140087ed0();
          pcVar17 = (char *)(**(code **)(*plVar16 + 0x290))(plVar16);
          if (pcVar17 != (char *)0x0) {
            tq::SafeCopy(local_488,pcVar17,0x24);
          }
        }
        local_460 = 0;
        local_458 = 0;
        local_450 = 0;
        local_448 = 0;
        local_440 = 0;
        memset(local_238,0,0x100);
        uVar6 = (**(code **)(*plVar14 + 0x50))(plVar14);
        uVar9 = (**(code **)(*plVar1 + 0x198))(plVar1);
        uVar12 = (**(code **)(*plVar14 + 0x40))(plVar14);
        uVar10 = FUN_14018eb30(plVar14);
        uVar8 = (**(code **)(*plVar1 + 0x70))(plVar1);
        uVar11 = (**(code **)(*local_8f8 + 8))();
        local_920 = &local_460;
        local_928 = local_488;
        local_938 = uVar8;
        local_930 = uVar10;
        local_918 = (char *)uVar12;
        local_910 = uVar9;
        local_908 = uVar6;
        _snprintf(local_238,0x100,"%u %d %d #%s #%s %s %d %d",(ulonglong)uVar11);
        local_139 = 0;
        FUN_14037e280(param_1,local_238);
        (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,param_1);
      }
    }
    break;
  case 0x1d:
    if (local_438[0] != '\0') {
      uVar12 = FUN_140008520((int)param_1[0x82]);
      plVar14 = (longlong *)FUN_140087650(uVar12);
      plVar14 = (longlong *)(**(code **)(*plVar14 + 0x90))(plVar14,local_438,0);
      if (plVar14 != (longlong *)0x0) {
        memset(local_338,0,0x100);
        bVar2 = *(byte *)((longlong)plVar14 + 0xeee);
        uVar6 = (**(code **)(*plVar14 + 0x50))(plVar14);
        uVar9 = (**(code **)(plVar14[2] + 0x30))(plVar14 + 2);
        uVar10 = (**(code **)(plVar14[2] + 0x70))(plVar14 + 2);
        uVar11 = (**(code **)(*plVar14 + 8))(plVar14);
        local_918 = local_438;
        local_920 = (undefined8 *)CONCAT44(local_920._4_4_,(uint)bVar2);
        local_928 = (char *)CONCAT44(local_928._4_4_,uVar6);
        local_938 = uVar10;
        local_930 = uVar9;
        _snprintf(local_338,0x100,"%u %u %u %d %u %s",(ulonglong)uVar11);
        local_239 = 0;
        FUN_14037e280(param_1,local_338);
        (**(code **)(plVar13[2] + 0x350))(plVar13 + 2,param_1);
      }
    }
    break;
  case 0x32:
    if (((plVar13 != (longlong *)0x0) &&
        (cVar5 = (**(code **)(plVar13[2] + 0x230))(plVar13 + 2), cVar5 != '\0')) &&
       (local_438[0] != '\0')) {
      uVar12 = FUN_140008520((int)param_1[0x82]);
      plVar14 = (longlong *)FUN_140087650(uVar12);
      lVar18 = (**(code **)(*plVar14 + 0x90))(plVar14,local_438,0);
      if (lVar18 == 0) {
        (**(code **)(plVar13[2] + 0x358))(plVar13 + 2,&DAT_14075c170);
      }
      else {
        FUN_1401786a0(lVar18);
      }
    }
    break;
  case 0x37:
    if (*(int *)((longlong)param_1 + 0x414) == 0x10000) {
      puVar15 = DAT_140975bd8;
      if (DAT_140975bd8 == (undefined1 *)0x0) {
        local_938 = 0x3ce;
        log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pGm",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                          );
        puVar15 = (undefined1 *)0x0;
      }
      *puVar15 = 1;
    }
    else {
      local_938 = 0x94;
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","bFlag",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgname.cpp"
                        );
    }
  }
  return;
}

// ==== CMsgName::helper_1404640a0  @1404640a0  [medium:callgraph-r3]  (orig: FUN_1404640a0)
void FUN_1404640a0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_70,"invalid vector<T> subscript");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_1409445a0);
}

// ==== CMsgName::helper_140465290  @140465290  [medium:callgraph-r2]  (orig: FUN_140465290)
longlong FUN_140465290(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  
  lVar1 = param_3 + ((param_2 - param_1) / 0x18) * 0x18;
  if (param_1 != param_2) {
    param_1 = param_1 - param_3;
    do {
      FUN_140097920(param_3);
      FUN_140362c00(param_3,param_1 + param_3);
      param_3 = param_3 + 0x18;
    } while (param_1 + param_3 != param_2);
  }
  return lVar1;
}

// ==== CMsgName::helper_140465380  @140465380  [medium:callgraph-r3]  (orig: FUN_140465380)
void FUN_140465380(undefined8 *param_1,longlong param_2,undefined8 param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = 0;
      param_1[1] = 0;
      param_1[2] = 0;
      FUN_140362c00(param_1,param_3);
    }
    param_1 = param_1 + 3;
  }
  return;
}

// ==== CMsgName::helper_140465570  @140465570  [medium:callgraph-r2]  (orig: FUN_140465570)
ulonglong FUN_140465570(longlong *param_1,ulonglong param_2)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[3];
  if ((ulonglong)((longlong)(param_1[4] - uVar1) / 0x18) <= param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_1404640a0();
  }
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 + param_2 * 0x18;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14046561e;
  }
  _invalid_parameter_noinfo();
LAB_14046561e:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMsgName::helper_1404670d0  @1404670d0  [medium:callgraph-r1]  (orig: FUN_1404670d0)
undefined8 FUN_1404670d0(longlong param_1,int param_2)

{
  longlong *plVar1;
  ulonglong *puVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  ulonglong uVar7;
  uint uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined1 local_res10;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar6 = *(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20);
  uVar11 = 0;
  iVar4 = (int)(lVar6 >> 0x3f);
  iVar5 = (int)(lVar6 / 0x18) + iVar4;
  uVar7 = uVar11;
  uVar9 = uVar11;
  uVar10 = uVar11;
  if (iVar5 != iVar4 && -1 < iVar5 - iVar4) {
    do {
      if ((ulonglong)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18) <=
          uVar10) {
        _invalid_parameter_noinfo();
      }
      plVar1 = *(longlong **)(uVar7 + *(longlong *)(param_1 + 0x20));
      if ((plVar1 != (longlong *)0x0) && (iVar5 = (**(code **)(*plVar1 + 8))(), iVar5 == param_2)) {
        uVar7 = *(ulonglong *)(param_1 + 0x20);
        if (*(ulonglong *)(param_1 + 0x28) < uVar7) {
          _invalid_parameter_noinfo();
        }
        puVar2 = *(ulonglong **)(param_1 + 8);
        if (puVar2 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar10 = uVar11;
        }
        else {
          uVar10 = *puVar2;
        }
        uVar7 = uVar7 + (longlong)(int)uVar9 * 0x18;
        if (uVar7 <= *(ulonglong *)(uVar10 + 0x20)) {
          if (puVar2 != (ulonglong *)0x0) {
            uVar11 = *puVar2;
          }
          if (*(ulonglong *)(uVar11 + 0x18) <= uVar7) goto LAB_140467239;
        }
        _invalid_parameter_noinfo();
LAB_140467239:
        FUN_140465290(uVar7 + 0x18,*(undefined8 *)(param_1 + 0x28),uVar7,local_res10,local_res10,0);
        lVar3 = *(longlong *)(param_1 + 0x28);
        for (lVar6 = lVar3 + -0x18; lVar6 != lVar3; lVar6 = lVar6 + 0x18) {
          FUN_140097920(lVar6);
        }
        *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -0x18;
        if ((uVar7 < *(ulonglong *)(param_1 + 0x20)) || (*(ulonglong *)(param_1 + 0x28) < uVar7)) {
          _invalid_parameter_noinfo();
        }
        return 1;
      }
      uVar8 = (int)uVar9 + 1;
      uVar7 = uVar7 + 0x18;
      uVar9 = (ulonglong)uVar8;
      uVar10 = uVar10 + 1;
    } while ((int)uVar8 <
             (int)((*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x18));
  }
  return 0;
}

// ==== CMsgName::helper_1404674c0  @1404674c0  [medium:callgraph-r1]  (orig: FUN_1404674c0)
bool FUN_1404674c0(longlong *param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  ulonglong *puVar3;
  longlong lVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong lVar9;
  uint uVar10;
  ulonglong uVar12;
  ulonglong uVar11;
  
  if ((int)param_1[1] < 0) {
    param_1[2] = 0;
    return false;
  }
  uVar12 = 0;
  uVar11 = uVar12;
  while (uVar10 = (int)uVar11 + 1, uVar11 = (ulonglong)uVar10, uVar10 < 0xf4241) {
    plVar7 = (longlong *)FUN_140465570(*param_1,(longlong)(int)param_1[1]);
    lVar1 = *plVar7;
    param_1[2] = lVar1;
    if (lVar1 == 0) {
      plVar7 = (longlong *)*param_1;
      uVar2 = plVar7[3];
      if ((ulonglong)plVar7[4] < uVar2) {
        _invalid_parameter_noinfo();
      }
      puVar3 = (ulonglong *)*plVar7;
      lVar1 = param_1[1];
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar8 = uVar12;
      }
      else {
        uVar8 = *puVar3;
      }
      uVar2 = uVar2 + (longlong)(int)lVar1 * 0x18;
      if (*(ulonglong *)(uVar8 + 0x20) < uVar2) {
LAB_14046758b:
        _invalid_parameter_noinfo();
      }
      else {
        uVar8 = uVar12;
        if (puVar3 != (ulonglong *)0x0) {
          uVar8 = *puVar3;
        }
        if (uVar2 < *(ulonglong *)(uVar8 + 0x18)) goto LAB_14046758b;
      }
      lVar1 = *param_1;
      uVar8 = *(ulonglong *)(lVar1 + 0x20);
      uVar5 = uVar2;
      while (uVar6 = uVar5 + 0x18, uVar6 != uVar8) {
        FUN_140097920(uVar5);
        FUN_140362c00(uVar5,uVar6);
        uVar5 = uVar6;
      }
      lVar4 = *(longlong *)(lVar1 + 0x20);
      for (lVar9 = lVar4 + -0x18; lVar9 != lVar4; lVar9 = lVar9 + 0x18) {
        FUN_140097920(lVar9);
      }
      *(longlong *)(lVar1 + 0x20) = *(longlong *)(lVar1 + 0x20) + -0x18;
      if ((uVar2 < *(ulonglong *)(lVar1 + 0x18)) || (*(ulonglong *)(lVar1 + 0x20) < uVar2)) {
        _invalid_parameter_noinfo();
      }
    }
    plVar7 = param_1 + 1;
    *(int *)plVar7 = (int)*plVar7 + -1;
    if (((int)*plVar7 < 0) || (param_1[2] != 0)) goto LAB_140467635;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_140467635:
  return param_1[2] != 0;
}

// ==== CMsgName::helper_140468860  @140468860  [medium:callgraph-r3]  (orig: FUN_140468860)
longlong * FUN_140468860(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar5 = param_1[4] - uVar1;
  lVar3 = 0;
  lVar2 = lVar5 >> 0x3f;
  lVar4 = lVar3;
  if (lVar5 / 0x18 + lVar2 != lVar2) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar1) / 6 + ((longlong)(param_3[1] - uVar1) >> 0x3f);
    lVar4 = (lVar2 >> 2) - (lVar2 >> 0x3f);
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1404677d0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 + lVar4 * 0x18;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    if (*(ulonglong *)(lVar3 + 0x18) <= uVar1) goto LAB_140468984;
  }
  _invalid_parameter_noinfo();
LAB_140468984:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgName::helper_1404689c0  @1404689c0  [medium:callgraph-r0]  (orig: FUN_1404689c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404689c0(int *param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  int *piVar9;
  undefined8 uVar10;
  uint uVar11;
  undefined1 auStack_4f8 [32];
  undefined4 local_4d8;
  int local_4c8;
  ulonglong local_4c0;
  longlong *local_4b8;
  int *local_4b0;
  int local_4a8;
  longlong local_4a0;
  int *local_498;
  undefined8 local_490;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  local_4b8 = param_2;
  local_498 = param_1;
  if (param_2 == (longlong *)0x0) {
    local_4d8 = 0x8b;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    lVar5 = FUN_140464b50(param_1 + 2,uVar2);
    uVar10 = 0;
    if (lVar5 != 0) {
      if (*param_1 == 1) {
        plVar6 = (longlong *)FUN_140463d30(param_1 + 0x10);
        uVar7 = (**(code **)(*plVar6 + 0x10))(plVar6);
        while( true ) {
          uVar7 = uVar7 - 1;
          local_4c0 = uVar7;
          if (*(longlong *)(param_1 + 0x10) == 0) {
            local_4d8 = 0x1c;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar8 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
          if (uVar8 <= uVar7) break;
          if (*(longlong *)(param_1 + 0x10) == 0) {
            local_4d8 = 0x1c;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          piVar9 = (int *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x18))
                                    (*(longlong **)(param_1 + 0x10),uVar7);
          if (piVar9 == (int *)0x0) {
            local_4d8 = 0x9a;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            iVar4 = *piVar9;
            iVar3 = (**(code **)(*param_2 + 8))(param_2);
            if (iVar4 == iVar3) {
              FUN_140455ef0(local_488);
              uVar2 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
              iVar4 = FUN_140455f70(local_488,2,uVar2);
              if ((iVar4 != 0) && (iVar4 = FUN_140455ff0(local_488,piVar9[1],piVar9[2]), iVar4 != 0)
                 ) {
                FUN_140467d50(param_1,local_488,param_2);
              }
              iVar4 = piVar9[2];
              local_4c8 = iVar4;
              if (iVar4 < 1) {
                local_4d8 = 0xa5;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              if (*(longlong *)(param_1 + 0x10) == 0) {
                local_4d8 = 0x1c;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              plVar6 = *(longlong **)(param_1 + 0x10);
              iVar3 = piVar9[1];
              lVar5 = *plVar6;
              uVar2 = (**(code **)(*param_2 + 8))(param_2);
              (**(code **)(lVar5 + 0x30))(plVar6,uVar2,iVar3);
              (**(code **)(*param_2 + 0x180))(param_2,(longlong)iVar4,1);
              param_1[0x18] = param_1[0x18] - iVar4;
              FUN_140455f40(local_488);
            }
          }
        }
      }
      else if (*param_1 != 2) {
        log_InlineLogERROR(&DAT_140783808);
      }
      uVar2 = (**(code **)(*param_2 + 8))(param_2);
      FUN_1404670d0(param_1 + 2,uVar2);
      local_4b0 = param_1 + 4;
      iVar4 = (int)(*(longlong *)(param_1 + 0xc) - *(longlong *)(param_1 + 10) >> 0x3f);
      if ((int)((*(longlong *)(param_1 + 0xc) - *(longlong *)(param_1 + 10)) / 0x18) + iVar4 ==
          iVar4) {
        *param_1 = 0;
      }
      uVar11 = 0;
      local_4a8 = (int)((*(longlong *)(param_1 + 0xc) - *(longlong *)(param_1 + 10)) / 0x18) + -1;
      local_4a0 = 0;
      cVar1 = FUN_1404674c0(&local_4b0);
      lVar5 = local_4a0;
      while (cVar1 != '\0') {
        uVar11 = uVar11 + 1;
        local_4a0 = lVar5;
        if (1000000 < uVar11) {
          local_4d8 = 0xc0;
          log_InlineLogERROR(&DAT_1406d9c10);
          break;
        }
        if (lVar5 == 0) {
          local_4d8 = 0xc2;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          FUN_14037dfb0(local_488);
          uVar2 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
          uVar10 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          iVar4 = FUN_14037e0a0(local_488,0x12,uVar10,uVar2);
          if (iVar4 != 0) {
            (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x350))((longlong *)(lVar5 + 0x10),local_488)
            ;
          }
          FUN_14037e030(local_488);
        }
        cVar1 = FUN_1404674c0(&local_4b0);
        lVar5 = local_4a0;
      }
      uVar10 = 1;
    }
  }
  return uVar10;
}

// ==== CMsgName::helper_1404698c0  @1404698c0  [medium:callgraph-r2]  (orig: FUN_1404698c0)
void FUN_1404698c0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar4 = 0;
  }
  else {
    lVar3 = (longlong)(param_1[5] - uVar1) / 6 + ((longlong)(param_1[5] - uVar1) >> 0x3f);
    uVar4 = (lVar3 >> 2) - (lVar3 >> 0x3f);
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x18) < uVar4) {
    FUN_140465380(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x18;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_140468860(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgName::helper_1404699c0  @1404699c0  [medium:callgraph-r1]  (orig: FUN_1404699c0)
undefined8 FUN_1404699c0(longlong param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  
  if ((longlong *)*param_2 != (longlong *)0x0) {
    iVar2 = (**(code **)(*(longlong *)*param_2 + 8))();
    if (iVar2 != 0) {
      if (*param_2 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar3 = (**(code **)(*(longlong *)*param_2 + 8))();
      cVar1 = FUN_1404670d0(param_1,uVar3);
      if (cVar1 != '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_1404698c0(param_1 + 8,param_2);
      return 1;
    }
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgName::helper_140469ab0  @140469ab0  [medium:callgraph-r0]  (orig: FUN_140469ab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140469ab0(int *param_1,longlong *param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  ulonglong uVar9;
  int *piVar10;
  ulonglong uVar11;
  uint uVar12;
  undefined1 auStack_d88 [32];
  undefined4 local_d68;
  int *local_d58;
  longlong *local_d50;
  longlong *local_d48;
  int *local_d40;
  int local_d38;
  longlong *local_d30;
  undefined8 local_d28;
  undefined1 local_d18 [1072];
  undefined1 local_8e8 [1104];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_d28 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_d88;
  local_d48 = param_2;
  if (param_2 == (longlong *)0x0) {
    local_d68 = 0x41;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  piVar10 = param_1 + 2;
  local_d58 = piVar10;
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  lVar6 = FUN_140464b50(piVar10,uVar3);
  if (lVar6 != 0) {
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    FUN_1404670d0(piVar10,uVar3);
  }
  FUN_14037dfb0(local_8e8);
  param_2 = param_2 + 2;
  local_d50 = param_2;
  uVar3 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
  uVar7 = (**(code **)(*param_2 + 0x18))(param_2);
  iVar4 = FUN_14037e0a0(local_8e8,0x11,uVar7,uVar3);
  if (iVar4 == 0) {
    local_d68 = 0x48;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_2 + 0x350))(param_2,local_8e8);
  }
  iVar4 = *param_1;
  if (iVar4 == 0) {
    *param_1 = 1;
    param_1[0x12] = 0x32;
    plVar8 = (longlong *)FUN_140463d30(param_1 + 0x10);
    (**(code **)(*plVar8 + 0x48))(plVar8);
  }
  else if (iVar4 != 1) {
    if (iVar4 == 2) {
      FUN_140455ef0(local_d18);
      uVar3 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
      iVar4 = FUN_140455f70(local_d18,5,uVar3);
      if (iVar4 == 0) {
        local_d68 = 0x5d;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*param_2 + 0x350))(param_2,local_d18);
      }
      FUN_140455f40(local_d18);
    }
    else {
      log_InlineLogERROR(&DAT_140783ac0);
    }
    goto LAB_140469d1c;
  }
  FUN_140455ef0(local_d18);
  uVar3 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
  iVar4 = FUN_140455f70(local_d18,4,uVar3,param_1[0x12]);
  if (iVar4 == 0) {
    local_d68 = 0x56;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_2 + 0x350))(param_2,local_d18);
  }
  FUN_140455f40(local_d18);
LAB_140469d1c:
  local_d40 = param_1 + 4;
  local_d38 = (int)((*(longlong *)(param_1 + 0xc) - *(longlong *)(param_1 + 10)) / 0x18) + -1;
  local_d30 = (longlong *)0x0;
  uVar12 = 0;
  cVar2 = FUN_1404674c0(&local_d40);
  plVar8 = local_d30;
  do {
    local_d30 = plVar8;
    if (cVar2 == '\0') {
LAB_140469ff1:
      FUN_1404699c0(piVar10,local_d48 + 0x242);
      FUN_14037e030(local_8e8);
      return 1;
    }
    uVar12 = uVar12 + 1;
    if (1000000 < uVar12) {
      local_d68 = 0x69;
      log_InlineLogERROR(&DAT_1406d9c10);
      piVar10 = local_d58;
      goto LAB_140469ff1;
    }
    if (plVar8 == (longlong *)0x0) {
      local_d68 = 0x6b;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_14037dfb0(local_498);
      uVar3 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
      uVar7 = (**(code **)(plVar8[2] + 0x18))(plVar8 + 2);
      iVar4 = FUN_14037e0a0(local_498,0x11,uVar7,uVar3);
      if (iVar4 != 0) {
        (**(code **)(*param_2 + 0x350))(param_2,local_498);
      }
      FUN_14037e030(local_498);
    }
    FUN_140455ef0(local_d18);
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x16) + 8))();
    iVar4 = FUN_140455f70(local_d18,0,uVar3,0);
    if (iVar4 == 0) {
      local_d68 = 0x72;
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_140455f40(local_d18);
      FUN_14037e030(local_8e8);
      return 0;
    }
    bVar1 = false;
    uVar11 = 0;
    while( true ) {
      if (*(longlong *)(param_1 + 0x10) == 0) {
        local_d68 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar9 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
      param_2 = local_d50;
      if (uVar9 <= uVar11) break;
      if (*(longlong *)(param_1 + 0x10) == 0) {
        local_d68 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      piVar10 = (int *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x18))
                                 (*(longlong **)(param_1 + 0x10),uVar11);
      if (piVar10 == (int *)0x0) {
        local_d68 = 0x77;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar4 = *piVar10;
        iVar5 = (**(code **)(*plVar8 + 8))(plVar8);
        if ((iVar4 == iVar5) && (iVar4 = FUN_140455ff0(local_d18,piVar10[1],piVar10[2]), iVar4 != 0)
           ) {
          bVar1 = true;
        }
      }
      uVar11 = uVar11 + 1;
    }
    if (bVar1) {
      (**(code **)(*local_d50 + 0x350))(local_d50,local_d18);
    }
    FUN_140455f40(local_d18);
    cVar2 = FUN_1404674c0(&local_d40);
    piVar10 = local_d58;
    plVar8 = local_d30;
  } while( true );
}

