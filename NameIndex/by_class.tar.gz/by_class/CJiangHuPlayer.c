// ==== CJiangHuPlayer::helper_1403fdc00  @1403fdc00  [medium:callgraph-r0]  (orig: FUN_1403fdc00)
void FUN_1403fdc00(__uint64 param_1)

{
  if ((DAT_140976318 & 1) == 0) {
    DAT_140976318 = DAT_140976318 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976310,"CJiangHuPlayer");
    atexit((_func_5014 *)&LAB_1406d6d20);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403fdc55. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976310,param_1);
  return;
}

// ==== CJiangHuPlayer::helper_1403fdc60  @1403fdc60  [medium:callgraph-r0]  (orig: FUN_1403fdc60)
void FUN_1403fdc60(void *param_1)

{
  if ((DAT_140976318 & 1) == 0) {
    DAT_140976318 = DAT_140976318 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976310,"CJiangHuPlayer");
    atexit((_func_5014 *)&LAB_1406d6d20);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403fdcb5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976310,param_1);
  return;
}

// ==== CJiangHuPlayer::ctor_or_dtor  @1403fdd60  [high:vtable-assign]  (orig: FUN_1403fdd60)
undefined8 * FUN_1403fdd60(undefined8 *param_1,byte param_2)

{
  *param_1 = CJiangHuPlayer::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403fdc60();
  }
  return param_1;
}

// ==== CJiangHuPlayer::ctor_or_dtor  @1403fdd90  [high:vtable-assign]  (orig: FUN_1403fdd90)
undefined8 * FUN_1403fdd90(undefined4 param_1,int param_2,longlong param_3,undefined1 param_4)

{
  undefined8 *puVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  else {
    puVar1 = (undefined8 *)FUN_1403fdc00();
    if (puVar1 == (undefined8 *)0x0) {
      puVar1 = (undefined8 *)0x0;
    }
    else {
      *puVar1 = CJiangHuPlayer::vftable;
      *(undefined4 *)(puVar1 + 1) = param_1;
      *(int *)((longlong)puVar1 + 0xc) = param_2;
      puVar1[2] = param_3;
      *(undefined4 *)(puVar1 + 3) = 0;
      *(undefined4 *)((longlong)puVar1 + 0x24) = 0;
      *(undefined1 *)(puVar1 + 6) = param_4;
      *(undefined4 *)(puVar1 + 4) = 0;
      *(undefined4 *)((longlong)puVar1 + 0x1c) = 0;
      *(undefined4 *)((longlong)puVar1 + 0x2c) = 0;
      *(undefined4 *)(puVar1 + 5) = 0;
    }
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      puVar1 = (undefined8 *)0x0;
    }
  }
  return puVar1;
}

