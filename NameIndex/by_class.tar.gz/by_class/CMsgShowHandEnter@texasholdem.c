// ==== CMsgShowHandEnter@texasholdem::helper_14031bf40  @14031bf40  [medium:callgraph-r1]  (orig: FUN_14031bf40)
undefined8 FUN_14031bf40(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x78);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x78);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x48);
  if (*(longlong *)(param_1 + 0x48) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x78);
    local_28 = *(longlong *)(param_1 + 0x48);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x78);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMsgShowHandEnter@texasholdem::helper_14031c5a0  @14031c5a0  [medium:callgraph-r0]  (orig: FUN_14031c5a0)
undefined8 FUN_14031c5a0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_3);
  if ((lVar1 != 0) && (lVar1 = FUN_14031bf40(param_1,param_2), lVar1 != 0)) {
    uVar2 = FUN_1404bf6c0(lVar1,param_3);
    return uVar2;
  }
  return 0;
}

// ==== CMsgShowHandEnter@texasholdem::vfunc_1  @140453240  [high:rtti-vtable]  (orig: FUN_140453240)
undefined8 FUN_140453240(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandEnter@texasholdem::vfunc_0  @1404532f0  [high:rtti-vtable]  (orig: FUN_1404532f0)
undefined8 * FUN_1404532f0(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandEnter::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandEnter@texasholdem::vfunc_3  @140453340  [high:rtti-vtable]  (orig: FUN_140453340)
void FUN_140453340(longlong param_1)

{
  short sVar1;
  int iVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))(*(longlong **)(lVar5 + 0x90),param_1)
  ;
  if ((plVar6 != (longlong *)0x0) && (iVar2 = (int)plVar6[0x248], iVar2 != 0)) {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar5 = *(longlong *)(lVar5 + 0x108);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    cVar3 = FUN_140215360(lVar5,plVar6,iVar2);
    if (cVar3 != '\0') {
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar7 = FUN_140087830(uVar7);
      lVar5 = FUN_140214ce0(uVar7,iVar2);
      if (lVar5 != 0) {
        sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 1);
        if (sVar1 == 1) {
          cVar3 = FUN_1403bc2d0(lVar5);
          if (cVar3 != '\0') {
            uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
            uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            uVar7 = FUN_1401600a0(uVar7);
            cVar3 = FUN_14031c5a0(uVar7,iVar2,uVar4);
            if (cVar3 == '\0') {
              return;
            }
          }
          FUN_1403e26a0(lVar5,plVar6,1,*(undefined1 *)(*(longlong *)(param_1 + 0x428) + 3));
        }
        else if ((sVar1 == 2) && (cVar3 = FUN_1403bc2d0(lVar5), cVar3 == '\0')) {
          FUN_1403d8ec0(lVar5,iVar2,plVar6,*(undefined1 *)(*(longlong *)(param_1 + 0x428) + 3),1);
        }
      }
    }
  }
  return;
}

// ==== CMsgShowHandEnter@texasholdem::helper_1404bf6c0  @1404bf6c0  [medium:callgraph-r1]  (orig: FUN_1404bf6c0)
bool FUN_1404bf6c0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x21);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0x38);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

