// ==== CWinApp::method_14001d8c0  @14001d8c0  [medium:param1-type]  (orig: FUN_14001d8c0)
void FUN_14001d8c0(CWinApp *param_1)

{
  CWinApp::~CWinApp(param_1);
  return;
}

