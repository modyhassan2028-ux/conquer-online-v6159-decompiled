// ==== CMsgTotalPowerValueSort::helper_1401d8e10  @1401d8e10  [medium:callgraph-r0]  (orig: FUN_1401d8e10)
void FUN_1401d8e10(longlong param_1,longlong param_2)

{
  if ((param_2 != 0) && (*(longlong *)(param_1 + 0x30) != 0)) {
    FUN_1403fc5d0();
  }
  return;
}

// ==== CMsgTotalPowerValueSort::helper_1403fbc40  @1403fbc40  [medium:callgraph-r2]  (orig: FUN_1403fbc40)
undefined1 FUN_1403fbc40(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined1 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x70))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x70);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x70);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x40);
  if (*(longlong *)(param_1 + 0x40) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x70);
    local_28 = *(longlong *)(param_1 + 0x40);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x70);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x40))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined1 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CMsgTotalPowerValueSort::helper_1403fc5d0  @1403fc5d0  [medium:callgraph-r1]  (orig: FUN_1403fc5d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403fc5d0(longlong param_1,longlong *param_2,byte param_3)

{
  longlong *plVar1;
  char *pcVar2;
  ulonglong uVar3;
  int iVar4;
  longlong *plVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  char *pcVar9;
  longlong lVar10;
  char cVar11;
  ulonglong uVar12;
  undefined1 auStack_508 [32];
  byte local_4e8;
  undefined1 local_4e7;
  char local_4e6;
  int local_4e4;
  longlong *local_4e0;
  ulonglong local_4d8;
  longlong *local_4d0;
  longlong *local_4c0;
  undefined8 local_4b0;
  char local_4a8;
  undefined4 local_4a7;
  undefined4 local_4a3;
  char local_49f [39];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_4b0 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
    local_4e8 = param_3;
    local_4e0 = param_2;
    uVar7 = (**(code **)(*param_2 + 8))(param_2);
    local_4e7 = FUN_1403fbc40(param_1,uVar7);
    uVar3 = (*(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20)) / 0x2c;
    uVar12 = 100;
    if (uVar3 < 100) {
      uVar12 = uVar3;
    }
    pcVar9 = *(char **)(param_1 + 0x20);
    local_4c0 = (longlong *)0x0;
    local_4d8 = uVar12;
    if (*(char **)(param_1 + 0x28) < pcVar9) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(param_1 + 8);
    pcVar2 = *(char **)(param_1 + 0x28);
    local_4d0 = (longlong *)0x0;
    local_4c0 = plVar1;
    if (pcVar2 < *(char **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    local_4d0 = *(longlong **)(param_1 + 8);
    iVar8 = 1;
    local_4e4 = 1;
    cVar11 = '\x01';
    local_4e6 = '\x01';
    FUN_1404503d0(local_478);
    cVar6 = FUN_140450490(local_478,local_4e7,local_4e8,uVar12 & 0xff);
    plVar5 = local_4d0;
    if (cVar6 == '\0') {
      FUN_140450420(local_478);
    }
    else {
      while( true ) {
        if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar5)) {
          _invalid_parameter_noinfo();
        }
        if (pcVar9 == pcVar2) break;
        iVar4 = ((uint)local_4e8 + (uint)local_4e8 * 4) * 2;
        if ((iVar4 + -9 <= iVar8) && (iVar8 <= iVar4)) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar1;
          }
          if (*(char **)(lVar10 + 0x20) <= pcVar9) {
            _invalid_parameter_noinfo();
          }
          local_49f[0] = '\0';
          local_49f[1] = '\0';
          local_49f[2] = '\0';
          local_49f[3] = '\0';
          local_49f[4] = '\0';
          local_49f[5] = '\0';
          local_49f[6] = '\0';
          local_49f[7] = '\0';
          local_49f[8] = '\0';
          local_49f[9] = '\0';
          local_49f[10] = '\0';
          local_49f[0xb] = '\0';
          local_49f[0xc] = '\0';
          local_49f[0xd] = '\0';
          local_49f[0xe] = '\0';
          local_49f[0xf] = '\0';
          local_49f[0x10] = '\0';
          local_49f[0x11] = '\0';
          local_49f[0x12] = '\0';
          local_49f[0x13] = '\0';
          local_49f[0x14] = '\0';
          local_49f[0x15] = '\0';
          local_49f[0x16] = '\0';
          local_49f[0x17] = '\0';
          local_49f[0x18] = '\0';
          local_49f[0x19] = '\0';
          local_49f[0x1a] = '\0';
          local_49f[0x1b] = '\0';
          local_49f[0x1c] = '\0';
          local_49f[0x1d] = '\0';
          local_49f[0x1e] = '\0';
          local_49f[0x1f] = '\0';
          local_4a7 = *(undefined4 *)(pcVar9 + 0x10);
          local_4a3 = *(undefined4 *)(pcVar9 + 0x28);
          local_4a8 = cVar11;
          tq::SafeCopy(local_49f,pcVar9 + 0x18,0x10);
          tq::SafeCopy(local_49f + 0x10,pcVar9,0x10);
          cVar6 = FUN_140450590(local_478,&local_4a8);
          if (cVar6 == '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
            FUN_140450540(local_478);
            FUN_140450590(local_478,&local_4a8);
          }
        }
        iVar8 = iVar8 + 1;
        cVar11 = cVar11 + '\x01';
        local_4e6 = cVar11;
        local_4e4 = iVar8;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(char **)(lVar10 + 0x20) <= pcVar9) {
          _invalid_parameter_noinfo();
        }
        pcVar9 = pcVar9 + 0x2c;
      }
      iVar8 = FUN_140450640(local_478);
      if (0 < iVar8) {
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
      }
      FUN_140450420(local_478);
    }
  }
  return;
}

// ==== CMsgTotalPowerValueSort::ctor_or_dtor  @1404503d0  [high:vtable-assign]  (orig: FUN_1404503d0)
undefined8 * FUN_1404503d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTotalPowerValueSort::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTotalPowerValueSort::ctor_or_dtor  @140450420  [high:vtable-assign]  (orig: FUN_140450420)
void FUN_140450420(undefined8 *param_1)

{
  *param_1 = CMsgTotalPowerValueSort::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTotalPowerValueSort::vfunc_5  @140450450  [high:rtti-vtable]  (orig: FUN_140450450)
bool FUN_140450450(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa8f;
    }
  }
  return false;
}

// ==== CMsgTotalPowerValueSort::helper_140450490  @140450490  [medium:callgraph-r2]  (orig: FUN_140450490)
ulonglong FUN_140450490(longlong param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = param_2;
    **(undefined1 **)(param_1 + 0x428) = param_3;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 3) = param_4;
    lVar1 = *(longlong *)(param_1 + 0x428);
    *(undefined1 *)(lVar1 + 2) = 0;
    *(undefined4 *)(param_1 + 0xc) = 4;
    *(undefined4 *)(param_1 + 8) = 0xa8f;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CMsgTotalPowerValueSort::helper_140450540  @140450540  [medium:callgraph-r2]  (orig: FUN_140450540)
void FUN_140450540(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 2) = 0;
  *(undefined4 *)(param_1 + 0xc) = 4;
  return;
}

// ==== CMsgTotalPowerValueSort::helper_140450590  @140450590  [medium:callgraph-r2]  (orig: FUN_140450590)
ulonglong FUN_140450590(longlong param_1,undefined8 *param_2)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  longlong lVar4;
  
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    uVar3 = (longlong)*(int *)(param_1 + 0xc) + 0x29;
    if (uVar3 < 0x400) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x29;
      lVar4 = (ulonglong)*(byte *)(lVar2 + 2) * 0x29;
      *(undefined8 *)(lVar4 + 4 + lVar2) = *param_2;
      *(undefined8 *)(lVar4 + 0xc + lVar2) = param_2[1];
      *(undefined8 *)(lVar4 + 0x14 + lVar2) = param_2[2];
      *(undefined8 *)(lVar4 + 0x1c + lVar2) = param_2[3];
      *(undefined8 *)(lVar4 + 0x24 + lVar2) = param_2[4];
      *(undefined1 *)(lVar4 + 0x2c + lVar2) = *(undefined1 *)(param_2 + 5);
      lVar2 = *(longlong *)(param_1 + 0x428);
      pcVar1 = (char *)(lVar2 + 2);
      *pcVar1 = *pcVar1 + '\x01';
      return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CMsgTotalPowerValueSort::helper_140450640  @140450640  [medium:callgraph-r2]  (orig: FUN_140450640)
undefined1 FUN_140450640(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 2);
}

// ==== CMsgTotalPowerValueSort::ctor_or_dtor  @140450690  [high:vtable-assign]  (orig: FUN_140450690)
undefined8 * FUN_140450690(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTotalPowerValueSort::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTotalPowerValueSort::vfunc_3  @1404506e0  [high:rtti-vtable]  (orig: FUN_1404506e0)
void FUN_1404506e0(longlong param_1)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar2 = (longlong *)FUN_140087650(uVar1);
    lVar3 = (**(code **)(*plVar2 + 0x88))(plVar2,param_1);
    if (lVar3 != 0) {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      if (*(longlong *)(lVar4 + 0x1c0) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar1 = 0;
      }
      else {
        uVar1 = *(undefined8 *)(lVar4 + 0x1c0);
      }
      FUN_1401d8e10(uVar1,lVar3,**(undefined1 **)(param_1 + 0x428));
    }
  }
  return;
}

