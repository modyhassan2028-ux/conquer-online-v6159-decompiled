// ==== CMsgShowHandKick@texasholdem::helper_140214f20  @140214f20  [medium:callgraph-r0]  (orig: FUN_140214f20)
undefined1
FUN_140214f20(undefined4 *param_1,longlong param_2,int param_3,int param_4,undefined1 param_5)

{
  undefined8 uVar1;
  undefined1 uVar2;
  IStringManager *pIVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  
  if (((param_2 == 0) || (param_3 == 0)) || (param_4 == 0)) {
    uVar2 = 0;
  }
  else if (*(int *)(param_2 + 0x1240) == param_4) {
    uVar1 = FUN_140008520(*param_1);
    plVar4 = (longlong *)FUN_140087650(uVar1);
    lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,param_3);
    if (lVar5 == 0) {
      pIVar3 = theInstance();
      lVar5 = *(longlong *)(param_2 + 0x10);
      uVar1 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_TEXAX_KICK_KICKED_NO_FOUND");
      (**(code **)(lVar5 + 0x358))((longlong *)(param_2 + 0x10),uVar1);
      uVar2 = 0;
    }
    else if (*(int *)(lVar5 + 0x1240) == param_4) {
      lVar6 = FUN_140214ce0(param_1,param_4);
      if (lVar6 == 0) {
        pIVar3 = theInstance();
        lVar5 = *(longlong *)(param_2 + 0x10);
        uVar1 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_TEXAX_KICK_TABLE_ERROR");
        (**(code **)(lVar5 + 0x358))((longlong *)(param_2 + 0x10),uVar1);
        uVar2 = 0;
      }
      else {
        uVar2 = FUN_1403e8540(lVar6,param_2,lVar5,param_5);
      }
    }
    else {
      pIVar3 = theInstance();
      lVar5 = *(longlong *)(param_2 + 0x10);
      uVar1 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_TEXAX_KICK_KICKED_TABLE_ERROR");
      (**(code **)(lVar5 + 0x358))((longlong *)(param_2 + 0x10),uVar1);
      uVar2 = 0;
    }
  }
  else {
    pIVar3 = theInstance();
    lVar5 = *(longlong *)(param_2 + 0x10);
    uVar1 = (*(code *)**(undefined8 **)pIVar3)(pIVar3,"STR_TEXAX_KICK_USER_TABLE_ERROR");
    (**(code **)(lVar5 + 0x358))((longlong *)(param_2 + 0x10),uVar1);
    uVar2 = 0;
  }
  return uVar2;
}

// ==== CMsgShowHandKick@texasholdem::helper_1403caac0  @1403caac0  [medium:callgraph-r3]  (orig: FUN_1403caac0)
undefined8 *
FUN_1403caac0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x1555555555555553 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1403c3b00(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x24);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x24) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x24) = 1;
        *(undefined1 *)(lVar4 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x25) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x25) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x24) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x24) = 1;
        *(undefined1 *)(lVar4 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x25) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x24) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x24) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x25) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x24);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x24) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgShowHandKick@texasholdem::helper_1403cc350  @1403cc350  [medium:callgraph-r2]  (orig: FUN_1403cc350)
bool FUN_1403cc350(longlong param_1,longlong *param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *local_18;
  longlong local_10;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  FUN_1403c9dd0((longlong *)(param_1 + 0x108),&local_18,(longlong)param_2 + 0x1244);
  lVar2 = *(longlong *)(param_1 + 0x138);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x108))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar2) {
    return false;
  }
  if (local_18 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = 0;
  }
  else {
    lVar2 = *local_18;
  }
  if (local_10 == *(longlong *)(lVar2 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  iVar1 = (**(code **)(*param_2 + 8))(param_2);
  return iVar1 == *(int *)(local_10 + 0x20);
}

// ==== CMsgShowHandKick@texasholdem::helper_1403cce60  @1403cce60  [medium:callgraph-r2]  (orig: FUN_1403cce60)
longlong * FUN_1403cce60(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x25) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x25) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1403ccfbd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1403ccfec;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x25) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x25) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x25);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x25);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x25);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x25);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x25) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x25) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1403ccfbd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1403caac0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1403ccfec:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgShowHandKick@texasholdem::helper_1403d6ff0  @1403d6ff0  [medium:callgraph-r2]  (orig: FUN_1403d6ff0)
void FUN_1403d6ff0(longlong param_1,longlong param_2)

{
  char cVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  ulonglong uVar13;
  longlong *local_res18;
  longlong *local_res20;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  if (param_2 != 0) {
    puVar2 = *(undefined8 **)(param_1 + 0x2d8);
    puVar12 = (undefined8 *)*puVar2;
    puVar3 = *(ulonglong **)(param_1 + 0x2a8);
    local_res18 = operator_new(8);
    local_68[0] = (longlong *)0x0;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_68;
      local_68[0] = local_res18;
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    local_res20 = local_res18;
    while( true ) {
      uVar11 = 0;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (puVar12 == puVar2) break;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar13 = uVar11;
      }
      else {
        uVar13 = *puVar3;
      }
      if (puVar12 == *(undefined8 **)(uVar13 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar12 + 0x1c) != '\0') {
        lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
        if (*(longlong *)(lVar8 + 0x90) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar10 = *(longlong **)(lVar8 + 0x90);
        if (puVar3 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar13 = uVar11;
        }
        else {
          uVar13 = *puVar3;
        }
        if (puVar12 == *(undefined8 **)(uVar13 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar8 = (**(code **)(*plVar10 + 0x98))(plVar10,*(undefined4 *)(puVar12 + 3));
        puVar6 = local_48;
        if (lVar8 != 0) {
          local_res18 = (longlong *)CONCAT44(local_res18._4_4_,*(undefined4 *)(lVar8 + 0x122c));
          if (local_50 != (undefined4 *)0x0) {
            uVar11 = local_40 - (longlong)local_50 >> 2;
          }
          if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar11) {
            *local_48 = *(undefined4 *)(lVar8 + 0x122c);
            local_48 = local_48 + 1;
          }
          else {
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            puVar5 = local_50;
            plVar10 = local_68[0];
            if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
              lVar8 = 0;
            }
            else {
              if (local_48 < local_50) {
                _invalid_parameter_noinfo();
              }
              if ((plVar10 == (longlong *)0x0) || (plVar10 != local_68[0])) {
                _invalid_parameter_noinfo();
              }
              lVar8 = (longlong)puVar6 - (longlong)puVar5 >> 2;
            }
            local_88 = SUB84(plVar10,0);
            uStack_84 = (undefined4)((ulonglong)plVar10 >> 0x20);
            uStack_80 = SUB84(puVar6,0);
            uStack_7c = (undefined4)((ulonglong)puVar6 >> 0x20);
            local_78 = local_88;
            uStack_74 = uStack_84;
            uStack_70 = uStack_80;
            uStack_6c = uStack_7c;
            FUN_140036c20(local_68,&local_78,1,&local_res18);
            puVar6 = local_50;
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            plVar10 = local_68[0];
            if (local_68[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *local_68[0];
            }
            if (puVar6 + lVar8 <= *(undefined4 **)(lVar9 + 0x20)) {
              if (plVar10 == (longlong *)0x0) {
                lVar9 = 0;
              }
              else {
                lVar9 = *plVar10;
              }
              if (*(undefined4 **)(lVar9 + 0x18) <= puVar6 + lVar8) goto LAB_1403d727d;
            }
            _invalid_parameter_noinfo();
          }
        }
      }
LAB_1403d727d:
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar12 + 0x25) == '\0') {
        puVar4 = (undefined8 *)puVar12[2];
        if (*(char *)((longlong)puVar4 + 0x25) == '\0') {
          cVar1 = *(char *)((longlong)*puVar4 + 0x25);
          puVar12 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar4 + 0x25);
            puVar12 = puVar4;
            puVar4 = (undefined8 *)*puVar4;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar12[1] + 0x25);
          puVar7 = (undefined8 *)puVar12[1];
          puVar4 = puVar12;
          while ((puVar12 = puVar7, cVar1 == '\0' && (puVar4 == (undefined8 *)puVar12[2]))) {
            cVar1 = *(char *)((longlong)puVar12[1] + 0x25);
            puVar7 = (undefined8 *)puVar12[1];
            puVar4 = puVar12;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    plVar10 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    (**(code **)(*plVar10 + 0x40))(plVar10,local_68,param_2);
    if (local_50 != (undefined4 *)0x0) {
      operator_delete(local_50);
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    operator_delete(local_68[0]);
  }
  return;
}

// ==== CMsgShowHandKick@texasholdem::helper_1403e7b10  @1403e7b10  [medium:callgraph-r2]  (orig: FUN_1403e7b10)
void FUN_1403e7b10(longlong param_1,char param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  int iVar8;
  int iVar9;
  bool bVar10;
  longlong lVar11;
  bool bVar12;
  undefined1 uVar13;
  int iVar14;
  
  iVar3 = (int)*(undefined8 *)(param_1 + 0x2e0);
  if (0 < iVar3) {
    bVar10 = false;
    uVar13 = 0;
    iVar9 = 0;
    iVar14 = 0;
    iVar8 = 0;
    lVar11 = 1;
    plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x2d8);
    plVar1 = *(longlong **)(param_1 + 0x2a8);
LAB_1403e7b90:
    plVar5 = *(longlong **)(param_1 + 0x2d8);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x2a8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 != plVar5) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      lVar7 = 0;
      if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if ((int)plVar4[4] == 1) {
        iVar9 = iVar9 + 1;
        iVar14 = iVar9;
      }
      else {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = lVar7;
        }
        else {
          lVar6 = *plVar1;
        }
        if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if ((int)plVar4[4] == 0) {
          iVar8 = iVar8 + 1;
        }
        else if (param_2 == '\0') {
          if ((char)lVar11 != '\0') {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = lVar7;
            }
            else {
              lVar6 = *plVar1;
            }
            if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar4 + 0x1c) != '\0') {
              lVar11 = lVar7;
            }
          }
        }
        else {
          iVar8 = iVar8 + 1;
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar4 + 0x25) == '\0') {
        plVar5 = plVar4;
        plVar2 = (longlong *)plVar4[2];
        if (*(char *)(plVar4[2] + 0x25) == '\0') {
          do {
            plVar4 = plVar2;
            plVar2 = (longlong *)*plVar4;
          } while (*(char *)(*plVar4 + 0x25) == '\0');
        }
        else {
          do {
            plVar4 = (longlong *)plVar5[1];
            if (*(char *)((longlong)plVar4 + 0x25) != '\0') break;
            bVar12 = plVar5 == (longlong *)plVar4[2];
            plVar5 = plVar4;
          } while (bVar12);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1403e7b90;
    }
    if (((char)lVar11 == '\0') && (param_2 == '\0')) {
      if ((iVar9 * 2 <= iVar3) && (iVar8 * 2 < iVar3)) {
        return;
      }
      bVar10 = iVar3 < iVar9 * 2;
      uVar13 = bVar10;
    }
    else if (iVar8 < iVar9) {
      bVar10 = true;
      uVar13 = 1;
    }
    FUN_1403e79f0(param_1,bVar10,param_1,param_4,uVar13,iVar14);
  }
  return;
}

// ==== CMsgShowHandKick@texasholdem::helper_1403e8540  @1403e8540  [medium:callgraph-r1]  (orig: FUN_1403e8540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e8540(longlong param_1,longlong *param_2,longlong *param_3,char param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined4 uVar4;
  longlong *plVar5;
  char cVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  ulong uVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong lVar15;
  longlong lVar16;
  bool bVar17;
  undefined1 auStack_578 [32];
  undefined4 local_558;
  undefined1 local_550;
  char local_548;
  char local_547;
  undefined8 local_540;
  undefined4 local_538;
  undefined4 local_534;
  int local_530;
  undefined4 local_528;
  undefined4 uStack_524;
  undefined4 local_520;
  undefined4 uStack_51c;
  undefined4 local_518;
  undefined4 uStack_514;
  undefined4 uStack_510;
  undefined4 uStack_50c;
  longlong *local_508;
  undefined8 local_4f8;
  undefined8 uStack_4f0;
  longlong local_4e8;
  longlong *local_4e0;
  longlong local_4d8;
  longlong *local_4d0 [3];
  undefined8 local_4b8;
  longlong *local_4b0;
  longlong *local_4a0;
  longlong local_490;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_4b8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  if ((param_2 == (longlong *)0x0) || (param_3 == (longlong *)0x0)) {
    uVar12 = 0;
  }
  else {
    local_548 = param_4;
    local_547 = param_4;
    local_540 = param_3;
    local_4e8 = param_1;
    if (*(int *)(param_1 + 0x24c) == 0) {
      pIVar11 = theInstance();
      lVar15 = param_2[2];
      uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TEXAX_KICK_USER_TIME_ERROR");
      (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
      uVar12 = 0;
    }
    else {
      cVar6 = FUN_1403cc350();
      if (cVar6 == '\0') {
        pIVar11 = theInstance();
        lVar15 = param_2[2];
        uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TEXAX_KICK_USER_NO_JOIN");
        (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
        uVar12 = 0;
      }
      else {
        plVar13 = (longlong *)FUN_1403ccc50(param_1 + 0x108,local_4d0,(longlong)param_3 + 0x1244);
        plVar1 = (longlong *)*plVar13;
        local_4d8 = plVar13[1];
        lVar15 = *(longlong *)(param_1 + 0x138);
        lVar16 = 0;
        local_4a0 = *(longlong **)(param_1 + 0x108);
        local_4e0 = plVar1;
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_4a0)) {
          _invalid_parameter_noinfo();
        }
        lVar3 = local_4d8;
        if (local_4d8 == lVar15) {
          pIVar11 = theInstance();
          lVar15 = param_2[2];
          uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TEXAX_KICK_KICKED_NO_JOIN");
          (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
          uVar12 = 0;
        }
        else {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar15 = lVar16;
          }
          else {
            lVar15 = *plVar1;
          }
          if (lVar3 == *(longlong *)(lVar15 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar1 = local_540;
          iVar7 = (**(code **)(*local_540 + 8))(local_540);
          if (iVar7 == *(int *)(lVar3 + 0x20)) {
            if (*(char *)(lVar3 + 0x60) == '\x02') {
              pIVar11 = theInstance();
              lVar15 = param_2[2];
              uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                 (pIVar11,"STR_TEXAX_KICK_KICKED_PLAYERING");
              (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
              uVar12 = 0;
            }
            else {
              if (*(int *)(param_1 + 0x298) == 0) {
                iVar7 = (**(code **)(*param_2 + 8))(param_2);
                iVar8 = (**(code **)(*plVar1 + 8))(plVar1);
                if (iVar7 == iVar8) {
                  pIVar11 = theInstance();
                  lVar15 = param_2[2];
                  uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                     (pIVar11,"STR_TEXAX_KICK_USER_KICK_SELF");
                  (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
                  return 0;
                }
                plVar13 = (longlong *)**(undefined8 **)(param_1 + 0x138);
                plVar2 = *(longlong **)(param_1 + 0x108);
                local_4f8._0_4_ = SUB84(plVar2,0);
                local_4f8._4_4_ = (undefined4)((ulonglong)plVar2 >> 0x20);
                uStack_4f0._0_4_ = SUB84(plVar13,0);
                uStack_4f0._4_4_ = (undefined4)((ulonglong)plVar13 >> 0x20);
                local_518 = (undefined4)local_4f8;
                uStack_514 = local_4f8._4_4_;
                uStack_510 = (undefined4)uStack_4f0;
                uStack_50c = uStack_4f0._4_4_;
                local_4f8 = plVar2;
                uStack_4f0 = plVar13;
LAB_1403e89d0:
                plVar14 = *(longlong **)(param_1 + 0x138);
                local_4b0 = *(longlong **)(param_1 + 0x108);
                if ((plVar2 == (longlong *)0x0) || (plVar2 != local_4b0)) {
                  _invalid_parameter_noinfo();
                }
                if (plVar13 != plVar14) {
                  local_540 = (longlong *)CONCAT71(local_540._1_7_,1);
                  local_540 = (longlong *)CONCAT44(2,(undefined4)local_540);
                  if (plVar2 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar15 = lVar16;
                  }
                  else {
                    lVar15 = *plVar2;
                  }
                  if (plVar13 == *(longlong **)(lVar15 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  local_528 = (undefined4)plVar13[4];
                  uStack_524 = SUB84(local_540,0);
                  local_520 = (undefined4)((ulonglong)local_540 >> 0x20);
                  FUN_1403cce60(param_1 + 0x2a8,local_4d0,&local_528);
                  if (plVar2 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  if (*(char *)((longlong)plVar13 + 0x81) == '\0') {
                    plVar14 = plVar13;
                    plVar5 = (longlong *)plVar13[2];
                    if (*(char *)(plVar13[2] + 0x81) == '\0') {
                      do {
                        plVar13 = plVar5;
                        plVar5 = (longlong *)*plVar13;
                        local_508 = plVar13;
                      } while (*(char *)(*plVar13 + 0x81) == '\0');
                    }
                    else {
                      do {
                        plVar13 = (longlong *)plVar14[1];
                        if (*(char *)((longlong)plVar13 + 0x81) != '\0') break;
                        bVar17 = plVar14 == (longlong *)plVar13[2];
                        plVar14 = plVar13;
                      } while (bVar17);
                    }
                  }
                  else {
                    _invalid_parameter_noinfo();
                  }
                  goto LAB_1403e89d0;
                }
                local_538 = (**(code **)(*param_2 + 8))(param_2);
                FUN_1403cd010(param_1 + 0x2a8,&local_518,&local_538);
                lVar15 = *(longlong *)(param_1 + 0x2d8);
                local_4d0[0] = *(longlong **)(param_1 + 0x2a8);
                plVar13 = (longlong *)CONCAT44(uStack_514,local_518);
                if ((plVar13 == (longlong *)0x0) || (plVar13 != local_4d0[0])) {
                  _invalid_parameter_noinfo();
                }
                lVar3 = CONCAT44(uStack_50c,uStack_510);
                if (lVar3 == lVar15) {
                  (**(code **)(*param_2 + 8))(param_2);
                  log_InlineLogERROR(
                                    "CTexasHoldEm::AppKickUserVote. m_mapVoterInfo not found User[%u]"
                                    );
                  return 0;
                }
                if (local_548 == '\0') {
                  if (plVar13 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar16 = *plVar13;
                  }
                  if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined4 *)(lVar3 + 0x20) = 0;
                }
                else {
                  if (plVar13 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar16 = *plVar13;
                  }
                  if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined4 *)(lVar3 + 0x20) = 1;
                }
                uVar9 = (**(code **)(*plVar1 + 8))(plVar1);
                *(undefined4 *)(param_1 + 0x29c) = uVar9;
                uVar9 = (**(code **)(*param_2 + 8))(param_2);
                *(undefined4 *)(param_1 + 0x2a0) = uVar9;
                iVar7 = FUN_14016b120(param_1 + 0x248);
                if (10 < iVar7) {
                  iVar7 = 10;
                }
                *(int *)(param_1 + 0x294) = iVar7;
                local_530 = iVar7;
                uVar10 = tq::TimeGet(0);
                *(uint *)(param_1 + 0x298) = uVar10 / 1000;
                FUN_140459f10(local_478);
                local_558 = CONCAT22(local_558._2_2_,(short)iVar7);
                cVar6 = FUN_14045a050(local_478,1,*(undefined4 *)(param_1 + 0x2a0),
                                      *(undefined4 *)(param_1 + 0x29c));
                if (cVar6 != '\0') {
                  FUN_1403d6ff0(param_1,local_478);
                }
                FUN_140459f60(local_478);
              }
              else {
                local_534 = (**(code **)(*param_2 + 8))(param_2);
                FUN_1403cd010(param_1 + 0x2a8,&local_528,&local_534);
                uVar4 = uStack_524;
                uVar9 = local_528;
                lVar15 = *(longlong *)(param_1 + 0x2d8);
                local_490 = *(longlong *)(param_1 + 0x2a8);
                if ((local_490 == 0) || (local_490 != CONCAT44(uStack_524,local_528))) {
                  _invalid_parameter_noinfo();
                }
                plVar13 = (longlong *)CONCAT44(uVar4,uVar9);
                lVar3 = CONCAT44(uStack_51c,local_520);
                if (lVar15 == lVar3) {
                  pIVar11 = theInstance();
                  lVar15 = param_2[2];
                  uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                     (pIVar11,"STR_TEXAX_KICK_USER_IS_ILLEGAL");
                  (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
                  return 0;
                }
                if (plVar13 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar15 = lVar16;
                }
                else {
                  lVar15 = *plVar13;
                }
                if (lVar3 == *(longlong *)(lVar15 + 0x30)) {
                  _invalid_parameter_noinfo();
                }
                if (*(int *)(lVar3 + 0x20) != 2) {
                  pIVar11 = theInstance();
                  lVar15 = param_2[2];
                  uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                     (pIVar11,"STR_TEXAX_KICK_USER_HAVE_VOTE");
                  (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
                  return 0;
                }
                iVar7 = (**(code **)(*plVar1 + 8))(plVar1);
                cVar6 = local_548;
                if (*(int *)(param_1 + 0x29c) != iVar7) {
                  pIVar11 = theInstance();
                  lVar15 = param_2[2];
                  uVar12 = (*(code *)**(undefined8 **)pIVar11)
                                     (pIVar11,"STR_TEXAX_KICK_USER_KICK_ERROR");
                  (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
                  return 0;
                }
                if (local_548 == '\0') {
                  if (plVar13 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar16 = *plVar13;
                  }
                  if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined4 *)(lVar3 + 0x20) = 0;
                }
                else {
                  if (plVar13 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  else {
                    lVar16 = *plVar13;
                  }
                  if (lVar3 == *(longlong *)(lVar16 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  *(undefined4 *)(lVar3 + 0x20) = 1;
                }
                FUN_140459f10(local_478);
                local_558 = (**(code **)(*param_2 + 8))(param_2);
                local_550 = cVar6 != '\0';
                cVar6 = FUN_140459fc0(local_478,2,*(undefined4 *)(param_1 + 0x2a0),
                                      *(undefined4 *)(param_1 + 0x29c));
                if (cVar6 != '\0') {
                  FUN_1403d6ff0(param_1,local_478);
                }
                FUN_140459f60(local_478);
              }
              FUN_1403e7b10(param_1,0);
              uVar12 = 1;
            }
          }
          else {
            pIVar11 = theInstance();
            lVar15 = param_2[2];
            uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_TEXAX_KICK_KICKED_NO_FOUND");
            (**(code **)(lVar15 + 0x358))(param_2 + 2,uVar12);
            uVar12 = 0;
          }
        }
      }
    }
  }
  return uVar12;
}

// ==== CMsgShowHandKick@texasholdem::helper_140459f60  @140459f60  [medium:callgraph-r2]  (orig: FUN_140459f60)
void FUN_140459f60(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgShowHandKick::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgShowHandKick@texasholdem::vfunc_1  @140459f90  [high:rtti-vtable]  (orig: FUN_140459f90)
undefined8 FUN_140459f90(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandKick@texasholdem::helper_140459fc0  @140459fc0  [medium:callgraph-r2]  (orig: FUN_140459fc0)
undefined8
FUN_140459fc0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined1 param_6)

{
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 5) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 9) = param_5;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xd) = param_6;
  *(undefined4 *)(param_1 + 8) = 0x828;
  *(undefined4 *)(param_1 + 0xc) = 0xe;
  return 1;
}

// ==== CMsgShowHandKick@texasholdem::helper_14045a050  @14045a050  [medium:callgraph-r2]  (orig: FUN_14045a050)
undefined8
FUN_14045a050(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
             undefined2 param_5)

{
  FUN_1402b5600();
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 5) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 9) = param_5;
  *(undefined4 *)(param_1 + 8) = 0x828;
  *(undefined4 *)(param_1 + 0xc) = 0xe;
  return CONCAT71((uint7)(byte)((ushort)param_5 >> 8),1);
}

// ==== CMsgShowHandKick@texasholdem::vfunc_0  @14045a0d0  [high:rtti-vtable]  (orig: FUN_14045a0d0)
undefined8 * FUN_14045a0d0(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandKick::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandKick@texasholdem::vfunc_3  @14045a120  [high:rtti-vtable]  (orig: FUN_14045a120)
void FUN_14045a120(longlong param_1)

{
  char *pcVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  longlong *plVar6;
  
  if (*(char **)(param_1 + 0x428) == (char *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar3 = **(char **)(param_1 + 0x428);
  if ((cVar3 == '\0') || (cVar3 == '\x02')) {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x88))(plVar6,param_1);
    if (plVar6 != (longlong *)0x0) {
      pcVar1 = *(char **)(param_1 + 0x428);
      if (*pcVar1 == '\0') {
        iVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        if (iVar4 == *(int *)(pcVar1 + 9)) {
          return;
        }
        pcVar1[0xd] = '\x01';
      }
      else if (pcVar1[0xd] == '\x02') {
        return;
      }
      lVar2 = plVar6[0x248];
      if ((int)lVar2 != 0) {
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar5 = FUN_140087830(uVar5);
        cVar3 = FUN_140215360(uVar5,plVar6,(int)lVar2);
        if (cVar3 != '\0') {
          lVar2 = *(longlong *)(param_1 + 0x428);
          cVar3 = *(char *)(lVar2 + 0xd);
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087830(uVar5);
          FUN_140214f20(uVar5,plVar6,*(undefined4 *)(lVar2 + 5),(int)plVar6[0x248],cVar3 == '\x01');
        }
      }
    }
  }
  return;
}

