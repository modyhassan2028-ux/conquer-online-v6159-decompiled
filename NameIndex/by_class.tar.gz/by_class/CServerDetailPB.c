// ==== CServerDetailPB::helper_140033020  @140033020  [medium:callgraph-r2]  (orig: FUN_140033020)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140033020(basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_1,uint param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CServerDetailPB::helper_140554070  @140554070  [medium:callgraph-r1]  (orig: FUN_140554070)
void FUN_140554070(void)

{
  if (DAT_140977388 != 0) {
    FUN_140033020(DAT_140977388,1);
  }
  return;
}

// ==== CServerDetailPB::helper_1405540c0  @1405540c0  [medium:callgraph-r0]  (orig: FUN_1405540c0)
void FUN_1405540c0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 local_10;
  
  this = operator_new(0x28);
  if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
    local_10 = 0;
  }
  else {
    local_10 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
               basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
  }
  DAT_140977388 = local_10;
  FUN_140556df0(FUN_140554070);
  return;
}

// ==== CServerDetailPB::helper_140555c70  @140555c70  [medium:callgraph-r0]  (orig: FUN_140555c70)
void FUN_140555c70(undefined8 *param_1,int param_2)

{
  void *_Src;
  undefined1 auVar1 [16];
  undefined8 uVar2;
  undefined4 *puVar3;
  __uint64 _Var4;
  int local_res10 [6];
  int local_20 [2];
  void *local_18;
  void *local_10;
  
  if (*(int *)(param_1 + 2) < param_2) {
    _Src = (void *)*param_1;
    local_20[0] = *(int *)(param_1 + 2) << 1;
    local_res10[0] = param_2;
    uVar2 = FUN_140555ed0(local_20,local_res10);
    puVar3 = (undefined4 *)FUN_140555ed0(&DAT_1407a2768,uVar2);
    *(undefined4 *)(param_1 + 2) = *puVar3;
    auVar1._8_8_ = 0;
    auVar1._0_8_ = (longlong)*(int *)(param_1 + 2);
    _Var4 = SUB168(ZEXT816(8) * auVar1,0);
    if (SUB168(ZEXT816(8) * auVar1,8) != 0) {
      _Var4 = 0xffffffffffffffff;
    }
    local_18 = operator_new__(_Var4);
    *param_1 = local_18;
    if (_Src != (void *)0x0) {
      memcpy((void *)*param_1,_Src,(longlong)*(int *)((longlong)param_1 + 0xc) << 3);
      local_10 = _Src;
      operator_delete__(_Src);
    }
  }
  return;
}

// ==== CServerDetailPB::helper_1405571c0  @1405571c0  [medium:callgraph-r1]  (orig: FUN_1405571c0)
undefined8 FUN_1405571c0(undefined8 *param_1)

{
  return *param_1;
}

// ==== CServerDetailPB::helper_140558da0  @140558da0  [medium:callgraph-r1]  (orig: FUN_140558da0)
undefined4 FUN_140558da0(longlong param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 local_18;
  int local_14;
  
  local_14 = FUN_14055ab30(param_1);
  local_18 = *(undefined4 *)(param_1 + 0x28);
  if ((param_2 < 0) || (0x7fffffff - local_14 < param_2)) {
    *(undefined4 *)(param_1 + 0x28) = 0x7fffffff;
  }
  else {
    *(int *)(param_1 + 0x28) = local_14 + param_2;
  }
  puVar1 = (undefined4 *)FUN_14055b600(param_1 + 0x28,&local_18);
  *(undefined4 *)(param_1 + 0x28) = *puVar1;
  FUN_14055ab60(param_1);
  return local_18;
}

// ==== CServerDetailPB::helper_140558e40  @140558e40  [medium:callgraph-r1]  (orig: FUN_140558e40)
void FUN_140558e40(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x28) = param_2;
  FUN_14055ab60(param_1);
  *(undefined1 *)(param_1 + 0x24) = 0;
  return;
}

// ==== CServerDetailPB::helper_14055ab10  @14055ab10  [medium:callgraph-r3]  (orig: FUN_14055ab10)
longlong FUN_14055ab10(longlong param_1)

{
  return *(longlong *)(param_1 + 0x10) - *(longlong *)(param_1 + 8);
}

// ==== CServerDetailPB::helper_14055ab30  @14055ab30  [medium:callgraph-r2]  (orig: FUN_14055ab30)
int FUN_14055ab30(longlong param_1)

{
  int iVar1;
  
  iVar1 = FUN_14055ab10(param_1);
  return *(int *)(param_1 + 0x18) - (iVar1 + *(int *)(param_1 + 0x2c));
}

// ==== CServerDetailPB::helper_14055ab60  @14055ab60  [medium:callgraph-r2]  (orig: FUN_14055ab60)
void FUN_14055ab60(longlong param_1)

{
  int *piVar1;
  
  *(longlong *)(param_1 + 0x10) = (longlong)*(int *)(param_1 + 0x2c) + *(longlong *)(param_1 + 0x10)
  ;
  piVar1 = (int *)FUN_14055b600(param_1 + 0x28,param_1 + 0x30);
  if (*piVar1 < *(int *)(param_1 + 0x18)) {
    *(int *)(param_1 + 0x2c) = *(int *)(param_1 + 0x18) - *piVar1;
    *(longlong *)(param_1 + 0x10) =
         *(longlong *)(param_1 + 0x10) - (longlong)*(int *)(param_1 + 0x2c);
  }
  else {
    *(undefined4 *)(param_1 + 0x2c) = 0;
  }
  return;
}

// ==== CServerDetailPB::helper_14055d7b0  @14055d7b0  [medium:callgraph-r1]  (orig: FUN_14055d7b0)
void FUN_14055d7b0(void)

{
  Sleep(0);
  return;
}

// ==== CServerDetailPB::helper_14055d7d0  @14055d7d0  [medium:callgraph-r0]  (orig: FUN_14055d7d0)
void FUN_14055d7d0(undefined8 param_1,longlong *param_2)

{
  longlong lVar1;
  undefined8 local_18;
  
  lVar1 = FUN_1405571c0(param_1);
  if (lVar1 != 2) {
    local_18 = FUN_14055d880(param_1,0,1);
    if (local_18 == 0) {
      (**(code **)(*param_2 + 8))(param_2);
      FUN_14055d860(param_1,2);
    }
    else {
      while (local_18 == 1) {
        FUN_14055d7b0();
        local_18 = FUN_1405571c0(param_1);
      }
    }
  }
  return;
}

// ==== CServerDetailPB::helper_14055d860  @14055d860  [medium:callgraph-r1]  (orig: FUN_14055d860)
void FUN_14055d860(undefined8 *param_1,undefined8 param_2)

{
  *param_1 = param_2;
  return;
}

// ==== CServerDetailPB::helper_14055d880  @14055d880  [medium:callgraph-r1]  (orig: FUN_14055d880)
void FUN_14055d880(undefined8 param_1,undefined8 param_2,undefined8 param_3)

{
  FUN_14055da20(param_1,param_2,param_3);
  return;
}

// ==== CServerDetailPB::helper_14055da20  @14055da20  [medium:callgraph-r2]  (orig: FUN_14055da20)
longlong FUN_14055da20(longlong *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  
  LOCK();
  lVar1 = *param_1;
  if (param_2 == lVar1) {
    *param_1 = param_3;
    lVar1 = param_2;
  }
  UNLOCK();
  return lVar1;
}

// ==== CServerDetailPB::helper_140574440  @140574440  [medium:callgraph-r0]  (orig: FUN_140574440)
void FUN_140574440(longlong param_1,
                  basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                  *param_2)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar1;
  
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x40;
  if (*(longlong *)(param_1 + 0x50) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar1 = 0;
    }
    else {
      uVar1 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x50) = uVar1;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405744a1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::assign
            (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x50),
             param_2);
  return;
}

// ==== CServerDetailPB::helper_1405744b0  @1405744b0  [medium:callgraph-r0]  (orig: FUN_1405744b0)
undefined8 FUN_1405744b0(longlong param_1)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  undefined8 uVar1;
  
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x40;
  if (*(longlong *)(param_1 + 0x50) == DAT_140977388) {
    this = operator_new(0x28);
    if (this == (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0) {
      uVar1 = 0;
    }
    else {
      uVar1 = std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    }
    *(undefined8 *)(param_1 + 0x50) = uVar1;
  }
  else {
    uVar1 = *(undefined8 *)(param_1 + 0x50);
  }
  return uVar1;
}

// ==== CServerDetailPB::vfunc_3  @140574720  [high:rtti-vtable]  (orig: FUN_140574720)
void FUN_140574720(longlong param_1)

{
  if ((*(byte *)(param_1 + 0x30) & 0x7f) != 0) {
    *(undefined4 *)(param_1 + 0x38) = 0;
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
    *(undefined4 *)(param_1 + 0x4c) = 0;
    if (((*(uint *)(param_1 + 0x30) >> 6 & 1) != 0) &&
       (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)(param_1 + 0x50) !=
        (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)DAT_140977388)) {
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
                (*(basic_string<char,std::char_traits<char>,std::allocator<char>_> **)
                  (param_1 + 0x50));
    }
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
                    /* WARNING: Could not recover jumptable at 0x00014057476e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8));
  return;
}

// ==== CServerDetailPB::vfunc_9  @140574780  [high:rtti-vtable]  (orig: FUN_140574780)
void FUN_140574780(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
    FUN_1405c8ee0(1,*(undefined4 *)(param_1 + 0x38),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
    FUN_1405c8ee0(2,*(undefined4 *)(param_1 + 0x3c),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 2 & 1) != 0) {
    FUN_1405c8ee0(3,*(undefined4 *)(param_1 + 0x40),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 3 & 1) != 0) {
    FUN_1405c8ee0(4,*(undefined4 *)(param_1 + 0x44),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 4 & 1) != 0) {
    FUN_1405c8ee0(5,*(undefined4 *)(param_1 + 0x48),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 5 & 1) != 0) {
    FUN_1405c8ee0(6,*(undefined4 *)(param_1 + 0x4c),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 6 & 1) != 0) {
    FUN_1405c9580(7,*(undefined8 *)(param_1 + 0x50),param_2);
  }
  if (*(ulonglong *)(param_1 + 0x28) < 0x10) {
    lVar1 = param_1 + 0x10;
  }
  else {
    lVar1 = *(longlong *)(param_1 + 0x10);
  }
  FUN_14055a240(param_2,lVar1,*(ulonglong *)(param_1 + 0x20) & 0xffffffff);
  return;
}

// ==== CServerDetailPB::vfunc_8  @140574870  [high:rtti-vtable]  (orig: FUN_140574870)
int FUN_140574870(longlong param_1)

{
  longlong lVar1;
  ulonglong uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = 0;
  if (*(char *)(param_1 + 0x30) != '\0') {
    iVar4 = 1;
    if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
      if (*(uint *)(param_1 + 0x38) < 0x80) {
        iVar5 = 1;
      }
      else {
        iVar5 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
      if (*(uint *)(param_1 + 0x3c) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1 + iVar3;
    }
    if ((*(uint *)(param_1 + 0x30) >> 2 & 1) != 0) {
      if (*(uint *)(param_1 + 0x40) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1 + iVar3;
    }
    if ((*(uint *)(param_1 + 0x30) >> 3 & 1) != 0) {
      if (*(uint *)(param_1 + 0x44) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1 + iVar3;
    }
    if ((*(uint *)(param_1 + 0x30) >> 4 & 1) != 0) {
      if (*(uint *)(param_1 + 0x48) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1 + iVar3;
    }
    if ((*(uint *)(param_1 + 0x30) >> 5 & 1) != 0) {
      if (*(uint *)(param_1 + 0x4c) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar5 = iVar5 + 1 + iVar3;
    }
    if ((*(uint *)(param_1 + 0x30) >> 6 & 1) != 0) {
      lVar1 = *(longlong *)(param_1 + 0x50);
      uVar2 = *(ulonglong *)(lVar1 + 0x18);
      if (0x7f < (uint)uVar2) {
        iVar4 = FUN_14055a8a0(uVar2 & 0xffffffff);
      }
      iVar5 = iVar5 + 1 + *(int *)(lVar1 + 0x18) + iVar4;
    }
  }
  iVar5 = iVar5 + *(int *)(param_1 + 0x20);
  *(int *)(param_1 + 0x34) = iVar5;
  return iVar5;
}

// ==== CServerDetailPB::helper_1405749b0  @1405749b0  [medium:callgraph-r0]  (orig: FUN_1405749b0)
void FUN_1405749b0(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 local_res8 [8];
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8[0] = 0;
    uVar2 = FUN_140556890(local_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgsamegroupserverlist.pb.cc"
                          ,0x19a,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(local_res8,uVar2);
    FUN_140556900(local_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x38);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x38) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x3c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
      *(undefined4 *)(param_1 + 0x3c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 2 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 3 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x44);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
      *(undefined4 *)(param_1 + 0x44) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 4 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x48);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
      *(undefined4 *)(param_1 + 0x48) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 5 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x4c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x20;
      *(undefined4 *)(param_1 + 0x4c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 6 & 1) != 0) {
      FUN_140574440(param_1,*(undefined8 *)(param_2 + 0x50));
    }
  }
                    /* WARNING: Could not recover jumptable at 0x000140574ae6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CServerDetailPB::vfunc_4  @140574b30  [high:rtti-vtable]  (orig: FUN_140574b30)
bool FUN_140574b30(longlong param_1)

{
  return (*(byte *)(param_1 + 0x30) & 0x7f) == 0x7f;
}

// ==== CServerDetailPB::vfunc_1  @140574b40  [high:rtti-vtable]  (orig: FUN_140574b40)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140574b40(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2,"CServerDetailPB");
  return param_2;
}

// ==== CServerDetailPB::ctor_or_dtor  @140574e10  [high:vtable-assign]  (orig: FUN_140574e10)
undefined8 * FUN_140574e10(undefined8 *param_1)

{
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CServerDetailPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140574260();
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
  param_1[10] = DAT_140977388;
  *(undefined4 *)(param_1 + 6) = 0;
  return param_1;
}

// ==== CServerDetailPB::vfunc_11  @140574e90  [high:rtti-vtable]  (orig: FUN_140574e90)
undefined4 FUN_140574e90(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CServerDetailPB::ctor_or_dtor  @140574ea0  [high:vtable-assign]  (orig: FUN_140574ea0)
undefined8 *
FUN_140574ea0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CServerDetailPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140574260();
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
  param_1[10] = DAT_140977388;
  *(undefined4 *)(param_1 + 6) = 0;
  FUN_1405749b0(param_1,param_2,param_3,param_4,uVar1);
  return param_1;
}

// ==== CServerDetailPB::ctor_or_dtor  @140574f30  [high:vtable-assign]  (orig: FUN_140574f30)
void FUN_140574f30(undefined8 *param_1)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  
  *param_1 = CServerDetailPB::vftable;
  this = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)param_1[10];
  if ((this != DAT_140977388) &&
     (this != (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)0x0)) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(this);
    operator_delete(this);
  }
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  return;
}

// ==== CServerDetailPB::vfunc_2  @140574fa0  [high:rtti-vtable]  (orig: FUN_140574fa0)
undefined8 FUN_140574fa0(void)

{
  void *pvVar1;
  undefined8 uVar2;
  
  pvVar1 = operator_new(0x58);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_140574e10(pvVar1);
  }
  return uVar2;
}

// ==== CServerDetailPB::vfunc_0  @140575330  [high:rtti-vtable]  (orig: FUN_140575330)
void * FUN_140575330(void *param_1,uint param_2)

{
  FUN_140574f30();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CServerDetailPB::vfunc_7  @140575360  [high:rtti-vtable]  (orig: FUN_140575360)
undefined8 FUN_140575360(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  byte bVar1;
  byte *pbVar2;
  char *pcVar3;
  char cVar4;
  uint uVar5;
  undefined8 uVar6;
  int iVar7;
  ulonglong uVar8;
  undefined1 local_40 [16];
  undefined1 local_30 [40];
  
  FUN_14055c020(local_40,param_1 + 8,param_3,param_4,0xfffffffffffffffe);
  FUN_14055a0b0(local_30,local_40);
LAB_1405753a5:
  do {
    pbVar2 = *(byte **)(param_2 + 8);
    if ((pbVar2 < *(byte **)(param_2 + 0x10)) && (bVar1 = *pbVar2, '\0' < (char)bVar1)) {
      uVar8 = (ulonglong)bVar1;
      *(uint *)(param_2 + 0x20) = (uint)bVar1;
      *(byte **)(param_2 + 8) = pbVar2 + 1;
LAB_1405753e2:
      iVar7 = (int)uVar8;
      switch((int)(uVar8 >> 3)) {
      case 1:
        if (iVar7 == 8) {
          if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
             (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
            *(uint *)(param_1 + 0x38) = (uint)bVar1;
            *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
          }
          else {
            cVar4 = FUN_1405595b0(param_2);
            if (cVar4 == '\0') goto LAB_1405756a0;
          }
          *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
          pcVar3 = *(char **)(param_2 + 8);
          if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == '\x10')) {
            *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140575467:
            if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
               (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
              *(uint *)(param_1 + 0x3c) = (uint)bVar1;
              *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
            }
            else {
              cVar4 = FUN_1405595b0(param_2);
              if (cVar4 == '\0') goto LAB_1405756a0;
            }
            *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
            pcVar3 = *(char **)(param_2 + 8);
            if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == '\x18')) {
              *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_1405754c5:
              if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
                 (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
                *(uint *)(param_1 + 0x40) = (uint)bVar1;
                *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
              }
              else {
                cVar4 = FUN_1405595b0(param_2);
                if (cVar4 == '\0') goto LAB_1405756a0;
              }
              *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
              pcVar3 = *(char **)(param_2 + 8);
              if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == ' ')) {
                *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140575523:
                if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
                   (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
                  *(uint *)(param_1 + 0x44) = (uint)bVar1;
                  *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
                }
                else {
                  cVar4 = FUN_1405595b0(param_2);
                  if (cVar4 == '\0') goto LAB_1405756a0;
                }
                *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
                pcVar3 = *(char **)(param_2 + 8);
                if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == '(')) {
                  *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140575581:
                  if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
                     (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
                    *(uint *)(param_1 + 0x48) = (uint)bVar1;
                    *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
                  }
                  else {
                    cVar4 = FUN_1405595b0(param_2);
                    if (cVar4 == '\0') goto LAB_1405756a0;
                  }
                  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
                  pcVar3 = *(char **)(param_2 + 8);
                  if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == '0')) {
                    *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_1405755df:
                    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
                       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
                      *(uint *)(param_1 + 0x4c) = (uint)bVar1;
                      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
                    }
                    else {
                      cVar4 = FUN_1405595b0(param_2);
                      if (cVar4 == '\0') goto LAB_1405756a0;
                    }
                    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x20;
                    pcVar3 = *(char **)(param_2 + 8);
                    if ((pcVar3 < *(char **)(param_2 + 0x10)) && (*pcVar3 == ':')) {
                      *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140575639:
                      uVar6 = FUN_1405744b0(param_1);
                      cVar4 = FUN_1405c9b40(param_2,uVar6);
                      if (cVar4 == '\0') goto LAB_1405756a0;
                      if ((*(longlong *)(param_2 + 8) == *(longlong *)(param_2 + 0x10)) &&
                         ((*(int *)(param_2 + 0x2c) != 0 ||
                          (*(int *)(param_2 + 0x18) == *(int *)(param_2 + 0x28))))) {
                        *(undefined4 *)(param_2 + 0x20) = 0;
                        *(undefined1 *)(param_2 + 0x24) = 1;
                        goto LAB_1405756b9;
                      }
                    }
                  }
                }
              }
            }
          }
          goto LAB_1405753a5;
        }
        break;
      case 2:
        if (iVar7 == 0x10) goto LAB_140575467;
        break;
      case 3:
        if (iVar7 == 0x18) goto LAB_1405754c5;
        break;
      case 4:
        if (iVar7 == 0x20) goto LAB_140575523;
        break;
      case 5:
        if (iVar7 == 0x28) goto LAB_140575581;
        break;
      case 6:
        if (iVar7 == 0x30) goto LAB_1405755df;
        break;
      case 7:
        if (iVar7 == 0x3a) goto LAB_140575639;
      }
    }
    else {
      uVar5 = FUN_140559720(param_2);
      uVar8 = (ulonglong)uVar5;
      *(uint *)(param_2 + 0x20) = uVar5;
      if (uVar5 - 1 < 0x7f) goto LAB_1405753e2;
    }
    if (((int)uVar8 == 0) || (((byte)uVar8 & 7) == 4)) {
LAB_1405756b9:
      FUN_14055a130(local_30);
      FUN_14055c070(local_40);
      return 1;
    }
    cVar4 = FUN_1405c88b0(param_2,uVar8,local_30);
    if (cVar4 == '\0') {
LAB_1405756a0:
      FUN_14055a130(local_30);
      FUN_14055c070(local_40);
      return 0;
    }
  } while( true );
}

// ==== CServerDetailPB::vfunc_6  @140575700  [high:rtti-vtable]  (orig: thunk_FUN_1405749b0)
void thunk_FUN_1405749b0(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 auStackX_8 [8];
  undefined1 auStack_48 [64];
  
  if (param_2 == param_1) {
    auStackX_8[0] = 0;
    uVar2 = FUN_140556890(auStack_48,3,
                          "f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgsamegroupserverlist.pb.cc"
                          ,0x19a,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(auStackX_8,uVar2);
    FUN_140556900(auStack_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x38);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x38) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x3c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
      *(undefined4 *)(param_1 + 0x3c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 2 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 3 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x44);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
      *(undefined4 *)(param_1 + 0x44) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 4 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x48);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
      *(undefined4 *)(param_1 + 0x48) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 5 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x4c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x20;
      *(undefined4 *)(param_1 + 0x4c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 6 & 1) != 0) {
      FUN_140574440(param_1,*(undefined8 *)(param_2 + 0x50));
    }
  }
                    /* WARNING: Could not recover jumptable at 0x000140574ae6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CServerDetailPB::helper_1405757f0  @1405757f0  [medium:callgraph-r0]  (orig: FUN_1405757f0)
ulonglong FUN_1405757f0(longlong param_1,undefined8 param_2)

{
  byte *pbVar1;
  undefined4 uVar2;
  int iVar3;
  ulonglong uVar4;
  uint local_res8 [2];
  
  pbVar1 = *(byte **)(param_1 + 8);
  if ((pbVar1 < *(byte **)(param_1 + 0x10)) && (*pbVar1 < 0x80)) {
    local_res8[0] = (uint)*pbVar1;
    *(byte **)(param_1 + 8) = pbVar1 + 1;
  }
  else {
    uVar4 = FUN_1405595b0(param_1,local_res8);
    if ((char)uVar4 == '\0') goto LAB_140575833;
  }
  *(int *)(param_1 + 0x38) = *(int *)(param_1 + 0x38) + 1;
  uVar4 = (ulonglong)*(uint *)(param_1 + 0x38);
  if ((int)*(uint *)(param_1 + 0x38) <= *(int *)(param_1 + 0x3c)) {
    uVar2 = FUN_140558da0(param_1,local_res8[0]);
    uVar4 = FUN_140575360(param_2,param_1);
    if (((char)uVar4 != '\0') && (*(char *)(param_1 + 0x24) != '\0')) {
      FUN_140558e40(param_1,uVar2);
      iVar3 = *(int *)(param_1 + 0x38);
      if (0 < iVar3) {
        iVar3 = iVar3 + -1;
        *(int *)(param_1 + 0x38) = iVar3;
      }
      return CONCAT71((uint7)(uint3)((uint)iVar3 >> 8),1);
    }
    return uVar4 & 0xffffffffffffff00;
  }
LAB_140575833:
  return uVar4 & 0xffffffffffffff00;
}

// ==== CServerDetailPB::ctor_or_dtor  @140575f10  [high:vtable-assign]  (orig: FUN_140575f10)
undefined8 FUN_140575f10(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  char *pcVar4;
  char cVar5;
  uint uVar6;
  undefined8 *puVar7;
  ulonglong uVar8;
  undefined8 *puVar9;
  undefined1 local_70 [16];
  undefined **local_60;
  code *local_58;
  undefined1 local_50;
  undefined1 local_48 [32];
  
  FUN_14055c020(local_70,param_1 + 8,param_3,param_4,0xfffffffffffffffe);
  FUN_14055a0b0(local_48,local_70);
  do {
    while ((pbVar3 = *(byte **)(param_2 + 8), *(byte **)(param_2 + 0x10) <= pbVar3 ||
           (bVar1 = *pbVar3, (char)bVar1 < '\x01'))) {
      uVar6 = FUN_140559720(param_2);
      uVar8 = (ulonglong)uVar6;
      *(uint *)(param_2 + 0x20) = uVar6;
      if (uVar6 - 1 < 0x7f) goto LAB_140575fae;
LAB_1405760fd:
      if (((int)uVar8 == 0) || (((byte)uVar8 & 7) == 4)) goto LAB_140576142;
      cVar5 = FUN_1405c88b0(param_2,uVar8,local_48);
      if (cVar5 == '\0') {
LAB_140576129:
        FUN_14055a130(local_48);
        FUN_14055c070(local_70);
        return 0;
      }
    }
    uVar8 = (ulonglong)bVar1;
    *(uint *)(param_2 + 0x20) = (uint)bVar1;
    *(byte **)(param_2 + 8) = pbVar3 + 1;
LAB_140575fae:
    if (((int)(uVar8 >> 3) != 1) || ((int)uVar8 != 10)) goto LAB_1405760fd;
    while( true ) {
      iVar2 = *(int *)(param_1 + 0x40);
      if (iVar2 < *(int *)(param_1 + 0x44)) {
        puVar9 = *(undefined8 **)(*(longlong *)(param_1 + 0x38) + (longlong)iVar2 * 8);
        *(int *)(param_1 + 0x40) = iVar2 + 1;
      }
      else {
        if (*(int *)(param_1 + 0x44) == *(int *)(param_1 + 0x48)) {
          FUN_140555c70(param_1 + 0x38,*(int *)(param_1 + 0x48) + 1);
        }
        puVar7 = operator_new(0x58);
        puVar9 = (undefined8 *)0x0;
        if (puVar7 != (undefined8 *)0x0) {
          *puVar7 = google::protobuf::MessageLite::vftable;
          *puVar7 = CServerDetailPB::vftable;
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          basic_string<char,std::char_traits<char>,std::allocator<char>_>
                    ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar7 + 1)
                    );
          if (DAT_140977390 != 2) {
            local_60 = google::protobuf::internal::FunctionClosure0::vftable;
            local_58 = FUN_1405540c0;
            local_50 = 0;
            FUN_14055d7d0(&DAT_140977390,&local_60);
            FUN_140556ba0(&local_60);
          }
          *(undefined4 *)((longlong)puVar7 + 0x34) = 0;
          *(undefined4 *)(puVar7 + 7) = 0;
          *(undefined4 *)((longlong)puVar7 + 0x3c) = 0;
          *(undefined4 *)(puVar7 + 8) = 0;
          *(undefined4 *)((longlong)puVar7 + 0x44) = 0;
          *(undefined4 *)(puVar7 + 9) = 0;
          *(undefined4 *)((longlong)puVar7 + 0x4c) = 0;
          puVar7[10] = DAT_140977388;
          *(undefined4 *)(puVar7 + 6) = 0;
          puVar9 = puVar7;
        }
        *(int *)(param_1 + 0x44) = *(int *)(param_1 + 0x44) + 1;
        *(undefined8 **)(*(longlong *)(param_1 + 0x38) + (longlong)*(int *)(param_1 + 0x40) * 8) =
             puVar9;
        *(int *)(param_1 + 0x40) = *(int *)(param_1 + 0x40) + 1;
      }
      cVar5 = FUN_1405757f0(param_2,puVar9);
      if (cVar5 == '\0') goto LAB_140576129;
      pcVar4 = *(char **)(param_2 + 8);
      if ((*(char **)(param_2 + 0x10) <= pcVar4) || (*pcVar4 != '\n')) break;
      *(char **)(param_2 + 8) = pcVar4 + 1;
    }
  } while ((*(longlong *)(param_2 + 8) != *(longlong *)(param_2 + 0x10)) ||
          ((*(int *)(param_2 + 0x2c) == 0 && (*(int *)(param_2 + 0x18) != *(int *)(param_2 + 0x28)))
          ));
  *(undefined4 *)(param_2 + 0x20) = 0;
  *(undefined1 *)(param_2 + 0x24) = 1;
LAB_140576142:
  FUN_14055a130(local_48);
  FUN_14055c070(local_70);
  return 1;
}

