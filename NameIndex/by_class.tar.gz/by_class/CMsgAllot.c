// ==== CMsgAllot::helper_140184af0  @140184af0  [medium:callgraph-r0]  (orig: FUN_140184af0)
void FUN_140184af0(longlong param_1,int param_2)

{
  int iVar1;
  
  iVar1 = FUN_140371e60(param_1 + 0xe78);
  iVar1 = iVar1 + param_2;
  if (iVar1 < 0) {
    iVar1 = 0;
  }
  FUN_140171510(param_1,iVar1);
  return;
}

// ==== CMsgAllot::ctor_or_dtor  @1404575b0  [high:vtable-assign]  (orig: FUN_1404575b0)
undefined8 * FUN_1404575b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgAllot::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgAllot::ctor_or_dtor  @140457600  [high:vtable-assign]  (orig: FUN_140457600)
void FUN_140457600(undefined8 *param_1)

{
  *param_1 = CMsgAllot::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgAllot::helper_140457630  @140457630  [medium:callgraph-r0]  (orig: FUN_140457630)
undefined8
FUN_140457630(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  ulong uVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x18;
  *(undefined4 *)(param_1 + 8) = 0x400;
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar1;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_6;
  return 1;
}

// ==== CMsgAllot::vfunc_1  @1404576d0  [high:rtti-vtable]  (orig: FUN_1404576d0)
ulonglong FUN_1404576d0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x400);
}

// ==== CMsgAllot::ctor_or_dtor  @140457700  [high:vtable-assign]  (orig: FUN_140457700)
undefined8 * FUN_140457700(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgAllot::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgAllot::vfunc_3  @140457750  [high:rtti-vtable]  (orig: FUN_140457750)
void FUN_140457750(longlong param_1)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  undefined4 *puVar5;
  longlong lVar6;
  char cVar7;
  undefined4 uVar8;
  uint uVar9;
  int iVar10;
  longlong lVar11;
  longlong *plVar12;
  IStringManager *pIVar13;
  undefined8 uVar14;
  int iVar15;
  longlong *local_res8;
  
  lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar11 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar12 = (longlong *)
            (**(code **)(**(longlong **)(lVar11 + 0x88) + 0x18))
                      (*(longlong **)(lVar11 + 0x88),param_1,0);
  if (plVar12 != (longlong *)0x0) {
    local_res8 = (longlong *)0x0;
    (**(code **)(*plVar12 + 0x298))(plVar12,0x1001,&local_res8);
    if (local_res8 != (longlong *)0x0) {
      plVar12 = (longlong *)FUN_1400e1e60();
      puVar5 = *(undefined4 **)(param_1 + 0x428);
      lVar11 = *plVar12;
      lVar6 = local_res8[0x1e2];
      uVar8 = (**(code **)(*local_res8 + 8))();
      (**(code **)(lVar11 + 0x108))(plVar12,uVar8,(int)lVar6,*puVar5);
      cVar7 = (**(code **)(*local_res8 + 0x118))();
      if ((cVar7 == '\0') ||
         (uVar9 = (**(code **)(local_res8[2] + 0x70))(local_res8 + 2), 0x78 < uVar9)) {
        lVar11 = *(longlong *)(param_1 + 0x428);
        uVar1 = *(ushort *)(lVar11 + 8);
        uVar2 = *(ushort *)(lVar11 + 0xc);
        uVar3 = *(ushort *)(lVar11 + 0x10);
        uVar4 = *(ushort *)(lVar11 + 0x14);
        iVar15 = (uint)uVar1 + (uint)uVar3 + (uint)uVar4 + (uint)uVar2;
        if (iVar15 != 0) {
          iVar10 = FUN_140160eb0(local_res8);
          if (iVar10 < iVar15) {
            pIVar13 = theInstance();
            lVar11 = local_res8[2];
            uVar14 = (*(code *)**(undefined8 **)pIVar13)(pIVar13,"STR_CHEAT");
            (**(code **)(lVar11 + 0x358))(local_res8 + 2,uVar14);
          }
          else {
            FUN_140184af0(local_res8,-iVar15);
            if (uVar1 != 0) {
              FUN_140199cb0(local_res8,(uint)*(ushort *)(local_res8 + 0x1db) + (uint)uVar1);
            }
            if (uVar3 != 0) {
              FUN_140199f50(local_res8,(uint)*(ushort *)((longlong)local_res8 + 0xede) + (uint)uVar3
                           );
            }
            if (uVar4 != 0) {
              FUN_140199e70(local_res8,(uint)*(ushort *)(local_res8 + 0x1dc) + (uint)uVar4);
            }
            if (uVar2 != 0) {
              FUN_140199d90(local_res8,(uint)*(ushort *)((longlong)local_res8 + 0xedc) + (uint)uVar2
                           );
            }
            FUN_140457630(param_1,0,0,0,0,0);
            (**(code **)(local_res8[2] + 0x350))(local_res8 + 2,param_1);
          }
        }
      }
    }
  }
  return;
}

