// ==== CNpc::helper_140087b50  @140087b50  [medium:callgraph-r1]  (orig: FUN_140087b50)
longlong FUN_140087b50(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x1b8);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::helper_14016ce10  @14016ce10  [medium:callgraph-r0]  (orig: FUN_14016ce10)
uint FUN_14016ce10(longlong param_1)

{
  uint extraout_var;
  longlong *plVar1;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return extraout_var & 1;
}

// ==== CNpc::helper_140200550  @140200550  [medium:callgraph-r2]  (orig: FUN_140200550)
int FUN_140200550(longlong param_1)

{
  undefined8 uVar1;
  ulong uVar2;
  int iVar3;
  
  if (*(int *)(param_1 + 0x19c) != 0) {
    uVar2 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x19c) + *(int *)(param_1 + 0x198)) <= uVar2 / 1000) {
      uVar2 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x19c) = uVar2 / 1000;
      uVar1 = *(undefined8 *)(param_1 + 0x108);
      uVar2 = tq::TimeGet(0);
      iVar3 = rand();
      srand(iVar3 + uVar2 + (int)uVar1 * 999);
    }
  }
  iVar3 = tq::RandGet(0xed8);
  return iVar3 / 100;
}

// ==== CNpc::helper_1402036b0  @1402036b0  [medium:callgraph-r3]  (orig: FUN_1402036b0)
longlong * FUN_1402036b0(longlong *param_1,longlong *param_2,byte *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x1a) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(byte *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x1a) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(byte *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CNpc::helper_140204a30  @140204a30  [medium:callgraph-r3]  (orig: FUN_140204a30)
ulonglong FUN_140204a30(longlong param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong lVar12;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  ulonglong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x39);
  puVar5 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x39);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar5;
  local_38 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0x80);
  local_18 = plVar3;
  uVar8 = plVar9[1];
  local_10 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_10;
  if (local_10 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    lVar11 = 0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_3 = *(undefined4 *)(uVar6 + 0x1c);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *(undefined1 *)(param_3 + 1) = *(undefined1 *)(uVar6 + 0x20);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    param_3[2] = *(undefined4 *)(uVar6 + 0x24);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    param_3[3] = *(undefined4 *)(uVar6 + 0x28);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    param_3[4] = *(undefined4 *)(uVar6 + 0x2c);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar11;
    }
    else {
      lVar12 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    param_3[5] = *(undefined4 *)(uVar6 + 0x30);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined4 *)(uVar6 + 0x34);
    param_3[6] = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

// ==== CNpc::helper_140205b00  @140205b00  [medium:callgraph-r3]  (orig: FUN_140205b00)
ulonglong FUN_140205b00(longlong param_1,int param_2,int param_3)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  ulonglong uVar1;
  undefined8 *puVar2;
  ulonglong extraout_RAX_02;
  longlong lVar3;
  int local_res10 [2];
  int local_res20;
  int local_res24;
  longlong *local_68;
  longlong lStack_60;
  undefined8 local_48;
  undefined8 local_40;
  undefined8 local_38;
  
  local_res10[0] = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  FUN_140050f20(param_1 + 0xd0,&local_68,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x100);
  if ((local_68 == (longlong *)0x0) || (local_68 != *(longlong **)(param_1 + 0xd0))) {
    _invalid_parameter_noinfo();
  }
  if (lStack_60 == lVar3) {
    log_InlineLogERROR("CRouletteMgr::ProcessChangeToWitness not found data, idUser:%u, idNpc:%u.");
    uVar1 = extraout_RAX_01 & 0xffffffffffffff00;
  }
  else {
    if (local_68 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *local_68;
    }
    if (lStack_60 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)(lStack_60 + 0x1c) == param_3) {
      FUN_14004ee60(param_1 + 0xd0,&local_48,&local_68);
      local_res20 = param_2;
      local_res24 = param_3;
      puVar2 = (undefined8 *)FUN_1400507e0(param_1 + 0x110,&local_68,&local_res20);
      local_48 = *puVar2;
      local_40 = puVar2[1];
      local_38 = puVar2[2];
      if ((char)local_38 == '\0') {
        log_InlineLogERROR(
                          "CRouletteMgr::ProcessChangeToWitness m_mapWitnessUser insert failed, idUser:%u, idNpc:%u, at %s, %d."
                          );
        uVar1 = extraout_RAX_02 & 0xffffffffffffff00;
      }
      else {
        uVar1 = CONCAT71((int7)((ulonglong)local_38 >> 8),1);
      }
    }
    else {
      log_InlineLogERROR(
                        "CRouletteMgr::ProcessChangeToWitness user data error, idUser:%u, idNpc:%u."
                        );
      uVar1 = FUN_14004ee60(param_1 + 0xd0,&local_48,&local_68);
      uVar1 = uVar1 & 0xffffffffffffff00;
    }
  }
  return uVar1;
}

// ==== CNpc::helper_140206780  @140206780  [medium:callgraph-r3]  (orig: FUN_140206780)
void FUN_140206780(longlong *param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  undefined8 *puVar6;
  
  puVar1 = (undefined8 *)param_1[4];
  if (puVar1 < (undefined8 *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  puVar2 = (undefined8 *)param_1[3];
  if ((undefined8 *)param_1[4] < puVar2) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((puVar1 < (undefined8 *)param_1[3]) || ((undefined8 *)param_1[4] < puVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (puVar2 != puVar1) {
    puVar4 = (undefined8 *)param_1[4];
    if (puVar1 != puVar4) {
      puVar6 = puVar1;
      do {
        uVar5 = *puVar6;
        puVar6 = puVar6 + 1;
        *(undefined8 *)((longlong)puVar2 + (-8 - (longlong)puVar1) + (longlong)puVar6) = uVar5;
      } while (puVar6 != puVar4);
    }
    param_1[4] = (longlong)(puVar2 + ((longlong)puVar4 - (longlong)puVar1 >> 3));
  }
  return;
}

// ==== CNpc::helper_140206a10  @140206a10  [medium:callgraph-r3]  (orig: FUN_140206a10)
void FUN_140206a10(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  void *pvVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  
  if (((*(char *)(param_1 + 0x30) + (char)*(longlong *)(param_1 + 0x38) & 1U) == 0) &&
     (*(ulonglong *)(param_1 + 0x28) <= *(longlong *)(param_1 + 0x38) + 2U >> 1)) {
    FUN_140204540(param_1,1);
  }
  uVar3 = *(longlong *)(param_1 + 0x30) + *(longlong *)(param_1 + 0x38);
  uVar4 = uVar3 >> 1;
  if (*(ulonglong *)(param_1 + 0x28) <= uVar4) {
    uVar4 = uVar4 - *(ulonglong *)(param_1 + 0x28);
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) == 0) {
    pvVar2 = operator_new(0x10);
    *(void **)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) = pvVar2;
  }
  puVar1 = (undefined8 *)
           (*(longlong *)(*(longlong *)(param_1 + 0x20) + uVar4 * 8) +
           (ulonglong)((uint)uVar3 & 1) * 8);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = *param_2;
  }
  *(longlong *)(param_1 + 0x38) = *(longlong *)(param_1 + 0x38) + 1;
  return;
}

// ==== CNpc::helper_140207120  @140207120  [medium:callgraph-r2]  (orig: FUN_140207120)
void FUN_140207120(longlong param_1,int param_2,char param_3)

{
  int local_res10 [6];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    if (param_3 != '\0') {
      FUN_140050de0(param_1 + 0x110,local_res10);
      return;
    }
    FUN_140050de0(param_1 + 0xd0,local_res10);
  }
  return;
}

// ==== CNpc::helper_1402079d0  @1402079d0  [medium:callgraph-r2]  (orig: FUN_1402079d0)
void FUN_1402079d0(longlong param_1,longlong param_2)

{
  longlong local_res10 [3];
  
  if (param_2 != 0) {
    local_res10[0] = param_2;
    FUN_140206a10(param_1 + 0x150,local_res10);
  }
  return;
}

// ==== CNpc::helper_140214b70  @140214b70  [medium:callgraph-r1]  (orig: FUN_140214b70)
longlong FUN_140214b70(undefined4 *param_1,longlong *param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  undefined4 local_30 [2];
  longlong local_28;
  undefined1 local_20 [24];
  
  if (param_2 == (longlong *)0x0) {
    lVar4 = 0;
  }
  else {
    lVar3 = FUN_140008520(*param_1);
    lVar3 = *(longlong *)(lVar3 + 0x110);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    lVar4 = 0;
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    cVar1 = FUN_14031bee0(lVar3,uVar2);
    if (cVar1 == '\0') {
      (**(code **)(*param_2 + 8))(param_2);
      log_InlineLogERROR("CTexasMgr::CreateNewTable by NPC[%u], AddTableWittnessMgr");
      lVar4 = 0;
    }
    else {
      lVar3 = FUN_1403bfdd0(0x2e8);
      if (lVar3 != 0) {
        lVar4 = FUN_1403dcb60(lVar3,*param_1);
      }
      if (lVar4 == 0) {
        (**(code **)(*param_2 + 8))(param_2);
        log_InlineLogERROR("CTexasMgr::CreateNewTable by NPC[%u], failed in new TexasHoldEm");
        lVar4 = 0;
      }
      else {
        cVar1 = FUN_1403bfef0(lVar4,param_2);
        if (cVar1 == '\0') {
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("CTexasMgr::CreateNewTable by NPC[%u], failed in create TexasHoldEm");
          FUN_1403dc530(lVar4);
          FUN_1403bfe30(lVar4);
          lVar4 = 0;
        }
        else {
          local_30[0] = FUN_1403bc320(lVar4);
          local_28 = lVar4;
          FUN_140213fe0(param_1 + 8,local_20,local_30);
        }
      }
    }
  }
  return lVar4;
}

// ==== CNpc::helper_1402542d0  @1402542d0  [medium:callgraph-r3]  (orig: FUN_1402542d0)
undefined8 *
FUN_1402542d0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xaaaaaaaaaaaaaa8 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140251ef0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x30);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x30) == '\0') {
        *(undefined1 *)(plVar2 + 6) = 1;
        *(undefined1 *)(lVar4 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x31) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x31) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x30) == '\0') {
        *(undefined1 *)(plVar2 + 6) = 1;
        *(undefined1 *)(lVar4 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x31) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x30) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x30) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x31) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x30);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x30) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CNpc::helper_140255330  @140255330  [medium:callgraph-r2]  (orig: FUN_140255330)
longlong * FUN_140255330(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x31) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x31) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14025548d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402554bc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x31) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x31) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x31);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x31);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x31);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x31);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x31) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x31) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14025548d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1402542d0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402554bc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CNpc::helper_1402564c0  @1402564c0  [medium:callgraph-r1]  (orig: FUN_1402564c0)
undefined1 * FUN_1402564c0(longlong param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  longlong lVar6;
  char *pcVar7;
  char *pcVar8;
  undefined1 uVar9;
  undefined4 local_res18;
  undefined4 local_58;
  int local_54;
  undefined4 local_50;
  undefined4 local_4c;
  int local_48;
  undefined4 local_40;
  undefined4 local_3c;
  int local_38;
  undefined4 local_34;
  undefined4 local_30;
  int local_2c;
  
  if (param_2 == (longlong *)0x0) {
    return &stack0x00000000;
  }
  iVar1 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
  if (iVar1 != 0x3c) {
    return (undefined1 *)0x0;
  }
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
LAB_14025656a:
    tq::MyLogSave("gmlog/Slot","error-->CSlotMgr::LoadSlotNpcInfo. winning rule type is zero!");
    return (undefined1 *)0x0;
  }
  iVar1 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x12);
  if (iVar1 < 1) goto LAB_14025656a;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
LAB_1402565da:
    tq::MyLogSave("gmlog/Slot",
                  "error-->CSlotMgr::LoadSlotNpcInfo. Bet Currency Number less than or equal zero!")
    ;
    return (undefined1 *)0x0;
  }
  iVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x13);
  if (iVar2 < 1) goto LAB_1402565da;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x14);
    if (iVar3 != 0) {
      if (iVar3 != 1) {
        tq::MyLogSave("gmlog/Slot","error-->CSlotMgr::LoadSlotNpcInfo. Currency Type error!");
        return (undefined1 *)0x0;
      }
      local_res18 = 1;
      goto LAB_14025666f;
    }
  }
  local_res18 = 0;
  iVar2 = iVar2 * 10000;
LAB_14025666f:
  iVar3 = 1;
  pcVar8 = (char *)0x0;
  uVar9 = param_2[0xc] == 0;
  if ((bool)uVar9) {
    log_InlineLogERROR(&DAT_1406d9c10);
    pcVar5 = pcVar8;
  }
  else {
    pcVar5 = (char *)(**(code **)(*(longlong *)param_2[0xc] + 0x18))((longlong *)param_2[0xc],0x16);
  }
  lVar6 = 2;
  pcVar7 = "0";
  do {
    if (lVar6 == 0) break;
    lVar6 = lVar6 + -1;
    uVar9 = *pcVar5 == *pcVar7;
    pcVar5 = pcVar5 + 1;
    pcVar7 = pcVar7 + 1;
  } while ((bool)uVar9);
  if (!(bool)uVar9) {
    uVar9 = param_2[0xc] == 0;
    if ((bool)uVar9) {
      log_InlineLogERROR(&DAT_1406d9c10);
      pcVar5 = pcVar8;
    }
    else {
      pcVar5 = (char *)(**(code **)(*(longlong *)param_2[0xc] + 0x18))
                                 ((longlong *)param_2[0xc],0x16);
    }
    lVar6 = 2;
    pcVar7 = "1";
    do {
      if (lVar6 == 0) break;
      lVar6 = lVar6 + -1;
      uVar9 = *pcVar5 == *pcVar7;
      pcVar5 = pcVar5 + 1;
      pcVar7 = pcVar7 + 1;
    } while ((bool)uVar9);
    iVar3 = 0;
    if ((bool)uVar9) {
      iVar3 = 2;
    }
  }
  if (iVar3 == 1) {
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x15);
      pcVar8 = (char *)(ulonglong)uVar4;
      if ((int)uVar4 < 0) {
        tq::MyLogSave("gmlog/Slot","error-->CSlotMgr::LoadSlotNpcInfo. Lose Prize error!");
        return (undefined1 *)0x0;
      }
    }
  }
  else if (iVar3 == 2) {
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x15);
      pcVar8 = (char *)(ulonglong)uVar4;
      if ((int)uVar4 < 0) {
        tq::MyLogSave("gmlog/Slot","error-->CSlotMgr::LoadSlotNpcInfo. Lose Prize error!");
        return (undefined1 *)0x0;
      }
    }
  }
  local_58 = CONCAT31((int3)((uint)local_58 >> 8),(char)iVar1);
  local_50 = local_res18;
  local_4c = SUB84(pcVar8,0);
  local_54 = iVar2;
  local_48 = iVar3;
  local_40 = (**(code **)(*param_2 + 8))(param_2);
  local_3c = local_58;
  local_38 = local_54;
  local_34 = local_50;
  local_30 = local_4c;
  local_2c = local_48;
  FUN_140255330(param_1 + 0x58,&local_58,&local_40);
  return (undefined1 *)0x1;
}

// ==== CNpc::helper_1402ba560  @1402ba560  [medium:callgraph-r0]  (orig: FUN_1402ba560)
undefined8 FUN_1402ba560(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  if (iVar1 != 10) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
    if (iVar1 != 0x2e) {
      return 0;
    }
  }
  return 1;
}

// ==== CNpc::helper_1402ba780  @1402ba780  [medium:callgraph-r1]  (orig: FUN_1402ba780)
undefined8 FUN_1402ba780(void)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_14046a2a0(0x20);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_14046a3c0(lVar1);
  }
  return uVar2;
}

// ==== CNpc::ctor_or_dtor  @1402ba8a0  [high:vtable-assign]  (orig: FUN_1402ba8a0)
void FUN_1402ba8a0(undefined8 *param_1)

{
  *param_1 = CNpc::vftable;
  param_1[2] = CNpc::vftable;
  param_1[3] = CNpc::vftable;
  param_1[3] = IMapThing::vftable;
  param_1[2] = IRole::vftable;
  FUN_1402b55a0();
  return;
}

// ==== CNpc::vfunc_4  @1402ba900  [high:rtti-vtable]  (orig: FUN_1402ba900)
void FUN_1402ba900(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(plVar1);
  uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar4 = (**(code **)(*plVar1 + 0x160))(plVar1);
  FUN_1402c84c0(uVar4,uVar3,uVar2,param_2,param_3,param_4);
  return;
}

// ==== CNpc::vfunc_1  @1402ba980  [high:rtti-vtable]  (orig: FUN_1402ba980)
undefined4 FUN_1402ba980(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x58);
}

// ==== CNpc::vfunc_2  @1402ba990  [high:rtti-vtable]  (orig: FUN_1402ba990)
undefined4 FUN_1402ba990(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CNpc::vfunc_8  @1402ba9a0  [high:rtti-vtable]  (orig: FUN_1402ba9a0)
undefined4 FUN_1402ba9a0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x10);
}

// ==== CNpc::vfunc_9  @1402ba9b0  [high:rtti-vtable]  (orig: FUN_1402ba9b0)
undefined4 FUN_1402ba9b0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x14);
}

// ==== CNpc::vfunc_5  @1402ba9c0  [high:rtti-vtable]  (orig: FUN_1402ba9c0)
void FUN_1402ba9c0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402ba9cc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),7);
  return;
}

// ==== CNpc::vfunc_6  @1402ba9d0  [high:rtti-vtable]  (orig: FUN_1402ba9d0)
void FUN_1402ba9d0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402ba9dc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),8);
  return;
}

// ==== CNpc::vfunc_7  @1402ba9e0  [high:rtti-vtable]  (orig: FUN_1402ba9e0)
void FUN_1402ba9e0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402ba9ec. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),9);
  return;
}

// ==== CNpc::vfunc_4  @1402ba9f0  [high:rtti-vtable]  (orig: FUN_1402ba9f0)
undefined8 FUN_1402ba9f0(void)

{
  return 0;
}

// ==== CNpc::vfunc_5  @1402baa00  [high:rtti-vtable]  (orig: FUN_1402baa00)
undefined8 FUN_1402baa00(void)

{
  return 0;
}

// ==== CNpc::vfunc_7  @1402baa10  [high:rtti-vtable]  (orig: FUN_1402baa10)
undefined2 FUN_1402baa10(longlong param_1)

{
  undefined2 uVar1;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x11)
  ;
  return uVar1;
}

// ==== CNpc::vfunc_10  @1402baa30  [high:rtti-vtable]  (orig: FUN_1402baa30)
int FUN_1402baa30(longlong param_1)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),5);
  uVar2 = iVar1 % 10 >> 0x1f & 7;
  return (iVar1 % 10 + uVar2 & 7) - uVar2;
}

// ==== CNpc::vfunc_11  @1402baa80  [high:rtti-vtable]  (orig: FUN_1402baa80)
undefined4 * FUN_1402baa80(longlong param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0x70);
  param_2[1] = *(undefined4 *)(param_1 + 0x74);
  param_2[2] = *(undefined4 *)(param_1 + 0x78);
  param_2[3] = *(undefined4 *)(param_1 + 0x7c);
  param_2[4] = *(undefined4 *)(param_1 + 0x80);
  param_2[5] = *(undefined4 *)(param_1 + 0x84);
  return param_2;
}

// ==== CNpc::vfunc_12  @1402baab0  [high:rtti-vtable]  (orig: FUN_1402baab0)
void FUN_1402baab0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402baabc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0xf);
  return;
}

// ==== CNpc::vfunc_13  @1402baac0  [high:rtti-vtable]  (orig: FUN_1402baac0)
undefined8 FUN_1402baac0(void)

{
  return 0;
}

// ==== CNpc::vfunc_15  @1402baad0  [high:rtti-vtable]  (orig: FUN_1402baad0)
void FUN_1402baad0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402baadc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x18);
  return;
}

// ==== CNpc::vfunc_16  @1402baae0  [high:rtti-vtable]  (orig: FUN_1402baae0)
void FUN_1402baae0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402baaec. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x19);
  return;
}

// ==== CNpc::vfunc_17  @1402baaf0  [high:rtti-vtable]  (orig: FUN_1402baaf0)
undefined8 FUN_1402baaf0(void)

{
  return 0;
}

// ==== CNpc::vfunc_18  @1402bab00  [high:rtti-vtable]  (orig: FUN_1402bab00)
undefined8 FUN_1402bab00(void)

{
  return 0;
}

// ==== CNpc::vfunc_19  @1402bab10  [high:rtti-vtable]  (orig: FUN_1402bab10)
undefined8 FUN_1402bab10(void)

{
  return 0;
}

// ==== CNpc::vfunc_20  @1402bab20  [high:rtti-vtable]  (orig: FUN_1402bab20)
undefined8 FUN_1402bab20(void)

{
  return 0;
}

// ==== CNpc::vfunc_21  @1402bab30  [high:rtti-vtable]  (orig: FUN_1402bab30)
void FUN_1402bab30(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402bab3c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x1f);
  return;
}

// ==== CNpc::vfunc_22  @1402bab40  [high:rtti-vtable]  (orig: FUN_1402bab40)
void FUN_1402bab40(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402bab4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x1f);
  return;
}

// ==== CNpc::vfunc_23  @1402bab50  [high:rtti-vtable]  (orig: FUN_1402bab50)
undefined8 FUN_1402bab50(void)

{
  return 0;
}

// ==== CNpc::vfunc_24  @1402bab60  [high:rtti-vtable]  (orig: FUN_1402bab60)
undefined8 FUN_1402bab60(void)

{
  return 0;
}

// ==== CNpc::vfunc_25  @1402bab70  [high:rtti-vtable]  (orig: FUN_1402bab70)
undefined8 FUN_1402bab70(void)

{
  return 0;
}

// ==== CNpc::vfunc_26  @1402bab80  [high:rtti-vtable]  (orig: FUN_1402bab80)
undefined8 FUN_1402bab80(void)

{
  return 0;
}

// ==== CNpc::vfunc_27  @1402bab90  [high:rtti-vtable]  (orig: FUN_1402bab90)
undefined8 FUN_1402bab90(void)

{
  return 0;
}

// ==== CNpc::vfunc_28  @1402baba0  [high:rtti-vtable]  (orig: FUN_1402baba0)
void FUN_1402baba0(longlong param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402babac. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x20);
  return;
}

// ==== CNpc::vfunc_29  @1402babb0  [high:rtti-vtable]  (orig: FUN_1402babb0)
undefined8 FUN_1402babb0(void)

{
  return 0;
}

// ==== CNpc::vfunc_30  @1402babc0  [high:rtti-vtable]  (orig: FUN_1402babc0)
undefined8 FUN_1402babc0(void)

{
  return 0;
}

// ==== CNpc::vfunc_35  @1402babd0  [high:rtti-vtable]  (orig: FUN_1402babd0)
undefined8 FUN_1402babd0(void)

{
  return 0;
}

// ==== CNpc::vfunc_40  @1402babe0  [high:rtti-vtable]  (orig: FUN_1402babe0)
undefined8 FUN_1402babe0(void)

{
  return 0;
}

// ==== CNpc::vfunc_36  @1402babf0  [high:rtti-vtable]  (orig: FUN_1402babf0)
undefined8 FUN_1402babf0(void)

{
  return 0;
}

// ==== CNpc::vfunc_37  @1402bac00  [high:rtti-vtable]  (orig: FUN_1402bac00)
undefined8 FUN_1402bac00(void)

{
  return 0;
}

// ==== CNpc::vfunc_38  @1402bac10  [high:rtti-vtable]  (orig: FUN_1402bac10)
undefined8 FUN_1402bac10(void)

{
  return 0;
}

// ==== CNpc::vfunc_39  @1402bac20  [high:rtti-vtable]  (orig: FUN_1402bac20)
undefined8 FUN_1402bac20(void)

{
  return 0;
}

// ==== CNpc::vfunc_41  @1402bac30  [high:rtti-vtable]  (orig: FUN_1402bac30)
undefined8 FUN_1402bac30(void)

{
  return 0;
}

// ==== CNpc::vfunc_43  @1402bac40  [high:rtti-vtable]  (orig: FUN_1402bac40)
int FUN_1402bac40(longlong *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = (**(code **)(*param_1 + 0x40))();
  uVar3 = iVar1 - param_2 >> 0x1f;
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar4 = iVar2 - param_3 >> 0x1f;
  if ((int)((iVar2 - param_3 ^ uVar4) - uVar4) < (int)((iVar1 - param_2 ^ uVar3) - uVar3)) {
    iVar1 = (**(code **)(*param_1 + 0x40))();
    uVar3 = iVar1 - param_2;
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    uVar3 = iVar1 - param_3;
  }
  return (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f);
}

// ==== CNpc::vfunc_42  @1402bacb0  [high:rtti-vtable]  (orig: FUN_1402bacb0)
int FUN_1402bacb0(longlong *param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar5 = iVar2 - iVar1 >> 0x1f;
  iVar3 = (**(code **)(*param_2 + 0x20))(param_2);
  iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar6 = iVar4 - iVar3 >> 0x1f;
  if ((int)((iVar2 - iVar1 ^ uVar5) - uVar5) < (int)((iVar4 - iVar3 ^ uVar6) - uVar6)) {
    iVar1 = (**(code **)(*param_2 + 0x20))();
    iVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  }
  else {
    iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
    iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  }
  uVar5 = iVar2 - iVar1 >> 0x1f;
  return (iVar2 - iVar1 ^ uVar5) - uVar5;
}

// ==== CNpc::vfunc_44  @1402bad50  [high:rtti-vtable]  (orig: FUN_1402bad50)
longlong FUN_1402bad50(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x60);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_51  @1402bad90  [high:rtti-vtable]  (orig: FUN_1402bad90)
undefined8 FUN_1402bad90(void)

{
  return 0;
}

// ==== CNpc::vfunc_52  @1402bada0  [high:rtti-vtable]  (orig: FUN_1402bada0)
undefined8 FUN_1402bada0(void)

{
  return 0;
}

// ==== CNpc::vfunc_53  @1402badb0  [high:rtti-vtable]  (orig: FUN_1402badb0)
undefined8 FUN_1402badb0(void)

{
  return 0;
}

// ==== CNpc::vfunc_46  @1402badc0  [high:rtti-vtable]  (orig: FUN_1402badc0)
undefined8 FUN_1402badc0(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),2);
  if (iVar1 == 2) {
                    /* WARNING: Could not recover jumptable at 0x0001402badee. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
    return uVar2;
  }
  return 0;
}

// ==== CNpc::vfunc_47  @1402bae00  [high:rtti-vtable]  (orig: FUN_1402bae00)
int FUN_1402bae00(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x11)
  ;
  return iVar1 >> 0x10;
}

// ==== CNpc::vfunc_48  @1402bae20  [high:rtti-vtable]  (orig: FUN_1402bae20)
undefined1 FUN_1402bae20(void)

{
  return 0;
}

// ==== CNpc::vfunc_49  @1402bae30  [high:rtti-vtable]  (orig: FUN_1402bae30)
undefined1 FUN_1402bae30(void)

{
  return 0;
}

// ==== CNpc::vfunc_50  @1402bae40  [high:rtti-vtable]  (orig: FUN_1402bae40)
undefined8 FUN_1402bae40(void)

{
  return 0;
}

// ==== CNpc::vfunc_54  @1402bae50  [high:rtti-vtable]  (orig: FUN_1402bae50)
undefined8 FUN_1402bae50(void)

{
  return 0;
}

// ==== CNpc::vfunc_55  @1402bae60  [high:rtti-vtable]  (orig: FUN_1402bae60)
undefined8 FUN_1402bae60(void)

{
  return 0;
}

// ==== CNpc::vfunc_56  @1402bae70  [high:rtti-vtable]  (orig: FUN_1402bae70)
undefined8 FUN_1402bae70(void)

{
  return 0;
}

// ==== CNpc::vfunc_8  @1402bae80  [high:rtti-vtable]  (orig: FUN_1402bae80)
undefined1 FUN_1402bae80(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x98);
}

// ==== CNpc::vfunc_57  @1402bae90  [high:rtti-vtable]  (orig: FUN_1402bae90)
undefined1 FUN_1402bae90(void)

{
  return 0;
}

// ==== CNpc::vfunc_58  @1402baea0  [high:rtti-vtable]  (orig: FUN_1402baea0)
undefined1 FUN_1402baea0(void)

{
  return 0;
}

// ==== CNpc::vfunc_59  @1402baeb0  [high:rtti-vtable]  (orig: FUN_1402baeb0)
undefined8 FUN_1402baeb0(void)

{
  return 0;
}

// ==== CNpc::vfunc_80  @1402baec0  [high:rtti-vtable]  (orig: FUN_1402baec0)
undefined1 FUN_1402baec0(void)

{
  return 0;
}

// ==== CNpc::vfunc_60  @1402baed0  [high:rtti-vtable]  (orig: FUN_1402baed0)
undefined8 FUN_1402baed0(void)

{
  return 0;
}

// ==== CNpc::vfunc_61  @1402baee0  [high:rtti-vtable]  (orig: FUN_1402baee0)
undefined8 FUN_1402baee0(void)

{
  return 0;
}

// ==== CNpc::vfunc_62  @1402baef0  [high:rtti-vtable]  (orig: FUN_1402baef0)
undefined8 FUN_1402baef0(void)

{
  return 0;
}

// ==== CNpc::vfunc_63  @1402baf00  [high:rtti-vtable]  (orig: FUN_1402baf00)
undefined8 FUN_1402baf00(void)

{
  return 0;
}

// ==== CNpc::vfunc_64  @1402baf10  [high:rtti-vtable]  (orig: FUN_1402baf10)
undefined8 FUN_1402baf10(void)

{
  return 0;
}

// ==== CNpc::vfunc_65  @1402baf20  [high:rtti-vtable]  (orig: FUN_1402baf20)
undefined8 FUN_1402baf20(void)

{
  return 0;
}

// ==== CNpc::vfunc_66  @1402baf30  [high:rtti-vtable]  (orig: FUN_1402baf30)
undefined8 FUN_1402baf30(void)

{
  return 0;
}

// ==== CNpc::vfunc_67  @1402baf40  [high:rtti-vtable]  (orig: FUN_1402baf40)
undefined8 FUN_1402baf40(void)

{
  return 0;
}

// ==== CNpc::vfunc_69  @1402baf50  [high:rtti-vtable]  (orig: FUN_1402baf50)
undefined1 FUN_1402baf50(void)

{
  return 0;
}

// ==== CNpc::vfunc_70  @1402baf60  [high:rtti-vtable]  (orig: FUN_1402baf60)
undefined1 FUN_1402baf60(void)

{
  return 0;
}

// ==== CNpc::vfunc_71  @1402baf70  [high:rtti-vtable]  (orig: FUN_1402baf70)
undefined1 FUN_1402baf70(void)

{
  return 0;
}

// ==== CNpc::vfunc_72  @1402baf80  [high:rtti-vtable]  (orig: FUN_1402baf80)
undefined1 FUN_1402baf80(void)

{
  return 0;
}

// ==== CNpc::vfunc_74  @1402baf90  [high:rtti-vtable]  (orig: FUN_1402baf90)
undefined1 FUN_1402baf90(void)

{
  return 0;
}

// ==== CNpc::vfunc_75  @1402bafa0  [high:rtti-vtable]  (orig: FUN_1402bafa0)
undefined1 FUN_1402bafa0(void)

{
  return 1;
}

// ==== CNpc::vfunc_76  @1402bafb0  [high:rtti-vtable]  (orig: FUN_1402bafb0)
undefined1 FUN_1402bafb0(void)

{
  return 0;
}

// ==== CNpc::vfunc_77  @1402bafc0  [high:rtti-vtable]  (orig: FUN_1402bafc0)
undefined1 FUN_1402bafc0(void)

{
  return 0;
}

// ==== CNpc::vfunc_78  @1402bafd0  [high:rtti-vtable]  (orig: FUN_1402bafd0)
undefined1 FUN_1402bafd0(void)

{
  return 0;
}

// ==== CNpc::vfunc_79  @1402bafe0  [high:rtti-vtable]  (orig: FUN_1402bafe0)
undefined1 FUN_1402bafe0(void)

{
  return 0;
}

// ==== CNpc::vfunc_81  @1402baff0  [high:rtti-vtable]  (orig: FUN_1402baff0)
undefined1 FUN_1402baff0(void)

{
  return 0;
}

// ==== CNpc::vfunc_82  @1402bb000  [high:rtti-vtable]  (orig: FUN_1402bb000)
undefined1 FUN_1402bb000(void)

{
  return 0;
}

// ==== CNpc::vfunc_83  @1402bb010  [high:rtti-vtable]  (orig: FUN_1402bb010)
ulonglong FUN_1402bb010(longlong param_1,int param_2,longlong *param_3)

{
  ulonglong in_RAX;
  
  if (param_2 == 0x1040) {
    *param_3 = param_1 + -0x10;
    return CONCAT71((int7)((ulonglong)(param_1 + -0x10) >> 8),1);
  }
  *param_3 = 0;
  return in_RAX & 0xffffffffffffff00;
}

// ==== CNpc::vfunc_84  @1402bb030  [high:rtti-vtable]  (orig: FUN_1402bb030)
longlong FUN_1402bb030(longlong param_1)

{
  if (param_1 != 0x10) {
    return param_1 + 8;
  }
  return 0;
}

// ==== CNpc::vfunc_85  @1402bb050  [high:rtti-vtable]  (orig: FUN_1402bb050)
void FUN_1402bb050(longlong *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = (**(code **)(*param_1 + 0x48))();
  uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar3 = (**(code **)(*param_1 + 0x160))(param_1);
  FUN_1402c8700(uVar3,uVar2,uVar1,param_2);
  return;
}

// ==== CNpc::vfunc_8  @1402bb0b0  [high:rtti-vtable]  (orig: FUN_1402bb0b0)
undefined8 FUN_1402bb0b0(longlong param_1,longlong *param_2)

{
  if (param_1 != 0x18) {
    *param_2 = param_1 + -8;
    return CONCAT71((int7)((ulonglong)(param_1 + -8) >> 8),1);
  }
  *param_2 = 0;
  return 1;
}

// ==== CNpc::vfunc_86  @1402bb0d0  [high:rtti-vtable]  (orig: FUN_1402bb0d0)
undefined8 FUN_1402bb0d0(void)

{
  return 0;
}

// ==== CNpc::vfunc_87  @1402bb0e0  [high:rtti-vtable]  (orig: FUN_1402bb0e0)
void FUN_1402bb0e0(void)

{
  return;
}

// ==== CNpc::vfunc_88  @1402bb0f0  [high:rtti-vtable]  (orig: FUN_1402bb0f0)
void FUN_1402bb0f0(void)

{
  return;
}

// ==== CNpc::vfunc_93  @1402bb100  [high:rtti-vtable]  (orig: FUN_1402bb100)
void FUN_1402bb100(void)

{
  return;
}

// ==== CNpc::vfunc_95  @1402bb110  [high:rtti-vtable]  (orig: FUN_1402bb110)
undefined8 FUN_1402bb110(void)

{
  return 0;
}

// ==== CNpc::vfunc_96  @1402bb120  [high:rtti-vtable]  (orig: FUN_1402bb120)
undefined4 FUN_1402bb120(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CNpc::vfunc_97  @1402bb130  [high:rtti-vtable]  (orig: FUN_1402bb130)
undefined4 FUN_1402bb130(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CNpc::vfunc_98  @1402bb140  [high:rtti-vtable]  (orig: FUN_1402bb140)
undefined4 FUN_1402bb140(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CNpc::vfunc_99  @1402bb150  [high:rtti-vtable]  (orig: FUN_1402bb150)
undefined4 FUN_1402bb150(undefined8 param_1,undefined4 param_2)

{
  return param_2;
}

// ==== CNpc::vfunc_100  @1402bb160  [high:rtti-vtable]  (orig: FUN_1402bb160)
undefined4 FUN_1402bb160(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  return param_3;
}

// ==== CNpc::vfunc_101  @1402bb170  [high:rtti-vtable]  (orig: FUN_1402bb170)
undefined4 FUN_1402bb170(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  return param_3;
}

// ==== CNpc::vfunc_102  @1402bb180  [high:rtti-vtable]  (orig: FUN_1402bb180)
void FUN_1402bb180(void)

{
  return;
}

// ==== CNpc::vfunc_9  @1402bb190  [high:rtti-vtable]  (orig: FUN_1402bb190)
void FUN_1402bb190(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x98) = param_2;
  return;
}

// ==== CNpc::vfunc_106  @1402bb1a0  [high:rtti-vtable]  (orig: FUN_1402bb1a0)
undefined1 FUN_1402bb1a0(void)

{
  return 1;
}

// ==== CNpc::vfunc_107  @1402bb1b0  [high:rtti-vtable]  (orig: FUN_1402bb1b0)
undefined1 FUN_1402bb1b0(void)

{
  return 1;
}

// ==== CNpc::vfunc_109  @1402bb1c0  [high:rtti-vtable]  (orig: FUN_1402bb1c0)
undefined1 FUN_1402bb1c0(void)

{
  return 0;
}

// ==== CNpc::vfunc_111  @1402bb1d0  [high:rtti-vtable]  (orig: FUN_1402bb1d0)
void FUN_1402bb1d0(void)

{
  return;
}

// ==== CNpc::vfunc_94  @1402bb1e0  [high:rtti-vtable]  (orig: FUN_1402bb1e0)
void FUN_1402bb1e0(longlong *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x40))();
  *param_2 = uVar1;
  uVar1 = (**(code **)(*param_1 + 0x48))(param_1);
  *param_3 = uVar1;
  return;
}

// ==== CNpc::vfunc_112  @1402bb220  [high:rtti-vtable]  (orig: FUN_1402bb220)
void FUN_1402bb220(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001402bb225. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x388))(param_1,0);
  return;
}

// ==== CNpc::vfunc_113  @1402bb230  [high:rtti-vtable]  (orig: FUN_1402bb230)
undefined1 FUN_1402bb230(void)

{
  return 1;
}

// ==== CNpc::vfunc_114  @1402bb240  [high:rtti-vtable]  (orig: FUN_1402bb240)
undefined1 FUN_1402bb240(void)

{
  return 0;
}

// ==== CNpc::vfunc_115  @1402bb250  [high:rtti-vtable]  (orig: FUN_1402bb250)
undefined1 FUN_1402bb250(void)

{
  return 0;
}

// ==== CNpc::vfunc_116  @1402bb260  [high:rtti-vtable]  (orig: FUN_1402bb260)
undefined1 FUN_1402bb260(void)

{
  return 0;
}

// ==== CNpc::vfunc_117  @1402bb270  [high:rtti-vtable]  (orig: FUN_1402bb270)
undefined8 FUN_1402bb270(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpc::vfunc_120  @1402bb2b0  [high:rtti-vtable]  (orig: FUN_1402bb2b0)
undefined1 FUN_1402bb2b0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpc::vfunc_121  @1402bb2f0  [high:rtti-vtable]  (orig: FUN_1402bb2f0)
void FUN_1402bb2f0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CNpc::vfunc_123  @1402bb330  [high:rtti-vtable]  (orig: FUN_1402bb330)
undefined1 FUN_1402bb330(void)

{
  return 0;
}

// ==== CNpc::vfunc_125  @1402bb340  [high:rtti-vtable]  (orig: FUN_1402bb340)
undefined8 FUN_1402bb340(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpc::vfunc_127  @1402bb380  [high:rtti-vtable]  (orig: FUN_1402bb380)
void FUN_1402bb380(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CNpc::vfunc_10  @1402bb3c0  [high:rtti-vtable]  (orig: FUN_1402bb3c0)
bool FUN_1402bb3c0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  return iVar1 == 1;
}

// ==== CNpc::vfunc_11  @1402bb3e0  [high:rtti-vtable]  (orig: FUN_1402bb3e0)
longlong FUN_1402bb3e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x28);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_13  @1402bb420  [high:rtti-vtable]  (orig: FUN_1402bb420)
longlong FUN_1402bb420(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x30);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_14  @1402bb460  [high:rtti-vtable]  (orig: FUN_1402bb460)
bool FUN_1402bb460(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  return iVar1 == 3;
}

// ==== CNpc::vfunc_15  @1402bb480  [high:rtti-vtable]  (orig: FUN_1402bb480)
undefined8 FUN_1402bb480(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  if (iVar1 != 4) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
    if (iVar1 != 0x14) {
      return 0;
    }
  }
  return 1;
}

// ==== CNpc::vfunc_17  @1402bb4d0  [high:rtti-vtable]  (orig: FUN_1402bb4d0)
uint FUN_1402bb4d0(longlong param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),0x1b)
  ;
  return uVar1 >> 2 & 1;
}

// ==== CNpc::vfunc_18  @1402bb4f0  [high:rtti-vtable]  (orig: FUN_1402bb4f0)
longlong FUN_1402bb4f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x38);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_19  @1402bb530  [high:rtti-vtable]  (orig: FUN_1402bb530)
uint FUN_1402bb530(longlong param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),0x1b)
  ;
  return uVar1 >> 3 & 1;
}

// ==== CNpc::vfunc_20  @1402bb550  [high:rtti-vtable]  (orig: FUN_1402bb550)
longlong FUN_1402bb550(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x40);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_21  @1402bb590  [high:rtti-vtable]  (orig: FUN_1402bb590)
bool FUN_1402bb590(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  return iVar1 == 0x13;
}

// ==== CNpc::vfunc_22  @1402bb5b0  [high:rtti-vtable]  (orig: FUN_1402bb5b0)
longlong FUN_1402bb5b0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = *(longlong *)(param_1 + 0x48);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CNpc::vfunc_31  @1402bb7a0  [high:rtti-vtable]  (orig: FUN_1402bb7a0)
undefined8 FUN_1402bb7a0(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (iVar1 != 0x14) {
                    /* WARNING: Could not recover jumptable at 0x0001402bb7d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),10)
    ;
    return uVar3;
  }
  lVar4 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
  if (lVar4 != 0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
    lVar4 = *plVar5;
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
    (**(code **)(lVar4 + 0x78))(plVar5,uVar2,0x14);
  }
  return 0;
}

// ==== CNpc::vfunc_32  @1402bb840  [high:rtti-vtable]  (orig: FUN_1402bb840)
undefined8 FUN_1402bb840(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (iVar1 != 0x14) {
                    /* WARNING: Could not recover jumptable at 0x0001402bb877. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                      (*(longlong **)(param_1 + 0x50),0xb);
    return uVar3;
  }
  lVar4 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
  if (lVar4 != 0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
    lVar4 = *plVar5;
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
    (**(code **)(lVar4 + 0x78))(plVar5,uVar2,0x14);
  }
  return 0;
}

// ==== CNpc::vfunc_33  @1402bb8e0  [high:rtti-vtable]  (orig: FUN_1402bb8e0)
undefined8 FUN_1402bb8e0(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (iVar1 != 0x14) {
                    /* WARNING: Could not recover jumptable at 0x0001402bb917. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                      (*(longlong **)(param_1 + 0x50),0xc);
    return uVar3;
  }
  lVar4 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
  if (lVar4 != 0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
    lVar4 = *plVar5;
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
    (**(code **)(lVar4 + 0x78))(plVar5,uVar2,0x14);
  }
  return 0;
}

// ==== CNpc::vfunc_34  @1402bb980  [high:rtti-vtable]  (orig: FUN_1402bb980)
undefined8 FUN_1402bb980(longlong param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (iVar1 != 0x14) {
                    /* WARNING: Could not recover jumptable at 0x0001402bb9b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                      (*(longlong **)(param_1 + 0x50),0xd);
    return uVar3;
  }
  lVar4 = (**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
  if (lVar4 != 0) {
    plVar5 = (longlong *)(**(code **)(*(longlong *)(param_1 + -0x10) + 0x80))(param_1 + -0x10);
    lVar4 = *plVar5;
    uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
    (**(code **)(lVar4 + 0x78))(plVar5,uVar2,0x14);
  }
  return 0;
}

// ==== CNpc::vfunc_45  @1402bbcc0  [high:rtti-vtable]  (orig: FUN_1402bbcc0)
undefined8 FUN_1402bbcc0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402bbd07. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
  return uVar1;
}

// ==== CNpc::vfunc_105  @1402bbd10  [high:rtti-vtable]  (orig: FUN_1402bbd10)
void FUN_1402bbd10(longlong *param_1,longlong param_2,undefined1 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = (**(code **)(*param_1 + 0x160))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar2 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
  lVar1 = *plVar2;
  uVar3 = (**(code **)(*param_1 + 0x2a0))(param_1);
                    /* WARNING: Could not recover jumptable at 0x0001402bbe06. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(lVar1 + 0x30))(plVar2,uVar3,param_2,param_3);
  return;
}

// ==== CNpc::vfunc_104  @1402bbe10  [high:rtti-vtable]  (orig: FUN_1402bbe10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402bbe10(longlong *param_1,longlong param_2,undefined1 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_2 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x39f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14015b240(local_488);
    uVar2 = (**(code **)(*param_1 + 0x18))(param_1);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = 0x7d5;
    local_4d0 = 0xff0000;
    local_4d8 = 0;
    iVar1 = FUN_14015b300(local_488,uVar2,"ALLUSERS",param_2);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0x348))(param_1,local_488,param_3);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CNpc::vfunc_118  @1402bbf10  [high:rtti-vtable]  (orig: FUN_1402bbf10)
undefined4 FUN_1402bbf10(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  if (*(char *)(param_1 + 0x58) == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return param_3;
}

// ==== CNpc::vfunc_119  @1402bbf60  [high:rtti-vtable]  (orig: FUN_1402bbf60)
undefined4 FUN_1402bbf60(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  if (*(char *)(param_1 + 0x58) == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return param_3;
}

// ==== CNpc::vfunc_103  @1402bbfb0  [high:rtti-vtable]  (orig: FUN_1402bbfb0)
void FUN_1402bbfb0(longlong param_1)

{
  if ((*(longlong *)(param_1 + 0x50) != 0) && (*(char *)(param_1 + 0x58) != '\0')) {
    (**(code **)(**(longlong **)(param_1 + 0x50) + 0x70))();
  }
  return;
}

// ==== CNpc::vfunc_110  @1402bbfd0  [high:rtti-vtable]  (orig: FUN_1402bbfd0)
void FUN_1402bbfd0(void)

{
  return;
}

// ==== CNpc::helper_1402bc390  @1402bc390  [medium:callgraph-r0]  (orig: FUN_1402bc390)
ulonglong FUN_1402bc390(longlong param_1)

{
  uint uVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong extraout_RAX;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),0x1b)
  ;
  uVar1 = uVar1 & 0x58;
  uVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  if (((int)uVar3 == 0xf) && (uVar1 != 0)) {
LAB_1402bc41c:
    return uVar3 & 0xffffffffffffff00;
  }
  uVar3 = 0;
  do {
    if (uVar1 == 0) break;
    if ((uVar1 & 1) != 0) {
      uVar1 = uVar1 >> 1;
      if (uVar1 != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar3 = extraout_RAX;
        goto LAB_1402bc41c;
      }
    }
    uVar2 = (int)uVar3 + 1;
    uVar3 = (ulonglong)uVar2;
  } while ((int)uVar2 < 0x20);
  return CONCAT71((int7)(uVar3 >> 8),1);
}

// ==== CNpc::vfunc_6  @1402bc430  [high:rtti-vtable]  (orig: FUN_1402bc430)
void FUN_1402bc430(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (iVar1 == 0x3e) {
    if (*(int *)(param_1 + 0xb8) != 0) {
      return;
    }
  }
  else {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
    uVar2 = 0x10;
    if (iVar1 == 9) goto LAB_1402bc477;
  }
  uVar2 = 5;
LAB_1402bc477:
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),uVar2);
  return;
}

// ==== CNpc::vfunc_12  @1402bc490  [high:rtti-vtable]  (orig: FUN_1402bc490)
undefined8 FUN_1402bc490(longlong param_1)

{
  int iVar1;
  ulonglong uVar2;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  if (iVar1 != 2) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
    if (iVar1 != 8) {
      iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                        (*(longlong **)(param_1 + 0x60),4);
      if (iVar1 != 0x26) {
        iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                          (*(longlong **)(param_1 + 0x60),4);
        if (iVar1 != 0x1e) {
          uVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                            (*(longlong **)(param_1 + 0x60),0x1b);
          if ((uVar2 & 1) == 0) {
            return 0;
          }
        }
      }
    }
  }
  return 1;
}

// ==== CNpc::vfunc_16  @1402bc510  [high:rtti-vtable]  (orig: FUN_1402bc510)
undefined8 FUN_1402bc510(void)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001402bc52e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1,0x12);
    return uVar2;
  }
  return 0;
}

// ==== CNpc::helper_1402bc5d0  @1402bc5d0  [medium:callgraph-r0]  (orig: FUN_1402bc5d0)
bool FUN_1402bc5d0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  return iVar1 == 0x6e;
}

// ==== CNpc::helper_1402bc5f0  @1402bc5f0  [medium:callgraph-r0]  (orig: FUN_1402bc5f0)
bool FUN_1402bc5f0(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))(*(longlong **)(param_1 + 0x60),4);
  return iVar1 == 0x70;
}

// ==== CNpc::helper_1402bc610  @1402bc610  [medium:callgraph-r1]  (orig: FUN_1402bc610)
undefined8 FUN_1402bc610(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x50);
}

// ==== CNpc::vfunc_91  @1402bc620  [high:rtti-vtable]  (orig: FUN_1402bc620)
undefined1 FUN_1402bc620(longlong param_1,int param_2)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  if ((*(char *)(param_1 + 0x58) != '\0') && (-1 < param_2)) {
    plVar2 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x0001402bc661. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,*(undefined4 *)(param_1 + 0x48),param_2);
    return uVar1;
  }
  return 0;
}

// ==== CNpc::vfunc_0  @1402bc9f0  [high:rtti-vtable]  (orig: FUN_1402bc9f0)
void FUN_1402bc9f0(longlong param_1)

{
  FUN_1402bce40(param_1 + -0x18);
  return;
}

// ==== CNpc::vfunc_7  @1402bca00  [high:rtti-vtable]  (orig: FUN_1402bca00)
void FUN_1402bca00(longlong param_1)

{
  FUN_1402bb010(param_1 + -8);
  return;
}

// ==== CNpc::vfunc_4  @1402bca10  [high:rtti-vtable]  (orig: FUN_1402bca10)
void FUN_1402bca10(longlong param_1)

{
  FUN_1402ba9a0(param_1 + -8);
  return;
}

// ==== CNpc::vfunc_2  @1402bca20  [high:rtti-vtable]  (orig: FUN_1402bca20)
void FUN_1402bca20(longlong param_1)

{
  FUN_1402ba980(param_1 + -0x18);
  return;
}

// ==== CNpc::vfunc_3  @1402bca30  [high:rtti-vtable]  (orig: FUN_1402bca30)
void FUN_1402bca30(longlong param_1)

{
  FUN_1402ba990(param_1 + -0x18);
  return;
}

// ==== CNpc::vfunc_5  @1402bca40  [high:rtti-vtable]  (orig: FUN_1402bca40)
void FUN_1402bca40(longlong param_1)

{
  FUN_1402ba9b0(param_1 + -8);
  return;
}

// ==== CNpc::vfunc_0  @1402bca50  [high:rtti-vtable]  (orig: FUN_1402bca50)
void FUN_1402bca50(longlong param_1)

{
  FUN_1402bce40(param_1 + -0x10);
  return;
}

// ==== CNpc::vfunc_2  @1402bca60  [high:rtti-vtable]  (orig: FUN_1402bca60)
void FUN_1402bca60(longlong param_1)

{
  FUN_1402ba980(param_1 + -0x10);
  return;
}

// ==== CNpc::vfunc_14  @1402bca70  [high:rtti-vtable]  (orig: FUN_1402bca70)
undefined8 FUN_1402bca70(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (((iVar1 != 0x15) &&
      (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                         (*(longlong **)(param_1 + 0x50),4), iVar1 != 0x16)) &&
     (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                        (*(longlong **)(param_1 + 0x50),4), iVar1 != 0x17)) {
    return 0;
  }
  if (*(longlong *)(param_1 + 0x50) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402bcaff. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),0x15)
  ;
  return uVar2;
}

// ==== CNpc::vfunc_126  @1402bcb10  [high:rtti-vtable]  (orig: FUN_1402bcb10)
char FUN_1402bcb10(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  return (iVar1 == 10) + '\x04';
}

// ==== CNpc::helper_1402bcd80  @1402bcd80  [medium:callgraph-r0]  (orig: FUN_1402bcd80)
void FUN_1402bcd80(void *param_1)

{
  if ((DAT_140975f88 & 1) == 0) {
    DAT_140975f88 = DAT_140975f88 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f80,"CNpc");
    atexit((_func_5014 *)&LAB_1406d69e0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001402bcdd5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975f80,param_1);
  return;
}

// ==== CNpc::ctor_or_dtor  @1402bce40  [high:vtable-assign]  (orig: FUN_1402bce40)
undefined8 * FUN_1402bce40(undefined8 *param_1,uint param_2)

{
  *param_1 = CNpc::vftable;
  param_1[2] = CNpc::vftable;
  param_1[3] = CNpc::vftable;
  param_1[3] = IMapThing::vftable;
  param_1[2] = IRole::vftable;
  FUN_1402b55a0();
  if ((param_2 & 1) != 0) {
    FUN_1402bcd80(param_1);
  }
  return param_1;
}

// ==== CNpc::helper_1402bcec0  @1402bcec0  [medium:callgraph-r0]  (orig: FUN_1402bcec0)
void FUN_1402bcec0(longlong *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  
  uVar5 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
  plVar6 = (longlong *)FUN_1400875f0(uVar5);
  (**(code **)(*plVar6 + 0xe0))(plVar6,param_1);
  if (param_1[0xe] != 0) {
    uVar5 = (**(code **)(param_1[2] + 0x2a0))();
    FUN_1402c9300(param_1[0xe],uVar5,1);
  }
  if ((longlong *)param_1[0xf] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xf] + 8))();
    param_1[0xf] = 0;
  }
  if (param_1[0xc] != 0) {
    if ((char)param_1[0xd] != '\0') {
      cVar3 = (**(code **)(param_1[2] + 0x220))(param_1 + 2);
      if (cVar3 == '\0') {
        if ((char)param_1[0xd] == '\0') {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*(longlong *)param_1[0xc] + 0x48))((longlong *)param_1[0xc],0);
        }
      }
      else {
        (**(code **)(param_1[2] + 0x338))(param_1 + 2);
      }
    }
    (**(code **)(*(longlong *)param_1[0xc] + 0x58))();
    param_1[0xc] = 0;
  }
  puVar1 = (undefined8 *)param_1[5];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
    param_1[5] = 0;
  }
  puVar1 = (undefined8 *)param_1[6];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
    param_1[6] = 0;
  }
  puVar1 = (undefined8 *)param_1[8];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
    param_1[8] = 0;
  }
  puVar1 = (undefined8 *)param_1[7];
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
    param_1[7] = 0;
  }
  lVar2 = param_1[9];
  if (lVar2 != 0) {
    FUN_140467400(lVar2);
    FUN_1404647f0(lVar2);
    param_1[9] = 0;
  }
  if (param_1[10] != 0) {
    FUN_140410aa0();
    param_1[10] = 0;
  }
  if (*(char *)((longlong)param_1 + 0x69) != '\0') {
    uVar5 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
    plVar6 = (longlong *)FUN_1400876b0(uVar5);
    lVar2 = *plVar6;
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar2 + 0x138))(plVar6,uVar4);
  }
  return;
}

// ==== CNpc::helper_1402bd1e0  @1402bd1e0  [medium:callgraph-r0]  (orig: FUN_1402bd1e0)
undefined8 FUN_1402bd1e0(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  
  cVar1 = (**(code **)(*param_1 + 0x50))();
  lVar6 = 0;
  if ((cVar1 == '\0') &&
     (iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
     iVar2 != 0x20)) {
LAB_1402bd2d4:
    cVar1 = (**(code **)(*param_1 + 0x60))(param_1);
    if ((((((cVar1 != '\0') ||
           (iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
           iVar2 == 0x20)) ||
          (iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar2 == 0x21)) ||
         ((iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar2 == 0x22 ||
          (iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar2 == 0x23)))) ||
        ((iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
         iVar2 == 0x24 ||
         ((iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
          iVar2 == 0x25 || (cVar1 = FUN_1402ba6c0(param_1), cVar1 != '\0')))))) ||
       (iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4),
       iVar2 == 0x71)) {
      if (param_1[6] != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar5 = FUN_14046f080(0x28);
      if (lVar5 != 0) {
        lVar6 = FUN_14046ec20(lVar5);
      }
      param_1[6] = lVar6;
      if ((lVar6 == 0) || (cVar1 = FUN_140470a90(lVar6,param_2,param_1,param_1[0xc]), cVar1 == '\0')
         ) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
    }
    cVar1 = (**(code **)(*param_1 + 0x88))(param_1);
    if (cVar1 != '\0') {
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
      plVar8 = (longlong *)FUN_1400876b0(uVar7);
      lVar6 = *plVar8;
      uVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],7);
      lVar6 = (**(code **)(lVar6 + 0x10))(plVar8,uVar3,0);
      if (lVar6 == 0) {
        return 0;
      }
      if (param_1[7] != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar5 = FUN_1402ba780();
      param_1[7] = lVar5;
      if ((lVar5 == 0) || (cVar1 = FUN_14046a080(lVar5,param_1,lVar6), cVar1 == '\0')) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
    }
    cVar1 = (**(code **)(*param_1 + 0x98))(param_1);
    if (cVar1 != '\0') {
      if (param_1[8] != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar6 = FUN_14039e470(*(undefined4 *)((longlong)param_1 + 0xc4),param_1);
      param_1[8] = lVar6;
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
    }
    cVar1 = (**(code **)(*param_1 + 0xa8))(param_1);
    if (cVar1 != '\0') {
      if (param_1[9] != 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar6 = FUN_140467c90(*(undefined4 *)((longlong)param_1 + 0xc4),param_1);
      param_1[9] = lVar6;
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0;
      }
    }
    iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
    if (iVar2 == 0x6e) {
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
      uVar7 = FUN_140087830(uVar7);
      FUN_140214b70(uVar7,param_1);
    }
    iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
    if (iVar2 == 0x70) {
      lVar6 = FUN_1404109d0(*(undefined4 *)((longlong)param_1 + 0xc4),param_1);
      param_1[10] = lVar6;
      if (lVar6 == 0) {
        FUN_140087360(param_1);
        log_InlineLogERROR("CNpc::CreateFuncObj CRoulette CreateNew failed, npc id:%u, at %s, %d.");
        return 0;
      }
    }
    iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],4);
    if (iVar2 == 0x3c) {
      uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
      uVar7 = FUN_140087b50(uVar7);
      cVar1 = FUN_1402564c0(uVar7,param_1);
      if (cVar1 == '\0') {
        FUN_140087360(param_1);
        log_InlineLogERROR("CNpc::CreateFuncObj LoadSlotNpcInfo failed, npc id:%u, at %s, %d.");
        return 0;
      }
    }
    return 1;
  }
  if (param_1[5] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = FUN_14046acb0(0x120);
  lVar5 = lVar6;
  if (lVar4 != 0) {
    lVar5 = FUN_14046ea70(lVar4);
  }
  param_1[5] = lVar5;
  if (lVar5 != 0) {
    if ((longlong *)param_1[0xc] == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      uVar3 = (**(code **)(*(longlong *)param_1[0xc] + 8))();
    }
    cVar1 = FUN_14046e5f0(param_1[5],param_2,param_1,uVar3);
    if (cVar1 != '\0') goto LAB_1402bd2d4;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CNpc::vfunc_6  @1402bd740  [high:rtti-vtable]  (orig: FUN_1402bd740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402bd740(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  plVar1 = (longlong *)(param_1 + -0x18);
  iVar3 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x10))(*(longlong **)(param_1 + 0x48),4);
  if ((iVar3 == 9) ||
     (iVar3 = (**(code **)(**(longlong **)(param_1 + 0x48) + 0x10))
                        (*(longlong **)(param_1 + 0x48),4), iVar3 == 0x14)) {
    FUN_14039ed70(local_468);
    if (plVar1 == (longlong *)0x0) {
      param_1 = 0;
    }
    else {
      param_1 = param_1 + -8;
    }
    iVar3 = FUN_14039eef0(local_468,param_1,0,0);
    if (iVar3 == 0) {
      local_488 = 0x2c9;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_2 + 0x350))(param_2,local_468);
    }
    FUN_14039edf0(local_468);
    return;
  }
  cVar2 = FUN_1402bc5d0(plVar1);
  if (cVar2 != '\0') {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0xac));
    if (*(longlong *)(lVar5 + 0x108) == 0) {
      local_488 = 0x145;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = 0;
    }
    else {
      uVar6 = *(undefined8 *)(lVar5 + 0x108);
    }
    uVar4 = (**(code **)(*plVar1 + 8))(plVar1);
    uVar6 = FUN_140214ce0(uVar6,uVar4);
    FUN_140470f70(local_468);
    cVar2 = FUN_140471550(local_468,plVar1,uVar6);
    if (cVar2 != '\0') {
      (**(code **)(*param_2 + 0x350))(param_2,local_468);
    }
    FUN_140470fc0(local_468);
    return;
  }
  cVar2 = FUN_1402bc5f0(plVar1);
  if (cVar2 != '\0') {
    FUN_14040ac40(local_468);
    cVar2 = FUN_14040acf0(local_468,plVar1);
    if (cVar2 != '\0') {
      (**(code **)(*param_2 + 0x350))(param_2,local_468);
    }
    FUN_14040ac90(local_468);
    return;
  }
  if ((*(char *)(param_1 + 0x50) != '\0') &&
     (iVar3 = (**(code **)(*(longlong *)(param_1 + -8) + 0x80))(), iVar3 != 0)) {
    FUN_140456560(local_468);
    iVar3 = FUN_1404567b0(local_468,plVar1);
    if (iVar3 == 0) {
      local_488 = 0x2e0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_2 + 0x350))(param_2,local_468);
    }
    FUN_1404565e0(local_468);
    return;
  }
  FUN_140454910(local_468);
  iVar3 = FUN_1404549d0(local_468,plVar1);
  if (iVar3 == 0) {
    local_488 = 0x2e6;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    (**(code **)(*param_2 + 0x350))(param_2,local_468);
  }
  FUN_140454990(local_468);
  return;
}

// ==== CNpc::vfunc_92  @1402bddd0  [high:rtti-vtable]  (orig: FUN_1402bddd0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1402bddd0(longlong *param_1,int param_2,longlong param_3,int param_4,int *param_5)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  int iVar7;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if ((char)param_1[0xb] == '\0') {
    local_488 = 0x407;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else if (param_2 < 0x20) {
    iVar7 = param_2;
    if (param_5 != (int *)0x0) {
      iVar7 = *param_5;
    }
    if (param_3 != 0) {
      if (param_2 == 0) {
        cVar1 = FUN_1402ba560(param_1 + -2);
        iVar7 = (int)param_3;
        if (cVar1 != '\0') {
          iVar3 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
          if (((iVar3 == 10) &&
              (lVar4 = (**(code **)(*param_1 + 0x160))(param_1), (*(byte *)(lVar4 + 0x78) & 1) == 0)
              ) && (iVar7 < 0)) {
            log_InlineLogERROR(
                              "CNpc::AddAttrib. IsSynFlag() && !GetMap()->IsWarTime() && nDataTemp < 0"
                              );
            return 0;
          }
          iVar3 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
          if (((iVar3 == 0x2e) && (iVar7 < 0)) &&
             (plVar5 = (longlong *)CurrentInstanceGet(), plVar5 != (longlong *)0x0)) {
            uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xb4));
            cVar1 = FUN_14008b330(uVar6);
            if (cVar1 == '\0') {
              plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x1c);
              if ((plVar5 == (longlong *)0x0) ||
                 ((cVar1 = (**(code **)(*plVar5 + 0x10))(plVar5,0), cVar1 == '\0' &&
                  (cVar1 = (**(code **)(*plVar5 + 0x10))(plVar5,1), cVar1 == '\0')))) {
                return 0;
              }
            }
            else {
              plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x25);
              if ((plVar5 == (longlong *)0x0) ||
                 (cVar1 = (**(code **)(*plVar5 + 0x40))(plVar5), cVar1 == '\0')) {
                return 0;
              }
            }
          }
        }
        iVar3 = (**(code **)(*param_1 + 0x78))(param_1);
        if (iVar3 + iVar7 < 1) {
          (**(code **)(*(longlong *)param_1[10] + 0x60))((longlong *)param_1[10],0x18);
          iVar7 = param_2;
        }
        else {
          lVar4 = *(longlong *)param_1[10];
          iVar3 = (**(code **)(*param_1 + 0x78))(param_1);
          (**(code **)(lVar4 + 0x60))(param_1[10],0x18,iVar3 + iVar7);
          iVar7 = param_2;
        }
      }
      else {
        iVar7 = param_2;
        if (((param_2 != 2) && (param_2 != 4)) && (param_2 != 5)) {
          return 0;
        }
      }
    }
    if ((param_4 == 0) || (iVar7 == 0)) {
      if (param_5 != (int *)0x0) {
        *param_5 = iVar7;
      }
      uVar6 = 1;
    }
    else {
      FUN_14039e680(local_468);
      uVar2 = (**(code **)(param_1[-2] + 8))();
      iVar3 = FUN_14039e700(local_468,uVar2,0xffffffff);
      if (iVar3 == 0) {
        FUN_14039e6d0(local_468);
        uVar6 = 0;
      }
      else if (iVar7 == 2) {
        FUN_14039e6d0(local_468);
        uVar6 = 0;
      }
      else if (iVar7 == 5) {
        FUN_14039e6d0(local_468);
        uVar6 = 0;
      }
      else if (iVar7 == 4) {
        FUN_14039e6d0(local_468);
        uVar6 = 0;
      }
      else {
        FUN_14039e6d0(local_468);
        uVar6 = 0;
      }
    }
  }
  else {
    local_488 = 0x408;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  return uVar6;
}

// ==== CNpc::helper_1402be2f0  @1402be2f0  [medium:callgraph-r0]  (orig: FUN_1402be2f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402be2f0(longlong *param_1)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong lVar9;
  int iVar10;
  undefined1 auStack_498 [32];
  ulonglong local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  cVar1 = (**(code **)(param_1[2] + 0x220))(param_1 + 2);
  if (cVar1 != '\0') {
    uVar2 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
    uVar3 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
    if (uVar3 < uVar2) {
      if (param_1[0xc] == 0) {
        local_478 = CONCAT44(local_478._4_4_,0x144);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar4 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x12);
        if (0 < iVar4) {
          if (param_1[0xc] == 0) {
            local_478 = CONCAT44(local_478._4_4_,0x144);
            log_InlineLogERROR(&DAT_1406d9c10);
            iVar4 = 0;
          }
          else {
            iVar4 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x12);
          }
          iVar6 = 1000;
          if (iVar4 < 0x3e9) {
            iVar6 = iVar4;
          }
          iVar5 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
          iVar4 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
          iVar5 = iVar5 - iVar4;
          iVar4 = (iVar5 + -1) / 10 + 1;
          if (iVar6 <= iVar4) {
            iVar4 = iVar6;
          }
          if (param_1[0xc] == 0) {
            local_478 = CONCAT44(local_478._4_4_,0x144);
            log_InlineLogERROR(&DAT_1406d9c10);
            iVar6 = 0;
          }
          else {
            iVar6 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x12);
          }
          iVar10 = 0;
          if (-1 < iVar6 - iVar4) {
            iVar10 = iVar6 - iVar4;
          }
          if ((param_1[0xc] == 0) || ((char)param_1[0xd] == '\0')) {
            local_478 = CONCAT44(local_478._4_4_,0x14b);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            if ((int)param_1[0xb] == 0x334) {
              (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x12);
              local_478 = local_478 & 0xffffffff00000000;
              tq::MyLogSave("gmlog/npc_820",&DAT_1407026f0);
            }
            (**(code **)(*(longlong *)param_1[0xc] + 0x60))((longlong *)param_1[0xc],0x12,iVar10);
          }
          iVar6 = (**(code **)(param_1[2] + 0x170))(param_1 + 2);
          if (iVar6 != 0) {
            plVar8 = (longlong *)FUN_140087ed0();
            lVar9 = (**(code **)(*plVar8 + 0x268))(plVar8,iVar6);
            if (lVar9 < iVar4) {
              iVar4 = (int)lVar9;
            }
            if (iVar4 < 1) {
              if ((param_1[0xc] == 0) || ((char)param_1[0xd] == '\0')) {
                local_478 = CONCAT44(local_478._4_4_,0x14b);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                if ((int)param_1[0xb] == 0x334) {
                  (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x12);
                  local_478 = local_478 & 0xffffffff00000000;
                  tq::MyLogSave("gmlog/npc_820",&DAT_1407026f0);
                }
                (**(code **)(*(longlong *)param_1[0xc] + 0x60))((longlong *)param_1[0xc],0x12);
              }
            }
            else {
              iVar10 = iVar4 * 10;
              if (iVar5 <= iVar4 * 10) {
                iVar10 = iVar5;
              }
              plVar8 = (longlong *)FUN_140087ed0();
              (**(code **)(*plVar8 + 0x270))(plVar8,iVar6,-iVar4);
              local_478 = 0;
              (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0,(longlong)iVar10,2);
              iVar4 = (**(code **)(param_1[2] + 0x78))(param_1 + 2);
              uVar3 = iVar10 + iVar4;
              uVar2 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
              if (uVar2 < uVar3) {
                uVar3 = (**(code **)(param_1[2] + 0x80))(param_1 + 2);
              }
              FUN_14039e680(local_458);
              uVar7 = (**(code **)(*param_1 + 8))(param_1);
              iVar4 = FUN_14039e700(local_458,uVar7,0,uVar3);
              if (iVar4 == 0) {
                local_478 = CONCAT44(local_478._4_4_,0x708);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_458,0);
              }
              FUN_14039e6d0(local_458);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CNpc::vfunc_3  @1402be700  [high:rtti-vtable]  (orig: FUN_1402be700)
void FUN_1402be700(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong *plVar6;
  
  if (*(longlong *)(param_1 + 0x50) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    iVar2 = 0;
  }
  else {
    iVar2 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),1);
  }
  iVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))(*(longlong **)(param_1 + 0x50),4);
  if (((iVar3 == 10) ||
      (iVar3 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                         (*(longlong **)(param_1 + 0x50),4), iVar3 == 0x2e)) && (iVar2 != 0)) {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0xb4));
    cVar1 = FUN_14008b330(uVar4);
    if (cVar1 == '\0') {
      plVar6 = (longlong *)FUN_140087ed0();
      lVar5 = (**(code **)(*plVar6 + 0x290))(plVar6,iVar2);
    }
    else {
      lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0xb4));
      if (*(longlong *)(lVar5 + 0x208) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar5 = FUN_140263030(0,iVar2);
      }
      else {
        lVar5 = FUN_140263030(*(longlong *)(lVar5 + 0x208),iVar2);
      }
    }
    if (lVar5 != 0) {
      return;
    }
  }
  (**(code **)(**(longlong **)(param_1 + 0x50) + 0x18))(*(longlong **)(param_1 + 0x50),3);
  return;
}

// ==== CNpc::vfunc_124  @1402be840  [high:rtti-vtable]  (orig: FUN_1402be840)
undefined1 FUN_1402be840(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 uVar7;
  
  iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
  if ((iVar2 == 10) &&
     (lVar4 = (**(code **)(*param_1 + 0x160))(param_1), (*(byte *)(lVar4 + 0x78) & 1) == 0)) {
    return 0;
  }
  iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
  uVar7 = 1;
  if ((iVar2 == 0x2e) && (plVar5 = (longlong *)CurrentInstanceGet(), plVar5 != (longlong *)0x0)) {
    uVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xb4));
    cVar1 = FUN_14008b330(uVar6);
    if (cVar1 == '\0') {
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x1c);
      if (plVar5 != (longlong *)0x0) {
        cVar1 = (**(code **)(*plVar5 + 0x10))(plVar5,0);
        if (cVar1 != '\0') goto LAB_1402be94c;
        cVar1 = (**(code **)(*plVar5 + 0x10))(plVar5,1);
        if (cVar1 != '\0') {
          lVar4 = *plVar5;
          uVar3 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
          cVar1 = (**(code **)(lVar4 + 0x30))(plVar5,uVar3);
          if (cVar1 != '\0') goto LAB_1402be94c;
        }
      }
    }
    else {
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,0x25);
      if (plVar5 != (longlong *)0x0) {
        cVar1 = (**(code **)(*plVar5 + 0x40))(plVar5);
        if (cVar1 == '\0') {
          return 0;
        }
        goto LAB_1402be94c;
      }
    }
    uVar7 = 0;
  }
  else {
LAB_1402be94c:
    if (((char)param_1[0xb] == '\0') ||
       (iVar2 = (**(code **)(*param_1 + 0x80))(param_1), iVar2 == 0)) {
      uVar7 = 0;
    }
  }
  return uVar7;
}

// ==== CNpc::vfunc_68  @1402bf6d0  [high:rtti-vtable]  (orig: FUN_1402bf6d0)
undefined8 FUN_1402bf6d0(longlong param_1)

{
  int iVar1;
  
  if (((*(char *)(param_1 + 0x58) != '\0') &&
      (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                         (*(longlong **)(param_1 + 0x50),0x19), 0 < iVar1)) &&
     (iVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x10))
                        (*(longlong **)(param_1 + 0x50),0x18), iVar1 < 1)) {
    return 0;
  }
  if (*(int *)(param_1 + 0xa4) != 0) {
    return 0;
  }
  return 1;
}

// ==== CNpc::vfunc_73  @1402bf720  [high:rtti-vtable]  (orig: FUN_1402bf720)
ulonglong FUN_1402bf720(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0xa4) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0xa4) + *(int *)(param_1 + 0xa0);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      return CONCAT71((uint7)(uint3)(uVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CNpc::vfunc_1  @1402bf770  [high:rtti-vtable]  (orig: FUN_1402bf770)
void FUN_1402bf770(longlong param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(param_1 + -0x10);
  FUN_1402bcec0(puVar1);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CNpc::helper_1402bfbe0  @1402bfbe0  [medium:callgraph-r0]  (orig: FUN_1402bfbe0)
void FUN_1402bfbe0(longlong *param_1)

{
  uint *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  
  plVar5 = (longlong *)FUN_1401181a0();
  lVar2 = *plVar5;
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  iVar4 = (**(code **)(lVar2 + 0xf8))(plVar5,uVar3);
  if (iVar4 != 0) {
    if (0xbf < (ulonglong)(longlong)iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_140118b50(param_1 + 0x10);
    }
    puVar1 = (uint *)((longlong)param_1 + ((ulonglong)(longlong)iVar4 >> 5) * 4 + 0x80);
    *puVar1 = *puVar1 | 1 << ((byte)iVar4 & 0x1f);
    if (iVar4 != 0xa8) {
      iVar4 = iVar4 + -1;
      if (0xbf < (ulonglong)(longlong)iVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_140118b50(param_1 + 0x10);
      }
      puVar1 = (uint *)((longlong)param_1 + ((ulonglong)(longlong)iVar4 >> 5) * 4 + 0x80);
      *puVar1 = *puVar1 & ~(1 << ((byte)iVar4 & 0x1f));
    }
  }
  return;
}

// ==== CNpc::helper_1402c0190  @1402c0190  [medium:callgraph-r0]  (orig: FUN_1402c0190)
undefined8 * FUN_1402c0190(undefined1 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = IGameData::vftable;
    *puVar1 = CGameData<&char*_szNpcTable,&char*_szID>::vftable;
    *(undefined1 *)(puVar1 + 2) = param_1;
    puVar1[1] = 0;
  }
  return puVar1;
}

// ==== CNpc::vfunc_1  @1402c0230  [high:rtti-vtable]  (orig: FUN_1402c0230)
void FUN_1402c0230(longlong param_1)

{
  FUN_1402bf770(param_1 + -8);
  return;
}

// ==== CNpc::ctor_or_dtor  @1402c0240  [high:vtable-assign]  (orig: FUN_1402c0240)
undefined8 * FUN_1402c0240(undefined8 *param_1)

{
  longlong lVar1;
  longlong lVar2;
  
  FUN_1402b5540();
  param_1[2] = IRole::vftable;
  param_1[3] = IMapThing::vftable;
  *param_1 = CNpc::vftable;
  param_1[2] = CNpc::vftable;
  param_1[3] = CNpc::vftable;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  param_1[10] = 0;
  lVar1 = 5;
  lVar2 = 5;
  do {
    *(undefined4 *)((longlong)param_1 + lVar2 * 4 + 0x80) = 0;
    lVar2 = lVar2 + -1;
  } while (-1 < lVar2);
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)((longlong)param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0x15) = 0;
  *(undefined4 *)((longlong)param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0x16) = 0;
  *(undefined4 *)((longlong)param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0x17) = 0;
  *(undefined4 *)((longlong)param_1 + 0xbc) = 0;
  *(undefined1 *)(param_1 + 0x18) = 0;
  *(undefined4 *)(param_1 + 1) = 0x1040;
  *(undefined4 *)(param_1 + 0xb) = 0;
  param_1[0xc] = 0;
  *(undefined1 *)(param_1 + 0xd) = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[0xe] = 0;
  param_1[0xf] = 0;
  do {
    *(undefined4 *)((longlong)param_1 + lVar1 * 4 + 0x80) = 0;
    lVar1 = lVar1 + -1;
  } while (-1 < lVar1);
  *(undefined4 *)((longlong)param_1 + 0x9c) = 0;
  *(undefined1 *)((longlong)param_1 + 0x69) = 0;
  *(undefined1 *)(param_1 + 0x13) = 0;
  *(undefined4 *)(param_1 + 0x19) = 0;
  return param_1;
}

// ==== CNpc::vfunc_122  @1402c0350  [high:rtti-vtable]  (orig: FUN_1402c0350)
void FUN_1402c0350(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  longlong lVar2;
  char cVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  if ((char)param_1[0xb] == '\0') {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(int *)((longlong)param_1 + 0xa4) == 0) {
    plVar1 = param_1 + -2;
    uVar4 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],0x1b);
    if ((uVar4 >> 4 & 1) == 0) {
      (**(code **)(*param_1 + 0x2c8))(param_1,0,1);
      cVar3 = FUN_1402bf900(plVar1);
      if (cVar3 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
    }
    else {
      iVar5 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],0x17);
      if (iVar5 == 0) {
        (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
        (**(code **)(*plVar1 + 8))(plVar1);
        log_InlineLogDBERROR("CNpc::BeKill, table:cq_dynanpc, linkid is 0, npcid[%lu] type[%d].");
      }
      else {
        uVar7 = (**(code **)(*param_2 + 0x2b0))(param_2);
        plVar9 = param_1;
        if (plVar1 == (longlong *)0x0) {
          plVar9 = (longlong *)0x0;
        }
        uVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xb4));
        uVar8 = FUN_140087730(uVar8);
        FUN_140145f60(uVar8,iVar5,uVar7,plVar9,0,0);
        iVar5 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
        if ((iVar5 == 10) ||
           (iVar5 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
           iVar5 == 0x2e)) {
          plVar9 = (longlong *)FUN_1401181a0();
          lVar2 = *plVar9;
          uVar6 = (**(code **)(*plVar1 + 8))(plVar1);
          (**(code **)(lVar2 + 0x18))(plVar9,uVar6);
        }
      }
    }
  }
  return;
}

// ==== CNpc::vfunc_89  @1402c0530  [high:rtti-vtable]  (orig: FUN_1402c0530)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402c0530(longlong *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  uint local_480;
  undefined4 local_47c;
  undefined4 local_478;
  undefined4 local_474;
  undefined4 local_470;
  undefined4 local_46c;
  undefined8 local_468;
  int local_460 [6];
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_468 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  (**(code **)(*param_1 + 0x58))(param_1,local_460);
  lVar5 = 5;
  switch(param_2) {
  case 0:
    local_480 = *(uint *)(param_1 + 0xe);
    local_47c = *(undefined4 *)((longlong)param_1 + 0x74);
    local_478 = (undefined4)param_1[0xf];
    local_474 = *(undefined4 *)((longlong)param_1 + 0x7c);
    local_470 = (undefined4)param_1[0x10];
    local_46c = *(undefined4 *)((longlong)param_1 + 0x84);
    lVar3 = 5;
    do {
      *(undefined4 *)((longlong)param_1 + lVar3 * 4 + 0x70) = 0;
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
    if ((local_480 >> 6 & 1) != 0) {
      *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x40;
    }
    if ((local_480 >> 0xe & 1) != 0) {
      *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x4000;
    }
    if ((local_480 >> 0xf & 1) != 0) {
      *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x8000;
    }
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x20;
    break;
  case 1:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 1;
    break;
  case 2:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 2;
    break;
  case 3:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x40;
    break;
  case 4:
    break;
  case 5:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x80;
    break;
  case 6:
  case 0x2c:
  case 0x74:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x100;
    break;
  case 7:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x200;
    break;
  default:
    local_498 = 0x558;
    log_InlineLogERROR(&DAT_1406d9c10);
    break;
  case 9:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x1000;
    break;
  case 10:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x2000;
    break;
  case 0xb:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x10000;
    break;
  case 0xc:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x20000;
    break;
  case 0xd:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x40000;
    break;
  case 0xe:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x80000;
    break;
  case 0xf:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x100000;
    break;
  case 0x10:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x200000;
    break;
  case 0x11:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x400000;
    break;
  case 0x12:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x800000;
    break;
  case 0x13:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x1000000;
    break;
  case 0x14:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x2000000;
    break;
  case 0x15:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x4000000;
    break;
  case 0x16:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x8000000;
    break;
  case 0x17:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 0x10000000;
    break;
  case 0x27:
    *(uint *)((longlong)param_1 + 0x74) = *(uint *)((longlong)param_1 + 0x74) | 0x4000;
    break;
  case 0x2a:
    *(uint *)((longlong)param_1 + 0x74) = *(uint *)((longlong)param_1 + 0x74) | 0x1000;
    break;
  case 0x2b:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) | 2;
    break;
  case 0x59:
    *(uint *)(param_1 + 0xf) = *(uint *)(param_1 + 0xf) | 0x20000000;
    break;
  case 0x7d:
    *(uint *)((longlong)param_1 + 0x7c) = *(uint *)((longlong)param_1 + 0x7c) | 0x40000000;
    break;
  case 0xa8:
    FUN_1402bfbe0(param_1 + -2);
    break;
  case 0xffffffff:
    lVar3 = 5;
    do {
      *(undefined4 *)((longlong)param_1 + lVar3 * 4 + 0x70) = 0;
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
  }
  if (param_3 != '\0') {
    lVar3 = (**(code **)(*param_1 + 0x58))(param_1,&local_480);
    do {
      if (local_460[lVar5] != *(int *)(lVar3 + lVar5 * 4)) {
        FUN_14039e680(local_448);
        uVar4 = (**(code **)(*param_1 + 0x58))(param_1,&local_480);
        uVar1 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
        iVar2 = FUN_14039ec00(local_448,uVar1,0x19,uVar4);
        if (iVar2 == 0) {
          local_498 = 0x55f;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*param_1 + 0x348))(param_1,local_448,1);
        }
        FUN_14039e6d0(local_448);
        return;
      }
      lVar5 = lVar5 + -1;
    } while (-1 < lVar5);
  }
  return;
}

// ==== CNpc::vfunc_90  @1402c0980  [high:rtti-vtable]  (orig: FUN_1402c0980)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402c0980(longlong *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  int local_480 [6];
  undefined1 local_468 [32];
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_488 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  (**(code **)(*param_1 + 0x58))(param_1,local_480);
  switch(param_2) {
  case 0:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffffffdf;
    break;
  case 1:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffffffe;
    break;
  case 2:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffffffd;
    break;
  case 3:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffffffbf;
    break;
  case 4:
    break;
  case 5:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffffff7f;
    break;
  case 6:
  case 0x2c:
  case 0x74:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffffeff;
    break;
  case 7:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffffdff;
    break;
  default:
    local_498 = 0x605;
    log_InlineLogERROR(&DAT_1406d9c10);
    break;
  case 9:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffffefff;
    break;
  case 10:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffffdfff;
    break;
  case 0xb:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffeffff;
    break;
  case 0xc:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffdffff;
    break;
  case 0xd:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffbffff;
    break;
  case 0xe:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfff7ffff;
    break;
  case 0xf:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffefffff;
    break;
  case 0x10:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffdfffff;
    break;
  case 0x11:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xffbfffff;
    break;
  case 0x12:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xff7fffff;
    break;
  case 0x13:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfeffffff;
    break;
  case 0x14:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfdffffff;
    break;
  case 0x15:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfbffffff;
    break;
  case 0x16:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xf7ffffff;
    break;
  case 0x17:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xefffffff;
    break;
  case 0x27:
    *(uint *)((longlong)param_1 + 0x74) = *(uint *)((longlong)param_1 + 0x74) & 0xffffbfff;
    break;
  case 0x2a:
    *(uint *)((longlong)param_1 + 0x74) = *(uint *)((longlong)param_1 + 0x74) & 0xffffefff;
    break;
  case 0x2b:
    *(uint *)(param_1 + 0xe) = *(uint *)(param_1 + 0xe) & 0xfffffffd;
    break;
  case 0x59:
    *(uint *)(param_1 + 0xf) = *(uint *)(param_1 + 0xf) & 0xdfffffff;
    break;
  case 0x7d:
    *(uint *)((longlong)param_1 + 0x7c) = *(uint *)((longlong)param_1 + 0x7c) & 0xbfffffff;
    break;
  case 0xa8:
    *(uint *)((longlong)param_1 + 0x84) = *(uint *)((longlong)param_1 + 0x84) & 0xfffff0ff;
    break;
  case 0xffffffff:
    local_498 = 0x56c;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_3 != '\0') {
    lVar3 = (**(code **)(*param_1 + 0x58))(param_1,local_468);
    lVar5 = 5;
    do {
      if (local_480[lVar5] != *(int *)(lVar3 + lVar5 * 4)) {
        FUN_14039e680(local_448);
        uVar4 = (**(code **)(*param_1 + 0x58))(param_1,local_468);
        uVar1 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
        iVar2 = FUN_14039ec00(local_448,uVar1,0x19,uVar4);
        if (iVar2 == 0) {
          local_498 = 0x60c;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*param_1 + 0x348))(param_1,local_448,1);
        }
        FUN_14039e6d0(local_448);
        return;
      }
      lVar5 = lVar5 + -1;
    } while (-1 < lVar5);
  }
  return;
}

// ==== CNpc::helper_1402c0df0  @1402c0df0  [medium:callgraph-r0]  (orig: FUN_1402c0df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402c0df0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  tm *ptVar5;
  longlong lVar6;
  undefined8 uVar7;
  IStringManager *pIVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  int iVar12;
  uint uVar13;
  undefined1 auStack_518 [32];
  undefined8 local_4f8;
  undefined4 local_4f0;
  undefined2 local_4e8;
  undefined2 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined1 local_4c8;
  __time32_t local_4b8 [2];
  undefined8 local_4b0;
  undefined8 *local_4a8;
  undefined8 local_4a0;
  undefined8 local_498;
  longlong *local_490;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  local_4b8[0] = _time32((__time32_t *)0x0);
  ptVar5 = _localtime32(local_4b8);
  if (ptVar5 == (tm *)0x0) {
    local_4f8 = CONCAT44(local_4f8._4_4_,0x69d);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = ptVar5->tm_wday;
    if (iVar3 == 0) {
      iVar3 = 7;
    }
    iVar12 = ((iVar3 * 100 + ptVar5->tm_hour) * 100 + ptVar5->tm_min) * 100;
    uVar13 = 0;
    iVar3 = 0;
    if (param_1[0xc] == 0) {
      local_4f8 = CONCAT44(local_4f8._4_4_,0x144);
      log_InlineLogERROR(&DAT_1406d9c10);
      iVar2 = iVar3;
    }
    else {
      iVar2 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x13);
    }
    if (param_1[0xc] == 0) {
      local_4f8 = CONCAT44(local_4f8._4_4_,0x144);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar3 = (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0x14);
    }
    if ((iVar12 < (iVar2 / 100) * 100) || ((iVar3 / 100) * 100 <= iVar12)) {
      plVar9 = param_1 + 2;
      lVar6 = (**(code **)(*plVar9 + 0x160))(plVar9);
      if ((*(byte *)(lVar6 + 0x78) & 1) != 0) {
        uVar7 = (**(code **)(*plVar9 + 0x160))(plVar9);
        FUN_1402c6e30(uVar7,1);
        FUN_14015b240(local_478);
        pIVar8 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_SYN_WAR_END");
        local_4c8 = 1;
        local_4d0 = 0;
        local_4d8 = 0;
        local_4e0 = 0;
        local_4e8 = 2000;
        local_4f0 = 0xffffff;
        local_4f8 = 0;
        iVar3 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar3 != 0) {
          plVar10 = (longlong *)(**(code **)(*plVar9 + 0x160))(plVar9);
          (**(code **)(*plVar10 + 0x38))(plVar10,local_478,0);
        }
        plVar10 = (longlong *)FUN_140087ed0();
        lVar6 = *plVar10;
        uVar4 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar6 + 0x310))(plVar10,uVar4);
        plVar10 = (longlong *)FUN_1401181a0();
        lVar6 = *plVar10;
        uVar4 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar6 + 0x20))(plVar10,uVar4);
        uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0xc4));
        plVar10 = (longlong *)FUN_1400875f0(uVar7);
        lVar6 = (**(code **)(*plVar10 + 0x30))(plVar10);
        local_4a8 = (undefined8 *)(lVar6 + 0x10);
        local_498 = **(undefined8 **)(lVar6 + 0x40);
        local_4a0 = *local_4a8;
        local_490 = (longlong *)0x0;
        cVar1 = FUN_1400ce310(&local_4a8);
        plVar10 = local_490;
        while (local_490 = plVar10, cVar1 != '\0') {
          uVar13 = uVar13 + 1;
          if (1000000 < uVar13) {
            local_4f8._4_4_ = (undefined4)((ulonglong)local_4f8 >> 0x20);
            local_4f8 = CONCAT44(local_4f8._4_4_,0x6cb);
            log_InlineLogERROR(&DAT_1406d9c10);
            break;
          }
          if (plVar10 != (longlong *)0x0) {
            plVar11 = (longlong *)(**(code **)(*plVar10 + 0x160))(plVar10);
            iVar3 = (**(code **)(*plVar11 + 8))(plVar11);
            iVar12 = (**(code **)(*plVar9 + 0x168))(plVar9);
            if (iVar3 == iVar12) {
              (**(code **)(*plVar10 + 0x380))(plVar10);
              local_4b0 = 0;
              (**(code **)(*plVar10 + 0x298))(plVar10,0x1001,&local_4b0);
            }
          }
          cVar1 = FUN_1400ce310(&local_4a8);
          plVar10 = local_490;
        }
        tq::MyLogSave("gmlog/emoney_buy","0\t0\t0\t5000\t5008\t0\t0\t%d\t");
        FUN_14015b2c0(local_478);
      }
    }
    else {
      param_1 = param_1 + 2;
      lVar6 = (**(code **)(*param_1 + 0x160))(param_1);
      if ((*(byte *)(lVar6 + 0x78) & 1) == 0) {
        uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
        FUN_1402c6e30(uVar7,1,1);
        FUN_14015b240(local_478);
        pIVar8 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_SYN_WAR_START");
        local_4c8 = 1;
        local_4d0 = 0;
        local_4d8 = 0;
        local_4e0 = 0;
        local_4e8 = 2000;
        local_4f0 = 0xffffff;
        local_4f8 = 0;
        iVar3 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar3 != 0) {
          plVar9 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
          (**(code **)(*plVar9 + 0x38))(plVar9,local_478,0);
        }
        FUN_14015b2c0(local_478);
      }
    }
  }
  return;
}

// ==== CNpc::helper_1402c12a0  @1402c12a0  [medium:callgraph-r1]  (orig: FUN_1402c12a0)
undefined8 * FUN_1402c12a0(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IGameObjSet<IStatus>::vftable;
  *param_1 = CGameObjSet<IStatus>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CNpc::vfunc_108  @1402c1560  [high:rtti-vtable]  (orig: FUN_1402c1560)
void FUN_1402c1560(longlong *param_1,undefined8 param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  ulong uVar4;
  longlong lVar5;
  longlong *plVar6;
  tm *ptVar7;
  undefined8 uVar8;
  __time32_t local_res18 [2];
  uint local_res20;
  
  iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
  if (iVar2 == 10) {
    cVar1 = FUN_1400222e0(param_1 + 0x12,10);
    if (cVar1 != '\0') {
      FUN_1402be2f0(param_1 + -2);
    }
    cVar1 = FUN_1400222e0(param_1 + 0x13,0x1e);
    if (cVar1 != '\0') {
      lVar5 = (**(code **)(*param_1 + 0x160))(param_1);
      local_res20 = *(uint *)(lVar5 + 0x78);
      if ((local_res20 & 1) != 0) {
        plVar6 = (longlong *)FUN_140087ed0();
        lVar5 = *plVar6;
        uVar3 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
        (**(code **)(lVar5 + 0x330))(plVar6,uVar3);
      }
    }
    FUN_1402c0df0(param_1 + -2);
  }
  iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4);
  if ((iVar2 == 0x28) && (cVar1 = FUN_1400222e0(param_1 + 0x15,5), cVar1 != '\0')) {
    plVar6 = (longlong *)CurrentInstanceGet();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,0x18);
    if (plVar6 != (longlong *)0x0) {
      if (param_1[10] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],1);
        if ((iVar2 != 0) && (*(int *)((longlong)param_1 + 0x8c) != 0)) {
          uVar4 = tq::TimeGet(1);
          iVar2 = uVar4 - *(int *)((longlong)param_1 + 0x8c);
          if (iVar2 != 0) {
            *(ulong *)((longlong)param_1 + 0x8c) = uVar4;
            if (param_1[10] == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar3 = 0;
            }
            else {
              uVar3 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],1);
            }
            (**(code **)(*plVar6 + 0x10))(plVar6,uVar3,iVar2);
          }
        }
      }
      (**(code **)(*plVar6 + 0x60))(plVar6,0);
    }
  }
  if (((char)param_1[0xb] != '\0') &&
     (iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
     iVar2 == 0xf)) {
    local_res18[0] = _time32((__time32_t *)0x0);
    ptVar7 = _localtime32(local_res18);
    if (ptVar7 == (tm *)0x0) {
      return;
    }
    if ((char)param_1[0x16] == '\0') {
      if (ptVar7->tm_hour == 0) {
        *(undefined1 *)(param_1 + 0x16) = 1;
        uVar3 = (**(code **)(*param_1 + 0x170))(param_1);
        plVar6 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar6 + 0x270))(plVar6,uVar3,0xffffd8f0);
      }
    }
    else if (ptVar7->tm_hour != 0) {
      *(undefined1 *)(param_1 + 0x16) = 0;
    }
  }
  cVar1 = (**(code **)(param_1[-2] + 0x60))(param_1 + -2);
  if ((((cVar1 != '\0') ||
       (iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
       iVar2 == 0x20)) ||
      (iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
      iVar2 == 0x21)) ||
     (((iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
       iVar2 == 0x22 ||
       (iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
       iVar2 == 0x23)) ||
      ((iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
       iVar2 == 0x24 ||
       (iVar2 = (**(code **)(*(longlong *)param_1[10] + 0x10))((longlong *)param_1[10],4),
       iVar2 == 0x25)))))) {
    uVar8 = (**(code **)(param_1[-2] + 0x68))(param_1 + -2);
    FUN_14046f1f0(uVar8,param_2);
    return;
  }
  cVar1 = (**(code **)(param_1[-2] + 0xa8))(param_1 + -2);
  if (cVar1 != '\0') {
    uVar8 = (**(code **)(param_1[-2] + 0xb0))(param_1 + -2);
    FUN_140469790(uVar8);
    return;
  }
  cVar1 = FUN_1402bc5f0(param_1 + -2);
  if (cVar1 == '\0') {
    return;
  }
  if (param_1[8] == 0) {
    return;
  }
  FUN_140412f60();
  return;
}

// ==== CNpc::helper_1402c18f0  @1402c18f0  [medium:callgraph-r0]  (orig: FUN_1402c18f0)
undefined8
FUN_1402c18f0(undefined1 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  pvVar1 = operator_new(0x40);
  if (pvVar1 == (void *)0x0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_1402c12a0(pvVar1,param_1,param_3,param_4,uVar2);
  }
  return uVar2;
}

// ==== CNpc::CreateInstanceNpc  @1402c1c90  [high:log-string]  (orig: FUN_1402c1c90)
undefined8 FUN_1402c1c90(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong local_res8;
  
  *(undefined4 *)(param_1 + 0xc4) = 0xe;
  lVar3 = FUN_140008520(0xe);
  if (*(longlong *)(lVar3 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                    (*(longlong **)(lVar3 + 0x98),param_3,1);
  *(longlong *)(param_1 + 0x70) = lVar3;
  if (lVar3 == 0) {
    log_InlineLogDBERROR
              (
              "table:cq_map/cq_dynamap, CNpc::CreateInstanceNpc(), Create Instance Npc(%u) Can\'t Find Map(%u) at %s, %d"
              );
  }
  else {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
    if (*(longlong *)(lVar3 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))
                       (*(longlong **)(lVar3 + 0x88),param_2);
    local_res8 = 0;
    if (((plVar4 != (longlong *)0x0) &&
        (cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8), cVar1 != '\0')) &&
       (local_res8 != 0)) {
      plVar4 = (longlong *)FUN_1402c0190(0);
      if (plVar4 != (longlong *)0x0) {
        *(longlong **)(param_1 + 0x60) = plVar4;
        cVar1 = (**(code **)(*plVar4 + 0x38))(plVar4,"cq_dynanpc");
        if (cVar1 == '\0') {
          (**(code **)(**(longlong **)(param_1 + 0x60) + 0x58))();
          *(undefined8 *)(param_1 + 0x60) = 0;
          return 0;
        }
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_140087360(local_res8);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,1);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),1,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,2);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),2,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,4);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),4,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar5 = FUN_140117cc0(local_res8,3);
        (**(code **)(lVar3 + 0x68))(*(undefined8 *)(param_1 + 0x60),3,uVar5);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,5);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),5,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,6);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),6,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,7);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),7,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,8);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),8,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,9);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),9,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,10);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),10,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0xb);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0xb,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0xc);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0xc,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0xd);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0xd,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0xe);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0xe,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0xf);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0xf,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x10);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x10,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x11);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x11,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x12);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x12,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x13);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x13,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x14);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x14,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x15);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x15,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar5 = FUN_140117cc0(local_res8,0x16);
        (**(code **)(lVar3 + 0x68))(*(undefined8 *)(param_1 + 0x60),0x16,uVar5);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x17);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x17,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x18);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x18,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x19);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x19,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x1a);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x1a,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x1b);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x1b,uVar2);
        lVar3 = **(longlong **)(param_1 + 0x60);
        uVar2 = FUN_1400872b0(local_res8,0x1c);
        (**(code **)(lVar3 + 0x60))(*(undefined8 *)(param_1 + 0x60),0x1c,uVar2);
        uVar2 = FUN_1400872b0(local_res8,8);
        *(undefined4 *)(param_1 + 0x20) = uVar2;
        uVar2 = FUN_1400872b0(local_res8,9);
        *(undefined4 *)(param_1 + 0x24) = uVar2;
        cVar1 = FUN_1402bc390(param_1);
        if (cVar1 != '\0') {
          lVar3 = FUN_1402c18f0(1);
          *(longlong *)(param_1 + 0x78) = lVar3;
          if (lVar3 != 0) {
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
            plVar4 = (longlong *)FUN_1400876b0(uVar5);
            uVar2 = (**(code **)(*plVar4 + 0x130))(plVar4);
            *(undefined4 *)(param_1 + 0x58) = uVar2;
            cVar1 = FUN_1402bd1e0(param_1,*(undefined4 *)(param_1 + 0xc4));
            if (cVar1 == '\0') {
              log_InlineLogERROR("CNpc::CreateInstanceNpc() idNpcRecord:%u, at %s, %d");
              return 0;
            }
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
            plVar4 = (longlong *)FUN_1400875f0(uVar5);
            (**(code **)(*plVar4 + 0xd8))(plVar4,param_1,0);
            *(undefined1 *)(param_1 + 0x69) = 1;
            *(undefined1 *)(param_1 + 0x68) = 1;
            uVar5 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x2a0))(param_1 + 0x10);
            FUN_1402c90f0(*(undefined8 *)(param_1 + 0x70),uVar5,1);
            FUN_1402bda30(param_1);
            return 1;
          }
        }
      }
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return 0;
}

// ==== CNpc::Create  @1402c2390  [high:log-string]  (orig: FUN_1402c2390)
undefined8
FUN_1402c2390(longlong param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4,
             undefined8 param_5)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  
  *(undefined4 *)(param_1 + 0xc4) = param_2;
  if (*(longlong *)(param_1 + 0x60) != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = operator_new(0x18);
  if (plVar4 == (longlong *)0x0) {
    plVar4 = (longlong *)0x0;
  }
  else {
    *plVar4 = (longlong)IGameData::vftable;
    *plVar4 = (longlong)CGameData<&char*_szDynTable,&char*_szID>::vftable;
    *(undefined1 *)(plVar4 + 2) = 0;
    plVar4[1] = 0;
  }
  if (plVar4 == (longlong *)0x0) {
    uVar6 = 0;
  }
  else {
    *(longlong **)(param_1 + 0x60) = plVar4;
    cVar1 = (**(code **)(*plVar4 + 0x40))();
    if (cVar1 == '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x58))();
      *(undefined8 *)(param_1 + 0x60) = 0;
      uVar6 = 0;
    }
    else {
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),1,*param_3);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),2,param_3[1]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),4,param_3[5]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x68))
                (*(longlong **)(param_1 + 0x60),3,param_5);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),5,param_3[6]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))(*(longlong **)(param_1 + 0x60),6);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),7,param_3[2]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),8,param_3[3]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),9,param_3[4]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),10,param_3[7]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0xb,param_3[8]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0xc,param_3[9]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0xd,param_3[10]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0xe,param_3[0xb]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0xf,param_3[0xc]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x10,param_3[0xd]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x11,param_3[0xe]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x12,param_3[0xf]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x13,param_3[0x10]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x14,param_3[0x11]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x15,param_3[0x12]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x68))
                (*(longlong **)(param_1 + 0x60),0x16,param_3 + 0x13);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x17,param_3[0x17]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x18,param_3[0x18]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x19,param_3[0x18]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x1a,param_3[0x19]);
      (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                (*(longlong **)(param_1 + 0x60),0x1b,param_3[0x1a]);
      if ((*(byte *)(param_3 + 0x1a) & 2) != 0) {
        (**(code **)(**(longlong **)(param_1 + 0x60) + 0x60))
                  (*(longlong **)(param_1 + 0x60),0x1c,param_4);
      }
      *(undefined4 *)(param_1 + 0x20) = param_3[3];
      *(undefined4 *)(param_1 + 0x24) = param_3[4];
      cVar1 = FUN_1402bc390(param_1);
      if (cVar1 == '\0') {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar6 = 0;
      }
      else {
        lVar5 = FUN_1402c18f0(1);
        *(longlong *)(param_1 + 0x78) = lVar5;
        if (lVar5 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar6 = 0;
        }
        else {
          uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
          plVar4 = (longlong *)FUN_1400876b0(uVar6);
          lVar5 = (**(code **)(*plVar4 + 0x10))(plVar4,param_3[2],1);
          *(longlong *)(param_1 + 0x70) = lVar5;
          if (lVar5 == 0) {
            log_InlineLogERROR(
                              "CNpc::Create(), Create Npc(Type:%u, Name:%s) can\'t find map(%u) at %s, %d"
                              );
            uVar6 = 0;
          }
          else {
            cVar1 = FUN_14016ce10(lVar5);
            if (cVar1 == '\0') {
              *(undefined1 *)(param_1 + 0x68) = 1;
            }
            else {
              *(undefined1 *)(param_1 + 0x69) = 1;
            }
            if (*(char *)(param_1 + 0x68) == '\0') {
              if (*(char *)(param_1 + 0x69) != '\0') {
                uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
                plVar4 = (longlong *)FUN_1400876b0(uVar6);
                uVar3 = (**(code **)(*plVar4 + 0x130))(plVar4);
                *(undefined4 *)(param_1 + 0x58) = uVar3;
              }
            }
            else {
              iVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x50))();
              if (iVar2 == 0) {
                log_InlineLogERROR(
                                  "CNpc::Create() idProcess=%u, itemType=%u, name=%s, map%u(%d, %d), idOwner=%u, nType=%u, at %s, %d"
                                  );
                return 0;
              }
              uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
              plVar4 = (longlong *)FUN_1400876b0(uVar6);
              uVar3 = (**(code **)(*plVar4 + 200))(plVar4);
              *(undefined4 *)(param_1 + 0x58) = uVar3;
            }
            cVar1 = FUN_1402bd1e0(param_1,param_2);
            if (cVar1 == '\0') {
              (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
              log_InlineLogERROR(
                                "CNpc::Create() idProcess=%u, itemType=%u, name=%s, map%u(%d, %d), idOwner=%u, NPCID=%u, nType=%u, at %s, %d"
                                );
              uVar6 = 0;
            }
            else {
              uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
              plVar4 = (longlong *)FUN_1400875f0(uVar6);
              (**(code **)(*plVar4 + 0xd8))(plVar4,param_1,*(undefined1 *)(param_1 + 0x68));
              uVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x2a0))(param_1 + 0x10);
              FUN_1402c90f0(*(undefined8 *)(param_1 + 0x70),uVar6,1);
              FUN_1402bda30(param_1);
              iVar2 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                                (*(longlong **)(param_1 + 0x60),4);
              if (iVar2 == 10) {
                uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x170))(param_1 + 0x10);
                uVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x160))(param_1 + 0x10);
                FUN_1402cb7b0(uVar6,uVar3,1);
                plVar4 = *(longlong **)(param_1 + 0x60);
                if (plVar4 == (longlong *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  iVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,0x15);
                  if (iVar2 != 0) {
                    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0xc4));
                    plVar4 = (longlong *)FUN_1400876b0(uVar6);
                    lVar5 = (**(code **)(*plVar4 + 0x10))(plVar4,iVar2,1);
                    if (lVar5 != 0) {
                      uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x170))(param_1 + 0x10);
                      FUN_1402cb7b0(lVar5,uVar3,1);
                    }
                  }
                }
              }
              uVar6 = 1;
            }
          }
        }
      }
    }
  }
  return uVar6;
}

// ==== CNpc::helper_1402c6e30  @1402c6e30  [medium:callgraph-r1]  (orig: FUN_1402c6e30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1402c6e30(longlong *param_1,uint param_2,char param_3)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 uVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined2 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  uVar1 = *(uint *)(param_1 + 0xf);
  if (param_3 == '\0') {
    *(uint *)(param_1 + 0xf) = ~param_2 & uVar1;
  }
  else {
    *(uint *)(param_1 + 0xf) = uVar1 | param_2;
  }
  if (uVar1 == *(uint *)(param_1 + 0xf)) {
    uVar5 = 0;
  }
  else {
    FUN_140362560(local_468);
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    local_480 = 0;
    local_488 = (undefined4)param_1[0xf];
    local_490 = 0x69;
    local_498 = CONCAT22(local_498._2_2_,1);
    iVar3 = FUN_140362620(local_468,uVar2,1,1);
    if (iVar3 == 0) {
      local_498 = 0x537;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar4 = (longlong *)FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x74));
      (**(code **)(*plVar4 + 0x30))(plVar4,0,local_468);
    }
    FUN_1403625e0(local_468);
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CNpc::helper_1403bc2a0  @1403bc2a0  [medium:callgraph-r1]  (orig: FUN_1403bc2a0)
undefined1 FUN_1403bc2a0(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x208);
}

// ==== CNpc::helper_1403bc2b0  @1403bc2b0  [medium:callgraph-r1]  (orig: FUN_1403bc2b0)
undefined8 FUN_1403bc2b0(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x1a8);
}

// ==== CNpc::helper_1403c56e0  @1403c56e0  [medium:callgraph-r3]  (orig: FUN_1403c56e0)
void FUN_1403c56e0(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      *(undefined2 *)(param_1 + 1) = *(undefined2 *)(param_3 + 1);
    }
    param_1 = (undefined4 *)((longlong)param_1 + 6);
  }
  return;
}

// ==== CNpc::helper_1403d3250  @1403d3250  [medium:callgraph-r3]  (orig: FUN_1403d3250)
longlong * FUN_1403d3250(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar4 = param_1[4] - uVar1;
  lVar2 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar3 = lVar2;
  if (lVar4 / 6 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) / 6;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1403d13c0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 6;
  if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1403d3369;
  }
  _invalid_parameter_noinfo();
LAB_1403d3369:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CNpc::helper_1403d7a10  @1403d7a10  [medium:callgraph-r2]  (orig: FUN_1403d7a10)
void FUN_1403d7a10(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 6;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 6) < uVar3) {
    FUN_1403c56e0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 6;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1403d3250(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CNpc::helper_1403d8d50  @1403d8d50  [medium:callgraph-r1]  (orig: FUN_1403d8d50)
void FUN_1403d8d50(longlong param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined4 local_res8;
  undefined1 local_resc;
  undefined1 local_resd;
  
  if (*(int *)(param_1 + 0x210) != 0) {
    plVar2 = *(longlong **)(param_1 + 0x108);
    plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x138);
    while( true ) {
      plVar3 = *(longlong **)(param_1 + 0x138);
      if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x108))) {
        _invalid_parameter_noinfo();
      }
      if (plVar5 == plVar3) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_res8 = (undefined4)plVar5[4];
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      local_resc = (undefined1)plVar5[3];
      local_resd = *(char *)((longlong)plVar5 + 100) == '\0';
      FUN_1403d7a10(param_2,&local_res8);
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar5 + 0x81) == '\0') {
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x81) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x81);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x81);
            plVar5 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar1 = *(char *)(plVar5[1] + 0x81);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
          while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
            cVar1 = *(char *)(plVar5[1] + 0x81);
            plVar4 = (longlong *)plVar5[1];
            plVar3 = plVar5;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return;
}

// ==== CNpc::helper_14040acf0  @14040acf0  [medium:callgraph-r0]  (orig: FUN_14040acf0)
undefined8 FUN_14040acf0(longlong param_1,longlong *param_2)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  
  if (param_2 != (longlong *)0x0) {
    *(undefined4 *)(param_1 + 0xc) = 0x13;
    *(undefined4 *)(param_1 + 8) = 0xaf7;
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    uVar4 = 0;
    **(undefined4 **)(param_1 + 0x428) = uVar3;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = uVar4;
    }
    else {
      uVar3 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x12);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar3;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x13);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar4;
    uVar2 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar2;
    uVar2 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = uVar2;
    uVar2 = (**(code **)(param_2[2] + 0x30))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar2;
    lVar5 = FUN_1402bc610(param_2);
    if (lVar5 != 0) {
      uVar1 = FUN_14040e5c0(lVar5);
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x12) = uVar1;
      return 1;
    }
    log_InlineLogERROR("CMsgRouletteNpcInfo::Create pRoulette is null, npc id:%u, at %s, %d.");
  }
  return 0;
}

// ==== CNpc::helper_14040b0c0  @14040b0c0  [medium:callgraph-r2]  (orig: FUN_14040b0c0)
void FUN_14040b0c0(longlong param_1,byte param_2)

{
  if (0x25 < param_2) {
                    /* WARNING: Could not recover jumptable at 0x00014040b0cf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    log_InlineLogERROR("CRoulette::SaveWinNum ucNum is error, num:%u.");
    return;
  }
  *(byte *)(param_1 + 0xe0) = param_2;
  return;
}

// ==== CNpc::helper_14040b5a0  @14040b5a0  [medium:callgraph-r3]  (orig: FUN_14040b5a0)
void FUN_14040b5a0(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CNpc::helper_14040b6c0  @14040b6c0  [medium:callgraph-r3]  (orig: FUN_14040b6c0)
void FUN_14040b6c0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014040b6e4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CNpc::helper_14040bb70  @14040bb70  [medium:callgraph-r2]  (orig: FUN_14040bb70)
void FUN_14040bb70(void *param_1)

{
  if ((DAT_140976358 & 1) == 0) {
    DAT_140976358 = DAT_140976358 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976350,"CRoulette");
    atexit((_func_5014 *)&LAB_1406d6d60);
  }
                    /* WARNING: Could not recover jumptable at 0x00014040bbc5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976350,param_1);
  return;
}

// ==== CNpc::helper_14040c2e0  @14040c2e0  [medium:callgraph-r3]  (orig: FUN_14040c2e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040c2e0(longlong param_1,longlong param_2)

{
  longlong lVar1;
  uint uVar2;
  ulonglong uVar3;
  ulonglong uVar4;
  ulonglong uVar5;
  undefined8 ***pppuVar6;
  undefined1 auStack_188 [32];
  undefined4 local_168;
  undefined8 local_158;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_150 [8];
  undefined8 **local_148 [3];
  ulonglong local_130;
  char local_128;
  undefined1 local_127 [254];
  undefined1 local_29;
  ulonglong local_28;
  
  local_158 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_188;
  if (*(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3 != 0) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_150,"");
    uVar3 = 0;
    uVar5 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3;
    uVar4 = uVar3;
    if (uVar5 != 0) {
      do {
        local_128 = '\0';
        memset(local_127,0,0xff);
        if (uVar5 <= uVar4) {
          _invalid_parameter_noinfo();
        }
        lVar1 = *(longlong *)(param_2 + 0x18);
        if ((ulonglong)(*(longlong *)(param_2 + 0x20) - lVar1 >> 3) <= uVar4) {
          _invalid_parameter_noinfo();
        }
        local_168 = *(undefined4 *)(lVar1 + 4 + uVar4 * 8);
        _snprintf(&local_128,0x100," type:%d, Amount:%d",
                  (ulonglong)*(byte *)(*(longlong *)(param_2 + 0x18) + uVar4 * 8));
        local_29 = 0;
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
                  (local_150,&local_128);
        uVar2 = (int)uVar3 + 1;
        uVar3 = (ulonglong)uVar2;
        uVar4 = uVar4 + 1;
        uVar5 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3;
      } while ((ulonglong)(longlong)(int)uVar2 < uVar5);
    }
    pppuVar6 = local_148;
    if (0xf < local_130) {
      pppuVar6 = (undefined8 ***)local_148[0];
    }
    log_InlineLogERROR("Roulette WagerType:%u, %s.",(ulonglong)*(byte *)(param_1 + 4),pppuVar6);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_150);
  }
  return;
}

// ==== CNpc::helper_14040c470  @14040c470  [medium:callgraph-r3]  (orig: FUN_14040c470)
ulonglong FUN_14040c470(longlong param_1,longlong param_2)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  ulonglong extraout_RAX;
  longlong lVar4;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  iVar1 = FUN_140339f20(param_2,0x2dd80d);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 400));
  lVar4 = *(longlong *)(lVar4 + 0x1d8);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = 0;
  }
  iVar2 = FUN_1401fe190(lVar4);
  uVar3 = iVar2 * iVar1 + *(int *)(param_2 + 0xfa4);
  return (ulonglong)CONCAT31((int3)(uVar3 >> 8),*(uint *)(param_1 + 8) <= uVar3);
}

// ==== CNpc::helper_14040c560  @14040c560  [medium:callgraph-r3]  (orig: FUN_14040c560)
void FUN_14040c560(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CNpc::helper_14040cd50  @14040cd50  [medium:callgraph-r3]  (orig: FUN_14040cd50)
void FUN_14040cd50(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14040c6f0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CNpc::helper_14040d190  @14040d190  [medium:callgraph-r3]  (orig: FUN_14040d190)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040d190(longlong param_1,int param_2,longlong param_3,ulonglong param_4,char param_5)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  IStringManager *pIVar5;
  char *pcVar6;
  undefined1 auStack_918 [32];
  longlong local_8f8;
  undefined4 local_8f0;
  undefined2 local_8e8;
  undefined2 local_8e0;
  undefined4 local_8d8;
  undefined4 local_8d0;
  undefined1 local_8c8;
  undefined8 local_8b8;
  undefined1 local_8a8 [1104];
  char local_458 [1023];
  undefined1 local_59;
  ulonglong local_58;
  
  local_8b8 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_918;
  if (param_2 == 0) {
    log_InlineLogERROR("CRoulette::GiveBonus idUser is null, bonus:%I64d");
    return;
  }
  plVar4 = (longlong *)0x0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 400));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    local_8f8 = CONCAT44(local_8f8._4_4_,0x12f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    plVar4 = (longlong *)(**(code **)(*plVar3 + 0x2b0))(plVar3);
  }
  lVar2 = param_3 - (param_4 & 0xffffffff);
  if (0 < lVar2) {
    if (plVar4 == (longlong *)0x0) goto LAB_14040d59d;
    if (*(char *)(param_1 + 4) == '\x01') {
      if (lVar2 < 100000) {
        if (999 < lVar2) {
          pIVar5 = theInstance();
          (**(code **)(plVar4[2] + 0x18))();
          pcVar6 = (char *)(*(code *)**(undefined8 **)pIVar5)
                                     (pIVar5,"STR_ROULETTE_WIN_EMONEY_NOTICE_MAP");
          local_8f8 = lVar2;
          _snprintf(local_458,0x400,pcVar6);
          local_59 = 0;
          FUN_14015b240(local_8a8);
          local_8c8 = 1;
          local_8d0 = 0;
          local_8d8 = 0;
          local_8e0 = 0;
          local_8e8 = 0x7d7;
          local_8f0 = 0xff0000;
          local_8f8 = 0;
          iVar1 = FUN_14015b300(local_8a8,"SYSTEM","ALLUSERS",local_458);
          if (iVar1 != 0) {
            (**(code **)(*plVar4 + 0x148))(plVar4,local_8a8,1);
          }
          FUN_14015b2c0(local_8a8);
        }
      }
      else {
        pIVar5 = theInstance();
        (**(code **)(plVar4[2] + 0x18))();
        pcVar6 = (char *)(*(code *)**(undefined8 **)pIVar5)
                                   (pIVar5,"STR_ROULETTE_WIN_EMONEY_NOTICE_SERVER");
        local_8f8 = lVar2;
        _snprintf(local_458,0x400,pcVar6);
        local_59 = 0;
        plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 400));
        local_8f0 = 0x7d7;
        local_8f8 = CONCAT44(local_8f8._4_4_,0xff0000);
        (**(code **)(*plVar3 + 0x60))(plVar3,local_458,0xffffffff,0);
      }
    }
    else if (lVar2 < 100000000) {
      if (999999 < lVar2) {
        pIVar5 = theInstance();
        (**(code **)(plVar4[2] + 0x18))();
        pcVar6 = (char *)(*(code *)**(undefined8 **)pIVar5)
                                   (pIVar5,"STR_ROULETTE_WIN_MONEY_NOTICE_MAP");
        local_8f8 = lVar2 / 1000;
        _snprintf(local_458,0x400,pcVar6);
        local_59 = 0;
        FUN_14015b240(local_8a8);
        local_8c8 = 1;
        local_8d0 = 0;
        local_8d8 = 0;
        local_8e0 = 0;
        local_8e8 = 0x7d7;
        local_8f0 = 0xff0000;
        local_8f8 = 0;
        iVar1 = FUN_14015b300(local_8a8,"SYSTEM","ALLUSERS",local_458);
        if (iVar1 != 0) {
          (**(code **)(*plVar4 + 0x148))(plVar4,local_8a8,1);
        }
        FUN_14015b2c0(local_8a8);
      }
    }
    else {
      pIVar5 = theInstance();
      (**(code **)(plVar4[2] + 0x18))();
      pcVar6 = (char *)(*(code *)**(undefined8 **)pIVar5)
                                 (pIVar5,"STR_ROULETTE_WIN_MONEY_NOTICE_SERVER");
      local_8f8 = lVar2 / 1000;
      _snprintf(local_458,0x400,pcVar6);
      local_59 = 0;
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 400));
      local_8f0 = 0x7d7;
      local_8f8 = CONCAT44(local_8f8._4_4_,0xff0000);
      (**(code **)(*plVar3 + 0x60))(plVar3,local_458,0xffffffff,0);
    }
  }
  if ((plVar4 != (longlong *)0x0) && (param_5 == '\0')) {
    FUN_14040c8b0(param_1,plVar4,param_3);
    return;
  }
LAB_14040d59d:
  FUN_14040bc30(param_1,param_2,param_3);
  return;
}

// ==== CNpc::helper_14040e5c0  @14040e5c0  [medium:callgraph-r1]  (orig: FUN_14040e5c0)
char FUN_14040e5c0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  char cVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 0x20);
  cVar6 = '\0';
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x50);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x50);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x20))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar3) {
            return cVar6;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar5[4] != 0) && (*(char *)(plVar5[4] + 0x14) == '\0')) {
            cVar6 = cVar6 + '\x01';
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CNpc::helper_14040eaa0  @14040eaa0  [medium:callgraph-r2]  (orig: FUN_14040eaa0)
undefined8 * FUN_14040eaa0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_14040b6c0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_14040ec8c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_14040ec8c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14040c560(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14040b5a0(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_14040c560(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_14040b5a0(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_14040c560(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_14040b5a0(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CNpc::helper_14040ef50  @14040ef50  [medium:callgraph-r2]  (orig: FUN_14040ef50)
longlong * FUN_14040ef50(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14040cd50(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14040eaa0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CNpc::helper_14040f100  @14040f100  [medium:callgraph-r3]  (orig: FUN_14040f100)
void FUN_14040f100(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14040ef50((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CNpc::helper_14040f200  @14040f200  [medium:callgraph-r2]  (orig: FUN_14040f200)
undefined8 FUN_14040f200(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  uint uVar6;
  ulonglong uVar7;
  undefined1 local_res8 [8];
  undefined1 local_28 [32];
  ulonglong uVar8;
  
  lVar4 = *(longlong *)(param_1 + 0x198);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar8 = 0;
  if (*(longlong *)(lVar4 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = uVar8;
  }
  else {
    uVar6 = (**(code **)(**(longlong **)(lVar4 + 0x60) + 0x10))(*(longlong **)(lVar4 + 0x60),0x13);
    uVar7 = (ulonglong)uVar6;
  }
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 400));
  uVar5 = *(ulonglong *)(lVar4 + 0x1d8);
  if (*(ulonglong *)(lVar4 + 0x1d8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = uVar8;
  }
  cVar2 = FUN_140204a30(uVar5,uVar7,param_1);
  if (cVar2 != '\0') {
    do {
      local_res8[0] = (undefined1)uVar8;
      FUN_140203500(param_1 + 0x60,local_28,local_res8);
      uVar6 = (int)uVar8 + 1;
      uVar8 = (ulonglong)uVar6;
    } while ((int)uVar6 < 5);
    *(int *)(param_1 + 0x174) = *(int *)(param_1 + 0x18) * 9;
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x198) + 8))();
    lVar4 = FUN_1404dcd50(*(undefined4 *)(param_1 + 400),uVar3);
    *(longlong *)(param_1 + 0x188) = lVar4;
    if (lVar4 != 0) {
      *(undefined1 *)(param_1 + 0xe0) = 0x26;
      return 1;
    }
    if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
    }
    log_InlineLogERROR("CRoulette::Create CRouletteWitnessMgr::CreateNew failed, npc record id:%u.")
    ;
    return 0;
  }
  if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60);
    (**(code **)(*plVar1 + 0x10))(plVar1,0x12);
  }
  log_InlineLogERROR("CRoulette::Create GetChipInfo failed, npc:%u, chip id:%u, at %s, %d");
  return 0;
}

// ==== CNpc::helper_14040f450  @14040f450  [medium:callgraph-r2]  (orig: FUN_14040f450)
void FUN_14040f450(longlong param_1)

{
  int iVar1;
  undefined1 local_res8 [8];
  undefined1 local_28 [32];
  
  *(undefined1 *)(param_1 + 0x170) = 0;
  iVar1 = 0;
  *(undefined4 *)(param_1 + 0x184) = 0;
  *(undefined4 *)(param_1 + 0x180) = 0;
  *(undefined4 *)(param_1 + 0x17c) = 0;
  *(undefined4 *)(param_1 + 0x178) = 0;
  FUN_1404dd170(*(undefined8 *)(param_1 + 0x188));
  if (*(ulonglong *)(param_1 + 0x98) < 5) {
    log_InlineLogERROR("CRoulette::ProcessRouletteStop idle seat num is error, size:%u.");
    FUN_140201210(param_1 + 0x60);
    do {
      local_res8[0] = (undefined1)iVar1;
      FUN_140203500(param_1 + 0x60,local_28,local_res8);
      iVar1 = iVar1 + 1;
    } while (iVar1 < 5);
  }
  return;
}

// ==== CNpc::helper_14040f4e0  @14040f4e0  [medium:callgraph-r2]  (orig: FUN_14040f4e0)
undefined8 FUN_14040f4e0(undefined8 param_1,byte param_2)

{
  int iVar1;
  byte local_res10 [8];
  undefined1 local_28 [32];
  
  local_res10[0] = param_2;
  FUN_140201210();
  if (0x25 < param_2) {
    log_InlineLogERROR("CRoulette::ProcessEndOfOneRound Get random num is error, num:%d.");
    return 0;
  }
  if ((param_2 != 0x25) && (param_2 != 0)) {
    FUN_140203500(param_1,local_28,local_res10);
    if ((param_2 & 1) == 0) {
      local_res10[0] = 0x6f;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else {
      local_res10[0] = 0x70;
      FUN_140203500(param_1,local_28,local_res10);
    }
    if ((byte)(param_2 - 1) < 0xc) {
      local_res10[0] = 0x79;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else if ((byte)(param_2 - 0xd) < 0xc) {
      local_res10[0] = 0x7a;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else {
      local_res10[0] = 0x7b;
      FUN_140203500(param_1,local_28,local_res10);
    }
    iVar1 = (uint)param_2 + (param_2 / 3) * -3;
    if (iVar1 == 1) {
      local_res10[0] = 0x83;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else if (iVar1 == 2) {
      local_res10[0] = 0x84;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else {
      local_res10[0] = 0x85;
      FUN_140203500(param_1,local_28,local_res10);
    }
    if ((byte)(param_2 - 1) < 0x12) {
      local_res10[0] = 0x8d;
      FUN_140203500(param_1,local_28,local_res10);
    }
    else {
      local_res10[0] = 0x8e;
      FUN_140203500(param_1,local_28,local_res10);
    }
    switch((uint)param_2) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 9:
    case 0xc:
    case 0xe:
    case 0x10:
    case 0x12:
    case 0x13:
    case 0x15:
    case 0x17:
    case 0x19:
    case 0x1b:
    case 0x1e:
    case 0x20:
    case 0x22:
    case 0x24:
      local_res10[0] = 0x97;
      FUN_140203500(param_1,local_28,local_res10);
      return 1;
    default:
      local_res10[0] = 0x98;
    }
  }
  FUN_140203500(param_1,local_28,local_res10);
  return 1;
}

// ==== CNpc::helper_14040fcb0  @14040fcb0  [medium:callgraph-r2]  (orig: FUN_14040fcb0)
void FUN_14040fcb0(longlong param_1)

{
  FUN_140204240((undefined8 *)(param_1 + 0xa0));
  operator_delete(*(void **)(param_1 + 0xa0));
  FUN_140204240((undefined8 *)(param_1 + 0x60));
  operator_delete(*(void **)(param_1 + 0x60));
  FUN_14040f100((undefined8 *)(param_1 + 0x20));
  operator_delete(*(void **)(param_1 + 0x20));
  return;
}

// ==== CNpc::helper_14040fd60  @14040fd60  [medium:callgraph-r2]  (orig: FUN_14040fd60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14040fd60(longlong param_1,int *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  IStringManager *pIVar4;
  longlong lVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  int iVar9;
  ulonglong uVar10;
  undefined1 auStack_c8 [32];
  ulonglong local_a8;
  ulonglong local_a0;
  longlong local_98;
  int local_88;
  ulonglong local_80;
  uint local_78;
  uint local_74;
  uint local_70;
  longlong local_68;
  undefined8 local_58;
  char local_50 [32];
  ulonglong local_30;
  
  local_58 = 0xfffffffffffffffe;
  local_30 = DAT_1409707c0 ^ (ulonglong)auStack_c8;
  if (param_2 == (int *)0x0) {
    local_a8 = CONCAT44(local_a8._4_4_,0x358);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar7 = 0;
    local_88 = 0;
    iVar9 = *param_2;
    if (iVar9 == 0) {
      log_InlineLogERROR("CRoulette::ProcessPlayerBonus idUser is 0, status:%u.");
      FUN_14040c2e0(param_1,param_2 + 6);
    }
    else if (*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3 == 0) {
      if (*(longlong *)(param_1 + 0x98) == 0) {
        *(char *)((longlong)param_2 + 0x16) = *(char *)((longlong)param_2 + 0x16) + '\x01';
      }
      else {
        *(undefined1 *)((longlong)param_2 + 0x16) = 0;
      }
      *(int *)((ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c + 0xe4 + param_1) = iVar9;
      lVar5 = (ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c;
      *(undefined8 *)(lVar5 + 0xe8 + param_1) = *(undefined8 *)(param_2 + 1);
      *(undefined8 *)(lVar5 + 0xf0 + param_1) = *(undefined8 *)(param_2 + 3);
      *(undefined4 *)((ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c + 0xf8 + param_1) = 0;
      *(undefined4 *)(((ulonglong)*(byte *)((longlong)param_2 + 0x15) + 9) * 0x1c + param_1) = 0;
    }
    else {
      *(undefined1 *)((longlong)param_2 + 0x16) = 0;
      local_80 = 0;
      local_78 = 0;
      local_74 = 0;
      uVar8 = uVar7;
      uVar10 = uVar7;
      local_88 = iVar9;
      while( true ) {
        uVar6 = (ulonglong)(int)uVar7;
        iVar9 = (int)uVar10;
        if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <= uVar6)
        break;
        if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <= uVar6)
        {
          _invalid_parameter_noinfo();
        }
        local_78 = iVar9 + *(int *)(*(longlong *)(param_2 + 0xc) + 4 + uVar6 * 8);
        local_80 = *(ulonglong *)(param_1 + 0xd0);
        local_68 = *(longlong *)(param_1 + 0xa0);
        if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <= uVar6)
        {
          _invalid_parameter_noinfo();
        }
        plVar2 = (longlong *)FUN_1402036b0(param_1 + 0xa0,local_50);
        if ((*plVar2 == 0) || (*plVar2 != local_68)) {
          _invalid_parameter_noinfo();
        }
        if (plVar2[1] != local_80) {
          if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <= uVar6
             ) {
            _invalid_parameter_noinfo();
          }
          local_70 = *(byte *)(*(longlong *)(param_2 + 0xc) + uVar6 * 8) / 10;
          if (local_70 < 10) {
            local_70 = 10;
          }
          switch(local_70) {
          case 10:
            if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <=
                uVar6) {
              _invalid_parameter_noinfo();
            }
            uVar8 = uVar8 + (uint)(*(int *)(*(longlong *)(param_2 + 0xc) + 4 + uVar6 * 8) * 0x24);
            local_80 = uVar8;
            break;
          case 0xb:
          case 0xe:
          case 0xf:
            if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <=
                uVar6) {
              _invalid_parameter_noinfo();
            }
            uVar8 = uVar8 + (uint)(*(int *)(*(longlong *)(param_2 + 0xc) + 4 + uVar6 * 8) * 2);
            local_80 = uVar8;
            break;
          case 0xc:
          case 0xd:
            if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <=
                uVar6) {
              _invalid_parameter_noinfo();
            }
            uVar8 = uVar8 + (uint)(*(int *)(*(longlong *)(param_2 + 0xc) + 4 + uVar6 * 8) * 3);
            local_80 = uVar8;
            break;
          default:
            if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <=
                uVar6) {
              _invalid_parameter_noinfo();
            }
            if ((ulonglong)(*(longlong *)(param_2 + 0xe) - *(longlong *)(param_2 + 0xc) >> 3) <=
                uVar6) {
              _invalid_parameter_noinfo();
            }
            log_InlineLogERROR(
                              "CRoulette::ProcessPlayerBonus sort error, idUserL:%u, wager type:%u, amount:%u."
                              );
          }
        }
        local_74 = (int)uVar7 + 1;
        uVar7 = (ulonglong)local_74;
        uVar10 = (ulonglong)local_78;
      }
      FUN_140206780(param_2 + 6);
      if (((char)param_2[5] != '\x01') && (*(byte *)((longlong)param_2 + 0x15) < 5)) {
        *(int *)((ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c + 0xe4 + param_1) = *param_2;
        lVar5 = (ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c;
        *(undefined8 *)(lVar5 + 0xe8 + param_1) = *(undefined8 *)(param_2 + 1);
        *(undefined8 *)(lVar5 + 0xf0 + param_1) = *(undefined8 *)(param_2 + 3);
        *(int *)((ulonglong)*(byte *)((longlong)param_2 + 0x15) * 0x1c + 0xf8 + param_1) = iVar9;
        if ((longlong)uVar8 < 1000000000) {
          *(int *)(((ulonglong)*(byte *)((longlong)param_2 + 0x15) + 9) * 0x1c + param_1) =
               (int)uVar8;
        }
        else {
          *(undefined4 *)(((ulonglong)*(byte *)((longlong)param_2 + 0x15) + 9) * 0x1c + param_1) =
               1000000000;
        }
      }
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 400));
      plVar2 = (longlong *)FUN_140087650(uVar3);
      lVar5 = (**(code **)(*plVar2 + 0x98))(plVar2,*param_2);
      if (lVar5 != 0) {
        local_50[0] = '\0';
        local_50[1] = '\0';
        local_50[2] = '\0';
        local_50[3] = '\0';
        local_50[4] = '\0';
        local_50[5] = '\0';
        local_50[6] = '\0';
        local_50[7] = '\0';
        local_50[8] = '\0';
        local_50[9] = '\0';
        local_50[10] = '\0';
        local_50[0xb] = '\0';
        local_50[0xc] = '\0';
        local_50[0xd] = '\0';
        local_50[0xe] = '\0';
        local_50[0xf] = '\0';
        local_50[0x10] = '\0';
        local_50[0x11] = '\0';
        local_50[0x12] = '\0';
        local_50[0x13] = '\0';
        local_50[0x14] = '\0';
        local_50[0x15] = '\0';
        local_50[0x16] = '\0';
        local_50[0x17] = '\0';
        local_50[0x18] = '\0';
        local_50[0x19] = '\0';
        local_50[0x1a] = '\0';
        local_50[0x1b] = '\0';
        local_50[0x1c] = '\0';
        local_50[0x1d] = '\0';
        local_50[0x1e] = '\0';
        local_50[0x1f] = 0;
        if (*(char *)(param_1 + 0xe0) == '%') {
          strcpy_s(local_50,0x20,"00");
        }
        else {
          _snprintf(local_50,0x20,"%u");
          local_50[0x1f] = 0;
        }
        local_a8 = uVar8;
        if (*(char *)(param_1 + 4) == '\x01') {
          uVar7 = uVar8 - uVar10;
          if ((longlong)uVar7 < 0) {
            pIVar4 = theInstance();
            lVar1 = *(longlong *)(lVar5 + 0x10);
            uVar3 = (*(code *)**(undefined8 **)pIVar4)
                              (pIVar4,"STR_ROULETTE_EMONEY_NOTICE_USER_LOSE");
            local_a0 = -uVar7;
            (**(code **)(lVar1 + 0x358))(lVar5 + 0x10,uVar3,local_50,uVar10);
          }
          else {
            pIVar4 = theInstance();
            lVar1 = *(longlong *)(lVar5 + 0x10);
            uVar3 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_ROULETTE_EMONEY_NOTICE_USER_WIN")
            ;
            local_a0 = uVar7;
            (**(code **)(lVar1 + 0x358))(lVar5 + 0x10,uVar3,local_50,uVar10);
          }
        }
        else {
          uVar7 = uVar8 - uVar10;
          if ((longlong)uVar7 < 0) {
            pIVar4 = theInstance();
            lVar1 = *(longlong *)(lVar5 + 0x10);
            uVar3 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_ROULETTE_MONEY_NOTICE_USER_LOSE")
            ;
            local_a0 = -uVar7;
            (**(code **)(lVar1 + 0x358))(lVar5 + 0x10,uVar3,local_50,uVar10);
          }
          else {
            pIVar4 = theInstance();
            lVar1 = *(longlong *)(lVar5 + 0x10);
            uVar3 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_ROULETTE_MONEY_NOTICE_USER_WIN");
            local_a0 = uVar7;
            (**(code **)(lVar1 + 0x358))(lVar5 + 0x10,uVar3,local_50,uVar10);
          }
        }
      }
      if (*(char *)(param_1 + 4) == '\x01') {
        if (*(longlong *)(*(longlong *)(param_1 + 0x198) + 0x60) == 0) {
          local_a8 = CONCAT44(local_a8._4_4_,0x174);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(**(longlong **)(*(longlong *)(param_1 + 0x198) + 0x60) + 8))();
        }
        local_98 = uVar8 - uVar10;
        local_a8 = CONCAT44(local_a8._4_4_,iVar9);
        local_a0 = uVar8;
        tq::MyLogSave("gmlog/roulette",
                      "Roulette EMoney Single round result: NpcOwner[%u] User[%u] emoney wager:%u, bonus:%I64d, win:%I64d"
                     );
      }
      if (0 < (longlong)uVar8) {
        local_a8 = CONCAT71(local_a8._1_7_,(char)param_2[5] == '\x01');
        FUN_14040d190(param_1,*param_2,uVar8,uVar10);
      }
    }
  }
  return;
}

// ==== CNpc::helper_1404103f0  @1404103f0  [medium:callgraph-r1]  (orig: FUN_1404103f0)
void FUN_1404103f0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  bool bVar7;
  undefined1 local_28 [32];
  
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x50);
  lVar6 = 0;
  plVar1 = *(longlong **)(param_1 + 0x20);
LAB_140410440:
  do {
    plVar4 = *(longlong **)(param_1 + 0x50);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar4) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar6;
    }
    else {
      lVar3 = *plVar1;
    }
    if (plVar5 == *(longlong **)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5[4] == 0) {
LAB_14041066f:
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
        plVar4 = plVar5;
        plVar2 = (longlong *)plVar5[2];
        if (*(char *)(plVar5[2] + 0x29) == '\0') {
          do {
            plVar5 = plVar2;
            plVar2 = (longlong *)*plVar5;
          } while (*(char *)(*plVar5 + 0x29) == '\0');
        }
        else {
          do {
            plVar5 = (longlong *)plVar4[1];
            if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
            bVar7 = plVar4 == (longlong *)plVar5[2];
            plVar4 = plVar5;
          } while (bVar7);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_140410440;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar6;
    }
    else {
      lVar3 = *plVar1;
    }
    if (plVar5 == *(longlong **)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14040fd60(param_1,plVar5[4]);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar6;
    }
    else {
      lVar3 = *plVar1;
    }
    if (plVar5 == *(longlong **)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)(plVar5[4] + 0x14) != '\x01') goto LAB_14041066f;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar6;
    }
    else {
      lVar3 = *plVar1;
    }
    if (plVar5 == *(longlong **)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 400));
    if (*(longlong *)(lVar3 + 0x1d8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = lVar6;
    }
    else {
      lVar3 = *(longlong *)(lVar3 + 0x1d8);
    }
    FUN_1402079d0(lVar3,plVar5[4]);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = lVar6;
    }
    else {
      lVar3 = *plVar1;
    }
    if (plVar5 == *(longlong **)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 400));
    if (*(longlong *)(lVar3 + 0x1d8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = lVar6;
    }
    else {
      lVar3 = *(longlong *)(lVar3 + 0x1d8);
    }
    FUN_140207120(lVar3,*(undefined4 *)plVar5[4],0);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar4 = plVar5;
      plVar2 = (longlong *)plVar5[2];
      if (*(char *)(plVar5[2] + 0x29) == '\0') {
        do {
          plVar5 = plVar2;
          plVar2 = (longlong *)*plVar5;
        } while (*(char *)(*plVar5 + 0x29) == '\0');
      }
      else {
        do {
          plVar5 = (longlong *)plVar4[1];
          if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
          bVar7 = plVar4 == (longlong *)plVar5[2];
          plVar4 = plVar5;
        } while (bVar7);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    FUN_14040eaa0(param_1 + 0x20,local_28);
  } while( true );
}

// ==== CNpc::helper_140410710  @140410710  [medium:callgraph-r3]  (orig: FUN_140410710)
undefined8 * FUN_140410710(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_14040cf40(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CNpc::helper_140410900  @140410900  [medium:callgraph-r2]  (orig: FUN_140410900)
undefined4 * FUN_140410900(undefined4 *param_1,undefined4 param_2,undefined8 param_3)

{
  FUN_140410710(param_1 + 8);
  FUN_140207a00(param_1 + 0x18);
  FUN_140207a00(param_1 + 0x28);
  *(undefined1 *)(param_1 + 0x38) = 0;
  param_1[0x5d] = 0;
  param_1[0x5e] = 0;
  param_1[0x5f] = 0;
  param_1[0x60] = 0;
  param_1[0x61] = 0;
  *(undefined8 *)(param_1 + 0x62) = 0;
  param_1[100] = param_2;
  *(undefined8 *)(param_1 + 0x66) = param_3;
  *(undefined1 *)(param_1 + 0x5c) = 0;
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  memset(param_1 + 0x39,0,0x8c);
  return param_1;
}

// ==== CNpc::helper_1404109d0  @1404109d0  [medium:callgraph-r1]  (orig: FUN_1404109d0)
longlong FUN_1404109d0(undefined4 param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  void *pvVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    lVar3 = 0;
  }
  else {
    if ((DAT_140976358 & 1) == 0) {
      DAT_140976358 = DAT_140976358 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140976350,"CRoulette");
      atexit((_func_5014 *)&LAB_1406d6d60);
    }
    pvVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_140976350,0x1a0);
    if (pvVar2 == (void *)0x0) {
      lVar3 = 0;
    }
    else {
      lVar3 = FUN_140410900(pvVar2,param_1,param_2,param_4,uVar4);
    }
    if (lVar3 == 0) {
      lVar3 = 0;
    }
    else {
      cVar1 = FUN_14040f200(lVar3);
      if (cVar1 == '\0') {
        FUN_14040fcb0(lVar3);
        FUN_14040bb70(lVar3);
        lVar3 = 0;
      }
    }
  }
  return lVar3;
}

// ==== CNpc::helper_140410aa0  @140410aa0  [medium:callgraph-r1]  (orig: FUN_140410aa0)
void FUN_140410aa0(void *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  if (*(longlong *)((longlong)param_1 + 0x188) != 0) {
    FUN_1404dc8d0(*(undefined8 *)((longlong)param_1 + 0x188),param_2,param_3,param_4,
                  0xfffffffffffffffe);
    *(undefined8 *)((longlong)param_1 + 0x188) = 0;
  }
  if (param_1 != (void *)0x0) {
    puVar1 = (undefined8 *)((longlong)param_1 + 0xa0);
    puStack_30 = *(undefined8 **)((longlong)param_1 + 0xd0);
    local_38 = *puVar1;
    puStack_20 = (undefined8 *)*puStack_30;
    local_28 = local_38;
    FUN_140203080(puVar1,local_18,&local_28,&local_38);
    operator_delete(*(void **)((longlong)param_1 + 0xd0));
    *(undefined8 *)((longlong)param_1 + 0xd0) = 0;
    *(undefined8 *)((longlong)param_1 + 0xd8) = 0;
    operator_delete((void *)*puVar1);
    puVar1 = (undefined8 *)((longlong)param_1 + 0x60);
    puStack_20 = *(undefined8 **)((longlong)param_1 + 0x90);
    local_38 = *puVar1;
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_140203080(puVar1,local_18,&local_38,&local_28);
    operator_delete(*(void **)((longlong)param_1 + 0x90));
    *(undefined8 *)((longlong)param_1 + 0x90) = 0;
    *(undefined8 *)((longlong)param_1 + 0x98) = 0;
    operator_delete((void *)*puVar1);
    puVar1 = (undefined8 *)((longlong)param_1 + 0x20);
    puStack_20 = *(undefined8 **)((longlong)param_1 + 0x50);
    local_38 = *puVar1;
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_14040ef50(puVar1,local_18,&local_38,&local_28);
    operator_delete(*(void **)((longlong)param_1 + 0x50));
    *(undefined8 *)((longlong)param_1 + 0x50) = 0;
    *(undefined8 *)((longlong)param_1 + 0x58) = 0;
    operator_delete((void *)*puVar1);
    if ((DAT_140976358 & 1) == 0) {
      DAT_140976358 = DAT_140976358 | 1;
      CMyHeap::CMyHeap((CMyHeap *)&DAT_140976350,"CRoulette");
      atexit((_func_5014 *)&LAB_1406d6d60);
    }
    CMyHeap::Free((CMyHeap *)&DAT_140976350,param_1);
  }
  return;
}

// ==== CNpc::helper_140410f40  @140410f40  [medium:callgraph-r1]  (orig: FUN_140410f40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140410f40(longlong param_1)

{
  undefined1 uVar1;
  char cVar2;
  longlong lVar3;
  int iVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  uint local_458;
  undefined8 local_450;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_450 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  local_458 = 0;
  uVar6 = 0;
  uVar5 = uVar6;
  while (iVar4 = (int)uVar5, iVar4 < 5) {
    *(undefined4 *)((longlong)iVar4 * 0x1c + 0xe4 + param_1) = 0;
    local_458 = iVar4 + 1;
    uVar5 = (ulonglong)local_458;
  }
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 400));
  if (*(longlong *)(lVar3 + 0x1d8) == 0) {
    local_468 = 0x15f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar6 = *(ulonglong *)(lVar3 + 0x1d8);
  }
  uVar1 = FUN_140200550(uVar6);
  cVar2 = FUN_14040f4e0(param_1 + 0xa0,uVar1);
  if (cVar2 == '\0') {
    log_InlineLogERROR("CRoulette::ProcessEndOfOneRound SetWagerAreaWin failed, Win num:%u.");
  }
  else {
    FUN_14040b0c0(param_1,uVar1);
    FUN_1404ddcc0(local_448);
    cVar2 = FUN_1404ddd70(local_448,uVar1);
    if (cVar2 != '\0') {
      FUN_140410cb0(param_1,local_448,0);
    }
    FUN_1404ddd10(local_448);
  }
  return;
}

// ==== CNpc::helper_140411070  @140411070  [medium:callgraph-r2]  (orig: FUN_140411070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140411070(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  bool bVar14;
  undefined1 auStack_9c8 [32];
  undefined4 local_9a8;
  longlong *local_998;
  longlong *plStack_990;
  longlong *local_988;
  longlong *local_980;
  longlong *local_978;
  longlong *local_970;
  longlong *local_968;
  longlong *local_958;
  longlong *plStack_950;
  longlong *local_948;
  longlong *plStack_940;
  longlong *local_938 [4];
  longlong *local_918;
  longlong *plStack_910;
  undefined8 local_908;
  longlong *local_8f8;
  longlong *plStack_8f0;
  undefined1 local_8e8 [16];
  undefined1 local_8d8 [16];
  undefined1 local_8c8 [16];
  undefined1 local_8b8 [16];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_908 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_9c8;
  plVar13 = (longlong *)**(longlong **)(param_1 + 0x50);
  plVar1 = *(longlong **)(param_1 + 0x20);
  local_998 = plVar1;
  plStack_990 = plVar13;
LAB_1404110d0:
  do {
    plVar9 = *(longlong **)(param_1 + 0x50);
    local_938[0] = *(longlong **)(param_1 + 0x20);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_938[0])) {
      _invalid_parameter_noinfo();
    }
    if (plVar13 == plVar9) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plStack_990;
    plVar9 = local_998;
    if (plVar13[4] == 0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar13 + 0x29) == '\0') {
        plVar11 = plVar13;
        plVar12 = (longlong *)plVar13[2];
        if (*(char *)(plVar13[2] + 0x29) == '\0') {
          do {
            plVar13 = plVar12;
            plVar12 = (longlong *)*plVar13;
            plStack_990 = plVar13;
            local_970 = plVar13;
          } while (*(char *)(*plVar13 + 0x29) == '\0');
        }
        else {
          do {
            plVar13 = (longlong *)plVar11[1];
            plStack_990 = plVar13;
            if (*(char *)((longlong)plVar13 + 0x29) != '\0') break;
            bVar14 = plVar11 == (longlong *)plVar13[2];
            plVar11 = plVar13;
          } while (bVar14);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_958 = plVar9;
      plStack_950 = plVar3;
      FUN_14040eaa0(param_1 + 0x20,local_8e8);
      goto LAB_1404110d0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)(plVar13[4] + 0x14) != '\0') {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar1;
      }
      if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 400));
      if (*(longlong *)(lVar7 + 0x1d8) == 0) {
        local_9a8 = 0x15f;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar8 = 0;
      }
      else {
        uVar8 = *(undefined8 *)(lVar7 + 0x1d8);
      }
      FUN_1402079d0(uVar8,plVar13[4]);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar1;
      }
      if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 400));
      if (*(longlong *)(lVar7 + 0x1d8) == 0) {
        local_9a8 = 0x15f;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar8 = 0;
      }
      else {
        uVar8 = *(undefined8 *)(lVar7 + 0x1d8);
      }
      FUN_140207120(uVar8,*(undefined4 *)plVar13[4],0);
      plVar3 = plStack_990;
      plVar9 = local_998;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar13 + 0x29) == '\0') {
        plVar11 = plVar13;
        plVar12 = (longlong *)plVar13[2];
        if (*(char *)(plVar13[2] + 0x29) == '\0') {
          do {
            plVar13 = plVar12;
            plVar12 = (longlong *)*plVar13;
            plStack_990 = plVar13;
            local_968 = plVar13;
          } while (*(char *)(*plVar13 + 0x29) == '\0');
        }
        else {
          do {
            plVar13 = (longlong *)plVar11[1];
            plStack_990 = plVar13;
            if (*(char *)((longlong)plVar13 + 0x29) != '\0') break;
            bVar14 = plVar11 == (longlong *)plVar13[2];
            plVar11 = plVar13;
          } while (bVar14);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_948 = plVar9;
      plStack_940 = plVar3;
      FUN_14040eaa0(param_1 + 0x20,local_8c8);
      goto LAB_1404110d0;
    }
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 400));
    plVar9 = (longlong *)FUN_140087650(uVar8);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x98))(plVar9,*(undefined4 *)plVar13[4]);
    if (plVar9 == (longlong *)0x0) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar1;
      }
      if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 400));
      if (*(longlong *)(lVar7 + 0x1d8) == 0) {
        local_9a8 = 0x15f;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar8 = 0;
      }
      else {
        uVar8 = *(undefined8 *)(lVar7 + 0x1d8);
      }
      FUN_1402079d0(uVar8,plVar13[4]);
      plVar3 = plStack_990;
      plVar9 = local_998;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar13 + 0x29) == '\0') {
        plVar11 = plVar13;
        plVar12 = (longlong *)plVar13[2];
        if (*(char *)(plVar13[2] + 0x29) == '\0') {
          do {
            plVar13 = plVar12;
            plVar12 = (longlong *)*plVar13;
            plStack_990 = plVar13;
            local_988 = plVar13;
          } while (*(char *)(*plVar13 + 0x29) == '\0');
        }
        else {
          do {
            plVar13 = (longlong *)plVar11[1];
            plStack_990 = plVar13;
            if (*(char *)((longlong)plVar13 + 0x29) != '\0') break;
            bVar14 = plVar11 == (longlong *)plVar13[2];
            plVar11 = plVar13;
          } while (bVar14);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_918 = plVar9;
      plStack_910 = plVar3;
      FUN_14040eaa0(param_1 + 0x20,local_8b8,&local_918);
      goto LAB_1404110d0;
    }
    if (*(char *)(param_1 + 4) == '\0') {
      lVar7 = (**(code **)(*plVar9 + 0x60))(plVar9);
      if (lVar7 < (longlong)(ulonglong)(uint)(*(int *)(param_1 + 8) * 1000)) {
        uVar8 = 8;
      }
      else {
LAB_1404114fc:
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar1;
        }
        if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (*(byte *)(plVar13[4] + 0x16) < 3) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar13 + 0x29) == '\0') {
            plVar9 = plVar13;
            plVar3 = (longlong *)plVar13[2];
            if (*(char *)(plVar13[2] + 0x29) == '\0') {
              do {
                plVar13 = plVar3;
                plVar3 = (longlong *)*plVar13;
                plStack_990 = plVar13;
                local_978 = plVar13;
              } while (*(char *)(*plVar13 + 0x29) == '\0');
            }
            else {
              do {
                plVar13 = (longlong *)plVar9[1];
                plStack_990 = plVar13;
                if (*(char *)((longlong)plVar13 + 0x29) != '\0') break;
                bVar14 = plVar9 == (longlong *)plVar13[2];
                plVar9 = plVar13;
              } while (bVar14);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          goto LAB_1404110d0;
        }
        uVar8 = 7;
      }
    }
    else {
      cVar4 = FUN_14040c470(param_1,plVar9);
      if (cVar4 != '\0') goto LAB_1404114fc;
      uVar8 = 8;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140203500(param_1 + 0x60,local_938,plVar13[4] + 0x15);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar13 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 400));
    if (*(longlong *)(lVar7 + 0x1d8) == 0) {
      local_9a8 = 0x15f;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar10 = 0;
    }
    else {
      uVar10 = *(undefined8 *)(lVar7 + 0x1d8);
    }
    FUN_1402079d0(uVar10,plVar13[4]);
    plVar11 = plStack_990;
    plVar3 = local_998;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar13 + 0x29) == '\0') {
      plVar12 = plVar13;
      plVar2 = (longlong *)plVar13[2];
      if (*(char *)(plVar13[2] + 0x29) == '\0') {
        do {
          plVar13 = plVar2;
          plVar2 = (longlong *)*plVar13;
          plStack_990 = plVar13;
          local_980 = plVar13;
        } while (*(char *)(*plVar13 + 0x29) == '\0');
      }
      else {
        do {
          plVar13 = (longlong *)plVar12[1];
          plStack_990 = plVar13;
          if (*(char *)((longlong)plVar13 + 0x29) != '\0') break;
          bVar14 = plVar12 == (longlong *)plVar13[2];
          plVar12 = plVar13;
        } while (bVar14);
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_8f8 = plVar3;
    plStack_8f0 = plVar11;
    FUN_14040eaa0(param_1 + 0x20,local_8d8,&local_8f8);
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 400));
    if (*(longlong *)(lVar7 + 0x1d8) == 0) {
      local_9a8 = 0x15f;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar10 = 0;
    }
    else {
      uVar10 = *(undefined8 *)(lVar7 + 0x1d8);
    }
    uVar5 = (**(code **)(**(longlong **)(param_1 + 0x198) + 8))();
    uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
    cVar4 = FUN_140205b00(uVar10,uVar6,uVar5);
    if (cVar4 == '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x198) + 8))();
      (**(code **)(*plVar9 + 8))(plVar9);
      log_InlineLogERROR(
                        "CRoulette::CheckAllPlayerCondition RouletteMgr()->ProcessChangeToWitness failed. idUser:%u, idNpc."
                        );
    }
    else {
      uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
      FUN_1404dcbe0(*(undefined8 *)(param_1 + 0x188),uVar5);
      FUN_1404500a0(local_8a8);
      cVar4 = FUN_140450150(local_8a8,uVar8);
      if (cVar4 == '\0') {
        log_InlineLogERROR("CRoulette::CheckAllPlayerCondition create msg failed.");
        FUN_1404500f0(local_8a8);
      }
      else {
        (**(code **)(plVar9[2] + 0x350))(plVar9 + 2,local_8a8);
        FUN_1404131e0(local_478);
        uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
        cVar4 = FUN_140413290(local_478,7,uVar5);
        if (cVar4 == '\0') {
          log_InlineLogERROR("CRoulette::CheckAllPlayerCondition create msg failed.");
        }
        else {
          uVar5 = (**(code **)(*plVar9 + 8))(plVar9);
          FUN_140410cb0(param_1,local_478,uVar5);
        }
        FUN_140413230(local_478);
        FUN_1404500f0(local_8a8);
      }
    }
  } while( true );
}

// ==== CNpc::helper_1404126b0  @1404126b0  [medium:callgraph-r1]  (orig: FUN_1404126b0)
ulonglong FUN_1404126b0(longlong param_1,char param_2)

{
  ulong uVar1;
  ulonglong uVar2;
  
  if (param_2 == '\0') {
    FUN_140411070();
  }
  if (*(longlong *)(param_1 + 0x58) == 0) {
    uVar2 = FUN_14040f450(param_1);
  }
  else {
    *(undefined1 *)(param_1 + 0x170) = 1;
    *(undefined4 *)(param_1 + 0x17c) = 0;
    *(undefined4 *)(param_1 + 0x178) = 0;
    *(undefined4 *)(param_1 + 0x180) = 0x1e;
    uVar1 = tq::TimeGet(0);
    uVar2 = (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
    *(uint *)(param_1 + 0x184) = uVar1 / 1000;
  }
  return uVar2;
}

// ==== CNpc::helper_140412f60  @140412f60  [medium:callgraph-r0]  (orig: FUN_140412f60)
void FUN_140412f60(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  
  cVar1 = *(char *)(param_1 + 0x170);
  if (cVar1 != '\0') {
    if (cVar1 == '\x01') {
      if (*(int *)(param_1 + 0x184) != 0) {
        uVar2 = tq::TimeGet(0);
        if ((uint)(*(int *)(param_1 + 0x180) + *(int *)(param_1 + 0x184)) <= uVar2 / 1000) {
          *(undefined4 *)(param_1 + 0x184) = 0;
          *(undefined4 *)(param_1 + 0x180) = 0;
          FUN_140410f40(param_1);
          *(undefined1 *)(param_1 + 0x170) = 2;
          *(undefined4 *)(param_1 + 0x178) = 3;
          uVar2 = tq::TimeGet(0);
          *(uint *)(param_1 + 0x17c) = uVar2 / 1000;
        }
      }
    }
    else {
      if (cVar1 != '\x02') {
                    /* WARNING: Could not recover jumptable at 0x000140412f8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        log_InlineLogERROR("CRoulette::OnTimer ucStatus is error, ");
        return;
      }
      if (*(int *)(param_1 + 0x17c) != 0) {
        uVar2 = tq::TimeGet(0);
        if ((uint)(*(int *)(param_1 + 0x178) + *(int *)(param_1 + 0x17c)) <= uVar2 / 1000) {
          *(undefined4 *)(param_1 + 0x17c) = 0;
          *(undefined4 *)(param_1 + 0x178) = 0;
          FUN_1404103f0(param_1);
          FUN_1404126b0(param_1,0);
          return;
        }
      }
    }
  }
  return;
}

// ==== CNpc::helper_140413290  @140413290  [medium:callgraph-r3]  (orig: FUN_140413290)
undefined8 FUN_140413290(longlong param_1,undefined1 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  *(undefined4 *)(param_1 + 0xc) = 5;
  *(undefined4 *)(param_1 + 8) = 0xaf5;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 1) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CNpc::helper_1404549d0  @1404549d0  [medium:callgraph-r0]  (orig: FUN_1404549d0)
undefined8 FUN_1404549d0(longlong param_1,longlong *param_2)

{
  undefined2 uVar1;
  undefined4 uVar2;
  ulong uVar3;
  uint uVar4;
  
  FUN_1402b5600();
  uVar2 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar2;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h",0x174)
    ;
    uVar2 = 0;
  }
  else {
    uVar2 = (**(code **)(*(longlong *)param_2[0xc] + 8))();
  }
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar2;
  uVar1 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x12) = uVar1;
  uVar1 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x1b);
  param_2 = param_2 + 2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar1;
  uVar1 = (**(code **)(*param_2 + 0x30))(param_2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar1;
  uVar1 = (**(code **)(*param_2 + 0x40))(param_2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar1;
  uVar1 = (**(code **)(*param_2 + 0x48))(param_2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = uVar1;
  uVar3 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar3;
  *(undefined4 *)(param_1 + 8) = 0x7ee;
  uVar4 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar4 + 0x17;
  return 1;
}

// ==== CNpc::helper_140456070  @140456070  [medium:callgraph-r2]  (orig: FUN_140456070)
undefined8 FUN_140456070(longlong param_1,undefined1 param_2,undefined4 param_3,undefined1 *param_4)

{
  longlong lVar1;
  
  lVar1 = 0;
  while (('\0' < (char)param_4[lVar1] && ((char)param_4[lVar1] < '\a'))) {
    lVar1 = lVar1 + 1;
    if (3 < lVar1) {
      FUN_1402b5600();
      *(undefined4 *)(param_1 + 0xc) = 0x10;
      *(undefined4 *)(param_1 + 8) = 0x459;
      **(undefined1 **)(param_1 + 0x428) = param_2;
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 1;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xc) = *param_4;
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xd) = param_4[1];
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_4[2];
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xf) = param_4[3];
      return 1;
    }
  }
  log_InlineLogERROR(&DAT_14077f428);
  return 0;
}

// ==== CNpc::helper_1404567b0  @1404567b0  [medium:callgraph-r0]  (orig: FUN_1404567b0)
undefined8 FUN_1404567b0(longlong param_1,longlong *param_2)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  char *pcVar6;
  undefined8 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  
  FUN_1402b5600();
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  **(undefined4 **)(param_1 + 0x428) = uVar3;
  uVar3 = 0;
  if (param_2[0xc] == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h",0x174)
    ;
  }
  else {
    uVar3 = (**(code **)(*(longlong *)param_2[0xc] + 8))();
  }
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar3;
  uVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x16) = uVar2;
  uVar2 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x1b);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x18) = uVar2;
  uVar2 = (**(code **)(param_2[2] + 0x30))(param_2 + 2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar2;
  uVar2 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar2;
  uVar2 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x12) = uVar2;
  uVar3 = (**(code **)(param_2[2] + 0x80))(param_2 + 2);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar3;
  uVar3 = (**(code **)(param_2[2] + 0x78))(param_2 + 2);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar3;
  iVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
  if (iVar4 == 0x1a) {
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h",
                         0x142);
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 0;
    }
    else {
      uVar3 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],1);
      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = uVar3;
    }
  }
  else {
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = 0;
  }
  iVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
  if (((iVar4 == 10) ||
      (iVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4),
      iVar4 == 0x2e)) ||
     (iVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4),
     iVar4 == 0x3d)) {
    pcVar6 = (char *)(**(code **)(param_2[2] + 0x18))(param_2 + 2);
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),pcVar6);
    iVar4 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
    if (iVar4 == 0x2e) {
      uVar7 = FUN_140008520(0xe);
      cVar1 = FUN_14008b330(uVar7);
      if (cVar1 != '\0') {
        if (param_2[0xc] == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pData",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\npc.h",
                             0x142);
          uVar9 = 0;
        }
        else {
          uVar5 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],1);
          uVar9 = (ulonglong)uVar5;
        }
        lVar8 = FUN_140008520(0xe);
        uVar10 = *(ulonglong *)(lVar8 + 0x208);
        if (uVar10 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOSSyndicateMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                             ,0x166);
          uVar10 = 0;
        }
        uVar3 = FUN_140263070(uVar10,uVar9);
        uVar7 = FUN_140008520(0xe);
        pcVar6 = (char *)FUN_1400b3310(uVar7,uVar3);
        tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),pcVar6);
      }
    }
  }
  *(undefined4 *)(param_1 + 8) = 0x455;
  uVar5 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar5 + 0x23;
  return 1;
}

// ==== CNpc::helper_1404647f0  @1404647f0  [medium:callgraph-r1]  (orig: FUN_1404647f0)
void FUN_1404647f0(void *param_1)

{
  if ((DAT_140976438 & 1) == 0) {
    DAT_140976438 = DAT_140976438 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976430,"CNpcBet");
    atexit((_func_5014 *)&LAB_1406d6e40);
  }
                    /* WARNING: Could not recover jumptable at 0x000140464845. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976430,param_1);
  return;
}

// ==== CNpc::helper_1404657d0  @1404657d0  [medium:callgraph-r3]  (orig: FUN_1404657d0)
undefined8 * FUN_1404657d0(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IMultiObjSet<CBet>::vftable;
  *param_1 = CMultiObjSet<CBet>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CNpc::helper_140467400  @140467400  [medium:callgraph-r1]  (orig: FUN_140467400)
void FUN_140467400(longlong param_1)

{
  if (*(longlong **)(param_1 + 0x40) != (longlong *)0x0) {
    (**(code **)(**(longlong **)(param_1 + 0x40) + 8))();
  }
  *(undefined ***)(param_1 + 8) = CAutoLinkSet<CUser>::vftable;
  FUN_140466f60(param_1 + 0x10);
  return;
}

// ==== CNpc::helper_140467450  @140467450  [medium:callgraph-r3]  (orig: FUN_140467450)
undefined8 * FUN_140467450(undefined8 *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = CAutoLinkSet<CUser>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  return param_1;
}

// ==== CNpc::helper_140467bd0  @140467bd0  [medium:callgraph-r2]  (orig: FUN_140467bd0)
undefined4 * FUN_140467bd0(undefined4 *param_1)

{
  ulong uVar1;
  void *pvVar2;
  longlong lVar3;
  
  FUN_140467450(param_1 + 2);
  lVar3 = 0;
  *(undefined8 *)(param_1 + 0x10) = 0;
  *(undefined8 *)(param_1 + 0x16) = 0;
  param_1[0x1b] = 0;
  param_1[0x1c] = 0;
  param_1[0x13] = 0;
  *param_1 = 0;
  param_1[0x12] = 0;
  param_1[0x18] = 0;
  param_1[0x19] = 0;
  uVar1 = tq::TimeGet(0);
  param_1[0x1a] = uVar1 + 1800000;
  pvVar2 = operator_new(0x40);
  if (pvVar2 != (void *)0x0) {
    lVar3 = FUN_1404657d0(pvVar2,1);
  }
  if ((*(longlong *)(param_1 + 0x10) != 0) || (lVar3 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  *(longlong *)(param_1 + 0x10) = lVar3;
  return param_1;
}

// ==== CNpc::helper_140467c90  @140467c90  [medium:callgraph-r1]  (orig: FUN_140467c90)
longlong FUN_140467c90(undefined4 param_1,undefined8 param_2)

{
  void *pvVar1;
  longlong lVar2;
  
  if ((DAT_140976438 & 1) == 0) {
    DAT_140976438 = DAT_140976438 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976430,"CNpcBet");
    atexit((_func_5014 *)&LAB_1406d6e40);
  }
  pvVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976430,0x78);
  if (pvVar1 == (void *)0x0) {
    lVar2 = 0;
  }
  else {
    lVar2 = FUN_140467bd0(pvVar1);
  }
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_OK",&DAT_1407835e8,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\betoutside.cpp"
                       ,0x35);
    lVar2 = 0;
  }
  else {
    *(undefined4 *)(lVar2 + 0x50) = param_1;
    *(undefined8 *)(lVar2 + 0x58) = param_2;
  }
  return lVar2;
}

// ==== CNpc::helper_140468050  @140468050  [medium:callgraph-r1]  (orig: FUN_140468050)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140468050(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_140455ef0(local_448);
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x58) + 8))();
  iVar2 = FUN_140455f70(local_448,5,uVar1);
  if (iVar2 != 0) {
    FUN_140467d50(param_1,local_448,0);
  }
  FUN_140455f40(local_448);
  return;
}

// ==== CNpc::helper_1404680e0  @1404680e0  [medium:callgraph-r1]  (orig: FUN_1404680e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404680e0(longlong param_1)

{
  char cVar1;
  char cVar2;
  int iVar3;
  ulong uVar4;
  undefined4 uVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined4 *puVar8;
  undefined8 uVar9;
  IStringManager *pIVar10;
  char *_Format;
  longlong *plVar11;
  int iVar12;
  longlong lVar13;
  int iVar14;
  undefined1 auStack_cf8 [32];
  int local_cd8;
  undefined8 local_cc8;
  undefined1 local_cb8 [1104];
  undefined1 local_868 [1072];
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_cc8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_cf8;
  if (*(longlong *)(param_1 + 0x40) == 0) {
    local_cd8 = 0x1c;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar13 = *(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x28);
  lVar13 = lVar13 / 6 + (lVar13 >> 0x3f);
  iVar3 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))();
  uVar4 = tq::TimeGet(0);
  srand(((int)(lVar13 >> 2) - (int)(lVar13 >> 0x3f)) + uVar4 + iVar3);
  lVar13 = 0;
  do {
    iVar3 = rand();
    *(char *)(param_1 + 0x4c + lVar13) =
         (char)iVar3 +
         ((char)(iVar3 / 6) + (char)(iVar3 >> 0x1f) +
         (char)(((longlong)iVar3 / 6 + ((longlong)iVar3 >> 0x3f) & 0xffffffffU) >> 0x1f)) * -6 +
         '\x01';
    lVar13 = lVar13 + 1;
  } while (lVar13 < 4);
  FUN_140455ef0(local_868);
  uVar5 = (**(code **)(**(longlong **)(param_1 + 0x58) + 8))();
  iVar3 = FUN_140456070(local_868,6,uVar5,param_1 + 0x4c);
  if (iVar3 != 0) {
    plVar11 = (longlong *)(*(longlong *)(param_1 + 0x58) + 0x10);
    (**(code **)(*plVar11 + 0x348))(plVar11,local_868,0);
  }
  if (*(longlong *)(param_1 + 0x40) == 0) {
    local_cd8 = 0x1c;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar6 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))();
LAB_140468257:
  do {
    while( true ) {
      while( true ) {
        while( true ) {
          uVar6 = uVar6 - 1;
          if (*(longlong *)(param_1 + 0x40) == 0) {
            local_cd8 = 0x1c;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar7 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x10))();
          if (uVar7 <= uVar6) {
            FUN_140455f40(local_868);
            return;
          }
          if (*(longlong *)(param_1 + 0x40) == 0) {
            local_cd8 = 0x1c;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          puVar8 = (undefined4 *)
                   (**(code **)(**(longlong **)(param_1 + 0x40) + 0x18))
                             (*(longlong **)(param_1 + 0x40),uVar6);
          if (puVar8 != (undefined4 *)0x0) break;
          local_cd8 = 0x1a5;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        uVar5 = *puVar8;
        iVar3 = puVar8[1];
        iVar14 = puVar8[2];
        lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x50));
        if (*(longlong *)(lVar13 + 0x90) == 0) {
          local_cd8 = 0x130;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar11 = (longlong *)
                  (**(code **)(**(longlong **)(lVar13 + 0x90) + 0x98))
                            (*(longlong **)(lVar13 + 0x90),uVar5);
        if (plVar11 != (longlong *)0x0) break;
        log_InlineLogWARNING(&DAT_140783768);
        if (*(longlong *)(param_1 + 0x40) == 0) {
          local_cd8 = 0x1c;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))
                  (*(longlong **)(param_1 + 0x40),uVar5,iVar3,1);
      }
      if (iVar14 - 100U < 0x74cd) break;
      log_InlineLogWARNING(&DAT_1407836c8);
      if (*(longlong *)(param_1 + 0x40) == 0) {
        local_cd8 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))
                (*(longlong **)(param_1 + 0x40),uVar5,iVar3,1);
    }
    cVar1 = *(char *)(param_1 + 0x4e);
    cVar2 = *(char *)(param_1 + 0x4d);
    iVar12 = (int)cVar1 + (int)*(char *)(param_1 + 0x4c) + (int)cVar2;
    switch(iVar3) {
    case 0:
      if (iVar12 < 0xb) {
        iVar14 = iVar14 * 2;
        break;
      }
      goto LAB_140468630;
    case 1:
      if (iVar12 < 0xb) goto LAB_140468630;
      iVar14 = iVar14 * 2;
      break;
    case 2:
    case 3:
    case 4:
    case 5:
    case 6:
    case 7:
      if (((*(char *)(param_1 + 0x4c) != cVar2) || (cVar2 != cVar1)) || ((int)cVar1 != iVar3 + -1))
      goto LAB_140468630;
      iVar14 = iVar14 * *(int *)(&DAT_140782c20 + (longlong)iVar3 * 4);
      break;
    case 8:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
    case 0x10:
    case 0x11:
    case 0x12:
    case 0x13:
    case 0x14:
    case 0x15:
      if (iVar12 != iVar3 + -4) goto LAB_140468630;
      iVar14 = iVar14 * *(int *)(&DAT_140782c20 + (longlong)iVar3 * 4);
      break;
    default:
      if (*(longlong *)(param_1 + 0x40) == 0) {
        local_cd8 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))
                (*(longlong **)(param_1 + 0x40),uVar5,iVar3,1);
      log_InlineLogERROR(&DAT_140783740);
    }
    if (iVar14 == 0) {
LAB_140468630:
      if (*(longlong *)(param_1 + 0x40) == 0) {
        local_cd8 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      lVar13 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))
                         (*(longlong **)(param_1 + 0x40),uVar5,iVar3);
      if ((lVar13 != 0) && (iVar14 = *(int *)(lVar13 + 8), 9999 < iVar14)) {
        (**(code **)(*plVar11 + 8))(plVar11);
        (**(code **)(plVar11[2] + 0x18))(plVar11 + 2);
        local_cd8 = iVar14;
        tq::MyLogSave("gmlog/gamble","User:%s(%u) lost money %u in gamble.");
      }
      if (*(longlong *)(param_1 + 0x40) == 0) {
        local_cd8 = 0x1c;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      (**(code **)(**(longlong **)(param_1 + 0x40) + 0x30))
                (*(longlong **)(param_1 + 0x40),uVar5,iVar3,1);
      goto LAB_140468257;
    }
    if (*(longlong *)(param_1 + 0x40) == 0) {
      local_cd8 = 0x1c;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar13 = (**(code **)(**(longlong **)(param_1 + 0x40) + 0x38))
                       (*(longlong **)(param_1 + 0x40),uVar5,iVar3);
    if (lVar13 != 0) {
      *(int *)(lVar13 + 8) = iVar14;
    }
    if (iVar14 < 1) {
      local_cd8 = 0x1f7;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*plVar11 + 0x180))(plVar11,(longlong)iVar14,1);
      *(int *)(param_1 + 0x60) = *(int *)(param_1 + 0x60) - iVar14;
    }
    FUN_14037dfb0(local_cb8);
    plVar11 = plVar11 + 2;
    uVar9 = (**(code **)(*plVar11 + 0x18))(plVar11);
    iVar3 = FUN_14037e0a0(local_cb8,0x13,uVar9,iVar14);
    if (iVar3 != 0) {
      FUN_140467d50(param_1,local_cb8,0);
    }
    if (60000 < iVar14) {
      local_438 = '\0';
      memset(local_437,0,0x3ff);
      pIVar10 = theInstance();
      (**(code **)(*plVar11 + 0x18))(plVar11);
      _Format = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_WIN_BET_sd");
      local_cd8 = iVar14;
      _snprintf(&local_438,0x3ff,_Format);
      (**(code **)(*plVar11 + 0x340))(plVar11,&local_438,1);
    }
    FUN_14037e030(local_cb8);
  } while( true );
}

// ==== CNpc::helper_1404687d0  @1404687d0  [medium:callgraph-r1]  (orig: FUN_1404687d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404687d0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_140455ef0(local_448);
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x58) + 8))();
  iVar2 = FUN_140455f70(local_448,4,uVar1,0x32);
  if (iVar2 != 0) {
    FUN_140467d50(param_1,local_448,0);
  }
  FUN_140455f40(local_448);
  return;
}

// ==== CNpc::helper_140469790  @140469790  [medium:callgraph-r0]  (orig: FUN_140469790)
ulonglong FUN_140469790(int *param_1)

{
  int iVar1;
  uint uVar2;
  ulong uVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  longlong *plVar5;
  
  uVar3 = tq::TimeGet(0);
  uVar4 = (ulonglong)uVar3 * 0x10624dd3 & 0xffffffff;
  if (param_1[0x1c] + 1U <= uVar3 / 1000) {
    uVar3 = tq::TimeGet(0);
    uVar4 = (ulonglong)uVar3 * 0x10624dd3 & 0xffffffff;
    param_1[0x1c] = uVar3 / 1000;
    iVar1 = *param_1;
    if (iVar1 != 0) {
      if (iVar1 == 1) {
        param_1[0x12] = param_1[0x12] + -1;
        if (param_1[0x12] < 1) {
          uVar4 = FUN_140468050(param_1);
          *param_1 = 2;
        }
      }
      else {
        if (iVar1 != 2) {
                    /* WARNING: Could not recover jumptable at 0x0001404697fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          log_InlineLogERROR(&DAT_1407839d0);
          return extraout_RAX;
        }
        param_1[0x12] = param_1[0x12] + -1;
        uVar2 = param_1[0x12];
        uVar4 = (ulonglong)uVar2;
        if (uVar2 == 0xfffffffe) {
          uVar4 = FUN_1404680e0(param_1);
          if (param_1[0x18] != 0) {
            uVar3 = tq::TimeGet(0);
            uVar4 = (ulonglong)uVar3;
            if ((uint)param_1[0x1a] < uVar3) {
              param_1[0x19] = param_1[0x19] + param_1[0x18];
              log_InlineLogMessage(&DAT_1407839a0);
              param_1[0x18] = 0;
              uVar3 = tq::TimeGet(0);
              param_1[0x1a] = uVar3 + 1800000;
              return (ulonglong)(uVar3 + 1800000);
            }
          }
        }
        else if ((int)uVar2 < -9) {
          FUN_1404687d0(param_1);
          *param_1 = 1;
          param_1[0x12] = 0x32;
          plVar5 = (longlong *)FUN_140463d30(param_1 + 0x10);
                    /* WARNING: Could not recover jumptable at 0x000140469890. Too many branches */
                    /* WARNING: Treating indirect jump as call */
          uVar4 = (**(code **)(*plVar5 + 0x48))(plVar5);
          return uVar4;
        }
      }
    }
  }
  return uVar4;
}

// ==== CNpc::helper_14046a2a0  @14046a2a0  [medium:callgraph-r2]  (orig: FUN_14046a2a0)
void FUN_14046a2a0(__uint64 param_1)

{
  if ((DAT_140976448 & 1) == 0) {
    DAT_140976448 = DAT_140976448 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976440,"CNpcScene");
    atexit((_func_5014 *)&LAB_1406d6e50);
  }
                    /* WARNING: Could not recover jumptable at 0x00014046a2f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976440,param_1);
  return;
}

// ==== CNpc::helper_14046acb0  @14046acb0  [medium:callgraph-r1]  (orig: FUN_14046acb0)
void FUN_14046acb0(__uint64 param_1)

{
  if ((DAT_140976458 & 1) == 0) {
    DAT_140976458 = DAT_140976458 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976450,"CNpcShop");
    atexit((_func_5014 *)&LAB_1406d6e60);
  }
                    /* WARNING: Could not recover jumptable at 0x00014046ad05. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976450,param_1);
  return;
}

// ==== CNpc::helper_14046cb20  @14046cb20  [medium:callgraph-r3]  (orig: FUN_14046cb20)
undefined8 * FUN_14046cb20(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_14046be90(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_14046be90(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_14046be90(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x25) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x25);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x25);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x25);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x25) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x25) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x25) != '\0') {
              FUN_14046be90(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_14046be90(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x25) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x25) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x25);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x25);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x25);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x25);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x25) != '\0') {
              FUN_14046be90(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_14046be90(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_14046c410(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CNpc::helper_14046ce40  @14046ce40  [medium:callgraph-r2]  (orig: FUN_14046ce40)
undefined8 * FUN_14046ce40(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = IGameObjSet<CItemType>::vftable;
  *param_1 = CGameObjSet<CItemType>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CNpc::helper_14046de30  @14046de30  [medium:callgraph-r2]  (orig: FUN_14046de30)
longlong FUN_14046de30(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  uint local_58;
  undefined8 local_54;
  undefined8 local_48;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x25) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x25) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  local_48 = plVar5;
  uStack_40 = puVar4;
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_58 = *param_2;
    local_38 = (undefined4)local_48;
    uStack_34 = local_48._4_4_;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    local_54 = 0;
    plVar3 = (longlong *)FUN_14046cb20(param_1,local_28,&local_38,&local_58);
    plVar5 = (longlong *)*plVar3;
    puVar4 = (undefined8 *)plVar3[1];
    local_48 = plVar5;
    uStack_40 = puVar4;
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar5;
  }
  if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return (longlong)puVar4 + 0x1c;
}

// ==== CNpc::helper_14046e5f0  @14046e5f0  [medium:callgraph-r1]  (orig: FUN_14046e5f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14046e5f0(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined7 uVar10;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar11;
  undefined1 auStack_478 [32];
  undefined4 local_458;
  void *local_448;
  undefined8 local_440;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  *(undefined4 *)(param_1 + 0x118) = param_2;
  *(undefined8 *)(param_1 + 0x110) = param_3;
  local_448 = operator_new(0x40);
  if (local_448 == (void *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_14046ce40(local_448);
  }
  *(undefined8 *)(param_1 + 8) = uVar3;
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  _snprintf(&local_438,0x3ff,"SELECT * FROM cq_goods WHERE ownerid=%u");
  FUN_140008520(*(undefined4 *)(param_1 + 0x118));
  plVar4 = (longlong *)InstanceGet();
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,&local_438,2);
  if (plVar4 == (longlong *)0x0) {
    uVar10 = 0;
  }
  else {
    iVar11 = 0;
    iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
    if (0 < iVar1) {
      do {
        (**(code **)(*plVar4 + 0x30))(plVar4,(longlong)iVar11);
        plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,2);
        uVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
        local_448 = (void *)CONCAT44(local_448._4_4_,uVar2);
        plVar5 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          local_458 = 0x3c0;
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar5 = (longlong *)0x0;
        }
        lVar6 = (**(code **)(*plVar5 + 0x70))(plVar5,uVar2);
        if (lVar6 == 0) {
LAB_14046e876:
          log_InlineLogDBERROR(&DAT_1407842a8);
        }
        else {
          plVar5 = (longlong *)
                   (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))(*(longlong **)(lVar6 + 8),0);
          uVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
          lVar7 = (**(code **)(**(longlong **)(param_1 + 8) + 0x30))
                            (*(longlong **)(param_1 + 8),uVar2);
          if (lVar7 != 0) goto LAB_14046e876;
          (**(code **)(**(longlong **)(param_1 + 8) + 0x20))(*(longlong **)(param_1 + 8),lVar6);
          plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,3);
          puVar8 = (undefined4 *)FUN_140070860(param_1 + 0x10,&local_448);
          uVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
          *puVar8 = uVar2;
          plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,4);
          iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
          if (0 < iVar1) {
            piVar9 = (int *)FUN_14046de30(param_1 + 0x50,&local_448);
            *piVar9 = iVar1;
            plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,5);
            uVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
            lVar6 = FUN_14046de30(param_1 + 0x50,&local_448);
            *(undefined4 *)(lVar6 + 4) = uVar2;
          }
          plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,6);
          iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
          if (0 < iVar1) {
            piVar9 = (int *)FUN_140070860(param_1 + 0x90,&local_448);
            *piVar9 = iVar1;
          }
          plVar5 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,7);
          iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
          if (0 < iVar1) {
            piVar9 = (int *)FUN_140070860(param_1 + 0xd0,&local_448);
            *piVar9 = iVar1;
          }
        }
        iVar11 = iVar11 + 1;
        iVar1 = (**(code **)(*plVar4 + 0x40))(plVar4);
      } while (iVar11 < iVar1);
    }
    uVar3 = (**(code **)*plVar4)(plVar4);
    uVar10 = (undefined7)((ulonglong)uVar3 >> 8);
  }
  return CONCAT71(uVar10,1);
}

// ==== CNpc::helper_14046f080  @14046f080  [medium:callgraph-r1]  (orig: FUN_14046f080)
void FUN_14046f080(__uint64 param_1)

{
  if ((DAT_140976468 & 1) == 0) {
    DAT_140976468 = DAT_140976468 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976460,"CNpcTask");
    atexit((_func_5014 *)&LAB_1406d6e70);
  }
                    /* WARNING: Could not recover jumptable at 0x00014046f0d5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140976460,param_1);
  return;
}

// ==== CNpc::helper_14046f1f0  @14046f1f0  [medium:callgraph-r0]  (orig: FUN_14046f1f0)
void FUN_14046f1f0(longlong param_1,__int64 param_2)

{
  longlong *plVar1;
  longlong lVar2;
  bool bVar3;
  int iVar4;
  ulong uVar5;
  uint uVar6;
  ulong uVar7;
  ulonglong uVar8;
  undefined8 uVar9;
  ulonglong uVar10;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 0x60);
  uVar8 = (**(code **)(*plVar1 + 0x10))(plVar1,0x1b);
  if ((uVar8 & 0x40) != 0) {
    if (*(char *)(param_1 + 8) == '\0') {
      uVar8 = 0;
      iVar4 = 0;
      if (*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 0x60);
        iVar4 = (**(code **)(*plVar1 + 0x10))(plVar1,0x15);
      }
      bVar3 = tq::IsActiveTime(param_2,(iVar4 / 1000) * 1000);
      if (bVar3) {
        *(undefined1 *)(param_1 + 8) = 1;
        uVar5 = tq::TimeGet(0);
        lVar2 = *(longlong *)(param_1 + 0x18);
        uVar10 = uVar8;
        if (lVar2 != 0) {
          uVar10 = lVar2 + 0x10;
        }
        if (*(longlong *)(lVar2 + 0x60) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar6 = (**(code **)(**(longlong **)(lVar2 + 0x60) + 0x10))
                            (*(longlong **)(lVar2 + 0x60),0x17);
          uVar8 = (ulonglong)uVar6;
        }
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
        uVar9 = FUN_140087730(uVar9);
        FUN_140145f60(uVar9,uVar8,0,uVar10,0,0);
        uVar7 = tq::TimeGet(0);
        if (1000 < uVar7 - uVar5) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
      }
    }
    else {
      if (*(longlong *)(*(longlong *)(param_1 + 0x18) + 0x60) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        iVar4 = 0;
      }
      else {
        plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 0x60);
        iVar4 = (**(code **)(*plVar1 + 0x10))(plVar1,0x15);
      }
      bVar3 = tq::IsActiveTime(param_2,(iVar4 / 1000) * 1000);
      if (!bVar3) {
        *(undefined1 *)(param_1 + 8) = 0;
        return;
      }
    }
  }
  return;
}

// ==== CNpc::helper_14046f6a0  @14046f6a0  [medium:callgraph-r2]  (orig: FUN_14046f6a0)
undefined8 * FUN_14046f6a0(undefined8 *param_1,undefined1 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  *param_1 = ISingleObjSet2<CConstGameData<&char*_szTaskTable,&char*_szTaskTableID>_>::vftable;
  *param_1 = CSingleObjSet2<CConstGameData<&char*_szTaskTable,&char*_szTaskTableID>_>::vftable;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 1);
    plVar2 = plVar1;
  }
  param_1[1] = plVar2;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  *(undefined1 *)(param_1 + 7) = param_2;
  return param_1;
}

// ==== CNpc::helper_140470a90  @140470a90  [medium:callgraph-r1]  (orig: FUN_140470a90)
undefined8 FUN_140470a90(longlong param_1,undefined4 param_2,undefined8 param_3,longlong *param_4)

{
  int iVar1;
  int iVar2;
  undefined8 uVar3;
  void *pvVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  
  if (param_4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x20) = param_2;
    *(undefined8 *)(param_1 + 0x18) = param_3;
    pvVar4 = operator_new(0x40);
    if (pvVar4 == (void *)0x0) {
      lVar5 = 0;
    }
    else {
      lVar5 = FUN_14046f6a0(pvVar4,0);
    }
    *(longlong *)(param_1 + 0x10) = lVar5;
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = 0;
    }
    else {
      iVar1 = (**(code **)(*param_4 + 0x10))(param_4,4);
      if (iVar1 != 9) {
        iVar1 = 0;
        do {
          iVar2 = (**(code **)(*param_4 + 0x10))(param_4,iVar1 + 10);
          if (iVar2 == 0) break;
          plVar7 = DAT_140975b80;
          if (DAT_140975b80 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar7 = (longlong *)0x0;
          }
          lVar5 = (**(code **)(*plVar7 + 0x40))(plVar7,iVar2);
          if (lVar5 == 0) {
            FUN_140087360(*(undefined8 *)(param_1 + 0x18));
            log_InlineLogDBERROR("table:cq_npc, Can\'t find task[%u] of npc[%d].");
          }
          else {
            lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))
                              (*(longlong **)(param_1 + 0x10),iVar2);
            if (lVar6 == 0) {
              (**(code **)(**(longlong **)(param_1 + 0x10) + 0x28))
                        (*(longlong **)(param_1 + 0x10),lVar5);
            }
            else {
              FUN_140087360(*(undefined8 *)(param_1 + 0x18));
              log_InlineLogDBERROR("table:cq_npc, Duplicate task[%u] of npc[%d].");
            }
          }
          iVar1 = iVar1 + 1;
        } while (iVar1 < 8);
      }
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CNpc::helper_140470f70  @140470f70  [medium:callgraph-r0]  (orig: FUN_140470f70)
undefined8 * FUN_140470f70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = texasholdem::CMsgTexasHoldEmNpcInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CNpc::helper_140470fc0  @140470fc0  [medium:callgraph-r0]  (orig: FUN_140470fc0)
void FUN_140470fc0(undefined8 *param_1)

{
  *param_1 = texasholdem::CMsgTexasHoldEmNpcInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CNpc::helper_140471550  @140471550  [medium:callgraph-r0]  (orig: FUN_140471550)
BADSPACEBASE * FUN_140471550(longlong param_1,longlong *param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  undefined1 uVar6;
  undefined2 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  undefined4 *puVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *local_60 [3];
  undefined4 *local_48;
  undefined4 *local_40;
  undefined8 local_38;
  
  if (param_2 != (longlong *)0x0) {
    uVar8 = (**(code **)(*param_2 + 8))(param_2);
    **(undefined4 **)(param_1 + 0x428) = uVar8;
    uVar7 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],4);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x12) = uVar7;
    uVar7 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x1b);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar7;
    uVar7 = (**(code **)(param_2[2] + 0x30))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = uVar7;
    uVar7 = (**(code **)(param_2[2] + 0x40))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = uVar7;
    uVar7 = (**(code **)(param_2[2] + 0x48))(param_2 + 2);
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = uVar7;
    uVar8 = (**(code **)(param_2[2] + 0x80))(param_2 + 2);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = uVar8;
    uVar8 = (**(code **)(param_2[2] + 0x78))(param_2 + 2);
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = uVar8;
    plVar14 = (longlong *)0x0;
    uVar8 = 0;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar9 = uVar8;
    }
    else {
      uVar9 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x12);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x16) = uVar9;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar9 = uVar8;
    }
    else {
      uVar9 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x13);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1a) = uVar9;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar9 = uVar8;
    }
    else {
      uVar9 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x14);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1e) = uVar9;
    if (param_2[0xc] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar8 = (**(code **)(*(longlong *)param_2[0xc] + 0x10))((longlong *)param_2[0xc],0x15);
    }
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x22) = uVar8;
    if (param_3 != 0) {
      uVar6 = FUN_1403bc2a0(param_3);
      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x26) = uVar6;
      uVar10 = FUN_1403bc2b0(param_3);
      *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 0x27) = uVar10;
      plVar11 = operator_new(8);
      local_60[0] = plVar14;
      if (plVar11 != (longlong *)0x0) {
        *plVar11 = (longlong)local_60;
        local_60[0] = plVar11;
      }
      local_48 = (undefined4 *)0x0;
      local_40 = (undefined4 *)0x0;
      local_38 = 0;
      FUN_1403d8d50(param_3,local_60);
      puVar12 = local_48;
      *(char *)(*(longlong *)(param_1 + 0x428) + 0x2f) =
           (char)(((longlong)local_40 - (longlong)local_48) / 6);
      plVar11 = local_60[0];
      if (local_40 < local_48) {
        _invalid_parameter_noinfo();
        plVar11 = local_60[0];
      }
      while( true ) {
        puVar5 = local_40;
        if (local_40 < local_48) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == (longlong *)0x0) || (plVar11 != local_60[0])) {
          _invalid_parameter_noinfo();
        }
        puVar4 = local_48;
        if (puVar12 == puVar5) break;
        if (local_40 < local_48) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == (longlong *)0x0) || (plVar11 != local_60[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar13 = plVar14;
        }
        else {
          plVar13 = (longlong *)*plVar11;
        }
        if ((undefined4 *)plVar13[4] <= puVar12) {
          _invalid_parameter_noinfo();
        }
        lVar1 = (((longlong)puVar12 - (longlong)puVar4) / 6) * 3 + 0x18;
        lVar2 = *(longlong *)(param_1 + 0x428);
        *(undefined4 *)(lVar2 + lVar1 * 2) = *puVar12;
        *(undefined2 *)(lVar2 + 4 + lVar1 * 2) = *(undefined2 *)(puVar12 + 1);
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar13 = plVar14;
        }
        else {
          plVar13 = (longlong *)*plVar11;
        }
        if ((undefined4 *)plVar13[4] <= puVar12) {
          _invalid_parameter_noinfo();
        }
        puVar12 = (undefined4 *)((longlong)puVar12 + 6);
      }
      if (local_48 != (undefined4 *)0x0) {
        operator_delete(local_48);
      }
      local_48 = (undefined4 *)0x0;
      local_40 = (undefined4 *)0x0;
      local_38 = 0;
      operator_delete(local_60[0]);
    }
    *(undefined4 *)(param_1 + 8) = 0x87c;
    iVar3 = ((uint)*(byte *)(*(longlong *)(param_1 + 0x428) + 0x2f) * 3 + 0x18) * 2;
    *(int *)(param_1 + 0xc) = iVar3;
    register0x00000020 = (BADSPACEBASE *)CONCAT71((uint7)(uint3)((uint)iVar3 >> 8),1);
  }
  return register0x00000020;
}

// ==== CNpc::helper_1404dc8d0  @1404dc8d0  [medium:callgraph-r2]  (orig: FUN_1404dc8d0)
void FUN_1404dc8d0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CNpc::helper_1404dd170  @1404dd170  [medium:callgraph-r3]  (orig: FUN_1404dd170)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404dd170(longlong param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  char cVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  undefined1 auStack_508 [32];
  undefined4 local_4e8;
  undefined8 local_4d8;
  undefined8 uStack_4d0;
  longlong *local_4c8 [3];
  undefined8 *local_4b0;
  undefined8 *local_4a8;
  longlong local_4a0;
  longlong *local_498 [2];
  undefined4 local_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_498[0] = operator_new(8);
  plVar9 = (longlong *)0x0;
  local_4c8[0] = plVar9;
  if (local_498[0] != (longlong *)0x0) {
    *local_498[0] = (longlong)local_4c8;
    local_4c8[0] = local_498[0];
  }
  local_4b0 = (undefined8 *)0x0;
  local_4a8 = (undefined8 *)0x0;
  local_4a0 = 0;
  puVar11 = (undefined8 *)**(undefined8 **)(param_1 + 0x38);
  plVar3 = *(longlong **)(param_1 + 8);
  local_4d8 = plVar3;
  uStack_4d0 = puVar11;
  do {
    puVar4 = *(undefined8 **)(param_1 + 0x38);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (puVar11 == puVar4) {
      plVar9 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
      cVar6 = *(char *)((longlong)plVar9 + 0x1d);
      while (cVar6 == '\0') {
        FUN_1400098c0(param_1 + 8,plVar9[2]);
        plVar3 = (longlong *)*plVar9;
        operator_delete(plVar9);
        plVar9 = plVar3;
        cVar6 = *(char *)((longlong)plVar3 + 0x1d);
      }
      *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
      *(undefined8 *)(param_1 + 0x40) = 0;
      *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
      *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
      if ((longlong)local_4a8 - (longlong)local_4b0 >> 2 != 0) {
        FUN_1404500a0(local_468);
        cVar6 = FUN_140450150(local_468,9);
        if (cVar6 != '\0') {
          plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
          (**(code **)(*plVar9 + 0x40))(plVar9,local_4c8,local_468);
        }
        FUN_1404500f0(local_468);
      }
      if (local_4b0 != (undefined8 *)0x0) {
        operator_delete(local_4b0);
      }
      local_4b0 = (undefined8 *)0x0;
      local_4a8 = (undefined8 *)0x0;
      local_4a0 = 0;
      operator_delete(local_4c8[0]);
      return;
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar10 = plVar9;
    }
    else {
      plVar10 = (longlong *)*plVar3;
    }
    if (puVar11 == (undefined8 *)plVar10[6]) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(undefined4 *)(puVar11 + 3);
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
    plVar10 = *(longlong **)(lVar7 + 0x1d8);
    if (*(longlong **)(lVar7 + 0x1d8) == (longlong *)0x0) {
      local_4e8 = 0x15f;
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar10 = plVar9;
    }
    FUN_140207120(plVar10,uVar2,1);
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x4c));
    if (*(longlong *)(lVar7 + 0x90) == 0) {
      local_4e8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar7 = (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x98))(*(longlong **)(lVar7 + 0x90),uVar2);
    puVar4 = local_4a8;
    if (lVar7 != 0) {
      local_498[0] = (longlong *)CONCAT44(local_498[0]._4_4_,*(undefined4 *)(lVar7 + 0x122c));
      plVar10 = plVar9;
      if (local_4b0 != (undefined8 *)0x0) {
        plVar10 = (longlong *)(local_4a0 - (longlong)local_4b0 >> 2);
      }
      if ((longlong *)((longlong)local_4a8 - (longlong)local_4b0 >> 2) < plVar10) {
        *(undefined4 *)local_4a8 = *(undefined4 *)(lVar7 + 0x122c);
        local_4a8 = (undefined8 *)((longlong)local_4a8 + 4);
      }
      else {
        if (local_4a8 < local_4b0) {
          _invalid_parameter_noinfo();
        }
        puVar5 = local_4b0;
        plVar10 = local_4c8[0];
        local_4d8 = local_4c8[0];
        uStack_4d0 = puVar4;
        plVar8 = plVar9;
        if (((longlong)local_4a8 - (longlong)local_4b0 & 0xfffffffffffffffcU) != 0) {
          if (local_4a8 < local_4b0) {
            _invalid_parameter_noinfo();
          }
          if ((plVar10 == (longlong *)0x0) || (plVar10 != local_4c8[0])) {
            _invalid_parameter_noinfo();
          }
          plVar8 = (longlong *)((longlong)puVar4 - (longlong)puVar5 >> 2);
        }
        local_488 = (undefined4)local_4d8;
        uStack_484 = local_4d8._4_4_;
        uStack_480 = (undefined4)uStack_4d0;
        uStack_47c = uStack_4d0._4_4_;
        FUN_140036c20(local_4c8,&local_488,1,local_498);
        puVar4 = local_4b0;
        if (local_4a8 < local_4b0) {
          _invalid_parameter_noinfo();
        }
        plVar10 = local_4c8[0];
        if (local_4c8[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar12 = plVar9;
        }
        else {
          plVar12 = (longlong *)*local_4c8[0];
        }
        puVar1 = (undefined4 *)((longlong)puVar4 + (longlong)plVar8 * 4);
        if (puVar1 <= (undefined4 *)plVar12[4]) {
          plVar8 = plVar9;
          if (plVar10 != (longlong *)0x0) {
            plVar8 = (longlong *)*plVar10;
          }
          if ((undefined4 *)plVar8[3] <= puVar1) goto LAB_1404dd428;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_1404dd428:
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar11 + 0x1d) == '\0') {
      puVar4 = (undefined8 *)puVar11[2];
      if (*(char *)((longlong)puVar4 + 0x1d) == '\0') {
        cVar6 = *(char *)((longlong)*puVar4 + 0x1d);
        puVar11 = puVar4;
        puVar4 = (undefined8 *)*puVar4;
        while (cVar6 == '\0') {
          cVar6 = *(char *)((longlong)*puVar4 + 0x1d);
          puVar11 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
        }
      }
      else {
        cVar6 = *(char *)((longlong)puVar11[1] + 0x1d);
        puVar5 = (undefined8 *)puVar11[1];
        puVar4 = puVar11;
        while ((puVar11 = puVar5, cVar6 == '\0' && (puVar4 == (undefined8 *)puVar11[2]))) {
          cVar6 = *(char *)((longlong)puVar11[1] + 0x1d);
          puVar5 = (undefined8 *)puVar11[1];
          puVar4 = puVar11;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CNpc::helper_1404ddd70  @1404ddd70  [medium:callgraph-r2]  (orig: FUN_1404ddd70)
undefined8 FUN_1404ddd70(longlong param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 0xc) = 1;
  *(undefined4 *)(param_1 + 8) = 0xaf1;
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

