// ==== CMsgCrossFlagWarMerit::helper_140005790  @140005790  [medium:callgraph-r0]  (orig: FUN_140005790)
void FUN_140005790(longlong param_1)

{
  tm *ptVar1;
  __time32_t local_res10 [6];
  
  _time32(local_res10);
  ptVar1 = _localtime32(local_res10);
  if (ptVar1 != (tm *)0x0) {
    *(int *)(param_1 + 8) = ptVar1->tm_wday;
    *(int *)(param_1 + 0xc) = ptVar1->tm_hour;
    *(int *)(param_1 + 0x10) = ptVar1->tm_min;
  }
  return;
}

// ==== CMsgCrossFlagWarMerit::helper_1400057d0  @1400057d0  [medium:callgraph-r0]  (orig: FUN_1400057d0)
void FUN_1400057d0(longlong param_1)

{
  tm *ptVar1;
  int local_res10 [6];
  
  _time32(local_res10);
  ptVar1 = _localtime32(local_res10);
  if (ptVar1 != (tm *)0x0) {
    local_res10[0] = local_res10[0] - *(int *)(param_1 + 0x14);
    ptVar1 = _localtime32(local_res10);
    *(int *)(param_1 + 0x10) = ptVar1->tm_min;
    *(int *)(param_1 + 0xc) = ptVar1->tm_hour;
    *(int *)(param_1 + 8) = ptVar1->tm_wday;
  }
  return;
}

// ==== CMsgCrossFlagWarMerit::ctor_or_dtor  @140449990  [high:vtable-assign]  (orig: FUN_140449990)
undefined8 * FUN_140449990(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCrossFlagWarMerit::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgCrossFlagWarMerit::ctor_or_dtor  @1404499e0  [high:vtable-assign]  (orig: FUN_1404499e0)
void FUN_1404499e0(undefined8 *param_1)

{
  *param_1 = CMsgCrossFlagWarMerit::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgCrossFlagWarMerit::vfunc_5  @140449ad0  [high:rtti-vtable]  (orig: FUN_140449ad0)
bool FUN_140449ad0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c8;
    }
  }
  return false;
}

// ==== CMsgCrossFlagWarMerit::ctor_or_dtor  @140449c40  [high:vtable-assign]  (orig: FUN_140449c40)
undefined8 * FUN_140449c40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCrossFlagWarMerit::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgCrossFlagWarMerit::vfunc_3  @140449c90  [high:rtti-vtable]  (orig: FUN_140449c90)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140449c90(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  int iVar7;
  int local_res18 [2];
  int local_res20;
  
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  cVar1 = FUN_14008b330(uVar3);
  if (cVar1 == '\0') {
    if (*(longlong *)(param_1 + 0x428) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgcrossflagwarmerit.cpp"
                        );
    }
    else {
      switch(**(undefined2 **)(param_1 + 0x428)) {
      case 0:
        if (*(int *)(*(undefined2 **)(param_1 + 0x428) + 2) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECK","m_pInfo->idSyn",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgcrossflagwarmerit.cpp"
                            );
        }
        else {
          plVar4 = (longlong *)FUN_140087ed0();
          cVar1 = (**(code **)(*plVar4 + 0x380))
                            (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          if (cVar1 == '\0') {
            log_InlineLogERROR("CMsgFrontierFlagWarMerit::Process[CROSS_FLAG_WAR_USER_MERIT], Syn[%u] not found!"
                               ,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
          }
          else {
            for (iVar7 = 0; lVar5 = *(longlong *)(param_1 + 0x428), iVar7 < *(int *)(lVar5 + 0x10);
                iVar7 = iVar7 + 1) {
              lVar6 = ((longlong)iVar7 + 1) * 0x1c + lVar5;
              tq::SysLogSave("crossmerit","Syn[%u]\tUser[%u]\tMerit[%d]",*(undefined4 *)(lVar5 + 4),
                             *(undefined4 *)(lVar6 + 4));
              plVar4 = (longlong *)FUN_140087ed0();
              (**(code **)(*plVar4 + 0x388))
                        (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                         *(undefined4 *)(lVar6 + 4),*(undefined4 *)(lVar6 + 8));
            }
          }
        }
        break;
      case 1:
        plVar4 = (longlong *)CurrentInstanceGet();
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,0x1c);
        if (plVar4 != (longlong *)0x0) {
          (**(code **)(*plVar4 + 0x78))(plVar4,0);
        }
        plVar4 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar4 + 0x390))(plVar4);
        plVar4 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar4 + 0x398))(plVar4,3);
        plVar4 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar4 + 0x3b8))(plVar4);
        break;
      case 2:
        local_res18[0] = 0;
        local_res20 = 0;
        plVar4 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar4 + 0x3c8))
                  (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),3,local_res18);
        *(int *)(*(longlong *)(param_1 + 0x428) + 0xc) = local_res18[0];
        *(int *)(*(longlong *)(param_1 + 0x428) + 8) = local_res20;
        if ((local_res18[0] != 0) || (local_res20 != 0)) {
          uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar2 = FUN_14008b340(uVar3);
          uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          cVar1 = FUN_1400b3d90(uVar3,uVar2);
          if (cVar1 == '\0') {
            plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            (**(code **)(*plVar4 + 8))(plVar4,param_1);
          }
          else {
            plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            (**(code **)(*plVar4 + 0x18))(plVar4,*(undefined4 *)(param_1 + 0x41c),param_1);
          }
        }
        break;
      default:
        log_InlineLogERROR("CMsgFrontierFlagWarMerit::Process. unknown type [%u]");
        break;
      case 5:
        plVar4 = (longlong *)FUN_140087ed0();
        (**(code **)(*plVar4 + 0x3b0))(plVar4);
        break;
      case 6:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x148) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pCrossConfig",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar3 = 0;
        }
        else {
          uVar3 = *(undefined8 *)(lVar5 + 0x148);
        }
        FUN_140005790(uVar3);
        break;
      case 7:
        lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar5 + 0x148) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pCrossConfig",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                            );
          uVar3 = 0;
        }
        else {
          uVar3 = *(undefined8 *)(lVar5 + 0x148);
        }
        FUN_1400057d0(uVar3);
      }
    }
  }
  return;
}

