// ==== CCrossMsgGongFuSummaryInfo::helper_1401e85c0  @1401e85c0  [medium:callgraph-r0]  (orig: FUN_1401e85c0)
void FUN_1401e85c0(longlong param_1,longlong *param_2,undefined8 param_3,undefined1 param_4,
                  undefined4 param_5,undefined8 param_6,undefined4 param_7,undefined8 param_8,
                  undefined1 *param_9,undefined1 param_10,undefined8 param_11)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined4 local_50 [2];
  longlong local_48;
  undefined1 local_40 [24];
  
  plVar3 = (longlong *)InstanceGet();
  plVar4 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_jianghu_player");
  if (plVar4 != (longlong *)0x0) {
    plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,1);
    lVar6 = *plVar5;
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    (**(code **)(lVar6 + 0xb8))(plVar5,uVar2);
    plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,3);
    (**(code **)(*plVar5 + 0x80))(plVar5,param_3);
    plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,5);
    (**(code **)(*plVar5 + 0xd8))(plVar5,param_4);
    plVar5 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,6);
    (**(code **)(*plVar5 + 0xa8))(plVar5,param_5);
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
    lVar6 = FUN_1403fdd90(*(undefined4 *)(param_1 + 8),uVar2,plVar4,1);
    if (lVar6 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      (**(code **)*plVar4)(plVar4,0);
    }
    else {
      cVar1 = FUN_1403fe5c0(lVar6,1);
      if (cVar1 == '\0') {
        FUN_1403fdeb0(lVar6);
      }
      else {
        FUN_1403fda80(lVar6,param_7);
        local_50[0] = (**(code **)(*param_2 + 8))(param_2);
        local_48 = lVar6;
        FUN_1401e2940(param_1 + 0x90,local_40,local_50);
        plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_jianghu_caltivate_times");
        if (plVar3 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
          lVar6 = *plVar4;
          uVar2 = (**(code **)(*param_2 + 8))(param_2);
          (**(code **)(lVar6 + 0xb8))(plVar4,uVar2);
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,2);
          (**(code **)(*plVar4 + 0xd8))(plVar4,*param_9);
          plVar4 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,3);
          (**(code **)(*plVar4 + 0xa8))(plVar4,*(undefined4 *)(param_9 + 1));
          uVar2 = (**(code **)(*param_2 + 8))(param_2);
          lVar6 = FUN_1403fec80(uVar2,plVar3,1);
          if (lVar6 == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            (**(code **)*plVar3)(plVar3,0);
          }
          else {
            local_50[0] = (**(code **)(*param_2 + 8))(param_2);
            local_48 = lVar6;
            FUN_1401e2f80(param_1 + 0xd0,local_40,local_50);
            uVar2 = (**(code **)(*param_2 + 8))(param_2);
            lVar6 = FUN_140400820(*(undefined4 *)(param_1 + 8),uVar2,1);
            if (lVar6 == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              cVar1 = FUN_1403ffb20(lVar6,param_10,param_11);
              if (cVar1 == '\0') {
                FUN_1403ff130(lVar6);
              }
              else {
                local_50[0] = (**(code **)(*param_2 + 8))(param_2);
                local_48 = lVar6;
                FUN_1401e35c0(param_1 + 0x150,local_40,local_50);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CCrossMsgGongFuSummaryInfo::helper_1403fda80  @1403fda80  [medium:callgraph-r1]  (orig: FUN_1403fda80)
void FUN_1403fda80(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x18) = param_2;
  return;
}

// ==== CCrossMsgGongFuSummaryInfo::helper_1403ffb20  @1403ffb20  [medium:callgraph-r1]  (orig: FUN_1403ffb20)
undefined8 FUN_1403ffb20(longlong param_1,byte param_2,undefined8 *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  longlong lVar4;
  ulonglong uVar5;
  uint uVar6;
  char local_68 [8];
  longlong *local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined2 local_48;
  undefined1 local_40 [24];
  
  if (*(char *)(param_1 + 0x54) != '\0') {
    uVar5 = (ulonglong)param_2;
    cVar3 = '\x01';
    if (param_2 != 0) {
      do {
        local_58 = *param_3;
        uVar6 = 1;
        local_50 = param_3[1];
        local_48 = *(undefined2 *)(param_3 + 2);
        plVar1 = (longlong *)InstanceGet();
        plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"cq_jianghu_player_power");
        if (plVar1 == (longlong *)0x0) {
          log_InlineLogOSERROR
                    ("LoadOSUserPowerData(),user:%u, gongfu power(level:%u) error,at %s, %d");
        }
        else {
          plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,1);
          (**(code **)(*plVar2 + 0xb8))(plVar2,*(undefined4 *)(param_1 + 0xc));
          plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
          (**(code **)(*plVar2 + 0xd8))(plVar2,cVar3);
          lVar4 = 0;
          do {
            plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,uVar6 * 2 + 1);
            (**(code **)(*plVar2 + 0xd8))(plVar2,*(undefined1 *)((longlong)&local_58 + lVar4 * 2));
            plVar2 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,uVar6 * 2 + 2);
            (**(code **)(*plVar2 + 0xd8))
                      (plVar2,*(undefined1 *)((longlong)&local_58 + lVar4 * 2 + 1));
            lVar4 = lVar4 + 1;
            uVar6 = (uint)(byte)((char)uVar6 + 1);
          } while (lVar4 < 9);
          local_68[0] = cVar3;
          local_60 = plVar1;
          FUN_140156b30(param_1 + 0x10,local_40,local_68);
          cVar3 = cVar3 + '\x01';
        }
        param_3 = (undefined8 *)((longlong)param_3 + 0x12);
        uVar5 = uVar5 - 1;
      } while (uVar5 != 0);
    }
    return 1;
  }
  return 0;
}

// ==== CCrossMsgGongFuSummaryInfo::ctor_or_dtor  @140401a90  [high:vtable-assign]  (orig: FUN_140401a90)
undefined8 * FUN_140401a90(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgGongFuSummaryInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgGongFuSummaryInfo::ctor_or_dtor  @140401ae0  [high:vtable-assign]  (orig: FUN_140401ae0)
void FUN_140401ae0(undefined8 *param_1)

{
  *param_1 = CCrossMsgGongFuSummaryInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgGongFuSummaryInfo::vfunc_5  @140401b10  [high:rtti-vtable]  (orig: FUN_140401b10)
bool FUN_140401b10(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c54;
    }
  }
  return false;
}

// ==== CCrossMsgGongFuSummaryInfo::ctor_or_dtor  @140401d70  [high:vtable-assign]  (orig: FUN_140401d70)
undefined8 * FUN_140401d70(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgGongFuSummaryInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgGongFuSummaryInfo::vfunc_3  @140401dc0  [high:rtti-vtable]  (orig: FUN_140401dc0)
void FUN_140401dc0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_res8;
  undefined1 local_resc;
  
  uVar1 = *(undefined4 *)(param_1 + 0x420);
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = FUN_1402af110(*(undefined8 *)(lVar4 + 0x90),uVar2,uVar1);
  if (lVar4 == 0) {
    log_InlineLogOSERROR
              (
              "CCrossMsgGongFuSummaryInfo::Process UserManager GetCreatedOSUser failed. server id:%u, os user id:%u."
              );
  }
  else {
    local_res8 = *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x2b);
    local_resc = *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x2f);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar5 = *(longlong *)(lVar5 + 0x1c0);
    if (lVar5 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar5 = 0;
    }
    lVar3 = *(longlong *)(param_1 + 0x428);
    FUN_1401e85c0(lVar5,lVar4,lVar3,*(undefined1 *)(lVar3 + 0x11),*(undefined4 *)(lVar3 + 0x13),
                  *(undefined8 *)(lVar3 + 0x17),*(undefined4 *)(lVar3 + 0x1f),
                  *(undefined8 *)(lVar3 + 0x23),&local_res8,*(undefined1 *)(lVar3 + 0x10),
                  lVar3 + 0x30);
  }
  return;
}

