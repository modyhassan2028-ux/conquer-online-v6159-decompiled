// ==== CMsgNpcPath::helper_1402a4450  @1402a4450  [medium:callgraph-r2]  (orig: FUN_1402a4450)
void FUN_1402a4450(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x29) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMsgNpcPath::helper_1402a4570  @1402a4570  [medium:callgraph-r2]  (orig: FUN_1402a4570)
void FUN_1402a4570(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x29) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x29);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x29);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x29);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x29);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001402a4594. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgNpcPath::helper_1402a4820  @1402a4820  [medium:callgraph-r2]  (orig: FUN_1402a4820)
void FUN_1402a4820(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x29) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMsgNpcPath::helper_1402a5870  @1402a5870  [medium:callgraph-r1]  (orig: FUN_1402a5870)
undefined8 * FUN_1402a5870(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x29) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402a4570(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x29) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 5;
        plVar8 = plVar8 + 5;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1402a5a5c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x29);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x29);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x29);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1402a5a5c:
  if ((char)plVar2[5] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[5] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402a4820(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(*plVar9 + 0x28) != '\x01') || (*(char *)(plVar9[2] + 0x28) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x28) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402a4450(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(plVar9[2] + 0x28) = 1;
              FUN_1402a4820(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        else {
          if ((char)plVar9[5] == '\0') {
            *(undefined1 *)(plVar9 + 5) = 1;
            *(undefined1 *)(plVar8 + 5) = 0;
            FUN_1402a4450(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
            if ((*(char *)(plVar9[2] + 0x28) != '\x01') || (*(char *)(*plVar9 + 0x28) != '\x01')) {
              if (*(char *)(*plVar9 + 0x28) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x28) = 1;
                *(undefined1 *)(plVar9 + 5) = 0;
                FUN_1402a4820(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 5) = (char)plVar8[5];
              *(undefined1 *)(plVar8 + 5) = 1;
              *(undefined1 *)(*plVar9 + 0x28) = 1;
              FUN_1402a4450(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 5) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 5) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMsgNpcPath::helper_1402a6490  @1402a6490  [medium:callgraph-r0]  (orig: FUN_1402a6490)
undefined8 FUN_1402a6490(longlong *param_1,uint param_2,undefined1 param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined4 local_res8 [2];
  longlong *local_58;
  longlong lStack_50;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  longlong local_30;
  undefined1 local_28 [16];
  
  puVar7 = (undefined8 *)((undefined8 *)param_1[6])[1];
  cVar4 = *(char *)((longlong)puVar7 + 0x29);
  puVar3 = (undefined8 *)param_1[6];
  while (cVar4 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar4 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar7 = (undefined8 *)param_1[6];
  local_40 = puVar3;
  local_48 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar8 = &local_38;
    local_30 = param_1[6];
    local_38 = *param_1;
  }
  else {
    plVar8 = &local_48;
  }
  plVar1 = (longlong *)*plVar8;
  lVar9 = param_1[6];
  lStack_50 = plVar8[1];
  local_58 = plVar1;
  if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_1)) {
    _invalid_parameter_noinfo();
  }
  lVar2 = lStack_50;
  if (lStack_50 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar1;
    }
    if (lVar2 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar9 = *(longlong *)(lVar2 + 0x20);
    if ((lVar9 != 0) && (cVar4 = FUN_1403a0240(lVar9), cVar4 != '\0')) {
      local_res8[0] = FUN_1403a0110(lVar9);
      FUN_1402a5c30(param_1 + 8,&local_58,local_res8);
      lVar2 = param_1[0xe];
      if ((local_58 == (longlong *)0x0) || (local_58 != (longlong *)param_1[8])) {
        _invalid_parameter_noinfo();
      }
      if (lStack_50 != lVar2) {
        FUN_1402a5870(param_1 + 8,local_28,&local_58);
      }
    }
    local_58 = (longlong *)*plVar8;
    lStack_50 = plVar8[1];
    FUN_1402a5870(param_1,local_28,&local_58);
    FUN_1403a5760(lVar9,param_3);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgNpcPath::helper_140388710  @140388710  [medium:callgraph-r0]  (orig: FUN_140388710)
void FUN_140388710(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  if (*(longlong *)(param_1 + 0x180) != 0) {
    *(undefined1 *)(param_1 + 0x17c) = 0;
    FUN_1403a5360(*(longlong *)(param_1 + 0x180),param_3);
    *(undefined8 *)(param_1 + 0x180) = 0;
  }
  return;
}

// ==== CMsgNpcPath::helper_1403887a0  @1403887a0  [medium:callgraph-r0]  (orig: FUN_1403887a0)
undefined8 FUN_1403887a0(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x180);
}

// ==== CMsgNpcPath::helper_14038bb70  @14038bb70  [medium:callgraph-r0]  (orig: FUN_14038bb70)
ulonglong FUN_14038bb70(longlong param_1)

{
  ulonglong uVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  ulonglong extraout_RAX;
  
  uVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x220))(param_1 + 0x10);
  if ((char)uVar1 != '\0') {
    if (*(longlong *)(param_1 + 0x180) != 0) {
      uVar1 = FUN_1403a0a40();
      if ((char)uVar1 != '\0') goto LAB_14038bbf5;
    }
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,*(undefined4 *)(param_1 + 0x170));
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = extraout_RAX;
    }
    else {
      if (*(char *)(param_1 + 0x17d) != '\0') {
        plVar3 = (longlong *)FUN_140118320();
        uVar1 = 0;
        if (plVar3 == (longlong *)0x0) goto LAB_14038bbf5;
        uVar1 = (**(code **)(*plVar3 + 0x30))(plVar3,*(undefined4 *)(param_1 + 0x170));
        if ((int)uVar1 == 0) goto LAB_14038bbf5;
      }
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
      uVar2 = FUN_140087790(uVar2);
      lVar4 = FUN_1402a6090(uVar2,*(undefined4 *)(param_1 + 0x170));
      *(longlong *)(param_1 + 0x180) = lVar4;
      uVar1 = 0;
      if (lVar4 != 0) {
        uVar1 = FUN_1403a2cc0(lVar4,*(undefined4 *)(param_1 + 0x88),*(undefined1 *)(param_1 + 0x17e)
                              ,*(undefined4 *)(param_1 + 0x170),*(undefined4 *)(param_1 + 0x174));
        return uVar1;
      }
    }
  }
LAB_14038bbf5:
  return uVar1 & 0xffffffffffffff00;
}

// ==== CMsgNpcPath::helper_14038e8d0  @14038e8d0  [medium:callgraph-r0]  (orig: FUN_14038e8d0)
void FUN_14038e8d0(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x114) = 0;
  if (*(int *)(param_1 + 0x154) == 0) {
    FUN_14038e270(param_1,0);
    *(undefined8 *)(param_1 + 0x180) = 0;
    return;
  }
  *(undefined8 *)(param_1 + 0x180) = 0;
  return;
}

// ==== CMsgNpcPath::helper_1403a00a0  @1403a00a0  [medium:callgraph-r0]  (orig: FUN_1403a00a0)
void FUN_1403a00a0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  return;
}

// ==== CMsgNpcPath::helper_1403a0110  @1403a0110  [medium:callgraph-r1]  (orig: FUN_1403a0110)
undefined4 FUN_1403a0110(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xc);
}

// ==== CMsgNpcPath::helper_1403a0240  @1403a0240  [medium:callgraph-r1]  (orig: FUN_1403a0240)
undefined1 FUN_1403a0240(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x28);
}

// ==== CMsgNpcPath::helper_1403a0a40  @1403a0a40  [medium:callgraph-r1]  (orig: FUN_1403a0a40)
ulonglong FUN_1403a0a40(longlong param_1)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
     (*(int *)(param_1 + 8) != 0)) {
    uVar1 = *(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8);
    return CONCAT71((int7)(uVar1 >> 8),(uVar1 & 0xffffffffffffffc0) != 0);
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgNpcPath::helper_1403a0ae0  @1403a0ae0  [medium:callgraph-r1]  (orig: FUN_1403a0ae0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a0ae0(longlong param_1,longlong param_2,longlong param_3,undefined4 param_4)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  undefined1 auStack_518 [32];
  ulonglong local_4f8;
  undefined8 local_4f0;
  undefined2 local_4e8;
  undefined2 local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d0;
  undefined1 local_4c8;
  undefined8 local_4b8;
  undefined1 local_4a8 [1104];
  ulonglong local_58;
  
  local_4b8 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_518;
  if (param_2 == 0) {
    local_4f8 = CONCAT44(local_4f8._4_4_,0x1eb);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 == 0) {
    local_4f8 = CONCAT44(local_4f8._4_4_,0x1ec);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    lVar4 = *(longlong *)(lVar2 + 0xe0);
    if (*(longlong *)(lVar2 + 0xe0) == 0) {
      local_4f8 = CONCAT44(local_4f8._4_4_,0x141);
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar4 = 0;
    }
    plVar3 = (longlong *)FUN_140315120(lVar4,param_4);
    if (plVar3 != (longlong *)0x0) {
      lVar4 = (**(code **)(*plVar3 + 0x40))(plVar3);
      if (lVar4 != 0) {
        FUN_14015b240(local_4a8);
        uVar5 = (**(code **)(*(longlong *)(param_3 + 0x10) + 0x18))(param_3 + 0x10);
        local_4c8 = 1;
        local_4d0 = 0;
        local_4d8 = 0;
        local_4e0 = 0;
        local_4e8 = 2000;
        local_4f0 = CONCAT44(local_4f0._4_4_,0xffffff);
        local_4f8 = 0;
        FUN_14015b300(local_4a8,uVar5,"ALLUSERS",lVar4);
        (**(code **)(*(longlong *)(param_3 + 0x10) + 0x348))(param_3 + 0x10,local_4a8,1);
        FUN_14015b2c0(local_4a8);
      }
      uVar1 = (**(code **)(*plVar3 + 0x38))(plVar3);
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      uVar5 = FUN_140087730(uVar5);
      local_4f0 = 0;
      local_4f8 = local_4f8 & 0xffffffff00000000;
      FUN_140145f60(uVar5,uVar1,param_2,param_3 + 0x10);
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a1a90  @1403a1a90  [medium:callgraph-r1]  (orig: FUN_1403a1a90)
void FUN_1403a1a90(longlong param_1)

{
  int iVar1;
  ulonglong uVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  undefined8 local_res8;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))
                    (*(longlong **)(lVar5 + 0x90),*(undefined4 *)(param_1 + 4));
  if (lVar5 == 0) {
    log_InlineLogERROR("CNpcPathTask::OnPathFinal, NPC path task no found leader");
    return;
  }
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x88) + 0x20))
                     (*(longlong **)(lVar5 + 0x88),*(undefined4 *)(param_1 + 8));
  if (plVar6 != (longlong *)0x0) {
    lVar5 = 0;
    local_res8 = 0;
    cVar3 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1002,&local_res8);
    if ((cVar3 != '\0') &&
       (((*(int *)(param_1 + 0x30) != 0 || (*(longlong *)(param_1 + 0x80) != 0)) &&
        ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) != 0)
        ))) {
      uVar2 = *(ulonglong *)(param_1 + 0xb8);
      if (*(ulonglong *)(param_1 + 0xc0) < uVar2) {
        _invalid_parameter_noinfo();
      }
      if (*(longlong **)(param_1 + 0xa0) == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar5 = **(longlong **)(param_1 + 0xa0);
      }
      if (*(ulonglong *)(lVar5 + 0x20) <= uVar2) {
        _invalid_parameter_noinfo();
      }
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      plVar8 = (longlong *)FUN_140087650(uVar7);
      lVar5 = *plVar8;
      uVar4 = FUN_1404d9f10(uVar2);
      lVar5 = (**(code **)(lVar5 + 0x98))(plVar8,uVar4);
      if (lVar5 != 0) {
        iVar1 = *(int *)(param_1 + 0x30);
        if (iVar1 == 0) {
          if (*(longlong *)(param_1 + 0x80) != 0) {
            if (*(ulonglong *)(param_1 + 0x88) < 0x10) {
              lVar5 = param_1 + 0x70;
            }
            else {
              lVar5 = *(longlong *)(param_1 + 0x70);
            }
            uVar4 = FUN_1404d9f10(uVar2);
            uVar7 = FUN_140087e30();
            cVar3 = FUN_140286530(uVar7,lVar5,uVar4,*(undefined4 *)(param_1 + 0x14),0,0);
            if (cVar3 == '\0') {
              log_InlineLogLuaERROR
                        ("Lua return fault, Call From:CNpcPathTask::OnPathFinal, lua function:%s.");
            }
          }
        }
        else {
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
          uVar7 = FUN_140087730(uVar7);
          FUN_140145f60(uVar7,iVar1,lVar5,plVar6,0,0);
        }
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a1d00  @1403a1d00  [medium:callgraph-r2]  (orig: FUN_1403a1d00)
void FUN_1403a1d00(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  longlong lVar4;
  
  uVar3 = *(ulonglong *)(param_1 + 0xb8);
  if (*(ulonglong *)(param_1 + 0xc0) < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(param_1 + 0xa0);
  while( true ) {
    uVar2 = *(ulonglong *)(param_1 + 0xc0);
    if (uVar2 < *(ulonglong *)(param_1 + 0xb8)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xa0))) {
      _invalid_parameter_noinfo();
    }
    if (uVar3 == uVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(ulonglong *)(lVar4 + 0x20) <= uVar3) {
      _invalid_parameter_noinfo();
    }
    FUN_1404da3a0(uVar3);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(ulonglong *)(lVar4 + 0x20) <= uVar3) {
      _invalid_parameter_noinfo();
    }
    uVar3 = uVar3 + 0x40;
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a2270  @1403a2270  [medium:callgraph-r3]  (orig: FUN_1403a2270)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a2270(longlong param_1)

{
  ulonglong uVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  ulonglong uVar8;
  longlong lVar9;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  longlong local_4a8 [2];
  longlong *local_498;
  ulonglong uStack_490;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if ((((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
      (*(int *)(param_1 + 8) != 0)) &&
     ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) != 0)) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      local_4c8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x98))
                      (*(longlong **)(lVar4 + 0x90),*(undefined4 *)(param_1 + 4));
    if (lVar4 != 0) {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      plVar6 = (longlong *)FUN_1400875f0(uVar5);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,*(undefined4 *)(param_1 + 8));
      if (plVar6 != (longlong *)0x0) {
        local_4a8[0] = 0;
        (**(code **)(*plVar6 + 0x298))(plVar6,0x1002,local_4a8);
        if (local_4a8[0] == 0) {
          local_4c8 = 0x365;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          uVar8 = *(ulonglong *)(param_1 + 0xb8);
          if (*(ulonglong *)(param_1 + 0xc0) < uVar8) {
            _invalid_parameter_noinfo();
          }
          plVar6 = *(longlong **)(param_1 + 0xa0);
          local_498 = plVar6;
          uStack_490 = uVar8;
          while( true ) {
            uVar1 = *(ulonglong *)(param_1 + 0xc0);
            if (uVar1 < *(ulonglong *)(param_1 + 0xb8)) {
              _invalid_parameter_noinfo();
            }
            if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0xa0))) {
              _invalid_parameter_noinfo();
            }
            if (uVar8 == uVar1) break;
            if (plVar6 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *plVar6;
            }
            if (*(ulonglong *)(lVar9 + 0x20) <= uVar8) {
              _invalid_parameter_noinfo();
            }
            iVar2 = FUN_1404d9f10(uVar8);
            if (iVar2 != *(int *)(param_1 + 4)) {
              uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
              plVar7 = (longlong *)FUN_140087650(uVar5);
              lVar9 = *plVar7;
              uVar3 = FUN_1404d9f10(uVar8);
              plVar7 = (longlong *)(**(code **)(lVar9 + 0x98))(plVar7,uVar3);
              if (plVar7 == (longlong *)0x0) {
                local_4c8 = 0x377;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                FUN_140457e30(local_478);
                uVar3 = (**(code **)(*plVar7 + 8))(plVar7);
                local_4b0 = *(undefined4 *)(param_1 + 0x14);
                local_4b8 = *(undefined4 *)(param_1 + 0x18);
                local_4c0 = *(undefined4 *)(param_1 + 0x10);
                local_4c8 = *(undefined4 *)(param_1 + 8);
                iVar2 = FUN_140457f00(local_478,0,*(undefined4 *)(param_1 + 4),uVar3);
                if (iVar2 == 0) {
                  FUN_140457ec0(local_478);
                }
                else {
                  uVar5 = (**(code **)(*(longlong *)(local_4a8[0] + 0x10) + 0x18))();
                  FUN_1404580b0(local_478,uVar5);
                  uVar5 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x18))();
                  FUN_1404580f0(local_478,uVar5);
                  FUN_1404581d0(local_478,10);
                  (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,local_478);
                  FUN_140457ec0(local_478);
                }
              }
            }
            if (plVar6 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar9 = 0;
            }
            else {
              lVar9 = *plVar6;
            }
            if (*(ulonglong *)(lVar9 + 0x20) <= uVar8) {
              _invalid_parameter_noinfo();
            }
            uVar8 = uVar8 + 0x40;
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a25d0  @1403a25d0  [medium:callgraph-r0]  (orig: FUN_1403a25d0)
ulonglong FUN_1403a25d0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  ulonglong uVar2;
  ulong uVar3;
  uint uVar4;
  ulonglong in_RAX;
  undefined4 extraout_var;
  longlong *extraout_RAX;
  longlong *extraout_RAX_00;
  longlong *plVar5;
  longlong *extraout_RAX_01;
  longlong *extraout_RAX_02;
  ulonglong uVar6;
  longlong lVar7;
  
  if ((((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
      (*(int *)(param_1 + 8) != 0)) &&
     (in_RAX = *(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8),
     (in_RAX & 0xffffffffffffffc0) != 0)) {
    uVar3 = tq::TimeGet(1);
    in_RAX = CONCAT44(extraout_var,uVar3);
    if (((*(uint *)(param_1 + 0x1c) <= uVar3) && (*(int *)(param_1 + 4) == param_3)) &&
       (uVar4 = uVar3 - *(uint *)(param_1 + 0x1c), in_RAX = (ulonglong)uVar4, uVar4 < 0xb)) {
      uVar6 = *(ulonglong *)(param_1 + 0xb8);
      if (*(ulonglong *)(param_1 + 0xc0) < uVar6) {
        _invalid_parameter_noinfo();
      }
      plVar1 = *(longlong **)(param_1 + 0xa0);
      plVar5 = plVar1;
      while( true ) {
        uVar2 = *(ulonglong *)(param_1 + 0xc0);
        if (uVar2 < *(ulonglong *)(param_1 + 0xb8)) {
          _invalid_parameter_noinfo();
          plVar5 = extraout_RAX;
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xa0))) {
          _invalid_parameter_noinfo();
          plVar5 = extraout_RAX_00;
        }
        if (uVar6 == uVar2) {
          return (ulonglong)plVar5 & 0xffffffffffffff00;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar1;
        }
        if (*(ulonglong *)(lVar7 + 0x20) <= uVar6) {
          _invalid_parameter_noinfo();
        }
        plVar5 = (longlong *)FUN_1404d9f10(uVar6);
        if (((int)plVar5 == param_2) &&
           (plVar5 = (longlong *)FUN_1404d9f30(uVar6), (char)plVar5 == '\0')) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
          plVar5 = extraout_RAX_01;
        }
        else {
          lVar7 = *plVar1;
        }
        if (*(ulonglong *)(lVar7 + 0x20) <= uVar6) {
          _invalid_parameter_noinfo();
          plVar5 = extraout_RAX_02;
        }
        uVar6 = uVar6 + 0x40;
      }
      FUN_1404d9f40(uVar6,*(undefined4 *)(param_1 + 0x34),*(undefined4 *)(param_1 + 0x38));
      uVar6 = FUN_1404daa10(uVar6);
      return uVar6;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgNpcPath::helper_1403a28d0  @1403a28d0  [medium:callgraph-r2]  (orig: FUN_1403a28d0)
undefined8 FUN_1403a28d0(char *param_1)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  ulong uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))
                     (*(longlong **)(lVar5 + 0x90),*(undefined4 *)(param_1 + 4));
  if (plVar6 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  if (*(int *)(param_1 + 0x10) != 0) {
    plVar7 = (longlong *)FUN_140118220();
    uVar2 = (**(code **)(*plVar7 + 0xe0))(plVar7,*(undefined4 *)(param_1 + 0x24),param_1 + 0x38);
    *(undefined4 *)(param_1 + 0x34) = uVar2;
    if (*param_1 != '\0') {
      plVar7 = (longlong *)FUN_140118320();
      if (plVar7 == (longlong *)0x0) {
        return 0;
      }
      lVar5 = *plVar7;
      uVar2 = (**(code **)(*plVar6 + 8))(plVar6);
      iVar3 = (**(code **)(lVar5 + 0x28))(plVar7,uVar2);
      if (iVar3 == 0) {
        return 0;
      }
      (**(code **)(*plVar7 + 0x98))(plVar7,iVar3,*(undefined4 *)(param_1 + 8));
    }
    param_1[0x94] = '\0';
    param_1[0x95] = '\0';
    param_1[0x96] = '\0';
    param_1[0x97] = '\0';
    param_1[0x90] = '\0';
    param_1[0x91] = '\0';
    param_1[0x92] = '\0';
    param_1[0x93] = '\0';
    uVar4 = tq::TimeGet(1);
    *(ulong *)(param_1 + 0x1c) = uVar4;
    param_1[0x98] = '\n';
    param_1[0x99] = '\0';
    param_1[0x9a] = '\0';
    param_1[0x9b] = '\0';
    uVar4 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x9c) = uVar4 / 1000;
    cVar1 = FUN_1403a25d0(param_1,*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 4));
    if (cVar1 == '\0') {
      return 0;
    }
    FUN_1403a2270(param_1);
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMsgNpcPath::helper_1403a2aa0  @1403a2aa0  [medium:callgraph-r0]  (orig: FUN_1403a2aa0)
void FUN_1403a2aa0(longlong param_1,int param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))
                     (*(longlong **)(lVar2 + 0x88),*(undefined4 *)(param_1 + 8));
  if (plVar3 != (longlong *)0x0) {
    local_res8 = 0;
    (**(code **)(*plVar3 + 0x298))(plVar3,0x1002,&local_res8);
    if (local_res8 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    cVar1 = FUN_1403886d0();
    if (cVar1 != '\0') {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      plVar3 = (longlong *)FUN_140087650(uVar4);
      lVar2 = (**(code **)(*plVar3 + 0x98))(plVar3,*(undefined4 *)(param_1 + 4));
      if (lVar2 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      *(int *)(param_1 + 0x18) = param_2;
      if (param_2 == 2) {
        FUN_1403a0ae0(param_1,lVar2,local_res8,*(undefined4 *)(param_1 + 0x10));
      }
      else if (param_2 == 3) {
        FUN_1403a1a90(param_1);
        return;
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a2cc0  @1403a2cc0  [medium:callgraph-r1]  (orig: FUN_1403a2cc0)
ulonglong FUN_1403a2cc0(longlong param_1,undefined4 param_2,undefined1 param_3,int param_4,
                       uint param_5)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong extraout_RAX;
  ulonglong uVar4;
  longlong *local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  uVar4 = 0;
  if (plVar3 != (longlong *)0x0) {
    local_res8 = (longlong *)0x0;
    (**(code **)(*plVar3 + 0x298))(plVar3,0x1002,&local_res8);
    if (local_res8 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar4 = extraout_RAX;
    }
    else {
      uVar4 = (**(code **)(*local_res8 + 0x50))();
      if (((((int)uVar4 == *(int *)(param_1 + 0xc)) && (param_4 == *(int *)(param_1 + 4))) &&
          (uVar4 = (ulonglong)*(uint *)(param_1 + 0x14), param_5 == *(uint *)(param_1 + 0x14))) &&
         (uVar4 = *(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8),
         (uVar4 & 0xffffffffffffffc0) != 0)) {
        *(undefined4 *)(param_1 + 8) = param_2;
        *(undefined1 *)(param_1 + 0x20) = param_3;
        uVar4 = *(ulonglong *)(param_1 + 0xb8);
        if (*(ulonglong *)(param_1 + 0xc0) < uVar4) {
          _invalid_parameter_noinfo();
        }
        plVar3 = *(longlong **)(param_1 + 0xa0);
        while( true ) {
          uVar1 = *(ulonglong *)(param_1 + 0xc0);
          if (uVar1 < *(ulonglong *)(param_1 + 0xb8)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xa0))) {
            _invalid_parameter_noinfo();
          }
          if (uVar4 == uVar1) break;
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar2 = 0;
          }
          else {
            lVar2 = *plVar3;
          }
          if (*(ulonglong *)(lVar2 + 0x20) <= uVar4) {
            _invalid_parameter_noinfo();
          }
          FUN_1404d9f20(uVar4,param_2);
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar2 = 0;
          }
          else {
            lVar2 = *plVar3;
          }
          if (*(ulonglong *)(lVar2 + 0x20) <= uVar4) {
            _invalid_parameter_noinfo();
          }
          uVar4 = uVar4 + 0x40;
        }
        uVar4 = FUN_1403a28d0(param_1);
        return uVar4;
      }
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMsgNpcPath::helper_1403a3b70  @1403a3b70  [medium:callgraph-r0]  (orig: FUN_1403a3b70)
void FUN_1403a3b70(longlong param_1,int param_2)

{
  longlong *plVar1;
  ulonglong uVar2;
  char cVar3;
  int iVar4;
  ulonglong uVar5;
  longlong lVar6;
  
  if ((param_2 != 0) && (cVar3 = FUN_1403a2020(), cVar3 != '\0')) {
    uVar5 = *(ulonglong *)(param_1 + 0xb8);
    if (*(ulonglong *)(param_1 + 0xc0) < uVar5) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(param_1 + 0xa0);
    while( true ) {
      uVar2 = *(ulonglong *)(param_1 + 0xc0);
      if (uVar2 < *(ulonglong *)(param_1 + 0xb8)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xa0))) {
        _invalid_parameter_noinfo();
      }
      if (uVar5 == uVar2) {
        return;
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(ulonglong *)(lVar6 + 0x20) <= uVar5) {
        _invalid_parameter_noinfo();
      }
      iVar4 = FUN_1404d9f10(uVar5);
      if (iVar4 == param_2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      if (*(ulonglong *)(lVar6 + 0x20) <= uVar5) {
        _invalid_parameter_noinfo();
      }
      uVar5 = uVar5 + 0x40;
    }
    FUN_1403a3530(param_1,param_2,8);
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a43b0  @1403a43b0  [medium:callgraph-r2]  (orig: FUN_1403a43b0)
void FUN_1403a43b0(char *param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  FUN_1403a3ca0(param_1 + 0xa0);
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))
                     (*(longlong **)(lVar3 + 0x90),*(undefined4 *)(param_1 + 4));
  if ((plVar4 != (longlong *)0x0) && (*param_1 != '\0')) {
    plVar5 = (longlong *)FUN_140118320();
    if (plVar5 != (longlong *)0x0) {
      lVar3 = *plVar5;
      uVar1 = (**(code **)(*plVar4 + 8))(plVar4);
      iVar2 = (**(code **)(lVar3 + 0x28))(plVar5,uVar1);
      if (iVar2 != 0) {
        (**(code **)(*plVar5 + 0xa0))(plVar5,iVar2);
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a4640  @1403a4640  [medium:callgraph-r2]  (orig: FUN_1403a4640)
void FUN_1403a4640(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  ulonglong uVar11;
  longlong *local_res10;
  longlong *local_res18;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
           (*(int *)(param_1 + 8) != 0)) &&
          ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) !=
           0)) {
    local_res10 = operator_new(8);
    plVar8 = (longlong *)0x0;
    local_68[0] = plVar8;
    if (local_res10 != (longlong *)0x0) {
      *local_res10 = (longlong)local_68;
      local_68[0] = local_res10;
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    uVar11 = *(ulonglong *)(param_1 + 0xb8);
    local_res18 = local_res10;
    if (*(ulonglong *)(param_1 + 0xc0) < uVar11) {
      _invalid_parameter_noinfo();
    }
    puVar1 = *(undefined8 **)(param_1 + 0xa0);
    while( true ) {
      uVar2 = *(ulonglong *)(param_1 + 0xc0);
      if (uVar2 < *(ulonglong *)(param_1 + 0xb8)) {
        _invalid_parameter_noinfo();
      }
      if ((puVar1 == (undefined8 *)0x0) || (puVar1 != *(undefined8 **)(param_1 + 0xa0))) {
        _invalid_parameter_noinfo();
      }
      if (uVar11 == uVar2) break;
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar8;
      }
      else {
        plVar9 = (longlong *)*puVar1;
      }
      if ((ulonglong)plVar9[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      if (*(longlong *)(lVar6 + 0x90) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar9 = *(longlong **)(lVar6 + 0x90);
      lVar6 = *plVar9;
      uVar5 = FUN_1404d9f10(uVar11);
      lVar6 = (**(code **)(lVar6 + 0x98))(plVar9,uVar5);
      puVar4 = local_48;
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,*(undefined4 *)(lVar6 + 0x122c));
        plVar9 = plVar8;
        if (local_50 != (undefined4 *)0x0) {
          plVar9 = (longlong *)(local_40 - (longlong)local_50 >> 2);
        }
        if ((longlong *)((longlong)local_48 - (longlong)local_50 >> 2) < plVar9) {
          *local_48 = *(undefined4 *)(lVar6 + 0x122c);
          local_48 = local_48 + 1;
        }
        else {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_50;
          plVar9 = local_68[0];
          plVar10 = plVar8;
          if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) != 0) {
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            if ((plVar9 == (longlong *)0x0) || (plVar9 != local_68[0])) {
              _invalid_parameter_noinfo();
            }
            plVar10 = (longlong *)((longlong)puVar4 - (longlong)puVar3 >> 2);
          }
          local_88 = SUB84(plVar9,0);
          uStack_84 = (undefined4)((ulonglong)plVar9 >> 0x20);
          uStack_80 = SUB84(puVar4,0);
          uStack_7c = (undefined4)((ulonglong)puVar4 >> 0x20);
          local_78 = local_88;
          uStack_74 = uStack_84;
          uStack_70 = uStack_80;
          uStack_6c = uStack_7c;
          FUN_140036c20(local_68,&local_78,1,&local_res10);
          puVar4 = local_50;
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_68[0];
          if (local_68[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar7 = plVar8;
          }
          else {
            plVar7 = (longlong *)*local_68[0];
          }
          if (puVar4 + (longlong)plVar10 <= (undefined4 *)plVar7[4]) {
            plVar7 = plVar8;
            if (plVar9 != (longlong *)0x0) {
              plVar7 = (longlong *)*plVar9;
            }
            if ((undefined4 *)plVar7[3] <= puVar4 + (longlong)plVar10) goto LAB_1403a497d;
          }
          _invalid_parameter_noinfo();
        }
      }
LAB_1403a497d:
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar8;
      }
      else {
        plVar9 = (longlong *)*puVar1;
      }
      if ((ulonglong)plVar9[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      uVar11 = uVar11 + 0x40;
    }
    plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    (**(code **)(*plVar8 + 0x40))(plVar8,local_68,param_2);
    if (local_50 != (undefined4 *)0x0) {
      operator_delete(local_50);
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    operator_delete(local_68[0]);
  }
  return;
}

// ==== CMsgNpcPath::helper_1403a5360  @1403a5360  [medium:callgraph-r1]  (orig: FUN_1403a5360)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403a5360(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_480;
  longlong local_478 [2];
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478[1] = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (*(int *)(param_1 + 0x10) == 0) {
    local_498 = 0xe7;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140457e30(local_468);
    local_480 = *(undefined4 *)(param_1 + 0x14);
    local_488 = 0;
    local_490 = *(undefined4 *)(param_1 + 0x10);
    local_498 = *(undefined4 *)(param_1 + 8);
    FUN_140457f00(local_468,5,*(undefined4 *)(param_1 + 4),0);
    FUN_140458130(local_468,param_2);
    if ((((*(int *)(param_1 + 0x10) != 0) && (*(int *)(param_1 + 4) != 0)) &&
        (*(int *)(param_1 + 8) != 0)) &&
       ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) != 0))
    {
      plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      (**(code **)(*plVar1 + 0x30))(plVar1,*(undefined4 *)(param_1 + 8),local_468);
    }
    local_480 = *(undefined4 *)(param_1 + 0x14);
    local_488 = 0;
    local_490 = *(undefined4 *)(param_1 + 0x10);
    local_498 = *(undefined4 *)(param_1 + 8);
    FUN_140457f00(local_468,6,*(undefined4 *)(param_1 + 4));
    FUN_140458130(local_468,param_2);
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_498 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                      (*(longlong **)(lVar2 + 0x90),*(undefined4 *)(param_1 + 4));
    if (lVar2 == 0) {
      FUN_140457ec0(local_468);
    }
    else {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
      plVar1 = (longlong *)FUN_1400875f0(uVar3);
      plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,*(undefined4 *)(param_1 + 8));
      if (plVar1 == (longlong *)0x0) {
        FUN_140457ec0(local_468);
      }
      else {
        local_478[0] = 0;
        (**(code **)(*plVar1 + 0x298))(plVar1,0x1002,local_478);
        if (local_478[0] == 0) {
          local_498 = 0x100;
          log_InlineLogERROR(&DAT_1406d9c10);
          FUN_140457ec0(local_468);
        }
        else {
          uVar3 = (**(code **)(*(longlong *)(local_478[0] + 0x10) + 0x18))();
          FUN_1404580b0(local_468,uVar3);
          FUN_1403a4640(param_1,local_468);
          FUN_1403a1d00(param_1);
          FUN_1403a43b0(param_1);
          *(undefined4 *)(param_1 + 0x10) = 0;
          uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
          uVar3 = FUN_140087790(uVar3);
          FUN_1402a6490(uVar3,*(undefined4 *)(param_1 + 4),1);
          FUN_140457ec0(local_468);
        }
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::ctor_or_dtor  @140457e30  [high:vtable-assign]  (orig: FUN_140457e30)
undefined8 * FUN_140457e30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNpcPath::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  *(undefined4 *)(param_1 + 7) = 3;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)(param_1[0x85] + 0x3c),0x3c1,true);
  return param_1;
}

// ==== CMsgNpcPath::ctor_or_dtor  @140457ec0  [high:vtable-assign]  (orig: FUN_140457ec0)
void FUN_140457ec0(undefined8 *param_1)

{
  *param_1 = CMsgNpcPath::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgNpcPath::helper_140457f00  @140457f00  [medium:callgraph-r0]  (orig: FUN_140457f00)
undefined8
FUN_140457f00(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0x40;
  *(undefined4 *)(param_1 + 8) = 0x40f;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_6;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_7;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_8;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x20) = 0;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x28) = 3;
  return 1;
}

// ==== CMsgNpcPath::vfunc_1  @140457fc0  [high:rtti-vtable]  (orig: FUN_140457fc0)
undefined8 FUN_140457fc0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgNpcPath::helper_140457ff0  @140457ff0  [medium:callgraph-r0]  (orig: FUN_140457ff0)
ulonglong FUN_140457ff0(longlong param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  ulonglong extraout_RAX;
  
  if (param_2 == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  FUN_140457f00(param_1,*param_2,param_2[1],0,param_2[3],param_2[4],param_2[6],param_2[5]);
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x38) = param_2[0xe];
  uVar1 = param_2[8];
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x20) = uVar1;
  return CONCAT71((uint7)(uint3)((uint)uVar1 >> 8),1);
}

// ==== CMsgNpcPath::helper_1404580b0  @1404580b0  [medium:callgraph-r2]  (orig: FUN_1404580b0)
void FUN_1404580b0(longlong param_1,char *param_2)

{
  uint uVar1;
  
  tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_2);
  uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar1 + 0x3f;
  return;
}

// ==== CMsgNpcPath::ctor_or_dtor  @1404581e0  [high:vtable-assign]  (orig: FUN_1404581e0)
undefined8 * FUN_1404581e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNpcPath::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgNpcPath::vfunc_3  @140458240  [high:rtti-vtable]  (orig: FUN_140458240)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140458240(longlong param_1,longlong param_2)

{
  int *piVar1;
  char cVar2;
  int iVar3;
  undefined8 uVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  longlong local_488;
  longlong local_480;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  local_480 = param_1;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_4a8 = 0x57;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 != 0) {
    local_488 = 0;
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar5 = (longlong *)FUN_1400875f0(uVar4);
    plVar5 = (longlong *)
             (**(code **)(*plVar5 + 0x20))
                       (plVar5,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
    if (plVar5 != (longlong *)0x0) {
      (**(code **)(*plVar5 + 0x298))(plVar5,0x1002,&local_488);
      if (local_488 == 0) {
        local_4a8 = 0x73;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        cVar2 = FUN_1403886d0();
        if (cVar2 == '\0') {
          if (**(int **)(param_1 + 0x428) == 3) {
            cVar2 = FUN_14038bb70(local_488);
            if (cVar2 == '\0') {
              lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              if (*(longlong *)(lVar6 + 0x230) == 0) {
                local_4a8 = 0x143;
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar4 = 0;
              }
              else {
                uVar4 = *(undefined8 *)(lVar6 + 0x230);
              }
              FUN_1402a6490(uVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),1);
              FUN_140457e30(local_468);
              lVar6 = *(longlong *)(param_1 + 0x428);
              local_490 = *(undefined4 *)(lVar6 + 0x14);
              local_498 = 0;
              local_4a0 = *(undefined4 *)(lVar6 + 0x10);
              local_4a8 = *(undefined4 *)(lVar6 + 0xc);
              iVar3 = FUN_140457f00(local_468,4,*(undefined4 *)(lVar6 + 4));
              if (iVar3 != 0) {
                (**(code **)(*(longlong *)(local_488 + 0x10) + 0x350))
                          ((longlong *)(local_488 + 0x10),local_468);
              }
              FUN_140457ec0(local_468);
            }
          }
          else if (**(int **)(param_1 + 0x428) == 0xb) {
            FUN_14038e8d0(local_488);
          }
        }
        else {
          lVar6 = FUN_1403887a0(local_488);
          if (lVar6 == 0) {
            local_4a8 = 0x95;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            piVar1 = *(int **)(param_1 + 0x428);
            iVar3 = *piVar1;
            if (iVar3 == 1) {
              if (piVar1[0xe] == 1) {
                FUN_1403a25d0(lVar6,piVar1[2],piVar1[1]);
              }
              else {
                FUN_1403a3b70(lVar6,piVar1[2]);
              }
            }
            else if (4 < iVar3) {
              if (iVar3 < 7) {
                FUN_140388710(local_488,piVar1[1],piVar1[8]);
              }
              else if (iVar3 == 7) {
                FUN_1403a00a0(lVar6,piVar1[4]);
              }
              else if (iVar3 == 8) {
                FUN_1403a2aa0(lVar6,piVar1[6],piVar1[0xe]);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::ctor_or_dtor  @140458510  [high:vtable-assign]  (orig: FUN_140458510)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140458510(longlong param_1)

{
  char cVar1;
  uint uVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  char *pcVar6;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  longlong local_478 [2];
  undefined **local_468;
  int local_45c;
  CStringPacker local_38 [32];
  ulonglong local_18;
  
  local_478[1] = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_488 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))
                    (*(longlong **)(lVar3 + 0x90),
                     *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (lVar3 != 0) {
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x88) == 0) {
      local_488 = 0x12f;
      log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pRoleManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
    }
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(lVar4 + 0x88) + 0x20))
                       (*(longlong **)(lVar4 + 0x88),
                        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc));
    if (plVar5 != (longlong *)0x0) {
      local_478[0] = 0;
      (**(code **)(*plVar5 + 0x298))(plVar5,0x1002,local_478);
      if (local_478[0] == 0) {
        local_488 = 0xe5;
        log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pMonster",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgnpcpath.cpp"
                          );
      }
      else {
        FUN_140457e30(&local_468);
        cVar1 = FUN_140457ff0(&local_468,*(undefined8 *)(param_1 + 0x428));
        if (cVar1 != '\0') {
          pcVar6 = (char *)(**(code **)(*(longlong *)(local_478[0] + 0x10) + 0x18))();
          tq::CStringPacker::AddString(local_38,pcVar6);
          uVar2 = tq::CStringPacker::GetSize(local_38);
          local_45c = uVar2 + 0x3f;
          (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),&local_468);
        }
        local_468 = CMsgNpcPath::vftable;
        tq::CStringPacker::~CStringPacker(local_38);
        FUN_1402b55f0(&local_468);
      }
    }
  }
  return;
}

// ==== CMsgNpcPath::helper_1404d9f20  @1404d9f20  [medium:callgraph-r2]  (orig: FUN_1404d9f20)
void FUN_1404d9f20(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x1c) = param_2;
  return;
}

// ==== CMsgNpcPath::helper_1404d9f30  @1404d9f30  [medium:callgraph-r1]  (orig: FUN_1404d9f30)
undefined1 FUN_1404d9f30(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x34);
}

// ==== CMsgNpcPath::helper_1404d9f40  @1404d9f40  [medium:callgraph-r1]  (orig: FUN_1404d9f40)
void FUN_1404d9f40(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0x10) = param_2;
  *(undefined4 *)(param_1 + 0x14) = param_3;
  return;
}

// ==== CMsgNpcPath::helper_1404da170  @1404da170  [medium:callgraph-r2]  (orig: FUN_1404da170)
undefined8 FUN_1404da170(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  
  lVar4 = FUN_1404da070();
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((*(int *)(param_1 + 0x20) != 0) && (-1 < *(int *)(param_1 + 0xc))) {
    plVar5 = (longlong *)FUN_140118220();
    *(longlong **)(param_1 + 0x38) = plVar5;
    cVar1 = (**(code **)(*plVar5 + 0x20))
                      (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20));
    if (cVar1 == '\0') {
      cVar1 = (**(code **)(*plVar5 + 0x10))
                        (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),
                         *(undefined4 *)(param_1 + 0xc));
      if (cVar1 == '\0') {
        return 0;
      }
      (**(code **)(*plVar5 + 8))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),1);
      (**(code **)(*plVar5 + 0x60))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),0);
      (**(code **)(*plVar5 + 0x78))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),
                 *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
    }
    else {
      iVar2 = (**(code **)(*plVar5 + 0x38))
                        (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),5);
      if (0 < iVar2) {
        iVar2 = (**(code **)(*plVar5 + 0x38))
                          (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),6)
        ;
        iVar3 = (**(code **)(*plVar5 + 0x38))
                          (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),5)
        ;
        if (iVar3 <= iVar2) {
          return 0;
        }
      }
      (**(code **)(*plVar5 + 0x78))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),
                 *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
      cVar1 = (**(code **)(*plVar5 + 0x60))
                        (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),0);
      if (cVar1 == '\0') {
        return 0;
      }
      (**(code **)(*plVar5 + 0x78))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),
                 *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x14));
      (**(code **)(*plVar5 + 8))
                (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),1);
    }
    (**(code **)(*plVar5 + 0x40))
              (plVar5,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_1 + 0x20),1,
               *(undefined4 *)(param_1 + 0x20));
    return 1;
  }
  return 0;
}

// ==== CMsgNpcPath::helper_1404daa10  @1404daa10  [medium:callgraph-r1]  (orig: FUN_1404daa10)
undefined1 FUN_1404daa10(longlong param_1)

{
  char cVar1;
  
  cVar1 = FUN_1404da170();
  if (cVar1 != '\0') {
    *(undefined1 *)(param_1 + 0x34) = 1;
    return 1;
  }
  *(undefined1 *)(param_1 + 0x34) = 0;
  return 0;
}

