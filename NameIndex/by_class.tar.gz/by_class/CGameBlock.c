// ==== CGameBlock::vfunc_1  @1402c4c60  [high:rtti-vtable]  (orig: FUN_1402c4c60)
undefined8 FUN_1402c4c60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return 0;
}

// ==== CGameBlock::vfunc_0  @1402c4c80  [high:rtti-vtable]  (orig: FUN_1402c4c80)
void * FUN_1402c4c80(void *param_1,uint param_2)

{
  FUN_1404721c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CGameBlock::helper_1402c4d70  @1402c4d70  [medium:callgraph-r0]  (orig: FUN_1402c4d70)
void FUN_1402c4d70(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CGameBlock::helper_1402c7d20  @1402c7d20  [medium:callgraph-r0]  (orig: FUN_1402c7d20)
void FUN_1402c7d20(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x18)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x18);
  return;
}

// ==== CGameBlock::ctor_or_dtor  @1402c81c0  [high:vtable-assign]  (orig: FUN_1402c81c0)
undefined8 * FUN_1402c81c0(longlong param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x18) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = CGameBlock::vftable;
      param_3[1] = *(undefined8 *)(param_1 + 8);
      *(undefined1 *)(param_3 + 2) = *(undefined1 *)(param_1 + 0x10);
    }
    param_3 = param_3 + 3;
  }
  return param_3;
}

// ==== CGameBlock::ctor_or_dtor  @1402c8310  [high:vtable-assign]  (orig: FUN_1402c8310)
undefined8 * FUN_1402c8310(longlong param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x18) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = CGameBlock::vftable;
      param_3[1] = *(undefined8 *)(param_1 + 8);
      *(undefined1 *)(param_3 + 2) = *(undefined1 *)(param_1 + 0x10);
    }
    param_3 = param_3 + 3;
  }
  return param_3;
}

// ==== CGameBlock::ctor_or_dtor  @1402ca5b0  [high:vtable-assign]  (orig: FUN_1402ca5b0)
void FUN_1402ca5b0(undefined8 *param_1,longlong param_2,longlong param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = CGameBlock::vftable;
      param_1[1] = *(undefined8 *)(param_3 + 8);
      *(undefined1 *)(param_1 + 2) = *(undefined1 *)(param_3 + 0x10);
    }
    param_1 = param_1 + 3;
  }
  return;
}

// ==== CGameBlock::helper_1402cabe0  @1402cabe0  [medium:callgraph-r0]  (orig: FUN_1402cabe0)
longlong FUN_1402cabe0(longlong param_1,longlong param_2,longlong param_3)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  longlong lVar5;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar5 = param_2 - param_3;
    puVar3 = (undefined1 *)(param_3 + 0x10);
    do {
      puVar1 = (undefined8 *)(param_2 + -0x10);
      puVar4 = puVar3 + -0x18;
      param_2 = param_2 + -0x18;
      *(undefined8 *)(puVar3 + -0x20) = *puVar1;
      *puVar4 = puVar4[lVar5];
      puVar3 = puVar4;
    } while (param_2 != param_1);
  }
  return param_3 + (lVar2 / 0x18) * -0x18;
}

// ==== CGameBlock::helper_1402cb4e0  @1402cb4e0  [medium:callgraph-r0]  (orig: FUN_1402cb4e0)
void FUN_1402cb4e0(undefined8 param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_2 != param_3; param_2 = param_2 + 3) {
    (**(code **)*param_2)(param_2,0);
  }
  return;
}

// ==== CGameBlock::ctor_or_dtor  @1402ce1f0  [high:vtable-assign]  (orig: FUN_1402ce1f0)
void FUN_1402ce1f0(longlong param_1,longlong param_2,ulonglong param_3,longlong param_4)

{
  undefined1 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong lVar5;
  undefined1 *puVar6;
  undefined1 *puVar7;
  ulonglong uVar8;
  longlong lVar9;
  undefined1 local_res8;
  undefined **local_58;
  undefined8 local_50;
  undefined1 local_48;
  
  lVar5 = *(longlong *)(param_1 + 0x18);
  if (lVar5 == 0) {
    uVar8 = 0;
  }
  else {
    lVar9 = *(longlong *)(param_1 + 0x28) - lVar5;
    lVar9 = lVar9 / 6 + (lVar9 >> 0x3f);
    uVar8 = (lVar9 >> 2) - (lVar9 >> 0x3f);
  }
  if (param_3 != 0) {
    lVar5 = (*(longlong *)(param_1 + 0x20) - lVar5) / 0x18;
    if (0xaaaaaaaaaaaaaaaU - lVar5 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_1402c4d70();
    }
    uVar2 = lVar5 + param_3;
    local_res8 = (undefined1)param_1;
    if (uVar8 < uVar2) {
      if (0xaaaaaaaaaaaaaaa - (uVar8 >> 1) < uVar8) {
        uVar8 = 0;
      }
      else {
        uVar8 = uVar8 + (uVar8 >> 1);
      }
      if (uVar8 < uVar2) {
        uVar8 = uVar2;
      }
      lVar3 = FUN_1402c7d20(param_1 + 0x10,uVar8);
      lVar5 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18);
      lVar5 = lVar5 / 6 + (lVar5 >> 0x3f);
      lVar5 = (lVar5 >> 2) - (lVar5 >> 0x3f);
      FUN_1402ca5b0(lVar3 + lVar5 * 0x18,param_3,param_4,param_1 + 0x10,local_res8,0,0,lVar3,lVar5);
      FUN_1402c8310(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10,local_res8,0,1);
      FUN_1402c8310(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar3 + (lVar5 + param_3) * 0x18,param_1 + 0x10,local_res8,0,2);
      lVar5 = *(longlong *)(param_1 + 0x18);
      lVar9 = *(longlong *)(param_1 + 0x20);
      if (lVar5 != 0) {
        FUN_1402cb4e0(param_1,lVar5,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = lVar3 + uVar8 * 0x18;
      *(ulonglong *)(param_1 + 0x20) = lVar3 + (param_3 + (lVar9 - lVar5) / 0x18) * 0x18;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x18) <
             param_3) {
      local_58 = CGameBlock::vftable;
      local_50 = *(undefined8 *)(param_4 + 8);
      local_48 = *(undefined1 *)(param_4 + 0x10);
      FUN_1402c8310(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x18,param_1 + 0x10,local_res8,0);
      FUN_1402ca5b0(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x18,
                    &local_58,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x18;
      puVar7 = (undefined1 *)(*(longlong *)(param_1 + 0x20) + param_3 * -0x18);
      if (*(undefined1 **)(param_2 + 8) != puVar7) {
        puVar6 = *(undefined1 **)(param_2 + 8) + 0x10;
        do {
          *(undefined8 *)(puVar6 + -8) = local_50;
          *puVar6 = local_48;
          puVar1 = puVar6 + 8;
          puVar6 = puVar6 + 0x18;
        } while (puVar1 != puVar7);
      }
      FUN_1404721c0(&local_58);
    }
    else {
      local_58 = CGameBlock::vftable;
      local_50 = *(undefined8 *)(param_4 + 8);
      local_48 = *(undefined1 *)(param_4 + 0x10);
      lVar5 = *(longlong *)(param_1 + 0x20);
      lVar9 = lVar5 + param_3 * -0x18;
      uVar4 = FUN_1402c8310(lVar9,lVar5,lVar5,param_1 + 0x10,local_res8,0);
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      FUN_1402cabe0(*(undefined8 *)(param_2 + 8),lVar9,lVar5);
      puVar7 = *(undefined1 **)(param_2 + 8);
      if (puVar7 != puVar7 + param_3 * 0x18) {
        puVar6 = puVar7 + 0x10;
        do {
          *(undefined8 *)(puVar6 + -8) = local_50;
          *puVar6 = local_48;
          puVar1 = puVar6 + 8;
          puVar6 = puVar6 + 0x18;
        } while (puVar1 != puVar7 + param_3 * 0x18);
      }
      FUN_1404721c0(&local_58);
    }
  }
  return;
}

// ==== CGameBlock::ctor_or_dtor  @1404721a0  [high:vtable-assign]  (orig: FUN_1404721a0)
undefined8 * FUN_1404721a0(undefined8 *param_1)

{
  *(undefined1 *)(param_1 + 2) = 0;
  param_1[1] = 0;
  *param_1 = CGameBlock::vftable;
  return param_1;
}

// ==== CGameBlock::ctor_or_dtor  @1404721c0  [high:vtable-assign]  (orig: FUN_1404721c0)
void FUN_1404721c0(undefined8 *param_1)

{
  *param_1 = CGameBlock::vftable;
  if ((longlong *)param_1[1] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[1] + 8))();
  }
  return;
}

