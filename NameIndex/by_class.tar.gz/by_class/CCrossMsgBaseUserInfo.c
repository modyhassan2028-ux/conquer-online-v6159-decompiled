// ==== CCrossMsgBaseUserInfo::helper_140167eb0  @140167eb0  [medium:callgraph-r0]  (orig: FUN_140167eb0)
void FUN_140167eb0(longlong *param_1,undefined4 *param_2)

{
  *(undefined4 *)((longlong)param_1 + 0xe84) = *param_2;
  param_1[0x1d1] = 0;
  param_1[0x1d2] = 0;
  if ((longlong *)(param_2 + 1) != (longlong *)0x0) {
    param_1[0x1d1] = *(longlong *)(param_2 + 1);
    *(undefined4 *)(param_1 + 0x1d2) = param_2[3];
    *(undefined2 *)((longlong)param_1 + 0xe94) = *(undefined2 *)(param_2 + 4);
    *(undefined1 *)((longlong)param_1 + 0xe96) = *(undefined1 *)((longlong)param_2 + 0x12);
  }
  param_1[0x1d3] = 0;
  param_1[0x1d4] = 0;
  if ((longlong *)(param_2 + 5) != (longlong *)0x0) {
    param_1[0x1d3] = *(longlong *)(param_2 + 5);
    *(undefined4 *)(param_1 + 0x1d4) = param_2[7];
    *(undefined2 *)((longlong)param_1 + 0xea4) = *(undefined2 *)(param_2 + 8);
    *(undefined1 *)((longlong)param_1 + 0xea6) = *(undefined1 *)((longlong)param_2 + 0x22);
  }
  param_1[0x20d] = 0;
  param_1[0x20e] = 0;
  if ((longlong *)(param_2 + 9) != (longlong *)0x0) {
    param_1[0x20d] = *(longlong *)(param_2 + 9);
    *(undefined4 *)(param_1 + 0x20e) = param_2[0xb];
    *(undefined2 *)((longlong)param_1 + 0x1074) = *(undefined2 *)(param_2 + 0xc);
    *(undefined1 *)((longlong)param_1 + 0x1076) = *(undefined1 *)((longlong)param_2 + 0x32);
  }
  *(undefined4 *)((longlong)param_1 + 0xeac) = param_2[0xd];
  *(undefined4 *)(param_1 + 0x1d6) = param_2[0xe];
  param_1[0x1d7] = *(longlong *)(param_2 + 0x10);
  param_1[0x1d8] = *(longlong *)(param_2 + 0x12);
  *(undefined4 *)(param_1 + 0x1d9) = param_2[0x14];
  *(undefined1 *)((longlong)param_1 + 0xecc) = *(undefined1 *)(param_2 + 0x15);
  param_1[0x1da] = *(longlong *)(param_2 + 0x16);
  *(undefined2 *)(param_1 + 0x1db) = *(undefined2 *)(param_2 + 0x18);
  *(undefined1 *)((longlong)param_1 + 0xeda) = *(undefined1 *)((longlong)param_2 + 0x62);
  *(undefined1 *)((longlong)param_1 + 0xedb) = *(undefined1 *)((longlong)param_2 + 99);
  *(undefined2 *)((longlong)param_1 + 0xedc) = *(undefined2 *)(param_2 + 0x19);
  *(undefined2 *)((longlong)param_1 + 0xede) = *(undefined2 *)((longlong)param_2 + 0x66);
  *(undefined2 *)(param_1 + 0x1dc) = *(undefined2 *)(param_2 + 0x1a);
  *(undefined2 *)((longlong)param_1 + 0xee2) = *(undefined2 *)((longlong)param_2 + 0x6a);
  *(undefined1 *)((longlong)param_1 + 0xee4) = *(undefined1 *)(param_2 + 0x1b);
  *(undefined4 *)(param_1 + 0x1dd) = param_2[0x1c];
  *(undefined2 *)((longlong)param_1 + 0xeec) = *(undefined2 *)(param_2 + 0x1d);
  *(undefined1 *)((longlong)param_1 + 0xeee) = *(undefined1 *)((longlong)param_2 + 0x76);
  *(undefined4 *)(param_1 + 0x1de) = param_2[0x1e];
  *(undefined2 *)((longlong)param_1 + 0xef4) = *(undefined2 *)(param_2 + 0x1f);
  *(undefined1 *)((longlong)param_1 + 0xef6) = *(undefined1 *)((longlong)param_2 + 0x7e);
  *(undefined4 *)(param_1 + 0x1df) = param_2[0x20];
  *(undefined4 *)((longlong)param_1 + 0xefc) = param_2[0x21];
  *(undefined1 *)(param_1 + 0x1e0) = *(undefined1 *)(param_2 + 0x22);
  *(undefined4 *)((longlong)param_1 + 0xf04) = param_2[0x23];
  _snprintf((char *)(param_1 + 0x261),0x24,"%s");
  *(undefined4 *)(param_1 + 0x1e1) = param_2[0x2d];
  *(undefined2 *)((longlong)param_1 + 0xf0c) = *(undefined2 *)(param_2 + 0x2e);
  *(undefined2 *)((longlong)param_1 + 0xf0e) = *(undefined2 *)((longlong)param_2 + 0xba);
  *(undefined4 *)(param_1 + 0x1e2) = param_2[0x2f];
  *(undefined4 *)(param_1 + 0x1e3) = param_2[0x30];
  *(undefined4 *)((longlong)param_1 + 0xf24) = param_2[0x31];
  *(undefined4 *)(param_1 + 0x1e5) = param_2[0x32];
  *(undefined4 *)((longlong)param_1 + 0xf2c) = param_2[0x33];
  *(undefined4 *)(param_1 + 0x1e6) = param_2[0x34];
  *(undefined4 *)(param_1 + 0x1e7) = param_2[0x36];
  *(undefined4 *)((longlong)param_1 + 0xf3c) = param_2[0x37];
  *(undefined4 *)(param_1 + 0x1e8) = param_2[0x38];
  *(undefined4 *)(param_1 + 0x1ea) = param_2[0x39];
  *(undefined4 *)((longlong)param_1 + 0xf54) = param_2[0x3a];
  *(undefined4 *)(param_1 + 0x1eb) = param_2[0x3b];
  *(undefined4 *)((longlong)param_1 + 0xf5c) = param_2[0x3c];
  *(undefined1 *)(param_1 + 0x1f2) = *(undefined1 *)(param_2 + 0x3d);
  *(undefined2 *)((longlong)param_1 + 0xf92) = *(undefined2 *)((longlong)param_2 + 0xf6);
  *(undefined2 *)((longlong)param_1 + 0xf94) = *(undefined2 *)(param_2 + 0x3e);
  *(undefined4 *)(param_1 + 499) = param_2[0x3f];
  *(undefined4 *)((longlong)param_1 + 0xfa4) = param_2[0x40];
  *(undefined4 *)(param_1 + 0x1f5) = param_2[0x41];
  *(undefined4 *)((longlong)param_1 + 0xfac) = param_2[0x42];
  *(undefined4 *)(param_1 + 0x1f6) = param_2[0x43];
  *(undefined4 *)((longlong)param_1 + 0xfb4) = param_2[0x44];
  *(undefined2 *)(param_1 + 0x1f7) = *(undefined2 *)(param_2 + 0x45);
  *(undefined2 *)((longlong)param_1 + 0xfba) = *(undefined2 *)((longlong)param_2 + 0x116);
  *(undefined4 *)((longlong)param_1 + 0xfbc) = param_2[0x46];
  *(undefined4 *)(param_1 + 0x1f8) = param_2[0x47];
  *(undefined4 *)((longlong)param_1 + 0xfc4) = param_2[0x48];
  *(undefined4 *)(param_1 + 0x1f9) = param_2[0x49];
  *(undefined4 *)((longlong)param_1 + 0xfcc) = param_2[0x4a];
  param_1[0x1fa] = *(longlong *)(param_2 + 0x4c);
  *(undefined4 *)(param_1 + 0x1fb) = param_2[0x4e];
  *(undefined4 *)((longlong)param_1 + 0xfdc) = param_2[0x4f];
  *(undefined4 *)(param_1 + 0x1fc) = param_2[0x50];
  *(undefined2 *)((longlong)param_1 + 0xfe4) = *(undefined2 *)(param_2 + 0x51);
  *(undefined2 *)((longlong)param_1 + 0xfe6) = *(undefined2 *)((longlong)param_2 + 0x146);
  *(undefined2 *)(param_1 + 0x1fd) = *(undefined2 *)(param_2 + 0x52);
  *(undefined2 *)((longlong)param_1 + 0xfea) = *(undefined2 *)((longlong)param_2 + 0x14a);
  *(undefined4 *)((longlong)param_1 + 0xfec) = param_2[0x53];
  *(undefined4 *)(param_1 + 0x1fe) = param_2[0x54];
  *(undefined4 *)((longlong)param_1 + 0xff4) = param_2[0x55];
  *(undefined4 *)(param_1 + 0x1ff) = param_2[0x56];
  *(undefined4 *)((longlong)param_1 + 0xffc) = param_2[0x57];
  *(undefined4 *)(param_1 + 0x200) = param_2[0x58];
  *(undefined1 *)((longlong)param_1 + 0x1004) = *(undefined1 *)(param_2 + 0x59);
  *(undefined4 *)(param_1 + 0x201) = param_2[0x5a];
  *(undefined4 *)((longlong)param_1 + 0x100c) = param_2[0x5b];
  *(undefined1 *)((longlong)param_1 + 0x1024) = *(undefined1 *)(param_2 + 0x5c);
  *(undefined4 *)(param_1 + 0x205) = param_2[0x5d];
  *(undefined4 *)((longlong)param_1 + 0x102c) = param_2[0x5e];
  *(undefined1 *)(param_1 + 0x206) = *(undefined1 *)(param_2 + 0x5f);
  *(undefined4 *)((longlong)param_1 + 0x1034) = param_2[0x60];
  *(undefined4 *)(param_1 + 0x207) = param_2[0x61];
  *(undefined1 *)((longlong)param_1 + 0x103c) = *(undefined1 *)(param_2 + 0x62);
  param_1[0x208] = *(longlong *)(param_2 + 100);
  param_1[0x209] = *(longlong *)(param_2 + 0x66);
  *(undefined4 *)((longlong)param_1 + 0xf9c) = param_2[0x68];
  *(undefined4 *)(param_1 + 500) = param_2[0x69];
  *(undefined4 *)((longlong)param_1 + 0x105c) = param_2[0x71];
  *(undefined2 *)(param_1 + 0x20c) = *(undefined2 *)(param_2 + 0x72);
  *(undefined2 *)(param_1 + 0x32) = *(undefined2 *)((longlong)param_2 + 0x1ca);
  *(undefined4 *)(param_1 + 0x171) = param_2[0x73];
  *(undefined2 *)((longlong)param_1 + 0x105a) = *(undefined2 *)(param_2 + 0x70);
  *(undefined4 *)(param_1 + 0x21e) = param_2[0x6a];
  *(undefined4 *)((longlong)param_1 + 0xb2c) = param_2[0x6b];
  *(undefined4 *)(param_1 + 0x6e) = param_2[0x6c];
  *(undefined4 *)((longlong)param_1 + 0x11ac) = param_2[0x6d];
  *(bool *)((longlong)param_1 + 0x954) = *(char *)(param_2 + 0x6e) == '\x01';
  *(undefined4 *)(param_1 + 0x238) = param_2[0x6f];
  *(undefined4 *)(param_1 + 0x213) = param_2[0x74];
  *(undefined4 *)((longlong)param_1 + 0x1094) = param_2[0x75];
  *(undefined4 *)((longlong)param_1 + 0x109c) = param_2[0x76];
  *(undefined1 *)(param_1 + 0x267) = *(undefined1 *)(param_2 + 0x77);
  *(undefined1 *)((longlong)param_1 + 0x1339) = *(undefined1 *)((longlong)param_2 + 0x1dd);
  tq::StrCopy((char *)((longlong)param_1 + 0x133a),(char *)((longlong)param_2 + 0x1de),0x20);
  (**(code **)(*param_1 + 0x38))(param_1);
                    /* WARNING: Could not recover jumptable at 0x0001401684af. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  log_InlineLogOSMessage("login os step3: load os user[id:%u, serverid:%u] base info ok.");
  return;
}

// ==== CCrossMsgBaseUserInfo::helper_1401adad0  @1401adad0  [medium:callgraph-r0]  (orig: FUN_1401adad0)
void FUN_1401adad0(longlong *param_1,longlong param_2)

{
  ushort uVar1;
  int iVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  
  iVar2 = *(int *)(param_2 + 0x70);
  iVar4 = (**(code **)(param_1[2] + 0x78))();
  if (iVar4 != iVar2) {
    FUN_140198760(param_1,iVar2,0);
  }
  uVar1 = *(ushort *)(param_2 + 0x74);
  uVar5 = (**(code **)(*param_1 + 0x80))(param_1);
  if (uVar5 != uVar1) {
    FUN_1403716b0(param_1 + 0x1cf,(uint)uVar1,0);
  }
  if ((int)param_1[0x21e] != *(int *)(param_2 + 0x1a8)) {
    FUN_1401a9e70(param_1);
  }
  if ((char)param_1[0x1f2] != *(char *)(param_2 + 0xf4)) {
    *(char *)(param_1 + 0x1f2) = *(char *)(param_2 + 0xf4);
  }
  if (*(short *)((longlong)param_1 + 0xf92) != *(short *)(param_2 + 0xf6)) {
    *(short *)((longlong)param_1 + 0xf92) = *(short *)(param_2 + 0xf6);
  }
  if ((short)param_1[0x32] != *(short *)(param_2 + 0x1ca)) {
    *(short *)(param_1 + 0x32) = *(short *)(param_2 + 0x1ca);
  }
  FUN_14018e220(param_1,*(undefined4 *)(param_2 + 0x1cc));
  iVar2 = *(int *)(param_2 + 0x1a0);
  *(int *)((longlong)param_1 + 0xf9c) = iVar2;
  iVar4 = *(int *)(param_2 + 0x1a4);
  *(int *)(param_1 + 500) = iVar4;
  *(undefined4 *)(param_1 + 0x6e) = *(undefined4 *)(param_2 + 0x1b0);
  *(bool *)((longlong)param_1 + 0x954) = *(char *)(param_2 + 0x1b8) == '\x01';
  if ((iVar2 == 0) || (iVar4 == 0)) {
    if (param_1[0x151] != 0) {
      FUN_140173030(param_1);
    }
    if ((int)param_1[0x153] != -1) {
      FUN_140173130(param_1);
    }
  }
  else {
    cVar3 = FUN_140172b80(param_1,iVar2,iVar4,1,1);
    if (cVar3 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

// ==== CCrossMsgBaseUserInfo::ctor_or_dtor  @1403ef2a0  [high:vtable-assign]  (orig: FUN_1403ef2a0)
undefined8 * FUN_1403ef2a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgBaseUserInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgBaseUserInfo::ctor_or_dtor  @1403ef2f0  [high:vtable-assign]  (orig: FUN_1403ef2f0)
void FUN_1403ef2f0(undefined8 *param_1)

{
  *param_1 = CCrossMsgBaseUserInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgBaseUserInfo::vfunc_1  @1403ef320  [high:rtti-vtable]  (orig: FUN_1403ef320)
undefined8 FUN_1403ef320(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgBaseUserInfo::ctor_or_dtor  @1403ef3b0  [high:vtable-assign]  (orig: FUN_1403ef3b0)
undefined8 * FUN_1403ef3b0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgBaseUserInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgBaseUserInfo::vfunc_3  @1403ef400  [high:rtti-vtable]  (orig: FUN_1403ef400)
void FUN_1403ef400(longlong param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  
  if (**(short **)(param_1 + 0x428) == 0) {
    uVar1 = *(undefined4 *)(param_1 + 0x41c);
    uVar2 = *(undefined4 *)(param_1 + 0x420);
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar3 = FUN_140087650(uVar3);
    lVar5 = FUN_1402af110(uVar3,uVar1,uVar2);
    if (lVar5 == 0) {
                    /* WARNING: Could not recover jumptable at 0x0001403ef4c9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      log_InlineLogOSWARNING("CCrossMsgBaseUserInfo::Process not found user, idServer:%u, idOSUser")
      ;
      return;
    }
    FUN_140167eb0(lVar5,*(longlong *)(param_1 + 0x428) + 8);
  }
  else if (**(short **)(param_1 + 0x428) == 1) {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x98))
                      (plVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
    if (lVar5 != 0) {
      FUN_1401adad0(lVar5,*(longlong *)(param_1 + 0x428) + 8);
      return;
    }
  }
  return;
}

