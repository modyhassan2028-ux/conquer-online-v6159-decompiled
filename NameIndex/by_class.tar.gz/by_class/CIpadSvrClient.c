// ==== CIpadSvrClient::ctor_or_dtor  @140502ef0  [high:vtable-assign]  (orig: FUN_140502ef0)
undefined8 * FUN_140502ef0(undefined8 *param_1)

{
  FUN_140506e80();
  *param_1 = CIpadSvrClient::vftable;
  return param_1;
}

// ==== CIpadSvrClient::ctor_or_dtor  @140502f20  [high:vtable-assign]  (orig: FUN_140502f20)
void FUN_140502f20(undefined8 *param_1)

{
  *param_1 = CIpadSvrClient::vftable;
  FUN_1405061c0();
  return;
}

// ==== CIpadSvrClient::vfunc_1  @140502f50  [high:rtti-vtable]  (orig: FUN_140502f50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140502f50(longlong *param_1,longlong param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  undefined1 auStack_458 [32];
  undefined8 local_438;
  CIniFile local_428 [1024];
  undefined8 local_28;
  undefined2 local_20;
  undefined4 local_1e;
  undefined2 local_1a;
  ulonglong local_18;
  
  local_438 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if ((param_2 == 0) || (param_3 != 5)) {
    uVar3 = 0;
  }
  else {
    param_1[0x208] = param_2;
    *(undefined4 *)(param_1 + 0x207) = 5;
    (**(code **)(*param_1 + 0x28))(param_1,0);
    CIniFile::CIniFile(local_428,"shell.ini","IPADPaymentsClient");
    local_28 = DAT_1406e8af0;
    local_20 = DAT_1406e8af8;
    local_1e = 0;
    local_1a = 0;
    CIniFile::GetString(local_428,(char *)&local_28,"WebServerIP",0x10);
    iVar2 = CIniFile::GetInt(local_428,"WebServerPort");
    if (iVar2 == 0) {
      log_InlineLogERROR(&DAT_14079a888,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\evnet\\ipadsvrclient.cpp",
                         0x29);
      CIniFile::~CIniFile(local_428);
      uVar3 = 0;
    }
    else {
      cVar1 = (**(code **)(*param_1 + 0x40))(param_1,&local_28,iVar2);
      if (cVar1 == '\0') {
        log_InlineLogERROR("CClientSocket::Create, IpadServer client socket Open error.");
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
      else {
        CIniFile::~CIniFile(local_428);
        uVar3 = 1;
      }
    }
  }
  return uVar3;
}

// ==== CIpadSvrClient::vfunc_2  @1405030b0  [high:rtti-vtable]  (orig: FUN_1405030b0)
void FUN_1405030b0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CIpadSvrClient::vfunc_3  @1405030d0  [high:rtti-vtable]  (orig: FUN_1405030d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405030d0(longlong *param_1)

{
  ushort uVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  uint uVar5;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined1 local_434 [1052];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_1[0x208] == 0) {
    local_448 = (undefined4 *)CONCAT44(local_448._4_4_,0x3c);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar3 = (int)param_1[0x105];
    if (0 < iVar3) {
      while (3 < iVar3) {
        uVar1 = *(ushort *)(param_1 + 5);
        if (iVar3 < (int)(uint)uVar1) {
          return;
        }
        uVar5 = (uint)uVar1;
        if ((uVar1 < 4) || (uVar5 != 0x400 && 0x3ff < uVar1)) {
          (**(code **)(*param_1 + 0x68))(param_1);
          tq::MyLogSave("gmlog/IPADPayments",
                        "receive web server message size error, socket be close, message size = %d."
                       );
          return;
        }
        memset((void *)((longlong)&local_438 + 1),0,0x417);
        local_438 = uVar5;
        memcpy(local_434,param_1 + 5,(ulonglong)uVar1);
        plVar4 = (longlong *)FUN_1404f7270(param_1[0x208]);
        local_448 = &local_438;
        (**(code **)(*plVar4 + 0x50))(plVar4,9,0x186a9,0x418);
        cVar2 = (**(code **)(*param_1 + 0x58))(param_1,uVar5,0);
        if (cVar2 == '\0') {
          return;
        }
        iVar3 = (int)param_1[0x105];
        if (iVar3 < 1) {
          return;
        }
      }
    }
  }
  return;
}

// ==== CIpadSvrClient::ctor_or_dtor  @140503230  [high:vtable-assign]  (orig: FUN_140503230)
undefined8 * FUN_140503230(undefined8 *param_1,uint param_2)

{
  *param_1 = CIpadSvrClient::vftable;
  FUN_1405061c0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

