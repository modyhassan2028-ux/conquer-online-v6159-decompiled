// ==== CMsgSlotOpt::helper_14024f480  @14024f480  [medium:callgraph-r1]  (orig: FUN_14024f480)
ulonglong FUN_14024f480(undefined8 param_1,longlong param_2,int param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ulonglong in_RAX;
  undefined8 uVar4;
  ulonglong uVar5;
  undefined8 local_res10;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    plVar1 = (longlong *)(param_2 + 0x10);
    local_res10 = 0;
    uVar2 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x48))(plVar1);
    uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
    uVar4 = (**(code **)(*plVar1 + 0x160))(plVar1);
    uVar5 = FUN_1402c84c0(uVar4,uVar3,uVar2,0x1040,param_3,&local_res10);
    return uVar5;
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMsgSlotOpt::helper_140250570  @140250570  [medium:callgraph-r1]  (orig: FUN_140250570)
bool FUN_140250570(longlong param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)(**(code **)(**(longlong **)(lVar3 + 0x88) + 0x30))();
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x40))(plVar4,param_2);
  if (plVar4 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8);
    if ((cVar1 != '\0') && (local_res8 != 0)) {
      iVar2 = (**(code **)(**(longlong **)(local_res8 + 0x60) + 0x10))
                        (*(longlong **)(local_res8 + 0x60),4);
      return iVar2 == 0x3c;
    }
  }
  return false;
}

// ==== CMsgSlotOpt::helper_140250640  @140250640  [medium:callgraph-r1]  (orig: FUN_140250640)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140250640(longlong param_1,longlong *param_2,undefined4 param_3,ulonglong param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  undefined1 auStack_4b8 [32];
  longlong local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  lVar2 = (**(code **)(*param_2 + 0x68))(param_2);
  lVar2 = param_4 + lVar2;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0xb0) == 0) {
    local_498 = CONCAT44(local_498._4_4_,0x138);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = FUN_140006cc0(*(undefined8 *)(lVar3 + 0xb0));
  if (lVar3 < lVar2) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar3 + 0xb0) == 0) {
      local_498 = CONCAT44(local_498._4_4_,0x138);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = FUN_140006cc0(*(undefined8 *)(lVar3 + 0xb0));
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar4 + 0xb0) == 0) {
      local_498 = CONCAT44(local_498._4_4_,0x138);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar4 = FUN_140006cc0(*(undefined8 *)(lVar4 + 0xb0));
    (**(code **)(*param_2 + 8))(param_2);
    (**(code **)(param_2[2] + 0x18))(param_2 + 2);
    local_498 = lVar2 - lVar4;
    tq::MyLogSave("gmlog/Slot",
                  "message-->CSlotMgr::CheckInMoneyToStorage. user(%s,%u) storage money full, money(%I64d) lost!"
                 );
    lVar2 = lVar3;
  }
  else if (lVar2 < 1) {
    (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR(
                      "CSlotMgr::CheckInMoneyToStorage: money is less than 0,storage money=%I64d,n64Money=%I64d,user=%u"
                      );
    return;
  }
  FUN_140371790(param_2 + 0x1cf,lVar2,0);
  FUN_140424450(local_478);
  cVar1 = FUN_1404245b0(local_478,1,param_3,param_4 & 0xffffffff);
  if (cVar1 != '\0') {
    (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
  }
  FUN_1404244a0(local_478);
  return;
}

// ==== CMsgSlotOpt::helper_140250850  @140250850  [medium:callgraph-r1]  (orig: FUN_140250850)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140250850(longlong param_1,longlong param_2,undefined4 param_3,int param_4,uint param_5,
                  undefined4 param_6)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  IStringManager *pIVar4;
  char *pcVar5;
  undefined1 auStack_2068 [32];
  undefined8 local_2048;
  undefined4 local_2040;
  longlong local_2038 [2];
  char local_2028;
  undefined1 local_2027 [1022];
  undefined1 local_1c29;
  char local_1c28;
  undefined1 local_1c27 [1022];
  undefined1 local_1829;
  char local_1828;
  undefined1 local_1827 [1022];
  undefined1 local_1429;
  char local_1428;
  undefined1 local_1427 [1022];
  undefined1 local_1029;
  char local_1028;
  undefined1 local_1027 [1022];
  undefined1 local_c29;
  char local_c28;
  undefined1 local_c27 [1022];
  undefined1 local_829;
  char local_828;
  undefined1 local_827 [1022];
  undefined1 local_429;
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  undefined8 uStack_20;
  
  uStack_20 = 0x14025085f;
  local_2038[1] = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_2068;
  if (param_2 != 0) {
    local_2038[0] = 0;
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    plVar3 = (longlong *)FUN_1400875f0(uVar2);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x30))(plVar3);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x40))(plVar3,param_3);
    if (plVar3 != (longlong *)0x0) {
      cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,local_2038);
      if ((cVar1 != '\0') && (local_2038[0] != 0)) {
        if (param_4 == 0) {
          if (param_5 < 0x3c) {
            local_828 = (char)param_4;
            memset(local_827,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_MONEY_1250");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_828,0x400,pcVar5);
            local_429 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_828,0xffffffff,0);
          }
          else if (param_5 < 500) {
            local_1828 = '\0';
            memset(local_1827,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_MONEY_6250");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_1828,0x400,pcVar5);
            local_1429 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_1828,0xffffffff,0);
          }
          else if (param_5 < 1000) {
            local_2028 = '\0';
            memset(local_2027,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_MONEY_12500");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_2028,0x400,pcVar5);
            local_1c29 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_2028,0xffffffff,0);
          }
          else if (param_5 < 0xbb9) {
            local_1028 = '\0';
            memset(local_1027,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_MONEY_666_665");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_1028,0x400,pcVar5);
            local_c29 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_1028,0xffffffff,0);
          }
        }
        else if (param_4 == 1) {
          if (param_5 < 0x3c) {
            local_1c28 = '\0';
            memset(local_1c27,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_EMONEY_270");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_1c28,0x400,pcVar5);
            local_1829 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_1c28,0xffffffff,0);
          }
          else if (param_5 < 500) {
            local_1428 = '\0';
            memset(local_1427,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_EMONEY_1350");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_1428,0x400,pcVar5);
            local_1029 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_1428,0xffffffff,0);
          }
          else if (param_5 < 1000) {
            local_c28 = '\0';
            memset(local_c27,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_EMONEY_2700");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_c28,0x400,pcVar5);
            local_829 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_c28,0xffffffff,0);
          }
          else if (param_5 < 0xbb9) {
            local_428 = '\0';
            memset(local_427,0,0x3ff);
            pIVar4 = theInstance();
            uVar2 = (**(code **)(*(longlong *)(local_2038[0] + 0x10) + 0x18))();
            (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))((longlong *)(param_2 + 0x10));
            pcVar5 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_SLOT_EMONEY_666_665");
            local_2040 = param_6;
            local_2048 = uVar2;
            _snprintf(&local_428,0x400,pcVar5);
            local_29 = 0;
            plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
            local_2040 = 0x7db;
            local_2048 = CONCAT44(local_2048._4_4_,0xff0000);
            (**(code **)(*plVar3 + 0x60))(plVar3,&local_428,0xffffffff,0);
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgSlotOpt::helper_140251e60  @140251e60  [medium:callgraph-r3]  (orig: FUN_140251e60)
undefined8 *
FUN_140251e60(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             void *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x48);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    memcpy(puVar1 + 3,param_5,0x2c);
    *(undefined1 *)((longlong)puVar1 + 0x44) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x45) = 0;
  }
  return puVar1;
}

// ==== CMsgSlotOpt::helper_140252db0  @140252db0  [medium:callgraph-r2]  (orig: FUN_140252db0)
undefined8 * FUN_140252db0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x45) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x45) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x45) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x45) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x45) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x45) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMsgSlotOpt::helper_140253ec0  @140253ec0  [medium:callgraph-r2]  (orig: FUN_140253ec0)
undefined8 *
FUN_140253ec0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x5d1745d1745d172 < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140251e60(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x44);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x44) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x44) = 1;
        *(undefined1 *)(lVar4 + 0x44) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x44) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x45) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x44) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x44) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x45) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x44) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x44) = 1;
        *(undefined1 *)(lVar4 + 0x44) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x44) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x45) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x44) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x44) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x45) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x44);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x44) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgSlotOpt::helper_140254f70  @140254f70  [medium:callgraph-r1]  (orig: FUN_140254f70)
longlong * FUN_140254f70(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x45) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x45) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1402550cd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1402550fc;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x45) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x45) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x45);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x45);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x45);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x45);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x45) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x45) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1402550cd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140253ec0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1402550fc:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CMsgSlotOpt::helper_140255120  @140255120  [medium:callgraph-r1]  (orig: FUN_140255120)
longlong FUN_140255120(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140252db0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x45) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x45) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x45);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x45);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x45);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x45);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140253cb0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMsgSlotOpt::helper_140255ad0  @140255ad0  [medium:callgraph-r1]  (orig: FUN_140255ad0)
ulonglong FUN_140255ad0(longlong param_1,uint param_2,undefined4 *param_3)

{
  char cVar1;
  undefined4 uVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 *puVar5;
  ulonglong uVar6;
  undefined8 *puVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  ulonglong local_10;
  
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x88))[1];
  cVar1 = *(char *)((longlong)puVar10 + 0x31);
  puVar5 = *(undefined8 **)(param_1 + 0x88);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar10[2];
      puVar10 = puVar5;
    }
    else {
      puVar7 = (undefined8 *)*puVar10;
    }
    puVar5 = puVar10;
    puVar10 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x31);
  }
  puVar10 = *(undefined8 **)(param_1 + 0x88);
  local_30 = puVar5;
  local_38 = *(longlong *)(param_1 + 0x58);
  if (*(longlong *)(param_1 + 0x58) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar5 == puVar10) || (param_2 < *(uint *)(puVar5 + 3))) {
    plVar9 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x88);
    local_28 = *(longlong *)(param_1 + 0x58);
  }
  else {
    plVar9 = &local_38;
  }
  plVar3 = (longlong *)*plVar9;
  uVar4 = *(ulonglong *)(param_1 + 0x88);
  local_18 = plVar3;
  uVar8 = plVar9[1];
  local_10 = uVar8;
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x58))) {
    _invalid_parameter_noinfo();
    uVar8 = extraout_RAX;
  }
  uVar6 = local_10;
  if (local_10 == uVar4) {
    uVar8 = uVar8 & 0xffffffffffffff00;
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar3;
    }
    if (uVar6 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *param_3 = *(undefined4 *)(uVar6 + 0x1c);
    param_3[1] = *(undefined4 *)(uVar6 + 0x20);
    param_3[2] = *(undefined4 *)(uVar6 + 0x24);
    param_3[3] = *(undefined4 *)(uVar6 + 0x28);
    uVar2 = *(undefined4 *)(uVar6 + 0x2c);
    param_3[4] = uVar2;
    uVar8 = CONCAT71((uint7)(uint3)((uint)uVar2 >> 8),1);
  }
  return uVar8;
}

// ==== CMsgSlotOpt::helper_140255c10  @140255c10  [medium:callgraph-r1]  (orig: FUN_140255c10)
bool FUN_140255c10(longlong param_1,uint param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x45);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar6 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar6[2];
      puVar6 = puVar3;
    }
    else {
      puVar4 = (undefined8 *)*puVar6;
    }
    puVar3 = puVar6;
    puVar6 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x45);
  }
  puVar6 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar6) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar5 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar5 = &local_38;
  }
  local_18 = *plVar5;
  lVar2 = *(longlong *)(param_1 + 0x48);
  local_10 = plVar5[1];
  if ((local_18 == 0) || (local_18 != *(longlong *)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  return local_10 != lVar2;
}

// ==== CMsgSlotOpt::helper_140255cf0  @140255cf0  [medium:callgraph-r1]  (orig: FUN_140255cf0)
undefined8 FUN_140255cf0(longlong param_1,uint param_2,void *param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x48))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x45);
  puVar3 = *(undefined8 **)(param_1 + 0x48);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x45);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x48);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x18);
  if (*(longlong *)(param_1 + 0x18) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x48);
    local_28 = *(longlong *)(param_1 + 0x18);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x48);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x18))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    memcpy(param_3,(void *)(lVar4 + 0x1c),0x28);
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgSlotOpt::helper_140255e10  @140255e10  [medium:callgraph-r0]  (orig: FUN_140255e10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140255e10(longlong param_1,longlong *param_2,int param_3,char param_4)

{
  ushort uVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  uint uVar11;
  ulonglong uVar12;
  longlong *plVar13;
  uint uVar14;
  uint uVar15;
  undefined1 auStack_508 [32];
  undefined8 local_4e8;
  uint local_4e0;
  uint local_4d8;
  uint local_4d0;
  char local_4c8;
  int local_4c4;
  int local_4c0;
  char local_4bc;
  uint local_4b8;
  uint local_4b4;
  int local_4b0;
  uint local_4ac;
  ushort local_4a8;
  int local_4a4;
  undefined4 local_4a0;
  undefined4 local_49c;
  ulonglong local_498;
  longlong local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  if (((param_2 != (longlong *)0x0) && (*(longlong *)(param_1 + 0x10) != 0)) &&
     ((byte)(param_4 - 1U) < 3)) {
    local_4c0 = 0;
    local_4bc = '\0';
    local_4b8 = 0;
    local_4b4 = 0;
    local_4b0 = 0;
    local_4ac = 0;
    local_4a8 = 0;
    local_4a4 = 0;
    local_49c = 0;
    local_4a0 = 0;
    local_4c4 = param_3;
    local_490 = param_1;
    uVar3 = (**(code **)(*param_2 + 8))(param_2);
    cVar2 = FUN_140255cf0(param_1,uVar3,&local_4c0);
    if (cVar2 != '\0') {
      if ((local_4c0 == param_3) && (local_4bc == param_4)) {
        uVar3 = (**(code **)(*param_2 + 8))(param_2);
        local_498 = CONCAT44(local_498._4_4_,uVar3);
        FUN_140255120(param_1 + 0x18,&local_498);
        uVar1 = local_4a8;
        (**(code **)(*param_2 + 8))(param_2);
        (**(code **)(param_2[2] + 0x18))(param_2 + 2);
        local_4d0 = (uint)uVar1;
        local_4d8 = local_4ac;
        local_4e0 = local_4b8;
        local_4e8._0_4_ = local_4b4;
        tq::MyLogSave("gmlog/Slot",
                      "message-->CSlotMgr::ProcessSettle. Settle Info,  UserName(%s), UserID(%u), CurrencyType(%d),BetCurrencyNum(%u), Multiple(%u), Pattern(%u)"
                     );
        local_4c8 = '\0';
        if (local_4ac == 0) {
          if (local_4b4 == 1) {
            if (local_4a4 == 1) {
              plVar13 = DAT_140975be0;
              if (DAT_140975be0 == (longlong *)0x0) {
                local_4e8._0_4_ = 0x3c5;
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar13 = (longlong *)0x0;
              }
              uVar14 = FUN_14014df00(plVar13,0);
              uVar15 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
              if (uVar15 < uVar14) {
                pIVar9 = theInstance();
                lVar6 = param_2[2];
                uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SLOT_LOTTERY_AWARD_EXP");
                (**(code **)(lVar6 + 0x358))(param_2 + 2,uVar7,local_4b0);
                FUN_1401ad760(param_2,local_4b0 * 10);
              }
            }
            else if (local_4a4 == 2) {
              plVar13 = DAT_140975b60;
              if (DAT_140975b60 == (longlong *)0x0) {
                local_4e8._0_4_ = 0x3c0;
                log_InlineLogERROR(&DAT_1406d9c10);
                plVar13 = (longlong *)0x0;
              }
              lVar6 = *plVar13;
              local_4d8 = CONCAT31(local_4d8._1_3_,1);
              local_4e0 = 0;
              local_4e8._0_4_ = 1;
              uVar3 = FUN_14034a8d0(param_2,local_4b0,0,1);
              lVar6 = (**(code **)(lVar6 + 0x60))(plVar13,uVar3);
              if (lVar6 != 0) {
                pIVar9 = theInstance();
                lVar8 = param_2[2];
                uVar7 = FUN_140100430(lVar6,0x65);
                uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_GOT_ITEM");
                (**(code **)(lVar8 + 0x358))(param_2 + 2,uVar10,uVar7);
              }
            }
          }
        }
        else if (local_4b4 == 0) {
          uVar14 = local_4b8 * local_4ac;
          lVar6 = (**(code **)(*param_2 + 0x60))(param_2);
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          uVar7 = FUN_1400d6610(uVar7);
          lVar8 = FUN_140006cc0(uVar7);
          if (lVar8 < (longlong)((ulonglong)uVar14 + lVar6)) {
            uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            uVar7 = FUN_1400d6610(uVar7);
            iVar4 = FUN_140006cc0(uVar7);
            iVar5 = (**(code **)(*param_2 + 0x60))(param_2);
            local_498 = (ulonglong)(uint)(iVar4 - iVar5);
            uVar11 = uVar14 - (iVar4 - iVar5);
            FUN_140250640(param_1,param_2,local_4c4,uVar11);
            local_4c8 = '\x01';
            (**(code **)(*param_2 + 8))(param_2);
            (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            local_4e8._0_4_ = uVar11;
            tq::MyLogSave("gmlog/Slot",
                          "message-->CSlotMgr::ProcessSettle. user(%s,%u) check in money(%u) to storage for slot lottery!"
                         );
            uVar15 = *(uint *)(param_2 + 0x1e2);
            (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            (**(code **)(*param_2 + 8))(param_2);
            local_4e0 = uVar11;
            local_4e8._0_4_ = uVar15;
            tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4280\t0\t0\t-%u\t");
            uVar12 = local_498;
          }
          else {
            uVar12 = (ulonglong)uVar14;
          }
          cVar2 = (**(code **)(*param_2 + 0x180))(param_2,uVar12 & 0xffffffff,1);
          if (cVar2 == '\0') {
            return;
          }
          (**(code **)(*param_2 + 8))(param_2);
          (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          local_4e0 = uVar14;
          local_4e8._0_4_ = (uint)uVar12;
          tq::MyLogSave("gmlog/Slot",
                        "message-->CSlotMgr::ProcessSettle. user(%s,%u) gain money(%u) WinningMoney(%u)!"
                       );
          uVar15 = *(uint *)(param_2 + 0x1e2);
          (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          (**(code **)(*param_2 + 8))(param_2);
          local_4e0 = (uint)uVar12;
          local_4e8._0_4_ = uVar15;
          tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4280\t0\t0\t-%u\t");
          if (0x27 < local_4ac) {
            local_4e8._0_4_ = local_4ac;
            local_4e0 = uVar14;
            FUN_140250850(param_1,param_2,local_4c4,0);
          }
          if (local_4c8 != '\0') {
            return;
          }
        }
        else if (local_4b4 == 1) {
          uVar15 = local_4b8 * local_4ac;
          uVar14 = uVar15;
          if (1000000000 < *(int *)((longlong)param_2 + 0xfa4) + uVar15) {
            uVar14 = 1000000000 - *(int *)((longlong)param_2 + 0xfa4);
            (**(code **)(*param_2 + 8))(param_2);
            (**(code **)(param_2[2] + 0x18))(param_2 + 2);
            local_4e8 = CONCAT44(local_4e8._4_4_,uVar15 - uVar14);
            tq::MyLogSave("gmlog/Slot",
                          "message-->CSlotMgr::ProcessSettle. user(%s,%u) emoney full, emoney(%u) lost!"
                         );
          }
          local_4e8 = 0;
          cVar2 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,uVar14,1);
          if (cVar2 == '\0') {
            return;
          }
          uVar3 = (**(code **)(*param_2 + 8))(param_2);
          local_4e8._0_4_ = uVar14;
          FUN_1401742b0(param_2,0x33,0,uVar3);
          uVar11 = *(uint *)(param_2 + 0x1e2);
          (**(code **)(param_2[2] + 0x18))(param_2 + 2);
          (**(code **)(*param_2 + 8))(param_2);
          local_4e0 = -uVar14;
          local_4d8 = -uVar14;
          local_4e8._0_4_ = uVar11;
          tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5003\t%d\t%d\t1\t");
          if (0x27 < local_4ac) {
            local_4e8._0_4_ = local_4ac;
            local_4e0 = uVar15;
            FUN_140250850(local_490,param_2,local_4c4,1);
          }
        }
        FUN_140424450(local_478);
        cVar2 = FUN_1404245b0(local_478,1,local_4c4,0);
        if (cVar2 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
        }
        FUN_1404244a0(local_478);
      }
      else {
        FUN_140424690(local_478);
        cVar2 = FUN_140424750(local_478,1,2);
        if (cVar2 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
        }
        FUN_1404246e0(local_478);
      }
    }
  }
  return;
}

// ==== CMsgSlotOpt::helper_140257070  @140257070  [medium:callgraph-r0]  (orig: FUN_140257070)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140257070(longlong param_1,longlong *param_2,uint param_3,byte param_4)

{
  longlong *plVar1;
  int iVar2;
  uint uVar3;
  char cVar4;
  undefined4 uVar5;
  ulong uVar6;
  longlong lVar7;
  uint uVar8;
  undefined1 auStack_978 [32];
  undefined8 local_958;
  uint local_950;
  uint local_948;
  undefined1 local_938;
  char local_937;
  char local_936;
  ushort local_934 [2];
  byte local_930;
  undefined4 local_92c;
  undefined1 local_928 [4];
  uint local_924;
  int local_920;
  int local_91c;
  int local_918;
  uint local_910;
  uint local_908;
  byte local_904;
  uint local_900;
  int local_8fc;
  int local_8f8;
  undefined4 local_8f4;
  ushort local_8f0;
  int local_8ec;
  undefined4 local_8e8;
  uint local_8e4;
  undefined8 local_8e0;
  undefined4 local_8d8;
  undefined1 local_8d4 [44];
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8e0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_978;
  if (((param_2 != (longlong *)0x0) && (*(longlong *)(param_1 + 0x10) != 0)) &&
     ((byte)(param_4 - 1) < 3)) {
    local_930 = param_4;
    local_910 = param_3;
    uVar5 = (**(code **)(*param_2 + 8))(param_2);
    cVar4 = FUN_140255c10(param_1,uVar5);
    if (cVar4 == '\0') {
      cVar4 = FUN_14024f480(param_1,param_2,param_3);
      if (cVar4 == '\0') {
        FUN_140424690(local_8a8);
        cVar4 = FUN_140424750(local_8a8,1);
        if (cVar4 != '\0') {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
        }
        FUN_1404246e0(local_8a8);
      }
      else {
        cVar4 = FUN_140250570(param_1,param_3);
        if (cVar4 == '\0') {
          FUN_140424690(local_8a8);
          cVar4 = FUN_140424750(local_8a8,1,2);
          if (cVar4 != '\0') {
            (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
          }
          tq::MyLogSave("gmlog/Slot","error-->CSlotMgr::ProcessSlotLottery. is slot npc not exist!")
          ;
          FUN_1404246e0(local_8a8);
        }
        else {
          local_928[0] = 0;
          local_924 = 0;
          local_920 = 0;
          local_91c = 0;
          local_918 = 0;
          cVar4 = FUN_140255ad0(param_1,param_3,local_928);
          if (cVar4 == '\0') {
            FUN_140424690(local_8a8);
            cVar4 = FUN_140424750(local_8a8,1,2);
            if (cVar4 != '\0') {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
            }
            FUN_1404246e0(local_8a8);
          }
          else {
            uVar8 = local_924 * param_4;
            if (local_918 == 1) {
              local_91c = local_91c * (uint)param_4;
            }
            iVar2 = local_91c;
            local_950 = uVar8;
            local_924 = uVar8;
            local_958._0_4_ = uVar8;
            if (local_920 == 0) {
              lVar7 = (**(code **)(*param_2 + 0x60))(param_2);
              if (lVar7 < (longlong)(ulonglong)uVar8) {
                FUN_140424690(local_8a8);
                cVar4 = FUN_140424750(local_8a8,1,3);
                if (cVar4 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
                }
                FUN_1404246e0(local_8a8);
                return;
              }
              cVar4 = (**(code **)(*param_2 + 0x178))(param_2,(ulonglong)uVar8,1);
              if (cVar4 == '\0') {
                return;
              }
              plVar1 = param_2 + 2;
              (**(code **)(*param_2 + 8))(param_2);
              (**(code **)(*plVar1 + 0x18))(plVar1);
              tq::MyLogSave("gmlog/Slot",
                            "message-->CSlotMgr::ProcessSlotLottery. user(%s,%u) spend money(%u) for slot lottery!"
                           );
              lVar7 = param_2[0x1e2];
              (**(code **)(*plVar1 + 0x18))(plVar1);
              (**(code **)(*param_2 + 8))(param_2);
              local_958 = CONCAT44(local_958._4_4_,(int)lVar7);
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4280\t0\t0\t%u\t");
            }
            else {
              if (local_920 != 1) {
                tq::MyLogSave("gmlog/Slot",
                              "error-->CSlotMgr::ProcessSlotLottery. Currency Type Error!");
                return;
              }
              if (*(uint *)((longlong)param_2 + 0xfa4) < uVar8) {
                FUN_140424690(local_8a8);
                cVar4 = FUN_140424750(local_8a8,1,3);
                if (cVar4 != '\0') {
                  (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_8a8);
                }
                FUN_1404246e0(local_8a8);
                return;
              }
              plVar1 = param_2 + 2;
              local_958 = 0;
              cVar4 = (**(code **)(*plVar1 + 0x2e0))(plVar1,0x1d,(longlong)(int)-uVar8,1);
              if (cVar4 == '\0') {
                return;
              }
              uVar5 = (**(code **)(*param_2 + 8))(param_2);
              FUN_1401742b0(param_2,0x33,uVar5);
              lVar7 = param_2[0x1e2];
              (**(code **)(*plVar1 + 0x18))(plVar1);
              (**(code **)(*param_2 + 8))(param_2);
              local_958 = CONCAT44(local_958._4_4_,(int)lVar7);
              local_948 = uVar8;
              tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t5000\t5003\t%u\t%d\t1\t");
            }
            local_934[0] = 0;
            local_92c = 0;
            FUN_140423b40(*(undefined8 *)(param_1 + 0x10),local_928[0],local_934,&local_92c);
            uVar3 = local_910;
            local_8e4 = 0;
            local_908 = local_910;
            local_904 = local_930;
            local_8fc = local_920;
            local_8ec = local_918;
            local_8f4 = local_92c;
            local_8f0 = local_934[0];
            local_8e8 = 0x3c;
            local_900 = uVar8;
            local_8f8 = iVar2;
            uVar6 = tq::TimeGet(0);
            local_8e4 = uVar6 / 1000;
            local_8d8 = (**(code **)(*param_2 + 8))(param_2);
            memcpy(local_8d4,&local_908,0x28);
            FUN_140254f70(param_1 + 0x18,local_928,&local_8d8);
            uVar8 = (uint)local_934[0] % 100;
            local_938 = (undefined1)(local_934[0] / 100);
            local_937 = (char)(uVar8 / 10);
            local_936 = (char)uVar8 + local_937 * -10;
            FUN_140424450(local_478);
            cVar4 = FUN_140424510(local_478,0,uVar3,&local_938);
            if (cVar4 != '\0') {
              (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
            }
            FUN_1404244a0(local_478);
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgSlotOpt::helper_140423840  @140423840  [medium:callgraph-r2]  (orig: FUN_140423840)
undefined4 FUN_140423840(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x80))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x80);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x80);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x50);
  if (*(longlong *)(param_1 + 0x50) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x80);
    local_28 = *(longlong *)(param_1 + 0x50);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x80);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x50))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CMsgSlotOpt::helper_140423b40  @140423b40  [medium:callgraph-r1]  (orig: FUN_140423b40)
void FUN_140423b40(longlong param_1,byte param_2,undefined2 *param_3,undefined4 *param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined2 uVar3;
  ulong uVar4;
  int iVar5;
  uint uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  uint uVar11;
  byte local_res10 [8];
  longlong *local_58;
  longlong local_50;
  longlong *local_48;
  longlong *local_38;
  
  local_res10[0] = param_2;
  uVar4 = tq::TimeGet(0);
  iVar5 = rand();
  srand(iVar5 + uVar4 + (uint)param_2);
  iVar5 = FUN_140423840(param_1,param_2);
  uVar6 = tq::RandGet(iVar5);
  uVar11 = 0;
  FUN_1403f4d90(param_1 + 0x10,&local_58,local_res10);
  lVar10 = *(longlong *)(param_1 + 0x40);
  local_48 = *(longlong **)(param_1 + 0x10);
  if ((local_58 == (longlong *)0x0) || (local_58 != local_48)) {
    _invalid_parameter_noinfo();
  }
  if (local_50 == lVar10) {
    return;
  }
  if (local_58 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar10 = 0;
  }
  else {
    lVar10 = *local_58;
  }
  if (local_50 == *(longlong *)(lVar10 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  plVar9 = *(longlong **)(local_50 + 0x38);
  local_58 = (longlong *)0x0;
  if (*(longlong **)(local_50 + 0x40) < plVar9) {
    _invalid_parameter_noinfo();
  }
  plVar1 = *(longlong **)(local_50 + 0x20);
  local_58 = plVar1;
  while( true ) {
    plVar2 = *(longlong **)(local_50 + 0x40);
    local_38 = (longlong *)0x0;
    if (plVar2 < *(longlong **)(local_50 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    local_38 = *(longlong **)(local_50 + 0x20);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_38)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)*plVar9;
    if (plVar2 != (longlong *)0x0) {
      plVar8 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,3);
      iVar5 = (**(code **)(*plVar8 + 0x50))(plVar8);
      uVar11 = uVar11 + iVar5;
      if (uVar6 < uVar11) {
        plVar9 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
        uVar3 = (**(code **)(*plVar9 + 0x30))(plVar9);
        *param_3 = uVar3;
        plVar9 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
        uVar7 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *param_4 = uVar7;
        return;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
      _invalid_parameter_noinfo();
    }
    plVar9 = plVar9 + 1;
  }
  return;
}

// ==== CMsgSlotOpt::helper_140424510  @140424510  [medium:callgraph-r1]  (orig: FUN_140424510)
ulonglong FUN_140424510(longlong param_1,undefined1 param_2,undefined4 param_3,undefined1 *param_4)

{
  ulonglong in_RAX;
  ulonglong uVar1;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar1 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x548;
    *(undefined4 *)(param_1 + 0xc) = 0xc;
    **(undefined1 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = *param_4;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 2) = param_4[1];
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 3) = param_4[2];
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CMsgSlotOpt::helper_1404245b0  @1404245b0  [medium:callgraph-r1]  (orig: FUN_1404245b0)
ulonglong FUN_1404245b0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x548;
    *(undefined4 *)(param_1 + 0xc) = 0xc;
    **(undefined1 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    lVar1 = *(longlong *)(param_1 + 0x428);
    *(undefined4 *)(lVar1 + 4) = param_4;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CMsgSlotOpt::ctor_or_dtor  @140424690  [high:vtable-assign]  (orig: FUN_140424690)
undefined8 * FUN_140424690(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgSlotOpt::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgSlotOpt::ctor_or_dtor  @1404246e0  [high:vtable-assign]  (orig: FUN_1404246e0)
void FUN_1404246e0(undefined8 *param_1)

{
  *param_1 = CMsgSlotOpt::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgSlotOpt::vfunc_1  @140424710  [high:rtti-vtable]  (orig: FUN_140424710)
bool FUN_140424710(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x547;
    }
  }
  return false;
}

// ==== CMsgSlotOpt::helper_140424750  @140424750  [medium:callgraph-r1]  (orig: FUN_140424750)
ulonglong FUN_140424750(longlong param_1,undefined1 param_2,undefined1 param_3)

{
  longlong lVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x547;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 1) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgSlotOpt::ctor_or_dtor  @1404247c0  [high:vtable-assign]  (orig: FUN_1404247c0)
undefined8 * FUN_1404247c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgSlotOpt::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgSlotOpt::vfunc_3  @140424810  [high:rtti-vtable]  (orig: FUN_140424810)
void FUN_140424810(longlong param_1)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  IStringManager *pIVar5;
  longlong lVar6;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar3 = (longlong *)FUN_140087650(uVar2);
    lVar4 = (**(code **)(*plVar3 + 0x88))(plVar3,param_1);
    if (lVar4 != 0) {
      cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x220))(lVar4 + 0x10);
      if (cVar1 == '\0') {
        pIVar5 = theInstance();
        lVar6 = *(longlong *)(lVar4 + 0x10);
        uVar2 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE");
        (**(code **)(lVar6 + 0x358))(lVar4 + 0x10,uVar2);
      }
      else if (**(char **)(param_1 + 0x428) == '\0') {
        lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar6 + 0x1b8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar6 + 0x1b8);
        }
        FUN_140257070(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1));
      }
      else if (**(char **)(param_1 + 0x428) == '\x02') {
        lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        if (*(longlong *)(lVar6 + 0x1b8) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar2 = 0;
        }
        else {
          uVar2 = *(undefined8 *)(lVar6 + 0x1b8);
        }
        FUN_140255e10(uVar2,lVar4,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4),
                      *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1));
      }
    }
  }
  return;
}

