// ==== CCrossMsgPowerAttribAndValue::helper_1401dd400  @1401dd400  [medium:callgraph-r1]  (orig: FUN_1401dd400)
void FUN_1401dd400(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 4) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  return;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401dd460  @1401dd460  [medium:callgraph-r3]  (orig: FUN_1401dd460)
undefined8 *
FUN_1401dd460(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined8 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x28);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    puVar1[3] = *param_5;
    *(undefined1 *)(puVar1 + 4) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x21) = 0;
  }
  return puVar1;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401deb60  @1401deb60  [medium:callgraph-r2]  (orig: FUN_1401deb60)
undefined8 * FUN_1401deb60(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x21) == '\0') {
    puVar1 = (undefined8 *)
             FUN_1401dd460(param_1,puVar3,param_3,puVar3,param_2 + 3,*(undefined1 *)(param_2 + 4),
                           0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x21) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_1401deb60(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_1401deb60(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401e0110  @1401e0110  [medium:callgraph-r1]  (orig: FUN_1401e0110)
void FUN_1401e0110(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1401deb60(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x21) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x21);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x21);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x21);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x21);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401ee5e0  @1401ee5e0  [medium:callgraph-r3]  (orig: FUN_1401ee5e0)
undefined8 *
FUN_1401ee5e0(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0x38e38e38e38e38c < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1401ee500(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x60);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x60) == '\0') {
        *(undefined1 *)(plVar2 + 0xc) = 1;
        *(undefined1 *)(lVar4 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x61) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x61) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x60) == '\0') {
        *(undefined1 *)(plVar2 + 0xc) = 1;
        *(undefined1 *)(lVar4 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x61) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x60) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x60) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x61) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x60);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x60) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401ee960  @1401ee960  [medium:callgraph-r3]  (orig: FUN_1401ee960)
longlong * FUN_1401ee960(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x61) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x61) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_1401eeabd:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_1401eeaec;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x61) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x61) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x61);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x61);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x61);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x61);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x61) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x61) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_1401eeabd;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_1401ee5e0(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_1401eeaec:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401eef50  @1401eef50  [medium:callgraph-r2]  (orig: FUN_1401eef50)
undefined8 * FUN_1401eef50(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  uint uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_1401ee5e0(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_1401ee5e0(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_1401ee5e0(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar7 = *param_4;
        if (uVar7 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)local_30 + 0x61) == '\0') {
            plVar8 = (longlong *)*local_30;
            if (*(char *)((longlong)plVar8 + 0x61) == '\0') {
              cVar1 = *(char *)(plVar8[2] + 0x61);
              plVar9 = (longlong *)plVar8[2];
              while (local_30 = plVar8, cVar1 == '\0') {
                cVar1 = *(char *)(plVar9[2] + 0x61);
                plVar8 = plVar9;
                plVar9 = (longlong *)plVar9[2];
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x61);
              plVar4 = (longlong *)local_30[1];
              plVar9 = local_30;
              while ((plVar8 = plVar4, cVar1 == '\0' && (plVar9 == (longlong *)*plVar8))) {
                cVar1 = *(char *)(plVar8[1] + 0x61);
                plVar4 = (longlong *)plVar8[1];
                plVar9 = plVar8;
              }
              local_30 = plVar8;
              if (*(char *)((longlong)plVar9 + 0x61) != '\0') {
                local_30 = plVar9;
                _invalid_parameter_noinfo();
                plVar8 = plVar9;
              }
            }
          }
          else {
            plVar8 = (longlong *)local_30[2];
            local_30 = plVar8;
            if (*(char *)((longlong)plVar8 + 0x61) != '\0') {
              _invalid_parameter_noinfo();
            }
          }
          uVar7 = *param_4;
          if (*(uint *)(plVar8 + 3) < uVar7) {
            if (*(char *)(plVar8[2] + 0x61) != '\0') {
              FUN_1401ee5e0(param_1,param_2,0,plVar8,param_4);
              return param_2;
            }
            FUN_1401ee5e0(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar7) {
          local_38 = *param_3;
          plVar8 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x61) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x61);
              plVar4 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar4 + 0x61);
                plVar9 = plVar4;
                plVar4 = (longlong *)*plVar4;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x61);
              plVar5 = (longlong *)local_30[1];
              plVar4 = local_30;
              while ((plVar9 = plVar5, cVar1 == '\0' && (plVar4 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x61);
                plVar5 = (longlong *)plVar9[1];
                plVar4 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar8) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x61) != '\0') {
              FUN_1401ee5e0(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_1401ee5e0(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar6 = (undefined8 *)FUN_1401ee960(param_1,&local_38,param_4);
    *param_2 = *puVar6;
    param_2[1] = puVar6[1];
  }
  return param_2;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401f04c0  @1401f04c0  [medium:callgraph-r1]  (orig: FUN_1401f04c0)
undefined8 * FUN_1401f04c0(undefined8 *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong *local_108;
  undefined8 *puStack_100;
  longlong *local_f8;
  undefined8 *puStack_f0;
  longlong *local_e8;
  undefined8 *puStack_e0;
  longlong *local_d8 [6];
  undefined8 *local_a8;
  undefined8 local_a0;
  undefined8 local_98;
  uint local_90 [2];
  void *local_88 [8];
  undefined1 local_48 [16];
  undefined1 local_38 [16];
  
  local_98 = 0xfffffffffffffffe;
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x61) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x61) == '\0');
  }
  plVar3 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  local_f8 = plVar3;
  puStack_f0 = puVar4;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar5 = (longlong *)0x0;
  if ((puVar4 == puVar1) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_108 = local_f8;
    puStack_100 = puStack_f0;
    plVar3 = operator_new(8);
    local_d8[0] = plVar5;
    if (plVar3 != (longlong *)0x0) {
      *plVar3 = (longlong)local_d8;
      local_d8[0] = plVar3;
    }
    local_a8 = (undefined8 *)FUN_1401dd400(local_d8);
    *(undefined1 *)((longlong)local_a8 + 0x21) = 1;
    local_a8[1] = local_a8;
    *local_a8 = local_a8;
    local_a8[2] = local_a8;
    local_a0 = 0;
    local_90[0] = *param_2;
    FUN_1401e8c10(local_88,local_d8);
    puVar4 = (undefined8 *)FUN_1401eef50(param_1,local_48,&local_108,local_90);
    local_f8 = (longlong *)*puVar4;
    puStack_f0 = (undefined8 *)puVar4[1];
    FUN_1401e0500(local_88);
    operator_delete(local_88[0]);
    puStack_100 = (undefined8 *)*local_a8;
    local_e8 = local_d8[0];
    puStack_e0 = local_a8;
    local_108 = local_d8[0];
    FUN_1401dff20(local_d8,local_38,&local_108,&local_e8);
    operator_delete(local_a8);
    local_a8 = (undefined8 *)0x0;
    local_a0 = 0;
    operator_delete(local_d8[0]);
    puVar4 = puStack_f0;
    plVar3 = local_f8;
  }
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    plVar5 = (longlong *)*plVar3;
  }
  if (puVar4 == (undefined8 *)plVar5[6]) {
    _invalid_parameter_noinfo();
  }
  return puVar4 + 4;
}

// ==== CCrossMsgPowerAttribAndValue::helper_1401f15a0  @1401f15a0  [medium:callgraph-r0]  (orig: FUN_1401f15a0)
void FUN_1401f15a0(longlong param_1,undefined4 param_2,uint param_3,undefined1 *param_4)

{
  longlong **pplVar1;
  ulonglong uVar2;
  undefined4 local_res10 [2];
  undefined8 local_88;
  longlong lStack_80;
  longlong *local_78;
  longlong *plStack_70;
  longlong *local_68 [6];
  undefined8 *local_38;
  undefined8 local_30;
  undefined1 local_28 [24];
  undefined8 local_10;
  
  if (param_3 != 0) {
    local_10 = 0xfffffffffffffffe;
    uVar2 = (ulonglong)param_3;
    local_res10[0] = param_2;
    local_88 = operator_new(8);
    if (local_88 == (longlong *)0x0) {
      local_68[0] = (longlong *)0x0;
    }
    else {
      *local_88 = (longlong)local_68;
      local_68[0] = local_88;
    }
    local_78 = local_88;
    local_38 = (undefined8 *)FUN_1401dd400(local_68);
    *(undefined1 *)((longlong)local_38 + 0x21) = 1;
    local_38[1] = local_38;
    *local_38 = local_38;
    local_38[2] = local_38;
    local_30 = 0;
    if (param_3 != 0) {
      do {
        local_88 = (longlong *)CONCAT71(local_88._1_7_,*param_4);
        local_88 = (longlong *)CONCAT44(*(undefined4 *)(param_4 + 4),(undefined4)local_88);
        FUN_1401e2440(local_68,local_28,&local_88);
        param_4 = param_4 + 8;
        uVar2 = uVar2 - 1;
      } while (uVar2 != 0);
    }
    pplVar1 = (longlong **)FUN_1401f04c0(param_1 + 0x210,local_res10);
    if (pplVar1 != local_68) {
      plStack_70 = pplVar1[6];
      local_88 = *pplVar1;
      lStack_80 = *plStack_70;
      local_78 = local_88;
      FUN_1401dff20(pplVar1,local_28,&local_88,&local_78);
      FUN_1401e0110(pplVar1,local_68);
    }
    lStack_80 = *local_38;
    local_78 = local_68[0];
    plStack_70 = local_38;
    local_88 = local_68[0];
    FUN_1401dff20(local_68,local_28,&local_88,&local_78);
    operator_delete(local_38);
    local_38 = (undefined8 *)0x0;
    local_30 = 0;
    operator_delete(local_68[0]);
  }
  return;
}

// ==== CCrossMsgPowerAttribAndValue::ctor_or_dtor  @140402260  [high:vtable-assign]  (orig: FUN_140402260)
undefined8 * FUN_140402260(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgPowerAttribAndValue::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgPowerAttribAndValue::ctor_or_dtor  @1404022b0  [high:vtable-assign]  (orig: FUN_1404022b0)
void FUN_1404022b0(undefined8 *param_1)

{
  *param_1 = CCrossMsgPowerAttribAndValue::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgPowerAttribAndValue::vfunc_1  @1404022e0  [high:rtti-vtable]  (orig: FUN_1404022e0)
undefined8 FUN_1404022e0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgPowerAttribAndValue::ctor_or_dtor  @1404024a0  [high:vtable-assign]  (orig: FUN_1404024a0)
undefined8 * FUN_1404024a0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgPowerAttribAndValue::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgPowerAttribAndValue::vfunc_3  @1404024f0  [high:rtti-vtable]  (orig: FUN_1404024f0)
void FUN_1404024f0(longlong param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar3 = *(undefined4 *)(param_1 + 0x41c);
    uVar1 = *(undefined4 *)(param_1 + 0x420);
    lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar4 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar5 = (longlong *)FUN_1402af110(*(undefined8 *)(lVar4 + 0x90),uVar3,uVar1);
    if (plVar5 == (longlong *)0x0) {
      log_InlineLogOSWARNING
                (
                "CCrossMsgPowerAttribAndValue::Process UserManager GetCreatedOSUser failed. server id:%u, os user id:%u."
                );
    }
    else {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar4 = *(longlong *)(lVar4 + 0x1c0);
      if (lVar4 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      puVar2 = *(undefined4 **)(param_1 + 0x428);
      uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
      FUN_1401f15a0(lVar4,uVar3,*puVar2,puVar2 + 1);
    }
  }
  return;
}

