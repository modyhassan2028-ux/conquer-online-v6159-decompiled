// ==== CMsgMailNotify@mail::vfunc_6  @14035c9b0  [high:rtti-vtable]  (orig: FUN_14035c9b0)
bool FUN_14035c9b0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x417;
    }
  }
  return false;
}

// ==== CMsgMailNotify@mail::vfunc_5  @14035c9f0  [high:rtti-vtable]  (orig: FUN_14035c9f0)
undefined8 FUN_14035c9f0(longlong param_1,undefined2 param_2)

{
  undefined2 *puVar1;
  
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  if (puVar1 == (undefined2 *)0x0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined4 *)(param_1 + 8) = 0x417;
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMsgMailNotify@mail::vfunc_0  @14035ca20  [high:rtti-vtable]  (orig: FUN_14035ca20)
undefined8 * FUN_14035ca20(undefined8 *param_1,uint param_2)

{
  *param_1 = mail::CMsgMailNotify::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

