// ==== CCrossMsgServerName::ctor_or_dtor  @140361c60  [high:vtable-assign]  (orig: FUN_140361c60)
undefined8 * FUN_140361c60(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgServerName::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgServerName::ctor_or_dtor  @140361cb0  [high:vtable-assign]  (orig: FUN_140361cb0)
void FUN_140361cb0(undefined8 *param_1)

{
  *param_1 = CCrossMsgServerName::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgServerName::vfunc_1  @140361ce0  [high:rtti-vtable]  (orig: FUN_140361ce0)
undefined8 FUN_140361ce0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgServerName::vfunc_3  @140361db0  [high:rtti-vtable]  (orig: FUN_140361db0)
void FUN_140361db0(void)

{
  return;
}

// ==== CCrossMsgServerName::ctor_or_dtor  @140361e20  [high:vtable-assign]  (orig: FUN_140361e20)
undefined8 * FUN_140361e20(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgServerName::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

