// ==== CMsgItemInfo::ctor_or_dtor  @140458720  [high:vtable-assign]  (orig: FUN_140458720)
undefined8 * FUN_140458720(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgItemInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgItemInfo::ctor_or_dtor  @140458770  [high:vtable-assign]  (orig: FUN_140458770)
void FUN_140458770(undefined8 *param_1)

{
  *param_1 = CMsgItemInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgItemInfo::vfunc_1  @1404587a0  [high:rtti-vtable]  (orig: FUN_1404587a0)
ulonglong FUN_1404587a0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3f0);
}

// ==== CMsgItemInfo::vfunc_3  @140458a90  [high:rtti-vtable]  (orig: FUN_140458a90)
void FUN_140458a90(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgItemInfo::ctor_or_dtor  @140458ad0  [high:vtable-assign]  (orig: FUN_140458ad0)
undefined8 * FUN_140458ad0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgItemInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

