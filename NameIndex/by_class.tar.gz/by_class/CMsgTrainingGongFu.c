// ==== CMsgTrainingGongFu::helper_1401d8b90  @1401d8b90  [medium:callgraph-r3]  (orig: FUN_1401d8b90)
void FUN_1401d8b90(longlong param_1,undefined1 param_2,char param_3,char param_4,byte *param_5,
                  byte *param_6)

{
  byte bVar1;
  int iVar2;
  
  if (param_3 == '\x01') {
    if (param_4 == '\0') {
      bVar1 = FUN_1403f5750(*(undefined8 *)(param_1 + 0x20),param_2);
      *param_6 = bVar1;
      if (bVar1 == 6) {
        iVar2 = 0;
        do {
          bVar1 = FUN_1403f5750(*(undefined8 *)(param_1 + 0x20),param_2);
          *param_6 = bVar1;
          if (bVar1 != 6) goto LAB_1401d8bed;
          iVar2 = iVar2 + 1;
        } while (iVar2 < 10);
        *param_6 = 1;
        goto LAB_1401d8c22;
      }
    }
    else {
      bVar1 = FUN_1403f5750(*(undefined8 *)(param_1 + 0x20),param_2);
      *param_6 = bVar1;
    }
  }
  else if (param_3 == '\x02') {
    if (param_4 == '\0') {
      bVar1 = FUN_1403f5960(*(undefined8 *)(param_1 + 0x20),param_2);
      *param_6 = bVar1;
      if (bVar1 == 6) {
        iVar2 = 0;
        do {
          bVar1 = FUN_1403f5960(*(undefined8 *)(param_1 + 0x20),param_2);
          *param_6 = bVar1;
          if (bVar1 != 6) goto LAB_1401d8bed;
          iVar2 = iVar2 + 1;
        } while (iVar2 < 10);
        *param_6 = 1;
        goto LAB_1401d8c22;
      }
    }
    else {
      bVar1 = FUN_1403f5960(*(undefined8 *)(param_1 + 0x20),param_2);
      *param_6 = bVar1;
    }
  }
  else if (param_4 == '\0') {
    bVar1 = FUN_1403f5540(*(undefined8 *)(param_1 + 0x20),param_2);
    *param_6 = bVar1;
    if (bVar1 == 6) {
      iVar2 = 0;
      do {
        bVar1 = FUN_1403f5540(*(undefined8 *)(param_1 + 0x20),param_2);
        *param_6 = bVar1;
        if (bVar1 != 6) goto LAB_1401d8bed;
        iVar2 = iVar2 + 1;
      } while (iVar2 < 10);
      *param_6 = 1;
      goto LAB_1401d8c22;
    }
  }
  else {
    bVar1 = FUN_1403f5540(*(undefined8 *)(param_1 + 0x20));
    *param_6 = bVar1;
  }
LAB_1401d8bed:
  if ((*param_6 == 0) || (6 < *param_6)) {
    *param_6 = 1;
    log_InlineLogERROR(
                      "PowerLevel(%u), SelectCritType(%u) GetCritRandPowerQuality(%u) error,at %s, %d"
                      );
  }
LAB_1401d8c22:
  bVar1 = FUN_1403f7740(*(undefined8 *)(param_1 + 0x28),param_2);
  *param_5 = bVar1;
  if ((bVar1 == 0) || (0xf < bVar1)) {
    *param_5 = 1;
    log_InlineLogERROR("PowerLevel(%u) GetPowerRandAttrib(%u) error,at %s, %d");
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1401e34f0  @1401e34f0  [medium:callgraph-r1]  (orig: FUN_1401e34f0)
longlong * FUN_1401e34f0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x29) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgTrainingGongFu::helper_1401e6680  @1401e6680  [medium:callgraph-r2]  (orig: FUN_1401e6680)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401e6680(longlong param_1,longlong *param_2,longlong param_3,longlong param_4,uint param_5
                  )

{
  longlong lVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  undefined1 uVar6;
  char cVar7;
  undefined4 uVar8;
  longlong lVar9;
  undefined1 auStack_538 [32];
  byte *local_518;
  byte *local_510;
  uint local_508;
  uint local_500;
  uint local_4f8;
  uint local_4f0;
  byte local_4e8;
  byte local_4e7;
  byte local_4e6;
  byte local_4e5;
  undefined2 local_4e4;
  undefined4 local_4e0;
  undefined1 uStack_4dc;
  undefined4 local_4d8 [4];
  undefined4 local_4c8;
  undefined1 local_4c4;
  longlong *local_4b8;
  longlong *local_4b0;
  longlong *local_4a8;
  longlong local_4a0;
  longlong *local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_488 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_538;
    if ((param_3 != 0) && (param_4 != 0)) {
      local_4b8 = param_2;
      local_4b0 = param_2;
      bVar5 = FUN_1403fff00(param_4,param_5 >> 0x18,param_5 >> 0x10);
      local_4e8 = 0;
      local_4e6 = 0;
      local_518 = &local_4e6;
      FUN_140400270(param_4,param_5._3_1_,param_5._2_1_,&local_4e8);
      local_4e7 = 0;
      local_4e5 = 0;
      local_510 = &local_4e5;
      local_518 = &local_4e7;
      FUN_1401d8b90(param_1,param_5._3_1_,(undefined1)param_5,4 < bVar5);
      bVar5 = local_4e5;
      local_518._0_1_ = local_4e5;
      FUN_140400120(param_4,param_5._3_1_,param_5._2_1_,local_4e7);
      local_518 = (byte *)CONCAT71(local_518._1_7_,local_4e6);
      FUN_1403fee40(param_4,param_5._3_1_,param_5._2_1_,local_4e8);
      lVar9 = 0;
      local_4e0 = 0;
      uStack_4dc = 0;
      local_4d8[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401e34f0((longlong *)(param_1 + 0xd0),&local_4a8,local_4d8);
      lVar1 = *(longlong *)(param_1 + 0x100);
      local_498 = *(longlong **)(param_1 + 0xd0);
      if ((local_4a8 == (longlong *)0x0) || (local_4a8 != local_498)) {
        _invalid_parameter_noinfo();
      }
      if (local_4a0 != lVar1) {
        if (local_4a8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar9 = *local_4a8;
        }
        if (local_4a0 == *(longlong *)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar1 = *(longlong *)(local_4a0 + 0x20);
        if (lVar1 != 0) {
          uVar6 = FUN_1403fe830(lVar1,2);
          local_4e0 = CONCAT31(local_4e0._1_3_,uVar6);
          uVar8 = FUN_1403fe980(lVar1,3);
          local_4e0._1_3_ = (undefined3)uVar8;
          uStack_4dc = (undefined1)((uint)uVar8 >> 0x18);
        }
      }
      bVar3 = local_4e7;
      local_4e4 = CONCAT11(bVar5,local_4e7);
      uVar8 = FUN_1403fd5d0(param_3,6);
      FUN_140401810(local_478);
      local_4c8 = local_4e0;
      local_4c4 = uStack_4dc;
      local_518 = (byte *)&local_4c8;
      cVar7 = FUN_1404018d0(local_478,uVar8,param_5,local_4e4);
      if (cVar7 != '\0') {
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_478);
      }
      bVar4 = local_4e6;
      bVar2 = local_4e8;
      if (4 < local_4e6) {
        (**(code **)(*local_4b0 + 8))();
        local_4f0 = (uint)bVar5;
        local_4f8 = (uint)bVar3;
        local_500 = (uint)bVar4;
        local_508 = (uint)bVar2;
        local_510 = (byte *)CONCAT44(local_510._4_4_,(uint)param_5._2_1_);
        local_518 = (byte *)CONCAT44(local_518._4_4_,(uint)param_5._3_1_);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Training KungFu Replace, user(id:%u, account:%u) training KungFu(PowerLevel=%u, PowerOrder=%u, OldPowerType=%u, OldPowerQuality=%u, NewPowerType=%u, NewPowerQuality=%u)."
                     );
      }
      FUN_140401860(local_478);
    }
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1401e9b60  @1401e9b60  [medium:callgraph-r1]  (orig: FUN_1401e9b60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401e9b60(longlong param_1,longlong *param_2,longlong param_3,longlong param_4,
                  longlong param_5,uint param_6)

{
  char cVar1;
  byte bVar2;
  undefined1 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong *plVar10;
  longlong *plVar11;
  uint uVar12;
  longlong lVar13;
  longlong lVar14;
  bool bVar15;
  bool bVar16;
  undefined1 auStack_548 [32];
  uint local_528;
  uint local_520;
  byte local_518;
  undefined1 local_517;
  uint local_514;
  int local_510;
  longlong local_508;
  int local_500;
  int local_4fc;
  longlong local_4f8;
  longlong local_4f0;
  longlong local_4e8;
  longlong local_4e0;
  undefined4 local_4d8;
  longlong *local_4d0;
  undefined4 local_4c8;
  longlong *local_4c0;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_548;
  local_4f8 = param_5;
  if (param_2 == (longlong *)0x0) {
    return;
  }
  if (param_3 == 0) {
    return;
  }
  if (param_4 == 0) {
    return;
  }
  if (param_5 == 0) {
    return;
  }
  local_508 = param_3;
  local_4e8 = param_1;
  local_4e0 = param_4;
  local_4d0 = param_2;
  FUN_140156ce0(param_1 + 0x110,&local_4c0,(longlong)&param_6 + 3);
  lVar14 = *(longlong *)(param_1 + 0x140);
  lVar13 = 0;
  iVar4 = 0;
  local_4a8 = *(longlong **)(param_1 + 0x110);
  if ((local_4c0 == (longlong *)0x0) || (local_4c0 != local_4a8)) {
    _invalid_parameter_noinfo();
  }
  if (local_4b8 == lVar14) {
    (**(code **)(*param_2 + 8))(param_2);
    local_528 = 0x4c3;
    log_InlineLogDBERROR
              (
              "table:cq_jianghu_caltivate_condition, user(%u), PowerLevel(%u), Can Not Find Cultivate Condition Data, at %s, %d"
              );
    return;
  }
  if (local_4c0 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar14 = lVar13;
  }
  else {
    lVar14 = *local_4c0;
  }
  if (local_4b8 == *(longlong *)(lVar14 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  plVar11 = *(longlong **)(local_4b8 + 0x20);
  if (plVar11 == (longlong *)0x0) {
    local_528 = 0x4c7;
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  local_520 = local_520 & 0xffffff00;
  local_528 = 1;
  cVar1 = FUN_140338940(param_2,0x2dd22e,0x2dd22e,1);
  lVar14 = local_508;
  bVar15 = cVar1 == '\0';
  local_500 = 0;
  local_4d8 = 0;
  local_514 = 0;
  local_4c8 = 0;
  local_518 = 0;
  local_4f0 = 0;
  if (bVar15) {
    local_518 = FUN_1403fd740(local_508,5);
    if (local_518 < 2) {
      pIVar7 = theInstance();
      lVar14 = param_2[2];
      uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_GENUINE_QI_NOT_ENOUGH")
      ;
      (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
      return;
    }
    bVar2 = FUN_1403fe830(local_4f8,2);
    local_514 = (uint)bVar2;
    if ((int)(*(int *)(param_1 + 0xc) - local_514) < 1) {
      pIVar7 = theInstance();
      lVar14 = param_2[2];
      uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_FREE_TIMES_NOT_ENOUGH")
      ;
      (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
      return;
    }
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    cVar1 = FUN_14008abf0(uVar8);
    if (cVar1 == '\0') {
      lVar9 = FUN_1401669e0(param_2);
      plVar10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,3);
      local_4f0 = (**(code **)(*plVar10 + 0x58))(plVar10);
      if (lVar9 < local_4f0) {
        pIVar7 = theInstance();
        lVar14 = param_2[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar7)
                          (pIVar7,"STR_TRAINING_GONGFU_CULTIVATE_VALUE_NOT_ENOUGH");
        (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
        return;
      }
      local_500 = FUN_1403fd5d0(lVar14,6);
      if (local_500 / 10000 < 1) {
        pIVar7 = theInstance();
        lVar14 = param_2[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar7)
                          (pIVar7,"STR_TRAINING_GONGFU_FREE_TIMES_CUMULATE_NOT_ENOUGH");
        (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar8);
        return;
      }
    }
  }
  lVar14 = local_4e8;
  local_4fc = 0;
  bVar16 = false;
  local_517 = 0;
  local_510 = *(int *)(local_4e8 + 0x48);
  if ((param_6 & 0xff) == 1) {
    local_520 = (uint)local_520._1_3_ << 8;
    local_528 = 1;
    cVar1 = FUN_140338940(param_2,0x2dd2f5,0x2dd2f5,1);
    bVar16 = cVar1 != '\0';
    if (bVar16) {
      local_517 = 1;
    }
    else {
      plVar10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,4);
      iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
      local_4fc = iVar4;
    }
    plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,4);
    iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_510 = local_510 + iVar5;
LAB_1401e9f96:
    if (0 < iVar4) {
      cVar1 = FUN_1401d8980(lVar14,param_2,iVar4);
      if (cVar1 == '\0') {
        return;
      }
      if (bVar15) {
        uVar12 = local_514 + 1;
        (**(code **)(*param_2 + 8))(param_2);
        local_528 = iVar4;
        local_520 = uVar12;
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Training, user(id:%u, account:%u) Crit Cost(%d) Trainig Times(%d).");
      }
      else {
        (**(code **)(*param_2 + 8))(param_2);
        local_528 = iVar4;
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Use Item Training, user(id:%u, account:%u) Crit Cost(%d).");
      }
    }
  }
  else if ((param_6 & 0xff) == 2) {
    local_520 = (uint)local_520._1_3_ << 8;
    local_528 = 1;
    cVar1 = FUN_140338940(param_2,0x2dd2f6,0x2dd2f6,1);
    bVar16 = cVar1 != '\0';
    if (bVar16) {
      local_517 = 1;
    }
    else {
      plVar10 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,5);
      iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
      local_4fc = iVar4;
    }
    plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,5);
    iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_510 = local_510 + iVar5;
    goto LAB_1401e9f96;
  }
  lVar14 = local_4e8;
  lVar9 = FUN_140008520(*(undefined4 *)(local_4e8 + 8));
  if (*(longlong *)(lVar9 + 0x1c8) == 0) {
    local_528 = 0x15d;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar13 = *(longlong *)(lVar9 + 0x1c8);
  }
  FUN_1400d2660(lVar13,param_2,6,local_510);
  if (!bVar15) {
    local_520 = local_520 & 0xffffff00;
    local_528 = 1;
    cVar1 = FUN_140350360(param_2,0x2dd22e,0x2dd22e,1);
    if (cVar1 == '\0') {
      (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/TrainingKungFu",
                    "Free Training, User(id:%u, account:%u) Delete Free Item Error.");
      return;
    }
    pIVar7 = theInstance();
    lVar13 = param_2[2];
    uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_DELETE_FREE_ITEM");
    (**(code **)(lVar13 + 0x358))(param_2 + 2,uVar8);
  }
  uVar12 = local_514;
  if (bVar16) {
    if ((param_6 & 0xff) == 1) {
      local_520 = (uint)local_520._1_3_ << 8;
      local_528 = 1;
      cVar1 = FUN_140350360(param_2,0x2dd2f5,0x2dd2f5,1);
      uVar12 = local_514;
      if (cVar1 == '\0') {
        (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Training, User(id:%u, account:%u) Use Crit Item Trainig Error.");
        return;
      }
      if (!bVar15) {
        (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Use Item Training, User(id:%u, account:%u) Use Crit Item Trainig.");
        lVar13 = local_508;
        goto LAB_1401ea3d2;
      }
      iVar4 = local_514 + 1;
      (**(code **)(*param_2 + 8))(param_2);
      local_528 = iVar4;
      tq::MyLogSave("gmlog/TrainingKungFu",
                    "Free Training, User(id:%u, account:%u) Use Crit Item Trainig, Times(%d).");
    }
    else if ((param_6 & 0xff) == 2) {
      local_520 = (uint)local_520._1_3_ << 8;
      local_528 = 1;
      cVar1 = FUN_140350360(param_2,0x2dd2f6,0x2dd2f6,1);
      uVar12 = local_514;
      if (cVar1 == '\0') {
        (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Training, User(id:%u, account:%u) Use High Crit Item Trainig Error.");
        return;
      }
      if (!bVar15) {
        (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Free Use Item Training, User(id:%u, account:%u) Use High Crit Item Trainig.")
        ;
        lVar13 = local_508;
        goto LAB_1401ea3d2;
      }
      iVar4 = local_514 + 1;
      (**(code **)(*param_2 + 8))(param_2);
      local_528 = iVar4;
      tq::MyLogSave("gmlog/TrainingKungFu",
                    "Free Training, User(id:%u, account:%u) Use High Crit Item Trainig, Times(%d).")
      ;
    }
  }
  lVar13 = local_508;
  if (bVar15) {
    FUN_1403fd7d0(local_508,5,local_518 - 1,1);
    FUN_140400920(local_498);
    uVar3 = FUN_1403fd740(lVar13,5);
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    cVar1 = FUN_140400ce0(local_498,5,uVar6,uVar3);
    if (cVar1 != '\0') {
      (**(code **)(param_2[2] + 0x348))(param_2 + 2,local_498,1);
    }
    uVar8 = FUN_140008520(*(undefined4 *)(lVar14 + 8));
    cVar1 = FUN_14008abf0(uVar8);
    lVar13 = local_508;
    if (cVar1 == '\0') {
      FUN_1401669f0(param_2,-local_4f0,1);
      lVar13 = local_508;
      FUN_1403fd660(local_508,6,local_500 + -10000,1);
    }
    FUN_1403fe8c0(local_4f8,2,uVar12 + 1);
    local_520 = local_520 & 0xffffff00;
    local_528 = CONCAT31(local_528._1_3_,1);
    FUN_140384c50(param_2,1,1,uVar12 + 1);
    FUN_1404009a0(local_498);
  }
LAB_1401ea3d2:
  local_528 = param_6;
  FUN_1401e6680(lVar14,param_2,lVar13,local_4e0);
  return;
}

// ==== CMsgTrainingGongFu::helper_1401ea420  @1401ea420  [medium:callgraph-r1]  (orig: FUN_1401ea420)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401ea420(longlong param_1,longlong *param_2,longlong param_3,longlong param_4,
                  longlong param_5,uint param_6)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong lVar10;
  int iVar11;
  longlong lVar12;
  bool bVar13;
  longlong *local_60;
  longlong local_58;
  longlong *local_50;
  
  if ((((param_2 != (longlong *)0x0) && (param_3 != 0)) && (param_4 != 0)) && (param_5 != 0)) {
    iVar2 = FUN_1403fe980(param_5,3);
    if (iVar2 < *(int *)(param_1 + 0x10)) {
      FUN_140156ce0(param_1 + 0x110,&local_60,(longlong)&param_6 + 3);
      lVar10 = *(longlong *)(param_1 + 0x140);
      lVar12 = 0;
      local_50 = *(longlong **)(param_1 + 0x110);
      if ((local_60 == (longlong *)0x0) || (local_60 != local_50)) {
        _invalid_parameter_noinfo();
      }
      if (local_58 == lVar10) {
        log_InlineLogDBERROR
                  ("table:cq_jianghu_caltivate_condition, PowerLevel(%u), Can Not Find Cultivate Condition Data, at %s, %d"
                   ,(ulonglong)param_6._3_1_,
                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                   ,0x5a9);
      }
      else {
        if (local_60 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar12;
        }
        else {
          lVar10 = *local_60;
        }
        if (local_58 == *(longlong *)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plVar8 = *(longlong **)(local_58 + 0x20);
        if (plVar8 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pConditionRecord",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                            );
        }
        else {
          iVar3 = 0;
          bVar13 = false;
          iVar4 = 0;
          if ((param_6 & 0xff) == 1) {
            cVar1 = FUN_140338940(param_2,0x2dd2f5,0x2dd2f5,1);
            bVar13 = cVar1 != '\0';
            iVar3 = 0;
            if (!bVar13) {
              plVar7 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
              iVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
            }
            plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
            iVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
          }
          else if ((param_6 & 0xff) == 2) {
            cVar1 = FUN_140338940(param_2,0x2dd2f6,0x2dd2f6,1);
            bVar13 = cVar1 != '\0';
            iVar3 = 0;
            if (!bVar13) {
              plVar7 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,5);
              iVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
            }
            plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,5);
            iVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
          }
          iVar11 = *(int *)(param_1 + 0x3c) * iVar2 + *(int *)(param_1 + 0x38);
          if (*(int *)(param_1 + 0x40) < iVar11) {
            iVar11 = *(int *)(param_1 + 0x40);
          }
          if (0 < iVar11 + iVar3) {
            cVar1 = FUN_1401d8980(param_1,param_2);
            if (cVar1 == '\0') {
              return;
            }
            lVar10 = param_2[0x1e2];
            uVar9 = (**(code **)(*param_2 + 8))(param_2);
            tq::MyLogSave("gmlog/TrainingKungFu",
                          "Pay Training, user(id:%u, account:%u) Crit Cost(%d) Extra Cost(%d) Training Times(%d)."
                          ,uVar9 & 0xffffffff,(int)lVar10);
          }
          lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          if (*(longlong *)(lVar10 + 0x1c8) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOperatingActMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
          }
          else {
            lVar12 = *(longlong *)(lVar10 + 0x1c8);
          }
          FUN_1400d2660(lVar12,param_2,6,iVar4 + iVar11);
          if (bVar13) {
            if ((param_6 & 0xff) == 1) {
              cVar1 = FUN_140350360(param_2,0x2dd2f5,0x2dd2f5,1);
              if (cVar1 == '\0') {
                lVar10 = param_2[0x1e2];
                uVar9 = (**(code **)(*param_2 + 8))(param_2);
                tq::MyLogSave("gmlog/TrainingKungFu",
                              "Pay Training, User(id:%u, account:%u) Use Crit Item Trainig Error, Times(%d)."
                              ,uVar9 & 0xffffffff,(int)lVar10);
                return;
              }
              lVar10 = param_2[0x1e2];
              uVar9 = (**(code **)(*param_2 + 8))(param_2);
              tq::MyLogSave("gmlog/TrainingKungFu",
                            "Pay Training, User(id:%u, account:%u) Use Crit Item Trainig, Times(%d)."
                            ,uVar9 & 0xffffffff,(int)lVar10);
            }
            else if ((param_6 & 0xff) == 2) {
              cVar1 = FUN_140350360(param_2,0x2dd2f6,0x2dd2f6,1);
              if (cVar1 == '\0') {
                lVar10 = param_2[0x1e2];
                uVar9 = (**(code **)(*param_2 + 8))(param_2);
                tq::MyLogSave("gmlog/TrainingKungFu",
                              "Pay Training, User(id:%u, account:%u) Use High Crit Item Trainig Error, Times(%d)."
                              ,uVar9 & 0xffffffff,(int)lVar10);
                return;
              }
              lVar10 = param_2[0x1e2];
              uVar9 = (**(code **)(*param_2 + 8))(param_2);
              tq::MyLogSave("gmlog/TrainingKungFu",
                            "Pay Training, User(id:%u, account:%u) Use High Crit Item Trainig, Times(%d)."
                            ,uVar9 & 0xffffffff,(int)lVar10);
            }
          }
          FUN_1403fea10(param_5,3,iVar2 + 1);
          FUN_140384c50(param_2,1,2,iVar2 + 1);
          FUN_1401e6680(param_1,param_2,param_3,param_4);
        }
      }
    }
    else {
      pIVar5 = theInstance();
      lVar10 = param_2[2];
      uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_TRAINING_GONGFU_PAY_TIMES_NOT_ENOUGH");
      (**(code **)(lVar10 + 0x358))(param_2 + 2,uVar6);
    }
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1401ea930  @1401ea930  [medium:callgraph-r1]  (orig: FUN_1401ea930)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401ea930(longlong param_1,longlong *param_2,longlong param_3,longlong param_4,
                  longlong param_5,uint param_6)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  int iVar12;
  longlong *plVar13;
  bool bVar14;
  int local_70;
  undefined8 *local_60;
  longlong local_58;
  undefined8 *local_50;
  
  if (param_2 == (longlong *)0x0) {
    return;
  }
  if (param_3 == 0) {
    return;
  }
  if (param_4 == 0) {
    return;
  }
  if (param_5 == 0) {
    return;
  }
  iVar2 = FUN_1403fe980(param_5,3);
  if (*(int *)(param_1 + 0x10) <= iVar2) {
    pIVar5 = theInstance();
    lVar7 = param_2[2];
    uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_TRAINING_GONGFU_PAY_TIMES_NOT_ENOUGH");
    (**(code **)(lVar7 + 0x358))(param_2 + 2,uVar6);
    return;
  }
  FUN_140156ce0(param_1 + 0x110,&local_60,(longlong)&param_6 + 3);
  lVar7 = *(longlong *)(param_1 + 0x140);
  plVar13 = (longlong *)0x0;
  local_50 = *(undefined8 **)(param_1 + 0x110);
  if ((local_60 == (undefined8 *)0x0) || (local_60 != local_50)) {
    _invalid_parameter_noinfo();
  }
  if (local_58 == lVar7) {
    log_InlineLogDBERROR
              ("table:cq_jianghu_caltivate_condition, PowerLevel(%u), Can Not Find Cultivate Condition Data, at %s, %d"
               ,(ulonglong)param_6._3_1_,
               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
               ,0x62f);
    return;
  }
  if (local_60 == (undefined8 *)0x0) {
    _invalid_parameter_noinfo();
    plVar9 = plVar13;
  }
  else {
    plVar9 = (longlong *)*local_60;
  }
  if (local_58 == plVar9[6]) {
    _invalid_parameter_noinfo();
  }
  plVar9 = *(longlong **)(local_58 + 0x20);
  if (plVar9 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pConditionRecord",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                      );
    return;
  }
  plVar8 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar8 = plVar13;
  }
  lVar7 = (**(code **)(*plVar8 + 0x70))(plVar8,0x2dd2f4);
  if (lVar7 == 0) {
    log_InlineLogDBERROR
              (&DAT_140724be0,0x2dd2f4,
               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
               ,0x63b);
    return;
  }
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),0x25);
  uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
  plVar8 = (longlong *)
           (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),0x26);
  uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
  if (uVar3 != uVar4) {
    log_InlineLogERROR(&DAT_140724b90,0x2dd2f4,(ulonglong)uVar3,(ulonglong)uVar4);
    return;
  }
  if ((int)uVar3 < 1) {
    log_InlineLogERROR(&DAT_140724b50,0x2dd2f4,(ulonglong)uVar3,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                      );
    return;
  }
  iVar12 = *(int *)(param_1 + 0x3c) * iVar2 + *(int *)(param_1 + 0x38);
  if (*(int *)(param_1 + 0x40) < iVar12) {
    iVar12 = *(int *)(param_1 + 0x40);
  }
  uVar10 = (longlong)(int)(iVar12 + -1 + uVar3) / (longlong)(int)uVar3;
  if ((int)uVar10 < 1) {
    log_InlineLogERROR("Need Use Item Num(%d) Error at %s, %d",uVar10 & 0xffffffff,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\jianghu\\jianghumgr.cpp"
                       ,0x654);
    return;
  }
  cVar1 = FUN_140338940(param_2,0x2dd2f4,0x2dd2f4,uVar10 & 0xffffffff);
  if (cVar1 == '\0') {
    return;
  }
  local_70 = 0;
  bVar14 = false;
  iVar12 = 0;
  if ((param_6 & 0xff) == 1) {
    cVar1 = FUN_140338940(param_2,0x2dd2f5,0x2dd2f5,1);
    bVar14 = cVar1 != '\0';
    if (!bVar14) {
      plVar8 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
      local_70 = (**(code **)(*plVar8 + 0x48))(plVar8);
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,4);
    iVar12 = (**(code **)(*plVar9 + 0x48))(plVar9);
  }
  else {
    if ((param_6 & 0xff) != 2) goto LAB_1401ead39;
    cVar1 = FUN_140338940(param_2,0x2dd2f6,0x2dd2f6,1);
    bVar14 = cVar1 != '\0';
    if (!bVar14) {
      plVar8 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
      local_70 = (**(code **)(*plVar8 + 0x48))(plVar8);
    }
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,5);
    iVar12 = (**(code **)(*plVar9 + 0x48))(plVar9);
  }
  if ((0 < local_70) && (cVar1 = FUN_1401d8980(param_1,param_2,local_70), cVar1 == '\0')) {
    return;
  }
LAB_1401ead39:
  lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar7 + 0x1c8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOperatingActMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  else {
    plVar13 = *(longlong **)(lVar7 + 0x1c8);
  }
  FUN_1400d2660(plVar13,param_2,6,iVar12 + (int)uVar10 * uVar3);
  if (bVar14) {
    if ((param_6 & 0xff) == 1) {
      cVar1 = FUN_140350360(param_2,0x2dd2f5,0x2dd2f5,1);
      if (cVar1 == '\0') {
        lVar7 = param_2[0x1e2];
        uVar10 = (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Use Item Training, User(id:%u, account:%u) Use Crit Item Trainig Error, Times(%d)."
                      ,uVar10 & 0xffffffff,(int)lVar7);
        return;
      }
      lVar7 = param_2[0x1e2];
      uVar11 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/TrainingKungFu",
                    "Use Item Training, User(id:%u, account:%u) Use Crit Item Trainig, Times(%d).",
                    uVar11 & 0xffffffff,(int)lVar7);
    }
    else if ((param_6 & 0xff) == 2) {
      cVar1 = FUN_140350360(param_2,0x2dd2f6,0x2dd2f6,1);
      if (cVar1 == '\0') {
        lVar7 = param_2[0x1e2];
        uVar10 = (**(code **)(*param_2 + 8))(param_2);
        tq::MyLogSave("gmlog/TrainingKungFu",
                      "Use Item Training, User(id:%u, account:%u) Use High Crit Item Trainig Error, Times(%d)."
                      ,uVar10 & 0xffffffff,(int)lVar7);
        return;
      }
      lVar7 = param_2[0x1e2];
      uVar11 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/TrainingKungFu",
                    "Use Item Training, User(id:%u, account:%u) Use High Crit Item Trainig, Times(%d)."
                    ,uVar11 & 0xffffffff,(int)lVar7);
    }
  }
  cVar1 = FUN_140345840(param_2,0x2dd2f4,0x2dd2f4,uVar10 & 0xffffffff);
  if (cVar1 == '\0') {
    lVar7 = param_2[0x1e2];
    uVar11 = (**(code **)(*param_2 + 8))(param_2);
    log_InlineLogERROR("CJiangHuMgr::ProcessUseItemTrainingGongfu, user(id:%u, account:%u) Expend Item Num(%d) Failed."
                       ,uVar11 & 0xffffffff,(int)lVar7,uVar10 & 0xffffffff);
  }
  else {
    lVar7 = param_2[0x1e2];
    uVar10 = (**(code **)(*param_2 + 8))(param_2);
    tq::MyLogSave("gmlog/TrainingKungFu",
                  "Use Item Training, user(id:%u, account:%u) Crit Cost(%d) Use Item Num (%d) Training Times(%d)."
                  ,uVar10 & 0xffffffff,(int)lVar7);
    FUN_1403fea10(param_5,3,iVar2 + 1);
    FUN_140384c50(param_2,1,2,iVar2 + 1);
    FUN_1401e6680(param_1,param_2,param_3,param_4);
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1401ec1d0  @1401ec1d0  [medium:callgraph-r0]  (orig: FUN_1401ec1d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ec1d0(longlong param_1,longlong *param_2,undefined4 param_3)

{
  byte bVar1;
  char cVar2;
  byte bVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  IStringManager *pIVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong lVar12;
  longlong lVar13;
  longlong lVar14;
  undefined1 auStack_1f8 [32];
  undefined8 local_1d8;
  undefined8 local_1d0;
  longlong *local_1c8;
  longlong local_1c0;
  undefined4 local_1b8 [2];
  longlong local_1b0;
  undefined4 local_1a8;
  undefined4 uStack_1a4;
  longlong *local_1a0;
  longlong *local_198;
  undefined8 local_190;
  longlong *local_188;
  longlong *local_178 [3];
  longlong *local_160;
  char local_148;
  undefined1 local_147 [254];
  undefined1 local_49;
  ulonglong local_48;
  
  if (param_2 != (longlong *)0x0) {
    local_190 = 0xfffffffffffffffe;
    local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1f8;
    if ((((((*(char *)((longlong)param_2 + 0x51c) != '\0') &&
           (bVar3 = (byte)((uint)param_3 >> 0x18), bVar3 != 0)) && (bVar3 < 10)) &&
         ((bVar1 = (byte)((uint)param_3 >> 0x10), bVar1 != 0 && (bVar1 < 10)))) &&
        ((cVar4 = (char)param_3, cVar4 == '\0' || ((cVar4 == '\x01' || (cVar4 == '\x02')))))) &&
       ((cVar4 = (char)((uint)param_3 >> 8), cVar4 == '\0' ||
        ((cVar4 == '\x01' || (cVar4 == '\x02')))))) {
      local_198 = param_2;
      local_1b8[0] = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401e2eb0(param_1 + 0x90,&local_1c8,local_1b8);
      plVar9 = local_1c8;
      lVar11 = *(longlong *)(param_1 + 0xc0);
      lVar14 = 0;
      local_160 = *(longlong **)(param_1 + 0x90);
      if ((local_1c8 == (longlong *)0x0) || (local_1c8 != local_160)) {
        _invalid_parameter_noinfo();
      }
      lVar12 = local_1c0;
      if (local_1c0 == lVar11) {
        pIVar7 = theInstance();
        lVar11 = param_2[2];
        uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_NOT_CREATE_GONGFU");
        (**(code **)(lVar11 + 0x358))(param_2 + 2,uVar8);
      }
      else {
        if (plVar9 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar14;
        }
        else {
          lVar11 = *plVar9;
        }
        if (lVar12 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar11 = *(longlong *)(lVar12 + 0x20);
        if (lVar11 == 0) {
          pIVar7 = theInstance();
          lVar11 = param_2[2];
          uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_NOT_CREATE_GONGFU")
          ;
          (**(code **)(lVar11 + 0x358))(param_2 + 2,uVar8);
          (**(code **)(*param_2 + 8))(param_2);
          log_InlineLogERROR("user(%u), pJiangHuPlayer == NULL, at %s, %d");
        }
        else {
          bVar1 = FUN_1403fd740(lVar11,4);
          if (bVar1 < bVar3) {
            pIVar7 = theInstance();
            lVar11 = param_2[2];
            uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TRAINING_GONGFU_NOT_OPEN_POWER");
            (**(code **)(lVar11 + 0x358))(param_2 + 2,uVar8);
          }
          else {
            uVar5 = (**(code **)(*param_2 + 8))(param_2);
            local_1b0 = CONCAT44(local_1b0._4_4_,uVar5);
            FUN_1401e3b30(param_1 + 0x150,&local_1c8,&local_1b0);
            plVar9 = local_1c8;
            lVar12 = *(longlong *)(param_1 + 0x180);
            local_188 = *(longlong **)(param_1 + 0x150);
            if ((local_1c8 == (longlong *)0x0) || (local_1c8 != local_188)) {
              _invalid_parameter_noinfo();
            }
            if (local_1c0 == lVar12) {
              (**(code **)(*param_2 + 8))(param_2);
              log_InlineLogERROR(
                                "user(%u), iterPower == m_mapJiangHuPlayerPowerInfo.end(), at %s, %d"
                                );
            }
            else {
              if (plVar9 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar12 = lVar14;
              }
              else {
                lVar12 = *plVar9;
              }
              if (local_1c0 == *(longlong *)(lVar12 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              lVar12 = *(longlong *)(local_1c0 + 0x20);
              local_1b0 = lVar12;
              if (lVar12 == 0) {
                local_1d8 = (longlong *)CONCAT44(local_1d8._4_4_,0x471);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                uVar5 = (**(code **)(*param_2 + 8))(param_2);
                local_1c8 = (longlong *)CONCAT44(local_1c8._4_4_,uVar5);
                FUN_1401e34f0(param_1 + 0xd0,&local_1a8,&local_1c8);
                local_1c8 = *(longlong **)(param_1 + 0x100);
                local_178[0] = *(longlong **)(param_1 + 0xd0);
                plVar9 = (longlong *)CONCAT44(uStack_1a4,local_1a8);
                if ((plVar9 == (longlong *)0x0) || (plVar9 != local_178[0])) {
                  _invalid_parameter_noinfo();
                }
                plVar10 = local_1a0;
                if (local_1a0 == local_1c8) {
                  plVar9 = (longlong *)InstanceGet();
                  plVar10 = (longlong *)
                            (**(code **)(*plVar9 + 0x20))(plVar9,"cq_jianghu_caltivate_times");
                  if (plVar10 == (longlong *)0x0) {
                    local_1d8 = (longlong *)CONCAT44(local_1d8._4_4_,0x47d);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    return;
                  }
                  plVar9 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,1);
                  lVar12 = *plVar9;
                  uVar5 = (**(code **)(*param_2 + 8))(param_2);
                  (**(code **)(lVar12 + 0xb8))(plVar9,uVar5);
                  plVar9 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,2);
                  (**(code **)(*plVar9 + 0xb0))(plVar9,0);
                  plVar9 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,3);
                  (**(code **)(*plVar9 + 0xb0))(plVar9,0);
                  cVar2 = (**(code **)(*plVar10 + 0x50))(plVar10,1);
                  if (cVar2 == '\0') {
                    (**(code **)*plVar10)(plVar10,1);
                    (**(code **)(*param_2 + 8))(param_2);
                    log_InlineLogERROR(
                                      "user:%u, insert data to cq_jianghu_caltivate_times error,at %s, %d"
                                      );
                    return;
                  }
                  uVar5 = (**(code **)(*param_2 + 8))(param_2);
                  plVar9 = (longlong *)FUN_1403fec80(uVar5,plVar10,0);
                  if (plVar9 == (longlong *)0x0) {
                    local_1d8 = (longlong *)CONCAT44(local_1d8._4_4_,0x48b);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    (**(code **)*plVar10)(plVar10,1);
                    return;
                  }
                  local_1a8 = (**(code **)(*param_2 + 8))(param_2);
                  local_1a0 = plVar9;
                  FUN_1401e2f80(param_1 + 0xd0,local_178,&local_1a8);
                  lVar12 = local_1b0;
                }
                else {
                  if (plVar9 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                    lVar13 = lVar14;
                  }
                  else {
                    lVar13 = *plVar9;
                  }
                  if (plVar10 == *(longlong **)(lVar13 + 0x30)) {
                    _invalid_parameter_noinfo();
                  }
                  plVar9 = (longlong *)plVar10[4];
                }
                if (cVar4 == '\0') {
                  local_1d0 = CONCAT44(local_1d0._4_4_,param_3);
                  local_1d8 = plVar9;
                  FUN_1401e9b60(param_1,param_2,lVar11,lVar12);
                }
                else if (cVar4 == '\x01') {
                  local_1d0 = CONCAT44(local_1d0._4_4_,param_3);
                  local_1d8 = plVar9;
                  FUN_1401ea420(param_1,param_2,lVar11,lVar12);
                }
                else if (cVar4 == '\x02') {
                  local_1d0 = CONCAT44(local_1d0._4_4_,param_3);
                  local_1d8 = plVar9;
                  FUN_1401ea930(param_1,param_2,lVar11,lVar12);
                }
                local_148 = '\0';
                memset(local_147,0,0xff);
                bVar3 = FUN_1403fe830(plVar9,2);
                iVar6 = FUN_1403fe980(plVar9,3);
                (**(code **)(*param_2 + 8))(param_2);
                local_1d8._0_4_ = (uint)bVar3 + iVar6;
                _snprintf(&local_148,0x100,"</F>TrainingGongfu</N>%lu</N>%u");
                local_49 = 0;
                lVar11 = DAT_140975bf0;
                if (DAT_140975bf0 == 0) {
                  local_1d8._0_4_ = 0x3cd;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  lVar11 = lVar14;
                }
                uVar5 = (**(code **)(*param_2 + 8))(param_2);
                local_1d0 = 0;
                local_1d8 = (longlong *)((ulonglong)local_1d8._4_4_ << 0x20);
                cVar4 = FUN_140286530(lVar11,&local_148,uVar5,0);
                if (cVar4 == '\0') {
                  log_InlineLogLuaERROR
                            (
                            "Lua return fault, Call From:CJiangHuMgr::ProcessTrainingGongFu, lua function:%s."
                            );
                }
                lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 8));
                if (*(longlong *)(lVar11 + 0x1f8) == 0) {
                  local_1d8 = (longlong *)CONCAT44(local_1d8._4_4_,0x163);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  lVar14 = *(longlong *)(lVar11 + 0x1f8);
                }
                FUN_140261810(lVar14,param_2,9);
              }
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1403fe830  @1403fe830  [medium:callgraph-r1]  (orig: FUN_1403fe830)
ulonglong FUN_1403fe830(longlong param_1,int param_2)

{
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong *plVar1;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (3 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001403fe8b6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1);
  return uVar2;
}

// ==== CMsgTrainingGongFu::helper_1403fe8c0  @1403fe8c0  [medium:callgraph-r2]  (orig: FUN_1403fe8c0)
void FUN_1403fe8c0(longlong param_1,int param_2,undefined1 param_3)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (3 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
  (**(code **)(*plVar1 + 0xd8))(plVar1,param_3);
  if (*(char *)(param_1 + 0x18) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1403fe980  @1403fe980  [medium:callgraph-r1]  (orig: FUN_1403fe980)
undefined8 FUN_1403fe980(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (3 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
                    /* WARNING: Could not recover jumptable at 0x0001403fea06. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CMsgTrainingGongFu::helper_1403fea10  @1403fea10  [medium:callgraph-r2]  (orig: FUN_1403fea10)
void FUN_1403fea10(longlong param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (3 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_3);
  if (*(char *)(param_1 + 0x18) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1403fee40  @1403fee40  [medium:callgraph-r3]  (orig: FUN_1403fee40)
void FUN_1403fee40(longlong param_1,byte param_2,byte param_3,undefined1 param_4,undefined1 param_5)

{
  if ((((param_2 != 0) && (param_2 < 10)) && (param_3 != 0)) && (param_3 < 10)) {
    *(byte *)(param_1 + 0x50) = param_2;
    *(byte *)(param_1 + 0x51) = param_3;
    *(undefined1 *)(param_1 + 0x53) = param_5;
    *(undefined1 *)(param_1 + 0x52) = param_4;
  }
  return;
}

// ==== CMsgTrainingGongFu::helper_1403fff00  @1403fff00  [medium:callgraph-r3]  (orig: FUN_1403fff00)
ulonglong FUN_1403fff00(longlong param_1,char param_2,byte param_3)

{
  ulonglong uVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  longlong *plVar2;
  ulonglong extraout_RAX_02;
  longlong lVar3;
  char local_res10 [8];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  if ((8 < (byte)(param_2 - 1U)) || (8 < (byte)(param_3 - 1))) {
    log_InlineLogERROR("PowerLevel(%u), PowerOrder:%u, error,at %s, %d");
    return extraout_RAX_02 & 0xffffffffffffff00;
  }
  uVar1 = FUN_140156ce0((longlong *)(param_1 + 0x10),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x40);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
    uVar1 = extraout_RAX;
  }
  if (local_10 != lVar3) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
      uVar1 = extraout_RAX_00;
    }
    else {
      lVar3 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
      uVar1 = extraout_RAX_01;
    }
    plVar2 = *(longlong **)(local_10 + 0x20);
    if (plVar2 != (longlong *)0x0) {
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,param_3 + 2 + (uint)param_3);
                    /* WARNING: Could not recover jumptable at 0x0001403fffcd. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar1 = (**(code **)(*plVar2 + 0x20))(plVar2);
      return uVar1;
    }
  }
  return uVar1 & 0xffffffffffffff00;
}

// ==== CMsgTrainingGongFu::ctor_or_dtor  @140401810  [high:vtable-assign]  (orig: FUN_140401810)
undefined8 * FUN_140401810(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingGongFu::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingGongFu::ctor_or_dtor  @140401860  [high:vtable-assign]  (orig: FUN_140401860)
void FUN_140401860(undefined8 *param_1)

{
  *param_1 = CMsgTrainingGongFu::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingGongFu::vfunc_5  @140401890  [high:rtti-vtable]  (orig: FUN_140401890)
bool FUN_140401890(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa8e;
    }
  }
  return false;
}

// ==== CMsgTrainingGongFu::helper_1404018d0  @1404018d0  [medium:callgraph-r3]  (orig: FUN_1404018d0)
ulonglong FUN_1404018d0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                       undefined4 *param_5)

{
  longlong lVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 10) = *param_5;
  *(undefined1 *)(lVar1 + 0xe) = *(undefined1 *)(param_5 + 1);
  *(undefined4 *)(param_1 + 0xc) = 0xf;
  *(undefined4 *)(param_1 + 8) = 0xa8e;
  return 1;
}

// ==== CMsgTrainingGongFu::ctor_or_dtor  @140401970  [high:vtable-assign]  (orig: FUN_140401970)
undefined8 * FUN_140401970(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingGongFu::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTrainingGongFu::vfunc_3  @1404019c0  [high:rtti-vtable]  (orig: FUN_1404019c0)
void FUN_1404019c0(longlong param_1)

{
  longlong lVar1;
  char cVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if ((lVar3 != 0) &&
       (cVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x220))(lVar3 + 0x10), cVar2 != '\0')) {
      lVar1 = *(longlong *)(param_1 + 0x428);
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar4 = FUN_140087ba0(uVar4);
      FUN_1401ec1d0(uVar4,lVar3,*(undefined4 *)(lVar1 + 4));
    }
  }
  return;
}

