// ==== CPromotionInfo::helper_140473290  @140473290  [medium:callgraph-r0]  (orig: FUN_140473290)
void FUN_140473290(void *param_1)

{
  if ((DAT_140976488 & 1) == 0) {
    DAT_140976488 = DAT_140976488 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976480,"CPromotionInfo");
    atexit((_func_5014 *)&LAB_1406d6e90);
  }
                    /* WARNING: Could not recover jumptable at 0x0001404732e5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976480,param_1);
  return;
}

// ==== CPromotionInfo::ctor_or_dtor  @140473350  [high:vtable-assign]  (orig: FUN_140473350)
void FUN_140473350(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = CPromotionInfo::vftable;
  if ((param_1[2] != 0) && (param_1[2] != 0)) {
    (*(code *)**(undefined8 **)param_1[2])
              ((undefined8 *)param_1[2],1,param_3,param_4,0xfffffffffffffffe);
    param_1[2] = 0;
  }
  return;
}

// ==== CPromotionInfo::ctor_or_dtor  @1404733a0  [high:vtable-assign]  (orig: FUN_1404733a0)
undefined8 * FUN_1404733a0(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140976488 & 1) == 0) {
    DAT_140976488 = DAT_140976488 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976480,"CPromotionInfo");
    atexit((_func_5014 *)&LAB_1406d6e90);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976480,0x18);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CPromotionInfo::vftable;
    *(undefined4 *)(puVar1 + 1) = 0;
    puVar1[2] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pPromotionInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\promotioninfo.cpp"
                       ,0x1b);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

// ==== CPromotionInfo::vfunc_0  @140473880  [high:rtti-vtable]  (orig: FUN_140473880)
undefined8 FUN_140473880(undefined8 param_1,uint param_2)

{
  FUN_140473350();
  if ((param_2 & 1) != 0) {
    FUN_140473290(param_1);
  }
  return param_1;
}

