// ==== CTerrainObj::helper_140570c00  @140570c00  [medium:callgraph-r0]  (orig: FUN_140570c00)
undefined4 FUN_140570c00(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x20);
}

// ==== CTerrainObj::helper_140570c10  @140570c10  [medium:callgraph-r0]  (orig: FUN_140570c10)
undefined4 FUN_140570c10(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x24);
}

// ==== CTerrainObj::vfunc_1  @1405724e0  [high:rtti-vtable]  (orig: FUN_1405724e0)
void FUN_1405724e0(longlong param_1,int param_2,int param_3)

{
  int *piVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong *plVar5;
  int iVar6;
  int iVar7;
  undefined8 *puVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  
  uVar10 = 0xfffffffffffffffe;
  FUN_140570be0();
  puVar8 = *(undefined8 **)(param_1 + 0x38);
  if (*(undefined8 **)(param_1 + 0x40) < puVar8) {
    _invalid_parameter_noinfo();
  }
  plVar2 = *(longlong **)(param_1 + 0x20);
  while( true ) {
    puVar3 = *(undefined8 **)(param_1 + 0x40);
    if (puVar3 < *(undefined8 **)(param_1 + 0x38)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    if (puVar8 == puVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (*(undefined8 **)(lVar9 + 0x20) <= puVar8) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)puVar8[1];
    plVar5 = (longlong *)*puVar8;
    if (plVar4 != (longlong *)0x0) {
      LOCK();
      *(int *)(plVar4 + 2) = (int)plVar4[2] + 1;
      UNLOCK();
    }
    plVar11 = plVar5;
    plVar12 = plVar4;
    iVar6 = FUN_140570c00(plVar5);
    iVar7 = FUN_140570c10(plVar5);
    (**(code **)(*plVar5 + 8))
              (plVar5,param_2 + iVar6,param_3 + iVar7,*plVar5,uVar10,plVar11,plVar12);
    if (plVar4 != (longlong *)0x0) {
      LOCK();
      plVar5 = plVar4 + 2;
      *(int *)plVar5 = (int)*plVar5 + -1;
      UNLOCK();
      if ((int)*plVar5 == 0) {
        (**(code **)*plVar4)(plVar4);
        LOCK();
        piVar1 = (int *)((longlong)plVar4 + 0x14);
        *piVar1 = *piVar1 + -1;
        UNLOCK();
        if (*piVar1 == 0) {
          (**(code **)(*plVar4 + 8))(plVar4);
        }
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (*(undefined8 **)(lVar9 + 0x20) <= puVar8) {
      _invalid_parameter_noinfo();
    }
    puVar8 = puVar8 + 2;
  }
  return;
}

// ==== CTerrainObj::helper_140572a30  @140572a30  [medium:callgraph-r0]  (orig: FUN_140572a30)
void FUN_140572a30(undefined8 param_1,longlong *param_2,longlong *param_3)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (param_2 != param_3) {
    plVar4 = param_2 + 1;
    do {
      plVar3 = (longlong *)*plVar4;
      if (plVar3 != (longlong *)0x0) {
        LOCK();
        plVar1 = plVar3 + 2;
        *(int *)plVar1 = (int)*plVar1 + -1;
        UNLOCK();
        if ((int)*plVar1 == 0) {
          (**(code **)*plVar3)(plVar3);
          LOCK();
          piVar2 = (int *)((longlong)plVar3 + 0x14);
          *piVar2 = *piVar2 + -1;
          UNLOCK();
          if (*piVar2 == 0) {
            (**(code **)(*plVar3 + 8))(plVar3);
          }
        }
      }
      plVar3 = plVar4 + 1;
      plVar4 = plVar4 + 2;
    } while (plVar3 != param_3);
  }
  return;
}

// ==== CTerrainObj::ctor_or_dtor  @140573160  [high:vtable-assign]  (orig: FUN_140573160)
undefined8 *
FUN_140573160(undefined8 *param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  
  FUN_140570b90(param_1,1,param_3,param_4,0xfffffffffffffffe);
  *param_1 = CTerrainObj::vftable;
  *(undefined4 *)(param_1 + 3) = param_2;
  plVar1 = operator_new(8);
  plVar2 = (longlong *)0x0;
  if (plVar1 != (longlong *)0x0) {
    *plVar1 = (longlong)(param_1 + 4);
    plVar2 = plVar1;
  }
  param_1[4] = plVar2;
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  return param_1;
}

// ==== CTerrainObj::ctor_or_dtor  @1405731e0  [high:vtable-assign]  (orig: FUN_1405731e0)
void FUN_1405731e0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  *param_1 = CTerrainObj::vftable;
  if (param_1[7] != 0) {
    FUN_140572a30(param_1 + 4,param_1[7],param_1[8],param_4,0xfffffffffffffffe);
    operator_delete((void *)param_1[7]);
  }
  param_1[7] = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  operator_delete((void *)param_1[4]);
  FUN_140570bb0(param_1);
  return;
}

// ==== CTerrainObj::vfunc_0  @140573330  [high:rtti-vtable]  (orig: FUN_140573330)
void * FUN_140573330(void *param_1,uint param_2)

{
  FUN_1405731e0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

