// ==== CMsgRegisterFB@world_kernel::vfunc_1  @1400849e0  [high:rtti-vtable]  (orig: FUN_1400849e0)
ulonglong FUN_1400849e0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x4b2);
}

// ==== CMsgRegisterFB@world_kernel::vfunc_3  @140084a10  [high:rtti-vtable]  (orig: FUN_140084a10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140084a10(longlong *param_1)

{
  ushort uVar1;
  ushort uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  longlong lVar8;
  ulonglong uVar9;
  char *pcVar10;
  undefined1 auStack_4e8 [32];
  longlong local_4c8;
  longlong local_4c0;
  uint local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1088];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  log_InlineLogFACEBOOK("Facebook: Recv and process MsgRegisterFB");
  uVar5 = *(undefined4 *)((longlong)param_1 + 0x414);
  if (DAT_140975af8 == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  iVar4 = FUN_14005cf90(DAT_140975af8,uVar5);
  uVar5 = *(undefined4 *)((longlong)param_1 + 0x414);
  if (DAT_140975af8 == 0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x128);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar5 = FUN_14005ce90(DAT_140975af8,uVar5);
  local_4c0 = param_1[0x84] + 0x10;
  local_4c8 = param_1[0x84] + 0x30;
  log_InlineLogFACEBOOK
            (
            "Facebook: MsgRegisterFB, idAccount:%u, idUin:%u, szAccount:%s, szPassword:%s, szName:%s"
            );
  if (*(int *)((char *)param_1[0x84] + 0x44) != iVar4) {
    if (iVar4 == 0) {
      return;
    }
    local_4c8 = CONCAT44(local_4c8._4_4_,0x38);
    log_InlineLogERROR("CMsgRegister Account[%u] unequal to right Account[%u] at %s, %d");
    return;
  }
  iVar4 = tq::StringCheck((char *)param_1[0x84],0);
  if (iVar4 == 0) {
    log_InlineLogFACEBOOK("Facebook: MsgRegisterFB, invalid account");
    FUN_14007a560(local_478);
    pIVar6 = theInstance();
    uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_ACCOUNT");
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = (uint)local_4b0._2_2_ << 0x10;
    local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
    local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
    local_4c8 = 0;
    iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
    if (iVar4 != 0) {
      (**(code **)(*param_1 + 0x20))(param_1,local_478);
    }
    FUN_14007a5e0(local_478);
    return;
  }
  iVar4 = tq::StringCheck((char *)(param_1[0x84] + 0x30),0);
  if (iVar4 == 0) {
    log_InlineLogFACEBOOK("Facebook: MsgRegisterFB,invalid password");
    FUN_14007a560(local_478);
    pIVar6 = theInstance();
    uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_PASSWORD");
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = (uint)local_4b0._2_2_ << 0x10;
    local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
    local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
    local_4c8 = 0;
    iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
    if (iVar4 != 0) {
      (**(code **)(*param_1 + 0x20))(param_1,local_478);
    }
    FUN_14007a5e0(local_478);
    return;
  }
  uVar9 = 0xffffffffffffffff;
  pcVar10 = (char *)(param_1[0x84] + 0x10);
  do {
    if (uVar9 == 0) break;
    uVar9 = uVar9 - 1;
    cVar3 = *pcVar10;
    pcVar10 = pcVar10 + 1;
  } while (cVar3 != '\0');
  if ((~uVar9 - 1 < 0x10) &&
     (iVar4 = tq::NameStrCheck((char *)(param_1[0x84] + 0x10),false), iVar4 != 0)) {
    lVar8 = param_1[0x84];
    uVar7 = FUN_140054dc0();
    cVar3 = FUN_140056730(uVar7,lVar8 + 0x10);
    if (cVar3 == '\0') {
      if (DAT_140975c00 != '\0') {
        iVar4 = tq::NameStrCheck((char *)(param_1[0x84] + 0x20),false);
        if (iVar4 != 0) {
          lVar8 = param_1[0x84];
          uVar7 = FUN_140054dc0();
          cVar3 = FUN_140056730(uVar7,lVar8 + 0x20);
          if (cVar3 == '\0') goto LAB_140084dd6;
        }
        FUN_14007a560(local_478);
        pIVar6 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_NAME");
        local_498 = 1;
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = (uint)local_4b0._2_2_ << 0x10;
        local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
        local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
        local_4c8 = 0;
        iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar4 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_478);
        }
        FUN_14007a5e0(local_478);
        return;
      }
LAB_140084dd6:
      lVar8 = param_1[0x84];
      uVar1 = *(ushort *)(lVar8 + 0x42);
      uVar2 = *(ushort *)(lVar8 + 0x40);
      uVar7 = FUN_140054e10();
      local_4a8 = *(undefined4 *)(lVar8 + 0x48);
      local_4b0 = *(uint *)(lVar8 + 0x44);
      local_4b8 = (uint)uVar1;
      local_4c8 = lVar8 + 0x30;
      local_4a0 = uVar5;
      local_4c0._0_4_ = (uint)uVar2;
      cVar3 = FUN_1400856e0(uVar7,lVar8,lVar8 + 0x10,lVar8 + 0x20);
      if (cVar3 == '\0') {
        log_InlineLogFACEBOOK("Facebook: MsgRegisterFB,create user failed");
        FUN_14007a560(local_478);
        pIVar6 = theInstance();
        uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_DUPLICATE_NAME");
        local_498 = 1;
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = local_4b0 & 0xffff0000;
        local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
        local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
        local_4c8 = 0;
        iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
        if (iVar4 != 0) {
          (**(code **)(*param_1 + 0x20))(param_1,local_478);
        }
        FUN_14007a5e0(local_478);
        return;
      }
      log_InlineLogFACEBOOK("Facebook: MsgRegisterFB,create user successfully");
      FUN_14007a560(local_478);
      local_498 = 1;
      local_4a0 = 0;
      local_4a8 = 0;
      local_4b0 = local_4b0 & 0xffff0000;
      local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
      local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
      local_4c8 = 0;
      iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS","ANSWER_OK");
      if (iVar4 != 0) {
        (**(code **)(*param_1 + 0x20))(param_1,local_478);
      }
      if (param_1[0x84] != -0x4c) {
        lVar8 = FUN_140054dc0();
        if (lVar8 == 0) {
          FUN_14007a5e0(local_478);
          return;
        }
        FUN_140055a90(lVar8,*(undefined4 *)(param_1[0x84] + 0x44),param_1[0x84] + 0x4c);
      }
      lVar8 = param_1[0x84];
      uVar7 = FUN_140054dc0();
      FUN_1400568e0(uVar7,*(undefined4 *)(lVar8 + 0x44),1);
      FUN_14007a5e0(local_478);
      return;
    }
  }
  log_InlineLogFACEBOOK("Facebook: MsgRegisterFB, forbiden name");
  FUN_14007a560(local_478);
  pIVar6 = theInstance();
  uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_ERROR_ILLEGAL_NAME");
  local_498 = 1;
  local_4a0 = 0;
  local_4a8 = 0;
  local_4b0 = (uint)local_4b0._2_2_ << 0x10;
  local_4b8 = CONCAT22(local_4b8._2_2_,0x834);
  local_4c0 = CONCAT44(local_4c0._4_4_,0xffffff);
  local_4c8 = 0;
  iVar4 = FUN_14007a620(local_478,"SYSTEM","ALLUSERS",uVar7);
  if (iVar4 != 0) {
    (**(code **)(*param_1 + 0x20))(param_1,local_478);
  }
  FUN_14007a5e0(local_478);
  return;
}

// ==== CMsgRegisterFB@world_kernel::vfunc_0  @140085060  [high:rtti-vtable]  (orig: FUN_140085060)
undefined8 * FUN_140085060(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgRegisterFB::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgRegisterFB@world_kernel::helper_1400856e0  @1400856e0  [medium:callgraph-r0]  (orig: FUN_1400856e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400856e0(undefined8 param_1,undefined8 param_2,ulonglong param_3,ulonglong param_4,
             undefined8 param_5,int param_6,undefined4 param_7,undefined4 param_8,undefined4 param_9
             )

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  undefined1 auStack_978 [32];
  undefined4 local_958;
  undefined8 local_950;
  undefined8 local_948;
  int local_940;
  int local_938;
  int local_930;
  int local_928;
  undefined4 local_920;
  undefined4 local_918;
  undefined4 local_910;
  int local_908;
  int local_900;
  int local_8f8;
  int local_8f0;
  int local_8e8;
  int local_8e0;
  undefined1 *local_8d8;
  undefined1 *local_8d0;
  int local_8c8;
  int local_8c4;
  int local_8c0;
  int local_8bc;
  ulonglong local_8b8;
  longlong local_8b0;
  ulonglong local_8a8;
  undefined1 local_898;
  undefined8 local_897;
  undefined8 local_88f;
  undefined8 local_887;
  undefined8 local_87f;
  undefined8 local_877;
  undefined8 local_86f;
  undefined8 local_867;
  undefined8 local_85f;
  undefined8 local_857;
  undefined1 local_84f;
  char local_848;
  undefined1 local_847 [1022];
  undefined1 local_449;
  char local_448;
  undefined1 local_447 [1022];
  undefined1 local_49;
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_978;
  local_8b8 = param_3;
  local_8a8 = param_4;
  log_InlineLogWARNING("CuserListFB::CreateNewPlayer idUin=%u");
  uVar7 = FUN_140067320();
  local_8b0 = FUN_140073c40(uVar7,0x3ea);
  if (local_8b0 == 0) {
    return 0;
  }
  if ((0x3ea < param_6) && ((param_6 < 0x3ed || ((2000 < param_6 && (param_6 < 0x7d3)))))) {
    switch(param_7) {
    case 0:
    case 1:
      iVar12 = 100;
      break;
    case 2:
    case 3:
      iVar12 = 10;
      break;
    case 4:
    case 5:
      iVar12 = 0x28;
      break;
    case 6:
    case 7:
      iVar12 = 0x14;
      break;
    case 8:
    case 9:
      iVar12 = 0x32;
      break;
    case 10:
    case 0xb:
      iVar12 = 0x3c;
      break;
    case 0xc:
    case 0xd:
    case 0xe:
    case 0xf:
      iVar12 = 0x50;
      break;
    default:
      iVar12 = 0x14;
    }
    local_8bc = 0;
    iVar2 = tq::RandGet(7);
    iVar3 = tq::RandGet(10);
    local_8c8 = iVar3 + 0x156 + iVar2 * 100;
    if (iVar12 == 0x3c) {
      if ((param_6 / 1000) % 10 == 1) {
        local_8c8 = 0x3c;
      }
      else {
        iVar2 = tq::RandGet(7);
        local_8c8 = iVar2 * 100 + 0x168;
      }
      iVar2 = 4;
      iVar13 = 0x94ffd;
      iVar3 = 2;
      iVar14 = 3;
      iVar15 = 1;
    }
    else if (iVar12 == 100) {
      iVar14 = 0;
      iVar2 = 3;
      iVar3 = 5;
      iVar15 = 2;
      iVar13 = 0x66db5;
    }
    else if (iVar12 == 0x50) {
      iVar2 = 3;
      iVar3 = 0;
      iVar14 = 5;
      iVar15 = 2;
      iVar13 = 0x96b55;
    }
    else if (iVar12 == 0x46) {
      iVar2 = 3;
      iVar3 = 0;
      iVar14 = 4;
      iVar15 = 3;
      iVar13 = 0x953e5;
    }
    else if (iVar12 == 0x32) {
      iVar2 = 1;
      iVar3 = 0;
      iVar15 = 8;
      iVar14 = 1;
      iVar13 = 0x92cd5;
    }
    else if (iVar12 == 0x28) {
      iVar2 = 1;
      iVar3 = 0;
      iVar14 = 2;
      iVar15 = 7;
      iVar13 = 0x7a24d;
      local_8bc = 0x100590;
    }
    else if (iVar12 == 10) {
      iVar2 = 3;
      iVar3 = 0;
      iVar14 = 5;
      iVar15 = 2;
      iVar13 = 0x642bd;
    }
    else {
      iVar12 = 0x14;
      iVar3 = 0;
      iVar15 = 2;
      iVar2 = 3;
      iVar14 = 5;
      iVar13 = 0x642bd;
    }
    local_8c0 = (iVar3 + iVar2 * 8 + iVar15 + iVar14) * 3;
    iVar11 = (param_6 / 1000) % 10;
    if (iVar11 == 1) {
      if (iVar12 == 0x32) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0x67 - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x3c) {
        iVar11 = tq::RandGet(0x14);
        param_6 = param_6 + (iVar11 + (0x6d - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x46) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0x9a - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x50) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0xa4 - param_6 / 10000)) * 10000;
      }
      else {
        iVar11 = tq::RandGet(0x66);
        param_6 = param_6 + 10000 + (iVar11 - param_6 / 10000) * 10000;
      }
    }
    else if (iVar11 == 2) {
      if (iVar12 == 0x32) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0x123 - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x3c) {
        iVar11 = tq::RandGet(0x14);
        param_6 = param_6 + (iVar11 + (300 - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x46) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0x159 - param_6 / 10000)) * 10000;
      }
      else if (iVar12 == 0x50) {
        iVar11 = tq::RandGet(5);
        param_6 = param_6 + (iVar11 + (0x163 - param_6 / 10000)) * 10000;
      }
      else {
        iVar11 = tq::RandGet(0x5a);
        param_6 = param_6 + (iVar11 + (0xc9 - param_6 / 10000)) * 10000;
      }
    }
    else {
      param_6 = param_6 + (param_6 / 1000) * -1000 + 1000;
      param_6 = param_6 + (param_6 / 10000) * -10000 + 10000;
    }
    if (DAT_140975af8 == 0) {
      local_958 = 0x128;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar9 = DAT_140975af8;
    if (DAT_140975af8 == 0) {
      local_958 = 0x170;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar1 = FUN_140056a60();
      local_8c4 = 0;
      local_448 = '\0';
      if (cVar1 != '\0') {
        local_8c4 = 0xff;
      }
      memset(local_447,0,0x3ff);
      local_898 = 0;
      local_897 = 0;
      local_88f = 0;
      local_887 = 0;
      local_87f = 0;
      local_877 = 0;
      local_86f = 0;
      local_867 = 0;
      local_85f = 0;
      local_857 = 0;
      local_84f = 0;
      cVar1 = FUN_140056910(lVar9,param_8,&local_898);
      if (cVar1 == '\0') {
        local_958 = 0x17d;
        log_InlineLogERROR(
                          "CUserList::CreateNewPlayer, idAccount[%lu] szName[%s] can not find channel_account at %s, %d"
                          );
      }
      else {
        local_84f = 0;
        if (DAT_140975c00 == '\0') {
          local_8d8 = &local_898;
          local_8e0 = local_8c4;
          local_910 = *(undefined4 *)(local_8b0 + 0xc);
          local_918 = *(undefined4 *)(local_8b0 + 8);
          local_920 = 0x3ea;
          local_928 = 100;
          local_930 = iVar3 * 5;
          local_938 = local_8c0;
          local_940 = local_8c8;
          local_948 = CONCAT44(local_948._4_4_,param_6);
          local_950 = local_8b8;
          local_958 = param_9;
          local_908 = iVar14;
          local_900 = iVar15;
          local_8f8 = iVar2;
          local_8f0 = iVar3;
          local_8e8 = iVar12;
          _snprintf(&local_448,0x400,
                    "INSERT cq_user SET account_id=%u, uin=%u, name=\'%s\',lookface=%d,hair=%d,life=%d,mana=%d,money=%u,recordmap_id=%u, recordx=%u, recordy=%u,strength=%d,speed=%d,health=%d,soul=%d,profession=%d,business=%d,channel_account=\'%s\'"
                   );
        }
        else {
          local_8d0 = &local_898;
          local_8d8 = (undefined1 *)CONCAT44(local_8d8._4_4_,local_8c4);
          local_908 = *(int *)(local_8b0 + 0xc);
          local_910 = *(undefined4 *)(local_8b0 + 8);
          local_918 = 0x3ea;
          local_920 = 100;
          local_928 = iVar3 * 5;
          local_930 = local_8c0;
          local_938 = local_8c8;
          local_948 = local_8a8;
          local_950 = local_8b8;
          local_958 = param_9;
          local_940 = param_6;
          local_900 = iVar14;
          local_8f8 = iVar15;
          local_8f0 = iVar2;
          local_8e8 = iVar3;
          local_8e0 = iVar12;
          _snprintf(&local_448,0x400,
                    "INSERT cq_user SET account_id=%u, uin=%u, name=\'%s\',lastname=\'%s\',lookface=%d,hair=%d,life=%d,mana=%d,money=%u,recordmap_id=%u, recordx=%u, recordy=%u,strength=%d,speed=%d,health=%d,soul=%d,profession=%d,business=%d,channel_account=\'%s\'"
                   );
        }
        local_49 = 0;
        uVar7 = FUN_140054dc0();
        plVar8 = (longlong *)InstanceGet(uVar7);
        cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,&local_448,1);
        if (cVar1 != '\0') {
          uVar7 = FUN_140054dc0();
          plVar8 = (longlong *)InstanceGet(uVar7);
          uVar4 = (**(code **)(*plVar8 + 0x18))(plVar8);
          if (DAT_140975b60 != (longlong *)0x0) {
            lVar9 = (**(code **)(*DAT_140975b60 + 0x70))();
            local_848 = '\0';
            memset(local_847,0,0x3ff);
            if ((iVar13 != 0) &&
               (lVar10 = (**(code **)(*DAT_140975b60 + 0x70))(DAT_140975b60,iVar13), lVar10 != 0)) {
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                                 (*(longlong **)(lVar10 + 8),0x15);
              uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                                 (*(longlong **)(lVar10 + 8),0x16);
              local_940 = (**(code **)(*plVar8 + 0x48))(plVar8);
              local_938 = 4;
              local_948 = CONCAT44(local_948._4_4_,uVar5);
              local_950 = CONCAT44(local_950._4_4_,uVar4);
              local_958 = uVar4;
              _snprintf(&local_848,0x400,
                        "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,position=%d, accumulate_num = 1"
                       );
              local_449 = 0;
              uVar7 = FUN_140054dc0();
              plVar8 = (longlong *)InstanceGet(uVar7);
              cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,1);
              if (cVar1 != '\0') {
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                uVar5 = (**(code **)(*plVar8 + 0x18))(plVar8);
                local_928 = 0;
                local_930 = 0;
                local_938 = 0;
                local_940 = 0;
                local_948 = local_948 & 0xffffffff00000000;
                local_950 = local_950 & 0xffffffff00000000;
                local_958 = 0;
                FUN_1400fe140(uVar5,uVar4,iVar13,0);
                local_958 = uVar5;
                _snprintf(&local_848,0x400,"UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
                local_449 = 0;
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,0,1);
              }
            }
            iVar12 = local_8bc;
            if ((local_8bc != 0) &&
               (lVar10 = (**(code **)(*DAT_140975b60 + 0x70))(DAT_140975b60,local_8bc), lVar10 != 0)
               ) {
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                                 (*(longlong **)(lVar10 + 8),0x15);
              uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar10 + 8) + 0x10))
                                 (*(longlong **)(lVar10 + 8),0x16);
              local_940 = (**(code **)(*plVar8 + 0x48))(plVar8);
              local_938 = 5;
              local_948 = CONCAT44(local_948._4_4_,uVar5);
              local_950 = CONCAT44(local_950._4_4_,uVar4);
              local_958 = uVar4;
              _snprintf(&local_848,0x400,
                        "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,position=%d, accumulate_num = 1"
                       );
              local_449 = 0;
              uVar7 = FUN_140054dc0();
              plVar8 = (longlong *)InstanceGet(uVar7);
              cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,1);
              if (cVar1 != '\0') {
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                uVar5 = (**(code **)(*plVar8 + 0x18))(plVar8);
                local_928 = 0;
                local_930 = 0;
                local_938 = 0;
                local_940 = 0;
                local_948 = local_948 & 0xffffffff00000000;
                local_950 = local_950 & 0xffffffff00000000;
                local_958 = 0;
                FUN_1400fe140(uVar5,uVar4,iVar12,0);
                local_958 = uVar5;
                _snprintf(&local_848,0x400,"UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
                local_449 = 0;
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,0,1);
              }
            }
            if (lVar9 != 0) {
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))
                                 (*(longlong **)(lVar9 + 8),0x15);
              uVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
              plVar8 = (longlong *)
                       (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))
                                 (*(longlong **)(lVar9 + 8),0x16);
              uVar6 = (**(code **)(*plVar8 + 0x48))(plVar8);
              local_930 = tq::RandGet(7);
              local_930 = local_930 + 3;
              local_938 = 3;
              local_958 = uVar4;
              local_940 = uVar6;
              local_948._0_4_ = uVar5;
              local_950._0_4_ = uVar4;
              _snprintf(&local_848,0x400,
                        "INSERT cq_item SET type=%u,owner_id=%u,player_id=%u,amount=%d,amount_limit=%d,position=%d,color=%d, accumulate_num = 1"
                       );
              local_449 = 0;
              uVar7 = FUN_140054dc0();
              plVar8 = (longlong *)InstanceGet(uVar7);
              cVar1 = (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,1);
              if (cVar1 != '\0') {
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                uVar5 = (**(code **)(*plVar8 + 0x18))(plVar8);
                local_928 = 0;
                local_930 = 0;
                local_938 = 0;
                local_940 = 0;
                local_948 = (ulonglong)local_948._4_4_ << 0x20;
                local_950 = (ulonglong)local_950._4_4_ << 0x20;
                local_958 = 0;
                FUN_1400fe140(uVar5,uVar4,0x203a3,0);
                local_958 = uVar5;
                _snprintf(&local_848,0x400,"UPDATE cq_item SET chk_sum=%u WHERE id=%u LIMIT 1");
                local_449 = 0;
                uVar7 = FUN_140054dc0();
                plVar8 = (longlong *)InstanceGet(uVar7);
                (**(code **)(*plVar8 + 0x30))(plVar8,&local_848,0,1);
              }
            }
          }
          return 1;
        }
      }
    }
  }
  return 0;
}

