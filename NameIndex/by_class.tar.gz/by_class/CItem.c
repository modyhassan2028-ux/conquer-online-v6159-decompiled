// ==== CItem::vfunc_3  @1400fd6e0  [high:rtti-vtable]  (orig: FUN_1400fd6e0)
void FUN_1400fd6e0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 8) = param_2;
  return;
}

// ==== CItem::ctor_or_dtor  @1400fd8d0  [high:vtable-assign]  (orig: FUN_1400fd8d0)
undefined8 * FUN_1400fd8d0(undefined8 *param_1,undefined4 param_2)

{
  FUN_1402b5540();
  *param_1 = CItem::vftable;
  param_1[4] = 0;
  param_1[6] = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = param_2;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  *(undefined1 *)(param_1 + 0xc) = 1;
  *(undefined4 *)((longlong)param_1 + 100) = 0;
  *(undefined4 *)(param_1 + 0xd) = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[5] = 0;
  *(undefined1 *)((longlong)param_1 + 0x6c) = 1;
  *(undefined1 *)((longlong)param_1 + 0x6d) = 0;
  *(undefined1 *)((longlong)param_1 + 0x6e) = 0;
  *(undefined4 *)(param_1 + 1) = 0x1004;
  *(undefined4 *)(param_1 + 7) = 0xffffffff;
  return param_1;
}

// ==== CItem::vfunc_2  @1400fd960  [high:rtti-vtable]  (orig: FUN_1400fd960)
undefined4 FUN_1400fd960(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CItem::vfunc_1  @1400fd970  [high:rtti-vtable]  (orig: FUN_1400fd970)
void FUN_1400fd970(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),0);
                    /* WARNING: Could not recover jumptable at 0x0001400fd98a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1);
  return;
}

// ==== CItem::helper_140101310  @140101310  [medium:callgraph-r0]  (orig: FUN_140101310)
void FUN_140101310(void *param_1)

{
  if ((DAT_140975cf0 & 1) == 0) {
    DAT_140975cf0 = DAT_140975cf0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ce8,"CItem");
    atexit((_func_5014 *)&LAB_1406d66c0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140101365. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975ce8,param_1);
  return;
}

// ==== CItem::helper_140103e00  @140103e00  [medium:callgraph-r0]  (orig: FUN_140103e00)
void FUN_140103e00(longlong *param_1)

{
  uint uVar1;
  
  *param_1 = (longlong)CItem::vftable;
  if ((param_1[2] != 0) && ((char)param_1[0xc] != '\0')) {
    uVar1 = (**(code **)(*param_1 + 8))();
    if ((uVar1 < 4100000000) || (*(int *)((longlong)param_1 + 100) == 0)) {
      (*(code *)**(undefined8 **)param_1[2])((undefined8 *)param_1[2],1);
    }
    else {
      (*(code *)**(undefined8 **)param_1[2])((undefined8 *)param_1[2],0);
    }
    param_1[2] = 0;
  }
  if ((longlong *)param_1[8] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[8] + 8))();
  }
  if ((longlong *)param_1[9] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[9] + 8))();
  }
  if ((longlong *)param_1[10] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[10] + 8))();
  }
  if ((longlong *)param_1[0xb] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[0xb] + 8))();
  }
  FUN_1402b55a0(param_1);
  return;
}

// ==== CItem::vfunc_0  @1401064e0  [high:rtti-vtable]  (orig: FUN_1401064e0)
undefined8 FUN_1401064e0(undefined8 param_1,uint param_2)

{
  FUN_140103e00();
  if ((param_2 & 1) != 0) {
    FUN_140101310(param_1);
  }
  return param_1;
}

// ==== CItem::IsValidPt  @140322f60  [high:log-string]  (orig: FUN_140322f60)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_140322f60(longlong *param_1,uint param_2,uint param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined8 *puVar7;
  longlong lVar8;
  ulonglong uVar9;
  undefined8 uVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  longlong local_60;
  undefined8 *local_58;
  longlong local_50;
  longlong local_48;
  longlong *local_38;
  longlong local_30;
  
  puVar11 = (undefined8 *)((undefined8 *)param_1[0x19])[1];
  cVar4 = *(char *)((longlong)puVar11 + 0x29);
  puVar2 = (undefined8 *)param_1[0x19];
  while (cVar4 == '\0') {
    if (*(uint *)(puVar11 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar11[2];
      puVar11 = puVar2;
    }
    else {
      puVar7 = (undefined8 *)*puVar11;
    }
    puVar2 = puVar11;
    puVar11 = puVar7;
    cVar4 = *(char *)((longlong)puVar7 + 0x29);
  }
  local_58 = puVar2;
  local_60 = param_1[0x13];
  puVar11 = (undefined8 *)param_1[0x19];
  if (param_1[0x13] == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar11) || (param_2 < *(uint *)(puVar2 + 3))) {
    local_48 = param_1[0x19];
    local_50 = param_1[0x13];
    plVar12 = &local_50;
  }
  else {
    plVar12 = &local_60;
  }
  plVar1 = (longlong *)*plVar12;
  local_30 = plVar12[1];
  lVar8 = param_1[0x19];
  local_38 = plVar1;
  if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)param_1[0x13])) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_30;
  if (local_30 != lVar8) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (lVar3 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = *(longlong *)(lVar3 + 0x20);
    local_38 = (longlong *)*plVar12;
    local_30 = plVar12[1];
    FUN_140321a80(param_1 + 0x13,&local_50,&local_38);
    if (((lVar8 != 0) && (param_3 != 0)) &&
       (((iVar5 = FUN_1400fda10(lVar8,7,1), 200 < iVar5 &&
         (iVar5 = FUN_1400fda10(lVar8,7,1), iVar5 < 0xcc)) ||
        (iVar5 = FUN_1400fda10(lVar8,7,1), iVar5 == 0xd0)))) {
      FUN_1400fda10(lVar8,0x1a,1);
      FUN_1400fda10(lVar8,7,1);
      FUN_1400fda10(lVar8,2,1);
      FUN_1400fda10(lVar8,3,1);
      FUN_1400fda10(lVar8,1,1);
      uVar9 = FUN_1400fda10(lVar8,0,1);
      tq::SysLogSave("unloaditem",
                     "unload storage item from:%d, item id:%u, type:%u, player_id:%u, owner_id:%u, position:%u, accumulate:%u"
                     ,(ulonglong)param_3,uVar9 & 0xffffffff);
    }
    cVar4 = FUN_140101370(lVar8);
    if (cVar4 == '\0') {
      log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","CItem::IsValidPt(pItem)",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\itemmgr.cpp"
                        );
      uVar10 = 0;
    }
    else {
      (**(code **)(*param_1 + 0x180))(param_1,param_2);
      (**(code **)(*param_1 + 0x160))(param_1,param_2);
      if (((longlong *)param_1[0x2e] != (longlong *)0x0) &&
         (uVar6 = (**(code **)(*(longlong *)param_1[0x2e] + 8))(), uVar6 == param_2)) {
        param_1[0x2e] = 0;
      }
      FUN_140103eb0(lVar8);
      uVar10 = 1;
    }
    return uVar10;
  }
  return 0;
}

