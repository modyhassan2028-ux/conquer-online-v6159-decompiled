// ==== CPigeonActor@adapter::helper_140162170  @140162170  [medium:callgraph-r0]  (orig: FUN_140162170)
undefined8 FUN_140162170(longlong *param_1)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = (**(code **)(*param_1 + 0xc0))();
  if (iVar1 == 0) {
    uVar2 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
    if ((((0x32 < uVar2) || (*(ushort *)(param_1 + 0x214) < 10)) &&
        ((uVar2 = (**(code **)(param_1[2] + 0x70))(param_1 + 2), 100 < uVar2 ||
         (*(ushort *)(param_1 + 0x214) < 0x14)))) && (*(ushort *)(param_1 + 0x214) < 0x1e)) {
      return 0;
    }
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0xc0))(param_1);
    if ((iVar1 != 1) || (*(ushort *)(param_1 + 0x214) < 0x32)) {
      if (*(ushort *)(param_1 + 0x214) < 100) {
        return 0;
      }
      return 1;
    }
  }
  return 1;
}

// ==== CPigeonActor@adapter::helper_140193cf0  @140193cf0  [medium:callgraph-r0]  (orig: FUN_140193cf0)
bool FUN_140193cf0(longlong param_1)

{
  longlong lVar1;
  int iVar2;
  
  if (*(uint *)(param_1 + 0x100) < 6) {
    lVar1 = FUN_140373200(param_1 + 0xe78);
    if (lVar1 < 30000000) {
      iVar2 = FUN_14018eb30(param_1);
      return 0xf9 < iVar2;
    }
  }
  return true;
}

// ==== CPigeonActor@adapter::vfunc_1  @1405b94e0  [high:rtti-vtable]  (orig: FUN_1405b94e0)
void FUN_1405b94e0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CPigeonActor@adapter::vfunc_4  @1405b9550  [high:rtti-vtable]  (orig: FUN_1405b9550)
undefined8 FUN_1405b9550(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405b95b1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x18))(lVar2 + 0x10);
      return uVar3;
    }
  }
  return 0;
}

// ==== CPigeonActor@adapter::vfunc_1  @1405b95c0  [high:rtti-vtable]  (orig: FUN_1405b95c0)
void FUN_1405b95c0(longlong param_1,undefined8 param_2,longlong param_3,undefined8 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  
  if (param_3 != 0) {
    plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (plVar1 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*plVar1 + 0x150))(plVar1,param_5,param_3);
  }
  return;
}

// ==== CPigeonActor@adapter::vfunc_2  @1405b9670  [high:rtti-vtable]  (orig: FUN_1405b9670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b9670(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  undefined4 param_5,undefined1 param_6)

{
  int iVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    local_4c8 = CONCAT44(local_4c8._4_4_,0x84);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 == 0) {
      local_4c8 = CONCAT44(local_4c8._4_4_,0x8c);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_14015b240(local_478);
      local_498 = param_6;
      local_4a0 = param_5;
      local_4a8 = 0;
      local_4b0 = 0;
      local_4b8 = 0x9c4;
      local_4c0 = 0xffffff;
      local_4c8 = 0;
      iVar1 = FUN_14015b300(local_478,param_3,"ALLUSERS",param_4);
      if (iVar1 != 0) {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
      }
      FUN_14015b2c0(local_478);
    }
  }
  return;
}

// ==== CPigeonActor@adapter::vfunc_6  @1405b97c0  [high:rtti-vtable]  (orig: FUN_1405b97c0)
undefined4 FUN_1405b97c0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 != 0) {
      return *(undefined4 *)(lVar2 + 0xfa4);
    }
  }
  return 0;
}

// ==== CPigeonActor@adapter::vfunc_7  @1405b9820  [high:rtti-vtable]  (orig: FUN_1405b9820)
undefined4 FUN_1405b9820(longlong param_1)

{
  undefined4 uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar3 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar3 != 0) {
      uVar1 = FUN_140371860(lVar3 + 0xe78);
      return uVar1;
    }
  }
  return 0;
}

// ==== CPigeonActor@adapter::vfunc_8  @1405b9890  [high:rtti-vtable]  (orig: FUN_1405b9890)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405b9890(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  longlong local_4a0;
  longlong local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar5 == (longlong *)0x0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0xde);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x2b0))(plVar5);
    if (plVar5 == (longlong *)0x0) {
      uVar6 = 0;
    }
    else {
      local_4b8 = 0;
      cVar2 = (**(code **)(plVar5[2] + 0x2e0))(plVar5 + 2,0x1d,-param_3);
      if (cVar2 == '\0') {
        uVar6 = 0;
      }
      else {
        uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        local_4b8._0_4_ = (int)param_3;
        FUN_1401742b0(plVar5,10,uVar3);
        lVar1 = plVar5[0x1e2];
        (**(code **)(plVar5[2] + 0x18))(plVar5 + 2);
        local_4b0 = 600;
        local_4b8 = CONCAT44(local_4b8._4_4_,(int)lVar1);
        local_4a8 = param_4;
        local_4a0 = param_3;
        local_498 = param_3;
        tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t%u\t%u\t%d\t%d\t1\t");
        FUN_14039e680(local_478);
        iVar4 = FUN_14039e700(local_478,param_2,0x1d,*(undefined4 *)((longlong)plVar5 + 0xfa4));
        if (iVar4 != 0) {
          (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_478);
        }
        FUN_14039e6d0(local_478);
        uVar6 = 1;
      }
    }
  }
  return uVar6;
}

// ==== CPigeonActor@adapter::vfunc_9  @1405b9a20  [high:rtti-vtable]  (orig: FUN_1405b9a20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405b9a20(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  undefined8 uVar6;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  longlong local_4a0;
  longlong local_498;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  plVar5 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar5 == (longlong *)0x0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x115);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x2b0))(plVar5);
    if (plVar5 == (longlong *)0x0) {
      uVar6 = 0;
    }
    else {
      local_4b8 = 0;
      cVar2 = (**(code **)(plVar5[2] + 0x2e0))(plVar5 + 2,0x2d,-param_3);
      if (cVar2 == '\0') {
        uVar6 = 0;
      }
      else {
        uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
        local_4b8._0_4_ = (int)param_3;
        FUN_140174470(plVar5,10,uVar3);
        lVar1 = plVar5[0x1e2];
        (**(code **)(plVar5[2] + 0x18))(plVar5 + 2);
        local_4b0 = 600;
        local_4b8 = CONCAT44(local_4b8._4_4_,(int)lVar1);
        local_4a8 = param_4;
        local_4a0 = param_3;
        local_498 = param_3;
        tq::MyLogSave("gmlog/emoney_mono_buy","%u\t%s\t%u\t%u\t%u\t%d\t%d\t1\t");
        FUN_14039e680(local_478);
        uVar3 = FUN_140371860(plVar5 + 0x1cf);
        iVar4 = FUN_14039e700(local_478,param_2,0x2d,uVar3);
        if (iVar4 != 0) {
          (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_478);
        }
        FUN_14039e6d0(local_478);
        uVar6 = 1;
      }
    }
  }
  return uVar6;
}

// ==== CPigeonActor@adapter::vfunc_5  @1405b9bc0  [high:rtti-vtable]  (orig: FUN_1405b9bc0)
undefined8 FUN_1405b9bc0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405b9c52. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x70))(lVar2 + 0x10);
  return uVar3;
}

// ==== CPigeonActor@adapter::vfunc_10  @1405b9c60  [high:rtti-vtable]  (orig: FUN_1405b9c60)
ulonglong FUN_1405b9c60(longlong param_1)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  return (ulonglong)(*(int *)(lVar2 + 0xfc0) == 1);
}

// ==== CPigeonActor@adapter::vfunc_11  @1405b9d00  [high:rtti-vtable]  (orig: FUN_1405b9d00)
undefined1 FUN_1405b9d00(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar2 + 0x51c);
}

// ==== CPigeonActor@adapter::vfunc_13  @1405b9da0  [high:rtti-vtable]  (orig: FUN_1405b9da0)
ulonglong FUN_1405b9da0(longlong param_1)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar3 = FUN_140162170(lVar2);
  return uVar3;
}

// ==== CPigeonActor@adapter::vfunc_14  @1405b9e40  [high:rtti-vtable]  (orig: FUN_1405b9e40)
ulonglong FUN_1405b9e40(longlong param_1)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  uVar3 = FUN_140193cf0(lVar2);
  return uVar3;
}

// ==== CPigeonActor@adapter::vfunc_15  @1405b9ee0  [high:rtti-vtable]  (orig: FUN_1405b9ee0)
undefined2 FUN_1405b9ee0(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined2 *)(lVar2 + 0x10a0);
}

// ==== CPigeonActor@adapter::vfunc_16  @1405b9f80  [high:rtti-vtable]  (orig: FUN_1405b9f80)
void FUN_1405b9f80(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x0001405b9f9a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x540))(plVar1,param_2);
  return;
}

// ==== CPigeonActor@adapter::vfunc_17  @1405b9fb0  [high:rtti-vtable]  (orig: FUN_1405b9fb0)
undefined8 FUN_1405b9fb0(longlong param_1,undefined4 param_2)

{
  int iVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar2 == (longlong *)0x0) {
    plVar2 = (longlong *)FUN_140087ed0();
    iVar1 = (**(code **)(*plVar2 + 0x540))(plVar2,param_2);
    if (iVar1 != 0) {
      plVar2 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x0001405ba043. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*plVar2 + 0x548))(plVar2,param_2);
      return uVar3;
    }
  }
  else {
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (plVar2 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405ba015. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar3 = (**(code **)(*plVar2 + 0x50))(plVar2);
      return uVar3;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 1;
}

// ==== CPigeonActor@adapter::vfunc_0  @1405ba050  [high:rtti-vtable]  (orig: FUN_1405ba050)
void FUN_1405ba050(longlong param_1)

{
  FUN_1405ba0b0(param_1 + -8);
  return;
}

// ==== CPigeonActor@adapter::helper_1405ba0b0  @1405ba0b0  [medium:callgraph-r0]  (orig: FUN_1405ba0b0)
undefined8 * FUN_1405ba0b0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CPigeonActor::vftable;
  param_1[1] = adapter::CPigeonActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CPigeonActor@adapter::vfunc_0  @1405ba100  [high:rtti-vtable]  (orig: FUN_1405ba100)
void FUN_1405ba100(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong *plVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x20))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(*plVar1 + 0x2b0))(plVar1);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(ushort *)(param_3 + 8) - 4,0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CPigeonActor@adapter::vfunc_3  @1405ba200  [high:rtti-vtable]  (orig: FUN_1405ba200)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ba200(longlong param_1,longlong param_2,longlong param_3,undefined4 param_4,
                  undefined1 param_5)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if ((param_2 == 0) || (param_3 == 0)) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x9a);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14015b240(local_488);
    local_4a8 = param_5;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = 0x9c4;
    local_4d0 = 0xffffff;
    local_4d8 = 0;
    local_4b0 = param_4;
    iVar1 = FUN_14015b300(local_488,param_2,"ALLUSERS",param_3);
    if (iVar1 != 0) {
      plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar2 + 0x68))(plVar2,local_488,0xffffffff);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CPigeonActor@adapter::vfunc_12  @1405ba310  [high:rtti-vtable]  (orig: FUN_1405ba310)
undefined8 FUN_1405ba310(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_2 + 10),
                           param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    uVar1 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x58))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
      uVar1 = 1;
    }
  }
  return uVar1;
}

