// ==== CCrossMsgLeagueRank::ctor_or_dtor  @14045c670  [high:vtable-assign]  (orig: FUN_14045c670)
undefined8 * FUN_14045c670(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueRank::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLeagueRank::ctor_or_dtor  @14045c6c0  [high:vtable-assign]  (orig: FUN_14045c6c0)
void FUN_14045c6c0(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueRank::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLeagueRank::vfunc_1  @14045c6f0  [high:rtti-vtable]  (orig: FUN_14045c6f0)
ulonglong FUN_14045c6f0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c64);
}

// ==== CCrossMsgLeagueRank::vfunc_3  @14045c720  [high:rtti-vtable]  (orig: FUN_14045c720)
void FUN_14045c720(longlong param_1)

{
  longlong *plVar1;
  longlong lVar2;
  ushort uVar3;
  
  plVar1 = (longlong *)FUN_140087ed0();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar3 = 0;
  if ((**(short **)(param_1 + 0x428) == 0) && ((char)(*(short **)(param_1 + 0x428))[1] == '\x01')) {
    (**(code **)(*plVar1 + 0x488))(plVar1);
  }
  lVar2 = *(longlong *)(param_1 + 0x428);
  if (*(short *)(lVar2 + 4) != 0) {
    do {
      (**(code **)(*plVar1 + 0x480))(plVar1,(ulonglong)uVar3 * 0x2c + 8 + lVar2);
      lVar2 = *(longlong *)(param_1 + 0x428);
      uVar3 = uVar3 + 1;
    } while (uVar3 < *(ushort *)(lVar2 + 4));
  }
  return;
}

// ==== CCrossMsgLeagueRank::ctor_or_dtor  @14045c7e0  [high:vtable-assign]  (orig: FUN_14045c7e0)
undefined8 * FUN_14045c7e0(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueRank::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

