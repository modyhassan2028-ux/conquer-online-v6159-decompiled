// ==== CMsg2ndPwd::helper_1403f4130  @1403f4130  [medium:callgraph-r0]  (orig: FUN_1403f4130)
undefined8 FUN_1403f4130(longlong param_1,undefined1 param_2,undefined1 param_3)

{
  longlong lVar1;
  
  if (*(undefined1 **)(param_1 + 0x428) == (undefined1 *)0x0) {
    return 0;
  }
  *(undefined4 *)(param_1 + 8) = 0x9c6d;
  *(undefined4 *)(param_1 + 0xc) = 2;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 1) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsg2ndPwd::ctor_or_dtor  @14044e580  [high:vtable-assign]  (orig: FUN_14044e580)
undefined8 * FUN_14044e580(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsg2ndPwd::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsg2ndPwd::ctor_or_dtor  @14044e5d0  [high:vtable-assign]  (orig: FUN_14044e5d0)
void FUN_14044e5d0(undefined8 *param_1)

{
  *param_1 = CMsg2ndPwd::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsg2ndPwd::vfunc_1  @14044e700  [high:rtti-vtable]  (orig: FUN_14044e700)
ulonglong FUN_14044e700(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8d5);
}

// ==== CMsg2ndPwd::ctor_or_dtor  @14044e760  [high:vtable-assign]  (orig: FUN_14044e760)
undefined8 * FUN_14044e760(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsg2ndPwd::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsg2ndPwd::vfunc_3  @14044e7b0  [high:rtti-vtable]  (orig: FUN_14044e7b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14044e7b0(longlong param_1)

{
  short sVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  ulong uVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  tm *ptVar10;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  __time64_t local_468;
  longlong local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_460 = param_1;
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar8 = (longlong *)FUN_140087650(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x88))(plVar8,param_1);
  if ((plVar8 != (longlong *)0x0) &&
     ((cVar3 = FUN_140167b70(plVar8), cVar3 == '\0' || (**(short **)(param_1 + 0x428) == 1)))) {
    sVar1 = **(short **)(param_1 + 0x428);
    if (sVar1 == 0) {
      iVar4 = FUN_1401642c0(plVar8);
      if ((iVar4 != 0) && (iVar4 = FUN_140164270(plVar8), iVar4 != 0)) {
        uVar5 = tq::TimeStampGet();
        uVar6 = FUN_140164270(plVar8);
        if (uVar5 / 100 < uVar6) {
          FUN_140164280(plVar8,0);
          pIVar9 = theInstance();
          lVar2 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SECONDPWD_CANCEL_FORGET");
          (**(code **)(lVar2 + 0x358))(plVar8 + 2,uVar7);
          FUN_14044e620(param_1,plVar8,5);
        }
      }
    }
    else if (sVar1 == 1) {
      iVar4 = FUN_1401642c0(plVar8);
      if (iVar4 != 0) {
        iVar4 = FUN_1401642c0(plVar8);
        if (iVar4 == *(int *)(*(longlong *)(param_1 + 0x428) + 8)) {
          *(undefined1 *)((longlong)plVar8 + 0x51c) = 1;
          pIVar9 = theInstance();
          lVar2 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SECONDPWD_CHECK");
          (**(code **)(lVar2 + 0x358))(plVar8 + 2,uVar7);
          FUN_14044e620(param_1,plVar8,5);
          cVar3 = FUN_140167b70(plVar8);
          if (cVar3 != '\0') {
            FUN_1403f4080(local_448);
            cVar3 = FUN_1403f4130(local_448,1);
            if (cVar3 == '\0') {
              local_478 = 0x6e;
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1403f40d0(local_448);
            }
            else {
              (**(code **)(*plVar8 + 0x138))(plVar8,local_448,4);
              FUN_1403f40d0(local_448);
            }
          }
        }
        else {
          FUN_14044e6c0(param_1,plVar8,0);
        }
      }
    }
    else if (sVar1 == 2) {
      iVar4 = FUN_1401642c0(plVar8);
      if ((iVar4 != 0) && (iVar4 = FUN_140164270(plVar8), iVar4 == 0)) {
        local_468 = 0;
        _time64(&local_468);
        local_468 = local_468 + 0x93a80;
        ptVar10 = _localtime64(&local_468);
        if (ptVar10 == (tm *)0x0) {
          local_478 = 0xc6;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          FUN_140164280(plVar8,(((ptVar10->tm_year % 100) * 100 + 1 + ptVar10->tm_mon) * 100 +
                               ptVar10->tm_mday) * 100 + ptVar10->tm_hour);
          pIVar9 = theInstance();
          lVar2 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SECONDPWD_FORGET");
          (**(code **)(lVar2 + 0x358))(plVar8 + 2,uVar7);
          FUN_14044e620(param_1,plVar8,7);
        }
      }
    }
    else if (sVar1 == 3) {
      iVar4 = FUN_1401642c0(plVar8);
      if ((((iVar4 == 0) && (uVar6 = *(uint *)(*(longlong *)(param_1 + 0x428) + 8), uVar6 != 0)) &&
          (uVar6 < 1000000000)) && (cVar3 = FUN_1401642a0(plVar8), cVar3 != '\0')) {
        pIVar9 = theInstance();
        lVar2 = plVar8[2];
        uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SECONDPWD_SET");
        (**(code **)(lVar2 + 0x358))(plVar8 + 2,uVar7);
        *(undefined1 *)((longlong)plVar8 + 0x51c) = 1;
        FUN_14044e620(param_1,plVar8,5);
      }
    }
    else if ((sVar1 == 4) && (iVar4 = FUN_1401642c0(plVar8), iVar4 != 0)) {
      lVar2 = *(longlong *)(param_1 + 0x428);
      iVar4 = FUN_1401642c0(plVar8);
      if (iVar4 == *(int *)(lVar2 + 4)) {
        uVar6 = *(uint *)(lVar2 + 8);
        if (((uVar6 != 0) && (uVar6 < 1000000000)) && (cVar3 = FUN_1401642a0(plVar8), cVar3 != '\0')
           ) {
          pIVar9 = theInstance();
          lVar2 = plVar8[2];
          uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_SECONDPWD_MODIFY");
          (**(code **)(lVar2 + 0x358))(plVar8 + 2,uVar7);
          iVar4 = FUN_140164270(plVar8);
          if (iVar4 != 0) {
            FUN_140164280(plVar8,0);
          }
          *(undefined1 *)((longlong)plVar8 + 0x51c) = 1;
          FUN_14044e620(param_1,plVar8,5);
        }
      }
      else {
        FUN_14044e6c0(param_1,plVar8,1);
      }
    }
  }
  return;
}

