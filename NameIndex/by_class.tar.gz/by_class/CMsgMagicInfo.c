// ==== CMsgMagicInfo::helper_1402f1dd0  @1402f1dd0  [medium:callgraph-r0]  (orig: FUN_1402f1dd0)
undefined1 FUN_1402f1dd0(undefined8 param_1,undefined8 param_2,undefined4 param_3,byte param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  
  if ((param_4 != 0) && (param_4 < 0x20)) {
    lVar2 = FUN_1402f1610();
    if (lVar2 != 0) {
      uVar1 = FUN_14048c4c0(lVar2,param_3,param_4);
      return uVar1;
    }
  }
  return 0;
}

// ==== CMsgMagicInfo::helper_1402f1e20  @1402f1e20  [medium:callgraph-r0]  (orig: FUN_1402f1e20)
undefined1 FUN_1402f1e20(undefined8 param_1,undefined8 param_2,undefined4 param_3,byte param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  
  if (param_4 < 0x20) {
    lVar2 = FUN_1402f1610();
    if (lVar2 != 0) {
      uVar1 = FUN_14048c770(lVar2,param_3,param_4);
      return uVar1;
    }
  }
  return 0;
}

// ==== CMsgMagicInfo::ctor_or_dtor  @140456f30  [high:vtable-assign]  (orig: FUN_140456f30)
undefined8 * FUN_140456f30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMagicInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMagicInfo::ctor_or_dtor  @140456f80  [high:vtable-assign]  (orig: FUN_140456f80)
void FUN_140456f80(undefined8 *param_1)

{
  *param_1 = CMsgMagicInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMagicInfo::vfunc_1  @140456fb0  [high:rtti-vtable]  (orig: FUN_140456fb0)
ulonglong FUN_140456fb0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x44f);
}

// ==== CMsgMagicInfo::helper_140457190  @140457190  [medium:callgraph-r0]  (orig: FUN_140457190)
ulonglong FUN_140457190(longlong param_1,undefined2 param_2,int param_3,undefined1 param_4)

{
  ulong uVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  undefined4 extraout_var;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_2;
    *(int *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
    uVar1 = tq::TimeGet(0);
    **(ulong **)(param_1 + 0x428) = uVar1;
    *(undefined4 *)(param_1 + 8) = 0x44f;
    *(undefined4 *)(param_1 + 0xc) = 0x1c;
    uVar2 = CONCAT71((int7)(CONCAT44(extraout_var,uVar1) >> 8),1);
  }
  return uVar2;
}

// ==== CMsgMagicInfo::ctor_or_dtor  @140457310  [high:vtable-assign]  (orig: FUN_140457310)
undefined8 * FUN_140457310(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMagicInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMagicInfo::vfunc_3  @140457360  [high:rtti-vtable]  (orig: FUN_140457360)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140457360(longlong param_1)

{
  short sVar1;
  undefined4 *puVar2;
  longlong lVar3;
  char cVar4;
  undefined4 uVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar8 = (longlong *)FUN_140087650(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x88))(plVar8,param_1);
  if (plVar8 != (longlong *)0x0) {
    plVar9 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar8[0x1e2];
    lVar10 = *plVar9;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
    (**(code **)(lVar10 + 0x108))(plVar9,uVar5,(int)lVar3,*puVar2);
    iVar6 = (**(code **)(*plVar8 + 8))(plVar8);
    if (iVar6 != 0) {
      if (*(longlong *)(param_1 + 0x428) == 0) {
        local_478 = 0x8d;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 0xe);
        if (sVar1 == 2) {
          lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar10 + 0x100) == 0) {
            local_478 = 0x144;
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar7 = 0;
          }
          else {
            uVar7 = *(undefined8 *)(lVar10 + 0x100);
          }
          cVar4 = FUN_1402f1e20(uVar7,iVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                                *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10));
          if (cVar4 != '\0') {
            FUN_140456f30(local_458);
            cVar4 = FUN_140457190(local_458,3,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                                  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10));
            if (cVar4 != '\0') {
              (**(code **)(plVar8[2] + 0x350))(plVar8 + 2,local_458);
            }
            FUN_140456f80(local_458);
          }
        }
        else if (sVar1 == 5) {
          lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          if (*(longlong *)(lVar10 + 0x100) == 0) {
            local_478 = 0x144;
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar7 = 0;
          }
          else {
            uVar7 = *(undefined8 *)(lVar10 + 0x100);
          }
          FUN_1402f1dd0(uVar7,iVar6,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                        *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10));
        }
      }
    }
  }
  return;
}

// ==== CMsgMagicInfo::helper_14048c770  @14048c770  [medium:callgraph-r1]  (orig: FUN_14048c770)
undefined4 FUN_14048c770(undefined8 param_1,undefined8 param_2,byte param_3)

{
  uint uVar1;
  longlong lVar2;
  
  lVar2 = FUN_14048b5f0();
  if (lVar2 != 0) {
    uVar1 = FUN_140418e40(lVar2,8);
    if ((uVar1 >> (param_3 & 0x1f) & 1) != 0) {
      FUN_140418d90(lVar2,7,(uint)param_3);
      FUN_140418450(lVar2);
      return 1;
    }
  }
  return 0;
}

