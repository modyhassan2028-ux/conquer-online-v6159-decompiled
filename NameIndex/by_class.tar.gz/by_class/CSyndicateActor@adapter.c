// ==== CSyndicateActor@adapter::helper_140006ce0  @140006ce0  [medium:callgraph-r0]  (orig: FUN_140006ce0)
undefined4 FUN_140006ce0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a0);
}

// ==== CSyndicateActor@adapter::helper_140006cf0  @140006cf0  [medium:callgraph-r0]  (orig: FUN_140006cf0)
undefined4 FUN_140006cf0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x19c);
}

// ==== CSyndicateActor@adapter::helper_140006d10  @140006d10  [medium:callgraph-r1]  (orig: FUN_140006d10)
undefined4 FUN_140006d10(longlong param_1,uint param_2)

{
  if (3 < param_2) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined4 *)(param_1 + 0x1ac + (longlong)(int)param_2 * 4);
}

// ==== CSyndicateActor@adapter::helper_140006d60  @140006d60  [medium:callgraph-r0]  (orig: FUN_140006d60)
undefined4 FUN_140006d60(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1a4);
}

// ==== CSyndicateActor@adapter::helper_140006d70  @140006d70  [medium:callgraph-r0]  (orig: FUN_140006d70)
undefined4 FUN_140006d70(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1bc);
}

// ==== CSyndicateActor@adapter::helper_14008a830  @14008a830  [medium:callgraph-r0]  (orig: FUN_14008a830)
void FUN_14008a830(longlong param_1,int param_2,int param_3,undefined2 param_4)

{
  int local_18;
  int local_14;
  undefined2 local_10;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_18 = param_2;
    local_14 = param_3;
    local_10 = param_4;
    (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
              (*(longlong **)(param_1 + 0x80),8,0x15f9b,0xc,&local_18);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_14008aa10  @14008aa10  [medium:callgraph-r0]  (orig: FUN_14008aa10)
void FUN_14008aa10(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined4 local_18;
  undefined2 local_14;
  undefined4 local_10;
  
  local_18 = param_2;
  local_14 = param_3;
  local_10 = param_4;
  (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
            (*(longlong **)(param_1 + 0x80),8,0x15f9f,0xc,&local_18);
  return;
}

// ==== CSyndicateActor@adapter::helper_140092c80  @140092c80  [medium:callgraph-r0]  (orig: FUN_140092c80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140092c80(longlong param_1,int param_2,longlong param_3)

{
  int iVar1;
  ulonglong uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined1 auStack_4a8 [32];
  undefined4 *local_488;
  uint local_478;
  uint local_474;
  uint local_470;
  undefined8 local_468;
  undefined4 local_458;
  uint local_454;
  int aiStack_450 [262];
  ulonglong local_38;
  
  local_468 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if ((param_2 != 0) &&
     (uVar5 = (uint)(*(longlong *)(param_3 + 0x20) - *(longlong *)(param_3 + 0x18) >> 2), uVar5 != 0
     )) {
    local_458 = local_458 & 0xffffff00;
    memset((void *)((longlong)&local_458 + 1),0,0x417);
    uVar3 = 8;
    local_478 = 8;
    local_454 = 0;
    uVar4 = 0;
    local_470 = 0;
    local_474 = 0;
    uVar2 = 0;
    local_458 = param_2;
    while ((uint)uVar2 < uVar5) {
      uVar4 = uVar4 + 1;
      local_470 = uVar4;
      if (10000 < uVar4) {
        local_488 = (undefined4 *)CONCAT44(local_488._4_4_,0xf19);
        log_InlineLogERROR(&DAT_1406d9c10);
        break;
      }
      if (0x417 < (ulonglong)uVar3 + 4) {
        local_488 = &local_458;
        (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                  (*(longlong **)(param_1 + 0x80),8,0x15f9a,0x418);
        uVar3 = 8;
        local_478 = 8;
        local_454 = 0;
      }
      if ((ulonglong)(*(longlong *)(param_3 + 0x20) - *(longlong *)(param_3 + 0x18) >> 2) <= uVar2)
      {
        _invalid_parameter_noinfo();
      }
      iVar1 = *(int *)(*(longlong *)(param_3 + 0x18) + uVar2 * 4);
      if (iVar1 != 0) {
        aiStack_450[local_454] = iVar1;
        local_478 = uVar3 + 4;
        local_454 = local_454 + 1;
        uVar3 = local_478;
      }
      local_474 = (uint)uVar2 + 1;
      uVar2 = (ulonglong)local_474;
    }
    if (local_454 != 0) {
      local_488 = &local_458;
      (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
                (*(longlong **)(param_1 + 0x80),8,0x15f9a,0x418);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_140109740  @140109740  [medium:callgraph-r0]  (orig: FUN_140109740)
void FUN_140109740(__uint64 param_1)

{
  if ((DAT_140975d00 & 1) == 0) {
    DAT_140975d00 = DAT_140975d00 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975cf8,"CMessageBoard");
    atexit((_func_5014 *)&LAB_1406d66d0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140109795. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975cf8,param_1);
  return;
}

// ==== CSyndicateActor@adapter::helper_140165640  @140165640  [medium:callgraph-r0]  (orig: FUN_140165640)
undefined4 FUN_140165640(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x11dc);
}

// ==== CSyndicateActor@adapter::helper_140165650  @140165650  [medium:callgraph-r0]  (orig: FUN_140165650)
void FUN_140165650(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x11dc) = param_2;
  return;
}

// ==== CSyndicateActor@adapter::helper_1401657d0  @1401657d0  [medium:callgraph-r0]  (orig: FUN_1401657d0)
void FUN_1401657d0(longlong param_1)

{
  FUN_1403732b0(param_1 + 0xe78);
  return;
}

// ==== CSyndicateActor@adapter::helper_1401667d0  @1401667d0  [medium:callgraph-r0]  (orig: FUN_1401667d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401667d0(int param_1,int param_2,int param_3,int param_4,undefined4 param_5,
                  undefined4 param_6,longlong *param_7)

{
  undefined1 auStack_498 [32];
  int local_478;
  int local_470;
  int local_468;
  int local_460;
  ulong local_458;
  uint local_450;
  undefined4 local_448;
  undefined4 local_440;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_7 == (longlong *)0x0) {
    local_478 = 0x5ed3;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_458 = tq::TimeStampGet();
    local_440 = param_6;
    local_448 = param_5;
    local_450 = param_3 + param_1 * 3 + param_4 * 2 + param_2 ^ local_458;
    local_478 = param_1;
    local_470 = param_2;
    local_468 = param_3;
    local_460 = param_4;
    _snprintf(local_438,0x400,
              "INSERT INTO %s SET type=%u, id_source=%u, id_target=%u, number=%d, time_stamp=%u, chk_sum=%u, source_balance=%d, target_balance=%d"
             );
    local_39 = 0;
    (**(code **)(*param_7 + 0x30))(param_7,local_438,0,1);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_140168b80  @140168b80  [medium:callgraph-r0]  (orig: FUN_140168b80)
undefined1 FUN_140168b80(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x194);
}

// ==== CSyndicateActor@adapter::helper_140168bd0  @140168bd0  [medium:callgraph-r0]  (orig: FUN_140168bd0)
void FUN_140168bd0(longlong param_1)

{
  FUN_1403741d0(param_1 + 0xe78);
  return;
}

// ==== CSyndicateActor@adapter::helper_140168be0  @140168be0  [medium:callgraph-r0]  (orig: FUN_140168be0)
void FUN_140168be0(longlong param_1)

{
  FUN_140374250(param_1 + 0xe78);
  return;
}

// ==== CSyndicateActor@adapter::helper_140168bf0  @140168bf0  [medium:callgraph-r2]  (orig: FUN_140168bf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140168bf0(longlong *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_140374260(param_1 + 0x1cf);
  if (param_3 != '\0') {
    FUN_14039e680(local_448);
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    iVar2 = FUN_14039e700(local_448,uVar1,0x52,param_2);
    if (iVar2 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,1);
    }
    FUN_14039e6d0(local_448);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_14016cb70  @14016cb70  [medium:callgraph-r0]  (orig: FUN_14016cb70)
uint FUN_14016cb70(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
  return (uint)(uVar2 >> 1) & 1;
}

// ==== CSyndicateActor@adapter::helper_14016ccf0  @14016ccf0  [medium:callgraph-r0]  (orig: FUN_14016ccf0)
uint FUN_14016ccf0(longlong param_1)

{
  uint extraout_var;
  longlong *plVar1;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  (**(code **)(*plVar1 + 0x58))(plVar1);
  return extraout_var & 1;
}

// ==== CSyndicateActor@adapter::helper_14017b840  @14017b840  [medium:callgraph-r1]  (orig: FUN_14017b840)
void FUN_14017b840(longlong *param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  
  FUN_1403741e0(param_1 + 0x1cf);
  plVar6 = (longlong *)FUN_140087ed0();
  uVar2 = FUN_140373290(param_1 + 0x1cf);
  lVar1 = *plVar6;
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar1 + 0x640))(plVar6,uVar3,uVar2,param_2);
  plVar6 = (longlong *)FUN_140087ed0();
  iVar4 = (**(code **)(*plVar6 + 0x630))(plVar6,param_2);
  iVar5 = FUN_140374250(param_1 + 0x1cf);
  if (iVar5 != iVar4) {
    FUN_140168bf0(param_1,iVar4,1);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_14017b8f0  @14017b8f0  [medium:callgraph-r0]  (orig: FUN_14017b8f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14017b8f0(longlong *param_1,longlong param_2,undefined1 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == 0) {
    uVar3 = 1;
  }
  else {
    uVar4 = FUN_1403741d0(param_1 + 0x1cf);
    uVar4 = (uVar4 & 0xffffffff) + param_2;
    if (uVar4 < 1000000000) {
      FUN_14017b840(param_1,uVar4 & 0xffffffff,param_3);
      FUN_14039e680(local_458);
      uVar1 = (**(code **)(*param_1 + 8))(param_1);
      iVar2 = FUN_14039e700(local_458,uVar1,0x54,uVar4);
      if (iVar2 == 0) {
        local_478 = 0x7839;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_14039e6d0(local_458);
        uVar3 = 0;
      }
      else {
        (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_458);
        FUN_14039e6d0(local_458);
        uVar3 = 1;
      }
    }
    else {
      uVar3 = 0;
    }
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::helper_14017ba10  @14017ba10  [medium:callgraph-r0]  (orig: FUN_14017ba10)
undefined4 FUN_14017ba10(longlong param_1)

{
  int iVar1;
  int iVar2;
  longlong lVar3;
  int iVar4;
  
  iVar4 = 0;
  do {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
    if (*(longlong *)(lVar3 + 0xb0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar1 = FUN_140006d10(*(undefined8 *)(lVar3 + 0xb0),iVar4);
    if (iVar1 != 0) {
      iVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x168))(param_1 + 0x10);
      if (iVar2 == iVar1) {
        return 1;
      }
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 4);
  return 0;
}

// ==== CSyndicateActor@adapter::helper_140278a60  @140278a60  [medium:callgraph-r3]  (orig: FUN_140278a60)
undefined8 *
FUN_140278a60(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 *param_5,undefined1 param_6)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = param_2;
    puVar1[1] = param_3;
    puVar1[2] = param_4;
    *(undefined4 *)(puVar1 + 3) = *param_5;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = param_5[1];
    *(undefined4 *)(puVar1 + 4) = param_5[2];
    *(undefined4 *)((longlong)puVar1 + 0x24) = param_5[3];
    *(undefined4 *)(puVar1 + 5) = param_5[4];
    *(undefined1 *)((longlong)puVar1 + 0x2c) = param_6;
    *(undefined1 *)((longlong)puVar1 + 0x2d) = 0;
  }
  return puVar1;
}

// ==== CSyndicateActor@adapter::helper_140279140  @140279140  [medium:callgraph-r2]  (orig: FUN_140279140)
undefined8 *
FUN_140279140(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xcccccccccccccca < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_140278a60(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x2c);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x2d) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x2c) == '\0') {
        *(undefined1 *)((longlong)plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x2d) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x2c) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x2c) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x2d) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x2c);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x2c) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CSyndicateActor@adapter::helper_1402794d0  @1402794d0  [medium:callgraph-r1]  (orig: FUN_1402794d0)
longlong * FUN_1402794d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  char cVar1;
  longlong lVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  bool bVar8;
  longlong local_38;
  undefined8 *local_30;
  
  puVar7 = (undefined8 *)param_1[6];
  bVar8 = true;
  if (*(char *)((longlong)puVar7[1] + 0x2d) == '\0') {
    puVar5 = (undefined8 *)puVar7[1];
    do {
      puVar7 = puVar5;
      bVar8 = *param_3 < *(uint *)(puVar7 + 3);
      if (bVar8) {
        puVar5 = (undefined8 *)*puVar7;
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
      }
    } while (*(char *)((longlong)puVar5 + 0x2d) == '\0');
  }
  lVar2 = *param_1;
  puVar5 = puVar7;
  local_38 = lVar2;
  puVar4 = puVar7;
  if (bVar8 == false) {
LAB_14027962d:
    local_30 = puVar4;
    if (*param_3 <= *(uint *)(puVar5 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_38;
      goto LAB_14027965c;
    }
  }
  else {
    puVar5 = *(undefined8 **)param_1[6];
    local_30 = puVar7;
    if (lVar2 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar7 != puVar5) {
      if (lVar2 == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
        puVar5 = (undefined8 *)*puVar7;
        if (*(char *)((longlong)puVar5 + 0x2d) == '\0') {
          cVar1 = *(char *)((longlong)puVar5[2] + 0x2d);
          puVar3 = (undefined8 *)puVar5[2];
          while (puVar4 = puVar5, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)puVar3[2] + 0x2d);
            puVar5 = puVar3;
            puVar3 = (undefined8 *)puVar3[2];
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar7[1] + 0x2d);
          puVar4 = (undefined8 *)puVar7[1];
          puVar3 = puVar7;
          while ((puVar5 = puVar4, cVar1 == '\0' && (puVar3 == (undefined8 *)*puVar5))) {
            cVar1 = *(char *)((longlong)puVar5[1] + 0x2d);
            puVar4 = (undefined8 *)puVar5[1];
            puVar3 = puVar5;
            local_30 = puVar5;
          }
          puVar4 = puVar5;
          if (*(char *)((longlong)puVar3 + 0x2d) != '\0') {
            _invalid_parameter_noinfo();
            puVar5 = puVar3;
            puVar4 = local_30;
          }
        }
      }
      else {
        puVar5 = (undefined8 *)puVar7[2];
        puVar4 = puVar5;
        if (*(char *)((longlong)puVar5 + 0x2d) != '\0') {
          local_30 = puVar5;
          _invalid_parameter_noinfo();
          puVar4 = local_30;
        }
      }
      goto LAB_14027962d;
    }
    bVar8 = true;
  }
  plVar6 = (longlong *)FUN_140279140(param_1,&local_38,bVar8,puVar7,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_30 = (undefined8 *)plVar6[1];
  *param_2 = *plVar6;
LAB_14027965c:
  param_2[1] = (longlong)local_30;
  return param_2;
}

// ==== CSyndicateActor@adapter::helper_14027a570  @14027a570  [medium:callgraph-r0]  (orig: FUN_14027a570)
void FUN_14027a570(longlong param_1,uint param_2,undefined2 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  ulong uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  undefined8 local_58;
  undefined8 local_50;
  longlong local_48;
  undefined8 local_40;
  undefined8 local_30;
  undefined8 local_28;
  undefined4 local_20;
  
  plVar1 = (longlong *)(param_1 + 0x48);
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar2 = *(char *)((longlong)puVar9 + 0x2d);
  puVar4 = *(undefined8 **)(param_1 + 0x78);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar7 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar7 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar7;
    cVar2 = *(char *)((longlong)puVar7 + 0x2d);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x78);
  local_50 = puVar4;
  local_58 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x78);
    local_48 = *plVar1;
  }
  else {
    plVar8 = &local_58;
  }
  plVar3 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x78);
  local_28 = plVar8[1];
  local_30 = plVar3;
  if (((longlong *)*plVar1 == (longlong *)0x0) || ((longlong *)*plVar1 != plVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_28;
  if (lVar10 == local_28) {
    local_50._0_4_ = 0;
    local_50._4_4_ = param_5;
    local_58 = (ulonglong)CONCAT24(param_3,param_4);
    uVar6 = tq::TimeGet(1);
    local_50 = (undefined8 *)CONCAT44(local_50._4_4_,uVar6);
    local_30 = (longlong *)CONCAT44((undefined4)local_58,param_2);
    local_28 = CONCAT44(uVar6,local_58._4_4_);
    local_20 = local_50._4_4_;
    FUN_1402794d0(plVar1,&local_48,&local_30);
  }
  else {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    *(undefined4 *)(lVar5 + 0x1c) = param_4;
    *(undefined4 *)(lVar5 + 0x28) = param_5;
    *(undefined2 *)(lVar5 + 0x20) = param_3;
    uVar6 = tq::TimeGet(1);
    *(ulong *)(lVar5 + 0x24) = uVar6;
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_14027a720  @14027a720  [medium:callgraph-r0]  (orig: FUN_14027a720)
undefined8
FUN_14027a720(longlong param_1,uint param_2,short param_3,int param_4,undefined4 *param_5)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  plVar1 = (longlong *)(param_1 + 0x48);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar2 = *(char *)((longlong)puVar7 + 0x2d);
  puVar4 = *(undefined8 **)(param_1 + 0x78);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x2d);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x78);
  local_40 = puVar4;
  local_48 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar7) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x78);
    local_38 = *plVar1;
  }
  else {
    plVar8 = &local_48;
  }
  plVar3 = (longlong *)*plVar8;
  lVar9 = *(longlong *)(param_1 + 0x78);
  local_28 = plVar3;
  local_20 = plVar8[1];
  if (((longlong *)*plVar1 == (longlong *)0x0) || ((longlong *)*plVar1 != plVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_20;
  if (lVar9 != local_20) {
    lVar9 = 0;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar9;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((*(short *)(lVar5 + 0x20) == param_3) && (*(int *)(lVar5 + 0x1c) == param_4)) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar9 = *plVar3;
      }
      if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *param_5 = *(undefined4 *)(lVar5 + 0x28);
      local_28 = (longlong *)*plVar8;
      local_20 = plVar8[1];
      FUN_140279680(plVar1,&local_38,&local_28);
      return 1;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::helper_1402bb5f0  @1402bb5f0  [medium:callgraph-r0]  (orig: FUN_1402bb5f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402bb5f0(longlong *param_1,undefined4 param_2,char param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  int iVar3;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  *(undefined4 *)(param_1 + 0x19) = param_2;
  if (param_3 != '\0') {
    FUN_14039e680(local_448);
    lVar1 = param_1[0x19];
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    iVar3 = FUN_14039e700(local_448,uVar2,0x55,(int)lVar1);
    if (iVar3 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,0);
    }
    FUN_14039e6d0(local_448);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_1402bb6a0  @1402bb6a0  [medium:callgraph-r0]  (orig: FUN_1402bb6a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402bb6a0(longlong *param_1,char param_2)

{
  longlong *plVar1;
  longlong lVar2;
  undefined4 uVar3;
  int iVar4;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  plVar1 = (longlong *)param_1[0xc];
  if (plVar1 == (longlong *)0x0) {
    local_468 = 0x142;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    uVar3 = (**(code **)(*plVar1 + 0x10))(plVar1,5);
  }
  *(undefined4 *)(param_1 + 0x19) = uVar3;
  if (param_2 != '\0') {
    FUN_14039e680(local_448);
    lVar2 = param_1[0x19];
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    iVar4 = FUN_14039e700(local_448,uVar3,0x55,(int)lVar2);
    if (iVar4 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,0);
    }
    FUN_14039e6d0(local_448);
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_1403732b0  @1403732b0  [medium:callgraph-r1]  (orig: FUN_1403732b0)
void FUN_1403732b0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x224) = param_2;
  return;
}

// ==== CSyndicateActor@adapter::helper_1403741e0  @1403741e0  [medium:callgraph-r2]  (orig: FUN_1403741e0)
void FUN_1403741e0(longlong param_1,undefined4 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined4 *)(param_1 + 0x218) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"league_contribution");
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::helper_140374260  @140374260  [medium:callgraph-r3]  (orig: FUN_140374260)
void FUN_140374260(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x21c) = param_2;
  return;
}

// ==== CSyndicateActor@adapter::helper_1403b69f0  @1403b69f0  [medium:callgraph-r0]  (orig: FUN_1403b69f0)
undefined8 FUN_1403b69f0(longlong param_1,undefined2 param_2,undefined4 param_3,void *param_4)

{
  if (param_4 == (void *)0xffffffffffffffe4) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  memcpy((void *)(*(longlong *)(param_1 + 0x428) + 8),param_4,0x40);
  *(undefined4 *)(param_1 + 8) = 0x9c50;
  *(undefined4 *)(param_1 + 0xc) = 0x48;
  return 1;
}

// ==== CSyndicateActor@adapter::helper_1403ef8c0  @1403ef8c0  [medium:callgraph-r0]  (orig: FUN_1403ef8c0)
undefined8
FUN_1403ef8c0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  *(undefined4 *)(param_1 + 8) = 0x9c65;
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_6;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_7;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_8;
  return 1;
}

// ==== CSyndicateActor@adapter::helper_1403f3790  @1403f3790  [medium:callgraph-r0]  (orig: FUN_1403f3790)
bool FUN_1403f3790(longlong param_1,undefined2 param_2,undefined4 param_3,char *param_4)

{
  uint uVar1;
  
  if (param_4 != (char *)0x0) {
    FUN_1402b5600();
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_4);
    *(undefined4 *)(param_1 + 8) = 0x9c63;
    uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(uint *)(param_1 + 0xc) = uVar1 + 0xf;
  }
  return param_4 != (char *)0x0;
}

// ==== CSyndicateActor@adapter::helper_140433210  @140433210  [medium:callgraph-r0]  (orig: FUN_140433210)
undefined8 FUN_140433210(longlong param_1,undefined2 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5c;
  *(undefined4 *)(param_1 + 0xc) = 0x28;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined8 *)(lVar1 + 8) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_140433270  @140433270  [medium:callgraph-r0]  (orig: FUN_140433270)
undefined8
FUN_140433270(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5c;
  *(undefined4 *)(param_1 + 0xc) = 0x28;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_5;
  return CONCAT71((uint7)(uint3)((uint)param_5 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_1404332f0  @1404332f0  [medium:callgraph-r0]  (orig: FUN_1404332f0)
ulonglong FUN_1404332f0(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,char *param_6,undefined4 param_7)

{
  uint uVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  
  if (param_6 == (char *)0x0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x9c5c;
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_5;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_7;
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_6);
    uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(uint *)(param_1 + 0xc) = uVar1 + 0x27;
    uVar2 = CONCAT71((uint7)(uint3)(uVar1 + 0x27 >> 8),1);
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::helper_1404333b0  @1404333b0  [medium:callgraph-r0]  (orig: FUN_1404333b0)
ulonglong FUN_1404333b0(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,char *param_6,char *param_7)

{
  uint uVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  
  if ((param_6 == (char *)0x0) || (param_7 == (char *)0x0)) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x9c5c;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = 0;
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_5;
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_6);
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_7);
    uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
    *(uint *)(param_1 + 0xc) = uVar1 + 0x27;
    uVar2 = CONCAT71((uint7)(uint3)(uVar1 + 0x27 >> 8),1);
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::helper_140433530  @140433530  [medium:callgraph-r0]  (orig: FUN_140433530)
ulonglong FUN_140433530(longlong param_1,char *param_2)

{
  uint uVar1;
  ulonglong in_RAX;
  
  if (param_2 == (char *)0x0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5c;
  **(undefined2 **)(param_1 + 0x428) = 5;
  tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_2);
  uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar1 + 0x27;
  return CONCAT71((uint7)(uint3)(uVar1 + 0x27 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_1404335b0  @1404335b0  [medium:callgraph-r0]  (orig: FUN_1404335b0)
undefined8
FUN_1404335b0(longlong param_1,undefined2 param_2,char *param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  uint uVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c5c;
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_5;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_6;
  if (param_3 != (char *)0x0) {
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_3);
  }
  uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar1 + 0x27;
  return CONCAT71((uint7)(uint3)(uVar1 + 0x27 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_140449a50  @140449a50  [medium:callgraph-r0]  (orig: FUN_140449a50)
undefined8 FUN_140449a50(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x9c8;
  *(undefined4 *)(param_1 + 0xc) = 0x1c;
  **(undefined2 **)(param_1 + 0x428) = 2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_3;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_4;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_14045bd40  @14045bd40  [medium:callgraph-r0]  (orig: FUN_14045bd40)
undefined8 FUN_14045bd40(longlong param_1,undefined2 param_2,undefined4 *param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 4 +
   *(longlong *)(param_1 + 0x428)) = *param_3;
  *(undefined4 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 8 +
   *(longlong *)(param_1 + 0x428)) = param_3[1];
  *(undefined4 *)
   ((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 0xc +
   *(longlong *)(param_1 + 0x428)) = param_3[2];
  tq::StrCopy((char *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 0x20 +
                      *(longlong *)(param_1 + 0x428)),(char *)(param_3 + 7),0x10);
  tq::StrCopy((char *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 0x10 +
                      *(longlong *)(param_1 + 0x428)),(char *)(param_3 + 3),0x10);
  if ((char *)(param_3 + 0xb) != (char *)0x0) {
    tq::StrCopy((char *)((ulonglong)*(ushort *)(*(longlong *)(param_1 + 0x428) + 2) * 0x3c + 0x30 +
                        *(longlong *)(param_1 + 0x428)),(char *)(param_3 + 0xb),0x10);
  }
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 2) = 1;
  *(undefined4 *)(param_1 + 8) = 0x9c62;
  *(undefined4 *)(param_1 + 0xc) = 0x40;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_14045c450  @14045c450  [medium:callgraph-r0]  (orig: FUN_14045c450)
undefined8 FUN_14045c450(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  FUN_1402b5600();
  **(undefined2 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined1 *)(lVar1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 8) = 0x9c69;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_14045c4d0  @14045c4d0  [medium:callgraph-r0]  (orig: FUN_14045c4d0)
ulonglong FUN_14045c4d0(longlong param_1,undefined4 param_2)

{
  char *pcVar1;
  longlong lVar2;
  ulonglong uVar3;
  
  uVar3 = (longlong)*(int *)(param_1 + 0xc) + 4;
  if (0x3ff < uVar3) {
    return uVar3 & 0xffffffffffffff00;
  }
  *(undefined4 *)
   (*(longlong *)(param_1 + 0x428) + 0x10 +
   (ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xc) * 4) = param_2;
  lVar2 = *(longlong *)(param_1 + 0x428);
  pcVar1 = (char *)(lVar2 + 0xc);
  *pcVar1 = *pcVar1 + '\x01';
  *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 4;
  return CONCAT71((int7)((ulonglong)lVar2 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_140460ac0  @140460ac0  [medium:callgraph-r0]  (orig: FUN_140460ac0)
undefined8 FUN_140460ac0(longlong param_1,undefined1 param_2)

{
  *(undefined4 *)(param_1 + 8) = 0x9c67;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  return 1;
}

// ==== CSyndicateActor@adapter::helper_140460ae0  @140460ae0  [medium:callgraph-r0]  (orig: FUN_140460ae0)
undefined8 FUN_140460ae0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  *(undefined4 *)(param_1 + 8) = 0x9c67;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  **(undefined1 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  return 1;
}

// ==== CSyndicateActor@adapter::helper_140460e50  @140460e50  [medium:callgraph-r0]  (orig: FUN_140460e50)
undefined8 FUN_140460e50(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 8) = 0x9c66;
  *(undefined4 *)(param_1 + 0xc) = 8;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  return 1;
}

// ==== CSyndicateActor@adapter::helper_140461050  @140461050  [medium:callgraph-r0]  (orig: FUN_140461050)
undefined8 FUN_140461050(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  FUN_1402b5600();
  **(undefined2 **)(param_1 + 0x428) = 0;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_2;
  *(undefined4 *)(param_1 + 8) = 0x9c6b;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CSyndicateActor@adapter::helper_1404610a0  @1404610a0  [medium:callgraph-r0]  (orig: FUN_1404610a0)
undefined2
FUN_1404610a0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
             undefined2 param_5)

{
  FUN_1402b5600();
  **(undefined2 **)(param_1 + 0x428) = 1;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_5;
  *(undefined4 *)(param_1 + 8) = 0x9c6b;
  *(undefined4 *)(param_1 + 0xc) = 0x10;
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_1  @1405a8680  [high:rtti-vtable]  (orig: FUN_1405a8680)
void FUN_1405a8680(longlong param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(param_1 + -8);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_3  @1405a86a0  [high:rtti-vtable]  (orig: FUN_1405a86a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405a86a0(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 local_res20;
  undefined1 auStack_438 [32];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  if (param_3 == (char *)0x0) {
    return false;
  }
  local_res20 = param_4;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    _vsnprintf(local_418,0x400,param_3,(va_list)&local_res20);
    local_19 = 0;
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),local_418);
  }
  return lVar1 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_2  @1405a8760  [high:rtti-vtable]  (orig: FUN_1405a8760)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a8760(longlong param_1,undefined8 param_2,undefined4 param_3,char *param_4)

{
  undefined8 uVar1;
  longlong *plVar2;
  undefined1 auStack_448 [32];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar1 = 0;
    if (plVar2 != (longlong *)0x0) {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      (**(code **)(*plVar2 + 0x150))(plVar2,param_3,local_428);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_12  @1405a8810  [high:rtti-vtable]  (orig: FUN_1405a8810)
undefined8 FUN_1405a8810(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  
  if (param_3 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 != 0) {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x340))((longlong *)(lVar1 + 0x10),param_3,param_4)
      ;
      return 1;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_5  @1405a8870  [high:rtti-vtable]  (orig: FUN_1405a8870)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405a8870(longlong param_1,undefined4 param_2,undefined8 param_3,undefined4 param_4)

{
  int iVar1;
  longlong lVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  FUN_14015b240();
  local_4a8 = 1;
  local_4b0 = 0;
  local_4b8 = 0;
  local_4c0 = 0;
  local_4c8 = 0x7d5;
  local_4d8 = 0;
  local_4d0 = param_4;
  iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_3);
  if (iVar1 == 0) {
    FUN_14015b2c0(local_488);
  }
  else {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_2);
    if (lVar2 == 0) {
      FUN_14015b2c0(local_488);
    }
    else {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_488);
      FUN_14015b2c0(local_488);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_27  @1405a8960  [high:rtti-vtable]  (orig: FUN_1405a8960)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a8960(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    FUN_14039ed70(local_468);
    iVar2 = FUN_14039eef0(local_468,plVar3 + 2,0,0);
    if (iVar2 == 0) {
      cVar1 = (**(code **)(plVar3[2] + 0x230))(plVar3 + 2);
      if ((cVar1 == '\0') || (cVar1 = (**(code **)(plVar3[2] + 0x238))(plVar3 + 2), cVar1 != '\0'))
      {
        (**(code **)(*plVar3 + 8))(plVar3);
        log_InlineLogERROR("CSyndicateActor::BroadcastPlayer user[%u] is unvisible.");
      }
    }
    else {
      (**(code **)(plVar3[2] + 0x348))(plVar3 + 2,local_468,0);
    }
    FUN_14039edf0(local_468);
    return 1;
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_29  @1405a8a50  [high:rtti-vtable]  (orig: FUN_1405a8a50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a8a50(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar4 = 0;
  if (plVar3 != (longlong *)0x0) {
    FUN_14039e680(local_458);
    uVar1 = (**(code **)(*plVar3 + 8))(plVar3);
    iVar2 = FUN_14039e700(local_458,uVar1,param_3,param_4);
    if (iVar2 == 0) {
      local_478 = 0x163;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(plVar3[2] + 0x348))(plVar3 + 2,local_458,0);
    }
    FUN_14039e6d0(local_458);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CSyndicateActor@adapter::vfunc_30  @1405a8b30  [high:rtti-vtable]  (orig: FUN_1405a8b30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405a8b30(longlong param_1,undefined8 param_2,undefined4 param_3,longlong param_4,
             undefined4 param_5)

{
  int iVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_4 == 0) {
    local_498 = 0x19e;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_498 = 0x1a1;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar2 = 0;
    }
    else {
      FUN_14037dfb0(local_478);
      iVar1 = FUN_14037e0a0(local_478,param_3,param_4,param_5);
      if (iVar1 == 0) {
        local_498 = 0x1a4;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
      }
      FUN_14037e030(local_478);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_31  @1405a8c70  [high:rtti-vtable]  (orig: FUN_1405a8c70)
undefined8 FUN_1405a8c70(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_14018f460(lVar1,param_3,0,0);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_38  @1405a8cb0  [high:rtti-vtable]  (orig: FUN_1405a8cb0)
void FUN_1405a8cb0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a8cf5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_40  @1405a8d00  [high:rtti-vtable]  (orig: FUN_1405a8d00)
bool FUN_1405a8d00(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,
                  undefined4 param_5,undefined1 param_6)

{
  char cVar1;
  longlong lVar2;
  bool bVar3;
  undefined4 uVar4;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  bVar3 = false;
  if (lVar2 != 0) {
    uVar4 = 0;
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2e0))
                      (lVar2 + 0x10,0x1d,(longlong)-param_4,param_6,0);
    bVar3 = cVar1 != '\0';
    if (bVar3) {
      FUN_1401742b0(lVar2,param_5,param_2,param_3,CONCAT44(uVar4,param_4));
    }
  }
  return bVar3;
}

// ==== CSyndicateActor@adapter::vfunc_39  @1405a8da0  [high:rtti-vtable]  (orig: FUN_1405a8da0)
undefined8 FUN_1405a8da0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return 0;
  }
  (**(code **)(*plVar1 + 0x180))(plVar1,param_3,param_4);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_41  @1405a8df0  [high:rtti-vtable]  (orig: FUN_1405a8df0)
bool FUN_1405a8df0(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,
                  undefined4 param_5,undefined1 param_6)

{
  char cVar1;
  longlong lVar2;
  undefined4 uVar3;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    if (0 < param_4) {
      uVar3 = 0;
      cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2e0))
                        ((longlong *)(lVar2 + 0x10),0x1d,(longlong)param_4,param_6,0);
      if (cVar1 != '\0') {
        FUN_1401742b0(lVar2,param_5,param_3,param_2,CONCAT44(uVar3,param_4));
      }
      return cVar1 != '\0';
    }
    log_InlineLogERROR(
                      "CSyndicateActor::GainUserEMoney. nEMoney[%d] <= 0 User[%u], Source[%u], Reason[%d]"
                      );
  }
  return false;
}

// ==== CSyndicateActor@adapter::vfunc_42  @1405a8eb0  [high:rtti-vtable]  (orig: FUN_1405a8eb0)
undefined8 FUN_1405a8eb0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_140165790(lVar1,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_43  @1405a8ef0  [high:rtti-vtable]  (orig: FUN_1405a8ef0)
undefined8 FUN_1405a8ef0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_1401657b0(lVar1,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_44  @1405a8f30  [high:rtti-vtable]  (orig: FUN_1405a8f30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405a8f30(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar4 = 0;
  if (plVar3 != (longlong *)0x0) {
    FUN_1401657d0(plVar3,param_3);
    FUN_14039e680(local_448);
    uVar1 = (**(code **)(*plVar3 + 8))(plVar3);
    iVar2 = FUN_14039e700(local_448,uVar1,0x53,param_3);
    if (iVar2 == 0) {
      local_468 = 0x22a;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(plVar3[2] + 0x350))(plVar3 + 2,local_448);
    }
    FUN_14039e6d0(local_448);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CSyndicateActor@adapter::vfunc_45  @1405a9020  [high:rtti-vtable]  (orig: FUN_1405a9020)
void FUN_1405a9020(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = FUN_140167b70(lVar2);
    if (cVar1 != '\0') {
      FUN_140167d20(lVar2,param_3);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_46  @1405a9070  [high:rtti-vtable]  (orig: FUN_1405a9070)
void FUN_1405a9070(longlong param_1,undefined8 param_2,undefined1 param_3)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = FUN_140167b70(lVar2);
    if (cVar1 != '\0') {
      FUN_140167dd0(lVar2,param_3);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_47  @1405a90c0  [high:rtti-vtable]  (orig: FUN_1405a90c0)
void FUN_1405a90c0(longlong param_1,int param_2,longlong param_3)

{
  char cVar1;
  longlong lVar2;
  
  if ((((param_2 != 0) && (param_3 != 0)) &&
      (lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))(), lVar2 != 0)) &&
     (cVar1 = FUN_140167b70(lVar2), cVar1 != '\0')) {
    FUN_140167c80(lVar2,param_3);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_149  @1405a9110  [high:rtti-vtable]  (orig: FUN_1405a9110)
void FUN_1405a9110(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1401657c0(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_64  @1405a9140  [high:rtti-vtable]  (orig: FUN_1405a9140)
undefined4 FUN_1405a9140(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xf10);
}

// ==== CSyndicateActor@adapter::vfunc_70  @1405a9170  [high:rtti-vtable]  (orig: FUN_1405a9170)
void FUN_1405a9170(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9195. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x60))(plVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_71  @1405a91a0  [high:rtti-vtable]  (orig: FUN_1405a91a0)
undefined4 FUN_1405a91a0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xfa4);
}

// ==== CSyndicateActor@adapter::vfunc_73  @1405a91d0  [high:rtti-vtable]  (orig: FUN_1405a91d0)
undefined1 FUN_1405a91d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x51c);
}

// ==== CSyndicateActor@adapter::vfunc_59  @1405a9200  [high:rtti-vtable]  (orig: FUN_1405a9200)
undefined1 * FUN_1405a9200(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a922e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CSyndicateActor@adapter::vfunc_72  @1405a9240  [high:rtti-vtable]  (orig: FUN_1405a9240)
void FUN_1405a9240(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9267. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_65  @1405a9270  [high:rtti-vtable]  (orig: FUN_1405a9270)
void FUN_1405a9270(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9295. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_62  @1405a92a0  [high:rtti-vtable]  (orig: FUN_1405a92a0)
void FUN_1405a92a0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a92c7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_61  @1405a92d0  [high:rtti-vtable]  (orig: FUN_1405a92d0)
void FUN_1405a92d0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a92f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x50))(plVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_74  @1405a9300  [high:rtti-vtable]  (orig: FUN_1405a9300)
void FUN_1405a9300(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140188830(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_75  @1405a9330  [high:rtti-vtable]  (orig: FUN_1405a9330)
void FUN_1405a9330(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_14018eb30(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_66  @1405a9360  [high:rtti-vtable]  (orig: FUN_1405a9360)
void FUN_1405a9360(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9385. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x108))(plVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_67  @1405a9390  [high:rtti-vtable]  (orig: FUN_1405a9390)
ulonglong FUN_1405a9390(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return (ulonglong)*(byte *)(lVar1 + 0xeee) / 10;
}

// ==== CSyndicateActor@adapter::vfunc_68  @1405a93e0  [high:rtti-vtable]  (orig: FUN_1405a93e0)
undefined1 FUN_1405a93e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CSyndicateActor@adapter::vfunc_63  @1405a9410  [high:rtti-vtable]  (orig: FUN_1405a9410)
undefined8 FUN_1405a9410(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x0001405a9432. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_60  @1405a9440  [high:rtti-vtable]  (orig: FUN_1405a9440)
undefined8 FUN_1405a9440(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x90))
                     (*(longlong **)(param_1 + 0x10),param_2,0);
  if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405a9463. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar1 + 8))(plVar1);
    return uVar2;
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_76  @1405a9470  [high:rtti-vtable]  (orig: FUN_1405a9470)
undefined8 FUN_1405a9470(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    uVar2 = FUN_140164440(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_77  @1405a94a0  [high:rtti-vtable]  (orig: FUN_1405a94a0)
bool FUN_1405a94a0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_90  @1405a94c0  [high:rtti-vtable]  (orig: FUN_1405a94c0)
bool FUN_1405a94c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_91  @1405a94e0  [high:rtti-vtable]  (orig: FUN_1405a94e0)
void FUN_1405a94e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9507. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_92  @1405a9510  [high:rtti-vtable]  (orig: FUN_1405a9510)
void FUN_1405a9510(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140170e90(lVar1,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_89  @1405a9570  [high:rtti-vtable]  (orig: FUN_1405a9570)
void FUN_1405a9570(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140177530(lVar1,param_3,0);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_52  @1405a95b0  [high:rtti-vtable]  (orig: FUN_1405a95b0)
undefined8 FUN_1405a95b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_140194ac0(lVar1,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_55  @1405a95f0  [high:rtti-vtable]  (orig: FUN_1405a95f0)
undefined8 FUN_1405a95f0(longlong param_1,undefined8 param_2,uint param_3,uint param_4)

{
  longlong *plVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar4 == (longlong *)0x0) {
    return 0;
  }
  plVar1 = plVar4 + 2;
  iVar2 = (**(code **)(plVar4[2] + 0x170))(plVar1);
  if (iVar2 == 0) {
    uVar3 = (**(code **)(*plVar1 + 0x70))(plVar1);
    if (uVar3 < param_3) {
      pIVar5 = theInstance();
      lVar7 = *plVar1;
      uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NOT_ENOUGH_LEV");
      (**(code **)(lVar7 + 0x358))(plVar1,uVar6,param_3);
      return 0;
    }
    lVar7 = (**(code **)(*plVar4 + 0x60))(plVar4);
    if ((longlong)(ulonglong)param_4 <= lVar7) {
      return 1;
    }
    pIVar5 = theInstance();
    lVar7 = *plVar1;
    uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NOT_ENOUGH_MONEY");
    (**(code **)(lVar7 + 0x358))(plVar1,uVar6,param_4);
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_69  @1405a96d0  [high:rtti-vtable]  (orig: FUN_1405a96d0)
undefined8 FUN_1405a96d0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  puVar2 = (undefined8 *)(**(code **)(*plVar1 + 0x20))(plVar1,0xb);
  if (puVar2 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a9767. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)*puVar2)(puVar2,param_2);
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_86  @1405a9770  [high:rtti-vtable]  (orig: FUN_1405a9770)
undefined8 FUN_1405a9770(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = CurrentInstanceGet();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x18);
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a980e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x70))(plVar2,param_2);
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_87  @1405a9820  [high:rtti-vtable]  (orig: FUN_1405a9820)
undefined8 FUN_1405a9820(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  lVar1 = CurrentInstanceGet();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar2 = (longlong *)CurrentInstanceGet();
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,0x1c);
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a98d7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x98))(plVar2,param_2,param_3);
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_88  @1405a98e0  [high:rtti-vtable]  (orig: FUN_1405a98e0)
bool FUN_1405a98e0(longlong param_1,undefined8 param_2,uint param_3,uint param_4,uint param_5)

{
  uint uVar1;
  longlong *plVar2;
  byte bVar3;
  
  plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar2 != (longlong *)0x0) {
    uVar1 = (**(code **)(plVar2[2] + 0x70))(plVar2 + 2);
    if ((uVar1 < param_3) || (uVar1 = (**(code **)(*plVar2 + 0x108))(plVar2), uVar1 < param_4)) {
      bVar3 = 1;
    }
    else {
      bVar3 = 0;
      switch(*(byte *)((longlong)plVar2 + 0xeee) / 10) {
      case 1:
        bVar3 = (byte)param_5 & 1;
        break;
      case 2:
        bVar3 = (byte)(param_5 >> 1) & 1;
        break;
      default:
        log_InlineLogERROR("CSyndicate::CheckCondition Error ProfSort:%d");
        break;
      case 4:
        bVar3 = (byte)(param_5 >> 3) & 1;
        break;
      case 5:
        bVar3 = (byte)(param_5 >> 4) & 1;
        break;
      case 6:
        bVar3 = (byte)(param_5 >> 5) & 1;
        break;
      case 7:
        bVar3 = (byte)(param_5 >> 6) & 1;
        break;
      case 8:
        bVar3 = (byte)(param_5 >> 7) & 1;
        break;
      case 10:
      case 0xb:
      case 0xc:
      case 0xd:
      case 0xe:
      case 0xf:
        bVar3 = (byte)(param_5 >> 2) & 1;
      }
    }
    return bVar3 == 0;
  }
  return false;
}

// ==== CSyndicateActor@adapter::vfunc_78  @1405a9a50  [high:rtti-vtable]  (orig: FUN_1405a9a50)
ulonglong FUN_1405a9a50(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong lVar4;
  ulonglong extraout_RAX;
  ulonglong uVar5;
  longlong *plVar6;
  undefined8 local_res8;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 != 0) {
    lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_3);
    if (lVar4 != 0) {
      plVar6 = (longlong *)(lVar3 + 0x10);
      lVar3 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x160))(plVar6);
      local_res8 = 0;
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar5 = extraout_RAX & 0xffffffffffffff00;
      }
      else {
        uVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
        uVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
        uVar5 = FUN_1402c84c0(lVar3,uVar2,uVar1,0x1001,param_3,&local_res8);
      }
      return uVar5;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_79  @1405a9b40  [high:rtti-vtable]  (orig: FUN_1405a9b40)
void FUN_1405a9b40(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140167b70(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_36  @1405a9b70  [high:rtti-vtable]  (orig: FUN_1405a9b70)
undefined8
FUN_1405a9b70(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 uVar2;
  
  uVar2 = 0xfffffffffffffffe;
  lVar1 = FUN_140109740(0x50);
  if (lVar1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = FUN_14010a8e0(lVar1,param_2,500,param_4,uVar2);
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_6  @1405a9bb0  [high:rtti-vtable]  (orig: FUN_1405a9bb0)
void FUN_1405a9bb0(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001405a9bb3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x5a0))();
  return;
}

// ==== CSyndicateActor@adapter::vfunc_17  @1405a9bc0  [high:rtti-vtable]  (orig: FUN_1405a9bc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405a9bc0(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
             undefined2 param_5)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_3 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x540);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_14015b240();
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = param_5;
    local_4d0 = 0xffffff;
    local_4d8 = 0;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_3);
    if (iVar1 == 0) {
      local_4d8 = CONCAT44(local_4d8._4_4_,0x543);
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_14015b2c0(local_488);
      uVar2 = 0;
    }
    else {
      (**(code **)(*param_1 + 0x5a0))(param_1,param_2,local_488,param_4);
      FUN_14015b2c0(local_488);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_53  @1405a9d00  [high:rtti-vtable]  (orig: FUN_1405a9d00)
undefined8 FUN_1405a9d00(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  FUN_140165650(lVar1,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_54  @1405a9d40  [high:rtti-vtable]  (orig: FUN_1405a9d40)
void FUN_1405a9d40(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140165640(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_101  @1405a9d70  [high:rtti-vtable]  (orig: FUN_1405a9d70)
void FUN_1405a9d70(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
                    /* WARNING: Could not recover jumptable at 0x0001405a9d8a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_100  @1405a9d90  [high:rtti-vtable]  (orig: FUN_1405a9d90)
void FUN_1405a9d90(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
                    /* WARNING: Could not recover jumptable at 0x0001405a9daa. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x88))(plVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_102  @1405a9dc0  [high:rtti-vtable]  (orig: FUN_1405a9dc0)
undefined1 FUN_1405a9dc0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
  (**(code **)(*plVar1 + 0x80))(plVar1,param_2,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_103  @1405a9e00  [high:rtti-vtable]  (orig: FUN_1405a9e00)
undefined1 FUN_1405a9e00(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
  (**(code **)(*plVar1 + 0x70))(plVar1,param_2);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_104  @1405a9e30  [high:rtti-vtable]  (orig: FUN_1405a9e30)
undefined1 FUN_1405a9e30(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
  (**(code **)(*plVar1 + 0x78))(plVar1,param_2);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_105  @1405a9e60  [high:rtti-vtable]  (orig: FUN_1405a9e60)
void FUN_1405a9e60(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
                    /* WARNING: Could not recover jumptable at 0x0001405a9e7a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x68))(plVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_146  @1405a9e80  [high:rtti-vtable]  (orig: FUN_1405a9e80)
bool FUN_1405a9e80(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
                  undefined2 param_5)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    return false;
  }
  iVar1 = FUN_1401c55b0(lVar2,param_3,param_4,param_5,0);
  return iVar1 != -1;
}

// ==== CSyndicateActor@adapter::vfunc_147  @1405a9ee0  [high:rtti-vtable]  (orig: FUN_1405a9ee0)
undefined8
FUN_1405a9ee0(longlong param_1,undefined8 param_2,undefined4 *param_3,undefined2 *param_4,
             undefined2 *param_5)

{
  longlong *plVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 == 0) {
    return 0;
  }
  plVar1 = (longlong *)(lVar4 + 0x10);
  uVar3 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x168))(plVar1);
  *param_3 = uVar3;
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  *param_4 = uVar2;
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  *param_5 = uVar2;
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_107  @1405a9f60  [high:rtti-vtable]  (orig: FUN_1405a9f60)
void FUN_1405a9f60(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1400e1de0();
  (**(code **)(*plVar1 + 8))(plVar1,param_2,param_3,param_4,param_5,param_6);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_108  @1405a9fb0  [high:rtti-vtable]  (orig: FUN_1405a9fb0)
ulonglong FUN_1405a9fb0(void)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x1c);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa040. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x10))(plVar1,0);
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_109  @1405aa050  [high:rtti-vtable]  (orig: FUN_1405aa050)
void FUN_1405aa050(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x1c);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa0fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x60))(plVar1,param_2,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_110  @1405aa100  [high:rtti-vtable]  (orig: FUN_1405aa100)
void FUN_1405aa100(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x1c);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa193. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x50))(plVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_111  @1405aa1a0  [high:rtti-vtable]  (orig: FUN_1405aa1a0)
void FUN_1405aa1a0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x1c);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa233. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x58))(plVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_113  @1405aa240  [high:rtti-vtable]  (orig: FUN_1405aa240)
undefined8 FUN_1405aa240(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x1c);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001405aa283. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x70))(plVar1,param_2,param_3);
      return uVar2;
    }
  }
  return 0xffffffff;
}

// ==== CSyndicateActor@adapter::vfunc_118  @1405aa2a0  [high:rtti-vtable]  (orig: FUN_1405aa2a0)
void FUN_1405aa2a0(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_119  @1405aa2b0  [high:rtti-vtable]  (orig: FUN_1405aa2b0)
undefined1
FUN_1405aa2b0(undefined8 param_1,longlong param_2,int param_3,undefined8 param_4,undefined4 param_5,
             undefined2 param_6)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  puVar2 = (undefined8 *)FUN_1400e1de0();
  uVar1 = (**(code **)*puVar2)(puVar2,param_2,param_3,param_4,param_5,param_6);
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_57  @1405aa390  [high:rtti-vtable]  (orig: FUN_1405aa390)
ulonglong FUN_1405aa390(longlong param_1,undefined8 param_2,ushort param_3,ushort param_4,
                       byte param_5,byte param_6,ushort param_7)

{
  uint3 uVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  uint7 uVar6;
  ulonglong extraout_RAX;
  char *pcVar8;
  uint7 uVar7;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar5 = 0;
  if (plVar4 == (longlong *)0x0) goto LAB_1405aa570;
  uVar5 = (**(code **)(plVar4[2] + 0x70))(plVar4 + 2);
  if ((uint)uVar5 < (uint)param_3) goto LAB_1405aa570;
  uVar5 = FUN_14018eb30(plVar4);
  if ((int)uVar5 < (int)(uint)param_7) goto LAB_1405aa570;
  uVar5 = (**(code **)(*plVar4 + 0x108))(plVar4);
  if ((uint)uVar5 < (uint)param_4) goto LAB_1405aa570;
  iVar2 = (**(code **)(*plVar4 + 0x50))(plVar4);
  if (iVar2 == 1) {
    uVar5 = 0;
    if ((param_6 & 1) != 0) goto LAB_1405aa570;
LAB_1405aa450:
    uVar3 = *(byte *)((longlong)plVar4 + 0xeee) / 10 - 1;
    uVar5 = (ulonglong)uVar3;
    if (uVar3 < 0xf) {
      uVar1 = (uint3)(uVar3 >> 8);
      uVar6 = (uint7)uVar1;
      uVar7 = (uint7)uVar1;
      switch(uVar5) {
      case 0:
        if ((param_5 & 1) != 0) {
          return (ulonglong)uVar7 << 8;
        }
        break;
      case 1:
        if ((param_5 & 2) != 0) {
          return (ulonglong)uVar7 << 8;
        }
        break;
      case 2:
      case 8:
        goto switchD_1405aa491_caseD_2;
      case 3:
        if ((param_5 & 8) != 0) {
          return (ulonglong)uVar7 << 8;
        }
        break;
      case 4:
        if ((param_5 & 0x10) != 0) {
          return (ulonglong)uVar6 << 8;
        }
        break;
      case 5:
        if ((param_5 & 0x20) != 0) {
          return (ulonglong)uVar6 << 8;
        }
        break;
      case 6:
        if ((param_5 & 0x40) != 0) {
          return (ulonglong)uVar6 << 8;
        }
        break;
      case 7:
        if ((param_5 & 0x80) == 0) break;
        goto LAB_1405aa570;
      default:
        if ((param_5 & 4) != 0) {
          return (ulonglong)uVar6 << 8;
        }
      }
      return CONCAT71(uVar7,1);
    }
switchD_1405aa491_caseD_2:
    pcVar8 = "CSyndicate::CheckUserAutoJoinSynCondition Error ProfSort:%d";
  }
  else {
    if (iVar2 == 2) {
      if ((param_6 & 2) != 0) {
        return 0;
      }
      goto LAB_1405aa450;
    }
    (**(code **)(*plVar4 + 0x50))(plVar4);
    pcVar8 = "CSyndicate::CheckUserAutoJoinSynCondition Error Sex:%d";
  }
  log_InlineLogERROR(pcVar8);
  uVar5 = extraout_RAX;
LAB_1405aa570:
  return uVar5 & 0xffffffffffffff00;
}

// ==== CSyndicateActor@adapter::vfunc_58  @1405aa5c0  [high:rtti-vtable]  (orig: FUN_1405aa5c0)
void FUN_1405aa5c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa5e7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_122  @1405aa5f0  [high:rtti-vtable]  (orig: FUN_1405aa5f0)
void FUN_1405aa5f0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)CurrentInstanceGet();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,0x23);
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aa6b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1,param_2,param_3,param_4);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_82  @1405aa6c0  [high:rtti-vtable]  (orig: FUN_1405aa6c0)
undefined4 FUN_1405aa6c0(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    return 0;
  }
  uVar1 = FUN_140168bd0(lVar2);
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_83  @1405aa6f0  [high:rtti-vtable]  (orig: FUN_1405aa6f0)
void FUN_1405aa6f0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    FUN_14017b8f0(lVar1,param_3,param_4);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_84  @1405aa730  [high:rtti-vtable]  (orig: FUN_1405aa730)
undefined8 FUN_1405aa730(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 != 0) {
      uVar2 = FUN_140161f90(lVar1);
      return uVar2;
    }
  }
  return 0xffffffff;
}

// ==== CSyndicateActor@adapter::vfunc_85  @1405aa760  [high:rtti-vtable]  (orig: FUN_1405aa760)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405aa760(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar2 = 0;
    if (lVar3 != 0) {
      FUN_140161fa0(lVar3,param_3);
      FUN_140362560(local_478);
      cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_478);
      }
      FUN_1403625e0(local_478);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_20  @1405aa810  [high:rtti-vtable]  (orig: FUN_1405aa810)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405aa810(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
             undefined2 param_5)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_3 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0x862);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_14015b240();
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = param_5;
    local_4d0 = 0xffffff;
    local_4d8 = 0;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_3);
    if (iVar1 == 0) {
      local_4d8 = CONCAT44(local_4d8._4_4_,0x865);
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_14015b2c0(local_488);
      uVar2 = 0;
    }
    else {
      (**(code **)(*param_1 + 0x5a8))(param_1,param_2,local_488,param_4);
      FUN_14015b2c0(local_488);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_129  @1405aa950  [high:rtti-vtable]  (orig: FUN_1405aa950)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405aa950(longlong param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_2 == 0) {
    uVar2 = 0;
  }
  else {
    plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar2 = 0;
    if (plVar3 != (longlong *)0x0) {
      FUN_140433120(local_468);
      cVar1 = FUN_140433210(local_468,0xb,param_3);
      if (cVar1 != '\0') {
        (**(code **)(*plVar3 + 0x130))(plVar3,local_468);
      }
      FUN_1404331a0(local_468);
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_130  @1405aaa00  [high:rtti-vtable]  (orig: FUN_1405aaa00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405aaa00(longlong param_1,int param_2,undefined4 param_3,char param_4,char param_5,
             longlong param_6)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  uint uVar4;
  undefined1 auStack_4d8 [32];
  uint local_4b8;
  longlong local_4b0;
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if ((param_2 == 0) || (param_6 == 0)) {
    uVar3 = 0;
  }
  else {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar3 = 0;
    if (plVar2 != (longlong *)0x0) {
      uVar4 = (uint)(param_4 != '\0');
      if (param_5 != '\0') {
        uVar4 = uVar4 + 0x10000;
      }
      FUN_140433120(local_488);
      local_4a8 = 0;
      local_4b0 = param_6;
      local_4b8 = uVar4;
      cVar1 = FUN_1404332f0(local_488,0xc,param_2,param_3);
      if (cVar1 != '\0') {
        (**(code **)(*plVar2 + 0x130))(plVar2,local_488);
      }
      FUN_1404331a0(local_488);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_80  @1405aab10  [high:rtti-vtable]  (orig: FUN_1405aab10)
undefined1 FUN_1405aab10(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x12c8);
}

// ==== CSyndicateActor@adapter::vfunc_81  @1405aab40  [high:rtti-vtable]  (orig: FUN_1405aab40)
ulonglong FUN_1405aab40(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405aab93. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_127  @1405aaba0  [high:rtti-vtable]  (orig: FUN_1405aaba0)
undefined8 FUN_1405aaba0(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_2 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 != 0) {
      uVar2 = FUN_140167b60(lVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_160  @1405aabd0  [high:rtti-vtable]  (orig: FUN_1405aabd0)
bool FUN_1405aabd0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined2 param_4,
                  undefined1 param_5,undefined4 param_6)

{
  int iVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    return false;
  }
  iVar1 = FUN_140340e50(lVar2,param_3,param_4,param_5,param_6,0,1);
  return iVar1 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_161  @1405aac40  [high:rtti-vtable]  (orig: FUN_1405aac40)
void FUN_1405aac40(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_0  @1405aaca0  [high:rtti-vtable]  (orig: FUN_1405aaca0)
void FUN_1405aaca0(longlong param_1)

{
  FUN_1405aad00(param_1 + -8);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_0  @1405aad00  [high:rtti-vtable]  (orig: FUN_1405aad00)
undefined8 * FUN_1405aad00(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CSyndicateActor::vftable;
  param_1[1] = adapter::CSyndicateActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  *param_1 = syndicate::IConsumer::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CSyndicateActor@adapter::vfunc_1  @1405aad60  [high:rtti-vtable]  (orig: FUN_1405aad60)
undefined8 FUN_1405aad60(longlong param_1,undefined8 param_2,longlong param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar1 = 0;
    if (lVar2 != 0) {
      if ((*(char *)(lVar2 + 0x12c8) == '\0') || (*(short *)(param_3 + 10) != 0x452)) {
        puVar3 = (undefined8 *)
                 FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar2 + 0x122c),
                               *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                               *(undefined2 *)(param_3 + 8),0);
        if (puVar3 == (undefined8 *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar1 = 0;
        }
        else {
          (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),puVar3);
          (**(code **)*puVar3)(puVar3,1);
          uVar1 = 1;
        }
      }
      else {
        uVar1 = 0;
      }
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_11  @1405aae80  [high:rtti-vtable]  (orig: FUN_1405aae80)
undefined8 FUN_1405aae80(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  uVar3 = 0;
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_3 + 10),
                           param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar4);
    uVar3 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x348))((longlong *)(lVar1 + 0x10),puVar2,param_4);
      (**(code **)*puVar2)(puVar2,1);
      uVar3 = 1;
    }
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_26  @1405aaf30  [high:rtti-vtable]  (orig: FUN_1405aaf30)
undefined8 FUN_1405aaf30(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_2 + 10),
                           param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    uVar1 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x58))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_25  @1405aafc0  [high:rtti-vtable]  (orig: FUN_1405aafc0)
undefined1 FUN_1405aafc0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  
  if (param_2 == 0) {
    return 0;
  }
  plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar1 + 0x50))(plVar1,param_2,0xffffffff);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_24  @1405ab000  [high:rtti-vtable]  (orig: FUN_1405ab000)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405ab000(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined2 param_5,undefined8 param_6,undefined4 param_7)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  FUN_140362560(local_488);
  local_4a0 = 0;
  local_4a8 = param_7;
  local_4b0 = 0x77;
  local_4b8 = CONCAT22(local_4b8._2_2_,param_5);
  iVar1 = FUN_140362620(local_488,param_2,param_3,param_4);
  if (iVar1 == 0) {
    local_4b8 = 0xe6;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 0x58))(plVar2,local_488,0xffffffff);
  }
  FUN_1403625e0(local_488);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_16  @1405ab0f0  [high:rtti-vtable]  (orig: FUN_1405ab0f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405ab0f0(longlong param_1,undefined4 param_2,undefined2 param_3,longlong param_4)

{
  int iVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if (param_4 == 0) {
    local_4d8 = CONCAT44(local_4d8._4_4_,0xf3);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4d0 = 0xffffff;
    local_4d8 = 0;
    local_4c8 = param_3;
    iVar1 = FUN_14015b300(local_488,"SYSTEM","ALLUSERS",param_4);
    if (iVar1 == 0) {
      local_4d8 = CONCAT44(local_4d8._4_4_,0xf7);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar3 = (longlong *)FUN_1400876b0(uVar2);
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,param_2,1);
      if (plVar3 == (longlong *)0x0) {
        local_4d8 = CONCAT44(local_4d8._4_4_,0xfb);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*plVar3 + 0x38))(plVar3,local_488,0);
      }
    }
    FUN_14015b2c0(local_488);
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_15  @1405ab270  [high:rtti-vtable]  (orig: FUN_1405ab270)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1405ab270(longlong param_1,longlong param_2)

{
  int iVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_2 == 0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x108);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_14015b240();
    local_488 = 1;
    local_490 = 0;
    local_498 = 0;
    local_4a0 = 0;
    local_4a8 = 0x7db;
    local_4b0 = 0xffffff;
    local_4b8 = 0;
    iVar1 = FUN_14015b300(local_468,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 == 0) {
      local_4b8 = CONCAT44(local_4b8._4_4_,0x10a);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,local_468,0xffffffff);
    }
    FUN_14015b2c0(local_468);
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_18  @1405ab3b0  [high:rtti-vtable]  (orig: FUN_1405ab3b0)
void FUN_1405ab3b0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  (**(code **)(*plVar1 + 0x60))(plVar1,param_2,0xffffffff,0,0xffffff,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_19  @1405ab400  [high:rtti-vtable]  (orig: FUN_1405ab400)
undefined8 FUN_1405ab400(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                           param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_28  @1405ab4c0  [high:rtti-vtable]  (orig: FUN_1405ab4c0)
undefined8 FUN_1405ab4c0(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_2 + 10),
                           param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_4  @1405ab550  [high:rtti-vtable]  (orig: FUN_1405ab550)
undefined8 FUN_1405ab550(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_3 == 0) {
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0xffffffff,*(undefined2 *)(param_3 + 10),
                           param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar3 + 0x30))(plVar3,param_2,puVar2);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_150  @1405ab5e0  [high:rtti-vtable]  (orig: FUN_1405ab5e0)
void FUN_1405ab5e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006d60(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

// ==== CSyndicateActor@adapter::vfunc_48  @1405ab640  [high:rtti-vtable]  (orig: FUN_1405ab640)
undefined1 FUN_1405ab640(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined1 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14027a410(*(longlong *)(lVar1 + 0x218),param_2,param_3,param_4);
  return uVar2;
}

// ==== CSyndicateActor@adapter::vfunc_49  @1405ab6f0  [high:rtti-vtable]  (orig: FUN_1405ab6f0)
undefined1 FUN_1405ab6f0(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14027a130(*(longlong *)(lVar1 + 0x218),param_2,param_3,param_4);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_37  @1405ab7b0  [high:rtti-vtable]  (orig: FUN_1405ab7b0)
void FUN_1405ab7b0(undefined8 param_1,undefined8 *param_2,undefined8 param_3,undefined8 param_4)

{
  if (param_2 != (undefined8 *)0x0) {
    (**(code **)*param_2)(param_2,1,param_2,param_4,0xfffffffffffffffe);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_7  @1405ab7e0  [high:rtti-vtable]  (orig: FUN_1405ab7e0)
undefined1 FUN_1405ab7e0(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310((int)param_1[3],0,*(undefined2 *)(param_3 + 10),param_3 + 0xc,
                           *(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    uVar1 = (**(code **)(*param_1 + 0x5a0))(param_1,param_2,puVar2,param_4);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_13  @1405ab8c0  [high:rtti-vtable]  (orig: FUN_1405ab8c0)
undefined8 FUN_1405ab8c0(longlong param_1,undefined4 param_2,longlong param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong *plVar4;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                           param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                       (*(longlong **)(lVar3 + 0x98),param_2,1);
    uVar1 = 0;
    if (plVar4 != (longlong *)0x0) {
      (**(code **)(*plVar4 + 0x38))(plVar4,puVar2,0);
      if (puVar2 != (undefined8 *)0x0) {
        (**(code **)*puVar2)(puVar2,1);
      }
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_8  @1405ab9d0  [high:rtti-vtable]  (orig: FUN_1405ab9d0)
void FUN_1405ab9d0(longlong *param_1,longlong param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar1 = (undefined8 *)
             FUN_1402ba310((int)param_1[3],0,*(undefined2 *)(param_2 + 10),param_2 + 0xc,
                           *(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    if (puVar1 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_1 + 0x48))(param_1,puVar1,param_3);
      (**(code **)*puVar1)(puVar1,1);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_33  @1405abab0  [high:rtti-vtable]  (orig: FUN_1405abab0)
void FUN_1405abab0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a9d0(uVar1,param_2,param_4,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_34  @1405abaf0  [high:rtti-vtable]  (orig: FUN_1405abaf0)
void FUN_1405abaf0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008aa10(uVar1,param_2,param_4,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_95  @1405abb30  [high:rtti-vtable]  (orig: FUN_1405abb30)
undefined8 FUN_1405abb30(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      uVar4 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x170))(local_res8 + 0x10);
      return uVar4;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_96  @1405abbe0  [high:rtti-vtable]  (orig: FUN_1405abbe0)
undefined8 FUN_1405abbe0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      uVar4 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x168))(local_res8 + 0x10);
      return uVar4;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_97  @1405abc90  [high:rtti-vtable]  (orig: FUN_1405abc90)
undefined8 FUN_1405abc90(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong local_res20;
  undefined8 uVar5;
  
  uVar5 = 0xfffffffffffffffe;
  local_res20 = 0;
  uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar3 = (longlong *)FUN_1400875f0(uVar2);
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,param_2);
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res20,*plVar3,uVar5);
    if (cVar1 != '\0') {
      FUN_1402be990(local_res20,param_3);
      lVar4 = (**(code **)(*(longlong *)(local_res20 + 0x10) + 0x160))();
      if (lVar4 != 0) {
        FUN_1402cb7b0(lVar4,param_3,1);
      }
      FUN_1402bda30(local_res20);
      return 1;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_99  @1405abd40  [high:rtti-vtable]  (orig: FUN_1405abd40)
undefined8 FUN_1405abd40(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      lVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x160))(local_res8 + 0x10);
      if (lVar2 != 0) {
        uVar4 = (**(code **)(**(longlong **)(lVar2 + 0x58) + 0x10))(*(longlong **)(lVar2 + 0x58),5);
        return uVar4;
      }
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_32  @1405abe10  [high:rtti-vtable]  (orig: FUN_1405abe10)
undefined8 FUN_1405abe10(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  
  lVar1 = FUN_140008520();
  if (lVar1 == 0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    puVar2 = (undefined8 *)(lVar1 + 8);
  }
  (**(code **)*puVar2)(puVar2,param_2,param_3);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_56  @1405abe50  [high:rtti-vtable]  (orig: FUN_1405abe50)
void FUN_1405abe50(longlong param_1)

{
  undefined2 uVar1;
  undefined2 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  undefined8 uVar10;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar6 != 0) &&
     (lVar7 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x160))(lVar6 + 0x10), lVar7 != 0)) {
    plVar8 = *(longlong **)(*(longlong *)(lVar7 + 0x58) + 8);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
    uVar9 = (**(code **)(*plVar8 + 0x58))(plVar8);
    if ((uVar9 >> 0x1c & 1) != 0) {
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar8 = (longlong *)FUN_1400876b0(uVar10);
      lVar7 = *plVar8;
      uVar4 = FUN_140161f50(lVar6);
      lVar7 = (**(code **)(lVar7 + 0x10))(plVar8,uVar4,1);
      local_18 = 0;
      local_14 = 0;
      local_10 = 0;
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar10 = FUN_1400d6610(uVar10);
      FUN_140006c50(uVar10,&local_18);
      if ((lVar7 == 0) || (cVar3 = FUN_1401195d0(lVar7), cVar3 == '\0')) {
        uVar1 = *(undefined2 *)(lVar6 + 0xf0e);
        uVar2 = *(undefined2 *)(lVar6 + 0xf0c);
        uVar4 = FUN_140161f50(lVar6);
        iVar5 = FUN_1401c55b0(lVar6,uVar4,uVar2,uVar1,0);
        if (iVar5 != -1) {
          return;
        }
      }
      FUN_1401c55b0(lVar6,local_18,local_14,local_10,0);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_148  @1405abf90  [high:rtti-vtable]  (orig: FUN_1405abf90)
undefined8 FUN_1405abf90(longlong param_1,undefined4 param_2,undefined2 param_3,undefined2 param_4)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x20))
                    (*(longlong **)(lVar2 + 0x98),param_2,1);
  if ((lVar2 != 0) && (cVar1 = FUN_1402c3cc0(lVar2,param_3,param_4), cVar1 != '\0')) {
    return 1;
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_106  @1405ac040  [high:rtti-vtable]  (orig: FUN_1405ac040)
void FUN_1405ac040(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  undefined8 uVar1;
  
  FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar1 = InstanceGet();
  FUN_1401667d0(param_2,param_3,param_4,param_5,0,0,uVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_112  @1405ac0a0  [high:rtti-vtable]  (orig: FUN_1405ac0a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ac0a0(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined1 auStack_4c8 [32];
  undefined8 local_4a8;
  int local_498;
  int local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined4 local_484;
  undefined4 local_480;
  undefined4 local_47c;
  undefined4 local_478;
  undefined4 local_474;
  undefined4 local_470;
  undefined4 local_46c;
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  undefined4 local_45c;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != 0) {
    local_4a8 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
    if ((param_3 != 0) &&
       (plVar4 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                           (*(longlong **)(param_1 + 0x10),param_3), plVar4 != (longlong *)0x0)) {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar5 = FUN_140087970(uVar5);
      cVar1 = FUN_140005850(uVar5);
      if ((cVar1 != '\0') && (iVar2 = (**(code **)(plVar4[2] + 0x170))(), iVar2 == param_2)) {
        local_494 = 0;
        local_490 = 0;
        local_48c = 0;
        local_488 = 0;
        local_484 = 0;
        local_480 = 0;
        local_47c = 0;
        local_478 = 0;
        local_474 = 0;
        local_470 = 0;
        local_46c = 0;
        local_468 = 0;
        local_464 = 0;
        local_460 = 0;
        local_45c = 0;
        local_498 = param_2;
        plVar6 = (longlong *)FUN_140087ed0();
        local_494 = (**(code **)(*plVar6 + 0x2c0))(plVar6,param_2);
        local_494 = local_494 + -1;
        plVar6 = (longlong *)FUN_140087ed0();
        local_490 = (**(code **)(*plVar6 + 0x2c8))(plVar6,param_2);
        FUN_1403b6940(local_458);
        uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
        iVar2 = FUN_1403b69f0(local_458,1,uVar3,&local_498);
        if (iVar2 != 0) {
          (**(code **)(*plVar4 + 0x130))(plVar4,local_458);
        }
        FUN_1403b6990(local_458);
      }
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_114  @1405ac210  [high:rtti-vtable]  (orig: FUN_1405ac210)
void FUN_1405ac210(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x148);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140005680(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_115  @1405ac260  [high:rtti-vtable]  (orig: FUN_1405ac260)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405ac260(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  char cVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  FUN_140449990(local_468);
  cVar2 = FUN_140449a50(local_468,param_2,param_3,param_4);
  if (cVar2 == '\0') {
    FUN_1404499e0(local_468);
    uVar3 = 0;
  }
  else {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    uVar4 = FUN_14008b340(uVar5);
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    cVar2 = FUN_1400b3d90(uVar5,uVar4);
    if (cVar2 == '\0') {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar3 = (**(code **)(*plVar6 + 8))(plVar6,local_468);
      FUN_1404499e0(local_468);
    }
    else {
      plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      lVar1 = *plVar6;
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar4 = FUN_14008b340(uVar5);
      uVar3 = (**(code **)(lVar1 + 0x18))(plVar6,uVar4,local_468);
      FUN_1404499e0(local_468);
    }
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_116  @1405ac370  [high:rtti-vtable]  (orig: FUN_1405ac370)
void FUN_1405ac370(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_117  @1405ac3f0  [high:rtti-vtable]  (orig: FUN_1405ac3f0)
void FUN_1405ac3f0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  undefined8 uVar1;
  longlong lVar2;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0xa8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140145f60(*(undefined8 *)(lVar2 + 0xa8),param_3,uVar1,0,0,0);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_93  @1405ac490  [high:rtti-vtable]  (orig: FUN_1405ac490)
undefined4 FUN_1405ac490(longlong param_1,char *param_2)

{
  undefined8 uVar1;
  char cVar2;
  int iVar3;
  
  if (param_2 != (char *)0x0) {
    iVar3 = tq::NameStrCheck(param_2,false);
    if (iVar3 != 0) {
      uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      cVar2 = FUN_14008a1d0(uVar1,param_2,0);
      if (cVar2 == '\0') {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_120  @1405ac4f0  [high:rtti-vtable]  (orig: FUN_1405ac4f0)
void FUN_1405ac4f0(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_140092c80(uVar1,param_2,param_3);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_121  @1405ac520  [high:rtti-vtable]  (orig: FUN_1405ac520)
void FUN_1405ac520(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a830(uVar1,param_2,param_3,param_4);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_123  @1405ac560  [high:rtti-vtable]  (orig: FUN_1405ac560)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405ac560(longlong param_1,int param_2,undefined4 param_3,char *param_4,undefined4 param_5,
             undefined4 param_6)

{
  undefined8 uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_88 [32];
  int *local_68;
  int local_58;
  undefined4 local_54;
  undefined1 local_50;
  char local_4f [39];
  undefined4 local_28;
  undefined4 local_24;
  undefined1 local_20;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  if (param_2 == 0) {
    local_68 = (int *)CONCAT44(local_68._4_4_,0x807);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else if (param_4 == (char *)0x0) {
    local_68 = (int *)CONCAT44(local_68._4_4_,0x808);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    local_4f[0] = '\0';
    local_4f[1] = '\0';
    local_4f[2] = '\0';
    local_4f[3] = '\0';
    local_4f[4] = '\0';
    local_4f[5] = '\0';
    local_4f[6] = '\0';
    local_4f[7] = '\0';
    local_4f[8] = '\0';
    local_4f[9] = '\0';
    local_4f[10] = '\0';
    local_4f[0xb] = '\0';
    local_4f[0xc] = '\0';
    local_4f[0xd] = '\0';
    local_4f[0xe] = '\0';
    local_4f[0xf] = '\0';
    local_4f[0x10] = '\0';
    local_4f[0x11] = '\0';
    local_4f[0x12] = '\0';
    local_4f[0x13] = '\0';
    local_4f[0x14] = '\0';
    local_4f[0x15] = '\0';
    local_4f[0x16] = '\0';
    local_4f[0x17] = '\0';
    local_4f[0x18] = '\0';
    local_4f[0x19] = '\0';
    local_4f[0x1a] = '\0';
    local_4f[0x1b] = '\0';
    local_4f[0x1c] = '\0';
    local_4f[0x1d] = '\0';
    local_4f[0x1e] = '\0';
    local_4f[0x1f] = '\0';
    local_4f[0x20] = '\0';
    local_4f[0x21] = '\0';
    local_4f[0x22] = '\0';
    local_4f[0x23] = '\0';
    local_28 = param_5;
    local_20 = 0;
    local_24 = param_6;
    local_50 = 2;
    local_58 = param_2;
    local_54 = param_3;
    tq::SafeCopy(local_4f,param_4,0x24);
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar3 = *(longlong **)(lVar2 + 0x80);
    if (plVar3 == (longlong *)0x0) {
      local_68 = (int *)CONCAT44(local_68._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
    local_68 = &local_58;
    (**(code **)(*plVar3 + 0x50))(plVar3,4,0xc354,0x3c);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_124  @1405ac6c0  [high:rtti-vtable]  (orig: FUN_1405ac6c0)
void FUN_1405ac6c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006cc0(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

// ==== CSyndicateActor@adapter::vfunc_21  @1405ac720  [high:rtti-vtable]  (orig: FUN_1405ac720)
undefined8 FUN_1405ac720(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310((int)param_1[3],0,*(undefined2 *)(param_3 + 10),param_3 + 0xc,
                           *(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    (**(code **)(*param_1 + 0x5a8))(param_1,param_2,puVar2,param_4);
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_131  @1405ac7f0  [high:rtti-vtable]  (orig: FUN_1405ac7f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405ac7f0(longlong *param_1,int param_2,undefined4 param_3,char param_4,char param_5,
             longlong param_6)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  uint uVar4;
  undefined1 auStack_4d8 [32];
  uint local_4b8;
  longlong local_4b0;
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if ((param_2 == 0) || (param_6 == 0)) {
    uVar3 = 0;
  }
  else {
    uVar4 = (uint)(param_4 != '\0');
    if (param_5 != '\0') {
      uVar4 = uVar4 + 0x10000;
    }
    FUN_140433120(local_488);
    local_4a8 = (**(code **)(*param_1 + 0x3f0))(param_1);
    local_4b0 = param_6;
    local_4b8 = uVar4;
    cVar1 = FUN_1404332f0(local_488,0xd,param_2,param_3);
    if (cVar1 != '\0') {
      plVar2 = (longlong *)FUN_140008520((int)param_1[3]);
      (**(code **)(*plVar2 + 0x78))(plVar2,local_488);
    }
    FUN_1404331a0(local_488);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_132  @1405ac8e0  [high:rtti-vtable]  (orig: FUN_1405ac8e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1405ac8e0(longlong *param_1,undefined4 param_2,undefined4 param_3,longlong param_4,
             longlong param_5)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  longlong local_4b0;
  longlong local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if ((param_4 == 0) || (param_5 == 0)) {
    uVar3 = 0;
  }
  else {
    FUN_140433120(local_488);
    local_4b8 = (**(code **)(*param_1 + 0x3f0))(param_1);
    local_4a8 = param_5;
    local_4b0 = param_4;
    cVar1 = FUN_1404333b0(local_488,0xe,param_2,param_3);
    if (cVar1 != '\0') {
      plVar2 = (longlong *)FUN_140008520((int)param_1[3]);
      (**(code **)(*plVar2 + 0x78))(plVar2,local_488);
    }
    FUN_1404331a0(local_488);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_133  @1405ac9b0  [high:rtti-vtable]  (orig: FUN_1405ac9b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405ac9b0(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_1403f36a0(local_478);
  iVar1 = FUN_1403f3790(local_478,0,param_2,param_3);
  if (iVar1 != 0) {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 8))(plVar2,local_478);
    FUN_1403f3720(local_478);
  }
  else {
    FUN_1403f3720(local_478);
  }
  return iVar1 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_134  @1405aca50  [high:rtti-vtable]  (orig: FUN_1405aca50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405aca50(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_1403f36a0(local_478);
  iVar1 = FUN_1403f3790(local_478,1,param_2,param_3);
  if (iVar1 == 0) {
    FUN_1403f3720(local_478);
  }
  else {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 8))(plVar2,local_478);
    FUN_1403f3720(local_478);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_136  @1405acaf0  [high:rtti-vtable]  (orig: FUN_1405acaf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405acaf0(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  int iVar1;
  longlong *plVar2;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_1403f36a0(local_478);
  iVar1 = FUN_1403f3790(local_478,2,param_2,param_3);
  if (iVar1 == 0) {
    FUN_1403f3720(local_478);
  }
  else {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 8))(plVar2,local_478);
    FUN_1403f3720(local_478);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_135  @1405acb90  [high:rtti-vtable]  (orig: FUN_1405acb90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405acb90(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  if (param_2 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    FUN_140433120(local_468);
    cVar1 = FUN_140433530(local_468,param_2);
    if (cVar1 != '\0') {
      plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar2 + 8))(plVar2,local_468);
    }
    FUN_1404331a0(local_468);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_138  @1405acc30  [high:rtti-vtable]  (orig: FUN_1405acc30)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405acc30(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_498 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_3)
  ;
  if (plVar4 == (longlong *)0x0) {
    local_498 = 0x92d;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1403ef810(local_468);
    uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
    local_480 = param_7;
    local_488 = param_6;
    local_490 = param_5;
    local_498 = param_4;
    iVar2 = FUN_1403ef8c0(local_468,2,param_2,uVar1);
    if (iVar2 != 0) {
      (**(code **)(*plVar4 + 0x138))(plVar4,local_468,4);
    }
    FUN_1403ef860(local_468);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_167  @1405acd80  [high:rtti-vtable]  (orig: FUN_1405acd80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405acd80(longlong param_1,undefined1 param_2,int param_3,undefined4 param_4,
                  undefined4 param_5)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_3 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_488 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                       (*(longlong **)(lVar2 + 0x90),param_3);
    if (plVar3 != (longlong *)0x0) {
      FUN_140460a10(local_468);
      iVar1 = FUN_140460ae0(local_468,param_2,param_4,param_5);
      if (iVar1 != 0) {
        (**(code **)(*plVar3 + 0x138))(plVar3,local_468,4);
      }
      FUN_140460a60(local_468);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_170  @1405ace80  [high:rtti-vtable]  (orig: FUN_1405ace80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ace80(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    local_478 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 == (longlong *)0x0) {
    local_478 = 0x975;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140460fa0(local_458);
    cVar1 = FUN_140461050(local_458,param_3);
    if (cVar1 != '\0') {
      (**(code **)(*plVar3 + 0x138))(plVar3,local_458,4);
    }
    FUN_140460ff0(local_458);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_171  @1405acf90  [high:rtti-vtable]  (orig: FUN_1405acf90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405acf90(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined2 param_5,undefined2 param_6)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    local_488 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 == (longlong *)0x0) {
    local_488 = 0x985;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140460fa0(local_468);
    local_488 = CONCAT22(local_488._2_2_,param_6);
    cVar1 = FUN_1404610a0(local_468,param_3,param_4,param_5);
    if (cVar1 != '\0') {
      (**(code **)(*plVar3 + 0x130))(plVar3,local_468);
    }
    FUN_140460ff0(local_468);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_137  @1405ad0b0  [high:rtti-vtable]  (orig: FUN_1405ad0b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad0b0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  int iVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_4a8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_3)
  ;
  if (plVar4 != (longlong *)0x0) {
    FUN_1403ef810(local_478);
    local_490 = param_7;
    local_498 = param_6;
    local_4a0 = param_5;
    local_4a8 = param_4;
    iVar1 = FUN_1403ef8c0(local_478,3,param_2,param_3);
    if (iVar1 != 0) {
      plVar5 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      lVar3 = *plVar5;
      uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
      (**(code **)(lVar3 + 0x10))(plVar5,uVar2,local_478);
    }
    FUN_1403ef860(local_478);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_139  @1405ad1e0  [high:rtti-vtable]  (orig: FUN_1405ad1e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad1e0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    local_488 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    FUN_140460da0(local_468);
    iVar1 = FUN_140460e50(local_468,param_3,param_4);
    if (iVar1 != 0) {
      (**(code **)(*plVar3 + 0x138))(plVar3,local_468,4);
    }
    FUN_140460df0(local_468);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_140  @1405ad2d0  [high:rtti-vtable]  (orig: FUN_1405ad2d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad2d0(longlong param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    local_468 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    FUN_140460a10(local_448);
    iVar1 = FUN_140460ac0(local_448,0);
    if (iVar1 != 0) {
      (**(code **)(*plVar3 + 0x138))(plVar3,local_448,4);
    }
    FUN_140460a60(local_448);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_141  @1405ad3c0  [high:rtti-vtable]  (orig: FUN_1405ad3c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad3c0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined4 local_480;
  undefined4 local_478;
  undefined4 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_488 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2)
  ;
  if (plVar4 != (longlong *)0x0) {
    FUN_1403ef810(local_458);
    uVar1 = (**(code **)(*plVar4 + 0x38))(plVar4);
    local_470 = 0;
    local_478 = 0;
    local_480 = 0;
    local_488 = param_2;
    iVar2 = FUN_1403ef8c0(local_458,5,param_3,uVar1);
    if (iVar2 != 0) {
      (**(code **)(*plVar4 + 0x138))(plVar4,local_458,4);
    }
    FUN_1403ef860(local_458);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_142  @1405ad4c0  [high:rtti-vtable]  (orig: FUN_1405ad4c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad4c0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    local_478 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))(*(longlong **)(lVar2 + 0x90),param_2);
  if (lVar2 != 0) {
    FUN_14039e680(local_458);
    iVar1 = FUN_14039e700(local_458,param_3,0x1d,*(undefined4 *)(lVar2 + 0xfa4));
    if (iVar1 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_458);
    }
    FUN_14039e6d0(local_458);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_176  @1405ad5b0  [high:rtti-vtable]  (orig: FUN_1405ad5b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad5b0(longlong param_1,int param_2,int param_3,longlong param_4,undefined4 param_5)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != 0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
    if (0 < param_3) {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar4 = (longlong *)FUN_140087650(uVar3);
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0x98))(plVar4,param_2);
      if (plVar4 != (longlong *)0x0) {
        FUN_14045c3a0(local_458);
        uVar2 = (**(code **)(*plVar4 + 0x38))(plVar4);
        cVar1 = FUN_14045c450(local_458,0xc,uVar2,param_5);
        if (cVar1 == '\0') {
          FUN_14045c3f0(local_458);
        }
        else {
          lVar5 = 0;
          if (0 < (longlong)param_3) {
            do {
              if ((*(int *)(param_4 + lVar5 * 4) != 0) &&
                 (cVar1 = FUN_14045c4d0(local_458), cVar1 == '\0')) {
                log_InlineLogERROR("CSyndicateActor::Send2CrossSignUpPlunderWarInfo msg over size");
                break;
              }
              lVar5 = lVar5 + 1;
            } while (lVar5 < param_3);
          }
          (**(code **)(*plVar4 + 0x138))(plVar4,local_458,4);
          FUN_14045c3f0(local_458);
        }
      }
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_143  @1405ad6e0  [high:rtti-vtable]  (orig: FUN_1405ad6e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad6e0(longlong param_1,undefined4 param_2,undefined2 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_4a8 [32];
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  FUN_140433120(local_478);
  cVar1 = FUN_140433210(local_478,param_3,param_2);
  if (cVar1 != '\0') {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 8))(plVar2,local_478);
  }
  FUN_1404331a0(local_478);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_144  @1405ad770  [high:rtti-vtable]  (orig: FUN_1405ad770)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ad770(longlong param_1,undefined8 param_2,undefined2 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_488 [32];
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  FUN_14045bc40(local_458);
  cVar1 = FUN_14045bd40(local_458,param_3,param_2);
  if (cVar1 != '\0') {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 8))(plVar2,local_458);
  }
  FUN_14045bc90(local_458);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_145  @1405ad800  [high:rtti-vtable]  (orig: FUN_1405ad800)
void FUN_1405ad800(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a730(uVar1,0);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_125  @1405ad820  [high:rtti-vtable]  (orig: FUN_1405ad820)
undefined8 FUN_1405ad820(longlong param_1,int param_2)

{
  char cVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  if (param_2 == 0) {
    return 0;
  }
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    return 0;
  }
  cVar1 = FUN_140167b70(lVar2);
  if (cVar1 != '\0') {
    uVar3 = FUN_140167b40(lVar2);
    return uVar3;
  }
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar3 = FUN_14008b420(uVar3);
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_126  @1405ad8a0  [high:rtti-vtable]  (orig: FUN_1405ad8a0)
void FUN_1405ad8a0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b420(uVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_151  @1405ad8c0  [high:rtti-vtable]  (orig: FUN_1405ad8c0)
bool FUN_1405ad8c0(longlong param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4,
                  undefined4 *param_5)

{
  longlong *plVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if (lVar3 != 0) {
    plVar1 = (longlong *)(lVar3 + 0x10);
    uVar2 = (**(code **)(*plVar1 + 0x168))(plVar1);
    *param_3 = uVar2;
    uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
    *param_4 = uVar2;
    uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
    *param_5 = uVar2;
  }
  else {
    log_InlineLogERROR("CSyndicateActor::GetPublishPoint user[%u] is not find.");
  }
  return lVar3 != 0;
}

// ==== CSyndicateActor@adapter::vfunc_152  @1405ad990  [high:rtti-vtable]  (orig: FUN_1405ad990)
ulonglong FUN_1405ad990(longlong param_1,int param_2,int param_3,undefined8 param_4)

{
  int iVar1;
  undefined4 uVar2;
  ulonglong in_RAX;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,param_2);
    in_RAX = 0;
    if (lVar5 != 0) {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar3 = FUN_1400d6610(uVar3);
      iVar1 = FUN_140006d00(uVar3);
      if (iVar1 < 1) {
        uVar2 = 1;
      }
      else {
        uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        uVar3 = FUN_1400d6610(uVar3);
        uVar2 = FUN_140006d00(uVar3);
      }
      uVar6 = FUN_1401c9c80(lVar5,param_3,param_4,uVar2);
      return uVar6;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CSyndicateActor@adapter::vfunc_153  @1405ada60  [high:rtti-vtable]  (orig: FUN_1405ada60)
void FUN_1405ada60(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_14017ba10(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_154  @1405adae0  [high:rtti-vtable]  (orig: FUN_1405adae0)
void FUN_1405adae0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_14017bac0(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_155  @1405adb60  [high:rtti-vtable]  (orig: FUN_1405adb60)
undefined8 FUN_1405adb60(longlong param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2)
  ;
  if (plVar4 != (longlong *)0x0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0xb0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    uVar5 = *(undefined8 *)(lVar3 + 0xb0);
    uVar1 = (**(code **)(*plVar4 + 0x108))(plVar4);
    uVar2 = FUN_140006cf0(uVar5);
    if (uVar2 <= uVar1) {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar5 = FUN_1400d6610(uVar5);
      uVar1 = FUN_140006ce0(uVar5);
      uVar2 = (**(code **)(plVar4[2] + 0x70))(plVar4 + 2);
      if (uVar1 <= uVar2) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_174  @1405adc80  [high:rtti-vtable]  (orig: FUN_1405adc80)
bool FUN_1405adc80(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                  undefined2 param_5)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))(*(longlong **)(lVar3 + 0x90),param_2);
  if ((((lVar3 != 0) &&
       (cVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x220))(lVar3 + 0x10), cVar1 != '\0')) &&
      (iVar2 = FUN_140166ec0(lVar3), iVar2 == 0)) && (cVar1 = FUN_140178570(lVar3,0), cVar1 == '\0')
     ) {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar5 = (longlong *)FUN_1400876b0(uVar4);
    lVar3 = (**(code **)(*plVar5 + 0x10))(plVar5,param_3,1);
    if (((lVar3 != 0) && (cVar1 = FUN_1402c68a0(lVar3,7,param_4,param_5), cVar1 == '\0')) &&
       ((cVar1 = FUN_14016ccf0(lVar3), cVar1 == '\0' &&
        ((cVar1 = FUN_140119510(lVar3), cVar1 == '\0' &&
         (cVar1 = FUN_14016cb70(lVar3), cVar1 == '\0')))))) {
      cVar1 = FUN_1402c3cc0(lVar3,param_4,param_5);
      return cVar1 != '\0';
    }
  }
  return false;
}

// ==== CSyndicateActor@adapter::vfunc_178  @1405adde0  [high:rtti-vtable]  (orig: FUN_1405adde0)
void FUN_1405adde0(longlong param_1,int param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong local_res18 [2];
  
  if (param_2 != 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x88) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))
                       (*(longlong **)(lVar2 + 0x88),param_2);
    if (plVar3 != (longlong *)0x0) {
      local_res18[0] = 0;
      cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,local_res18);
      if ((cVar1 != '\0') && (local_res18[0] != 0)) {
        FUN_1402bb6a0(local_res18[0],1);
      }
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_179  @1405ade90  [high:rtti-vtable]  (orig: FUN_1405ade90)
ulonglong FUN_1405ade90(longlong param_1,int param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  ulonglong in_RAX;
  longlong lVar4;
  ulonglong uVar5;
  
  if (param_2 == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar4 = (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x98))(*(longlong **)(lVar4 + 0x90),param_2);
  if (lVar4 == 0) {
    return 0;
  }
  plVar1 = (longlong *)(lVar4 + 0x10);
  lVar4 = (**(code **)(*plVar1 + 0x160))(plVar1);
  uVar5 = 0;
  if (lVar4 != 0) {
    uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
    uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
    uVar5 = FUN_1402c68a0(lVar4,param_3,uVar3,uVar2);
  }
  return uVar5;
}

// ==== CSyndicateActor@adapter::vfunc_156  @1405adf80  [high:rtti-vtable]  (orig: FUN_1405adf80)
undefined1 FUN_1405adf80(longlong param_1,int param_2,int param_3)

{
  undefined8 uVar1;
  undefined1 uVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar3 = (longlong *)FUN_140087650(uVar1);
    lVar4 = (**(code **)(*plVar3 + 0x98))(plVar3,param_2);
    if (lVar4 != 0) {
      uVar2 = FUN_1401bdae0(lVar4,param_3,0);
      return uVar2;
    }
  }
  return 0;
}

// ==== CSyndicateActor@adapter::vfunc_157  @1405adfe0  [high:rtti-vtable]  (orig: FUN_1405adfe0)
void FUN_1405adfe0(longlong param_1,int param_2,int param_3,int param_4,undefined4 param_5,
                  undefined4 param_6)

{
  undefined8 uVar1;
  longlong *plVar2;
  longlong lVar3;
  
  if (((param_2 != 0) && (param_3 != 0)) && (param_4 != 0)) {
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar2 = (longlong *)FUN_140087650(uVar1);
    lVar3 = (**(code **)(*plVar2 + 0x98))(plVar2,param_2);
    if (lVar3 != 0) {
      FUN_140168d90(lVar3,param_3,param_4,param_5,param_6);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_14  @1405ae060  [high:rtti-vtable]  (orig: FUN_1405ae060)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405ae060(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
                  undefined8 param_5)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  FUN_140433120(local_488);
  uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  uVar2 = FUN_14008b420(uVar3);
  local_4a8 = param_3;
  local_4a0 = param_4;
  cVar1 = FUN_1404335b0(local_488,param_2,param_5,uVar2);
  if (cVar1 != '\0') {
    plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar4 + 0x78))(plVar4,local_488);
    FUN_1404331a0(local_488);
  }
  else {
    FUN_1404331a0(local_488);
  }
  return cVar1 != '\0';
}

// ==== CSyndicateActor@adapter::vfunc_128  @1405ae130  [high:rtti-vtable]  (orig: FUN_1405ae130)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405ae130(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  FUN_140433120(local_488);
  uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  local_4a8 = FUN_14008b420(uVar2);
  cVar1 = FUN_140433270(local_488,param_2,param_3,param_5);
  if (cVar1 == '\0') {
    FUN_1404331a0(local_488);
  }
  else {
    plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar3 + 0x20))(plVar3,param_4,local_488,4);
    FUN_1404331a0(local_488);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_50  @1405ae1f0  [high:rtti-vtable]  (orig: FUN_1405ae1f0)
undefined8
FUN_1405ae1f0(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14027a570(*(longlong *)(lVar1 + 0x218),param_4,param_3,param_2,param_5);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_51  @1405ae2b0  [high:rtti-vtable]  (orig: FUN_1405ae2b0)
undefined8
FUN_1405ae2b0(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
             undefined8 param_5)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_14027a720(*(longlong *)(lVar1 + 0x218),param_2,param_3,param_4,param_5);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_35  @1405ae370  [high:rtti-vtable]  (orig: FUN_1405ae370)
void FUN_1405ae370(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x180);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1400df9c0(lVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_162  @1405ae3d0  [high:rtti-vtable]  (orig: FUN_1405ae3d0)
undefined8 FUN_1405ae3d0(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  if ((0 < param_3) &&
     (0x28 < (ulonglong)
             ((*(longlong *)(lVar1 + 0xc28) - *(longlong *)(lVar1 + 0xc20) >> 2) + (longlong)param_3
             ))) {
    return 0;
  }
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_163  @1405ae430  [high:rtti-vtable]  (orig: FUN_1405ae430)
void FUN_1405ae430(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x98))(*(longlong **)(lVar1 + 0x90),param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140168be0(lVar1);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_169  @1405ae4b0  [high:rtti-vtable]  (orig: FUN_1405ae4b0)
void FUN_1405ae4b0(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_1400b3310(uVar1,param_2);
  return;
}

// ==== CSyndicateActor@adapter::vfunc_173  @1405ae4d0  [high:rtti-vtable]  (orig: FUN_1405ae4d0)
int FUN_1405ae4d0(longlong param_1,undefined8 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 == 0) {
    return 0;
  }
  cVar1 = FUN_140167b70(lVar3);
  if (cVar1 == '\0') {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    iVar2 = FUN_14008b420(uVar4);
  }
  else {
    iVar2 = FUN_140167b40(lVar3);
  }
  return iVar2 * 1000000 + param_3;
}

// ==== CSyndicateActor@adapter::vfunc_23  @1405ae550  [high:rtti-vtable]  (orig: FUN_1405ae550)
undefined8
FUN_1405ae550(longlong *param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
             undefined1 param_5)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310((int)param_1[3],0xffffffff,*(undefined2 *)(param_3 + 10),param_3 + 0xc,
                           *(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    uVar1 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)(*param_1 + 0xb0))(param_1,param_2,puVar2,param_4,param_5);
      (**(code **)*puVar2)(puVar2,1);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CSyndicateActor@adapter::vfunc_164  @1405ae620  [high:rtti-vtable]  (orig: FUN_1405ae620)
bool FUN_1405ae620(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  char cVar2;
  longlong lVar3;
  longlong *plVar4;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                    (*(longlong **)(lVar3 + 0x98),param_2,0);
  if (lVar3 != 0) {
    plVar4 = *(longlong **)(*(longlong *)(lVar3 + 0x58) + 8);
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,4);
    bVar1 = (**(code **)(*plVar4 + 0x58))(plVar4);
    if ((bVar1 >> 1 & 1) == 0) {
      cVar2 = FUN_1402c3cc0(lVar3,param_3,param_4);
      return cVar2 != '\0';
    }
  }
  return false;
}

// ==== CSyndicateActor@adapter::vfunc_98  @1405ae6f0  [high:rtti-vtable]  (orig: FUN_1405ae6f0)
undefined8 FUN_1405ae6f0(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  uint uVar6;
  undefined8 *local_28;
  undefined8 local_20;
  undefined8 local_18;
  longlong *local_10;
  
  if (param_2 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar4 = (longlong *)FUN_1400875f0(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x30))(plVar4);
    local_28 = (undefined8 *)(lVar5 + 0x10);
    local_18 = **(undefined8 **)(lVar5 + 0x40);
    uVar6 = 0;
    local_20 = *local_28;
    local_10 = (longlong *)0x0;
    while (cVar1 = FUN_1400ce310(&local_28), cVar1 != '\0') {
      uVar6 = uVar6 + 1;
      if (1000000 < uVar6) {
        log_InlineLogERROR(&DAT_1406d9c10);
        break;
      }
      if ((local_10 != (longlong *)0x0) && (lVar5 = (**(code **)(*local_10 + 0x160))(), lVar5 != 0))
      {
        plVar4 = (longlong *)(**(code **)(*local_10 + 0x160))();
        iVar2 = (**(code **)(*plVar4 + 8))(plVar4);
        if (iVar2 == param_2) {
          (**(code **)(*local_10 + 0x380))();
        }
      }
    }
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CSyndicateActor@adapter::vfunc_177  @1405ae810  [high:rtti-vtable]  (orig: FUN_1405ae810)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405ae810(longlong *param_1,int param_2,undefined4 param_3,longlong param_4,
                  longlong param_5)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  longlong *plVar5;
  IStringManager *pIVar6;
  char *_Format;
  uint uVar7;
  undefined1 auStack_2b8 [32];
  longlong local_298;
  longlong local_288;
  undefined1 local_280 [8];
  undefined1 local_278 [24];
  longlong *local_260;
  longlong *local_258 [2];
  char local_248;
  undefined1 local_247 [510];
  undefined1 local_49;
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_2b8;
  if (((param_5 != 0) && (param_4 != 0)) && (param_2 != 0)) {
    uVar4 = FUN_140008520((int)param_1[3]);
    plVar5 = (longlong *)FUN_1400875f0(uVar4);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,param_2);
    if (plVar5 != (longlong *)0x0) {
      uVar7 = 0;
      local_288 = 0;
      cVar2 = (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,&local_288);
      if ((cVar2 == '\0') || (local_288 == 0)) {
        return false;
      }
      FUN_1402bb5f0(local_288,param_3,1);
      local_248 = '\0';
      memset(local_247,0,0x1ff);
      pIVar6 = theInstance();
      _Format = (char *)(*(code *)**(undefined8 **)pIVar6)
                                  (pIVar6,"STR_LEAGUE_NOTIFY_BREAK_MOVE_BRICK");
      local_298 = param_5;
      _snprintf(&local_248,0x200,_Format);
      local_49 = 0;
      uVar4 = FUN_140008520((int)param_1[3]);
      uVar4 = FUN_140087650(uVar4);
      FUN_1402ac340(uVar4,local_280);
      do {
        cVar2 = FUN_1400ce310(local_278);
        if (cVar2 == '\0') {
LAB_1405aea71:
          return uVar7 < 1000000;
        }
        while (cVar2 = (**(code **)(*local_260 + 0x298))(local_260,0x1001,local_258), cVar2 == '\0')
        {
          cVar2 = FUN_1400ce310(local_278);
          if (cVar2 == '\0') {
            return uVar7 < 1000000;
          }
        }
        uVar7 = uVar7 + 1;
        if (1000000 < uVar7) {
          local_298 = CONCAT44(local_298._4_4_,0xae5);
          log_InlineLogERROR(&DAT_1406d9c10);
          goto LAB_1405aea71;
        }
        if ((local_258[0] != (longlong *)0x0) && (cVar2 = FUN_140168b80(), cVar2 != '\0')) {
          if (local_258[0] == (longlong *)0x0) {
            local_298 = CONCAT44(local_298._4_4_,0x2b);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          FUN_14017af70(local_258[0],0,0);
          if (local_258[0] == (longlong *)0x0) {
            local_298 = CONCAT44(local_298._4_4_,0x2b);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          lVar1 = *param_1;
          uVar3 = (**(code **)(*local_258[0] + 8))();
          (**(code **)(lVar1 + 0x28))(param_1,uVar3,&local_248,0xffff00);
        }
      } while( true );
    }
  }
  return false;
}

// ==== CSyndicateActor@adapter::vfunc_159  @1405aeab0  [high:rtti-vtable]  (orig: FUN_1405aeab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined4 FUN_1405aeab0(longlong param_1,undefined8 param_2,longlong param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  ulong uVar5;
  int iVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  IStringManager *pIVar10;
  char *pcVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 auStack_238 [32];
  undefined4 local_218;
  undefined4 local_210;
  uint local_208;
  undefined8 local_1f8;
  longlong *local_1f0;
  longlong *local_1e8;
  longlong *local_1e0 [3];
  longlong *local_1c8;
  longlong *local_1c0;
  undefined8 local_1b8;
  undefined8 local_1b0;
  undefined4 local_1a8;
  char local_1a4 [60];
  uint local_168;
  char local_164 [254];
  undefined1 local_66;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_54;
  undefined1 local_50;
  ulonglong local_48;
  
  local_1b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_238;
  if (param_3 == 0) {
    uVar4 = 0;
  }
  else {
    lVar7 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    uVar4 = 0;
    if ((lVar7 != 0) && (iVar3 = FUN_1401657c0(lVar7), uVar4 = 0, iVar3 != 0)) {
      plVar12 = (longlong *)(lVar7 + 0x10);
      lVar7 = (**(code **)(*plVar12 + 0x160))(plVar12);
      uVar4 = 0;
      if (lVar7 != 0) {
        uVar4 = (**(code **)(*plVar12 + 0x40))(plVar12);
        local_1f8 = (longlong *)CONCAT44(local_1f8._4_4_,uVar4);
        uVar4 = (**(code **)(*plVar12 + 0x48))(plVar12);
        local_1f8 = (longlong *)CONCAT44(uVar4,(undefined4)local_1f8);
        local_1f0 = operator_new(8);
        local_1e0[0] = (longlong *)0x0;
        if (local_1f0 != (longlong *)0x0) {
          *local_1f0 = (longlong)local_1e0;
          local_1e0[0] = local_1f0;
        }
        local_1c8 = (longlong *)0x0;
        local_1c0 = (longlong *)0x0;
        local_1b8 = 0;
        local_1e8 = local_1f0;
        uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        uVar8 = FUN_1400d6610(uVar8);
        uVar4 = FUN_140006d70(uVar8);
        local_218 = 0x1001;
        FUN_1402d2470(lVar7,local_1e0,local_1f8,uVar4);
        uVar5 = tq::TimeGet(3);
        plVar13 = local_1c8;
        local_1e8 = (longlong *)CONCAT44(local_1e8._4_4_,uVar5 / 10000 + 0x76c);
        local_1f0 = (longlong *)CONCAT44(local_1f0._4_4_,(uVar5 % 10000) / 100);
        plVar12 = local_1e0[0];
        if (local_1c0 < local_1c8) {
          _invalid_parameter_noinfo();
          plVar12 = local_1e0[0];
        }
        while( true ) {
          plVar9 = local_1c0;
          lVar7 = 0;
          if (local_1c0 < local_1c8) {
            _invalid_parameter_noinfo();
          }
          if ((plVar12 == (longlong *)0x0) || (plVar12 != local_1e0[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar13 == plVar9) break;
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar7 = *plVar12;
          }
          if (*(longlong **)(lVar7 + 0x20) <= plVar13) {
            _invalid_parameter_noinfo();
          }
          plVar9 = (longlong *)*plVar13;
          if (plVar9 != (longlong *)0x0) {
            local_1f8 = (longlong *)0x0;
            iVar6 = (**(code **)(*plVar9 + 0x18))(plVar9);
            if (((iVar6 == 0x1001) &&
                (cVar1 = (**(code **)(*plVar9 + 0x38))(plVar9,0x1001,&local_1f8), cVar1 != '\0')) &&
               (iVar6 = FUN_1401657c0(local_1f8), iVar6 == iVar3)) {
              uVar2 = FUN_140168be0(local_1f8);
              plVar9 = (longlong *)FUN_140087ed0();
              uVar4 = (**(code **)(*plVar9 + 0x620))(plVar9,uVar2);
              local_218 = CONCAT31(local_218._1_3_,1);
              cVar1 = FUN_140339ec0(local_1f8,uVar4,1);
              if (cVar1 == '\0') {
                plVar9 = (longlong *)FUN_140087ed0();
                uVar4 = (**(code **)(*plVar9 + 0x628))(plVar9);
                local_1a8 = 0;
                local_1a4[0] = '\0';
                local_1a4[1] = '\0';
                local_1a4[2] = '\0';
                local_1a4[3] = '\0';
                local_1a4[4] = '\0';
                local_1a4[5] = '\0';
                local_1a4[6] = '\0';
                local_1a4[7] = '\0';
                local_1a4[8] = '\0';
                local_1a4[9] = '\0';
                local_1a4[10] = '\0';
                local_1a4[0xb] = '\0';
                local_1a4[0xc] = '\0';
                local_1a4[0xd] = '\0';
                local_1a4[0xe] = '\0';
                local_1a4[0xf] = '\0';
                local_1a4[0x10] = '\0';
                local_1a4[0x11] = '\0';
                local_1a4[0x12] = '\0';
                local_1a4[0x13] = '\0';
                local_1a4[0x14] = '\0';
                local_1a4[0x15] = '\0';
                local_1a4[0x16] = '\0';
                local_1a4[0x17] = '\0';
                local_1a4[0x18] = '\0';
                local_1a4[0x19] = '\0';
                local_1a4[0x1a] = '\0';
                local_1a4[0x1b] = '\0';
                local_1a4[0x1c] = '\0';
                local_1a4[0x1d] = '\0';
                local_1a4[0x1e] = '\0';
                local_1a4[0x1f] = '\0';
                local_1a4[0x20] = '\0';
                local_1a4[0x21] = '\0';
                local_1a4[0x22] = '\0';
                local_1a4[0x23] = '\0';
                local_1a4[0x24] = '\0';
                local_1a4[0x25] = '\0';
                local_1a4[0x26] = '\0';
                local_1a4[0x27] = '\0';
                local_1a4[0x28] = '\0';
                local_1a4[0x29] = '\0';
                local_1a4[0x2a] = '\0';
                local_1a4[0x2b] = '\0';
                local_1a4[0x2c] = '\0';
                local_1a4[0x2d] = '\0';
                local_1a4[0x2e] = '\0';
                local_1a4[0x2f] = '\0';
                local_1a4[0x30] = '\0';
                local_1a4[0x31] = '\0';
                local_1a4[0x32] = '\0';
                local_1a4[0x33] = '\0';
                local_1a4[0x34] = '\0';
                local_1a4[0x35] = '\0';
                local_1a4[0x36] = '\0';
                local_1a4[0x37] = '\0';
                local_1a4[0x38] = '\0';
                local_1a4[0x39] = '\0';
                local_1a4[0x3a] = '\0';
                local_1a4[0x3b] = '\0';
                local_168 = 0;
                memset(local_164,0,0xff);
                local_64 = 0;
                local_60 = 0;
                local_5c = 0;
                local_58 = 0;
                local_54 = 0x1e;
                local_50 = 0;
                local_1a8 = (**(code **)(*local_1f8 + 8))();
                local_54 = 6;
                local_5c = uVar4;
                pIVar10 = theInstance();
                pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)(pIVar10,"STR_SYSTEM_NAME");
                strncpy(local_1a4,pcVar11,0x10);
                pIVar10 = theInstance();
                pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                            (pIVar10,"STR_LEAGUE_TITLE_ORDER_GIFT");
                _snprintf(local_1a4 + 0x20,0x20,pcVar11);
                local_168 = local_168 & 0xffffff;
                pIVar10 = theInstance();
                pcVar11 = (char *)(*(code *)**(undefined8 **)pIVar10)
                                            (pIVar10,"STR_LEAGUE_ORDER_GIFT_MAIL_CONTENT");
                local_210 = local_1f0._0_4_;
                local_218 = local_1e8._0_4_;
                local_208 = uVar5 % 100;
                _snprintf(local_164,0xff,pcVar11);
                local_66 = 0;
                uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
                uVar8 = FUN_14001b5b0(uVar8);
                FUN_1400df9c0(uVar8,&local_1a8);
              }
              else {
                local_208 = CONCAT31(local_208._1_3_,1);
                local_210 = 0;
                local_218 = 1;
                FUN_140340e50(local_1f8,uVar4,1,1);
              }
            }
          }
          lVar7 = 0;
          if (plVar12 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar7 = *plVar12;
          }
          if (*(longlong **)(lVar7 + 0x20) <= plVar13) {
            _invalid_parameter_noinfo();
          }
          plVar13 = plVar13 + 1;
        }
        if (local_1c8 != (longlong *)0x0) {
          operator_delete(local_1c8);
        }
        local_1c8 = (longlong *)0x0;
        local_1c0 = (longlong *)0x0;
        local_1b8 = 0;
        operator_delete(local_1e0[0]);
        uVar4 = 1;
      }
    }
  }
  return uVar4;
}

// ==== CSyndicateActor@adapter::vfunc_172  @1405aef90  [high:rtti-vtable]  (orig: FUN_1405aef90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405aef90(longlong param_1,undefined4 param_2,undefined4 param_3,longlong *param_4)

{
  int *piVar1;
  char cVar2;
  longlong *plVar3;
  int *piVar4;
  longlong lVar5;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (param_4[4] - param_4[3] >> 2 != 0) {
    FUN_14045c3a0(local_468);
    cVar2 = FUN_14045c450(local_468,param_2,param_3,0);
    if (cVar2 != '\0') {
      piVar4 = (int *)param_4[3];
      if ((int *)param_4[4] < piVar4) {
        _invalid_parameter_noinfo();
      }
      plVar3 = (longlong *)*param_4;
      while( true ) {
        piVar1 = (int *)param_4[4];
        if (piVar1 < (int *)param_4[3]) {
          _invalid_parameter_noinfo();
        }
        if (((longlong *)*param_4 == (longlong *)0x0) || ((longlong *)*param_4 != plVar3)) {
          _invalid_parameter_noinfo();
        }
        if (piVar1 == piVar4) goto LAB_1405af0b1;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar3;
        }
        if (*(int **)(lVar5 + 0x20) <= piVar4) {
          _invalid_parameter_noinfo();
        }
        if ((*piVar4 != 0) && (cVar2 = FUN_14045c4d0(local_468), cVar2 == '\0')) break;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar5 = 0;
        }
        else {
          lVar5 = *plVar3;
        }
        if (*(int **)(lVar5 + 0x20) <= piVar4) {
          _invalid_parameter_noinfo();
        }
        piVar4 = piVar4 + 1;
      }
      log_InlineLogERROR("CSyndicateActor::Send2CrossSignUpPlunderWarInfo msg over size");
LAB_1405af0b1:
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 8))(plVar3,local_468);
      FUN_14045c3f0(local_468);
      return;
    }
    FUN_14045c3f0(local_468);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_94  @1405af100  [high:rtti-vtable]  (orig: FUN_1405af100)
bool FUN_1405af100(longlong param_1,int param_2,longlong *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  ulonglong *puVar3;
  char cVar4;
  int iVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  uint uVar11;
  undefined4 local_res8 [2];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 local_58 [8];
  undefined1 local_50 [24];
  longlong *local_38;
  longlong *local_30;
  ulonglong uVar12;
  
  FUN_140036640(param_3);
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_58);
  uVar10 = 0;
  uVar12 = uVar10;
LAB_1405af190:
  do {
    do {
      uVar11 = (uint)uVar12;
      cVar4 = FUN_1400ce310(local_50);
      while( true ) {
        if (cVar4 == '\0') goto LAB_1405af3be;
        cVar4 = (**(code **)(*local_38 + 0x298))(local_38,0x1001,&local_30);
        if (cVar4 != '\0') break;
        cVar4 = FUN_1400ce310(local_50);
      }
      uVar11 = uVar11 + 1;
      uVar12 = (ulonglong)uVar11;
      if (1000000 < uVar11) {
        log_InlineLogERROR(&DAT_1406d9c10);
LAB_1405af3be:
        return uVar11 < 1000000;
      }
      if (local_30 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar5 = (**(code **)(local_30[2] + 0x170))(local_30 + 2);
    } while (iVar5 != param_2);
    if (local_30 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    local_res8[0] = (**(code **)(*local_30 + 8))();
    puVar1 = (undefined4 *)param_3[3];
    uVar8 = uVar10;
    if (puVar1 != (undefined4 *)0x0) {
      uVar8 = param_3[5] - (longlong)puVar1 >> 2;
    }
    puVar2 = (undefined4 *)param_3[4];
    if (uVar8 <= (ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2)) {
      if (puVar2 < puVar1) {
        _invalid_parameter_noinfo();
      }
      uVar8 = param_3[3];
      lVar6 = *param_3;
      uVar7 = uVar10;
      if ((param_3[4] - uVar8 & 0xfffffffffffffffc) != 0) {
        if ((ulonglong)param_3[4] < uVar8) {
          _invalid_parameter_noinfo();
        }
        if ((lVar6 == 0) || (lVar6 != *param_3)) {
          _invalid_parameter_noinfo();
        }
        uVar7 = (longlong)((longlong)puVar2 - uVar8) >> 2;
      }
      local_78 = (undefined4)lVar6;
      uStack_74 = (undefined4)((ulonglong)lVar6 >> 0x20);
      uStack_70 = SUB84(puVar2,0);
      uStack_6c = (undefined4)((ulonglong)puVar2 >> 0x20);
      local_68 = local_78;
      uStack_64 = uStack_74;
      uStack_60 = uStack_70;
      uStack_5c = uStack_6c;
      FUN_140036c20(param_3,&local_68,1,local_res8);
      uVar8 = param_3[3];
      if ((ulonglong)param_3[4] < uVar8) {
        _invalid_parameter_noinfo();
      }
      puVar3 = (ulonglong *)*param_3;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar9 = uVar10;
      }
      else {
        uVar9 = *puVar3;
      }
      uVar8 = uVar8 + uVar7 * 4;
      if (uVar8 <= *(ulonglong *)(uVar9 + 0x20)) break;
      goto LAB_1405af389;
    }
    *puVar2 = local_res8[0];
    param_3[4] = (longlong)(puVar2 + 1);
  } while( true );
  uVar7 = uVar10;
  if (puVar3 != (ulonglong *)0x0) {
    uVar7 = *puVar3;
  }
  if (uVar8 < *(ulonglong *)(uVar7 + 0x18)) {
LAB_1405af389:
    _invalid_parameter_noinfo();
  }
  goto LAB_1405af190;
}

// ==== CSyndicateActor@adapter::vfunc_10  @1405af3f0  [high:rtti-vtable]  (orig: FUN_1405af3f0)
void FUN_1405af3f0(longlong param_1,longlong *param_2,int param_3,char param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  uint uVar9;
  undefined4 local_res8 [2];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined1 local_58 [8];
  undefined1 local_50 [24];
  longlong *local_38;
  longlong *local_30;
  
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_58);
  uVar9 = 0;
LAB_1405af470:
  while( true ) {
    do {
      do {
        cVar4 = FUN_1400ce310(local_50);
        while( true ) {
          if (cVar4 == '\0') {
            return;
          }
          cVar4 = (**(code **)(*local_38 + 0x298))(local_38,0x1001,&local_30);
          if (cVar4 != '\0') break;
          cVar4 = FUN_1400ce310(local_50);
        }
        uVar9 = uVar9 + 1;
        if (100000 < uVar9) {
          log_InlineLogERROR(&DAT_1406d9c10);
          return;
        }
      } while ((local_30 == (longlong *)0x0) ||
              ((param_3 != 0 && (iVar5 = (**(code **)(*local_30 + 8))(), param_3 == iVar5))));
      if (local_30 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    } while (((char)local_30[0x259] != '\0') && (param_4 != '\0'));
    local_res8[0] = (**(code **)(*local_30 + 8))();
    puVar1 = (undefined4 *)param_2[3];
    if (puVar1 == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = param_2[5] - (longlong)puVar1 >> 2;
    }
    puVar2 = (undefined4 *)param_2[4];
    if (uVar7 <= (ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2)) break;
    *puVar2 = local_res8[0];
    param_2[4] = (longlong)(puVar2 + 1);
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  uVar7 = param_2[3];
  lVar6 = *param_2;
  if ((param_2[4] - uVar7 & 0xfffffffffffffffc) == 0) {
    lVar8 = 0;
  }
  else {
    if ((ulonglong)param_2[4] < uVar7) {
      _invalid_parameter_noinfo();
    }
    if ((lVar6 == 0) || (lVar6 != *param_2)) {
      _invalid_parameter_noinfo();
    }
    lVar8 = (longlong)((longlong)puVar2 - uVar7) >> 2;
  }
  local_78 = (undefined4)lVar6;
  uStack_74 = (undefined4)((ulonglong)lVar6 >> 0x20);
  uStack_70 = SUB84(puVar2,0);
  uStack_6c = (undefined4)((ulonglong)puVar2 >> 0x20);
  local_68 = local_78;
  uStack_64 = uStack_74;
  uStack_60 = uStack_70;
  uStack_5c = uStack_6c;
  FUN_140036c20(param_2,&local_68,1,local_res8);
  uVar7 = param_2[3];
  if ((ulonglong)param_2[4] < uVar7) {
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_2;
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar3;
  }
  uVar7 = uVar7 + lVar8 * 4;
  if (uVar7 <= *(ulonglong *)(lVar6 + 0x20)) goto code_r0x0001405af62c;
  goto LAB_1405af642;
code_r0x0001405af62c:
  if (plVar3 == (longlong *)0x0) {
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar3;
  }
  if (uVar7 < *(ulonglong *)(lVar6 + 0x18)) {
LAB_1405af642:
    _invalid_parameter_noinfo();
  }
  goto LAB_1405af470;
}

// ==== CSyndicateActor@adapter::vfunc_9  @1405af6a0  [high:rtti-vtable]  (orig: FUN_1405af6a0)
void FUN_1405af6a0(longlong param_1,longlong param_2,longlong *param_3)

{
  int iVar1;
  ulonglong *puVar2;
  int *piVar3;
  longlong *plVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  ulonglong uVar10;
  int *piVar11;
  ulonglong uVar12;
  uint uVar13;
  longlong *local_res10;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  if (param_2 != 0) {
    local_res10 = operator_new(8);
    plVar9 = (longlong *)0x0;
    local_68[0] = plVar9;
    if (local_res10 != (longlong *)0x0) {
      *local_res10 = (longlong)local_68;
      local_68[0] = local_res10;
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    piVar11 = (int *)param_3[3];
    if ((int *)param_3[4] < piVar11) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (ulonglong *)*param_3;
    while( true ) {
      uVar10 = 0;
      piVar3 = (int *)param_3[4];
      if (piVar3 < (int *)param_3[3]) {
        _invalid_parameter_noinfo();
      }
      if ((puVar2 == (ulonglong *)0x0) || (puVar2 != (ulonglong *)*param_3)) {
        _invalid_parameter_noinfo();
      }
      if (piVar11 == piVar3) goto LAB_1405af9ce;
      uVar13 = (int)plVar9 + 1;
      plVar9 = (longlong *)(ulonglong)uVar13;
      if (100000 < uVar13) break;
      if (puVar2 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar12 = uVar10;
      }
      else {
        uVar12 = *puVar2;
      }
      if (*(int **)(uVar12 + 0x20) <= piVar11) {
        _invalid_parameter_noinfo();
      }
      iVar1 = *piVar11;
      if (iVar1 != 0) {
        lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        if (*(longlong *)(lVar7 + 0x90) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar7 = (**(code **)(**(longlong **)(lVar7 + 0x90) + 0x98))
                          (*(longlong **)(lVar7 + 0x90),iVar1);
        puVar6 = local_48;
        if ((lVar7 != 0) &&
           (((*(char *)(lVar7 + 0x12c8) == '\0' || (*(int *)(param_2 + 8) == 0x3ec)) ||
            (*(int *)(param_2 + 8) == 0xa49)))) {
          local_res10 = (longlong *)CONCAT44(local_res10._4_4_,*(undefined4 *)(lVar7 + 0x122c));
          if (local_50 != (undefined4 *)0x0) {
            uVar10 = local_40 - (longlong)local_50 >> 2;
          }
          if ((ulonglong)((longlong)local_48 - (longlong)local_50 >> 2) < uVar10) {
            *local_48 = *(undefined4 *)(lVar7 + 0x122c);
            local_48 = local_48 + 1;
          }
          else {
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            puVar5 = local_50;
            plVar4 = local_68[0];
            if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) == 0) {
              lVar7 = 0;
            }
            else {
              if (local_48 < local_50) {
                _invalid_parameter_noinfo();
              }
              if ((plVar4 == (longlong *)0x0) || (plVar4 != local_68[0])) {
                _invalid_parameter_noinfo();
              }
              lVar7 = (longlong)puVar6 - (longlong)puVar5 >> 2;
            }
            local_88 = SUB84(plVar4,0);
            uStack_84 = (undefined4)((ulonglong)plVar4 >> 0x20);
            uStack_80 = SUB84(puVar6,0);
            uStack_7c = (undefined4)((ulonglong)puVar6 >> 0x20);
            local_78 = local_88;
            uStack_74 = uStack_84;
            uStack_70 = uStack_80;
            uStack_6c = uStack_7c;
            FUN_140036c20(local_68,&local_78,1,&local_res10);
            puVar6 = local_50;
            if (local_48 < local_50) {
              _invalid_parameter_noinfo();
            }
            plVar4 = local_68[0];
            if (local_68[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = 0;
            }
            else {
              lVar8 = *local_68[0];
            }
            if (puVar6 + lVar7 <= *(undefined4 **)(lVar8 + 0x20)) {
              if (plVar4 == (longlong *)0x0) {
                lVar8 = 0;
              }
              else {
                lVar8 = *plVar4;
              }
              if (*(undefined4 **)(lVar8 + 0x18) <= puVar6 + lVar7) goto LAB_1405af97b;
            }
            _invalid_parameter_noinfo();
          }
        }
      }
LAB_1405af97b:
      uVar10 = 0;
      if (puVar2 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        uVar10 = *puVar2;
      }
      if (*(int **)(uVar10 + 0x20) <= piVar11) {
        _invalid_parameter_noinfo();
      }
      piVar11 = piVar11 + 1;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
LAB_1405af9ce:
    plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar9 + 0x40))(plVar9,local_68,param_2);
    if (local_50 != (undefined4 *)0x0) {
      operator_delete(local_50);
    }
    local_50 = (undefined4 *)0x0;
    local_48 = (undefined4 *)0x0;
    local_40 = 0;
    operator_delete(local_68[0]);
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_158  @1405afa40  [high:rtti-vtable]  (orig: FUN_1405afa40)
undefined8 FUN_1405afa40(longlong param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  undefined8 *puVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  uint uVar13;
  longlong *local_res18;
  undefined8 *local_res20;
  uint uVar15;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  longlong *plVar14;
  
  if (param_3 == 0) {
    uVar6 = 0;
  }
  else {
    plVar10 = (longlong *)0x0;
    uVar15 = (uint)*(ushort *)(param_3 + 8);
    puVar5 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                           param_3 + 0xc,uVar15,0,0xfffffffffffffffe);
    local_res20 = puVar5;
    if (puVar5 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = 0;
    }
    else {
      local_res18 = operator_new(8);
      local_68[0] = plVar10;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_68;
        local_68[0] = local_res18;
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      plVar11 = *(longlong **)param_2[6];
      puVar2 = (undefined8 *)*param_2;
      plVar14 = plVar10;
      while( true ) {
        plVar7 = (longlong *)param_2[6];
        if ((puVar2 == (undefined8 *)0x0) || (puVar2 != (undefined8 *)*param_2)) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == plVar7) goto LAB_1405afdb5;
        uVar13 = (int)plVar14 + 1;
        plVar14 = (longlong *)(ulonglong)uVar13;
        if (10000 < uVar13) break;
        if (puVar2 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar10;
        }
        else {
          plVar7 = (longlong *)*puVar2;
        }
        if (plVar11 == (longlong *)plVar7[6]) {
          _invalid_parameter_noinfo();
        }
        lVar8 = plVar11[3];
        if ((int)lVar8 != 0) {
          uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
          plVar7 = (longlong *)FUN_140087650(uVar6);
          lVar8 = (**(code **)(*plVar7 + 0x98))(plVar7,(int)lVar8);
          puVar4 = local_48;
          if ((lVar8 != 0) &&
             (((*(char *)(lVar8 + 0x12c8) == '\0' || (*(int *)(puVar5 + 1) == 0x3ec)) ||
              (*(int *)(puVar5 + 1) == 0xa48)))) {
            local_res18 = (longlong *)CONCAT44(local_res18._4_4_,*(undefined4 *)(lVar8 + 0x122c));
            if ((local_50 == (undefined4 *)0x0) ||
               ((ulonglong)(local_40 - (longlong)local_50 >> 2) <=
                (ulonglong)((longlong)local_48 - (longlong)local_50 >> 2))) {
              if (local_48 < local_50) {
                _invalid_parameter_noinfo();
              }
              puVar3 = local_50;
              plVar7 = local_68[0];
              plVar12 = plVar10;
              if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) != 0) {
                if (local_48 < local_50) {
                  _invalid_parameter_noinfo();
                }
                if ((plVar7 == (longlong *)0x0) || (plVar7 != local_68[0])) {
                  _invalid_parameter_noinfo();
                }
                plVar12 = (longlong *)((longlong)puVar4 - (longlong)puVar3 >> 2);
              }
              local_88 = SUB84(plVar7,0);
              uStack_84 = (undefined4)((ulonglong)plVar7 >> 0x20);
              uStack_80 = SUB84(puVar4,0);
              uStack_7c = (undefined4)((ulonglong)puVar4 >> 0x20);
              local_78 = local_88;
              uStack_74 = uStack_84;
              uStack_70 = uStack_80;
              uStack_6c = uStack_7c;
              FUN_140036c20(local_68,&local_78,1,&local_res18);
              puVar4 = local_50;
              if (local_48 < local_50) {
                _invalid_parameter_noinfo();
              }
              plVar7 = local_68[0];
              if (local_68[0] == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar9 = plVar10;
              }
              else {
                plVar9 = (longlong *)*local_68[0];
              }
              if (puVar4 + (longlong)plVar12 <= (undefined4 *)plVar9[4]) {
                plVar9 = plVar10;
                if (plVar7 != (longlong *)0x0) {
                  plVar9 = (longlong *)*plVar7;
                }
                puVar5 = local_res20;
                if ((undefined4 *)plVar9[3] <= puVar4 + (longlong)plVar12) goto LAB_1405afd1b;
              }
              _invalid_parameter_noinfo();
              puVar5 = local_res20;
            }
            else {
              *local_48 = *(undefined4 *)(lVar8 + 0x122c);
              local_48 = local_48 + 1;
            }
          }
        }
LAB_1405afd1b:
        if (puVar2 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar11 + 0x1d) == '\0') {
          plVar7 = (longlong *)plVar11[2];
          if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
            cVar1 = *(char *)(*plVar7 + 0x1d);
            plVar11 = plVar7;
            plVar7 = (longlong *)*plVar7;
            while (cVar1 == '\0') {
              cVar1 = *(char *)(*plVar7 + 0x1d);
              plVar11 = plVar7;
              plVar7 = (longlong *)*plVar7;
            }
          }
          else {
            cVar1 = *(char *)(plVar11[1] + 0x1d);
            plVar12 = (longlong *)plVar11[1];
            plVar7 = plVar11;
            while ((plVar11 = plVar12, cVar1 == '\0' && (plVar7 == (longlong *)plVar11[2]))) {
              cVar1 = *(char *)(plVar11[1] + 0x1d);
              plVar12 = (longlong *)plVar11[1];
              plVar7 = plVar11;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      uVar15 = 0x50c;
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1405afdb5:
      plVar10 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar10 + 0x40))(plVar10,local_68,puVar5,*plVar10,uVar15);
      (**(code **)*puVar5)(puVar5,1);
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      uVar6 = 1;
    }
  }
  return uVar6;
}

// ==== CSyndicateActor@adapter::vfunc_180  @1405afe30  [high:rtti-vtable]  (orig: FUN_1405afe30)
bool FUN_1405afe30(longlong param_1,int param_2,longlong param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  uint uVar9;
  bool bVar10;
  longlong *local_res18;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined1 local_78 [8];
  undefined1 local_70 [24];
  longlong *local_58;
  longlong *local_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 local_38;
  
  local_38 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar10 = false;
  }
  else {
    local_res18 = operator_new(8);
    if (local_res18 == (longlong *)0x0) {
      local_b8[0] = (longlong *)0x0;
    }
    else {
      *local_res18 = (longlong)local_b8;
      local_b8[0] = local_res18;
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    uVar9 = 0;
    local_88 = local_res18;
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_78);
LAB_1405aff40:
    cVar3 = FUN_1400ce310(local_70);
    if (cVar3 != '\0') {
      while (cVar3 = (**(code **)(*local_58 + 0x298))(local_58,0x1001,&local_50), cVar3 == '\0') {
        cVar3 = FUN_1400ce310(local_70);
        if (cVar3 == '\0') goto LAB_1405b01be;
      }
      uVar9 = uVar9 + 1;
      if (1000000 < uVar9) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1405b01ca;
      }
      if ((local_50 != (longlong *)0x0) &&
         (iVar4 = (**(code **)(local_50[2] + 0x170))(), iVar4 == param_2)) {
        if (param_4 != 0) {
          if (local_50 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(*local_50 + 8))();
          if (param_4 == iVar4) goto LAB_1405aff40;
        }
        if (local_50 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        puVar2 = local_98;
        if (((char)local_50[0x259] == '\0') || (*(int *)(param_3 + 8) == 0x3ec)) {
          local_res18 = (longlong *)
                        CONCAT44(local_res18._4_4_,*(undefined4 *)((longlong)local_50 + 0x122c));
          if (local_a0 == (undefined4 *)0x0) {
            uVar8 = 0;
          }
          else {
            uVar8 = local_90 - (longlong)local_a0 >> 2;
          }
          if (uVar8 <= (ulonglong)((longlong)local_98 - (longlong)local_a0 >> 2)) {
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            puVar1 = local_a0;
            plVar7 = local_b8[0];
            local_88 = local_b8[0];
            uStack_80 = puVar2;
            if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) == 0) {
              lVar5 = 0;
            }
            else {
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar7 == (longlong *)0x0) || (plVar7 != local_b8[0])) {
                _invalid_parameter_noinfo();
              }
              lVar5 = (longlong)puVar2 - (longlong)puVar1 >> 2;
            }
            local_48 = (undefined4)local_88;
            uStack_44 = local_88._4_4_;
            uStack_40 = (undefined4)uStack_80;
            uStack_3c = uStack_80._4_4_;
            FUN_140036c20(local_b8,&local_48,1,&local_res18);
            puVar2 = local_a0;
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            plVar7 = local_b8[0];
            if (local_b8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *local_b8[0];
            }
            if (puVar2 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
              if (plVar7 == (longlong *)0x0) {
                lVar6 = 0;
              }
              else {
                lVar6 = *plVar7;
              }
              if (*(undefined4 **)(lVar6 + 0x18) <= puVar2 + lVar5) goto LAB_1405aff40;
            }
            _invalid_parameter_noinfo();
            goto LAB_1405aff40;
          }
          *local_98 = *(undefined4 *)((longlong)local_50 + 0x122c);
          local_98 = local_98 + 1;
        }
      }
      goto LAB_1405aff40;
    }
LAB_1405b01be:
    local_50 = (longlong *)0x0;
LAB_1405b01ca:
    plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar7 + 0x40))(plVar7,local_b8,param_3);
    bVar10 = uVar9 < 1000000;
    if (local_a0 != (undefined4 *)0x0) {
      operator_delete(local_a0);
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    operator_delete(local_b8[0]);
  }
  return bVar10;
}

// ==== CSyndicateActor@adapter::vfunc_181  @1405b0250  [high:rtti-vtable]  (orig: FUN_1405b0250)
bool FUN_1405b0250(longlong param_1,int param_2,longlong param_3,int param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  uint uVar9;
  bool bVar10;
  longlong *local_res18;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined1 local_78 [8];
  undefined1 local_70 [24];
  longlong *local_58;
  longlong *local_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined8 local_38;
  
  local_38 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar10 = false;
  }
  else {
    local_res18 = operator_new(8);
    if (local_res18 == (longlong *)0x0) {
      local_b8[0] = (longlong *)0x0;
    }
    else {
      *local_res18 = (longlong)local_b8;
      local_b8[0] = local_res18;
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    uVar9 = 0;
    local_88 = local_res18;
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_78);
LAB_1405b0360:
    cVar3 = FUN_1400ce310(local_70);
    if (cVar3 != '\0') {
      while (cVar3 = (**(code **)(*local_58 + 0x298))(local_58,0x1001,&local_50), cVar3 == '\0') {
        cVar3 = FUN_1400ce310(local_70);
        if (cVar3 == '\0') goto LAB_1405b05e0;
      }
      uVar9 = uVar9 + 1;
      if (1000000 < uVar9) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1405b05ec;
      }
      if ((local_50 != (longlong *)0x0) && (iVar4 = FUN_1401657c0(), iVar4 == param_2)) {
        if (param_4 != 0) {
          if (local_50 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(*local_50 + 8))();
          if (param_4 == iVar4) goto LAB_1405b0360;
        }
        if (local_50 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        puVar2 = local_98;
        if ((((char)local_50[0x259] == '\0') || (*(int *)(param_3 + 8) == 0x3ec)) ||
           (*(int *)(param_3 + 8) == 0xc1c)) {
          local_res18 = (longlong *)
                        CONCAT44(local_res18._4_4_,*(undefined4 *)((longlong)local_50 + 0x122c));
          if (local_a0 == (undefined4 *)0x0) {
            uVar8 = 0;
          }
          else {
            uVar8 = local_90 - (longlong)local_a0 >> 2;
          }
          if (uVar8 <= (ulonglong)((longlong)local_98 - (longlong)local_a0 >> 2)) {
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            puVar1 = local_a0;
            plVar7 = local_b8[0];
            local_88 = local_b8[0];
            uStack_80 = puVar2;
            if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) == 0) {
              lVar5 = 0;
            }
            else {
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar7 == (longlong *)0x0) || (plVar7 != local_b8[0])) {
                _invalid_parameter_noinfo();
              }
              lVar5 = (longlong)puVar2 - (longlong)puVar1 >> 2;
            }
            local_48 = (undefined4)local_88;
            uStack_44 = local_88._4_4_;
            uStack_40 = (undefined4)uStack_80;
            uStack_3c = uStack_80._4_4_;
            FUN_140036c20(local_b8,&local_48,1,&local_res18);
            puVar2 = local_a0;
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            plVar7 = local_b8[0];
            if (local_b8[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *local_b8[0];
            }
            if (puVar2 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
              if (plVar7 == (longlong *)0x0) {
                lVar6 = 0;
              }
              else {
                lVar6 = *plVar7;
              }
              if (*(undefined4 **)(lVar6 + 0x18) <= puVar2 + lVar5) goto LAB_1405b0360;
            }
            _invalid_parameter_noinfo();
            goto LAB_1405b0360;
          }
          *local_98 = *(undefined4 *)((longlong)local_50 + 0x122c);
          local_98 = local_98 + 1;
        }
      }
      goto LAB_1405b0360;
    }
LAB_1405b05e0:
    local_50 = (longlong *)0x0;
LAB_1405b05ec:
    plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar7 + 0x40))(plVar7,local_b8,param_3);
    bVar10 = uVar9 < 1000000;
    if (local_a0 != (undefined4 *)0x0) {
      operator_delete(local_a0);
    }
    local_a0 = (undefined4 *)0x0;
    local_98 = (undefined4 *)0x0;
    local_90 = 0;
    operator_delete(local_b8[0]);
  }
  return bVar10;
}

// ==== CSyndicateActor@adapter::vfunc_168  @1405b0670  [high:rtti-vtable]  (orig: FUN_1405b0670)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1405b0670(longlong param_1,int param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint uVar10;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 auStack_538 [32];
  undefined4 local_518;
  longlong *local_508 [3];
  undefined4 *local_4f0;
  undefined4 *local_4e8;
  longlong local_4e0;
  longlong *local_4d8 [2];
  undefined8 local_4c8;
  undefined8 uStack_4c0;
  undefined1 local_4b8 [8];
  undefined1 local_4b0 [24];
  longlong *local_498;
  longlong *local_490;
  undefined4 local_488;
  undefined4 uStack_484;
  undefined4 uStack_480;
  undefined4 uStack_47c;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  longlong *plVar11;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  plVar6 = (longlong *)FUN_140087ed0();
  if (plVar6 != (longlong *)0x0) {
    local_4d8[0] = operator_new(8);
    plVar13 = (longlong *)0x0;
    local_508[0] = plVar13;
    if (local_4d8[0] != (longlong *)0x0) {
      *local_4d8[0] = (longlong)local_508;
      local_508[0] = local_4d8[0];
    }
    local_4f0 = (undefined4 *)0x0;
    local_4e8 = (undefined4 *)0x0;
    local_4e0 = 0;
    local_4c8 = local_4d8[0];
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar7 + 0x90) == 0) {
      local_518 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar7 + 0x90),local_4b8);
    plVar11 = plVar13;
LAB_1405b0760:
    cVar3 = FUN_1400ce310(local_4b0);
    if (cVar3 != '\0') {
      while (cVar3 = (**(code **)(*local_498 + 0x298))(local_498,0x1001,&local_490), cVar3 == '\0')
      {
        cVar3 = FUN_1400ce310(local_4b0);
        if (cVar3 == '\0') goto LAB_1405b09cb;
      }
      uVar10 = (int)plVar11 + 1;
      plVar11 = (longlong *)(ulonglong)uVar10;
      if (1000000 < uVar10) {
        local_518 = 0x95d;
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1405b09d3;
      }
      if ((local_490 != (longlong *)0x0) && (iVar5 = FUN_1401657c0(), iVar5 == param_2)) {
        if (local_490 == (longlong *)0x0) {
          local_518 = 0x2b;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar7 = *plVar6;
        uVar4 = (**(code **)(*local_490 + 8))();
        cVar3 = (**(code **)(lVar7 + 0x600))(plVar6,uVar4);
        if (cVar3 != '\0') {
          if (local_490 == (longlong *)0x0) {
            local_518 = 0x2b;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          puVar2 = local_4e8;
          local_4d8[0] = (longlong *)
                         CONCAT44(local_4d8[0]._4_4_,*(undefined4 *)((longlong)local_490 + 0x122c));
          plVar9 = plVar13;
          if (local_4f0 != (undefined4 *)0x0) {
            plVar9 = (longlong *)(local_4e0 - (longlong)local_4f0 >> 2);
          }
          if (plVar9 <= (longlong *)((longlong)local_4e8 - (longlong)local_4f0 >> 2)) {
            if (local_4e8 < local_4f0) {
              _invalid_parameter_noinfo();
            }
            puVar1 = local_4f0;
            plVar9 = local_508[0];
            local_4c8 = local_508[0];
            uStack_4c0 = puVar2;
            plVar12 = plVar13;
            if (((longlong)local_4e8 - (longlong)local_4f0 & 0xfffffffffffffffcU) != 0) {
              if (local_4e8 < local_4f0) {
                _invalid_parameter_noinfo();
              }
              if ((plVar9 == (longlong *)0x0) || (plVar9 != local_508[0])) {
                _invalid_parameter_noinfo();
              }
              plVar12 = (longlong *)((longlong)puVar2 - (longlong)puVar1 >> 2);
            }
            local_488 = (undefined4)local_4c8;
            uStack_484 = local_4c8._4_4_;
            uStack_480 = (undefined4)uStack_4c0;
            uStack_47c = uStack_4c0._4_4_;
            FUN_140036c20(local_508,&local_488,1,local_4d8);
            puVar2 = local_4f0;
            if (local_4e8 < local_4f0) {
              _invalid_parameter_noinfo();
            }
            plVar9 = local_508[0];
            if (local_508[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar8 = plVar13;
            }
            else {
              plVar8 = (longlong *)*local_508[0];
            }
            if (puVar2 + (longlong)plVar12 <= (undefined4 *)plVar8[4]) {
              plVar8 = plVar13;
              if (plVar9 != (longlong *)0x0) {
                plVar8 = (longlong *)*plVar9;
              }
              if ((undefined4 *)plVar8[3] <= puVar2 + (longlong)plVar12) goto LAB_1405b0760;
            }
            _invalid_parameter_noinfo();
            goto LAB_1405b0760;
          }
          *local_4e8 = *(undefined4 *)((longlong)local_490 + 0x122c);
          local_4e8 = local_4e8 + 1;
        }
      }
      goto LAB_1405b0760;
    }
LAB_1405b09cb:
    local_490 = (longlong *)0x0;
LAB_1405b09d3:
    if (((longlong)local_4e8 - (longlong)local_4f0 & 0xfffffffffffffffcU) == 0) {
      if (local_4f0 != (undefined4 *)0x0) {
        operator_delete(local_4f0);
      }
      local_4f0 = (undefined4 *)0x0;
      local_4e8 = (undefined4 *)0x0;
      local_4e0 = 0;
      operator_delete(local_508[0]);
    }
    else {
      FUN_14039e680(local_468);
      iVar5 = FUN_14039e700(local_468,0,0x56,1);
      if (iVar5 != 0) {
        plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        (**(code **)(*plVar6 + 0x40))(plVar6,local_508,local_468);
      }
      FUN_14039e6d0(local_468);
      if (local_4f0 != (undefined4 *)0x0) {
        operator_delete(local_4f0);
      }
      local_4f0 = (undefined4 *)0x0;
      local_4e8 = (undefined4 *)0x0;
      local_4e0 = 0;
      operator_delete(local_508[0]);
    }
  }
  return;
}

// ==== CSyndicateActor@adapter::vfunc_175  @1405b0ad0  [high:rtti-vtable]  (orig: FUN_1405b0ad0)
/* WARNING: Removing unreachable block (ram,0x0001405b0b84) */
/* WARNING: Removing unreachable block (ram,0x0001405b0b4c) */
/* WARNING: Removing unreachable block (ram,0x0001405b0b6c) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bb9) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bbe) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bc9) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bce) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bd3) */
/* WARNING: Removing unreachable block (ram,0x0001405b0bd9) */

undefined8 FUN_1405b0ad0(longlong param_1,int param_2)

{
  longlong *plVar1;
  void *pvVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong lVar5;
  longlong *plVar6;
  int local_res10 [2];
  longlong *local_res18;
  longlong *local_res20;
  uint in_stack_ffffffffffffff48;
  longlong *local_98;
  undefined8 uStack_90;
  longlong *local_88 [3];
  void *local_70;
  void *local_68;
  undefined8 local_60;
  undefined1 local_58 [48];
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  local_res18 = operator_new(8);
  plVar3 = (longlong *)0x0;
  local_98 = plVar3;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)local_88;
    local_98 = local_res18;
  }
  local_60 = 0;
  local_68 = (void *)0x0;
  local_70 = (void *)0x0;
  uStack_90 = 0;
  local_res20 = local_res18;
  local_88[0] = local_98;
  FUN_140036c20(local_88,&local_98,1,local_res10);
  pvVar2 = local_70;
  if (local_68 < local_70) {
    _invalid_parameter_noinfo();
  }
  plVar1 = local_88[0];
  if (local_88[0] == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar6 = plVar3;
  }
  else {
    plVar6 = (longlong *)*local_88[0];
  }
  if (pvVar2 <= (void *)plVar6[4]) {
    if (plVar1 != (longlong *)0x0) {
      plVar3 = (longlong *)*plVar1;
    }
    if ((void *)plVar3[3] <= pvVar2) goto LAB_1405b0c55;
  }
  _invalid_parameter_noinfo();
LAB_1405b0c55:
  local_res18 = (longlong *)local_58;
  uVar4 = FUN_140043260(local_58,local_88);
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    in_stack_ffffffffffffff48 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402b3560(*(undefined8 *)(lVar5 + 0x90),uVar4,0xd,1,in_stack_ffffffffffffff48 & 0xffffff00,1);
  if (local_70 != (void *)0x0) {
    operator_delete(local_70);
  }
  local_70 = (void *)0x0;
  local_68 = (void *)0x0;
  local_60 = 0;
  operator_delete(local_88[0]);
  return 1;
}

// ==== CSyndicateActor@adapter::vfunc_22  @1405b0d20  [high:rtti-vtable]  (orig: FUN_1405b0d20)
bool FUN_1405b0d20(longlong param_1,int param_2,longlong param_3,int param_4,char param_5)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  uint uVar9;
  bool bVar10;
  longlong *local_res18 [2];
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  undefined1 local_98 [8];
  undefined1 local_90 [24];
  longlong *local_78;
  longlong *local_70;
  undefined8 local_68;
  undefined8 uStack_60;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    bVar10 = false;
  }
  else {
    local_res18[0] = operator_new(8);
    if (local_res18[0] == (longlong *)0x0) {
      local_c8[0] = (longlong *)0x0;
    }
    else {
      *local_res18[0] = (longlong)local_c8;
      local_c8[0] = local_res18[0];
    }
    local_b0 = (undefined4 *)0x0;
    local_a8 = (undefined4 *)0x0;
    local_a0 = 0;
    uVar9 = 0;
    local_68 = local_res18[0];
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_98);
LAB_1405b0e32:
    cVar3 = FUN_1400ce310(local_90);
    if (cVar3 != '\0') {
      while (cVar3 = (**(code **)(*local_78 + 0x298))(local_78,0x1001,&local_70), cVar3 == '\0') {
        cVar3 = FUN_1400ce310(local_90);
        if (cVar3 == '\0') goto LAB_1405b10ed;
      }
      uVar9 = uVar9 + 1;
      if (1000000 < uVar9) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1405b10f9;
      }
      if ((local_70 != (longlong *)0x0) && (iVar4 = FUN_1401657c0(), iVar4 == param_2)) {
        if (param_4 != 0) {
          if (local_70 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = (**(code **)(*local_70 + 8))();
          if (param_4 == iVar4) goto LAB_1405b0e32;
        }
        if (param_5 == '\0') {
          if (local_70 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          if ((char)local_70[0x259] != '\0') goto LAB_1405b0e32;
        }
        if (local_70 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        puVar2 = local_a8;
        local_res18[0] =
             (longlong *)CONCAT44(local_res18[0]._4_4_,*(undefined4 *)((longlong)local_70 + 0x122c))
        ;
        if (local_b0 == (undefined4 *)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = local_a0 - (longlong)local_b0 >> 2;
        }
        if (uVar8 <= (ulonglong)((longlong)local_a8 - (longlong)local_b0 >> 2)) {
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          puVar1 = local_b0;
          plVar7 = local_c8[0];
          local_68 = local_c8[0];
          uStack_60 = puVar2;
          if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) == 0) {
            lVar5 = 0;
          }
          else {
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar7 == (longlong *)0x0) || (plVar7 != local_c8[0])) {
              _invalid_parameter_noinfo();
            }
            lVar5 = (longlong)puVar2 - (longlong)puVar1 >> 2;
          }
          local_58 = (undefined4)local_68;
          uStack_54 = local_68._4_4_;
          uStack_50 = (undefined4)uStack_60;
          uStack_4c = uStack_60._4_4_;
          FUN_140036c20(local_c8,&local_58,1,local_res18);
          puVar2 = local_b0;
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          plVar7 = local_c8[0];
          if (local_c8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *local_c8[0];
          }
          if (puVar2 + lVar5 <= *(undefined4 **)(lVar6 + 0x20)) {
            if (plVar7 == (longlong *)0x0) {
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar7;
            }
            if (*(undefined4 **)(lVar6 + 0x18) <= puVar2 + lVar5) goto LAB_1405b0e32;
          }
          _invalid_parameter_noinfo();
          goto LAB_1405b0e32;
        }
        *local_a8 = *(undefined4 *)((longlong)local_70 + 0x122c);
        local_a8 = local_a8 + 1;
      }
      goto LAB_1405b0e32;
    }
LAB_1405b10ed:
    local_70 = (longlong *)0x0;
LAB_1405b10f9:
    plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar7 + 0x40))(plVar7,local_c8,param_3);
    bVar10 = uVar9 < 1000000;
    if (local_b0 != (undefined4 *)0x0) {
      operator_delete(local_b0);
    }
    local_b0 = (undefined4 *)0x0;
    local_a8 = (undefined4 *)0x0;
    local_a0 = 0;
    operator_delete(local_c8[0]);
  }
  return bVar10;
}

// ==== CSyndicateActor@adapter::vfunc_165  @1405b1180  [high:rtti-vtable]  (orig: FUN_1405b1180)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_1405b1180(longlong param_1,int param_2,char param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint uVar10;
  longlong *plVar12;
  undefined1 auStack_568 [32];
  undefined4 local_548;
  longlong *local_538 [3];
  undefined4 *local_520;
  undefined4 *local_518;
  longlong local_510;
  longlong *local_508;
  undefined1 local_500 [8];
  undefined1 local_4f8 [24];
  longlong *local_4e0;
  longlong local_4d8 [2];
  undefined8 local_4c8;
  undefined8 uStack_4c0;
  undefined4 local_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  longlong *plVar11;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  cVar3 = FUN_14008b330(uVar5);
  if (cVar3 != '\0') {
    return true;
  }
  local_508 = operator_new(8);
  plVar8 = (longlong *)0x0;
  local_538[0] = plVar8;
  if (local_508 != (longlong *)0x0) {
    *local_508 = (longlong)local_538;
    local_538[0] = local_508;
  }
  local_520 = (undefined4 *)0x0;
  local_518 = (undefined4 *)0x0;
  local_510 = 0;
  local_4c8 = local_508;
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    local_548 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_500);
  plVar11 = plVar8;
LAB_1405b1271:
  do {
    do {
      uVar10 = (uint)plVar11;
      cVar3 = FUN_1400ce310(local_4f8);
      while( true ) {
        if (cVar3 == '\0') {
          local_4d8[0] = 0;
          goto LAB_1405b15d0;
        }
        cVar3 = (**(code **)(*local_4e0 + 0x298))(local_4e0,0x1001,local_4d8);
        if (cVar3 != '\0') break;
        cVar3 = FUN_1400ce310(local_4f8);
      }
      uVar10 = uVar10 + 1;
      plVar11 = (longlong *)(ulonglong)uVar10;
      if (1000000 < uVar10) {
        local_548 = 0xc95;
        log_InlineLogERROR(&DAT_1406d9c10);
LAB_1405b15d0:
        FUN_140362560(local_498);
        cVar3 = FUN_140362910(local_498,0x60,0,(longlong)param_2);
        if (cVar3 == '\0') {
          FUN_1403625e0(local_498);
          if (local_520 != (undefined4 *)0x0) {
            operator_delete(local_520);
          }
          local_520 = (undefined4 *)0x0;
          local_518 = (undefined4 *)0x0;
          local_510 = 0;
          operator_delete(local_538[0]);
          return false;
        }
        if (param_3 == '\0') {
          plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
          (**(code **)(*plVar8 + 0x40))(plVar8,local_538,local_498);
        }
        else {
          plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
          (**(code **)(*plVar8 + 0x48))(plVar8,local_538,local_498);
        }
        FUN_1403625e0(local_498);
        if (local_520 != (undefined4 *)0x0) {
          operator_delete(local_520);
        }
        local_520 = (undefined4 *)0x0;
        local_518 = (undefined4 *)0x0;
        local_510 = 0;
        operator_delete(local_538[0]);
        return uVar10 < 1000000;
      }
    } while (local_4d8[0] == 0);
    if (param_3 == '\0') goto LAB_1405b12ec;
    cVar3 = FUN_140167b70();
  } while (cVar3 == '\0');
  goto LAB_1405b1345;
LAB_1405b12ec:
  cVar3 = FUN_140167b70();
  if (cVar3 == '\0') {
    if (local_4d8[0] == 0) {
      local_548 = 0x2b;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    if (*(char *)(local_4d8[0] + 0x12c8) == '\0') {
LAB_1405b1345:
      if (local_4d8[0] == 0) {
        local_548 = 0x2b;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = FUN_140161f90(local_4d8[0]);
      if (param_2 != iVar4) {
        if (param_3 == '\0') {
          if (local_4d8[0] == 0) {
            local_548 = 0x2b;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar4 = FUN_140161f90(local_4d8[0]);
          if (iVar4 != 9) goto LAB_1405b1271;
        }
        if (local_4d8[0] == 0) {
          local_548 = 0x2b;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        FUN_140161fa0(local_4d8[0],param_2);
        if (local_4d8[0] == 0) {
          local_548 = 0x2b;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        puVar2 = local_518;
        local_508 = (longlong *)CONCAT44(local_508._4_4_,*(undefined4 *)(local_4d8[0] + 0x122c));
        plVar9 = plVar8;
        if (local_520 != (undefined4 *)0x0) {
          plVar9 = (longlong *)(local_510 - (longlong)local_520 >> 2);
        }
        if (plVar9 <= (longlong *)((longlong)local_518 - (longlong)local_520 >> 2)) {
          if (local_518 < local_520) {
            _invalid_parameter_noinfo();
          }
          puVar1 = local_520;
          plVar9 = local_538[0];
          local_4c8 = local_538[0];
          uStack_4c0 = puVar2;
          plVar12 = plVar8;
          if (((longlong)local_518 - (longlong)local_520 & 0xfffffffffffffffcU) != 0) {
            if (local_518 < local_520) {
              _invalid_parameter_noinfo();
            }
            if ((plVar9 == (longlong *)0x0) || (plVar9 != local_538[0])) {
              _invalid_parameter_noinfo();
            }
            plVar12 = (longlong *)((longlong)puVar2 - (longlong)puVar1 >> 2);
          }
          local_4b8 = (undefined4)local_4c8;
          uStack_4b4 = local_4c8._4_4_;
          uStack_4b0 = (undefined4)uStack_4c0;
          uStack_4ac = uStack_4c0._4_4_;
          FUN_140036c20(local_538,&local_4b8,1,&local_508);
          puVar2 = local_520;
          if (local_518 < local_520) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_538[0];
          if (local_538[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar7 = plVar8;
          }
          else {
            plVar7 = (longlong *)*local_538[0];
          }
          if (puVar2 + (longlong)plVar12 <= (undefined4 *)plVar7[4]) {
            plVar7 = plVar8;
            if (plVar9 != (longlong *)0x0) {
              plVar7 = (longlong *)*plVar9;
            }
            if ((undefined4 *)plVar7[3] <= puVar2 + (longlong)plVar12) goto LAB_1405b1271;
          }
          _invalid_parameter_noinfo();
          goto LAB_1405b1271;
        }
        *local_518 = *(undefined4 *)(local_4d8[0] + 0x122c);
        local_518 = local_518 + 1;
      }
    }
  }
  goto LAB_1405b1271;
}

// ==== CSyndicateActor@adapter::vfunc_166  @1405b16f0  [high:rtti-vtable]  (orig: FUN_1405b16f0)
BADSPACEBASE * FUN_1405b16f0(longlong *param_1,int param_2,longlong param_3)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined8 *puVar5;
  char cVar6;
  int iVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  uint uVar13;
  longlong *local_res20;
  uint uVar15;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined1 local_88 [8];
  undefined1 local_80 [24];
  longlong *local_68;
  longlong *local_60;
  undefined8 local_58;
  undefined8 uStack_50;
  undefined8 *local_48;
  undefined8 local_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  longlong *plVar14;
  
  local_40 = 0xfffffffffffffffe;
  if ((param_2 != 0) && (param_3 != 0)) {
    plVar11 = (longlong *)0x0;
    uVar15 = (uint)*(ushort *)(param_3 + 8);
    local_48 = (undefined8 *)
               FUN_1402ba310((int)param_1[3],0,*(undefined2 *)(param_3 + 10),param_3 + 0xc,uVar15,0)
    ;
    if (local_48 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      register0x00000020 = (BADSPACEBASE *)0x0;
    }
    else {
      local_res20 = operator_new(8);
      local_b8[0] = plVar11;
      if (local_res20 != (longlong *)0x0) {
        *local_res20 = (longlong)local_b8;
        local_b8[0] = local_res20;
      }
      local_a0 = (undefined4 *)0x0;
      local_98 = (undefined4 *)0x0;
      local_90 = 0;
      local_58 = local_res20;
      uVar9 = FUN_140008520((int)param_1[3]);
      uVar9 = FUN_140087650(uVar9);
      FUN_1402ac340(uVar9,local_88);
      plVar14 = plVar11;
LAB_1405b1800:
      uVar13 = (uint)plVar14;
      cVar6 = FUN_1400ce310(local_80);
      if (cVar6 != '\0') {
        while (cVar6 = (**(code **)(*local_68 + 0x298))(local_68,0x1001,&local_60), cVar6 == '\0') {
          cVar6 = FUN_1400ce310(local_80);
          if (cVar6 == '\0') goto LAB_1405b1acd;
        }
        uVar13 = uVar13 + 1;
        plVar14 = (longlong *)(ulonglong)uVar13;
        if (1000000 < uVar13) {
          uVar15 = 0xce9;
          log_InlineLogERROR(&DAT_1406d9c10);
          goto LAB_1405b1ad5;
        }
        if ((local_60 != (longlong *)0x0) && (cVar6 = FUN_140167b70(), cVar6 == '\0')) {
          if (local_60 == (longlong *)0x0) {
            uVar15 = 0x2b;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          iVar7 = FUN_1401657c0(local_60);
          if (iVar7 == param_2) {
            if (local_60 == (longlong *)0x0) {
              uVar15 = 0x2b;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            if ((char)local_60[0x259] == '\0') {
              lVar1 = *param_1;
              uVar8 = (**(code **)(*local_60 + 8))();
              cVar6 = (**(code **)(lVar1 + 0x4d0))(param_1,uVar8);
              if (cVar6 == '\0') goto LAB_1405b1800;
            }
            if (local_60 == (longlong *)0x0) {
              uVar15 = 0x2b;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            puVar4 = local_98;
            local_res20 = (longlong *)
                          CONCAT44(local_res20._4_4_,*(undefined4 *)((longlong)local_60 + 0x122c));
            if ((local_a0 == (undefined4 *)0x0) ||
               ((ulonglong)(local_90 - (longlong)local_a0 >> 2) <=
                (ulonglong)((longlong)local_98 - (longlong)local_a0 >> 2))) {
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              puVar3 = local_a0;
              plVar2 = local_b8[0];
              local_58 = local_b8[0];
              uStack_50 = puVar4;
              plVar12 = plVar11;
              if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) != 0) {
                if (local_98 < local_a0) {
                  _invalid_parameter_noinfo();
                }
                if ((plVar2 == (longlong *)0x0) || (plVar2 != local_b8[0])) {
                  _invalid_parameter_noinfo();
                }
                plVar12 = (longlong *)((longlong)puVar4 - (longlong)puVar3 >> 2);
              }
              local_38 = (undefined4)local_58;
              uStack_34 = local_58._4_4_;
              uStack_30 = (undefined4)uStack_50;
              uStack_2c = uStack_50._4_4_;
              FUN_140036c20(local_b8,&local_38,1,&local_res20,uVar15);
              puVar4 = local_a0;
              if (local_98 < local_a0) {
                _invalid_parameter_noinfo();
              }
              plVar2 = local_b8[0];
              if (local_b8[0] == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar10 = plVar11;
              }
              else {
                plVar10 = (longlong *)*local_b8[0];
              }
              if (puVar4 + (longlong)plVar12 <= (undefined4 *)plVar10[4]) {
                plVar10 = plVar11;
                if (plVar2 != (longlong *)0x0) {
                  plVar10 = (longlong *)*plVar2;
                }
                if ((undefined4 *)plVar10[3] <= puVar4 + (longlong)plVar12) goto LAB_1405b1800;
              }
              _invalid_parameter_noinfo();
              goto LAB_1405b1800;
            }
            *local_98 = *(undefined4 *)((longlong)local_60 + 0x122c);
            local_98 = local_98 + 1;
          }
        }
        goto LAB_1405b1800;
      }
LAB_1405b1acd:
      local_60 = (longlong *)0x0;
LAB_1405b1ad5:
      plVar11 = (longlong *)FUN_140008520((int)param_1[3]);
      puVar5 = local_48;
      (**(code **)(*plVar11 + 0x40))(plVar11,local_b8,local_48,*plVar11,uVar15);
      (**(code **)*puVar5)(puVar5,1);
      if (local_a0 != (undefined4 *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (undefined4 *)0x0;
      local_98 = (undefined4 *)0x0;
      local_90 = 0;
      operator_delete(local_b8[0]);
      register0x00000020 = (BADSPACEBASE *)(ulonglong)(uVar13 < 1000000);
    }
  }
  return register0x00000020;
}

