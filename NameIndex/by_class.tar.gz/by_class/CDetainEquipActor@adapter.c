// ==== CDetainEquipActor@adapter::vfunc_1  @14059ff60  [high:rtti-vtable]  (orig: FUN_14059ff60)
void FUN_14059ff60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_0  @14059ffd0  [high:rtti-vtable]  (orig: FUN_14059ffd0)
void FUN_14059ffd0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a0029. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xa0))(plVar1,param_2,param_3);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_1  @1405a0030  [high:rtti-vtable]  (orig: FUN_1405a0030)
void FUN_1405a0030(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a007a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xf8))(plVar1,param_2);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_2  @1405a0090  [high:rtti-vtable]  (orig: FUN_1405a0090)
void FUN_1405a0090(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a00da. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x118))(plVar1,param_2);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_3  @1405a00f0  [high:rtti-vtable]  (orig: FUN_1405a00f0)
void FUN_1405a00f0(undefined8 param_1,undefined4 param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)0x0;
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = plVar2;
  }
  (**(code **)(*plVar1 + 0x180))(plVar1,param_2);
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = plVar2;
  }
  (**(code **)(*plVar1 + 0x160))(plVar1,param_2);
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = plVar2;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a01d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x120))(plVar1,param_2);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_4  @1405a01e0  [high:rtti-vtable]  (orig: FUN_1405a01e0)
ulonglong FUN_1405a01e0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1400ffbe0(lVar1);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_5  @1405a0270  [high:rtti-vtable]  (orig: FUN_1405a0270)
ulonglong FUN_1405a0270(undefined8 param_1,undefined4 param_2)

{
  uint uVar1;
  longlong lVar2;
  ulonglong extraout_RAX;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar1 = FUN_1400fda10(lVar2,0x6e,1);
  return (ulonglong)(~uVar1 & 1);
}

// ==== CDetainEquipActor@adapter::vfunc_6  @1405a0310  [high:rtti-vtable]  (orig: FUN_1405a0310)
bool FUN_1405a0310(undefined8 param_1,undefined4 param_2)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar1 = FUN_1400fda10(lVar2,0x17,1);
  return iVar1 != 0;
}

// ==== CDetainEquipActor@adapter::vfunc_7  @1405a03c0  [high:rtti-vtable]  (orig: FUN_1405a03c0)
void FUN_1405a03c0(undefined8 param_1,undefined4 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a041b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x38))(plVar1,param_2,param_4);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_8  @1405a0420  [high:rtti-vtable]  (orig: FUN_1405a0420)
ulonglong FUN_1405a0420(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1400ff650(lVar1,param_3);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_9  @1405a04c0  [high:rtti-vtable]  (orig: FUN_1405a04c0)
undefined8 FUN_1405a04c0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x68))(plVar2,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_140104960(lVar1,0,3);
  return 1;
}

// ==== CDetainEquipActor@adapter::vfunc_10  @1405a0560  [high:rtti-vtable]  (orig: FUN_1405a0560)
void FUN_1405a0560(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a05b9. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x28))(plVar1,param_2,param_3);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_11  @1405a05c0  [high:rtti-vtable]  (orig: FUN_1405a05c0)
ulonglong FUN_1405a05c0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140101cb0(lVar1,param_3);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_12  @1405a0660  [high:rtti-vtable]  (orig: FUN_1405a0660)
undefined8 FUN_1405a0660(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_1400fda10(lVar1,param_3,1);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_13  @1405a0710  [high:rtti-vtable]  (orig: FUN_1405a0710)
undefined8
FUN_1405a0710(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined1 param_5)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_140104140(lVar1,param_3,param_4,param_5);
  return 1;
}

// ==== CDetainEquipActor@adapter::vfunc_14  @1405a07d0  [high:rtti-vtable]  (orig: FUN_1405a07d0)
undefined1 * FUN_1405a07d0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined1 *puVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  puVar2 = (undefined1 *)FUN_140100430(lVar1,0x65);
  return puVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_16  @1405a0870  [high:rtti-vtable]  (orig: FUN_1405a0870)
undefined1 * FUN_1405a0870(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  undefined1 *puVar3;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x70))(plVar2,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
  plVar2 = (longlong *)(**(code **)(**(longlong **)(lVar1 + 8) + 0x10))(*(longlong **)(lVar1 + 8),1)
  ;
                    /* WARNING: Could not recover jumptable at 0x0001405a090e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar3 = (undefined1 *)(**(code **)(*plVar2 + 0x78))(plVar2);
  return puVar3;
}

// ==== CDetainEquipActor@adapter::vfunc_17  @1405a0920  [high:rtti-vtable]  (orig: FUN_1405a0920)
void FUN_1405a0920(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140087f50();
                    /* WARNING: Could not recover jumptable at 0x0001405a0949. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1,param_2,param_3);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_18  @1405a0950  [high:rtti-vtable]  (orig: FUN_1405a0950)
bool FUN_1405a0950(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CDetainEquipActor@adapter::vfunc_19  @1405a0970  [high:rtti-vtable]  (orig: FUN_1405a0970)
undefined1 * FUN_1405a0970(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a09c8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_15  @1405a09d0  [high:rtti-vtable]  (orig: FUN_1405a09d0)
ulonglong FUN_1405a09d0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140167b70(lVar1);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_20  @1405a0a30  [high:rtti-vtable]  (orig: FUN_1405a0a30)
undefined8 FUN_1405a0a30(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a0a83. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_21  @1405a0a90  [high:rtti-vtable]  (orig: FUN_1405a0a90)
undefined8 FUN_1405a0a90(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a0ae3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_22  @1405a0af0  [high:rtti-vtable]  (orig: FUN_1405a0af0)
undefined8 FUN_1405a0af0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405a0b43. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_23  @1405a0b50  [high:rtti-vtable]  (orig: FUN_1405a0b50)
undefined4 FUN_1405a0b50(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xfa4);
}

// ==== CDetainEquipActor@adapter::vfunc_24  @1405a0bb0  [high:rtti-vtable]  (orig: FUN_1405a0bb0)
ulonglong FUN_1405a0bb0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
                    ((longlong *)(lVar1 + 0x10),0x1d,-param_3,1,0);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_25  @1405a0c30  [high:rtti-vtable]  (orig: FUN_1405a0c30)
ulonglong FUN_1405a0c30(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
                    ((longlong *)(lVar1 + 0x10),0x1d,param_3,1,0);
  return uVar2;
}

// ==== CDetainEquipActor@adapter::vfunc_27  @1405a0cb0  [high:rtti-vtable]  (orig: FUN_1405a0cb0)
ulonglong FUN_1405a0cb0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong lVar4;
  ulonglong extraout_RAX_01;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar6 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar6 = (longlong *)0x0;
  }
  cVar1 = (**(code **)(*plVar6 + 0x128))(plVar6,param_3);
  if (cVar1 != '\0') {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar4 = (**(code **)(*plVar6 + 0x60))(plVar6,param_3);
    if (lVar4 != 0) {
      lVar5 = FUN_140100070(lVar4);
      if ((lVar5 != 0) || (lVar5 = FUN_140100290(lVar4), lVar5 != 0)) {
        plVar6 = (longlong *)FUN_140087d40();
        (**(code **)(*plVar6 + 0x178))(plVar6,param_3);
      }
      plVar6 = (longlong *)FUN_140087d40();
      iVar2 = (**(code **)(*plVar6 + 0x148))(plVar6,lVar4);
      if ((iVar2 == 2) || (iVar2 == 3)) {
        plVar6 = (longlong *)FUN_140087d40();
        (**(code **)(*plVar6 + 0x158))(plVar6,param_3);
      }
      uVar7 = FUN_140340de0(lVar3,param_3,1);
      return uVar7;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_01 & 0xffffffffffffff00;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return extraout_RAX_00 & 0xffffffffffffff00;
}

// ==== CDetainEquipActor@adapter::vfunc_28  @1405a0ea0  [high:rtti-vtable]  (orig: FUN_1405a0ea0)
undefined8
FUN_1405a0ea0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,char param_6)

{
  undefined4 uVar1;
  longlong lVar2;
  
  uVar1 = param_4;
  if (param_6 != '\0') {
    uVar1 = param_3;
  }
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                    (*(longlong **)(param_1 + 0x10),uVar1);
  if (lVar2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_1401742b0(lVar2,param_2,param_3,param_4,param_5);
  return 1;
}

// ==== CDetainEquipActor@adapter::vfunc_29  @1405a0f40  [high:rtti-vtable]  (orig: FUN_1405a0f40)
undefined8 FUN_1405a0f40(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x68))(plVar3,param_2);
  if (lVar1 != 0) {
    plVar3 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar3 = (longlong *)0x0;
    }
                    /* WARNING: Could not recover jumptable at 0x0001405a101d. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*plVar3 + 0x148))(plVar3,lVar1);
    return uVar2;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 4;
}

// ==== CDetainEquipActor@adapter::vfunc_31  @1405a1030  [high:rtti-vtable]  (orig: FUN_1405a1030)
void FUN_1405a1030(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  
  if (param_3 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),param_3);
  }
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_33  @1405a10a0  [high:rtti-vtable]  (orig: FUN_1405a10a0)
void FUN_1405a10a0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x68))(plVar3,param_3);
  if ((lVar1 != 0) && (lVar2 != 0)) {
    FUN_14019a030(lVar1,param_3,0,1);
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_36  @1405a1160  [high:rtti-vtable]  (orig: FUN_1405a1160)
void FUN_1405a1160(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  FUN_140006ad0(param_2,param_3);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_0  @1405a1170  [high:rtti-vtable]  (orig: FUN_1405a1170)
void FUN_1405a1170(longlong param_1)

{
  FUN_1405a11d0(param_1 + -8);
  return;
}

// ==== CDetainEquipActor@adapter::helper_1405a11d0  @1405a11d0  [medium:callgraph-r0]  (orig: FUN_1405a11d0)
undefined8 * FUN_1405a11d0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CDetainEquipActor::vftable;
  param_1[1] = adapter::CDetainEquipActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CDetainEquipActor@adapter::vfunc_26  @1405a1220  [high:rtti-vtable]  (orig: FUN_1405a1220)
ulonglong FUN_1405a1220(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if ((0 < param_3) &&
     (0x28 < (ulonglong)
             ((*(longlong *)(lVar1 + 0xc28) - *(longlong *)(lVar1 + 0xc20) >> 2) + (longlong)param_3
             ))) {
    return 0;
  }
  return 1;
}

// ==== CDetainEquipActor@adapter::vfunc_30  @1405a12a0  [high:rtti-vtable]  (orig: FUN_1405a12a0)
void FUN_1405a12a0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if ((lVar1 != 0) && (param_3 != 0)) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(ushort *)(param_3 + 8) - 4,
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_32  @1405a1370  [high:rtti-vtable]  (orig: FUN_1405a1370)
void FUN_1405a1370(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  
  if (param_2 != 0) {
    plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar1 + 0x60))(plVar1,param_2,0xffffffff,0,0xffffff,2000);
  }
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_35  @1405a13b0  [high:rtti-vtable]  (orig: FUN_1405a13b0)
void FUN_1405a13b0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a710(uVar1);
  return;
}

// ==== CDetainEquipActor@adapter::vfunc_34  @1405a13d0  [high:rtti-vtable]  (orig: FUN_1405a13d0)
void FUN_1405a13d0(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *local_58 [3];
  longlong *local_40;
  longlong *local_38;
  undefined8 local_30;
  
  plVar8 = (longlong *)0x0;
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = plVar8;
  }
  iVar2 = (**(code **)(*plVar4 + 0xd0))();
  if (param_3 == iVar2) {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = plVar8;
    }
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x68))(plVar4,param_2);
  }
  else {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = plVar8;
    }
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x60))(plVar4,param_2);
  }
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = operator_new(8);
    local_58[0] = plVar8;
    if (plVar5 != (longlong *)0x0) {
      *plVar5 = (longlong)local_58;
      local_58[0] = plVar5;
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    FUN_140109210(plVar4,local_58);
    plVar5 = local_40;
    if (0 < (int)((longlong)local_38 - (longlong)local_40 >> 3)) {
      plVar1 = local_58[0];
      if (local_38 < local_40) {
        _invalid_parameter_noinfo();
        plVar1 = local_58[0];
      }
      while( true ) {
        plVar7 = local_38;
        if (local_38 < local_40) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_58[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar5 == plVar7) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar8;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar7[4] <= plVar5) {
          _invalid_parameter_noinfo();
        }
        plVar7 = (longlong *)*plVar5;
        if (plVar7 != (longlong *)0x0) {
          (**(code **)(*plVar7 + 0x38))(plVar7,2);
          (**(code **)(*plVar7 + 0x50))(plVar7);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar7 = plVar8;
        }
        else {
          plVar7 = (longlong *)*plVar1;
        }
        if ((longlong *)plVar7[4] <= plVar5) {
          _invalid_parameter_noinfo();
        }
        plVar5 = plVar5 + 1;
      }
      plVar5 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar5 = plVar8;
      }
      iVar2 = (**(code **)(*plVar5 + 0xd0))();
      if (param_3 != iVar2) {
        lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                          (*(longlong **)(param_1 + 0x10),param_3);
        if (lVar6 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar5 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar5 = plVar8;
          }
          iVar2 = (**(code **)(*plVar5 + 0xd0))();
          if (param_3 == iVar2) {
            uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
            FUN_14019a030(lVar6,uVar3,0,1);
          }
          else {
            uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
            FUN_14019a030(lVar6,uVar3,0,0);
          }
        }
      }
    }
    if (local_40 != (longlong *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (longlong *)0x0;
    local_38 = (longlong *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
  }
  return;
}

