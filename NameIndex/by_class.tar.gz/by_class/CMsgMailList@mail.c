// ==== CMsgMailList@mail::helper_1400d7e20  @1400d7e20  [medium:callgraph-r3]  (orig: FUN_1400d7e20)
void FUN_1400d7e20(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)param_1[1];
  if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
    lVar3 = *plVar2;
    if (*(char *)(lVar3 + 0x29) == '\0') {
      cVar1 = *(char *)(*(longlong *)(lVar3 + 0x10) + 0x29);
      lVar4 = *(longlong *)(lVar3 + 0x10);
      while (lVar5 = lVar4, cVar1 == '\0') {
        lVar4 = *(longlong *)(lVar5 + 0x10);
        cVar1 = *(char *)(lVar4 + 0x29);
        lVar3 = lVar5;
      }
      param_1[1] = lVar3;
      return;
    }
    plVar2 = (longlong *)plVar2[1];
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
    while ((cVar1 == '\0' && (param_1[1] == *plVar2))) {
      param_1[1] = (longlong)plVar2;
      plVar2 = (longlong *)plVar2[1];
      cVar1 = *(char *)((longlong)plVar2 + 0x29);
    }
    if (*(char *)(param_1[1] + 0x29) == '\0') {
      param_1[1] = (longlong)plVar2;
      return;
    }
  }
  else {
    lVar3 = plVar2[2];
    param_1[1] = lVar3;
    if (*(char *)(lVar3 + 0x29) == '\0') {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x0001400d7e52. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgMailList@mail::helper_1400d9680  @1400d9680  [medium:callgraph-r2]  (orig: FUN_1400d9680)
longlong * FUN_1400d9680(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  
  plVar2 = (longlong *)*param_1;
  plVar3 = (longlong *)param_1[1];
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
    plVar4 = (longlong *)*plVar3;
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      cVar1 = *(char *)(plVar4[2] + 0x29);
      plVar3 = (longlong *)plVar4[2];
      while (cVar1 == '\0') {
        cVar1 = *(char *)(plVar3[2] + 0x29);
        plVar4 = plVar3;
        plVar3 = (longlong *)plVar3[2];
      }
    }
    else {
      cVar1 = *(char *)(plVar3[1] + 0x29);
      plVar4 = (longlong *)plVar3[1];
      while ((cVar1 == '\0' && (plVar3 == (longlong *)*plVar4))) {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar3 = plVar4;
        plVar4 = (longlong *)plVar4[1];
      }
      if (*(char *)((longlong)plVar3 + 0x29) != '\0') {
        _invalid_parameter_noinfo();
        plVar4 = plVar3;
      }
    }
  }
  else {
    plVar4 = (longlong *)plVar3[2];
    if (*(char *)((longlong)plVar4 + 0x29) != '\0') {
      _invalid_parameter_noinfo();
    }
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = 0;
  }
  else {
    lVar5 = *plVar2;
  }
  if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return plVar4 + 3;
}

// ==== CMsgMailList@mail::helper_1400daeb0  @1400daeb0  [medium:callgraph-r2]  (orig: FUN_1400daeb0)
void FUN_1400daeb0(longlong *param_1,int param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulonglong uVar5;
  
  for (; 0 < param_2; param_2 = param_2 + -1) {
    FUN_1400d7e20(param_1);
  }
  if (param_2 < 0) {
    uVar5 = (ulonglong)(uint)-param_2;
    do {
      if (*param_1 == 0) {
        _invalid_parameter_noinfo();
      }
      lVar2 = param_1[1];
      if (*(char *)(lVar2 + 0x29) == '\0') {
        plVar3 = *(longlong **)(lVar2 + 0x10);
        if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = (longlong *)*plVar3;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar4 + 0x29);
            plVar3 = plVar4;
            plVar4 = (longlong *)*plVar4;
          }
          param_1[1] = (longlong)plVar3;
        }
        else {
          lVar2 = *(longlong *)(lVar2 + 8);
          cVar1 = *(char *)(lVar2 + 0x29);
          while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
            param_1[1] = lVar2;
            lVar2 = *(longlong *)(lVar2 + 8);
            cVar1 = *(char *)(lVar2 + 0x29);
          }
          param_1[1] = lVar2;
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      uVar5 = uVar5 - 1;
    } while (uVar5 != 0);
  }
  return;
}

// ==== CMsgMailList@mail::helper_1400dc040  @1400dc040  [medium:callgraph-r1]  (orig: FUN_1400dc040)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400dc040(longlong *param_1,int param_2,int param_3)

{
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  char *pcVar10;
  longlong *plVar11;
  ulonglong uVar12;
  ulonglong uVar13;
  undefined1 auStack_598 [32];
  undefined4 local_578;
  undefined1 local_568;
  undefined4 local_558;
  undefined4 uStack_554;
  longlong *plStack_550;
  uint local_548;
  undefined8 local_538;
  undefined8 uStack_530;
  ulonglong local_528 [2];
  undefined8 local_518;
  longlong *plStack_510;
  undefined8 local_508;
  ulonglong *local_500;
  undefined4 local_4e8;
  undefined4 uStack_4e4;
  undefined4 uStack_4e0;
  undefined4 uStack_4dc;
  undefined4 local_4d8;
  char local_4d4 [64];
  undefined4 local_494;
  undefined4 local_490;
  undefined4 local_48c;
  undefined4 local_488;
  undefined1 local_484;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_508 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  local_528[0] = CONCAT44(local_528[0]._4_4_,param_2);
  if (param_2 == 0) {
    local_578 = 0x364;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    uVar6 = FUN_140008520((int)param_1[8]);
    plVar7 = (longlong *)FUN_140087650(uVar6);
    lVar8 = (**(code **)(*plVar7 + 0x98))(plVar7,param_2);
    if (lVar8 == 0) {
      local_578 = 0x369;
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar6 = 0;
    }
    else {
      FUN_1400db220(param_1,&local_538,local_528);
      lVar1 = param_1[6];
      uVar12 = 0;
      local_500 = (ulonglong *)*param_1;
      if ((local_538 == (ulonglong *)0x0) || (local_538 != local_500)) {
        _invalid_parameter_noinfo();
      }
      lVar3 = (longlong)uStack_530;
      if (uStack_530 == (longlong *)lVar1) {
        uVar6 = 0;
      }
      else {
        if (local_538 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar13 = uVar12;
        }
        else {
          uVar13 = *local_538;
        }
        if (uStack_530 == (longlong *)*(longlong *)(uVar13 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        plStack_550 = *(longlong **)((longlong)uStack_530 + 0x50);
        uVar6 = *(undefined8 *)((longlong)uStack_530 + 0x20);
        local_518._0_4_ = (undefined4)uVar6;
        local_518._4_4_ = (undefined4)((ulonglong)uVar6 >> 0x20);
        local_558 = (undefined4)local_518;
        uStack_554 = local_518._4_4_;
        local_548 = 0;
        uVar13 = *(ulonglong *)((longlong)uStack_530 + 0x58);
        if ((param_3 < 0) || ((int)uVar13 <= param_3)) {
          uVar6 = 0;
        }
        else {
          local_528[0] = uVar13;
          local_518 = uVar6;
          plStack_510 = plStack_550;
          FUN_14035bec0(local_478);
          cVar4 = FUN_14035bf80(local_478,param_3,uVar13 & 0xffffffff);
          if (cVar4 == '\0') {
            FUN_14035bf10(local_478);
            uVar6 = 0;
          }
          else {
            FUN_1400daeb0(&local_558,param_3,local_568);
            lVar1 = CONCAT44(uStack_554,local_558);
            plVar7 = plStack_550;
            plVar2 = plStack_550;
            while( true ) {
              plStack_550 = plVar2;
              plVar2 = (longlong *)**(longlong **)(lVar3 + 0x50);
              lVar9 = *(longlong *)(lVar3 + 0x20);
              local_538._0_4_ = (undefined4)lVar9;
              local_538._4_4_ = (undefined4)((ulonglong)lVar9 >> 0x20);
              uStack_530._0_4_ = SUB84(plVar2,0);
              uStack_530._4_4_ = (undefined4)((ulonglong)plVar2 >> 0x20);
              local_4e8 = (undefined4)local_538;
              uStack_4e4 = local_538._4_4_;
              uStack_4e0 = (undefined4)uStack_530;
              uStack_4dc = uStack_530._4_4_;
              local_538 = (ulonglong *)lVar9;
              uStack_530 = plVar2;
              if ((lVar1 == 0) || (lVar1 != lVar9)) {
                _invalid_parameter_noinfo();
              }
              if ((plVar7 == plVar2) || (7 < (uint)uVar12)) break;
              lVar9 = FUN_1400d9680(&local_558);
              lVar9 = *(longlong *)(lVar9 + 8);
              if (lVar9 != 0) {
                local_4d8 = 0;
                local_4d4[0] = '\0';
                local_4d4[1] = '\0';
                local_4d4[2] = '\0';
                local_4d4[3] = '\0';
                local_4d4[4] = '\0';
                local_4d4[5] = '\0';
                local_4d4[6] = '\0';
                local_4d4[7] = '\0';
                local_4d4[8] = '\0';
                local_4d4[9] = '\0';
                local_4d4[10] = '\0';
                local_4d4[0xb] = '\0';
                local_4d4[0xc] = '\0';
                local_4d4[0xd] = '\0';
                local_4d4[0xe] = '\0';
                local_4d4[0xf] = '\0';
                local_4d4[0x10] = '\0';
                local_4d4[0x11] = '\0';
                local_4d4[0x12] = '\0';
                local_4d4[0x13] = '\0';
                local_4d4[0x14] = '\0';
                local_4d4[0x15] = '\0';
                local_4d4[0x16] = '\0';
                local_4d4[0x17] = '\0';
                local_4d4[0x18] = '\0';
                local_4d4[0x19] = '\0';
                local_4d4[0x1a] = '\0';
                local_4d4[0x1b] = '\0';
                local_4d4[0x1c] = '\0';
                local_4d4[0x1d] = '\0';
                local_4d4[0x1e] = '\0';
                local_4d4[0x1f] = '\0';
                local_4d4[0x20] = '\0';
                local_4d4[0x21] = '\0';
                local_4d4[0x22] = '\0';
                local_4d4[0x23] = '\0';
                local_4d4[0x24] = '\0';
                local_4d4[0x25] = '\0';
                local_4d4[0x26] = '\0';
                local_4d4[0x27] = '\0';
                local_4d4[0x28] = '\0';
                local_4d4[0x29] = '\0';
                local_4d4[0x2a] = '\0';
                local_4d4[0x2b] = '\0';
                local_4d4[0x2c] = '\0';
                local_4d4[0x2d] = '\0';
                local_4d4[0x2e] = '\0';
                local_4d4[0x2f] = '\0';
                local_4d4[0x30] = '\0';
                local_4d4[0x31] = '\0';
                local_4d4[0x32] = '\0';
                local_4d4[0x33] = '\0';
                local_4d4[0x34] = '\0';
                local_4d4[0x35] = '\0';
                local_4d4[0x36] = '\0';
                local_4d4[0x37] = '\0';
                local_4d4[0x38] = '\0';
                local_4d4[0x39] = '\0';
                local_4d4[0x3a] = '\0';
                local_4d4[0x3b] = '\0';
                local_4d4[0x3c] = '\0';
                local_4d4[0x3d] = '\0';
                local_4d4[0x3e] = '\0';
                local_4d4[0x3f] = '\0';
                local_494 = 0;
                local_490 = 0;
                local_48c = 0;
                local_488 = 0;
                local_484 = 0;
                local_4d8 = FUN_14035ab70(lVar9);
                pcVar10 = (char *)FUN_14035ae90(lVar9,2);
                strncpy(local_4d4,pcVar10,0x20);
                pcVar10 = (char *)FUN_14035ae90(lVar9,3);
                strncpy(local_4d4 + 0x20,pcVar10,0x20);
                local_494 = FUN_14035ad90(lVar9,5);
                local_490 = FUN_14035ad90(lVar9,6);
                iVar5 = FUN_14035ad90(lVar9,7);
                local_484 = iVar5 != 0;
                local_48c = FUN_14035b530(lVar9);
                local_488 = FUN_14035ad90(lVar9,9);
                cVar4 = FUN_14035c090(local_478,&local_4d8);
                if (cVar4 == '\0') {
                  (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))
                            ((longlong *)(lVar8 + 0x10),local_478);
                  FUN_14035c030(local_478);
                  FUN_14035c090(local_478,&local_4d8);
                }
                local_548 = (uint)uVar12 + 1;
                uVar12 = (ulonglong)local_548;
              }
              if (lVar1 == 0) {
                _invalid_parameter_noinfo();
              }
              if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
                plVar11 = (longlong *)*plVar7;
                plVar2 = plStack_550;
                if (*(char *)(*plVar7 + 0x29) == '\0') {
                  do {
                    plVar7 = plVar11;
                    plVar11 = (longlong *)plVar7[2];
                    plVar2 = plVar7;
                  } while (*(char *)(plVar7[2] + 0x29) == '\0');
                }
                else {
                  do {
                    plStack_550 = plVar2;
                    plVar11 = plVar7;
                    plVar7 = (longlong *)plVar11[1];
                    if (*(char *)((longlong)plVar7 + 0x29) != '\0') break;
                    plVar2 = plVar7;
                  } while (plVar11 == (longlong *)*plVar7);
                  plVar2 = plVar7;
                  if (*(char *)((longlong)plVar11 + 0x29) != '\0') {
                    _invalid_parameter_noinfo();
                    plVar7 = plVar11;
                    plVar2 = plStack_550;
                  }
                }
              }
              else {
                plVar7 = (longlong *)plVar7[2];
                plVar2 = plVar7;
                if (*(char *)((longlong)plVar7 + 0x29) != '\0') {
                  plStack_550 = plVar7;
                  _invalid_parameter_noinfo();
                  plVar2 = plStack_550;
                }
              }
            }
            iVar5 = FUN_14035c120(local_478);
            if (0 < iVar5) {
              (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))
                        ((longlong *)(lVar8 + 0x10),local_478);
            }
            FUN_14035bf10(local_478);
            uVar6 = 1;
          }
        }
      }
    }
  }
  return uVar6;
}

// ==== CMsgMailList@mail::helper_1400dd700  @1400dd700  [medium:callgraph-r0]  (orig: FUN_1400dd700)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400dd700(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  cVar1 = FUN_1400dc040();
  if (cVar1 == '\0') {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x40));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      local_478 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x98))
                      (*(longlong **)(lVar2 + 0x90),param_2);
    if (lVar2 != 0) {
      FUN_14035bec0(local_458);
      cVar1 = FUN_14035bf80(local_458,param_3,0);
      if (cVar1 == '\0') {
        FUN_14035bf10(local_458);
      }
      else {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_458);
        FUN_14035bf10(local_458);
      }
    }
  }
  return;
}

// ==== CMsgMailList@mail::helper_14035ab70  @14035ab70  [medium:callgraph-r2]  (orig: FUN_14035ab70)
undefined8 FUN_14035ab70(longlong *param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  param_1 = (longlong *)*param_1;
  if (param_1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(*param_1 + 0x10))(param_1,0);
                    /* WARNING: Could not recover jumptable at 0x00014035abbf. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CMsgMailList@mail::helper_14035b530  @14035b530  [medium:callgraph-r2]  (orig: FUN_14035b530)
int FUN_14035b530(longlong *param_1)

{
  uint uVar1;
  __time32_t _Var2;
  __time32_t _Var3;
  longlong *plVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  tm local_58;
  tm local_30;
  
  uVar1 = FUN_14035ac20();
  param_1 = (longlong *)*param_1;
  uVar6 = (ulonglong)uVar1;
  if (param_1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar5 = 0;
  }
  else {
    plVar4 = (longlong *)(**(code **)(*param_1 + 0x10))(param_1,8);
    uVar5 = (**(code **)(*plVar4 + 0x48))(plVar4);
    uVar5 = uVar5 & 0xffffffff;
  }
  local_30.tm_sec = 0;
  local_30.tm_wday = 0;
  local_30.tm_yday = 0;
  local_30.tm_isdst = 0;
  local_30.tm_year = uVar1 / 100000000 + 100;
  local_30.tm_mon = (int)(uVar6 / 1000000) + (int)((uVar6 / 1000000) / 100) * -100 + -1;
  local_30.tm_mday = (int)(uVar6 / 10000) + (int)((uVar6 / 10000) / 100) * -100;
  local_30.tm_hour = (int)(uVar6 / 100);
  local_30.tm_min = uVar1 + local_30.tm_hour * -100;
  local_58.tm_sec = 0;
  local_30.tm_hour = local_30.tm_hour + (int)((uVar6 / 100) / 100) * -100;
  local_58.tm_wday = 0;
  local_58.tm_yday = 0;
  local_58.tm_isdst = 0;
  local_58.tm_year = (int)(uVar5 / 100000000) + 100;
  local_58.tm_mon = (int)(uVar5 / 1000000) + (int)((uVar5 / 1000000) / 100) * -100 + -1;
  local_58.tm_mday = (int)(uVar5 / 10000) + (int)((uVar5 / 10000) / 100) * -100;
  local_58.tm_hour = (int)(uVar5 / 100);
  local_58.tm_min = (int)uVar5 + local_58.tm_hour * -100;
  local_58.tm_hour = local_58.tm_hour + (int)((uVar5 / 100) / 100) * -100;
  _Var2 = _mktime32(&local_58);
  _Var3 = _mktime32(&local_30);
  return _Var2 - _Var3;
}

// ==== CMsgMailList@mail::helper_14035bec0  @14035bec0  [medium:callgraph-r1]  (orig: FUN_14035bec0)
undefined8 * FUN_14035bec0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = mail::CMsgMailList::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMailList@mail::helper_14035bf10  @14035bf10  [medium:callgraph-r1]  (orig: FUN_14035bf10)
void FUN_14035bf10(undefined8 *param_1)

{
  *param_1 = mail::CMsgMailList::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMailList@mail::vfunc_5  @14035bf40  [high:rtti-vtable]  (orig: FUN_14035bf40)
bool FUN_14035bf40(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x416;
    }
  }
  return false;
}

// ==== CMsgMailList@mail::helper_14035bf80  @14035bf80  [medium:callgraph-r1]  (orig: FUN_14035bf80)
ulonglong FUN_14035bf80(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  *(undefined4 *)(param_1 + 8) = 0x416;
  **(undefined4 **)(param_1 + 0x428) = 0;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined4 *)(lVar1 + 8) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgMailList@mail::helper_14035c030  @14035c030  [medium:callgraph-r2]  (orig: FUN_14035c030)
void FUN_14035c030(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  **(undefined4 **)(param_1 + 0x428) = 0;
  *(undefined4 *)(param_1 + 0xc) = 0xc;
  return;
}

// ==== CMsgMailList@mail::helper_14035c090  @14035c090  [medium:callgraph-r2]  (orig: FUN_14035c090)
undefined8 FUN_14035c090(longlong param_1,void *param_2)

{
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 0x428);
  if (piVar1 == (int *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((longlong)*(int *)(param_1 + 0xc) + 0x58U < 0x400) {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x58;
    memcpy(piVar1 + (longlong)*piVar1 * 0x16 + 3,param_2,0x58);
    **(int **)(param_1 + 0x428) = **(int **)(param_1 + 0x428) + 1;
    return 1;
  }
  return 0;
}

// ==== CMsgMailList@mail::helper_14035c120  @14035c120  [medium:callgraph-r2]  (orig: FUN_14035c120)
undefined4 FUN_14035c120(longlong param_1)

{
  if (*(undefined4 **)(param_1 + 0x428) == (undefined4 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return **(undefined4 **)(param_1 + 0x428);
}

// ==== CMsgMailList@mail::vfunc_0  @14035c170  [high:rtti-vtable]  (orig: FUN_14035c170)
undefined8 * FUN_14035c170(undefined8 *param_1,uint param_2)

{
  *param_1 = mail::CMsgMailList::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgMailList@mail::vfunc_3  @14035c1c0  [high:rtti-vtable]  (orig: FUN_14035c1c0)
void FUN_14035c1c0(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  longlong *plVar3;
  longlong lVar4;
  
  uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar3 = (longlong *)FUN_140087650(uVar2);
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x88))(plVar3,param_1);
  if (plVar3 != (longlong *)0x0) {
    iVar1 = (**(code **)(*plVar3 + 8))(plVar3);
    if (iVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else if (*(longlong *)(param_1 + 0x428) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      if (*(longlong *)(lVar4 + 0x180) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar2 = 0;
      }
      else {
        uVar2 = *(undefined8 *)(lVar4 + 0x180);
      }
      FUN_1400dd700(uVar2,iVar1,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
    }
  }
  return;
}

