// ==== CMsgWalkPB::vfunc_3  @140576b90  [high:rtti-vtable]  (orig: FUN_140576b90)
void FUN_140576b90(longlong param_1)

{
  if ((*(byte *)(param_1 + 0x30) & 0x1f) != 0) {
    *(undefined4 *)(param_1 + 0x38) = 0;
    *(undefined4 *)(param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 0x40) = 0;
    *(undefined4 *)(param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 0x48) = 0;
  }
  *(undefined4 *)(param_1 + 0x30) = 0;
                    /* WARNING: Could not recover jumptable at 0x000140576bb0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::clear
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8));
  return;
}

// ==== CMsgWalkPB::vfunc_9  @140576bc0  [high:rtti-vtable]  (orig: FUN_140576bc0)
void FUN_140576bc0(longlong param_1,undefined8 param_2)

{
  longlong lVar1;
  
  if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
    FUN_1405c8ee0(1,*(undefined4 *)(param_1 + 0x38),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
    FUN_1405c8ee0(2,*(undefined4 *)(param_1 + 0x3c),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 2 & 1) != 0) {
    FUN_1405c8ee0(3,*(undefined4 *)(param_1 + 0x40),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 3 & 1) != 0) {
    FUN_1405c8ee0(4,*(undefined4 *)(param_1 + 0x44),param_2);
  }
  if ((*(uint *)(param_1 + 0x30) >> 4 & 1) != 0) {
    FUN_1405c8ee0(5,*(undefined4 *)(param_1 + 0x48),param_2);
  }
  if (*(ulonglong *)(param_1 + 0x28) < 0x10) {
    lVar1 = param_1 + 0x10;
  }
  else {
    lVar1 = *(longlong *)(param_1 + 0x10);
  }
  FUN_14055a240(param_2,lVar1,*(ulonglong *)(param_1 + 0x20) & 0xffffffff);
  return;
}

// ==== CMsgWalkPB::vfunc_8  @140576c80  [high:rtti-vtable]  (orig: FUN_140576c80)
int FUN_140576c80(longlong param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  if (*(char *)(param_1 + 0x30) != '\0') {
    iVar2 = 1;
    if ((*(byte *)(param_1 + 0x30) & 1) != 0) {
      if (*(uint *)(param_1 + 0x38) < 0x80) {
        iVar3 = 1;
      }
      else {
        iVar3 = FUN_14055a8a0();
      }
      iVar3 = iVar3 + 1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 1 & 1) != 0) {
      if (*(uint *)(param_1 + 0x3c) < 0x80) {
        iVar1 = 1;
      }
      else {
        iVar1 = FUN_14055a8a0();
      }
      iVar3 = iVar3 + 1 + iVar1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 2 & 1) != 0) {
      if (*(uint *)(param_1 + 0x40) < 0x80) {
        iVar1 = 1;
      }
      else {
        iVar1 = FUN_14055a8a0();
      }
      iVar3 = iVar3 + 1 + iVar1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 3 & 1) != 0) {
      if (*(uint *)(param_1 + 0x44) < 0x80) {
        iVar1 = 1;
      }
      else {
        iVar1 = FUN_14055a8a0();
      }
      iVar3 = iVar3 + 1 + iVar1;
    }
    if ((*(uint *)(param_1 + 0x30) >> 4 & 1) != 0) {
      if (0x7f < *(uint *)(param_1 + 0x48)) {
        iVar2 = FUN_14055a8a0();
      }
      iVar3 = iVar3 + 1 + iVar2;
    }
  }
  iVar3 = iVar3 + *(int *)(param_1 + 0x20);
  *(int *)(param_1 + 0x34) = iVar3;
  return iVar3;
}

// ==== CMsgWalkPB::helper_140576d60  @140576d60  [medium:callgraph-r0]  (orig: FUN_140576d60)
void FUN_140576d60(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 local_res8 [8];
  undefined1 local_48 [64];
  
  if (param_2 == param_1) {
    local_res8[0] = 0;
    uVar2 = FUN_140556890(local_48,3,"f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgwalk.pb.cc",
                          0x155,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(local_res8,uVar2);
    FUN_140556900(local_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x38);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x38) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x3c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
      *(undefined4 *)(param_1 + 0x3c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 2 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 3 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x44);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
      *(undefined4 *)(param_1 + 0x44) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 4 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x48);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
      *(undefined4 *)(param_1 + 0x48) = uVar1;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x000140576e68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

// ==== CMsgWalkPB::vfunc_4  @140576eb0  [high:rtti-vtable]  (orig: FUN_140576eb0)
bool FUN_140576eb0(longlong param_1)

{
  return (*(byte *)(param_1 + 0x30) & 0xf) == 0xf;
}

// ==== CMsgWalkPB::vfunc_1  @140576ec0  [high:rtti-vtable]  (orig: FUN_140576ec0)
basic_string<char,std::char_traits<char>,std::allocator<char>_> *
FUN_140576ec0(undefined8 param_1,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_2)

{
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(param_2,"CMsgWalkPB");
  return param_2;
}

// ==== CMsgWalkPB::ctor_or_dtor  @140576f20  [high:vtable-assign]  (orig: FUN_140576f20)
undefined8 * FUN_140576f20(undefined8 *param_1)

{
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgWalkPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  return param_1;
}

// ==== CMsgWalkPB::vfunc_11  @140576f80  [high:rtti-vtable]  (orig: FUN_140576f80)
undefined4 FUN_140576f80(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x34);
}

// ==== CMsgWalkPB::ctor_or_dtor  @140576f90  [high:vtable-assign]  (orig: FUN_140576f90)
undefined8 *
FUN_140576f90(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  *param_1 = google::protobuf::MessageLite::vftable;
  *param_1 = CMsgWalkPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  FUN_140576d60(param_1,param_2,param_3,param_4,uVar1);
  return param_1;
}

// ==== CMsgWalkPB::ctor_or_dtor  @140577000  [high:vtable-assign]  (orig: FUN_140577000)
void FUN_140577000(undefined8 *param_1)

{
  *param_1 = CMsgWalkPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  return;
}

// ==== CMsgWalkPB::ctor_or_dtor  @140577040  [high:vtable-assign]  (orig: FUN_140577040)
undefined8 * FUN_140577040(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = google::protobuf::MessageLite::vftable;
    *puVar1 = CMsgWalkPB::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar1 + 1));
    *(undefined4 *)((longlong)puVar1 + 0x34) = 0;
    *(undefined4 *)(puVar1 + 7) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x3c) = 0;
    *(undefined4 *)(puVar1 + 8) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x44) = 0;
    *(undefined4 *)(puVar1 + 9) = 0;
    *(undefined4 *)(puVar1 + 6) = 0;
  }
  return puVar1;
}

// ==== CMsgWalkPB::ctor_or_dtor  @140577230  [high:vtable-assign]  (orig: FUN_140577230)
undefined8 * FUN_140577230(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgWalkPB::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 1));
  FUN_140554130(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgWalkPB::vfunc_7  @1405772c0  [high:rtti-vtable]  (orig: FUN_1405772c0)
undefined8 FUN_1405772c0(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  byte bVar1;
  byte *pbVar2;
  char *pcVar3;
  int iVar4;
  char cVar5;
  uint uVar6;
  int iVar7;
  ulonglong uVar8;
  undefined1 local_40 [16];
  undefined1 local_30 [40];
  
  FUN_14055c020(local_40,param_1 + 8,param_3,param_4,0xfffffffffffffffe);
  FUN_14055a0b0(local_30,local_40);
LAB_140577300:
  while ((pbVar2 = *(byte **)(param_2 + 8), *(byte **)(param_2 + 0x10) <= pbVar2 ||
         (bVar1 = *pbVar2, (char)bVar1 < '\x01'))) {
    uVar6 = FUN_140559720(param_2);
    uVar8 = (ulonglong)uVar6;
    *(uint *)(param_2 + 0x20) = uVar6;
    if (uVar6 - 1 < 0x7f) goto LAB_14057733d;
LAB_14057753a:
    if (((int)uVar8 == 0) || (((byte)uVar8 & 7) == 4)) goto LAB_140577582;
    cVar5 = FUN_1405c88b0(param_2,uVar8,local_30);
    if (cVar5 == '\0') {
LAB_140577569:
      FUN_14055a130(local_30);
      FUN_14055c070(local_40);
      return 0;
    }
  }
  uVar8 = (ulonglong)bVar1;
  *(uint *)(param_2 + 0x20) = (uint)bVar1;
  *(byte **)(param_2 + 8) = pbVar2 + 1;
LAB_14057733d:
  iVar7 = (int)uVar8;
  iVar4 = (int)(uVar8 >> 3);
  if (iVar4 == 1) {
    if (iVar7 != 8) goto LAB_14057753a;
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x38) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar5 = FUN_1405595b0(param_2);
      if (cVar5 == '\0') goto LAB_140577569;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
    pcVar3 = *(char **)(param_2 + 8);
    if ((*(char **)(param_2 + 0x10) <= pcVar3) || (*pcVar3 != '\x10')) goto LAB_140577300;
    *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_1405773ef:
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x3c) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar5 = FUN_1405595b0(param_2);
      if (cVar5 == '\0') goto LAB_140577569;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
    pcVar3 = *(char **)(param_2 + 8);
    if ((*(char **)(param_2 + 0x10) <= pcVar3) || (*pcVar3 != '\x18')) goto LAB_140577300;
    *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140577442:
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x40) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar5 = FUN_1405595b0(param_2);
      if (cVar5 == '\0') goto LAB_140577569;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
    pcVar3 = *(char **)(param_2 + 8);
    if ((*(char **)(param_2 + 0x10) <= pcVar3) || (*pcVar3 != ' ')) goto LAB_140577300;
    *(char **)(param_2 + 8) = pcVar3 + 1;
LAB_140577495:
    if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
       (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
      *(uint *)(param_1 + 0x44) = (uint)bVar1;
      *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
    }
    else {
      cVar5 = FUN_1405595b0(param_2);
      if (cVar5 == '\0') goto LAB_140577569;
    }
    *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
    pcVar3 = *(char **)(param_2 + 8);
    if ((*(char **)(param_2 + 0x10) <= pcVar3) || (*pcVar3 != '(')) goto LAB_140577300;
    *(char **)(param_2 + 8) = pcVar3 + 1;
  }
  else {
    if (iVar4 == 2) {
      if (iVar7 != 0x10) goto LAB_14057753a;
      goto LAB_1405773ef;
    }
    if (iVar4 == 3) {
      if (iVar7 != 0x18) goto LAB_14057753a;
      goto LAB_140577442;
    }
    if (iVar4 == 4) {
      if (iVar7 != 0x20) goto LAB_14057753a;
      goto LAB_140577495;
    }
    if ((iVar4 != 5) || (iVar7 != 0x28)) goto LAB_14057753a;
  }
  if ((*(byte **)(param_2 + 8) < *(byte **)(param_2 + 0x10)) &&
     (bVar1 = **(byte **)(param_2 + 8), bVar1 < 0x80)) {
    *(uint *)(param_1 + 0x48) = (uint)bVar1;
    *(longlong *)(param_2 + 8) = *(longlong *)(param_2 + 8) + 1;
  }
  else {
    cVar5 = FUN_1405595b0(param_2);
    if (cVar5 == '\0') goto LAB_140577569;
  }
  *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
  if ((*(longlong *)(param_2 + 8) == *(longlong *)(param_2 + 0x10)) &&
     ((*(int *)(param_2 + 0x2c) != 0 || (*(int *)(param_2 + 0x18) == *(int *)(param_2 + 0x28))))) {
    *(undefined4 *)(param_2 + 0x20) = 0;
    *(undefined1 *)(param_2 + 0x24) = 1;
LAB_140577582:
    FUN_14055a130(local_30);
    FUN_14055c070(local_40);
    return 1;
  }
  goto LAB_140577300;
}

// ==== CMsgWalkPB::vfunc_6  @1405775b0  [high:rtti-vtable]  (orig: thunk_FUN_140576d60)
void thunk_FUN_140576d60(longlong param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined8 uVar2;
  undefined1 auStackX_8 [8];
  undefined1 auStack_48 [64];
  
  if (param_2 == param_1) {
    auStackX_8[0] = 0;
    uVar2 = FUN_140556890(auStack_48,3,"f:\\version\\cqserver-78.0.11-1204\\protobuf\\msgwalk.pb.cc"
                          ,0x155,0,0xfffffffffffffffe);
    uVar2 = FUN_1405564f0(uVar2,"CHECK failed: (&from) != (this): ");
    FUN_140556a40(auStackX_8,uVar2);
    FUN_140556900(auStack_48);
  }
  if (*(char *)(param_2 + 0x30) != '\0') {
    if ((*(byte *)(param_2 + 0x30) & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x38);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 1;
      *(undefined4 *)(param_1 + 0x38) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 1 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x3c);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 2;
      *(undefined4 *)(param_1 + 0x3c) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 2 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x40);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 4;
      *(undefined4 *)(param_1 + 0x40) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 3 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x44);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 8;
      *(undefined4 *)(param_1 + 0x44) = uVar1;
    }
    if ((*(uint *)(param_2 + 0x30) >> 4 & 1) != 0) {
      uVar1 = *(undefined4 *)(param_2 + 0x48);
      *(uint *)(param_1 + 0x30) = *(uint *)(param_1 + 0x30) | 0x10;
      *(undefined4 *)(param_1 + 0x48) = uVar1;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x000140576e68. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::append
            ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_1 + 8),
             (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
             (param_2 + 8));
  return;
}

