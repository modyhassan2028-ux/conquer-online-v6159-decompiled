// ==== CNpcTask::ctor_or_dtor  @14046ec20  [high:vtable-assign]  (orig: FUN_14046ec20)
undefined8 * FUN_14046ec20(undefined8 *param_1)

{
  *param_1 = CNpcTask::vftable;
  param_1[2] = 0;
  param_1[3] = 0;
  *(undefined1 *)(param_1 + 1) = 0;
  return param_1;
}

// ==== CNpcTask::ctor_or_dtor  @14046ec40  [high:vtable-assign]  (orig: FUN_14046ec40)
void FUN_14046ec40(undefined8 *param_1)

{
  *param_1 = CNpcTask::vftable;
  if ((longlong *)param_1[2] != (longlong *)0x0) {
    (**(code **)(*(longlong *)param_1[2] + 0x10))();
  }
  return;
}

