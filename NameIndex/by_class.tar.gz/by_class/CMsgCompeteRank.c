// ==== CMsgCompeteRank::ctor_or_dtor  @1403803a0  [high:vtable-assign]  (orig: FUN_1403803a0)
undefined8 * FUN_1403803a0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCompeteRank::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgCompeteRank::ctor_or_dtor  @1403803f0  [high:vtable-assign]  (orig: FUN_1403803f0)
void FUN_1403803f0(undefined8 *param_1)

{
  *param_1 = CMsgCompeteRank::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgCompeteRank::vfunc_1  @140380420  [high:rtti-vtable]  (orig: FUN_140380420)
ulonglong FUN_140380420(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x42f);
}

// ==== CMsgCompeteRank::ctor_or_dtor  @1403805c0  [high:vtable-assign]  (orig: FUN_1403805c0)
undefined8 * FUN_1403805c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCompeteRank::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

