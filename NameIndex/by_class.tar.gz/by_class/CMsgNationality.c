// ==== CMsgNationality::helper_140166d10  @140166d10  [medium:callgraph-r0]  (orig: FUN_140166d10)
void FUN_140166d10(longlong param_1)

{
  FUN_140373cd0(param_1 + 0xe78);
  return;
}

// ==== CMsgNationality::helper_140166d20  @140166d20  [medium:callgraph-r0]  (orig: FUN_140166d20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140166d20(longlong *param_1,undefined2 param_2)

{
  char cVar1;
  undefined4 uVar2;
  undefined1 auStack_478 [32];
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  FUN_140373ce0(param_1 + 0x1cf);
  FUN_1403b66d0(local_448);
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  cVar1 = FUN_1403b6790(local_448,uVar2,param_2);
  if (cVar1 == '\0') {
    FUN_1403b6720(local_448);
  }
  else {
    (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_448,1);
    FUN_1403b6720(local_448);
  }
  return;
}

// ==== CMsgNationality::helper_140373cd0  @140373cd0  [medium:callgraph-r1]  (orig: FUN_140373cd0)
undefined2 FUN_140373cd0(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x1e8);
}

// ==== CMsgNationality::helper_140373ce0  @140373ce0  [medium:callgraph-r1]  (orig: FUN_140373ce0)
void FUN_140373ce0(longlong param_1,undefined2 param_2,char param_3)

{
  longlong *plVar1;
  
  *(undefined2 *)(param_1 + 0x1e8) = param_2;
  plVar1 = *(longlong **)(param_1 + 0x230);
  if (plVar1 != (longlong *)0x0) {
    plVar1 = (longlong *)(**(code **)(*plVar1 + 0x20))(plVar1,"nationality");
    (**(code **)(*plVar1 + 200))(plVar1,param_2);
    if (param_3 != '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x230) + 0x38))(*(longlong **)(param_1 + 0x230),0);
    }
  }
  return;
}

// ==== CMsgNationality::ctor_or_dtor  @1403b66d0  [high:vtable-assign]  (orig: FUN_1403b66d0)
undefined8 * FUN_1403b66d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgNationality::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgNationality::ctor_or_dtor  @1403b6720  [high:vtable-assign]  (orig: FUN_1403b6720)
void FUN_1403b6720(undefined8 *param_1)

{
  *param_1 = CMsgNationality::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgNationality::vfunc_1  @1403b6750  [high:rtti-vtable]  (orig: FUN_1403b6750)
bool FUN_1403b6750(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x97e;
    }
  }
  return false;
}

// ==== CMsgNationality::helper_1403b6790  @1403b6790  [medium:callgraph-r1]  (orig: FUN_1403b6790)
undefined8 FUN_1403b6790(longlong param_1,undefined4 param_2,undefined2 param_3)

{
  longlong lVar1;
  
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0x97e;
  *(undefined4 *)(param_1 + 0xc) = 6;
  **(undefined4 **)(param_1 + 0x428) = param_2;
  lVar1 = *(longlong *)(param_1 + 0x428);
  *(undefined2 *)(lVar1 + 4) = param_3;
  return CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
}

// ==== CMsgNationality::ctor_or_dtor  @1403b67f0  [high:vtable-assign]  (orig: FUN_1403b67f0)
undefined8 * FUN_1403b67f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgNationality::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgNationality::vfunc_3  @1403b6840  [high:rtti-vtable]  (orig: FUN_1403b6840)
void FUN_1403b6840(longlong param_1)

{
  short sVar1;
  longlong lVar2;
  char cVar3;
  short sVar4;
  longlong lVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x88))
                      (*(longlong **)(lVar5 + 0x90),param_1);
    if (lVar5 != 0) {
      cVar3 = (**(code **)(*(longlong *)(lVar5 + 0x10) + 0x220))(lVar5 + 0x10);
      if (cVar3 == '\0') {
        pIVar6 = theInstance();
        lVar2 = *(longlong *)(lVar5 + 0x10);
        uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_DIE");
                    /* WARNING: Could not recover jumptable at 0x0001403b6907. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (**(code **)(lVar2 + 0x358))(lVar5 + 0x10,uVar7);
        return;
      }
      sVar1 = *(short *)(*(longlong *)(param_1 + 0x428) + 4);
      sVar4 = FUN_140166d10(lVar5);
      if (sVar1 != sVar4) {
        FUN_140166d20(lVar5,sVar1,0);
      }
    }
  }
  return;
}

