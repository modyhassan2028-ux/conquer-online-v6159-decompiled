// ==== CMapGroupKernel::helper_140005820  @140005820  [medium:callgraph-r1]  (orig: FUN_140005820)
void FUN_140005820(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14001ce60  @14001ce60  [medium:callgraph-r3]  (orig: FUN_14001ce60)
longlong * FUN_14001ce60(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14001cd70(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x51) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x51);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x51);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x51);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x51);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14001c980(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_14001d040  @14001d040  [medium:callgraph-r2]  (orig: FUN_14001d040)
void FUN_14001d040(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14001ce60((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_14001d110  @14001d110  [medium:callgraph-r1]  (orig: FUN_14001d110)
void FUN_14001d110(longlong param_1)

{
  FUN_14001d040((undefined8 *)(param_1 + 8));
  operator_delete(*(void **)(param_1 + 8));
  return;
}

// ==== CMapGroupKernel::helper_14002c020  @14002c020  [medium:callgraph-r2]  (orig: FUN_14002c020)
bool FUN_14002c020(longlong param_1)

{
  return *(int *)(param_1 + 0xc) == 2;
}

// ==== CMapGroupKernel::helper_140088970  @140088970  [medium:callgraph-r0]  (orig: FUN_140088970)
undefined1 FUN_140088970(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = FUN_1401599e0(0x10);
  if (lVar2 == 0) {
    lVar2 = 0;
  }
  else {
    lVar2 = FUN_140159b00(lVar2,*(undefined4 *)(param_1 + 0x68));
  }
  if ((lVar2 != 0) && (cVar1 = FUN_140159b80(lVar2), cVar1 != '\0')) {
    *(longlong *)(param_1 + 0xa0) = lVar2;
    return 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMapGroupKernel::helper_14008d7b0  @14008d7b0  [medium:callgraph-r3]  (orig: FUN_14008d7b0)
void FUN_14008d7b0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroupKernel::helper_1400923f0  @1400923f0  [medium:callgraph-r1]  (orig: FUN_1400923f0)
void FUN_1400923f0(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  uint uVar3;
  
  uVar3 = 0x1ef9b0;
  do {
    plVar2 = DAT_140975b88;
    if (DAT_140975b88 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)0x0;
    }
    lVar1 = (**(code **)(*plVar2 + 0x40))(plVar2,uVar3);
    if (lVar1 != 0) {
      lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
      if (*(longlong *)(lVar1 + 0xa8) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_140145f60(*(undefined8 *)(lVar1 + 0xa8),uVar3,0,0,0,0);
    }
    uVar3 = uVar3 + 1;
  } while (uVar3 < 0x1efa14);
  return;
}

// ==== CMapGroupKernel::helper_1400945c0  @1400945c0  [medium:callgraph-r1]  (orig: FUN_1400945c0)
longlong * FUN_1400945c0(longlong *param_1)

{
  longlong *plVar1;
  longlong lVar2;
  longlong lVar3;
  
  plVar1 = (longlong *)*param_1;
  lVar3 = 0;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar1 = (longlong *)*param_1;
    lVar2 = lVar3;
    if (plVar1 == (longlong *)0x0) goto LAB_1400945f3;
  }
  lVar2 = *plVar1;
  if (plVar1 != (longlong *)0x0) {
    lVar3 = lVar2;
  }
LAB_1400945f3:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar2 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1[1] = param_1[1] + 1;
  return param_1;
}

// ==== CMapGroupKernel::helper_140095130  @140095130  [medium:callgraph-r3]  (orig: FUN_140095130)
void FUN_140095130(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x850)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 0x850);
  return;
}

// ==== CMapGroupKernel::helper_1400a42b0  @1400a42b0  [medium:callgraph-r3]  (orig: FUN_1400a42b0)
void FUN_1400a42b0(undefined8 param_1,longlong *param_2,longlong *param_3)

{
  for (; param_2 != param_3; param_2 = param_2 + 0x10a) {
    (**(code **)(*param_2 + 0x128))(param_2,0);
  }
  return;
}

// ==== CMapGroupKernel::helper_1400b23f0  @1400b23f0  [medium:callgraph-r3]  (orig: FUN_1400b23f0)
undefined8 FUN_1400b23f0(undefined8 param_1,longlong param_2,longlong *param_3,longlong *param_4)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  
  FUN_140098330(param_4,param_1,param_3[1] - *(longlong *)(param_2 + 8));
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = *(longlong **)*param_4;
  }
  plVar5 = (longlong *)*plVar5;
  uVar9 = param_4[1];
  plVar1 = (longlong *)*param_3;
  uVar8 = param_3[1];
  uVar2 = *(ulonglong *)(param_2 + 8);
  while (uVar2 != uVar8) {
    uVar8 = uVar8 - 1;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    if ((ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30)) <= uVar8) {
      _invalid_parameter_noinfo();
    }
    if (plVar1 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    uVar7 = uVar8;
    if (*(ulonglong *)(lVar6 + 0x28) <= uVar8) {
      if (plVar1 == (longlong *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar1;
      }
      uVar7 = uVar8 - *(longlong *)(lVar6 + 0x28);
    }
    if (plVar1 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar1;
    }
    uVar9 = uVar9 - 1;
    puVar3 = *(undefined8 **)(*(longlong *)(lVar6 + 0x20) + uVar7 * 8);
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    if ((ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30)) <= uVar9) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    uVar7 = uVar9;
    if (*(ulonglong *)(lVar6 + 0x28) <= uVar9) {
      if (plVar5 == (longlong *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar5;
      }
      uVar7 = uVar9 - *(longlong *)(lVar6 + 0x28);
    }
    if (plVar5 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    puVar4 = *(undefined8 **)(*(longlong *)(lVar6 + 0x20) + uVar7 * 8);
    *puVar4 = *puVar3;
    *(undefined4 *)(puVar4 + 1) = *(undefined4 *)(puVar3 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar4 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               (puVar3 + 2));
  }
  return param_1;
}

// ==== CMapGroupKernel::helper_1400b25d0  @1400b25d0  [medium:callgraph-r3]  (orig: FUN_1400b25d0)
undefined8 FUN_1400b25d0(undefined8 param_1,longlong *param_2,longlong param_3,longlong *param_4)

{
  ulonglong uVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  
  FUN_1400958b0(param_4,param_1,*(longlong *)(param_3 + 8) - param_2[1]);
  if ((undefined8 *)*param_4 == (undefined8 *)0x0) {
    plVar5 = (longlong *)0x0;
  }
  else {
    plVar5 = *(longlong **)*param_4;
  }
  plVar5 = (longlong *)*plVar5;
  uVar9 = param_4[1];
  uVar1 = *(ulonglong *)(param_3 + 8);
  plVar2 = (longlong *)*param_2;
  for (uVar7 = param_2[1]; uVar7 != uVar1; uVar7 = uVar7 + 1) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if ((ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30)) <= uVar7) {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    uVar8 = uVar7;
    if (*(ulonglong *)(lVar6 + 0x28) <= uVar7) {
      if (plVar2 == (longlong *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar2;
      }
      uVar8 = uVar7 - *(longlong *)(lVar6 + 0x28);
    }
    if (plVar2 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    puVar3 = *(undefined8 **)(*(longlong *)(lVar6 + 0x20) + uVar8 * 8);
    if (plVar5 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    if ((ulonglong)(*(longlong *)(lVar6 + 0x38) + *(longlong *)(lVar6 + 0x30)) <= uVar9) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    uVar8 = uVar9;
    if (*(ulonglong *)(lVar6 + 0x28) <= uVar9) {
      if (plVar5 == (longlong *)0x0) {
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar5;
      }
      uVar8 = uVar9 - *(longlong *)(lVar6 + 0x28);
    }
    if (plVar5 == (longlong *)0x0) {
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar5;
    }
    puVar4 = *(undefined8 **)(*(longlong *)(lVar6 + 0x20) + uVar8 * 8);
    *puVar4 = *puVar3;
    *(undefined4 *)(puVar4 + 1) = *(undefined4 *)(puVar3 + 1);
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(puVar4 + 2),
               (basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_> *)
               (puVar3 + 2));
    uVar9 = uVar9 + 1;
  }
  return param_1;
}

// ==== CMapGroupKernel::helper_1400b4f30  @1400b4f30  [medium:callgraph-r1]  (orig: FUN_1400b4f30)
void FUN_1400b4f30(longlong *param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  uVar2 = param_1[3];
  if ((ulonglong)param_1[4] < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((uVar2 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar2)) {
    _invalid_parameter_noinfo();
  }
  lVar3 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar3 == 0) || (lVar3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar2 != uVar1) {
    lVar3 = FUN_14009c860(uVar1,param_1[4],uVar2);
    param_1[4] = lVar3;
  }
  return;
}

// ==== CMapGroupKernel::helper_1400b8930  @1400b8930  [medium:callgraph-r2]  (orig: FUN_1400b8930)
longlong *
FUN_1400b8930(longlong *param_1,longlong *param_2,undefined8 *param_3,undefined8 *param_4)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined1 local_res10;
  longlong *local_78;
  ulonglong uStack_70;
  longlong *local_68;
  ulonglong uStack_60;
  longlong *local_58;
  ulonglong uStack_50;
  undefined1 local_48 [16];
  
  local_68 = (longlong *)*param_3;
  uVar2 = param_3[1];
  if (((param_1 == (longlong *)0x0) || (uVar2 < (ulonglong)param_1[6])) ||
     ((ulonglong)(param_1[6] + param_1[7]) < uVar2)) {
    uStack_60 = uVar2;
    _invalid_parameter_noinfo();
  }
  plVar3 = (longlong *)*param_1;
  local_78 = (longlong *)*param_4;
  uVar7 = param_4[1];
  local_68 = plVar3;
  if ((uVar7 < (ulonglong)param_1[6]) ||
     (uStack_60 = uVar2, (ulonglong)(param_1[6] + param_1[7]) < uVar7)) {
    uStack_70 = uVar7;
    uStack_60 = uVar2;
    _invalid_parameter_noinfo();
  }
  plVar4 = (longlong *)*param_1;
  uVar5 = param_1[6];
  local_78 = plVar4;
  uStack_70 = uVar7;
  if (uVar5 + param_1[7] < uVar5) {
    _invalid_parameter_noinfo();
  }
  if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*param_1)) {
    _invalid_parameter_noinfo();
  }
  if ((plVar4 == (longlong *)0x0) || (plVar4 != plVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar6 = uVar7 - uVar2;
  uVar1 = param_1[6] + param_1[7];
  if (uVar1 < (ulonglong)param_1[6]) {
    _invalid_parameter_noinfo();
  }
  if (((longlong *)*param_1 == (longlong *)0x0) || ((longlong *)*param_1 != plVar4)) {
    _invalid_parameter_noinfo();
  }
  local_res10 = SUB81(param_2,0);
  if (uVar2 - uVar5 < uVar1 - uVar7) {
    uVar7 = param_1[6];
    if (uVar7 + param_1[7] < uVar7) {
      _invalid_parameter_noinfo();
    }
    local_68 = local_78;
    uStack_60 = uStack_70;
    local_78 = (longlong *)0x0;
    local_58 = local_78;
    if (plVar3 != (longlong *)0x0) {
      local_58 = (longlong *)*plVar3;
    }
    local_58 = (longlong *)*local_58;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      local_78 = *(longlong **)*param_1;
    }
    local_78 = (longlong *)*local_78;
    uStack_70 = uVar7;
    uStack_50 = uVar2;
    FUN_1400b23f0(local_48,&local_78,&local_58,&local_68,local_res10,local_res10,0);
    for (; lVar6 != 0; lVar6 = lVar6 + -1) {
      if (param_1[7] != 0) {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                  ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   (*(longlong *)(param_1[4] + param_1[6] * 8) + 0x10));
        param_1[6] = param_1[6] + 1;
        if ((ulonglong)param_1[5] <= (ulonglong)param_1[6]) {
          param_1[6] = 0;
        }
        plVar3 = param_1 + 7;
        *plVar3 = *plVar3 + -1;
        if (*plVar3 == 0) {
          param_1[6] = 0;
        }
      }
    }
  }
  else {
    uVar1 = param_1[6] + param_1[7];
    if (uVar1 < (ulonglong)param_1[6]) {
      _invalid_parameter_noinfo();
    }
    local_58 = local_68;
    uStack_50 = uStack_60;
    local_68 = (longlong *)0x0;
    local_78 = local_68;
    if ((undefined8 *)*param_1 != (undefined8 *)0x0) {
      local_78 = *(longlong **)*param_1;
    }
    local_78 = (longlong *)*local_78;
    if (plVar4 != (longlong *)0x0) {
      local_68 = (longlong *)*plVar4;
    }
    local_68 = (longlong *)*local_68;
    uStack_70 = uVar1;
    uStack_60 = uVar7;
    FUN_1400b25d0(local_48,&local_68,&local_78,&local_58,local_res10,local_res10,0);
    for (; lVar6 != 0; lVar6 = lVar6 + -1) {
      if (param_1[7] != 0) {
        uVar7 = param_1[6] + -1 + param_1[7];
        if ((ulonglong)param_1[5] <= uVar7) {
          uVar7 = uVar7 - param_1[5];
        }
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                  ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                   (*(longlong *)(param_1[4] + uVar7 * 8) + 0x10));
        plVar3 = param_1 + 7;
        *plVar3 = *plVar3 + -1;
        if (*plVar3 == 0) {
          param_1[6] = 0;
        }
      }
    }
  }
  lVar6 = 0;
  uVar7 = param_1[6];
  if (uVar7 + param_1[7] < uVar7) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_68 = param_1;
  uStack_60 = uVar7;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar8 = lVar6;
  }
  else {
    lVar8 = *param_1;
  }
  uVar7 = uVar7 + (uVar2 - uVar5);
  if (uVar7 <= (ulonglong)(*(longlong *)(lVar8 + 0x38) + *(longlong *)(lVar8 + 0x30))) {
    if (param_1 != (longlong *)0x0) {
      lVar6 = *param_1;
    }
    if (*(ulonglong *)(lVar6 + 0x30) <= uVar7) goto LAB_1400b8ce5;
  }
  _invalid_parameter_noinfo();
LAB_1400b8ce5:
  *param_2 = (longlong)local_68;
  param_2[1] = uVar7;
  return param_2;
}

// ==== CMapGroupKernel::helper_1400b99f0  @1400b99f0  [medium:callgraph-r1]  (orig: FUN_1400b99f0)
undefined8 FUN_1400b99f0(undefined8 param_1,undefined8 param_2,longlong *param_3)

{
  longlong *plVar1;
  longlong lVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong *local_38;
  ulonglong uStack_30;
  longlong local_28;
  longlong local_20;
  
  plVar1 = (longlong *)*param_3;
  uStack_30 = param_3[1];
  lVar2 = 0;
  local_38 = plVar1;
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *plVar1;
  }
  uVar3 = uStack_30 + 1;
  if (uVar3 <= (ulonglong)(*(longlong *)(lVar4 + 0x38) + *(longlong *)(lVar4 + 0x30))) {
    if (plVar1 != (longlong *)0x0) {
      lVar2 = *plVar1;
    }
    if (*(ulonglong *)(lVar2 + 0x30) <= uVar3) goto LAB_1400b9a6d;
  }
  _invalid_parameter_noinfo();
LAB_1400b9a6d:
  local_28 = *param_3;
  local_20 = param_3[1];
  uStack_30 = uVar3;
  FUN_1400b8930(param_1,param_2,&local_28,&local_38);
  return param_2;
}

// ==== CMapGroupKernel::helper_1400c0b80  @1400c0b80  [medium:callgraph-r0]  (orig: FUN_1400c0b80)
void FUN_1400c0b80(longlong param_1,undefined4 param_2)

{
  int iVar1;
  ulonglong uVar2;
  char cVar3;
  ulong uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  int *piVar12;
  int *piVar13;
  ulonglong uVar14;
  undefined8 local_b8;
  undefined8 uStack_b0;
  uint local_a8;
  ulonglong local_a0;
  CTickAnalyst local_98 [32];
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined8 *local_58;
  undefined8 local_48;
  undefined1 local_40 [24];
  
  local_48 = 0xfffffffffffffffe;
  DAT_140975c6c = DAT_140975c6c + 1;
  plVar11 = (longlong *)0x0;
  if (2 < DAT_140975c6c) {
    DAT_140975c6c = 0;
  }
  if (DAT_140975c6c == 1) {
    CTickAnalyst::CTickAnalyst(local_98,0xe);
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    plVar11 = (longlong *)FUN_1400875f0(uVar6);
    (**(code **)(*plVar11 + 0x10))(plVar11,param_2);
    CTickAnalyst::~CTickAnalyst(local_98);
  }
  else if (DAT_140975c6c == 2) {
    CTickAnalyst::CTickAnalyst(local_98,0x16);
    uVar4 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x58) + *(int *)(param_1 + 0x5c)) <= uVar4 / 1000) {
      uVar4 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x5c) = uVar4 / 1000;
      FUN_1400923f0(param_1);
    }
    local_a8 = 0;
    uVar2 = *(ulonglong *)(param_1 + 0x48);
    local_b8 = (undefined8 *)0x0;
    if (uVar2 + *(longlong *)(param_1 + 0x50) < uVar2) {
      _invalid_parameter_noinfo();
    }
    local_b8 = *(undefined8 **)(param_1 + 0x18);
    plVar7 = plVar11;
    uStack_b0 = uVar2;
    while( true ) {
      uVar14 = uStack_b0;
      puVar10 = local_b8;
      uVar2 = *(ulonglong *)(param_1 + 0x48) + *(longlong *)(param_1 + 0x50);
      local_58 = (undefined8 *)0x0;
      if (uVar2 < *(ulonglong *)(param_1 + 0x48)) {
        _invalid_parameter_noinfo();
      }
      local_58 = *(undefined8 **)(param_1 + 0x18);
      if ((puVar10 == (undefined8 *)0x0) || (puVar10 != local_58)) {
        _invalid_parameter_noinfo();
      }
      if (uVar14 == uVar2) goto LAB_1400c177f;
      local_a8 = (int)plVar7 + 1;
      plVar7 = (longlong *)(ulonglong)local_a8;
      if (1000000 < local_a8) break;
      local_a0 = uVar14;
      if (puVar10 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar11;
        plVar9 = plVar11;
      }
      else {
        plVar8 = (longlong *)*puVar10;
        plVar9 = (longlong *)*puVar10;
      }
      if ((ulonglong)(plVar8[7] + plVar9[6]) <= uVar14) {
        _invalid_parameter_noinfo();
      }
      plVar9 = plVar11;
      if (puVar10 != (undefined8 *)0x0) {
        plVar9 = (longlong *)*puVar10;
      }
      if ((ulonglong)plVar9[5] <= uVar14) {
        plVar9 = plVar11;
        if (puVar10 != (undefined8 *)0x0) {
          plVar9 = (longlong *)*puVar10;
        }
        uVar14 = uVar14 - plVar9[5];
        local_a0 = uVar14;
      }
      plVar9 = plVar11;
      if (puVar10 != (undefined8 *)0x0) {
        plVar9 = (longlong *)*puVar10;
      }
      piVar12 = *(int **)(plVar9[4] + uVar14 * 8);
      if ((piVar12[1] == 0) ||
         (uVar4 = tq::TimeGet(0), uVar4 / 1000 < (uint)(piVar12[1] + *piVar12))) {
        FUN_1400945c0(&local_b8);
      }
      else {
        piVar12[1] = 0;
        *piVar12 = 0;
        iVar1 = piVar12[2];
        if (iVar1 == 0) {
          if (*(longlong *)(piVar12 + 10) != 0) {
            if (*(ulonglong *)(piVar12 + 0xc) < 0x10) {
              piVar13 = piVar12 + 6;
            }
            else {
              piVar13 = *(int **)(piVar12 + 6);
            }
            plVar9 = DAT_140975bf0;
            if (DAT_140975bf0 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pLuaScriptMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                 ,0x3cd);
              plVar9 = plVar11;
            }
            cVar3 = FUN_140286530(plVar9,piVar13,0,0,0,0);
            if (cVar3 == '\0') {
              if (*(ulonglong *)(piVar12 + 0xc) < 0x10) {
                piVar12 = piVar12 + 6;
              }
              else {
                piVar12 = *(int **)(piVar12 + 6);
              }
              log_InlineLogLuaERROR
                        ("Lua return fault, Call From:CMapGroup::OnTimer, lua function:%s.",piVar12)
              ;
            }
          }
        }
        else {
          uVar6 = FUN_140087730(param_1);
          FUN_140145f60(uVar6,iVar1,0,0,0,0);
        }
        local_78 = (undefined4)local_b8;
        uStack_74 = local_b8._4_4_;
        uStack_70 = (undefined4)uStack_b0;
        uStack_6c = uStack_b0._4_4_;
        puVar10 = (undefined8 *)FUN_1400b99f0(param_1 + 0x18,local_40);
        local_b8 = (undefined8 *)*puVar10;
        uStack_b0 = puVar10[1];
      }
    }
    log_InlineLogERROR(&DAT_1406d9c10,"DEAD_LOOP_BREAK","uLoopCount",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.cpp"
                       ,0x577);
LAB_1400c177f:
    CTickAnalyst::~CTickAnalyst(local_98);
  }
  else {
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x140) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pAuraMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x149);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x140);
    }
    FUN_14024dff0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x168) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pStrCheckKey",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x150);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x168);
    }
    FUN_1400fbec0(plVar7);
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    plVar7 = (longlong *)FUN_1400876b0(uVar6);
    (**(code **)(*plVar7 + 0x40))(plVar7,param_2);
    CTickAnalyst::CTickAnalyst((CTickAnalyst *)&local_78,0x14);
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    plVar7 = (longlong *)FUN_140087650(uVar6);
    (**(code **)(*plVar7 + 0x28))(plVar7,param_2);
    CTickAnalyst::~CTickAnalyst((CTickAnalyst *)&local_78);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x230) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pNpcPathTaskMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x143);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x230);
    }
    FUN_1402a7cd0(plVar7);
    if (*(longlong *)(param_1 + 0xb8) != 0) {
      FUN_14021c480(*(undefined8 *)(param_1 + 0xb8),param_2);
    }
    if (*(longlong *)(param_1 + 0xc0) != 0) {
      FUN_140221da0(*(undefined8 *)(param_1 + 0xc0),param_2);
    }
    if (*(longlong *)(param_1 + 0xd8) != 0) {
      FUN_14020bb50(*(undefined8 *)(param_1 + 0xd8),param_2);
    }
    plVar7 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x3c0);
      plVar7 = plVar11;
    }
    (**(code **)(*plVar7 + 8))(plVar7,param_2);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x100) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMagicManager",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x144);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x100);
    }
    FUN_1402ef7c0(plVar7,param_2);
    plVar7 = (longlong *)FUN_140087f50();
    (**(code **)(*plVar7 + 0x38))(plVar7,param_2);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x120) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pInstanceMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x148);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x120);
    }
    FUN_1402490f0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x138) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pTeamDiceMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x14c);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x138);
    }
    FUN_1402eb4b0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x180) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x153);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x180);
    }
    FUN_1400e1420(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x188) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pAuctionMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x154);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x188);
    }
    FUN_140231590(plVar7);
    plVar7 = DAT_140975b68;
    if (DAT_140975b68 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pAchievementMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x3c1);
      plVar7 = plVar11;
    }
    FUN_140112880(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1a8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pTrainingVitalityMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x159);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1a8);
    }
    FUN_1402e5180(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1b8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pSlotMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x15b);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1b8);
    }
    FUN_140258270(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1c0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pJiangHuMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x15c);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1c0);
    }
    FUN_1401ec0b0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1b0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pPromotionActivityMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x15a);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1b0);
    }
    FUN_1402dfbd0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1c8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOperatingActMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x15d);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1c8);
    }
    FUN_1400d64b0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1d8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pRouletteMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x15f);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1d8);
    }
    FUN_140205d20(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 400) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pDeathMarkedMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x155);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 400);
    }
    FUN_14023b280(plVar7);
    if (DAT_140975bf0 != (longlong *)0x0) {
      FUN_140286840(DAT_140975bf0);
    }
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x1f8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x163);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x1f8);
    }
    FUN_140261b80(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x108) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pTexasMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x145);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x108);
    }
    FUN_140214a10(plVar7,param_2);
    plVar7 = DAT_140975bf8;
    if (DAT_140975bf8 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pSpecialItemGen",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x3cf);
      plVar7 = plVar11;
    }
    FUN_1401d8420(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x218) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pApplyMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x167);
      plVar7 = plVar11;
    }
    else {
      plVar7 = *(longlong **)(lVar5 + 0x218);
    }
    FUN_140279da0(plVar7);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (*(longlong *)(lVar5 + 0x220) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pSignMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                         ,0x168);
    }
    else {
      plVar11 = *(longlong **)(lVar5 + 0x220);
    }
    FUN_140208ce0(plVar11);
  }
  return;
}

// ==== CMapGroupKernel::helper_1400c5510  @1400c5510  [medium:callgraph-r0]  (orig: FUN_1400c5510)
void FUN_1400c5510(longlong param_1)

{
  char cVar1;
  void *pvVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 *puVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  undefined8 *local_b8;
  undefined8 *local_b0;
  undefined8 *local_98;
  undefined8 *local_90;
  undefined8 local_78;
  undefined1 local_70 [32];
  undefined1 local_50 [40];
  
  local_78 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x198) != 0) {
    pvVar2 = *(void **)(param_1 + 0x198);
    if (pvVar2 != (void *)0x0) {
      FUN_1402a2cd0(pvVar2);
      operator_delete(pvVar2);
    }
    *(undefined8 *)(param_1 + 0x198) = 0;
  }
  puVar12 = (undefined8 *)0x0;
  FUN_14001aff0(local_50,"CMapGroup",2);
  lVar7 = FUN_140311b80();
  if (lVar7 != 0) {
    FUN_140311cd0();
  }
  if (DAT_140975bd8 != (void *)0x0) {
    operator_delete(DAT_140975bd8);
    DAT_140975bd8 = (void *)0x0;
  }
  if (*(longlong *)(param_1 + 0x240) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x240);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x240) = 0;
  }
  if (*(longlong *)(param_1 + 0x248) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x248);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x248) = 0;
  }
  if (*(longlong *)(param_1 + 0x250) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x250);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x250) = 0;
  }
  if (*(longlong *)(param_1 + 600) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 600);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 600) = 0;
  }
  if (*(longlong *)(param_1 + 0x260) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x260);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x260) = 0;
  }
  FUN_14001aff0(&local_98,"Components",3);
  if (*(longlong *)(param_1 + 0xe8) != 0) {
    FUN_14001aff0(&local_b8,"LostItemMgr",4);
    if (*(longlong *)(param_1 + 0xe8) != 0) {
      pvVar2 = *(void **)(param_1 + 0xe8);
      if (pvVar2 != (void *)0x0) {
        FUN_14010f4a0(pvVar2);
        operator_delete(pvVar2);
      }
      *(undefined8 *)(param_1 + 0xe8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xd0) != 0) {
    FUN_14001aff0(&local_b8,"NpcIncome",4);
    if (*(longlong *)(param_1 + 0xd0) != 0) {
      puVar3 = *(undefined8 **)(param_1 + 0xd0);
      FUN_140150870(puVar3);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)*puVar3)(puVar3,1);
      }
      *(undefined8 *)(param_1 + 0xd0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  FUN_1400b4f30(param_1 + 0x388);
  if (*(longlong *)(param_1 + 0xa8) != 0) {
    FUN_14001aff0(&local_b8,"GameAction",4);
    if (*(longlong *)(param_1 + 0xa8) != 0) {
      puVar3 = *(undefined8 **)(param_1 + 0xa8);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)*puVar3)(puVar3,1);
      }
      *(undefined8 *)(param_1 + 0xa8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xb0) != 0) {
    FUN_14001aff0(&local_b8,"GameConfig",4);
    if (*(longlong *)(param_1 + 0xb0) != 0) {
      FUN_140010e40(*(undefined8 *)(param_1 + 0xb0));
      *(undefined8 *)(param_1 + 0xb0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xa0) != 0) {
    FUN_14001aff0(&local_b8,"NpcManager",4);
    if (*(longlong *)(param_1 + 0xa0) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0xa0) + 8))();
      *(undefined8 *)(param_1 + 0xa0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xd8) != 0) {
    FUN_14001aff0(&local_b8,"Compete",4);
    if (*(longlong *)(param_1 + 0xd8) != 0) {
      FUN_14020a260(*(undefined8 *)(param_1 + 0xd8));
      *(undefined8 *)(param_1 + 0xd8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x90) != 0) {
    FUN_14001aff0(&local_b8,"UserManager",4);
    if (*(longlong *)(param_1 + 0x90) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x90) + 0x20))();
      *(undefined8 *)(param_1 + 0x90) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x128) != 0) {
    FUN_14001aff0(&local_b8,"SuperFlagMgr",4);
    if (*(longlong *)(param_1 + 0x128) != 0) {
      FUN_14020c6e0(*(undefined8 *)(param_1 + 0x128));
      *(undefined8 *)(param_1 + 0x128) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x130) != 0) {
    FUN_14001aff0(&local_b8,"VipTransPointMgr",4);
    if (*(longlong *)(param_1 + 0x130) != 0) {
      puVar3 = *(undefined8 **)(param_1 + 0x130);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)*puVar3)(puVar3,1);
      }
      *(undefined8 *)(param_1 + 0x130) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x88) != 0) {
    FUN_14001aff0(&local_b8,"RoleManager",4);
    if (*(longlong *)(param_1 + 0x88) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x88) + 8))();
      *(undefined8 *)(param_1 + 0x88) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x138) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x138);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x138) = 0;
  }
  if (*(longlong *)(param_1 + 0xf8) != 0) {
    FUN_14001aff0(&local_b8,"AstProfMgr",4);
    if (*(longlong *)(param_1 + 0xf8) != 0) {
      puVar3 = *(undefined8 **)(param_1 + 0xf8);
      FUN_140156080(puVar3);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)*puVar3)(puVar3,1);
      }
      *(undefined8 *)(param_1 + 0xf8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x98) != 0) {
    FUN_14001aff0(&local_b8,"MapManager",4);
    if (*(longlong *)(param_1 + 0x98) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x98) + 8))();
      *(undefined8 *)(param_1 + 0x98) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  thunk_FUN_14056f060();
  if (*(longlong *)(param_1 + 0x110) != 0) {
    puVar3 = *(undefined8 **)(param_1 + 0x110);
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    *(undefined8 *)(param_1 + 0x110) = 0;
  }
  if (*(longlong *)(param_1 + 0x108) != 0) {
    FUN_140218e20(*(undefined8 *)(param_1 + 0x108));
    *(undefined8 *)(param_1 + 0x108) = 0;
  }
  if (*(longlong *)(param_1 + 0xb8) != 0) {
    FUN_14001aff0(&local_b8,"InviteMgr",4);
    if (*(longlong *)(param_1 + 0xb8) != 0) {
      FUN_1402199b0(*(undefined8 *)(param_1 + 0xb8));
      *(undefined8 *)(param_1 + 0xb8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xc0) != 0) {
    FUN_14001aff0(&local_b8,"VipTransMgr",4);
    if (*(longlong *)(param_1 + 0xc0) != 0) {
      FUN_14021c810(*(undefined8 *)(param_1 + 0xc0));
      *(undefined8 *)(param_1 + 0xc0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 200) != 0) {
    FUN_14001aff0(&local_b8,"AchCheckMgr",4);
    if (*(longlong *)(param_1 + 200) != 0) {
      FUN_140223a10(*(undefined8 *)(param_1 + 200));
      *(undefined8 *)(param_1 + 200) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0xf0) != 0) {
    FUN_14001aff0(&local_b8,"MonsterTypeMagic",4);
    if (*(longlong *)(param_1 + 0xf0) != 0) {
      FUN_140226230(*(undefined8 *)(param_1 + 0xf0));
      *(undefined8 *)(param_1 + 0xf0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x100) != 0) {
    FUN_14001aff0(&local_b8,"MagicManager",4);
    if (*(longlong *)(param_1 + 0x100) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x100) + 0x10))();
      *(undefined8 *)(param_1 + 0x100) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x178) != 0) {
    FUN_14001aff0(&local_b8,"FacebookInfoManager",4);
    if (*(longlong *)(param_1 + 0x178) != 0) {
      FUN_140226be0(*(undefined8 *)(param_1 + 0x178));
      *(undefined8 *)(param_1 + 0x178) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x188) != 0) {
    FUN_14001aff0(&local_b8,"AuctionMgr",4);
    if (*(longlong *)(param_1 + 0x188) != 0) {
      FUN_14022afd0(*(undefined8 *)(param_1 + 0x188));
      *(undefined8 *)(param_1 + 0x188) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 400) != 0) {
    FUN_14001aff0(&local_b8,"DeathMarkedMgr",4);
    if (*(longlong *)(param_1 + 400) != 0) {
      FUN_140234130(*(undefined8 *)(param_1 + 400));
      *(undefined8 *)(param_1 + 400) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x118) != 0) {
    FUN_14001aff0(&local_b8,"TransportorMgr",4);
    if (*(longlong *)(param_1 + 0x118) != 0) {
      FUN_14023bc40(*(undefined8 *)(param_1 + 0x118));
      *(undefined8 *)(param_1 + 0x118) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x120) != 0) {
    FUN_14001aff0(&local_b8,"InstanceMgr",4);
    if (*(longlong *)(param_1 + 0x120) != 0) {
      FUN_14023e950(*(undefined8 *)(param_1 + 0x120));
      *(undefined8 *)(param_1 + 0x120) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x150) != 0) {
    FUN_14001aff0(&local_b8,"SynDomainMgr",4);
    if (*(longlong *)(param_1 + 0x150) != 0) {
      FUN_14024ba60(*(undefined8 *)(param_1 + 0x150));
      *(undefined8 *)(param_1 + 0x150) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x140) != 0) {
    FUN_14001aff0(&local_b8,"AuraMgr",4);
    if (*(longlong *)(param_1 + 0x140) != 0) {
      FUN_14024c780(*(undefined8 *)(param_1 + 0x140));
      *(undefined8 *)(param_1 + 0x140) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x168) != 0) {
    FUN_14001aff0(&local_b8,"StrCheckKey",4);
    if (*(longlong *)(param_1 + 0x168) != 0) {
      FUN_1400fce20(*(undefined8 *)(param_1 + 0x168));
      *(undefined8 *)(param_1 + 0x168) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x170) != 0) {
    FUN_14001aff0(&local_b8,"DBDataPrepare",4);
    if (*(longlong *)(param_1 + 0x170) != 0) {
      (**(code **)(**(longlong **)(param_1 + 0x170) + 8))();
      *(undefined8 *)(param_1 + 0x170) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x180) != 0) {
    FUN_14001aff0(&local_b8,"MailMgr",4);
    if (*(longlong *)(param_1 + 0x180) != 0) {
      FUN_1400e1660(*(undefined8 *)(param_1 + 0x180));
      *(undefined8 *)(param_1 + 0x180) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1a8) != 0) {
    FUN_14001aff0(&local_b8,"TrainingVitalityMgr",4);
    FUN_1402e63f0(*(undefined8 *)(param_1 + 0x1a8));
    *(undefined8 *)(param_1 + 0x1a8) = 0;
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1b0) != 0) {
    FUN_14001aff0(&local_b8,"PromotionActivityMgr",4);
    FUN_1402e0af0(*(undefined8 *)(param_1 + 0x1b0));
    *(undefined8 *)(param_1 + 0x1b0) = 0;
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1b8) != 0) {
    FUN_14001aff0(&local_b8,"SlotMgr",4);
    if (*(longlong *)(param_1 + 0x1b8) != 0) {
      FUN_140253a70(*(undefined8 *)(param_1 + 0x1b8));
      *(undefined8 *)(param_1 + 0x1b8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1c0) != 0) {
    FUN_14001aff0(&local_b8,"CJiangHuMgr",4);
    if (*(longlong *)(param_1 + 0x1c0) != 0) {
      FUN_1401f17f0(*(undefined8 *)(param_1 + 0x1c0));
      *(undefined8 *)(param_1 + 0x1c0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1c8) != 0) {
    FUN_14001aff0(&local_b8,"COperatingActMgr",4);
    if (*(longlong *)(param_1 + 0x1c8) != 0) {
      FUN_1400d4870(*(undefined8 *)(param_1 + 0x1c8));
      *(undefined8 *)(param_1 + 0x1c8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1d0) != 0) {
    FUN_14001aff0(&local_b8,"m_pInnerStrengthMgr",4);
    if (*(longlong *)(param_1 + 0x1d0) != 0) {
      FUN_1401f4e20(*(undefined8 *)(param_1 + 0x1d0));
      *(undefined8 *)(param_1 + 0x1d0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1d8) != 0) {
    FUN_14001aff0(&local_b8,"CRouletteMgr",4);
    if (*(longlong *)(param_1 + 0x1d8) != 0) {
      FUN_1402085d0(*(undefined8 *)(param_1 + 0x1d8));
      *(undefined8 *)(param_1 + 0x1d8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1e8) != 0) {
    FUN_14001aff0(&local_b8,"CItemOSLimitMgr",4);
    if (*(longlong *)(param_1 + 0x1e8) != 0) {
      FUN_1402585d0(*(undefined8 *)(param_1 + 0x1e8));
      *(undefined8 *)(param_1 + 0x1e8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1f0) != 0) {
    FUN_14001aff0(&local_b8,"CTaskRewardMgr",4);
    if (*(longlong *)(param_1 + 0x1f0) != 0) {
      FUN_14025c9a0(*(undefined8 *)(param_1 + 0x1f0));
      *(undefined8 *)(param_1 + 0x1f0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1f8) != 0) {
    FUN_14001aff0(&local_b8,"CActivityMgr",4);
    if (*(longlong *)(param_1 + 0x1f8) != 0) {
      FUN_140260850(*(undefined8 *)(param_1 + 0x1f8));
      *(undefined8 *)(param_1 + 0x1f8) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x208) != 0) {
    FUN_14001aff0(&local_b8,"COSSyndicateMgr",4);
    if (*(longlong *)(param_1 + 0x208) != 0) {
      FUN_140264e90(*(undefined8 *)(param_1 + 0x208));
      *(undefined8 *)(param_1 + 0x208) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x1e0) != 0) {
    FUN_14001aff0(&local_b8,"CMainProcedure",4);
    if (*(longlong *)(param_1 + 0x1e0) != 0) {
      pvVar2 = *(void **)(param_1 + 0x1e0);
      if (pvVar2 != (void *)0x0) {
        FUN_14001d110(pvVar2);
        operator_delete(pvVar2);
      }
      *(undefined8 *)(param_1 + 0x1e0) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x200) != 0) {
    FUN_14001aff0(&local_b8,"m_pProcessGoalMgr",4);
    if (*(longlong *)(param_1 + 0x200) != 0) {
      FUN_14026a760(*(undefined8 *)(param_1 + 0x200));
      *(undefined8 *)(param_1 + 0x200) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  if (*(longlong *)(param_1 + 0x220) != 0) {
    FUN_14001aff0(&local_b8,"CSignMgr",4);
    if (*(longlong *)(param_1 + 0x220) != 0) {
      FUN_14020a040(*(undefined8 *)(param_1 + 0x220));
      *(undefined8 *)(param_1 + 0x220) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  FUN_14001b030(&local_98);
  if (*(longlong *)(param_1 + 0x228) != 0) {
    FUN_14001aff0(&local_b8,"Adapter",3);
    if (*(longlong *)(param_1 + 0x228) != 0) {
      operator_delete(*(void **)(param_1 + 0x228));
      *(undefined8 *)(param_1 + 0x228) = 0;
    }
    FUN_14001b030(&local_b8);
  }
  FUN_14001aff0(&local_b8,"NpcPathManager",3);
  FUN_140315170();
  FUN_14001b030(&local_b8);
  if (*(longlong *)(param_1 + 0x230) != 0) {
    pvVar2 = *(void **)(param_1 + 0x230);
    if (pvVar2 != (void *)0x0) {
      FUN_1402a7250(pvVar2);
      operator_delete(pvVar2);
    }
    *(undefined8 *)(param_1 + 0x230) = 0;
  }
  if (*(int *)(param_1 + 0x68) == 0xe) {
    FUN_14001aff0(local_70,"Const Objects",3);
    FUN_14001aff0(&local_b8,"BattleEffect",4);
    FUN_14031d330();
    FUN_14001b030(&local_b8);
    if (DAT_140975ba8 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"Rebirth",4);
      if (DAT_140975ba8 != (longlong *)0x0) {
        (**(code **)(*DAT_140975ba8 + 0x10))();
        DAT_140975ba8 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975ba0 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"MonsterType",4);
      if (DAT_140975ba0 != (longlong *)0x0) {
        (**(code **)(*DAT_140975ba0 + 0x10))();
        DAT_140975ba0 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975b98 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"TrapType",4);
      if (DAT_140975b98 != (longlong *)0x0) {
        (**(code **)(*DAT_140975b98 + 0x10))();
        DAT_140975b98 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975b90 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"AddPoint",4);
      if (DAT_140975b90 != (longlong *)0x0) {
        (**(code **)(*DAT_140975b90 + 0x10))();
        DAT_140975b90 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    puVar3 = DAT_140975be0;
    if ((DAT_140975be0 != (undefined8 *)0x0) && (DAT_140975be0 != (undefined8 *)0x0)) {
      FUN_14014d470(DAT_140975be0);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)*puVar3)(puVar3,1);
      }
      DAT_140975be0 = (undefined8 *)0x0;
    }
    if (DAT_140975b88 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"Action",4);
      if (DAT_140975b88 != (longlong *)0x0) {
        (**(code **)(*DAT_140975b88 + 0x10))();
        DAT_140975b88 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975b80 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,&DAT_1406fca1c,4);
      if (DAT_140975b80 != (longlong *)0x0) {
        (**(code **)(*DAT_140975b80 + 0x10))();
        DAT_140975b80 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975b78 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"StaticMap",4);
      if (DAT_140975b78 != (longlong *)0x0) {
        (**(code **)(*DAT_140975b78 + 0x10))();
        DAT_140975b78 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975b60 != (undefined8 *)0x0) {
      (**(code **)*DAT_140975b60)(DAT_140975b60,1);
      DAT_140975b60 = (undefined8 *)0x0;
    }
    if ((DAT_140975bf8 != 0) && (DAT_140975bf8 != 0)) {
      FUN_1401d7ed0();
      DAT_140975bf8 = 0;
    }
    if ((DAT_140975b68 != (undefined8 *)0x0) && (DAT_140975b68 != (undefined8 *)0x0)) {
      (**(code **)*DAT_140975b68)(DAT_140975b68,1);
      DAT_140975b68 = (undefined8 *)0x0;
    }
    if ((DAT_140975b70 != 0) && (DAT_140975b70 != 0)) {
      FUN_140117390();
      DAT_140975b70 = 0;
    }
    if (*(longlong *)(param_1 + 0x158) != 0) {
      FUN_14026aa40(*(undefined8 *)(param_1 + 0x158));
      *(undefined8 *)(param_1 + 0x158) = 0;
    }
    if (*(longlong *)(param_1 + 0x1a0) != 0) {
      FUN_140271420(*(undefined8 *)(param_1 + 0x1a0));
      *(undefined8 *)(param_1 + 0x1a0) = 0;
    }
    if (*(longlong *)(param_1 + 0x160) != 0) {
      FUN_140272200(*(undefined8 *)(param_1 + 0x160));
      *(undefined8 *)(param_1 + 0x160) = 0;
    }
    if (DAT_140975bb8 != 0) {
      FUN_14001aff0(&local_b8,"EMoneyCardCfg",4);
      if (DAT_140975bb8 != 0) {
        FUN_140276730();
        DAT_140975bb8 = 0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975bc8 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"Props",4);
      if (DAT_140975bc8 != (longlong *)0x0) {
        (**(code **)(*DAT_140975bc8 + 0x10))();
        DAT_140975bc8 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975be8 != (longlong *)0x0) {
      FUN_14001aff0(&local_b8,"ExchangeBuy",4);
      if (DAT_140975be8 != (longlong *)0x0) {
        (**(code **)(*DAT_140975be8 + 0x10))();
        DAT_140975be8 = (longlong *)0x0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975bd0 != 0) {
      FUN_14001aff0(&local_b8,"CheatRemitCfg",4);
      if (DAT_140975bd0 != 0) {
        FUN_140277d70();
        DAT_140975bd0 = 0;
      }
      FUN_14001b030(&local_b8);
    }
    if (*(longlong *)(param_1 + 0x218) != 0) {
      FUN_14001aff0(&local_b8,"m_pApplyMgr",4);
      if (*(longlong *)(param_1 + 0x218) != 0) {
        FUN_140278ff0(*(undefined8 *)(param_1 + 0x218));
        *(undefined8 *)(param_1 + 0x218) = 0;
      }
      FUN_14001b030(&local_b8);
    }
    if (DAT_140975bf0 != 0) {
      FUN_14001aff0(&local_b8,"CLuaScriptMgr",4);
      if (DAT_140975bf0 != 0) {
        FUN_14027aed0();
        DAT_140975bf0 = 0;
      }
      FUN_14001b030(&local_b8);
    }
    FUN_14001aff0(&local_98,"Others",4);
    if (DAT_140975bb0 != (undefined8 *)0x0) {
      (**(code **)*DAT_140975bb0)(DAT_140975bb0,1);
      DAT_140975bb0 = (undefined8 *)0x0;
    }
    if (DAT_140975bc0 != (longlong *)0x0) {
      (**(code **)(*DAT_140975bc0 + 0x10))();
      DAT_140975bc0 = (longlong *)0x0;
    }
    FUN_14001b030(&local_98);
    FUN_14001b030(local_70);
  }
  plVar4 = *(longlong **)(param_1 + 0x4f0);
  plVar8 = (longlong *)*plVar4;
  *plVar4 = (longlong)plVar4;
  *(longlong *)(*(longlong *)(param_1 + 0x4f0) + 8) = *(longlong *)(param_1 + 0x4f0);
  *(undefined8 *)(param_1 + 0x4f8) = 0;
  if (plVar8 != *(longlong **)(param_1 + 0x4f0)) {
    do {
      plVar4 = (longlong *)*plVar8;
      operator_delete(plVar8);
      plVar8 = plVar4;
    } while (plVar4 != (longlong *)*(longlong *)(param_1 + 0x4f0));
  }
  local_b0 = *(undefined8 **)(param_1 + 0x4f0);
  local_b8 = puVar12;
  if (*(undefined8 **)(param_1 + 0x4c8) != (undefined8 *)0x0) {
    local_b8 = (undefined8 *)**(undefined8 **)(param_1 + 0x4c8);
  }
  local_b8 = (undefined8 *)*local_b8;
  FUN_1400c0570(param_1 + 0x500,9,&local_b8);
  *(undefined8 *)(param_1 + 0x530) = 7;
  *(undefined8 *)(param_1 + 0x538) = 8;
  lVar9 = *(longlong *)(param_1 + 0x288) - *(longlong *)(param_1 + 0x280);
  lVar7 = lVar9 >> 0x3f;
  if (lVar9 / 0x30 + lVar7 != lVar7) {
    uVar11 = *(ulonglong *)(param_1 + 0x280);
    if (*(ulonglong *)(param_1 + 0x288) < uVar11) {
      _invalid_parameter_noinfo();
    }
    puVar3 = *(undefined8 **)(param_1 + 0x268);
    uVar5 = *(ulonglong *)(param_1 + 0x288);
    if (uVar5 < *(ulonglong *)(param_1 + 0x280)) {
      _invalid_parameter_noinfo();
    }
    puVar10 = *(undefined8 **)(param_1 + 0x268);
    while( true ) {
      if ((puVar3 == (undefined8 *)0x0) || (puVar3 != puVar10)) {
        _invalid_parameter_noinfo();
      }
      if (uVar11 == uVar5) break;
      if (puVar3 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        puVar13 = puVar12;
      }
      else {
        puVar13 = (undefined8 *)*puVar3;
      }
      if ((ulonglong)puVar13[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      lVar9 = *(longlong *)(uVar11 + 0x20) - *(longlong *)(uVar11 + 0x18);
      lVar7 = lVar9 >> 0x3f;
      if (lVar9 / 0x28 + lVar7 != lVar7) {
        if (puVar3 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          puVar13 = puVar12;
        }
        else {
          puVar13 = (undefined8 *)*puVar3;
        }
        if ((ulonglong)puVar13[4] <= uVar11) {
          _invalid_parameter_noinfo();
        }
        FUN_140037e80(uVar11);
      }
      if (puVar3 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        puVar13 = puVar12;
      }
      else {
        puVar13 = (undefined8 *)*puVar3;
      }
      if ((ulonglong)puVar13[4] <= uVar11) {
        _invalid_parameter_noinfo();
      }
      uVar11 = uVar11 + 0x30;
    }
    FUN_1400667c0(param_1 + 0x268);
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x3f0) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x21);
  while (cVar1 == '\0') {
    FUN_140015820(param_1 + 0x3c0,plVar4[2]);
    plVar8 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar8;
    cVar1 = *(char *)((longlong)plVar8 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x3f0) + 8) = *(longlong *)(param_1 + 0x3f0);
  *(undefined8 *)(param_1 + 0x3f8) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x3f0) = *(undefined8 *)(param_1 + 0x3f0);
  *(longlong *)(*(longlong *)(param_1 + 0x3f0) + 0x10) = *(longlong *)(param_1 + 0x3f0);
  puVar3 = *(undefined8 **)(param_1 + 0x830);
  puVar10 = (undefined8 *)*puVar3;
  puVar13 = *(undefined8 **)(param_1 + 0x800);
  local_b8 = puVar13;
  local_b0 = puVar3;
  local_98 = puVar13;
  local_90 = puVar10;
  while( true ) {
    if (puVar13 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar10 == puVar3) break;
    if (puVar13 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      puVar14 = puVar12;
    }
    else {
      puVar14 = (undefined8 *)*puVar13;
    }
    if (puVar10 == (undefined8 *)puVar14[6]) {
      _invalid_parameter_noinfo();
    }
    if ((longlong *)puVar10[4] != (longlong *)0x0) {
      (**(code **)(*(longlong *)puVar10[4] + 0x58))();
    }
    if (puVar13 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar10 + 0x29) == '\0') {
      puVar14 = (undefined8 *)puVar10[2];
      if (*(char *)((longlong)puVar14 + 0x29) == '\0') {
        cVar1 = *(char *)((longlong)*puVar14 + 0x29);
        puVar10 = puVar14;
        puVar14 = (undefined8 *)*puVar14;
        while (local_90 = puVar10, cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar14 + 0x29);
          puVar10 = puVar14;
          puVar14 = (undefined8 *)*puVar14;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar10[1] + 0x29);
        puVar6 = (undefined8 *)puVar10[1];
        puVar14 = puVar10;
        while ((puVar10 = puVar6, local_90 = puVar10, cVar1 == '\0' &&
               (puVar14 == (undefined8 *)puVar10[2]))) {
          cVar1 = *(char *)((longlong)puVar10[1] + 0x29);
          puVar6 = (undefined8 *)puVar10[1];
          puVar14 = puVar10;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  if (*(longlong *)(param_1 + 0x148) != 0) {
    FUN_140005820(*(undefined8 *)(param_1 + 0x148));
    *(undefined8 *)(param_1 + 0x148) = 0;
  }
  if (*(longlong *)(param_1 + 0x210) != 0) {
    FUN_14001aff0(local_70,"m_pRecPoolMgr",4);
    if (*(longlong *)(param_1 + 0x210) != 0) {
      FUN_14028f960(*(undefined8 *)(param_1 + 0x210));
      *(undefined8 *)(param_1 + 0x210) = 0;
    }
    FUN_14001b030(local_70);
  }
  FUN_14001b030(local_50);
  return;
}

// ==== CMapGroupKernel::helper_1400c8c20  @1400c8c20  [medium:callgraph-r3]  (orig: FUN_1400c8c20)
longlong FUN_1400c8c20(longlong *param_1)

{
  ulonglong uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  uVar1 = param_1[1];
  plVar2 = (longlong *)*param_1;
  lVar5 = 0;
  uVar6 = uVar1 >> 1;
  lVar3 = lVar5;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    plVar2 = (longlong *)*param_1;
    lVar4 = lVar5;
    if (plVar2 == (longlong *)0x0) goto LAB_1400c8c6f;
  }
  lVar4 = *plVar2;
  if (plVar2 != (longlong *)0x0) {
    lVar3 = lVar4;
  }
LAB_1400c8c6f:
  if ((ulonglong)(*(longlong *)(lVar3 + 0x38) + *(longlong *)(lVar4 + 0x30)) <=
      (ulonglong)param_1[1]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = lVar5;
  if (param_1 != (longlong *)0x0) {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x28) <= uVar6) {
    lVar3 = lVar5;
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    uVar6 = uVar6 - *(longlong *)(lVar3 + 0x28);
  }
  if (param_1 != (longlong *)0x0) {
    lVar5 = *param_1;
  }
  return *(longlong *)(*(longlong *)(lVar5 + 0x20) + uVar6 * 8) + (ulonglong)((uint)uVar1 & 1) * 8;
}

// ==== CMapGroupKernel::helper_1400d1740  @1400d1740  [medium:callgraph-r3]  (orig: FUN_1400d1740)
undefined4 FUN_1400d1740(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  undefined8 *puVar11;
  undefined8 *puVar12;
  longlong lVar13;
  bool bVar14;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else {
    iVar4 = FUN_1400c7ac0(param_2);
    uVar5 = FUN_1400c7be0(param_2);
    uVar6 = FUN_1400c7b20(param_2);
    *(int *)(param_1 + 0x1a4) = *(int *)(param_1 + 0x1a4) + 1;
    if ((iVar4 == 0) || (uVar6 == 0)) {
      log_InlineLogERROR(
                        "COperatingActMgr::ProcessAutoGivePrizeAsynch data err, user id:%u, act id:%u."
                        );
      uVar7 = 0;
    }
    else if (uVar5 == 0) {
      FUN_1400c7ca0(param_1,param_2);
      uVar7 = 1;
    }
    else {
      cVar2 = FUN_1400c7c40(param_2);
      cVar2 = cVar2 + '\x01';
      uVar8 = 0;
LAB_1400d1820:
      do {
        uVar8 = uVar8 + 1;
        if (2000 < uVar8) {
          log_InlineLogERROR(&DAT_1406d9c10);
LAB_1400d1b24:
          FUN_1400c7ca0(param_1,param_2);
          return 1;
        }
        puVar11 = *(undefined8 **)(param_1 + 0x78);
        puVar12 = (undefined8 *)puVar11[1];
        puVar10 = puVar11;
        while (puVar9 = puVar12, *(char *)((longlong)puVar9 + 0x29) == '\0') {
          if (*(uint *)(puVar9 + 3) < uVar6) {
            puVar12 = (undefined8 *)puVar9[2];
          }
          else {
            if ((*(char *)((longlong)puVar11 + 0x29) != '\0') && (uVar6 < *(uint *)(puVar9 + 3))) {
              puVar11 = puVar9;
            }
            puVar12 = (undefined8 *)*puVar9;
            puVar10 = puVar9;
          }
        }
        if (*(char *)((longlong)puVar11 + 0x29) == '\0') {
          puVar12 = (undefined8 *)*puVar11;
        }
        else {
          puVar12 = *(undefined8 **)(*(longlong *)(param_1 + 0x78) + 8);
        }
        while (puVar9 = puVar12, *(char *)((longlong)puVar9 + 0x29) == '\0') {
          if (uVar6 < *(uint *)(puVar9 + 3)) {
            puVar12 = (undefined8 *)*puVar9;
            puVar11 = puVar9;
          }
          else {
            puVar12 = (undefined8 *)puVar9[2];
          }
        }
        if ((longlong *)(param_1 + 0x48) == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        plVar1 = *(longlong **)(param_1 + 0x48);
LAB_1400d1996:
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar10 == puVar11) goto LAB_1400d1b24;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar13 = 0;
        }
        else {
          lVar13 = *plVar1;
        }
        if (puVar10 == *(undefined8 **)(lVar13 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar13 = puVar10[4];
        if (((lVar13 == 0) || (*(char *)(lVar13 + 0xc) != cVar2)) ||
           (uVar5 < *(uint *)(lVar13 + 0x10))) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar10 + 0x29) == '\0') {
            puVar12 = puVar10;
            puVar9 = (undefined8 *)puVar10[2];
            if (*(char *)((longlong)puVar10[2] + 0x29) == '\0') {
              do {
                puVar10 = puVar9;
                puVar9 = (undefined8 *)*puVar10;
              } while (*(char *)((longlong)*puVar10 + 0x29) == '\0');
            }
            else {
              do {
                puVar10 = (undefined8 *)puVar12[1];
                if (*(char *)((longlong)puVar10 + 0x29) != '\0') break;
                bVar14 = puVar12 == (undefined8 *)puVar10[2];
                puVar12 = puVar10;
              } while (bVar14);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          goto LAB_1400d1996;
        }
        FUN_14032a1e0(param_2,cVar2,0);
        cVar2 = cVar2 + '\x01';
        *(int *)(param_1 + 0x1a4) = *(int *)(param_1 + 0x1a4) + 1;
        cVar3 = FUN_1400c9de0(param_1,iVar4,*(undefined4 *)(lVar13 + 8),
                              *(char *)(lVar13 + 0x14) != '\0');
        if (cVar3 == '\0') {
          log_InlineLogERROR(
                            "COperatingActMgr::ProcessAutoGivePrizeAsynch ProcessGivePrizeByMailAsyn failed, user id:%u, item type:%u, act id:%u, reward grade:%d."
                            );
          goto LAB_1400d1820;
        }
      } while (*(int *)(param_1 + 0x1a4) < 10);
      uVar7 = 2;
    }
  }
  return uVar7;
}

// ==== CMapGroupKernel::helper_1400d39d0  @1400d39d0  [medium:callgraph-r1]  (orig: FUN_1400d39d0)
void FUN_1400d39d0(longlong param_1,longlong param_2)

{
  ulonglong *puVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  uint uVar11;
  bool bVar13;
  longlong *plStack_c0;
  ulonglong *local_88;
  longlong *plStack_80;
  ulonglong *local_78;
  ulonglong *local_68;
  longlong *plStack_60;
  undefined1 local_58 [16];
  undefined1 local_48 [32];
  ulonglong uVar12;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_14032ab60(param_2,2);
    cVar5 = FUN_1400c7820(param_2);
    if (cVar5 != '\x05') {
      iVar6 = FUN_1400c77c0(param_2);
      if (iVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar9 = (longlong *)**(longlong **)(param_1 + 0xb8);
        puVar1 = *(ulonglong **)(param_1 + 0x88);
        uVar12 = 0;
        plStack_c0 = plVar9;
LAB_1400d3ad0:
        plVar4 = plStack_c0;
        plVar8 = *(longlong **)(param_1 + 0xb8);
        local_78 = *(ulonglong **)(param_1 + 0x88);
        if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_78)) {
          _invalid_parameter_noinfo();
        }
        if (plVar9 == plVar8) {
          return;
        }
        uVar11 = (int)uVar12 + 1;
        uVar12 = (ulonglong)uVar11;
        if (uVar11 < 0x186a1) {
          if (puVar1 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar10 = 0;
          }
          else {
            uVar10 = *puVar1;
          }
          if (plVar9 == *(longlong **)(uVar10 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar2 = plVar9[4];
          if (lVar2 == 0) {
            if (puVar1 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
              plVar8 = plVar9;
              plVar3 = (longlong *)plVar9[2];
              if (*(char *)(plVar9[2] + 0x29) == '\0') {
                do {
                  plVar9 = plVar3;
                  plVar3 = (longlong *)*plVar9;
                  plStack_c0 = plVar9;
                } while (*(char *)(*plVar9 + 0x29) == '\0');
              }
              else {
                do {
                  plVar9 = (longlong *)plVar8[1];
                  plStack_c0 = plVar9;
                  if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                  bVar13 = plVar8 == (longlong *)plVar9[2];
                  plVar8 = plVar9;
                } while (bVar13);
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
            plStack_60 = plVar4;
            local_68 = puVar1;
            FUN_1400cfdc0(param_1 + 0x88,local_58,&local_68);
          }
          else {
            iVar7 = FUN_1400c7b20(lVar2);
            if (iVar6 == iVar7) {
              FUN_1400d1b70(param_1,lVar2);
              FUN_14032aa50(lVar2);
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                plVar8 = plVar9;
                plVar3 = (longlong *)plVar9[2];
                if (*(char *)(plVar9[2] + 0x29) == '\0') {
                  do {
                    plVar9 = plVar3;
                    plVar3 = (longlong *)*plVar9;
                    plStack_c0 = plVar9;
                  } while (*(char *)(*plVar9 + 0x29) == '\0');
                }
                else {
                  do {
                    plVar9 = (longlong *)plVar8[1];
                    plStack_c0 = plVar9;
                    if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                    bVar13 = plVar8 == (longlong *)plVar9[2];
                    plVar8 = plVar9;
                  } while (bVar13);
                }
              }
              else {
                _invalid_parameter_noinfo();
              }
              plStack_80 = plVar4;
              local_88 = puVar1;
              FUN_1400cfdc0(param_1 + 0x88,local_48,&local_88);
            }
            else {
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
              }
              if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                plVar8 = plVar9;
                plVar4 = (longlong *)plVar9[2];
                if (*(char *)(plVar9[2] + 0x29) == '\0') {
                  do {
                    plVar9 = plVar4;
                    plVar4 = (longlong *)*plVar9;
                    plStack_c0 = plVar9;
                  } while (*(char *)(*plVar9 + 0x29) == '\0');
                }
                else {
                  do {
                    plVar9 = (longlong *)plVar8[1];
                    plStack_c0 = plVar9;
                    if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                    bVar13 = plVar8 == (longlong *)plVar9[2];
                    plVar8 = plVar9;
                  } while (bVar13);
                }
              }
              else {
                _invalid_parameter_noinfo();
              }
            }
          }
          goto LAB_1400d3ad0;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400d3d90  @1400d3d90  [medium:callgraph-r2]  (orig: FUN_1400d3d90)
void FUN_1400d3d90(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  int iVar3;
  longlong *plVar4;
  undefined8 uVar5;
  undefined8 local_20;
  ulonglong local_18;
  
  uVar5 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x180) != 0) {
    *(undefined4 *)(param_1 + 0x1a4) = 0;
    while ((*(int *)(param_1 + 0x1a4) < 0xb && (*(longlong *)(param_1 + 0x180) != 0))) {
      uVar1 = *(ulonglong *)(param_1 + 0x178);
      if (uVar1 + *(longlong *)(param_1 + 0x180) < uVar1) {
        _invalid_parameter_noinfo();
      }
      local_20 = *(undefined8 *)(param_1 + 0x148);
      local_18 = uVar1;
      plVar4 = (longlong *)FUN_1400c8c20(&local_20);
      lVar2 = *plVar4;
      if (lVar2 == 0) {
        if (*(longlong *)(param_1 + 0x180) != 0) {
          *(longlong *)(param_1 + 0x178) = *(longlong *)(param_1 + 0x178) + 1;
          if ((ulonglong)(*(longlong *)(param_1 + 0x170) * 2) <= *(ulonglong *)(param_1 + 0x178)) {
            *(undefined8 *)(param_1 + 0x178) = 0;
          }
          lVar2 = *(longlong *)(param_1 + 0x180) + -1;
          *(longlong *)(param_1 + 0x180) = lVar2;
          if (lVar2 == 0) {
            *(undefined8 *)(param_1 + 0x178) = 0;
          }
        }
      }
      else {
        iVar3 = FUN_1400d1740(param_1,lVar2,param_3,param_4,uVar5);
        if (iVar3 != 2) {
          FUN_14032aa50(lVar2);
          if (*(longlong *)(param_1 + 0x180) != 0) {
            *(longlong *)(param_1 + 0x178) = *(longlong *)(param_1 + 0x178) + 1;
            if ((ulonglong)(*(longlong *)(param_1 + 0x170) * 2) <= *(ulonglong *)(param_1 + 0x178))
            {
              *(undefined8 *)(param_1 + 0x178) = 0;
            }
            lVar2 = *(longlong *)(param_1 + 0x180) + -1;
            *(longlong *)(param_1 + 0x180) = lVar2;
            if (lVar2 == 0) {
              *(undefined8 *)(param_1 + 0x178) = 0;
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400d48b0  @1400d48b0  [medium:callgraph-r0]  (orig: FUN_1400d48b0)
undefined8 FUN_1400d48b0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar1 = *(longlong **)(param_1 + 8);
  plVar2 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar2;
          plVar2 = *(longlong **)(param_1 + 0x38);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar2) {
            return 1;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar6 = plVar5[4];
          if (lVar6 != 0) {
            cVar3 = FUN_14032ac40(lVar6);
            if (cVar3 == '\0') {
              cVar3 = FUN_14032ad90(lVar6);
              if (cVar3 != '\0') {
                FUN_1400d39d0(param_1,lVar6);
              }
            }
            else {
              FUN_14032ab60(lVar6,1);
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar2 = plVar5;
        }
        plVar2 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar2 + 0x29) != '\0') break;
        cVar3 = *(char *)(*plVar2 + 0x29);
        plVar5 = (longlong *)*plVar2;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar5 + 0x29);
          plVar2 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar2 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar2 + 0x29) != '\0');
    do {
      plVar4 = plVar2;
      plVar2 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar2 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar2 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_1400d5040  @1400d5040  [medium:callgraph-r3]  (orig: FUN_1400d5040)
void FUN_1400d5040(undefined8 param_1,longlong param_2,char param_3)

{
  char cVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar1 = FUN_14032ac40(param_2);
    if (cVar1 != '\0') {
      if (param_3 == '\0') {
        FUN_1400d35b0(param_1,param_2);
        FUN_14032ab60(param_2,1);
      }
      else {
        FUN_14032ab60(param_2,1);
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400d50f0  @1400d50f0  [medium:callgraph-r3]  (orig: FUN_1400d50f0)
void FUN_1400d50f0(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  uint uVar11;
  bool bVar12;
  undefined4 local_res18 [2];
  int local_res20;
  longlong *plStack_120;
  longlong local_110;
  longlong *local_108;
  longlong *local_100;
  longlong *local_f8;
  longlong *local_f0;
  longlong *local_e8 [4];
  longlong *local_c8;
  longlong *plStack_c0;
  longlong *local_b8;
  longlong *plStack_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  undefined8 local_98;
  undefined8 local_90;
  longlong *local_88;
  longlong *plStack_80;
  undefined1 local_78 [16];
  undefined1 local_68 [16];
  undefined1 local_58 [32];
  
  local_a8 = 0xfffffffffffffffe;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar4 = FUN_14032ad90(param_2);
    if (cVar4 != '\0') {
      iVar5 = FUN_1400c77c0(param_2);
      local_res20 = iVar5;
      if (iVar5 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        FUN_14032ab60(param_2,2);
        cVar4 = FUN_1400c7820(param_2);
        if (cVar4 != '\x05') {
          FUN_1400c77c0(param_2);
          uVar11 = 0;
          plVar9 = (longlong *)**(longlong **)(param_1 + 0xb8);
          plVar1 = *(longlong **)(param_1 + 0x88);
          plStack_120 = plVar9;
LAB_1400d5200:
          plVar3 = plStack_120;
          lVar10 = 0;
          plVar8 = *(longlong **)(param_1 + 0xb8);
          local_e8[0] = *(longlong **)(param_1 + 0x88);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_e8[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar9 == plVar8) {
            return;
          }
          uVar11 = uVar11 + 1;
          if (uVar11 < 0x186a1) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar10 = *plVar1;
            }
            if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            lVar10 = plVar9[4];
            local_110 = lVar10;
            if (lVar10 == 0) {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
              }
              if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                plVar8 = plVar9;
                plVar2 = (longlong *)plVar9[2];
                if (*(char *)(plVar9[2] + 0x29) == '\0') {
                  do {
                    plVar9 = plVar2;
                    plVar2 = (longlong *)*plVar9;
                    plStack_120 = plVar9;
                    local_f0 = plVar9;
                  } while (*(char *)(*plVar9 + 0x29) == '\0');
                }
                else {
                  do {
                    plVar9 = (longlong *)plVar8[1];
                    plStack_120 = plVar9;
                    if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                    bVar12 = plVar8 == (longlong *)plVar9[2];
                    plVar8 = plVar9;
                  } while (bVar12);
                }
              }
              else {
                _invalid_parameter_noinfo();
              }
              plStack_80 = plVar3;
              local_88 = plVar1;
              FUN_1400cfdc0(param_1 + 0x88,local_78,&local_88);
            }
            else {
              iVar6 = FUN_1400c7b20(lVar10);
              if (iVar5 == iVar6) {
                tq::TimeGet(1);
                local_a0 = 0;
                local_res18[0] = FUN_1400c7a60(lVar10);
                puVar7 = (undefined8 *)FUN_14000d480(param_1 + 0x108,local_e8,local_res18);
                local_a0 = *puVar7;
                local_98 = puVar7[1];
                local_90 = puVar7[2];
                if ((char)local_90 == '\0') {
                  FUN_14032aa50(lVar10);
                  local_110 = 0;
                  if (plVar1 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                    plVar8 = plVar9;
                    plVar2 = (longlong *)plVar9[2];
                    if (*(char *)(plVar9[2] + 0x29) == '\0') {
                      do {
                        plVar9 = plVar2;
                        plVar2 = (longlong *)*plVar9;
                        plStack_120 = plVar9;
                        local_f8 = plVar9;
                      } while (*(char *)(*plVar9 + 0x29) == '\0');
                    }
                    else {
                      do {
                        plVar9 = (longlong *)plVar8[1];
                        plStack_120 = plVar9;
                        if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                        bVar12 = plVar8 == (longlong *)plVar9[2];
                        plVar8 = plVar9;
                      } while (bVar12);
                    }
                  }
                  else {
                    _invalid_parameter_noinfo();
                  }
                  plStack_b0 = plVar3;
                  local_b8 = plVar1;
                  FUN_1400cfdc0(param_1 + 0x88,local_58,&local_b8);
                  FUN_1400c7b20(0);
                  FUN_1400c7ac0(0);
                  FUN_1400c7a60(0);
                  log_InlineLogERROR(
                                    "COperatingActMgr::CloseOperatingActAsyn cq_operating_user_info id  is repeat, id:%u, user id:%u, act id:%u."
                                    );
                  iVar5 = local_res20;
                }
                else {
                  FUN_1400d33c0(param_1 + 0x148,&local_110);
                  if (plVar1 == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                    plVar8 = plVar9;
                    plVar2 = (longlong *)plVar9[2];
                    if (*(char *)(plVar9[2] + 0x29) == '\0') {
                      do {
                        plVar9 = plVar2;
                        plVar2 = (longlong *)*plVar9;
                        plStack_120 = plVar9;
                        local_100 = plVar9;
                      } while (*(char *)(*plVar9 + 0x29) == '\0');
                    }
                    else {
                      do {
                        plVar9 = (longlong *)plVar8[1];
                        plStack_120 = plVar9;
                        if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                        bVar12 = plVar8 == (longlong *)plVar9[2];
                        plVar8 = plVar9;
                      } while (bVar12);
                    }
                  }
                  else {
                    _invalid_parameter_noinfo();
                  }
                  plStack_c0 = plVar3;
                  local_c8 = plVar1;
                  FUN_1400cfdc0(param_1 + 0x88,local_68,&local_c8);
                }
              }
              else {
                if (plVar1 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                }
                if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
                  plVar8 = plVar9;
                  plVar3 = (longlong *)plVar9[2];
                  if (*(char *)(plVar9[2] + 0x29) == '\0') {
                    do {
                      plVar9 = plVar3;
                      plVar3 = (longlong *)*plVar9;
                      plStack_120 = plVar9;
                      local_108 = plVar9;
                    } while (*(char *)(*plVar9 + 0x29) == '\0');
                  }
                  else {
                    do {
                      plVar9 = (longlong *)plVar8[1];
                      plStack_120 = plVar9;
                      if (*(char *)((longlong)plVar9 + 0x29) != '\0') break;
                      bVar12 = plVar8 == (longlong *)plVar9[2];
                      plVar8 = plVar9;
                    } while (bVar12);
                  }
                }
                else {
                  _invalid_parameter_noinfo();
                }
              }
            }
            goto LAB_1400d5200;
          }
          log_InlineLogERROR(&DAT_1406d9c10);
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400d61e0  @1400d61e0  [medium:callgraph-r2]  (orig: FUN_1400d61e0)
void FUN_1400d61e0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  ulong uVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *local_38;
  longlong *plStack_30;
  undefined1 local_28 [32];
  
  plVar1 = *(longlong **)(param_1 + 8);
  plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar6;
          plVar6 = *(longlong **)(param_1 + 0x38);
          if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar6) {
            uVar4 = tq::TimeGet(1);
            plVar1 = *(longlong **)(param_1 + 200);
            plVar6 = (longlong *)**(longlong **)(param_1 + 0xf8);
            plVar5 = plVar1;
            plVar9 = plVar6;
            while( true ) {
              plVar10 = *(longlong **)(param_1 + 0xf8);
              if ((plVar1 == (longlong *)0x0) ||
                 (plVar8 = plVar5, plVar1 != *(longlong **)(param_1 + 200))) {
                _invalid_parameter_noinfo();
                plVar8 = plVar5;
              }
              if (plVar6 == plVar10) break;
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar7 = 0;
              }
              else {
                lVar7 = *plVar1;
              }
              if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              plVar5 = plVar8;
              if (uVar4 - (int)plVar6[4] < 0x78) {
                if (plVar1 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  plVar5 = plVar8;
                }
                if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
                  plVar9 = (longlong *)plVar6[2];
                  if (*(char *)((longlong)plVar9 + 0x25) == '\0') {
                    cVar3 = *(char *)(*plVar9 + 0x25);
                    plVar6 = plVar9;
                    plVar10 = (longlong *)*plVar9;
                    while (plVar9 = plVar6, cVar3 == '\0') {
                      cVar3 = *(char *)(*plVar10 + 0x25);
                      plVar6 = plVar10;
                      plVar10 = (longlong *)*plVar10;
                    }
                  }
                  else {
                    cVar3 = *(char *)(plVar6[1] + 0x25);
                    plVar9 = (longlong *)plVar6[1];
                    plVar10 = plVar6;
                    while ((plVar6 = plVar9, plVar9 = plVar6, cVar3 == '\0' &&
                           (plVar10 == (longlong *)plVar6[2]))) {
                      cVar3 = *(char *)(plVar6[1] + 0x25);
                      plVar9 = (longlong *)plVar6[1];
                      plVar10 = plVar6;
                    }
                  }
                }
                else {
                  _invalid_parameter_noinfo();
                }
              }
              else {
                plVar10 = plVar9;
                if (plVar1 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                }
                if (*(char *)((longlong)plVar6 + 0x25) == '\0') {
                  plVar10 = (longlong *)plVar6[2];
                  if (*(char *)((longlong)plVar10 + 0x25) == '\0') {
                    cVar3 = *(char *)(*plVar10 + 0x25);
                    plVar6 = plVar10;
                    plVar2 = (longlong *)*plVar10;
                    while (plVar10 = plVar6, cVar3 == '\0') {
                      cVar3 = *(char *)(*plVar2 + 0x25);
                      plVar6 = plVar2;
                      plVar2 = (longlong *)*plVar2;
                    }
                  }
                  else {
                    cVar3 = *(char *)(plVar6[1] + 0x25);
                    plVar10 = (longlong *)plVar6[1];
                    plVar2 = plVar6;
                    while ((plVar6 = plVar10, plVar10 = plVar6, cVar3 == '\0' &&
                           (plVar2 == (longlong *)plVar6[2]))) {
                      cVar3 = *(char *)(plVar6[1] + 0x25);
                      plVar10 = (longlong *)plVar6[1];
                      plVar2 = plVar6;
                    }
                  }
                }
                else {
                  _invalid_parameter_noinfo();
                }
                local_38 = plVar8;
                plStack_30 = plVar9;
                FUN_1400d0360(param_1 + 200,local_28,&local_38,param_4,plVar5,plVar10);
                plVar9 = plVar10;
              }
            }
            return;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar1;
          }
          if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          lVar7 = plVar5[4];
          if (lVar7 != 0) {
            cVar3 = FUN_14032ac40(lVar7);
            if (cVar3 == '\0') {
              cVar3 = FUN_14032ad90(lVar7);
              if (cVar3 != '\0') {
                FUN_1400d50f0(param_1,lVar7);
              }
            }
            else {
              FUN_1400d5040(param_1,lVar7,0);
            }
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar6 = plVar5;
        }
        plVar6 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar6 + 0x29) != '\0') break;
        cVar3 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar6 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar6 + 0x29) != '\0');
    do {
      plVar9 = plVar6;
      plVar6 = plVar9;
      if (plVar5 != (longlong *)plVar9[2]) break;
      plVar6 = (longlong *)plVar9[1];
      plVar5 = plVar9;
    } while (*(char *)((longlong)plVar6 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_1400d64b0  @1400d64b0  [medium:callgraph-r1]  (orig: FUN_1400d64b0)
void FUN_1400d64b0(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined8 uVar3;
  
  uVar3 = FUN_14002e300();
  cVar1 = FUN_14002c020(uVar3);
  if (cVar1 == '\0') {
    uVar2 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 400) + *(int *)(param_1 + 0x18c)) <= uVar2 / 1000) {
      uVar2 = tq::TimeGet(0);
      *(uint *)(param_1 + 400) = uVar2 / 1000;
      FUN_1400d61e0(param_1);
    }
    FUN_1400d3d90(param_1);
  }
  return;
}

// ==== CMapGroupKernel::helper_1400db930  @1400db930  [medium:callgraph-r3]  (orig: FUN_1400db930)
void FUN_1400db930(longlong *param_1)

{
  rsize_t _DstSize;
  void *_Src;
  void *_Dst;
  longlong lVar1;
  
  _Src = (void *)param_1[4];
  if (_Src < (void *)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  _Dst = (void *)param_1[3];
  if ((void *)param_1[4] < _Dst) {
    _invalid_parameter_noinfo();
  }
  if ((_Dst < (void *)param_1[3]) || ((void *)param_1[4] < _Dst)) {
    _invalid_parameter_noinfo();
  }
  lVar1 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar1 == 0) || (lVar1 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (_Dst != _Src) {
    lVar1 = param_1[4] - (longlong)_Src >> 3;
    _DstSize = lVar1 * 8;
    if (0 < lVar1) {
      memmove_s(_Dst,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)_Dst);
  }
  return;
}

// ==== CMapGroupKernel::helper_1400dd830  @1400dd830  [medium:callgraph-r3]  (orig: FUN_1400dd830)
void FUN_1400dd830(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_1400dd5d0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMapGroupKernel::helper_1400e0fe0  @1400e0fe0  [medium:callgraph-r2]  (orig: FUN_1400e0fe0)
void FUN_1400e0fe0(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong lVar12;
  bool bVar13;
  longlong *local_res10;
  longlong *local_res18;
  longlong *local_e8 [3];
  longlong *local_d0;
  longlong *local_c8;
  undefined8 local_c0;
  longlong *local_b8;
  longlong *local_b0;
  longlong *local_a8;
  longlong *local_98;
  longlong *local_88;
  longlong *local_78;
  longlong *local_68;
  undefined8 local_58;
  longlong *local_50;
  
  local_58 = 0xfffffffffffffffe;
  local_res10 = operator_new(8);
  if (local_res10 == (longlong *)0x0) {
    local_e8[0] = (longlong *)0x0;
  }
  else {
    *local_res10 = (longlong)local_e8;
    local_e8[0] = local_res10;
  }
  lVar12 = 0;
  local_d0 = (longlong *)0x0;
  local_c8 = (longlong *)0x0;
  local_c0 = 0;
  plVar11 = *(longlong **)param_1[6];
  plVar1 = (longlong *)*param_1;
  local_res18 = local_res10;
  local_50 = plVar1;
LAB_1400e1070:
  do {
    plVar7 = (longlong *)param_1[6];
    local_a8 = (longlong *)*param_1;
    if ((plVar1 == (longlong *)0x0) || (plVar1 != local_a8)) {
      _invalid_parameter_noinfo();
    }
    plVar9 = local_d0;
    if (plVar11 == plVar7) {
      local_88 = (longlong *)0x0;
      if (local_c8 < local_d0) {
        _invalid_parameter_noinfo();
      }
      plVar11 = local_e8[0];
      local_88 = local_e8[0];
      while( true ) {
        plVar1 = local_c8;
        local_68 = (longlong *)0x0;
        if (local_c8 < local_d0) {
          _invalid_parameter_noinfo();
        }
        local_68 = local_e8[0];
        if ((plVar11 == (longlong *)0x0) || (plVar11 != local_e8[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar9 == plVar1) break;
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar12;
        }
        else {
          lVar10 = *plVar11;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        lVar10 = *plVar9;
        if (lVar10 != 0) {
          uVar5 = FUN_14035ab70(lVar10);
          uVar6 = FUN_14035ad90(lVar10,1);
          FUN_1400df530(param_1,uVar6,uVar5);
        }
        if (plVar11 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = lVar12;
        }
        else {
          lVar10 = *plVar11;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar9 = plVar9 + 1;
      }
      FUN_1400db930(local_e8);
      if (local_d0 != (longlong *)0x0) {
        operator_delete(local_d0);
      }
      local_d0 = (longlong *)0x0;
      local_c8 = (longlong *)0x0;
      local_c0 = 0;
      operator_delete(local_e8[0]);
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar12;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar11 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar7 = *(longlong **)plVar11[10];
    plVar9 = (longlong *)plVar11[4];
    local_78 = plVar9;
LAB_1400e10e0:
    plVar8 = (longlong *)plVar11[10];
    local_98 = (longlong *)plVar11[4];
    if ((plVar9 == (longlong *)0x0) || (plVar9 != local_98)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 != plVar8) {
      if (plVar9 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = lVar12;
      }
      else {
        lVar10 = *plVar9;
      }
      if (plVar7 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar8 = (longlong *)plVar7[4];
      local_res10 = plVar8;
      if (plVar8 != (longlong *)0x0) {
        uVar3 = FUN_14035ad90(plVar8,8);
        if (uVar3 == 0) {
          log_InlineLogERROR("CMailMgr::ProcessExpirationDateMail,unExpirationDate is wrong data");
        }
        else {
          uVar4 = FUN_14035ac20(plVar8);
          if (uVar4 == 0) {
            log_InlineLogERROR(
                              "CSynRecruitAdvertisingMgr::ProcessExpirationDateMail,unCurrentDate is wrong data"
                              );
          }
          else if (uVar3 <= uVar4) {
            FUN_1400dd830(local_e8,&local_res10);
          }
        }
      }
      if (plVar9 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        plVar8 = plVar7;
        plVar2 = (longlong *)plVar7[2];
        if (*(char *)(plVar7[2] + 0x29) == '\0') {
          do {
            plVar7 = plVar2;
            plVar2 = (longlong *)*plVar7;
            local_b0 = plVar7;
          } while (*(char *)(*plVar7 + 0x29) == '\0');
        }
        else {
          do {
            plVar7 = (longlong *)plVar8[1];
            if (*(char *)((longlong)plVar7 + 0x29) != '\0') break;
            bVar13 = plVar8 == (longlong *)plVar7[2];
            plVar8 = plVar7;
          } while (bVar13);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1400e10e0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar11 + 0x61) != '\0') {
      _invalid_parameter_noinfo();
      goto LAB_1400e1070;
    }
    plVar7 = plVar11;
    plVar9 = (longlong *)plVar11[2];
    if (*(char *)(plVar11[2] + 0x61) == '\0') {
      do {
        plVar11 = plVar9;
        plVar9 = (longlong *)*plVar11;
        local_b8 = plVar11;
      } while (*(char *)(*plVar11 + 0x61) == '\0');
    }
    else {
      do {
        plVar11 = (longlong *)plVar7[1];
        if (*(char *)((longlong)plVar11 + 0x61) != '\0') break;
        bVar13 = plVar7 == (longlong *)plVar11[2];
        plVar7 = plVar11;
      } while (bVar13);
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_1400e1420  @1400e1420  [medium:callgraph-r1]  (orig: FUN_1400e1420)
ulonglong FUN_1400e1420(longlong param_1)

{
  ulong uVar1;
  ulonglong uVar2;
  
  uVar1 = tq::TimeGet(0);
  uVar2 = (ulonglong)uVar1 * 0x10624dd3 & 0xffffffff;
  if ((uint)(*(int *)(param_1 + 0x48) + *(int *)(param_1 + 0x44)) <= uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x48) = uVar1 / 1000;
    uVar2 = FUN_1400e0fe0(param_1);
  }
  return uVar2;
}

// ==== CMapGroupKernel::vfunc_1  @1400e21b0  [high:rtti-vtable]  (orig: FUN_1400e21b0)
ulonglong FUN_1400e21b0(longlong *param_1,longlong param_2)

{
  ulonglong extraout_RAX;
  ulonglong uVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (*(int *)(param_2 + 0x414) != -1) {
    uVar1 = (**(code **)*param_1)(param_1,*(int *)(param_2 + 0x414));
    return uVar1;
  }
  uVar1 = (*(code *)((undefined8 *)*param_1)[2])
                    (param_1,*(undefined4 *)(param_2 + 0x418),*(undefined4 *)(param_2 + 8),
                     param_2 + 0x10,*(undefined4 *)(param_2 + 0xc));
  return uVar1;
}

// ==== CMapGroupKernel::vfunc_0  @1400e2230  [high:rtti-vtable]  (orig: FUN_1400e2230)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400e2230(longlong param_1,undefined4 param_2,int param_3,void *param_4,int param_5)

{
  undefined8 uVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  int local_448;
  undefined8 local_440;
  undefined4 local_438;
  int local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_440 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_448 = param_3;
  if (param_4 == (void *)0x0) {
    log_InlineLogERROR("Error: null msg point found in CGameSocket::SendMsg.");
    uVar1 = 0;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR("invalid msg type in CMapGroupKernel::SendMsg().");
    uVar1 = 0;
  }
  else if (param_5 + 4 < 0x401) {
    local_430 = param_5;
    local_438 = param_2;
    local_434 = param_3;
    memcpy(local_42c,param_4,(longlong)param_5);
    local_458 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x18) + 0x50))
              (*(longlong **)(param_1 + 0x18),1,0x7533,0x418);
    uVar1 = 1;
  }
  else {
    log_InlineLogERROR("Error: msg length overflow. MsgID:%u, MsgLen:%d");
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CMapGroupKernel::vfunc_2  @1400e2320  [high:rtti-vtable]  (orig: FUN_1400e2320)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400e2320(longlong param_1,undefined4 param_2,int param_3,void *param_4,int param_5)

{
  undefined8 uVar1;
  undefined1 auStack_478 [32];
  undefined4 *local_458;
  undefined8 local_448;
  undefined4 local_438;
  int local_434;
  int local_430;
  undefined1 local_42c [1044];
  ulonglong local_18;
  
  local_448 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  if (param_4 == (void *)0x0) {
    log_InlineLogERROR("null msg point found in CGameSocket::SendNpcMsg: NpcID:[%u] MsgID:[%u]");
    uVar1 = 0;
  }
  else if (param_3 == 0) {
    log_InlineLogERROR("invalid msg type in CMapGroupKernel::SendNpcMsg(): NpcID:[%u]");
    uVar1 = 0;
  }
  else {
    local_430 = param_5;
    local_438 = param_2;
    local_434 = param_3;
    memcpy(local_42c,param_4,(longlong)param_5);
    local_458 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x18) + 0x50))
              (*(longlong **)(param_1 + 0x18),1,0x7534,0x418);
    uVar1 = 1;
  }
  return uVar1;
}

// ==== CMapGroupKernel::vfunc_5  @1400e23e0  [high:rtti-vtable]  (orig: FUN_1400e23e0)
undefined8 FUN_1400e23e0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  (**(code **)(**(longlong **)(param_1 + 0x18) + 0x50))
            (*(longlong **)(param_1 + 0x18),1,0x7538,0xea65,local_res10);
  return 1;
}

// ==== CMapGroupKernel::vfunc_4  @1400e2450  [high:rtti-vtable]  (orig: FUN_1400e2450)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400e2450(longlong param_1,undefined4 param_2,undefined4 param_3,int param_4,void *param_5,
             int param_6,undefined4 param_7)

{
  undefined8 uVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined4 local_42c;
  int local_428;
  undefined1 local_424 [1036];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_5 == (void *)0x0) {
    log_InlineLogERROR("Error: null msg point found in CMapGroupKernel::SendCrossMsg.");
    uVar1 = 0;
  }
  else if (param_4 == 0) {
    log_InlineLogERROR("invalid msg type in CMapGroupKernel::SendCrossMsg() by User[%u].");
    uVar1 = 0;
  }
  else if (param_6 + 4 < 0x401) {
    local_428 = param_6;
    local_42c = param_7;
    local_438 = param_2;
    local_434 = param_3;
    local_430 = param_4;
    memcpy(local_424,param_5,(longlong)param_6);
    local_448 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x18) + 0x50))(*(longlong **)(param_1 + 0x18),6,0x3fc);
    uVar1 = 1;
  }
  else {
    log_InlineLogERROR("Error: msg length overflow. MsgID:%u, MsgLen:%d");
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CMapGroupKernel::vfunc_3  @1400e2540  [high:rtti-vtable]  (orig: FUN_1400e2540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_1400e2540(longlong param_1,int param_2,undefined4 param_3,void *param_4,int param_5,
             undefined4 param_6)

{
  undefined8 uVar1;
  undefined1 auStack_468 [32];
  undefined4 *local_448;
  undefined4 local_438;
  undefined4 local_434;
  int local_430;
  undefined4 local_42c;
  int local_428;
  undefined1 local_424 [1036];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  if (param_4 == (void *)0x0) {
    log_InlineLogERROR("Error: null msg point found in CMapGroupKernel::SendCrossMsg.");
    uVar1 = 0;
  }
  else if (param_2 == 0) {
    log_InlineLogERROR("invalid msg type in CMapGroupKernel::SendCrossMsg().");
    uVar1 = 0;
  }
  else if (param_5 + 4 < 0x401) {
    local_428 = param_5;
    local_42c = param_6;
    local_438 = 0;
    local_434 = param_3;
    local_430 = param_2;
    memcpy(local_424,param_4,(longlong)param_5);
    local_448 = &local_438;
    (**(code **)(**(longlong **)(param_1 + 0x18) + 0x50))(*(longlong **)(param_1 + 0x18),6,0x3fc);
    uVar1 = 1;
  }
  else {
    log_InlineLogERROR("Error: msg length overflow. MsgID:%u, MsgLen:%d");
    uVar1 = 0;
  }
  return uVar1;
}

// ==== CMapGroupKernel::helper_1400e2770  @1400e2770  [medium:callgraph-r1]  (orig: FUN_1400e2770)
void FUN_1400e2770(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x79) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMapGroupKernel::helper_1400e2990  @1400e2990  [medium:callgraph-r1]  (orig: FUN_1400e2990)
void FUN_1400e2990(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x79) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x79) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x79);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x79);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x79);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x79);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001400e29b4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMapGroupKernel::helper_1400e34b0  @1400e34b0  [medium:callgraph-r0]  (orig: FUN_1400e34b0)
void FUN_1400e34b0(void *param_1)

{
  if ((DAT_140975ca0 & 1) == 0) {
    DAT_140975ca0 = DAT_140975ca0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975c98,"CMapGroupKernel");
    atexit((_func_5014 *)&LAB_1406d66a0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001400e3505. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975c98,param_1);
  return;
}

// ==== CMapGroupKernel::helper_1400e3cc0  @1400e3cc0  [medium:callgraph-r0]  (orig: FUN_1400e3cc0)
void FUN_1400e3cc0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  ulong uVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  
  plVar2 = (longlong *)FUN_140006ad0(0x753a,1,param_3,param_4,0xfffffffffffffffe);
  if (plVar2 != (longlong *)0x0) {
    lVar3 = (**(code **)(*plVar2 + 0x40))(plVar2);
    if (lVar3 != 0) {
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
      DAT_140975c70 = (**(code **)(*plVar4 + 0x48))(plVar4);
    }
    (**(code **)*plVar2)(plVar2);
  }
  if (DAT_140975c70 == 0) {
    uVar1 = tq::TimeGet(3);
    DAT_140975c70 = uVar1 + 19000000;
    plVar2 = (longlong *)InstanceGet();
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,"cq_config");
    if (plVar2 != (longlong *)0x0) {
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,1);
      (**(code **)(*plVar4 + 0xb0))(plVar4,0x753a);
      plVar4 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
      (**(code **)(*plVar4 + 0xb0))(plVar4,DAT_140975c70);
      (**(code **)(*plVar2 + 0x50))(plVar2,1);
      (**(code **)*plVar2)(plVar2,1);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400e3e60  @1400e3e60  [medium:callgraph-r1]  (orig: FUN_1400e3e60)
void FUN_1400e3e60(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x79) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMapGroupKernel::helper_1400e44d0  @1400e44d0  [medium:callgraph-r3]  (orig: FUN_1400e44d0)
void FUN_1400e44d0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x79);
  while (cVar1 == '\0') {
    FUN_1400e44d0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x79);
  }
  return;
}

// ==== CMapGroupKernel::InitOnlyOnce  @1400e47b0  [high:log-string]  (orig: FUN_1400e47b0)
undefined1 FUN_1400e47b0(longlong param_1)

{
  undefined8 *puVar1;
  undefined1 uVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  if (*(int *)(param_1 + 0x10) == 0xe) {
    lVar6 = FUN_140579610(0xe);
    *(longlong *)(param_1 + 0x28) = lVar6;
    if (lVar6 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"AdapterCreate\"",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                         ,0x94d);
      return 0;
    }
    lVar6 = FUN_14057ba20(*(undefined4 *)(param_1 + 0x10));
    *(longlong *)(param_1 + 0x30) = lVar6;
    if (lVar6 == 0) {
      if (*(longlong *)(param_1 + 0x28) != 0) {
        operator_delete(*(void **)(param_1 + 0x28));
        *(undefined8 *)(param_1 + 0x28) = 0;
      }
      log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"ResponderCreate\"",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                         ,0x955);
      return 0;
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    uVar2 = FUN_14008b330(uVar7);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    uVar7 = FUN_1400875f0(uVar7);
    lVar6 = GameCreate(*(undefined8 *)(param_1 + 0x28),*(undefined8 *)(param_1 + 0x30),uVar7,uVar2);
    *(longlong *)(param_1 + 0x38) = lVar6;
    if (lVar6 == 0) {
      if (*(longlong *)(param_1 + 0x28) != 0) {
        operator_delete(*(void **)(param_1 + 0x28));
        *(undefined8 *)(param_1 + 0x28) = 0;
      }
      if (*(longlong *)(param_1 + 0x30) != 0) {
        puVar1 = *(undefined8 **)(param_1 + 0x30);
        if (puVar1 != (undefined8 *)0x0) {
          (**(code **)*puVar1)(puVar1,1);
        }
        *(undefined8 *)(param_1 + 0x30) = 0;
      }
      log_InlineLogERROR("PROCESS CRASH! root::GameCreate failed at %s, %d.",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                         ,0x95e);
                    /* WARNING: Subroutine does not return */
      exit(1);
    }
    uVar4 = (**(code **)(**(longlong **)(param_1 + 0x20) + 8))();
    uVar7 = FUN_140008520(uVar4);
    cVar3 = FUN_140088970(uVar7);
    if (cVar3 == '\0') {
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x20) + 8))();
      uVar7 = FUN_140008520(uVar4);
      FUN_1400c5510(uVar7);
      return 0;
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar8 = (longlong *)FUN_1400876b0(uVar7);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,0x11,1);
    if (plVar8 != (longlong *)0x0) {
      plVar9 = (longlong *)FUN_140087ed0();
      uVar4 = (**(code **)(*(longlong *)plVar8[0xb] + 0x10))((longlong *)plVar8[0xb],5);
      lVar6 = *plVar9;
      uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
      (**(code **)(lVar6 + 800))(plVar9,uVar5,uVar4);
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    plVar8 = (longlong *)FUN_1400876b0(uVar7);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,0x12,1);
    if (plVar8 != (longlong *)0x0) {
      plVar9 = (longlong *)FUN_140087ed0();
      uVar4 = (**(code **)(*(longlong *)plVar8[0xb] + 0x10))((longlong *)plVar8[0xb],5);
      lVar6 = *plVar9;
      uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
      (**(code **)(lVar6 + 800))(plVar9,uVar5,uVar4);
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    uVar7 = FUN_140087ba0(uVar7);
    cVar3 = FUN_1401d8da0(uVar7);
    if (cVar3 == '\0') {
      return 0;
    }
    plVar8 = (longlong *)FUN_140087ed0();
    (**(code **)(*plVar8 + 0xd0))(plVar8);
    plVar8 = (longlong *)FUN_140087ed0();
    (**(code **)(*plVar8 + 0xe0))(plVar8);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    uVar7 = FUN_14001b600(uVar7);
    FUN_1400d48b0(uVar7);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    uVar7 = FUN_140087a10(uVar7);
    cVar3 = FUN_140233260(uVar7);
    if (cVar3 == '\0') {
      log_InlineLogERROR("CMapGroupKernel::InitOnlyOnce, failed loading all auction item and info");
    }
    plVar8 = (longlong *)CurrentInstanceGet();
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,8);
    if ((plVar8 == (longlong *)0x0) ||
       (cVar3 = (**(code **)(*plVar8 + 0x1d0))(plVar8), cVar3 == '\0')) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pIProider && pIProider->ProcessInit()",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroupkernel.cpp"
                         ,0x985);
      return 0;
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
    cVar3 = FUN_14008b330(uVar7);
    if (cVar3 == '\0') {
      plVar8 = (longlong *)CurrentInstanceGet();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0x1c);
      if ((plVar8 == (longlong *)0x0) ||
         (cVar3 = (**(code **)(*plVar8 + 0x80))(plVar8), cVar3 == '\0')) {
        log_InlineLogERROR("CMapGroupKernel::InitOnlyOnce(). pVexillumIProider == NULL");
        return 0;
      }
    }
    else {
      plVar8 = (longlong *)CurrentInstanceGet();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,0x25);
      if ((plVar8 == (longlong *)0x0) ||
         (cVar3 = (**(code **)(*plVar8 + 0x80))(plVar8), cVar3 == '\0')) {
        log_InlineLogERROR("CMapGroupKernel::InitOnlyOnce(). pFrontierFlagWarIProider == NULL");
        return 0;
      }
    }
    FUN_1400e3cc0();
    uVar7 = FUN_140087e30();
    FUN_140286530(uVar7,"</F>Event_Server_Start",0,0,0,0);
  }
  return 1;
}

// ==== CMapGroupKernel::helper_1400e4cc0  @1400e4cc0  [medium:callgraph-r1]  (orig: FUN_1400e4cc0)
void FUN_1400e4cc0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400e4cc0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_1400e5030  @1400e5030  [medium:callgraph-r2]  (orig: FUN_1400e5030)
void FUN_1400e5030(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x79);
  while (cVar1 == '\0') {
    FUN_1400e44d0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x79);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroupKernel::helper_1400e50b0  @1400e50b0  [medium:callgraph-r1]  (orig: FUN_1400e50b0)
void FUN_1400e50b0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x80);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0xf) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x79) = 0;
  return;
}

// ==== CMapGroupKernel::vfunc_5  @1400e7f70  [high:rtti-vtable]  (orig: FUN_1400e7f70)
undefined8 FUN_1400e7f70(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong *plVar2;
  short sVar3;
  undefined2 uVar4;
  char cVar5;
  undefined1 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  undefined8 uVar9;
  uint uVar10;
  undefined4 in_stack_fffffffffffffb78;
  undefined2 uVar11;
  undefined1 local_478 [8];
  undefined1 local_470 [24];
  longlong *local_458;
  longlong *local_450;
  undefined8 local_448;
  undefined1 local_438 [8];
  short local_430;
  undefined2 local_42e;
  undefined1 local_42c [1028];
  
  local_448 = 0xfffffffffffffffe;
  FUN_14035cfb0(local_438);
  tq::TimeGet(0);
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 2));
  if (*(longlong *)(lVar8 + 0x90) == 0) {
    in_stack_fffffffffffffb78 = 0;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (*(longlong *)(lVar8 + 0x90) != 0) {
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 2));
    if (*(longlong *)(lVar8 + 0x90) == 0) {
      in_stack_fffffffffffffb78 = 0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar8 + 0x90),local_478);
    uVar10 = 0;
    while (cVar5 = FUN_1400ce310(local_470), cVar5 != '\0') {
      while (cVar5 = (**(code **)(*local_458 + 0x298))(local_458,0x1001,&local_450), cVar5 == '\0')
      {
        cVar5 = FUN_1400ce310(local_470);
        if (cVar5 == '\0') goto LAB_1400e81ad;
      }
      uVar10 = uVar10 + 1;
      if (1000000 < uVar10) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1400e81b6;
      }
      if ((local_450 != (longlong *)0x0) && (param_1[7] != 0)) {
        uVar7 = (**(code **)(*local_450 + 8))();
        cVar5 = FUN_14035d050(local_438,uVar7);
        uVar11 = (undefined2)((uint)in_stack_fffffffffffffb78 >> 0x10);
        if (cVar5 != '\0') {
          if (local_450 == (longlong *)0x0) {
            uVar11 = 0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar2 = local_450;
          if (local_450 == (longlong *)0x0) {
            uVar11 = 0;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          uVar4 = local_42e;
          sVar3 = local_430;
          lVar8 = *(longlong *)param_1[7];
          uVar6 = FUN_140167b70(local_450);
          uVar7 = (**(code **)(*plVar2 + 8))(plVar2);
          in_stack_fffffffffffffb78 = CONCAT22(uVar11,uVar4);
          (**(code **)(lVar8 + 0x10))
                    (param_1[7],uVar7,local_42c,sVar3 + -4,in_stack_fffffffffffffb78,uVar6);
        }
      }
    }
LAB_1400e81ad:
    local_450 = (longlong *)0x0;
LAB_1400e81b6:
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 2));
    if (*(longlong *)(lVar8 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x60))();
  }
  tq::TimeGet(0);
  uVar7 = (**(code **)(*(longlong *)param_1[4] + 8))();
  uVar9 = FUN_140008520(uVar7);
  FUN_1400c5510(uVar9);
  tq::TimeGet(0);
  if (*(int *)(param_1 + 2) == 0xe) {
    if (param_1[5] != 0) {
      operator_delete((void *)param_1[5]);
      param_1[5] = 0;
    }
    if (param_1[6] != 0) {
      puVar1 = (undefined8 *)param_1[6];
      if (puVar1 != (undefined8 *)0x0) {
        (**(code **)*puVar1)(puVar1,1);
      }
      param_1[6] = 0;
    }
    if (param_1[7] != 0) {
      puVar1 = (undefined8 *)param_1[7];
      if (puVar1 != (undefined8 *)0x0) {
        (**(code **)*puVar1)(puVar1,1);
      }
      param_1[7] = 0;
    }
  }
  (**(code **)*param_1)(param_1,1);
  tq::TimeGet(0);
  FUN_14035d010(local_438);
  return 1;
}

// ==== CMapGroupKernel::helper_1400e8580  @1400e8580  [medium:callgraph-r0]  (orig: FUN_1400e8580)
undefined8 * FUN_1400e8580(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x79) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1400e2990(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x79) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x79) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x79) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0xf;
        plVar8 = plVar8 + 0xf;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1400e876c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x79) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x79) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x79);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x79);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x79) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x79);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x79);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1400e876c:
  if ((char)plVar2[0xf] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0xf] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0xf] == '\0') {
            *(undefined1 *)(plVar9 + 0xf) = 1;
            *(undefined1 *)(plVar8 + 0xf) = 0;
            FUN_1400e3e60(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x79) == '\0') {
            if ((*(char *)(*plVar9 + 0x78) != '\x01') || (*(char *)(plVar9[2] + 0x78) != '\x01')) {
              if (*(char *)(plVar9[2] + 0x78) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x78) = 1;
                *(undefined1 *)(plVar9 + 0xf) = 0;
                FUN_1400e2770(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0xf) = (char)plVar8[0xf];
              *(undefined1 *)(plVar8 + 0xf) = 1;
              *(undefined1 *)(plVar9[2] + 0x78) = 1;
              FUN_1400e3e60(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xf) = 0;
          }
        }
        else {
          if ((char)plVar9[0xf] == '\0') {
            *(undefined1 *)(plVar9 + 0xf) = 1;
            *(undefined1 *)(plVar8 + 0xf) = 0;
            FUN_1400e2770(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x79) == '\0') {
            if ((*(char *)(plVar9[2] + 0x78) != '\x01') || (*(char *)(*plVar9 + 0x78) != '\x01')) {
              if (*(char *)(*plVar9 + 0x78) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x78) = 1;
                *(undefined1 *)(plVar9 + 0xf) = 0;
                FUN_1400e3e60(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0xf) = (char)plVar8[0xf];
              *(undefined1 *)(plVar8 + 0xf) = 1;
              *(undefined1 *)(*plVar9 + 0x78) = 1;
              FUN_1400e2770(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0xf) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0xf) = 1;
  }
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CMapGroupKernel::helper_1400e8d70  @1400e8d70  [medium:callgraph-r0]  (orig: FUN_1400e8d70)
void FUN_1400e8d70(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400e71c0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_1400e8e30  @1400e8e30  [medium:callgraph-r1]  (orig: FUN_1400e8e30)
longlong * FUN_1400e8e30(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1400e5030(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x79) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x79) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x79);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x79);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x79);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x79);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1400e8580(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_1400e9a90  @1400e9a90  [medium:callgraph-r0]  (orig: FUN_1400e9a90)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1400e9a90(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  undefined8 *puVar8;
  longlong **pplVar9;
  longlong *plVar10;
  undefined8 *puVar11;
  longlong lVar12;
  longlong lVar13;
  longlong *local_68;
  undefined8 *puStack_60;
  longlong *local_58;
  longlong *local_50;
  longlong *local_48;
  longlong *plStack_40;
  longlong *local_38;
  longlong *plStack_30;
  
  plVar10 = (longlong *)**(undefined8 **)(param_1 + 0x78);
  plVar2 = *(longlong **)(param_1 + 0x48);
  lVar13 = 0;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x78);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar13;
    }
    else {
      lVar12 = *plVar2;
    }
    if (plVar10 == *(longlong **)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar11 = *(undefined8 **)(param_1 + 0xb8);
    if (*(char *)((longlong)puVar11[1] + 0x29) == '\0') {
      puVar6 = (undefined8 *)puVar11[1];
      do {
        if (*(uint *)(puVar6 + 3) < *(uint *)(plVar10 + 3)) {
          puVar7 = (undefined8 *)puVar6[2];
        }
        else {
          puVar7 = (undefined8 *)*puVar6;
          puVar11 = puVar6;
        }
        puVar6 = puVar7;
      } while (*(char *)((longlong)puVar7 + 0x29) == '\0');
    }
    puVar6 = *(undefined8 **)(param_1 + 0xb8);
    puStack_60 = puVar11;
    local_68 = *(longlong **)(param_1 + 0x88);
    if (*(longlong **)(param_1 + 0x88) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar11 == puVar6) || (*(uint *)(plVar10 + 3) < *(uint *)(puVar11 + 3))) {
      pplVar9 = &local_58;
      local_50 = *(longlong **)(param_1 + 0xb8);
      local_58 = *(longlong **)(param_1 + 0x88);
    }
    else {
      pplVar9 = &local_68;
    }
    plVar3 = *pplVar9;
    plVar4 = *(longlong **)(param_1 + 0xb8);
    local_48 = plVar3;
    plStack_40 = pplVar9[1];
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x88))) {
      _invalid_parameter_noinfo();
    }
    plVar5 = plStack_40;
    if (plStack_40 != plVar4) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::OverTimeLogSave("syslog/overtime",
                          "ClientMsgType=%u-%u, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                          *(uint *)(plVar5 + 3) / 1000,(ulonglong)(*(uint *)(plVar5 + 3) % 1000));
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar10 + 0x1d) == '\0') {
      plVar3 = (longlong *)plVar10[2];
      if (*(char *)((longlong)plVar3 + 0x1d) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x1d);
        plVar10 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x1d);
          plVar10 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar10[1] + 0x1d);
        plVar4 = (longlong *)plVar10[1];
        plVar3 = plVar10;
        while ((plVar10 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar10[2]))) {
          cVar1 = *(char *)(plVar10[1] + 0x1d);
          plVar4 = (longlong *)plVar10[1];
          plVar3 = plVar10;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar10 = *(longlong **)(*(longlong *)(param_1 + 0xb8) + 8);
  cVar1 = *(char *)((longlong)plVar10 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400e4cc0(param_1 + 0x88,plVar10[2]);
    plVar2 = (longlong *)*plVar10;
    operator_delete(plVar10);
    plVar10 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0xb8) + 8) = *(longlong *)(param_1 + 0xb8);
  *(undefined8 *)(param_1 + 0xc0) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0xb8) = *(undefined8 *)(param_1 + 0xb8);
  *(longlong *)(*(longlong *)(param_1 + 0xb8) + 0x10) = *(longlong *)(param_1 + 0xb8);
  plVar10 = *(longlong **)(*(longlong *)(param_1 + 0x78) + 8);
  cVar1 = *(char *)((longlong)plVar10 + 0x1d);
  while (cVar1 == '\0') {
    FUN_1400098c0(param_1 + 0x48,plVar10[2]);
    plVar2 = (longlong *)*plVar10;
    operator_delete(plVar10);
    plVar10 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x1d);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 8) = *(longlong *)(param_1 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x78);
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 0x10) = *(longlong *)(param_1 + 0x78);
  plVar10 = *(longlong **)(param_1 + 200);
  local_48 = plVar10;
  plStack_40 = (undefined8 *)**(undefined8 **)(param_1 + 0xf8);
  local_68 = plVar10;
  puStack_60 = (undefined8 *)**(undefined8 **)(param_1 + 0xf8);
  puVar11 = puStack_60;
  while( true ) {
    puVar6 = *(undefined8 **)(param_1 + 0xf8);
    if ((plVar10 == (longlong *)0x0) || (plVar10 != *(longlong **)(param_1 + 200))) {
      _invalid_parameter_noinfo();
    }
    if (puVar11 == puVar6) break;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar12 = lVar13;
    }
    else {
      lVar12 = *plVar10;
    }
    if (puVar11 == *(undefined8 **)(lVar12 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar6 = *(undefined8 **)(param_1 + 0x138);
    if (*(char *)((longlong)puVar6[1] + 0x29) == '\0') {
      puVar7 = (undefined8 *)puVar6[1];
      do {
        if (*(uint *)(puVar7 + 3) < *(uint *)(puVar11 + 3)) {
          puVar8 = (undefined8 *)puVar7[2];
        }
        else {
          puVar8 = (undefined8 *)*puVar7;
          puVar6 = puVar7;
        }
        puVar7 = puVar8;
      } while (*(char *)((longlong)puVar8 + 0x29) == '\0');
    }
    puVar7 = *(undefined8 **)(param_1 + 0x138);
    plStack_40 = puVar6;
    local_48 = *(longlong **)(param_1 + 0x108);
    if (*(longlong **)(param_1 + 0x108) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar6 == puVar7) || (*(uint *)(puVar11 + 3) < *(uint *)(puVar6 + 3))) {
      pplVar9 = &local_58;
      local_50 = *(longlong **)(param_1 + 0x138);
      local_58 = *(longlong **)(param_1 + 0x108);
    }
    else {
      pplVar9 = &local_48;
    }
    plVar2 = *pplVar9;
    plVar3 = *(longlong **)(param_1 + 0x138);
    local_38 = plVar2;
    plStack_30 = pplVar9[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x108))) {
      _invalid_parameter_noinfo();
    }
    plVar4 = plStack_30;
    if (plStack_30 != plVar3) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar12 = lVar13;
      }
      else {
        lVar12 = *plVar2;
      }
      if (plVar4 == *(longlong **)(lVar12 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::OverTimeLogSave("syslog/overtime","NpcMsgType=%u, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                          (int)plVar4[3],(int)plVar4[4]);
    }
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar11 + 0x1d) == '\0') {
      puVar6 = (undefined8 *)puVar11[2];
      if (*(char *)((longlong)puVar6 + 0x1d) == '\0') {
        cVar1 = *(char *)((longlong)*puVar6 + 0x1d);
        puVar11 = puVar6;
        puVar6 = (undefined8 *)*puVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar6 + 0x1d);
          puVar11 = puVar6;
          puVar6 = (undefined8 *)*puVar6;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar11[1] + 0x1d);
        puVar7 = (undefined8 *)puVar11[1];
        puVar6 = puVar11;
        while ((puVar11 = puVar7, cVar1 == '\0' && (puVar6 == (undefined8 *)puVar11[2]))) {
          cVar1 = *(char *)((longlong)puVar11[1] + 0x1d);
          puVar7 = (undefined8 *)puVar11[1];
          puVar6 = puVar11;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar10 = *(longlong **)(*(longlong *)(param_1 + 0x138) + 8);
  cVar1 = *(char *)((longlong)plVar10 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400e4cc0(param_1 + 0x108,plVar10[2]);
    plVar2 = (longlong *)*plVar10;
    operator_delete(plVar10);
    plVar10 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x138) + 8) = *(longlong *)(param_1 + 0x138);
  *(undefined8 *)(param_1 + 0x140) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x138) = *(undefined8 *)(param_1 + 0x138);
  *(longlong *)(*(longlong *)(param_1 + 0x138) + 0x10) = *(longlong *)(param_1 + 0x138);
  plVar10 = *(longlong **)(*(longlong *)(param_1 + 0xf8) + 8);
  cVar1 = *(char *)((longlong)plVar10 + 0x1d);
  while (cVar1 == '\0') {
    FUN_1400098c0(param_1 + 200,plVar10[2]);
    plVar2 = (longlong *)*plVar10;
    operator_delete(plVar10);
    plVar10 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x1d);
  }
  plVar10 = (longlong *)(param_1 + 0x148);
  *(longlong *)(*(longlong *)(param_1 + 0xf8) + 8) = *(longlong *)(param_1 + 0xf8);
  *(undefined8 *)(param_1 + 0x100) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0xf8) = *(undefined8 *)(param_1 + 0xf8);
  *(longlong *)(*(longlong *)(param_1 + 0xf8) + 0x10) = *(longlong *)(param_1 + 0xf8);
  plStack_30 = (longlong *)**(undefined8 **)(param_1 + 0x178);
  plVar2 = (longlong *)*plVar10;
  local_68 = plVar2;
  puStack_60 = plStack_30;
  puVar11 = puStack_60;
  local_38 = plVar2;
  do {
    do {
      while( true ) {
        while( true ) {
          puVar6 = puVar11;
          puVar11 = *(undefined8 **)(param_1 + 0x178);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)*plVar10)) {
            _invalid_parameter_noinfo();
          }
          if (puVar6 == puVar11) {
            plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x1b8) + 8);
            cVar1 = *(char *)((longlong)plVar2 + 0x29);
            while (cVar1 == '\0') {
              FUN_1400e4cc0(param_1 + 0x188,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x29);
            }
            *(longlong *)(*(longlong *)(param_1 + 0x1b8) + 8) = *(longlong *)(param_1 + 0x1b8);
            *(undefined8 *)(param_1 + 0x1c0) = 0;
            *(undefined8 *)*(undefined8 *)(param_1 + 0x1b8) = *(undefined8 *)(param_1 + 0x1b8);
            *(longlong *)(*(longlong *)(param_1 + 0x1b8) + 0x10) = *(longlong *)(param_1 + 0x1b8);
            plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x178) + 8);
            cVar1 = *(char *)((longlong)plVar2 + 0x1d);
            while (cVar1 == '\0') {
              FUN_1400098c0(plVar10,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x1d);
            }
            *(longlong *)(*(longlong *)(param_1 + 0x178) + 8) = *(longlong *)(param_1 + 0x178);
            *(undefined8 *)(param_1 + 0x180) = 0;
            *(undefined8 *)*(undefined8 *)(param_1 + 0x178) = *(undefined8 *)(param_1 + 0x178);
            *(longlong *)(*(longlong *)(param_1 + 0x178) + 0x10) = *(longlong *)(param_1 + 0x178);
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = lVar13;
          }
          else {
            lVar12 = *plVar2;
          }
          if (puVar6 == *(undefined8 **)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          puVar11 = *(undefined8 **)(param_1 + 0x1b8);
          if (*(char *)((longlong)puVar11[1] + 0x29) == '\0') {
            puVar7 = (undefined8 *)puVar11[1];
            do {
              if (*(uint *)(puVar7 + 3) < *(uint *)(puVar6 + 3)) {
                puVar8 = (undefined8 *)puVar7[2];
              }
              else {
                puVar8 = (undefined8 *)*puVar7;
                puVar11 = puVar7;
              }
              puVar7 = puVar8;
            } while (*(char *)((longlong)puVar8 + 0x29) == '\0');
          }
          puVar7 = *(undefined8 **)(param_1 + 0x1b8);
          plStack_30 = puVar11;
          local_38 = *(longlong **)(param_1 + 0x188);
          if (*(longlong **)(param_1 + 0x188) == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if ((puVar11 == puVar7) || (*(uint *)(puVar6 + 3) < *(uint *)(puVar11 + 3))) {
            pplVar9 = &local_48;
            plStack_40 = *(undefined8 **)(param_1 + 0x1b8);
            local_48 = *(longlong **)(param_1 + 0x188);
          }
          else {
            pplVar9 = &local_38;
          }
          plVar3 = *pplVar9;
          plVar4 = *(longlong **)(param_1 + 0x1b8);
          local_58 = plVar3;
          local_50 = pplVar9[1];
          if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x188))) {
            _invalid_parameter_noinfo();
          }
          plVar5 = local_50;
          if (local_50 != plVar4) {
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar12 = lVar13;
            }
            else {
              lVar12 = *plVar3;
            }
            if (plVar5 == *(longlong **)(lVar12 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            tq::OverTimeLogSave("syslog/overtime",
                                "CrossMsgType=%u, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                                (int)plVar5[3],(int)plVar5[4]);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar6 + 0x1d) == '\0') break;
          _invalid_parameter_noinfo();
          puVar11 = puVar6;
        }
        puVar11 = (undefined8 *)puVar6[2];
        if (*(char *)((longlong)puVar11 + 0x1d) != '\0') break;
        cVar1 = *(char *)((longlong)*puVar11 + 0x1d);
        puVar6 = (undefined8 *)*puVar11;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar6 + 0x1d);
          puVar11 = puVar6;
          puVar6 = (undefined8 *)*puVar6;
        }
      }
      puVar11 = (undefined8 *)puVar6[1];
    } while (*(char *)((longlong)puVar11 + 0x1d) != '\0');
    do {
      puVar7 = puVar11;
      puVar11 = puVar7;
      if (puVar6 != (undefined8 *)puVar7[2]) break;
      puVar11 = (undefined8 *)puVar7[1];
      puVar6 = puVar7;
    } while (*(char *)((longlong)puVar11 + 0x1d) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_1400ea7d0  @1400ea7d0  [medium:callgraph-r0]  (orig: FUN_1400ea7d0)
void FUN_1400ea7d0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1400e8e30((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::vfunc_4  @1400eb590  [high:rtti-vtable]  (orig: FUN_1400eb590)
undefined8 FUN_1400eb590(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  uint uVar4;
  ulong uVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  undefined8 *puVar9;
  longlong *plVar10;
  longlong in_stack_ffffffffffffff58;
  undefined4 uVar11;
  longlong local_90;
  undefined8 *local_88;
  longlong local_80;
  undefined8 local_78;
  longlong *local_70;
  longlong local_68;
  longlong local_58;
  longlong local_50;
  CTickAnalyst local_48 [32];
  
  DAT_140975ca4 = DAT_140975ca4 + 1;
  if (DAT_140975ca4 < 4) {
    if (0 < DAT_140975ca4) {
      CTickAnalyst::CTickAnalyst(local_48,0xd);
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
      FUN_1400c0b80(uVar7,param_2);
      CTickAnalyst::~CTickAnalyst(local_48);
      return 1;
    }
  }
  else {
    DAT_140975ca4 = 0;
  }
  uVar4 = CAsyncDBThread::UserLoginGet();
  uVar11 = (undefined4)((ulonglong)in_stack_ffffffffffffff58 >> 0x20);
  do {
    if (uVar4 == 0) {
LAB_1400eb781:
      if ((*(longlong *)(param_1 + 0x38) != 0) && (*(int *)(param_1 + 0x10) == 0xe)) {
        CTickAnalyst::CTickAnalyst(local_48,0x17);
        (**(code **)(**(longlong **)(param_1 + 0x38) + 8))();
        CTickAnalyst::~CTickAnalyst(local_48);
      }
      uVar5 = tq::TimeGet(0);
      if ((uint)(*(int *)(param_1 + 0x40) + *(int *)(param_1 + 0x44)) <= uVar5 / 1000) {
        uVar5 = tq::TimeGet(0);
        *(uint *)(param_1 + 0x44) = uVar5 / 1000;
        FUN_1400e9a90(param_1);
        FUN_14013b0c0();
        if (DAT_140975bf0 == 0) {
          uVar7 = CONCAT44(uVar11,0x3cd);
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pLuaScriptMgr",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                             ,uVar7);
          uVar11 = (undefined4)((ulonglong)uVar7 >> 0x20);
        }
        else {
          uVar7 = FUN_140087e30();
          FUN_140283410(uVar7);
        }
        lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
        if (*(longlong *)(lVar6 + 0x100) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMagicManager",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                             ,CONCAT44(uVar11,0x144));
        }
        else {
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x10));
          uVar7 = FUN_1400877e0(uVar7);
          FUN_1402f20d0(uVar7);
        }
      }
      return 1;
    }
    uVar11 = (undefined4)((ulonglong)in_stack_ffffffffffffff58 >> 0x20);
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x1f8))[1];
    cVar1 = *(char *)((longlong)puVar9 + 0x79);
    puVar3 = *(undefined8 **)(param_1 + 0x1f8);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar4) {
        puVar8 = (undefined8 *)puVar9[2];
        puVar9 = puVar3;
      }
      else {
        puVar8 = (undefined8 *)*puVar9;
      }
      puVar3 = puVar9;
      puVar9 = puVar8;
      cVar1 = *(char *)((longlong)puVar8 + 0x79);
    }
    local_88 = puVar3;
    local_90 = *(longlong *)(param_1 + 0x1c8);
    puVar9 = *(undefined8 **)(param_1 + 0x1f8);
    if (*(longlong *)(param_1 + 0x1c8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar9) || (uVar4 < *(uint *)(puVar3 + 3))) {
      local_78 = *(undefined8 *)(param_1 + 0x1f8);
      local_80 = *(longlong *)(param_1 + 0x1c8);
      plVar10 = &local_80;
    }
    else {
      plVar10 = &local_90;
    }
    plVar2 = (longlong *)*plVar10;
    local_70 = plVar2;
    local_68 = plVar10[1];
    lVar6 = *(longlong *)(param_1 + 0x1f8);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x1c8))) {
      _invalid_parameter_noinfo();
    }
    in_stack_ffffffffffffff58 = local_68;
    if (local_68 == lVar6) {
      log_InlineLogERROR("CMapGroupKernel::OnTimer cannot find login serial %u",(ulonglong)uVar4);
      goto LAB_1400eb781;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (in_stack_ffffffffffffff58 == *(longlong *)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    in_stack_ffffffffffffff58 = in_stack_ffffffffffffff58 + 0x1c;
    (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
              (*(longlong **)(param_1 + 0x20),4,0xc351,0x5c,in_stack_ffffffffffffff58);
    local_58 = *plVar10;
    local_50 = plVar10[1];
    FUN_1400e8580(param_1 + 0x1c8,local_48,&local_58);
    uVar4 = CAsyncDBThread::UserLoginGet();
    uVar11 = (undefined4)((ulonglong)in_stack_ffffffffffffff58 >> 0x20);
  } while( true );
}

// ==== CMapGroupKernel::helper_1400ef850  @1400ef850  [medium:callgraph-r0]  (orig: FUN_1400ef850)
undefined8 * FUN_1400ef850(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1400e50b0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x79) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroupKernel::ctor_or_dtor  @1400f0000  [high:vtable-assign]  (orig: FUN_1400f0000)
undefined8 * FUN_1400f0000(undefined8 *param_1)

{
  *param_1 = IMapGroup::vftable;
  *param_1 = CMapGroupKernel::vftable;
  param_1[1] = CMapGroupKernel::vftable;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  FUN_14000ef40(param_1 + 9);
  FUN_1400ec260(param_1 + 0x11);
  FUN_14000ef40(param_1 + 0x19);
  FUN_1400ec260(param_1 + 0x21);
  FUN_14000ef40(param_1 + 0x29);
  FUN_1400ec260(param_1 + 0x31);
  FUN_1400ef850(param_1 + 0x39);
  return param_1;
}

// ==== CMapGroupKernel::ctor_or_dtor  @1400f00a0  [high:vtable-assign]  (orig: FUN_1400f00a0)
void FUN_1400f00a0(undefined8 *param_1)

{
  *param_1 = CMapGroupKernel::vftable;
  param_1[1] = CMapGroupKernel::vftable;
  FUN_1400ea7d0(param_1 + 0x39);
  operator_delete((void *)param_1[0x39]);
  FUN_1400e8d70(param_1 + 0x31);
  operator_delete((void *)param_1[0x31]);
  FUN_14000c310(param_1 + 0x29);
  operator_delete((void *)param_1[0x29]);
  FUN_1400e8d70(param_1 + 0x21);
  operator_delete((void *)param_1[0x21]);
  FUN_14000c310(param_1 + 0x19);
  operator_delete((void *)param_1[0x19]);
  FUN_1400e8d70(param_1 + 0x11);
  operator_delete((void *)param_1[0x11]);
  FUN_14000c310(param_1 + 9);
  operator_delete((void *)param_1[9]);
  *param_1 = IMapGroup::vftable;
  return;
}

// ==== CMapGroupKernel::vfunc_0  @1400f01c0  [high:rtti-vtable]  (orig: FUN_1400f01c0)
undefined8 FUN_1400f01c0(undefined8 param_1,uint param_2)

{
  FUN_1400f00a0();
  if ((param_2 & 1) != 0) {
    FUN_1400e34b0(param_1);
  }
  return param_1;
}

// ==== CMapGroupKernel::helper_1400f1410  @1400f1410  [medium:callgraph-r3]  (orig: FUN_1400f1410)
longlong FUN_1400f1410(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_2 + 0x10);
  FUN_1400efbf0(param_1 + 0x18,param_2 + 0x18);
  *(undefined8 *)(param_1 + 0x58) = *(undefined8 *)(param_2 + 0x58);
  *(undefined8 *)(param_1 + 0x60) = *(undefined8 *)(param_2 + 0x60);
  *(undefined4 *)(param_1 + 0x68) = *(undefined4 *)(param_2 + 0x68);
  *(undefined8 *)(param_1 + 0x70) = *(undefined8 *)(param_2 + 0x70);
  *(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_2 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = *(undefined8 *)(param_2 + 0x80);
  *(undefined8 *)(param_1 + 0x88) = *(undefined8 *)(param_2 + 0x88);
  *(undefined8 *)(param_1 + 0x90) = *(undefined8 *)(param_2 + 0x90);
  *(undefined8 *)(param_1 + 0x98) = *(undefined8 *)(param_2 + 0x98);
  *(undefined8 *)(param_1 + 0xa0) = *(undefined8 *)(param_2 + 0xa0);
  *(undefined8 *)(param_1 + 0xa8) = *(undefined8 *)(param_2 + 0xa8);
  *(undefined8 *)(param_1 + 0xb0) = *(undefined8 *)(param_2 + 0xb0);
  *(undefined8 *)(param_1 + 0xb8) = *(undefined8 *)(param_2 + 0xb8);
  *(undefined8 *)(param_1 + 0xc0) = *(undefined8 *)(param_2 + 0xc0);
  *(undefined8 *)(param_1 + 200) = *(undefined8 *)(param_2 + 200);
  *(undefined8 *)(param_1 + 0xd0) = *(undefined8 *)(param_2 + 0xd0);
  *(undefined8 *)(param_1 + 0xd8) = *(undefined8 *)(param_2 + 0xd8);
  *(undefined8 *)(param_1 + 0xe0) = *(undefined8 *)(param_2 + 0xe0);
  *(undefined8 *)(param_1 + 0xe8) = *(undefined8 *)(param_2 + 0xe8);
  *(undefined8 *)(param_1 + 0xf0) = *(undefined8 *)(param_2 + 0xf0);
  *(undefined8 *)(param_1 + 0xf8) = *(undefined8 *)(param_2 + 0xf8);
  *(undefined8 *)(param_1 + 0x100) = *(undefined8 *)(param_2 + 0x100);
  *(undefined8 *)(param_1 + 0x108) = *(undefined8 *)(param_2 + 0x108);
  *(undefined8 *)(param_1 + 0x110) = *(undefined8 *)(param_2 + 0x110);
  *(undefined8 *)(param_1 + 0x118) = *(undefined8 *)(param_2 + 0x118);
  *(undefined8 *)(param_1 + 0x120) = *(undefined8 *)(param_2 + 0x120);
  *(undefined8 *)(param_1 + 0x128) = *(undefined8 *)(param_2 + 0x128);
  *(undefined8 *)(param_1 + 0x130) = *(undefined8 *)(param_2 + 0x130);
  *(undefined8 *)(param_1 + 0x138) = *(undefined8 *)(param_2 + 0x138);
  *(undefined8 *)(param_1 + 0x140) = *(undefined8 *)(param_2 + 0x140);
  *(undefined8 *)(param_1 + 0x148) = *(undefined8 *)(param_2 + 0x148);
  *(undefined8 *)(param_1 + 0x150) = *(undefined8 *)(param_2 + 0x150);
  *(undefined8 *)(param_1 + 0x158) = *(undefined8 *)(param_2 + 0x158);
  *(undefined8 *)(param_1 + 0x160) = *(undefined8 *)(param_2 + 0x160);
  *(undefined8 *)(param_1 + 0x168) = *(undefined8 *)(param_2 + 0x168);
  *(undefined8 *)(param_1 + 0x170) = *(undefined8 *)(param_2 + 0x170);
  *(undefined8 *)(param_1 + 0x178) = *(undefined8 *)(param_2 + 0x178);
  *(undefined8 *)(param_1 + 0x180) = *(undefined8 *)(param_2 + 0x180);
  *(undefined8 *)(param_1 + 0x188) = *(undefined8 *)(param_2 + 0x188);
  *(undefined8 *)(param_1 + 400) = *(undefined8 *)(param_2 + 400);
  *(undefined8 *)(param_1 + 0x198) = *(undefined8 *)(param_2 + 0x198);
  *(undefined8 *)(param_1 + 0x1a0) = *(undefined8 *)(param_2 + 0x1a0);
  *(undefined8 *)(param_1 + 0x1a8) = *(undefined8 *)(param_2 + 0x1a8);
  *(undefined8 *)(param_1 + 0x1b0) = *(undefined8 *)(param_2 + 0x1b0);
  *(undefined8 *)(param_1 + 0x1b8) = *(undefined8 *)(param_2 + 0x1b8);
  *(undefined8 *)(param_1 + 0x1c0) = *(undefined8 *)(param_2 + 0x1c0);
  *(undefined8 *)(param_1 + 0x1c8) = *(undefined8 *)(param_2 + 0x1c8);
  *(undefined8 *)(param_1 + 0x1d0) = *(undefined8 *)(param_2 + 0x1d0);
  *(undefined8 *)(param_1 + 0x1d8) = *(undefined8 *)(param_2 + 0x1d8);
  *(undefined8 *)(param_1 + 0x1e0) = *(undefined8 *)(param_2 + 0x1e0);
  *(undefined8 *)(param_1 + 0x1e8) = *(undefined8 *)(param_2 + 0x1e8);
  *(undefined8 *)(param_1 + 0x1f0) = *(undefined8 *)(param_2 + 0x1f0);
  *(undefined8 *)(param_1 + 0x1f8) = *(undefined8 *)(param_2 + 0x1f8);
  *(undefined8 *)(param_1 + 0x200) = *(undefined8 *)(param_2 + 0x200);
  *(undefined8 *)(param_1 + 0x208) = *(undefined8 *)(param_2 + 0x208);
  *(undefined8 *)(param_1 + 0x210) = *(undefined8 *)(param_2 + 0x210);
  *(undefined8 *)(param_1 + 0x218) = *(undefined8 *)(param_2 + 0x218);
  *(undefined8 *)(param_1 + 0x220) = *(undefined8 *)(param_2 + 0x220);
  *(undefined8 *)(param_1 + 0x228) = *(undefined8 *)(param_2 + 0x228);
  *(undefined8 *)(param_1 + 0x230) = *(undefined8 *)(param_2 + 0x230);
  *(undefined8 *)(param_1 + 0x238) = *(undefined8 *)(param_2 + 0x238);
  *(undefined8 *)(param_1 + 0x240) = *(undefined8 *)(param_2 + 0x240);
  *(undefined8 *)(param_1 + 0x248) = *(undefined8 *)(param_2 + 0x248);
  *(undefined8 *)(param_1 + 0x250) = *(undefined8 *)(param_2 + 0x250);
  *(undefined8 *)(param_1 + 600) = *(undefined8 *)(param_2 + 600);
  *(undefined8 *)(param_1 + 0x260) = *(undefined8 *)(param_2 + 0x260);
  FUN_1400f11d0(param_1 + 0x268,param_2 + 0x268);
  *(undefined4 *)(param_1 + 0x298) = *(undefined4 *)(param_2 + 0x298);
  *(undefined4 *)(param_1 + 0x29c) = *(undefined4 *)(param_2 + 0x29c);
  *(undefined4 *)(param_1 + 0x2a0) = *(undefined4 *)(param_2 + 0x2a0);
  *(undefined4 *)(param_1 + 0x2a4) = *(undefined4 *)(param_2 + 0x2a4);
  *(undefined4 *)(param_1 + 0x2a8) = *(undefined4 *)(param_2 + 0x2a8);
  *(undefined4 *)(param_1 + 0x2ac) = *(undefined4 *)(param_2 + 0x2ac);
  *(undefined4 *)(param_1 + 0x2b0) = *(undefined4 *)(param_2 + 0x2b0);
  *(undefined4 *)(param_1 + 0x2b4) = *(undefined4 *)(param_2 + 0x2b4);
  *(undefined4 *)(param_1 + 0x2b8) = *(undefined4 *)(param_2 + 0x2b8);
  *(undefined4 *)(param_1 + 700) = *(undefined4 *)(param_2 + 700);
  *(undefined4 *)(param_1 + 0x2c0) = *(undefined4 *)(param_2 + 0x2c0);
  *(undefined4 *)(param_1 + 0x2c4) = *(undefined4 *)(param_2 + 0x2c4);
  *(undefined4 *)(param_1 + 0x2c8) = *(undefined4 *)(param_2 + 0x2c8);
  *(undefined4 *)(param_1 + 0x2cc) = *(undefined4 *)(param_2 + 0x2cc);
  *(undefined1 *)(param_1 + 0x2d0) = *(undefined1 *)(param_2 + 0x2d0);
  *(undefined4 *)(param_1 + 0x2d4) = *(undefined4 *)(param_2 + 0x2d4);
  *(undefined1 *)(param_1 + 0x2d8) = *(undefined1 *)(param_2 + 0x2d8);
  *(undefined4 *)(param_1 + 0x2dc) = *(undefined4 *)(param_2 + 0x2dc);
  FUN_1400eafd0(param_1 + 0x2e0,param_2 + 0x2e0);
  *(undefined4 *)(param_1 + 0x310) = *(undefined4 *)(param_2 + 0x310);
  *(undefined4 *)(param_1 + 0x314) = *(undefined4 *)(param_2 + 0x314);
  puVar1 = (undefined8 *)(param_1 + 0x348);
  *(undefined1 *)(param_1 + 0x318) = *(undefined1 *)(param_2 + 0x318);
  *(undefined4 *)(param_1 + 0x31c) = *(undefined4 *)(param_2 + 0x31c);
  *(undefined4 *)(param_1 + 800) = *(undefined4 *)(param_2 + 800);
  *(undefined1 *)(param_1 + 0x324) = *(undefined1 *)(param_2 + 0x324);
  *(undefined4 *)(param_1 + 0x328) = *(undefined4 *)(param_2 + 0x328);
  *(undefined4 *)(param_1 + 0x32c) = *(undefined4 *)(param_2 + 0x32c);
  *(undefined4 *)(param_1 + 0x330) = *(undefined4 *)(param_2 + 0x330);
  *(undefined4 *)(param_1 + 0x334) = *(undefined4 *)(param_2 + 0x334);
  *(undefined4 *)(param_1 + 0x338) = *(undefined4 *)(param_2 + 0x338);
  *(undefined1 *)(param_1 + 0x33c) = *(undefined1 *)(param_2 + 0x33c);
  *(undefined4 *)(param_1 + 0x340) = *(undefined4 *)(param_2 + 0x340);
  *(undefined1 *)(param_1 + 0x344) = *(undefined1 *)(param_2 + 0x344);
  if (puVar1 != (undefined8 *)(param_2 + 0x348)) {
    local_38 = *puVar1;
    puStack_30 = *(undefined8 **)(param_1 + 0x378);
    puStack_20 = (undefined8 *)*puStack_30;
    local_28 = local_38;
    FUN_14009e180(puVar1,local_18,&local_28,&local_38);
    FUN_1400e77d0(puVar1,(undefined8 *)(param_2 + 0x348));
  }
  FUN_1400eb180(param_1 + 0x388,param_2 + 0x388);
  *(undefined4 *)(param_1 + 0x3b8) = *(undefined4 *)(param_2 + 0x3b8);
  puVar1 = (undefined8 *)(param_1 + 0x3c0);
  *(undefined1 *)(param_1 + 0x3bc) = *(undefined1 *)(param_2 + 0x3bc);
  if (puVar1 != (undefined8 *)(param_2 + 0x3c0)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x3f0);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_140017580(puVar1,local_18,&local_38,&local_28);
    FUN_1400e75c0(puVar1,(undefined8 *)(param_2 + 0x3c0));
  }
  *(undefined1 *)(param_1 + 0x400) = *(undefined1 *)(param_2 + 0x400);
  *(undefined4 *)(param_1 + 0x404) = *(undefined4 *)(param_2 + 0x404);
  memcpy((void *)(param_1 + 0x408),(void *)(param_2 + 0x408),0x2c);
  puVar1 = (undefined8 *)(param_1 + 0x438);
  if (puVar1 != (undefined8 *)(param_2 + 0x438)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x468);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4360(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7880(puVar1,(undefined8 *)(param_2 + 0x438));
  }
  puVar1 = (undefined8 *)(param_1 + 0x478);
  if (puVar1 != (undefined8 *)(param_2 + 0x478)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x4a8);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4510(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7930(puVar1,(undefined8 *)(param_2 + 0x478));
  }
  if (param_1 + 0x4b8 != param_2 + 0x4b8) {
    FUN_1400ef8d0();
  }
  puVar1 = (undefined8 *)(param_1 + 0x548);
  if (puVar1 != (undefined8 *)(param_2 + 0x548)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x578);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4510(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7930(puVar1,(undefined8 *)(param_2 + 0x548));
  }
  puVar1 = (undefined8 *)(param_1 + 0x588);
  if (puVar1 != (undefined8 *)(param_2 + 0x588)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x5b8);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4510(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7930(puVar1,(undefined8 *)(param_2 + 0x588));
  }
  puVar1 = (undefined8 *)(param_1 + 0x5c8);
  if (puVar1 != (undefined8 *)(param_2 + 0x5c8)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x5f8);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4100(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7720(puVar1,(undefined8 *)(param_2 + 0x5c8));
  }
  puVar1 = (undefined8 *)(param_1 + 0x608);
  if (puVar1 != (undefined8 *)(param_2 + 0x608)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x638);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4870(puVar1,local_18,&local_38,&local_28);
    FUN_1400e79e0(puVar1,(undefined8 *)(param_2 + 0x608));
  }
  puVar1 = (undefined8 *)(param_1 + 0x648);
  if (puVar1 != (undefined8 *)(param_2 + 0x648)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x678);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_140050400(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7670(puVar1,(undefined8 *)(param_2 + 0x648));
  }
  puVar1 = (undefined8 *)(param_1 + 0x6e0);
  *(undefined4 *)(param_1 + 0x688) = *(undefined4 *)(param_2 + 0x688);
  *(undefined4 *)(param_1 + 0x68c) = *(undefined4 *)(param_2 + 0x68c);
  *(undefined4 *)(param_1 + 0x690) = *(undefined4 *)(param_2 + 0x690);
  *(undefined4 *)(param_1 + 0x694) = *(undefined4 *)(param_2 + 0x694);
  *(undefined4 *)(param_1 + 0x698) = *(undefined4 *)(param_2 + 0x698);
  *(undefined1 *)(param_1 + 0x69c) = *(undefined1 *)(param_2 + 0x69c);
  *(undefined1 *)(param_1 + 0x69d) = *(undefined1 *)(param_2 + 0x69d);
  *(undefined1 *)(param_1 + 0x69e) = *(undefined1 *)(param_2 + 0x69e);
  *(undefined1 *)(param_1 + 0x69f) = *(undefined1 *)(param_2 + 0x69f);
  *(undefined1 *)(param_1 + 0x6a0) = *(undefined1 *)(param_2 + 0x6a0);
  *(undefined1 *)(param_1 + 0x6a1) = *(undefined1 *)(param_2 + 0x6a1);
  *(undefined1 *)(param_1 + 0x6a2) = *(undefined1 *)(param_2 + 0x6a2);
  *(undefined1 *)(param_1 + 0x6a3) = *(undefined1 *)(param_2 + 0x6a3);
  *(undefined4 *)(param_1 + 0x6a4) = *(undefined4 *)(param_2 + 0x6a4);
  *(undefined4 *)(param_1 + 0x6a8) = *(undefined4 *)(param_2 + 0x6a8);
  *(undefined4 *)(param_1 + 0x6ac) = *(undefined4 *)(param_2 + 0x6ac);
  *(undefined4 *)(param_1 + 0x6b0) = *(undefined4 *)(param_2 + 0x6b0);
  *(undefined4 *)(param_1 + 0x6b4) = *(undefined4 *)(param_2 + 0x6b4);
  *(undefined4 *)(param_1 + 0x6b8) = *(undefined4 *)(param_2 + 0x6b8);
  *(undefined4 *)(param_1 + 0x6bc) = *(undefined4 *)(param_2 + 0x6bc);
  *(undefined4 *)(param_1 + 0x6c0) = *(undefined4 *)(param_2 + 0x6c0);
  *(undefined4 *)(param_1 + 0x6c4) = *(undefined4 *)(param_2 + 0x6c4);
  *(undefined4 *)(param_1 + 0x6c8) = *(undefined4 *)(param_2 + 0x6c8);
  *(undefined4 *)(param_1 + 0x6cc) = *(undefined4 *)(param_2 + 0x6cc);
  *(undefined4 *)(param_1 + 0x6d0) = *(undefined4 *)(param_2 + 0x6d0);
  *(undefined4 *)(param_1 + 0x6d4) = *(undefined4 *)(param_2 + 0x6d4);
  *(undefined4 *)(param_1 + 0x6d8) = *(undefined4 *)(param_2 + 0x6d8);
  if (puVar1 != (undefined8 *)(param_2 + 0x6e0)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x710);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4bd0(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7a90(puVar1,(undefined8 *)(param_2 + 0x6e0));
  }
  puVar1 = (undefined8 *)(param_1 + 0x738);
  *(undefined4 *)(param_1 + 0x720) = *(undefined4 *)(param_2 + 0x720);
  *(undefined8 *)(param_1 + 0x724) = *(undefined8 *)(param_2 + 0x724);
  *(undefined4 *)(param_1 + 0x72c) = *(undefined4 *)(param_2 + 0x72c);
  *(undefined1 *)(param_1 + 0x730) = *(undefined1 *)(param_2 + 0x730);
  *(undefined1 *)(param_1 + 0x731) = *(undefined1 *)(param_2 + 0x731);
  if (puVar1 != (undefined8 *)(param_2 + 0x738)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x768);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a3f50(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7510(puVar1,(undefined8 *)(param_2 + 0x738));
  }
  puVar1 = (undefined8 *)(param_1 + 0x800);
  *(undefined4 *)(param_1 + 0x778) = *(undefined4 *)(param_2 + 0x778);
  *(undefined1 *)(param_1 + 0x77c) = *(undefined1 *)(param_2 + 0x77c);
  *(undefined4 *)(param_1 + 0x780) = *(undefined4 *)(param_2 + 0x780);
  *(undefined4 *)(param_1 + 0x784) = *(undefined4 *)(param_2 + 0x784);
  *(undefined4 *)(param_1 + 0x788) = *(undefined4 *)(param_2 + 0x788);
  *(undefined4 *)(param_1 + 0x78c) = *(undefined4 *)(param_2 + 0x78c);
  *(undefined4 *)(param_1 + 0x790) = *(undefined4 *)(param_2 + 0x790);
  *(undefined4 *)(param_1 + 0x794) = *(undefined4 *)(param_2 + 0x794);
  *(undefined4 *)(param_1 + 0x798) = *(undefined4 *)(param_2 + 0x798);
  *(undefined4 *)(param_1 + 0x79c) = *(undefined4 *)(param_2 + 0x79c);
  *(undefined4 *)(param_1 + 0x7a0) = *(undefined4 *)(param_2 + 0x7a0);
  *(undefined4 *)(param_1 + 0x7a4) = *(undefined4 *)(param_2 + 0x7a4);
  *(undefined4 *)(param_1 + 0x7a8) = *(undefined4 *)(param_2 + 0x7a8);
  *(undefined4 *)(param_1 + 0x7ac) = *(undefined4 *)(param_2 + 0x7ac);
  *(undefined4 *)(param_1 + 0x7b0) = *(undefined4 *)(param_2 + 0x7b0);
  *(undefined4 *)(param_1 + 0x7b4) = *(undefined4 *)(param_2 + 0x7b4);
  *(undefined4 *)(param_1 + 0x7b8) = *(undefined4 *)(param_2 + 0x7b8);
  *(undefined4 *)(param_1 + 0x7bc) = *(undefined4 *)(param_2 + 0x7bc);
  *(undefined4 *)(param_1 + 0x7c0) = *(undefined4 *)(param_2 + 0x7c0);
  *(undefined4 *)(param_1 + 0x7c4) = *(undefined4 *)(param_2 + 0x7c4);
  *(undefined4 *)(param_1 + 0x7c8) = *(undefined4 *)(param_2 + 0x7c8);
  *(undefined4 *)(param_1 + 0x7cc) = *(undefined4 *)(param_2 + 0x7cc);
  *(undefined4 *)(param_1 + 2000) = *(undefined4 *)(param_2 + 2000);
  *(undefined4 *)(param_1 + 0x7d4) = *(undefined4 *)(param_2 + 0x7d4);
  *(undefined4 *)(param_1 + 0x7d8) = *(undefined4 *)(param_2 + 0x7d8);
  *(undefined4 *)(param_1 + 0x7dc) = *(undefined4 *)(param_2 + 0x7dc);
  *(undefined4 *)(param_1 + 0x7e0) = *(undefined4 *)(param_2 + 0x7e0);
  *(undefined4 *)(param_1 + 0x7e4) = *(undefined4 *)(param_2 + 0x7e4);
  *(undefined4 *)(param_1 + 0x7e8) = *(undefined4 *)(param_2 + 0x7e8);
  *(undefined4 *)(param_1 + 0x7ec) = *(undefined4 *)(param_2 + 0x7ec);
  *(undefined4 *)(param_1 + 0x7f0) = *(undefined4 *)(param_2 + 0x7f0);
  *(undefined4 *)(param_1 + 0x7f4) = *(undefined4 *)(param_2 + 0x7f4);
  *(undefined4 *)(param_1 + 0x7f8) = *(undefined4 *)(param_2 + 0x7f8);
  *(undefined4 *)(param_1 + 0x7fc) = *(undefined4 *)(param_2 + 0x7fc);
  if (puVar1 != (undefined8 *)(param_2 + 0x800)) {
    local_38 = *puVar1;
    puStack_20 = *(undefined8 **)(param_1 + 0x830);
    puStack_30 = (undefined8 *)*puStack_20;
    local_28 = local_38;
    FUN_1400a4d80(puVar1,local_18,&local_38,&local_28);
    FUN_1400e7b40(puVar1,(undefined8 *)(param_2 + 0x800));
  }
  *(undefined4 *)(param_1 + 0x840) = *(undefined4 *)(param_2 + 0x840);
  *(undefined4 *)(param_1 + 0x844) = *(undefined4 *)(param_2 + 0x844);
  *(undefined4 *)(param_1 + 0x848) = *(undefined4 *)(param_2 + 0x848);
  return param_1;
}

// ==== CMapGroupKernel::helper_1400f2330  @1400f2330  [medium:callgraph-r3]  (orig: FUN_1400f2330)
longlong FUN_1400f2330(longlong param_1,longlong param_2,longlong param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 0x850) {
    if (param_3 != 0) {
      FUN_1400f0820(param_3,param_1);
    }
    param_3 = param_3 + 0x850;
  }
  return param_3;
}

// ==== CMapGroupKernel::helper_1400f23b0  @1400f23b0  [medium:callgraph-r2]  (orig: FUN_1400f23b0)
longlong FUN_1400f23b0(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar1 = param_3 - param_1;
    do {
      FUN_1400f1410(lVar1 + param_1,param_1);
      param_1 = param_1 + 0x850;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x850) * 0x850 + param_3;
}

// ==== CMapGroupKernel::helper_1400f2490  @1400f2490  [medium:callgraph-r3]  (orig: FUN_1400f2490)
void FUN_1400f2490(longlong param_1,longlong param_2,undefined8 param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != 0) {
      FUN_1400f0820(param_1,param_3);
    }
    param_1 = param_1 + 0x850;
  }
  return;
}

// ==== CMapGroupKernel::helper_1400f2510  @1400f2510  [medium:callgraph-r3]  (orig: FUN_1400f2510)
longlong FUN_1400f2510(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar2 = param_3 - param_2;
    do {
      param_2 = param_2 + -0x850;
      FUN_1400f1410(lVar2 + param_2,param_2);
    } while (param_2 != param_1);
  }
  return param_3 + (lVar1 / 0x850) * -0x850;
}

// ==== CMapGroupKernel::helper_1400f2880  @1400f2880  [medium:callgraph-r2]  (orig: FUN_1400f2880)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f2880(longlong param_1,longlong param_2,ulonglong param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  ulonglong uVar5;
  longlong lVar6;
  undefined1 auStack_908 [32];
  undefined1 local_8e8;
  undefined1 local_8e0;
  undefined1 local_8d8;
  undefined4 local_8d4;
  longlong local_8d0;
  longlong local_8c8;
  ulonglong local_8c0;
  longlong local_8b8;
  undefined8 local_8b0;
  undefined8 local_8a8;
  undefined1 local_898 [2128];
  ulonglong local_48;
  
  local_8a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_908;
  lVar2 = *(longlong *)(param_1 + 0x18);
  if (lVar2 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = (*(longlong *)(param_1 + 0x28) - lVar2) / 0x850;
  }
  if (param_3 != 0) {
    lVar2 = (*(longlong *)(param_1 + 0x20) - lVar2) / 0x850;
    local_8d0 = param_2;
    local_8c8 = param_1;
    local_8c0 = param_3;
    local_8b0 = param_4;
    if (0x1ecc07b301ecc0U - lVar2 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_14008d7b0();
    }
    uVar1 = lVar2 + param_3;
    if (uVar5 < uVar1) {
      if (0x1ecc07b301ecc0 - (uVar5 >> 1) < uVar5) {
        uVar5 = 0;
      }
      else {
        uVar5 = uVar5 + (uVar5 >> 1);
      }
      if (uVar5 < uVar1) {
        uVar5 = uVar1;
      }
      lVar3 = FUN_140095130(param_1 + 0x10,uVar5);
      lVar2 = (*(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18)) / 0x850;
      local_8d4 = 0;
      local_8e0 = 0;
      local_8e8 = local_8d8;
      local_8d0 = lVar2;
      local_8b8 = lVar3;
      FUN_1400f2490(lVar2 * 0x850 + lVar3,param_3,local_8b0,param_1 + 0x10);
      local_8d4 = 1;
      local_8e0 = 0;
      local_8e8 = local_8d8;
      FUN_1400f2330(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10);
      local_8d4 = 2;
      local_8e0 = 0;
      local_8e8 = local_8d8;
      FUN_1400f2330(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (param_3 + lVar2) * 0x850 + lVar3,param_1 + 0x10);
      lVar2 = *(longlong *)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (lVar2 != 0) {
        FUN_1400a42b0(param_1,lVar2,*(undefined8 *)(param_1 + 0x20));
        operator_delete(*(void **)(param_1 + 0x18));
      }
      *(ulonglong *)(param_1 + 0x28) = uVar5 * 0x850 + lVar3;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar6 - lVar2) / 0x850) * 0x850 + lVar3;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)((*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x850) <
             param_3) {
      FUN_1400f0820(local_898,param_4);
      local_8e0 = 0;
      local_8e8 = local_8d8;
      FUN_1400f2330(*(longlong *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    *(longlong *)(param_2 + 8) + param_3 * 0x850,param_1 + 0x10);
      local_8e0 = 0;
      local_8e8 = local_8d8;
      FUN_1400f2490(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8)) / 0x850,
                    local_898,param_1 + 0x10);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x850;
      lVar2 = *(longlong *)(param_1 + 0x20);
      for (lVar6 = *(longlong *)(param_2 + 8); lVar6 != lVar2 + param_3 * -0x850;
          lVar6 = lVar6 + 0x850) {
        FUN_1400f1410(lVar6,local_898);
      }
      FUN_1400c5230(local_898);
    }
    else {
      FUN_1400f0820(local_898,param_4);
      lVar2 = *(longlong *)(param_1 + 0x20);
      lVar6 = lVar2 + param_3 * -0x850;
      local_8e0 = 0;
      local_8e8 = local_8d8;
      uVar4 = FUN_1400f2330(lVar6,lVar2,lVar2,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar4;
      local_8e0 = 0;
      local_8e8 = local_8d8;
      FUN_1400f2510(*(undefined8 *)(param_2 + 8),lVar6,lVar2,local_8d8);
      lVar6 = *(longlong *)(param_2 + 8);
      lVar2 = lVar6 + param_3 * 0x850;
      for (; lVar6 != lVar2; lVar6 = lVar6 + 0x850) {
        FUN_1400f1410(lVar6,local_898);
      }
      FUN_1400c5230(local_898);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1400f2c50  @1400f2c50  [medium:callgraph-r1]  (orig: FUN_1400f2c50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1400f2c50(longlong *param_1,ulonglong param_2,undefined8 param_3)

{
  ulonglong uVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  undefined1 auStack_a8 [32];
  undefined1 local_88;
  undefined1 local_80;
  undefined1 local_78;
  longlong local_68;
  ulonglong uStack_60;
  undefined8 local_58;
  undefined8 local_50;
  ulonglong local_48;
  
  local_58 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  uVar1 = param_1[4];
  uVar5 = param_1[3];
  uVar3 = (longlong)(uVar1 - uVar5) / 0x850;
  local_50 = param_3;
  if (uVar3 < param_2) {
    if (uVar1 < uVar5) {
      _invalid_parameter_noinfo();
    }
    local_68 = *param_1;
    uStack_60 = uVar1;
    FUN_1400f2880(param_1,&local_68,param_2 - (param_1[4] - param_1[3]) / 0x850,param_3);
    goto LAB_1400f2e0f;
  }
  if (uVar3 <= param_2) goto LAB_1400f2e0f;
  if (uVar1 < uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar5 = param_1[3];
  if ((ulonglong)param_1[4] < uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar8 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar7 = lVar8;
  }
  else {
    lVar7 = *plVar2;
  }
  uVar5 = param_2 * 0x850 + uVar5;
  if (*(ulonglong *)(lVar7 + 0x20) < uVar5) {
LAB_1400f2d6e:
    _invalid_parameter_noinfo();
  }
  else {
    if (plVar2 != (longlong *)0x0) {
      lVar8 = *plVar2;
    }
    if (uVar5 < *(ulonglong *)(lVar8 + 0x18)) goto LAB_1400f2d6e;
  }
  if ((uVar5 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar5)) {
    _invalid_parameter_noinfo();
  }
  lVar8 = *param_1;
  if ((uVar1 < (ulonglong)param_1[3]) || ((ulonglong)param_1[4] < uVar1)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar8 == 0) || (lVar8 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (uVar5 != uVar1) {
    local_80 = 0;
    local_88 = local_78;
    plVar4 = (longlong *)FUN_1400f23b0(uVar1,param_1[4],uVar5,local_78);
    plVar2 = (longlong *)param_1[4];
    for (plVar6 = plVar4; plVar6 != plVar2; plVar6 = plVar6 + 0x10a) {
      (**(code **)(*plVar6 + 0x128))(plVar6,0);
    }
    param_1[4] = (longlong)plVar4;
  }
LAB_1400f2e0f:
  FUN_1400c5230(param_3);
  return;
}

// ==== CMapGroupKernel::helper_1400f2ea0  @1400f2ea0  [medium:callgraph-r0]  (orig: FUN_1400f2ea0)
void FUN_1400f2ea0(uint param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  undefined8 uVar2;
  undefined1 local_860 [2136];
  
  uVar2 = 0xfffffffffffffffe;
  if ((ulonglong)((DAT_140975c28 - DAT_140975c20) / 0x850) <= (ulonglong)param_1) {
    uVar1 = FUN_1400c4a90(local_860);
    FUN_1400f2c50(&DAT_140975c08,param_1 + 1,uVar1,param_4,uVar2);
  }
  return;
}

// ==== CMapGroupKernel::vfunc_1  @1400f2f20  [high:rtti-vtable]  (orig: FUN_1400f2f20)
bool FUN_1400f2f20(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  ulong uVar5;
  undefined8 uVar6;
  bool bVar7;
  
  param_1[4] = (longlong)param_2;
  param_1[5] = 0;
  param_1[6] = 0;
  param_1[7] = 0;
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  *(undefined4 *)(param_1 + 2) = uVar3;
  (**(code **)(*(longlong *)param_1[4] + 0x38))();
  (**(code **)(*(longlong *)param_1[4] + 0x40))((longlong *)param_1[4],3000);
  *(undefined4 *)(param_1 + 0x41) = 1;
  if (*(uint *)(param_1 + 2) < 0xe) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar3 = (**(code **)(*(longlong *)param_1[4] + 8))();
  FUN_1400f2ea0(uVar3);
  plVar1 = (longlong *)param_1[4];
  uVar3 = (**(code **)(*param_2 + 8))(param_2);
  uVar4 = (**(code **)(*plVar1 + 8))(plVar1);
  uVar6 = FUN_140008520(uVar4);
  cVar2 = FUN_1400c26d0(uVar6,uVar3,param_1 + 1,param_1[4]);
  if (cVar2 == '\0') {
    uVar3 = (**(code **)(*(longlong *)param_1[4] + 8))();
    uVar6 = FUN_140008520(uVar3);
    FUN_1400c5510(uVar6);
    bVar7 = false;
  }
  else {
    if ((int)param_1[2] == 0xe) {
      *(undefined4 *)(param_1 + 8) = 300;
      uVar5 = tq::TimeGet(0);
      *(uint *)((longlong)param_1 + 0x44) = uVar5 / 1000;
    }
    cVar2 = (**(code **)(*param_1 + 0x10))(param_1);
    bVar7 = cVar2 != '\0';
  }
  return bVar7;
}

// ==== CMapGroupKernel::helper_1400fbec0  @1400fbec0  [medium:callgraph-r1]  (orig: FUN_1400fbec0)
ulonglong FUN_1400fbec0(longlong param_1)

{
  void *_Dst;
  ulonglong uVar1;
  longlong *plVar2;
  ulong uVar3;
  uint uVar4;
  ulonglong uVar5;
  ulonglong uVar6;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  ulonglong extraout_RAX_02;
  longlong lVar7;
  rsize_t _DstSize;
  longlong lVar8;
  
  uVar5 = *(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40);
  if ((uVar5 & 0xfffffffffffffffc) == 0) {
    return uVar5;
  }
  uVar3 = tq::TimeGet(0);
  if (uVar3 / 1000 < (uint)(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x24))) {
    return (ulonglong)uVar3 * 0x10624dd3 & 0xffffffff;
  }
  uVar3 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x24) = uVar3 / 1000;
  uVar5 = (*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40) >> 2) - 1;
  if ((ulonglong)(*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40) >> 2) <= uVar5) {
    _invalid_parameter_noinfo();
  }
  uVar6 = FUN_1400fbb30(param_1,*(undefined4 *)(*(longlong *)(param_1 + 0x40) + uVar5 * 4));
  uVar1 = *(ulonglong *)(param_1 + 0x40);
  if (*(ulonglong *)(param_1 + 0x48) < uVar1) {
    _invalid_parameter_noinfo();
    uVar6 = extraout_RAX;
  }
  plVar2 = *(longlong **)(param_1 + 0x28);
  lVar7 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    uVar6 = extraout_RAX_00;
    lVar8 = lVar7;
  }
  else {
    lVar8 = *plVar2;
  }
  _Dst = (void *)(uVar1 + uVar5 * 4);
  if (_Dst <= *(void **)(lVar8 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar7 = *plVar2;
    }
    if (*(void **)(lVar7 + 0x18) <= _Dst) goto LAB_1400fbfb0;
  }
  _invalid_parameter_noinfo();
  uVar6 = extraout_RAX_01;
LAB_1400fbfb0:
  lVar7 = *(longlong *)(param_1 + 0x48) - ((longlong)_Dst + 4) >> 2;
  if (0 < lVar7) {
    _DstSize = lVar7 << 2;
    uVar4 = memmove_s(_Dst,_DstSize,(void *)((longlong)_Dst + 4),_DstSize);
    uVar6 = (ulonglong)uVar4;
  }
  *(longlong *)(param_1 + 0x48) = *(longlong *)(param_1 + 0x48) + -4;
  if ((_Dst < *(void **)(param_1 + 0x40)) || (*(void **)(param_1 + 0x48) < _Dst)) {
    _invalid_parameter_noinfo();
    uVar6 = extraout_RAX_02;
  }
  return uVar6;
}

// ==== CMapGroupKernel::helper_1400fce20  @1400fce20  [medium:callgraph-r1]  (orig: FUN_1400fce20)
void FUN_1400fce20(undefined8 *param_1)

{
  undefined8 *puVar1;
  
  if (DAT_140975cd0 != (undefined8 *)0x0) {
    FUN_1400667c0();
    puVar1 = DAT_140975cd0;
    if (DAT_140975cd0 != (undefined8 *)0x0) {
      if (DAT_140975cd0[3] != 0) {
        FUN_140066540(DAT_140975cd0[3],DAT_140975cd0[4],DAT_140975cd0 + 2,
                      (ulonglong)DAT_140975cd0 & 0xff);
        operator_delete((void *)puVar1[3]);
      }
      puVar1[3] = 0;
      puVar1[4] = 0;
      puVar1[5] = 0;
      operator_delete((void *)*puVar1);
      operator_delete(puVar1);
    }
    DAT_140975cd0 = (undefined8 *)0x0;
  }
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14010daa0  @14010daa0  [medium:callgraph-r2]  (orig: FUN_14010daa0)
void FUN_14010daa0(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x69);
  while (cVar1 == '\0') {
    FUN_14010daa0(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x69);
  }
  return;
}

// ==== CMapGroupKernel::helper_14010ea30  @14010ea30  [medium:callgraph-r3]  (orig: FUN_14010ea30)
longlong * FUN_14010ea30(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14010d7f0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14010def0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_14010ec30  @14010ec30  [medium:callgraph-r3]  (orig: FUN_14010ec30)
longlong * FUN_14010ec30(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14010daa0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x69) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x69) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x69);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x69);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x69);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x69);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14010e500(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_14010f280  @14010f280  [medium:callgraph-r2]  (orig: FUN_14010f280)
void FUN_14010f280(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14010ea30((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_14010f370  @14010f370  [medium:callgraph-r2]  (orig: FUN_14010f370)
void FUN_14010f370(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14010ec30((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_14010f4a0  @14010f4a0  [medium:callgraph-r1]  (orig: FUN_14010f4a0)
void FUN_14010f4a0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  
  puVar1 = param_1 + 0x19;
  FUN_14010daa0(puVar1,*(undefined8 *)(param_1[0x1f] + 8),param_3,param_4,0xfffffffffffffffe);
  *(undefined8 *)(param_1[0x1f] + 8) = param_1[0x1f];
  param_1[0x20] = 0;
  *(undefined8 *)param_1[0x1f] = param_1[0x1f];
  *(undefined8 *)(param_1[0x1f] + 0x10) = param_1[0x1f];
  FUN_14010f370(puVar1);
  operator_delete((void *)*puVar1);
  FUN_140050610(param_1 + 0x10);
  operator_delete((void *)param_1[0x10]);
  FUN_140050610(param_1 + 8);
  operator_delete((void *)param_1[8]);
  FUN_14010f280(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapGroupKernel::helper_140112880  @140112880  [medium:callgraph-r1]  (orig: FUN_140112880)
void FUN_140112880(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar2 = *(longlong **)(param_1 + 0x10);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x40);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x40);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar3) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_140377230(plVar5[4]);
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_14013b0c0  @14013b0c0  [medium:callgraph-r0]  (orig: FUN_14013b0c0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_14013b0c0(void)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong **pplVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong *local_38;
  longlong *plStack_30;
  longlong *local_28;
  longlong *local_20;
  longlong *local_18;
  longlong *local_10;
  
  plVar3 = DAT_140975d70;
  plVar7 = (longlong *)*DAT_140975da0;
  local_38 = DAT_140975d70;
  plStack_30 = plVar7;
  while( true ) {
    plVar2 = DAT_140975da0;
    if ((plVar3 == (longlong *)0x0) || (plVar3 != DAT_140975d70)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar2) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = DAT_140975de0;
    plVar8 = DAT_140975de0;
    if (*(char *)(DAT_140975de0[1] + 0x29) == '\0') {
      plVar4 = (longlong *)DAT_140975de0[1];
      do {
        if (*(uint *)(plVar4 + 3) < *(uint *)(plVar7 + 3)) {
          plVar5 = (longlong *)plVar4[2];
        }
        else {
          plVar5 = (longlong *)*plVar4;
          plVar8 = plVar4;
        }
        plVar4 = plVar5;
      } while (*(char *)((longlong)plVar5 + 0x29) == '\0');
    }
    plStack_30 = plVar8;
    local_38 = DAT_140975db0;
    if (DAT_140975db0 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    plVar4 = DAT_140975de0;
    if ((plVar8 == plVar2) || (*(uint *)(plVar7 + 3) < *(uint *)(plVar8 + 3))) {
      pplVar6 = &local_28;
      local_20 = DAT_140975de0;
      local_28 = DAT_140975db0;
    }
    else {
      pplVar6 = &local_38;
    }
    plVar2 = *pplVar6;
    local_18 = plVar2;
    local_10 = pplVar6[1];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != DAT_140975db0)) {
      _invalid_parameter_noinfo();
    }
    plVar8 = local_10;
    if (local_10 != plVar4) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar2;
      }
      if (plVar8 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::OverTimeLogSave("syslog/overtime",
                          "ProcessActionType=%u, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                          (int)plVar8[3],(int)plVar8[4]);
    }
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x1d) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x1d) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x1d);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x1d);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x1d);
        plVar8 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar8, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x1d);
          plVar8 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)(DAT_140975da0[1] + 0x1d);
  plVar7 = (longlong *)DAT_140975da0[1];
  while (cVar1 == '\0') {
    FUN_1400098c0(&DAT_140975d70,plVar7[2]);
    plVar3 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x1d);
  }
  DAT_140975da0[1] = (longlong)DAT_140975da0;
  _DAT_140975da8 = 0;
  *DAT_140975da0 = (longlong)DAT_140975da0;
  DAT_140975da0[2] = (longlong)DAT_140975da0;
  cVar1 = *(char *)(DAT_140975de0[1] + 0x29);
  plVar7 = (longlong *)DAT_140975de0[1];
  while (cVar1 == '\0') {
    FUN_1400e4cc0(&DAT_140975db0,plVar7[2]);
    plVar3 = (longlong *)*plVar7;
    operator_delete(plVar7);
    plVar7 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  DAT_140975de0[1] = (longlong)DAT_140975de0;
  _DAT_140975de8 = 0;
  *DAT_140975de0 = (longlong)DAT_140975de0;
  DAT_140975de0[2] = (longlong)DAT_140975de0;
  return;
}

// ==== CMapGroupKernel::helper_14014a810  @14014a810  [medium:callgraph-r2]  (orig: FUN_14014a810)
void FUN_14014a810(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_14014a810(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_14014d470  @14014d470  [medium:callgraph-r1]  (orig: FUN_14014d470)
void FUN_14014d470(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((longlong *)plVar4[4] != (longlong *)0x0) {
      (**(code **)(*(longlong *)plVar4[4] + 0x58))();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x29);
  while (cVar1 == '\0') {
    FUN_14014a810(param_1 + 8,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x78) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x21);
  while (cVar1 == '\0') {
    FUN_14014a860(param_1 + 0x48,plVar4[2]);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x21);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 8) = *(longlong *)(param_1 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x78);
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 0x10) = *(longlong *)(param_1 + 0x78);
  return;
}

// ==== CMapGroupKernel::helper_14014f6e0  @14014f6e0  [medium:callgraph-r2]  (orig: FUN_14014f6e0)
void FUN_14014f6e0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x31);
  while (cVar1 == '\0') {
    FUN_14014f6e0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x31);
  }
  return;
}

// ==== CMapGroupKernel::helper_140150870  @140150870  [medium:callgraph-r1]  (orig: FUN_140150870)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_140150870(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  
  plVar4 = DAT_140975e00;
  uVar7 = 0xfffffffffffffffe;
  puVar5 = (undefined8 *)*DAT_140975e30;
  plVar8 = DAT_140975e00;
  puVar9 = puVar5;
  while( true ) {
    puVar2 = DAT_140975e30;
    if ((plVar4 == (longlong *)0x0) || (plVar4 != DAT_140975e00)) {
      _invalid_parameter_noinfo();
    }
    if (puVar5 == puVar2) break;
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar4;
    }
    if (puVar5 == *(undefined8 **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar2 = (undefined8 *)puVar5[5];
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar5 + 0x31) == '\0') {
      puVar9 = (undefined8 *)puVar5[2];
      if (*(char *)((longlong)puVar9 + 0x31) == '\0') {
        cVar1 = *(char *)((longlong)*puVar9 + 0x31);
        puVar5 = puVar9;
        puVar2 = (undefined8 *)*puVar9;
        while (puVar9 = puVar5, cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar2 + 0x31);
          puVar5 = puVar2;
          puVar2 = (undefined8 *)*puVar2;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar5[1] + 0x31);
        puVar9 = (undefined8 *)puVar5[1];
        puVar2 = puVar5;
        while ((puVar5 = puVar9, puVar9 = puVar5, cVar1 == '\0' &&
               (puVar2 == (undefined8 *)puVar5[2]))) {
          cVar1 = *(char *)((longlong)puVar5[1] + 0x31);
          puVar9 = (undefined8 *)puVar5[1];
          puVar2 = puVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)DAT_140975e30[1] + 0x31);
  plVar4 = (longlong *)DAT_140975e30[1];
  while (cVar1 == '\0') {
    FUN_14014f6e0(&DAT_140975e00,plVar4[2],param_3,param_4,uVar7,plVar8,puVar9);
    plVar3 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x31);
  }
  DAT_140975e30[1] = DAT_140975e30;
  _DAT_140975e38 = 0;
  *DAT_140975e30 = DAT_140975e30;
  DAT_140975e30[2] = DAT_140975e30;
  return;
}

// ==== CMapGroupKernel::helper_140153cc0  @140153cc0  [medium:callgraph-r2]  (orig: FUN_140153cc0)
void FUN_140153cc0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153cc0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_140153d10  @140153d10  [medium:callgraph-r2]  (orig: FUN_140153d10)
void FUN_140153d10(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153d10(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_140153d60  @140153d60  [medium:callgraph-r2]  (orig: FUN_140153d60)
void FUN_140153d60(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153d60(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_140156080  @140156080  [medium:callgraph-r1]  (orig: FUN_140156080)
void FUN_140156080(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  
  uVar7 = 0xfffffffffffffffe;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plVar8 = plVar2;
  plVar9 = plVar5;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      FUN_1403aee70(puVar4);
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar9 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar9 + 0x29);
        plVar5 = plVar9;
        plVar3 = (longlong *)*plVar9;
        while (plVar9 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar9, plVar9 = plVar5, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2])
               )) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153cc0(param_1 + 8,plVar5[2],param_3,param_4,uVar7,plVar8,plVar9);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x80);
  plVar2 = *(longlong **)(param_1 + 0x50);
  while( true ) {
    plVar8 = *(longlong **)(param_1 + 0x80);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x50))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar8) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar5 = plVar8;
        plVar8 = (longlong *)*plVar8;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar8 + 0x29);
          plVar5 = plVar8;
          plVar8 = (longlong *)*plVar8;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar8 = plVar5;
        while ((plVar5 = plVar9, cVar1 == '\0' && (plVar8 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar8 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x80) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153d10(param_1 + 0x50,plVar5[2]);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x80) + 8) = *(longlong *)(param_1 + 0x80);
  *(undefined8 *)(param_1 + 0x88) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x80) = *(undefined8 *)(param_1 + 0x80);
  *(longlong *)(*(longlong *)(param_1 + 0x80) + 0x10) = *(longlong *)(param_1 + 0x80);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0xc0);
  plVar2 = *(longlong **)(param_1 + 0x90);
  while( true ) {
    plVar8 = *(longlong **)(param_1 + 0xc0);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x90))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar8) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar4 = (undefined8 *)plVar5[4];
    if (puVar4 != (undefined8 *)0x0) {
      (**(code **)*puVar4)(puVar4,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar5 = plVar8;
        plVar8 = (longlong *)*plVar8;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar8 + 0x29);
          plVar5 = plVar8;
          plVar8 = (longlong *)*plVar8;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar9 = (longlong *)plVar5[1];
        plVar8 = plVar5;
        while ((plVar5 = plVar9, cVar1 == '\0' && (plVar8 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar9 = (longlong *)plVar5[1];
          plVar8 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0xc0) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_140153d60(param_1 + 0x90,plVar5[2]);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0xc0) + 8) = *(longlong *)(param_1 + 0xc0);
  *(undefined8 *)(param_1 + 200) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0xc0) = *(undefined8 *)(param_1 + 0xc0);
  *(longlong *)(*(longlong *)(param_1 + 0xc0) + 0x10) = *(longlong *)(param_1 + 0xc0);
  return;
}

// ==== CMapGroupKernel::helper_1401599e0  @1401599e0  [medium:callgraph-r1]  (orig: FUN_1401599e0)
void FUN_1401599e0(__uint64 param_1)

{
  if ((DAT_140975e58 & 1) == 0) {
    DAT_140975e58 = DAT_140975e58 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975e50,"CNpcManager");
    atexit((_func_5014 *)&LAB_1406d68c0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140159a35. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Alloc((CMyHeap *)&DAT_140975e50,param_1);
  return;
}

// ==== CMapGroupKernel::helper_140159b80  @140159b80  [medium:callgraph-r1]  (orig: FUN_140159b80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140159b80(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong lVar11;
  uint uVar12;
  ulonglong uVar14;
  ulonglong uVar15;
  undefined1 auStack_468 [32];
  undefined4 local_448;
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  ulonglong uVar13;
  
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_468;
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  _snprintf(&local_438,0x3ff,"SELECT * FROM cq_npc WHERE idxserver=-1");
  FUN_140008520(*(undefined4 *)(param_1 + 8));
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_438,2);
  uVar9 = 0;
  if (plVar6 != (longlong *)0x0) {
    uVar15 = 0;
    iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
    uVar13 = uVar15;
    if (0 < iVar3) {
      do {
        (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)(int)uVar13);
        lVar7 = FUN_1402c0d80();
        if (lVar7 == 0) {
          (**(code **)*plVar6)(plVar6);
          goto LAB_140159d8e;
        }
        cVar2 = FUN_1402c29d0(lVar7,*(undefined4 *)(param_1 + 8),plVar6,0);
        if (cVar2 == '\0') {
          (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))(lVar7 + 0x10);
        }
        else {
          lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          if (*(longlong *)(lVar11 + 0x88) == 0) {
            local_448 = 0x12f;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar11 + 0x88) + 0x30))();
          (**(code **)(*plVar8 + 0x28))(plVar8,lVar7 + 0x10);
        }
        uVar12 = (int)uVar13 + 1;
        uVar13 = (ulonglong)uVar12;
        iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
      } while ((int)uVar12 < iVar3);
    }
    (**(code **)*plVar6)(plVar6);
    _snprintf(&local_438,0x3ff,"SELECT * FROM cq_dynanpc WHERE idxserver=-1 ");
    FUN_140008520(*(undefined4 *)(param_1 + 8));
    plVar6 = (longlong *)InstanceGet();
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_438,2);
    if (plVar6 == (longlong *)0x0) {
LAB_140159d8e:
      uVar9 = 0;
    }
    else {
      iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
      uVar13 = uVar15;
      if (0 < iVar3) {
        do {
          (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)(int)uVar13);
          plVar8 = (longlong *)FUN_1402c0d80();
          if (plVar8 == (longlong *)0x0) {
            (**(code **)*plVar6)(plVar6);
            goto LAB_14015a002;
          }
          cVar2 = FUN_1402c29d0(plVar8,*(undefined4 *)(param_1 + 8),plVar6,1);
          if (cVar2 == '\0') {
            (**(code **)(plVar8[2] + 8))(plVar8 + 2);
          }
          else {
            lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            if (*(longlong *)(lVar7 + 0x88) == 0) {
              local_448 = 0x12f;
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            plVar10 = (longlong *)(**(code **)(**(longlong **)(lVar7 + 0x88) + 0x30))();
            plVar1 = plVar8 + 2;
            (**(code **)(*plVar10 + 0x28))(plVar10,plVar1);
            lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            uVar14 = *(ulonglong *)(lVar7 + 0x120);
            if (*(ulonglong *)(lVar7 + 0x120) == 0) {
              local_448 = 0x148;
              log_InlineLogERROR(&DAT_1406d9c10);
              uVar14 = uVar15;
            }
            uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
            uVar5 = (**(code **)(*plVar1 + 0x168))(plVar1);
            FUN_140246900(uVar14,uVar5,uVar4);
          }
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&DAT_1406de8d4);
          iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
          if (iVar3 == 0x334) {
            plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"data0");
            (**(code **)(*plVar8 + 0x48))(plVar8);
            tq::MyLogSave("gmlog/npc_820",&DAT_1407138b8);
          }
          uVar12 = (int)uVar13 + 1;
          uVar13 = (ulonglong)uVar12;
          iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
        } while ((int)uVar12 < iVar3);
      }
      (**(code **)*plVar6)(plVar6);
      _snprintf(&local_438,0x3ff,"SELECT * FROM cq_trap");
      FUN_140008520(*(undefined4 *)(param_1 + 8));
      plVar6 = (longlong *)InstanceGet();
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_438,2);
      if (plVar6 == (longlong *)0x0) {
LAB_14015a002:
        uVar9 = 0;
      }
      else {
        iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
        if (0 < iVar3) {
          do {
            (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)(int)uVar15);
            lVar7 = FUN_1403ab350(*(undefined4 *)(param_1 + 8),plVar6);
            if (lVar7 != 0) {
              lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 8));
              if (*(longlong *)(lVar11 + 0x88) == 0) {
                local_448 = 0x12f;
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              plVar8 = (longlong *)(**(code **)(**(longlong **)(lVar11 + 0x88) + 0x30))();
              (**(code **)(*plVar8 + 0x28))(plVar8,lVar7 + 0x10);
            }
            uVar12 = (int)uVar15 + 1;
            uVar15 = (ulonglong)uVar12;
            iVar3 = (**(code **)(*plVar6 + 0x40))(plVar6);
          } while ((int)uVar12 < iVar3);
        }
        (**(code **)*plVar6)(plVar6);
        uVar9 = 1;
      }
    }
  }
  return uVar9;
}

// ==== CMapGroupKernel::helper_1401d8da0  @1401d8da0  [medium:callgraph-r0]  (orig: FUN_1401d8da0)
undefined1 FUN_1401d8da0(longlong param_1)

{
  char cVar1;
  
  if (*(longlong *)(param_1 + 0x30) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  cVar1 = FUN_1403fd4d0();
  if (cVar1 == '\0') {
    log_InlineLogERROR("m_pTotalPowerValueSort->Init error.at %s, %d");
    return 0;
  }
  return 1;
}

// ==== CMapGroupKernel::helper_1401ebbc0  @1401ebbc0  [medium:callgraph-r2]  (orig: FUN_1401ebbc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ebbc0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  longlong *plVar5;
  char cVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  undefined1 auStack_5c8 [32];
  undefined4 local_5a8;
  char local_598;
  longlong local_590;
  longlong *local_588 [3];
  undefined4 *local_570;
  undefined4 *local_568;
  longlong local_560;
  longlong *local_558;
  longlong *local_550;
  longlong *local_548;
  longlong local_540;
  undefined8 local_538;
  undefined8 uStack_530;
  undefined4 local_528;
  undefined4 uStack_524;
  undefined4 uStack_520;
  undefined4 uStack_51c;
  undefined8 local_518;
  undefined1 local_508 [1104];
  char local_b8;
  undefined1 local_b7 [126];
  undefined1 local_39;
  ulonglong local_38;
  
  local_518 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5c8;
  local_590 = param_1;
  local_540 = param_1;
  FUN_140400920(local_508);
  cVar6 = FUN_140400a20(local_508);
  local_598 = cVar6 != '\0';
  local_558 = operator_new(8);
  if (local_558 == (longlong *)0x0) {
    local_588[0] = (longlong *)0x0;
  }
  else {
    *local_558 = (longlong)local_588;
    local_588[0] = local_558;
  }
  lVar11 = 0;
  local_570 = (undefined4 *)0x0;
  local_568 = (undefined4 *)0x0;
  local_560 = 0;
  local_548 = local_558;
  FUN_140036640(local_588);
  plVar9 = (longlong *)**(longlong **)(param_1 + 0x100);
  plVar1 = *(longlong **)(param_1 + 0xd0);
  local_558 = plVar1;
  local_550 = plVar9;
  do {
    plVar2 = *(longlong **)(param_1 + 0x100);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xd0))) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar2) {
      plVar9 = *(longlong **)(*(longlong *)(param_1 + 0x100) + 8);
      cVar6 = *(char *)((longlong)plVar9 + 0x29);
      while (cVar6 == '\0') {
        FUN_1401dd200(param_1 + 0xd0);
        plVar1 = (longlong *)*plVar9;
        operator_delete(plVar9);
        plVar9 = plVar1;
        cVar6 = *(char *)((longlong)plVar1 + 0x29);
      }
      *(longlong *)(*(longlong *)(param_1 + 0x100) + 8) = *(longlong *)(param_1 + 0x100);
      *(undefined8 *)(param_1 + 0x108) = 0;
      *(undefined8 *)*(undefined8 *)(param_1 + 0x100) = *(undefined8 *)(param_1 + 0x100);
      *(longlong *)(*(longlong *)(param_1 + 0x100) + 0x10) = *(longlong *)(param_1 + 0x100);
      if (local_598 != '\0') {
        plVar9 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 8));
        (**(code **)(*plVar9 + 0x40))(plVar9,local_588,local_508);
      }
      plVar9 = (longlong *)InstanceGet();
      local_b8 = '\0';
      memset(local_b7,0,0x7f);
      _snprintf(&local_b8,0x80,"DELETE FROM cq_jianghu_caltivate_times");
      local_39 = 0;
      (**(code **)(*plVar9 + 0x30))(plVar9,&local_b8,1,0);
      if (local_570 != (undefined4 *)0x0) {
        operator_delete(local_570);
      }
      local_570 = (undefined4 *)0x0;
      local_568 = (undefined4 *)0x0;
      local_560 = 0;
      operator_delete(local_588[0]);
      FUN_1404009a0(local_508);
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar11;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar10 = plVar9[4];
    if (lVar10 != 0) {
      lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      if (*(longlong *)(lVar7 + 0x90) == 0) {
        local_5a8 = 0x130;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar2 = *(longlong **)(lVar7 + 0x90);
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar11;
      }
      else {
        lVar7 = *plVar1;
      }
      if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = (**(code **)(*plVar2 + 0x98))(plVar2);
      puVar4 = local_568;
      if (lVar7 != 0) {
        local_548 = (longlong *)CONCAT44(local_548._4_4_,*(undefined4 *)(lVar7 + 0x122c));
        if ((local_570 == (undefined4 *)0x0) ||
           ((ulonglong)(local_560 - (longlong)local_570 >> 2) <=
            (ulonglong)((longlong)local_568 - (longlong)local_570 >> 2))) {
          if (local_568 < local_570) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_570;
          plVar2 = local_588[0];
          local_538 = local_588[0];
          uStack_530 = puVar4;
          lVar7 = lVar11;
          if (((longlong)local_568 - (longlong)local_570 & 0xfffffffffffffffcU) != 0) {
            if (local_568 < local_570) {
              _invalid_parameter_noinfo();
            }
            if ((plVar2 == (longlong *)0x0) || (plVar2 != local_588[0])) {
              _invalid_parameter_noinfo();
            }
            lVar7 = (longlong)puVar4 - (longlong)puVar3 >> 2;
          }
          local_528 = (undefined4)local_538;
          uStack_524 = local_538._4_4_;
          uStack_520 = (undefined4)uStack_530;
          uStack_51c = uStack_530._4_4_;
          FUN_140036c20(local_588,&local_528,1);
          puVar4 = local_570;
          if (local_568 < local_570) {
            _invalid_parameter_noinfo();
          }
          plVar2 = local_588[0];
          if (local_588[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar8 = lVar11;
          }
          else {
            lVar8 = *local_588[0];
          }
          if (puVar4 + lVar7 <= *(undefined4 **)(lVar8 + 0x20)) {
            lVar8 = lVar11;
            if (plVar2 != (longlong *)0x0) {
              lVar8 = *plVar2;
            }
            param_1 = local_590;
            if (*(undefined4 **)(lVar8 + 0x18) <= puVar4 + lVar7) goto LAB_1401ebeaf;
          }
          _invalid_parameter_noinfo();
          param_1 = local_590;
        }
        else {
          *local_568 = *(undefined4 *)(lVar7 + 0x122c);
          local_568 = local_568 + 1;
        }
      }
LAB_1401ebeaf:
      FUN_1403fe770(lVar10);
      FUN_1403fed80(lVar10);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar6 = *(char *)(*plVar2 + 0x29);
        plVar9 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (local_550 = plVar9, cVar6 == '\0') {
          cVar6 = *(char *)(*plVar2 + 0x29);
          plVar9 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar6 = *(char *)(plVar9[1] + 0x29);
        plVar5 = (longlong *)plVar9[1];
        plVar2 = plVar9;
        while ((plVar9 = plVar5, local_550 = plVar9, cVar6 == '\0' &&
               (plVar2 == (longlong *)plVar9[2]))) {
          cVar6 = *(char *)(plVar9[1] + 0x29);
          plVar5 = (longlong *)plVar9[1];
          plVar2 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_1401ec0b0  @1401ec0b0  [medium:callgraph-r1]  (orig: FUN_1401ec0b0)
void FUN_1401ec0b0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  
  iVar4 = tq::DateStamp(0);
  if (*(int *)(param_1 + 0x18) != iVar4) {
    iVar4 = tq::DateStamp(0);
    *(int *)(param_1 + 0x18) = iVar4;
    FUN_1401ebbc0(param_1);
  }
  plVar2 = *(longlong **)(param_1 + 0x90);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0xc0);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar6 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0xc0);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x90))) {
            _invalid_parameter_noinfo();
          }
          if (plVar6 == plVar3) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar6[4] != 0) {
            FUN_1403fe610();
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar6 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar6;
        }
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar6 + 0x29);
          plVar3 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      plVar3 = (longlong *)plVar6[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar5 = plVar3;
      plVar3 = plVar5;
      if (plVar6 != (longlong *)plVar5[2]) break;
      plVar3 = (longlong *)plVar5[1];
      plVar6 = plVar5;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_140205d20  @140205d20  [medium:callgraph-r1]  (orig: FUN_140205d20)
void FUN_140205d20(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulong uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *local_38;
  longlong *plStack_30;
  undefined1 local_28 [32];
  
  if ((*(int *)(param_1 + 0x194) != 0) &&
     (uVar5 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x194) + *(int *)(param_1 + 400)) <= uVar5 / 1000)) {
    uVar5 = tq::TimeGet(0);
    plVar1 = (longlong *)(param_1 + 0x90);
    *(uint *)(param_1 + 0x194) = uVar5 / 1000;
    plVar3 = (longlong *)*plVar1;
    plVar6 = (longlong *)**(longlong **)(param_1 + 0xc0);
    plVar8 = plVar3;
    plVar10 = plVar6;
    while( true ) {
      plVar9 = *(longlong **)(param_1 + 0xc0);
      if ((plVar3 == (longlong *)0x0) || (plVar3 != (longlong *)*plVar1)) {
        _invalid_parameter_noinfo();
      }
      if (plVar6 == plVar9) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar3;
      }
      if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar9 = plVar8;
      if ((int)plVar6[5] == 0) {
LAB_140205e50:
        plVar8 = plVar9;
        plVar11 = plVar10;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x2d) == '\0') {
          plVar11 = (longlong *)plVar6[2];
          if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
            cVar2 = *(char *)(*plVar11 + 0x2d);
            plVar6 = plVar11;
            plVar4 = (longlong *)*plVar11;
            while (plVar11 = plVar6, cVar2 == '\0') {
              cVar2 = *(char *)(*plVar4 + 0x2d);
              plVar6 = plVar4;
              plVar4 = (longlong *)*plVar4;
            }
          }
          else {
            cVar2 = *(char *)(plVar6[1] + 0x2d);
            plVar11 = (longlong *)plVar6[1];
            plVar4 = plVar6;
            while ((plVar6 = plVar11, plVar11 = plVar6, cVar2 == '\0' &&
                   (plVar4 == (longlong *)plVar6[2]))) {
              cVar2 = *(char *)(plVar6[1] + 0x2d);
              plVar11 = (longlong *)plVar6[1];
              plVar4 = plVar6;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_38 = plVar9;
        plStack_30 = plVar10;
        FUN_140203bc0(plVar1,local_28,&local_38,param_4,plVar8,plVar11);
        plVar10 = plVar11;
      }
      else {
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar3;
        }
        if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (((int)plVar6[5] != 0) &&
           (uVar5 = tq::TimeGet(0),
           (uint)(*(int *)((longlong)plVar6 + 0x24) + (int)plVar6[5]) <= uVar5 / 1000)) {
          *(undefined4 *)(plVar6 + 5) = 0;
          *(undefined4 *)((longlong)plVar6 + 0x24) = 0;
          plVar9 = plVar8;
          goto LAB_140205e50;
        }
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x2d) == '\0') {
          plVar10 = (longlong *)plVar6[2];
          if (*(char *)((longlong)plVar10 + 0x2d) == '\0') {
            cVar2 = *(char *)(*plVar10 + 0x2d);
            plVar6 = plVar10;
            plVar9 = (longlong *)*plVar10;
            while (plVar10 = plVar6, cVar2 == '\0') {
              cVar2 = *(char *)(*plVar9 + 0x2d);
              plVar6 = plVar9;
              plVar9 = (longlong *)*plVar9;
            }
          }
          else {
            cVar2 = *(char *)(plVar6[1] + 0x2d);
            plVar10 = (longlong *)plVar6[1];
            plVar9 = plVar6;
            while ((plVar6 = plVar10, plVar10 = plVar6, cVar2 == '\0' &&
                   (plVar9 == (longlong *)plVar6[2]))) {
              cVar2 = *(char *)(plVar6[1] + 0x2d);
              plVar10 = (longlong *)plVar6[1];
              plVar9 = plVar6;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_140208ab0  @140208ab0  [medium:callgraph-r2]  (orig: FUN_140208ab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140208ab0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined1 auStack_e8 [32];
  undefined4 local_c8;
  longlong *local_b8;
  longlong *local_b0;
  longlong local_a8;
  undefined8 local_a0;
  char local_98;
  undefined1 local_97 [126];
  undefined1 local_19;
  ulonglong local_18;
  
  local_a0 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  plVar5 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  local_b8 = plVar2;
  local_b0 = plVar5;
  local_a8 = param_1;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((undefined8 *)plVar5[4] == (undefined8 *)0x0) {
      local_c8 = 0x1a8;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (*(code *)**(undefined8 **)plVar5[4])();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (local_b0 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, local_b0 = plVar5, cVar1 == '\0' &&
               (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar5 + 0x29);
  while (cVar1 == '\0') {
    FUN_14002ca30(param_1 + 8);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  plVar5 = (longlong *)InstanceGet();
  local_98 = '\0';
  memset(local_97,0,0x7f);
  _snprintf(&local_98,0x80,"DELETE FROM cq_sign_everyday");
  local_19 = 0;
  (**(code **)(*plVar5 + 0x30))(plVar5,&local_98,1,0);
  return;
}

// ==== CMapGroupKernel::helper_140208ce0  @140208ce0  [medium:callgraph-r1]  (orig: FUN_140208ce0)
void FUN_140208ce0(undefined4 *param_1)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  
  uVar3 = FUN_140008520(*param_1);
  cVar1 = FUN_14008ac00(uVar3);
  if (cVar1 != '\0') {
    iVar2 = tq::DateStamp(0);
    iVar2 = (iVar2 / 100) % 100;
    if (iVar2 != param_1[0x12]) {
      param_1[0x12] = iVar2;
      FUN_140208ab0(param_1);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_14020a260  @14020a260  [medium:callgraph-r1]  (orig: FUN_14020a260)
void FUN_14020a260(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14020bb50  @14020bb50  [medium:callgraph-r1]  (orig: FUN_14020bb50)
void FUN_14020bb50(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5[4] != 0) {
      FUN_14037f520(plVar5[4],param_2);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_14020c6e0  @14020c6e0  [medium:callgraph-r1]  (orig: FUN_14020c6e0)
void FUN_14020c6e0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140213890  @140213890  [medium:callgraph-r2]  (orig: FUN_140213890)
void FUN_140213890(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  longlong lVar8;
  
  plVar2 = *(longlong **)(param_1 + 0xe0);
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x110);
  lVar8 = 0;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x110);
    if ((*(longlong **)(param_1 + 0xe0) == (longlong *)0x0) ||
       (*(longlong **)(param_1 + 0xe0) != plVar2)) {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar5) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < (int)plVar5[0x15]) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4286\t0\t0\t%d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(undefined4 *)(plVar5 + 0x15) = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar5[0xb];
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if ((int)plVar5[0x14] < (int)lVar7) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4287\t0\t0\t%d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = plVar5[0xb];
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar8;
      }
      else {
        lVar6 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(int *)(plVar5 + 0x14) = (int)lVar7;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < plVar5[0x16]) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4288\t0\t0\t%I64d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5[0x16] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < plVar5[0x18]) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4289\t0\t0\t%I64d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5[0x18] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < *(int *)((longlong)plVar5 + 0xac)) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4290\t0\t0\t%d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(undefined4 *)((longlong)plVar5 + 0xac) = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar5[0x13];
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = lVar8;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(int *)((longlong)plVar5 + 0xa4) < (int)lVar7) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4291\t0\t0\t%d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar7 = plVar5[0x13];
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = lVar8;
      }
      else {
        lVar6 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      *(int *)((longlong)plVar5 + 0xa4) = (int)lVar7;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < plVar5[0x17]) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4292\t0\t0\t%I64d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5[0x17] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (0 < plVar5[0x19]) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::MyLogSave("gmlog/texasstatistic","0\tTexas\t%u\t350\t4293\t0\t0\t%I64d\t");
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = lVar8;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5[0x19] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0xd1) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0xd1) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0xd1);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0xd1);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0xd1);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0xd1);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_140214a10  @140214a10  [medium:callgraph-r1]  (orig: FUN_140214a10)
ulonglong FUN_140214a10(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  ulong uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  longlong lVar8;
  
  plVar2 = *(longlong **)(param_1 + 0x20);
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x50);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x50);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7[4] != 0) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar8 = 0;
      }
      else {
        lVar8 = *plVar2;
      }
      if (plVar7 == *(longlong **)(lVar8 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1403e7d60();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar7 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar7 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar4 = (longlong *)plVar7[1];
        plVar3 = plVar7;
        while ((plVar7 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar4 = (longlong *)plVar7[1];
          plVar3 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  uVar5 = tq::TimeGet(0);
  uVar6 = (ulonglong)uVar5 * 0x10624dd3 & 0xffffffff;
  if ((uint)(*(int *)(param_1 + 0x120) + *(int *)(param_1 + 0x124)) <= uVar5 / 1000) {
    uVar5 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x124) = uVar5 / 1000;
    uVar6 = FUN_140213890(param_1);
  }
  return uVar6;
}

// ==== CMapGroupKernel::helper_1402199b0  @1402199b0  [medium:callgraph-r1]  (orig: FUN_1402199b0)
void FUN_1402199b0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14021c480  @14021c480  [medium:callgraph-r1]  (orig: FUN_14021c480)
void FUN_14021c480(longlong param_1)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68 [3];
  undefined4 *local_50;
  undefined4 *local_48;
  longlong local_40;
  
  plVar4 = operator_new(8);
  plVar9 = (longlong *)0x0;
  local_68[0] = plVar9;
  if (plVar4 != (longlong *)0x0) {
    *plVar4 = (longlong)local_68;
    local_68[0] = plVar4;
  }
  local_50 = (undefined4 *)0x0;
  local_48 = (undefined4 *)0x0;
  local_40 = 0;
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  puVar1 = *(undefined8 **)(param_1 + 8);
  do {
    plVar6 = *(longlong **)(param_1 + 0x38);
    if ((puVar1 == (undefined8 *)0x0) || (puVar1 != *(undefined8 **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    puVar7 = local_50;
    if (plVar4 == plVar6) {
      plVar4 = local_68[0];
      if (local_48 < local_50) {
        _invalid_parameter_noinfo();
        plVar4 = local_68[0];
      }
      while( true ) {
        puVar2 = local_48;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        if ((plVar4 == (longlong *)0x0) || (plVar4 != local_68[0])) {
          _invalid_parameter_noinfo();
        }
        if (puVar7 == puVar2) break;
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar6 = plVar9;
        }
        else {
          plVar6 = (longlong *)*plVar4;
        }
        if ((undefined4 *)plVar6[4] <= puVar7) {
          _invalid_parameter_noinfo();
        }
        FUN_14021bd20(param_1,*puVar7);
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar6 = plVar9;
        }
        else {
          plVar6 = (longlong *)*plVar4;
        }
        if ((undefined4 *)plVar6[4] <= puVar7) {
          _invalid_parameter_noinfo();
        }
        puVar7 = puVar7 + 1;
      }
      if (local_50 != (undefined4 *)0x0) {
        operator_delete(local_50);
      }
      local_50 = (undefined4 *)0x0;
      local_48 = (undefined4 *)0x0;
      local_40 = 0;
      operator_delete(local_68[0]);
      return;
    }
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar6 = plVar9;
    }
    else {
      plVar6 = (longlong *)*puVar1;
    }
    if (plVar4 == (longlong *)plVar6[6]) {
      _invalid_parameter_noinfo();
    }
    cVar3 = FUN_1403808b0(plVar4[4]);
    if (cVar3 != '\0') {
      if (puVar1 == (undefined8 *)0x0) {
        _invalid_parameter_noinfo();
        plVar6 = plVar9;
      }
      else {
        plVar6 = (longlong *)*puVar1;
      }
      if (plVar4 == (longlong *)plVar6[6]) {
        _invalid_parameter_noinfo();
      }
      puVar7 = local_48;
      plVar6 = plVar9;
      if (local_50 != (undefined4 *)0x0) {
        plVar6 = (longlong *)(local_40 - (longlong)local_50 >> 2);
      }
      if ((longlong *)((longlong)local_48 - (longlong)local_50 >> 2) < plVar6) {
        *local_48 = (int)plVar4[3];
        local_48 = local_48 + 1;
      }
      else {
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        puVar2 = local_50;
        plVar6 = local_68[0];
        plVar8 = plVar9;
        if (((longlong)local_48 - (longlong)local_50 & 0xfffffffffffffffcU) != 0) {
          if (local_48 < local_50) {
            _invalid_parameter_noinfo();
          }
          if ((plVar6 == (longlong *)0x0) || (plVar6 != local_68[0])) {
            _invalid_parameter_noinfo();
          }
          plVar8 = (longlong *)((longlong)puVar7 - (longlong)puVar2 >> 2);
        }
        local_88 = SUB84(plVar6,0);
        uStack_84 = (undefined4)((ulonglong)plVar6 >> 0x20);
        uStack_80 = SUB84(puVar7,0);
        uStack_7c = (undefined4)((ulonglong)puVar7 >> 0x20);
        local_78 = local_88;
        uStack_74 = uStack_84;
        uStack_70 = uStack_80;
        uStack_6c = uStack_7c;
        FUN_140036c20(local_68,&local_78,1,plVar4 + 3);
        puVar7 = local_50;
        if (local_48 < local_50) {
          _invalid_parameter_noinfo();
        }
        plVar6 = local_68[0];
        if (local_68[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar5 = plVar9;
        }
        else {
          plVar5 = (longlong *)*local_68[0];
        }
        if (puVar7 + (longlong)plVar8 <= (undefined4 *)plVar5[4]) {
          plVar5 = plVar9;
          if (plVar6 != (longlong *)0x0) {
            plVar5 = (longlong *)*plVar6;
          }
          if ((undefined4 *)plVar5[3] <= puVar7 + (longlong)plVar8) goto LAB_14021c6a0;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_14021c6a0:
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar6 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar6 + 0x29);
        plVar4 = plVar6;
        plVar6 = (longlong *)*plVar6;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar6 + 0x29);
          plVar4 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      else {
        cVar3 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar6 = plVar4;
        while ((plVar4 = plVar8, cVar3 == '\0' && (plVar6 == (longlong *)plVar4[2]))) {
          cVar3 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar6 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_14021c810  @14021c810  [medium:callgraph-r1]  (orig: FUN_14021c810)
void FUN_14021c810(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140221da0  @140221da0  [medium:callgraph-r1]  (orig: FUN_140221da0)
void FUN_140221da0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  void *pvVar3;
  longlong *plVar4;
  ulong uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *local_38;
  longlong *plStack_30;
  undefined1 local_28 [32];
  
  plVar2 = *(longlong **)(param_1 + 0x88);
  plVar6 = (longlong *)**(longlong **)(param_1 + 0xb8);
  plVar8 = plVar2;
  plVar10 = plVar6;
  do {
    while( true ) {
      plVar11 = *(longlong **)(param_1 + 0xb8);
      if ((plVar2 == (longlong *)0x0) || (plVar9 = plVar8, plVar2 != *(longlong **)(param_1 + 0x88))
         ) {
        _invalid_parameter_noinfo();
        plVar9 = plVar8;
      }
      if (plVar6 == plVar11) {
        plVar2 = *(longlong **)(param_1 + 0x48);
        plVar6 = (longlong *)**(longlong **)(param_1 + 0x78);
        plVar8 = plVar2;
        plVar10 = plVar6;
        while( true ) {
          plVar11 = *(longlong **)(param_1 + 0x78);
          if ((plVar2 == (longlong *)0x0) ||
             (plVar9 = plVar8, plVar2 != *(longlong **)(param_1 + 0x48))) {
            _invalid_parameter_noinfo();
            plVar9 = plVar8;
          }
          if (plVar6 == plVar11) break;
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar2;
          }
          if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          pvVar3 = (void *)plVar6[4];
          plVar8 = plVar9;
          if ((*(int *)((longlong)pvVar3 + 0xc) == 0) ||
             (uVar5 = tq::TimeGet(0), plVar8 = plVar9,
             uVar5 / 1000 <
             (uint)(*(int *)((longlong)pvVar3 + 0xc) + *(int *)((longlong)pvVar3 + 8)))) {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
              plVar10 = (longlong *)plVar6[2];
              if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
                cVar1 = *(char *)(*plVar10 + 0x29);
                plVar6 = plVar10;
                plVar11 = (longlong *)*plVar10;
                while (plVar10 = plVar6, cVar1 == '\0') {
                  cVar1 = *(char *)(*plVar11 + 0x29);
                  plVar6 = plVar11;
                  plVar11 = (longlong *)*plVar11;
                }
              }
              else {
                cVar1 = *(char *)(plVar6[1] + 0x29);
                plVar10 = (longlong *)plVar6[1];
                plVar11 = plVar6;
                while ((plVar6 = plVar10, plVar10 = plVar6, cVar1 == '\0' &&
                       (plVar11 == (longlong *)plVar6[2]))) {
                  cVar1 = *(char *)(plVar6[1] + 0x29);
                  plVar10 = (longlong *)plVar6[1];
                  plVar11 = plVar6;
                }
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
          }
          else {
            operator_delete(pvVar3);
            plVar8 = plVar9;
            plVar11 = plVar10;
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
              plVar11 = (longlong *)plVar6[2];
              if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
                cVar1 = *(char *)(*plVar11 + 0x29);
                plVar6 = plVar11;
                plVar4 = (longlong *)*plVar11;
                while (plVar11 = plVar6, cVar1 == '\0') {
                  cVar1 = *(char *)(*plVar4 + 0x29);
                  plVar6 = plVar4;
                  plVar4 = (longlong *)*plVar4;
                }
              }
              else {
                cVar1 = *(char *)(plVar6[1] + 0x29);
                plVar11 = (longlong *)plVar6[1];
                plVar4 = plVar6;
                while ((plVar6 = plVar11, plVar11 = plVar6, cVar1 == '\0' &&
                       (plVar4 == (longlong *)plVar6[2]))) {
                  cVar1 = *(char *)(plVar6[1] + 0x29);
                  plVar11 = (longlong *)plVar6[1];
                  plVar4 = plVar6;
                }
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
            local_38 = plVar9;
            plStack_30 = plVar10;
            FUN_1402204c0((undefined8 *)(param_1 + 0x48),local_28,&local_38,param_4,plVar8,plVar11);
            plVar10 = plVar11;
          }
        }
        return;
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (*(int *)(plVar6[4] + 0xc) != 0) break;
LAB_140221f3d:
      plVar8 = plVar9;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar9;
      }
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        plVar10 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar10 + 0x29);
          plVar6 = plVar10;
          plVar11 = (longlong *)*plVar10;
          while (plVar10 = plVar6, cVar1 == '\0') {
            cVar1 = *(char *)(*plVar11 + 0x29);
            plVar6 = plVar11;
            plVar11 = (longlong *)*plVar11;
          }
        }
        else {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar10 = (longlong *)plVar6[1];
          plVar11 = plVar6;
          while ((plVar6 = plVar10, plVar10 = plVar6, cVar1 == '\0' &&
                 (plVar11 == (longlong *)plVar6[2]))) {
            cVar1 = *(char *)(plVar6[1] + 0x29);
            plVar10 = (longlong *)plVar6[1];
            plVar11 = plVar6;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar6[4];
    uVar5 = tq::TimeGet(0);
    if (uVar5 / 1000 < (uint)(*(int *)(lVar7 + 0xc) + *(int *)(lVar7 + 8))) goto LAB_140221f3d;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    operator_delete((void *)plVar6[4]);
    plVar8 = plVar9;
    plVar11 = plVar10;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar11 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar11 + 0x29);
        plVar6 = plVar11;
        plVar4 = (longlong *)*plVar11;
        while (plVar11 = plVar6, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar4 + 0x29);
          plVar6 = plVar4;
          plVar4 = (longlong *)*plVar4;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar11 = (longlong *)plVar6[1];
        plVar4 = plVar6;
        while ((plVar6 = plVar11, plVar11 = plVar6, cVar1 == '\0' &&
               (plVar4 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar11 = (longlong *)plVar6[1];
          plVar4 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_38 = plVar9;
    plStack_30 = plVar10;
    FUN_140220950(param_1 + 0x88,local_28,&local_38,param_4,plVar8,plVar11);
    plVar10 = plVar11;
  } while( true );
}

// ==== CMapGroupKernel::helper_140223a10  @140223a10  [medium:callgraph-r1]  (orig: FUN_140223a10)
void FUN_140223a10(void *param_1)

{
  if (param_1 != (void *)0x0) {
    operator_delete(param_1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140226230  @140226230  [medium:callgraph-r1]  (orig: FUN_140226230)
void FUN_140226230(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14022d250  @14022d250  [medium:callgraph-r1]  (orig: FUN_14022d250)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_14022d250(undefined8 param_1,int param_2,longlong param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  int iVar10;
  longlong *plVar11;
  undefined1 auStack_8d8 [32];
  undefined4 local_8b8;
  int local_8a8;
  longlong *local_8a0;
  uint local_898;
  longlong *local_890;
  longlong *local_888;
  longlong local_880;
  longlong *local_878;
  longlong *local_870 [3];
  void *local_858;
  undefined8 local_850;
  undefined8 local_848;
  longlong local_840;
  longlong *local_838;
  undefined8 local_830;
  char local_828;
  undefined1 local_827 [1022];
  undefined1 local_429;
  char local_428;
  undefined1 local_427 [1022];
  undefined1 local_29;
  ulonglong local_28;
  
  local_830 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8d8;
  if ((param_2 < 1) || (param_3 == 0)) {
    local_28 = local_28 & 0xffffffffffffff00;
  }
  else {
    local_840 = param_3;
    local_890 = (longlong *)InstanceGet();
    plVar11 = (longlong *)0x0;
    for (local_8a8 = 0; local_8a8 < param_2; local_8a8 = local_8a8 + 1) {
      if (*(int *)(local_840 + (longlong)local_8a8 * 4) != 0) {
        local_828 = '\0';
        memset(local_827,0,0x3ff);
        _snprintf(&local_828,0x3ff,"SELECT * FROM cq_item where id = %d limit 1");
        local_429 = 0;
        plVar4 = (longlong *)(**(code **)(*local_890 + 0x10))(local_890,&local_828,2);
        local_8a0 = plVar4;
        if ((plVar4 == (longlong *)0x0) ||
           (lVar5 = (**(code **)(*plVar4 + 0x40))(plVar4), lVar5 == 0)) {
          plVar6 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,0);
          plVar8 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,2);
          plVar9 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,3);
          (**(code **)(*plVar6 + 0x40))(plVar6);
          (**(code **)(*plVar8 + 0x40))(plVar8);
          (**(code **)(*plVar9 + 0x40))(plVar9);
          log_InlineLogERROR(&DAT_14072f190);
          (**(code **)*plVar4)(plVar4);
          local_8a0 = (longlong *)0x0;
        }
        else {
          plVar6 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,7);
          iVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
          if (iVar2 == 0xcf) {
            plVar6 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_8b8 = 0x3c0;
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar6 = plVar11;
            }
            lVar5 = *plVar6;
            uVar7 = (**(code **)(*plVar4 + 0x38))(plVar4);
            plVar6 = (longlong *)(**(code **)(lVar5 + 0x10))(plVar6,uVar7,0);
            local_888 = plVar6;
            if (plVar6 == (longlong *)0x0) {
              (**(code **)*plVar4)(plVar4);
              local_8a0 = (longlong *)0x0;
            }
            else {
              (**(code **)*plVar4)(plVar4);
              local_8a0 = (longlong *)0x0;
              cVar1 = FUN_1400ffcb0(plVar6);
              if (cVar1 == '\0') {
                (**(code **)(*plVar6 + 8))(plVar6);
                tq::MyLogSave("gmlog/invalid_item","invalid item:[%u] found in auction items");
                plVar4 = DAT_140975b60;
                if (DAT_140975b60 == (longlong *)0x0) {
                  local_8b8 = 0x3c0;
                  log_InlineLogERROR(&DAT_1406d9c10);
                  plVar4 = plVar11;
                }
                lVar5 = *plVar4;
                uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
                (**(code **)(lVar5 + 0x58))(plVar4,uVar3,0);
              }
              else {
                uVar3 = FUN_1400fda10(plVar6,1,1);
                cVar1 = FUN_1400ff940(uVar3);
                if (cVar1 != '\0') {
                  local_428 = '\0';
                  memset(local_427,0,0x3ff);
                  (**(code **)(*plVar6 + 8))(plVar6);
                  _snprintf(&local_428,0x3ff,PTR_s_SELECT___FROM_cq_itemstatus_WHER_14094f190);
                  local_29 = 0;
                  plVar4 = (longlong *)(**(code **)(*local_890 + 0x10))(local_890,&local_428,2);
                  if (plVar4 == (longlong *)0x0) {
                    local_878 = (longlong *)0x0;
                  }
                  else {
                    local_878 = plVar4;
                    local_888 = operator_new(8);
                    local_870[0] = plVar11;
                    if (local_888 != (longlong *)0x0) {
                      *local_888 = (longlong)local_870;
                      local_870[0] = local_888;
                    }
                    local_858 = (void *)0x0;
                    local_850 = 0;
                    local_848 = 0;
                    local_838 = local_888;
                    iVar2 = (**(code **)(*plVar4 + 0x40))(plVar4);
                    local_898 = 0;
                    plVar8 = plVar11;
                    while (iVar10 = (int)plVar8, iVar10 < iVar2) {
                      (**(code **)(*plVar4 + 0x30))(plVar4,(longlong)iVar10);
                      local_880 = (**(code **)(*plVar4 + 0x38))(plVar4);
                      if (local_880 != 0) {
                        FUN_140019370(local_870,&local_880);
                      }
                      local_898 = iVar10 + 1;
                      plVar8 = (longlong *)(ulonglong)local_898;
                    }
                    FUN_140108580(plVar6,local_870,1);
                    (**(code **)*plVar4)(plVar4);
                    local_878 = (longlong *)0x0;
                    if (local_858 != (void *)0x0) {
                      operator_delete(local_858);
                    }
                    local_858 = (void *)0x0;
                    local_850 = 0;
                    local_848 = 0;
                    operator_delete(local_870[0]);
                  }
                }
              }
            }
          }
          else {
            (**(code **)*plVar4)(plVar4);
            local_8a0 = (longlong *)0x0;
          }
        }
      }
    }
    local_28 = CONCAT71((int7)(int3)((uint)local_8a8 >> 8),1);
  }
  return local_28;
}

// ==== CMapGroupKernel::helper_140230cf0  @140230cf0  [medium:callgraph-r2]  (orig: FUN_140230cf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140230cf0(undefined8 param_1,longlong param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  longlong lVar3;
  char *pcVar4;
  IStringManager *pIVar5;
  longlong *plVar6;
  undefined1 auStack_208 [32];
  ulonglong local_1e8;
  undefined4 *local_1e0;
  undefined8 local_1d8;
  undefined4 local_1c8;
  char local_1c4 [60];
  uint local_188;
  undefined1 local_184 [256];
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined1 local_70;
  char local_68 [48];
  ulonglong local_38;
  
  local_1d8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_208;
  if (param_2 == 0) {
    local_1e8 = CONCAT44(local_1e8._4_4_,0x557);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar1 = FUN_14041e8c0(param_2);
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      local_1e8 = CONCAT44(local_1e8._4_4_,0x3c0);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar3 = (**(code **)(*plVar6 + 0x60))(plVar6,uVar1);
    if (lVar3 == 0) {
      local_1e8 = CONCAT44(local_1e8._4_4_,0x55d);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar2 = FUN_14041e710(param_2,2);
      local_68[0] = '\0';
      local_68[1] = '\0';
      local_68[2] = '\0';
      local_68[3] = '\0';
      local_68[4] = '\0';
      local_68[5] = '\0';
      local_68[6] = '\0';
      local_68[7] = '\0';
      local_68[8] = '\0';
      local_68[9] = '\0';
      local_68[10] = '\0';
      local_68[0xb] = '\0';
      local_68[0xc] = '\0';
      local_68[0xd] = '\0';
      local_68[0xe] = '\0';
      local_68[0xf] = 0;
      pcVar4 = (char *)FUN_14041e6b0(param_2,3);
      strncpy(local_68,pcVar4,0x10);
      FUN_1400fda10(lVar3,1,1);
      tq::MyLogSave("gmlog/auction","auction item sell time out, cancel sell item(%u, type:%u)");
      FUN_14022f690(param_1);
      local_1e8 = local_1e8 & 0xffffffff00000000;
      FUN_14022b360(param_1,0,lVar3,0);
      local_1c8 = 0;
      local_1c4[0] = '\0';
      local_1c4[1] = '\0';
      local_1c4[2] = '\0';
      local_1c4[3] = '\0';
      local_1c4[4] = '\0';
      local_1c4[5] = '\0';
      local_1c4[6] = '\0';
      local_1c4[7] = '\0';
      local_1c4[8] = '\0';
      local_1c4[9] = '\0';
      local_1c4[10] = '\0';
      local_1c4[0xb] = '\0';
      local_1c4[0xc] = '\0';
      local_1c4[0xd] = '\0';
      local_1c4[0xe] = '\0';
      local_1c4[0xf] = '\0';
      local_1c4[0x10] = '\0';
      local_1c4[0x11] = '\0';
      local_1c4[0x12] = '\0';
      local_1c4[0x13] = '\0';
      local_1c4[0x14] = '\0';
      local_1c4[0x15] = '\0';
      local_1c4[0x16] = '\0';
      local_1c4[0x17] = '\0';
      local_1c4[0x18] = '\0';
      local_1c4[0x19] = '\0';
      local_1c4[0x1a] = '\0';
      local_1c4[0x1b] = '\0';
      local_1c4[0x1c] = '\0';
      local_1c4[0x1d] = '\0';
      local_1c4[0x1e] = '\0';
      local_1c4[0x1f] = '\0';
      local_1c4[0x20] = '\0';
      local_1c4[0x21] = '\0';
      local_1c4[0x22] = '\0';
      local_1c4[0x23] = '\0';
      local_1c4[0x24] = '\0';
      local_1c4[0x25] = '\0';
      local_1c4[0x26] = '\0';
      local_1c4[0x27] = '\0';
      local_1c4[0x28] = '\0';
      local_1c4[0x29] = '\0';
      local_1c4[0x2a] = '\0';
      local_1c4[0x2b] = '\0';
      local_1c4[0x2c] = '\0';
      local_1c4[0x2d] = '\0';
      local_1c4[0x2e] = '\0';
      local_1c4[0x2f] = '\0';
      local_1c4[0x30] = '\0';
      local_1c4[0x31] = '\0';
      local_1c4[0x32] = '\0';
      local_1c4[0x33] = '\0';
      local_1c4[0x34] = '\0';
      local_1c4[0x35] = '\0';
      local_1c4[0x36] = '\0';
      local_1c4[0x37] = '\0';
      local_1c4[0x38] = '\0';
      local_1c4[0x39] = '\0';
      local_1c4[0x3a] = '\0';
      local_1c4[0x3b] = '\0';
      local_188 = 0;
      memset(local_184,0,0xff);
      local_84 = 0;
      local_80 = 0;
      local_7c = 0;
      local_74 = 0x1e;
      local_70 = 0;
      local_68[0x10] = 0;
      local_68[0x11] = '\0';
      local_68[0x12] = '\0';
      local_68[0x13] = '\0';
      local_68[0x14] = '\0';
      local_68[0x15] = '\0';
      local_68[0x16] = '\0';
      local_68[0x17] = '\0';
      local_68[0x18] = '\0';
      local_68[0x19] = '\0';
      local_68[0x1a] = '\0';
      local_68[0x1b] = '\0';
      local_68[0x1c] = '\0';
      local_68[0x1d] = '\0';
      local_68[0x1e] = '\0';
      local_68[0x1f] = '\0';
      local_68[0x20] = '\0';
      local_68[0x21] = '\0';
      local_68[0x22] = '\0';
      local_68[0x23] = '\0';
      local_68[0x24] = '\0';
      local_68[0x25] = '\0';
      local_68[0x26] = '\0';
      local_68[0x27] = '\0';
      local_68[0x28] = '\0';
      local_68[0x29] = '\0';
      local_68[0x2a] = '\0';
      local_68[0x2b] = '\0';
      local_68[0x2c] = '\0';
      local_68[0x2d] = '\0';
      local_68[0x2e] = '\0';
      local_68[0x2f] = 0;
      local_1c8 = uVar2;
      local_78 = uVar1;
      FUN_140227740(param_1,lVar3,local_68 + 0x10);
      pIVar5 = theInstance();
      pcVar4 = (char *)(*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_BID_SYSTEM_NAME");
      strncpy(local_1c4,pcVar4,0x10);
      pIVar5 = theInstance();
      pcVar4 = (char *)(*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_BID_CANCEL_MAIL_TITLE");
      _snprintf(local_1c4 + 0x20,0x20,pcVar4);
      local_188 = local_188 & 0xffffff;
      local_1e0 = &local_1c8;
      local_1e8 = lVar3;
      FUN_140228800(param_1,uVar2,0,0);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1402312f0  @1402312f0  [medium:callgraph-r1]  (orig: FUN_1402312f0)
void FUN_1402312f0(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  __time64_t _Var4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong lVar9;
  bool bVar10;
  longlong *local_res10;
  longlong *local_res18;
  longlong *local_a8 [3];
  longlong *local_90;
  longlong *local_88;
  undefined8 local_80;
  longlong *local_78;
  longlong *local_70;
  longlong *local_60;
  longlong *local_50;
  undefined8 local_40;
  longlong *local_38;
  
  local_40 = 0xfffffffffffffffe;
  _Var4 = _time64((__time64_t *)0x0);
  local_res10 = operator_new(8);
  if (local_res10 == (longlong *)0x0) {
    local_a8[0] = (longlong *)0x0;
  }
  else {
    *local_res10 = (longlong)local_a8;
    local_a8[0] = local_res10;
  }
  lVar9 = 0;
  local_90 = (longlong *)0x0;
  local_88 = (longlong *)0x0;
  local_80 = 0;
  plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x40);
  plVar1 = *(longlong **)(param_1 + 0x10);
  local_res18 = local_res10;
  local_38 = plVar1;
  do {
    while( true ) {
      while( true ) {
        plVar6 = *(longlong **)(param_1 + 0x40);
        local_70 = *(longlong **)(param_1 + 0x10);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_70)) {
          _invalid_parameter_noinfo();
        }
        plVar7 = local_90;
        if (plVar5 == plVar6) {
          local_60 = (longlong *)0x0;
          if (local_88 < local_90) {
            _invalid_parameter_noinfo();
          }
          plVar5 = local_a8[0];
          local_60 = local_a8[0];
          while( true ) {
            plVar1 = local_88;
            local_50 = (longlong *)0x0;
            if (local_88 < local_90) {
              _invalid_parameter_noinfo();
            }
            local_50 = local_a8[0];
            if ((plVar5 == (longlong *)0x0) || (plVar5 != local_a8[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar7 == plVar1) break;
            if (plVar5 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = lVar9;
            }
            else {
              lVar8 = *plVar5;
            }
            if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
              _invalid_parameter_noinfo();
            }
            lVar8 = *plVar7;
            if (lVar8 != 0) {
              iVar3 = FUN_14041e710(lVar8,10);
              if (iVar3 == 0) {
                FUN_140230cf0(param_1,lVar8);
              }
              else {
                FUN_14022fce0(param_1,lVar8);
              }
            }
            if (plVar5 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar8 = lVar9;
            }
            else {
              lVar8 = *plVar5;
            }
            if (*(longlong **)(lVar8 + 0x20) <= plVar7) {
              _invalid_parameter_noinfo();
            }
            plVar7 = plVar7 + 1;
          }
          FUN_14022bf20(local_a8);
          if (local_90 != (longlong *)0x0) {
            operator_delete(local_90);
          }
          local_90 = (longlong *)0x0;
          local_88 = (longlong *)0x0;
          local_80 = 0;
          operator_delete(local_a8[0]);
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar8 = lVar9;
        }
        else {
          lVar8 = *plVar1;
        }
        if (plVar5 == *(longlong **)(lVar8 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_res10 = (longlong *)plVar5[4];
        if ((local_res10 != (longlong *)0x0) &&
           (cVar2 = FUN_14041e650(local_res10,_Var4), cVar2 != '\0')) {
          FUN_14022ce90(local_a8,&local_res10);
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar6 = plVar5;
      plVar7 = (longlong *)plVar5[2];
      if (*(char *)(plVar5[2] + 0x29) != '\0') break;
      do {
        plVar5 = plVar7;
        plVar7 = (longlong *)*plVar5;
        local_78 = plVar5;
      } while (*(char *)(*plVar5 + 0x29) == '\0');
    }
    do {
      plVar5 = (longlong *)plVar6[1];
      if (*(char *)((longlong)plVar5 + 0x29) != '\0') break;
      bVar10 = plVar6 == (longlong *)plVar5[2];
      plVar6 = plVar5;
    } while (bVar10);
  } while( true );
}

// ==== CMapGroupKernel::helper_140231590  @140231590  [medium:callgraph-r1]  (orig: FUN_140231590)
void FUN_140231590(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0xe8) != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0xe8) + *(int *)(param_1 + 0xe4)) <= uVar1 / 1000) {
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0xe8) = uVar1 / 1000;
      log_InlineLogMessage("##current auction item count: %d");
    }
  }
  if (*(int *)(param_1 + 0xe0) != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0xdc) + *(int *)(param_1 + 0xe0)) <= uVar1 / 1000) {
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0xe0) = uVar1 / 1000;
      FUN_1402312f0(param_1);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_140233260  @140233260  [medium:callgraph-r0]  (orig: FUN_140233260)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140233260(longlong param_1)

{
  undefined1 auVar1 [16];
  char cVar2;
  int iVar3;
  longlong *plVar4;
  __uint64 _Var5;
  void *pvVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined8 uVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  undefined1 auStack_b8 [32];
  uint local_98;
  uint local_94;
  uint local_90;
  longlong *local_88;
  longlong local_80;
  longlong *local_78;
  void *local_70;
  longlong local_68;
  longlong *local_60;
  undefined8 local_58;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined1 local_44;
  undefined8 local_43;
  undefined8 local_3b;
  undefined1 local_33;
  undefined1 local_32;
  undefined1 local_31;
  undefined2 local_30;
  undefined2 local_2e;
  undefined2 local_2c;
  undefined4 local_28;
  ulonglong local_20;
  
  local_58 = 0xfffffffffffffffe;
  local_20 = DAT_1409707c0 ^ (ulonglong)auStack_b8;
  local_80 = param_1;
  plVar4 = (longlong *)InstanceGet();
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,"SELECT * FROM cq_auction",2);
  local_88 = plVar4;
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR("CAuctionMgr::Create, failed in load cq_auction");
    uVar12 = 0;
  }
  else {
    iVar3 = (**(code **)(*plVar4 + 0x40))(plVar4);
    uVar13 = 0;
    local_94 = 0;
    auVar1._8_8_ = 0;
    auVar1._0_8_ = (longlong)iVar3;
    _Var5 = SUB168(ZEXT816(4) * auVar1,0);
    if (SUB168(ZEXT816(4) * auVar1,8) != 0) {
      _Var5 = 0xffffffffffffffff;
    }
    pvVar6 = operator_new__(_Var5);
    local_90 = 0;
    uVar10 = uVar13;
    uVar14 = uVar13;
    local_70 = pvVar6;
    while( true ) {
      uVar7 = (**(code **)(*plVar4 + 0x40))(plVar4);
      if (uVar7 <= uVar10) break;
      (**(code **)(*plVar4 + 0x30))(plVar4,uVar10);
      plVar8 = (longlong *)(**(code **)(*plVar4 + 0x38))(plVar4);
      if (plVar8 != (longlong *)0x0) {
        local_78 = plVar8;
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
        iVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if (iVar3 == 0) {
          (**(code **)*plVar8)(plVar8,1);
        }
        else {
          *(int *)((longlong)pvVar6 + (longlong)(int)uVar14 * 4) = iVar3;
          local_94 = (int)uVar14 + 1;
          uVar14 = (ulonglong)local_94;
          (**(code **)*plVar8)(plVar8,1);
        }
      }
      local_78 = (longlong *)0x0;
      local_90 = (int)uVar10 + 1;
      uVar10 = (ulonglong)local_90;
    }
    FUN_14022d250(local_80,uVar14,pvVar6);
    operator_delete__(pvVar6);
    _time64((__time64_t *)0x0);
    local_98 = 0;
    while( true ) {
      uVar10 = (**(code **)(*plVar4 + 0x40))(plVar4);
      if (uVar10 <= uVar13) break;
      (**(code **)(*plVar4 + 0x30))(plVar4,uVar13);
      plVar8 = (longlong *)(**(code **)(*plVar4 + 0x38))(plVar4);
      local_60 = plVar8;
      if (plVar8 != (longlong *)0x0) {
        plVar9 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,4);
        (**(code **)(*plVar9 + 0x40))(plVar9);
        lVar11 = FUN_14041f710(plVar8);
        local_68 = lVar11;
        if (lVar11 == 0) {
          (**(code **)*plVar8)(plVar8,1);
          local_60 = (longlong *)0x0;
        }
        else {
          cVar2 = FUN_1402326f0(local_80,lVar11);
          if (cVar2 == '\0') {
            FUN_14041e870(lVar11);
            FUN_14041eef0(lVar11);
            local_68 = 0;
          }
        }
      }
      local_98 = (int)uVar13 + 1;
      uVar13 = (ulonglong)local_98;
    }
    (**(code **)*plVar4)(plVar4);
    lVar11 = local_80;
    FUN_1402312f0(local_80);
    local_50 = 0;
    local_4c = 0;
    local_48 = 0;
    local_44 = 0;
    local_33 = 0;
    local_32 = 0;
    local_31 = 0;
    local_30 = 0;
    local_2e = 0;
    local_2c = 0x8c;
    local_28 = 0;
    local_43 = 0;
    local_3b = 0;
    uVar12 = FUN_140008520(*(undefined4 *)(lVar11 + 8));
    FUN_14008aba0(uVar12,0x1637e,&local_50);
    uVar12 = 1;
  }
  return uVar12;
}

// ==== CMapGroupKernel::helper_140234130  @140234130  [medium:callgraph-r1]  (orig: FUN_140234130)
void FUN_140234130(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140234680  @140234680  [medium:callgraph-r3]  (orig: FUN_140234680)
void FUN_140234680(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMapGroupKernel::helper_140235280  @140235280  [medium:callgraph-r3]  (orig: FUN_140235280)
void FUN_140235280(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 0x10)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 << 4);
  return;
}

// ==== CMapGroupKernel::helper_140235630  @140235630  [medium:callgraph-r3]  (orig: FUN_140235630)
undefined4 * FUN_140235630(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 4) {
    if (param_3 != (undefined4 *)0x0) {
      *param_3 = *param_1;
      param_3[1] = param_1[1];
      param_3[2] = param_1[2];
      param_3[3] = param_1[3];
    }
    param_3 = param_3 + 4;
  }
  return param_3;
}

// ==== CMapGroupKernel::helper_140235d80  @140235d80  [medium:callgraph-r2]  (orig: FUN_140235d80)
void FUN_140235d80(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
      param_1[3] = param_3[3];
    }
    param_1 = param_1 + 4;
  }
  return;
}

// ==== CMapGroupKernel::helper_140236c90  @140236c90  [medium:callgraph-r3]  (orig: FUN_140236c90)
longlong FUN_140236c90(longlong param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  longlong lVar2;
  longlong lVar3;
  
  if (param_1 != param_2) {
    lVar3 = param_3 - param_2;
    lVar1 = param_2;
    do {
      lVar2 = lVar1 + -0x10;
      *(undefined4 *)(lVar3 + lVar2) = *(undefined4 *)(lVar1 + -0x10);
      *(undefined4 *)(lVar3 + 4 + lVar2) = *(undefined4 *)(lVar1 + -0xc);
      *(undefined4 *)(lVar3 + 8 + lVar2) = *(undefined4 *)(lVar1 + -8);
      *(undefined4 *)(lVar3 + 0xc + lVar2) = *(undefined4 *)(lVar1 + -4);
      lVar1 = lVar2;
    } while (lVar2 != param_1);
  }
  return param_3 - (param_2 - param_1 & 0xfffffffffffffff0U);
}

// ==== CMapGroupKernel::helper_140238a20  @140238a20  [medium:callgraph-r2]  (orig: FUN_140238a20)
void FUN_140238a20(longlong param_1,longlong param_2,ulonglong param_3,undefined4 *param_4)

{
  void *pvVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong lVar4;
  undefined4 *puVar5;
  ulonglong uVar6;
  ulonglong uVar7;
  undefined4 *puVar8;
  undefined1 local_res8;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar6 = 0;
  }
  else {
    uVar6 = *(longlong *)(param_1 + 0x28) - lVar4 >> 4;
  }
  if (param_3 != 0) {
    lVar2 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar2 - lVar4 >> 4;
    if (0xfffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140234680();
    }
    uVar7 = param_3 + lVar4;
    if (uVar6 < uVar7) {
      if (0xfffffffffffffff - (uVar6 >> 1) < uVar6) {
        uVar6 = 0;
      }
      else {
        uVar6 = uVar6 + (uVar6 >> 1);
      }
      if (uVar6 < uVar7) {
        uVar6 = uVar7;
      }
      lVar2 = FUN_140235280(param_1 + 0x10,uVar6);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 4;
      local_res8 = (undefined1)lVar2;
      FUN_140235d80(lVar4 * 0x10 + lVar2,param_3,param_4,param_1 + 0x10,local_res8,0);
      FUN_140235630(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar2,
                    param_1 + 0x10,local_res8,0,1);
      FUN_140235630(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    (lVar4 + param_3) * 0x10 + lVar2,param_1 + 0x10,local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = uVar6 * 0x10 + lVar2;
      *(ulonglong *)(param_1 + 0x20) = (param_3 + (lVar4 - (longlong)pvVar1 >> 4)) * 0x10 + lVar2;
      *(longlong *)(param_1 + 0x18) = lVar2;
    }
    else if ((ulonglong)(lVar2 - *(longlong *)(param_2 + 8) >> 4) < param_3) {
      local_38 = *param_4;
      local_34 = param_4[1];
      local_30 = param_4[2];
      local_2c = param_4[3];
      FUN_140235630(*(longlong *)(param_2 + 8),lVar2,*(longlong *)(param_2 + 8) + param_3 * 0x10,
                    param_1 + 0x10);
      FUN_140235d80(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 4),
                    &local_38,param_1 + 0x10,local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 0x10;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar5 = *(undefined4 **)(param_2 + 8); puVar5 != (undefined4 *)(lVar4 + param_3 * -0x10)
          ; puVar5 = puVar5 + 4) {
        *puVar5 = local_38;
        puVar5[1] = local_34;
        puVar5[2] = local_30;
        puVar5[3] = local_2c;
      }
    }
    else {
      local_38 = *param_4;
      local_34 = param_4[1];
      local_30 = param_4[2];
      local_2c = param_4[3];
      lVar4 = lVar2 + param_3 * -0x10;
      uVar3 = FUN_140235630(lVar4,lVar2,lVar2,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140236c90(*(undefined8 *)(param_2 + 8),lVar4,lVar2);
      puVar8 = *(undefined4 **)(param_2 + 8);
      puVar5 = puVar8 + param_3 * 4;
      for (; puVar8 != puVar5; puVar8 = puVar8 + 4) {
        *puVar8 = local_38;
        puVar8[1] = local_34;
        puVar8[2] = local_30;
        puVar8[3] = local_2c;
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_14023b280  @14023b280  [medium:callgraph-r1]  (orig: FUN_14023b280)
void FUN_14023b280(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  ulonglong *puVar3;
  undefined8 *puVar4;
  undefined1 uVar5;
  longlong *plVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  ulong uVar9;
  longlong *plVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined8 *puVar13;
  undefined4 *puVar14;
  undefined8 *puVar15;
  ulonglong uVar16;
  longlong lVar17;
  longlong lVar18;
  undefined8 *local_res10;
  longlong *local_c8 [2];
  undefined1 local_b8 [8];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  undefined8 *local_98;
  longlong *local_90;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  
  local_68 = 0xfffffffffffffffe;
  plVar10 = operator_new(8);
  local_c8[0] = (longlong *)0x0;
  if (plVar10 != (longlong *)0x0) {
    *plVar10 = (longlong)local_c8;
    local_c8[0] = plVar10;
  }
  local_b0 = (undefined4 *)0x0;
  local_a8 = (undefined4 *)0x0;
  local_a0 = 0;
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  local_res10 = (undefined8 *)*puVar2;
  plVar10 = *(longlong **)(param_1 + 8);
  uVar5 = local_res10._0_1_;
  local_90 = plVar10;
  do {
    lVar18 = 0;
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    puVar14 = local_b0;
    if (local_res10 == puVar2) {
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
      }
      puVar7 = local_a8;
      plVar6 = local_c8[0];
      plVar10 = local_c8[0];
      if (local_a8 < local_b0) {
        _invalid_parameter_noinfo();
        plVar10 = local_c8[0];
      }
      while( true ) {
        if ((plVar6 == (longlong *)0x0) || (plVar6 != plVar10)) {
          _invalid_parameter_noinfo();
        }
        if (puVar14 == puVar7) break;
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar18;
        }
        else {
          lVar11 = *plVar6;
        }
        if (*(undefined4 **)(lVar11 + 0x20) <= puVar14) {
          _invalid_parameter_noinfo();
        }
        FUN_14023aee0(param_1,puVar14[1],*puVar14);
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = lVar18;
        }
        else {
          lVar11 = *plVar6;
        }
        if (*(undefined4 **)(lVar11 + 0x20) <= puVar14) {
          _invalid_parameter_noinfo();
        }
        puVar14 = puVar14 + 4;
      }
      if (local_b0 != (undefined4 *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (undefined4 *)0x0;
      local_a8 = (undefined4 *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      return;
    }
    if (plVar10 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar18 = *plVar10;
    }
    if (local_res10 == *(undefined8 **)(lVar18 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar13 = (undefined8 *)local_res10[10];
    puVar15 = (undefined8 *)*puVar13;
    puVar3 = (ulonglong *)local_res10[4];
    local_98 = puVar13;
    while( true ) {
      uVar12 = 0;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      plVar10 = local_90;
      if (puVar15 == puVar13) break;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar16 = uVar12;
      }
      else {
        uVar16 = *puVar3;
      }
      if (puVar15 == *(undefined8 **)(uVar16 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if ((*(int *)(puVar15 + 5) != 0) &&
         (uVar9 = tq::TimeGet(0), puVar14 = local_a8,
         (uint)(*(int *)((longlong)puVar15 + 0x24) + *(int *)(puVar15 + 5)) <= uVar9 / 1000)) {
        *(undefined4 *)(puVar15 + 5) = 0;
        *(undefined4 *)((longlong)puVar15 + 0x24) = 0;
        if (local_b0 != (undefined4 *)0x0) {
          uVar12 = local_a0 - (longlong)local_b0 >> 4;
        }
        if ((ulonglong)((longlong)local_a8 - (longlong)local_b0 >> 4) < uVar12) {
          FUN_140235d80(local_a8,1,(longlong)puVar15 + 0x1c,local_b8,uVar5,0);
          local_a8 = puVar14 + 4;
          puVar13 = local_98;
        }
        else {
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          puVar7 = local_b0;
          plVar10 = local_c8[0];
          local_78 = local_c8[0];
          uStack_70 = puVar14;
          if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffff0U) == 0) {
            lVar18 = 0;
          }
          else {
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar10 == (longlong *)0x0) || (plVar10 != local_c8[0])) {
              _invalid_parameter_noinfo();
            }
            lVar18 = (longlong)puVar14 - (longlong)puVar7 >> 4;
          }
          lVar11 = 0;
          local_58 = (undefined4)local_78;
          uStack_54 = local_78._4_4_;
          uStack_50 = (undefined4)uStack_70;
          uStack_4c = uStack_70._4_4_;
          FUN_140238a20(local_c8,&local_58,1,(longlong)puVar15 + 0x1c);
          puVar14 = local_b0;
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          plVar10 = local_c8[0];
          if (local_c8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar17 = lVar11;
          }
          else {
            lVar17 = *local_c8[0];
          }
          if (puVar14 + lVar18 * 4 <= *(undefined4 **)(lVar17 + 0x20)) {
            if (plVar10 != (longlong *)0x0) {
              lVar11 = *plVar10;
            }
            puVar13 = local_98;
            if (*(undefined4 **)(lVar11 + 0x18) <= puVar14 + lVar18 * 4) goto LAB_14023b536;
          }
          _invalid_parameter_noinfo();
          puVar13 = local_98;
        }
      }
LAB_14023b536:
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar15 + 0x2d) == '\0') {
        puVar4 = (undefined8 *)puVar15[2];
        if (*(char *)((longlong)puVar4 + 0x2d) == '\0') {
          cVar1 = *(char *)((longlong)*puVar4 + 0x2d);
          puVar15 = puVar4;
          puVar4 = (undefined8 *)*puVar4;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar4 + 0x2d);
            puVar15 = puVar4;
            puVar4 = (undefined8 *)*puVar4;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar15[1] + 0x2d);
          puVar8 = (undefined8 *)puVar15[1];
          puVar4 = puVar15;
          while ((puVar15 = puVar8, cVar1 == '\0' && (puVar4 == (undefined8 *)puVar15[2]))) {
            cVar1 = *(char *)((longlong)puVar15[1] + 0x2d);
            puVar8 = (undefined8 *)puVar15[1];
            puVar4 = puVar15;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    if (local_90 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)local_res10 + 0x61) == '\0') {
      puVar13 = (undefined8 *)local_res10[2];
      if (*(char *)((longlong)puVar13 + 0x61) == '\0') {
        cVar1 = *(char *)((longlong)*puVar13 + 0x61);
        local_res10 = puVar13;
        puVar13 = (undefined8 *)*puVar13;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar13 + 0x61);
          local_res10 = puVar13;
          puVar13 = (undefined8 *)*puVar13;
        }
      }
      else {
        cVar1 = *(char *)((longlong)local_res10[1] + 0x61);
        puVar15 = (undefined8 *)local_res10[1];
        puVar13 = local_res10;
        while ((local_res10 = puVar15, cVar1 == '\0' && (puVar13 == (undefined8 *)local_res10[2])))
        {
          cVar1 = *(char *)((longlong)local_res10[1] + 0x61);
          puVar15 = (undefined8 *)local_res10[1];
          puVar13 = local_res10;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_14023bc40  @14023bc40  [medium:callgraph-r1]  (orig: FUN_14023bc40)
void FUN_14023bc40(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14023e950  @14023e950  [medium:callgraph-r1]  (orig: FUN_14023e950)
void FUN_14023e950(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14023fd50  @14023fd50  [medium:callgraph-r2]  (orig: FUN_14023fd50)
void FUN_14023fd50(longlong param_1,longlong param_2)

{
  undefined8 uVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar2 = FUN_140421020(param_2);
    FUN_140421d50(param_2);
    FUN_140420ff0(param_2);
    uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
    plVar3 = (longlong *)FUN_1400876b0(uVar1);
    (**(code **)(*plVar3 + 0x148))(plVar3,uVar2);
  }
  return;
}

// ==== CMapGroupKernel::helper_140242030  @140242030  [medium:callgraph-r3]  (orig: FUN_140242030)
undefined8 * FUN_140242030(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMapGroupKernel::helper_1402466c0  @1402466c0  [medium:callgraph-r3]  (orig: FUN_1402466c0)
undefined8 FUN_1402466c0(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0xc0))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0xc0);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0xc0);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x90);
  if (*(longlong *)(param_1 + 0x90) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xc0);
    local_28 = *(longlong *)(param_1 + 0x90);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0xc0);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x90))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar6 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = *(undefined8 *)(lVar4 + 0x20);
  }
  return uVar6;
}

// ==== CMapGroupKernel::helper_140246900  @140246900  [medium:callgraph-r2]  (orig: FUN_140246900)
void FUN_140246900(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_1402466c0();
  if (lVar1 != 0) {
    FUN_140422910(lVar1,param_3);
  }
  return;
}

// ==== CMapGroupKernel::helper_140246ea0  @140246ea0  [medium:callgraph-r2]  (orig: FUN_140246ea0)
longlong FUN_140246ea0(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140242030(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140244cc0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMapGroupKernel::helper_1402479e0  @1402479e0  [medium:callgraph-r2]  (orig: FUN_1402479e0)
void FUN_1402479e0(longlong param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong lVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  uint in_stack_ffffffffffffffe8;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    in_stack_ffffffffffffffe8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))(*(longlong **)(lVar5 + 0x90),param_2);
  if (lVar5 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar6 = FUN_1402464b0(param_1,param_2);
    if (lVar6 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar1 = FUN_140420c80(lVar6);
      lVar6 = FUN_1402467e0(param_1,uVar1);
      if (lVar6 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar1 = FUN_140421080(lVar6,9);
        uVar2 = FUN_140421080(lVar6,10);
        uVar3 = FUN_140421080(lVar6,0xb);
        iVar4 = FUN_1401c55b0(lVar5,uVar1,uVar2,uVar3,in_stack_ffffffffffffffe8 & 0xffffff00);
        if (iVar4 != 0) {
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x194));
          plVar8 = (longlong *)FUN_140087650(uVar7);
          (**(code **)(*plVar8 + 0x50))(plVar8,lVar5,"CInstanceMgr::UserLeaveInstance");
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_140248ca0  @140248ca0  [medium:callgraph-r2]  (orig: FUN_140248ca0)
void FUN_140248ca0(undefined8 param_1,undefined4 param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  uint uVar9;
  undefined1 local_88 [8];
  undefined8 uStack_80;
  undefined1 local_78 [8];
  undefined8 uStack_70;
  undefined1 local_68 [16];
  longlong *local_58 [6];
  undefined8 *local_28;
  undefined8 local_20;
  
  lVar6 = FUN_1402467e0();
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar7 = FUN_140421120(lVar6);
    FUN_14000e970(local_58,uVar7);
    puVar4 = local_28;
    plVar3 = local_58[0];
    puVar8 = (undefined8 *)*local_28;
    uVar9 = 0;
    uStack_80 = puVar8;
    while( true ) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (puVar8 == puVar4) goto LAB_140248e35;
      uVar9 = uVar9 + 1;
      if (1000 < uVar9) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar3;
      }
      if (puVar8 == *(undefined8 **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_1402479e0(param_1,*(undefined4 *)(puVar8 + 3));
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar8 + 0x1d) == '\0') {
        puVar2 = (undefined8 *)puVar8[2];
        if (*(char *)((longlong)puVar2 + 0x1d) == '\0') {
          cVar1 = *(char *)((longlong)*puVar2 + 0x1d);
          puVar8 = puVar2;
          puVar2 = (undefined8 *)*puVar2;
          while (cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar2 + 0x1d);
            puVar8 = puVar2;
            puVar2 = (undefined8 *)*puVar2;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar8[1] + 0x1d);
          puVar5 = (undefined8 *)puVar8[1];
          puVar2 = puVar8;
          while ((puVar8 = puVar5, cVar1 == '\0' && (puVar2 == (undefined8 *)puVar8[2]))) {
            cVar1 = *(char *)((longlong)puVar8[1] + 0x1d);
            puVar5 = (undefined8 *)puVar8[1];
            puVar2 = puVar8;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    log_InlineLogERROR(&DAT_1406d9c10);
LAB_140248e35:
    lVar6 = FUN_1402467e0(param_1,param_2);
    if (lVar6 == 0) {
      log_InlineLogERROR("CInstanceMgr::DelInstance QueryInstance failed, id:%u.");
    }
    else {
      FUN_140421130(lVar6);
    }
    uStack_70 = *local_28;
    FUN_14000bd50(local_58,local_68,local_78,local_88);
    operator_delete(local_28);
    local_28 = (undefined8 *)0x0;
    local_20 = 0;
    operator_delete(local_58[0]);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402490f0  @1402490f0  [medium:callgraph-r1]  (orig: FUN_1402490f0)
void FUN_1402490f0(longlong param_1)

{
  longlong *plVar1;
  int *piVar2;
  longlong *plVar3;
  int *piVar4;
  int *piVar5;
  undefined8 *puVar6;
  char cVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  ulonglong uVar13;
  int *piVar14;
  undefined8 *puVar15;
  uint uVar16;
  longlong lVar17;
  undefined8 *puVar18;
  longlong *local_res8;
  longlong *local_res10;
  int *piStack_110;
  longlong *local_108 [3];
  int *local_f0;
  int *local_e8;
  longlong local_e0;
  longlong *local_d8 [3];
  int *local_c0;
  int *local_b8;
  longlong local_b0;
  longlong *local_a8;
  int *piStack_a0;
  longlong *local_98;
  int *piStack_90;
  longlong local_88;
  undefined8 *local_80;
  longlong local_78;
  undefined8 local_70;
  undefined8 local_68;
  undefined1 local_60 [40];
  
  local_68 = 0xfffffffffffffffe;
  puVar18 = *(undefined8 **)(param_1 + 0x40);
  puVar15 = (undefined8 *)*puVar18;
  plVar1 = *(longlong **)(param_1 + 0x10);
  local_res8 = operator_new(8);
  if (local_res8 == (longlong *)0x0) {
    local_108[0] = (longlong *)0x0;
  }
  else {
    *local_res8 = (longlong)local_108;
    local_108[0] = local_res8;
  }
  local_f0 = (int *)0x0;
  local_e8 = (int *)0x0;
  local_e0 = 0;
  local_res10 = local_res8;
  while( true ) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    piVar14 = local_f0;
    if (puVar15 == puVar18) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar17 = 0;
    }
    else {
      lVar17 = *plVar1;
    }
    if (puVar15 == *(undefined8 **)(lVar17 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar17 = puVar15[4];
    if (lVar17 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar7 = FUN_140420fa0(lVar17);
      if (cVar7 != '\0') {
        iVar8 = FUN_140420c70(lVar17);
        piVar14 = local_e8;
        local_res8 = (longlong *)CONCAT44(local_res8._4_4_,iVar8);
        if (local_f0 == (int *)0x0) {
          uVar13 = 0;
        }
        else {
          uVar13 = local_e0 - (longlong)local_f0 >> 2;
        }
        if ((ulonglong)((longlong)local_e8 - (longlong)local_f0 >> 2) < uVar13) {
          *local_e8 = iVar8;
          local_e8 = local_e8 + 1;
        }
        else {
          if (local_e8 < local_f0) {
            _invalid_parameter_noinfo();
          }
          piVar2 = local_f0;
          plVar12 = local_108[0];
          if (((longlong)local_e8 - (longlong)local_f0 & 0xfffffffffffffffcU) == 0) {
            lVar17 = 0;
          }
          else {
            if (local_e8 < local_f0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar12 == (longlong *)0x0) || (plVar12 != local_108[0])) {
              _invalid_parameter_noinfo();
            }
            lVar17 = (longlong)piVar14 - (longlong)piVar2 >> 2;
          }
          local_a8 = plVar12;
          piStack_a0 = piVar14;
          FUN_140036c20(local_108,&local_a8,1,&local_res8);
          piVar14 = local_f0;
          if (local_e8 < local_f0) {
            _invalid_parameter_noinfo();
          }
          plVar12 = local_108[0];
          if (local_108[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *local_108[0];
          }
          if (piVar14 + lVar17 <= *(int **)(lVar10 + 0x20)) {
            if (plVar12 == (longlong *)0x0) {
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar12;
            }
            if (*(int **)(lVar10 + 0x18) <= piVar14 + lVar17) goto LAB_14024932a;
          }
          _invalid_parameter_noinfo();
        }
      }
    }
LAB_14024932a:
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar15 + 0x29) == '\0') {
      puVar11 = (undefined8 *)puVar15[2];
      if (*(char *)((longlong)puVar11 + 0x29) == '\0') {
        cVar7 = *(char *)((longlong)*puVar11 + 0x29);
        puVar15 = puVar11;
        puVar11 = (undefined8 *)*puVar11;
        while (cVar7 == '\0') {
          cVar7 = *(char *)((longlong)*puVar11 + 0x29);
          puVar15 = puVar11;
          puVar11 = (undefined8 *)*puVar11;
        }
      }
      else {
        cVar7 = *(char *)((longlong)puVar15[1] + 0x29);
        puVar6 = (undefined8 *)puVar15[1];
        puVar11 = puVar15;
        while ((puVar15 = puVar6, cVar7 == '\0' && (puVar11 == (undefined8 *)puVar15[2]))) {
          cVar7 = *(char *)((longlong)puVar15[1] + 0x29);
          puVar6 = (undefined8 *)puVar15[1];
          puVar11 = puVar15;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  if (local_e8 < local_f0) {
    _invalid_parameter_noinfo();
  }
  piVar2 = local_e8;
  plVar1 = local_108[0];
  if (local_e8 < local_f0) {
    _invalid_parameter_noinfo();
  }
  plVar12 = local_108[0];
  uVar16 = 0;
  while( true ) {
    if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar12)) {
      _invalid_parameter_noinfo();
    }
    if (piVar14 == piVar2) goto LAB_1402494a2;
    uVar16 = uVar16 + 1;
    if (1000 < uVar16) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar17 = 0;
    }
    else {
      lVar17 = *plVar1;
    }
    if (*(int **)(lVar17 + 0x20) <= piVar14) {
      _invalid_parameter_noinfo();
    }
    if (*piVar14 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_1402479e0(param_1);
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar17 = 0;
    }
    else {
      lVar17 = *plVar1;
    }
    if (*(int **)(lVar17 + 0x20) <= piVar14) {
      _invalid_parameter_noinfo();
    }
    piVar14 = piVar14 + 1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1402494a2:
  piVar14 = (int *)**(undefined8 **)(param_1 + 0x100);
  plVar1 = *(longlong **)(param_1 + 0xd0);
  piStack_110 = piVar14;
  while( true ) {
    piVar4 = piStack_110;
    piVar2 = *(int **)(param_1 + 0x100);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0xd0))) {
      _invalid_parameter_noinfo();
    }
    if (piVar14 == piVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar17 = 0;
    }
    else {
      lVar17 = *plVar1;
    }
    if (piVar14 == *(int **)(lVar17 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar17 = *(longlong *)(piVar14 + 8);
    if (lVar17 != 0) {
      cVar7 = FUN_140421140(lVar17);
      if (cVar7 == '\0') {
        FUN_140421920(lVar17);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)piVar14 + 0x29) == '\0') {
          piVar2 = *(int **)(piVar14 + 4);
          if (*(char *)((longlong)piVar2 + 0x29) == '\0') {
            cVar7 = *(char *)((longlong)*(int **)piVar2 + 0x29);
            piVar14 = piVar2;
            piVar2 = *(int **)piVar2;
            while (piStack_110 = piVar14, cVar7 == '\0') {
              cVar7 = *(char *)((longlong)*(int **)piVar2 + 0x29);
              piVar14 = piVar2;
              piVar2 = *(int **)piVar2;
            }
          }
          else {
            cVar7 = *(char *)((longlong)*(int **)(piVar14 + 2) + 0x29);
            piVar4 = *(int **)(piVar14 + 2);
            piVar2 = piVar14;
            while ((piVar14 = piVar4, piStack_110 = piVar14, cVar7 == '\0' &&
                   (piVar2 == *(int **)(piVar14 + 4)))) {
              cVar7 = *(char *)((longlong)*(int **)(piVar14 + 2) + 0x29);
              piVar4 = *(int **)(piVar14 + 2);
              piVar2 = piVar14;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      else {
        uVar9 = FUN_140421010(lVar17);
        local_res8 = (longlong *)CONCAT44(local_res8._4_4_,uVar9);
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)piVar14 + 0x29) == '\0') {
          piVar2 = *(int **)(piVar14 + 4);
          if (*(char *)((longlong)piVar2 + 0x29) == '\0') {
            cVar7 = *(char *)((longlong)*(int **)piVar2 + 0x29);
            piVar14 = piVar2;
            piVar2 = *(int **)piVar2;
            while (piStack_110 = piVar14, cVar7 == '\0') {
              cVar7 = *(char *)((longlong)*(int **)piVar2 + 0x29);
              piVar14 = piVar2;
              piVar2 = *(int **)piVar2;
            }
          }
          else {
            cVar7 = *(char *)((longlong)*(int **)(piVar14 + 2) + 0x29);
            piVar5 = *(int **)(piVar14 + 2);
            piVar2 = piVar14;
            while ((piVar14 = piVar5, piStack_110 = piVar14, cVar7 == '\0' &&
                   (piVar2 == *(int **)(piVar14 + 4)))) {
              cVar7 = *(char *)((longlong)*(int **)(piVar14 + 2) + 0x29);
              piVar5 = *(int **)(piVar14 + 2);
              piVar2 = piVar14;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        piStack_90 = piVar4;
        local_98 = plVar1;
        FUN_140244670(param_1 + 0xd0,local_60,&local_98);
        uVar16 = FUN_140421080(lVar17,0);
        puVar18 = (undefined8 *)(*(undefined8 **)(param_1 + 0x140))[1];
        cVar7 = *(char *)((longlong)puVar18 + 0x61);
        puVar15 = *(undefined8 **)(param_1 + 0x140);
        while (cVar7 == '\0') {
          if (*(uint *)(puVar18 + 3) < uVar16) {
            puVar11 = (undefined8 *)puVar18[2];
            puVar18 = puVar15;
          }
          else {
            puVar11 = (undefined8 *)*puVar18;
          }
          puVar15 = puVar18;
          puVar18 = puVar11;
          cVar7 = *(char *)((longlong)puVar11 + 0x61);
        }
        local_80 = puVar15;
        local_88 = *(longlong *)(param_1 + 0x110);
        puVar18 = *(undefined8 **)(param_1 + 0x140);
        if (*(longlong *)(param_1 + 0x110) == 0) {
          _invalid_parameter_noinfo();
        }
        if ((puVar15 == puVar18) || (uVar16 < *(uint *)(puVar15 + 3))) {
          local_70 = *(undefined8 *)(param_1 + 0x140);
          local_78 = *(longlong *)(param_1 + 0x110);
          plVar12 = &local_78;
        }
        else {
          plVar12 = &local_88;
        }
        plVar3 = (longlong *)*plVar12;
        piStack_a0 = (int *)plVar12[1];
        piVar2 = *(int **)(param_1 + 0x140);
        local_a8 = plVar3;
        if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x110))) {
          _invalid_parameter_noinfo();
        }
        piVar4 = piStack_a0;
        if (piStack_a0 != piVar2) {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar17 = 0;
          }
          else {
            lVar17 = *plVar3;
          }
          if (piVar4 == *(int **)(lVar17 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          FUN_140246ea0(piVar4 + 8,&local_res8);
        }
        FUN_14023fd50(param_1);
      }
    }
  }
  puVar18 = *(undefined8 **)(param_1 + 0x100);
  puVar15 = (undefined8 *)*puVar18;
  plVar1 = *(longlong **)(param_1 + 0xd0);
  local_res8 = operator_new(8);
  if (local_res8 == (longlong *)0x0) {
    local_d8[0] = (longlong *)0x0;
  }
  else {
    *local_res8 = (longlong)local_d8;
    local_d8[0] = local_res8;
  }
  local_c0 = (int *)0x0;
  local_b8 = (int *)0x0;
  local_b0 = 0;
  local_res10 = local_res8;
  do {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    piVar14 = local_c0;
    if (puVar15 == puVar18) {
      if (local_b8 < local_c0) {
        _invalid_parameter_noinfo();
      }
      piVar2 = local_b8;
      plVar12 = local_d8[0];
      plVar1 = local_d8[0];
      if (local_b8 < local_c0) {
        _invalid_parameter_noinfo();
        plVar1 = local_d8[0];
      }
      while( true ) {
        if ((plVar12 == (longlong *)0x0) || (plVar12 != plVar1)) {
          _invalid_parameter_noinfo();
        }
        if (piVar14 == piVar2) break;
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar17 = 0;
        }
        else {
          lVar17 = *plVar12;
        }
        if (*(int **)(lVar17 + 0x20) <= piVar14) {
          _invalid_parameter_noinfo();
        }
        if (*piVar14 == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          FUN_140248ca0(param_1);
        }
        if (plVar12 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar17 = 0;
        }
        else {
          lVar17 = *plVar12;
        }
        if (*(int **)(lVar17 + 0x20) <= piVar14) {
          _invalid_parameter_noinfo();
        }
        piVar14 = piVar14 + 1;
      }
      if (local_c0 != (int *)0x0) {
        operator_delete(local_c0);
      }
      local_c0 = (int *)0x0;
      local_b8 = (int *)0x0;
      local_b0 = 0;
      operator_delete(local_d8[0]);
      if (local_f0 != (int *)0x0) {
        operator_delete(local_f0);
      }
      local_f0 = (int *)0x0;
      local_e8 = (int *)0x0;
      local_e0 = 0;
      operator_delete(local_108[0]);
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar17 = 0;
    }
    else {
      lVar17 = *plVar1;
    }
    if (puVar15 == *(undefined8 **)(lVar17 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar17 = puVar15[4];
    if ((lVar17 != 0) && (cVar7 = FUN_1404213b0(lVar17), cVar7 != '\0')) {
      iVar8 = FUN_140421010(lVar17);
      piVar14 = local_b8;
      local_res8 = (longlong *)CONCAT44(local_res8._4_4_,iVar8);
      if (local_c0 == (int *)0x0) {
        uVar13 = 0;
      }
      else {
        uVar13 = local_b0 - (longlong)local_c0 >> 2;
      }
      if ((ulonglong)((longlong)local_b8 - (longlong)local_c0 >> 2) < uVar13) {
        *local_b8 = iVar8;
        local_b8 = local_b8 + 1;
      }
      else {
        if (local_b8 < local_c0) {
          _invalid_parameter_noinfo();
        }
        piVar2 = local_c0;
        plVar12 = local_d8[0];
        local_a8 = local_d8[0];
        piStack_a0 = piVar14;
        if (((longlong)local_b8 - (longlong)local_c0 & 0xfffffffffffffffcU) == 0) {
          lVar17 = 0;
        }
        else {
          if (local_b8 < local_c0) {
            _invalid_parameter_noinfo();
          }
          if ((plVar12 == (longlong *)0x0) || (plVar12 != local_d8[0])) {
            _invalid_parameter_noinfo();
          }
          lVar17 = (longlong)piVar14 - (longlong)piVar2 >> 2;
        }
        local_98 = local_a8;
        piStack_90 = piStack_a0;
        FUN_140036c20(local_d8,&local_98,1,&local_res8);
        piVar14 = local_c0;
        if (local_b8 < local_c0) {
          _invalid_parameter_noinfo();
        }
        plVar12 = local_d8[0];
        if (local_d8[0] == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *local_d8[0];
        }
        if (piVar14 + lVar17 <= *(int **)(lVar10 + 0x20)) {
          if (plVar12 == (longlong *)0x0) {
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar12;
          }
          if (*(int **)(lVar10 + 0x18) <= piVar14 + lVar17) goto LAB_140249973;
        }
        _invalid_parameter_noinfo();
      }
    }
LAB_140249973:
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar15 + 0x29) == '\0') {
      puVar11 = (undefined8 *)puVar15[2];
      if (*(char *)((longlong)puVar11 + 0x29) == '\0') {
        cVar7 = *(char *)((longlong)*puVar11 + 0x29);
        puVar15 = puVar11;
        puVar11 = (undefined8 *)*puVar11;
        while (cVar7 == '\0') {
          cVar7 = *(char *)((longlong)*puVar11 + 0x29);
          puVar15 = puVar11;
          puVar11 = (undefined8 *)*puVar11;
        }
      }
      else {
        cVar7 = *(char *)((longlong)puVar15[1] + 0x29);
        puVar6 = (undefined8 *)puVar15[1];
        puVar11 = puVar15;
        while ((puVar15 = puVar6, cVar7 == '\0' && (puVar11 == (undefined8 *)puVar15[2]))) {
          cVar7 = *(char *)((longlong)puVar15[1] + 0x29);
          puVar6 = (undefined8 *)puVar15[1];
          puVar11 = puVar15;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_14024ba60  @14024ba60  [medium:callgraph-r1]  (orig: FUN_14024ba60)
void FUN_14024ba60(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14024c780  @14024c780  [medium:callgraph-r1]  (orig: FUN_14024c780)
void FUN_14024c780(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14024dff0  @14024dff0  [medium:callgraph-r1]  (orig: FUN_14024dff0)
void FUN_14024dff0(longlong param_1)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong lVar7;
  
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  plVar3 = *(longlong **)(param_1 + 8);
  puVar4 = (undefined8 *)*puVar2;
  do {
    do {
      while( true ) {
        while( true ) {
          puVar6 = puVar4;
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (puVar6 == puVar2) {
            return;
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *plVar3;
          }
          if (puVar6 == *(undefined8 **)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (puVar6[4] != 0) {
            FUN_14041c4e0();
          }
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)puVar6 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          puVar4 = puVar6;
        }
        puVar4 = (undefined8 *)puVar6[2];
        if (*(char *)((longlong)puVar4 + 0x29) != '\0') break;
        cVar1 = *(char *)((longlong)*puVar4 + 0x29);
        puVar6 = (undefined8 *)*puVar4;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar6 + 0x29);
          puVar4 = puVar6;
          puVar6 = (undefined8 *)*puVar6;
        }
      }
      puVar4 = (undefined8 *)puVar6[1];
    } while (*(char *)((longlong)puVar4 + 0x29) != '\0');
    do {
      puVar5 = puVar4;
      puVar4 = puVar5;
      if (puVar6 != (undefined8 *)puVar5[2]) break;
      puVar4 = (undefined8 *)puVar5[1];
      puVar6 = puVar5;
    } while (*(char *)((longlong)puVar4 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_140252580  @140252580  [medium:callgraph-r3]  (orig: FUN_140252580)
void FUN_140252580(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
    }
    param_1 = param_1 + 3;
  }
  return;
}

// ==== CMapGroupKernel::helper_1402577e0  @1402577e0  [medium:callgraph-r3]  (orig: FUN_1402577e0)
longlong * FUN_1402577e0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar5 = param_1[4] - uVar1;
  lVar3 = 0;
  lVar2 = lVar5 >> 0x3f;
  lVar4 = lVar3;
  if (lVar5 / 0xc + lVar2 != lVar2) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = (longlong)(param_3[1] - uVar1) / 6 + ((longlong)(param_3[1] - uVar1) >> 0x3f);
    lVar4 = (lVar2 >> 1) - (lVar2 >> 0x3f);
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_140256b00(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 + lVar4 * 0xc;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar3 = *param_1;
    }
    if (*(ulonglong *)(lVar3 + 0x18) <= uVar1) goto LAB_140257902;
  }
  _invalid_parameter_noinfo();
LAB_140257902:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMapGroupKernel::helper_140258180  @140258180  [medium:callgraph-r2]  (orig: FUN_140258180)
void FUN_140258180(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  longlong lVar3;
  ulonglong uVar4;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar4 = 0;
  }
  else {
    lVar3 = (longlong)(param_1[5] - uVar1) / 6 + ((longlong)(param_1[5] - uVar1) >> 0x3f);
    uVar4 = (lVar3 >> 1) - (lVar3 >> 0x3f);
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0xc) < uVar4) {
    FUN_140252580(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0xc;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1402577e0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMapGroupKernel::helper_140258270  @140258270  [medium:callgraph-r1]  (orig: FUN_140258270)
void FUN_140258270(longlong param_1)

{
  undefined4 *puVar1;
  int iVar2;
  longlong *plVar3;
  ulong uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined4 *puVar10;
  longlong lVar11;
  longlong lVar12;
  bool bVar13;
  longlong *local_f8 [3];
  undefined4 *local_e0;
  undefined4 *local_d8;
  undefined8 local_d0;
  int local_c8;
  undefined4 local_c4;
  undefined1 local_c0;
  undefined4 local_b8;
  undefined4 local_b4;
  undefined4 local_b0;
  longlong *local_a8;
  undefined4 local_a0;
  undefined1 local_9c;
  int local_80;
  int local_7c;
  longlong *local_78;
  longlong *local_68;
  undefined8 local_58;
  longlong *local_50;
  longlong *local_40;
  
  local_58 = 0xfffffffffffffffe;
  local_f8[0] = operator_new(8);
  if (local_f8[0] == (longlong *)0x0) {
    local_f8[0] = (longlong *)0x0;
  }
  else {
    *local_f8[0] = (longlong)local_f8;
  }
  lVar11 = 0;
  local_e0 = (undefined4 *)0x0;
  local_d8 = (undefined4 *)0x0;
  local_d0 = 0;
  plVar8 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  plVar6 = *(longlong **)(param_1 + 0x18);
  local_78 = plVar6;
  do {
    while( true ) {
      while( true ) {
        plVar9 = *(longlong **)(param_1 + 0x48);
        local_40 = *(longlong **)(param_1 + 0x18);
        if ((plVar6 == (longlong *)0x0) || (plVar6 != local_40)) {
          _invalid_parameter_noinfo();
        }
        puVar10 = local_e0;
        if (plVar8 == plVar9) {
          local_50 = (longlong *)0x0;
          if (local_d8 < local_e0) {
            _invalid_parameter_noinfo();
          }
          plVar8 = local_f8[0];
          local_50 = local_f8[0];
          while( true ) {
            puVar1 = local_d8;
            local_68 = (longlong *)0x0;
            if (local_d8 < local_e0) {
              _invalid_parameter_noinfo();
            }
            local_68 = local_f8[0];
            if ((plVar8 == (longlong *)0x0) || (plVar8 != local_f8[0])) {
              _invalid_parameter_noinfo();
            }
            if (puVar10 == puVar1) break;
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = lVar11;
            }
            else {
              lVar7 = *plVar8;
            }
            if (*(undefined4 **)(lVar7 + 0x20) <= puVar10) {
              _invalid_parameter_noinfo();
            }
            local_b8 = *puVar10;
            local_b4 = puVar10[1];
            local_b0 = puVar10[2];
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            plVar6 = (longlong *)FUN_140087650(uVar5);
            lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,local_b8);
            if (lVar7 != 0) {
              FUN_140255e10(param_1,lVar7,local_b4,(undefined1)local_b0);
            }
            if (plVar8 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = lVar11;
            }
            else {
              lVar7 = *plVar8;
            }
            if (*(undefined4 **)(lVar7 + 0x20) <= puVar10) {
              _invalid_parameter_noinfo();
            }
            puVar10 = puVar10 + 3;
          }
          if (local_e0 != (undefined4 *)0x0) {
            operator_delete(local_e0);
          }
          local_e0 = (undefined4 *)0x0;
          local_d8 = (undefined4 *)0x0;
          local_d0 = 0;
          operator_delete(local_f8[0]);
          return;
        }
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = lVar11;
        }
        else {
          lVar7 = *plVar6;
        }
        if (plVar8 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar7 = plVar8[3];
        if ((int)lVar7 != 0) {
          if (plVar6 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = lVar11;
          }
          else {
            lVar12 = *plVar6;
          }
          if (plVar8 == *(longlong **)(lVar12 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          memcpy(&local_a0,(void *)((longlong)plVar8 + 0x1c),0x28);
          iVar2 = local_7c;
          if ((local_7c != 0) && (uVar4 = tq::TimeGet(0), (uint)(iVar2 + local_80) <= uVar4 / 1000))
          {
            local_80 = 0;
            local_c4 = local_a0;
            local_c0 = local_9c;
            local_c8 = (int)lVar7;
            FUN_140258180(local_f8,&local_c8);
          }
        }
        if (plVar6 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar8 + 0x45) == '\0') break;
        _invalid_parameter_noinfo();
      }
      plVar9 = plVar8;
      plVar3 = (longlong *)plVar8[2];
      if (*(char *)(plVar8[2] + 0x45) != '\0') break;
      do {
        plVar8 = plVar3;
        plVar3 = (longlong *)*plVar8;
        local_a8 = plVar8;
      } while (*(char *)(*plVar8 + 0x45) == '\0');
    }
    do {
      plVar8 = (longlong *)plVar9[1];
      if (*(char *)((longlong)plVar8 + 0x45) != '\0') break;
      bVar13 = plVar9 == (longlong *)plVar8[2];
      plVar9 = plVar8;
    } while (bVar13);
  } while( true );
}

// ==== CMapGroupKernel::helper_1402585d0  @1402585d0  [medium:callgraph-r1]  (orig: FUN_1402585d0)
void FUN_1402585d0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140261b80  @140261b80  [medium:callgraph-r1]  (orig: FUN_140261b80)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140261b80(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined1 local_498 [8];
  undefined1 local_490 [24];
  longlong *local_478;
  longlong *local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  iVar4 = tq::DateStamp(0);
  if (*(int *)(param_1 + 0x58) != iVar4) {
    iVar4 = tq::DateStamp(0);
    *(int *)(param_1 + 0x58) = iVar4;
    iVar4 = 0;
    lVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x5c));
    if (*(longlong *)(lVar7 + 0x90) == 0) {
      local_4a8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_1402ac340(*(undefined8 *)(lVar7 + 0x90),local_498);
    while (cVar3 = FUN_1400ce310(local_490), cVar3 != '\0') {
      while (cVar3 = (**(code **)(*local_478 + 0x298))(local_478,0x1001,&local_470),
            plVar9 = local_470, cVar3 == '\0') {
        cVar3 = FUN_1400ce310(local_490);
        if (cVar3 == '\0') goto LAB_140261d9c;
      }
      iVar4 = iVar4 + 1;
      if (10000 < iVar4) {
        local_4a8 = 0xa6;
        log_InlineLogERROR(&DAT_1406d9c10);
        break;
      }
      if (local_470 != (longlong *)0x0) {
        uVar5 = (**(code **)(*local_470 + 8))(local_470);
        lVar7 = FUN_140261430(param_1,uVar5);
        if ((lVar7 != 0) && (cVar3 = FUN_140427220(lVar7), cVar3 != '\0')) {
          uVar5 = (**(code **)(plVar9[2] + 0x70))(plVar9 + 2);
          uVar6 = (**(code **)(*plVar9 + 0x108))(plVar9);
          plVar8 = (longlong *)FUN_140425750(*(undefined8 *)(param_1 + 8),uVar6,uVar5,2);
          if ((plVar8 != (longlong *)0x0) && (lVar7 = FUN_14042a550(lVar7,plVar8,0,0), lVar7 == 0))
          {
            plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,0);
            (**(code **)(*plVar8 + 0x40))(plVar8);
            (**(code **)(*plVar9 + 8))(plVar9);
            log_InlineLogERROR(
                              "CActivityMgr::OnTimer, AddActivityTask user_id[%u] activity_id[%u] failed."
                              );
          }
          FUN_14042bb20(local_458);
          cVar3 = FUN_14042bbe0(local_458,0);
          if (cVar3 != '\0') {
            (**(code **)(plVar9[2] + 0x350))(plVar9 + 2,local_458);
          }
          FUN_14042bb70(local_458);
        }
      }
    }
  }
LAB_140261d9c:
  plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x48);
  plVar8 = *(longlong **)(param_1 + 0x18);
  while( true ) {
    plVar1 = *(longlong **)(param_1 + 0x48);
    if ((plVar8 == (longlong *)0x0) || (plVar8 != *(longlong **)(param_1 + 0x18))) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar1) break;
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar8;
    }
    if (plVar9 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar9[4] != 0) {
      FUN_140428e30();
    }
    if (plVar8 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar1 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar1 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar1 + 0x29);
        plVar9 = plVar1;
        plVar1 = (longlong *)*plVar1;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar1 + 0x29);
          plVar9 = plVar1;
          plVar1 = (longlong *)*plVar1;
        }
      }
      else {
        cVar3 = *(char *)(plVar9[1] + 0x29);
        plVar2 = (longlong *)plVar9[1];
        plVar1 = plVar9;
        while ((plVar9 = plVar2, cVar3 == '\0' && (plVar1 == (longlong *)plVar9[2]))) {
          cVar3 = *(char *)(plVar9[1] + 0x29);
          plVar2 = (longlong *)plVar9[1];
          plVar1 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_14026a760  @14026a760  [medium:callgraph-r1]  (orig: FUN_14026a760)
void FUN_14026a760(undefined8 *param_1)

{
  FUN_1402672c0();
  FUN_14026a520(param_1);
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14026aa40  @14026aa40  [medium:callgraph-r1]  (orig: FUN_14026aa40)
void FUN_14026aa40(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140272200  @140272200  [medium:callgraph-r1]  (orig: FUN_140272200)
void FUN_140272200(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140276730  @140276730  [medium:callgraph-r1]  (orig: FUN_140276730)
void FUN_140276730(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    FUN_1400a29f0();
    operator_delete((void *)*param_1);
    operator_delete(param_1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140278ff0  @140278ff0  [medium:callgraph-r1]  (orig: FUN_140278ff0)
void FUN_140278ff0(undefined8 *param_1)

{
  FUN_140278cb0(param_1 + 9);
  FUN_140278cb0(param_1 + 1);
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140279da0  @140279da0  [medium:callgraph-r1]  (orig: FUN_140279da0)
longlong * FUN_140279da0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  ulong uVar2;
  longlong *extraout_RAX;
  longlong *plVar3;
  longlong *extraout_RAX_00;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *local_48;
  longlong *plStack_40;
  undefined1 local_38 [32];
  
  uVar2 = tq::TimeGet(0);
  plVar3 = (longlong *)((ulonglong)uVar2 * 0x10624dd3 & 0xffffffff);
  if ((uint)(*(int *)(param_1 + 0x8c) + *(int *)(param_1 + 0x88)) <= uVar2 / 1000) {
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x8c) = uVar2 / 1000;
    uVar2 = tq::TimeGet(1);
    plVar3 = *(longlong **)(param_1 + 8);
    plVar4 = (longlong *)**(longlong **)(param_1 + 0x38);
    plVar5 = plVar3;
    plVar8 = plVar4;
    while( true ) {
      plVar10 = *(longlong **)(param_1 + 0x38);
      if ((plVar3 == (longlong *)0x0) || (plVar7 = plVar5, plVar3 != *(longlong **)(param_1 + 8))) {
        _invalid_parameter_noinfo();
        plVar7 = plVar5;
      }
      if (plVar4 == plVar10) break;
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar3;
      }
      if (plVar4 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar5 = plVar7;
      if (*(int *)((longlong)plVar4 + 0x24) + 0x78U < uVar2) {
        plVar10 = plVar8;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x2d) == '\0') {
          plVar10 = (longlong *)plVar4[2];
          if (*(char *)((longlong)plVar10 + 0x2d) == '\0') {
            cVar1 = *(char *)(*plVar10 + 0x2d);
            plVar4 = plVar10;
            plVar9 = (longlong *)*plVar10;
            while (plVar10 = plVar4, cVar1 == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x2d);
              plVar4 = plVar9;
              plVar9 = (longlong *)*plVar9;
            }
          }
          else {
            cVar1 = *(char *)(plVar4[1] + 0x2d);
            plVar10 = (longlong *)plVar4[1];
            plVar9 = plVar4;
            while ((plVar4 = plVar10, plVar10 = plVar4, cVar1 == '\0' &&
                   (plVar9 == (longlong *)plVar4[2]))) {
              cVar1 = *(char *)(plVar4[1] + 0x2d);
              plVar10 = (longlong *)plVar4[1];
              plVar9 = plVar4;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_48 = plVar7;
        plStack_40 = plVar8;
        FUN_140279680(param_1 + 8,local_38,&local_48,param_4,plVar5,plVar10);
        plVar8 = plVar10;
      }
      else {
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar5 = plVar7;
        }
        if (*(char *)((longlong)plVar4 + 0x2d) == '\0') {
          plVar8 = (longlong *)plVar4[2];
          if (*(char *)((longlong)plVar8 + 0x2d) == '\0') {
            cVar1 = *(char *)(*plVar8 + 0x2d);
            plVar4 = plVar8;
            plVar10 = (longlong *)*plVar8;
            while (plVar8 = plVar4, cVar1 == '\0') {
              cVar1 = *(char *)(*plVar10 + 0x2d);
              plVar4 = plVar10;
              plVar10 = (longlong *)*plVar10;
            }
          }
          else {
            cVar1 = *(char *)(plVar4[1] + 0x2d);
            plVar8 = (longlong *)plVar4[1];
            plVar10 = plVar4;
            while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' &&
                   (plVar10 == (longlong *)plVar4[2]))) {
              cVar1 = *(char *)(plVar4[1] + 0x2d);
              plVar8 = (longlong *)plVar4[1];
              plVar10 = plVar4;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
    plVar3 = *(longlong **)(param_1 + 0x78);
    plVar4 = *(longlong **)(param_1 + 0x48);
    plVar5 = (longlong *)*plVar3;
    plVar8 = plVar4;
    plVar10 = (longlong *)*plVar3;
    while( true ) {
      plVar7 = *(longlong **)(param_1 + 0x78);
      if ((plVar4 == (longlong *)0x0) || (plVar9 = plVar8, plVar4 != *(longlong **)(param_1 + 0x48))
         ) {
        _invalid_parameter_noinfo();
        plVar3 = extraout_RAX;
        plVar9 = plVar8;
      }
      if (plVar5 == plVar7) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar6 = 0;
      }
      else {
        lVar6 = *plVar4;
      }
      if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar9;
      if (*(int *)((longlong)plVar5 + 0x24) + 0x78U < uVar2) {
        plVar7 = plVar10;
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar5 + 0x2d) == '\0') {
          plVar3 = (longlong *)plVar5[2];
          if (*(char *)((longlong)plVar3 + 0x2d) == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x2d);
            plVar5 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (plVar7 = plVar5, cVar1 == '\0') {
              cVar1 = *(char *)(*plVar3 + 0x2d);
              plVar5 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar1 = *(char *)(plVar5[1] + 0x2d);
            plVar7 = (longlong *)plVar5[1];
            plVar3 = plVar5;
            while ((plVar5 = plVar7, plVar7 = plVar5, cVar1 == '\0' &&
                   (plVar3 == (longlong *)plVar5[2]))) {
              cVar1 = *(char *)(plVar5[1] + 0x2d);
              plVar7 = (longlong *)plVar5[1];
              plVar3 = plVar5;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_48 = plVar9;
        plStack_40 = plVar10;
        plVar3 = (longlong *)FUN_140279680(param_1 + 0x48,local_38,&local_48,param_4,plVar8,plVar7);
        plVar10 = plVar7;
      }
      else {
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar8 = plVar9;
        }
        if (*(char *)((longlong)plVar5 + 0x2d) == '\0') {
          plVar3 = (longlong *)plVar5[2];
          if (*(char *)((longlong)plVar3 + 0x2d) == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x2d);
            plVar5 = plVar3;
            plVar3 = (longlong *)*plVar3;
            while (plVar10 = plVar5, cVar1 == '\0') {
              cVar1 = *(char *)(*plVar3 + 0x2d);
              plVar5 = plVar3;
              plVar3 = (longlong *)*plVar3;
            }
          }
          else {
            cVar1 = *(char *)(plVar5[1] + 0x2d);
            plVar10 = (longlong *)plVar5[1];
            plVar7 = plVar5;
            while ((plVar3 = plVar10, plVar5 = plVar3, plVar10 = plVar3, cVar1 == '\0' &&
                   (plVar7 == (longlong *)plVar3[2]))) {
              cVar1 = *(char *)(plVar3[1] + 0x2d);
              plVar10 = (longlong *)plVar3[1];
              plVar7 = plVar3;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
          plVar3 = extraout_RAX_00;
        }
      }
    }
  }
  return plVar3;
}

// ==== CMapGroupKernel::helper_14027aed0  @14027aed0  [medium:callgraph-r1]  (orig: FUN_14027aed0)
void FUN_14027aed0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14027dda0  @14027dda0  [medium:callgraph-r2]  (orig: FUN_14027dda0)
longlong FUN_14027dda0(undefined4 *param_1,undefined4 *param_2,longlong param_3)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> *this;
  longlong lVar1;
  longlong lVar2;
  
  lVar2 = (longlong)param_2 - (longlong)param_1;
  if (param_1 != param_2) {
    lVar1 = (longlong)param_1 - param_3;
    this = (basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_3 + 8);
    do {
      *(undefined4 *)(this + -8) = *param_1;
      *(undefined4 *)(this + -4) = param_1[1];
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                (this,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)(this + lVar1));
      param_1 = param_1 + 0xc;
      this = this + 0x30;
    } while (param_1 != param_2);
  }
  return (lVar2 / 0x30) * 0x30 + param_3;
}

// ==== CMapGroupKernel::helper_140281e10  @140281e10  [medium:callgraph-r1]  (orig: FUN_140281e10)
longlong *
FUN_140281e10(longlong *param_1,longlong *param_2,
             basic_string<char,std::char_traits<char>,std::allocator<char>_> *param_3)

{
  char cVar1;
  undefined8 *puVar2;
  bool bVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar6 = (undefined8 *)((undefined8 *)param_1[6])[1];
  cVar1 = *(char *)((longlong)puVar6 + 0x51);
  puVar2 = (undefined8 *)param_1[6];
  while (cVar1 == '\0') {
    bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                      ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                       (puVar6 + 3),param_3);
    if (bVar3) {
      puVar5 = (undefined8 *)puVar6[2];
      puVar6 = puVar2;
    }
    else {
      puVar5 = (undefined8 *)*puVar6;
    }
    puVar2 = puVar6;
    puVar6 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x51);
  }
  puVar6 = (undefined8 *)param_1[6];
  local_20 = puVar2;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar6) ||
     (bVar3 = std::operator<<char,std::char_traits<char>,std::allocator<char>_>
                        (param_3,(basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                                 (puVar2 + 3)), bVar3)) {
    plVar4 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar4 = &local_28;
  }
  *param_2 = *plVar4;
  param_2[1] = plVar4[1];
  return param_2;
}

// ==== CMapGroupKernel::helper_140283410  @140283410  [medium:callgraph-r0]  (orig: FUN_140283410)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140283410(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  undefined1 local_38 [16];
  
  plVar2 = *(longlong **)(param_1 + 0x98);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 200);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 200);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x98))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar3) {
            plVar2 = *(longlong **)(*(longlong *)(param_1 + 200) + 8);
            cVar1 = *(char *)((longlong)plVar2 + 0x41);
            while (cVar1 == '\0') {
              FUN_140016c20(param_1 + 0x98,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                        ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         (plVar2 + 3));
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x41);
            }
            *(longlong *)(*(longlong *)(param_1 + 200) + 8) = *(longlong *)(param_1 + 200);
            *(undefined8 *)(param_1 + 0xd0) = 0;
            *(undefined8 *)*(undefined8 *)(param_1 + 200) = *(undefined8 *)(param_1 + 200);
            *(longlong *)(*(longlong *)(param_1 + 200) + 0x10) = *(longlong *)(param_1 + 200);
            plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x108) + 8);
            cVar1 = *(char *)((longlong)plVar2 + 0x51);
            while (cVar1 == '\0') {
              FUN_140280fc0(param_1 + 0xd8,plVar2[2]);
              plVar3 = (longlong *)*plVar2;
              std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
              ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                        ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)
                         (plVar2 + 3));
              operator_delete(plVar2);
              plVar2 = plVar3;
              cVar1 = *(char *)((longlong)plVar3 + 0x51);
            }
            *(longlong *)(*(longlong *)(param_1 + 0x108) + 8) = *(longlong *)(param_1 + 0x108);
            *(undefined8 *)(param_1 + 0x110) = 0;
            *(undefined8 *)*(undefined8 *)(param_1 + 0x108) = *(undefined8 *)(param_1 + 0x108);
            *(longlong *)(*(longlong *)(param_1 + 0x108) + 0x10) = *(longlong *)(param_1 + 0x108);
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          plVar4 = (longlong *)FUN_140281e10(param_1 + 0xd8,local_38,plVar5 + 3);
          plVar3 = (longlong *)*plVar4;
          lVar6 = plVar4[1];
          lVar7 = *(longlong *)(param_1 + 0x108);
          if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0xd8))) {
            _invalid_parameter_noinfo();
          }
          if (lVar6 != lVar7) {
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (plVar3 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar3;
            }
            if (lVar6 == *(longlong *)(lVar7 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(ulonglong *)(lVar6 + 0x38) < 0x10) {
              lVar7 = lVar6 + 0x20;
            }
            else {
              lVar7 = *(longlong *)(lVar6 + 0x20);
            }
            tq::OverTimeLogSave("syslog/slowscript","%s, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                                lVar7,*(undefined4 *)(lVar6 + 0x44));
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x41) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x41) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x41);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x41);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x41) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x41) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_140286760  @140286760  [medium:callgraph-r2]  (orig: FUN_140286760)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140286760(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
             undefined4 param_5,undefined8 param_6)

{
  char cVar1;
  undefined1 auStack_478 [32];
  undefined4 local_458;
  undefined8 local_450;
  undefined8 local_448;
  undefined8 local_440;
  undefined8 local_438;
  char local_428 [1024];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  local_448 = *(undefined8 *)(param_1 + 0x10);
  local_450 = param_6;
  local_440 = *(undefined8 *)(param_1 + 0x18);
  local_438 = *(undefined8 *)(param_1 + 0x20);
  local_458 = param_5;
  sprintf(local_428,"</F>OnSystemFunctionProcess</N>%d</N>%d</N>%d</S>%s");
  local_450 = 0;
  local_458 = 0;
  cVar1 = FUN_1402863b0(param_1,local_428,param_2,0);
  if (cVar1 == '\0') {
    log_InlineLogLuaERROR
              ("Lua return fault, Call From:CLuaScriptMgr::LuaEventNotify, lua function:%s.");
  }
  *(undefined8 *)(param_1 + 0x10) = local_448;
  *(undefined8 *)(param_1 + 0x18) = local_440;
  *(undefined8 *)(param_1 + 0x20) = local_438;
  return 1;
}

// ==== CMapGroupKernel::helper_140286840  @140286840  [medium:callgraph-r1]  (orig: FUN_140286840)
void FUN_140286840(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  char cVar7;
  ulong uVar8;
  longlong lVar9;
  longlong *plVar10;
  ulonglong uVar11;
  longlong lVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  undefined1 local_res8;
  ulonglong local_res10;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong *plStack_70;
  longlong *local_68;
  longlong *plStack_60;
  undefined1 local_58 [32];
  
  uVar16 = 0xfffffffffffffffe;
  uVar8 = tq::TimeGet(1);
  uVar11 = 0;
  local_res10 = 0;
  lVar9 = *(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40);
  lVar12 = lVar9 >> 0x3f;
  if (lVar9 / 0x30 + lVar12 != lVar12) {
    local_res8 = (undefined1)uVar8;
    uVar14 = uVar11;
    do {
      if ((ulonglong)((*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40)) / 0x30) <=
          local_res10) {
        _invalid_parameter_noinfo();
      }
      lVar12 = *(longlong *)(param_1 + 0x40);
      if (uVar8 < *(uint *)(lVar12 + uVar11)) {
        uVar14 = (ulonglong)((int)uVar14 + 1);
        local_res10 = local_res10 + 1;
        uVar11 = uVar11 + 0x30;
      }
      else {
        if (*(ulonglong *)(lVar12 + 0x28 + uVar11) < 0x10) {
          lVar9 = lVar12 + 0x10 + uVar11;
        }
        else {
          lVar9 = *(longlong *)(lVar12 + 0x10 + uVar11);
        }
        uVar15 = 0;
        cVar7 = FUN_140286530(param_1,lVar9,*(undefined4 *)(lVar12 + 4 + uVar11),0,0,0,uVar16);
        if (cVar7 == '\0') {
          if (*(ulonglong *)(lVar12 + 0x28 + uVar11) < 0x10) {
            lVar12 = lVar12 + 0x10 + uVar11;
          }
          else {
            lVar12 = *(longlong *)(lVar12 + 0x10 + uVar11);
          }
          log_InlineLogLuaERROR
                    ("Lua return fault, Call From:CLuaScriptMgr::OnTimer, lua function:%s.",lVar12);
        }
        uVar13 = *(ulonglong *)(param_1 + 0x40);
        if (*(ulonglong *)(param_1 + 0x48) < uVar13) {
          _invalid_parameter_noinfo();
        }
        plVar10 = *(longlong **)(param_1 + 0x28);
        if (plVar10 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar10;
        }
        uVar13 = uVar13 + (longlong)(int)uVar14 * 0x30;
        if (*(ulonglong *)(lVar12 + 0x20) < uVar13) {
LAB_1402869cb:
          _invalid_parameter_noinfo();
        }
        else {
          if (plVar10 == (longlong *)0x0) {
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar10;
          }
          if (uVar13 < *(ulonglong *)(lVar12 + 0x18)) goto LAB_1402869cb;
        }
        FUN_14027dda0(uVar13 + 0x30,*(undefined8 *)(param_1 + 0x48),uVar13,local_res8,uVar8 & 0xff,
                      uVar15 & 0xffffffffffffff00);
        lVar9 = *(longlong *)(param_1 + 0x48);
        for (lVar12 = lVar9 + -0x30; lVar12 != lVar9; lVar12 = lVar12 + 0x30) {
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
                    ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(lVar12 + 8)
                    );
        }
        *(longlong *)(param_1 + 0x48) = *(longlong *)(param_1 + 0x48) + -0x30;
        if ((uVar13 < *(ulonglong *)(param_1 + 0x40)) || (*(ulonglong *)(param_1 + 0x48) < uVar13))
        {
          _invalid_parameter_noinfo();
        }
      }
    } while ((ulonglong)(longlong)(int)uVar14 <
             (ulonglong)((*(longlong *)(param_1 + 0x48) - *(longlong *)(param_1 + 0x40)) / 0x30));
  }
  lVar12 = 0;
  plVar10 = (longlong *)**(longlong **)(param_1 + 0x88);
  plVar3 = *(longlong **)(param_1 + 0x58);
  plStack_70 = plVar10;
  while( true ) {
    plVar5 = plStack_70;
    plVar4 = *(longlong **)(param_1 + 0x88);
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x58))) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar4) break;
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = lVar12;
    }
    else {
      lVar9 = *plVar3;
    }
    if (plVar10 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (uVar8 < *(uint *)(plVar10 + 4)) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        plVar4 = (longlong *)plVar10[2];
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
          cVar7 = *(char *)(*plVar4 + 0x29);
          plVar10 = plVar4;
          plVar4 = (longlong *)*plVar4;
          while (plStack_70 = plVar10, cVar7 == '\0') {
            cVar7 = *(char *)(*plVar4 + 0x29);
            plVar10 = plVar4;
            plVar4 = (longlong *)*plVar4;
          }
        }
        else {
          cVar7 = *(char *)(plVar10[1] + 0x29);
          plVar5 = (longlong *)plVar10[1];
          plVar4 = plVar10;
          while ((plVar10 = plVar5, plStack_70 = plVar10, cVar7 == '\0' &&
                 (plVar4 == (longlong *)plVar10[2]))) {
            cVar7 = *(char *)(plVar10[1] + 0x29);
            plVar5 = (longlong *)plVar10[1];
            plVar4 = plVar10;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    else {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = lVar12;
      }
      else {
        lVar9 = *plVar3;
      }
      if (plVar10 == *(longlong **)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined4 *)((longlong)plVar10 + 0x1c);
      iVar2 = *(int *)((longlong)plVar10 + 0x24);
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        plVar4 = (longlong *)plVar10[2];
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
          cVar7 = *(char *)(*plVar4 + 0x29);
          plVar10 = plVar4;
          plVar4 = (longlong *)*plVar4;
          while (plStack_70 = plVar10, cVar7 == '\0') {
            cVar7 = *(char *)(*plVar4 + 0x29);
            plVar10 = plVar4;
            plVar4 = (longlong *)*plVar4;
          }
        }
        else {
          cVar7 = *(char *)(plVar10[1] + 0x29);
          plVar6 = (longlong *)plVar10[1];
          plVar4 = plVar10;
          while ((plVar10 = plVar6, plStack_70 = plVar10, cVar7 == '\0' &&
                 (plVar4 == (longlong *)plVar10[2]))) {
            cVar7 = *(char *)(plVar10[1] + 0x29);
            plVar6 = (longlong *)plVar10[1];
            plVar4 = plVar10;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      plStack_60 = plVar5;
      local_68 = plVar3;
      FUN_140281940(param_1 + 0x58,local_58,&local_68);
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined1 **)(param_1 + 0x20) = &DAT_1406dd892;
      *(undefined4 *)(param_1 + 0x18) = 0;
      *(int *)(param_1 + 0x10) = iVar2;
      lVar9 = lVar12;
      if (iVar2 != 0) {
        lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x118),0);
        if (*(longlong *)(lVar9 + 0x90) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pUserManager",
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                             ,0x130);
        }
        lVar9 = (**(code **)(**(longlong **)(lVar9 + 0x90) + 0x98))
                          (*(longlong **)(lVar9 + 0x90),*(undefined4 *)(param_1 + 0x10));
      }
      FUN_140286760(param_1,lVar9,0x34,uVar1,0,&DAT_1406dd892);
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_1 + 0x14) = 0;
      *(undefined1 **)(param_1 + 0x20) = &DAT_1406dd892;
      *(undefined4 *)(param_1 + 0x18) = 0;
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_14029e630  @14029e630  [medium:callgraph-r2]  (orig: FUN_14029e630)
void FUN_14029e630(undefined8 param_1,longlong *param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  cVar1 = *(char *)((longlong)param_2 + 0x49);
  while (cVar1 == '\0') {
    FUN_14029e630(param_1,param_2[2],param_3,param_4,uVar3);
    plVar2 = (longlong *)*param_2;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    ~basic_string<char,std::char_traits<char>,std::allocator<char>_>
              ((basic_string<char,std::char_traits<char>,std::allocator<char>_> *)(param_2 + 3));
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x49);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402a1a60  @1402a1a60  [medium:callgraph-r3]  (orig: FUN_1402a1a60)
longlong * FUN_1402a1a60(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_14029e630(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar2 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar2;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x49) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x49) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x49);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x49);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x49);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x49);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_14029d600(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_1402a2170  @1402a2170  [medium:callgraph-r2]  (orig: FUN_1402a2170)
void FUN_1402a2170(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402a1a60((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_1402a2cd0  @1402a2cd0  [medium:callgraph-r1]  (orig: FUN_1402a2cd0)
void FUN_1402a2cd0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  FUN_14029e630(param_1,*(undefined8 *)(param_1[6] + 8),param_3,param_4,0xfffffffffffffffe);
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  param_1[7] = 0;
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  FUN_1402a2170(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapGroupKernel::helper_1402a4b60  @1402a4b60  [medium:callgraph-r3]  (orig: FUN_1402a4b60)
void FUN_1402a4b60(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402a49b0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMapGroupKernel::helper_1402a5280  @1402a5280  [medium:callgraph-r3]  (orig: FUN_1402a5280)
void FUN_1402a5280(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_1402a4ec0(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x29) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x29);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x29);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x29);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x29);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMapGroupKernel::helper_1402a5d20  @1402a5d20  [medium:callgraph-r2]  (orig: FUN_1402a5d20)
longlong * FUN_1402a5d20(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402a4b60(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402a5870(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMapGroupKernel::helper_1402a5ed0  @1402a5ed0  [medium:callgraph-r2]  (orig: FUN_1402a5ed0)
void FUN_1402a5ed0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1402a5d20((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_1402a6fa0  @1402a6fa0  [medium:callgraph-r2]  (orig: FUN_1402a6fa0)
undefined8 *
FUN_1402a6fa0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402a4be0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_1402a5280(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMapGroupKernel::helper_1402a7250  @1402a7250  [medium:callgraph-r1]  (orig: FUN_1402a7250)
void FUN_1402a7250(undefined8 *param_1)

{
  FUN_1402a5ed0(param_1 + 8);
  operator_delete((void *)param_1[8]);
  FUN_1402a5ed0(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CMapGroupKernel::helper_1402a7cd0  @1402a7cd0  [medium:callgraph-r1]  (orig: FUN_1402a7cd0)
void FUN_1402a7cd0(undefined8 param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong lVar6;
  bool bVar7;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 local_b8;
  undefined4 uStack_b4;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  longlong *local_a0 [3];
  longlong *local_88 [6];
  undefined8 *local_58;
  undefined8 local_50;
  longlong *local_48;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined8 local_18;
  
  local_18 = 0xfffffffffffffffe;
  FUN_1402a6fa0(local_88,param_1);
  puVar2 = local_58;
  plVar1 = local_88[0];
  puVar4 = (undefined8 *)*local_58;
  local_48 = local_88[0];
  local_a0[0] = local_88[0];
  do {
    while( true ) {
      while( true ) {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar4 == puVar2) {
          local_b8 = SUB84(local_88[0],0);
          uStack_b4 = (undefined4)((ulonglong)local_88[0] >> 0x20);
          uStack_b0 = SUB84(local_58,0);
          uStack_ac = (undefined4)((ulonglong)local_58 >> 0x20);
          local_28 = local_b8;
          uStack_24 = uStack_b4;
          uStack_20 = uStack_b0;
          uStack_1c = uStack_ac;
          uStack_c0 = (undefined4)*local_58;
          uStack_bc = (undefined4)((ulonglong)*local_58 >> 0x20);
          local_38 = local_b8;
          uStack_34 = uStack_b4;
          uStack_30 = uStack_c0;
          uStack_2c = uStack_bc;
          FUN_1402a5d20(local_88,local_a0,&local_38,&local_28);
          operator_delete(local_58);
          local_58 = (undefined8 *)0x0;
          local_50 = 0;
          operator_delete(local_88[0]);
          return;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar6 = 0;
        }
        else {
          lVar6 = *plVar1;
        }
        if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        if (puVar4[4] != 0) {
          FUN_1403a4210();
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar4 + 0x29) == '\0') break;
        _invalid_parameter_noinfo();
      }
      puVar5 = puVar4;
      puVar3 = (undefined8 *)puVar4[2];
      if (*(char *)((longlong)puVar4[2] + 0x29) != '\0') break;
      do {
        puVar4 = puVar3;
        puVar3 = (undefined8 *)*puVar4;
      } while (*(char *)((longlong)*puVar4 + 0x29) == '\0');
    }
    do {
      puVar4 = (undefined8 *)puVar5[1];
      if (*(char *)((longlong)puVar4 + 0x29) != '\0') break;
      bVar7 = puVar5 == (undefined8 *)puVar4[2];
      puVar5 = puVar4;
    } while (bVar7);
  } while( true );
}

// ==== CMapGroupKernel::helper_1402d8ee0  @1402d8ee0  [medium:callgraph-r2]  (orig: FUN_1402d8ee0)
void FUN_1402d8ee0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402d8ee0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402d8f30  @1402d8f30  [medium:callgraph-r2]  (orig: FUN_1402d8f30)
void FUN_1402d8f30(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402d8f30(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402d8f80  @1402d8f80  [medium:callgraph-r2]  (orig: FUN_1402d8f80)
void FUN_1402d8f80(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402d8f80(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402d8fd0  @1402d8fd0  [medium:callgraph-r2]  (orig: FUN_1402d8fd0)
void FUN_1402d8fd0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402d8fd0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402dc720  @1402dc720  [medium:callgraph-r2]  (orig: FUN_1402dc720)
void FUN_1402dc720(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 0x88);
  plVar6 = (longlong *)**(undefined8 **)(param_1 + 0xb8);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0xb8);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x88))) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6[4] == 0) {
      log_InlineLogERROR("CPromotionActivityMgr::UpdateAllPromotionInfo iterInfo->second is null.");
    }
    else {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar2;
      }
      if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      iVar5 = FUN_1404730a0(plVar6[4]);
      if (iVar5 != 3) {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar7 = 0;
        }
        else {
          lVar7 = *plVar2;
        }
        if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_140473180(plVar6[4]);
      }
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar4 = (longlong *)plVar6[1];
        plVar3 = plVar6;
        while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar4 = (longlong *)plVar6[1];
          plVar3 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1402de5f0  @1402de5f0  [medium:callgraph-r2]  (orig: FUN_1402de5f0)
int FUN_1402de5f0(longlong param_1,int param_2)

{
  ushort uVar1;
  int iVar2;
  longlong lVar3;
  longlong lVar4;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  FUN_1402dccb0((longlong *)(param_1 + 0x48),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x78);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x48))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 == lVar3) {
    log_InlineLogERROR(
                      "CPromotionActivityMgr::GetAddActorRandNum can not found goods info, goods:%u"
                      );
  }
  else {
    lVar3 = 0;
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = lVar3;
    }
    else {
      lVar4 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar4 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(longlong *)(local_10 + 0x20) == 0) {
      log_InlineLogERROR("CPromotionActivityMgr::GetAddActorRandNum iter->second is null, goods:%u")
      ;
    }
    else {
      if (local_18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar3 = *local_18;
      }
      if (local_10 == *(longlong *)(lVar3 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(ushort *)(*(longlong *)(local_10 + 0x20) + 0x14);
      if (uVar1 != 0) {
        iVar2 = tq::RandGet(uVar1 / 5);
        return iVar2 + 1;
      }
    }
  }
  return 0;
}

// ==== CMapGroupKernel::helper_1402dfbd0  @1402dfbd0  [medium:callgraph-r1]  (orig: FUN_1402dfbd0)
ulonglong FUN_1402dfbd0(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined2 uVar3;
  ulong uVar4;
  int iVar5;
  undefined4 uVar6;
  ulonglong uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  bool bVar11;
  
  uVar4 = tq::TimeGet(0);
  if ((uint)(*(int *)(param_1 + 0x118) + *(int *)(param_1 + 0x114)) <= uVar4 / 1000) {
    uVar4 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x118) = uVar4 / 1000;
    FUN_1402df5e0(param_1);
  }
  uVar4 = tq::TimeGet(0);
  uVar7 = (ulonglong)uVar4 * 0x10624dd3 & 0xffffffff;
  if ((uint)(*(int *)(param_1 + 0x110) + *(int *)(param_1 + 0x10c)) <= uVar4 / 1000) {
    uVar4 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x110) = uVar4 / 1000;
    plVar8 = (longlong *)**(undefined8 **)(param_1 + 0xb8);
    plVar1 = *(longlong **)(param_1 + 0x88);
LAB_1402dfcb0:
    plVar9 = *(longlong **)(param_1 + 0xb8);
    if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 0x88))) {
      _invalid_parameter_noinfo();
    }
    if (plVar8 != plVar9) {
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar1;
      }
      if (plVar8 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar10 = plVar8[4];
      if (lVar10 == 0) {
        log_InlineLogERROR("CPromotionActivityMgr::OnTimer pPromotionInfo is null.");
      }
      else {
        iVar5 = FUN_1404730a0(lVar10);
        if (iVar5 == 1) {
          uVar6 = FUN_1402d6fd0(lVar10);
          uVar3 = FUN_1402de5f0(param_1,uVar6);
          FUN_140473690(lVar10,uVar3);
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        plVar9 = plVar8;
        plVar2 = (longlong *)plVar8[2];
        if (*(char *)(plVar8[2] + 0x29) == '\0') {
          do {
            plVar8 = plVar2;
            plVar2 = (longlong *)*plVar8;
          } while (*(char *)(*plVar8 + 0x29) == '\0');
        }
        else {
          do {
            plVar8 = (longlong *)plVar9[1];
            if (*(char *)((longlong)plVar8 + 0x29) != '\0') break;
            bVar11 = plVar9 == (longlong *)plVar8[2];
            plVar9 = plVar8;
          } while (bVar11);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1402dfcb0;
    }
    uVar7 = FUN_1402dc720(param_1);
  }
  return uVar7;
}

// ==== CMapGroupKernel::helper_1402e0af0  @1402e0af0  [medium:callgraph-r1]  (orig: FUN_1402e0af0)
void FUN_1402e0af0(undefined8 *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  uVar9 = 0xfffffffffffffffe;
  plVar6 = *(longlong **)param_1[0x17];
  plVar2 = (longlong *)param_1[0x11];
  lVar8 = 0;
  while( true ) {
    plVar10 = (longlong *)param_1[0x17];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[0x11])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar10) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6[4] != 0) {
      FUN_140473630(plVar6[4]);
      plVar6[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar10 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar10 + 0x29);
        plVar6 = plVar10;
        plVar10 = (longlong *)*plVar10;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar10 + 0x29);
          plVar6 = plVar10;
          plVar10 = (longlong *)*plVar10;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar11 = (longlong *)plVar6[1];
        plVar10 = plVar6;
        while ((plVar6 = plVar11, cVar1 == '\0' && (plVar10 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar11 = (longlong *)plVar6[1];
          plVar10 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x17] + 8) + 0x29);
  plVar6 = *(longlong **)(param_1[0x17] + 8);
  while (cVar1 == '\0') {
    FUN_1402d8f80(param_1 + 0x11,plVar6[2]);
    plVar2 = (longlong *)*plVar6;
    operator_delete(plVar6);
    plVar6 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[0x17] + 8) = param_1[0x17];
  param_1[0x18] = 0;
  *(undefined8 *)param_1[0x17] = param_1[0x17];
  *(undefined8 *)(param_1[0x17] + 0x10) = param_1[0x17];
  plVar6 = *(longlong **)param_1[7];
  plVar2 = (longlong *)param_1[1];
  while( true ) {
    plVar10 = (longlong *)param_1[7];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[1])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar10) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6[4] != 0) {
      operator_delete((void *)plVar6[4]);
      plVar6[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar10 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar10 + 0x29);
        plVar6 = plVar10;
        plVar10 = (longlong *)*plVar10;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar10 + 0x29);
          plVar6 = plVar10;
          plVar10 = (longlong *)*plVar10;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar11 = (longlong *)plVar6[1];
        plVar10 = plVar6;
        while ((plVar6 = plVar11, cVar1 == '\0' && (plVar10 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar11 = (longlong *)plVar6[1];
          plVar10 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar6 = *(longlong **)(param_1[7] + 8);
  while (cVar1 == '\0') {
    FUN_1402d8ee0(param_1 + 1,plVar6[2]);
    plVar2 = (longlong *)*plVar6;
    operator_delete(plVar6);
    plVar6 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  plVar6 = *(longlong **)param_1[0xf];
  plVar2 = (longlong *)param_1[9];
  while( true ) {
    plVar10 = (longlong *)param_1[0xf];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[9])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar10) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6[4] != 0) {
      operator_delete((void *)plVar6[4]);
      plVar6[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar10 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar10 + 0x29);
        plVar6 = plVar10;
        plVar10 = (longlong *)*plVar10;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar10 + 0x29);
          plVar6 = plVar10;
          plVar10 = (longlong *)*plVar10;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar11 = (longlong *)plVar6[1];
        plVar10 = plVar6;
        while ((plVar6 = plVar11, cVar1 == '\0' && (plVar10 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar11 = (longlong *)plVar6[1];
          plVar10 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[0xf] + 8) + 0x29);
  plVar6 = *(longlong **)(param_1[0xf] + 8);
  while (cVar1 == '\0') {
    FUN_1402d8f30(param_1 + 9,plVar6[2]);
    plVar2 = (longlong *)*plVar6;
    operator_delete(plVar6);
    plVar6 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[0xf] + 8) = param_1[0xf];
  param_1[0x10] = 0;
  *(undefined8 *)param_1[0xf] = param_1[0xf];
  *(undefined8 *)(param_1[0xf] + 0x10) = param_1[0xf];
  plVar6 = *(longlong **)param_1[0x1f];
  plVar2 = (longlong *)param_1[0x19];
  plVar10 = plVar2;
  plVar11 = plVar6;
  while( true ) {
    plVar3 = (longlong *)param_1[0x1f];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[0x19])) {
      _invalid_parameter_noinfo();
    }
    if (plVar6 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar8;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar6[4] != 0) {
      puVar4 = (undefined8 *)plVar6[4];
      if (puVar4 != (undefined8 *)0x0) {
        puVar5 = (undefined8 *)puVar4[6];
        local_68 = (undefined4)*puVar4;
        uStack_64 = (undefined4)((ulonglong)*puVar4 >> 0x20);
        uStack_60 = SUB84(puVar5,0);
        uStack_5c = (undefined4)((ulonglong)puVar5 >> 0x20);
        local_48 = local_68;
        uStack_44 = uStack_64;
        uStack_40 = uStack_60;
        uStack_3c = uStack_5c;
        uStack_50 = (undefined4)*puVar5;
        uStack_4c = (undefined4)((ulonglong)*puVar5 >> 0x20);
        local_38 = local_68;
        uStack_34 = uStack_64;
        uStack_30 = uStack_50;
        uStack_2c = uStack_4c;
        FUN_14000bd50(puVar4,local_28,&local_38,&local_48,uVar9,plVar10,plVar11);
        operator_delete((void *)puVar4[6]);
        puVar4[6] = 0;
        puVar4[7] = 0;
        operator_delete((void *)*puVar4);
        operator_delete(puVar4);
      }
      plVar6[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar11 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar11 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar11 + 0x29);
        plVar6 = plVar11;
        plVar3 = (longlong *)*plVar11;
        while (plVar11 = plVar6, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar11 = (longlong *)plVar6[1];
        plVar3 = plVar6;
        while ((plVar6 = plVar11, plVar11 = plVar6, cVar1 == '\0' &&
               (plVar3 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar11 = (longlong *)plVar6[1];
          plVar3 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[0x1f] + 8) + 0x29);
  plVar6 = *(longlong **)(param_1[0x1f] + 8);
  while (cVar1 == '\0') {
    FUN_1402d8fd0(param_1 + 0x19,plVar6[2]);
    plVar2 = (longlong *)*plVar6;
    operator_delete(plVar6);
    plVar6 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[0x1f] + 8) = param_1[0x1f];
  param_1[0x20] = 0;
  *(undefined8 *)param_1[0x1f] = param_1[0x1f];
  *(undefined8 *)(param_1[0x1f] + 0x10) = param_1[0x1f];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_1402e4ec0  @1402e4ec0  [medium:callgraph-r2]  (orig: FUN_1402e4ec0)
void FUN_1402e4ec0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_1404795e0();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402e3f20(param_1 + 8,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  plVar4 = (longlong *)**(undefined8 **)(param_1 + 0x78);
  plVar2 = *(longlong **)(param_1 + 0x48);
  while( true ) {
    plVar7 = *(longlong **)(param_1 + 0x78);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar7) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      FUN_14047c830();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar7 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar7 + 0x29);
        plVar4 = plVar7;
        plVar7 = (longlong *)*plVar7;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar7 + 0x29);
          plVar4 = plVar7;
          plVar7 = (longlong *)*plVar7;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar7 = plVar4;
        while ((plVar4 = plVar8, cVar1 == '\0' && (plVar7 == (longlong *)plVar4[2]))) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar7 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar4 = *(longlong **)(*(longlong *)(param_1 + 0x78) + 8);
  cVar1 = *(char *)((longlong)plVar4 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402e3f70(param_1 + 0x48,plVar4[2]);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 8) = *(longlong *)(param_1 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x78);
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 0x10) = *(longlong *)(param_1 + 0x78);
  return;
}

// ==== CMapGroupKernel::helper_1402e5180  @1402e5180  [medium:callgraph-r1]  (orig: FUN_1402e5180)
void FUN_1402e5180(longlong param_1)

{
  longlong lVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  undefined8 uVar9;
  IStringManager *pIVar10;
  undefined1 local_38 [40];
  longlong local_10;
  
  iVar4 = tq::DateStamp(0);
  if (*(int *)(param_1 + 0x8c) != iVar4) {
    iVar4 = tq::DateStamp(0);
    *(int *)(param_1 + 0x8c) = iVar4;
    iVar4 = 0;
    uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    uVar9 = FUN_140087650(uVar9);
    FUN_1402ac340(uVar9,local_38);
    while (cVar3 = FUN_1400cf370(local_38), lVar2 = local_10, cVar3 != '\0') {
      iVar4 = iVar4 + 1;
      if (10000 < iVar4) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      if (local_10 != 0) {
        uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
        uVar5 = FUN_14008aea0(uVar9);
        uVar6 = FUN_140166bf0(lVar2);
        if (uVar6 < uVar5) {
          uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
          iVar7 = FUN_14008aeb0(uVar9);
          iVar8 = FUN_140166bf0(lVar2);
          if ((uint)(iVar8 + iVar7) < uVar5) {
            FUN_140166c00(lVar2,iVar8 + iVar7,0);
          }
          else {
            FUN_140166c00(lVar2,uVar5,0);
            pIVar10 = theInstance();
            lVar1 = *(longlong *)(lVar2 + 0x10);
            uVar9 = (*(code *)**(undefined8 **)pIVar10)
                              (pIVar10,"STR_TRAINING_VITALITY_STRENGTH_VALUE_FULL");
            (**(code **)(lVar1 + 0x358))((longlong *)(lVar2 + 0x10),uVar9);
          }
        }
        else {
          pIVar10 = theInstance();
          lVar1 = *(longlong *)(lVar2 + 0x10);
          uVar9 = (*(code *)**(undefined8 **)pIVar10)
                            (pIVar10,"STR_TRAINING_VITALITY_STRENGTH_VALUE_FULL");
          (**(code **)(lVar1 + 0x358))((longlong *)(lVar2 + 0x10),uVar9);
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1402e63f0  @1402e63f0  [medium:callgraph-r1]  (orig: FUN_1402e63f0)
undefined8
FUN_1402e63f0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  FUN_1402e4ec0();
  if ((param_1[0x13] != 0) && (param_1[0x13] != 0)) {
    FUN_140476730(param_1[0x13]);
    param_1[0x13] = 0;
  }
  if ((param_1[0x14] != 0) && (param_1[0x14] != 0)) {
    FUN_140473df0(param_1[0x14]);
    param_1[0x14] = 0;
  }
  if (param_1[0x15] != 0) {
    FUN_14047af70(param_1[0x15]);
    param_1[0x15] = 0;
  }
  (**(code **)*param_1)(param_1,1,param_3,param_4,uVar1);
  return 0;
}

// ==== CMapGroupKernel::helper_1402eb4b0  @1402eb4b0  [medium:callgraph-r1]  (orig: FUN_1402eb4b0)
void FUN_1402eb4b0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  bool bVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *local_78;
  longlong *plStack_70;
  longlong *local_68;
  longlong *local_58;
  longlong *plStack_50;
  undefined1 local_48 [16];
  undefined1 local_38 [32];
  
  plVar4 = (longlong *)**(longlong **)(param_1 + 0x40);
  plVar1 = *(longlong **)(param_1 + 0x10);
  plVar9 = plVar1;
  plVar11 = plVar4;
LAB_1402eb500:
  do {
    plVar6 = *(longlong **)(param_1 + 0x40);
    local_68 = *(longlong **)(param_1 + 0x10);
    if ((plVar1 == (longlong *)0x0) || (plVar10 = plVar9, plVar1 != local_68)) {
      _invalid_parameter_noinfo();
      plVar10 = plVar9;
    }
    if (plVar4 == plVar6) {
      return;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar1;
    }
    if (plVar4 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar4[4];
    if (lVar7 == 0) {
      plVar9 = plVar10;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar9 = plVar10;
      }
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        plVar6 = plVar4;
        plVar10 = (longlong *)plVar4[2];
        if (*(char *)(plVar4[2] + 0x29) == '\0') {
          do {
            plVar4 = plVar10;
            plVar10 = (longlong *)*plVar4;
            plVar11 = plVar4;
          } while (*(char *)(*plVar4 + 0x29) == '\0');
        }
        else {
          do {
            plVar4 = (longlong *)plVar6[1];
            plVar11 = plVar4;
            if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
            bVar8 = plVar6 == (longlong *)plVar4[2];
            plVar6 = plVar4;
          } while (bVar8);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      goto LAB_1402eb500;
    }
    cVar3 = FUN_14047e1c0(lVar7);
    if (cVar3 == '\0') {
      FUN_14047ef60(lVar7);
      uVar12 = 0;
      plVar9 = plVar10;
      plVar6 = plVar11;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
        plVar5 = plVar4;
        plVar2 = (longlong *)plVar4[2];
        if (*(char *)(plVar4[2] + 0x29) == '\0') {
          do {
            plVar4 = plVar2;
            plVar2 = (longlong *)*plVar4;
            plVar6 = plVar4;
          } while (*(char *)(*plVar4 + 0x29) == '\0');
        }
        else {
          do {
            plVar4 = (longlong *)plVar5[1];
            plVar6 = plVar4;
            if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
            bVar8 = plVar5 == (longlong *)plVar4[2];
            plVar5 = plVar4;
          } while (bVar8);
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
      local_58 = plVar10;
      plStack_50 = plVar11;
      FUN_1402eae00(param_1 + 0x10,local_48,&local_58,param_4,plVar9,plVar6,uVar12);
      plVar11 = plVar6;
    }
    else {
      cVar3 = FUN_14047e180(lVar7);
      if (cVar3 == '\0') {
        plVar9 = plVar10;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = plVar10;
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
          plVar6 = plVar4;
          plVar10 = (longlong *)plVar4[2];
          if (*(char *)(plVar4[2] + 0x29) == '\0') {
            do {
              plVar4 = plVar10;
              plVar10 = (longlong *)*plVar4;
              plVar11 = plVar4;
            } while (*(char *)(*plVar4 + 0x29) == '\0');
          }
          else {
            do {
              plVar4 = (longlong *)plVar6[1];
              plVar11 = plVar4;
              if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
              bVar8 = plVar6 == (longlong *)plVar4[2];
              plVar6 = plVar4;
            } while (bVar8);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      else {
        thunk_FUN_14047f5b0(lVar7);
        plVar9 = plVar10;
        plVar6 = plVar11;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
          plVar5 = plVar4;
          plVar2 = (longlong *)plVar4[2];
          if (*(char *)(plVar4[2] + 0x29) == '\0') {
            do {
              plVar4 = plVar2;
              plVar2 = (longlong *)*plVar4;
              plVar6 = plVar4;
            } while (*(char *)(*plVar4 + 0x29) == '\0');
          }
          else {
            do {
              plVar4 = (longlong *)plVar5[1];
              plVar6 = plVar4;
              if (*(char *)((longlong)plVar4 + 0x29) != '\0') break;
              bVar8 = plVar5 == (longlong *)plVar4[2];
              plVar5 = plVar4;
            } while (bVar8);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_78 = plVar10;
        plStack_70 = plVar11;
        FUN_1402eae00(param_1 + 0x10,local_38,&local_78,param_4,plVar9,plVar6);
        plVar11 = plVar6;
        if (lVar7 != 0) {
          FUN_14047ef60(lVar7);
          plVar11 = plVar6;
        }
      }
    }
  } while( true );
}

// ==== CMapGroupKernel::helper_1402ef7c0  @1402ef7c0  [medium:callgraph-r1]  (orig: FUN_1402ef7c0)
void FUN_1402ef7c0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar2 = *(longlong **)(param_1 + 0x88);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0xb8);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0xb8);
          if ((*(longlong **)(param_1 + 0x88) == (longlong *)0x0) ||
             (*(longlong **)(param_1 + 0x88) != plVar2)) {
            _invalid_parameter_noinfo();
          }
          if (plVar3 == plVar5) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar5[4] != 0) {
            FUN_1404be340(plVar5[4],param_2);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_1402f20d0  @1402f20d0  [medium:callgraph-r0]  (orig: FUN_1402f20d0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1402f20d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong **pplVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong lVar11;
  longlong *local_48;
  undefined8 *puStack_40;
  longlong *local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong *local_20;
  
  puVar9 = (undefined8 *)**(undefined8 **)(param_1 + 0x38);
  plVar2 = *(longlong **)(param_1 + 8);
  local_48 = plVar2;
  puStack_40 = puVar9;
  while( true ) {
    puVar10 = *(undefined8 **)(param_1 + 0x38);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (puVar9 == puVar10) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = 0;
    }
    else {
      lVar11 = *plVar2;
    }
    if (puVar9 == *(undefined8 **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar10 = *(undefined8 **)(param_1 + 0x78);
    if (*(char *)((longlong)puVar10[1] + 0x29) == '\0') {
      puVar6 = (undefined8 *)puVar10[1];
      do {
        if (*(uint *)(puVar6 + 3) < *(uint *)(puVar9 + 3)) {
          puVar7 = (undefined8 *)puVar6[2];
        }
        else {
          puVar7 = (undefined8 *)*puVar6;
          puVar10 = puVar6;
        }
        puVar6 = puVar7;
      } while (*(char *)((longlong)puVar7 + 0x29) == '\0');
    }
    puVar6 = *(undefined8 **)(param_1 + 0x78);
    puStack_40 = puVar10;
    local_48 = *(longlong **)(param_1 + 0x48);
    if (*(longlong **)(param_1 + 0x48) == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar10 == puVar6) || (*(uint *)(puVar9 + 3) < *(uint *)(puVar10 + 3))) {
      pplVar8 = &local_38;
      local_30 = *(undefined8 *)(param_1 + 0x78);
      local_38 = *(longlong **)(param_1 + 0x48);
    }
    else {
      pplVar8 = &local_48;
    }
    plVar3 = *pplVar8;
    plVar4 = *(longlong **)(param_1 + 0x78);
    local_28 = plVar3;
    local_20 = pplVar8[1];
    if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x48))) {
      _invalid_parameter_noinfo();
    }
    plVar5 = local_20;
    if (local_20 != plVar4) {
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (plVar3 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *plVar3;
      }
      if (plVar5 == *(longlong **)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      tq::OverTimeLogSave("syslog/overtime","MagicType=%u, cnt=%u, tot=%ums, avg=%.2fms, max=%ums",
                          (int)plVar5[3],(int)plVar5[4]);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar9 + 0x1d) == '\0') {
      puVar10 = (undefined8 *)puVar9[2];
      if (*(char *)((longlong)puVar10 + 0x1d) == '\0') {
        cVar1 = *(char *)((longlong)*puVar10 + 0x1d);
        puVar9 = puVar10;
        puVar10 = (undefined8 *)*puVar10;
        while (cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar10 + 0x1d);
          puVar9 = puVar10;
          puVar10 = (undefined8 *)*puVar10;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar9[1] + 0x1d);
        puVar6 = (undefined8 *)puVar9[1];
        puVar10 = puVar9;
        while ((puVar9 = puVar6, cVar1 == '\0' && (puVar10 == (undefined8 *)puVar9[2]))) {
          cVar1 = *(char *)((longlong)puVar9[1] + 0x1d);
          puVar6 = (undefined8 *)puVar9[1];
          puVar10 = puVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x38) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x1d);
  while (cVar1 == '\0') {
    FUN_1400098c0(param_1 + 8,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x1d);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 8) = *(longlong *)(param_1 + 0x38);
  *(undefined8 *)(param_1 + 0x40) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_1 + 0x38);
  *(longlong *)(*(longlong *)(param_1 + 0x38) + 0x10) = *(longlong *)(param_1 + 0x38);
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x78) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1400e4cc0(param_1 + 0x48,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 8) = *(longlong *)(param_1 + 0x78);
  *(undefined8 *)(param_1 + 0x80) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x78) = *(undefined8 *)(param_1 + 0x78);
  *(longlong *)(*(longlong *)(param_1 + 0x78) + 0x10) = *(longlong *)(param_1 + 0x78);
  return;
}

// ==== CMapGroupKernel::helper_14030cb00  @14030cb00  [medium:callgraph-r3]  (orig: FUN_14030cb00)
void FUN_14030cb00(void *param_1)

{
  if ((DAT_140976000 & 1) == 0) {
    DAT_140976000 = DAT_140976000 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975ff8,"CMineCtrl");
    atexit((_func_5014 *)&LAB_1406d6a50);
  }
                    /* WARNING: Could not recover jumptable at 0x00014030cb55. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975ff8,param_1);
  return;
}

// ==== CMapGroupKernel::helper_14030f3d0  @14030f3d0  [medium:callgraph-r3]  (orig: FUN_14030f3d0)
void FUN_14030f3d0(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_14030ed60((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_140311920  @140311920  [medium:callgraph-r3]  (orig: FUN_140311920)
void FUN_140311920(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_140311740((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CMapGroupKernel::helper_140311c50  @140311c50  [medium:callgraph-r2]  (orig: FUN_140311c50)
void FUN_140311c50(longlong *param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)*param_1;
  if (puVar1 != (undefined8 *)0x0) {
    FUN_14030f3d0(puVar1 + 8);
    operator_delete((void *)puVar1[8]);
    FUN_140311920(puVar1);
    operator_delete((void *)*puVar1);
    FUN_14030cb00(puVar1);
    *param_1 = 0;
  }
  return;
}

// ==== CMapGroupKernel::helper_140311cd0  @140311cd0  [medium:callgraph-r1]  (orig: FUN_140311cd0)
void FUN_140311cd0(void)

{
  FUN_140311c50(&DAT_140975ff0);
  return;
}

// ==== CMapGroupKernel::helper_140315170  @140315170  [medium:callgraph-r1]  (orig: FUN_140315170)
void FUN_140315170(void)

{
  longlong *plVar1;
  
  plVar1 = DAT_140976008;
  if (DAT_140976008 != (longlong *)0x0) {
    if ((longlong *)*DAT_140976008 != (longlong *)0x0) {
      (**(code **)(*(longlong *)*DAT_140976008 + 8))();
    }
    operator_delete(plVar1);
    DAT_140976008 = (longlong *)0x0;
  }
  return;
}

// ==== CMapGroupKernel::helper_14031d330  @14031d330  [medium:callgraph-r1]  (orig: FUN_14031d330)
void FUN_14031d330(void)

{
  if (DAT_140976010 != 0) {
    FUN_1404c02b0();
    DAT_140976010 = 0;
  }
  return;
}

// ==== CMapGroupKernel::helper_14032ab60  @14032ab60  [medium:callgraph-r1]  (orig: FUN_14032ab60)
void FUN_14032ab60(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
  (**(code **)(*plVar1 + 0xb0))(plVar1,param_2);
                    /* WARNING: Could not recover jumptable at 0x00014032abdc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 8) + 0x38))(*(longlong **)(param_1 + 8),0);
  return;
}

// ==== CMapGroupKernel::helper_14032ac40  @14032ac40  [medium:callgraph-r1]  (orig: FUN_14032ac40)
undefined8 FUN_14032ac40(longlong param_1)

{
  ulong uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  longlong *plVar5;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
    iVar2 = (**(code **)(*plVar5 + 0x50))(plVar5);
    if (iVar2 != 0) {
      return 0;
    }
  }
  uVar1 = tq::TimeGet(2);
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
    uVar3 = (**(code **)(*plVar5 + 0x50))(plVar5);
  }
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
    uVar4 = (**(code **)(*plVar5 + 0x50))(plVar5);
    if ((((uVar4 != 0) && (uVar3 != 0)) && (uVar3 <= uVar1)) && (uVar1 < uVar4)) {
      return 1;
    }
  }
  return 0;
}

// ==== CMapGroupKernel::helper_14032ad90  @14032ad90  [medium:callgraph-r1]  (orig: FUN_14032ad90)
undefined8 FUN_14032ad90(longlong param_1)

{
  int iVar1;
  ulong uVar2;
  uint uVar3;
  longlong *plVar4;
  
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
  iVar1 = (**(code **)(*plVar4 + 0x50))(plVar4);
  if (iVar1 != 1) {
    return 0;
  }
  uVar2 = tq::TimeGet(2);
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 1;
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
  uVar3 = (**(code **)(*plVar4 + 0x50))(plVar4);
  if (uVar3 <= uVar2) {
    return 1;
  }
  return 0;
}

// ==== CMapGroupKernel::helper_140377230  @140377230  [medium:callgraph-r2]  (orig: FUN_140377230)
ulonglong FUN_140377230(longlong param_1)

{
  longlong *plVar1;
  ulong uVar2;
  ulonglong uVar3;
  
  uVar2 = tq::TimeGet(0);
  uVar3 = (ulonglong)uVar2 * 0x10624dd3 & 0xffffffff;
  if ((uint)(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x1c)) <= uVar2 / 1000) {
    uVar2 = tq::TimeGet(0);
    uVar3 = (ulonglong)uVar2 * 0x10624dd3 & 0xffffffff;
    *(uint *)(param_1 + 0x20) = uVar2 / 1000;
    if ((*(char *)(param_1 + 0x18) != '\0') &&
       (plVar1 = *(longlong **)(param_1 + 8), plVar1 != (longlong *)0x0)) {
      *(undefined1 *)(param_1 + 0x18) = 0;
      uVar3 = (**(code **)(*plVar1 + 0x38))(plVar1,0);
    }
  }
  return uVar3;
}

// ==== CMapGroupKernel::helper_14037ee50  @14037ee50  [medium:callgraph-r3]  (orig: FUN_14037ee50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14037ee50(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined2 local_490;
  undefined4 local_488;
  undefined4 local_480;
  longlong local_478 [2];
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478[1] = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (*(char *)(param_1 + 0x94) != '\0') {
    *(undefined1 *)(param_1 + 0x94) = 0;
    FUN_140362560(local_468);
    local_480 = 0;
    local_488 = 0;
    local_490 = 0x192;
    local_498 = (uint)local_498._2_2_ << 0x10;
    iVar2 = FUN_140362620(local_468,1,0);
    if (iVar2 == 0) {
      local_498 = 0x148;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
      plVar5 = (longlong *)FUN_1400876b0(uVar4);
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,*(undefined4 *)(param_1 + 0xa8),1);
      if (plVar5 != (longlong *)0x0) {
        (**(code **)(*plVar5 + 0x38))(plVar5,local_468,0);
      }
    }
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
    if (*(longlong *)(lVar3 + 0x98) == 0) {
      local_498 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                      (*(longlong **)(lVar3 + 0x98),*(undefined4 *)(param_1 + 0xa8),1);
    if (lVar3 == 0) {
      local_498 = 0x153;
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_1403625e0(local_468);
    }
    else if (*(int *)(param_1 + 0x90) == 0) {
      FUN_1403625e0(local_468);
    }
    else {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
      plVar5 = (longlong *)FUN_1400875f0(uVar4);
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,*(undefined4 *)(param_1 + 0x90));
      *(undefined4 *)(param_1 + 0x90) = 0;
      if (plVar5 == (longlong *)0x0) {
        FUN_1403625e0(local_468);
      }
      else {
        local_478[0] = 0;
        (**(code **)(*plVar5 + 0x298))(plVar5,0x1040,local_478);
        if (local_478[0] == 0) {
          FUN_1403625e0(local_468);
        }
        else {
          iVar2 = (**(code **)(*(longlong *)(local_478[0] + 0x10) + 0x168))();
          if ((iVar2 == 5000) &&
             (iVar2 = (**(code **)(**(longlong **)(local_478[0] + 0x60) + 0x10))
                                (*(longlong **)(local_478[0] + 0x60),4), iVar2 == 0x27)) {
            cVar1 = FUN_1402bf7a0(local_478[0],*(undefined4 *)(param_1 + 0xa8),
                                  *(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0));
            if (cVar1 == '\0') {
              FUN_1403625e0(local_468);
              return 0;
            }
            FUN_1402bc690(local_478[0],lVar3);
            FUN_1403625e0(local_468);
            return 1;
          }
          FUN_1403625e0(local_468);
        }
      }
    }
  }
  return 0;
}

// ==== CMapGroupKernel::helper_14037f210  @14037f210  [medium:callgraph-r3]  (orig: FUN_14037f210)
undefined8 FUN_14037f210(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  ulong uVar5;
  int iVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  
  *(undefined4 *)(param_1 + 0x10) = *(undefined4 *)(param_1 + 0x48);
  uVar5 = tq::TimeGet(0);
  *(uint *)(param_1 + 0x14) = uVar5 / 1000;
  uVar5 = tq::TimeGet(0);
  *(ulong *)(param_1 + 0xac) = uVar5;
  *(undefined1 *)(param_1 + 0x94) = 1;
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0xa4));
  if (*(longlong *)(lVar8 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar9 = (longlong *)(**(code **)(**(longlong **)(lVar8 + 0x88) + 0xd0))();
  plVar1 = (longlong *)*plVar9;
  plVar10 = *(longlong **)plVar9[6];
  while( true ) {
    plVar2 = (longlong *)plVar9[6];
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*plVar9)) {
      _invalid_parameter_noinfo();
    }
    if (plVar10 == plVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar1;
    }
    if (plVar10 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = (longlong *)plVar10[4];
    if (((plVar2 != (longlong *)0x0) &&
        (iVar6 = (**(code **)(plVar2[2] + 0x168))(plVar2 + 2), iVar6 == *(int *)(param_1 + 0xa8)))
       && (iVar6 = (**(code **)(*(longlong *)plVar2[0xc] + 0x10))((longlong *)plVar2[0xc],4),
          iVar6 == 0x27)) {
      FUN_1402bc670(plVar2);
      uVar7 = (**(code **)(plVar2[2] + 0x40))(plVar2 + 2);
      *(undefined4 *)(param_1 + 0x9c) = uVar7;
      uVar7 = (**(code **)(plVar2[2] + 0x48))(plVar2 + 2);
      *(undefined4 *)(param_1 + 0xa0) = uVar7;
      uVar7 = (**(code **)(*plVar2 + 8))(plVar2);
      *(undefined4 *)(param_1 + 0x90) = uVar7;
      cVar4 = FUN_1402bf7a0(plVar2,5000,100);
      if (cVar4 != '\0') {
        return 1;
      }
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar10 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar10[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar4 = *(char *)(*plVar2 + 0x29);
        plVar10 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar4 == '\0') {
          cVar4 = *(char *)(*plVar2 + 0x29);
          plVar10 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar4 = *(char *)(plVar10[1] + 0x29);
        plVar3 = (longlong *)plVar10[1];
        plVar2 = plVar10;
        while ((plVar10 = plVar3, cVar4 == '\0' && (plVar2 == (longlong *)plVar10[2]))) {
          cVar4 = *(char *)(plVar10[1] + 0x29);
          plVar3 = (longlong *)plVar10[1];
          plVar2 = plVar10;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return 0;
}

// ==== CMapGroupKernel::helper_14037f520  @14037f520  [medium:callgraph-r2]  (orig: FUN_14037f520)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14037f520(int *param_1)

{
  ulong uVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined1 auStack_4b8 [32];
  uint local_498;
  undefined2 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_1[1] != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*param_1 + param_1[1]) <= uVar1 / 1000) {
      param_1[1] = 0;
      *param_1 = 0;
      FUN_140362560(local_468);
      local_480 = 0;
      local_488 = 0;
      local_490 = 0x191;
      local_498 = local_498 & 0xffff0000;
      iVar2 = FUN_140362620(local_468,1,0,0);
      if (iVar2 == 0) {
        local_498 = 0x19f;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar3 = FUN_140008520(param_1[0x29]);
        plVar4 = (longlong *)FUN_1400876b0(uVar3);
        plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,param_1[0x2a],1);
        if (plVar4 != (longlong *)0x0) {
          (**(code **)(*plVar4 + 0x38))(plVar4,local_468,0);
        }
      }
      param_1[1] = 0;
      *param_1 = 0;
      param_1[2] = 5;
      uVar1 = tq::TimeGet(0);
      param_1[3] = uVar1 / 1000;
      FUN_1403625e0(local_468);
    }
  }
  if (param_1[3] != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(param_1[3] + param_1[2]) <= uVar1 / 1000) {
      param_1[3] = 0;
      param_1[2] = 0;
      FUN_14037f210(param_1);
      param_1[3] = 0;
      param_1[2] = 0;
    }
  }
  if (param_1[5] != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(param_1[4] + param_1[5]) <= uVar1 / 1000) {
      param_1[5] = 0;
      param_1[4] = 0;
      FUN_14037ee50(param_1);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403808b0  @1403808b0  [medium:callgraph-r2]  (orig: FUN_1403808b0)
ulonglong FUN_1403808b0(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x90) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x90) + *(int *)(param_1 + 0x8c);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      return CONCAT71((uint7)(uint3)(uVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapGroupKernel::helper_1403a0200  @1403a0200  [medium:callgraph-r3]  (orig: FUN_1403a0200)
bool FUN_1403a0200(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(1);
  return (uint)(*(int *)(param_1 + 0x24) * 0x3c + *(int *)(param_1 + 0x1c)) < uVar1;
}

// ==== CMapGroupKernel::helper_1403a0f60  @1403a0f60  [medium:callgraph-r3]  (orig: FUN_1403a0f60)
void FUN_1403a0f60(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if ((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) & 0xffffffffffffffc0U) == 0) {
    lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    lVar1 = *(longlong *)(lVar1 + 0x230);
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar1 = 0;
    }
    FUN_1402a6490(lVar1,*(undefined4 *)(param_1 + 4),1);
    return;
  }
  if (((*(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8) >> 4 ^
       *(longlong *)(param_1 + 0xf0) - *(longlong *)(param_1 + 0xe8)) & 0xfffffffffffffffcU) != 0) {
    FUN_1403a0de0(param_1);
    return;
  }
  if (*(int *)(param_1 + 8) == 0) {
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    uVar2 = FUN_140087790(uVar2);
    FUN_1402a6490(uVar2,*(undefined4 *)(param_1 + 4),0);
  }
  return;
}

// ==== CMapGroupKernel::helper_1403a32c0  @1403a32c0  [medium:callgraph-r3]  (orig: FUN_1403a32c0)
undefined8 FUN_1403a32c0(longlong param_1)

{
  longlong lVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined4 *puVar7;
  undefined8 *puVar8;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined4 local_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uVar6 = *(ulonglong *)(param_1 + 0xb8);
  if (*(ulonglong *)(param_1 + 0xc0) < uVar6) {
    _invalid_parameter_noinfo();
  }
  local_28._0_4_ = (undefined4)*(undefined8 *)(param_1 + 0xa0);
  local_28._4_4_ = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0xa0) >> 0x20);
  uStack_20._0_4_ = (undefined4)uVar6;
  uStack_20._4_4_ = (undefined4)(uVar6 >> 0x20);
  do {
    while( true ) {
      uVar6 = *(ulonglong *)(param_1 + 0xc0);
      if (uVar6 < *(ulonglong *)(param_1 + 0xb8)) {
        _invalid_parameter_noinfo();
      }
      if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0xa0))) {
        _invalid_parameter_noinfo();
      }
      if (uStack_20 == uVar6) {
        uVar6 = *(longlong *)(param_1 + 0xc0) - *(longlong *)(param_1 + 0xb8);
        return CONCAT71((int7)(uVar6 >> 8),(uVar6 & 0xffffffffffffffc0) == 0);
      }
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *local_28;
      }
      if (*(ulonglong *)(lVar5 + 0x20) <= uStack_20) {
        _invalid_parameter_noinfo();
      }
      cVar3 = FUN_1404daa40(uStack_20);
      if (cVar3 != '\0') break;
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar5 = 0;
      }
      else {
        lVar5 = *local_28;
      }
      if (*(ulonglong *)(lVar5 + 0x20) <= uStack_20) {
        _invalid_parameter_noinfo();
      }
      uStack_20 = uStack_20 + 0x40;
    }
    uVar4 = FUN_1404d9f10(uStack_20);
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))(*(longlong **)(lVar5 + 0x90),uVar4);
    if (lVar5 != 0) {
      FUN_1403a2130(param_1,uVar4,2);
    }
    FUN_1404da3a0(uStack_20);
    lVar1 = *(longlong *)(param_1 + 0xc0);
    lVar5 = uStack_20 + 0x40;
    if (lVar5 != lVar1) {
      puVar7 = (undefined4 *)(uStack_20 + 0xc);
      do {
        lVar5 = lVar5 + 0x40;
        *(undefined1 *)(puVar7 + -1) = *(undefined1 *)(puVar7 + 0xf);
        *puVar7 = puVar7[0x10];
        puVar7[1] = puVar7[0x11];
        puVar7[2] = puVar7[0x12];
        puVar7[3] = puVar7[0x13];
        puVar7[4] = puVar7[0x14];
        puVar7[5] = puVar7[0x15];
        *(undefined8 *)(puVar7 + 6) = *(undefined8 *)(puVar7 + 0x16);
        *(undefined1 *)(puVar7 + 8) = *(undefined1 *)(puVar7 + 0x18);
        puVar7[9] = puVar7[0x19];
        *(undefined1 *)(puVar7 + 10) = *(undefined1 *)(puVar7 + 0x1a);
        *(undefined8 *)(puVar7 + 0xb) = *(undefined8 *)(puVar7 + 0x1b);
        puVar7 = puVar7 + 0x10;
      } while (lVar5 != lVar1);
    }
    puVar2 = *(undefined8 **)(param_1 + 0xc0);
    for (puVar8 = puVar2 + -8; puVar8 != puVar2; puVar8 = puVar8 + 8) {
      (**(code **)*puVar8)(puVar8,0);
    }
    *(longlong *)(param_1 + 0xc0) = *(longlong *)(param_1 + 0xc0) + -0x40;
    if ((uStack_20 < *(ulonglong *)(param_1 + 0xb8)) || (*(ulonglong *)(param_1 + 0xc0) < uStack_20)
       ) {
      _invalid_parameter_noinfo();
    }
    local_18 = (undefined4)*(undefined8 *)(param_1 + 0xa0);
    uStack_14 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0xa0) >> 0x20);
    uStack_10 = (undefined4)uStack_20;
    uStack_c = (undefined4)(uStack_20 >> 0x20);
    local_28._0_4_ = local_18;
    local_28._4_4_ = uStack_14;
    uStack_20._0_4_ = uStack_10;
    uStack_20._4_4_ = uStack_c;
  } while( true );
}

// ==== CMapGroupKernel::helper_1403a3960  @1403a3960  [medium:callgraph-r3]  (orig: FUN_1403a3960)
void FUN_1403a3960(longlong param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  undefined8 *puVar3;
  char cVar4;
  undefined4 uVar5;
  undefined4 *puVar6;
  longlong lVar7;
  undefined8 *puVar8;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined4 local_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  *(undefined4 *)(param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0x98) = 0;
  uVar1 = *(ulonglong *)(param_1 + 0xb8);
  if (*(ulonglong *)(param_1 + 0xc0) < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28._0_4_ = (undefined4)*(undefined8 *)(param_1 + 0xa0);
  local_28._4_4_ = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0xa0) >> 0x20);
  uStack_20._0_4_ = (undefined4)uVar1;
  uStack_20._4_4_ = (undefined4)(uVar1 >> 0x20);
  do {
    while( true ) {
      uVar1 = *(ulonglong *)(param_1 + 0xc0);
      if (uVar1 < *(ulonglong *)(param_1 + 0xb8)) {
        _invalid_parameter_noinfo();
      }
      if ((local_28 == (longlong *)0x0) || (local_28 != *(longlong **)(param_1 + 0xa0))) {
        _invalid_parameter_noinfo();
      }
      if (uStack_20 == uVar1) {
        return;
      }
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *local_28;
      }
      if (*(ulonglong *)(lVar7 + 0x20) <= uStack_20) {
        _invalid_parameter_noinfo();
      }
      cVar4 = FUN_1404d9f30(uStack_20);
      if (cVar4 == '\0') break;
      if (local_28 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *local_28;
      }
      if (*(ulonglong *)(lVar7 + 0x20) <= uStack_20) {
        _invalid_parameter_noinfo();
      }
      uStack_20 = uStack_20 + 0x40;
    }
    uVar5 = FUN_1404d9f10(uStack_20);
    FUN_1403a2130(param_1,uVar5,8);
    FUN_1404da3a0(uStack_20);
    lVar2 = *(longlong *)(param_1 + 0xc0);
    lVar7 = uStack_20 + 0x40;
    if (lVar7 != lVar2) {
      puVar6 = (undefined4 *)(uStack_20 + 0xc);
      do {
        lVar7 = lVar7 + 0x40;
        *(undefined1 *)(puVar6 + -1) = *(undefined1 *)(puVar6 + 0xf);
        *puVar6 = puVar6[0x10];
        puVar6[1] = puVar6[0x11];
        puVar6[2] = puVar6[0x12];
        puVar6[3] = puVar6[0x13];
        puVar6[4] = puVar6[0x14];
        puVar6[5] = puVar6[0x15];
        *(undefined8 *)(puVar6 + 6) = *(undefined8 *)(puVar6 + 0x16);
        *(undefined1 *)(puVar6 + 8) = *(undefined1 *)(puVar6 + 0x18);
        puVar6[9] = puVar6[0x19];
        *(undefined1 *)(puVar6 + 10) = *(undefined1 *)(puVar6 + 0x1a);
        *(undefined8 *)(puVar6 + 0xb) = *(undefined8 *)(puVar6 + 0x1b);
        puVar6 = puVar6 + 0x10;
      } while (lVar7 != lVar2);
    }
    puVar3 = *(undefined8 **)(param_1 + 0xc0);
    for (puVar8 = puVar3 + -8; puVar8 != puVar3; puVar8 = puVar8 + 8) {
      (**(code **)*puVar8)(puVar8,0);
    }
    *(longlong *)(param_1 + 0xc0) = *(longlong *)(param_1 + 0xc0) + -0x40;
    if ((uStack_20 < *(ulonglong *)(param_1 + 0xb8)) || (*(ulonglong *)(param_1 + 0xc0) < uStack_20)
       ) {
      _invalid_parameter_noinfo();
    }
    local_18 = (undefined4)*(undefined8 *)(param_1 + 0xa0);
    uStack_14 = (undefined4)((ulonglong)*(undefined8 *)(param_1 + 0xa0) >> 0x20);
    uStack_10 = (undefined4)uStack_20;
    uStack_c = (undefined4)(uStack_20 >> 0x20);
    local_28._0_4_ = local_18;
    local_28._4_4_ = uStack_14;
    uStack_20._0_4_ = uStack_10;
    uStack_20._4_4_ = uStack_c;
  } while( true );
}

// ==== CMapGroupKernel::helper_1403a4210  @1403a4210  [medium:callgraph-r2]  (orig: FUN_1403a4210)
void FUN_1403a4210(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong local_res8 [4];
  
  if (*(int *)(param_1 + 0x94) != 0) {
    uVar2 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x94) + *(int *)(param_1 + 0x90)) <= uVar2 / 1000) {
      *(undefined4 *)(param_1 + 0x94) = 0;
      *(undefined4 *)(param_1 + 0x90) = 0;
      FUN_1403a0f60(param_1);
      return;
    }
  }
  if (*(int *)(param_1 + 0x9c) != 0) {
    uVar2 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x9c) + *(int *)(param_1 + 0x98)) <= uVar2 / 1000) {
      FUN_1403a3960(param_1);
      return;
    }
  }
  if (*(int *)(param_1 + 8) != 0) {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x100));
    plVar4 = (longlong *)FUN_1400875f0(uVar3);
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,*(undefined4 *)(param_1 + 8));
    if (plVar4 != (longlong *)0x0) {
      local_res8[0] = 0;
      (**(code **)(*plVar4 + 0x298))(plVar4,0x1002,local_res8);
      if (local_res8[0] == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      cVar1 = (**(code **)(*(longlong *)(local_res8[0] + 0x10) + 0x220))(local_res8[0] + 0x10);
      if (cVar1 == '\0') {
        FUN_140388710(local_res8[0],*(undefined4 *)(param_1 + 4),4);
        return;
      }
      cVar1 = FUN_1403a0200(param_1);
      if (cVar1 != '\0') {
        FUN_140388710(local_res8[0],*(undefined4 *)(param_1 + 4),0xb);
        return;
      }
      cVar1 = FUN_1403a32c0(param_1);
      if (cVar1 != '\0') {
        FUN_140388710(local_res8[0],*(undefined4 *)(param_1 + 4),2);
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403a6c70  @1403a6c70  [medium:callgraph-r3]  (orig: FUN_1403a6c70)
longlong FUN_1403a6c70(void)

{
  longlong lVar1;
  
  lVar1 = DAT_140975b98;
  if (DAT_140975b98 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  return lVar1;
}

// ==== CMapGroupKernel::helper_1403aabd0  @1403aabd0  [medium:callgraph-r3]  (orig: FUN_1403aabd0)
undefined8 FUN_1403aabd0(longlong param_1)

{
  undefined4 uVar1;
  int iVar2;
  ulong uVar3;
  char *pcVar4;
  void *pvVar5;
  longlong lVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),9);
  *(undefined4 *)(param_1 + 0x78) = uVar1;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),8);
  *(undefined4 *)(param_1 + 0x7c) = uVar1;
  uVar1 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),0xe);
  *(undefined4 *)(param_1 + 0x40) = uVar1;
  *(undefined4 *)(param_1 + 0x44) = uVar1;
  pcVar4 = (char *)(**(code **)(**(longlong **)(param_1 + 0xb0) + 0x18))
                             (*(longlong **)(param_1 + 0xb0),0xf);
  tq::SafeCopy((char *)(param_1 + 0x59),pcVar4,0xf);
  iVar2 = (**(code **)(**(longlong **)(param_1 + 0xb0) + 0x10))(*(longlong **)(param_1 + 0xb0),1);
  if (iVar2 == 0xd) {
    *(undefined4 *)(param_1 + 0x6c) = *(undefined4 *)(param_1 + 0x7c);
    uVar3 = tq::TimeGet(0);
    *(ulong *)(param_1 + 0x70) = uVar3;
  }
  pvVar5 = operator_new(0x40);
  lVar7 = 0;
  lVar6 = lVar7;
  if (pvVar5 != (void *)0x0) {
    lVar6 = FUN_1402c12a0(pvVar5,1);
  }
  *(longlong *)(param_1 + 0xa0) = lVar6;
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else {
    lVar6 = FUN_1403e9370(0x20);
    if (lVar6 != 0) {
      lVar7 = FUN_1403e8ca0(lVar6,*(undefined4 *)(param_1 + 0x20),param_1 + 0x10);
    }
    *(longlong *)(param_1 + 0xb8) = lVar7;
    if (lVar7 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar8 = 0;
    }
    else {
      uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x20));
      plVar9 = (longlong *)FUN_1400876b0(uVar8);
      lVar6 = (**(code **)(*plVar9 + 0x10))(plVar9,*(undefined4 *)(param_1 + 0x30),1);
      *(longlong *)(param_1 + 0xa8) = lVar6;
      if (lVar6 == 0) {
        log_InlineLogERROR("CMapTrap::Init cannot find map%u(%u, %u) for trap type %u");
        uVar8 = 0;
      }
      else {
        uVar8 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x2a0))();
        FUN_1402c90f0(*(undefined8 *)(param_1 + 0xa8),uVar8,0);
        uVar8 = 1;
      }
    }
  }
  return uVar8;
}

// ==== CMapGroupKernel::helper_1403ab350  @1403ab350  [medium:callgraph-r2]  (orig: FUN_1403ab350)
longlong FUN_1403ab350(undefined4 param_1,longlong *param_2)

{
  char cVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  void *pvVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong *plVar11;
  
  if ((DAT_1409761f0 & 1) == 0) {
    DAT_1409761f0 = DAT_1409761f0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761e8,"CMapTrap");
    atexit((_func_5014 *)&LAB_1406d6bc0);
  }
  pvVar6 = CMyHeap::Alloc((CMyHeap *)&DAT_1409761e8,200);
  if (pvVar6 == (void *)0x0) {
    lVar7 = 0;
  }
  else {
    lVar7 = FUN_1403a91f0(pvVar6);
  }
  if (lVar7 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pTrap",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\maptrap.cpp",
                       0xda);
    lVar7 = 0;
  }
  else if ((param_2 == (longlong *)0x0) ||
          (lVar8 = (**(code **)(*param_2 + 0x40))(param_2), lVar8 == 0)) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pRes && pRes->CountRecord() > 0",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\maptrap.cpp",
                       0xdb);
    lVar7 = 0;
  }
  else {
    *(undefined4 *)(lVar7 + 0x20) = param_1;
    plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,4);
    uVar10 = FUN_140008520(param_1);
    plVar11 = (longlong *)FUN_1400876b0(uVar10);
    lVar8 = *plVar11;
    uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
    lVar8 = (**(code **)(lVar8 + 0x20))(plVar11,uVar3,1);
    if (lVar8 == 0) {
      (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))();
      lVar7 = 0;
    }
    else {
      plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,1);
      plVar11 = (longlong *)FUN_1403a6c70();
      lVar8 = *plVar11;
      uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
      lVar8 = (**(code **)(lVar8 + 0x40))(plVar11,uVar3);
      *(longlong *)(lVar7 + 0xb0) = lVar8;
      if (lVar8 == 0) {
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,1);
        plVar11 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,0);
        uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        uVar5 = (**(code **)(*plVar11 + 0x40))(plVar11);
        log_InlineLogDBERROR
                  ("table:cq_trap, CMapTrap::CreateNew(), id[%lu] invalid trap type[%lu] cann\'t find in cq_trap_type"
                   ,(ulonglong)uVar5,(ulonglong)uVar4);
        (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))();
        lVar7 = 0;
      }
      else {
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,0);
        uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        *(undefined4 *)(lVar7 + 0x24) = uVar3;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,1);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x28) = uVar2;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,2);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x2a) = uVar2;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,3);
        uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        *(undefined4 *)(lVar7 + 0x2c) = uVar3;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,4);
        uVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        *(undefined4 *)(lVar7 + 0x30) = uVar3;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,5);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x34) = uVar2;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,6);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x36) = uVar2;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,7);
        uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
        *(undefined4 *)(lVar7 + 0x38) = uVar3;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,8);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x3c) = uVar2;
        plVar9 = (longlong *)(**(code **)(*param_2 + 0x20))(param_2,9);
        uVar2 = (**(code **)(*plVar9 + 0x50))(plVar9);
        *(undefined2 *)(lVar7 + 0x3e) = uVar2;
        cVar1 = FUN_1403aabd0(lVar7);
        if (cVar1 == '\0') {
          log_InlineLogERROR("CMapTrap::CreateNew failed for trap type %u in map%u(%u, %u) @%s,%d",
                             (ulonglong)*(ushort *)(lVar7 + 0x28),(ulonglong)*(uint *)(lVar7 + 0x30)
                             ,(ulonglong)*(ushort *)(lVar7 + 0x34),(uint)*(ushort *)(lVar7 + 0x36),
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\maptrap.cpp"
                             ,0xfc);
          (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))();
          lVar7 = 0;
        }
      }
    }
  }
  return lVar7;
}

// ==== CMapGroupKernel::helper_1403cc910  @1403cc910  [medium:callgraph-r3]  (orig: FUN_1403cc910)
longlong FUN_1403cc910(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1403c6ef0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x25) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x25) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x25);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x25);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x25);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x25);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_1403ca400(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMapGroupKernel::helper_1403e6f10  @1403e6f10  [medium:callgraph-r3]  (orig: FUN_1403e6f10)
void FUN_1403e6f10(longlong param_1)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  ushort local_res10 [4];
  undefined8 local_res18;
  undefined8 local_res20;
  longlong *local_48;
  longlong local_40;
  longlong *local_38;
  
  FUN_1403ccc50(param_1 + 0x108,&local_48,param_1 + 0x189);
  lVar5 = *(longlong *)(param_1 + 0x138);
  lVar6 = 0;
  local_38 = *(longlong **)(param_1 + 0x108);
  if ((local_48 == (longlong *)0x0) || (local_48 != local_38)) {
    _invalid_parameter_noinfo();
  }
  if (local_40 == lVar5) {
    cVar1 = FUN_1403cf3e0(param_1,param_1 + 0x189);
    if (cVar1 != '\0') {
      FUN_1403d6c80(param_1);
    }
  }
  else {
    if (local_48 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar6 = *local_48;
    }
    if (local_40 == *(longlong *)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x20c));
    plVar4 = (longlong *)FUN_140087650(uVar3);
    lVar5 = (**(code **)(*plVar4 + 0x98))(plVar4,*(undefined4 *)(local_40 + 0x20));
    if (lVar5 != 0) {
      if (*(char *)(local_40 + 0x78) == '\0') {
        FUN_1403e5a50(param_1,*(undefined1 *)(param_1 + 0x189),lVar5,0);
      }
      else {
        local_res10[0] = 0;
        local_res20 = 0;
        local_res18 = 0;
        FUN_1403cf560(param_1,local_res10,&local_res20,&local_res18);
        if ((local_res10[0] & 2) == 0) {
          iVar2 = *(int *)(param_1 + 0x1c0);
          if ((*(char *)(param_1 + 0x208) == '\x03') || (*(char *)(param_1 + 0x208) == '\x04')) {
            iVar2 = iVar2 * 2;
          }
          if ((local_res10[0] & 1) == 0) {
            if ((local_res10[0] & 8) == 0) {
              FUN_1403e5a50(param_1,*(undefined1 *)(param_1 + 0x189),lVar5,0);
            }
            else {
              FUN_1403e5710(param_1,*(undefined1 *)(param_1 + 0x189),lVar5,0);
            }
          }
          else {
            FUN_1403e50e0(param_1,*(undefined1 *)(param_1 + 0x189),lVar5,(longlong)iVar2,0);
          }
        }
        else {
          FUN_1403e5cf0(param_1,*(undefined1 *)(param_1 + 0x189),lVar5,0);
        }
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403e7d60  @1403e7d60  [medium:callgraph-r2]  (orig: FUN_1403e7d60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_1403e7d60(longlong param_1)

{
  undefined1 uVar1;
  undefined4 uVar2;
  ulonglong *puVar3;
  longlong *plVar4;
  ulonglong *puVar5;
  longlong lVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  char cVar9;
  ulong uVar10;
  ulonglong uVar11;
  undefined8 *puVar12;
  longlong *plVar13;
  longlong *plVar14;
  undefined8 *puVar15;
  undefined8 *puVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  bool bVar19;
  undefined1 auStack_df8 [32];
  undefined1 local_dd8;
  byte local_dc8;
  undefined1 local_dc7;
  ulonglong *local_db8;
  undefined8 *puStack_db0;
  uint local_da8;
  ulonglong *local_d98;
  longlong *plStack_d90;
  ulonglong *local_d88;
  longlong local_d80;
  undefined8 *local_d78;
  undefined8 local_d68;
  undefined8 uStack_d60;
  undefined8 *local_d58;
  longlong *local_d50;
  ulonglong *local_d48;
  longlong *plStack_d40;
  ulonglong *local_d38 [2];
  undefined4 local_d28;
  undefined4 uStack_d24;
  undefined4 uStack_d20;
  undefined4 uStack_d1c;
  ulonglong *local_d18;
  undefined8 *puStack_d10;
  undefined8 local_d08;
  undefined1 local_cf8 [1072];
  undefined1 local_8c8 [1072];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_d08 = 0xfffffffffffffffe;
  uVar11 = DAT_1409707c0 ^ (ulonglong)auStack_df8;
  if (*(int *)(param_1 + 0x210) != 0) {
    local_48 = uVar11;
    if ((*(int *)(param_1 + 0x23c) != 0) &&
       (uVar10 = tq::TimeGet(0),
       (uint)(*(int *)(param_1 + 0x23c) + *(int *)(param_1 + 0x238)) <= uVar10 / 1000)) {
      *(undefined4 *)(param_1 + 0x23c) = 0;
      *(undefined4 *)(param_1 + 0x238) = 0;
      FUN_1403d6c80(param_1);
    }
    uVar11 = 0;
    if ((*(int *)(param_1 + 0x234) != 0) &&
       (uVar10 = tq::TimeGet(0),
       (uint)(*(int *)(param_1 + 0x230) + *(int *)(param_1 + 0x234)) <= uVar10 / 1000)) {
      *(undefined4 *)(param_1 + 0x234) = 0;
      *(undefined4 *)(param_1 + 0x230) = 0;
      FUN_1403d86c0(param_1,*(undefined1 *)(param_1 + 0x189));
      *(undefined4 *)(param_1 + 0x238) = 4;
      uVar10 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x23c) = uVar10 / 1000;
    }
    if ((*(int *)(param_1 + 0x244) != 0) &&
       (uVar10 = tq::TimeGet(0),
       (uint)(*(int *)(param_1 + 0x240) + *(int *)(param_1 + 0x244)) <= uVar10 / 1000)) {
      *(undefined4 *)(param_1 + 0x244) = 0;
      *(undefined4 *)(param_1 + 0x240) = 0;
      FUN_1403e6f10(param_1);
    }
    if (*(int *)(param_1 + 0x298) != 0) {
      uVar10 = tq::TimeGet(0);
      if ((uint)(*(int *)(param_1 + 0x298) + *(int *)(param_1 + 0x294)) <=
          (uint)((ulonglong)uVar10 / 1000)) {
        *(undefined4 *)(param_1 + 0x298) = 0;
        *(undefined4 *)(param_1 + 0x294) = 0;
        FUN_1403e7b10(param_1,CONCAT71((int7)((ulonglong)uVar10 / 1000 >> 8),1));
      }
    }
    if (*(int *)(param_1 + 0x24c) != 0) {
      uVar10 = tq::TimeGet(0);
      if ((uint)(*(int *)(param_1 + 0x248) + *(int *)(param_1 + 0x24c)) <=
          (uint)((ulonglong)uVar10 / 1000)) {
        *(undefined4 *)(param_1 + 0x24c) = 0;
        *(undefined4 *)(param_1 + 0x248) = 0;
        FUN_1403e7b10(param_1,CONCAT71((int7)((ulonglong)uVar10 / 1000 >> 8),1));
        local_da8 = 0;
        plVar13 = (longlong *)**(undefined8 **)(param_1 + 0x138);
        puVar3 = *(ulonglong **)(param_1 + 0x108);
        plVar4 = *(longlong **)(param_1 + 0x138);
        puVar5 = *(ulonglong **)(param_1 + 0x108);
        local_d68._0_4_ = SUB84(puVar5,0);
        local_d68._4_4_ = (undefined4)((ulonglong)puVar5 >> 0x20);
        uStack_d60._0_4_ = SUB84(plVar4,0);
        uStack_d60._4_4_ = (undefined4)((ulonglong)plVar4 >> 0x20);
        local_d28 = (undefined4)local_d68;
        uStack_d24 = local_d68._4_4_;
        uStack_d20 = (undefined4)uStack_d60;
        uStack_d1c = uStack_d60._4_4_;
        uVar18 = uVar11;
        local_d98 = puVar3;
        plStack_d90 = plVar13;
        local_d68 = puVar5;
        uStack_d60 = plVar4;
        local_d48 = puVar3;
        plStack_d40 = plVar13;
LAB_1403e7fe0:
        if ((puVar3 == (ulonglong *)0x0) || (puVar3 != puVar5)) {
          _invalid_parameter_noinfo();
        }
        if (plVar13 != plVar4) {
          if (puVar3 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
            uVar17 = uVar11;
          }
          else {
            uVar17 = *puVar3;
          }
          if (plVar13 == *(longlong **)(uVar17 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if ((char)plVar13[0xc] == '\x01') {
            local_da8 = (int)uVar18 + 1;
            uVar18 = (ulonglong)local_da8;
          }
          if (puVar3 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar13 + 0x81) == '\0') {
            plVar14 = plVar13;
            plVar8 = (longlong *)plVar13[2];
            if (*(char *)(plVar13[2] + 0x81) == '\0') {
              do {
                plVar13 = plVar8;
                plVar8 = (longlong *)*plVar13;
                local_d50 = plVar13;
              } while (*(char *)(*plVar13 + 0x81) == '\0');
            }
            else {
              do {
                plVar13 = (longlong *)plVar14[1];
                if (*(char *)((longlong)plVar13 + 0x81) != '\0') break;
                bVar19 = plVar14 == (longlong *)plVar13[2];
                plVar14 = plVar13;
              } while (bVar19);
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          goto LAB_1403e7fe0;
        }
        if ((int)uVar18 < 2) {
          *(undefined1 *)(param_1 + 0x188) = 0xff;
        }
        else {
          FUN_1403e1140(param_1);
        }
      }
    }
    local_dc8 = 0;
    local_d98 = *(ulonglong **)(param_1 + 0x138);
    puVar16 = (undefined8 *)*local_d98;
    puVar3 = *(ulonglong **)(param_1 + 0x108);
    local_db8 = puVar3;
    puStack_db0 = puVar16;
    local_d88 = puVar3;
LAB_1403e80f2:
    puVar5 = local_d98;
    if ((puVar3 == (ulonglong *)0x0) || (puVar3 != local_d88)) {
      _invalid_parameter_noinfo();
    }
    if (puVar16 != puVar5) {
      local_dc7 = 0;
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar18 = uVar11;
      }
      else {
        uVar18 = *puVar3;
      }
      if (puVar16 == *(undefined8 **)(uVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      if (puVar3 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar18 = uVar11;
      }
      else {
        uVar18 = *puVar3;
      }
      if (puVar16 == *(undefined8 **)(uVar18 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      uVar1 = *(undefined1 *)(puVar16 + 3);
      uVar2 = *(undefined4 *)(puVar16 + 4);
      if (((*(char *)((longlong)puVar16 + 100) == '\0') ||
          (local_dc8 = 1, *(int *)((longlong)puVar16 + 0x74) == 0)) ||
         (uVar10 = tq::TimeGet(0),
         uVar10 / 1000 < (uint)(*(int *)((longlong)puVar16 + 0x74) + *(int *)(puVar16 + 0xe)))) {
        if (puVar3 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar16 + 0x81) == '\0') {
          puVar12 = puVar16;
          puVar15 = (undefined8 *)puVar16[2];
          if (*(char *)((longlong)puVar16[2] + 0x81) == '\0') {
            do {
              puVar16 = puVar15;
              puVar15 = (undefined8 *)*puVar16;
              puStack_db0 = puVar16;
              local_d58 = puVar16;
            } while (*(char *)((longlong)*puVar16 + 0x81) == '\0');
          }
          else {
            do {
              puVar16 = (undefined8 *)puVar12[1];
              puStack_db0 = puVar16;
              if (*(char *)((longlong)puVar16 + 0x81) != '\0') break;
              bVar19 = puVar12 == (undefined8 *)puVar16[2];
              puVar12 = puVar16;
            } while (bVar19);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      else {
        *(undefined4 *)((longlong)puVar16 + 0x74) = 0;
        *(undefined4 *)(puVar16 + 0xe) = 0;
        local_dc7 = 1;
        FUN_140452f10(local_8c8);
        cVar9 = FUN_140452fc0(local_8c8,1,*(undefined4 *)(param_1 + 0x1b4),
                              *(undefined4 *)(puVar16 + 4));
        if (cVar9 != '\0') {
          FUN_1403d63a0(param_1,local_8c8,0);
        }
        FUN_140453760(local_cf8);
        if (puVar3 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar18 = uVar11;
        }
        else {
          uVar18 = *puVar3;
        }
        if (puVar16 == *(undefined8 **)(uVar18 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        local_dd8 = *(undefined1 *)(puVar16 + 3);
        cVar9 = FUN_140453810(local_cf8,1,*(undefined4 *)(param_1 + 0x210),
                              *(undefined4 *)(puVar16 + 4));
        if (cVar9 != '\0') {
          FUN_1403d74e0(param_1,local_cf8,0);
        }
        if (*(char *)(puVar16 + 0xc) == '\x02') {
          puVar12 = (undefined8 *)FUN_1403cff10(param_1 + 0x1c8,puVar16 + 4);
          *puVar12 = puVar16[0xb];
        }
        FUN_140362560(local_498);
        cVar9 = FUN_140362910(local_498,0xeb,*(undefined4 *)(param_1 + 0x210),
                              *(longlong *)(param_1 + 0x140) + -1);
        if (cVar9 != '\0') {
          FUN_1403d74e0(param_1,local_498,0);
        }
        FUN_1403cc910(&DAT_1409762b0,puVar16 + 4);
        puVar12 = puStack_db0;
        puVar5 = local_db8;
        if (puVar3 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar16 + 0x81) == '\0') {
          puVar15 = puVar16;
          puVar7 = (undefined8 *)puVar16[2];
          if (*(char *)((longlong)puVar16[2] + 0x81) == '\0') {
            do {
              puVar16 = puVar7;
              puVar7 = (undefined8 *)*puVar16;
              puStack_db0 = puVar16;
              local_d78 = puVar16;
            } while (*(char *)((longlong)*puVar16 + 0x81) == '\0');
          }
          else {
            do {
              puVar16 = (undefined8 *)puVar15[1];
              puStack_db0 = puVar16;
              if (*(char *)((longlong)puVar16 + 0x81) != '\0') break;
              bVar19 = puVar15 == (undefined8 *)puVar16[2];
              puVar15 = puVar16;
            } while (bVar19);
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
        local_d18 = puVar5;
        puStack_d10 = puVar12;
        FUN_1403da2f0(param_1 + 0x108,local_d38,&local_d18);
        FUN_1403cfb80(param_1,uVar2,uVar1,0);
        FUN_1403625e0(local_498);
        FUN_1404537b0(local_cf8);
        FUN_140452f60();
      }
      goto LAB_1403e80f2;
    }
    uVar11 = (ulonglong)local_dc8;
    if ((((local_dc8 != 0) && (uVar11 = FUN_1403c9810(param_1), (char)uVar11 == '\0')) &&
        (uVar11 = FUN_1403e3280(param_1), (char)uVar11 == '\0')) &&
       (uVar11 = FUN_1403e44e0(param_1), (char)uVar11 == '\0')) {
      if (*(int *)(param_1 + 0x228) < 1) {
        FUN_1403ccc50(param_1 + 0x108,&local_d88,param_1 + 0x189);
        lVar6 = *(longlong *)(param_1 + 0x138);
        local_d38[0] = *(ulonglong **)(param_1 + 0x108);
        if ((local_d88 == (ulonglong *)0x0) || (local_d88 != local_d38[0])) {
          _invalid_parameter_noinfo();
        }
        if (local_d80 == lVar6) {
          FUN_1403cf3e0(param_1,param_1 + 0x189);
        }
        uVar11 = FUN_1403d6c80(param_1);
      }
      else {
        *(int *)(param_1 + 0x230) = *(int *)(param_1 + 0x228);
        uVar10 = tq::TimeGet(0);
        uVar11 = (ulonglong)uVar10 * 0x10624dd3 & 0xffffffff;
        *(uint *)(param_1 + 0x234) = uVar10 / 1000;
        *(undefined4 *)(param_1 + 0x228) = 0;
      }
    }
  }
  return uVar11;
}

// ==== CMapGroupKernel::helper_1403fcc20  @1403fcc20  [medium:callgraph-r3]  (orig: FUN_1403fcc20)
void FUN_1403fcc20(longlong param_1)

{
  ulonglong uVar1;
  ulonglong uVar2;
  void *pvVar3;
  void *_Src;
  byte *pbVar4;
  void *_Dst;
  void *pvVar5;
  longlong *plVar6;
  longlong lVar7;
  byte bVar8;
  
  uVar1 = *(ulonglong *)(param_1 + 0x28);
  if (uVar1 < *(ulonglong *)(param_1 + 0x20)) {
    _invalid_parameter_noinfo();
  }
  uVar2 = *(ulonglong *)(param_1 + 0x20);
  lVar7 = *(longlong *)(param_1 + 8);
  if (*(ulonglong *)(param_1 + 0x28) < uVar2) {
    _invalid_parameter_noinfo();
  }
  if ((lVar7 == 0) || (lVar7 != *(longlong *)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  FUN_1403fc330(uVar2,uVar1,(longlong)(uVar1 - uVar2) / 0x2c,&LAB_1403f8170);
  pvVar5 = *(void **)(param_1 + 0x20);
  if (*(void **)(param_1 + 0x28) < pvVar5) {
    _invalid_parameter_noinfo();
  }
  plVar6 = *(longlong **)(param_1 + 8);
  bVar8 = 1;
  while( true ) {
    pvVar3 = *(void **)(param_1 + 0x28);
    if (pvVar3 < *(void **)(param_1 + 0x20)) {
      _invalid_parameter_noinfo();
    }
    if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    if (pvVar5 == pvVar3) break;
    if (bVar8 < 0x97) {
      if (plVar6 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar6;
      }
      if (*(void **)(lVar7 + 0x20) <= pvVar5) {
        _invalid_parameter_noinfo();
      }
      pbVar4 = (byte *)FUN_1403fbd40(param_1 + 0x40,(longlong)pvVar5 + 0x14);
      *pbVar4 = bVar8;
      if (bVar8 == 0x96) {
        *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)((longlong)pvVar5 + 0x10);
      }
      if (plVar6 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar7 = 0;
      }
      else {
        lVar7 = *plVar6;
      }
      if (*(void **)(lVar7 + 0x20) <= pvVar5) {
        _invalid_parameter_noinfo();
      }
      pvVar5 = (void *)((longlong)pvVar5 + 0x2c);
      bVar8 = bVar8 + 1;
    }
    else {
      pvVar3 = *(void **)(param_1 + 0x28);
      _Dst = pvVar5;
      _Src = pvVar5;
      while (_Src = (void *)((longlong)_Src + 0x2c), _Src != pvVar3) {
        memcpy(_Dst,_Src,0x2c);
        _Dst = (void *)((longlong)_Dst + 0x2c);
      }
      *(longlong *)(param_1 + 0x28) = *(longlong *)(param_1 + 0x28) + -0x2c;
      if ((pvVar5 < *(void **)(param_1 + 0x20)) || (*(void **)(param_1 + 0x28) < pvVar5)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(param_1 + 8);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403fcf20  @1403fcf20  [medium:callgraph-r3]  (orig: FUN_1403fcf20)
void FUN_1403fcf20(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x2c;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x2c) < uVar3) {
    FUN_1403f9a00(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x2c;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1403fc920(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMapGroupKernel::helper_1403fd020  @1403fd020  [medium:callgraph-r2]  (orig: FUN_1403fd020)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403fd020(longlong param_1)

{
  int iVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  longlong *plVar5;
  char *pcVar6;
  longlong lVar7;
  char *pcVar8;
  int iVar9;
  undefined1 uVar10;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  char local_470 [16];
  int local_460;
  undefined4 local_45c;
  char local_458 [16];
  undefined4 local_448;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  local_438 = '\0';
  memset(local_437,0,0x3ff);
  _snprintf(&local_438,0x400,PTR_s_SELECT_cq_jianghu_player_gongfu__14095e3f0);
  local_39 = 0;
  plVar3 = (longlong *)InstanceGet();
  plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,&local_438,2);
  if (plVar3 == (longlong *)0x0) {
    local_488 = 0x39;
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR("LoadUserTotalPowerValueSort, CreateRecordset error.at %s, %d");
    uVar4 = 0;
  }
  else {
    iVar9 = 0;
    iVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
    if (0 < iVar1) {
      do {
        if (0x95 < iVar9) break;
        (**(code **)(*plVar3 + 0x30))(plVar3,(longlong)iVar9);
        plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,1);
        iVar1 = (**(code **)(*plVar5 + 0x50))(plVar5);
        if (iVar1 != 0) {
          plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,2);
          iVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
          if (iVar2 == 0) {
            plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,4);
            iVar2 = (**(code **)(*plVar5 + 0x40))(plVar5);
            uVar10 = iVar2 == 0;
            if ((bool)uVar10) {
              plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,3);
              pcVar6 = (char *)(**(code **)(*plVar5 + 0x78))(plVar5);
              lVar7 = 1;
              pcVar8 = "";
              do {
                if (lVar7 == 0) break;
                lVar7 = lVar7 + -1;
                uVar10 = *pcVar6 == *pcVar8;
                pcVar6 = pcVar6 + 1;
                pcVar8 = pcVar8 + 1;
              } while ((bool)uVar10);
              if ((bool)uVar10) goto LAB_1403fd280;
            }
          }
          local_470[0] = '\0';
          local_470[1] = '\0';
          local_470[2] = '\0';
          local_470[3] = '\0';
          local_470[4] = '\0';
          local_470[5] = '\0';
          local_470[6] = '\0';
          local_470[7] = '\0';
          local_470[8] = '\0';
          local_470[9] = '\0';
          local_470[10] = '\0';
          local_470[0xb] = '\0';
          local_470[0xc] = '\0';
          local_470[0xd] = '\0';
          local_470[0xe] = '\0';
          local_470[0xf] = '\0';
          local_460 = 0;
          local_45c = 0;
          local_458[0] = '\0';
          local_458[1] = '\0';
          local_458[2] = '\0';
          local_458[3] = '\0';
          local_458[4] = '\0';
          local_458[5] = '\0';
          local_458[6] = '\0';
          local_458[7] = '\0';
          local_458[8] = '\0';
          local_458[9] = '\0';
          local_458[10] = '\0';
          local_458[0xb] = '\0';
          local_458[0xc] = '\0';
          local_458[0xd] = '\0';
          local_458[0xe] = '\0';
          local_458[0xf] = '\0';
          local_448 = 0;
          plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0);
          pcVar6 = (char *)(**(code **)(*plVar5 + 0x78))(plVar5);
          tq::SafeCopy(local_470,pcVar6,0x10);
          local_460 = iVar1;
          plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,2);
          local_45c = (**(code **)(*plVar5 + 0x40))(plVar5);
          plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,3);
          pcVar6 = (char *)(**(code **)(*plVar5 + 0x78))(plVar5);
          tq::SafeCopy(local_458,pcVar6,0x10);
          plVar5 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,4);
          local_448 = (**(code **)(*plVar5 + 0x50))(plVar5);
          FUN_1403fcf20(param_1 + 8,local_470);
        }
LAB_1403fd280:
        iVar9 = iVar9 + 1;
        iVar1 = (**(code **)(*plVar3 + 0x40))(plVar3);
      } while (iVar9 < iVar1);
    }
    FUN_1403fcc20(param_1);
    (**(code **)*plVar3)(plVar3);
    uVar4 = 1;
  }
  return uVar4;
}

// ==== CMapGroupKernel::helper_1403fd4d0  @1403fd4d0  [medium:callgraph-r1]  (orig: FUN_1403fd4d0)
bool FUN_1403fd4d0(void)

{
  char cVar1;
  
  cVar1 = FUN_1403fd020();
  return cVar1 != '\0';
}

// ==== CMapGroupKernel::helper_1403fdf30  @1403fdf30  [medium:callgraph-r3]  (orig: FUN_1403fdf30)
ulonglong FUN_1403fdf30(longlong param_1,char param_2)

{
  longlong *plVar1;
  undefined1 uVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  ulonglong extraout_RAX;
  undefined8 uVar15;
  
  uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  uVar11 = FUN_14008abf0(uVar10);
  if ((char)uVar11 == '\0') {
    iVar4 = FUN_1403fd5d0(param_1,6);
    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar12 + 0x1c0) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar10 = 0;
    }
    else {
      uVar10 = *(undefined8 *)(lVar12 + 0x1c0);
    }
    uVar15 = 0;
    uVar11 = FUN_1401d8970(uVar10);
    if (iVar4 < (int)uVar11) {
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 8));
      plVar13 = (longlong *)FUN_140087650(uVar10);
      lVar12 = (**(code **)(*plVar13 + 0x98))(plVar13,*(undefined4 *)(param_1 + 0xc));
      uVar11 = 0;
      if (lVar12 != 0) {
        uVar2 = FUN_1403fd740(param_1,5);
        lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 8));
        if (*(longlong *)(lVar14 + 0x1c0) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          uVar10 = uVar15;
        }
        else {
          uVar10 = *(undefined8 *)(lVar14 + 0x1c0);
        }
        plVar13 = (longlong *)FUN_1401e5190(uVar10,uVar2);
        if (plVar13 == (longlong *)0x0) {
          log_InlineLogERROR(
                            "CJiangHuMgr::ProcessAddUserFreeCativateParam, Genuine Qi Level(%u) Record Is Null. at %s, %d"
                            );
          uVar11 = extraout_RAX;
        }
        else if (param_2 == '\0') {
          plVar1 = (longlong *)(lVar12 + 0x10);
          iVar5 = (**(code **)(*plVar1 + 0x168))(plVar1);
          if ((((iVar5 == 0x3ea) && (*(char *)(lVar12 + 0x12c8) == '\0')) &&
              (cVar3 = (**(code **)(*plVar1 + 0x220))(plVar1), cVar3 != '\0')) &&
             ((cVar3 = FUN_1403fd9d0(param_1), cVar3 == '\x01' &&
              (lVar12 = (**(code **)(*plVar1 + 0x160))(plVar1), lVar12 != 0)))) {
            uVar8 = (**(code **)(*plVar1 + 0x48))(plVar1);
            uVar9 = (**(code **)(*plVar1 + 0x40))(plVar1);
            uVar10 = (**(code **)(*plVar1 + 0x160))(plVar1);
            lVar12 = FUN_1402c6790(uVar10,0x1e,uVar9,uVar8);
            if (lVar12 != 0) {
              plVar13 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,4);
              iVar5 = (**(code **)(*plVar13 + 0x48))(plVar13);
              lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
              if (*(longlong *)(lVar12 + 0x1c0) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar10 = uVar15;
              }
              else {
                uVar10 = *(undefined8 *)(lVar12 + 0x1c0);
              }
              iVar5 = iVar5 + iVar4;
              iVar4 = FUN_1401d8970(uVar10);
              if (iVar4 < iVar5) {
                lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
                if (*(longlong *)(lVar12 + 0x1c0) == 0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  uVar15 = *(undefined8 *)(lVar12 + 0x1c0);
                }
                iVar5 = FUN_1401d8970(uVar15);
              }
              uVar11 = FUN_1403fd660(param_1,6,iVar5);
              return uVar11;
            }
          }
          plVar13 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,3);
          iVar5 = (**(code **)(*plVar13 + 0x48))(plVar13);
          lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
          if (*(longlong *)(lVar12 + 0x1c0) == 0) {
            log_InlineLogERROR(&DAT_1406d9c10);
            uVar10 = uVar15;
          }
          else {
            uVar10 = *(undefined8 *)(lVar12 + 0x1c0);
          }
          iVar5 = iVar5 + iVar4;
          iVar4 = FUN_1401d8970(uVar10);
          if (iVar4 < iVar5) {
            lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
            if (*(longlong *)(lVar12 + 0x1c0) == 0) {
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              uVar15 = *(undefined8 *)(lVar12 + 0x1c0);
            }
            iVar5 = FUN_1401d8970(uVar15);
          }
          uVar11 = FUN_1403fd660(param_1,6,iVar5);
        }
        else {
          iVar5 = FUN_140165970(lVar12);
          uVar6 = _time32((__time32_t *)0x0);
          uVar11 = (ulonglong)uVar6;
          iVar5 = uVar6 - iVar5;
          if (0 < iVar5) {
            plVar13 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,3);
            iVar7 = (**(code **)(*plVar13 + 0x48))(plVar13);
            uVar11 = (longlong)iVar5 * -0x77777777 & 0xffffffff;
            iVar7 = iVar7 * (iVar5 / 0x1e);
            if (0 < iVar7) {
              lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
              if (*(longlong *)(lVar12 + 0x1c0) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar10 = uVar15;
              }
              else {
                uVar10 = *(undefined8 *)(lVar12 + 0x1c0);
              }
              iVar7 = iVar7 + iVar4;
              iVar4 = FUN_1401d8970(uVar10);
              if (iVar4 < iVar7) {
                lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 8));
                if (*(longlong *)(lVar12 + 0x1c0) == 0) {
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  uVar15 = *(undefined8 *)(lVar12 + 0x1c0);
                }
                iVar7 = FUN_1401d8970(uVar15);
              }
              uVar11 = FUN_1403fd660(param_1,6,iVar7,1);
            }
          }
        }
      }
    }
  }
  return uVar11;
}

// ==== CMapGroupKernel::helper_1403fe430  @1403fe430  [medium:callgraph-r3]  (orig: FUN_1403fe430)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403fe430(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  IStringManager *pIVar6;
  undefined8 uVar7;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 8));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    local_488 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x98))
                     (*(longlong **)(lVar3 + 0x90),*(undefined4 *)(param_1 + 0xc));
  if (plVar4 != (longlong *)0x0) {
    cVar1 = FUN_1403fd9d0(param_1);
    if (cVar1 == '\x01') {
      if (*(longlong *)(param_1 + 0x10) == 0) {
        local_488 = 0xa5;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))
                           (*(longlong **)(param_1 + 0x10),2);
        (**(code **)(*plVar5 + 0xd8))(plVar5,2);
      }
      FUN_140400920(local_468);
      uVar2 = (**(code **)(*plVar4 + 8))(plVar4);
      cVar1 = FUN_140400ce0(local_468,6,uVar2,2);
      if (cVar1 != '\0') {
        (**(code **)(plVar4[2] + 0x348))(plVar4 + 2,local_468,1);
      }
      pIVar6 = theInstance();
      lVar3 = plVar4[2];
      uVar7 = (*(code *)**(undefined8 **)pIVar6)(pIVar6,"STR_JAING_HU_LEAVE_SUCCESS");
      (**(code **)(lVar3 + 0x358))(plVar4 + 2,uVar7);
      FUN_1404009a0(local_468);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403fe610  @1403fe610  [medium:callgraph-r2]  (orig: FUN_1403fe610)
void FUN_1403fe610(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x20) != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x20) + *(int *)(param_1 + 0x1c)) <= uVar1 / 1000) {
      uVar1 = tq::TimeGet(0);
      *(uint *)(param_1 + 0x20) = uVar1 / 1000;
      FUN_1403fdf30(param_1,0);
      uVar1 = tq::TimeGet(1);
      *(ulong *)(param_1 + 0x24) = uVar1;
    }
  }
  if (*(int *)(param_1 + 0x2c) != 0) {
    uVar1 = tq::TimeGet(0);
    if ((uint)(*(int *)(param_1 + 0x2c) + *(int *)(param_1 + 0x28)) <= uVar1 / 1000) {
      *(undefined4 *)(param_1 + 0x2c) = 0;
      *(undefined4 *)(param_1 + 0x28) = 0;
      FUN_1403fe430(param_1);
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1403fe770  @1403fe770  [medium:callgraph-r3]  (orig: FUN_1403fe770)
void FUN_1403fe770(longlong param_1)

{
  if (*(char *)(param_1 + 0x18) == '\0') {
    if (*(longlong *)(param_1 + 0x10) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))(*(longlong **)(param_1 + 0x10),1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14041c4e0  @14041c4e0  [medium:callgraph-r2]  (orig: FUN_14041c4e0)
void FUN_14041c4e0(longlong param_1)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  char cVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  undefined4 uVar14;
  longlong lVar15;
  longlong *plVar16;
  longlong *plVar17;
  undefined8 *puVar18;
  undefined8 *puVar19;
  longlong *plVar20;
  longlong *local_res10;
  longlong *local_res18;
  longlong *local_res20;
  longlong *local_c8;
  undefined8 *puStack_c0;
  longlong *local_b8;
  undefined8 uStack_b0;
  longlong *local_a8 [6];
  undefined8 *local_78;
  undefined8 local_70;
  undefined1 local_68 [24];
  undefined8 local_50;
  
  local_50 = 0xfffffffffffffffe;
  local_res10 = operator_new(8);
  if (local_res10 == (longlong *)0x0) {
    local_a8[0] = (longlong *)0x0;
  }
  else {
    *local_res10 = (longlong)local_a8;
    local_a8[0] = local_res10;
  }
  local_res18 = local_res10;
  local_78 = (undefined8 *)FUN_140009e80(local_a8);
  *(undefined1 *)((longlong)local_78 + 0x1d) = 1;
  local_78[1] = local_78;
  *local_78 = local_78;
  local_78[2] = local_78;
  local_70 = 0;
  plVar20 = (longlong *)**(undefined8 **)(param_1 + 0x80);
  local_res20 = *(longlong **)(param_1 + 0x50);
  local_b8 = *(longlong **)(param_1 + 0x80);
  while( true ) {
    plVar16 = local_b8;
    if (local_res20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    puVar19 = local_78;
    plVar17 = local_a8[0];
    if (plVar20 == plVar16) break;
    if (local_res20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *local_res20;
    }
    if (plVar20 == *(longlong **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar15 = plVar20[4];
    if (lVar15 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = FUN_14041daa0(lVar15);
      local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar4);
      uVar5 = FUN_14041dab0(lVar15);
      local_res10 = (longlong *)CONCAT44(local_res10._4_4_,uVar5);
      uVar5 = FUN_14041da90(lVar15);
      lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x90));
      if (*(longlong *)(lVar15 + 0x90) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      plVar16 = (longlong *)
                (**(code **)(**(longlong **)(lVar15 + 0x90) + 0x98))
                          (*(longlong **)(lVar15 + 0x90),*(undefined4 *)(param_1 + 8));
      if (plVar16 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x90));
        if (*(longlong *)(lVar15 + 0x90) == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar17 = (longlong *)
                  (**(code **)(**(longlong **)(lVar15 + 0x90) + 0x98))
                            (*(longlong **)(lVar15 + 0x90),uVar4);
        if (plVar17 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else if (plVar16 != plVar17) {
          plVar17 = plVar17 + 2;
          iVar6 = (**(code **)(*plVar17 + 0x168))(plVar17);
          iVar7 = (**(code **)(plVar16[2] + 0x168))(plVar16 + 2);
          if (iVar7 == iVar6) {
            iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
            iVar7 = (**(code **)(plVar16[2] + 0x48))(plVar16 + 2);
            iVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
            iVar9 = (**(code **)(plVar16[2] + 0x48))(plVar16 + 2);
            iVar10 = (**(code **)(*plVar17 + 0x40))(plVar17);
            iVar11 = (**(code **)(plVar16[2] + 0x40))(plVar16 + 2);
            iVar12 = (**(code **)(*plVar17 + 0x40))(plVar17);
            iVar13 = (**(code **)(plVar16[2] + 0x40))(plVar16 + 2);
            if ((int)local_res10 * (int)local_res10 <
                (iVar12 - iVar13) * (iVar10 - iVar11) + (iVar8 - iVar9) * (iVar6 - iVar7)) {
              local_res10 = (longlong *)CONCAT44(local_res10._4_4_,uVar5);
              FUN_14000d480(local_a8,local_68,&local_res10);
            }
            else {
              plVar17 = (longlong *)FUN_140118320();
              if (plVar17 == (longlong *)0x0) {
                uVar4 = 0x1ac;
                log_InlineLogERROR(&DAT_1406d9c10);
                uStack_b0 = *local_78;
                local_c8 = local_a8[0];
                puStack_c0 = local_78;
                local_b8 = local_a8[0];
                FUN_14000bd50(local_a8,local_68,&local_b8,&local_c8,uVar4);
                operator_delete(local_78);
                local_78 = (undefined8 *)0x0;
                local_70 = 0;
                operator_delete(local_a8[0]);
                return;
              }
              cVar3 = FUN_140167b70(plVar16);
              if (cVar3 == '\0') {
                iVar6 = (**(code **)(*plVar17 + 0x28))(plVar17,*(undefined4 *)(param_1 + 8));
              }
              else {
                lVar15 = *plVar17;
                uVar4 = (**(code **)(*plVar16 + 0x38))(plVar16);
                uVar14 = FUN_140167b40(plVar16);
                iVar6 = (**(code **)(lVar15 + 0xe8))(plVar17,uVar14,uVar4);
              }
              if ((iVar6 == 0) ||
                 (cVar3 = (**(code **)(*plVar17 + 0x20))
                                    (plVar17,*(undefined4 *)(param_1 + 8),
                                     (ulonglong)local_res18 & 0xffffffff), cVar3 == '\0')) {
                local_res10 = (longlong *)CONCAT44(local_res10._4_4_,uVar5);
                FUN_14000d480(local_a8,local_68,&local_res10);
              }
            }
          }
          else {
            local_res10 = (longlong *)CONCAT44(local_res10._4_4_,uVar5);
            FUN_14000d480(local_a8,local_68,&local_res10);
          }
        }
      }
    }
    if (local_res20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar20 + 0x29) == '\0') {
      plVar16 = (longlong *)plVar20[2];
      if (*(char *)((longlong)plVar16 + 0x29) == '\0') {
        cVar3 = *(char *)(*plVar16 + 0x29);
        plVar20 = plVar16;
        plVar16 = (longlong *)*plVar16;
        while (cVar3 == '\0') {
          cVar3 = *(char *)(*plVar16 + 0x29);
          plVar20 = plVar16;
          plVar16 = (longlong *)*plVar16;
        }
      }
      else {
        cVar3 = *(char *)(plVar20[1] + 0x29);
        plVar17 = (longlong *)plVar20[1];
        plVar16 = plVar20;
        while ((plVar20 = plVar17, cVar3 == '\0' && (plVar16 == (longlong *)plVar20[2]))) {
          cVar3 = *(char *)(plVar20[1] + 0x29);
          plVar17 = (longlong *)plVar20[1];
          plVar16 = plVar20;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar18 = (undefined8 *)*local_78;
  while( true ) {
    if (plVar17 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar18 == puVar19) break;
    if (plVar17 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar17;
    }
    if (puVar18 == *(undefined8 **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14041b950(param_1,*(undefined4 *)(puVar18 + 3));
    if (plVar17 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar18 + 0x1d) == '\0') {
      puVar1 = (undefined8 *)puVar18[2];
      if (*(char *)((longlong)puVar1 + 0x1d) == '\0') {
        cVar3 = *(char *)((longlong)*puVar1 + 0x1d);
        puVar18 = puVar1;
        puVar1 = (undefined8 *)*puVar1;
        while (cVar3 == '\0') {
          cVar3 = *(char *)((longlong)*puVar1 + 0x1d);
          puVar18 = puVar1;
          puVar1 = (undefined8 *)*puVar1;
        }
      }
      else {
        cVar3 = *(char *)((longlong)puVar18[1] + 0x1d);
        puVar2 = (undefined8 *)puVar18[1];
        puVar1 = puVar18;
        while ((puVar18 = puVar2, cVar3 == '\0' && (puVar1 == (undefined8 *)puVar18[2]))) {
          cVar3 = *(char *)((longlong)puVar18[1] + 0x1d);
          puVar2 = (undefined8 *)puVar18[1];
          puVar1 = puVar18;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  uStack_b0 = *local_78;
  local_c8 = local_a8[0];
  puStack_c0 = local_78;
  local_b8 = local_a8[0];
  FUN_14000bd50(local_a8,local_68,&local_b8,&local_c8);
  operator_delete(local_78);
  local_78 = (undefined8 *)0x0;
  local_70 = 0;
  operator_delete(local_a8[0]);
  local_res10 = operator_new(8);
  if (local_res10 == (longlong *)0x0) {
    local_a8[0] = (longlong *)0x0;
  }
  else {
    *local_res10 = (longlong)local_a8;
    local_a8[0] = local_res10;
  }
  local_res18 = local_res10;
  local_78 = (undefined8 *)FUN_140009e80(local_a8);
  *(undefined1 *)((longlong)local_78 + 0x1d) = 1;
  local_78[1] = local_78;
  *local_78 = local_78;
  local_78[2] = local_78;
  local_70 = 0;
  puVar19 = *(undefined8 **)(param_1 + 0x40);
  puVar18 = (undefined8 *)*puVar19;
  plVar20 = *(longlong **)(param_1 + 0x10);
  while( true ) {
    if (plVar20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    puVar1 = local_78;
    plVar16 = local_a8[0];
    if (puVar18 == puVar19) break;
    if (plVar20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar20;
    }
    if (puVar18 == *(undefined8 **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar15 = puVar18[4];
    if (lVar15 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar3 = FUN_14041ded0(lVar15);
      if (cVar3 != '\0') {
        uVar4 = FUN_14041da90(lVar15);
        local_res10 = (longlong *)CONCAT44(local_res10._4_4_,uVar4);
        FUN_14000d480(local_a8,local_68,&local_res10);
      }
    }
    if (plVar20 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar18 + 0x29) == '\0') {
      puVar1 = (undefined8 *)puVar18[2];
      if (*(char *)((longlong)puVar1 + 0x29) == '\0') {
        cVar3 = *(char *)((longlong)*puVar1 + 0x29);
        puVar18 = puVar1;
        puVar1 = (undefined8 *)*puVar1;
        while (cVar3 == '\0') {
          cVar3 = *(char *)((longlong)*puVar1 + 0x29);
          puVar18 = puVar1;
          puVar1 = (undefined8 *)*puVar1;
        }
      }
      else {
        cVar3 = *(char *)((longlong)puVar18[1] + 0x29);
        puVar2 = (undefined8 *)puVar18[1];
        puVar1 = puVar18;
        while ((puVar18 = puVar2, cVar3 == '\0' && (puVar1 == (undefined8 *)puVar18[2]))) {
          cVar3 = *(char *)((longlong)puVar18[1] + 0x29);
          puVar2 = (undefined8 *)puVar18[1];
          puVar1 = puVar18;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar19 = (undefined8 *)*local_78;
  while( true ) {
    if (plVar16 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar19 == puVar1) break;
    if (plVar16 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar16;
    }
    if (puVar19 == *(undefined8 **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_14041bdf0(param_1,*(undefined4 *)(puVar19 + 3));
    if (plVar16 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar19 + 0x1d) == '\0') {
      puVar18 = (undefined8 *)puVar19[2];
      if (*(char *)((longlong)puVar18 + 0x1d) == '\0') {
        cVar3 = *(char *)((longlong)*puVar18 + 0x1d);
        puVar19 = puVar18;
        puVar18 = (undefined8 *)*puVar18;
        while (cVar3 == '\0') {
          cVar3 = *(char *)((longlong)*puVar18 + 0x1d);
          puVar19 = puVar18;
          puVar18 = (undefined8 *)*puVar18;
        }
      }
      else {
        cVar3 = *(char *)((longlong)puVar19[1] + 0x1d);
        puVar2 = (undefined8 *)puVar19[1];
        puVar18 = puVar19;
        while ((puVar19 = puVar2, cVar3 == '\0' && (puVar18 == (undefined8 *)puVar19[2]))) {
          cVar3 = *(char *)((longlong)puVar19[1] + 0x1d);
          puVar2 = (undefined8 *)puVar19[1];
          puVar18 = puVar19;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  uStack_b0 = *local_78;
  local_c8 = local_a8[0];
  puStack_c0 = local_78;
  local_b8 = local_a8[0];
  FUN_14000bd50(local_a8,local_68,&local_b8,&local_c8);
  operator_delete(local_78);
  local_78 = (undefined8 *)0x0;
  local_70 = 0;
  operator_delete(local_a8[0]);
  return;
}

// ==== CMapGroupKernel::helper_14041ded0  @14041ded0  [medium:callgraph-r3]  (orig: FUN_14041ded0)
ulonglong FUN_14041ded0(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x68) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x68) + *(int *)(param_1 + 100);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      *(undefined4 *)(param_1 + 0x68) = 0;
      *(undefined4 *)(param_1 + 100) = 0;
      return 1;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapGroupKernel::helper_14041e870  @14041e870  [medium:callgraph-r1]  (orig: FUN_14041e870)
undefined8 FUN_14041e870(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  (**(code **)(**(longlong **)(param_1 + 8) + 0x40))(*(longlong **)(param_1 + 8),0);
  return 1;
}

// ==== CMapGroupKernel::helper_140420c70  @140420c70  [medium:callgraph-r2]  (orig: FUN_140420c70)
undefined4 FUN_140420c70(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMapGroupKernel::helper_140420fa0  @140420fa0  [medium:callgraph-r2]  (orig: FUN_140420fa0)
ulonglong FUN_140420fa0(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x1c) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x1c) + *(int *)(param_1 + 0x18);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      *(undefined4 *)(param_1 + 0x1c) = 0;
      *(undefined4 *)(param_1 + 0x18) = 0;
      return 1;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapGroupKernel::helper_140421120  @140421120  [medium:callgraph-r3]  (orig: FUN_140421120)
longlong FUN_140421120(longlong param_1)

{
  return param_1 + 0x28;
}

// ==== CMapGroupKernel::helper_140421140  @140421140  [medium:callgraph-r2]  (orig: FUN_140421140)
undefined1 FUN_140421140(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0xb0);
}

// ==== CMapGroupKernel::helper_1404213b0  @1404213b0  [medium:callgraph-r2]  (orig: FUN_1404213b0)
ulonglong FUN_1404213b0(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x1c) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x1c) + *(int *)(param_1 + 0x18);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      *(undefined4 *)(param_1 + 0x1c) = 0;
      *(undefined4 *)(param_1 + 0x18) = 0;
      return 1;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMapGroupKernel::helper_140421920  @140421920  [medium:callgraph-r2]  (orig: FUN_140421920)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140421920(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  ulong uVar8;
  int iVar9;
  longlong lVar10;
  IStringManager *pIVar11;
  undefined8 uVar12;
  undefined8 *puVar13;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if ((*(int *)(param_1 + 0xac) != 0) &&
     (uVar8 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0xac) + *(int *)(param_1 + 0xa8)) <= uVar8 / 1000)) {
    *(undefined4 *)(param_1 + 0xac) = 0;
    *(undefined4 *)(param_1 + 0xa8) = 0;
  }
  if ((*(int *)(param_1 + 0x24) != 0) &&
     (uVar8 = tq::TimeGet(0),
     (uint)(*(int *)(param_1 + 0x24) + *(int *)(param_1 + 0x20)) <= uVar8 / 1000)) {
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x20) = 0;
    puVar3 = *(undefined8 **)(param_1 + 0x58);
    puVar13 = (undefined8 *)*puVar3;
    plVar4 = *(longlong **)(param_1 + 0x28);
    FUN_140362560(local_488);
    local_4a0 = 0;
    local_4a8 = 3;
    local_4b0 = 0xfa;
    local_4b8 = (uint)local_4b8._2_2_ << 0x10;
    iVar9 = FUN_140362620(local_488,1,0);
    if (iVar9 == 0) {
      local_4b8 = 0x127;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      while( true ) {
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar13 == puVar3) break;
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar4;
        }
        if (puVar13 == *(undefined8 **)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        uVar2 = *(undefined4 *)(puVar13 + 3);
        lVar10 = FUN_140008520(0xe);
        if (*(longlong *)(lVar10 + 0x90) == 0) {
          local_4b8 = 0x130;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        lVar10 = (**(code **)(**(longlong **)(lVar10 + 0x90) + 0x98))
                           (*(longlong **)(lVar10 + 0x90),uVar2);
        if (lVar10 == 0) {
          local_4b8 = 0x12e;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          pIVar11 = theInstance();
          lVar5 = *(longlong *)(lVar10 + 0x10);
          uVar12 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_INSTANCE_ENDING");
          (**(code **)(lVar5 + 0x358))(lVar10 + 0x10,uVar12);
          (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x350))(lVar10 + 0x10,local_488);
        }
        if (plVar4 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar13 + 0x1d) == '\0') {
          puVar6 = (undefined8 *)puVar13[2];
          if (*(char *)((longlong)puVar6 + 0x1d) == '\0') {
            cVar1 = *(char *)((longlong)*puVar6 + 0x1d);
            puVar13 = puVar6;
            puVar6 = (undefined8 *)*puVar6;
            while (cVar1 == '\0') {
              cVar1 = *(char *)((longlong)*puVar6 + 0x1d);
              puVar13 = puVar6;
              puVar6 = (undefined8 *)*puVar6;
            }
          }
          else {
            cVar1 = *(char *)((longlong)puVar13[1] + 0x1d);
            puVar7 = (undefined8 *)puVar13[1];
            puVar6 = puVar13;
            while ((puVar13 = puVar7, cVar1 == '\0' && (puVar6 == (undefined8 *)puVar13[2]))) {
              cVar1 = *(char *)((longlong)puVar13[1] + 0x1d);
              puVar7 = (undefined8 *)puVar13[1];
              puVar6 = puVar13;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
    }
    FUN_1403625e0(local_488);
  }
  return;
}

// ==== CMapGroupKernel::helper_140421d50  @140421d50  [medium:callgraph-r3]  (orig: FUN_140421d50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140421d50(longlong param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined1 auStack_538 [32];
  uint local_518;
  undefined4 local_510;
  undefined4 local_508;
  undefined8 local_500;
  undefined8 local_4f8;
  longlong *local_4e8;
  longlong local_4e0;
  undefined4 local_4d8;
  undefined4 local_4d4;
  undefined4 local_4d0;
  longlong *local_4c8;
  longlong *local_4c0 [3];
  longlong *local_4a8;
  longlong *local_4a0;
  undefined8 local_498;
  undefined8 local_490;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_490 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  lVar6 = FUN_140008520(0xe);
  if (*(longlong *)(lVar6 + 0x98) == 0) {
    local_518 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x98) + 0x10))
                    (*(longlong **)(lVar6 + 0x98),*(undefined4 *)(param_1 + 0xc),1);
  if (lVar6 == 0) {
    local_518 = 0x83;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_1402d1bd0(lVar6);
    local_4e8 = operator_new(8);
    plVar9 = (longlong *)0x0;
    local_4c0[0] = plVar9;
    if (local_4e8 != (longlong *)0x0) {
      *local_4e8 = (longlong)local_4c0;
      local_4c0[0] = local_4e8;
    }
    local_4a8 = (longlong *)0x0;
    local_4a0 = (longlong *)0x0;
    local_498 = 0;
    local_4c8 = local_4e8;
    FUN_1402d2100(lVar6,local_4c0);
    plVar10 = local_4a8;
    if (local_4a0 < local_4a8) {
      _invalid_parameter_noinfo();
    }
    plVar2 = local_4a0;
    plVar1 = local_4c0[0];
    plVar11 = local_4c0[0];
    if (local_4a0 < local_4a8) {
      _invalid_parameter_noinfo();
      plVar11 = local_4c0[0];
    }
    while( true ) {
      if ((plVar1 == (longlong *)0x0) || (plVar1 != plVar11)) {
        _invalid_parameter_noinfo();
      }
      if (plVar10 == plVar2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar9;
      }
      else {
        plVar8 = (longlong *)*plVar1;
      }
      if ((longlong *)plVar8[4] <= plVar10) {
        _invalid_parameter_noinfo();
      }
      plVar8 = (longlong *)*plVar10;
      if (plVar8 == (longlong *)0x0) {
        local_518 = 0x92;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_4e8 = (longlong *)0x0;
        cVar3 = (**(code **)(*plVar8 + 0x40))(plVar8,&local_4e8);
        if ((cVar3 != '\0') && (local_4e8 != (longlong *)0x0)) {
          local_4e0 = 0;
          local_4c8 = (longlong *)0x0;
          (**(code **)(*local_4e8 + 0x298))(local_4e8,0x1001,&local_4e0);
          (**(code **)(*local_4e8 + 0x298))(local_4e8,0x1002,&local_4c8);
          if (local_4e0 == 0) {
            if (local_4c8 != (longlong *)0x0) {
              FUN_140388a30();
            }
            plVar8 = (longlong *)FUN_140119790(0xe);
            lVar6 = *plVar8;
            uVar5 = (**(code **)(*local_4e8 + 0x10))();
            (**(code **)(lVar6 + 0xc0))(plVar8,uVar5);
          }
          else {
            local_4d8 = 0;
            local_4d4 = 0;
            local_4d0 = 0;
            uVar7 = FUN_140008520(0xe);
            uVar7 = FUN_1400d6610(uVar7);
            FUN_140006c50(uVar7,&local_4d8);
            local_518 = local_518 & 0xffffff00;
            iVar4 = FUN_1401c55b0(local_4e0,local_4d8,local_4d4,local_4d0);
            if (iVar4 != 0) {
              log_InlineLogERROR("CInstance::Destory fly map error.");
            }
            plVar8 = (longlong *)FUN_140421150(0xe);
            (**(code **)(*plVar8 + 0x50))(plVar8,local_4e0,"CInstance::Destory");
          }
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar8 = plVar9;
      }
      else {
        plVar8 = (longlong *)*plVar1;
      }
      if ((longlong *)plVar8[4] <= plVar10) {
        _invalid_parameter_noinfo();
      }
      plVar10 = plVar10 + 1;
    }
    lVar6 = FUN_140008520(0xe);
    if (*(longlong *)(lVar6 + 0x98) == 0) {
      local_518 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar9 = (longlong *)(**(code **)(**(longlong **)(lVar6 + 0x98) + 0x18))();
    (**(code **)(*plVar9 + 0x30))(plVar9,*(undefined4 *)(param_1 + 0xc));
    uVar7 = FUN_140008520(0xe);
    FUN_14008a910(uVar7,*(undefined4 *)(param_1 + 0xc));
    FUN_140422f50(local_488);
    uVar5 = FUN_140422650(*(undefined8 *)(param_1 + 0x10));
    local_4f8 = 0;
    local_500 = 0;
    local_508 = 0;
    local_510 = *(undefined4 *)(param_1 + 0xc);
    local_518 = 0;
    cVar3 = FUN_140423040(local_488,6,*(undefined4 *)(param_1 + 8),uVar5);
    if (cVar3 != '\0') {
      plVar9 = (longlong *)FUN_140008520(0xe);
      (**(code **)(*plVar9 + 0x30))(plVar9,0,local_488);
    }
    plVar9 = *(longlong **)(*(longlong *)(param_1 + 0x98) + 8);
    cVar3 = *(char *)((longlong)plVar9 + 0x1d);
    while (cVar3 == '\0') {
      FUN_1400098c0(param_1 + 0x68,plVar9[2]);
      plVar10 = (longlong *)*plVar9;
      operator_delete(plVar9);
      plVar9 = plVar10;
      cVar3 = *(char *)((longlong)plVar10 + 0x1d);
    }
    *(longlong *)(*(longlong *)(param_1 + 0x98) + 8) = *(longlong *)(param_1 + 0x98);
    *(undefined8 *)(param_1 + 0xa0) = 0;
    *(undefined8 *)*(undefined8 *)(param_1 + 0x98) = *(undefined8 *)(param_1 + 0x98);
    *(longlong *)(*(longlong *)(param_1 + 0x98) + 0x10) = *(longlong *)(param_1 + 0x98);
    FUN_140422fd0(local_488);
    if (local_4a8 != (longlong *)0x0) {
      operator_delete(local_4a8);
    }
    local_4a8 = (longlong *)0x0;
    local_4a0 = (longlong *)0x0;
    local_498 = 0;
    operator_delete(local_4c0[0]);
  }
  return;
}

// ==== CMapGroupKernel::helper_140422910  @140422910  [medium:callgraph-r3]  (orig: FUN_140422910)
void FUN_140422910(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0x18,local_28,local_res10);
  return;
}

// ==== CMapGroupKernel::helper_140428e30  @140428e30  [medium:callgraph-r2]  (orig: FUN_140428e30)
void FUN_140428e30(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar2 = *(longlong **)(param_1 + 8);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x38);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar3) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (plVar5[4] != 0) {
            FUN_1404dea90();
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x29) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x29) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x29) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x29) == '\0');
  } while( true );
}

// ==== CMapGroupKernel::helper_14042bbe0  @14042bbe0  [medium:callgraph-r2]  (orig: FUN_14042bbe0)
ulonglong FUN_14042bbe0(longlong param_1,undefined1 param_2)

{
  undefined1 *puVar1;
  ulonglong in_RAX;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  FUN_1402b5600();
  *(undefined4 *)(param_1 + 8) = 0xb04;
  *(undefined4 *)(param_1 + 0xc) = 2;
  *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 1) = 0;
  puVar1 = *(undefined1 **)(param_1 + 0x428);
  *puVar1 = param_2;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CMapGroupKernel::helper_140473180  @140473180  [medium:callgraph-r3]  (orig: FUN_140473180)
void FUN_140473180(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x10) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001404731c7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x38))(*(longlong **)(param_1 + 0x10),0);
  return;
}

// ==== CMapGroupKernel::helper_140473df0  @140473df0  [medium:callgraph-r2]  (orig: FUN_140473df0)
void FUN_140473df0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong lVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong *plVar12;
  
  uVar10 = 0xfffffffffffffffe;
  plVar7 = *(longlong **)param_1[8];
  plVar2 = (longlong *)param_1[2];
  plVar11 = plVar2;
  plVar12 = plVar7;
  while( true ) {
    plVar3 = (longlong *)param_1[8];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[2])) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (plVar7 == *(longlong **)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar7 + 4;
    plVar8 = (longlong *)plVar7[7];
    if ((longlong *)plVar7[8] < plVar8) {
      _invalid_parameter_noinfo();
    }
    plVar4 = (longlong *)*plVar3;
    while( true ) {
      plVar5 = (longlong *)plVar7[8];
      if (plVar5 < (longlong *)plVar7[7]) {
        _invalid_parameter_noinfo();
      }
      if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar4;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      puVar6 = (undefined8 *)*plVar8;
      if (puVar6 != (undefined8 *)0x0) {
        (**(code **)*puVar6)(puVar6,1);
      }
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar9 = 0;
      }
      else {
        lVar9 = *plVar4;
      }
      if (*(longlong **)(lVar9 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar8 + 1;
    }
    FUN_1400179f0(plVar3);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x51) == '\0') {
      plVar12 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar12 + 0x51) == '\0') {
        cVar1 = *(char *)(*plVar12 + 0x51);
        plVar7 = plVar12;
        plVar3 = (longlong *)*plVar12;
        while (plVar12 = plVar7, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x51);
          plVar7 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x51);
        plVar12 = (longlong *)plVar7[1];
        plVar3 = plVar7;
        while ((plVar7 = plVar12, plVar12 = plVar7, cVar1 == '\0' &&
               (plVar3 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x51);
          plVar12 = (longlong *)plVar7[1];
          plVar3 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_1403f6730(param_1 + 2,*(undefined8 *)(param_1[8] + 8),param_3,param_4,uVar10,plVar11,plVar12);
  *(undefined8 *)(param_1[8] + 8) = param_1[8];
  param_1[9] = 0;
  *(undefined8 *)param_1[8] = param_1[8];
  *(undefined8 *)(param_1[8] + 0x10) = param_1[8];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_140476730  @140476730  [medium:callgraph-r2]  (orig: FUN_140476730)
void FUN_140476730(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 uVar11;
  
  uVar11 = 0xfffffffffffffffe;
  plVar9 = *(longlong **)param_1[8];
  plVar2 = (longlong *)param_1[2];
  while( true ) {
    plVar3 = (longlong *)param_1[8];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[2])) {
      _invalid_parameter_noinfo();
    }
    if (plVar9 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar2;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar3 = plVar9 + 4;
    plVar8 = *(longlong **)plVar9[10];
    plVar4 = (longlong *)*plVar3;
    while( true ) {
      plVar5 = (longlong *)plVar9[10];
      if ((plVar4 == (longlong *)0x0) || (plVar4 != (longlong *)*plVar3)) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar5) break;
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar4;
      }
      if (plVar8 == *(longlong **)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      puVar6 = (undefined8 *)plVar8[4];
      if (puVar6 != (undefined8 *)0x0) {
        (**(code **)*puVar6)(puVar6,1);
      }
      if (plVar4 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        plVar5 = (longlong *)plVar8[2];
        if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar8 = plVar5;
          plVar5 = (longlong *)*plVar5;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar5 + 0x29);
            plVar8 = plVar5;
            plVar5 = (longlong *)*plVar5;
          }
        }
        else {
          cVar1 = *(char *)(plVar8[1] + 0x29);
          plVar7 = (longlong *)plVar8[1];
          plVar5 = plVar8;
          while ((plVar8 = plVar7, cVar1 == '\0' && (plVar5 == (longlong *)plVar8[2]))) {
            cVar1 = *(char *)(plVar8[1] + 0x29);
            plVar7 = (longlong *)plVar8[1];
            plVar5 = plVar8;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    cVar1 = *(char *)((longlong)*(longlong **)(plVar9[10] + 8) + 0x29);
    plVar8 = *(longlong **)(plVar9[10] + 8);
    while (cVar1 == '\0') {
      FUN_140153d10(plVar3,plVar8[2]);
      plVar4 = (longlong *)*plVar8;
      operator_delete(plVar8);
      plVar8 = plVar4;
      cVar1 = *(char *)((longlong)plVar4 + 0x29);
    }
    *(longlong *)(plVar9[10] + 8) = plVar9[10];
    plVar9[0xb] = 0;
    *(longlong *)plVar9[10] = plVar9[10];
    *(longlong *)(plVar9[10] + 0x10) = plVar9[10];
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x61) == '\0') {
      plVar3 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar3 + 0x61) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x61);
        plVar9 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x61);
          plVar9 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar9[1] + 0x61);
        plVar8 = (longlong *)plVar9[1];
        plVar3 = plVar9;
        while ((plVar9 = plVar8, cVar1 == '\0' && (plVar3 == (longlong *)plVar9[2]))) {
          cVar1 = *(char *)(plVar9[1] + 0x61);
          plVar8 = (longlong *)plVar9[1];
          plVar3 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  FUN_140475f10(param_1 + 2,*(undefined8 *)(param_1[8] + 8),param_3,param_4,uVar11);
  *(undefined8 *)(param_1[8] + 8) = param_1[8];
  param_1[9] = 0;
  *(undefined8 *)param_1[8] = param_1[8];
  *(undefined8 *)(param_1[8] + 0x10) = param_1[8];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14047af70  @14047af70  [medium:callgraph-r2]  (orig: FUN_14047af70)
void FUN_14047af70(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  
  uVar6 = 0xfffffffffffffffe;
  plVar4 = *(longlong **)param_1[8];
  plVar2 = (longlong *)param_1[2];
  plVar7 = plVar2;
  plVar8 = plVar4;
  while( true ) {
    plVar3 = (longlong *)param_1[8];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[2])) {
      _invalid_parameter_noinfo();
    }
    if (plVar4 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar5 = 0;
    }
    else {
      lVar5 = *plVar2;
    }
    if (plVar4 == *(longlong **)(lVar5 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar4[4] != 0) {
      (*(code *)**(undefined8 **)plVar4[4])((undefined8 *)plVar4[4],1);
      plVar4[4] = 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar4 + 0x29) == '\0') {
      plVar8 = (longlong *)plVar4[2];
      if (*(char *)((longlong)plVar8 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar8 + 0x29);
        plVar4 = plVar8;
        plVar3 = (longlong *)*plVar8;
        while (plVar8 = plVar4, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar4 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar4[1] + 0x29);
        plVar8 = (longlong *)plVar4[1];
        plVar3 = plVar4;
        while ((plVar4 = plVar8, plVar8 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar4[2])
               )) {
          cVar1 = *(char *)(plVar4[1] + 0x29);
          plVar8 = (longlong *)plVar4[1];
          plVar3 = plVar4;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[8] + 8) + 0x29);
  plVar4 = *(longlong **)(param_1[8] + 8);
  while (cVar1 == '\0') {
    FUN_140479ff0(param_1 + 2,plVar4[2],param_3,param_4,uVar6,plVar7,plVar8);
    plVar2 = (longlong *)*plVar4;
    operator_delete(plVar4);
    plVar4 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[8] + 8) = param_1[8];
  param_1[9] = 0;
  *(undefined8 *)param_1[8] = param_1[8];
  *(undefined8 *)(param_1[8] + 0x10) = param_1[8];
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CMapGroupKernel::helper_14047e180  @14047e180  [medium:callgraph-r2]  (orig: FUN_14047e180)
ulonglong FUN_14047e180(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(0);
  return CONCAT71((int7)((ulonglong)uVar1 * 0x10624dd3 >> 8),
                  (uint)(*(int *)(param_1 + 0x14) + *(int *)(param_1 + 0x10)) <= uVar1 / 1000) &
         0xffffffff;
}

// ==== CMapGroupKernel::helper_140490070  @140490070  [medium:callgraph-r3]  (orig: FUN_140490070)
undefined8 FUN_140490070(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  longlong lVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong lVar7;
  undefined4 local_res10 [2];
  undefined4 local_50;
  undefined4 uStack_4c;
  longlong local_48;
  undefined1 local_40 [24];
  
  local_res10[0] = param_2;
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x1c0));
  lVar4 = *(longlong *)(lVar4 + 0x100);
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar4 = 0;
  }
  lVar6 = 0;
  lVar4 = FUN_1402f0fe0(lVar4,param_3,param_4);
  if (lVar4 == 0) {
    log_InlineLogDBERROR("table:cq_magictype, can not find magictype: %d, level: %d");
    uVar5 = 0;
  }
  else {
    lVar4 = FUN_1404186d0(*(undefined4 *)(param_1 + 0x1c0),0);
    if (lVar4 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar5 = 0;
    }
    else {
      cVar2 = FUN_140418400(lVar4);
      if (cVar2 == '\0') {
        FUN_1404183d0(lVar4);
        uVar5 = 0;
      }
      else {
        FUN_140418d90(lVar4,0,param_2);
        uVar3 = (**(code **)(**(longlong **)(param_1 + 0x1c8) + 8))();
        FUN_140418d90(lVar4,1,uVar3);
        FUN_140418d90(lVar4,2,param_3);
        FUN_140418d90(lVar4,3,param_4);
        FUN_140418d90(lVar4,4);
        FUN_140418470(lVar4);
        FUN_1404187b0(lVar4);
        FUN_14048dd30(param_1 + 8,&local_50,local_res10);
        lVar7 = *(longlong *)(param_1 + 0x38);
        plVar1 = (longlong *)CONCAT44(uStack_4c,local_50);
        if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
          _invalid_parameter_noinfo();
        }
        if (local_48 == lVar7) {
          local_50 = param_2;
          local_48 = lVar4;
          FUN_14048d7c0(param_1 + 8,local_40,&local_50);
        }
        else {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = lVar6;
          }
          else {
            lVar7 = *plVar1;
          }
          if (local_48 == *(longlong *)(lVar7 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if (*(longlong *)(local_48 + 0x20) != 0) {
            FUN_1404183d0(*(undefined8 *)(local_48 + 0x20));
            *(undefined8 *)(local_48 + 0x20) = 0;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar6 = *plVar1;
          }
          if (local_48 == *(longlong *)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          *(longlong *)(local_48 + 0x20) = lVar4;
        }
        uVar5 = 1;
      }
    }
  }
  return uVar5;
}

// ==== CMapGroupKernel::helper_1404be340  @1404be340  [medium:callgraph-r2]  (orig: FUN_1404be340)
void FUN_1404be340(longlong param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  
  if ((*(longlong *)(param_1 + 0x90) != 0) &&
     ((*(longlong *)(param_1 + 0x1c8) == 0 ||
      (*(char *)(*(longlong *)(param_1 + 0x1c8) + 0x12c8) == '\0')))) {
    iVar2 = FUN_140418c50(*(longlong *)(param_1 + 0x90),0x95);
    if (iVar2 == 0) {
      if ((*(int *)(param_1 + 0xac) != 0) &&
         (uVar4 = tq::TimeGet(0),
         (uint)(*(int *)(param_1 + 0xac) + *(int *)(param_1 + 0xa8)) <= uVar4)) {
        *(undefined4 *)(param_1 + 0xac) = 0;
        *(undefined4 *)(param_1 + 0xa8) = 0;
        FUN_1404bd870(param_1);
        return;
      }
      if ((*(char *)(param_1 + 200) != '\0') && (*(int *)(param_1 + 0xac) == 0)) {
        iVar2 = *(int *)(param_1 + 0xd0);
        iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x85);
        if (iVar3 != 0) {
          iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x85);
        }
        plVar6 = (longlong *)
                 (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))
                           (*(longlong *)(param_1 + 0x1c8) + 0x10);
        iVar3 = (**(code **)(*plVar6 + 8))(plVar6);
        if (iVar3 == 0x40f) {
          cVar1 = FUN_140169360(param_1 + 0xb0,iVar2);
          if (cVar1 != '\0') {
            iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x79);
            if ((iVar2 != 1) &&
               (((iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x7c), iVar2 == 0 ||
                 (uVar8 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x7c), (uVar8 & 8) != 0)) &&
                (iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66), iVar2 != 0xc)))) {
              uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
              FUN_1404bda90(param_1,uVar5,*(undefined4 *)(param_1 + 0x98),
                            *(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0));
            }
            if (*(longlong *)(param_1 + 0x1c8) != 0) {
              FUN_140198450();
            }
          }
        }
        else {
          cVar1 = FUN_140169360(param_1 + 0xb0,
                                *(int *)(*(longlong *)(param_1 + 0x1c8) + 0x1194) + iVar2);
          if (cVar1 != '\0') {
            iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
            if (iVar2 != 0) {
              iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
              iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),2);
              if (iVar2 != iVar3) {
                uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
                lVar7 = FUN_14048b5f0(param_1,uVar5);
                iVar2 = DAT_14096d6c0;
                if (lVar7 == 0) {
                  LOCK();
                  DAT_14096d6c0 = DAT_14096d6c0 + 1;
                  UNLOCK();
                  uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
                  cVar1 = FUN_140490070(param_1,iVar2 + 1,uVar5,0);
                  if (cVar1 == '\0') {
                    log_InlineLogERROR(&DAT_1406d9c10);
                    return;
                  }
                }
              }
              uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
              FUN_1404bda90(param_1,uVar5,*(undefined4 *)(param_1 + 0x98),
                            *(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0));
            }
            *(undefined4 *)(*(longlong *)(param_1 + 0x1c8) + 0x1194) = 0;
            return;
          }
        }
      }
    }
    else {
      iVar2 = *(int *)(param_1 + 0xd0);
      iVar3 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x85);
      if (iVar3 != 0) {
        iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x85);
      }
      plVar6 = (longlong *)
               (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))
                         (*(longlong *)(param_1 + 0x1c8) + 0x10);
      iVar3 = (**(code **)(*plVar6 + 8))(plVar6);
      if ((iVar3 == 0x40f) &&
         (uVar4 = tq::TimeGet(0), (uint)(iVar2 + *(int *)(param_1 + 0xb4)) <= uVar4)) {
        if (*(longlong *)(param_1 + 0x1c8) != 0) {
          FUN_140198450();
        }
        iVar2 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
        if (iVar2 == 0) {
          uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x95);
        }
        else {
          uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x84);
          lVar7 = FUN_14048b5f0(param_1,uVar5);
          if (lVar7 == 0) {
            uVar5 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x95);
            *(undefined4 *)(param_1 + 0x100) = 0;
            *(undefined4 *)(param_1 + 0x108) = 0;
            *(undefined4 *)(param_1 + 0x104) = 0;
            *(undefined4 *)(param_1 + 0x110) = 0;
            *(undefined4 *)(param_1 + 0x10c) = 0;
          }
        }
        FUN_1404bda90(param_1,uVar5,*(undefined4 *)(param_1 + 0x98),*(undefined4 *)(param_1 + 0x9c),
                      *(undefined4 *)(param_1 + 0xa0));
        return;
      }
    }
  }
  return;
}

// ==== CMapGroupKernel::helper_1404dea90  @1404dea90  [medium:callgraph-r3]  (orig: FUN_1404dea90)
void FUN_1404dea90(longlong param_1)

{
  char cVar1;
  ulong uVar2;
  undefined4 uVar3;
  int extraout_EAX;
  int iVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong lVar7;
  __time64_t _Var8;
  
  plVar5 = *(longlong **)(param_1 + 0x10);
  if (plVar5 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,3);
  cVar1 = (**(code **)(*plVar5 + 0x20))(plVar5);
  if (cVar1 == '\x02') {
    if ((*(int *)(param_1 + 0x1c) != 0) &&
       (uVar2 = tq::TimeGet(0), (uint)(*(int *)(param_1 + 0x18) + *(int *)(param_1 + 0x1c)) <= uVar2
       )) {
      *(undefined4 *)(param_1 + 0x1c) = 0;
      *(undefined4 *)(param_1 + 0x18) = 0;
      uVar3 = FUN_1404de030(param_1);
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x24));
      plVar5 = (longlong *)FUN_140087650(uVar6);
      lVar7 = (**(code **)(*plVar5 + 0x98))(plVar5,uVar3);
      if ((lVar7 != 0) && (cVar1 = FUN_140384bc0(lVar7,2,1), cVar1 == '\0')) {
        FUN_140384c50(lVar7,2,1,0,1,1);
      }
    }
    _Var8 = _time64((__time64_t *)0x0);
    extraout_EAX = (int)_Var8;
    iVar4 = extraout_EAX;
    if (*(int *)(param_1 + 0x20) <= extraout_EAX) {
      if (extraout_EAX - *(int *)(param_1 + 0x20) < 0x708) {
        return;
      }
      FUN_1404de700(param_1,1);
      _Var8 = _time64((__time64_t *)0x0);
      iVar4 = (int)_Var8;
    }
    *(int *)(param_1 + 0x20) = iVar4;
  }
  return;
}

// ==== CMapGroupKernel::helper_140579f20  @140579f20  [medium:callgraph-r2]  (orig: FUN_140579f20)
void FUN_140579f20(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CMapGroupKernel::helper_14057b920  @14057b920  [medium:callgraph-r1]  (orig: FUN_14057b920)
undefined8 * FUN_14057b920(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140579f20(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CMapGroupKernel::helper_14057ba20  @14057ba20  [medium:callgraph-r0]  (orig: FUN_14057ba20)
undefined8 * FUN_14057ba20(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = adapter::IResponder::vftable;
    *puVar1 = adapter::CResponder::vftable;
    FUN_14057b920(puVar1 + 1);
    *(undefined4 *)(puVar1 + 9) = param_1;
  }
  return puVar1;
}

