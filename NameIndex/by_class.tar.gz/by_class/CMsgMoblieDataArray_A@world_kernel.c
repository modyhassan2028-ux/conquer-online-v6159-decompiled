// ==== CMsgMoblieDataArray_A@world_kernel::vfunc_0  @1400768e0  [high:rtti-vtable]  (orig: FUN_1400768e0)
undefined8 * FUN_1400768e0(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgMoblieDataArray_A::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

