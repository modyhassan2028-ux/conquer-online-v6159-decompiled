// ==== CServerStatusMonitor::helper_14001f4b0  @14001f4b0  [medium:callgraph-r1]  (orig: FUN_14001f4b0)
void FUN_14001f4b0(longlong param_1,undefined4 param_2)

{
  LOCK();
  *(undefined4 *)(param_1 + 0x1fc) = param_2;
  UNLOCK();
  return;
}

// ==== CServerStatusMonitor::helper_14001f4c0  @14001f4c0  [medium:callgraph-r0]  (orig: FUN_14001f4c0)
undefined4 FUN_14001f4c0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x1fc);
}

// ==== CServerStatusMonitor::helper_14002a1d0  @14002a1d0  [medium:callgraph-r3]  (orig: FUN_14002a1d0)
void FUN_14002a1d0(longlong param_1,longlong param_2,ulonglong param_3,undefined8 *param_4)

{
  void *pvVar1;
  undefined8 uVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined8 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined8 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 3;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 3;
    if (0x1fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140028ab0();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x1fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_140029150(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      puVar6 = (undefined8 *)((longlong)_Dst + lVar4 * 8);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 3;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 3;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 8),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 8);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar1 >> 3)) * 8);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      uVar2 = *param_4;
      FUN_140029fb0(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 8);
      puVar6 = *(undefined8 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 3); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar2;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined8 **)(param_2 + 8); puVar6 != (undefined8 *)(lVar4 + param_3 * -8);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar2;
      }
    }
    else {
      uVar2 = *param_4;
      lVar4 = lVar7 + param_3 * -8;
      uVar3 = FUN_140029fb0(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140029780(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined8 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar2;
      }
    }
  }
  return;
}

// ==== CServerStatusMonitor::helper_14002ac60  @14002ac60  [medium:callgraph-r2]  (orig: FUN_14002ac60)
longlong * FUN_14002ac60(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14002a1d0(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14002ad54;
  }
  _invalid_parameter_noinfo();
LAB_14002ad54:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CServerStatusMonitor::helper_14002ae40  @14002ae40  [medium:callgraph-r1]  (orig: FUN_14002ae40)
void FUN_14002ae40(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14002ac60(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CServerStatusMonitor::helper_14002aef0  @14002aef0  [medium:callgraph-r0]  (orig: FUN_14002aef0)
/* WARNING: Removing unreachable block (ram,0x00014002b17a) */

ulonglong FUN_14002aef0(longlong *param_1,longlong *param_2)

{
  char *_Str1;
  longlong lVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong *plVar4;
  bool bVar5;
  int iVar6;
  ulong uVar7;
  ulonglong extraout_RAX;
  ulonglong uVar8;
  __int64 *p_Var9;
  ulonglong extraout_RAX_00;
  longlong *plVar10;
  undefined1 local_res20 [8];
  undefined4 local_c0 [2];
  undefined *local_b8;
  longlong local_a8;
  longlong *plStack_a0;
  longlong *local_98;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined8 local_68;
  longlong local_60;
  char *local_50;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  local_68 = 0xfffffffffffffffe;
  if (DAT_140975948 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX;
  }
  iVar6 = (int)param_2[1];
  uVar8 = (ulonglong)iVar6;
  if (iVar6 < 3) {
    return uVar8;
  }
  _Str1 = (char *)((longlong)param_2 + 0xc);
  if ((_Str1[uVar8 - 2] != '\r') || (_Str1[uVar8 - 1] != '\n')) {
    if (iVar6 < 0x1f) {
      return uVar8;
    }
    *(undefined4 *)(param_2 + 1) = 0;
    return uVar8;
  }
  local_50 = _Str1;
  iVar6 = _stricmp(_Str1,PTR_s_get_run_info_140949850);
  if (iVar6 == 0) {
    p_Var9 = tq::CrashTimeGet();
    lVar1 = *p_Var9;
    bVar5 = false;
    EnterCriticalSection((LPCRITICAL_SECTION)(param_1 + 8));
    if ((param_1[6] - param_1[5] & 0xfffffffffffffff8U) == 0) {
      bVar5 = true;
      FUN_14002ae40(param_1 + 2,param_2);
    }
    else {
      plVar2 = (longlong *)param_1[6];
      local_78 = 0;
      if (plVar2 < (longlong *)param_1[5]) {
        _invalid_parameter_noinfo();
      }
      lVar3 = param_1[2];
      local_78._0_4_ = (undefined4)lVar3;
      local_78._4_4_ = (undefined4)((ulonglong)lVar3 >> 0x20);
      uStack_70._0_4_ = SUB84(plVar2,0);
      uStack_70._4_4_ = (undefined4)((ulonglong)plVar2 >> 0x20);
      local_48 = (undefined4)local_78;
      uStack_44 = local_78._4_4_;
      uStack_40 = (undefined4)uStack_70;
      uStack_3c = uStack_70._4_4_;
      plVar4 = (longlong *)param_1[5];
      local_a8 = 0;
      local_78 = lVar3;
      uStack_70 = plVar2;
      if ((longlong *)param_1[6] < plVar4) {
        _invalid_parameter_noinfo();
      }
      local_a8 = param_1[2];
      for (plVar10 = plVar4; (plVar10 != plVar2 && (*plVar10 != *param_2)); plVar10 = plVar10 + 1) {
      }
      local_88._0_4_ = (undefined4)local_a8;
      local_88._4_4_ = (undefined4)((ulonglong)local_a8 >> 0x20);
      uStack_80._0_4_ = SUB84(plVar10,0);
      uStack_80._4_4_ = (undefined4)((ulonglong)plVar10 >> 0x20);
      local_38 = (undefined4)local_88;
      uStack_34 = local_88._4_4_;
      uStack_30 = (undefined4)uStack_80;
      uStack_2c = uStack_80._4_4_;
      plVar2 = (longlong *)param_1[6];
      local_60 = 0;
      plStack_a0 = plVar4;
      local_98 = plVar10;
      local_88 = local_a8;
      uStack_80 = plVar10;
      if (plVar2 < (longlong *)param_1[5]) {
        _invalid_parameter_noinfo();
      }
      local_60 = param_1[2];
      if ((local_88 == 0) || (local_88 != local_60)) {
        _invalid_parameter_noinfo();
      }
      if (plVar10 == plVar2) {
        FUN_14002ae40(param_1 + 2,param_2);
      }
    }
    LeaveCriticalSection((LPCRITICAL_SECTION)(param_1 + 8));
    if (lVar1 == 0) {
      uVar8 = extraout_RAX_00;
      if (bVar5) {
        if (*(int *)((longlong)param_1 + 0xc) != 0) {
          *(undefined4 *)((longlong)param_1 + 0xc) = 0;
          *(undefined4 *)(param_1 + 1) = 0;
        }
        *(undefined4 *)(param_1 + 1) = 2;
        uVar7 = tq::TimeGet(0);
        uVar8 = (ulonglong)uVar7 * 0x10624dd3 & 0xffffffff;
        *(uint *)((longlong)param_1 + 0xc) = uVar7 / 1000;
      }
    }
    else {
      uVar8 = FUN_14002a5a0(param_1);
    }
  }
  else {
    iVar6 = _stricmp(_Str1,PTR_s_close_server_140949858);
    if (iVar6 == 0) {
      if (*param_1 == 0) {
        uVar8 = 0;
        goto LAB_14002b29a;
      }
      FUN_14001f4b0(*param_1,3);
    }
    else {
      iVar6 = _stricmp(_Str1,PTR_s_reset_crash_state_140949860);
      if (iVar6 == 0) {
        p_Var9 = tq::CrashTimeGet();
        if (*p_Var9 != 0) {
          p_Var9 = tq::CrashTimeGet();
          LOCK();
          *p_Var9 = 0;
          UNLOCK();
        }
      }
      else {
        iVar6 = _stricmp(_Str1,PTR_s_reset_dbserver_state_140949868);
        if (iVar6 != 0) {
          local_c0[0] = 2;
          local_b8 = &DAT_1406e0a0c;
          uVar8 = WSASend(*param_2,local_c0,1,local_res20,0,0,0);
          goto LAB_14002b29a;
        }
        if (DAT_140975998 != 0) {
          LOCK();
          DAT_140975998 = 0;
          UNLOCK();
        }
      }
    }
    local_c0[0] = 4;
    local_b8 = &DAT_1406e46e0;
    uVar8 = WSASend(*param_2,local_c0,1,local_res20,0,0,0);
  }
LAB_14002b29a:
  *(undefined4 *)(param_2 + 1) = 0;
  return uVar8;
}

// ==== CServerStatusMonitor::SocketThread  @14002b2d0  [high:log-string]  (orig: FUN_14002b2d0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Removing unreachable block (ram,0x00014002b5d8) */
/* WARNING: Removing unreachable block (ram,0x00014002b5e4) */

uint FUN_14002b2d0(longlong param_1)

{
  longlong *_Dst;
  ushort uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong lVar8;
  uint uVar9;
  ulonglong uVar10;
  int iVar11;
  undefined1 auStack_1cb8 [32];
  undefined8 local_1c98;
  undefined8 local_1c90;
  undefined8 local_1c88;
  int local_1c78;
  uint local_1c74;
  int local_1c70;
  int local_1c6c;
  int local_1c68;
  int local_1c64;
  undefined4 local_1c60;
  uint local_1c5c;
  undefined4 local_1c58;
  undefined4 local_1c54;
  undefined4 local_1c50;
  uint local_1c4c;
  undefined4 local_1c48;
  undefined4 local_1c44;
  longlong local_1c40;
  longlong local_1c38;
  int local_1c30 [2];
  undefined1 *local_1c28;
  undefined8 local_1c20;
  uint local_1c18 [2];
  longlong alStack_1c10 [65];
  undefined4 local_1a08;
  undefined4 local_1a04;
  undefined4 local_1a00;
  undefined4 local_19fc;
  undefined2 local_19f8;
  ushort local_19f6;
  undefined4 local_19f4;
  undefined1 local_19e8 [2];
  ushort local_19e6;
  undefined4 local_19e4;
  CIniFile local_19d8 [1024];
  undefined1 local_15d8 [416];
  longlong local_1438;
  undefined4 uStack_1430;
  undefined1 auStack_142c [68];
  undefined1 local_13e8 [5040];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x14002b2e4;
  local_1c20 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1cb8;
  local_1c40 = param_1;
  log_InlineLogMessage("Server Status Monitor SocketThread start.");
  if (param_1 == 0) {
    local_1c98 = (undefined4 *)CONCAT44(local_1c98._4_4_,0x16b);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pMainThread",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp");
    uVar2 = 0;
  }
  else {
    uVar2 = Ordinal_115(0x202,local_15d8);
    if (((uVar2 == 0) && ((char)local_15d8._0_2_ == '\x02')) &&
       (SUB21(local_15d8._0_2_,1) == '\x02')) {
      local_1c90 = (ulonglong)local_1c90._4_4_ << 0x20;
      local_1c98 = (undefined4 *)((ulonglong)local_1c98._4_4_ << 0x20);
      iVar11 = 1;
      lVar6 = WSASocketA(2,1,0,0);
      local_1c38 = lVar6;
      if (lVar6 == -1) {
        uVar2 = Ordinal_111();
        Ordinal_116();
        log_InlineLogERROR("CServerStatusMonitor::SocketThread(), ErrCode:%d at %s, %d",
                           (ulonglong)uVar2,
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp",
                           0x17e);
      }
      else {
        local_1c74 = 0;
        CIniFile::CIniFile(local_19d8,"StatusMonitor.ini","Setting");
        uVar2 = CIniFile::GetInt(local_19d8,"port");
        if ((int)uVar2 < 1) {
          uVar2 = 0x16e4;
        }
        local_19f8 = 2;
        local_1c74 = uVar2;
        WSAHtons(lVar6,uVar2 & 0xffff,&local_19f6);
        local_19f4 = 0;
        iVar3 = Ordinal_2(lVar6,&local_19f8,0x10);
        if (iVar3 == 0) {
          log_InlineLogMessage("Server Status Monitor Socket using port[%d].",(ulonglong)uVar2);
          iVar3 = Ordinal_13(lVar6);
          if (iVar3 == 0) {
            local_1c48 = 0;
            local_1c44 = 500;
            local_1c70 = 1;
            memset(&local_1438,0,0x1400);
            local_1438 = lVar6;
            while( true ) {
              iVar3 = FUN_14001f4c0(param_1);
              if (iVar3 != 2) break;
              local_1c50 = 0;
              alStack_1c10[0] = lVar6;
              local_1c18[0] = 1;
              uVar2 = 1;
              local_1c4c = 0;
              uVar10 = 0;
              while (iVar3 = (int)uVar10, iVar3 < iVar11) {
                local_1c5c = 0;
                uVar10 = 0;
                while ((uVar9 = (uint)uVar10, uVar9 < uVar2 &&
                       (alStack_1c10[uVar10] != (&local_1438)[(longlong)iVar3 * 10]))) {
                  local_1c5c = uVar9 + 1;
                  uVar10 = (ulonglong)local_1c5c;
                }
                if ((uVar9 == uVar2) && (uVar2 < 0x40)) {
                  alStack_1c10[uVar10] = (&local_1438)[(longlong)iVar3 * 10];
                  local_1c18[0] = local_1c18[0] + 1;
                  uVar2 = local_1c18[0];
                }
                local_1c4c = iVar3 + 1;
                uVar10 = (ulonglong)local_1c4c;
              }
              local_1c98 = &local_1c48;
              iVar3 = Ordinal_18(0,local_1c18,0,0);
              local_1c6c = iVar3;
              if (iVar3 == -1) {
                uVar2 = Ordinal_111();
                log_InlineLogMessage("Server Status Monitor select failed : %d",(ulonglong)uVar2);
                break;
              }
              if (0 < iVar3) {
                iVar4 = Ordinal_151(lVar6,local_1c18);
                if (iVar4 != 0) {
                  if (iVar11 < 0x40) {
                    local_1c54 = 0x10;
                    local_1c98 = (undefined4 *)0x0;
                    lVar6 = WSAAccept(lVar6,local_19e8,&local_1c54,0);
                    uVar1 = local_19e6;
                    (&local_1438)[(longlong)iVar11 * 10] = lVar6;
                    if (lVar6 == -1) {
                      log_InlineLogERROR("Server Status Monitor client login Error.");
                    }
                    else {
                      uVar7 = Ordinal_12(local_19e4);
                      log_InlineLogMessage
                                ("Server Status Monitor client(%s : %u) login",uVar7,
                                 (ulonglong)uVar1);
                      (&uStack_1430)[(longlong)iVar11 * 0x14] = 0;
                      iVar11 = iVar11 + 1;
                      local_1c70 = iVar11;
                    }
                  }
                  else {
                    log_InlineLogMessage("Server Status Monitor client login number overflow.");
                  }
                  iVar3 = iVar3 + -1;
                  local_1c6c = iVar3;
                }
                local_1c68 = 1;
                while ((iVar4 = local_1c68, lVar6 = local_1c38, param_1 = local_1c40, 0 < iVar3 &&
                       (local_1c68 < iVar11))) {
                  lVar8 = (longlong)local_1c68;
                  lVar6 = lVar8 * 0x50;
                  _Dst = &local_1438 + lVar8 * 10;
                  iVar5 = Ordinal_151(*_Dst,local_1c18);
                  if (iVar5 != 0) {
                    iVar3 = iVar3 + -1;
                    local_1c30[0] = 0x1f - (&uStack_1430)[lVar8 * 0x14];
                    local_1c6c = iVar3;
                    if (local_1c30[0] == 0) {
                      local_1c98 = (undefined4 *)CONCAT44(local_1c98._4_4_,0x1fb);
                      log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","WSABuff.len > 0",
                                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp"
                                        );
                    }
                    local_1c28 = auStack_142c + (int)(&uStack_1430)[lVar8 * 0x14] + lVar6;
                    local_1c78 = 0;
                    local_1c60 = 0;
                    local_1c88 = 0;
                    local_1c90 = 0;
                    local_1c98 = &local_1c60;
                    iVar5 = WSARecv(*_Dst,local_1c30,1,&local_1c78);
                    if ((iVar5 == 0) && (local_1c78 != 0)) {
                      (&uStack_1430)[lVar8 * 0x14] = (&uStack_1430)[lVar8 * 0x14] + local_1c78;
                      lVar6 = lVar6 + (int)(&uStack_1430)[lVar8 * 0x14];
                      if (*(char *)((longlong)&uStack_1430 + lVar6 + 3) == '\0') {
                        (&uStack_1430)[lVar8 * 0x14] = (&uStack_1430)[lVar8 * 0x14] + -1;
                      }
                      else {
                        auStack_142c[lVar6] = 0;
                      }
                      FUN_14002aef0(DAT_140975948,_Dst);
                    }
                    else {
                      local_1a08 = 0;
                      local_1a04 = 0;
                      local_1a00 = 0;
                      local_19fc = 0;
                      local_1c58 = 0x10;
                      iVar5 = Ordinal_5(*_Dst,&local_1a08,&local_1c58);
                      if (iVar5 == 0) {
                        uVar1 = local_1a08._2_2_;
                        uVar7 = Ordinal_12(local_1a04);
                        log_InlineLogMessage
                                  ("Server Status Monitor client(%s : %u) logout",uVar7,
                                   (ulonglong)uVar1);
                      }
                      else {
                        log_InlineLogMessage("Server Status Monitor client logout.");
                      }
                      Ordinal_22(*_Dst,2);
                      Ordinal_3(*_Dst);
                      memcpy(_Dst,local_13e8 + lVar6,(longlong)((iVar11 - iVar4) + -1) * 0x50);
                      iVar11 = iVar11 + -1;
                      iVar4 = iVar4 + -1;
                      local_1c70 = iVar11;
                    }
                  }
                  local_1c68 = iVar4 + 1;
                }
              }
            }
            Ordinal_3(lVar6);
            local_1c64 = 1;
            while (iVar3 = local_1c64, local_1c64 < iVar11) {
              lVar6 = (longlong)local_1c64;
              Ordinal_22((&local_1438)[lVar6 * 10],2);
              Ordinal_3((&local_1438)[lVar6 * 10]);
              local_1c64 = iVar3 + 1;
            }
            Ordinal_116();
            log_InlineLogMessage("Server Status Monitor SocketThread end.");
            CIniFile::~CIniFile(local_19d8);
            uVar2 = 0;
          }
          else {
            uVar2 = Ordinal_111();
            log_InlineLogMessage("Server Status Monitor listen failed : %d",(ulonglong)uVar2);
            Ordinal_3(lVar6);
            Ordinal_116();
            log_InlineLogERROR("CServerStatusMonitor::SocketThread(), ErrCode:%d at %s, %d",
                               (ulonglong)uVar2,
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp"
                               ,0x1aa);
            CIniFile::~CIniFile(local_19d8);
          }
        }
        else {
          uVar2 = Ordinal_111();
          uVar7 = Ordinal_12(local_19f4);
          log_InlineLogMessage
                    ("Server Status Monitor can not bind to (%s : %u), error : %d",uVar7,
                     (ulonglong)local_19f6,(ulonglong)uVar2);
          Ordinal_3(lVar6);
          Ordinal_116();
          log_InlineLogERROR("CServerStatusMonitor::SocketThread(), ErrCode:%d at %s, %d",
                             (ulonglong)uVar2,
                             "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp"
                             ,0x19d);
          CIniFile::~CIniFile(local_19d8);
        }
      }
    }
    else {
      log_InlineLogERROR("CServerStatusMonitor::SocketThread(), ErrCode:%d at %s, %d",
                         (ulonglong)uVar2,
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\serverstatusmonitor.cpp",
                         0x173);
    }
  }
  return uVar2;
}

// ==== CServerStatusMonitor::StartWorkerThread  @14002ba80  [high:log-string]  (orig: FUN_14002ba80)
uintptr_t FUN_14002ba80(undefined8 *param_1)

{
  uintptr_t uVar1;
  uint local_res10 [6];
  
  if (DAT_140975948 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((void *)*param_1 == (void *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  local_res10[0] = 0;
  uVar1 = _beginthreadex((void *)0x0,0,FUN_14002b2d0,(void *)*param_1,0,local_res10);
  param_1[0xd] = uVar1;
  if (uVar1 == 0) {
    log_InlineLogERROR("CServerStatusMonitor::StartWorkerThread() _beginthreadex failed at %s, %d");
    uVar1 = 0;
  }
  return uVar1;
}

