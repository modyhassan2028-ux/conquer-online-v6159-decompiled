// ==== CMsgMailContent@mail::vfunc_5  @14035c360  [high:rtti-vtable]  (orig: FUN_14035c360)
bool FUN_14035c360(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x418;
    }
  }
  return false;
}

// ==== CMsgMailContent@mail::vfunc_6  @14035c400  [high:rtti-vtable]  (orig: FUN_14035c400)
void FUN_14035c400(void)

{
  return;
}

// ==== CMsgMailContent@mail::vfunc_0  @14035c410  [high:rtti-vtable]  (orig: FUN_14035c410)
undefined8 * FUN_14035c410(undefined8 *param_1,uint param_2)

{
  *param_1 = mail::CMsgMailContent::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

