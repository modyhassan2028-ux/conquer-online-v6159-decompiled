// ==== CMsgQuench::helper_1400b3e50  @1400b3e50  [medium:callgraph-r3]  (orig: FUN_1400b3e50)
undefined8 FUN_1400b3e50(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (5 < param_3) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_1400a91c0((longlong *)(param_1 + 0x800),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x830);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x800))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_10 + 0x20);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001400b3f33. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x10))(plVar1,param_3 + 1);
      return uVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgQuench::helper_1400b4040  @1400b4040  [medium:callgraph-r3]  (orig: FUN_1400b4040)
undefined8 FUN_1400b4040(longlong param_1,undefined4 param_2,int param_3)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (5 < param_3) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_1400a91c0((longlong *)(param_1 + 0x800),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x830);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x800))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_10 + 0x20);
    if (plVar1 != (longlong *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x0001400b4123. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x18))(plVar1,param_3 + 7);
      return uVar2;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CMsgQuench::helper_1400e2430  @1400e2430  [medium:callgraph-r3]  (orig: FUN_1400e2430)
undefined4 FUN_1400e2430(void)

{
  return DAT_140975c74;
}

// ==== CMsgQuench::helper_140102030  @140102030  [medium:callgraph-r3]  (orig: FUN_140102030)
int FUN_140102030(longlong param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  ulonglong uVar9;
  int local_res8 [2];
  
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),5);
  iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),4);
  iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  if (iVar2 == 0) {
    iVar2 = 0;
  }
  else {
    uVar8 = 0;
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),8)
    ;
    local_res8[0] = (**(code **)(*plVar5 + 0x48))(plVar5);
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),9)
    ;
    local_res8[1] = (**(code **)(*plVar5 + 0x48))(plVar5);
    uVar9 = uVar8;
    do {
      iVar2 = local_res8[uVar8];
      if ((iVar2 != 0) && (iVar2 != 0xff)) {
        iVar4 = (int)uVar9;
        if (iVar2 == 0x29) {
          uVar9 = (ulonglong)(iVar4 + 0x32);
        }
        else if (iVar2 == 0x2a) {
          uVar9 = (ulonglong)(iVar4 + 100);
        }
        else if (iVar2 == 0x2b) {
          uVar9 = (ulonglong)(iVar4 + 200);
        }
      }
      iVar2 = (int)uVar9;
      uVar8 = uVar8 + 1;
    } while ((longlong)uVar8 < 2);
  }
  plVar5 = *(longlong **)(param_1 + 0x50);
  iVar1 = (iVar1 * 100) / (iVar2 + 100);
  if (plVar5 == (longlong *)0x0) {
    plVar5 = *(longlong **)(param_1 + 0x58);
  }
  if (plVar5 == (longlong *)0x0) {
LAB_14010219b:
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  else {
    uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5,3);
    plVar6 = (longlong *)FUN_140087d40();
    lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,uVar3);
    if (lVar7 == 0) goto LAB_14010219b;
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),4);
    iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
    if ((iVar2 <= iVar4) || (plVar5 == *(longlong **)(param_1 + 0x58))) goto LAB_14010219b;
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  if (iVar2 <= iVar1) {
    return 0;
  }
  plVar5 = *(longlong **)(param_1 + 0x50);
  if (plVar5 == (longlong *)0x0) {
    plVar5 = *(longlong **)(param_1 + 0x58);
  }
  if (plVar5 == (longlong *)0x0) {
LAB_14010226e:
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  else {
    uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5,3);
    plVar6 = (longlong *)FUN_140087d40();
    lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,uVar3);
    if (lVar7 == 0) goto LAB_14010226e;
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),4);
    iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
    if ((iVar2 <= iVar4) || (plVar5 == *(longlong **)(param_1 + 0x58))) goto LAB_14010226e;
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  iVar2 = iVar2 - iVar1;
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(*(longlong **)(param_1 + 0x10),1);
  iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  if (iVar1 % 10 == 8) {
    plVar5 = *(longlong **)(param_1 + 0x50);
    if (plVar5 == (longlong *)0x0) {
      plVar5 = *(longlong **)(param_1 + 0x58);
    }
    if (plVar5 != (longlong *)0x0) {
      uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5,3);
      plVar5 = (longlong *)FUN_140087d40();
      lVar7 = (**(code **)(*plVar5 + 0x70))(plVar5,uVar3);
      if (lVar7 != 0) {
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),4);
        (**(code **)(*plVar5 + 0x48))(plVar5);
        plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
        plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,4);
        (**(code **)(*plVar5 + 0x48))(plVar5);
      }
    }
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
    iVar2 = MulDiv(3500000,iVar2,iVar1);
    iVar1 = 350000;
    goto LAB_140102520;
  }
  if (iVar1 % 10 == 9) {
    plVar5 = *(longlong **)(param_1 + 0x50);
    if (plVar5 == (longlong *)0x0) {
      plVar5 = *(longlong **)(param_1 + 0x58);
    }
    if (plVar5 == (longlong *)0x0) {
LAB_14010244a:
      plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
      iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
    }
    else {
      uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5,3);
      plVar6 = (longlong *)FUN_140087d40();
      lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,uVar3);
      if (lVar7 == 0) goto LAB_14010244a;
      plVar6 = (longlong *)
               (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),4);
      iVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
      plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
      iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      if ((iVar1 <= iVar4) || (plVar5 == *(longlong **)(param_1 + 0x58))) goto LAB_14010244a;
      plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
      plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
      iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
    }
    iVar2 = MulDiv(5000000,iVar2,iVar1);
    iVar1 = 500000;
    goto LAB_140102520;
  }
  plVar5 = *(longlong **)(param_1 + 0x50);
  if (plVar5 == (longlong *)0x0) {
    plVar5 = *(longlong **)(param_1 + 0x58);
  }
  if (plVar5 == (longlong *)0x0) {
LAB_140102378:
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  else {
    uVar3 = (**(code **)(*plVar5 + 0x30))(plVar5,3);
    plVar6 = (longlong *)FUN_140087d40();
    lVar7 = (**(code **)(*plVar6 + 0x70))(plVar6,uVar3);
    if (lVar7 == 0) goto LAB_140102378;
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(lVar7 + 8) + 0x10))(*(longlong **)(lVar7 + 8),4);
    iVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
    plVar6 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
    iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
    if ((iVar1 <= iVar4) || (plVar5 == *(longlong **)(param_1 + 0x58))) goto LAB_140102378;
    plVar5 = *(longlong **)(*(longlong *)(param_1 + 0x18) + 8);
    plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x16);
    iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  }
  iVar2 = MulDiv(1500000,iVar2,iVar1);
  iVar1 = 150000;
LAB_140102520:
  if (iVar1 < iVar2) {
    iVar1 = iVar2;
  }
  if (iVar1 < 1) {
    iVar1 = 1;
  }
  return iVar1;
}

// ==== CMsgQuench::helper_1401184a0  @1401184a0  [medium:callgraph-r2]  (orig: FUN_1401184a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401184a0(undefined8 param_1,char *param_2,char *param_3,int param_4)

{
  char cVar1;
  bool bVar2;
  char *pcVar3;
  IStringManager *pIVar4;
  longlong lVar5;
  ulonglong uVar6;
  uint uVar7;
  uint uVar8;
  undefined1 auStack_458 [32];
  undefined4 local_438;
  char local_428 [1024];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  if ((param_2 == (char *)0x0) || (param_3 == (char *)0x0)) {
    log_InlineLogACTION_ERROR("ReplaceParamStr()");
  }
  else {
    pcVar3 = strchr(param_3,0x40);
    if (pcVar3 == (char *)0x0) {
      tq::SafeCopy(param_2,param_3,(longlong)param_4);
    }
    else {
      uVar8 = 0;
      if (*param_3 == '\0') {
LAB_140118656:
        *param_2 = '\0';
      }
      else {
        do {
          uVar8 = uVar8 + 1;
          if (1000000 < uVar8) {
            local_438 = 0x5c;
            log_InlineLogERROR(&DAT_1406d9c10);
            goto LAB_140118656;
          }
          local_428[0] = '\0';
          memset(local_428 + 1,0,0x3ff);
          cVar1 = *param_3;
          uVar7 = 0;
          while( true ) {
            if (cVar1 == '\0') {
              return;
            }
            if (cVar1 == '@') goto LAB_1401185a9;
            uVar7 = uVar7 + 1;
            if (1000000 < uVar7) break;
            param_3 = param_3 + 1;
            *param_2 = cVar1;
            param_2 = param_2 + 1;
            cVar1 = *param_3;
          }
          local_438 = 0x61;
          log_InlineLogERROR(&DAT_1406d9c10);
LAB_1401185a9:
          if (*param_3 == '\0') {
            return;
          }
          param_3 = param_3 + 1;
          lVar5 = 0;
          do {
            cVar1 = *param_3;
            if ((cVar1 == '\0') || (cVar1 == '@')) break;
            local_428[lVar5] = cVar1;
            lVar5 = lVar5 + 1;
            param_3 = param_3 + 1;
          } while (lVar5 < 0x400);
          local_428[0x3ff] = 0;
          pIVar4 = theInstance();
          pcVar3 = (char *)(*(code *)**(undefined8 **)pIVar4)(pIVar4,local_428);
          bVar2 = tq::SafeCopy(param_2,pcVar3,0x3bf);
          if (!bVar2) {
            return;
          }
          uVar6 = 0xffffffffffffffff;
          param_3 = param_3 + 1;
          do {
            if (uVar6 == 0) break;
            uVar6 = uVar6 - 1;
            cVar1 = *pcVar3;
            pcVar3 = pcVar3 + 1;
          } while (cVar1 != '\0');
          param_2 = param_2 + (~uVar6 - 1);
        } while (*param_3 != '\0');
        *param_2 = '\0';
      }
    }
  }
  return;
}

// ==== CMsgQuench::helper_14011b910  @14011b910  [medium:callgraph-r2]  (orig: FUN_14011b910)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

undefined8
FUN_14011b910(longlong param_1,undefined8 *param_2,char *param_3,longlong *param_4,
             undefined4 param_5,undefined4 param_6)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  __time32_t _Var6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong lVar12;
  char *pcVar13;
  undefined1 auStack_138 [32];
  undefined4 *local_118;
  undefined4 *local_110;
  uint *local_108;
  uint *local_100;
  uint *local_f8;
  undefined4 *local_f0;
  uint local_e8 [4];
  uint local_d8 [4];
  undefined4 local_c8;
  undefined4 local_c4;
  undefined4 local_c0;
  undefined4 local_bc;
  undefined4 local_b8;
  undefined4 local_b0;
  undefined4 local_ac;
  undefined4 local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined4 local_98;
  int local_94;
  undefined4 local_90;
  undefined4 local_88;
  undefined4 local_84;
  undefined4 local_80;
  undefined4 local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  char local_60 [16];
  ulonglong local_50;
  
  local_50 = DAT_1409707c0 ^ (ulonglong)auStack_138;
  if (param_2 == (undefined8 *)0x0) {
    local_118 = (undefined4 *)CONCAT44(local_118._4_4_,0x37d7);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_4 == (longlong *)0x0) {
    plVar8 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,3);
    (**(code **)(*plVar8 + 0x48))(plVar8);
    plVar8 = (longlong *)
             (**(code **)(*(longlong *)*param_2 + 0x20))((longlong *)*param_2,&DAT_14094da3c);
    (**(code **)(*plVar8 + 0x40))(plVar8);
    local_118 = (undefined4 *)CONCAT44(local_118._4_4_,0x37db);
    log_InlineLogDBERROR
              (
              "table:cq_action/cq_newaction, CGameAction::ProcessActionItemQuench() ActionID=%u, ActionType=%u at %s, %d"
              );
  }
  else {
    plVar8 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,3);
    iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
    if (iVar3 == 0x214) {
      plVar8 = (longlong *)FUN_140087d40();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_5);
      plVar9 = (longlong *)FUN_140087d40();
      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x60))(plVar9,param_6);
      if ((plVar8 != (longlong *)0x0) && (plVar9 != (longlong *)0x0)) {
        uVar4 = FUN_1400fda10(plVar8,1,1);
        cVar2 = FUN_1400ff940(uVar4);
        if ((cVar2 != '\0') && (cVar2 = FUN_1400ffc20(plVar9), cVar2 == '\0')) {
          lVar12 = 0;
          local_d8[1] = 0;
          local_d8[2] = 0;
          local_f0 = &local_bc;
          local_f8 = local_d8 + 2;
          local_100 = local_d8 + 1;
          local_108 = local_d8;
          local_110 = &local_c8;
          local_b8 = 0;
          local_118 = &local_c0;
          local_c4 = 0;
          local_bc = 0;
          local_c0 = 0;
          local_c8 = 0;
          local_d8[0] = 0;
          iVar3 = sscanf(param_3,"%d %d %d %d %d %d %d %d");
          if (6 < iVar3) {
            uVar5 = FUN_1400fda10(plVar8,1,1);
            local_e8[0] = 0;
            local_e8[1] = 0;
            local_e8[2] = 0;
            do {
              if (*(int *)((longlong)local_d8 + lVar12) == 0) {
                *(undefined4 *)((longlong)local_e8 + lVar12) = 0xffffffff;
              }
              else {
                local_60[0] = '\0';
                local_60[1] = '\0';
                local_60[2] = '\0';
                local_60[3] = '\0';
                local_60[4] = '\0';
                local_60[5] = '\0';
                local_60[6] = '\0';
                local_60[7] = '\0';
                local_60[8] = '\0';
                local_60[9] = '\0';
                _itoa(*(int *)((longlong)local_d8 + lVar12),local_60,10);
                lVar11 = -1;
                pcVar13 = local_60;
                do {
                  if (lVar11 == 0) break;
                  lVar11 = lVar11 + -1;
                  cVar2 = *pcVar13;
                  pcVar13 = pcVar13 + 1;
                } while (cVar2 != '\0');
                if (lVar11 == -3) {
                  *(uint *)((longlong)local_e8 + lVar12) = uVar5 / 100000;
                }
                else if (lVar11 == -4) {
                  *(uint *)((longlong)local_e8 + lVar12) = uVar5 / 10000;
                }
                else if (lVar11 == -5) {
                  *(uint *)((longlong)local_e8 + lVar12) = uVar5 / 1000;
                }
                else {
                  *(undefined4 *)((longlong)local_e8 + lVar12) = 0xffffffff;
                }
              }
              lVar12 = lVar12 + 4;
              if (0xb < lVar12) {
                if ((((local_d8[0] == local_e8[0]) || (local_d8[1] == local_e8[1])) ||
                    (local_d8[2] == local_e8[2])) ||
                   (((local_d8[0] == 0 && (local_d8[1] == 0)) && (local_d8[2] == 0)))) {
                  local_88 = 0;
                  local_84 = (**(code **)(*plVar8 + 8))(plVar8);
                  local_80 = (**(code **)(*param_4 + 8))(param_4);
                  plVar10 = (longlong *)
                            (**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,4);
                  local_7c = (**(code **)(*plVar10 + 0x48))(plVar10);
                  local_78 = local_b8;
                  local_74 = local_c4;
                  local_70 = local_bc;
                  local_68 = local_c0;
                  local_6c = local_c8;
                  uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                  cVar2 = FUN_140340190(param_4,uVar4,1,1);
                  if (cVar2 != '\0') {
                    plVar9 = (longlong *)FUN_140100070(plVar8);
                    bVar1 = false;
                    if (plVar9 != (longlong *)0x0) {
                      local_b0 = 0;
                      bVar1 = true;
                      local_ac = (**(code **)*plVar9)(plVar9);
                      local_a8 = (**(code **)(**(longlong **)(param_1 + 8) + 8))();
                      local_a4 = (**(code **)(*plVar9 + 0x30))(plVar9,3);
                      local_a0 = (**(code **)(*plVar9 + 0x30))(plVar9,4);
                      local_9c = (**(code **)(*plVar9 + 0x10))(plVar9);
                      local_98 = (**(code **)(*plVar9 + 0x18))(plVar9);
                      local_90 = (**(code **)(*plVar9 + 0x30))(plVar9,8);
                      iVar3 = (**(code **)(*plVar9 + 0x30))(plVar9,7);
                      if (iVar3 == 0) {
                        local_94 = 0;
                      }
                      else {
                        iVar3 = (**(code **)(*plVar9 + 0x30))(plVar9,7);
                        _Var6 = _time32((__time32_t *)0x0);
                        local_94 = iVar3 - _Var6;
                        if (local_94 == 0) {
                          bVar1 = false;
                        }
                      }
                      uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                      FUN_1401ad8d0(param_4,uVar4);
                      FUN_140100090(plVar8,0);
                    }
                    uVar4 = FUN_1401649c0(param_4);
                    cVar2 = FUN_140102a10(plVar8,&local_88,uVar4,0);
                    if (cVar2 != '\0') {
                      uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                      FUN_140166590(param_4,uVar4,local_7c);
                      if (!bVar1) {
                        uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                        (**(code **)(*param_4 + 8))(param_4);
                        (**(code **)(param_4[2] + 0x18))(param_4 + 2);
                        local_110 = (undefined4 *)CONCAT44(local_110._4_4_,local_7c);
                        local_118 = (undefined4 *)CONCAT44(local_118._4_4_,uVar4);
                        tq::MyLogSave("gmlog/QuenchItem",
                                      "%s(%u) Add Temp ItemStatu[itemid=%u, itemstatu=%u]");
                        return 1;
                      }
                      uVar4 = FUN_1400fda10(plVar8,1,1);
                      uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
                      (**(code **)(*param_4 + 8))(param_4);
                      (**(code **)(param_4[2] + 0x18))(param_4 + 2);
                      local_110 = (undefined4 *)CONCAT44(local_110._4_4_,uVar4);
                      local_118 = (undefined4 *)CONCAT44(local_118._4_4_,uVar7);
                      tq::MyLogSave("gmlog/QuenchItem",
                                    "%s(%u) Erase Temp Item Statu [id=%u, type=%u]");
                      return 1;
                    }
                    if (bVar1) {
                      FUN_140102a10(plVar8,&local_b0,0,0);
                      uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
                      FUN_140166590(param_4,uVar4,local_a4);
                    }
                  }
                }
                return 0;
              }
            } while( true );
          }
          plVar8 = (longlong *)
                   (**(code **)(*(longlong *)*param_2 + 0x20))((longlong *)*param_2,&DAT_14094da3c);
          (**(code **)(*plVar8 + 0x40))(plVar8);
          log_InlineLogDBERROR(&DAT_14070c010);
        }
      }
    }
    else {
      plVar8 = (longlong *)(**(code **)(*(longlong *)*param_2 + 0x10))((longlong *)*param_2,3);
      (**(code **)(*plVar8 + 0x48))(plVar8);
      plVar8 = (longlong *)
               (**(code **)(*(longlong *)*param_2 + 0x20))((longlong *)*param_2,&DAT_14094da3c);
      (**(code **)(*plVar8 + 0x40))(plVar8);
      log_InlineLogDBERROR(&DAT_14070c140);
    }
  }
  return 0;
}

// ==== CMsgQuench::helper_14011e970  @14011e970  [medium:callgraph-r3]  (orig: FUN_14011e970)
ulonglong FUN_14011e970(longlong *param_1)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  
  uVar1 = param_1[4];
  if (uVar1 < (ulonglong)param_1[3]) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  lVar3 = 0;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar2 = lVar3;
  }
  else {
    lVar2 = *param_1;
  }
  uVar1 = uVar1 - 4;
  if (uVar1 <= *(ulonglong *)(lVar2 + 0x20)) {
    lVar2 = lVar3;
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14011e9e7;
  }
  _invalid_parameter_noinfo();
LAB_14011e9e7:
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar3 = *param_1;
  }
  if (*(ulonglong *)(lVar3 + 0x20) <= uVar1) {
    _invalid_parameter_noinfo();
  }
  return uVar1;
}

// ==== CMsgQuench::helper_14011efb0  @14011efb0  [medium:callgraph-r2]  (orig: FUN_14011efb0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14011efb0(longlong param_1,char *param_2,char *param_3,int param_4,char *param_5,
                  longlong *param_6,longlong *param_7,int param_8)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  longlong *plVar8;
  char *pcVar9;
  char *pcVar10;
  undefined8 uVar11;
  tm *ptVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  undefined4 *puVar16;
  IStringManager *pIVar17;
  char *pcVar18;
  longlong lVar19;
  ulonglong uVar20;
  int iVar21;
  undefined1 auStack_4718 [32];
  undefined8 local_46f8;
  undefined4 *local_46f0;
  undefined4 local_46e8;
  undefined4 local_46e0;
  longlong local_46d8;
  int local_46d0;
  undefined4 local_46cc;
  undefined4 local_46c8;
  undefined4 local_46c4;
  undefined4 local_46c0;
  undefined4 local_46bc;
  undefined4 local_46b8;
  undefined4 local_46b4;
  undefined4 local_46b0;
  undefined4 local_46ac;
  undefined4 local_46a8;
  int local_46a4;
  undefined4 local_46a0;
  char *local_4698;
  longlong *local_4690;
  longlong local_4688;
  undefined4 local_4680;
  undefined4 local_467c;
  undefined4 local_4678;
  undefined4 local_4674;
  int local_4670;
  int local_466c;
  uint local_4668;
  char *local_4660;
  undefined2 local_4658;
  undefined1 local_4656 [253];
  undefined1 local_4559;
  undefined2 local_4558;
  undefined1 local_4556;
  undefined1 local_4555 [252];
  undefined1 local_4459;
  char local_4458 [255];
  undefined1 local_4359;
  undefined2 local_4358;
  undefined1 local_4356;
  undefined1 local_4355 [252];
  undefined1 local_4259;
  undefined2 local_4258;
  undefined1 local_4256;
  undefined1 local_4255 [252];
  undefined1 local_4159;
  undefined2 local_4158;
  undefined1 local_4156;
  undefined1 local_4155 [252];
  undefined1 local_4059;
  undefined2 local_4058;
  undefined1 local_4056;
  undefined1 local_4055 [252];
  undefined1 local_3f59;
  undefined2 local_3f58;
  undefined1 local_3f56;
  undefined1 local_3f55 [252];
  undefined1 local_3e59;
  char local_3e58 [255];
  undefined1 local_3d59;
  undefined2 local_3d58;
  undefined1 local_3d56;
  undefined1 local_3d55 [252];
  undefined1 local_3c59;
  char local_3c58 [255];
  undefined1 local_3b59;
  char local_3b58 [256];
  char local_3a58 [256];
  char local_3958 [256];
  char local_3858 [255];
  undefined1 local_3759;
  undefined2 local_3758;
  undefined1 local_3756 [253];
  undefined1 local_3659;
  char local_3658 [255];
  undefined1 local_3559;
  undefined2 local_3558;
  undefined1 local_3556 [253];
  undefined1 local_3459;
  char local_3458 [256];
  char local_3358 [255];
  undefined1 local_3259;
  undefined2 local_3258;
  undefined1 local_3256;
  undefined1 local_3255 [252];
  undefined1 local_3159;
  undefined2 local_3158;
  undefined1 local_3156 [253];
  undefined1 local_3059;
  char local_3058 [256];
  char local_2f58 [255];
  undefined1 local_2e59;
  char local_2e58 [255];
  undefined1 local_2d59;
  char local_2d58 [255];
  undefined1 local_2c59;
  char local_2c58 [256];
  char local_2b58 [256];
  char local_2a58 [256];
  char local_2958 [256];
  char local_2858 [256];
  char local_2758 [256];
  char local_2658 [256];
  char local_2558 [256];
  char local_2458 [256];
  char local_2358 [256];
  char local_2258 [256];
  char local_2158 [256];
  char local_2058 [256];
  char local_1f58 [256];
  char local_1e58 [256];
  char local_1d58 [256];
  char local_1c58 [256];
  char local_1b58 [256];
  char local_1a58 [256];
  char local_1958 [256];
  char local_1858 [256];
  undefined2 local_1758;
  undefined1 local_1756;
  undefined1 local_1755 [253];
  char local_1658 [256];
  char local_1558 [256];
  char local_1458 [256];
  char local_1358 [256];
  char local_1258 [256];
  char local_1158 [256];
  char local_1058 [256];
  char local_f58 [256];
  char local_e58 [256];
  char local_d58 [256];
  char local_c58 [256];
  char local_b58 [256];
  char local_a58 [256];
  char local_958 [256];
  char local_858 [256];
  char local_758 [256];
  char local_658 [256];
  char local_558 [256];
  undefined1 local_458;
  undefined1 local_457 [255];
  undefined1 local_358;
  undefined1 local_357 [255];
  undefined1 local_258;
  undefined1 local_257 [255];
  undefined1 local_158;
  undefined1 local_157 [255];
  ulonglong local_58;
  
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_4718;
  local_4698 = param_5;
  local_4690 = param_6;
  local_4688 = param_1;
  plVar8 = (longlong *)FUN_140087ed0();
  local_4670 = (**(code **)(*plVar8 + 0x1d0))(plVar8);
  plVar8 = (longlong *)FUN_140087ed0();
  local_466c = (**(code **)(*plVar8 + 0x1d8))(plVar8);
  if ((param_2 == (char *)0x0) || (param_3 == (char *)0x0)) {
    local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0x92);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    pcVar9 = strchr(param_3,0x25);
    if (pcVar9 == (char *)0x0) {
      tq::SafeCopy(param_2,param_3,(longlong)param_4);
    }
    else {
      local_46d8 = 0;
      if (param_7 != (longlong *)0x0) {
        (**(code **)(*param_7 + 0x298))(param_7,0x1040,&local_46d8);
      }
      local_4668 = 0;
      cVar1 = *param_3;
      while (cVar1 != '\0') {
        local_4668 = local_4668 + 1;
        if (1000000 < local_4668) {
          local_46f8._4_4_ = (undefined4)((ulonglong)local_46f8 >> 0x20);
          local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0xa5);
          log_InlineLogERROR(&DAT_1406d9c10);
          break;
        }
        if (*param_3 == '%') {
          pcVar9 = param_3 + 1;
          local_46d0 = 0;
          iVar2 = isdigit((int)param_3[1]);
          iVar21 = 0;
          if (iVar2 != 0) {
            local_46d0 = *pcVar9 + -0x30;
            pcVar9 = param_3 + 2;
            iVar21 = local_46d0;
          }
          iVar2 = isdigit((int)*pcVar9);
          if (iVar2 != 0) {
            cVar1 = *pcVar9;
            pcVar9 = pcVar9 + 1;
            local_46d0 = cVar1 + -0x30 + iVar21 * 10;
            iVar21 = local_46d0;
          }
          local_4660 = param_2 + iVar21;
          if (*pcVar9 == '%') {
            *param_2 = '%';
            pcVar9 = pcVar9 + 2;
            param_2 = param_2 + 1;
          }
          pcVar10 = strstr(pcVar9,"sysdata(");
          if ((pcVar10 == (char *)0x0) || (pcVar10 = strstr(pcVar9,")"), pcVar10 == (char *)0x0)) {
            pcVar10 = strstr(pcVar9,"sysdatastr(");
            if ((pcVar10 == (char *)0x0) || (pcVar10 = strstr(pcVar9,")"), pcVar10 == (char *)0x0))
            {
              pcVar10 = strstr(pcVar9,"taskdata(");
              if ((pcVar10 != (char *)0x0) && (pcVar10 = strstr(pcVar9,")"), pcVar10 != (char *)0x0)
                 ) {
                local_46bc = 0;
                local_46a0 = 0;
                sscanf(pcVar9,"taskdata(%u, %d)");
                if (param_6 != (longlong *)0x0) {
                  plVar8 = (longlong *)FUN_140118220();
                  lVar19 = *plVar8;
                  uVar3 = (**(code **)(*param_6 + 8))(param_6);
                  (**(code **)(lVar19 + 0x38))(plVar8,uVar3,local_46bc,local_46a0);
                }
                local_3858[0] = '\0';
                memset(local_3858 + 1,0,0xff);
                _snprintf(local_3858,0x100,"%d");
                local_3759 = 0;
                pcVar10 = local_3858;
                do {
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                  pcVar10[(longlong)(param_2 + (-1 - (longlong)local_3858))] = cVar1;
                } while (cVar1 != '\0');
                pcVar9 = strstr(pcVar9,")");
                uVar20 = 0xffffffffffffffff;
                pcVar9 = pcVar9 + 1;
                pcVar10 = local_3858;
                do {
                  if (uVar20 == 0) break;
                  uVar20 = uVar20 - 1;
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                param_2 = param_2 + (~uVar20 - 1);
              }
            }
            else {
              local_46a8 = 0;
              local_46c4 = 0;
              sscanf(pcVar9,"sysdatastr(%u, %d)");
              uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
              FUN_1400b4040(uVar11,local_46a8,local_46c4);
              local_4458[0] = '\0';
              memset(local_4458 + 1,0,0xff);
              _snprintf(local_4458,0x100,"%s");
              local_4359 = 0;
              pcVar10 = local_4458;
              do {
                cVar1 = *pcVar10;
                pcVar10 = pcVar10 + 1;
                pcVar10[(longlong)(param_2 + (-1 - (longlong)local_4458))] = cVar1;
              } while (cVar1 != '\0');
              pcVar9 = strstr(pcVar9,")");
              uVar20 = 0xffffffffffffffff;
              pcVar9 = pcVar9 + 1;
              pcVar10 = local_4458;
              do {
                if (uVar20 == 0) break;
                uVar20 = uVar20 - 1;
                cVar1 = *pcVar10;
                pcVar10 = pcVar10 + 1;
              } while (cVar1 != '\0');
              param_2 = param_2 + (~uVar20 - 1);
            }
          }
          else {
            local_46b4 = 0;
            local_46b8 = 0;
            sscanf(pcVar9,"sysdata(%u, %d)");
            uVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x48));
            FUN_1400b3e50(uVar11,local_46b4,local_46b8);
            local_3358[0] = '\0';
            memset(local_3358 + 1,0,0xff);
            _snprintf(local_3358,0x100,"%d");
            local_3259 = 0;
            pcVar10 = local_3358;
            do {
              cVar1 = *pcVar10;
              pcVar10 = pcVar10 + 1;
              pcVar10[(longlong)(param_2 + (-1 - (longlong)local_3358))] = cVar1;
            } while (cVar1 != '\0');
            pcVar9 = strstr(pcVar9,")");
            uVar20 = 0xffffffffffffffff;
            pcVar9 = pcVar9 + 1;
            pcVar10 = local_3358;
            do {
              if (uVar20 == 0) break;
              uVar20 = uVar20 - 1;
              cVar1 = *pcVar10;
              pcVar10 = pcVar10 + 1;
            } while (cVar1 != '\0');
            param_2 = param_2 + (~uVar20 - 1);
          }
          if (param_6 != (longlong *)0x0) {
            iVar2 = _strnicmp(pcVar9,"iter_emoney",0xb);
            if (iVar2 == 0) {
              local_558[0] = '\0';
              memset(local_558 + 1,0,0xff);
              _snprintf(local_558,0xff,"%u");
              pcVar10 = local_558;
              do {
                cVar1 = *pcVar10;
                pcVar10 = pcVar10 + 1;
                pcVar10[(longlong)(param_2 + (-1 - (longlong)local_558))] = cVar1;
              } while (cVar1 != '\0');
              uVar20 = 0xffffffffffffffff;
              pcVar10 = local_558;
              do {
                if (uVar20 == 0) break;
                uVar20 = uVar20 - 1;
                cVar1 = *pcVar10;
                pcVar10 = pcVar10 + 1;
              } while (cVar1 != '\0');
              pcVar9 = pcVar9 + 0xb;
              param_2 = param_2 + (~uVar20 - 1);
            }
            else {
              iVar2 = _strnicmp(pcVar9,"iter_blesstime",0xe);
              if (iVar2 == 0) {
                local_1758 = DAT_14070cec4;
                local_1756 = DAT_14070cec6;
                memset(local_1755,0,0xfd);
                FUN_140382a40(param_6,&local_1758);
                pcVar10 = (char *)&local_1758;
                do {
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                  pcVar10[(longlong)(param_2 + (-1 - (longlong)&local_1758))] = cVar1;
                } while (cVar1 != '\0');
                uVar20 = 0xffffffffffffffff;
                pcVar10 = (char *)&local_1758;
                do {
                  if (uVar20 == 0) break;
                  uVar20 = uVar20 - 1;
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                pcVar9 = pcVar9 + 0xe;
                param_2 = param_2 + (~uVar20 - 1);
              }
              else {
                pcVar10 = strstr(pcVar9,"emoney_card1(");
                if ((pcVar10 == (char *)0x0) ||
                   (pcVar10 = strstr(pcVar9,")"), pcVar10 == (char *)0x0)) {
                  iVar2 = _strnicmp(pcVar9,"emoney_card2",0xc);
                  if (iVar2 == 0) {
                    local_2958[0] = '\0';
                    memset(local_2958 + 1,0,0xff);
                    FUN_1401749c0(param_6);
                    _snprintf(local_2958,0xff,"%d");
                    pcVar10 = local_2958;
                    do {
                      cVar1 = *pcVar10;
                      pcVar10 = pcVar10 + 1;
                      pcVar10[(longlong)(param_2 + (-1 - (longlong)local_2958))] = cVar1;
                    } while (cVar1 != '\0');
                    uVar20 = 0xffffffffffffffff;
                    pcVar10 = local_2958;
                    do {
                      if (uVar20 == 0) break;
                      uVar20 = uVar20 - 1;
                      cVar1 = *pcVar10;
                      pcVar10 = pcVar10 + 1;
                    } while (cVar1 != '\0');
                    pcVar9 = pcVar9 + 0xc;
                    param_2 = param_2 + (~uVar20 - 1);
                  }
                  else {
                    iVar2 = _strnicmp(pcVar9,"emoney_card3",0xc);
                    if (iVar2 == 0) {
                      local_3258 = DAT_14070cec4;
                      local_3256 = DAT_14070cec6;
                      memset(local_3255,0,0xfd);
                      FUN_140174b80(param_6);
                      _snprintf((char *)&local_3258,0x100,"%d");
                      local_3159 = 0;
                      pcVar10 = (char *)&local_3258;
                      do {
                        cVar1 = *pcVar10;
                        pcVar10 = pcVar10 + 1;
                        pcVar10[(longlong)(param_2 + (-1 - (longlong)&local_3258))] = cVar1;
                      } while (cVar1 != '\0');
                      uVar20 = 0xffffffffffffffff;
                      pcVar10 = (char *)&local_3258;
                      do {
                        if (uVar20 == 0) break;
                        uVar20 = uVar20 - 1;
                        cVar1 = *pcVar10;
                        pcVar10 = pcVar10 + 1;
                      } while (cVar1 != '\0');
                      pcVar9 = pcVar9 + 0xc;
                      param_2 = param_2 + (~uVar20 - 1);
                    }
                    else {
                      iVar2 = _strnicmp(pcVar9,"emoney_card4",0xc);
                      if (iVar2 == 0) {
                        local_4058 = DAT_14070cec4;
                        local_4056 = DAT_14070cec6;
                        memset(local_4055,0,0xfd);
                        FUN_140174d40(param_6);
                        _snprintf((char *)&local_4058,0x100,"%d");
                        local_3f59 = 0;
                        pcVar10 = (char *)&local_4058;
                        do {
                          cVar1 = *pcVar10;
                          pcVar10 = pcVar10 + 1;
                          pcVar10[(longlong)(param_2 + (-1 - (longlong)&local_4058))] = cVar1;
                        } while (cVar1 != '\0');
                        uVar20 = 0xffffffffffffffff;
                        pcVar10 = (char *)&local_4058;
                        do {
                          if (uVar20 == 0) break;
                          uVar20 = uVar20 - 1;
                          cVar1 = *pcVar10;
                          pcVar10 = pcVar10 + 1;
                        } while (cVar1 != '\0');
                        pcVar9 = pcVar9 + 0xc;
                        param_2 = param_2 + (~uVar20 - 1);
                      }
                      else {
                        iVar2 = _strnicmp(pcVar9,"dragon_type1",0xc);
                        if (iVar2 == 0) {
                          local_3658[0] = '\0';
                          memset(local_3658 + 1,0,0xff);
                          FUN_140175200(param_6,1);
                          _snprintf(local_3658,0x100,"%d");
                          local_3559 = 0;
                          pcVar10 = local_3658;
                          do {
                            cVar1 = *pcVar10;
                            pcVar10 = pcVar10 + 1;
                            pcVar10[(longlong)(param_2 + (-1 - (longlong)local_3658))] = cVar1;
                          } while (cVar1 != '\0');
                          uVar20 = 0xffffffffffffffff;
                          pcVar10 = local_3658;
                          do {
                            if (uVar20 == 0) break;
                            uVar20 = uVar20 - 1;
                            cVar1 = *pcVar10;
                            pcVar10 = pcVar10 + 1;
                          } while (cVar1 != '\0');
                          pcVar9 = pcVar9 + 0xc;
                          param_2 = param_2 + (~uVar20 - 1);
                        }
                        else {
                          iVar2 = _strnicmp(pcVar9,"dragon_type2",0xc);
                          if (iVar2 == 0) {
                            local_3e58[0] = '\0';
                            memset(local_3e58 + 1,0,0xff);
                            FUN_140175200(param_6,2);
                            _snprintf(local_3e58,0x100,"%d");
                            local_3d59 = 0;
                            pcVar10 = local_3e58;
                            do {
                              cVar1 = *pcVar10;
                              pcVar10[(longlong)param_2 - (longlong)local_3e58] = cVar1;
                              pcVar10 = pcVar10 + 1;
                            } while (cVar1 != '\0');
                            uVar20 = 0xffffffffffffffff;
                            pcVar10 = local_3e58;
                            do {
                              if (uVar20 == 0) break;
                              uVar20 = uVar20 - 1;
                              cVar1 = *pcVar10;
                              pcVar10 = pcVar10 + 1;
                            } while (cVar1 != '\0');
                            pcVar9 = pcVar9 + 0xc;
                            param_2 = param_2 + (~uVar20 - 1);
                          }
                          else {
                            iVar2 = _strnicmp(pcVar9,"levelup_exp",0xb);
                            if (iVar2 == 0) {
                              local_2e58[0] = '\0';
                              memset(local_2e58 + 1,0,0xff);
                              FUN_14016e130(param_6);
                              _snprintf(local_2e58,0x100,"%I64d");
                              local_2d59 = 0;
                              pcVar10 = local_2e58;
                              do {
                                cVar1 = *pcVar10;
                                pcVar10[(longlong)param_2 - (longlong)local_2e58] = cVar1;
                                pcVar10 = pcVar10 + 1;
                              } while (cVar1 != '\0');
                              uVar20 = 0xffffffffffffffff;
                              pcVar10 = local_2e58;
                              do {
                                if (uVar20 == 0) break;
                                uVar20 = uVar20 - 1;
                                cVar1 = *pcVar10;
                                pcVar10 = pcVar10 + 1;
                              } while (cVar1 != '\0');
                              pcVar9 = pcVar9 + 0xb;
                              param_2 = param_2 + (~uVar20 - 1);
                            }
                            else {
                              iVar2 = _strnicmp(pcVar9,"businessman_days",0x10);
                              if (iVar2 == 0) {
                                local_3c58[0] = '\0';
                                memset(local_3c58 + 1,0,0xff);
                                FUN_140176110(param_6);
                                _snprintf(local_3c58,0x100,"%d");
                                local_3b59 = 0;
                                pcVar10 = local_3c58;
                                do {
                                  cVar1 = *pcVar10;
                                  pcVar10[(longlong)param_2 - (longlong)local_3c58] = cVar1;
                                  pcVar10 = pcVar10 + 1;
                                } while (cVar1 != '\0');
                                uVar20 = 0xffffffffffffffff;
                                pcVar10 = local_3c58;
                                do {
                                  if (uVar20 == 0) break;
                                  uVar20 = uVar20 - 1;
                                  cVar1 = *pcVar10;
                                  pcVar10 = pcVar10 + 1;
                                } while (cVar1 != '\0');
                                pcVar9 = pcVar9 + 0x10;
                                param_2 = param_2 + (~uVar20 - 1);
                              }
                              else {
                                iVar2 = _strnicmp(pcVar9,"iter_time",9);
                                if (iVar2 == 0) {
                                  local_46a4 = iVar2;
                                  _time32(&local_46a4);
                                  ptVar12 = _localtime32(&local_46a4);
                                  if (ptVar12 == (tm *)0x0) {
                                    return;
                                  }
                                  local_d58[0] = '\0';
                                  memset(local_d58 + 1,0,0xff);
                                  _snprintf(local_d58,0xff,"%u");
                                  pcVar10 = local_d58;
                                  do {
                                    cVar1 = *pcVar10;
                                    pcVar10[(longlong)param_2 - (longlong)local_d58] = cVar1;
                                    pcVar10 = pcVar10 + 1;
                                  } while (cVar1 != '\0');
                                  uVar20 = 0xffffffffffffffff;
                                  pcVar10 = local_d58;
                                  do {
                                    if (uVar20 == 0) break;
                                    uVar20 = uVar20 - 1;
                                    cVar1 = *pcVar10;
                                    pcVar10 = pcVar10 + 1;
                                  } while (cVar1 != '\0');
                                  pcVar9 = pcVar9 + 9;
                                  param_2 = param_2 + (~uVar20 - 1);
                                }
                                else {
                                  iVar2 = _strnicmp(pcVar9,"user_lev",8);
                                  if (iVar2 == 0) {
                                    local_2758[0] = '\0';
                                    memset(local_2758 + 1,0,0xff);
                                    (**(code **)(param_6[2] + 0x70))(param_6 + 2);
                                    _snprintf(local_2758,0xff,"%d");
                                    pcVar10 = local_2758;
                                    do {
                                      cVar1 = *pcVar10;
                                      pcVar10[(longlong)param_2 - (longlong)local_2758] = cVar1;
                                      pcVar10 = pcVar10 + 1;
                                    } while (cVar1 != '\0');
                                    uVar20 = 0xffffffffffffffff;
                                    pcVar10 = local_2758;
                                    do {
                                      if (uVar20 == 0) break;
                                      uVar20 = uVar20 - 1;
                                      cVar1 = *pcVar10;
                                      pcVar10 = pcVar10 + 1;
                                    } while (cVar1 != '\0');
                                    pcVar9 = pcVar9 + 8;
                                    param_2 = param_2 + (~uVar20 - 1);
                                  }
                                  else {
                                    iVar2 = _strnicmp(pcVar9,"user_sex",8);
                                    if (iVar2 == 0) {
                                      local_1558[0] = '\0';
                                      memset(local_1558 + 1,0,0xff);
                                      (**(code **)(*param_6 + 0x50))(param_6);
                                      _snprintf(local_1558,0xff,"%d");
                                      pcVar10 = local_1558;
                                      do {
                                        cVar1 = *pcVar10;
                                        pcVar10[(longlong)param_2 - (longlong)local_1558] = cVar1;
                                        pcVar10 = pcVar10 + 1;
                                      } while (cVar1 != '\0');
                                      uVar20 = 0xffffffffffffffff;
                                      pcVar10 = local_1558;
                                      do {
                                        if (uVar20 == 0) break;
                                        uVar20 = uVar20 - 1;
                                        cVar1 = *pcVar10;
                                        pcVar10 = pcVar10 + 1;
                                      } while (cVar1 != '\0');
                                      pcVar9 = pcVar9 + 8;
                                      param_2 = param_2 + (~uVar20 - 1);
                                    }
                                    else {
                                      iVar2 = _strnicmp(pcVar9,"user_team",9);
                                      if (iVar2 == 0) {
                                        plVar8 = (longlong *)FUN_140118320();
                                        if (plVar8 != (longlong *)0x0) {
                                          lVar19 = *plVar8;
                                          uVar3 = (**(code **)(*param_6 + 8))(param_6);
                                          iVar2 = (**(code **)(lVar19 + 0x28))(plVar8,uVar3);
                                          if (iVar2 != 0) {
                                            (**(code **)(*plVar8 + 0x50))(plVar8,iVar2,0);
                                          }
                                        }
                                        local_2558[0] = '\0';
                                        memset(local_2558 + 1,0,0xff);
                                        _snprintf(local_2558,0xff,"%d");
                                        pcVar10 = local_2558;
                                        do {
                                          cVar1 = *pcVar10;
                                          pcVar10[(longlong)param_2 - (longlong)local_2558] = cVar1;
                                          pcVar10 = pcVar10 + 1;
                                        } while (cVar1 != '\0');
                                        uVar20 = 0xffffffffffffffff;
                                        pcVar10 = local_2558;
                                        do {
                                          if (uVar20 == 0) break;
                                          uVar20 = uVar20 - 1;
                                          cVar1 = *pcVar10;
                                          pcVar10 = pcVar10 + 1;
                                        } while (cVar1 != '\0');
                                        pcVar9 = pcVar9 + 9;
                                        param_2 = param_2 + (~uVar20 - 1);
                                      }
                                      else {
                                        iVar2 = _strnicmp(pcVar9,"user_meto",9);
                                        if (iVar2 == 0) {
                                          local_2c58[0] = '\0';
                                          memset(local_2c58 + 1,0,0xff);
                                          (**(code **)(*param_6 + 0x108))(param_6);
                                          _snprintf(local_2c58,0xff,"%d");
                                          pcVar10 = local_2c58;
                                          do {
                                            cVar1 = *pcVar10;
                                            pcVar10[(longlong)param_2 - (longlong)local_2c58] =
                                                 cVar1;
                                            pcVar10 = pcVar10 + 1;
                                          } while (cVar1 != '\0');
                                          uVar20 = 0xffffffffffffffff;
                                          pcVar10 = local_2c58;
                                          do {
                                            if (uVar20 == 0) break;
                                            uVar20 = uVar20 - 1;
                                            cVar1 = *pcVar10;
                                            pcVar10 = pcVar10 + 1;
                                          } while (cVar1 != '\0');
                                          pcVar9 = pcVar9 + 9;
                                          param_2 = param_2 + (~uVar20 - 1);
                                        }
                                        else {
                                          iVar2 = _strnicmp(pcVar9,"user_pro",8);
                                          if (iVar2 == 0) {
                                            local_2358[0] = '\0';
                                            memset(local_2358 + 1,0,0xff);
                                            _snprintf(local_2358,0xff,"%d");
                                            pcVar10 = local_2358;
                                            do {
                                              cVar1 = *pcVar10;
                                              pcVar10[(longlong)param_2 - (longlong)local_2358] =
                                                   cVar1;
                                              pcVar10 = pcVar10 + 1;
                                            } while (cVar1 != '\0');
                                            uVar20 = 0xffffffffffffffff;
                                            pcVar10 = local_2358;
                                            do {
                                              if (uVar20 == 0) break;
                                              uVar20 = uVar20 - 1;
                                              cVar1 = *pcVar10;
                                              pcVar10 = pcVar10 + 1;
                                            } while (cVar1 != '\0');
                                            pcVar9 = pcVar9 + 8;
                                            param_2 = param_2 + (~uVar20 - 1);
                                          }
                                          else {
                                            iVar2 = _strnicmp(pcVar9,"iter_rand",9);
                                            if (iVar2 == 0) {
                                              local_1358[0] = '\0';
                                              memset(local_1358 + 1,0,0xff);
                                              rand();
                                              _snprintf(local_1358,0xff,"%d");
                                              pcVar10 = local_1358;
                                              do {
                                                cVar1 = *pcVar10;
                                                pcVar10[(longlong)param_2 - (longlong)local_1358] =
                                                     cVar1;
                                                pcVar10 = pcVar10 + 1;
                                              } while (cVar1 != '\0');
                                              uVar20 = 0xffffffffffffffff;
                                              pcVar10 = local_1358;
                                              do {
                                                if (uVar20 == 0) break;
                                                uVar20 = uVar20 - 1;
                                                cVar1 = *pcVar10;
                                                pcVar10 = pcVar10 + 1;
                                              } while (cVar1 != '\0');
                                              pcVar9 = pcVar9 + 9;
                                              param_2 = param_2 + (~uVar20 - 1);
                                            }
                                            else {
                                              iVar2 = _strnicmp(pcVar9,"iter_var_data",0xd);
                                              if (((iVar2 == 0) &&
                                                  (cVar1 = pcVar9[0xd], '/' < cVar1)) &&
                                                 (cVar1 < '8')) {
                                                local_2158[0] = '\0';
                                                memset(local_2158 + 1,0,0xff);
                                                FUN_1401644d0(param_6,cVar1 + -0x30);
                                                _snprintf(local_2158,0xff,"%I64d");
                                                pcVar10 = local_2158;
                                                do {
                                                  cVar1 = *pcVar10;
                                                  pcVar10 = pcVar10 + 1;
                                                  pcVar10[(longlong)
                                                          (param_2 + (-1 - (longlong)local_2158))] =
                                                       cVar1;
                                                } while (cVar1 != '\0');
                                                uVar20 = 0xffffffffffffffff;
                                                pcVar10 = local_2158;
                                                do {
                                                  if (uVar20 == 0) break;
                                                  uVar20 = uVar20 - 1;
                                                  cVar1 = *pcVar10;
                                                  pcVar10 = pcVar10 + 1;
                                                } while (cVar1 != '\0');
                                                pcVar9 = pcVar9 + 0xe;
                                                param_2 = param_2 + (~uVar20 - 1);
                                              }
                                              else {
                                                iVar2 = _strnicmp(pcVar9,"iter_var_str",0xc);
                                                if (((iVar2 == 0) &&
                                                    (cVar1 = pcVar9[0xc], '/' < cVar1)) &&
                                                   (cVar1 < '8')) {
                                                  local_b58[0] = '\0';
                                                  memset(local_b58 + 1,0,0xff);
                                                  FUN_140164570(param_6,cVar1 + -0x30);
                                                  _snprintf(local_b58,0xff,"%s");
                                                  pcVar10 = local_b58;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)local_b58))]
                                                         = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = local_b58;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0xd;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                }
                                                else {
                                                  iVar2 = _strnicmp(pcVar9,"accept",6);
                                                  if (((iVar2 == 0) && ('/' < pcVar9[6])) &&
                                                     (pcVar9[6] < '4')) {
                                                    local_458 = 0;
                                                    memset(local_457,0,0xff);
                                                    local_358 = 0;
                                                    memset(local_357,0,0xff);
                                                    local_258 = 0;
                                                    memset(local_257,0,0xff);
                                                    local_158 = 0;
                                                    memset(local_157,0,0xff);
                                                    if (param_5 != (char *)0x0) {
                                                      local_46f0 = (undefined4 *)&local_158;
                                                      local_46f8 = (undefined4 *)&local_258;
                                                      sscanf(param_5,"%s %s %s %s");
                                                    }
                                                    local_1f58[0] = '\0';
                                                    memset(local_1f58 + 1,0,0xff);
                                                    _snprintf(local_1f58,0xff,"%s");
                                                    pcVar10 = local_1f58;
                                                    do {
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                      pcVar10[(longlong)
                                                              (param_2 + (-1 - (longlong)local_1f58)
                                                              )] = cVar1;
                                                    } while (cVar1 != '\0');
                                                    uVar20 = 0xffffffffffffffff;
                                                    pcVar10 = local_1f58;
                                                    do {
                                                      if (uVar20 == 0) break;
                                                      uVar20 = uVar20 - 1;
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    pcVar9 = pcVar9 + 7;
                                                    param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"accept_data",0xb);
                                                    if (((iVar2 == 0) && ('/' < pcVar9[0xb])) &&
                                                       (pcVar9[0xb] < '4')) {
                                                      local_4680 = 0;
                                                      local_467c = 0;
                                                      local_4678 = 0;
                                                      local_4674 = 0;
                                                      if (param_5 != (char *)0x0) {
                                                        local_46f0 = &local_4674;
                                                        local_46f8 = &local_4678;
                                                        sscanf(param_5,"%d %d %d %d");
                                                      }
                                                      local_1158[0] = '\0';
                                                      memset(local_1158 + 1,0,0xff);
                                                      _snprintf(local_1158,0xff,"%d");
                                                      pcVar10 = local_1158;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)local_1158))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = local_1158;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 0xc;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"iter_game_card4",0xf
                                                                       );
                                                      if (iVar2 == 0) {
                                                        local_1d58[0] = '\0';
                                                        memset(local_1d58 + 1,0,0xff);
                                                        FUN_140331010(param_6,0xbe6e3);
                                                        _snprintf(local_1d58,0xff,"%d");
                                                        pcVar10 = local_1d58;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_1d58))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_1d58;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 0xf;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"iter_game_card3",
                                                                          0xf);
                                                        if (iVar2 == 0) {
                                                          local_758[0] = '\0';
                                                          memset(local_758 + 1,0,0xff);
                                                          FUN_140331010(param_6,0xbe6e2);
                                                          _snprintf(local_758,0xff,"%d");
                                                          pcVar10 = local_758;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)local_758))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = local_758;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 0xf;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,"iter_game_card2"
                                                                            ,0xf);
                                                          if (iVar2 == 0) {
                                                            local_1b58[0] = '\0';
                                                            memset(local_1b58 + 1,0,0xff);
                                                            FUN_140330f80(param_6);
                                                            _snprintf(local_1b58,0xff,"%d");
                                                            pcVar10 = local_1b58;
                                                            do {
                                                              cVar1 = *pcVar10;
                                                              pcVar10 = pcVar10 + 1;
                                                              pcVar10[(longlong)
                                                                      (param_2 +
                                                                      (-1 - (longlong)local_1b58))]
                                                                   = cVar1;
                                                            } while (cVar1 != '\0');
                                                            uVar20 = 0xffffffffffffffff;
                                                            pcVar10 = local_1b58;
                                                            do {
                                                              if (uVar20 == 0) break;
                                                              uVar20 = uVar20 - 1;
                                                              cVar1 = *pcVar10;
                                                              pcVar10 = pcVar10 + 1;
                                                            } while (cVar1 != '\0');
                                                            pcVar9 = pcVar9 + 0xf;
                                                            param_2 = param_2 + (~uVar20 - 1);
                                                          }
                                                          else {
                                                            iVar2 = _strnicmp(pcVar9,
                                                  "iter_game_card1",0xf);
                                                  if (iVar2 == 0) {
                                                    local_f58[0] = '\0';
                                                    memset(local_f58 + 1,0,0xff);
                                                    FUN_140330ef0(param_6);
                                                    _snprintf(local_f58,0xff,"%d");
                                                    pcVar10 = local_f58;
                                                    do {
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                      pcVar10[(longlong)
                                                              (param_2 + (-1 - (longlong)local_f58))
                                                             ] = cVar1;
                                                    } while (cVar1 != '\0');
                                                    uVar20 = 0xffffffffffffffff;
                                                    pcVar10 = local_f58;
                                                    do {
                                                      if (uVar20 == 0) break;
                                                      uVar20 = uVar20 - 1;
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    pcVar9 = pcVar9 + 0xf;
                                                    param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_cost_durrecover",
                                                                      0x14);
                                                    if (iVar2 == 0) {
                                                      local_3458[0] = '\0';
                                                      memset(local_3458 + 1,0,0xff);
                                                      _snprintf(local_3458,0xff,"--");
                                                      if ((int)param_6[0x14d] != 0) {
                                                        plVar8 = (longlong *)FUN_140087d40();
                                                        lVar19 = *plVar8;
                                                        uVar3 = FUN_14032b4b0(param_6,(int)param_6[
                                                  0x14d]);
                                                  lVar19 = (**(code **)(lVar19 + 0x60))
                                                                     (plVar8,uVar3);
                                                  if (lVar19 != 0) {
                                                    FUN_140102030(lVar19);
                                                    _snprintf(local_3458,0xff,"%d");
                                                  }
                                                  }
                                                  pcVar10 = local_3458;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)local_3458))]
                                                         = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = local_3458;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0x14;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_police_wanted",
                                                                      0x12);
                                                    if (iVar2 == 0) {
                                                      local_3a58[0] = '\0';
                                                      memset(local_3a58 + 1,0,0xff);
                                                      _snprintf(local_3a58,0xff,"--");
                                                      uVar3 = (undefined4)param_6[0x14d];
                                                      plVar8 = (longlong *)FUN_1401182a0();
                                                      cVar1 = (**(code **)(*plVar8 + 0x38))
                                                                        (plVar8,uVar3);
                                                      if (cVar1 != '\0') {
                                                        plVar8 = (longlong *)FUN_1401182a0();
                                                        plVar13 = (longlong *)FUN_1401182a0();
                                                        plVar14 = (longlong *)FUN_1401182a0();
                                                        plVar15 = (longlong *)FUN_1401182a0();
                                                        uVar4 = (**(code **)(*plVar8 + 0xc0))
                                                                          (plVar8,uVar3);
                                                        uVar5 = (**(code **)(*plVar13 + 0xd8))
                                                                          (plVar13,uVar3);
                                                        puVar16 = (undefined4 *)
                                                                  (**(code **)(*plVar14 + 0xd0))
                                                                            (plVar14,uVar3);
                                                        local_46f8 = (undefined4 *)
                                                                     (**(code **)(*plVar15 + 200))
                                                                               (plVar15,uVar3);
                                                        local_46f0 = puVar16;
                                                        local_46e8 = uVar5;
                                                        local_46e0 = uVar4;
                                                        _snprintf(local_3a58,0xff,
                                                                  "%03u %-15s %-15s %03d %d");
                                                      }
                                                      pcVar10 = local_3a58;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)local_3a58))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar9 = pcVar9 + 0x12;
                                                      pcVar10 = local_3a58;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                      iVar21 = local_46d0;
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"iter_wanted",0xb);
                                                      if (iVar2 == 0) {
                                                        local_3058[0] = '\0';
                                                        memset(local_3058 + 1,0,0xff);
                                                        _snprintf(local_3058,0xff,"--");
                                                        uVar3 = (undefined4)param_6[0x14d];
                                                        plVar8 = (longlong *)FUN_1401182a0();
                                                        cVar1 = (**(code **)(*plVar8 + 0x60))
                                                                          (plVar8,uVar3);
                                                        if (cVar1 != '\0') {
                                                          plVar8 = (longlong *)FUN_1401182a0();
                                                          plVar13 = (longlong *)FUN_1401182a0();
                                                          plVar14 = (longlong *)FUN_1401182a0();
                                                          uVar4 = (**(code **)(*plVar8 + 0xb8))
                                                                            (plVar8,uVar3);
                                                          puVar16 = (undefined4 *)
                                                                    (**(code **)(*plVar13 + 0xb0))
                                                                              (plVar13,uVar3);
                                                          (**(code **)(*plVar14 + 0xa8))
                                                                    (plVar14,uVar3);
                                                          local_46f0 = (undefined4 *)
                                                                       CONCAT44(local_46f0._4_4_,
                                                                                uVar4);
                                                          local_46f8 = puVar16;
                                                          _snprintf(local_3058,0xff,"%06u %-15s %u")
                                                          ;
                                                        }
                                                        pcVar10 = local_3058;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_3058))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_3058;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 0xb;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar6 = _strnicmp(pcVar9,"enemy_syn",9);
                                                        iVar2 = local_4670;
                                                        if (((iVar6 == 0) &&
                                                            (cVar1 = pcVar9[9], '/' < cVar1)) &&
                                                           ((int)cVar1 < local_4670 + 0x30)) {
                                                          local_4558 = DAT_14070cec4;
                                                          local_4556 = DAT_14070cec6;
                                                          memset(local_4555,0,0xfd);
                                                          iVar6 = cVar1 + -0x30;
                                                          if (((-1 < iVar6) && (iVar6 < iVar2)) &&
                                                             (iVar2 = (**(code **)(param_6[2] +
                                                                                  0x170))(param_6 + 
                                                  2), iVar2 != 0)) {
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    lVar19 = *plVar8;
                                                    uVar3 = (**(code **)(param_6[2] + 0x170))
                                                                      (param_6 + 2);
                                                    lVar19 = (**(code **)(lVar19 + 0x1e0))
                                                                       (plVar8,uVar3,iVar6);
                                                    if (lVar19 != 0) {
                                                      _snprintf((char *)&local_4558,0x100,"%s");
                                                      local_4459 = 0;
                                                    }
                                                  }
                                                  pcVar10 = (char *)&local_4558;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)&local_4558))
                                                           ] = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = (char *)&local_4558;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 10;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar6 = _strnicmp(pcVar9,"ally_syn",8);
                                                    iVar2 = local_466c;
                                                    if (((iVar6 == 0) &&
                                                        (cVar1 = pcVar9[8], '/' < cVar1)) &&
                                                       ((int)cVar1 < local_466c + 0x30)) {
                                                      local_4358 = DAT_14070cec4;
                                                      local_4356 = DAT_14070cec6;
                                                      memset(local_4355,0,0xfd);
                                                      iVar6 = cVar1 + -0x30;
                                                      if (((-1 < iVar6) && (iVar6 < iVar2)) &&
                                                         (iVar2 = (**(code **)(param_6[2] + 0x170))
                                                                            (param_6 + 2),
                                                         iVar2 != 0)) {
                                                        plVar8 = (longlong *)FUN_140087ed0();
                                                        lVar19 = *plVar8;
                                                        uVar3 = (**(code **)(param_6[2] + 0x170))
                                                                          (param_6 + 2);
                                                        lVar19 = (**(code **)(lVar19 + 0x1e8))
                                                                           (plVar8,uVar3,iVar6);
                                                        if (lVar19 != 0) {
                                                          _snprintf((char *)&local_4358,0x100,"%s");
                                                          local_4259 = 0;
                                                        }
                                                      }
                                                      pcVar10 = (char *)&local_4358;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)&local_4358))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = (char *)&local_4358;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 9;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"account_id",10);
                                                      if (iVar2 == 0) {
                                                        local_1958[0] = '\0';
                                                        memset(local_1958 + 1,0,0xff);
                                                        _snprintf(local_1958,0xff,"%u");
                                                        pcVar10 = local_1958;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_1958))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_1958;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 10;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"user_id",7);
                                                        if (iVar2 == 0) {
                                                          local_958[0] = '\0';
                                                          memset(local_958 + 1,0,0xff);
                                                          (**(code **)(*param_6 + 8))(param_6);
                                                          _snprintf(local_958,0xff,"%u");
                                                          pcVar10 = local_958;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)local_958))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = local_958;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 7;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,"user_map_id",0xb
                                                                           );
                                                          if (iVar2 == 0) {
                                                            local_2b58[0] = '\0';
                                                            memset(local_2b58 + 1,0,0xff);
                                                            (**(code **)(param_6[2] + 0x168))
                                                                      (param_6 + 2);
                                                            _snprintf(local_2b58,0xff,"%u");
                                                            pcVar10 = local_2b58;
                                                            do {
                                                              cVar1 = *pcVar10;
                                                              pcVar10[(longlong)param_2 -
                                                                      (longlong)local_2b58] = cVar1;
                                                              pcVar10 = pcVar10 + 1;
                                                            } while (cVar1 != '\0');
                                                            uVar20 = 0xffffffffffffffff;
                                                            pcVar10 = local_2b58;
                                                            do {
                                                              if (uVar20 == 0) break;
                                                              uVar20 = uVar20 - 1;
                                                              cVar1 = *pcVar10;
                                                              pcVar10 = pcVar10 + 1;
                                                            } while (cVar1 != '\0');
                                                            pcVar9 = pcVar9 + 0xb;
                                                            param_2 = param_2 + (~uVar20 - 1);
                                                          }
                                                          else {
                                                            iVar2 = _strnicmp(pcVar9,"user_map_x",10
                                                                             );
                                                            if (iVar2 == 0) {
                                                              local_2a58[0] = '\0';
                                                              memset(local_2a58 + 1,0,0xff);
                                                              (**(code **)(param_6[2] + 0x40))
                                                                        (param_6 + 2);
                                                              _snprintf(local_2a58,0xff,"%u");
                                                              pcVar10 = local_2a58;
                                                              do {
                                                                cVar1 = *pcVar10;
                                                                pcVar10[(longlong)param_2 -
                                                                        (longlong)local_2a58] =
                                                                     cVar1;
                                                                pcVar10 = pcVar10 + 1;
                                                              } while (cVar1 != '\0');
                                                              uVar20 = 0xffffffffffffffff;
                                                              pcVar10 = local_2a58;
                                                              do {
                                                                if (uVar20 == 0) break;
                                                                uVar20 = uVar20 - 1;
                                                                cVar1 = *pcVar10;
                                                                pcVar10 = pcVar10 + 1;
                                                              } while (cVar1 != '\0');
                                                              pcVar9 = pcVar9 + 10;
                                                              param_2 = param_2 + (~uVar20 - 1);
                                                            }
                                                            else {
                                                              iVar2 = _strnicmp(pcVar9,"user_map_y",
                                                                                10);
                                                              if (iVar2 == 0) {
                                                                local_2858[0] = '\0';
                                                                memset(local_2858 + 1,0,0xff);
                                                                (**(code **)(param_6[2] + 0x48))
                                                                          (param_6 + 2);
                                                                _snprintf(local_2858,0xff,"%u");
                                                                pcVar10 = local_2858;
                                                                do {
                                                                  cVar1 = *pcVar10;
                                                                  pcVar10[(longlong)param_2 -
                                                                          (longlong)local_2858] =
                                                                       cVar1;
                                                                  pcVar10 = pcVar10 + 1;
                                                                } while (cVar1 != '\0');
                                                                uVar20 = 0xffffffffffffffff;
                                                                pcVar10 = local_2858;
                                                                do {
                                                                  if (uVar20 == 0) break;
                                                                  uVar20 = uVar20 - 1;
                                                                  cVar1 = *pcVar10;
                                                                  pcVar10 = pcVar10 + 1;
                                                                } while (cVar1 != '\0');
                                                                pcVar9 = pcVar9 + 10;
                                                                param_2 = param_2 + (~uVar20 - 1);
                                                              }
                                                              else {
                                                                iVar2 = _strnicmp(pcVar9,
                                                  "user_virtue",0xb);
                                                  if (iVar2 == 0) {
                                                    local_2658[0] = '\0';
                                                    memset(local_2658 + 1,0,0xff);
                                                    _snprintf(local_2658,0xff,"%u");
                                                    pcVar10 = local_2658;
                                                    do {
                                                      cVar1 = *pcVar10;
                                                      pcVar10[(longlong)param_2 -
                                                              (longlong)local_2658] = cVar1;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    uVar20 = 0xffffffffffffffff;
                                                    pcVar10 = local_2658;
                                                    do {
                                                      if (uVar20 == 0) break;
                                                      uVar20 = uVar20 - 1;
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    pcVar9 = pcVar9 + 0xb;
                                                    param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"user_home_id",0xc);
                                                    if (iVar2 == 0) {
                                                      local_2458[0] = '\0';
                                                      memset(local_2458 + 1,0,0xff);
                                                      _snprintf(local_2458,0xff,"%u");
                                                      pcVar10 = local_2458;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10[(longlong)param_2 -
                                                                (longlong)local_2458] = cVar1;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = local_2458;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 0xc;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"battle_lev",10);
                                                      if (iVar2 == 0) {
                                                        local_2258[0] = '\0';
                                                        memset(local_2258 + 1,0,0xff);
                                                        FUN_14018eb30(param_6);
                                                        _snprintf(local_2258,0xff,"%u");
                                                        pcVar10 = local_2258;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_2258))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_2258;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 10;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"syn_id",6);
                                                        if (iVar2 == 0) {
                                                          local_2058[0] = '\0';
                                                          memset(local_2058 + 1,0,0xff);
                                                          (**(code **)(param_6[2] + 0x170))
                                                                    (param_6 + 2);
                                                          _snprintf(local_2058,0xff,"%u");
                                                          pcVar10 = local_2058;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)local_2058))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = local_2058;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 6;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,"syn_name",8);
                                                          if (iVar2 == 0) {
                                                            pIVar17 = theInstance();
                                                            pcVar10 = (char *)(*(code *)**(
                                                  undefined8 **)pIVar17)(pIVar17,"SYNNAME_NONE");
                                                  iVar2 = (**(code **)(param_6[2] + 0x170))
                                                                    (param_6 + 2);
                                                  if (iVar2 != 0) {
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    lVar19 = *plVar8;
                                                    uVar3 = (**(code **)(param_6[2] + 0x170))
                                                                      (param_6 + 2);
                                                    pcVar18 = (char *)(**(code **)(lVar19 + 0x290))
                                                                                (plVar8,uVar3);
                                                    if (pcVar18 != (char *)0x0) {
                                                      pcVar10 = pcVar18;
                                                    }
                                                  }
                                                  pcVar18 = pcVar10;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    pcVar18[(longlong)
                                                            (param_2 + (-1 - (longlong)pcVar10))] =
                                                         cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 8;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"family_id",9);
                                                    if (iVar2 == 0) {
                                                      local_1e58[0] = '\0';
                                                      memset(local_1e58 + 1,0,0xff);
                                                      FUN_140164ac0(param_6);
                                                      _snprintf(local_1e58,0xff,"%u");
                                                      pcVar10 = local_1e58;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)local_1e58))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = local_1e58;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 9;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"user_name",9);
                                                      if (iVar2 == 0) {
                                                        pcVar18 = (char *)(**(code **)(param_6[2] +
                                                                                      0x18))(param_6
                                                                                             + 2);
                                                        pcVar10 = param_2;
                                                        do {
                                                          cVar1 = *pcVar18;
                                                          pcVar18 = pcVar18 + 1;
                                                          *pcVar10 = cVar1;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 9;
                                                        pcVar10 = (char *)(**(code **)(param_6[2] +
                                                                                      0x18))();
                                                        uVar20 = 0xffffffffffffffff;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"mate_name",9);
                                                        if (iVar2 == 0) {
                                                          pcVar18 = (char *)(**(code **)(*param_6 +
                                                                                        0x40))(
                                                  param_6);
                                                  pcVar10 = param_2;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    *pcVar10 = cVar1;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 9;
                                                  pcVar10 = (char *)(**(code **)(*param_6 + 0x40))()
                                                  ;
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"map_owner_id",0xc);
                                                    if (iVar2 == 0) {
                                                      local_1c58[0] = '\0';
                                                      memset(local_1c58 + 1,0,0xff);
                                                      lVar19 = (**(code **)(param_6[2] + 0x160))
                                                                         (param_6 + 2);
                                                      (**(code **)(**(longlong **)(lVar19 + 0x58) +
                                                                  0x10))(*(longlong **)
                                                                          (lVar19 + 0x58),5);
                                                      _snprintf(local_1c58,0xff,"%u");
                                                      pcVar10 = local_1c58;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)local_1c58))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = local_1c58;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 0xc;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"map_owner_type",0xe)
                                                      ;
                                                      if (iVar2 == 0) {
                                                        local_1a58[0] = '\0';
                                                        memset(local_1a58 + 1,0,0xff);
                                                        lVar19 = (**(code **)(param_6[2] + 0x160))
                                                                           (param_6 + 2);
                                                        (**(code **)(**(longlong **)(lVar19 + 0x58)
                                                                    + 0x10))
                                                                  (*(longlong **)(lVar19 + 0x58),
                                                                   0x10);
                                                        _snprintf(local_1a58,0xff,"%u");
                                                        pcVar10 = local_1a58;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_1a58))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_1a58;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 0xe;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"iter_value",10);
                                                        if (iVar2 == 0) {
                                                          local_1858[0] = '\0';
                                                          memset(local_1858 + 1,0,0xff);
                                                          _snprintf(local_1858,0xff,"%u");
                                                          pcVar10 = local_1858;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)local_1858))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = local_1858;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 10;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,"iter_syn_name",
                                                                            0xd);
                                                          if (iVar2 == 0) {
                                                            pcVar10 = "--";
                                                            if ((int)param_6[0x14d] != 0) {
                                                              plVar8 = (longlong *)FUN_140087ed0();
                                                              lVar19 = (**(code **)(*plVar8 + 0x290)
                                                                       )(plVar8,(int)param_6[0x14d])
                                                              ;
                                                              if (lVar19 != 0) {
                                                                plVar8 = (longlong *)FUN_140087ed0()
                                                                ;
                                                                pcVar10 = (char *)(**(code **)(*
                                                  plVar8 + 0x290))(plVar8,(int)param_6[0x14d]);
                                                  }
                                                  }
                                                  pcVar18 = pcVar10;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    pcVar18[(longlong)
                                                            (param_2 + (-1 - (longlong)pcVar10))] =
                                                         cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0xd;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_syn_leader",0xf);
                                                    if (iVar2 == 0) {
                                                      pcVar10 = "--";
                                                      if ((int)param_6[0x14d] != 0) {
                                                        plVar8 = (longlong *)FUN_140087ed0();
                                                        lVar19 = (**(code **)(*plVar8 + 0x298))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if (lVar19 != 0) {
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    pcVar10 = (char *)(**(code **)(*plVar8 + 0x298))
                                                                                (plVar8,(int)param_6
                                                  [0x14d]);
                                                  }
                                                  }
                                                  pcVar18 = pcVar10;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    pcVar18[(longlong)
                                                            (param_2 + (-1 - (longlong)pcVar10))] =
                                                         cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0xf;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_syn_money",0xe);
                                                    if (iVar2 == 0) {
                                                      local_4158 = DAT_14070cec4;
                                                      local_4156 = DAT_14070cec6;
                                                      memset(local_4155,0,0xfd);
                                                      if ((int)param_6[0x14d] != 0) {
                                                        plVar8 = (longlong *)FUN_140087ed0();
                                                        lVar19 = (**(code **)(*plVar8 + 0x290))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if (lVar19 != 0) {
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    (**(code **)(*plVar8 + 0x268))
                                                              (plVar8,(int)param_6[0x14d]);
                                                    _snprintf((char *)&local_4158,0x100,"%I64d");
                                                    local_4059 = 0;
                                                  }
                                                  }
                                                  pcVar10 = (char *)&local_4158;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)&local_4158))
                                                           ] = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = (char *)&local_4158;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0xe;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_syn_amount",0xf);
                                                    if (iVar2 == 0) {
                                                      local_3f58 = DAT_14070cec4;
                                                      local_3f56 = DAT_14070cec6;
                                                      memset(local_3f55,0,0xfd);
                                                      if ((int)param_6[0x14d] != 0) {
                                                        plVar8 = (longlong *)FUN_140087ed0();
                                                        lVar19 = (**(code **)(*plVar8 + 0x290))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if (lVar19 != 0) {
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    (**(code **)(*plVar8 + 600))
                                                              (plVar8,(int)param_6[0x14d]);
                                                    _snprintf((char *)&local_3f58,0x100,"%u");
                                                    local_3e59 = 0;
                                                  }
                                                  }
                                                  pcVar10 = (char *)&local_3f58;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)&local_3f58))
                                                           ] = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = (char *)&local_3f58;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0xf;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_member_rank",0x10
                                                                     );
                                                    if (iVar2 == 0) {
                                                      pcVar10 = "--";
                                                      if ((int)param_6[0x14d] != 0) {
                                                        uVar11 = FUN_140008520(*(undefined4 *)
                                                                                (param_1 + 0x48));
                                                        plVar8 = (longlong *)FUN_140087650(uVar11);
                                                        plVar8 = (longlong *)
                                                                 (**(code **)(*plVar8 + 0x98))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if ((plVar8 != (longlong *)0x0) &&
                                                     (iVar2 = (**(code **)(plVar8[2] + 0x170))
                                                                        (plVar8 + 2), iVar2 != 0)) {
                                                    plVar13 = (longlong *)FUN_140087ed0();
                                                    lVar19 = *plVar13;
                                                    uVar3 = (**(code **)(*plVar8 + 8))(plVar8);
                                                    uVar3 = (**(code **)(lVar19 + 0xf8))
                                                                      (plVar13,uVar3);
                                                    plVar8 = (longlong *)FUN_140087ed0();
                                                    pcVar10 = (char *)(**(code **)(*plVar8 + 0x2a0))
                                                                                (plVar8,uVar3);
                                                  }
                                                  }
                                                  pcVar18 = pcVar10;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    pcVar18[(longlong)
                                                            (param_2 + (-1 - (longlong)pcVar10))] =
                                                         cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0x10;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_member_name",0x10
                                                                     );
                                                    if (iVar2 == 0) {
                                                      pcVar10 = "--";
                                                      if ((int)param_6[0x14d] != 0) {
                                                        uVar11 = FUN_140008520(*(undefined4 *)
                                                                                (param_1 + 0x48));
                                                        plVar8 = (longlong *)FUN_140087650(uVar11);
                                                        lVar19 = (**(code **)(*plVar8 + 0x98))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if (lVar19 != 0) {
                                                    plVar8 = (longlong *)(lVar19 + 0x10);
                                                    iVar2 = (**(code **)(*plVar8 + 0x170))(plVar8);
                                                    if (iVar2 != 0) {
                                                      pcVar10 = (char *)(**(code **)(*plVar8 + 0x18)
                                                                        )(plVar8);
                                                    }
                                                  }
                                                  }
                                                  pcVar18 = pcVar10;
                                                  do {
                                                    cVar1 = *pcVar18;
                                                    pcVar18 = pcVar18 + 1;
                                                    pcVar18[(longlong)
                                                            (param_2 + (-1 - (longlong)pcVar10))] =
                                                         cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0x10;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"iter_member_proffer",
                                                                      0x13);
                                                    if (iVar2 == 0) {
                                                      local_3d58 = DAT_14070cec4;
                                                      local_3d56 = DAT_14070cec6;
                                                      memset(local_3d55,0,0xfd);
                                                      if ((int)param_6[0x14d] != 0) {
                                                        uVar11 = FUN_140008520(*(undefined4 *)
                                                                                (param_1 + 0x48));
                                                        plVar8 = (longlong *)FUN_140087650(uVar11);
                                                        plVar8 = (longlong *)
                                                                 (**(code **)(*plVar8 + 0x98))
                                                                           (plVar8,(int)param_6[
                                                  0x14d]);
                                                  if (plVar8 != (longlong *)0x0) {
                                                    plVar13 = (longlong *)FUN_140087ed0();
                                                    lVar19 = *plVar13;
                                                    uVar3 = (**(code **)(*plVar8 + 8))(plVar8);
                                                    (**(code **)(lVar19 + 0x168))(plVar13,uVar3);
                                                  }
                                                  _snprintf((char *)&local_3d58,0x100,"%d");
                                                  local_3c59 = 0;
                                                  }
                                                  pcVar10 = (char *)&local_3d58;
                                                  do {
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                    pcVar10[(longlong)
                                                            (param_2 + (-1 - (longlong)&local_3d58))
                                                           ] = cVar1;
                                                  } while (cVar1 != '\0');
                                                  uVar20 = 0xffffffffffffffff;
                                                  pcVar10 = (char *)&local_3d58;
                                                  do {
                                                    if (uVar20 == 0) break;
                                                    uVar20 = uVar20 - 1;
                                                    cVar1 = *pcVar10;
                                                    pcVar10 = pcVar10 + 1;
                                                  } while (cVar1 != '\0');
                                                  pcVar9 = pcVar9 + 0x13;
                                                  param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"last_add_item_id",0x10
                                                                     );
                                                    if (iVar2 == 0) {
                                                      local_3b58[0] = '\0';
                                                      memset(local_3b58 + 1,0,0xff);
                                                      plVar8 = (longlong *)FUN_140087d40();
                                                      puVar16 = (undefined4 *)
                                                                FUN_14011e970(param_6 + 0x181);
                                                      plVar8 = (longlong *)
                                                               (**(code **)(*plVar8 + 0x60))
                                                                         (plVar8,*puVar16);
                                                      if (plVar8 == (longlong *)0x0) {
                                                        _snprintf(local_3b58,0xff,"%u");
                                                      }
                                                      else {
                                                        (**(code **)(*plVar8 + 8))(plVar8);
                                                        _snprintf(local_3b58,0xff,"%u");
                                                      }
                                                      pcVar10 = local_3b58;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                        pcVar10[(longlong)
                                                                (param_2 +
                                                                (-1 - (longlong)local_3b58))] =
                                                             cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar10 = local_3b58;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = pcVar9 + 0x10;
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"last_add_item_type",
                                                                        0x12);
                                                      if (iVar2 == 0) {
                                                        local_3958[0] = '\0';
                                                        memset(local_3958 + 1,0,0xff);
                                                        plVar8 = (longlong *)FUN_140087d40();
                                                        puVar16 = (undefined4 *)
                                                                  FUN_14011e970(param_6 + 0x181);
                                                        lVar19 = (**(code **)(*plVar8 + 0x60))
                                                                           (plVar8,*puVar16);
                                                        if (lVar19 == 0) {
                                                          _snprintf(local_3958,0xff,"%u");
                                                        }
                                                        else {
                                                          FUN_1400fda10(lVar19,1,1);
                                                          _snprintf(local_3958,0xff,"%u");
                                                        }
                                                        pcVar10 = local_3958;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)local_3958))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = local_3958;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 0x12;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"last_del_item_id",
                                                                          0x10);
                                                        if (iVar2 == 0) {
                                                          local_1658[0] = '\0';
                                                          memset(local_1658 + 1,0,0xff);
                                                          _snprintf(local_1658,0xff,"%u");
                                                          pcVar10 = local_1658;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)local_1658))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = local_1658;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 0x10;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,
                                                  "pk_bonus_target_name",0x14);
                                                  if (iVar2 == 0) {
                                                    pcVar10 = (char *)(param_1 + 0x20);
                                                    pcVar18 = pcVar10;
                                                    do {
                                                      cVar1 = *pcVar18;
                                                      pcVar18 = pcVar18 + 1;
                                                      pcVar18[(longlong)
                                                              (param_2 + (-1 - (longlong)pcVar10))]
                                                           = cVar1;
                                                    } while (cVar1 != '\0');
                                                    uVar20 = 0xffffffffffffffff;
                                                    pcVar9 = pcVar9 + 0x14;
                                                    do {
                                                      if (uVar20 == 0) break;
                                                      uVar20 = uVar20 - 1;
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    iVar2 = _strnicmp(pcVar9,"pk_bonus_hunter_name",
                                                                      0x14);
                                                    if (iVar2 == 0) {
                                                      pcVar10 = (char *)(param_1 + 0x30);
                                                      pcVar18 = pcVar10;
                                                      do {
                                                        cVar1 = *pcVar18;
                                                        pcVar18 = pcVar18 + 1;
                                                        pcVar18[(longlong)
                                                                (param_2 + (-1 - (longlong)pcVar10))
                                                               ] = cVar1;
                                                      } while (cVar1 != '\0');
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar9 = pcVar9 + 0x14;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                    else {
                                                      iVar2 = _strnicmp(pcVar9,"pk_bonus_bonus",0xe)
                                                      ;
                                                      if (iVar2 == 0) {
                                                        local_3758 = 0x30;
                                                        memset(local_3756,0,0xfe);
                                                        _snprintf((char *)&local_3758,0x100,"%u");
                                                        local_3659 = 0;
                                                        pcVar10 = (char *)&local_3758;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                          pcVar10[(longlong)
                                                                  (param_2 +
                                                                  (-1 - (longlong)&local_3758))] =
                                                               cVar1;
                                                        } while (cVar1 != '\0');
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar10 = (char *)&local_3758;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = pcVar9 + 0xe;
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                      else {
                                                        iVar2 = _strnicmp(pcVar9,"pk_bonus_num",0xc)
                                                        ;
                                                        if (iVar2 == 0) {
                                                          local_3558 = 0x30;
                                                          memset(local_3556,0,0xfe);
                                                          _snprintf((char *)&local_3558,0x100,"%u");
                                                          local_3459 = 0;
                                                          pcVar10 = (char *)&local_3558;
                                                          do {
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                            pcVar10[(longlong)
                                                                    (param_2 +
                                                                    (-1 - (longlong)&local_3558))] =
                                                                 cVar1;
                                                          } while (cVar1 != '\0');
                                                          uVar20 = 0xffffffffffffffff;
                                                          pcVar10 = (char *)&local_3558;
                                                          do {
                                                            if (uVar20 == 0) break;
                                                            uVar20 = uVar20 - 1;
                                                            cVar1 = *pcVar10;
                                                            pcVar10 = pcVar10 + 1;
                                                          } while (cVar1 != '\0');
                                                          pcVar9 = pcVar9 + 0xc;
                                                          param_2 = param_2 + (~uVar20 - 1);
                                                        }
                                                        else {
                                                          iVar2 = _strnicmp(pcVar9,"riding_points",
                                                                            0xd);
                                                          if (iVar2 == 0) {
                                                            local_4658 = 0x30;
                                                            memset(local_4656,0,0xfe);
                                                            (**(code **)(*param_6 + 0x70))(param_6);
                                                            _snprintf((char *)&local_4658,0x100,"%d"
                                                                     );
                                                            local_4559 = 0;
                                                            pcVar10 = (char *)&local_4658;
                                                            do {
                                                              cVar1 = *pcVar10;
                                                              pcVar10[(longlong)param_2 -
                                                                      (longlong)&local_4658] = cVar1
                                                              ;
                                                              pcVar10 = pcVar10 + 1;
                                                            } while (cVar1 != '\0');
                                                            uVar20 = 0xffffffffffffffff;
                                                            pcVar10 = (char *)&local_4658;
                                                            do {
                                                              if (uVar20 == 0) break;
                                                              uVar20 = uVar20 - 1;
                                                              cVar1 = *pcVar10;
                                                              pcVar10 = pcVar10 + 1;
                                                            } while (cVar1 != '\0');
                                                            pcVar9 = pcVar9 + 0xd;
                                                            param_2 = param_2 + (~uVar20 - 1);
                                                          }
                                                          else {
                                                            iVar2 = _strnicmp(pcVar9,
                                                  "server_remaindays",0x11);
                                                  if (iVar2 == 0) {
                                                    local_3158 = 0x30;
                                                    memset(local_3156,0,0xfe);
                                                    FUN_1400e2430();
                                                    _snprintf((char *)&local_3158,0x100,"%d");
                                                    local_3059 = 0;
                                                    pcVar10 = (char *)&local_3158;
                                                    do {
                                                      cVar1 = *pcVar10;
                                                      pcVar10[(longlong)param_2 -
                                                              (longlong)&local_3158] = cVar1;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    uVar20 = 0xffffffffffffffff;
                                                    pcVar10 = (char *)&local_3158;
                                                    do {
                                                      if (uVar20 == 0) break;
                                                      uVar20 = uVar20 - 1;
                                                      cVar1 = *pcVar10;
                                                      pcVar10 = pcVar10 + 1;
                                                    } while (cVar1 != '\0');
                                                    pcVar9 = pcVar9 + 0x11;
                                                    param_2 = param_2 + (~uVar20 - 1);
                                                  }
                                                  else {
                                                    pcVar10 = strstr(pcVar9,"stc(");
                                                    if ((pcVar10 == (char *)0x0) ||
                                                       (pcVar10 = strstr(pcVar9,")"),
                                                       pcVar10 == (char *)0x0)) {
                                                      pcVar10 = strstr(pcVar9,"stc_daily(");
                                                      if ((pcVar10 != (char *)0x0) &&
                                                         (pcVar10 = strstr(pcVar9,")"),
                                                         pcVar10 != (char *)0x0)) {
                                                        local_46c8 = 0;
                                                        local_46c0 = 0;
                                                        sscanf(pcVar9,"stc_daily(%u, %u)");
                                                        FUN_140384af0(param_6,local_46c8,local_46c0)
                                                        ;
                                                        local_2d58[0] = '\0';
                                                        memset(local_2d58 + 1,0,0xff);
                                                        _snprintf(local_2d58,0x100,"%d");
                                                        local_2c59 = 0;
                                                        pcVar10 = local_2d58;
                                                        do {
                                                          cVar1 = *pcVar10;
                                                          pcVar10[(longlong)param_2 -
                                                                  (longlong)local_2d58] = cVar1;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        pcVar9 = strstr(pcVar9,")");
                                                        uVar20 = 0xffffffffffffffff;
                                                        pcVar9 = pcVar9 + 1;
                                                        pcVar10 = local_2d58;
                                                        do {
                                                          if (uVar20 == 0) break;
                                                          uVar20 = uVar20 - 1;
                                                          cVar1 = *pcVar10;
                                                          pcVar10 = pcVar10 + 1;
                                                        } while (cVar1 != '\0');
                                                        param_2 = param_2 + (~uVar20 - 1);
                                                      }
                                                    }
                                                    else {
                                                      local_46cc = 0;
                                                      local_46ac = 0;
                                                      sscanf(pcVar9,"stc(%u, %u)");
                                                      FUN_140385cf0(param_6,local_46cc,local_46ac);
                                                      local_2f58[0] = '\0';
                                                      memset(local_2f58 + 1,0,0xff);
                                                      _snprintf(local_2f58,0x100,"%d");
                                                      local_2e59 = 0;
                                                      pcVar10 = local_2f58;
                                                      do {
                                                        cVar1 = *pcVar10;
                                                        pcVar10[(longlong)param_2 -
                                                                (longlong)local_2f58] = cVar1;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      pcVar9 = strstr(pcVar9,")");
                                                      uVar20 = 0xffffffffffffffff;
                                                      pcVar9 = pcVar9 + 1;
                                                      pcVar10 = local_2f58;
                                                      do {
                                                        if (uVar20 == 0) break;
                                                        uVar20 = uVar20 - 1;
                                                        cVar1 = *pcVar10;
                                                        pcVar10 = pcVar10 + 1;
                                                      } while (cVar1 != '\0');
                                                      param_2 = param_2 + (~uVar20 - 1);
                                                    }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
                else {
                  local_46b0 = 0;
                  sscanf(pcVar9,"emoney_card1(%d)");
                  local_4258 = DAT_14070cec4;
                  local_4256 = DAT_14070cec6;
                  memset(local_4255,0,0xfd);
                  FUN_140174810(param_6,local_46b0);
                  _snprintf((char *)&local_4258,0x100,"%d");
                  local_4159 = 0;
                  pcVar10 = (char *)&local_4258;
                  do {
                    cVar1 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                    pcVar10[(longlong)(param_2 + (-1 - (longlong)&local_4258))] = cVar1;
                  } while (cVar1 != '\0');
                  pcVar9 = strstr(pcVar9,")");
                  uVar20 = 0xffffffffffffffff;
                  pcVar9 = pcVar9 + 1;
                  pcVar10 = (char *)&local_4258;
                  do {
                    if (uVar20 == 0) break;
                    uVar20 = uVar20 - 1;
                    cVar1 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                  } while (cVar1 != '\0');
                  param_2 = param_2 + (~uVar20 - 1);
                }
              }
            }
          }
          if (local_46d8 != 0) {
            iVar2 = _strnicmp(pcVar9,"datastr",7);
            if (iVar2 == 0) {
              pcVar10 = param_2;
              if (*(longlong *)(local_46d8 + 0x60) == 0) {
                local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0x143);
                log_InlineLogERROR(&DAT_1406d9c10);
                pcVar18 = (char *)0x0;
              }
              else {
                pcVar18 = (char *)(**(code **)(**(longlong **)(local_46d8 + 0x60) + 0x18))
                                            (*(longlong **)(local_46d8 + 0x60),0x16);
              }
              do {
                cVar1 = *pcVar18;
                pcVar18 = pcVar18 + 1;
                *pcVar10 = cVar1;
                pcVar10 = pcVar10 + 1;
              } while (cVar1 != '\0');
              pcVar9 = pcVar9 + 7;
              if (*(longlong *)(local_46d8 + 0x60) == 0) {
                local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0x143);
                log_InlineLogERROR(&DAT_1406d9c10);
                pcVar10 = (char *)0x0;
              }
              else {
                pcVar10 = (char *)(**(code **)(**(longlong **)(local_46d8 + 0x60) + 0x18))
                                            (*(longlong **)(local_46d8 + 0x60),0x16);
              }
              uVar20 = 0xffffffffffffffff;
              do {
                if (uVar20 == 0) break;
                uVar20 = uVar20 - 1;
                cVar1 = *pcVar10;
                pcVar10 = pcVar10 + 1;
              } while (cVar1 != '\0');
              param_2 = param_2 + (~uVar20 - 1);
            }
            else {
              iVar2 = _strnicmp(pcVar9,"data",4);
              if (((iVar2 == 0) && (cVar1 = pcVar9[4], '/' < cVar1)) && (cVar1 < '4')) {
                local_1458[0] = '\0';
                memset(local_1458 + 1,0,0xff);
                if ((int)cVar1 - 0x30U < 4) {
                  FUN_140087300(local_46d8);
                  _snprintf(local_1458,0xff,"%d");
                }
                pcVar10 = local_1458;
                do {
                  cVar1 = *pcVar10;
                  pcVar10[(longlong)param_2 - (longlong)local_1458] = cVar1;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                uVar20 = 0xffffffffffffffff;
                pcVar10 = local_1458;
                do {
                  if (uVar20 == 0) break;
                  uVar20 = uVar20 - 1;
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                pcVar9 = pcVar9 + 5;
                param_2 = param_2 + (~uVar20 - 1);
              }
              else {
                iVar2 = _strnicmp(pcVar9,"name",4);
                if (iVar2 == 0) {
                  pcVar18 = (char *)(**(code **)(*(longlong *)(local_46d8 + 0x10) + 0x18))
                                              (local_46d8 + 0x10);
                  pcVar10 = param_2;
                  do {
                    cVar1 = *pcVar18;
                    pcVar18 = pcVar18 + 1;
                    *pcVar10 = cVar1;
                    pcVar10 = pcVar10 + 1;
                  } while (cVar1 != '\0');
                  pcVar9 = pcVar9 + 4;
                  pcVar10 = (char *)FUN_140117cc0(local_46d8,3);
                  uVar20 = 0xffffffffffffffff;
                  do {
                    if (uVar20 == 0) break;
                    uVar20 = uVar20 - 1;
                    cVar1 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                  } while (cVar1 != '\0');
                  param_2 = param_2 + (~uVar20 - 1);
                }
                else {
                  iVar2 = _strnicmp(pcVar9,"id",2);
                  if (iVar2 == 0) {
                    local_1258[0] = '\0';
                    memset(local_1258 + 1,0,0xff);
                    FUN_140087360(local_46d8);
                    _snprintf(local_1258,0xff,"%u");
                    pcVar10 = local_1258;
                    do {
                      cVar1 = *pcVar10;
                      pcVar10[(longlong)param_2 - (longlong)local_1258] = cVar1;
                      pcVar10 = pcVar10 + 1;
                    } while (cVar1 != '\0');
                    uVar20 = 0xffffffffffffffff;
                    pcVar10 = local_1258;
                    do {
                      if (uVar20 == 0) break;
                      uVar20 = uVar20 - 1;
                      cVar1 = *pcVar10;
                      pcVar10 = pcVar10 + 1;
                    } while (cVar1 != '\0');
                    pcVar9 = pcVar9 + 2;
                    param_2 = param_2 + (~uVar20 - 1);
                  }
                  else {
                    iVar2 = _strnicmp(pcVar9,"npc_x",5);
                    if (iVar2 == 0) {
                      local_1058[0] = '\0';
                      memset(local_1058 + 1,0,0xff);
                      (**(code **)(*(longlong *)(local_46d8 + 0x10) + 0x40))(local_46d8 + 0x10);
                      _snprintf(local_1058,0xff,"%u");
                      pcVar10 = local_1058;
                      do {
                        cVar1 = *pcVar10;
                        pcVar10[(longlong)param_2 - (longlong)local_1058] = cVar1;
                        pcVar10 = pcVar10 + 1;
                      } while (cVar1 != '\0');
                      uVar20 = 0xffffffffffffffff;
                      pcVar10 = local_1058;
                      do {
                        if (uVar20 == 0) break;
                        uVar20 = uVar20 - 1;
                        cVar1 = *pcVar10;
                        pcVar10 = pcVar10 + 1;
                      } while (cVar1 != '\0');
                      pcVar9 = pcVar9 + 5;
                      param_2 = param_2 + (~uVar20 - 1);
                    }
                    else {
                      iVar2 = _strnicmp(pcVar9,"npc_y",5);
                      if (iVar2 == 0) {
                        local_e58[0] = '\0';
                        memset(local_e58 + 1,0,0xff);
                        (**(code **)(*(longlong *)(local_46d8 + 0x10) + 0x48))(local_46d8 + 0x10);
                        _snprintf(local_e58,0xff,"%u");
                        pcVar10 = local_e58;
                        do {
                          cVar1 = *pcVar10;
                          pcVar10[(longlong)param_2 - (longlong)local_e58] = cVar1;
                          pcVar10 = pcVar10 + 1;
                        } while (cVar1 != '\0');
                        uVar20 = 0xffffffffffffffff;
                        pcVar10 = local_e58;
                        do {
                          if (uVar20 == 0) break;
                          uVar20 = uVar20 - 1;
                          cVar1 = *pcVar10;
                          pcVar10 = pcVar10 + 1;
                        } while (cVar1 != '\0');
                        pcVar9 = pcVar9 + 5;
                        param_2 = param_2 + (~uVar20 - 1);
                      }
                      else {
                        iVar2 = _strnicmp(pcVar9,"npc_ownerid",0xb);
                        if (iVar2 == 0) {
                          local_c58[0] = '\0';
                          memset(local_c58 + 1,0,0xff);
                          FUN_1400872b0(local_46d8,1);
                          _snprintf(local_c58,0xff,"%u");
                          pcVar10 = local_c58;
                          do {
                            cVar1 = *pcVar10;
                            pcVar10[(longlong)param_2 - (longlong)local_c58] = cVar1;
                            pcVar10 = pcVar10 + 1;
                          } while (cVar1 != '\0');
                          uVar20 = 0xffffffffffffffff;
                          pcVar10 = local_c58;
                          do {
                            if (uVar20 == 0) break;
                            uVar20 = uVar20 - 1;
                            cVar1 = *pcVar10;
                            pcVar10 = pcVar10 + 1;
                          } while (cVar1 != '\0');
                          pcVar9 = pcVar9 + 0xb;
                          param_2 = param_2 + (~uVar20 - 1);
                        }
                        else {
                          iVar2 = _strnicmp(pcVar9,"npc_life",8);
                          if (iVar2 == 0) {
                            local_a58[0] = '\0';
                            memset(local_a58 + 1,0,0xff);
                            FUN_1400872b0(local_46d8,0x18);
                            _snprintf(local_a58,0xff,"%u");
                            pcVar10 = local_a58;
                            do {
                              cVar1 = *pcVar10;
                              pcVar10[(longlong)param_2 - (longlong)local_a58] = cVar1;
                              pcVar10 = pcVar10 + 1;
                            } while (cVar1 != '\0');
                            uVar20 = 0xffffffffffffffff;
                            pcVar10 = local_a58;
                            do {
                              if (uVar20 == 0) break;
                              uVar20 = uVar20 - 1;
                              cVar1 = *pcVar10;
                              pcVar10 = pcVar10 + 1;
                            } while (cVar1 != '\0');
                            pcVar9 = pcVar9 + 8;
                            param_2 = param_2 + (~uVar20 - 1);
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          if (param_8 != 0) {
            plVar8 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0x3c0);
              log_InlineLogERROR(&DAT_1406d9c10);
              plVar8 = (longlong *)0x0;
            }
            lVar19 = (**(code **)(*plVar8 + 0x60))(plVar8,param_8);
            if (lVar19 != 0) {
              iVar2 = _strnicmp(pcVar9,"item_type",9);
              if (iVar2 == 0) {
                local_858[0] = '\0';
                memset(local_858 + 1,0,0xff);
                FUN_1400fda10(lVar19,1,1);
                _snprintf(local_858,0xff,"%u");
                pcVar10 = local_858;
                do {
                  cVar1 = *pcVar10;
                  pcVar10[(longlong)param_2 - (longlong)local_858] = cVar1;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                uVar20 = 0xffffffffffffffff;
                pcVar10 = local_858;
                do {
                  if (uVar20 == 0) break;
                  uVar20 = uVar20 - 1;
                  cVar1 = *pcVar10;
                  pcVar10 = pcVar10 + 1;
                } while (cVar1 != '\0');
                pcVar9 = pcVar9 + 9;
                param_2 = param_2 + (~uVar20 - 1);
              }
              else {
                iVar2 = _strnicmp(pcVar9,"item_data",9);
                if (iVar2 == 0) {
                  local_658[0] = '\0';
                  memset(local_658 + 1,0,0xff);
                  FUN_1400fda10(lVar19,0xd,1);
                  _snprintf(local_658,0xff,"%u");
                  pcVar10 = local_658;
                  do {
                    cVar1 = *pcVar10;
                    pcVar10[(longlong)param_2 - (longlong)local_658] = cVar1;
                    pcVar10 = pcVar10 + 1;
                  } while (cVar1 != '\0');
                  uVar20 = 0xffffffffffffffff;
                  pcVar10 = local_658;
                  do {
                    if (uVar20 == 0) break;
                    uVar20 = uVar20 - 1;
                    cVar1 = *pcVar10;
                    pcVar10 = pcVar10 + 1;
                  } while (cVar1 != '\0');
                  pcVar9 = pcVar9 + 9;
                  param_2 = param_2 + (~uVar20 - 1);
                }
              }
            }
          }
          param_5 = local_4698;
          param_1 = local_4688;
          param_6 = local_4690;
          if (iVar21 != 0) {
            uVar7 = 0;
            for (; param_2 < local_4660; param_2 = param_2 + 1) {
              uVar7 = uVar7 + 1;
              if (1000000 < uVar7) {
                local_46f8 = (undefined4 *)CONCAT44(local_46f8._4_4_,0x4b7);
                log_InlineLogERROR(&DAT_1406d9c10);
                param_5 = local_4698;
                param_1 = local_4688;
                param_6 = local_4690;
                break;
              }
              *param_2 = ' ';
            }
          }
        }
        else {
          *param_2 = *param_3;
          pcVar9 = param_3 + 1;
          param_2 = param_2 + 1;
        }
        param_3 = pcVar9;
        cVar1 = *pcVar9;
      }
      *param_2 = '\0';
    }
  }
  return;
}

// ==== CMsgQuench::helper_140122f90  @140122f90  [medium:callgraph-r1]  (orig: FUN_140122f90)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140122f90(longlong param_1,int param_2,longlong *param_3,undefined4 param_4,undefined4 param_5,
             char *param_6)

{
  char cVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  undefined8 uVar10;
  ulonglong uVar11;
  char *pcVar12;
  undefined1 auStack_1528 [32];
  char *local_1508;
  undefined1 *local_1500;
  char *local_14f8;
  uint local_14f0;
  char *local_14e8;
  undefined4 local_14e0;
  undefined1 local_14d8;
  char local_14c8;
  int local_14c4;
  uint local_14c0;
  char *local_14b8;
  longlong *local_14b0;
  undefined8 local_14a8;
  undefined1 local_1498 [1104];
  char local_1048 [256];
  undefined1 local_f48;
  undefined1 local_f47 [255];
  char local_e48;
  undefined1 local_e47 [254];
  undefined1 local_d49;
  undefined1 local_a8a;
  char local_a48 [256];
  char local_948 [256];
  undefined1 local_848;
  undefined1 local_847 [957];
  undefined1 local_48a;
  char local_448;
  undefined1 local_447 [254];
  undefined1 local_349;
  ulonglong local_48;
  undefined8 uStack_40;
  
  uStack_40 = 0x140122fa6;
  local_14a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_1528;
  local_14b8 = param_6;
  if (param_2 == 0) {
    uVar10 = 0;
  }
  else {
    *(longlong **)(param_1 + 8) = param_3;
    *(undefined4 *)(param_1 + 0x18) = param_4;
    local_14c0 = 0;
    local_14c4 = param_2;
    local_14b0 = param_3;
    do {
      pcVar12 = local_14b8;
      uVar2 = local_14c0;
      if (local_14c4 == 0) goto LAB_140123565;
      plVar9 = DAT_140975b88;
      if (DAT_140975b88 == (longlong *)0x0) {
        local_1508 = (char *)CONCAT44(local_1508._4_4_,0x3c4);
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar9 = (longlong *)0x0;
      }
      puVar8 = (undefined8 *)(**(code **)(*plVar9 + 0x40))();
      if (puVar8 == (undefined8 *)0x0) {
        log_InlineLogDBERROR
                  (
                  "table:cq_action/cq_newaction, CGameAction::ProcessEqpQuenchAction Error: game action %u not found."
                  );
        goto LAB_140123565;
      }
      local_848 = 0;
      memset(local_847,0,0x3ff);
      plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,5);
      uVar10 = (**(code **)(*plVar9 + 0x78))(plVar9);
      FUN_1401184a0(param_1,&local_848,uVar10,0x400);
      local_48a = 0;
      local_e48 = '\0';
      memset(local_e47,0,0x3ff);
      local_14f0 = *(uint *)(param_1 + 0x18);
      local_14f8 = *(char **)(param_1 + 0x10);
      local_1500 = *(undefined1 **)(param_1 + 8);
      local_1508 = pcVar12;
      FUN_14011efb0(param_1,&local_e48,&local_848,0x400);
      local_a8a = 0;
      local_d49 = 0;
      if ((*(longlong *)(param_1 + 8) != 0) &&
         (cVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 8) + 0x10) + 0x238))(),
         cVar1 != '\0')) {
        local_448 = '\0';
        memset(local_447,0,0x3ff);
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,4);
        uVar2 = (**(code **)(*plVar9 + 0x48))(plVar9);
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,3);
        uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,2);
        uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,1);
        uVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
        FUN_1400bb7e0(puVar8);
        local_14e8 = &local_e48;
        local_14f8 = (char *)CONCAT44(local_14f8._4_4_,uVar3);
        local_1508 = (char *)CONCAT44(local_1508._4_4_,uVar5);
        local_14f0 = uVar2;
        local_1500._0_4_ = uVar4;
        _snprintf(&local_448,0x3ff,"%d: [%d,%d]. type[%d], data[%d], param:[%s].");
        local_349 = 0;
        FUN_14015b240(local_1498);
        uVar10 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 8) + 0x10) + 0x18))();
        local_14d8 = 1;
        local_14e0 = 0;
        local_14e8 = (char *)((ulonglong)local_14e8 & 0xffffffff00000000);
        local_14f0 = local_14f0 & 0xffff0000;
        local_14f8 = (char *)CONCAT62(local_14f8._2_6_,2000);
        local_1500 = (undefined1 *)CONCAT44(local_1500._4_4_,0xffff00);
        local_1508 = (char *)0x0;
        iVar6 = FUN_14015b300(local_1498,"SYSTEM",uVar10,&local_448);
        if (iVar6 != 0) {
          plVar9 = (longlong *)(*(longlong *)(param_1 + 8) + 0x10);
          (**(code **)(*plVar9 + 0x350))(plVar9,local_1498);
        }
        FUN_14015b2c0(local_1498);
        pcVar12 = local_14b8;
        param_3 = local_14b0;
        uVar2 = local_14c0;
      }
      local_14c8 = '\0';
      plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,3);
      iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
      if (iVar6 == 0x214) {
        local_1500 = (undefined1 *)CONCAT44(local_1500._4_4_,param_5);
        local_1508 = (char *)CONCAT44(local_1508._4_4_,*(undefined4 *)(param_1 + 0x18));
        local_14f8 = pcVar12;
        local_14c8 = FUN_14011b910(param_1,puVar8,&local_e48,*(undefined8 *)(param_1 + 8));
LAB_1401234c6:
        if (local_14c8 == '\0') goto LAB_140123514;
LAB_1401234cb:
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,1);
        local_14c4 = (**(code **)(*plVar9 + 0x48))(plVar9);
      }
      else {
        if (iVar6 == 0x3f2) {
          plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,4);
          iVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
          if (iVar6 == 0) {
            iVar6 = 2000;
          }
          (**(code **)(*param_3 + 0x150))(param_3,iVar6,&DAT_1406e4608,&local_e48);
          local_14c8 = '\x01';
          goto LAB_1401234cb;
        }
        if (iVar6 == 0x3e9) {
          local_f48 = 0;
          memset(local_f47,0,0xff);
          local_1500 = &local_f48;
          local_1508 = local_948;
          iVar6 = sscanf(&local_e48,"%s %s %s %s");
          if (iVar6 < 3) {
            FUN_1400bb7e0(puVar8);
            log_InlineLogDBERROR(&DAT_14070c010);
            goto LAB_140123565;
          }
          uVar11 = _strtoi64(local_948,(char **)0x0,10);
          iVar6 = _stricmp(local_a48,"vip");
          if (iVar6 == 0) {
            iVar6 = _stricmp(local_1048,"==");
            if (iVar6 == 0) {
              uVar7 = FUN_1401649c0(param_3);
              local_14c8 = uVar11 == uVar7;
            }
            iVar6 = _stricmp(local_1048,"<");
            if (iVar6 == 0) {
              uVar7 = FUN_1401649c0(param_3);
              local_14c8 = (longlong)(ulonglong)uVar7 < (longlong)uVar11;
            }
            iVar6 = _stricmp(local_1048,">");
            if (iVar6 == 0) {
              uVar7 = FUN_1401649c0(param_3);
              local_14c8 = (longlong)uVar11 < (longlong)(ulonglong)uVar7;
              goto LAB_1401234c6;
            }
            local_14c8 = '\0';
          }
        }
        else {
          local_1508 = (char *)CONCAT44(local_1508._4_4_,0x5f6);
          log_InlineLogDBERROR
                    ("table:cq_action/cq_newaction, Game action %u has a bad type %d @%s,%d");
        }
LAB_140123514:
        plVar9 = (longlong *)(**(code **)(*(longlong *)*puVar8 + 0x10))((longlong *)*puVar8,2);
        local_14c4 = (**(code **)(*plVar9 + 0x48))(plVar9);
      }
      local_14c0 = uVar2 + 1;
    } while (uVar2 < 0x20);
    FUN_1400bb7e0(puVar8);
    log_InlineLogDBERROR
              (
              "table:cq_action/cq_newaction, Error: too many game action,cur action:%u, last action:%u."
              );
LAB_140123565:
    uVar10 = 1;
  }
  return uVar10;
}

// ==== CMsgQuench::helper_14016e130  @14016e130  [medium:callgraph-r3]  (orig: FUN_14016e130)
undefined8 FUN_14016e130(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  lVar2 = DAT_140975be0;
  if (DAT_140975be0 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
  lVar2 = FUN_14014de60(lVar2,0,uVar1);
  if (lVar2 != 0) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 8) + 0x10))(*(longlong **)(lVar2 + 8),1);
                    /* WARNING: Could not recover jumptable at 0x00014016e1af. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar4 = (**(code **)(*plVar3 + 0x58))(plVar3);
    return uVar4;
  }
  return 0;
}

// ==== CMsgQuench::helper_140174810  @140174810  [medium:callgraph-r3]  (orig: FUN_140174810)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_140174810(longlong param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  ulonglong uVar11;
  undefined1 auStack_478 [32];
  uint local_458;
  undefined4 local_450;
  uint local_448;
  undefined8 local_440;
  char local_438 [1023];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_478;
  uVar1 = *(uint *)(param_1 + 0xf10);
  local_458 = uVar1;
  local_450 = param_2;
  _snprintf(local_438,0x400,"SELECT * FROM %s WHERE account_id=%u && used=0 && type=%d");
  local_39 = 0;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,local_438,2);
  uVar10 = 0;
  if (plVar6 != (longlong *)0x0) {
    uVar10 = 0;
    local_448 = 0;
    lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
    uVar11 = uVar10;
    if (lVar7 != 0) {
      do {
        (**(code **)(*plVar6 + 0x30))(plVar6,uVar11);
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"ref_id");
        uVar2 = (**(code **)(*plVar8 + 0x40))(plVar8);
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"time_stamp");
        uVar3 = (**(code **)(*plVar8 + 0x50))(plVar8);
        plVar8 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,"chk_sum");
        iVar4 = (**(code **)(*plVar8 + 0x50))(plVar8);
        iVar5 = FUN_140164640(uVar1,uVar2,uVar3,0);
        if (iVar5 == iVar4) {
          local_448 = (int)uVar10 + 1;
          uVar10 = (ulonglong)local_448;
        }
        else if ((uVar1 ^ 780000) + (uVar2 >> 1) == iVar4) {
          local_448 = (int)uVar10 + 1;
          uVar10 = (ulonglong)local_448;
        }
        uVar11 = (ulonglong)((int)uVar11 + 1);
        uVar9 = (**(code **)(*plVar6 + 0x40))(plVar6);
      } while (uVar11 < uVar9);
    }
    (**(code **)*plVar6)(plVar6);
  }
  return uVar10;
}

// ==== CMsgQuench::helper_140175200  @140175200  [medium:callgraph-r3]  (orig: FUN_140175200)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140175200(longlong param_1)

{
  undefined8 *puVar1;
  undefined1 auStack_458 [32];
  uint local_438;
  undefined8 local_430;
  uint local_428;
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_458;
  local_438 = *(uint *)(param_1 + 0xf10);
  local_428 = local_438 ^ 0x109a00;
  local_430 = 0;
  _snprintf(local_418,0x400,
            "SELECT count(id) FROM %s WHERE account_id = %u AND used = %u AND chk_sum = %u + (ref_id >> 1)"
           );
  local_19 = 0;
  FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  puVar1 = (undefined8 *)InstanceGet();
  (**(code **)*puVar1)(puVar1,local_418);
  return;
}

// ==== CMsgQuench::helper_140176110  @140176110  [medium:callgraph-r3]  (orig: FUN_140176110)
int FUN_140176110(longlong param_1)

{
  int iVar1;
  ulong uVar2;
  int iVar3;
  int iVar4;
  
  iVar1 = FUN_140372ed0(param_1 + 0xe78);
  uVar2 = tq::TimeGet(3);
  if ((0 < iVar1) && (iVar1 != 0xff)) {
    iVar4 = 1;
    do {
      iVar3 = tq::DateStampPass(uVar2 + 19000000,iVar4);
      if (iVar3 == iVar1) {
        return iVar4;
      }
      iVar4 = iVar4 + 1;
    } while (iVar4 < 6);
  }
  return 0;
}

// ==== CMsgQuench::helper_140177f10  @140177f10  [medium:callgraph-r0]  (orig: FUN_140177f10)
void FUN_140177f10(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  longlong *plVar6;
  undefined8 uVar7;
  longlong *plVar8;
  
  cVar1 = FUN_140333220();
  if (cVar1 != '\0') {
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
    if (plVar6 != (longlong *)0x0) goto LAB_140177fcb;
  }
  cVar1 = FUN_140332fe0(param_1,param_2);
  if (cVar1 == '\0') {
    return;
  }
  plVar6 = (longlong *)FUN_140087d40();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x60))(plVar6,param_2);
  if (plVar6 == (longlong *)0x0) {
    return;
  }
  uVar2 = FUN_1400fda10(plVar6,1,1);
  cVar1 = FUN_1400ff940(uVar2);
  if (cVar1 == '\0') {
    return;
  }
LAB_140177fcb:
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
  cVar1 = FUN_14008abf0(uVar7);
  if ((cVar1 == '\0') || (cVar1 = FUN_140103310(plVar6), cVar1 == '\0')) {
    uVar2 = FUN_1400fda10(plVar6,1,1);
    iVar3 = FUN_1400ff680(uVar2);
    if ((iVar3 != 0x16) && (cVar1 = FUN_140332fe0(param_1,param_3), cVar1 != '\0')) {
      plVar8 = (longlong *)FUN_140087d40();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_3);
      if (plVar8 != (longlong *)0x0) {
        uVar2 = (**(code **)(*plVar8 + 8))(plVar8);
        uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
        uVar5 = FUN_1400fda10(plVar8,0x71,1);
        uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
        uVar7 = FUN_140087730(uVar7);
        cVar1 = FUN_140122f90(uVar7,uVar5,param_1,uVar4,uVar2,0);
        if (cVar1 != '\0') {
          FUN_140170e90(param_1,0x28bf);
          uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x1230));
          uVar7 = FUN_140087c40(uVar7);
          FUN_140261810(uVar7,param_1,0xd);
        }
      }
    }
  }
  return;
}

// ==== CMsgQuench::helper_140330ae0  @140330ae0  [medium:callgraph-r2]  (orig: FUN_140330ae0)
undefined8 FUN_140330ae0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  ulonglong uVar5;
  int iVar6;
  
  iVar6 = 0;
  iVar3 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2);
  if ((0 < iVar3) && (iVar3 = iVar3 + -1, uVar5 = (ulonglong)iVar3, -1 < iVar3)) {
    do {
      plVar1 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar5
         ) {
        _invalid_parameter_noinfo();
      }
      lVar4 = (**(code **)(*plVar1 + 0x60))
                        (plVar1,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar5 * 4));
      if ((lVar4 != 0) &&
         (((cVar2 = FUN_1400ffbe0(lVar4), cVar2 == '\0' || (param_3 == 1)) &&
          (cVar2 = FUN_1400ffc20(lVar4), cVar2 == '\0')))) {
        iVar3 = FUN_1400fda10(lVar4,1,1);
        if (iVar3 == 0xafc9b) {
          iVar3 = FUN_140100000(lVar4);
          iVar6 = iVar6 + iVar3 * 10;
        }
        else if (iVar3 == 0xb0944) {
          iVar3 = FUN_140100000(lVar4);
          iVar6 = iVar6 + iVar3 * 5;
        }
        else if (iVar3 - 0x109a01U < 2) {
          iVar3 = FUN_140100000(lVar4);
          iVar6 = iVar6 + iVar3;
        }
        if (param_2 <= iVar6) {
          return 1;
        }
      }
      uVar5 = uVar5 - 1;
    } while (-1 < (longlong)uVar5);
  }
  return 0;
}

// ==== CMsgQuench::helper_140330c40  @140330c40  [medium:callgraph-r2]  (orig: FUN_140330c40)
bool FUN_140330c40(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  int iVar6;
  longlong *plVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong *plVar10;
  int iVar11;
  longlong *plVar12;
  int iVar13;
  int local_res8;
  
  plVar10 = (longlong *)0x0;
  iVar3 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2);
  iVar2 = 0;
  local_res8 = 0;
  if (iVar3 < 1) {
    return false;
  }
  uVar9 = (ulonglong)(iVar3 + -1);
  iVar13 = 1;
  plVar5 = plVar10;
  plVar8 = plVar10;
  plVar12 = plVar10;
  iVar6 = iVar2;
  iVar11 = iVar2;
  if (-1 < iVar3 + -1) {
    do {
      plVar7 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar7 = plVar10;
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar9
         ) {
        _invalid_parameter_noinfo();
      }
      lVar4 = (**(code **)(*plVar7 + 0x60))
                        (plVar7,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar9 * 4));
      if (((lVar4 != 0) && (cVar1 = FUN_1400ffc20(lVar4), cVar1 == '\0')) &&
         ((cVar1 = FUN_1400ffbe0(lVar4), cVar1 == '\0' || (param_3 == 1)))) {
        iVar2 = FUN_1400fda10(lVar4,1,1);
        if (iVar2 == 0xafc9b) {
          plVar12 = (longlong *)(ulonglong)((int)plVar12 + 1);
        }
        else if (iVar2 == 0xb0944) {
          plVar8 = (longlong *)(ulonglong)((int)plVar8 + 1);
        }
        else if (iVar2 - 0x109a01U < 2) {
          plVar5 = (longlong *)(ulonglong)((int)plVar5 + 1);
          iVar2 = FUN_140100000(lVar4);
          local_res8 = local_res8 + iVar2;
        }
      }
      iVar11 = (int)plVar12;
      iVar2 = (int)plVar8;
      uVar9 = uVar9 - 1;
      iVar6 = local_res8;
    } while (-1 < (longlong)uVar9);
  }
  param_2 = param_2 - iVar6;
  if (param_2 < 1) {
    return true;
  }
  iVar6 = (0x28 - iVar3) + (int)plVar5;
  iVar3 = FUN_1400ffd10(0x109a01);
  if (1 < iVar3) {
    iVar13 = FUN_1400ffd10(0x109a01);
  }
  iVar3 = param_2 / 5;
  if ((iVar2 < iVar3) || (param_2 % 5 != 0)) {
    if (iVar3 < iVar2) {
      return ((iVar13 - param_2 % 5) + 4) / iVar13 <= iVar3 + 1 + iVar6;
    }
    param_2 = param_2 + iVar2 * -5;
    iVar3 = param_2 / 10;
    param_2 = param_2 % 10;
    if ((iVar11 < iVar3) || ((iVar3 == iVar11 && (0 < param_2)))) {
      return false;
    }
    if (param_2 != 0) {
      return ((iVar13 - param_2) + 9) / iVar13 <= iVar3 + 1 + iVar6 + iVar2;
    }
  }
  return true;
}

// ==== CMsgQuench::helper_1403503a0  @1403503a0  [medium:callgraph-r2]  (orig: FUN_1403503a0)
bool FUN_1403503a0(longlong param_1,int param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  int iVar7;
  ulonglong uVar8;
  int iVar9;
  int iVar10;
  undefined4 local_res8 [2];
  undefined4 local_res20 [2];
  
  iVar9 = 0;
  iVar7 = 0;
  iVar4 = 0;
  local_res8[0] = 0;
  iVar3 = (int)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2);
  if (iVar3 < 1) {
    return true;
  }
  iVar3 = iVar3 + -1;
  uVar8 = (ulonglong)iVar3;
  iVar10 = 0;
  if (-1 < iVar3) {
    do {
      plVar1 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      if ((ulonglong)(*(longlong *)(param_1 + 0xc28) - *(longlong *)(param_1 + 0xc20) >> 2) <= uVar8
         ) {
        _invalid_parameter_noinfo();
      }
      lVar5 = (**(code **)(*plVar1 + 0x60))
                        (plVar1,*(undefined4 *)(*(longlong *)(param_1 + 0xc20) + uVar8 * 4));
      iVar4 = iVar10;
      if ((lVar5 != 0) &&
         (((cVar2 = FUN_1400ffbe0(), cVar2 == '\0' || (param_3 == 1)) &&
          (cVar2 = FUN_1400ffc20(), cVar2 == '\0')))) {
        iVar3 = FUN_1400fda10(lVar5,1,1);
        if (iVar3 == 0xafc9b) {
          iVar4 = FUN_140100000();
          iVar4 = iVar10 + iVar4;
        }
        else if (iVar3 == 0xb0944) {
          iVar3 = FUN_140100000();
          iVar7 = iVar7 + iVar3;
        }
        else if (iVar3 - 0x109a01U < 2) {
          iVar3 = FUN_140100000();
          iVar9 = iVar9 + iVar3;
        }
      }
      uVar8 = uVar8 - 1;
      iVar10 = iVar4;
    } while (-1 < (longlong)uVar8);
  }
  if (param_2 <= iVar9) {
    local_res8[0] = 0;
    cVar2 = FUN_140344e80(param_1,0x109a01,0x109a02,param_2,param_3,local_res8,0);
    return cVar2 != '\0';
  }
  local_res20[0] = 0;
  cVar2 = FUN_140344e80(param_1,0x109a01,0x109a02,iVar9,param_3,local_res20,0);
  if (cVar2 != '\0') {
    param_2 = param_2 - iVar9;
    iVar3 = param_2 / 5;
    iVar9 = param_2 % 5;
    if (iVar7 < iVar3) {
      local_res20[0] = 0;
      cVar2 = FUN_140344e80(param_1,0xb0944,0xb0944,iVar7,param_3,local_res20,0);
      if (cVar2 == '\0') {
        return false;
      }
    }
    else {
      if (iVar3 < iVar7) {
        if (iVar9 != 0) {
          cVar2 = FUN_140344e80(param_1,0xb0944,0xb0944,iVar3 + 1,param_3,local_res8,0);
          if (cVar2 == '\0') {
            return false;
          }
          FUN_140346470(param_1,5 - iVar9,local_res8[0],1);
          return true;
        }
        uVar6 = 0xb0944;
        goto LAB_1403505ff;
      }
      local_res20[0] = 0;
      cVar2 = FUN_140344e80(param_1,0xb0944,0xb0944,iVar3,param_3,local_res20,0);
      if (cVar2 == '\0') {
        return false;
      }
      if (iVar9 == 0) {
        return true;
      }
    }
    param_2 = param_2 + iVar7 * -5;
    iVar3 = param_2 / 10;
    param_2 = param_2 % 10;
    if (iVar3 < iVar4) {
      if (param_2 == 0) {
        uVar6 = 0xafc9b;
LAB_1403505ff:
        local_res8[0] = 0;
        cVar2 = FUN_140344e80(param_1,uVar6,uVar6,iVar3,param_3,local_res8,0);
        return cVar2 != '\0';
      }
      cVar2 = FUN_140344e80(param_1,0xafc9b,0xafc9b,iVar3 + 1,param_3,local_res8,0);
      if (cVar2 != '\0') {
        FUN_140346470(param_1,10 - param_2,local_res8[0],1);
        return true;
      }
    }
    else {
      local_res8[0] = 0;
      cVar2 = FUN_140344e80(param_1,0xafc9b,0xafc9b,iVar3,param_3,local_res8,0);
      if (cVar2 != '\0') {
        return true;
      }
    }
  }
  return false;
}

// ==== CMsgQuench::helper_1403564b0  @1403564b0  [medium:callgraph-r1]  (orig: FUN_1403564b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

char FUN_1403564b0(longlong *param_1,int param_2,int param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  longlong *plVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  longlong lVar11;
  uint uVar12;
  char *pcVar13;
  bool bVar14;
  float fVar15;
  float fVar16;
  undefined1 auStack_a8 [32];
  uint local_88;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 local_5c;
  undefined4 local_58;
  char local_50 [8];
  ulonglong local_48;
  
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  if (((param_2 == 0) || (param_3 == 0)) || (cVar1 = FUN_140332fe0(), cVar1 == '\0')) {
    return '\0';
  }
  plVar7 = (longlong *)FUN_140087d40();
  plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_2);
  plVar8 = (longlong *)FUN_140087d40();
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_3);
  if ((plVar7 == (longlong *)0x0) || (plVar8 == (longlong *)0x0)) {
    return '\0';
  }
  cVar1 = FUN_1400ffbe0(plVar7);
  bVar14 = cVar1 != '\0';
  uVar2 = FUN_1400fda10(plVar7,1,1);
  cVar1 = FUN_1400ff940(uVar2);
  if (cVar1 != '\0') {
    iVar3 = FUN_1400fda10(plVar8,0x7e,1);
    iVar4 = FUN_1400fda10(plVar7,1,1);
    if (iVar3 == 0) {
      iVar3 = FUN_1400fda10(plVar8,0x7f,1);
      iVar4 = FUN_1400ff680(iVar4);
      if (iVar3 == 4) {
        iVar5 = FUN_1400fed80(plVar7);
        if (iVar5 == 0x262) {
          return '\0';
        }
        iVar5 = FUN_1400fed80(plVar7);
        if (iVar5 == 0x263) {
          return '\0';
        }
        iVar5 = FUN_1400fed80(plVar7);
        if (iVar5 == 0x264) {
          return '\0';
        }
        iVar5 = FUN_1400fed80(plVar7);
        if (iVar5 == 0x265) {
          return '\0';
        }
      }
      if (iVar3 != iVar4) {
        return '\0';
      }
    }
    else if (iVar3 - 100000U < 900000) {
      iVar4 = FUN_1400fed80(plVar7);
      if ((iVar3 / 1000 != iVar4) && (iVar3 % 1000 != iVar4)) {
        return '\0';
      }
    }
    else {
      iVar5 = FUN_1400fed80(plVar7);
      if (iVar3 == 5) {
        uVar2 = FUN_1400fda10(plVar7,1,1);
        cVar1 = FUN_14015f820(uVar2);
        if (cVar1 != '\0') {
          return '\0';
        }
        if (iVar5 == 0x1ff) {
          return '\0';
        }
      }
      for (; 999999 < iVar4; iVar4 = iVar4 / 10) {
      }
      local_50[0] = '\0';
      local_50[1] = '\0';
      local_50[2] = '\0';
      local_50[3] = '\0';
      local_50[4] = '\0';
      local_50[5] = '\0';
      _itoa(iVar3,local_50,10);
      lVar11 = -1;
      pcVar13 = local_50;
      do {
        if (lVar11 == 0) break;
        lVar11 = lVar11 + -1;
        cVar1 = *pcVar13;
        pcVar13 = pcVar13 + 1;
      } while (cVar1 != '\0');
      uVar12 = 6 - (~(uint)lVar11 - 1);
      fVar15 = DAT_140755ba8;
      fVar16 = DAT_140715a84;
      uVar6 = uVar12;
      if ((int)uVar12 < 0) {
        uVar6 = -uVar12;
      }
      while( true ) {
        if ((uVar6 & 1) != 0) {
          fVar16 = fVar16 * fVar15;
        }
        if (uVar6 >> 1 == 0) break;
        fVar15 = fVar15 * fVar15;
        uVar6 = uVar6 >> 1;
      }
      if ((int)uVar12 < 0) {
        fVar16 = DAT_140715a84 / fVar16;
      }
      if (iVar3 != iVar4 / (int)fVar16) {
        return '\0';
      }
    }
    iVar4 = FUN_1400fda10(plVar7,0x68,1);
    iVar3 = FUN_1400fda10(plVar8,0x68,1);
    if (iVar3 <= iVar4) {
      uVar2 = FUN_1400fda10(plVar8,0x9d,1);
      cVar1 = FUN_140330ae0(param_1,uVar2,bVar14);
      if (cVar1 != '\0') {
        cVar1 = FUN_140330c40(param_1,uVar2,bVar14);
        if (cVar1 == '\0') {
          pIVar9 = theInstance();
          lVar11 = param_1[2];
          uVar10 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_NOT_ENOUGH_PACKSIZE");
          (**(code **)(lVar11 + 0x358))(param_1 + 2,uVar10);
          return '\0';
        }
        cVar1 = FUN_1403503a0(param_1,uVar2,bVar14);
        if (cVar1 != '\0') {
          local_78 = 0;
          local_74 = (**(code **)(*plVar7 + 8))(plVar7);
          local_70 = (**(code **)(*param_1 + 8))(param_1);
          local_6c = FUN_1400fda10(plVar8,1,1);
          local_68 = FUN_1400fda10(plVar8,0x9c,1);
          local_64 = 0;
          local_60 = 0;
          local_58 = 0;
          local_5c = 0x93a80;
          uVar2 = (**(code **)(*plVar8 + 8))(plVar8);
          local_88 = local_88 & 0xffffff00;
          cVar1 = FUN_14033a6a0(param_1,uVar2,1,0);
          if (cVar1 != '\0') {
            uVar2 = FUN_1401649c0(param_1);
            cVar1 = FUN_140102a10(plVar7,&local_78,uVar2,0);
            if (cVar1 != '\0') {
              uVar2 = (**(code **)(*plVar7 + 8))(plVar7);
              FUN_140334e70(param_1,uVar2,1);
              uVar2 = (**(code **)(*plVar7 + 8))(plVar7);
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              (**(code **)(*param_1 + 8))(param_1);
              local_88 = uVar2;
              tq::MyLogSave("gmlog/ForgeItem","User[%u][%s] ForgeItem[idItem=%u] success");
              uVar10 = FUN_140008520((int)param_1[0x246]);
              uVar10 = FUN_140087c40(uVar10);
              FUN_140261810(uVar10,param_1,0xd);
              return cVar1;
            }
            return '\0';
          }
          uVar2 = (**(code **)(*plVar8 + 8))(plVar8);
          (**(code **)(param_1[2] + 0x18))(param_1 + 2);
          (**(code **)(*param_1 + 8))(param_1);
          local_88 = uVar2;
          tq::MyLogSave("gmlog/ForgeItem","User[%u][%s] ForgeItem Erase GodSoulItem[%u] failed");
        }
      }
    }
  }
  return '\0';
}

// ==== CMsgQuench::helper_140358720  @140358720  [medium:callgraph-r0]  (orig: FUN_140358720)
void FUN_140358720(longlong *param_1,int param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  __time32_t _Var5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 uVar9;
  longlong *plVar10;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  int local_1c;
  undefined4 local_18;
  
  if ((((param_2 != 0) && (param_3 != 0)) && (param_2 != param_3)) &&
     (cVar2 = FUN_140332fe0(param_1,param_3), cVar2 != '\0')) {
    plVar7 = (longlong *)FUN_140087d40();
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x60))(plVar7,param_3);
    if (((plVar7 != (longlong *)0x0) && (iVar3 = FUN_1400fda10(plVar7,0x9c,1), 0 < iVar3)) &&
       ((cVar2 = FUN_1400ffc20(plVar7), cVar2 == '\0' &&
        (cVar2 = FUN_140332fe0(param_1,param_2), cVar2 != '\0')))) {
      plVar8 = (longlong *)FUN_140087d40();
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x60))(plVar8,param_2);
      if (plVar8 != (longlong *)0x0) {
        uVar9 = FUN_140008520((int)param_1[0x246]);
        cVar2 = FUN_14008abf0(uVar9);
        if ((cVar2 == '\0') || (cVar2 = FUN_140103310(plVar8), cVar2 == '\0')) {
          uVar4 = FUN_1400fda10(plVar8,1,1);
          iVar3 = FUN_1400ff680(uVar4);
          if (iVar3 != 0x16) {
            plVar10 = (longlong *)FUN_140100290(plVar8);
            bVar1 = false;
            if (plVar10 != (longlong *)0x0) {
              local_38 = 0;
              bVar1 = true;
              local_34 = (**(code **)*plVar10)(plVar10);
              local_30 = (**(code **)(*param_1 + 8))(param_1);
              local_2c = (**(code **)(*plVar10 + 0x30))(plVar10,3);
              local_28 = (**(code **)(*plVar10 + 0x30))(plVar10,4);
              local_24 = (**(code **)(*plVar10 + 0x10))(plVar10);
              local_20 = (**(code **)(*plVar10 + 0x18))(plVar10);
              local_18 = (**(code **)(*plVar10 + 0x30))(plVar10,8);
              iVar3 = (**(code **)(*plVar10 + 0x30))(plVar10,7);
              if (iVar3 == 0) {
                local_1c = 0;
              }
              else {
                iVar3 = (**(code **)(*plVar10 + 0x30))(plVar10,7);
                _Var5 = _time32((__time32_t *)0x0);
                local_1c = iVar3 - _Var5;
                if (local_1c == 0) {
                  bVar1 = false;
                }
              }
              FUN_140100210(plVar8,0);
            }
            uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
            uVar6 = (**(code **)(*plVar8 + 8))(plVar8);
            cVar2 = FUN_1403564b0(param_1,uVar6,uVar4);
            if ((cVar2 == '\0') && (bVar1)) {
              FUN_140102a10(plVar8,&local_38,0,0);
              uVar4 = (**(code **)(*plVar8 + 8))(plVar8);
              FUN_140334e70(param_1,uVar4,0);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgQuench::ctor_or_dtor  @140452310  [high:vtable-assign]  (orig: FUN_140452310)
undefined8 * FUN_140452310(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgQuench::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgQuench::ctor_or_dtor  @140452360  [high:vtable-assign]  (orig: FUN_140452360)
void FUN_140452360(undefined8 *param_1)

{
  *param_1 = CMsgQuench::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgQuench::vfunc_1  @140452400  [high:rtti-vtable]  (orig: FUN_140452400)
undefined8 FUN_140452400(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgQuench::ctor_or_dtor  @140452430  [high:vtable-assign]  (orig: FUN_140452430)
undefined8 * FUN_140452430(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgQuench::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgQuench::vfunc_3  @140452480  [high:rtti-vtable]  (orig: FUN_140452480)
void FUN_140452480(longlong param_1)

{
  short *psVar1;
  longlong lVar2;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))(*(longlong **)(lVar2 + 0x90),param_1);
  if (((lVar2 != 0) && (-1 < *(int *)(*(longlong *)(param_1 + 0x428) + 4))) &&
     (-1 < *(int *)(*(longlong *)(param_1 + 0x428) + 8))) {
    psVar1 = *(short **)(param_1 + 0x428);
    if (*psVar1 == 0) {
      FUN_140177f10(lVar2,*(undefined4 *)(psVar1 + 2),*(undefined4 *)(psVar1 + 4));
    }
    else if (*psVar1 == 1) {
      FUN_140358720(lVar2,*(undefined4 *)(psVar1 + 2),*(undefined4 *)(psVar1 + 4));
    }
    else {
      log_InlineLogERROR("Receive Error MsgQuech");
    }
  }
  return;
}

