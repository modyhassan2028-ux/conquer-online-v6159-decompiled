// ==== CTeamDiceMgr::helper_1402ea480  @1402ea480  [medium:callgraph-r0]  (orig: FUN_1402ea480)
void FUN_1402ea480(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ea480(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  return;
}

// ==== CTeamDiceMgr::helper_1402ea5b0  @1402ea5b0  [medium:callgraph-r1]  (orig: FUN_1402ea5b0)
void FUN_1402ea5b0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CTeamDiceMgr::helper_1402ea660  @1402ea660  [medium:callgraph-r1]  (orig: FUN_1402ea660)
void FUN_1402ea660(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1402ea480(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CTeamDiceMgr::helper_1402eb2b0  @1402eb2b0  [medium:callgraph-r0]  (orig: FUN_1402eb2b0)
longlong * FUN_1402eb2b0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402ea660(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402eae00(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CTeamDiceMgr::ctor_or_dtor  @1402ebf80  [high:vtable-assign]  (orig: FUN_1402ebf80)
void FUN_1402ebf80(undefined8 *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  undefined8 *puVar6;
  longlong lVar7;
  undefined8 uVar8;
  longlong *local_38;
  longlong *plStack_30;
  longlong *local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  uVar8 = 0xfffffffffffffffe;
  *param_1 = CTeamDiceMgr::vftable;
  plVar5 = *(longlong **)param_1[8];
  plVar2 = (longlong *)param_1[2];
  local_38 = plVar2;
  plStack_30 = plVar5;
  while( true ) {
    plVar3 = (longlong *)param_1[8];
    if ((plVar2 == (longlong *)0x0) || (plVar2 != (longlong *)param_1[2])) {
      _invalid_parameter_noinfo();
    }
    if (plVar5 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar5 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (plVar5[4] != 0) {
      FUN_14047ef60();
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar5 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar5[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar5 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (plStack_30 = plVar5, cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar5 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar5[1] + 0x29);
        plVar4 = (longlong *)plVar5[1];
        plVar3 = plVar5;
        while ((plVar5 = plVar4, plStack_30 = plVar5, cVar1 == '\0' &&
               (plVar3 == (longlong *)plVar5[2]))) {
          cVar1 = *(char *)(plVar5[1] + 0x29);
          plVar4 = (longlong *)plVar5[1];
          plVar3 = plVar5;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar6 = param_1 + 2;
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[8] + 8) + 0x29);
  plVar5 = *(longlong **)(param_1[8] + 8);
  while (cVar1 == '\0') {
    FUN_1402ea480(puVar6,plVar5[2]);
    plVar2 = (longlong *)*plVar5;
    operator_delete(plVar5);
    plVar5 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x29);
  }
  *(undefined8 *)(param_1[8] + 8) = param_1[8];
  param_1[9] = 0;
  *(undefined8 *)param_1[8] = param_1[8];
  *(undefined8 *)(param_1[8] + 0x10) = param_1[8];
  plStack_30 = (longlong *)param_1[8];
  local_38 = (longlong *)*puVar6;
  uStack_20 = *plStack_30;
  local_28 = local_38;
  FUN_1402eb2b0(puVar6,local_18,&local_28,&local_38,uVar8);
  operator_delete((void *)param_1[8]);
  param_1[8] = 0;
  param_1[9] = 0;
  operator_delete((void *)*puVar6);
  return;
}

// ==== CTeamDiceMgr::helper_1402ec180  @1402ec180  [medium:callgraph-r0]  (orig: FUN_1402ec180)
undefined8 * FUN_1402ec180(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1402ea5b0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CTeamDiceMgr::ctor_or_dtor  @1402ec200  [high:vtable-assign]  (orig: FUN_1402ec200)
undefined8 * FUN_1402ec200(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CTeamDiceMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1402ec180(param_1 + 2);
  return param_1;
}

// ==== CTeamDiceMgr::vfunc_0  @1402ec240  [high:rtti-vtable]  (orig: FUN_1402ec240)
void * FUN_1402ec240(void *param_1,uint param_2)

{
  FUN_1402ebf80();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CTeamDiceMgr::helper_14047e580  @14047e580  [medium:callgraph-r2]  (orig: FUN_14047e580)
void FUN_14047e580(longlong param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong lVar6;
  longlong *plVar7;
  
  plVar2 = *(longlong **)(param_1 + 0x28);
  plVar7 = (longlong *)**(undefined8 **)(param_1 + 0x58);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x58);
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar3) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *plVar2;
    }
    if (plVar7 == *(longlong **)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar6 = plVar7[3];
    lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 8));
    if (*(longlong *)(lVar5 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar6 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))
                      (*(longlong **)(lVar5 + 0x90),(int)lVar6);
    if (lVar6 != 0) {
      (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))((longlong *)(lVar6 + 0x10),param_2);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x21) == '\0') {
      plVar3 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar3 + 0x21) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x21);
        plVar7 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x21);
          plVar7 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x21);
        plVar4 = (longlong *)plVar7[1];
        plVar3 = plVar7;
        while ((plVar7 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x21);
          plVar4 = (longlong *)plVar7[1];
          plVar3 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return;
}

// ==== CTeamDiceMgr::helper_14047eba0  @14047eba0  [medium:callgraph-r1]  (orig: FUN_14047eba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14047eba0(longlong param_1)

{
  char cVar1;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  undefined4 local_45c;
  undefined4 local_458;
  undefined4 local_454;
  undefined8 local_450;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_450 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  local_45c = 0;
  local_458 = 0;
  local_454 = 0;
  local_468 = *(undefined4 *)(param_1 + 0x1c);
  local_464 = *(undefined4 *)(param_1 + 0x18);
  local_460 = 2;
  FUN_140455550(local_448);
  cVar1 = FUN_140455600(local_448,&local_468);
  if (cVar1 != '\0') {
    FUN_14047e580(param_1,local_448);
  }
  FUN_1404555a0(local_448);
  return;
}

// ==== CTeamDiceMgr::helper_14047ef60  @14047ef60  [medium:callgraph-r0]  (orig: FUN_14047ef60)
void FUN_14047ef60(undefined8 *param_1)

{
  longlong lVar1;
  longlong *plVar2;
  
  if (*(int *)((longlong)param_1 + 0x14) != 0) {
    FUN_14047eba0();
  }
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,*(undefined4 *)((longlong)param_1 + 0x1c));
  if (lVar1 != 0) {
    plVar2 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)0x0;
    }
    (**(code **)(*plVar2 + 0x30))(plVar2,*(undefined4 *)((longlong)param_1 + 0x1c),1,0);
  }
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
                    /* WARNING: Could not recover jumptable at 0x00014047f018. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)*param_1)(param_1,1);
  return;
}

