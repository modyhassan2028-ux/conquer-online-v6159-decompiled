// ==== CMsgMagicCoat::ctor_or_dtor  @1404f67b0  [high:vtable-assign]  (orig: FUN_1404f67b0)
undefined8 * FUN_1404f67b0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgMagicCoat::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgMagicCoat::ctor_or_dtor  @1404f6800  [high:vtable-assign]  (orig: FUN_1404f6800)
void FUN_1404f6800(undefined8 *param_1)

{
  *param_1 = CMsgMagicCoat::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgMagicCoat::vfunc_1  @1404f6830  [high:rtti-vtable]  (orig: FUN_1404f6830)
ulonglong FUN_1404f6830(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0xa96);
}

// ==== CMsgMagicCoat::vfunc_3  @1404f68b0  [high:rtti-vtable]  (orig: FUN_1404f68b0)
void FUN_1404f68b0(void)

{
  return;
}

// ==== CMsgMagicCoat::ctor_or_dtor  @1404f68c0  [high:vtable-assign]  (orig: FUN_1404f68c0)
undefined8 * FUN_1404f68c0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgMagicCoat::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

