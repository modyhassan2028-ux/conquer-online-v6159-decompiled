// ==== CMsgItemInfoEx::ctor_or_dtor  @140387320  [high:vtable-assign]  (orig: FUN_140387320)
undefined8 * FUN_140387320(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgItemInfoEx::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgItemInfoEx::ctor_or_dtor  @140387370  [high:vtable-assign]  (orig: FUN_140387370)
void FUN_140387370(undefined8 *param_1)

{
  *param_1 = CMsgItemInfoEx::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgItemInfoEx::vfunc_1  @1403873a0  [high:rtti-vtable]  (orig: FUN_1403873a0)
ulonglong FUN_1403873a0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x454);
}

// ==== CMsgItemInfoEx::vfunc_3  @1403876b0  [high:rtti-vtable]  (orig: FUN_1403876b0)
void FUN_1403876b0(void)

{
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMsgItemInfoEx::ctor_or_dtor  @1403876f0  [high:vtable-assign]  (orig: FUN_1403876f0)
undefined8 * FUN_1403876f0(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgItemInfoEx::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

