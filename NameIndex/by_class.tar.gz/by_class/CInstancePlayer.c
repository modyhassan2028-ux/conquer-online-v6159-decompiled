// ==== CInstancePlayer::helper_140420d80  @140420d80  [medium:callgraph-r0]  (orig: FUN_140420d80)
void FUN_140420d80(void *param_1)

{
  if ((DAT_1409763d8 & 1) == 0) {
    DAT_1409763d8 = DAT_1409763d8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763d0,"CInstancePlayer");
    atexit((_func_5014 *)&LAB_1406d6de0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140420dd5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763d0,param_1);
  return;
}

// ==== CInstancePlayer::ctor_or_dtor  @140420e70  [high:vtable-assign]  (orig: FUN_140420e70)
undefined8 * FUN_140420e70(undefined8 *param_1,byte param_2)

{
  *param_1 = CInstancePlayer::vftable;
  if ((param_2 & 1) != 0) {
    FUN_140420d80();
  }
  return param_1;
}

// ==== CInstancePlayer::ctor_or_dtor  @140420ea0  [high:vtable-assign]  (orig: FUN_140420ea0)
undefined8 * FUN_140420ea0(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined8 *puVar1;
  
  if ((DAT_1409763d8 & 1) == 0) {
    DAT_1409763d8 = DAT_1409763d8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763d0,"CInstancePlayer");
    atexit((_func_5014 *)&LAB_1406d6de0);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_1409763d0,0x20);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CInstancePlayer::vftable;
    *(undefined4 *)(puVar1 + 3) = 0;
    *(undefined4 *)((longlong)puVar1 + 0x1c) = 0;
    *(undefined4 *)(puVar1 + 1) = param_1;
    *(undefined4 *)((longlong)puVar1 + 0xc) = param_2;
    *(undefined4 *)(puVar1 + 2) = param_3;
    *(undefined4 *)((longlong)puVar1 + 0x14) = 0;
  }
  return puVar1;
}

