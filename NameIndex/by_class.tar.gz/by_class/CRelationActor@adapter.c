// ==== CRelationActor@adapter::helper_140092b60  @140092b60  [medium:callgraph-r0]  (orig: FUN_140092b60)
void FUN_140092b60(longlong param_1,int *param_2)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  ulonglong uVar4;
  int local_1a8;
  undefined1 local_1a4 [412];
  
  if ((*param_2 != 0) &&
     (lVar2 = (**(code **)(**(longlong **)(param_1 + 0x90) + 0x98))
                        (*(longlong **)(param_1 + 0x90),*param_2), lVar2 != 0)) {
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x90) + 0x98))();
    iVar1 = FUN_1401649c0(uVar3);
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x68));
    if (((int)*(uint *)(lVar2 + 0x2ac) < 1) ||
       (((*(uint *)(lVar2 + 0x2ac) >> 10 & 1) == 0 || (iVar1 < 0)))) {
      iVar1 = 0;
    }
    else if (6 < iVar1) {
      iVar1 = 6;
    }
    local_1a8 = 0;
    memset(local_1a4,0,400);
    if (*(int *)(&DAT_1406f38a0 + (longlong)iVar1 * 4) != -1) {
      lVar2 = -4 - (longlong)param_2;
      uVar4 = (ulonglong)(*(int *)(&DAT_1406f38a0 + (longlong)iVar1 * 4) + 1);
      do {
        if (*param_2 != 0) {
          *(int *)(local_1a4 + lVar2 + (longlong)param_2) = *param_2;
        }
        param_2 = param_2 + 1;
        uVar4 = uVar4 - 1;
      } while (uVar4 != 0);
    }
    (**(code **)(**(longlong **)(param_1 + 0x80) + 0x50))
              (*(longlong **)(param_1 + 0x80),8,0x15f94,0x194,&local_1a8);
    return;
  }
  log_InlineLogERROR("CMapGroup::SendChatFriendInfo, idUser <= ID_NONE.");
  return;
}

// ==== CRelationActor@adapter::helper_140226d50  @140226d50  [medium:callgraph-r0]  (orig: FUN_140226d50)
undefined8 FUN_140226d50(longlong param_1,uint param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x29);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x29);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(uint *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar9) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = *(longlong **)(lVar4 + 0x20);
    if (plVar6 != (longlong *)0x0) {
      plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,2);
      uVar7 = (**(code **)(*plVar6 + 0x78))(plVar6);
      return uVar7;
    }
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return 0;
}

// ==== CRelationActor@adapter::helper_140226f90  @140226f90  [medium:callgraph-r1]  (orig: FUN_140226f90)
undefined8 FUN_140226f90(longlong param_1,undefined4 param_2,longlong param_3)

{
  char cVar1;
  undefined8 uVar2;
  longlong *plVar3;
  undefined4 local_40 [2];
  longlong *local_38;
  undefined1 local_30 [24];
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    plVar3 = (longlong *)InstanceGet();
    local_38 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_facebook");
    uVar2 = 0;
    if (local_38 != (longlong *)0x0) {
      plVar3 = (longlong *)(**(code **)(*local_38 + 0x10))(local_38,1);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2);
      plVar3 = (longlong *)(**(code **)(*local_38 + 0x10))(local_38,2);
      (**(code **)(*plVar3 + 0x80))(plVar3,param_3);
      cVar1 = (**(code **)(*local_38 + 0x50))(local_38,1);
      if (cVar1 == '\0') {
        (**(code **)*local_38)(local_38,1);
        uVar2 = 0;
      }
      else {
        local_40[0] = param_2;
        FUN_14002d3d0(param_1 + 0x10,local_30,local_40);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CRelationActor@adapter::helper_1402271f0  @1402271f0  [medium:callgraph-r0]  (orig: FUN_1402271f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1402271f0(longlong param_1,undefined4 param_2,longlong param_3)

{
  longlong *plVar1;
  bool bVar2;
  undefined8 uVar3;
  longlong *plVar4;
  char *pcVar5;
  longlong lVar6;
  undefined1 auStack_a8 [32];
  undefined4 local_88;
  undefined4 local_78 [2];
  longlong *local_70;
  longlong local_68;
  undefined8 local_60;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_58 [24];
  longlong local_40;
  ulonglong local_30;
  
  local_60 = 0xfffffffffffffffe;
  local_30 = DAT_1409707c0 ^ (ulonglong)auStack_a8;
  local_78[0] = param_2;
  if (param_3 == 0) {
    local_88 = 0x65;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","lpszFacebookID",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\facebookinfomgr.cpp"
                      );
    return 0;
  }
  FUN_14002d940(param_1 + 0x10,&local_70,local_78);
  lVar6 = *(longlong *)(param_1 + 0x40);
  if ((local_70 == (longlong *)0x0) || (local_70 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (local_68 != lVar6) {
    if (local_70 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar6 = 0;
    }
    else {
      lVar6 = *local_70;
    }
    if (local_68 == *(longlong *)(lVar6 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_68 + 0x20);
    if (plVar1 != (longlong *)0x0) {
      plVar4 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
      pcVar5 = (char *)(**(code **)(*plVar4 + 0x78))(plVar4);
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_58,pcVar5);
      if ((local_40 == 0) ||
         (bVar2 = std::operator==<char,std::char_traits<char>,std::allocator<char>_>(local_58,""),
         bVar2)) {
        plVar4 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
        (**(code **)(*plVar4 + 0x80))(plVar4,param_3);
        (**(code **)(*plVar1 + 0x38))(plVar1,0);
      }
      std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
      ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_58);
      return 1;
    }
    local_88 = 0x6e;
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF",&DAT_1406e5370,
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\facebookinfomgr.cpp"
                      );
    return 0;
  }
  uVar3 = FUN_140226f90(param_1,param_2,param_3);
  return uVar3;
}

// ==== CRelationActor@adapter::helper_14027a2d0  @14027a2d0  [medium:callgraph-r0]  (orig: FUN_14027a2d0)
undefined4 FUN_14027a2d0(longlong param_1,uint param_2,short param_3)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  plVar1 = (longlong *)(param_1 + 8);
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar2 = *(char *)((longlong)puVar7 + 0x2d);
  puVar4 = *(undefined8 **)(param_1 + 0x38);
  while (cVar2 == '\0') {
    if (*(uint *)(puVar7 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar7[2];
      puVar7 = puVar4;
    }
    else {
      puVar6 = (undefined8 *)*puVar7;
    }
    puVar4 = puVar7;
    puVar7 = puVar6;
    cVar2 = *(char *)((longlong)puVar6 + 0x2d);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x38);
  local_40 = puVar4;
  local_48 = *plVar1;
  if (*plVar1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar7) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x38);
    local_38 = *plVar1;
  }
  else {
    plVar8 = &local_48;
  }
  plVar3 = (longlong *)*plVar8;
  lVar9 = *(longlong *)(param_1 + 0x38);
  local_28 = plVar3;
  local_20 = plVar8[1];
  if (((longlong *)*plVar1 == (longlong *)0x0) || ((longlong *)*plVar1 != plVar3)) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_20;
  if (lVar9 != local_20) {
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar3;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    if (*(short *)(lVar5 + 0x20) == param_3) {
      local_28 = (longlong *)*plVar8;
      local_20 = plVar8[1];
      FUN_140279680(plVar1,&local_38,&local_28);
      return *(undefined4 *)(lVar5 + 0x1c);
    }
  }
  return 0;
}

// ==== CRelationActor@adapter::vfunc_1  @14058c760  [high:rtti-vtable]  (orig: FUN_14058c760)
void FUN_14058c760(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CRelationActor@adapter::vfunc_3  @14058c780  [high:rtti-vtable]  (orig: FUN_14058c780)
ulonglong FUN_14058c780(longlong param_1,undefined8 param_2,undefined8 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058c7dc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),param_3);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_4  @14058c7f0  [high:rtti-vtable]  (orig: FUN_14058c7f0)
bool FUN_14058c7f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CRelationActor@adapter::vfunc_5  @14058c810  [high:rtti-vtable]  (orig: FUN_14058c810)
undefined4 FUN_14058c810(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0xffffffff;
  }
  return *(undefined4 *)(lVar1 + 0x122c);
}

// ==== CRelationActor@adapter::vfunc_8  @14058c870  [high:rtti-vtable]  (orig: FUN_14058c870)
undefined8 FUN_14058c870(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058c8c3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x198))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_9  @14058c8d0  [high:rtti-vtable]  (orig: FUN_14058c8d0)
undefined8 FUN_14058c8d0(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058c921. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_10  @14058c930  [high:rtti-vtable]  (orig: FUN_14058c930)
undefined8 FUN_14058c930(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058c983. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_11  @14058c990  [high:rtti-vtable]  (orig: FUN_14058c990)
undefined8 FUN_14058c990(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058c9e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x30))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_13  @14058c9f0  [high:rtti-vtable]  (orig: FUN_14058c9f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

bool FUN_14058c9f0(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 local_res20;
  undefined1 auStack_438 [32];
  char local_418 [1023];
  undefined1 local_19;
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_438;
  if (param_3 == (char *)0x0) {
    return false;
  }
  local_res20 = param_4;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    _vsnprintf(local_418,0x400,param_3,(va_list)&local_res20);
    local_19 = 0;
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x358))((longlong *)(lVar1 + 0x10),local_418);
  }
  return lVar1 != 0;
}

// ==== CRelationActor@adapter::vfunc_14  @14058cab0  [high:rtti-vtable]  (orig: FUN_14058cab0)
undefined8 FUN_14058cab0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058cb03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_15  @14058cb10  [high:rtti-vtable]  (orig: FUN_14058cb10)
ulonglong FUN_14058cb10(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058cb63. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_16  @14058cb70  [high:rtti-vtable]  (orig: FUN_14058cb70)
undefined1 FUN_14058cb70(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x51c);
}

// ==== CRelationActor@adapter::vfunc_17  @14058cbd0  [high:rtti-vtable]  (orig: FUN_14058cbd0)
ulonglong FUN_14058cbd0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140177530(lVar1,param_3,param_4);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_21  @14058cc50  [high:rtti-vtable]  (orig: FUN_14058cc50)
void FUN_14058cc50(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_14018f460(lVar1,param_3,0,0);
  return;
}

// ==== CRelationActor@adapter::vfunc_22  @14058ccb0  [high:rtti-vtable]  (orig: FUN_14058ccb0)
undefined1
FUN_14058ccb0(undefined8 param_1,longlong param_2,int param_3,undefined8 param_4,undefined4 param_5,
             undefined2 param_6)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  puVar2 = (undefined8 *)FUN_1400e1de0();
  uVar1 = (**(code **)*puVar2)(puVar2,param_2,param_3,param_4,param_5,param_6);
  return uVar1;
}

// ==== CRelationActor@adapter::vfunc_23  @14058cd90  [high:rtti-vtable]  (orig: FUN_14058cd90)
ulonglong FUN_14058cd90(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  longlong lVar4;
  ulonglong extraout_RAX;
  undefined8 uVar5;
  ulonglong uVar6;
  undefined8 local_res8;
  
  lVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  plVar1 = (longlong *)(lVar4 + 0x10);
  local_res8 = 0;
  uVar2 = (**(code **)(*plVar1 + 0x48))(plVar1);
  uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar5 = (**(code **)(*plVar1 + 0x160))(plVar1);
  uVar6 = FUN_1402c84c0(uVar5,uVar3,uVar2,0x1001,param_3,&local_res8);
  return uVar6;
}

// ==== CRelationActor@adapter::vfunc_24  @14058ce60  [high:rtti-vtable]  (orig: FUN_14058ce60)
void FUN_14058ce60(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058cf0a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x340))((longlong *)(lVar1 + 0x10),param_3,param_4);
  return;
}

// ==== CRelationActor@adapter::vfunc_26  @14058cf20  [high:rtti-vtable]  (orig: FUN_14058cf20)
undefined8 FUN_14058cf20(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058cfa8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x70))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_27  @14058cfb0  [high:rtti-vtable]  (orig: FUN_14058cfb0)
undefined1 FUN_14058cfb0(longlong param_1,int param_2)

{
  longlong lVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0xeee);
}

// ==== CRelationActor@adapter::vfunc_28  @14058d040  [high:rtti-vtable]  (orig: FUN_14058d040)
int FUN_14058d040(longlong param_1,int param_2)

{
  longlong lVar1;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return (int)*(short *)(lVar1 + 0xef4);
}

// ==== CRelationActor@adapter::vfunc_29  @14058d0d0  [high:rtti-vtable]  (orig: FUN_14058d0d0)
undefined8 FUN_14058d0d0(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058d158. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_30  @14058d160  [high:rtti-vtable]  (orig: FUN_14058d160)
ulonglong FUN_14058d160(longlong param_1,int param_2)

{
  ulonglong extraout_RAX;
  longlong lVar1;
  ulonglong extraout_RAX_00;
  ulonglong uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058d1e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x180))(lVar1 + 0x10);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_31  @14058d1f0  [high:rtti-vtable]  (orig: FUN_14058d1f0)
undefined8 FUN_14058d1f0(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058d276. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x40))(plVar1);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_32  @14058d280  [high:rtti-vtable]  (orig: FUN_14058d280)
undefined8 FUN_14058d280(undefined8 param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar1 = (longlong *)FUN_140087ed0();
                    /* WARNING: Could not recover jumptable at 0x00014058d2d0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0xf8))(plVar1,param_2);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_40  @14058d2e0  [high:rtti-vtable]  (orig: FUN_14058d2e0)
void FUN_14058d2e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1401649c0(lVar1);
  return;
}

// ==== CRelationActor@adapter::vfunc_36  @14058d310  [high:rtti-vtable]  (orig: FUN_14058d310)
void FUN_14058d310(longlong param_1,undefined8 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x10) + 0x90))
                     (*(longlong **)(param_1 + 0x10),param_2,0);
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014058d338. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 8))(plVar1);
  return;
}

// ==== CRelationActor@adapter::vfunc_0  @14058d340  [high:rtti-vtable]  (orig: FUN_14058d340)
void FUN_14058d340(longlong param_1)

{
  FUN_14058d3d0(param_1 + -8);
  return;
}

// ==== CRelationActor@adapter::helper_14058d3d0  @14058d3d0  [medium:callgraph-r0]  (orig: FUN_14058d3d0)
undefined8 * FUN_14058d3d0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CRelationActor::vftable;
  param_1[1] = adapter::CRelationActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CRelationActor@adapter::vfunc_1  @14058d420  [high:rtti-vtable]  (orig: FUN_14058d420)
void FUN_14058d420(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
                    /* WARNING: Could not recover jumptable at 0x00014058d44e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x88))(plVar1,param_2,param_3);
  return;
}

// ==== CRelationActor@adapter::vfunc_0  @14058d460  [high:rtti-vtable]  (orig: FUN_14058d460)
undefined1 FUN_14058d460(longlong param_1,longlong param_2,undefined4 param_3)

{
  undefined1 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                           param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
    uVar1 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar1 = (**(code **)(*plVar3 + 0x88))(plVar3,puVar2,param_3);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return uVar1;
}

// ==== CRelationActor@adapter::vfunc_7  @14058d530  [high:rtti-vtable]  (orig: FUN_14058d530)
undefined8 FUN_14058d530(longlong param_1,undefined8 param_2,longlong param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar1 = 0;
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                           param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
    uVar1 = 0;
    if (puVar2 != (undefined8 *)0x0) {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x40))(plVar3,param_2,puVar2);
      (**(code **)*puVar2)(puVar2,1);
      uVar1 = 1;
    }
  }
  return uVar1;
}

// ==== CRelationActor@adapter::vfunc_6  @14058d5f0  [high:rtti-vtable]  (orig: FUN_14058d5f0)
undefined1 FUN_14058d5f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  undefined1 uVar1;
  longlong *plVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
                    /* WARNING: Could not recover jumptable at 0x00014058d65a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar1 = (**(code **)(*plVar2 + 0x40))(plVar2,param_2,param_3);
  return uVar1;
}

// ==== CRelationActor@adapter::vfunc_2  @14058d660  [high:rtti-vtable]  (orig: FUN_14058d660)
void FUN_14058d660(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar2 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                             *(undefined2 *)(param_3 + 10),param_3 + 0xc,
                             *(undefined2 *)(param_3 + 8),0);
      if (puVar2 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
        (**(code **)*puVar2)(puVar2,1);
      }
    }
  }
  return;
}

// ==== CRelationActor@adapter::vfunc_12  @14058d780  [high:rtti-vtable]  (orig: FUN_14058d780)
undefined4 FUN_14058d780(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    cVar1 = FUN_14008ab60(uVar4,0xb);
    if (cVar1 != '\0') {
      iVar2 = FUN_1401649c0(lVar3);
      if (iVar2 < 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        return 0x32;
      }
      if (6 < iVar2) {
        iVar2 = 6;
      }
      return *(undefined4 *)(&DAT_1407ab500 + (longlong)iVar2 * 4);
    }
  }
  return 0x32;
}

// ==== CRelationActor@adapter::vfunc_18  @14058d860  [high:rtti-vtable]  (orig: FUN_14058d860)
void FUN_14058d860(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_14027a130(*(longlong *)(lVar1 + 0x218),param_2,param_3,param_4);
  return;
}

// ==== CRelationActor@adapter::vfunc_20  @14058d910  [high:rtti-vtable]  (orig: FUN_14058d910)
undefined8 FUN_14058d910(longlong param_1,undefined4 param_2,undefined2 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14027a2d0(*(longlong *)(lVar1 + 0x218),param_2,param_3);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_19  @14058d9b0  [high:rtti-vtable]  (orig: FUN_14058d9b0)
undefined1 FUN_14058d9b0(longlong param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  longlong lVar1;
  undefined1 uVar2;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x218) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_14027a410(*(longlong *)(lVar1 + 0x218),param_2,param_3,param_4);
  return uVar2;
}

// ==== CRelationActor@adapter::vfunc_33  @14058da60  [high:rtti-vtable]  (orig: FUN_14058da60)
uint FUN_14058da60(longlong param_1)

{
  longlong lVar1;
  longlong *plVar2;
  uint extraout_var;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar1 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x160))(lVar1 + 0x10);
    if (lVar1 != 0) {
      plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
      plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
      (**(code **)(*plVar2 + 0x58))(plVar2);
      return extraout_var >> 3 & 1;
    }
  }
  return 1;
}

// ==== CRelationActor@adapter::vfunc_25  @14058daf0  [high:rtti-vtable]  (orig: FUN_14058daf0)
void FUN_14058daf0(longlong param_1,undefined8 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar1 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      puVar2 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(undefined2 *)(param_3 + 8),0);
      if (puVar2 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x348))
                  ((longlong *)(lVar1 + 0x10),puVar2,param_4);
        (**(code **)*puVar2)(puVar2,1);
      }
    }
  }
  return;
}

// ==== CRelationActor@adapter::vfunc_37  @14058dc20  [high:rtti-vtable]  (orig: FUN_14058dc20)
void FUN_14058dc20(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_140092b60(uVar1,param_2);
  return;
}

// ==== CRelationActor@adapter::vfunc_38  @14058dc50  [high:rtti-vtable]  (orig: FUN_14058dc50)
void FUN_14058dc50(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a9d0(uVar1,param_2,param_4,param_3);
  return;
}

// ==== CRelationActor@adapter::vfunc_39  @14058dc90  [high:rtti-vtable]  (orig: FUN_14058dc90)
void FUN_14058dc90(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x170);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140313fc0(lVar1,param_2,param_3,param_4);
  return;
}

// ==== CRelationActor@adapter::vfunc_34  @14058dd10  [high:rtti-vtable]  (orig: FUN_14058dd10)
void FUN_14058dd10(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x178);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140226d50(lVar1,param_2);
  return;
}

// ==== CRelationActor@adapter::vfunc_35  @14058dd70  [high:rtti-vtable]  (orig: FUN_14058dd70)
void FUN_14058dd70(longlong param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x178);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_1402271f0(lVar1,param_2,param_3);
  return;
}

