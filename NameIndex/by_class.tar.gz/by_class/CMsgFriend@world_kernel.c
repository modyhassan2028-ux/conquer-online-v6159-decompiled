// ==== CMsgFriend@world_kernel::vfunc_1  @1400843b0  [high:rtti-vtable]  (orig: FUN_1400843b0)
ulonglong FUN_1400843b0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3fb);
}

// ==== CMsgFriend@world_kernel::vfunc_3  @1400844b0  [high:rtti-vtable]  (orig: FUN_1400844b0)
void FUN_1400844b0(longlong param_1)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  
  uVar2 = *(undefined4 *)(param_1 + 0x41c);
  uVar3 = FUN_140054e10();
  lVar4 = FUN_14006e3a0(uVar3,uVar2);
  if ((lVar4 != 0) &&
     ((cVar1 = *(char *)(*(longlong *)(param_1 + 0x420) + 4), cVar1 == '\f' || (cVar1 == '\x10'))))
  {
    FUN_140067420(lVar4,param_1);
  }
  return;
}

// ==== CMsgFriend@world_kernel::vfunc_0  @140084510  [high:rtti-vtable]  (orig: FUN_140084510)
undefined8 * FUN_140084510(undefined8 *param_1,uint param_2)

{
  *param_1 = world_kernel::CMsgFriend::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

