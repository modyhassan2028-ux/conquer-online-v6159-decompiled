// ==== CLogReleaseTime::helper_14001afe0  @14001afe0  [medium:callgraph-r0]  (orig: FUN_14001afe0)
void FUN_14001afe0(void)

{
  return;
}

// ==== CLogReleaseTime::ctor_or_dtor  @14001aff0  [high:vtable-assign]  (orig: FUN_14001aff0)
undefined8 * FUN_14001aff0(undefined8 *param_1,undefined8 param_2,undefined4 param_3)

{
  ulong uVar1;
  
  *(undefined4 *)(param_1 + 1) = param_3;
  *param_1 = CLogReleaseTime::vftable;
  param_1[2] = param_2;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
  uVar1 = tq::TimeGet(0);
  *(ulong *)(param_1 + 3) = uVar1;
  return param_1;
}

// ==== CLogReleaseTime::ctor_or_dtor  @14001b030  [high:vtable-assign]  (orig: FUN_14001b030)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14001b030(undefined8 *param_1,undefined8 param_2)

{
  int iVar1;
  undefined8 uVar2;
  ulong uVar3;
  uint uVar4;
  undefined1 auStack_78 [32];
  undefined1 local_58 [64];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_78;
  *param_1 = CLogReleaseTime::vftable;
  uVar3 = tq::TimeGet(0);
  *(ulong *)((longlong)param_1 + 0x1c) = uVar3;
  if (10 < *(int *)(param_1 + 1)) {
    *(undefined4 *)(param_1 + 1) = 10;
  }
  uVar4 = *(uint *)(param_1 + 1);
  if (0 < (int)uVar4) {
    memset(local_58,(int)CONCAT71((int7)((ulonglong)param_2 >> 8),9),(ulonglong)uVar4);
  }
  uVar2 = param_1[2];
  if ((int)uVar4 < 0) {
    uVar4 = 0;
  }
  iVar1 = *(int *)(param_1 + 3);
  local_58[(int)uVar4] = 0;
  FUN_14001afe0(local_58,uVar2,uVar3 - iVar1);
  return;
}

// ==== CLogReleaseTime::vfunc_0  @14001b0d0  [high:rtti-vtable]  (orig: FUN_14001b0d0)
void * FUN_14001b0d0(void *param_1,uint param_2)

{
  FUN_14001b030();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

