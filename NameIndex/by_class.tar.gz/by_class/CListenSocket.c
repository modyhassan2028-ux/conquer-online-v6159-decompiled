// ==== CListenSocket::ctor_or_dtor  @1404ffd70  [high:vtable-assign]  (orig: FUN_1404ffd70)
void FUN_1404ffd70(undefined8 *param_1)

{
  *param_1 = CListenSocket::vftable;
  if (param_1[1] != 0) {
    FUN_140542870();
    param_1[1] = 0;
  }
  *param_1 = IListenSocket::vftable;
  return;
}

// ==== CListenSocket::vfunc_2  @1404ffed0  [high:rtti-vtable]  (orig: FUN_1404ffed0)
void FUN_1404ffed0(longlong param_1)

{
  if (*(longlong *)(param_1 + 8) != 0) {
    FUN_140542870();
    *(undefined8 *)(param_1 + 8) = 0;
  }
  FUN_140503a90();
  return;
}

// ==== CListenSocket::vfunc_3  @1404fff10  [high:rtti-vtable]  (orig: FUN_1404fff10)
undefined8 FUN_1404fff10(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 8) != 0) {
    uVar1 = FUN_140542a10();
    return uVar1;
  }
  return 0xffffffffffffffff;
}

// ==== CListenSocket::ctor_or_dtor  @140500c80  [high:vtable-assign]  (orig: FUN_140500c80)
undefined8 * FUN_140500c80(undefined8 *param_1)

{
  *param_1 = IListenSocket::vftable;
  *param_1 = CListenSocket::vftable;
  param_1[1] = 0;
  return param_1;
}

// ==== CListenSocket::ctor_or_dtor  @140500cc0  [high:vtable-assign]  (orig: FUN_140500cc0)
undefined8 * FUN_140500cc0(undefined8 *param_1,uint param_2)

{
  *param_1 = CListenSocket::vftable;
  if (param_1[1] != 0) {
    FUN_140542870();
    param_1[1] = 0;
  }
  *param_1 = IListenSocket::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CListenSocket::helper_140503a90  @140503a90  [medium:callgraph-r0]  (orig: FUN_140503a90)
void FUN_140503a90(void)

{
  DAT_140976588 = 0;
  return;
}

// ==== CListenSocket::helper_140542a10  @140542a10  [medium:callgraph-r0]  (orig: FUN_140542a10)
undefined8 FUN_140542a10(longlong *param_1)

{
  undefined8 uVar1;
  
  if (param_1[1] != 0) {
    FUN_14054f1e0(0);
  }
  uVar1 = (**(code **)(*param_1 + 0x20))(param_1);
  if (param_1[1] != 0) {
    FUN_14054f200(0);
  }
  return uVar1;
}

