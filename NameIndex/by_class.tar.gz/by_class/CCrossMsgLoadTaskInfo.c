// ==== CCrossMsgLoadTaskInfo::ctor_or_dtor  @1403ef4f0  [high:vtable-assign]  (orig: FUN_1403ef4f0)
undefined8 * FUN_1403ef4f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLoadTaskInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLoadTaskInfo::ctor_or_dtor  @1403ef540  [high:vtable-assign]  (orig: FUN_1403ef540)
void FUN_1403ef540(undefined8 *param_1)

{
  *param_1 = CCrossMsgLoadTaskInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLoadTaskInfo::vfunc_1  @1403ef570  [high:rtti-vtable]  (orig: FUN_1403ef570)
undefined8 FUN_1403ef570(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CCrossMsgLoadTaskInfo::ctor_or_dtor  @1403ef670  [high:vtable-assign]  (orig: FUN_1403ef670)
undefined8 * FUN_1403ef670(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLoadTaskInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLoadTaskInfo::vfunc_3  @1403ef6c0  [high:rtti-vtable]  (orig: FUN_1403ef6c0)
void FUN_1403ef6c0(longlong param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  
  if (**(short **)(param_1 + 0x428) == 0) {
    uVar4 = *(undefined4 *)(param_1 + 0x420);
    uVar1 = *(undefined4 *)(param_1 + 0x41c);
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar5 = FUN_140087650(uVar5);
    plVar6 = (longlong *)FUN_1402af110(uVar5,uVar1,uVar4);
    if (plVar6 == (longlong *)0x0) {
      log_InlineLogOSWARNING("CCrossMsgBaseUserInfo::Process not found user, idServer:%u, idOSUser")
      ;
    }
    else {
      plVar7 = (longlong *)FUN_140118220();
      lVar2 = *(longlong *)(param_1 + 0x428);
      lVar3 = *plVar7;
      uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
      (**(code **)(lVar3 + 0xd0))(plVar7,uVar4,*(undefined4 *)(lVar2 + 8),lVar2 + 0xc);
    }
  }
  else if (**(short **)(param_1 + 0x428) == 1) {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar6 = (longlong *)FUN_140087650(uVar5);
    plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,*(undefined4 *)(param_1 + 0x420));
    if (plVar6 != (longlong *)0x0) {
      plVar7 = (longlong *)FUN_140118220();
      lVar2 = *(longlong *)(param_1 + 0x428);
      lVar3 = *plVar7;
      uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
      (**(code **)(lVar3 + 0xd8))(plVar7,uVar4,*(undefined4 *)(lVar2 + 8),lVar2 + 0xc);
    }
  }
  else {
    log_InlineLogERROR("CCrossMsgLoadTaskInfo::Process wrong action %u");
  }
  return;
}

