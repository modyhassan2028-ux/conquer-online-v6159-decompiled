// ==== CFrontierFlagWarActor@adapter::helper_1400b98b0  @1400b98b0  [medium:callgraph-r0]  (orig: FUN_1400b98b0)
void FUN_1400b98b0(longlong param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong lVar6;
  
  plVar2 = *(longlong **)(param_1 + 0x438);
  plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x468);
  do {
    do {
      while( true ) {
        while( true ) {
          plVar5 = plVar3;
          plVar3 = *(longlong **)(param_1 + 0x468);
          if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x438))) {
            _invalid_parameter_noinfo();
          }
          if (plVar5 == plVar3) {
            return;
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar6 = 0;
          }
          else {
            lVar6 = *plVar2;
          }
          if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
            _invalid_parameter_noinfo();
          }
          if ((char)plVar5[6] != '\0') {
            if (plVar2 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar6 = 0;
            }
            else {
              lVar6 = *plVar2;
            }
            if (plVar5 == *(longlong **)(lVar6 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            FUN_140037fe0(param_2,plVar5 + 3);
          }
          if (plVar2 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          if (*(char *)((longlong)plVar5 + 0x49) == '\0') break;
          _invalid_parameter_noinfo();
          plVar3 = plVar5;
        }
        plVar3 = (longlong *)plVar5[2];
        if (*(char *)((longlong)plVar3 + 0x49) != '\0') break;
        cVar1 = *(char *)(*plVar3 + 0x49);
        plVar5 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x49);
          plVar3 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      plVar3 = (longlong *)plVar5[1];
    } while (*(char *)((longlong)plVar3 + 0x49) != '\0');
    do {
      plVar4 = plVar3;
      plVar3 = plVar4;
      if (plVar5 != (longlong *)plVar4[2]) break;
      plVar3 = (longlong *)plVar4[1];
      plVar5 = plVar4;
    } while (*(char *)((longlong)plVar3 + 0x49) == '\0');
  } while( true );
}

// ==== CFrontierFlagWarActor@adapter::helper_1402629e0  @1402629e0  [medium:callgraph-r1]  (orig: FUN_1402629e0)
undefined8 FUN_1402629e0(longlong param_1,uint param_2)

{
  if (((999 < param_2) &&
      ((*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x28) & 0xfffffffffffffff8U) != 0))
     && ((ulonglong)param_2 <
         (*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x28) >> 3) + 1000U)) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x30) - *(longlong *)(param_1 + 0x28) >> 3) <=
        (ulonglong)(param_2 - 1000)) {
      _invalid_parameter_noinfo();
    }
    return *(undefined8 *)(*(longlong *)(param_1 + 0x28) + (ulonglong)(param_2 - 1000) * 8);
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::helper_140263050  @140263050  [medium:callgraph-r0]  (orig: FUN_140263050)
undefined4 FUN_140263050(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402629e0();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined4 *)(lVar1 + 4);
}

// ==== CFrontierFlagWarActor@adapter::helper_140263070  @140263070  [medium:callgraph-r0]  (orig: FUN_140263070)
undefined4 FUN_140263070(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402629e0();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined4 *)(lVar1 + 8);
}

// ==== CFrontierFlagWarActor@adapter::helper_1402c4200  @1402c4200  [medium:callgraph-r0]  (orig: FUN_1402c4200)
undefined8 FUN_1402c4200(longlong *param_1,int param_2,int *param_3,int *param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  ulonglong uVar7;
  longlong *plVar8;
  uint uVar9;
  ulonglong uVar10;
  
  uVar10 = 0;
  do {
    while( true ) {
      plVar8 = (longlong *)param_1[9];
      if (plVar8 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      uVar7 = (**(code **)(*plVar8 + 0x18))();
      if (uVar7 <= uVar10) {
        return 0;
      }
      plVar8 = (longlong *)param_1[9];
      if (plVar8 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar8 = (longlong *)0x0;
      }
      plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,uVar10);
      if ((plVar8 != (longlong *)0x0) &&
         (iVar2 = (**(code **)(*plVar8 + 0x10))(plVar8,2), iVar2 == param_2)) break;
LAB_1402c43d7:
      uVar10 = uVar10 + 1;
    }
    iVar2 = (**(code **)(*plVar8 + 0x10))(plVar8,1);
    iVar3 = (**(code **)(*param_1 + 8))(param_1);
    if (iVar2 != iVar3) goto LAB_1402c43d7;
    uVar9 = 0;
    iVar2 = 0;
    do {
      uVar9 = uVar9 + 1;
      if (1000 < uVar9) {
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1402c43d7;
      }
      iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,5);
      iVar3 = tq::RandGet(iVar3 + -2);
      iVar4 = (**(code **)(*plVar8 + 0x10))(plVar8,3);
      iVar3 = iVar3 + iVar4;
      iVar4 = (**(code **)(*plVar8 + 0x10))(plVar8,6);
      iVar4 = tq::RandGet(iVar4 + -2);
      iVar5 = (**(code **)(*plVar8 + 0x10))(plVar8,4);
      iVar4 = iVar4 + iVar5;
      uVar6 = (**(code **)(*param_1 + 8))(param_1);
      cVar1 = FUN_1402c3d40(plVar8,uVar6,iVar3,iVar4);
      if ((cVar1 != '\0') && (cVar1 = FUN_1402c3cc0(param_1,iVar3,iVar4), cVar1 != '\0')) {
        *param_3 = iVar3;
        *param_4 = iVar4;
        return 1;
      }
      iVar2 = iVar2 + 1;
    } while (iVar2 < 100);
    uVar10 = uVar10 + 1;
  } while( true );
}

// ==== CFrontierFlagWarActor@adapter::helper_1403f05b0  @1403f05b0  [medium:callgraph-r0]  (orig: FUN_1403f05b0)
undefined8 FUN_1403f05b0(longlong param_1)

{
  undefined2 *puVar1;
  
  FUN_1402b5600();
  puVar1 = *(undefined2 **)(param_1 + 0x428);
  *(undefined4 *)(param_1 + 8) = 0x9c56;
  *(undefined4 *)(param_1 + 0xc) = 8;
  *puVar1 = 0;
  return CONCAT71((int7)((ulonglong)puVar1 >> 8),1);
}

// ==== CFrontierFlagWarActor@adapter::vfunc_1  @14057bae0  [high:rtti-vtable]  (orig: FUN_14057bae0)
void FUN_14057bae0(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_0  @14057bb60  [high:rtti-vtable]  (orig: FUN_14057bb60)
bool FUN_14057bb60(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_4  @14057bb80  [high:rtti-vtable]  (orig: FUN_14057bb80)
undefined8 FUN_14057bb80(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014057bba2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_5  @14057bbb0  [high:rtti-vtable]  (orig: FUN_14057bbb0)
undefined8 FUN_14057bbb0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057bc03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_6  @14057bc10  [high:rtti-vtable]  (orig: FUN_14057bc10)
undefined8 FUN_14057bc10(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140167b40(lVar1);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_7  @14057bc70  [high:rtti-vtable]  (orig: FUN_14057bc70)
undefined8 FUN_14057bc70(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057bcc3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_8  @14057bcd0  [high:rtti-vtable]  (orig: FUN_14057bcd0)
undefined8 FUN_14057bcd0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014057bcf2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_9  @14057bd00  [high:rtti-vtable]  (orig: FUN_14057bd00)
undefined8 FUN_14057bd00(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014057bd22. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
    return uVar2;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_14  @14057bd30  [high:rtti-vtable]  (orig: FUN_14057bd30)
undefined8 FUN_14057bd30(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    plVar4 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar4;
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    uVar5 = (**(code **)(lVar1 + 8))(plVar4,uVar2,0x73,0,param_3,0,0,0,0,0,0);
    return uVar5;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_15  @14057bde0  [high:rtti-vtable]  (orig: FUN_14057bde0)
undefined8 FUN_14057bde0(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  plVar3 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar3 != (longlong *)0x0) {
    plVar4 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar4;
    uVar2 = (**(code **)(*plVar3 + 8))(plVar3);
    (**(code **)(lVar1 + 0x10))(plVar4,uVar2,0x73);
    return 1;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_16  @14057be50  [high:rtti-vtable]  (orig: FUN_14057be50)
undefined8 FUN_14057be50(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2d8))((longlong *)(lVar2 + 0x10),0x73);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_17  @14057be90  [high:rtti-vtable]  (orig: FUN_14057be90)
undefined8 FUN_14057be90(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    cVar1 = (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x2d8))((longlong *)(lVar2 + 0x10),0x73);
    if (cVar1 != '\0') {
      plVar3 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x00014057bed8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar4 = (**(code **)(*plVar3 + 0xb8))(plVar3,param_2,0x73);
      return uVar4;
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_30  @14057bef0  [high:rtti-vtable]  (orig: FUN_14057bef0)
ulonglong FUN_14057bef0(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_1401c7e10(lVar1,param_3);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_46  @14057bf50  [high:rtti-vtable]  (orig: FUN_14057bf50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14057bf50(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x19c);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_45  @14057c0b0  [high:rtti-vtable]  (orig: FUN_14057c0b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14057c0b0(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x1b5);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_50  @14057c210  [high:rtti-vtable]  (orig: FUN_14057c210)
void FUN_14057c210(undefined8 param_1,undefined4 param_2)

{
  FUN_140006ad0(param_2,0);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_3  @14057c220  [high:rtti-vtable]  (orig: FUN_14057c220)
void FUN_14057c220(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057c245. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x38))(plVar1);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_22  @14057c250  [high:rtti-vtable]  (orig: FUN_14057c250)
void FUN_14057c250(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  uint in_stack_ffffffffffffffe8;
  
  plVar4 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar4 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  cVar1 = (**(code **)(plVar4[2] + 0x220))(plVar4 + 2);
  if (cVar1 == '\0') {
    plVar5 = (longlong *)FUN_1401181a0();
    cVar1 = (**(code **)(*plVar5 + 0x60))(plVar5,param_2,0x6a);
    if (cVar1 != '\0') {
      plVar5 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar5 + 0x10))(plVar5,param_2,0x6a);
    }
    FUN_1401c6d40(plVar4,0,0,0,in_stack_ffffffffffffffe8 & 0xffffff00);
  }
  uVar2 = (**(code **)(plVar4[2] + 0x80))(plVar4 + 2);
  FUN_1401a6420(plVar4,0,uVar2,1);
  uVar2 = (**(code **)(*plVar4 + 0x88))(plVar4);
  FUN_1401a6420(plVar4,2,uVar2,1);
  iVar3 = FUN_1403837b0(plVar4);
  FUN_1401a6420(plVar4,8,(longlong)iVar3,1);
  plVar4 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x00014057c37c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar4 + 0x30))(plVar4,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_1  @14057c380  [high:rtti-vtable]  (orig: FUN_14057c380)
undefined8 FUN_14057c380(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x00014057c3d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x170))(lVar1 + 0x10);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_2  @14057c3e0  [high:rtti-vtable]  (orig: FUN_14057c3e0)
undefined4 FUN_14057c3e0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0x1330);
}

// ==== CFrontierFlagWarActor@adapter::vfunc_39  @14057c440  [high:rtti-vtable]  (orig: FUN_14057c440)
undefined8 FUN_14057c440(undefined8 param_1,int param_2,int param_3,int param_4,int *param_5)

{
  int iVar1;
  int iVar2;
  ulonglong uVar3;
  longlong *plVar4;
  ulonglong uVar5;
  
  uVar5 = 0;
  while( true ) {
    plVar4 = DAT_140975bc0;
    if (DAT_140975bc0 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    uVar3 = (**(code **)(*plVar4 + 0x18))();
    if (uVar3 <= uVar5) break;
    plVar4 = DAT_140975bc0;
    if (DAT_140975bc0 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    plVar4 = (longlong *)(**(code **)(*plVar4 + 0x20))(plVar4,uVar5);
    if (((plVar4 != (longlong *)0x0) &&
        (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,1), iVar1 == param_2)) &&
       (iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,2), iVar1 == 0x19)) {
      iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,3);
      *param_5 = iVar1;
      iVar1 = (**(code **)(*plVar4 + 0x10))(plVar4,4);
      param_5[1] = iVar1;
      iVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,5);
      iVar1 = param_5[1];
      param_5[2] = iVar2 + *param_5;
      iVar2 = (**(code **)(*plVar4 + 0x10))(plVar4,6);
      iVar2 = iVar2 + iVar1;
      param_5[3] = iVar2;
      if (((*param_5 <= param_3) && (param_3 <= param_5[2])) &&
         ((iVar1 <= param_4 && (param_4 <= iVar2)))) {
        return 1;
      }
    }
    uVar5 = uVar5 + 1;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_11  @14057c5d0  [high:rtti-vtable]  (orig: FUN_14057c5d0)
undefined8 FUN_14057c5d0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140161f90(lVar1);
  return uVar2;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_12  @14057c630  [high:rtti-vtable]  (orig: FUN_14057c630)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14057c630(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  longlong lVar2;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (param_2 == 0) {
    local_498 = 0x322;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar2 == 0) {
      local_498 = 0x326;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_140161fa0(lVar2,param_3);
      FUN_140362560(local_478);
      cVar1 = FUN_140362910(local_478,0x60,param_2,(longlong)param_3);
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_478);
      }
      FUN_1403625e0(local_478);
    }
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_13  @14057c740  [high:rtti-vtable]  (orig: FUN_14057c740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14057c740(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  if (param_2 == 0) {
    local_468 = 0x335;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar2 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (plVar2 == (longlong *)0x0) {
      local_468 = 0x339;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      FUN_1403f04c0(local_448);
      cVar1 = FUN_1403f05b0(local_448);
      if (cVar1 != '\0') {
        (**(code **)(*plVar2 + 0x138))(plVar2,local_448,4);
      }
      FUN_1403f0510(local_448);
    }
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_10  @14057c830  [high:rtti-vtable]  (orig: FUN_14057c830)
void FUN_14057c830(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_0  @14057c880  [high:rtti-vtable]  (orig: FUN_14057c880)
void FUN_14057c880(longlong param_1)

{
  FUN_14057c8e0(param_1 + -8);
  return;
}

// ==== CFrontierFlagWarActor@adapter::helper_14057c8e0  @14057c8e0  [medium:callgraph-r0]  (orig: FUN_14057c8e0)
undefined8 * FUN_14057c8e0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CFrontierFlagWarActor::vftable;
  param_1[1] = adapter::CFrontierFlagWarActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_26  @14057c930  [high:rtti-vtable]  (orig: FUN_14057c930)
void FUN_14057c930(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_1400b4b50(uVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_27  @14057c950  [high:rtti-vtable]  (orig: FUN_14057c950)
void FUN_14057c950(longlong param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_1400b3310(uVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_28  @14057c970  [high:rtti-vtable]  (orig: FUN_14057c970)
void FUN_14057c970(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008b330(uVar1);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_31  @14057c990  [high:rtti-vtable]  (orig: FUN_14057c990)
uint FUN_14057c990(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    return 0;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (uint)(uVar3 >> 0x1f) & 1;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_36  @14057ca30  [high:rtti-vtable]  (orig: FUN_14057ca30)
undefined8 FUN_14057ca30(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  local_res8 = 0;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      FUN_1402bf7a0(local_res8,5000,0x50);
      return 1;
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_37  @14057caf0  [high:rtti-vtable]  (orig: FUN_14057caf0)
undefined8
FUN_14057caf0(longlong param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong local_res8;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar3 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar4 = (longlong *)
           (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))(*(longlong **)(lVar3 + 0x88),param_2)
  ;
  local_res8 = 0;
  if ((plVar4 != (longlong *)0x0) &&
     (cVar1 = (**(code **)(*plVar4 + 0x298))(plVar4,0x1040,&local_res8), cVar1 != '\0')) {
    uVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x40))(local_res8 + 0x10);
    *param_3 = uVar2;
    uVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x48))();
    *param_4 = uVar2;
    return 1;
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_44  @14057cbd0  [high:rtti-vtable]  (orig: FUN_14057cbd0)
void FUN_14057cbd0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_47  @14057cc90  [high:rtti-vtable]  (orig: FUN_14057cc90)
void FUN_14057cc90(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  uint uVar5;
  
  uVar5 = (uint)*(ushort *)(param_3 + 8);
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,uVar5,0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x98) == 0) {
      uVar5 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                       (*(longlong **)(lVar2 + 0x98),param_2,1);
    if (plVar3 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                        (*(longlong **)(param_1 + 0x10),param_4);
      (**(code **)(*plVar3 + 0x38))(plVar3,puVar1,uVar4,*plVar3,uVar5);
    }
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_48  @14057cdc0  [high:rtti-vtable]  (orig: FUN_14057cdc0)
void FUN_14057cdc0(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  puVar2 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                         param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,0xfffffffffffffffe);
  if (puVar2 != (undefined8 *)0x0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                       (*(longlong **)(lVar3 + 0x98),param_2,1);
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_4);
    if ((plVar4 == (longlong *)0x0) || (lVar3 == 0)) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      lVar1 = *plVar4;
      uVar5 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x2a0))();
      (**(code **)(lVar1 + 0x30))(plVar4,uVar5,puVar2,param_5);
    }
    (**(code **)*puVar2)(puVar2,1);
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_42  @14057cf10  [high:rtti-vtable]  (orig: FUN_14057cf10)
void FUN_14057cf10(longlong param_1,int param_2,longlong param_3)

{
  char cVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  undefined8 uVar5;
  
  if (param_2 != -1) {
    uVar5 = 0xfffffffffffffffe;
    uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    cVar1 = FUN_1400b3d90(uVar2,param_2);
    if ((cVar1 != '\0') &&
       (puVar3 = (undefined8 *)
                 FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                               param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar5),
       puVar3 != (undefined8 *)0x0)) {
      plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar4 + 0x20))(plVar4,param_2,puVar3,4);
      (**(code **)*puVar3)(puVar3,1);
    }
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_43  @14057cfc0  [high:rtti-vtable]  (orig: FUN_14057cfc0)
void FUN_14057cfc0(longlong param_1,longlong param_2)

{
  undefined8 *puVar1;
  longlong *plVar2;
  
  puVar1 = (undefined8 *)
           FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_2 + 10),
                         param_2 + 0xc,*(undefined2 *)(param_2 + 8),0,0xfffffffffffffffe);
  if (puVar1 != (undefined8 *)0x0) {
    plVar2 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    (**(code **)(*plVar2 + 0x78))(plVar2,puVar1);
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_18  @14057d040  [high:rtti-vtable]  (orig: FUN_14057d040)
ulonglong FUN_14057d040(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    uVar3 = uVar3 >> 0x1f;
    if ((uVar3 & 1) != 0) {
      uVar3 = FUN_1402c68a0(lVar1,0x18,param_3,param_4);
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_19  @14057d140  [high:rtti-vtable]  (orig: FUN_14057d140)
ulonglong FUN_14057d140(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    uVar3 = uVar3 >> 0x1f;
    if ((uVar3 & 1) != 0) {
      uVar3 = FUN_1402c68a0(lVar1,0x19,param_3,param_4);
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_20  @14057d240  [high:rtti-vtable]  (orig: FUN_14057d240)
ulonglong FUN_14057d240(longlong param_1,undefined4 param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX;
  }
  else {
    plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
    plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
    uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
    uVar3 = uVar3 >> 0x1f;
    if ((uVar3 & 1) != 0) {
      uVar3 = FUN_1402c4200(lVar1,0x18,param_3,param_4);
      return uVar3;
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_23  @14057d340  [high:rtti-vtable]  (orig: FUN_14057d340)
void FUN_14057d340(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x208);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140263030(lVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_24  @14057d3a0  [high:rtti-vtable]  (orig: FUN_14057d3a0)
void FUN_14057d3a0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x208);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140263050(lVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_25  @14057d400  [high:rtti-vtable]  (orig: FUN_14057d400)
void FUN_14057d400(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  lVar1 = *(longlong *)(lVar1 + 0x208);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar1 = 0;
  }
  FUN_140263070(lVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_34  @14057d460  [high:rtti-vtable]  (orig: FUN_14057d460)
undefined8 FUN_14057d460(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  local_res8 = 0;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      FUN_1402be990(local_res8,param_3);
      FUN_1402bda30(local_res8);
      return 1;
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_35  @14057d530  [high:rtti-vtable]  (orig: FUN_14057d530)
undefined8 FUN_14057d530(longlong param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong local_res8;
  
  local_res8 = 0;
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)
           (**(code **)(**(longlong **)(lVar5 + 0x88) + 0x20))(*(longlong **)(lVar5 + 0x88),param_2)
  ;
  if (plVar6 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_res8);
    if (cVar1 != '\0') {
      plVar6 = (longlong *)(local_res8 + 0x10);
      iVar2 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x80))(plVar6);
      iVar3 = (**(code **)(*plVar6 + 0x78))(plVar6);
      if (iVar3 != iVar2) {
        uVar4 = (**(code **)(*(longlong *)(local_res8 + 0x10) + 0x80))(local_res8 + 0x10);
        if ((*(longlong *)(local_res8 + 0x60) != 0) && (*(char *)(local_res8 + 0x68) != '\0')) {
          (**(code **)(**(longlong **)(local_res8 + 0x60) + 0x60))
                    (*(longlong **)(local_res8 + 0x60),0x18,uVar4);
          return 1;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      return 1;
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_40  @14057d670  [high:rtti-vtable]  (orig: FUN_14057d670)
void FUN_14057d670(longlong param_1,undefined8 param_2)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_1400b98b0(uVar1,param_2);
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_41  @14057d6a0  [high:rtti-vtable]  (orig: FUN_14057d6a0)
void FUN_14057d6a0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))(*(longlong **)(lVar2 + 0x88),param_2)
  ;
  local_res8 = 0;
  if (plVar3 != (longlong *)0x0) {
    cVar1 = (**(code **)(*plVar3 + 0x298))(plVar3,0x1040,&local_res8);
    if (cVar1 != '\0') {
      plVar3 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar3 + 0x18))(plVar3,param_2);
      return;
    }
  }
  log_InlineLogERROR("CFrontierFlagWarActor::DeleteTarAllStatus. Npc id invalid!(%u)");
  return;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_33  @14057d760  [high:rtti-vtable]  (orig: FUN_14057d760)
undefined8
FUN_14057d760(longlong param_1,undefined4 param_2,undefined4 param_3,ushort *param_4,ushort *param_5
             )

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  int iVar10;
  longlong lVar11;
  longlong *local_a8 [3];
  longlong *local_90;
  longlong *local_88;
  undefined8 local_80;
  longlong local_78;
  uint local_70;
  uint uStack_6c;
  longlong *local_68;
  undefined8 local_60;
  longlong *local_58;
  longlong *local_48;
  undefined8 local_38;
  
  local_38 = 0xfffffffffffffffe;
  uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  plVar8 = (longlong *)FUN_1400875f0(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,param_2);
  local_60 = 0;
  if ((plVar8 != (longlong *)0x0) &&
     (cVar3 = (**(code **)(*plVar8 + 0x298))(plVar8,0x1040,&local_60), cVar3 != '\0')) {
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    plVar8 = (longlong *)FUN_1400876b0(uVar7);
    lVar9 = (**(code **)(*plVar8 + 0x10))(plVar8,param_3,1);
    if (lVar9 == 0) {
      return 0;
    }
    iVar4 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x28))();
    iVar5 = (**(code **)(**(longlong **)(lVar9 + 0x60) + 0x20))();
    for (iVar10 = 0; plVar8 = (longlong *)0x0, iVar10 < 100; iVar10 = iVar10 + 1) {
      iVar6 = tq::RandGet(iVar4 + 1);
      *param_4 = (ushort)iVar6;
      iVar6 = tq::RandGet(iVar5 + 1);
      *param_5 = (ushort)iVar6;
      cVar3 = FUN_1402c3cc0(lVar9,*param_4,(ushort)iVar6);
      if (((cVar3 != '\0') && (cVar3 = FUN_1402c68a0(lVar9,0x18,*param_4,*param_5), cVar3 == '\0'))
         && (cVar3 = FUN_1402c68a0(lVar9,0x19,*param_4,*param_5), cVar3 == '\0')) {
        local_58 = operator_new(8);
        if (local_58 != (longlong *)0x0) {
          *local_58 = (longlong)local_a8;
          plVar8 = local_58;
        }
        local_90 = (longlong *)0x0;
        local_88 = (longlong *)0x0;
        local_80 = 0;
        local_70 = (uint)*param_4;
        uStack_6c = (uint)*param_5;
        local_a8[0] = plVar8;
        local_48 = local_58;
        FUN_1402d2470(lVar9,local_a8,(ulonglong)CONCAT24(*param_5,local_70),0x19,0x1040);
        plVar8 = local_90;
        local_48 = (longlong *)0x0;
        if (local_88 < local_90) {
          _invalid_parameter_noinfo();
        }
        plVar1 = local_a8[0];
        local_48 = local_a8[0];
        while( true ) {
          plVar2 = local_88;
          local_58 = (longlong *)0x0;
          if (local_88 < local_90) {
            _invalid_parameter_noinfo();
          }
          local_58 = local_a8[0];
          if ((plVar1 == (longlong *)0x0) || (plVar1 != local_a8[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar8 == plVar2) break;
          local_68 = (longlong *)0x0;
          local_78 = 0;
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = 0;
          }
          else {
            lVar11 = *plVar1;
          }
          if (*(longlong **)(lVar11 + 0x20) <= plVar8) {
            _invalid_parameter_noinfo();
          }
          if (*plVar8 != 0) {
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar11 = 0;
            }
            else {
              lVar11 = *plVar1;
            }
            if (*(longlong **)(lVar11 + 0x20) <= plVar8) {
              _invalid_parameter_noinfo();
            }
            cVar3 = (**(code **)(*(longlong *)*plVar8 + 0x40))((longlong *)*plVar8,&local_68);
            if (((cVar3 != '\0') &&
                (cVar3 = (**(code **)(*local_68 + 0x298))(local_68,0x1040,&local_78),
                lVar11 = local_78, cVar3 != '\0')) &&
               ((iVar6 = (**(code **)(**(longlong **)(local_78 + 0x60) + 0x10))
                                   (*(longlong **)(local_78 + 0x60),4), iVar6 == 0x2e ||
                (iVar6 = (**(code **)(**(longlong **)(lVar11 + 0x60) + 0x10))
                                   (*(longlong **)(lVar11 + 0x60),4), iVar6 == 0x2f))))
            goto LAB_14057dae3;
          }
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar11 = 0;
          }
          else {
            lVar11 = *plVar1;
          }
          if (*(longlong **)(lVar11 + 0x20) <= plVar8) {
            _invalid_parameter_noinfo();
          }
          plVar8 = plVar8 + 1;
        }
        cVar3 = FUN_1402bf7a0(local_60,param_3,*param_4,*param_5);
        if (cVar3 != '\0') {
          if (local_90 != (longlong *)0x0) {
            operator_delete(local_90);
          }
          local_90 = (longlong *)0x0;
          local_88 = (longlong *)0x0;
          local_80 = 0;
          operator_delete(local_a8[0]);
          return 1;
        }
LAB_14057dae3:
        if (local_90 != (longlong *)0x0) {
          operator_delete(local_90);
        }
        local_90 = (longlong *)0x0;
        local_88 = (longlong *)0x0;
        local_80 = 0;
        operator_delete(local_a8[0]);
      }
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_38  @14057db50  [high:rtti-vtable]  (orig: FUN_14057db50)
undefined8
FUN_14057db50(longlong param_1,int param_2,int param_3,undefined4 *param_4,undefined4 *param_5,
             undefined4 *param_6)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong *local_res8;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar6 = (longlong *)(**(code **)(**(longlong **)(lVar5 + 0x88) + 0x30))();
  if (plVar6 != (longlong *)0x0) {
    local_res8 = (longlong *)0x0;
    (**(code **)(*plVar6 + 0x10))(plVar6,&local_48);
    while( true ) {
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x18))(plVar6,local_28);
      if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar7)) {
        _invalid_parameter_noinfo();
      }
      if (uStack_40 == (longlong *)plVar7[1]) break;
      local_38 = local_48;
      uStack_34 = uStack_44;
      uStack_30 = (undefined4)uStack_40;
      uStack_2c = uStack_40._4_4_;
      plVar7 = (longlong *)(**(code **)(*plVar6 + 0x20))(plVar6,&local_38);
      if (((plVar7 != (longlong *)0x0) &&
          (cVar2 = (**(code **)(*plVar7 + 0x298))(plVar7,0x1040,&local_res8), cVar2 != '\0')) &&
         ((char)local_res8[0xd] != '\0')) {
        if (local_res8[0xc] == 0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          iVar3 = 0;
        }
        else {
          iVar3 = (**(code **)(*(longlong *)local_res8[0xc] + 8))();
        }
        if ((iVar3 == param_2) &&
           (iVar3 = (**(code **)(*(longlong *)local_res8[0xc] + 0x10))
                              ((longlong *)local_res8[0xc],4), iVar3 == param_3)) {
          uVar4 = (**(code **)(local_res8[2] + 0x40))(local_res8 + 2);
          *param_5 = uVar4;
          uVar4 = (**(code **)(local_res8[2] + 0x48))(local_res8 + 2);
          *param_6 = uVar4;
          uVar4 = (**(code **)(*local_res8 + 8))();
          *param_4 = uVar4;
          return 1;
        }
      }
      if (CONCAT44(uStack_44,local_48) == 0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
        plVar7 = (longlong *)uStack_40[2];
        if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
          cVar2 = *(char *)(*plVar7 + 0x29);
          uStack_40 = plVar7;
          plVar7 = (longlong *)*plVar7;
          while (cVar2 == '\0') {
            cVar2 = *(char *)(*plVar7 + 0x29);
            uStack_40 = plVar7;
            plVar7 = (longlong *)*plVar7;
          }
        }
        else {
          cVar2 = *(char *)(uStack_40[1] + 0x29);
          plVar1 = (longlong *)uStack_40[1];
          plVar7 = uStack_40;
          while ((uStack_40 = plVar1, cVar2 == '\0' && (plVar7 == (longlong *)uStack_40[2]))) {
            cVar2 = *(char *)(uStack_40[1] + 0x29);
            plVar1 = (longlong *)uStack_40[1];
            plVar7 = uStack_40;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
  }
  return 0;
}

// ==== CFrontierFlagWarActor@adapter::vfunc_29  @14057ddb0  [high:rtti-vtable]  (orig: FUN_14057ddb0)
void FUN_14057ddb0(longlong param_1,int param_2,undefined8 *param_3)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  ulonglong uVar6;
  undefined4 local_res8 [2];
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined1 local_48 [16];
  undefined1 local_38 [8];
  undefined1 local_30 [24];
  longlong *local_18;
  longlong *local_10;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar5 + 0x90),local_38);
  do {
    cVar3 = FUN_1400ce310(local_30);
    while( true ) {
      if (cVar3 == '\0') {
        return;
      }
      cVar3 = (**(code **)(*local_18 + 0x298))(local_18,0x1001,&local_10);
      if (cVar3 != '\0') break;
      cVar3 = FUN_1400ce310(local_30);
    }
    if ((local_10 != (longlong *)0x0) &&
       (iVar4 = (**(code **)(local_10[2] + 0x168))(local_10 + 2), iVar4 == param_2)) {
      if (local_10 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      iVar4 = (**(code **)(local_10[2] + 0x168))(local_10 + 2);
      if (iVar4 == param_2) {
        if (local_10 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        local_res8[0] = (**(code **)(*local_10 + 8))();
        puVar1 = (undefined4 *)param_3[3];
        if (puVar1 == (undefined4 *)0x0) {
          uVar6 = 0;
        }
        else {
          uVar6 = param_3[5] - (longlong)puVar1 >> 2;
        }
        puVar2 = (undefined4 *)param_3[4];
        if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2) < uVar6) {
          *puVar2 = local_res8[0];
          param_3[4] = puVar2 + 1;
        }
        else {
          if (puVar2 < puVar1) {
            _invalid_parameter_noinfo();
          }
          local_68 = (undefined4)*param_3;
          uStack_64 = (undefined4)((ulonglong)*param_3 >> 0x20);
          uStack_60 = SUB84(puVar2,0);
          uStack_5c = (undefined4)((ulonglong)puVar2 >> 0x20);
          local_58 = local_68;
          uStack_54 = uStack_64;
          uStack_50 = uStack_60;
          uStack_4c = uStack_5c;
          FUN_1400375c0(param_3,local_48,&local_58,local_res8);
        }
      }
    }
  } while( true );
}

// ==== CFrontierFlagWarActor@adapter::vfunc_32  @14057dfc0  [high:rtti-vtable]  (orig: FUN_14057dfc0)
undefined8 FUN_14057dfc0(longlong param_1,int param_2,undefined8 param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined4 local_res8 [2];
  longlong *local_res20;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined8 uStack_40;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined1 local_28 [16];
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar4 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)(**(code **)(**(longlong **)(lVar4 + 0x88) + 0x30))();
  if (plVar5 == (longlong *)0x0) {
    return 0;
  }
  local_res20 = (longlong *)0x0;
  (**(code **)(*plVar5 + 0x10))(plVar5,&local_48);
  while( true ) {
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x18))(plVar5,local_28);
    if ((CONCAT44(uStack_44,local_48) == 0) || (CONCAT44(uStack_44,local_48) != *plVar6)) {
      _invalid_parameter_noinfo();
    }
    if (uStack_40 == (longlong *)plVar6[1]) break;
    local_38 = local_48;
    uStack_34 = uStack_44;
    uStack_30 = (undefined4)uStack_40;
    uStack_2c = uStack_40._4_4_;
    plVar6 = (longlong *)(**(code **)(*plVar5 + 0x20))(plVar5,&local_38);
    if ((((plVar6 != (longlong *)0x0) &&
         (cVar2 = (**(code **)(*plVar6 + 0x298))(plVar6,0x1040,&local_res20), cVar2 != '\0')) &&
        ((char)local_res20[0xd] != '\0')) &&
       (iVar3 = (**(code **)(*(longlong *)local_res20[0xc] + 0x10))((longlong *)local_res20[0xc],4),
       iVar3 == param_2)) {
      local_res8[0] = (**(code **)(*local_res20 + 8))();
      FUN_140037fe0(param_3,local_res8);
    }
    if (CONCAT44(uStack_44,local_48) == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)uStack_40 + 0x29) == '\0') {
      plVar6 = (longlong *)uStack_40[2];
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar2 = *(char *)(*plVar6 + 0x29);
        uStack_40 = plVar6;
        plVar6 = (longlong *)*plVar6;
        while (cVar2 == '\0') {
          cVar2 = *(char *)(*plVar6 + 0x29);
          uStack_40 = plVar6;
          plVar6 = (longlong *)*plVar6;
        }
      }
      else {
        cVar2 = *(char *)(uStack_40[1] + 0x29);
        plVar1 = (longlong *)uStack_40[1];
        plVar6 = uStack_40;
        while ((uStack_40 = plVar1, cVar2 == '\0' && (plVar6 == (longlong *)uStack_40[2]))) {
          cVar2 = *(char *)(uStack_40[1] + 0x29);
          plVar1 = (longlong *)uStack_40[1];
          plVar6 = uStack_40;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return CONCAT71((int7)((ulonglong)plVar6[1] >> 8),1);
}

// ==== CFrontierFlagWarActor@adapter::vfunc_49  @14057e1a0  [high:rtti-vtable]  (orig: FUN_14057e1a0)
void FUN_14057e1a0(longlong param_1,undefined8 *param_2,longlong param_3)

{
  ulonglong uVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  ulonglong uVar11;
  longlong *local_res20;
  longlong *local_e8 [3];
  undefined4 *local_d0;
  undefined4 *local_c8;
  longlong local_c0;
  longlong *local_b8 [3];
  undefined4 *local_a0;
  undefined4 *local_98;
  longlong local_90;
  undefined8 local_88;
  undefined8 uStack_80;
  undefined8 local_78;
  undefined8 uStack_70;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  undefined4 local_48;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  
  local_58 = 0xfffffffffffffffe;
  local_res20 = operator_new(8);
  if (local_res20 == (longlong *)0x0) {
    local_b8[0] = (longlong *)0x0;
  }
  else {
    *local_res20 = (longlong)local_b8;
    local_b8[0] = local_res20;
  }
  plVar8 = (longlong *)0x0;
  local_a0 = (undefined4 *)0x0;
  local_98 = (undefined4 *)0x0;
  local_90 = 0;
  local_88 = local_res20;
  local_res20 = operator_new(8);
  local_e8[0] = plVar8;
  if (local_res20 != (longlong *)0x0) {
    *local_res20 = (longlong)local_e8;
    local_e8[0] = local_res20;
  }
  local_d0 = (undefined4 *)0x0;
  local_c8 = (undefined4 *)0x0;
  local_c0 = 0;
  uVar11 = param_2[3];
  local_88 = local_res20;
  if ((ulonglong)param_2[4] < uVar11) {
    _invalid_parameter_noinfo();
  }
  puVar7 = (undefined8 *)*param_2;
  do {
    uVar1 = param_2[4];
    if (uVar1 < (ulonglong)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar7 == (undefined8 *)0x0) || (puVar7 != (undefined8 *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (uVar11 == uVar1) {
      if (((longlong)local_c8 - (longlong)local_d0 >> 2 != 0) &&
         (puVar7 = (undefined8 *)
                   FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                                 param_3 + 0xc,*(undefined2 *)(param_3 + 8),0),
         puVar7 != (undefined8 *)0x0)) {
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        (**(code **)(*plVar8 + 0x48))(plVar8,local_e8,puVar7);
        (**(code **)*puVar7)(puVar7,1);
      }
      if ((longlong)local_98 - (longlong)local_a0 >> 2 != 0) {
        plVar8 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
        (**(code **)(*plVar8 + 0x38))(plVar8,local_e8,param_3);
      }
      if (local_d0 != (undefined4 *)0x0) {
        operator_delete(local_d0);
      }
      local_d0 = (undefined4 *)0x0;
      local_c8 = (undefined4 *)0x0;
      local_c0 = 0;
      operator_delete(local_e8[0]);
      if (local_a0 != (undefined4 *)0x0) {
        operator_delete(local_a0);
      }
      local_a0 = (undefined4 *)0x0;
      local_98 = (undefined4 *)0x0;
      local_90 = 0;
      operator_delete(local_b8[0]);
      return;
    }
    if (puVar7 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar10 = plVar8;
    }
    else {
      plVar10 = (longlong *)*puVar7;
    }
    if ((ulonglong)plVar10[4] <= uVar11) {
      _invalid_parameter_noinfo();
    }
    lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar5 != 0) {
      cVar4 = FUN_140167b70(lVar5);
      puVar2 = local_98;
      puVar3 = local_c8;
      if (cVar4 == '\0') {
        local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar5 + 0x122c));
        if ((local_a0 == (undefined4 *)0x0) ||
           ((ulonglong)(local_90 - (longlong)local_a0 >> 2) <=
            (ulonglong)((longlong)local_98 - (longlong)local_a0 >> 2))) {
          if (local_98 < local_a0) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_a0;
          plVar10 = local_b8[0];
          local_78 = local_b8[0];
          uStack_70 = puVar2;
          plVar9 = plVar8;
          if (((longlong)local_98 - (longlong)local_a0 & 0xfffffffffffffffcU) != 0) {
            if (local_98 < local_a0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar10 == (longlong *)0x0) || (plVar10 != local_b8[0])) {
              _invalid_parameter_noinfo();
            }
            plVar9 = (longlong *)((longlong)puVar2 - (longlong)puVar3 >> 2);
          }
          local_48 = (undefined4)local_78;
          uStack_44 = local_78._4_4_;
          uStack_40 = (undefined4)uStack_70;
          uStack_3c = uStack_70._4_4_;
          FUN_140036c20(local_b8,&local_48,1,&local_res20);
          puVar3 = local_a0;
          if (local_98 < local_a0) {
            _invalid_parameter_noinfo();
          }
          plVar10 = local_b8[0];
          if (local_b8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar6 = plVar8;
          }
          else {
            plVar6 = (longlong *)*local_b8[0];
          }
          if (puVar3 + (longlong)plVar9 <= (undefined4 *)plVar6[4]) {
            plVar6 = plVar8;
            if (plVar10 != (longlong *)0x0) {
              plVar6 = (longlong *)*plVar10;
            }
            if ((undefined4 *)plVar6[3] <= puVar3 + (longlong)plVar9) goto LAB_14057e57b;
          }
          _invalid_parameter_noinfo();
        }
        else {
          *local_98 = *(undefined4 *)(lVar5 + 0x122c);
          local_98 = local_98 + 1;
        }
      }
      else {
        local_res20 = (longlong *)CONCAT44(local_res20._4_4_,*(undefined4 *)(lVar5 + 0x122c));
        if ((local_d0 == (undefined4 *)0x0) ||
           ((ulonglong)(local_c0 - (longlong)local_d0 >> 2) <=
            (ulonglong)((longlong)local_c8 - (longlong)local_d0 >> 2))) {
          if (local_c8 < local_d0) {
            _invalid_parameter_noinfo();
          }
          puVar2 = local_d0;
          plVar10 = local_e8[0];
          local_88 = local_e8[0];
          uStack_80 = puVar3;
          plVar9 = plVar8;
          if (((longlong)local_c8 - (longlong)local_d0 & 0xfffffffffffffffcU) != 0) {
            if (local_c8 < local_d0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar10 == (longlong *)0x0) || (plVar10 != local_e8[0])) {
              _invalid_parameter_noinfo();
            }
            plVar9 = (longlong *)((longlong)puVar3 - (longlong)puVar2 >> 2);
          }
          local_68 = (undefined4)local_88;
          uStack_64 = local_88._4_4_;
          uStack_60 = (undefined4)uStack_80;
          uStack_5c = uStack_80._4_4_;
          FUN_140036c20(local_e8,&local_68,1,&local_res20);
          puVar3 = local_d0;
          if (local_c8 < local_d0) {
            _invalid_parameter_noinfo();
          }
          plVar10 = local_e8[0];
          if (local_e8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar6 = plVar8;
          }
          else {
            plVar6 = (longlong *)*local_e8[0];
          }
          if (puVar3 + (longlong)plVar9 <= (undefined4 *)plVar6[4]) {
            plVar6 = plVar8;
            if (plVar10 != (longlong *)0x0) {
              plVar6 = (longlong *)*plVar10;
            }
            if ((undefined4 *)plVar6[3] <= puVar3 + (longlong)plVar9) goto LAB_14057e57b;
          }
          _invalid_parameter_noinfo();
        }
        else {
          *local_c8 = *(undefined4 *)(lVar5 + 0x122c);
          local_c8 = local_c8 + 1;
        }
      }
    }
LAB_14057e57b:
    if (puVar7 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar10 = plVar8;
    }
    else {
      plVar10 = (longlong *)*puVar7;
    }
    if ((ulonglong)plVar10[4] <= uVar11) {
      _invalid_parameter_noinfo();
    }
    uVar11 = uVar11 + 4;
  } while( true );
}

// ==== CFrontierFlagWarActor@adapter::vfunc_21  @14057e6d0  [high:rtti-vtable]  (orig: FUN_14057e6d0)
void FUN_14057e6d0(longlong param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  char cVar4;
  undefined4 uVar5;
  longlong *plVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong *plVar10;
  undefined4 *puVar11;
  longlong *plVar12;
  longlong *local_res18;
  longlong *local_res20;
  uint in_stack_ffffffffffffff28;
  longlong *local_c8 [3];
  undefined4 *local_b0;
  undefined4 *local_a8;
  longlong local_a0;
  undefined8 local_98;
  undefined8 uStack_90;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined8 local_78;
  longlong local_70 [7];
  
  local_78 = 0xfffffffffffffffe;
  local_res18 = operator_new(8);
  plVar12 = (longlong *)0x0;
  local_c8[0] = plVar12;
  if (local_res18 != (longlong *)0x0) {
    *local_res18 = (longlong)local_c8;
    local_c8[0] = local_res18;
  }
  local_b0 = (undefined4 *)0x0;
  local_a8 = (undefined4 *)0x0;
  local_a0 = 0;
  puVar11 = (undefined4 *)param_2[3];
  local_res20 = local_res18;
  if ((undefined4 *)param_2[4] < puVar11) {
    _invalid_parameter_noinfo();
  }
  puVar1 = (undefined8 *)*param_2;
  do {
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((puVar1 == (undefined8 *)0x0) || (puVar1 != (undefined8 *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar11 == puVar2) {
      local_res18 = local_70;
      uVar8 = FUN_140043260(local_70,local_c8);
      lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      if (*(longlong *)(lVar9 + 0x90) == 0) {
        in_stack_ffffffffffffff28 = 0x130;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      FUN_1402b3560(*(undefined8 *)(lVar9 + 0x90),uVar8,4,1,in_stack_ffffffffffffff28 & 0xffffff00,1
                   );
      if (local_b0 != (undefined4 *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (undefined4 *)0x0;
      local_a8 = (undefined4 *)0x0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      return;
    }
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar6 = plVar12;
    }
    else {
      plVar6 = (longlong *)*puVar1;
    }
    if ((undefined4 *)plVar6[4] <= puVar11) {
      _invalid_parameter_noinfo();
    }
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                       (*(longlong **)(param_1 + 0x10),*puVar11);
    if (plVar6 != (longlong *)0x0) {
      cVar4 = FUN_140167b70(plVar6);
      if (cVar4 == '\0') {
        (**(code **)(*plVar6 + 8))(plVar6);
        log_InlineLogERROR("CFrontierFlagWarActor::SendUserBack. User[%u] is not OS User");
      }
      else {
        uVar5 = (**(code **)(*plVar6 + 8))(plVar6);
        puVar2 = local_a8;
        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar5);
        plVar6 = plVar12;
        if (local_b0 != (undefined4 *)0x0) {
          plVar6 = (longlong *)(local_a0 - (longlong)local_b0 >> 2);
        }
        if ((longlong *)((longlong)local_a8 - (longlong)local_b0 >> 2) < plVar6) {
          *local_a8 = uVar5;
          local_a8 = local_a8 + 1;
        }
        else {
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_b0;
          plVar6 = local_c8[0];
          local_98 = local_c8[0];
          uStack_90 = puVar2;
          plVar10 = plVar12;
          if (((longlong)local_a8 - (longlong)local_b0 & 0xfffffffffffffffcU) != 0) {
            if (local_a8 < local_b0) {
              _invalid_parameter_noinfo();
            }
            if ((plVar6 == (longlong *)0x0) || (plVar6 != local_c8[0])) {
              _invalid_parameter_noinfo();
            }
            plVar10 = (longlong *)((longlong)puVar2 - (longlong)puVar3 >> 2);
          }
          local_88 = (undefined4)local_98;
          uStack_84 = local_98._4_4_;
          uStack_80 = (undefined4)uStack_90;
          uStack_7c = uStack_90._4_4_;
          FUN_140036c20(local_c8,&local_88,1,&local_res18);
          puVar2 = local_b0;
          if (local_a8 < local_b0) {
            _invalid_parameter_noinfo();
          }
          plVar6 = local_c8[0];
          if (local_c8[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar7 = plVar12;
          }
          else {
            plVar7 = (longlong *)*local_c8[0];
          }
          if (puVar2 + (longlong)plVar10 <= (undefined4 *)plVar7[4]) {
            plVar7 = plVar12;
            if (plVar6 != (longlong *)0x0) {
              plVar7 = (longlong *)*plVar6;
            }
            if ((undefined4 *)plVar7[3] <= puVar2 + (longlong)plVar10) goto LAB_14057e910;
          }
          _invalid_parameter_noinfo();
        }
      }
    }
LAB_14057e910:
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      plVar6 = plVar12;
    }
    else {
      plVar6 = (longlong *)*puVar1;
    }
    if ((undefined4 *)plVar6[4] <= puVar11) {
      _invalid_parameter_noinfo();
    }
    puVar11 = puVar11 + 1;
  } while( true );
}

