// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140162130  @140162130  [medium:callgraph-r0]  (orig: FUN_140162130)
void FUN_140162130(longlong param_1)

{
  FUN_140373f50(param_1 + 0xe78);
  return;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140210f90  @140210f90  [medium:callgraph-r3]  (orig: FUN_140210f90)
void FUN_140210f90(longlong *param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)param_1[1];
  if (*(char *)((longlong)plVar2 + 0x161) == '\0') {
    lVar3 = *plVar2;
    if (*(char *)(lVar3 + 0x161) == '\0') {
      cVar1 = *(char *)(*(longlong *)(lVar3 + 0x10) + 0x161);
      lVar4 = *(longlong *)(lVar3 + 0x10);
      while (cVar1 == '\0') {
        cVar1 = *(char *)(*(longlong *)(lVar4 + 0x10) + 0x161);
        lVar3 = lVar4;
        lVar4 = *(longlong *)(lVar4 + 0x10);
      }
      param_1[1] = lVar3;
      return;
    }
    plVar2 = (longlong *)plVar2[1];
    cVar1 = *(char *)((longlong)plVar2 + 0x161);
    while ((cVar1 == '\0' && (param_1[1] == *plVar2))) {
      param_1[1] = (longlong)plVar2;
      plVar2 = (longlong *)plVar2[1];
      cVar1 = *(char *)((longlong)plVar2 + 0x161);
    }
    if (*(char *)(param_1[1] + 0x161) == '\0') {
      param_1[1] = (longlong)plVar2;
      return;
    }
  }
  else {
    lVar3 = plVar2[2];
    param_1[1] = lVar3;
    if (*(char *)(lVar3 + 0x161) == '\0') {
      return;
    }
  }
                    /* WARNING: Could not recover jumptable at 0x000140210fc8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140214410  @140214410  [medium:callgraph-r1]  (orig: FUN_140214410)
longlong * FUN_140214410(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x2d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x2d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140215510  @140215510  [medium:callgraph-r2]  (orig: FUN_140215510)
void FUN_140215510(undefined8 *param_1)

{
  FUN_14000c310(param_1 + 0x20);
  operator_delete((void *)param_1[0x20]);
  FUN_14000c310(param_1 + 0x18);
  operator_delete((void *)param_1[0x18]);
  FUN_14000c310(param_1 + 0x10);
  operator_delete((void *)param_1[0x10]);
  FUN_14000c310(param_1 + 8);
  operator_delete((void *)param_1[8]);
  FUN_14000c310(param_1);
  operator_delete((void *)*param_1);
  return;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140215730  @140215730  [medium:callgraph-r2]  (orig: FUN_140215730)
longlong FUN_140215730(longlong param_1)

{
  FUN_14000ef40();
  FUN_14000ef40(param_1 + 0x40);
  FUN_14000ef40(param_1 + 0x80);
  FUN_14000ef40(param_1 + 0xc0);
  FUN_14000ef40(param_1 + 0x100);
  FUN_14000a7b0(param_1);
  FUN_14000a7b0(param_1 + 0x40);
  FUN_14000a7b0(param_1 + 0x80);
  FUN_14000a7b0(param_1 + 0xc0);
  FUN_14000a7b0(param_1 + 0x100);
  return param_1;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140215920  @140215920  [medium:callgraph-r2]  (orig: FUN_140215920)
longlong FUN_140215920(longlong param_1,longlong param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 uVar1;
  
  uVar1 = 0xfffffffffffffffe;
  FUN_14000e970();
  FUN_14000e970(param_1 + 0x40,param_2 + 0x40,param_3,param_4,uVar1);
  FUN_14000e970(param_1 + 0x80,param_2 + 0x80);
  FUN_14000e970(param_1 + 0xc0,param_2 + 0xc0);
  FUN_14000e970(param_1 + 0x100,param_2 + 0x100);
  return param_1;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140216a40  @140216a40  [medium:callgraph-r3]  (orig: FUN_140216a40)
undefined8 *
FUN_140216a40(undefined8 *param_1,undefined8 *param_2,char param_3,undefined8 *param_4,
             undefined8 param_5)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [40];
  
  if (0xc7ce0c7ce0c7cc < (ulonglong)param_1[7]) {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"map/set<T> too long");
    std::exception::exception((exception *)local_48);
    local_48[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_70);
    local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
  }
  plVar5 = (longlong *)
           FUN_1402161a0(param_1,param_1[6],param_4,param_1[6],param_5,0,0xfffffffffffffffe);
  param_1[7] = param_1[7] + 1;
  if (param_4 == (undefined8 *)param_1[6]) {
    ((undefined8 *)param_1[6])[1] = plVar5;
    *(longlong **)param_1[6] = plVar5;
    *(longlong **)(param_1[6] + 0x10) = plVar5;
  }
  else if (param_3 == '\0') {
    param_4[2] = plVar5;
    if (param_4 == *(undefined8 **)(param_1[6] + 0x10)) {
      *(longlong **)(param_1[6] + 0x10) = plVar5;
    }
  }
  else {
    *param_4 = plVar5;
    if (param_4 == *(undefined8 **)param_1[6]) {
      *(longlong **)param_1[6] = plVar5;
    }
  }
  plVar7 = plVar5 + 1;
  cVar1 = *(char *)(*plVar7 + 0x160);
  plVar6 = plVar5;
  while (cVar1 == '\0') {
    plVar2 = (longlong *)*plVar7;
    plVar3 = (longlong *)plVar2[1];
    if (plVar2 == (longlong *)*plVar3) {
      lVar4 = plVar3[2];
      if (*(char *)(lVar4 + 0x160) == '\0') {
        *(undefined1 *)(plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x160) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x160) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)plVar2[2]) {
          plVar6 = (longlong *)plVar2[2];
          plVar2[2] = *plVar6;
          if (*(char *)(*plVar6 + 0x161) == '\0') {
            *(longlong **)(*plVar6 + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          plVar6[1] = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong **)(param_1[6] + 8) = plVar6;
          }
          else {
            plVar3 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)*plVar3) {
              *plVar3 = (longlong)plVar6;
            }
            else {
              plVar3[2] = (longlong)plVar6;
            }
          }
          *plVar6 = (longlong)plVar2;
          *plVar7 = (longlong)plVar6;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x160) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x160) = 0;
        plVar7 = *(longlong **)(*plVar7 + 8);
        lVar4 = *plVar7;
        *plVar7 = *(longlong *)(lVar4 + 0x10);
        if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x161) == '\0') {
          *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar7;
        }
        *(longlong *)(lVar4 + 8) = plVar7[1];
        if (plVar7 == *(longlong **)(param_1[6] + 8)) {
          *(longlong *)(param_1[6] + 8) = lVar4;
        }
        else {
          plVar2 = (longlong *)plVar7[1];
          if (plVar7 == (longlong *)plVar2[2]) {
            plVar2[2] = lVar4;
          }
          else {
            *plVar2 = lVar4;
          }
        }
        *(longlong **)(lVar4 + 0x10) = plVar7;
        plVar7[1] = lVar4;
      }
    }
    else {
      lVar4 = *plVar3;
      if (*(char *)(lVar4 + 0x160) == '\0') {
        *(undefined1 *)(plVar2 + 0x2c) = 1;
        *(undefined1 *)(lVar4 + 0x160) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x160) = 0;
        plVar6 = *(longlong **)(*plVar7 + 8);
      }
      else {
        if (plVar6 == (longlong *)*plVar2) {
          lVar4 = *plVar2;
          *plVar2 = *(longlong *)(lVar4 + 0x10);
          if (*(char *)(*(longlong *)(lVar4 + 0x10) + 0x161) == '\0') {
            *(longlong **)(*(longlong *)(lVar4 + 0x10) + 8) = plVar2;
          }
          plVar7 = plVar2 + 1;
          *(longlong *)(lVar4 + 8) = *plVar7;
          if (plVar2 == *(longlong **)(param_1[6] + 8)) {
            *(longlong *)(param_1[6] + 8) = lVar4;
          }
          else {
            plVar6 = (longlong *)*plVar7;
            if (plVar2 == (longlong *)plVar6[2]) {
              plVar6[2] = lVar4;
            }
            else {
              *plVar6 = lVar4;
            }
          }
          *(longlong **)(lVar4 + 0x10) = plVar2;
          *plVar7 = lVar4;
          plVar6 = plVar2;
        }
        *(undefined1 *)(*plVar7 + 0x160) = 1;
        *(undefined1 *)(*(longlong *)(*plVar7 + 8) + 0x160) = 0;
        lVar4 = *(longlong *)(*plVar7 + 8);
        plVar7 = *(longlong **)(lVar4 + 0x10);
        *(longlong *)(lVar4 + 0x10) = *plVar7;
        if (*(char *)(*plVar7 + 0x161) == '\0') {
          *(longlong *)(*plVar7 + 8) = lVar4;
        }
        plVar7[1] = *(longlong *)(lVar4 + 8);
        if (lVar4 == *(longlong *)(param_1[6] + 8)) {
          *(longlong **)(param_1[6] + 8) = plVar7;
        }
        else {
          plVar2 = *(longlong **)(lVar4 + 8);
          if (lVar4 == *plVar2) {
            *plVar2 = (longlong)plVar7;
          }
          else {
            plVar2[2] = (longlong)plVar7;
          }
        }
        *plVar7 = lVar4;
        *(longlong **)(lVar4 + 8) = plVar7;
      }
    }
    plVar7 = plVar6 + 1;
    cVar1 = *(char *)(*plVar7 + 0x160);
  }
  *(undefined1 *)(*(longlong *)(param_1[6] + 8) + 0x160) = 1;
  param_2[1] = plVar5;
  *param_2 = *param_1;
  return param_2;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_1402171c0  @1402171c0  [medium:callgraph-r3]  (orig: FUN_1402171c0)
longlong * FUN_1402171c0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  bool bVar4;
  longlong local_28;
  undefined8 *local_20;
  
  puVar3 = (undefined8 *)param_1[6];
  bVar4 = true;
  if (*(char *)((longlong)puVar3[1] + 0x161) == '\0') {
    puVar1 = (undefined8 *)puVar3[1];
    do {
      puVar3 = puVar1;
      bVar4 = *param_3 < *(uint *)(puVar3 + 3);
      if (bVar4) {
        puVar1 = (undefined8 *)*puVar3;
      }
      else {
        puVar1 = (undefined8 *)puVar3[2];
      }
    } while (*(char *)((longlong)puVar1 + 0x161) == '\0');
  }
  local_28 = *param_1;
  local_20 = puVar3;
  if (bVar4 == false) {
LAB_140217282:
    if (*param_3 <= *(uint *)(local_20 + 3)) {
      *(undefined1 *)(param_2 + 2) = 0;
      *param_2 = local_28;
      goto LAB_1402172ac;
    }
  }
  else {
    puVar1 = *(undefined8 **)param_1[6];
    if (local_28 == 0) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 != puVar1) {
      FUN_140210f90(&local_28);
      goto LAB_140217282;
    }
    bVar4 = true;
  }
  plVar2 = (longlong *)FUN_140216a40(param_1,&local_28,bVar4,puVar3,param_3);
  *(undefined1 *)(param_2 + 2) = 1;
  local_20 = (undefined8 *)plVar2[1];
  *param_2 = *plVar2;
LAB_1402172ac:
  param_2[1] = (longlong)local_20;
  return param_2;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_1402176a0  @1402176a0  [medium:callgraph-r2]  (orig: FUN_1402176a0)
undefined8 * FUN_1402176a0(longlong *param_1,undefined8 *param_2,longlong *param_3,uint *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  uint uVar8;
  longlong *plVar9;
  longlong local_38;
  longlong *local_30;
  
  if (param_1[7] == 0) {
    FUN_140216a40(param_1,param_2,1,param_1[6],param_4);
  }
  else {
    lVar2 = *(longlong *)param_1[6];
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = param_3[1];
    if (lVar3 == lVar2) {
      if (*param_4 < *(uint *)(lVar3 + 0x18)) {
        FUN_140216a40(param_1,param_2,1,lVar3,param_4);
        return param_2;
      }
    }
    else {
      lVar2 = param_1[6];
      if ((*param_3 == 0) || (*param_3 != *param_1)) {
        _invalid_parameter_noinfo();
      }
      if (param_3[1] == lVar2) {
        if (*(uint *)(*(longlong *)(param_1[6] + 0x10) + 0x18) < *param_4) {
          FUN_140216a40(param_1,param_2,0,*(longlong *)(param_1[6] + 0x10),param_4);
          return param_2;
        }
      }
      else {
        uVar8 = *param_4;
        if (uVar8 < *(uint *)(param_3[1] + 0x18)) {
          local_38 = *param_3;
          local_30 = (longlong *)param_3[1];
          FUN_140210f90(&local_38);
          uVar8 = *param_4;
          if (*(uint *)(local_30 + 3) < uVar8) {
            if (*(char *)(local_30[2] + 0x161) != '\0') {
              FUN_140216a40(param_1,param_2,0,local_30,param_4);
              return param_2;
            }
            FUN_140216a40(param_1,param_2,1,param_3[1],param_4);
            return param_2;
          }
        }
        if (*(uint *)(param_3[1] + 0x18) < uVar8) {
          local_38 = *param_3;
          plVar4 = (longlong *)param_1[6];
          local_30 = (longlong *)param_3[1];
          lVar2 = *param_1;
          if (local_38 == 0) {
            _invalid_parameter_noinfo();
          }
          plVar9 = local_30;
          if (*(char *)((longlong)local_30 + 0x161) == '\0') {
            plVar9 = (longlong *)local_30[2];
            if (*(char *)((longlong)plVar9 + 0x161) == '\0') {
              cVar1 = *(char *)(*plVar9 + 0x161);
              plVar5 = (longlong *)*plVar9;
              while (cVar1 == '\0') {
                cVar1 = *(char *)(*plVar5 + 0x161);
                plVar9 = plVar5;
                plVar5 = (longlong *)*plVar5;
              }
            }
            else {
              cVar1 = *(char *)(local_30[1] + 0x161);
              plVar6 = (longlong *)local_30[1];
              plVar5 = local_30;
              while ((plVar9 = plVar6, cVar1 == '\0' && (plVar5 == (longlong *)plVar9[2]))) {
                cVar1 = *(char *)(plVar9[1] + 0x161);
                plVar6 = (longlong *)plVar9[1];
                plVar5 = plVar9;
              }
            }
          }
          else {
            _invalid_parameter_noinfo();
          }
          if ((local_38 == 0) || (local_38 != lVar2)) {
            _invalid_parameter_noinfo();
          }
          if ((plVar9 == plVar4) || (*param_4 < *(uint *)(plVar9 + 3))) {
            if (*(char *)(*(longlong *)(param_3[1] + 0x10) + 0x161) != '\0') {
              FUN_140216a40(param_1,param_2,0,param_3[1],param_4);
              return param_2;
            }
            FUN_140216a40(param_1,param_2,1,plVar9,param_4);
            return param_2;
          }
        }
      }
    }
    puVar7 = (undefined8 *)FUN_1402171c0(param_1,&local_38,param_4);
    *param_2 = *puVar7;
    param_2[1] = puVar7[1];
  }
  return param_2;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140217cc0  @140217cc0  [medium:callgraph-r1]  (orig: FUN_140217cc0)
undefined8 * FUN_140217cc0(longlong *param_1,uint *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  undefined8 *puVar4;
  longlong *plVar5;
  longlong lVar6;
  undefined4 local_2c8;
  undefined4 uStack_2c4;
  undefined4 uStack_2c0;
  undefined4 uStack_2bc;
  undefined4 local_2b8;
  undefined4 uStack_2b4;
  undefined4 uStack_2b0;
  undefined4 uStack_2ac;
  undefined8 local_2a8;
  undefined1 local_2a0 [16];
  uint local_290 [2];
  undefined1 local_288 [320];
  undefined1 local_148 [320];
  
  local_2a8 = 0xfffffffffffffffe;
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x161) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_2) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x161) == '\0');
  }
  plVar5 = (longlong *)*param_1;
  puVar1 = (undefined8 *)param_1[6];
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_2 < *(uint *)(puVar4 + 3))) {
    local_2c8 = SUB84(plVar5,0);
    uStack_2c4 = (undefined4)((ulonglong)plVar5 >> 0x20);
    uStack_2c0 = SUB84(puVar4,0);
    uStack_2bc = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_2b8 = local_2c8;
    uStack_2b4 = uStack_2c4;
    uStack_2b0 = uStack_2c0;
    uStack_2ac = uStack_2bc;
    uVar3 = FUN_140215730(local_148);
    local_290[0] = *param_2;
    FUN_140215920(local_288,uVar3);
    puVar4 = (undefined8 *)FUN_1402176a0(param_1,local_2a0,&local_2b8,local_290);
    plVar5 = (longlong *)*puVar4;
    puVar4 = (undefined8 *)puVar4[1];
    FUN_140215510(local_288);
    FUN_140215510(local_148);
  }
  if (plVar5 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar5;
  }
  if (puVar4 == *(undefined8 **)(lVar6 + 0x30)) {
    _invalid_parameter_noinfo();
  }
  return puVar4 + 4;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_1402188f0  @1402188f0  [medium:callgraph-r1]  (orig: FUN_1402188f0)
undefined8 FUN_1402188f0(undefined4 *param_1,uint param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong lVar6;
  longlong *plVar7;
  uint uVar8;
  undefined8 *puVar9;
  undefined8 *puVar10;
  longlong local_res8;
  uint local_res10 [2];
  longlong local_res18;
  undefined8 *local_res20;
  longlong local_80;
  undefined8 *local_78;
  longlong local_70;
  undefined8 local_68;
  longlong local_58;
  undefined8 *local_50;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x34))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x2d);
  puVar10 = *(undefined8 **)(param_1 + 0x34);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar4 = (undefined8 *)puVar9[2];
      puVar9 = puVar10;
    }
    else {
      puVar4 = (undefined8 *)*puVar9;
    }
    puVar10 = puVar9;
    puVar9 = puVar4;
    cVar1 = *(char *)((longlong)puVar4 + 0x2d);
  }
  local_78 = puVar10;
  local_80 = *(longlong *)(param_1 + 0x28);
  puVar9 = *(undefined8 **)(param_1 + 0x34);
  local_res10[0] = param_2;
  if (*(longlong *)(param_1 + 0x28) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar10 == puVar9) || (param_2 < *(uint *)(puVar10 + 3))) {
    local_68 = *(undefined8 *)(param_1 + 0x34);
    local_70 = *(longlong *)(param_1 + 0x28);
    plVar7 = &local_70;
  }
  else {
    plVar7 = &local_80;
  }
  local_58 = *plVar7;
  local_50 = (undefined8 *)plVar7[1];
  lVar3 = *(longlong *)(param_1 + 0x34);
  if ((local_58 == 0) || (local_58 != *(longlong *)(param_1 + 0x28))) {
    _invalid_parameter_noinfo();
  }
  if (local_50 == (undefined8 *)lVar3) {
    uVar5 = 0;
  }
  else {
    local_res8 = FUN_1403bfdd0(0x2e8);
    if (local_res8 == 0) {
      lVar3 = 0;
    }
    else {
      lVar3 = FUN_1403dcb60(local_res8,*param_1);
    }
    if (lVar3 == 0) {
      log_InlineLogERROR("CTexasMgr::CreateNewTable by config[%u], failed in new TexasHoldEm");
      uVar5 = 0;
    }
    else {
      param_1[5] = param_1[5] + 1;
      uVar8 = param_1[5] * 100 + param_2;
      local_res8 = CONCAT44(local_res8._4_4_,uVar8);
      local_res20 = *(undefined8 **)(param_1 + 0x14);
      local_res18 = *(longlong *)(param_1 + 8);
      cVar1 = *(char *)((longlong)local_res20[1] + 0x29);
      puVar9 = local_res20;
      puVar10 = (undefined8 *)local_res20[1];
      while (cVar1 == '\0') {
        if (*(uint *)(puVar10 + 3) < uVar8) {
          puVar4 = (undefined8 *)puVar10[2];
          puVar10 = puVar9;
        }
        else {
          puVar4 = (undefined8 *)*puVar10;
        }
        puVar9 = puVar10;
        puVar10 = puVar4;
        cVar1 = *(char *)((longlong)puVar4 + 0x29);
      }
      local_50 = puVar9;
      local_58 = local_res18;
      puVar10 = *(undefined8 **)(param_1 + 0x14);
      if (local_res18 == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar9 == puVar10) || (uVar8 < *(uint *)(puVar9 + 3))) {
        local_68 = *(undefined8 *)(param_1 + 0x14);
        local_70 = *(longlong *)(param_1 + 8);
        plVar7 = &local_70;
      }
      else {
        plVar7 = &local_58;
      }
      local_80 = *plVar7;
      local_78 = (undefined8 *)plVar7[1];
      if ((local_80 == 0) || (local_80 != local_res18)) {
        _invalid_parameter_noinfo();
      }
      if (local_78 == local_res20) {
        cVar1 = FUN_1403c0230(lVar3,uVar8,param_2);
        if (cVar1 == '\0') {
          log_InlineLogERROR("CTexasMgr::CreateNewTable by config[%u], failed in create TexasHoldEm"
                            );
          FUN_1403dc530(lVar3);
          FUN_1403bfe30(lVar3);
          uVar5 = 0;
        }
        else {
          uVar2 = FUN_1403bc320(lVar3);
          uVar5 = FUN_140008520(*param_1);
          uVar5 = FUN_1401600a0(uVar5);
          cVar1 = FUN_14031bee0(uVar5,uVar2);
          if (cVar1 == '\0') {
            log_InlineLogERROR(
                              "CTexasMgr::CreateNewTable by config[%u], failed in AddTableWittnessMgr"
                              );
            FUN_1403dc530(lVar3);
            FUN_1403bfe30(lVar3);
            uVar5 = 0;
          }
          else {
            uVar2 = FUN_1403bc320(lVar3);
            local_58 = CONCAT44(local_58._4_4_,uVar2);
            local_50 = (undefined8 *)lVar3;
            FUN_140213fe0(param_1 + 8,&local_70,&local_58);
            uVar2 = FUN_1403bc320(lVar3);
            local_res8 = CONCAT44(local_res8._4_4_,uVar2);
            lVar6 = FUN_140217cc0(param_1 + 0x18,local_res10);
            FUN_14000d480(lVar6 + 0x100,&local_58,&local_res8);
            uVar5 = FUN_1403bc320(lVar3);
          }
        }
      }
      else {
        FUN_1403dc530(lVar3);
        FUN_1403bfe30(lVar3);
        log_InlineLogERROR("CTexasMgr::CreateNewTable by config[%u], ID[%d] Repeat");
        uVar5 = 0;
      }
    }
  }
  return uVar5;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_1402190f0  @1402190f0  [medium:callgraph-r0]  (orig: FUN_1402190f0)
ulonglong FUN_1402190f0(undefined4 *param_1,undefined4 param_2,longlong *param_3)

{
  ulonglong *puVar1;
  longlong *plVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  undefined4 uVar6;
  ulonglong in_RAX;
  IStringManager *pIVar7;
  undefined8 uVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong lVar11;
  undefined8 *puVar12;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  ulonglong extraout_RAX_01;
  longlong *plVar13;
  longlong *plVar14;
  ulonglong uVar15;
  bool bVar16;
  undefined4 local_res10 [2];
  longlong *local_res18;
  __time32_t local_res20 [2];
  ulonglong *local_c8;
  longlong *plStack_c0;
  longlong *local_b8;
  longlong *local_b0;
  ulonglong *local_a8;
  longlong *plStack_a0;
  longlong *local_98;
  ulonglong *local_88;
  longlong *plStack_80;
  longlong local_78;
  undefined8 local_70;
  longlong local_68;
  ulonglong *local_60;
  longlong local_50;
  ulonglong *local_48;
  
  local_70 = 0xfffffffffffffffe;
  if (param_3 == (longlong *)0x0) {
    uVar9 = in_RAX & 0xffffffffffffff00;
  }
  else {
    local_res10[0] = param_2;
    local_res18 = param_3;
    if (*(char *)(param_1 + 7) == '\0') {
      pIVar7 = theInstance();
      lVar11 = param_3[2];
      uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_ACTIVE_NO_OPEN");
      uVar9 = (**(code **)(lVar11 + 0x358))(param_3 + 2,uVar8);
      uVar9 = uVar9 & 0xffffffffffffff00;
    }
    else {
      param_3 = param_3 + 2;
      iVar5 = (**(code **)(*param_3 + 0x168))(param_3);
      if (iVar5 == param_1[6]) {
        FUN_140214410(param_1 + 0x28,&local_c8,local_res10);
        puVar1 = local_c8;
        plVar14 = *(longlong **)(param_1 + 0x34);
        uVar9 = 0;
        local_60 = *(ulonglong **)(param_1 + 0x28);
        if ((local_c8 == (ulonglong *)0x0) || (local_c8 != local_60)) {
          _invalid_parameter_noinfo();
        }
        plVar13 = plStack_c0;
        if (plStack_c0 == plVar14) {
          pIVar7 = theInstance();
          lVar11 = *param_3;
          uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_AUTO_NO_CFG");
          uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
          uVar9 = uVar9 & 0xffffffffffffff00;
        }
        else {
          local_res20[0] = 0;
          _time32(local_res20);
          if ((local_res20[0] < (int)param_1[1]) || ((int)param_1[2] < local_res20[0])) {
            pIVar7 = theInstance();
            lVar11 = *param_3;
            uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_TIME_ERROR");
            uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
            uVar9 = uVar9 & 0xffffffffffffff00;
          }
          else {
            if (puVar1 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar10 = uVar9;
            }
            else {
              uVar10 = *puVar1;
            }
            if (plVar13 == *(longlong **)(uVar10 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if (*(int *)((longlong)plVar13 + 0x1c) == 0) {
              uVar10 = (**(code **)(*local_res18 + 0x60))();
            }
            else {
              if (puVar1 == (ulonglong *)0x0) {
                _invalid_parameter_noinfo();
                uVar10 = uVar9;
              }
              else {
                uVar10 = *puVar1;
              }
              if (plVar13 == *(longlong **)(uVar10 + 0x30)) {
                _invalid_parameter_noinfo();
              }
              uVar10 = uVar9;
              if (*(int *)((longlong)plVar13 + 0x1c) == 1) {
                uVar10 = (ulonglong)*(uint *)((longlong)local_res18 + 0xfa4);
              }
            }
            if (puVar1 == (ulonglong *)0x0) {
              _invalid_parameter_noinfo();
              uVar15 = uVar9;
            }
            else {
              uVar15 = *puVar1;
            }
            if (plVar13 == *(longlong **)(uVar15 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            if ((longlong)uVar10 < (longlong)(*(int *)((longlong)plVar13 + 0x24) * 10)) {
              pIVar7 = theInstance();
              lVar11 = *param_3;
              uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_AUTO_MONEY_LOW");
              uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
              uVar9 = uVar9 & 0xffffffffffffff00;
            }
            else {
              lVar11 = FUN_140008520(*param_1);
              if (*(longlong *)(lVar11 + 0x110) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar10 = uVar9;
              }
              else {
                uVar10 = *(ulonglong *)(lVar11 + 0x110);
              }
              plVar14 = local_res18;
              uVar6 = (**(code **)(*local_res18 + 8))(local_res18);
              cVar3 = FUN_14031b8d0(uVar10,uVar6);
              if (cVar3 == '\0') {
                if ((int)plVar14[0x248] == 0) {
                  puVar12 = (undefined8 *)FUN_140217cc0(param_1 + 0x18,local_res10);
                  lVar11 = puVar12[0x17];
                  if (lVar11 == 0) {
                    lVar11 = puVar12[0xf];
                    if (lVar11 == 0) {
                      lVar11 = puVar12[7];
                      if (lVar11 == 0) {
                        if (puVar12[0x27] == 0) {
                          uVar6 = FUN_1402188f0(param_1,param_2);
                        }
                        else {
                          lVar11 = *(longlong *)puVar12[0x26];
                          local_48 = (ulonglong *)puVar12[0x20];
                          if (local_48 == (ulonglong *)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          else {
                            uVar9 = *local_48;
                          }
                          if (lVar11 == *(longlong *)(uVar9 + 0x30)) {
                            _invalid_parameter_noinfo();
                          }
                          uVar6 = *(undefined4 *)(lVar11 + 0x18);
                        }
                      }
                      else {
                        plVar14 = *(longlong **)puVar12[6];
                        puVar1 = (ulonglong *)*puVar12;
                        local_c8 = puVar1;
                        plStack_c0 = plVar14;
                        local_50 = lVar11;
                        for (iVar5 = tq::RandGet((int)lVar11); 0 < iVar5; iVar5 = iVar5 + -1) {
                          if (puVar1 == (ulonglong *)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                            plVar13 = plVar14;
                            plVar2 = (longlong *)plVar14[2];
                            if (*(char *)(plVar14[2] + 0x1d) == '\0') {
                              do {
                                plVar14 = plVar2;
                                plVar2 = (longlong *)*plVar14;
                                local_b0 = plVar14;
                              } while (*(char *)(*plVar14 + 0x1d) == '\0');
                            }
                            else {
                              do {
                                plVar14 = (longlong *)plVar13[1];
                                if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                                bVar16 = plVar13 == (longlong *)plVar14[2];
                                plVar13 = plVar14;
                              } while (bVar16);
                            }
                          }
                          else {
                            _invalid_parameter_noinfo();
                          }
                        }
                        for (; iVar5 < 0; iVar5 = iVar5 + 1) {
                          if (puVar1 == (ulonglong *)0x0) {
                            _invalid_parameter_noinfo();
                          }
                          if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                            plVar13 = (longlong *)*plVar14;
                            if (*(char *)(*plVar14 + 0x1d) == '\0') {
                              do {
                                plVar2 = plVar13 + 2;
                                plVar14 = plVar13;
                                plVar13 = (longlong *)*plVar2;
                              } while (*(char *)(*plVar2 + 0x1d) == '\0');
                            }
                            else {
                              do {
                                plVar13 = plVar14;
                                plVar14 = (longlong *)plVar13[1];
                                if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                              } while (plVar13 == (longlong *)*plVar14);
                              if (*(char *)((longlong)plVar13 + 0x1d) != '\0') {
                                _invalid_parameter_noinfo();
                                plVar14 = plVar13;
                              }
                            }
                          }
                          else {
                            plVar14 = (longlong *)plVar14[2];
                            if (*(char *)((longlong)plVar14 + 0x1d) != '\0') {
                              _invalid_parameter_noinfo();
                            }
                          }
                        }
                        if (puVar1 == (ulonglong *)0x0) {
                          _invalid_parameter_noinfo();
                        }
                        else {
                          uVar9 = *puVar1;
                        }
                        if (plVar14 == *(longlong **)(uVar9 + 0x30)) {
                          _invalid_parameter_noinfo();
                        }
                        uVar6 = (undefined4)plVar14[3];
                        plVar14 = local_res18;
                      }
                    }
                    else {
                      plVar14 = *(longlong **)puVar12[0xe];
                      puVar1 = (ulonglong *)puVar12[8];
                      local_88 = puVar1;
                      plStack_80 = plVar14;
                      local_68 = lVar11;
                      for (iVar5 = tq::RandGet((int)lVar11); 0 < iVar5; iVar5 = iVar5 + -1) {
                        if (puVar1 == (ulonglong *)0x0) {
                          _invalid_parameter_noinfo();
                        }
                        if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                          plVar13 = plVar14;
                          plVar2 = (longlong *)plVar14[2];
                          if (*(char *)(plVar14[2] + 0x1d) == '\0') {
                            do {
                              plVar14 = plVar2;
                              plVar2 = (longlong *)*plVar14;
                              local_b8 = plVar14;
                            } while (*(char *)(*plVar14 + 0x1d) == '\0');
                          }
                          else {
                            do {
                              plVar14 = (longlong *)plVar13[1];
                              if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                              bVar16 = plVar13 == (longlong *)plVar14[2];
                              plVar13 = plVar14;
                            } while (bVar16);
                          }
                        }
                        else {
                          _invalid_parameter_noinfo();
                        }
                      }
                      for (; iVar5 < 0; iVar5 = iVar5 + 1) {
                        if (puVar1 == (ulonglong *)0x0) {
                          _invalid_parameter_noinfo();
                        }
                        if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                          plVar13 = (longlong *)*plVar14;
                          if (*(char *)(*plVar14 + 0x1d) == '\0') {
                            do {
                              plVar2 = plVar13 + 2;
                              plVar14 = plVar13;
                              plVar13 = (longlong *)*plVar2;
                            } while (*(char *)(*plVar2 + 0x1d) == '\0');
                          }
                          else {
                            do {
                              plVar13 = plVar14;
                              plVar14 = (longlong *)plVar13[1];
                              if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                            } while (plVar13 == (longlong *)*plVar14);
                            if (*(char *)((longlong)plVar13 + 0x1d) != '\0') {
                              _invalid_parameter_noinfo();
                              plVar14 = plVar13;
                            }
                          }
                        }
                        else {
                          plVar14 = (longlong *)plVar14[2];
                          if (*(char *)((longlong)plVar14 + 0x1d) != '\0') {
                            _invalid_parameter_noinfo();
                          }
                        }
                      }
                      if (puVar1 == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                      }
                      else {
                        uVar9 = *puVar1;
                      }
                      if (plVar14 == *(longlong **)(uVar9 + 0x30)) {
                        _invalid_parameter_noinfo();
                      }
                      uVar6 = (undefined4)plVar14[3];
                      plVar14 = local_res18;
                    }
                  }
                  else {
                    plVar14 = *(longlong **)puVar12[0x16];
                    puVar1 = (ulonglong *)puVar12[0x10];
                    local_a8 = puVar1;
                    plStack_a0 = plVar14;
                    local_78 = lVar11;
                    for (iVar5 = tq::RandGet((int)lVar11); 0 < iVar5; iVar5 = iVar5 + -1) {
                      if (puVar1 == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                      }
                      if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                        plVar13 = plVar14;
                        plVar2 = (longlong *)plVar14[2];
                        if (*(char *)(plVar14[2] + 0x1d) == '\0') {
                          do {
                            plVar14 = plVar2;
                            plVar2 = (longlong *)*plVar14;
                            local_98 = plVar14;
                          } while (*(char *)(*plVar14 + 0x1d) == '\0');
                        }
                        else {
                          do {
                            plVar14 = (longlong *)plVar13[1];
                            if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                            bVar16 = plVar13 == (longlong *)plVar14[2];
                            plVar13 = plVar14;
                          } while (bVar16);
                        }
                      }
                      else {
                        _invalid_parameter_noinfo();
                      }
                    }
                    for (; iVar5 < 0; iVar5 = iVar5 + 1) {
                      if (puVar1 == (ulonglong *)0x0) {
                        _invalid_parameter_noinfo();
                      }
                      if (*(char *)((longlong)plVar14 + 0x1d) == '\0') {
                        plVar13 = (longlong *)*plVar14;
                        if (*(char *)(*plVar14 + 0x1d) == '\0') {
                          do {
                            plVar2 = plVar13 + 2;
                            plVar14 = plVar13;
                            plVar13 = (longlong *)*plVar2;
                          } while (*(char *)(*plVar2 + 0x1d) == '\0');
                        }
                        else {
                          do {
                            plVar13 = plVar14;
                            plVar14 = (longlong *)plVar13[1];
                            if (*(char *)((longlong)plVar14 + 0x1d) != '\0') break;
                          } while (plVar13 == (longlong *)*plVar14);
                          if (*(char *)((longlong)plVar13 + 0x1d) != '\0') {
                            _invalid_parameter_noinfo();
                            plVar14 = plVar13;
                          }
                        }
                      }
                      else {
                        plVar14 = (longlong *)plVar14[2];
                        if (*(char *)((longlong)plVar14 + 0x1d) != '\0') {
                          _invalid_parameter_noinfo();
                        }
                      }
                    }
                    if (puVar1 == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                    }
                    else {
                      uVar9 = *puVar1;
                    }
                    if (plVar14 == *(longlong **)(uVar9 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    uVar6 = (undefined4)plVar14[3];
                    plVar14 = local_res18;
                  }
                  lVar11 = FUN_140214ce0(param_1,uVar6);
                  if (lVar11 == 0) {
                    log_InlineLogERROR("CTexasMgr::OnUserMatch. QueryTable(%u) not found");
                    uVar9 = extraout_RAX & 0xffffffffffffff00;
                  }
                  else {
                    cVar3 = FUN_1403bc2d0(lVar11);
                    if (cVar3 == '\0') {
                      log_InlineLogERROR("CTexasMgr::OnUserMatch. QueryTable(%u) is not match table"
                                        );
                      uVar9 = extraout_RAX_00 & 0xffffffffffffff00;
                    }
                    else {
                      bVar4 = FUN_1403cc1d0(lVar11);
                      if (bVar4 < 9) {
                        uVar9 = FUN_1403e26a0(lVar11,plVar14,1,bVar4);
                      }
                      else {
                        log_InlineLogERROR("CTexasMgr::OnUserMatch. QueryTable(%u) is no empty seat"
                                          );
                        uVar9 = extraout_RAX_01 & 0xffffffffffffff00;
                      }
                    }
                  }
                }
                else {
                  pIVar7 = theInstance();
                  lVar11 = *param_3;
                  uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_AUTO_HAS_JOIN");
                  uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
                  uVar9 = uVar9 & 0xffffffffffffff00;
                }
              }
              else {
                pIVar7 = theInstance();
                lVar11 = *param_3;
                uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_AUTO_WITTNESS");
                uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
                uVar9 = uVar9 & 0xffffffffffffff00;
              }
            }
          }
        }
      }
      else {
        pIVar7 = theInstance();
        lVar11 = *param_3;
        uVar8 = (*(code *)**(undefined8 **)pIVar7)(pIVar7,"STR_TEXAX_MAP_ERROR");
        uVar9 = (**(code **)(lVar11 + 0x358))(param_3,uVar8);
        uVar9 = uVar9 & 0xffffffffffffff00;
      }
    }
  }
  return uVar9;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_140373f50  @140373f50  [medium:callgraph-r1]  (orig: FUN_140373f50)
undefined8 FUN_140373f50(longlong param_1)

{
  return *(undefined8 *)(param_1 + 0x208);
}

// ==== CMsgShowHandRaceInteractive@texasholdem::helper_1403cc1d0  @1403cc1d0  [medium:callgraph-r1]  (orig: FUN_1403cc1d0)
undefined1 FUN_1403cc1d0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  ulonglong uVar7;
  longlong lVar8;
  
  if (*(longlong *)(param_1 + 0x288) != 0) {
    plVar2 = *(longlong **)(param_1 + 0x250);
    plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x280);
    for (iVar5 = tq::RandGet((int)*(longlong *)(param_1 + 0x288)); 0 < iVar5; iVar5 = iVar5 + -1) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)plVar6 + 0x1a) == '\0') {
        plVar3 = (longlong *)plVar6[2];
        if (*(char *)((longlong)plVar3 + 0x1a) == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x1a);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
          while (cVar1 == '\0') {
            cVar1 = *(char *)(*plVar3 + 0x1a);
            plVar6 = plVar3;
            plVar3 = (longlong *)*plVar3;
          }
        }
        else {
          cVar1 = *(char *)(plVar6[1] + 0x1a);
          plVar4 = (longlong *)plVar6[1];
          plVar3 = plVar6;
          while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
            cVar1 = *(char *)(plVar6[1] + 0x1a);
            plVar4 = (longlong *)plVar6[1];
            plVar3 = plVar6;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
      }
    }
    if (iVar5 < 0) {
      uVar7 = (ulonglong)(uint)-iVar5;
      do {
        if (plVar2 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)plVar6 + 0x1a) == '\0') {
          plVar3 = (longlong *)*plVar6;
          if (*(char *)((longlong)plVar3 + 0x1a) == '\0') {
            cVar1 = *(char *)(plVar3[2] + 0x1a);
            plVar4 = (longlong *)plVar3[2];
            while (plVar6 = plVar3, cVar1 == '\0') {
              cVar1 = *(char *)(plVar4[2] + 0x1a);
              plVar3 = plVar4;
              plVar4 = (longlong *)plVar4[2];
            }
          }
          else {
            cVar1 = *(char *)(plVar6[1] + 0x1a);
            plVar4 = (longlong *)plVar6[1];
            plVar3 = plVar6;
            while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)*plVar6))) {
              cVar1 = *(char *)(plVar6[1] + 0x1a);
              plVar4 = (longlong *)plVar6[1];
              plVar3 = plVar6;
            }
            if (*(char *)((longlong)plVar3 + 0x1a) != '\0') {
              _invalid_parameter_noinfo();
              plVar6 = plVar3;
            }
          }
        }
        else {
          plVar6 = (longlong *)plVar6[2];
          if (*(char *)((longlong)plVar6 + 0x1a) != '\0') {
            _invalid_parameter_noinfo();
          }
        }
        uVar7 = uVar7 - 1;
      } while (uVar7 != 0);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    return (char)plVar6[3];
  }
  return 100;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::vfunc_1  @140459d10  [high:rtti-vtable]  (orig: FUN_140459d10)
undefined8 FUN_140459d10(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::vfunc_0  @140459da0  [high:rtti-vtable]  (orig: FUN_140459da0)
undefined8 * FUN_140459da0(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandRaceInteractive::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandRaceInteractive@texasholdem::vfunc_3  @140459df0  [high:rtti-vtable]  (orig: FUN_140459df0)
void FUN_140459df0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x90) + 0x88))(*(longlong **)(lVar1 + 0x90),param_1);
  if (lVar1 != 0) {
    if (**(char **)(param_1 + 0x428) == '\0') {
      uVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar2 = FUN_140087830(uVar2);
      FUN_1402190f0(uVar2,1,lVar1);
    }
    else if (**(char **)(param_1 + 0x428) == '\x01') {
      uVar2 = FUN_140162130(lVar1);
      *(undefined8 *)(*(longlong *)(param_1 + 0x428) + 1) = uVar2;
                    /* WARNING: Could not recover jumptable at 0x000140459ed0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))(lVar1 + 0x10,param_1);
      return;
    }
  }
  return;
}

