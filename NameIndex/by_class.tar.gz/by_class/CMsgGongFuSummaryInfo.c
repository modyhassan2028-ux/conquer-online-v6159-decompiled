// ==== CMsgGongFuSummaryInfo::ctor_or_dtor  @140401f30  [high:vtable-assign]  (orig: FUN_140401f30)
undefined8 * FUN_140401f30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgGongFuSummaryInfo::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgGongFuSummaryInfo::ctor_or_dtor  @140401f80  [high:vtable-assign]  (orig: FUN_140401f80)
void FUN_140401f80(undefined8 *param_1)

{
  *param_1 = CMsgGongFuSummaryInfo::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgGongFuSummaryInfo::vfunc_5  @140401fb0  [high:rtti-vtable]  (orig: FUN_140401fb0)
bool FUN_140401fb0(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xa8d;
    }
  }
  return false;
}

// ==== CMsgGongFuSummaryInfo::vfunc_3  @140402200  [high:rtti-vtable]  (orig: FUN_140402200)
void FUN_140402200(void)

{
  return;
}

// ==== CMsgGongFuSummaryInfo::ctor_or_dtor  @140402210  [high:vtable-assign]  (orig: FUN_140402210)
undefined8 * FUN_140402210(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgGongFuSummaryInfo::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

