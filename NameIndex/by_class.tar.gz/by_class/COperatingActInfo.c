// ==== COperatingActInfo::helper_14032af40  @14032af40  [medium:callgraph-r0]  (orig: FUN_14032af40)
void FUN_14032af40(void *param_1)

{
  if ((DAT_140976050 & 1) == 0) {
    DAT_140976050 = DAT_140976050 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976048,"COperatingActInfo");
    atexit((_func_5014 *)&LAB_1406d6a80);
  }
                    /* WARNING: Could not recover jumptable at 0x00014032af95. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976048,param_1);
  return;
}

// ==== COperatingActInfo::ctor_or_dtor  @14032b000  [high:vtable-assign]  (orig: FUN_14032b000)
undefined8 * FUN_14032b000(undefined8 *param_1,byte param_2)

{
  *param_1 = COperatingActInfo::vftable;
  if ((param_2 & 1) != 0) {
    FUN_14032af40();
  }
  return param_1;
}

// ==== COperatingActInfo::ctor_or_dtor  @14032b030  [high:vtable-assign]  (orig: FUN_14032b030)
undefined8 * FUN_14032b030(void)

{
  undefined8 *puVar1;
  
  if ((DAT_140976050 & 1) == 0) {
    DAT_140976050 = DAT_140976050 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976048,"COperatingActInfo");
    atexit((_func_5014 *)&LAB_1406d6a80);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140976048,0x10);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = COperatingActInfo::vftable;
    puVar1[1] = 0;
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","pOperatingActInfo",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\operatingact\\operatingactinfo.cpp"
                       ,0x19);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

