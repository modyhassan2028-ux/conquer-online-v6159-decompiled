// ==== CNetMsg@world_kernel::vfunc_2  @1400752e0  [high:rtti-vtable]  (orig: FUN_1400752e0)
bool FUN_1400752e0(longlong param_1)

{
  return *(int *)(param_1 + 8) != 0;
}

// ==== CNetMsg@world_kernel::vfunc_1  @1400752f0  [high:rtti-vtable]  (orig: FUN_1400752f0)
undefined8 FUN_1400752f0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CNetMsg@world_kernel::vfunc_3  @140075320  [high:rtti-vtable]  (orig: FUN_140075320)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140075320(longlong param_1)

{
  undefined1 auStack_448 [32];
  undefined4 local_428;
  char local_418;
  undefined1 local_417 [1023];
  ulonglong local_18;
  
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  local_418 = '\0';
  memset(local_417,0,0x3ff);
  local_428 = *(undefined4 *)(param_1 + 0xc);
  _snprintf(&local_418,0x3ff,"Process Msg:%d, Size:%d");
  log_InlineLogMessage(&local_418);
  return;
}

// ==== CNetMsg@world_kernel::vfunc_4  @1400753a0  [high:rtti-vtable]  (orig: FUN_1400753a0)
void FUN_1400753a0(longlong param_1,undefined8 param_2)

{
  if (*(int *)(param_1 + 0x414) != -1) {
    if (DAT_140975af8 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
                    /* WARNING: Could not recover jumptable at 0x00014007540c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*DAT_140975af8 + 0x38))(DAT_140975af8,*(undefined4 *)(param_1 + 0x414),param_2);
    return;
  }
  if (DAT_140975af8 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x00014007545c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*DAT_140975af8 + 0x28))(DAT_140975af8,*(undefined4 *)(param_1 + 0x418),param_2);
  return;
}

// ==== CNetMsg@world_kernel::vfunc_0  @140076430  [high:rtti-vtable]  (orig: FUN_140076430)
undefined8 * FUN_140076430(undefined8 *param_1,byte param_2)

{
  *param_1 = world_kernel::CNetMsg::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

