// ==== CMsgTrainingVitality::helper_14008adc0  @14008adc0  [medium:callgraph-r1]  (orig: FUN_14008adc0)
undefined4 FUN_14008adc0(longlong param_1,int param_2)

{
  if (param_2 == 0) {
    return *(undefined4 *)(param_1 + 0x2b0);
  }
  if (param_2 == 1) {
    return *(undefined4 *)(param_1 + 0x2b4);
  }
  if (param_2 == 2) {
    return *(undefined4 *)(param_1 + 0x2b8);
  }
  if (param_2 == 3) {
    return *(undefined4 *)(param_1 + 700);
  }
  return 0;
}

// ==== CMsgTrainingVitality::helper_14008aea0  @14008aea0  [medium:callgraph-r1]  (orig: FUN_14008aea0)
int FUN_14008aea0(longlong param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2c0);
  if (*(int *)(param_1 + 0x2c0) < 0) {
    iVar1 = 0;
  }
  return iVar1;
}

// ==== CMsgTrainingVitality::helper_14008af80  @14008af80  [medium:callgraph-r1]  (orig: FUN_14008af80)
int FUN_14008af80(longlong param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2c8);
  if (*(int *)(param_1 + 0x2c8) < 0) {
    iVar1 = 0;
  }
  return iVar1;
}

// ==== CMsgTrainingVitality::helper_14008af90  @14008af90  [medium:callgraph-r1]  (orig: FUN_14008af90)
int FUN_14008af90(longlong param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x2cc);
  if (*(int *)(param_1 + 0x2cc) < 0) {
    iVar1 = 0;
  }
  return iVar1;
}

// ==== CMsgTrainingVitality::helper_1400a7e10  @1400a7e10  [medium:callgraph-r1]  (orig: FUN_1400a7e10)
undefined4 * FUN_1400a7e10(longlong param_1,undefined4 *param_2,byte param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  longlong lVar8;
  undefined4 local_res8;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  longlong local_20;
  
  puVar7 = (undefined8 *)(*(undefined8 **)(param_1 + 0x638))[1];
  cVar1 = *(char *)((longlong)puVar7 + 0x1f);
  puVar3 = *(undefined8 **)(param_1 + 0x638);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar7 + 3) < param_3) {
      puVar5 = (undefined8 *)puVar7[2];
      puVar7 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar7;
    }
    puVar3 = puVar7;
    puVar7 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x1f);
  }
  puVar7 = *(undefined8 **)(param_1 + 0x638);
  local_40 = puVar3;
  local_48 = *(longlong *)(param_1 + 0x608);
  if (*(longlong *)(param_1 + 0x608) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar7) || (param_3 < *(byte *)(puVar3 + 3))) {
    plVar6 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x638);
    local_38 = *(longlong *)(param_1 + 0x608);
  }
  else {
    plVar6 = &local_48;
  }
  plVar2 = (longlong *)*plVar6;
  lVar8 = *(longlong *)(param_1 + 0x638);
  local_28 = plVar2;
  local_20 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x608))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_20;
  if (local_20 == lVar8) {
    local_res8 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    local_res8 = *(undefined4 *)(lVar4 + 0x1a);
  }
  *param_2 = local_res8;
  return param_2;
}

// ==== CMsgTrainingVitality::helper_1402e1140  @1402e1140  [medium:callgraph-r2]  (orig: FUN_1402e1140)
ulonglong FUN_1402e1140(longlong param_1,char param_2,char param_3)

{
  byte bVar1;
  uint uVar2;
  uint uVar3;
  ulonglong uVar4;
  
  if ((((param_2 != '\0') && (param_3 != '\0')) && (*(longlong *)(param_1 + 0xa0) != 0)) &&
     (*(longlong *)(param_1 + 0x98) != 0)) {
    uVar2 = FUN_140475350();
    uVar3 = FUN_1404754d0(*(undefined8 *)(param_1 + 0x98),param_2,param_3);
    if (uVar2 < uVar3) {
      uVar4 = 0;
    }
    else {
      bVar1 = FUN_1404738b0(*(undefined8 *)(param_1 + 0xa0),param_2);
      uVar3 = (uint)bVar1 * (uVar2 - uVar3) + uVar3 * 100;
      if (uVar2 * 100 < uVar3) {
        uVar3 = uVar2 * 100;
      }
      uVar4 = (ulonglong)(uVar3 + 0x32) / 100;
    }
    return uVar4;
  }
  return 0;
}

// ==== CMsgTrainingVitality::helper_1402e1210  @1402e1210  [medium:callgraph-r1]  (orig: FUN_1402e1210)
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined8 FUN_1402e1210(undefined8 param_1,longlong *param_2,uint param_3)

{
  longlong lVar1;
  char cVar2;
  uint uVar3;
  undefined4 uVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  ulonglong uVar7;
  int iVar8;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"IF_NOT","pUser",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\trainingvitality\\trainingvitalitymgr.cpp"
                      );
    return 0;
  }
  uVar3 = FUN_140371860(param_2 + 0x1cf);
  if (uVar3 + *(int *)((longlong)param_2 + 0xfa4) < param_3) {
    pIVar5 = theInstance();
    lVar1 = param_2[2];
    uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_NOT_SO_MUCH_EMONEY");
    (**(code **)(lVar1 + 0x358))(param_2 + 2,uVar6);
LAB_1402e12b4:
    uVar6 = 0;
  }
  else {
    if (param_3 < uVar3) {
      iVar8 = 0;
      uVar3 = param_3;
    }
    else {
      iVar8 = param_3 - uVar3;
    }
    if (0 < (int)uVar3) {
      cVar2 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x2d,(longlong)(int)-uVar3,1);
      if (cVar2 == '\0') goto LAB_1402e12b4;
    }
    if (0 < iVar8) {
      cVar2 = (**(code **)(param_2[2] + 0x2e0))(param_2 + 2,0x1d,(longlong)-iVar8,1);
      if (cVar2 == '\0') goto LAB_1402e12b4;
    }
    if (0 < (int)uVar3) {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      FUN_140174470(param_2,0x32,uVar4);
      uVar6 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t350\t4229\t%d\t%d\t1\t",uVar7 & 0xffffffff,uVar6
                   );
    }
    if (0 < iVar8) {
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      FUN_1401742b0(param_2,0x32,uVar4);
      uVar6 = (**(code **)(param_2[2] + 0x18))(param_2 + 2);
      uVar7 = (**(code **)(*param_2 + 8))(param_2);
      tq::MyLogSave("gmlog/emoney_buy","%u\t%s\t%u\t700\t710\t%d\t%d\t1\t",uVar7 & 0xffffffff,uVar6)
      ;
    }
    uVar6 = 1;
  }
  return uVar6;
}

// ==== CMsgTrainingVitality::helper_1402e1420  @1402e1420  [medium:callgraph-r1]  (orig: FUN_1402e1420)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e1420(undefined8 param_1,longlong *param_2,longlong param_3,undefined1 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined4 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_468 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
    if (param_3 != 0) {
      FUN_140477070(local_458);
      uVar2 = FUN_140478350(param_3);
      uVar3 = FUN_140166bf0(param_2);
      uVar4 = (**(code **)(*param_2 + 8))(param_2);
      local_478 = uVar2;
      cVar1 = FUN_140477130(local_458,1,uVar4,uVar3);
      if (cVar1 == '\0') {
        FUN_1404770c0(local_458);
      }
      else {
        local_470 = param_8;
        local_478 = param_7;
        cVar1 = FUN_1404771d0(local_458,param_4,param_5,param_6);
        if (cVar1 == '\0') {
          FUN_1404770c0(local_458);
        }
        else {
          (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_458);
          FUN_1404770c0(local_458);
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e1540  @1402e1540  [medium:callgraph-r1]  (orig: FUN_1402e1540)
void FUN_1402e1540(undefined8 param_1,longlong param_2,undefined8 param_3,char param_4,char param_5,
                  char param_6,char param_7)

{
  char cVar1;
  char cVar2;
  char cVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  undefined7 uVar8;
  
  cVar1 = (char)param_3;
  if ((param_2 != 0) && ((byte)(cVar1 - 1U) < 4)) {
    iVar5 = FUN_140478350(param_2);
    uVar8 = (undefined7)((ulonglong)param_3 >> 8);
    iVar6 = iVar5;
    if (cVar1 == '\x01') {
      cVar1 = FUN_140478110(param_2,1);
      cVar2 = FUN_140478110(param_2,1,CONCAT71(uVar8,2));
      cVar3 = FUN_140478110(param_2,1,3);
      cVar4 = FUN_140478110(param_2,1,4);
      if (param_4 == '\0') {
        if (cVar1 != '\0') {
          iVar6 = iVar5 + -1;
        }
      }
      else if (cVar1 == '\0') {
        iVar6 = iVar5 + 1;
      }
      if (param_5 == '\0') {
        if (cVar2 != '\0') {
          iVar6 = iVar6 + -2;
        }
      }
      else if (cVar2 == '\0') {
        iVar6 = iVar6 + 2;
      }
      if (param_6 == '\0') {
        if (cVar3 != '\0') {
          iVar6 = iVar6 + -4;
        }
      }
      else if (cVar3 == '\0') {
        iVar6 = iVar6 + 4;
      }
      if (param_7 == '\0') {
        if (cVar4 != '\0') {
          iVar6 = iVar6 + -8;
        }
      }
      else if (cVar4 == '\0') {
        iVar6 = iVar6 + 8;
      }
    }
    else if (cVar1 == '\x02') {
      uVar7 = CONCAT71(uVar8,1);
      cVar1 = FUN_140478110(param_2,2,uVar7);
      uVar8 = (undefined7)((ulonglong)uVar7 >> 8);
      cVar2 = FUN_140478110(param_2,2);
      cVar3 = FUN_140478110(param_2,2,CONCAT71(uVar8,3));
      cVar4 = FUN_140478110(param_2,2,4);
      if (param_4 == '\0') {
        if (cVar1 != '\0') {
          iVar6 = iVar5 + -0x10;
        }
      }
      else if (cVar1 == '\0') {
        iVar6 = iVar5 + 0x10;
      }
      if (param_5 == '\0') {
        if (cVar2 != '\0') {
          iVar6 = iVar6 + -0x20;
        }
      }
      else if (cVar2 == '\0') {
        iVar6 = iVar6 + 0x20;
      }
      if (param_6 == '\0') {
        if (cVar3 != '\0') {
          iVar6 = iVar6 + -0x40;
        }
      }
      else if (cVar3 == '\0') {
        iVar6 = iVar6 + 0x40;
      }
      if (param_7 == '\0') {
        if (cVar4 != '\0') {
          iVar6 = iVar6 + -0x80;
        }
      }
      else if (cVar4 == '\0') {
        iVar6 = iVar6 + 0x80;
      }
    }
    else if (cVar1 == '\x03') {
      uVar7 = CONCAT71(uVar8,1);
      cVar1 = FUN_140478110(param_2,3,uVar7);
      uVar7 = CONCAT71((int7)((ulonglong)uVar7 >> 8),2);
      cVar2 = FUN_140478110(param_2,3,uVar7);
      uVar8 = (undefined7)((ulonglong)uVar7 >> 8);
      cVar3 = FUN_140478110(param_2,3);
      cVar4 = FUN_140478110(param_2,3,CONCAT71(uVar8,4));
      if (param_4 == '\0') {
        if (cVar1 != '\0') {
          iVar6 = iVar5 + -0x100;
        }
      }
      else if (cVar1 == '\0') {
        iVar6 = iVar5 + 0x100;
      }
      if (param_5 == '\0') {
        if (cVar2 != '\0') {
          iVar6 = iVar6 + -0x200;
        }
      }
      else if (cVar2 == '\0') {
        iVar6 = iVar6 + 0x200;
      }
      if (param_6 == '\0') {
        if (cVar3 != '\0') {
          iVar6 = iVar6 + -0x400;
        }
      }
      else if (cVar3 == '\0') {
        iVar6 = iVar6 + 0x400;
      }
      if (param_7 == '\0') {
        if (cVar4 != '\0') {
          iVar6 = iVar6 + -0x800;
        }
      }
      else if (cVar4 == '\0') {
        iVar6 = iVar6 + 0x800;
      }
    }
    else {
      if (cVar1 != '\x04') {
        return;
      }
      cVar1 = FUN_140478110(param_2,4,1);
      cVar2 = FUN_140478110(param_2,4,2);
      cVar3 = FUN_140478110(param_2,4,3);
      cVar4 = FUN_140478110(param_2,4);
      if (param_4 == '\0') {
        if (cVar1 != '\0') {
          iVar6 = iVar5 + -0x1000;
        }
      }
      else if (cVar1 == '\0') {
        iVar6 = iVar5 + 0x1000;
      }
      if (param_5 == '\0') {
        if (cVar2 != '\0') {
          iVar6 = iVar6 + -0x2000;
        }
      }
      else if (cVar2 == '\0') {
        iVar6 = iVar6 + 0x2000;
      }
      if (param_6 == '\0') {
        if (cVar3 != '\0') {
          iVar6 = iVar6 + -0x4000;
        }
      }
      else if (cVar3 == '\0') {
        iVar6 = iVar6 + 0x4000;
      }
      if (param_7 == '\0') {
        if (cVar4 != '\0') {
          iVar6 = iVar6 + -0x8000;
        }
      }
      else if (cVar4 == '\0') {
        iVar6 = iVar6 + 0x8000;
      }
    }
    if (iVar6 != iVar5) {
      FUN_140478380(param_2,iVar6);
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e1b80  @1402e1b80  [medium:callgraph-r2]  (orig: FUN_1402e1b80)
ulonglong FUN_1402e1b80(longlong param_1,undefined1 param_2,undefined1 param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  ulonglong uVar3;
  
  uVar1 = FUN_140475350(*(undefined8 *)(param_1 + 0x98));
  uVar2 = FUN_1404754d0(*(undefined8 *)(param_1 + 0x98),param_2,param_3);
  if ((uVar2 < param_4) && (uVar2 < uVar1)) {
    uVar3 = (ulonglong)((param_4 - uVar2) * 100) / (ulonglong)(uVar1 - uVar2);
  }
  else {
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CMsgTrainingVitality::helper_1402e2a70  @1402e2a70  [medium:callgraph-r2]  (orig: FUN_1402e2a70)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e2a70(longlong param_1,longlong param_2,char param_3,undefined1 param_4,uint param_5,
                  undefined4 param_6)

{
  char cVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  undefined1 auStack_498 [32];
  uint local_478;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (((param_2 != 0) && (param_3 != '\0')) && (*(longlong *)(param_1 + 0x98) != 0)) {
    uVar2 = FUN_140475350(*(longlong *)(param_1 + 0x98),param_3,param_4);
    uVar3 = FUN_1404754d0(*(undefined8 *)(param_1 + 0x98),param_3,param_4);
    if ((uVar3 < param_5) && (uVar3 < uVar2)) {
      uVar4 = (param_5 - uVar3) * 100;
      local_478 = uVar4 / (uVar2 - uVar3);
      if (0x59 < local_478) {
        FUN_14047dd50(local_468,(ulonglong)uVar4 % (ulonglong)(uVar2 - uVar3));
        uVar5 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x18))();
        cVar1 = FUN_14047de10(local_468,param_3,param_6,uVar5);
        if (cVar1 != '\0') {
          plVar6 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x88));
          (**(code **)(*plVar6 + 0x68))(plVar6,local_468,0xffffffff);
        }
        FUN_14047dda0(local_468);
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e2ba0  @1402e2ba0  [medium:callgraph-r0]  (orig: FUN_1402e2ba0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e2ba0(longlong param_1,longlong *param_2)

{
  ulonglong uVar1;
  byte bVar2;
  char cVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  undefined8 uVar7;
  undefined1 auStack_488 [32];
  byte local_468;
  byte local_467;
  undefined8 local_460;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  if (param_2 != (longlong *)0x0) {
    local_460 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_488;
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    FUN_1400a7e10(uVar7,&local_468,1);
    uVar4 = (**(code **)(*param_2 + 0x108))(param_2);
    if (uVar4 == local_467) {
      bVar2 = (**(code **)(param_2[2] + 0x70))();
      if (bVar2 < local_468) {
        return;
      }
    }
    else {
      uVar4 = (**(code **)(*param_2 + 0x108))(param_2);
      if (uVar4 < local_467) {
        return;
      }
    }
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    uVar4 = FUN_14008aea0(uVar7);
    uVar5 = FUN_140166bf0(param_2);
    uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    iVar6 = FUN_14008af80(uVar7);
    if (((uVar5 < uVar4) &&
        (uVar1 = (ulonglong)((uVar4 - uVar5) * iVar6 + -1 + uVar4) / (ulonglong)uVar4,
        0 < (int)uVar1)) && (cVar3 = FUN_1402e1210(param_1,param_2,uVar1), cVar3 != '\0')) {
      FUN_140166c00(param_2,uVar4,1);
      FUN_1403b6340(local_458);
      cVar3 = FUN_1403b6400(local_458,4,uVar4);
      if (cVar3 == '\0') {
        FUN_1403b6390(local_458);
      }
      else {
        (**(code **)(param_2[2] + 0x350))(param_2 + 2,local_458);
        FUN_1403b6390(local_458);
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e2d20  @1402e2d20  [medium:callgraph-r0]  (orig: FUN_1402e2d20)
void FUN_1402e2d20(longlong param_1,longlong *param_2)

{
  byte bVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  undefined8 uVar5;
  byte local_res10;
  byte local_res11;
  
  if (param_2 != (longlong *)0x0) {
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    FUN_1400a7e10(uVar5,&local_res10,1);
    uVar3 = (**(code **)(*param_2 + 0x108))(param_2);
    if (uVar3 == local_res11) {
      bVar1 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
      if (bVar1 < local_res10) {
        return;
      }
    }
    else {
      uVar3 = (**(code **)(*param_2 + 0x108))(param_2);
      if (uVar3 < local_res11) {
        return;
      }
    }
    uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    uVar3 = FUN_14008aea0(uVar5);
    iVar4 = FUN_140166bf0(param_2);
    if (iVar4 + 200U <= uVar3) {
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
      iVar4 = FUN_14008af90(uVar5);
      if ((iVar4 != 0) && (cVar2 = FUN_1402e1210(param_1,param_2,iVar4), cVar2 != '\0')) {
        FUN_140166c40(param_2,200,1);
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e3370  @1402e3370  [medium:callgraph-r1]  (orig: FUN_1402e3370)
/* WARNING: Restarted to delay deadcode elimination for space: register */

longlong *
FUN_1402e3370(longlong param_1,longlong *param_2,longlong param_3,undefined1 param_4,byte param_5,
             int *param_6,int *param_7,int *param_8,int *param_9)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined8 uVar9;
  byte local_78;
  byte local_58;
  
  if ((param_3 != 0) && (param_2 != (longlong *)0x0)) {
    bVar1 = 0;
    local_58 = 0;
    if ((param_5 & 1) != 0) {
      bVar1 = FUN_140477aa0(param_3,param_4,1);
      iVar4 = FUN_140477350(param_3,param_4,1);
      *param_6 = iVar4;
    }
    if ((param_5 & 2) == 0) {
      local_78 = 0;
    }
    else {
      local_78 = FUN_140477aa0(param_3,param_4,2);
      iVar4 = FUN_140477350(param_3,param_4,2);
      *param_7 = iVar4;
    }
    if ((param_5 & 4) == 0) {
      bVar2 = 0;
    }
    else {
      bVar2 = FUN_140477aa0(param_3,param_4,3);
      iVar4 = FUN_140477350(param_3,param_4,3);
      *param_8 = iVar4;
    }
    if ((param_5 & 8) != 0) {
      local_58 = FUN_140477aa0(param_3,param_4,4);
      iVar4 = FUN_140477350(param_3,param_4,4);
      *param_9 = iVar4;
    }
    if ((param_5 & 1) == 0) {
      uVar5 = FUN_140477350(param_3,param_4,1);
      for (iVar4 = 0; iVar4 < 100; iVar4 = iVar4 + 1) {
        bVar1 = FUN_1404750e0(*(undefined8 *)(param_1 + 0x98),param_4);
        if ((((bVar1 != local_78) && (bVar1 != bVar2)) && (bVar1 != local_58)) && (bVar1 != 0))
        goto LAB_1402e35d9;
      }
      bVar1 = FUN_140477aa0(param_3,param_4,1);
      if (bVar1 == 0) {
        for (iVar4 = 1;
            (iVar4 < 0xe &&
            (((bVar1 = (byte)iVar4, bVar1 == local_78 || (bVar1 == bVar2)) ||
             ((bVar1 == local_58 || (bVar1 == 0)))))); iVar4 = iVar4 + 1) {
        }
      }
LAB_1402e35d9:
      iVar4 = FUN_1402e1140(param_1,param_4,bVar1);
      *param_6 = (uint)bVar1 * 10000 + iVar4;
      FUN_1402e2a70(param_1,param_2,param_4,bVar1);
      uVar6 = FUN_1402e1b80(param_1,param_4,bVar1,iVar4);
      if (*(uint *)(param_1 + 0xc0) <= uVar6) {
        FUN_1402e1b80(param_1,param_4,uVar5 / 10000 & 0xff,uVar5 % 10000);
        bVar3 = *(byte *)((longlong)param_2 + 0xeee);
        (**(code **)(param_2[2] + 0x18))();
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        tq::GmLogSave("TrainingVitalityScore",
                      "user_id[%lu], pro[%lu], user_name[%s], fate_no[%d], lock_num[%d], type_pre[%u], value_pre[%u], type_new[%u], value_new[%u]"
                      ,uVar7 & 0xffffffff,(ulonglong)bVar3);
      }
    }
    if ((param_5 & 2) == 0) {
      uVar5 = FUN_140477350(param_3,param_4,2);
      for (iVar4 = 0; iVar4 < 100; iVar4 = iVar4 + 1) {
        local_78 = FUN_1404750e0(*(undefined8 *)(param_1 + 0x98),param_4);
        if (((local_78 != bVar1) && (local_78 != bVar2)) &&
           ((local_78 != local_58 && (local_78 != 0)))) goto LAB_1402e37eb;
      }
      local_78 = FUN_140477aa0(param_3,param_4,2);
      if (local_78 == 0) {
        for (iVar4 = 1; iVar4 < 0xe; iVar4 = iVar4 + 1) {
          local_78 = (byte)iVar4;
          if ((((local_78 != bVar1) && (local_78 != bVar2)) && (local_78 != local_58)) &&
             (local_78 != 0)) break;
        }
      }
LAB_1402e37eb:
      iVar4 = FUN_1402e1140(param_1,param_4,local_78);
      *param_7 = (uint)local_78 * 10000 + iVar4;
      FUN_1402e2a70(param_1,param_2,param_4,local_78);
      uVar6 = FUN_1402e1b80(param_1,param_4,local_78,iVar4);
      if (*(uint *)(param_1 + 0xc0) <= uVar6) {
        FUN_1402e1b80(param_1,param_4,uVar5 / 10000 & 0xff,uVar5 % 10000);
        bVar3 = *(byte *)((longlong)param_2 + 0xeee);
        (**(code **)(param_2[2] + 0x18))();
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        tq::GmLogSave("TrainingVitalityScore",
                      "user_id[%lu], pro[%lu], user_name[%s], fate_no[%d], lock_num[%d], type_pre[%u], value_pre[%u], type_new[%u], value_new[%u]"
                      ,uVar7 & 0xffffffff,(ulonglong)bVar3);
      }
    }
    if ((param_5 & 4) == 0) {
      uVar5 = FUN_140477350(param_3,param_4,3);
      for (iVar4 = 0; iVar4 < 100; iVar4 = iVar4 + 1) {
        bVar2 = FUN_1404750e0(*(undefined8 *)(param_1 + 0x98),param_4);
        if (((bVar2 != bVar1) && (bVar2 != local_78)) && ((bVar2 != local_58 && (bVar2 != 0))))
        goto LAB_1402e3a07;
      }
      bVar2 = FUN_140477aa0(param_3,param_4,3);
      if (bVar2 == 0) {
        for (iVar4 = 1;
            (iVar4 < 0xe &&
            (((bVar2 = (byte)iVar4, bVar2 == bVar1 || (bVar2 == local_78)) ||
             ((bVar2 == local_58 || (bVar2 == 0)))))); iVar4 = iVar4 + 1) {
        }
      }
LAB_1402e3a07:
      iVar4 = FUN_1402e1140(param_1,param_4,bVar2);
      *param_8 = (uint)bVar2 * 10000 + iVar4;
      FUN_1402e2a70(param_1,param_2,param_4,bVar2);
      uVar6 = FUN_1402e1b80(param_1,param_4,bVar2,iVar4);
      if (*(uint *)(param_1 + 0xc0) <= uVar6) {
        FUN_1402e1b80(param_1,param_4,uVar5 / 10000 & 0xff,uVar5 % 10000);
        bVar3 = *(byte *)((longlong)param_2 + 0xeee);
        (**(code **)(param_2[2] + 0x18))();
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        tq::GmLogSave("TrainingVitalityScore",
                      "user_id[%lu], pro[%lu], user_name[%s], fate_no[%d], lock_num[%d], type_pre[%u], value_pre[%u], type_new[%u], value_new[%u]"
                      ,uVar7 & 0xffffffff,(ulonglong)bVar3);
      }
    }
    if ((param_5 & 8) == 0) {
      uVar5 = FUN_140477350(param_3,param_4,4);
      for (iVar4 = 0; iVar4 < 100; iVar4 = iVar4 + 1) {
        bVar3 = FUN_1404750e0(*(undefined8 *)(param_1 + 0x98),param_4);
        if ((((bVar3 != bVar1) && (bVar3 != local_78)) && (bVar3 != bVar2)) && (bVar3 != 0))
        goto LAB_1402e3c19;
      }
      bVar3 = FUN_140477aa0(param_3,param_4,4);
      if (bVar3 == 0) {
        for (iVar4 = 1;
            (iVar4 < 0xe &&
            (((bVar3 = (byte)iVar4, bVar3 == bVar1 || (bVar3 == local_78)) ||
             ((bVar3 == bVar2 || (bVar3 == 0)))))); iVar4 = iVar4 + 1) {
        }
      }
LAB_1402e3c19:
      iVar4 = FUN_1402e1140(param_1,param_4,bVar3);
      *param_9 = (uint)bVar3 * 10000 + iVar4;
      FUN_1402e2a70(param_1,param_2,param_4,bVar3);
      uVar6 = FUN_1402e1b80(param_1,param_4,bVar3,iVar4);
      if (*(uint *)(param_1 + 0xc0) <= uVar6) {
        FUN_1402e1b80(param_1,param_4,uVar5 / 10000 & 0xff,uVar5 % 10000);
        bVar1 = *(byte *)((longlong)param_2 + 0xeee);
        (**(code **)(param_2[2] + 0x18))();
        uVar7 = (**(code **)(*param_2 + 8))(param_2);
        tq::GmLogSave("TrainingVitalityScore",
                      "user_id[%lu], pro[%lu], user_name[%s], fate_no[%d], lock_num[%d], type_pre[%u], value_pre[%u], type_new[%u], value_new[%u]"
                      ,uVar7 & 0xffffffff,(ulonglong)bVar1);
      }
    }
    lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
    if (*(longlong *)(lVar8 + 0x1f8) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pActivityMgr",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                        );
      uVar9 = 0;
    }
    else {
      uVar9 = *(undefined8 *)(lVar8 + 0x1f8);
    }
    param_2 = (longlong *)FUN_140261810(uVar9,param_2,8);
  }
  return param_2;
}

// ==== CMsgTrainingVitality::helper_1402e6810  @1402e6810  [medium:callgraph-r0]  (orig: FUN_1402e6810)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1402e6810(longlong param_1,longlong param_2,longlong *param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong lVar3;
  char cVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 *puVar8;
  longlong *plVar9;
  undefined8 *puVar10;
  longlong lVar11;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  longlong local_4a8;
  undefined8 local_4a0;
  longlong *local_498;
  longlong local_490;
  longlong local_488;
  undefined8 *local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_478 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
    if (param_3 != (longlong *)0x0) {
      uVar5 = (**(code **)(*param_3 + 8))(param_3);
      puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
      cVar4 = *(char *)((longlong)puVar10 + 0x29);
      puVar2 = *(undefined8 **)(param_1 + 0x38);
      while (cVar4 == '\0') {
        if (*(uint *)(puVar10 + 3) < uVar5) {
          puVar8 = (undefined8 *)puVar10[2];
          puVar10 = puVar2;
        }
        else {
          puVar8 = (undefined8 *)*puVar10;
        }
        puVar2 = puVar10;
        puVar10 = puVar8;
        cVar4 = *(char *)((longlong)puVar8 + 0x29);
      }
      local_480 = puVar2;
      local_488 = *(longlong *)(param_1 + 8);
      puVar10 = *(undefined8 **)(param_1 + 0x38);
      if (*(longlong *)(param_1 + 8) == 0) {
        _invalid_parameter_noinfo();
      }
      if ((puVar2 == puVar10) || (uVar5 < *(uint *)(puVar2 + 3))) {
        local_4a0 = *(undefined8 *)(param_1 + 0x38);
        local_4a8 = *(longlong *)(param_1 + 8);
        plVar9 = &local_4a8;
      }
      else {
        plVar9 = &local_488;
      }
      plVar1 = (longlong *)*plVar9;
      local_498 = plVar1;
      local_490 = plVar9[1];
      lVar11 = *(longlong *)(param_1 + 0x38);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
        _invalid_parameter_noinfo();
      }
      lVar3 = local_490;
      if (local_490 == lVar11) {
        FUN_140477070(local_468);
        uVar6 = FUN_140166bf0(param_3);
        uVar7 = (**(code **)(*param_3 + 8))(param_3);
        local_4b8 = 0;
        cVar4 = FUN_140477130(local_468,0,uVar7,uVar6);
        if (cVar4 == '\0') {
          FUN_1404770c0(local_468);
        }
        else {
          (**(code **)(*(longlong *)(param_2 + 0x10) + 0x350))
                    ((longlong *)(param_2 + 0x10),local_468);
          FUN_1404770c0(local_468);
        }
      }
      else {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar11 = 0;
        }
        else {
          lVar11 = *plVar1;
        }
        if (lVar3 == *(longlong *)(lVar11 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar11 = *(longlong *)(lVar3 + 0x20);
        if (lVar11 != 0) {
          FUN_140478d30(lVar11,0,param_2,param_3);
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e8f60  @1402e8f60  [medium:callgraph-r0]  (orig: FUN_1402e8f60)
void FUN_1402e8f60(longlong param_1,longlong *param_2,char param_3)

{
  longlong *plVar1;
  undefined4 uVar2;
  byte bVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined8 uVar7;
  longlong lVar8;
  longlong lVar9;
  byte local_res20;
  byte local_res21;
  ushort local_res22;
  uint in_stack_ffffffffffffff48;
  undefined4 *puVar10;
  undefined4 uVar12;
  undefined4 *puVar11;
  undefined4 uVar13;
  undefined4 uVar15;
  undefined4 *puVar14;
  undefined4 uVar16;
  undefined4 uVar18;
  uint *puVar17;
  undefined4 uVar19;
  undefined4 local_88 [2];
  longlong local_80;
  undefined4 local_78;
  undefined4 local_74;
  uint local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60 [2];
  int local_58;
  undefined4 uStack_54;
  longlong local_50;
  undefined8 local_48;
  longlong *local_40 [3];
  
  local_48 = 0xfffffffffffffffe;
  if (((param_2 != (longlong *)0x0) && (*(longlong *)(param_1 + 0x98) != 0)) &&
     ((byte)(param_3 - 1U) < 4)) {
    iVar5 = (**(code **)(*param_2 + 8))(param_2);
    local_80 = CONCAT44(local_80._4_4_,iVar5);
    if (iVar5 != 0) {
      uVar7 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
      FUN_1400a7e10(uVar7,&local_res20,param_3);
      uVar6 = (**(code **)(*param_2 + 0x108))(param_2);
      if (uVar6 == local_res21) {
        bVar3 = (**(code **)(param_2[2] + 0x70))();
        if (bVar3 < local_res20) {
          return;
        }
      }
      else {
        uVar6 = (**(code **)(*param_2 + 0x108))(param_2);
        if (uVar6 < local_res21) {
          return;
        }
      }
      FUN_1402e58a0(param_1 + 8,&local_58,&local_80);
      local_80 = *(longlong *)(param_1 + 0x38);
      local_40[0] = *(longlong **)(param_1 + 8);
      plVar1 = (longlong *)CONCAT44(uStack_54,local_58);
      if ((plVar1 == (longlong *)0x0) || (plVar1 != local_40[0])) {
        _invalid_parameter_noinfo();
      }
      if (local_50 == local_80) {
        if ((param_3 == '\x01') &&
           (lVar9 = FUN_140478740(*(undefined4 *)(param_1 + 0x88),param_2,
                                  *(undefined8 *)(param_1 + 0x98)), lVar9 != 0)) {
          local_88[0] = 0;
          local_78 = 0;
          local_70 = 0;
          local_64 = 0;
          puVar17 = &local_70;
          puVar14 = &local_78;
          puVar11 = local_88;
          FUN_1402e3370(param_1,param_2,lVar9,1,in_stack_ffffffffffffff48 & 0xffffff00,puVar11,
                        puVar14,puVar17,&local_64);
          uVar2 = local_64;
          uVar6 = local_70;
          uVar13 = (undefined4)((ulonglong)puVar11 >> 0x20);
          uVar16 = (undefined4)((ulonglong)puVar14 >> 0x20);
          uVar19 = (undefined4)((ulonglong)puVar17 >> 0x20);
          cVar4 = FUN_140477cc0(lVar9,local_88[0],local_78,local_70,local_64);
          if (cVar4 == '\0') {
            FUN_1404795e0(lVar9);
          }
          else {
            local_58 = iVar5;
            local_50 = lVar9;
            FUN_1402e5330(param_1 + 8,local_40,&local_58);
            FUN_1402e1420(param_1,param_2,lVar9,1,local_88[0],CONCAT44(uVar13,local_78),
                          CONCAT44(uVar16,uVar6),CONCAT44(uVar19,uVar2));
            FUN_1402e6f70(param_1,param_2,1);
          }
        }
      }
      else if (param_3 != '\x01') {
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar9 = 0;
        }
        else {
          lVar9 = *plVar1;
        }
        if (local_50 == *(longlong *)(lVar9 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        lVar9 = *(longlong *)(local_50 + 0x20);
        if (lVar9 != 0) {
          local_80 = lVar9;
          cVar4 = FUN_140477c00(lVar9,param_3 + -1);
          if (((cVar4 != '\0') && (cVar4 = FUN_140477c00(lVar9,param_3), cVar4 == '\0')) &&
             (lVar8 = FUN_1402e69e0(param_1,param_2,param_3 + -1),
             (longlong)(ulonglong)local_res22 <= lVar8)) {
            local_68 = 0;
            local_6c = 0;
            local_60[0] = 0;
            local_74 = 0;
            puVar14 = local_60;
            puVar11 = &local_6c;
            puVar10 = &local_68;
            FUN_1402e3370(param_1,param_2,lVar9,param_3,in_stack_ffffffffffffff48 & 0xffffff00,
                          puVar10,puVar11,puVar14,&local_74);
            uVar16 = local_68;
            uVar12 = (undefined4)((ulonglong)puVar10 >> 0x20);
            uVar15 = (undefined4)((ulonglong)puVar11 >> 0x20);
            uVar18 = (undefined4)((ulonglong)puVar14 >> 0x20);
            FUN_1404775d0(lVar9,param_3,1,local_68);
            uVar13 = local_6c;
            FUN_1404775d0(lVar9,param_3,2,local_6c);
            uVar19 = local_60[0];
            FUN_1404775d0(local_80,param_3,3,local_60[0]);
            uVar2 = local_74;
            FUN_1404775d0(local_80,param_3,4,local_74);
            FUN_1402e1420(param_1,param_2,local_80,param_3,uVar16,CONCAT44(uVar12,uVar13),
                          CONCAT44(uVar15,uVar19),CONCAT44(uVar18,uVar2));
            FUN_1402e6f70(param_1,param_2,param_3);
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1402e9350  @1402e9350  [medium:callgraph-r0]  (orig: FUN_1402e9350)
void FUN_1402e9350(longlong param_1,longlong *param_2,char param_3,byte param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  undefined8 uVar8;
  longlong lVar9;
  byte bVar10;
  longlong lVar11;
  bool bVar12;
  bool bVar13;
  bool bVar14;
  bool bVar15;
  undefined4 *puVar16;
  undefined4 uVar17;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60 [2];
  longlong *local_58;
  longlong local_50;
  undefined8 local_48;
  longlong *local_40;
  
  local_48 = 0xfffffffffffffffe;
  if (((param_2 != (longlong *)0x0) && (*(char *)((longlong)param_2 + 0x51c) != '\0')) &&
     ((byte)(param_3 - 1U) < 4)) {
    local_60[0] = (**(code **)(*param_2 + 8))(param_2);
    FUN_1402e58a0(param_1 + 8,&local_58,local_60);
    lVar11 = *(longlong *)(param_1 + 0x38);
    local_40 = *(longlong **)(param_1 + 8);
    if ((local_58 == (longlong *)0x0) || (local_58 != local_40)) {
      _invalid_parameter_noinfo();
    }
    if (local_50 != lVar11) {
      if (local_58 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar11 = 0;
      }
      else {
        lVar11 = *local_58;
      }
      if (local_50 == *(longlong *)(lVar11 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      lVar11 = *(longlong *)(local_50 + 0x20);
      if ((lVar11 != 0) && (cVar5 = FUN_140477c00(lVar11,param_3), cVar5 != '\0')) {
        bVar12 = (param_4 & 1) != 0;
        bVar13 = (param_4 & 2) != 0;
        bVar10 = bVar12;
        if (bVar13) {
          bVar10 = bVar12 + 1;
        }
        bVar14 = (param_4 & 4) != 0;
        if (bVar14) {
          bVar10 = bVar10 + 1;
        }
        bVar15 = (param_4 & 8) != 0;
        if (bVar15) {
          bVar10 = bVar10 + 1;
        }
        if (bVar10 < 4) {
          uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
          uVar6 = FUN_14008adc0(uVar8,bVar10);
          if (uVar6 == 0) {
            tq::MyLogSave("gmlog/TrainingVitality",
                          "error-->CTrainingVitalityMgr::OnTrainingVitality. GetConsumeStrengthValueByLockNum() is 0!, BelockAmout = %u"
                         );
          }
          else {
            uVar7 = FUN_140166bf0(param_2);
            if (uVar6 <= uVar7) {
              FUN_140166c00(param_2,uVar7 - uVar6,1);
              lVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
              if (*(longlong *)(lVar9 + 0x1c8) == 0) {
                log_InlineLogERROR(&DAT_1406d9c10);
                uVar8 = 0;
              }
              else {
                uVar8 = *(undefined8 *)(lVar9 + 0x1c8);
              }
              FUN_1400d2660(uVar8,param_2,3,uVar6);
              local_68 = 0;
              local_70 = 0;
              local_6c = 0;
              local_64 = 0;
              puVar16 = &local_6c;
              FUN_1402e3370(param_1,param_2,lVar11,param_3,param_4,&local_68,&local_70,puVar16,
                            &local_64);
              uVar3 = local_68;
              uVar17 = (undefined4)((ulonglong)puVar16 >> 0x20);
              if (!bVar12) {
                FUN_1404775d0(lVar11,param_3,1,local_68);
              }
              uVar1 = local_70;
              if (!bVar13) {
                FUN_1404775d0(lVar11,param_3,2,local_70);
              }
              uVar2 = local_6c;
              if (!bVar14) {
                FUN_1404775d0(lVar11,param_3,3,local_6c);
              }
              uVar4 = local_64;
              if (!bVar15) {
                FUN_1404775d0(lVar11,param_3,4,local_64);
              }
              FUN_1402e1540(param_1,lVar11,param_3,bVar12,bVar13,bVar14,bVar15);
              FUN_1402e1420(param_1,param_2,lVar11,param_3,uVar3,uVar1,uVar2,CONCAT44(uVar17,uVar4))
              ;
              FUN_1402e6f70(param_1,param_2,param_3);
            }
          }
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::ctor_or_dtor  @1403b6340  [high:vtable-assign]  (orig: FUN_1403b6340)
undefined8 * FUN_1403b6340(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTrainingVitality::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgTrainingVitality::ctor_or_dtor  @1403b6390  [high:vtable-assign]  (orig: FUN_1403b6390)
void FUN_1403b6390(undefined8 *param_1)

{
  *param_1 = CMsgTrainingVitality::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgTrainingVitality::vfunc_1  @1403b63c0  [high:rtti-vtable]  (orig: FUN_1403b63c0)
bool FUN_1403b63c0(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9e5;
    }
  }
  return false;
}

// ==== CMsgTrainingVitality::ctor_or_dtor  @1403b6470  [high:vtable-assign]  (orig: FUN_1403b6470)
undefined8 * FUN_1403b6470(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTrainingVitality::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTrainingVitality::vfunc_3  @1403b64c0  [high:rtti-vtable]  (orig: FUN_1403b64c0)
void FUN_1403b64c0(longlong param_1)

{
  short sVar1;
  char cVar2;
  longlong lVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar3 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))
                      (*(longlong **)(lVar3 + 0x90),param_1);
    if ((lVar3 != 0) &&
       ((cVar2 = FUN_140167b70(lVar3), cVar2 == '\0' ||
        (*(short *)(*(longlong *)(param_1 + 0x428) + 4) == 1)))) {
      cVar2 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x220))(lVar3 + 0x10);
      if (cVar2 == '\0') {
        pIVar4 = theInstance();
        lVar7 = *(longlong *)(lVar3 + 0x10);
        uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_DIE");
        (**(code **)(lVar7 + 0x358))(lVar3 + 0x10,uVar5);
      }
      else {
        lVar7 = *(longlong *)(param_1 + 0x428);
        sVar1 = *(short *)(lVar7 + 4);
        if (sVar1 == 0) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087ab0(uVar5);
          FUN_1402e8f60(uVar5,lVar3,*(undefined1 *)(lVar7 + 6));
        }
        else if (sVar1 == 1) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          plVar6 = (longlong *)FUN_140087650(uVar5);
          lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,**(undefined4 **)(param_1 + 0x428));
          if (lVar7 != 0) {
            uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            uVar5 = FUN_140087ab0(uVar5);
            FUN_1402e6810(uVar5,lVar3,lVar7);
          }
        }
        else if (sVar1 == 2) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087ab0(uVar5);
          FUN_1402e9350(uVar5,lVar3,*(undefined1 *)(lVar7 + 6),*(undefined1 *)(lVar7 + 7));
        }
        else if (sVar1 == 3) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087ab0(uVar5);
          FUN_1402e2ba0(uVar5,lVar3);
        }
        else if (sVar1 == 6) {
          uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          uVar5 = FUN_140087ab0(uVar5);
          FUN_1402e2d20(uVar5,lVar3);
        }
      }
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_1404738b0  @1404738b0  [medium:callgraph-r3]  (orig: FUN_1404738b0)
undefined1 FUN_1404738b0(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  bool bVar3;
  undefined8 *puVar4;
  longlong lVar5;
  undefined1 uVar6;
  ulong uVar7;
  int iVar8;
  uint uVar9;
  undefined8 *puVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 *puVar14;
  longlong lVar15;
  uint uVar16;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong local_30;
  
  puVar14 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar14 + 0x51);
  puVar4 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar14 + 3) < param_2) {
      puVar10 = (undefined8 *)puVar14[2];
      puVar14 = puVar4;
    }
    else {
      puVar10 = (undefined8 *)*puVar14;
    }
    puVar4 = puVar14;
    puVar14 = puVar10;
    cVar1 = *(char *)((longlong)puVar10 + 0x51);
  }
  puVar14 = *(undefined8 **)(param_1 + 0x40);
  local_50 = puVar4;
  local_58 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar14) || (param_2 < *(byte *)(puVar4 + 3))) {
    plVar13 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x40);
    local_48 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar13 = &local_58;
  }
  plVar2 = (longlong *)*plVar13;
  lVar15 = *(longlong *)(param_1 + 0x40);
  local_38 = plVar2;
  local_30 = plVar13[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_30;
  if (local_30 != lVar15) {
    uVar6 = 0;
    uVar16 = 0;
    bVar3 = true;
    uVar7 = tq::TimeGet(0);
    iVar8 = rand();
    srand(iVar8 + uVar7);
    iVar8 = tq::RandGet(100000);
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar2;
    }
    if (lVar5 == *(longlong *)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar13 = *(longlong **)(lVar5 + 0x38);
    if (*(longlong **)(lVar5 + 0x40) < plVar13) {
      _invalid_parameter_noinfo();
    }
    plVar2 = *(longlong **)(lVar5 + 0x20);
    while( true ) {
      plVar12 = *(longlong **)(lVar5 + 0x40);
      if (plVar12 < *(longlong **)(lVar5 + 0x38)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(lVar5 + 0x20))) {
        _invalid_parameter_noinfo();
      }
      if (plVar13 == plVar12) break;
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar15 = 0;
      }
      else {
        lVar15 = *plVar2;
      }
      if (*(longlong **)(lVar15 + 0x20) <= plVar13) {
        _invalid_parameter_noinfo();
      }
      plVar12 = (longlong *)*plVar13;
      if (plVar12 != (longlong *)0x0) {
        plVar11 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,2);
        uVar9 = (**(code **)(*plVar11 + 0x50))(plVar11);
        if (iVar8 + 1U <= uVar9) {
          if (bVar3) {
            plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,1);
            uVar6 = (**(code **)(*plVar12 + 0x20))(plVar12);
            bVar3 = false;
            uVar16 = uVar9;
          }
          else if (uVar9 < uVar16) {
            plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,1);
            uVar6 = (**(code **)(*plVar12 + 0x20))(plVar12);
            uVar16 = uVar9;
          }
        }
      }
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar15 = 0;
      }
      else {
        lVar15 = *plVar2;
      }
      if (*(longlong **)(lVar15 + 0x20) <= plVar13) {
        _invalid_parameter_noinfo();
      }
      plVar13 = plVar13 + 1;
    }
    return uVar6;
  }
  return 0;
}

// ==== CMsgTrainingVitality::helper_1404750e0  @1404750e0  [medium:callgraph-r2]  (orig: FUN_1404750e0)
ulonglong FUN_1404750e0(longlong param_1,byte param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  byte bVar5;
  ulong uVar6;
  int iVar7;
  uint uVar8;
  undefined8 *extraout_RAX;
  undefined8 *puVar9;
  undefined8 *extraout_RAX_00;
  longlong *plVar10;
  undefined8 *extraout_RAX_01;
  longlong *plVar11;
  ulonglong uVar12;
  undefined8 *puVar13;
  undefined8 *puVar14;
  longlong lVar15;
  uint uVar16;
  longlong local_48;
  undefined8 *local_40;
  longlong local_38;
  undefined8 local_30;
  longlong *local_28;
  undefined8 *local_20;
  
  uVar8 = (uint)param_2;
  uVar6 = tq::TimeGet(0);
  iVar7 = rand();
  srand(iVar7 + uVar8 + uVar6);
  iVar7 = 0;
  if (uVar8 == 1) {
    iVar7 = *(int *)(param_1 + 0x50);
  }
  else if (uVar8 == 2) {
    iVar7 = *(int *)(param_1 + 0x54);
  }
  else if (uVar8 == 3) {
    iVar7 = *(int *)(param_1 + 0x58);
  }
  else if (uVar8 == 4) {
    iVar7 = *(int *)(param_1 + 0x5c);
  }
  uVar8 = tq::RandGet(iVar7);
  uVar16 = 0;
  puVar14 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar14 + 0x61);
  puVar9 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar14 + 3) < param_2) {
      puVar13 = (undefined8 *)puVar14[2];
      puVar14 = puVar9;
    }
    else {
      puVar13 = (undefined8 *)*puVar14;
    }
    puVar9 = puVar14;
    puVar14 = puVar13;
    cVar1 = *(char *)((longlong)puVar13 + 0x61);
  }
  puVar14 = *(undefined8 **)(param_1 + 0x40);
  local_40 = puVar9;
  local_48 = *(longlong *)(param_1 + 0x10);
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar9 == puVar14) || (param_2 < *(byte *)(puVar9 + 3))) {
    plVar11 = &local_38;
    local_30 = *(undefined8 *)(param_1 + 0x40);
    local_38 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar11 = &local_48;
  }
  plVar2 = (longlong *)*plVar11;
  puVar14 = *(undefined8 **)(param_1 + 0x40);
  local_28 = plVar2;
  puVar9 = (undefined8 *)plVar11[1];
  local_20 = puVar9;
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
    puVar9 = extraout_RAX;
  }
  puVar13 = local_20;
  if (local_20 != puVar14) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar2;
    }
    if (puVar13 == *(undefined8 **)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar9 = (undefined8 *)puVar13[10];
    plVar11 = (longlong *)puVar13[4];
    puVar14 = (undefined8 *)*puVar9;
    while( true ) {
      puVar3 = (undefined8 *)puVar13[10];
      if ((plVar11 == (longlong *)0x0) || (plVar11 != (longlong *)puVar13[4])) {
        _invalid_parameter_noinfo();
        puVar9 = extraout_RAX_00;
      }
      if (puVar14 == puVar3) break;
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar15 = 0;
      }
      else {
        lVar15 = *plVar11;
      }
      if (puVar14 == *(undefined8 **)(lVar15 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar2 = (longlong *)puVar14[4];
      if (plVar2 != (longlong *)0x0) {
        plVar10 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,3);
        bVar5 = (**(code **)(*plVar10 + 0x20))(plVar10);
        uVar16 = uVar16 + bVar5;
        if (uVar8 < uVar16) {
          plVar11 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
          uVar12 = (**(code **)(*plVar11 + 0x20))(plVar11);
          return uVar12;
        }
      }
      if (plVar11 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      if (*(char *)((longlong)puVar14 + 0x29) == '\0') {
        puVar3 = (undefined8 *)puVar14[2];
        if (*(char *)((longlong)puVar3 + 0x29) == '\0') {
          cVar1 = *(char *)((longlong)*puVar3 + 0x29);
          puVar9 = (undefined8 *)*puVar3;
          while (puVar14 = puVar3, cVar1 == '\0') {
            cVar1 = *(char *)((longlong)*puVar9 + 0x29);
            puVar3 = puVar9;
            puVar9 = (undefined8 *)*puVar9;
          }
        }
        else {
          cVar1 = *(char *)((longlong)puVar14[1] + 0x29);
          puVar4 = (undefined8 *)puVar14[1];
          puVar3 = puVar14;
          while ((puVar9 = puVar4, puVar14 = puVar9, cVar1 == '\0' &&
                 (puVar3 == (undefined8 *)puVar9[2]))) {
            cVar1 = *(char *)((longlong)puVar9[1] + 0x29);
            puVar4 = (undefined8 *)puVar9[1];
            puVar3 = puVar9;
          }
        }
      }
      else {
        _invalid_parameter_noinfo();
        puVar9 = extraout_RAX_01;
      }
    }
  }
  return (ulonglong)puVar9 & 0xffffffffffffff00;
}

// ==== CMsgTrainingVitality::helper_1404754d0  @1404754d0  [medium:callgraph-r3]  (orig: FUN_1404754d0)
undefined8 FUN_1404754d0(longlong param_1,byte param_2,undefined1 param_3)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  longlong *plVar6;
  undefined8 uVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong lVar10;
  undefined1 local_res18 [8];
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x40))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x61);
  puVar3 = *(undefined8 **)(param_1 + 0x40);
  while (cVar1 == '\0') {
    if (*(byte *)(puVar8 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar5 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x61);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x40);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x10);
  local_res18[0] = param_3;
  if (*(longlong *)(param_1 + 0x10) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(byte *)(puVar3 + 3))) {
    plVar6 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x40);
    local_28 = *(longlong *)(param_1 + 0x10);
  }
  else {
    plVar6 = &local_38;
  }
  plVar2 = (longlong *)*plVar6;
  lVar9 = *(longlong *)(param_1 + 0x40);
  local_18 = plVar2;
  local_10 = plVar6[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar9) {
    lVar9 = 0;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = lVar9;
    }
    else {
      lVar10 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140156ce0((undefined8 *)(lVar4 + 0x20),&local_18,local_res18);
    plVar6 = local_18;
    lVar10 = *(longlong *)(lVar4 + 0x50);
    if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(lVar4 + 0x20))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = local_10;
    if (local_10 != lVar10) {
      if (plVar6 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        lVar9 = *plVar6;
      }
      if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      plVar6 = *(longlong **)(lVar4 + 0x20);
      if (plVar6 != (longlong *)0x0) {
        plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,4);
        uVar7 = (**(code **)(*plVar6 + 0x50))(plVar6);
        return uVar7;
      }
    }
  }
  return 0;
}

// ==== CMsgTrainingVitality::helper_140477130  @140477130  [medium:callgraph-r1]  (orig: FUN_140477130)
ulonglong FUN_140477130(longlong param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5)

{
  longlong lVar1;
  ulonglong in_RAX;
  ulonglong uVar2;
  
  if (*(longlong *)(param_1 + 0x428) == 0) {
    uVar2 = in_RAX & 0xffffffffffffff00;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x9e6;
    *(undefined4 *)(param_1 + 0xc) = 0x12;
    **(undefined2 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 2) = param_3;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 6) = param_4;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 10) = param_5;
    lVar1 = *(longlong *)(param_1 + 0x428);
    *(undefined4 *)(lVar1 + 0xe) = 0;
    uVar2 = CONCAT71((int7)((ulonglong)lVar1 >> 8),1);
  }
  return uVar2;
}

// ==== CMsgTrainingVitality::helper_1404771d0  @1404771d0  [medium:callgraph-r2]  (orig: FUN_1404771d0)
ulonglong FUN_1404771d0(longlong param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6)

{
  ulonglong uVar1;
  int *piVar2;
  longlong lVar3;
  
  uVar1 = (longlong)*(int *)(param_1 + 0xc) + 0x11;
  if ((uVar1 < 0x3fc) && (lVar3 = *(longlong *)(param_1 + 0x428), lVar3 != 0)) {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x11;
    *(undefined1 *)((ulonglong)*(uint *)(lVar3 + 0xe) * 0x11 + 0x12 + lVar3) = param_2;
    *(undefined4 *)
     ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0xe) * 0x11 + 0x13 +
     *(longlong *)(param_1 + 0x428)) = param_3;
    *(undefined4 *)
     ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0xe) * 0x11 + 0x17 +
     *(longlong *)(param_1 + 0x428)) = param_4;
    *(undefined4 *)
     ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0xe) * 0x11 + 0x1b +
     *(longlong *)(param_1 + 0x428)) = param_5;
    *(undefined4 *)
     ((ulonglong)*(uint *)(*(longlong *)(param_1 + 0x428) + 0xe) * 0x11 + 0x1f +
     *(longlong *)(param_1 + 0x428)) = param_6;
    lVar3 = *(longlong *)(param_1 + 0x428);
    piVar2 = (int *)(lVar3 + 0xe);
    *piVar2 = *piVar2 + 1;
    return CONCAT71((int7)((ulonglong)lVar3 >> 8),1);
  }
  return uVar1 & 0xffffffffffffff00;
}

// ==== CMsgTrainingVitality::helper_1404775d0  @1404775d0  [medium:callgraph-r1]  (orig: FUN_1404775d0)
void FUN_1404775d0(longlong param_1,char param_2,char param_3,undefined4 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  
  if (3 < (byte)(param_2 - 1U)) {
    return;
  }
  if (*(longlong *)(param_1 + 0x20) == 0) {
    return;
  }
  if (3 < (byte)(param_3 - 1U)) {
    return;
  }
  if (param_2 == '\x01') {
    if (param_3 == '\x01') {
      uVar2 = 2;
    }
    else if (param_3 == '\x02') {
      uVar2 = 3;
    }
    else if (param_3 == '\x03') {
      uVar2 = 4;
    }
    else {
      if (param_3 != '\x04') goto LAB_140477718;
      uVar2 = 5;
    }
  }
  else if (param_2 == '\x02') {
    if (param_3 == '\x01') {
      uVar2 = 6;
    }
    else if (param_3 == '\x02') {
      uVar2 = 7;
    }
    else if (param_3 == '\x03') {
      uVar2 = 8;
    }
    else {
      if (param_3 != '\x04') goto LAB_140477718;
      uVar2 = 9;
    }
  }
  else if (param_2 == '\x03') {
    if (param_3 == '\x01') {
      uVar2 = 10;
    }
    else if (param_3 == '\x02') {
      uVar2 = 0xb;
    }
    else if (param_3 == '\x03') {
      uVar2 = 0xc;
    }
    else {
      if (param_3 != '\x04') goto LAB_140477718;
      uVar2 = 0xd;
    }
  }
  else {
    if (param_2 != '\x04') goto LAB_140477718;
    if (param_3 == '\x01') {
      uVar2 = 0xe;
    }
    else if (param_3 == '\x02') {
      uVar2 = 0xf;
    }
    else if (param_3 == '\x03') {
      uVar2 = 0x10;
    }
    else {
      if (param_3 != '\x04') goto LAB_140477718;
      uVar2 = 0x11;
    }
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                     (*(longlong **)(param_1 + 0x20),uVar2);
  (**(code **)(*plVar1 + 0xa8))(plVar1,param_4);
LAB_140477718:
  if (*(char *)(param_1 + 0x30) == '\0') {
    (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
  }
  return;
}

// ==== CMsgTrainingVitality::helper_140477aa0  @140477aa0  [medium:callgraph-r2]  (orig: FUN_140477aa0)
ulonglong FUN_140477aa0(void)

{
  uint uVar1;
  
  uVar1 = FUN_140477350();
  return CONCAT71((int7)((ulonglong)uVar1 * 0xd1b71759 >> 8),(char)((ulonglong)uVar1 / 10000)) &
         0xffffffff;
}

// ==== CMsgTrainingVitality::helper_140477cc0  @140477cc0  [medium:callgraph-r1]  (orig: FUN_140477cc0)
ulonglong FUN_140477cc0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5)

{
  undefined4 uVar1;
  ulonglong in_RAX;
  longlong *plVar2;
  longlong lVar3;
  ulonglong uVar4;
  
  if (*(longlong *)(param_1 + 0x10) == 0) {
    return in_RAX & 0xffffffffffffff00;
  }
  plVar2 = (longlong *)InstanceGet();
  lVar3 = (**(code **)(*plVar2 + 0x20))(plVar2,"cq_fate_player");
  *(longlong *)(param_1 + 0x20) = lVar3;
  if (lVar3 != 0) {
    lVar3 = (**(code **)(*plVar2 + 0x20))(plVar2,"cq_fate_player");
    *(longlong *)(param_1 + 0x28) = lVar3;
    if (lVar3 != 0) {
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),1);
      lVar3 = *plVar2;
      uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 8))();
      (**(code **)(lVar3 + 0xb8))(plVar2,uVar1);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),2);
      (**(code **)(*plVar2 + 0xa8))(plVar2,param_2);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),3);
      (**(code **)(*plVar2 + 0xa8))(plVar2,param_3);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),4);
      (**(code **)(*plVar2 + 0xa8))(plVar2,param_4);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),5);
      (**(code **)(*plVar2 + 0xa8))(plVar2,param_5);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),6);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),7);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),8);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),9);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),10);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0xb);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0xc);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0xd);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0xe);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0xf);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0x10);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      plVar2 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                         (*(longlong **)(param_1 + 0x20),0x11);
      (**(code **)(*plVar2 + 0xb0))(plVar2,0);
      uVar4 = (**(code **)(**(longlong **)(param_1 + 0x20) + 0x50))
                        (*(longlong **)(param_1 + 0x20),1);
      return uVar4;
    }
  }
  return 0;
}

// ==== CMsgTrainingVitality::helper_140478110  @140478110  [medium:callgraph-r2]  (orig: FUN_140478110)
uint FUN_140478110(longlong param_1,byte param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  longlong *plVar3;
  uint uVar4;
  
  uVar4 = (uint)param_2;
  uVar1 = param_2 - 1;
  if (((byte)uVar1 < 4) && (uVar1 = param_3 - 1, (byte)uVar1 < 4)) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0x12);
    uVar2 = (**(code **)(*plVar3 + 0x50))(plVar3);
    if (uVar4 == 1) {
      uVar1 = 0;
      if (param_3 == 1) {
        if ((uVar2 & 1) != 0) {
          return 1;
        }
      }
      else if (param_3 == 2) {
        if ((uVar2 & 2) != 0) {
          return 1;
        }
      }
      else if (param_3 == 3) {
        if ((uVar2 & 4) != 0) {
          return 1;
        }
      }
      else if ((param_3 == 4) && ((uVar2 & 8) != 0)) {
        return 1;
      }
    }
    else if (uVar4 == 2) {
      uVar1 = 0;
      if (param_3 == 1) {
        if ((uVar2 & 0x10) != 0) {
          return 1;
        }
      }
      else if (param_3 == 2) {
        if ((uVar2 & 0x20) != 0) {
          return 1;
        }
      }
      else if (param_3 == 3) {
        if ((uVar2 & 0x40) != 0) {
          return 1;
        }
      }
      else if ((param_3 == 4) && ((char)uVar2 < '\0')) {
        return 1;
      }
    }
    else if (uVar4 == 3) {
      uVar1 = 0;
      if (param_3 == 1) {
        if ((uVar2 >> 8 & 1) != 0) {
          return 1;
        }
      }
      else if (param_3 == 2) {
        if ((uVar2 >> 9 & 1) != 0) {
          return 1;
        }
      }
      else if (param_3 == 3) {
        if ((uVar2 >> 10 & 1) != 0) {
          return 1;
        }
      }
      else if ((param_3 == 4) && ((uVar2 >> 0xb & 1) != 0)) {
        return 1;
      }
    }
    else {
      uVar1 = uVar4 - 4;
      if (uVar1 == 0) {
        if (param_3 == 1) {
          if ((uVar2 >> 0xc & 1) != 0) {
            return 1;
          }
        }
        else if (param_3 == 2) {
          if ((uVar2 >> 0xd & 1) != 0) {
            return 1;
          }
        }
        else if (param_3 == 3) {
          if ((uVar2 >> 0xe & 1) != 0) {
            return 1;
          }
        }
        else if ((param_3 == 4) && ((uVar2 >> 0xf & 1) != 0)) {
          return 1;
        }
      }
    }
  }
  return uVar1 & 0xffffff00;
}

// ==== CMsgTrainingVitality::helper_140478350  @140478350  [medium:callgraph-r2]  (orig: FUN_140478350)
undefined8 FUN_140478350(longlong param_1)

{
  longlong *plVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x20) == 0) {
    return 0;
  }
  plVar1 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                     (*(longlong **)(param_1 + 0x20),0x12);
                    /* WARNING: Could not recover jumptable at 0x00014047837b. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
  return uVar2;
}

// ==== CMsgTrainingVitality::helper_140478380  @140478380  [medium:callgraph-r2]  (orig: FUN_140478380)
void FUN_140478380(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  if (*(longlong *)(param_1 + 0x20) != 0) {
    plVar1 = (longlong *)
             (**(code **)(**(longlong **)(param_1 + 0x20) + 0x10))
                       (*(longlong **)(param_1 + 0x20),0x12);
    (**(code **)(*plVar1 + 0xa8))(plVar1,param_2);
    if (*(char *)(param_1 + 0x30) == '\0') {
      (**(code **)(**(longlong **)(param_1 + 0x20) + 0x38))(*(longlong **)(param_1 + 0x20),0);
    }
  }
  return;
}

// ==== CMsgTrainingVitality::helper_14047de10  @14047de10  [medium:callgraph-r3]  (orig: FUN_14047de10)
undefined8 FUN_14047de10(longlong param_1,undefined1 param_2,undefined4 param_3,char *param_4)

{
  undefined8 uVar1;
  
  if ((*(longlong *)(param_1 + 0x428) == 0) || (param_4 == (char *)0x0)) {
    uVar1 = 0;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 8) = 0x9e7;
    *(undefined4 *)(param_1 + 0xc) = 0x15;
    **(undefined1 **)(param_1 + 0x428) = param_2;
    *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 1) = param_3;
    strncpy((char *)(*(longlong *)(param_1 + 0x428) + 5),param_4,0x10);
    uVar1 = 1;
  }
  return uVar1;
}

