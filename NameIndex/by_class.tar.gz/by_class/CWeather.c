// ==== CWeather::helper_1403ac340  @1403ac340  [medium:callgraph-r0]  (orig: FUN_1403ac340)
void FUN_1403ac340(void *param_1)

{
  if ((DAT_140976200 & 1) == 0) {
    DAT_140976200 = DAT_140976200 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409761f8,"CWeather");
    atexit((_func_5014 *)&LAB_1406d6bd0);
  }
                    /* WARNING: Could not recover jumptable at 0x0001403ac395. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409761f8,param_1);
  return;
}

// ==== CWeather::ctor_or_dtor  @1403ac400  [high:vtable-assign]  (orig: FUN_1403ac400)
undefined8 * FUN_1403ac400(undefined8 *param_1,undefined8 param_2)

{
  param_1[1] = param_2;
  *param_1 = CWeather::vftable;
  *(undefined4 *)((longlong)param_1 + 0x54) = 0;
  *(undefined4 *)(param_1 + 0xb) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  *(undefined4 *)((longlong)param_1 + 0x14) = 0;
  *(undefined4 *)(param_1 + 3) = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  *(undefined4 *)((longlong)param_1 + 0x2c) = 0;
  *(undefined4 *)(param_1 + 6) = 0;
  *(undefined4 *)((longlong)param_1 + 0x34) = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined4 *)((longlong)param_1 + 0x44) = 0;
  *(undefined4 *)(param_1 + 9) = 0;
  *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
  *(undefined4 *)(param_1 + 10) = 0;
  *(undefined4 *)((longlong)param_1 + 0x1c) = 0x888888;
  return param_1;
}

// ==== CWeather::ctor_or_dtor  @1403ac460  [high:vtable-assign]  (orig: FUN_1403ac460)
undefined8 * FUN_1403ac460(undefined8 *param_1,byte param_2)

{
  *param_1 = CWeather::vftable;
  if ((param_2 & 1) != 0) {
    FUN_1403ac340();
  }
  return param_1;
}

