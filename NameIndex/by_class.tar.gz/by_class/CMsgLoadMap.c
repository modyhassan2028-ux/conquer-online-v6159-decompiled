// ==== CMsgLoadMap::helper_140167570  @140167570  [medium:callgraph-r0]  (orig: FUN_140167570)
void FUN_140167570(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0x13b0) = param_2;
  return;
}

// ==== CMsgLoadMap::helper_1401a41c0  @1401a41c0  [medium:callgraph-r0]  (orig: FUN_1401a41c0)
undefined1 FUN_1401a41c0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  undefined1 local_28 [40];
  
  local_res10[0] = param_2;
  FUN_14000d480(param_1 + 0x1370,local_28,local_res10);
  return 1;
}

// ==== CMsgLoadMap::helper_1401a4360  @1401a4360  [medium:callgraph-r0]  (orig: FUN_1401a4360)
undefined8 FUN_1401a4360(longlong param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined4 *puVar2;
  undefined4 *puVar3;
  longlong lVar4;
  undefined4 local_res10 [2];
  undefined1 local_38 [32];
  
  puVar3 = (undefined4 *)param_2[3];
  if ((undefined4 *)param_2[4] < puVar3) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)*param_2;
  while( true ) {
    puVar2 = (undefined4 *)param_2[4];
    if (puVar2 < (undefined4 *)param_2[3]) {
      _invalid_parameter_noinfo();
    }
    if ((plVar1 == (longlong *)0x0) || (plVar1 != (longlong *)*param_2)) {
      _invalid_parameter_noinfo();
    }
    if (puVar3 == puVar2) break;
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(undefined4 **)(lVar4 + 0x20) <= puVar3) {
      _invalid_parameter_noinfo();
    }
    local_res10[0] = *puVar3;
    FUN_14000d480(param_1 + 0x1370,local_38,local_res10);
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar4 = 0;
    }
    else {
      lVar4 = *plVar1;
    }
    if (*(undefined4 **)(lVar4 + 0x20) <= puVar3) {
      _invalid_parameter_noinfo();
    }
    puVar3 = puVar3 + 1;
  }
  return 1;
}

// ==== CMsgLoadMap::ctor_or_dtor  @1403eed30  [high:vtable-assign]  (orig: FUN_1403eed30)
undefined8 * FUN_1403eed30(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgLoadMap::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgLoadMap::ctor_or_dtor  @1403eed80  [high:vtable-assign]  (orig: FUN_1403eed80)
void FUN_1403eed80(undefined8 *param_1)

{
  *param_1 = CMsgLoadMap::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgLoadMap::vfunc_1  @1403eedb0  [high:rtti-vtable]  (orig: FUN_1403eedb0)
ulonglong FUN_1403eedb0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x414);
}

// ==== CMsgLoadMap::ctor_or_dtor  @1403eee60  [high:vtable-assign]  (orig: FUN_1403eee60)
undefined8 * FUN_1403eee60(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgLoadMap::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgLoadMap::helper_1403eeeb0  @1403eeeb0  [medium:callgraph-r0]  (orig: FUN_1403eeeb0)
void FUN_1403eeeb0(longlong *param_1,ulonglong param_2,undefined4 param_3)

{
  rsize_t _DstSize;
  void *_Src;
  void *pvVar1;
  longlong *plVar2;
  ulonglong uVar3;
  longlong lVar4;
  longlong lVar5;
  undefined4 local_res18 [2];
  longlong local_28;
  void *pvStack_20;
  
  _Src = (void *)param_1[4];
  pvVar1 = (void *)param_1[3];
  uVar3 = (longlong)_Src - (longlong)pvVar1 >> 2;
  local_res18[0] = param_3;
  if (uVar3 < param_2) {
    if (_Src < pvVar1) {
      _invalid_parameter_noinfo();
    }
    local_28 = *param_1;
    pvStack_20 = _Src;
    FUN_140036c20(param_1,&local_28,param_2 - (param_1[4] - param_1[3] >> 2),local_res18);
    return;
  }
  if (uVar3 <= param_2) {
    return;
  }
  if (_Src < pvVar1) {
    _invalid_parameter_noinfo();
  }
  uVar3 = param_1[3];
  if ((ulonglong)param_1[4] < uVar3) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*param_1;
  lVar4 = 0;
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar4;
  }
  else {
    lVar5 = *plVar2;
  }
  pvVar1 = (void *)(uVar3 + param_2 * 4);
  if (pvVar1 <= *(void **)(lVar5 + 0x20)) {
    if (plVar2 != (longlong *)0x0) {
      lVar4 = *plVar2;
    }
    if (*(void **)(lVar4 + 0x18) <= pvVar1) goto LAB_1403eef97;
  }
  _invalid_parameter_noinfo();
LAB_1403eef97:
  if ((pvVar1 < (void *)param_1[3]) || ((void *)param_1[4] < pvVar1)) {
    _invalid_parameter_noinfo();
  }
  lVar4 = *param_1;
  if ((_Src < (void *)param_1[3]) || ((void *)param_1[4] < _Src)) {
    _invalid_parameter_noinfo();
  }
  if ((lVar4 == 0) || (lVar4 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (pvVar1 != _Src) {
    lVar4 = param_1[4] - (longlong)_Src >> 2;
    _DstSize = lVar4 * 4;
    if (0 < lVar4) {
      memmove_s(pvVar1,_DstSize,_Src,_DstSize);
    }
    param_1[4] = (longlong)(_DstSize + (longlong)pvVar1);
  }
  return;
}

// ==== CMsgLoadMap::vfunc_3  @1403ef030  [high:rtti-vtable]  (orig: FUN_1403ef030)
void FUN_1403ef030(longlong param_1)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  int iVar7;
  longlong *plVar8;
  uint uVar9;
  longlong lVar10;
  longlong *local_60 [3];
  void *local_48;
  longlong local_40;
  undefined8 local_38;
  
  lVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar4 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar5 = (longlong *)
           (**(code **)(**(longlong **)(lVar4 + 0x90) + 0x88))(*(longlong **)(lVar4 + 0x90),param_1)
  ;
  if (plVar5 != (longlong *)0x0) {
    plVar6 = (longlong *)FUN_1400e1e60();
    lVar10 = plVar5[0x1e2];
    lVar4 = *plVar6;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar3 = (**(code **)(*plVar5 + 8))(plVar5);
    (**(code **)(lVar4 + 0x108))(plVar6,uVar3,(int)lVar10,*puVar2);
    lVar4 = *(longlong *)(param_1 + 0x428);
    if (*(short *)(lVar4 + 4) == 1) {
      if (*(char *)(lVar4 + 6) == '\0') {
        if ((0 < *(int *)(lVar4 + 8)) &&
           ((longlong)*(int *)(param_1 + 0xc) == (longlong)(*(int *)(lVar4 + 8) + -1) * 4 + 0x10)) {
          plVar6 = operator_new(8);
          plVar8 = (longlong *)0x0;
          local_60[0] = plVar8;
          if (plVar6 != (longlong *)0x0) {
            *plVar6 = (longlong)local_60;
            local_60[0] = plVar6;
          }
          local_48 = (void *)0x0;
          local_40 = 0;
          local_38 = 0;
          FUN_1403eeeb0(local_60,(longlong)*(int *)(*(longlong *)(param_1 + 0x428) + 8),0);
          plVar6 = plVar8;
          if (0 < *(int *)(*(longlong *)(param_1 + 0x428) + 8)) {
            do {
              if ((longlong *)(local_40 - (longlong)local_48 >> 2) <= plVar6) {
                _invalid_parameter_noinfo();
              }
              *(undefined4 *)((longlong)local_48 + (longlong)plVar6 * 4) =
                   *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc + (longlong)plVar6 * 4);
              uVar9 = (int)plVar8 + 1;
              plVar8 = (longlong *)(ulonglong)uVar9;
              plVar6 = (longlong *)((longlong)plVar6 + 1);
            } while ((int)uVar9 < *(int *)(*(longlong *)(param_1 + 0x428) + 8));
          }
          FUN_1401a4360(plVar5,local_60);
          if (local_48 != (void *)0x0) {
            operator_delete(local_48);
          }
          local_48 = (void *)0x0;
          local_40 = 0;
          local_38 = 0;
          operator_delete(local_60[0]);
        }
      }
      else {
        FUN_140167570(plVar5,1);
      }
    }
    else if ((((*(short *)(lVar4 + 4) == 3) && (iVar1 = *(int *)(lVar4 + 8), 0 < iVar1)) &&
             ((longlong)*(int *)(param_1 + 0xc) == (longlong)(iVar1 + -1) * 4 + 0x10)) &&
            (iVar7 = 0, 0 < iVar1)) {
      lVar10 = 0xc;
      do {
        FUN_1401a41c0(plVar5,*(undefined4 *)(lVar10 + lVar4));
        iVar7 = iVar7 + 1;
        lVar10 = lVar10 + 4;
        lVar4 = *(longlong *)(param_1 + 0x428);
      } while (iVar7 < *(int *)(lVar4 + 8));
    }
  }
  return;
}

