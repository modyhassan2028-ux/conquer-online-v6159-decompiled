// ==== CMsgCrossFlagWarResult::ctor_or_dtor  @14045f740  [high:vtable-assign]  (orig: FUN_14045f740)
undefined8 * FUN_14045f740(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgCrossFlagWarResult::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgCrossFlagWarResult::ctor_or_dtor  @14045f790  [high:vtable-assign]  (orig: FUN_14045f790)
void FUN_14045f790(undefined8 *param_1)

{
  *param_1 = CMsgCrossFlagWarResult::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgCrossFlagWarResult::vfunc_5  @14045f830  [high:rtti-vtable]  (orig: FUN_14045f830)
bool FUN_14045f830(longlong param_1,longlong param_2,undefined2 param_3)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640(param_1,param_2,param_3);
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c7;
    }
  }
  return false;
}

// ==== CMsgCrossFlagWarResult::ctor_or_dtor  @14045f870  [high:vtable-assign]  (orig: FUN_14045f870)
undefined8 * FUN_14045f870(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgCrossFlagWarResult::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgCrossFlagWarResult::vfunc_3  @14045f8c0  [high:rtti-vtable]  (orig: FUN_14045f8c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14045f8c0(longlong param_1)

{
  char cVar1;
  int iVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined1 auStack_4d8 [32];
  undefined8 local_4b8;
  undefined4 local_4b0;
  undefined2 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined1 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (*(longlong *)(param_1 + 0x428) == 0) {
    local_4b8 = CONCAT44(local_4b8._4_4_,0x35);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    cVar1 = FUN_14008b330(uVar3);
    if (cVar1 == '\0') {
      FUN_14015b240();
      local_488 = 1;
      local_490 = 0;
      local_498 = 0;
      local_4a0 = 0;
      local_4a8 = 0x7e6;
      local_4b0 = 0xff0000;
      local_4b8 = 0;
      iVar2 = FUN_14015b300(local_468,"SYSTEM","ALLUSERS",*(undefined8 *)(param_1 + 0x428));
      if (iVar2 == 0) {
        local_4b8 = CONCAT44(local_4b8._4_4_,0x3d);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar4 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        (**(code **)(*plVar4 + 0x68))(plVar4,local_468,0xffffffff);
      }
      FUN_14015b2c0(local_468);
    }
  }
  return;
}

