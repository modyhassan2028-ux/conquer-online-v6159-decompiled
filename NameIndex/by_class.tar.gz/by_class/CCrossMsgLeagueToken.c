// ==== CCrossMsgLeagueToken::ctor_or_dtor  @1403ef810  [high:vtable-assign]  (orig: FUN_1403ef810)
undefined8 * FUN_1403ef810(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgLeagueToken::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgLeagueToken::ctor_or_dtor  @1403ef860  [high:vtable-assign]  (orig: FUN_1403ef860)
void FUN_1403ef860(undefined8 *param_1)

{
  *param_1 = CCrossMsgLeagueToken::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgLeagueToken::vfunc_1  @1403ef890  [high:rtti-vtable]  (orig: FUN_1403ef890)
ulonglong FUN_1403ef890(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x9c65);
}

// ==== CCrossMsgLeagueToken::ctor_or_dtor  @1403ef930  [high:vtable-assign]  (orig: FUN_1403ef930)
undefined8 * FUN_1403ef930(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgLeagueToken::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossMsgLeagueToken::vfunc_3  @1403ef980  [high:rtti-vtable]  (orig: FUN_1403ef980)
void FUN_1403ef980(longlong param_1)

{
  char *pcVar1;
  longlong lVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  longlong *plVar9;
  undefined8 uVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong *local_res8;
  uint uVar16;
  longlong *local_88;
  undefined4 *puStack_80;
  longlong *local_78 [3];
  undefined4 *local_60;
  undefined4 *local_58;
  longlong local_50;
  longlong local_48 [6];
  
  pcVar1 = *(char **)(param_1 + 0x428);
  if (pcVar1 == (char *)0x0) {
    return;
  }
  cVar5 = *pcVar1;
  if (cVar5 == '\0') {
    uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar10 = FUN_140087650(uVar10);
    lVar13 = FUN_1402af110(uVar10,*(undefined4 *)(pcVar1 + 4),*(undefined4 *)(pcVar1 + 8));
    if (lVar13 == 0) {
      log_InlineLogOSWARNING
                (
                "CCrossMsgLeagueToken::ACTION_SET_OS_TOKEN_POINT from gs not found os user, idServer:%u, idOSUser:%u."
                );
      return;
    }
    lVar2 = *(longlong *)(param_1 + 0x428);
    FUN_140168d90(lVar13,*(undefined4 *)(lVar2 + 0xc),*(undefined4 *)(lVar2 + 0x10),
                  *(undefined4 *)(lVar2 + 0x14),*(undefined4 *)(lVar2 + 0x18));
    return;
  }
  if (cVar5 == '\x01') {
    uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar9 = (longlong *)FUN_140087650(uVar10);
    lVar13 = (**(code **)(*plVar9 + 0x98))
                       (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
    if (lVar13 == 0) {
      log_InlineLogERROR("CCrossMsgLeagueToken::ACTION_SET_GS_TOKEN_POINT, user[%lu] is not online."
                        );
      return;
    }
    lVar2 = *(longlong *)(param_1 + 0x428);
    FUN_140168d90(lVar13,*(undefined4 *)(lVar2 + 0xc),*(undefined4 *)(lVar2 + 0x10),
                  *(undefined4 *)(lVar2 + 0x14),*(undefined4 *)(lVar2 + 0x18));
    return;
  }
  if (cVar5 == '\x02') {
    uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar9 = (longlong *)FUN_140087650(uVar10);
    lVar13 = (**(code **)(*plVar9 + 0x98))
                       (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8));
    if (lVar13 == 0) {
      log_InlineLogERROR("CCrossMsgLeagueToken::ACTION_TOKEN_PUBLISH, user[%lu] is not online.");
      return;
    }
    cVar5 = FUN_140167b70(lVar13);
    if (cVar5 != '\0') {
      log_InlineLogERROR("CCrossMsgLeagueToken::ACTION_TOKEN_PUBLISH, user[%lu] is other server.");
      return;
    }
    plVar9 = (longlong *)FUN_140087ed0();
    if (plVar9 == (longlong *)0x0) {
      return;
    }
    lVar13 = *(longlong *)(param_1 + 0x428);
    (**(code **)(*plVar9 + 0x610))
              (plVar9,*(undefined4 *)(lVar13 + 8),*(undefined4 *)(lVar13 + 4),
               *(undefined4 *)(lVar13 + 0xc),*(undefined4 *)(lVar13 + 0x10),
               *(undefined4 *)(lVar13 + 0x14),*(undefined4 *)(lVar13 + 0x18));
    return;
  }
  if (cVar5 != '\x03') {
    if (cVar5 != '\x05') {
      return;
    }
    plVar9 = (longlong *)FUN_140087ed0();
    if (plVar9 == (longlong *)0x0) {
      return;
    }
    lVar13 = *(longlong *)(param_1 + 0x428);
    (**(code **)(*plVar9 + 0x580))
              (plVar9,*(undefined4 *)(lVar13 + 8),*(undefined4 *)(lVar13 + 4),
               *(undefined4 *)(lVar13 + 0xc));
    return;
  }
  uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar9 = (longlong *)FUN_140087650(uVar10);
  plVar9 = (longlong *)
           (**(code **)(*plVar9 + 0xa0))
                     (plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8),
                      *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (plVar9 == (longlong *)0x0) {
    log_InlineLogERROR("CCrossMsgLeagueToken::ACTION_TOKEN_ACK_OK, user[%lu] is not online.");
    return;
  }
  cVar5 = (**(code **)(plVar9[2] + 0x220))();
  if (cVar5 == '\0') {
    log_InlineLogERROR("CCrossMsgLeagueToken::ACTION_TOKEN_ACK_OK, user[%lu] is die.");
    return;
  }
  cVar5 = FUN_14017bac0(plVar9);
  if (cVar5 == '\0') {
    return;
  }
  uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  iVar6 = FUN_14008b420(uVar10);
  lVar13 = *(longlong *)(param_1 + 0x428);
  if (*(int *)(lVar13 + 0xc) == iVar6) {
    local_res8 = *(longlong **)(lVar13 + 0x14);
    uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar10 = FUN_1400d6610(uVar10);
    iVar6 = FUN_140006d00(uVar10);
    if (iVar6 < 1) {
      uVar7 = 1;
    }
    else {
      uVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar10 = FUN_1400d6610(uVar10);
      uVar7 = FUN_140006d00(uVar10);
    }
    FUN_1401c9c80(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x10),local_res8,uVar7);
    return;
  }
  iVar6 = *(int *)(lVar13 + 0xc);
  iVar8 = FUN_140167b40(plVar9);
  if (iVar6 != iVar8) {
    cVar5 = FUN_1401bdae0(plVar9,iVar6,0);
    if (cVar5 == '\0') {
      return;
    }
    lVar13 = *(longlong *)(param_1 + 0x428);
    FUN_140168d90(plVar9,*(undefined4 *)(lVar13 + 0xc),*(undefined4 *)(lVar13 + 0x10),
                  *(undefined4 *)(lVar13 + 0x14),*(undefined4 *)(lVar13 + 0x18));
    return;
  }
  lVar13 = *(longlong *)(param_1 + 0x428);
  uVar16 = *(uint *)(lVar13 + 0x18);
  FUN_140168d90(plVar9,*(undefined4 *)(lVar13 + 0xc),*(undefined4 *)(lVar13 + 0x10),
                *(undefined4 *)(lVar13 + 0x14),uVar16);
  local_res8 = operator_new(8);
  plVar11 = (longlong *)0x0;
  local_78[0] = plVar11;
  if (local_res8 != (longlong *)0x0) {
    *local_res8 = (longlong)local_78;
    local_78[0] = local_res8;
  }
  local_60 = (undefined4 *)0x0;
  local_58 = (undefined4 *)0x0;
  local_50 = 0;
  uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
  puVar4 = local_58;
  local_res8 = (longlong *)CONCAT44(local_res8._4_4_,uVar7);
  plVar9 = plVar11;
  if (local_60 != (undefined4 *)0x0) {
    plVar9 = (longlong *)(local_50 - (longlong)local_60 >> 2);
  }
  if ((longlong *)((longlong)local_58 - (longlong)local_60 >> 2) < plVar9) {
    *local_58 = uVar7;
    local_58 = local_58 + 1;
  }
  else {
    if (local_58 < local_60) {
      _invalid_parameter_noinfo();
    }
    puVar3 = local_60;
    plVar9 = local_78[0];
    local_88 = local_78[0];
    puStack_80 = puVar4;
    plVar14 = plVar11;
    if (((longlong)local_58 - (longlong)local_60 & 0xfffffffffffffffcU) != 0) {
      if (local_58 < local_60) {
        _invalid_parameter_noinfo();
      }
      if ((plVar9 == (longlong *)0x0) || (plVar9 != local_78[0])) {
        _invalid_parameter_noinfo();
      }
      plVar14 = (longlong *)((longlong)puVar4 - (longlong)puVar3 >> 2);
    }
    FUN_140036c20(local_78,&local_88,1,&local_res8);
    puVar4 = local_60;
    if (local_58 < local_60) {
      _invalid_parameter_noinfo();
    }
    plVar9 = local_78[0];
    if (local_78[0] == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar15 = plVar11;
    }
    else {
      plVar15 = (longlong *)*local_78[0];
    }
    if (puVar4 + (longlong)plVar14 <= (undefined4 *)plVar15[4]) {
      if (plVar9 != (longlong *)0x0) {
        plVar11 = (longlong *)*plVar9;
      }
      if ((undefined4 *)plVar11[3] <= puVar4 + (longlong)plVar14) goto LAB_1403efcf2;
    }
    _invalid_parameter_noinfo();
  }
LAB_1403efcf2:
  local_res8 = local_48;
  uVar10 = FUN_140043260(local_48,local_78);
  uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  uVar12 = FUN_140087650(uVar12);
  FUN_1402b3560(uVar12,uVar10,0xd,1,uVar16 & 0xffffff00,1);
  if (local_60 != (undefined4 *)0x0) {
    operator_delete(local_60);
  }
  local_60 = (undefined4 *)0x0;
  local_58 = (undefined4 *)0x0;
  local_50 = 0;
  operator_delete(local_78[0]);
  return;
}

