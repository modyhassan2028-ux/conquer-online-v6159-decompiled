// ==== CMsgShowHandExit@texasholdem::vfunc_1  @140452f90  [high:rtti-vtable]  (orig: FUN_140452f90)
undefined8 FUN_140452f90(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgShowHandExit@texasholdem::vfunc_0  @140453000  [high:rtti-vtable]  (orig: FUN_140453000)
undefined8 * FUN_140453000(undefined8 *param_1,uint param_2)

{
  *param_1 = texasholdem::CMsgShowHandExit::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgShowHandExit@texasholdem::vfunc_3  @140453050  [high:rtti-vtable]  (orig: FUN_140453050)
void FUN_140453050(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar2 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))(*(longlong **)(lVar2 + 0x90),param_1);
  if ((lVar2 != 0) && (*(int *)(lVar2 + 0x1240) != 0)) {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    lVar3 = *(longlong *)(lVar3 + 0x108);
    if (lVar3 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar3 = 0;
    }
    cVar1 = FUN_140215360(lVar3,lVar2,*(undefined4 *)(lVar2 + 0x1240));
    if (cVar1 != '\0') {
      uVar4 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      uVar4 = FUN_140087830(uVar4);
      lVar3 = FUN_140214ce0(uVar4,*(undefined4 *)(lVar2 + 0x1240));
      if (lVar3 != 0) {
        if (**(short **)(param_1 + 0x428) == 0) {
          cVar1 = FUN_1403bc2d0(lVar3);
          if (cVar1 == '\0') {
            FUN_1403d8ec0(lVar3,*(undefined4 *)(lVar2 + 0x1240),lVar2,
                          *(undefined1 *)(lVar2 + 0x1244),1);
          }
        }
        else if (**(short **)(param_1 + 0x428) == 1) {
          FUN_1403e7910(lVar3,lVar2);
          return;
        }
      }
    }
  }
  return;
}

