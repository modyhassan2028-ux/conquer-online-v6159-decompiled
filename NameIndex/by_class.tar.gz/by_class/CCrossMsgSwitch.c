// ==== CCrossMsgSwitch::ctor_or_dtor  @1403f1ca0  [high:vtable-assign]  (orig: FUN_1403f1ca0)
undefined8 * FUN_1403f1ca0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CCrossMsgSwitch::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CCrossMsgSwitch::ctor_or_dtor  @1403f1cf0  [high:vtable-assign]  (orig: FUN_1403f1cf0)
void FUN_1403f1cf0(undefined8 *param_1)

{
  *param_1 = CCrossMsgSwitch::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CCrossMsgSwitch::vfunc_1  @1403f1d20  [high:rtti-vtable]  (orig: FUN_1403f1d20)
bool FUN_1403f1d20(longlong param_1,longlong param_2,int param_3)

{
  int iVar1;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0x9c5;
    }
  }
  return false;
}

// ==== CCrossMsgSwitch::vfunc_3  @1403f1e40  [high:rtti-vtable]  (orig: FUN_1403f1e40)
void FUN_1403f1e40(void)

{
  return;
}

// ==== CCrossMsgSwitch::ctor_or_dtor  @1403f1e50  [high:vtable-assign]  (orig: FUN_1403f1e50)
undefined8 * FUN_1403f1e50(undefined8 *param_1,uint param_2)

{
  *param_1 = CCrossMsgSwitch::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

