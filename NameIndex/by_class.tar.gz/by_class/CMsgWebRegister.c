// ==== CMsgWebRegister::ctor_or_dtor  @1403b58f0  [high:vtable-assign]  (orig: FUN_1403b58f0)
undefined8 * FUN_1403b58f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgWebRegister::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf((CStringPacker *)(param_1 + 0x86),(char *)(param_1 + 3),0x3f5,true);
  return param_1;
}

// ==== CMsgWebRegister::ctor_or_dtor  @1403b5970  [high:vtable-assign]  (orig: FUN_1403b5970)
void FUN_1403b5970(undefined8 *param_1)

{
  *param_1 = CMsgWebRegister::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgWebRegister::vfunc_1  @1403b5a10  [high:rtti-vtable]  (orig: FUN_1403b5a10)
ulonglong FUN_1403b5a10(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x42c);
}

// ==== CMsgWebRegister::ctor_or_dtor  @1403b5a40  [high:vtable-assign]  (orig: FUN_1403b5a40)
undefined8 * FUN_1403b5a40(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgWebRegister::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgWebRegister::vfunc_3  @1403b5aa0  [high:rtti-vtable]  (orig: FUN_1403b5aa0)
void FUN_1403b5aa0(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  longlong lVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  
  lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar3 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar3 = (**(code **)(**(longlong **)(lVar3 + 0x90) + 0x88))(*(longlong **)(lVar3 + 0x90),param_1);
  if (lVar3 != 0) {
    plVar1 = (longlong *)(lVar3 + 0x10);
    cVar2 = (**(code **)(*plVar1 + 0x220))(plVar1);
    if (cVar2 == '\0') {
      pIVar4 = theInstance();
      lVar3 = *plVar1;
      uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_DIE");
      (**(code **)(lVar3 + 0x358))(plVar1,uVar5);
    }
  }
  return;
}

