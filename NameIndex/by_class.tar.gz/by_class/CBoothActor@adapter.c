// ==== CBoothActor@adapter::helper_140100320  @140100320  [medium:callgraph-r0]  (orig: FUN_140100320)
undefined8 FUN_140100320(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0x50) != 0) {
                    /* WARNING: Could not recover jumptable at 0x000140100333. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x50) + 0x30))(*(longlong **)(param_1 + 0x50),3);
    return uVar1;
  }
  return 0;
}

// ==== CBoothActor@adapter::helper_140162c40  @140162c40  [medium:callgraph-r0]  (orig: FUN_140162c40)
void FUN_140162c40(longlong param_1)

{
  FUN_1403b41e0(param_1 + 0x3a0);
  return;
}

// ==== CBoothActor@adapter::helper_1402c8370  @1402c8370  [medium:callgraph-r0]  (orig: FUN_1402c8370)
undefined8 FUN_1402c8370(longlong param_1,int param_2,int param_3,int param_4,undefined8 *param_5)

{
  longlong *plVar1;
  undefined8 *puVar2;
  char cVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  
  puVar2 = param_5;
  uVar8 = 0;
  *param_5 = 0;
  if (param_4 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((((-1 < param_2) &&
            (iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x28))(), param_2 < iVar4)) &&
           (-1 < param_3)) &&
          ((iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 0x20))(), param_3 < iVar4 &&
           (lVar5 = FUN_1402c7750(param_1,param_2,param_3), lVar5 != 0)))) {
    plVar1 = *(longlong **)(lVar5 + 8);
    if ((plVar1 != (longlong *)0x0) && (lVar5 = (**(code **)(*plVar1 + 0x10))(plVar1), lVar5 != 0))
    {
      do {
        plVar6 = (longlong *)(**(code **)(*plVar1 + 0x18))(plVar1,uVar8);
        if ((((plVar6 != (longlong *)0x0) &&
             (cVar3 = (**(code **)(*plVar6 + 0x38))(plVar6,param_4,&param_5), cVar3 != '\0')) &&
            (iVar4 = (**(code **)(*plVar6 + 0x20))(plVar6), iVar4 == param_2)) &&
           (iVar4 = (**(code **)(*plVar6 + 0x28))(plVar6), iVar4 == param_3)) {
          *puVar2 = param_5;
          return 1;
        }
        uVar8 = uVar8 + 1;
        uVar7 = (**(code **)(*plVar1 + 0x10))(plVar1);
      } while (uVar8 < uVar7);
    }
    return 0;
  }
  return 0;
}

// ==== CBoothActor@adapter::helper_140454b00  @140454b00  [medium:callgraph-r0]  (orig: FUN_140454b00)
undefined8
FUN_140454b00(longlong param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
             undefined2 param_5,undefined2 param_6,undefined2 param_7,undefined2 param_8,
             char *param_9)

{
  ulong uVar1;
  uint uVar2;
  
  FUN_1402b5600();
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x12) = param_4;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_5;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_6;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_7;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_8;
  if (param_9 != (char *)0x0) {
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_9);
  }
  uVar1 = tq::TimeGet(0);
  **(ulong **)(param_1 + 0x428) = uVar1;
  *(undefined4 *)(param_1 + 8) = 0x7ee;
  uVar2 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar2 + 0x17;
  return 1;
}

// ==== CBoothActor@adapter::helper_140456620  @140456620  [medium:callgraph-r0]  (orig: FUN_140456620)
undefined8
FUN_140456620(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined2 param_6,undefined2 param_7,undefined2 param_8,
             undefined2 param_9,undefined2 param_10,char *param_11)

{
  uint uVar1;
  
  FUN_1402b5600();
  **(undefined4 **)(param_1 + 0x428) = param_2;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4) = param_3;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 8) = param_4;
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0xc) = param_5;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x16) = param_6;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x18) = param_7;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x14) = param_8;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_9;
  *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 0x12) = param_10;
  if (param_11 != (char *)0x0) {
    tq::CStringPacker::AddString((CStringPacker *)(param_1 + 0x430),param_11);
  }
  *(undefined4 *)(param_1 + 8) = 0x455;
  uVar1 = tq::CStringPacker::GetSize((CStringPacker *)(param_1 + 0x430));
  *(uint *)(param_1 + 0xc) = uVar1 + 0x23;
  return 1;
}

// ==== CBoothActor@adapter::vfunc_1  @140592540  [high:rtti-vtable]  (orig: FUN_140592540)
void FUN_140592540(undefined8 *param_1)

{
  if (param_1 != (undefined8 *)0x8) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_6  @140592560  [high:rtti-vtable]  (orig: FUN_140592560)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140592560(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4,
                  undefined8 param_5,undefined8 param_6,undefined4 param_7,undefined2 param_8,
                  undefined2 param_9)

{
  int iVar1;
  longlong lVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 != 0) {
    FUN_14015b240(local_488);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = param_9;
    local_4c8 = param_8;
    local_4d0 = param_7;
    local_4d8 = param_6;
    iVar1 = FUN_14015b300(local_488,param_3,param_4,param_5);
    if (iVar1 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))((longlong *)(lVar2 + 0x10),local_488);
    }
    FUN_14015b2c0(local_488);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_7  @140592650  [high:rtti-vtable]  (orig: FUN_140592650)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140592650(longlong param_1,undefined8 param_2,undefined2 param_3,char *param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_4 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x75);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_4,&stack0x00000028);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8c0 = 0xffff00;
      local_8c8 = 0;
      local_8b8 = param_3;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CBoothActor@adapter::vfunc_8  @1405927b0  [high:rtti-vtable]  (orig: FUN_1405927b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1405927b0(longlong param_1,undefined8 param_2,char *param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_3 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res20 = param_4;
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar3 == 0) {
      local_8c8 = CONCAT44(local_8c8._4_4_,0x8f);
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar1 = 0;
    }
    else {
      _vsnprintf(local_428,0x400,param_3,(va_list)&local_res20);
      local_29 = 0;
      FUN_14015b240(local_878);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))(lVar3 + 0x10);
      local_898 = 1;
      local_8a0 = 0;
      local_8a8 = 0;
      local_8b0 = 0;
      local_8b8 = 0x7d5;
      local_8c0 = 0xff0000;
      local_8c8 = 0;
      iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar4,local_428);
      if (iVar2 == 0) {
        FUN_14015b2c0(local_878);
        uVar1 = 0;
      }
      else {
        uVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))(lVar3 + 0x10,local_878);
        FUN_14015b2c0(local_878);
      }
    }
  }
  return uVar1;
}

// ==== CBoothActor@adapter::vfunc_14  @140592910  [high:rtti-vtable]  (orig: FUN_140592910)
undefined8 FUN_140592910(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140592963. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x168))(lVar1 + 0x10);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_9  @140592970  [high:rtti-vtable]  (orig: FUN_140592970)
undefined1 * FUN_140592970(longlong param_1)

{
  longlong lVar1;
  undefined1 *puVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return &DAT_1406dd892;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405929c8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  puVar2 = (undefined1 *)(**(code **)(*(longlong *)(lVar1 + 0x10) + 0x18))(lVar1 + 0x10);
  return puVar2;
}

// ==== CBoothActor@adapter::vfunc_12  @1405929d0  [high:rtti-vtable]  (orig: FUN_1405929d0)
bool FUN_1405929d0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  return lVar1 != 0;
}

// ==== CBoothActor@adapter::vfunc_10  @1405929f0  [high:rtti-vtable]  (orig: FUN_1405929f0)
undefined8 FUN_1405929f0(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140592a43. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_11  @140592a50  [high:rtti-vtable]  (orig: FUN_140592a50)
undefined8 FUN_140592a50(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140592aa3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_13  @140592ab0  [high:rtti-vtable]  (orig: FUN_140592ab0)
ulonglong FUN_140592ab0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140592b03. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x220))(lVar1 + 0x10);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_33  @140592b10  [high:rtti-vtable]  (orig: FUN_140592b10)
bool FUN_140592b10(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  return lVar1 != 0;
}

// ==== CBoothActor@adapter::vfunc_41  @140592b70  [high:rtti-vtable]  (orig: FUN_140592b70)
void FUN_140592b70(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140101cb0(lVar1,param_3);
  return;
}

// ==== CBoothActor@adapter::vfunc_42  @140592bf0  [high:rtti-vtable]  (orig: FUN_140592bf0)
undefined8 FUN_140592bf0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140100320(lVar1);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_43  @140592c80  [high:rtti-vtable]  (orig: FUN_140592c80)
undefined8 FUN_140592c80(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  uVar2 = FUN_140100340(lVar1);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_65  @140592d10  [high:rtti-vtable]  (orig: FUN_140592d10)
void FUN_140592d10(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_140170e90(lVar1,param_3);
  return;
}

// ==== CBoothActor@adapter::vfunc_34  @140592d70  [high:rtti-vtable]  (orig: FUN_140592d70)
undefined8 FUN_140592d70(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  undefined8 uVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar1 != 0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_3);
    if (lVar1 != 0) {
      uVar2 = FUN_140332fe0(lVar1,param_2);
      return uVar2;
    }
  }
  return 0;
}

// ==== CBoothActor@adapter::vfunc_35  @140592e10  [high:rtti-vtable]  (orig: FUN_140592e10)
undefined8 FUN_140592e10(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong *plVar4;
  longlong lVar5;
  ulonglong uVar6;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  plVar4 = (longlong *)(**(code **)(*plVar4 + 0x60))(plVar4,param_3);
  if (((((plVar4 != (longlong *)0x0) &&
        (lVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                           (*(longlong **)(param_1 + 0x10),param_2), lVar5 != 0)) &&
       (cVar1 = FUN_1400ffbe0(plVar4), cVar1 == '\0')) &&
      ((uVar6 = FUN_1400fda10(plVar4,0x6e,1), ((uVar6 ^ 0xff) & 1) != 0 &&
       (iVar2 = FUN_1400fda10(plVar4,0x17,1), iVar2 == 0)))) &&
     ((cVar1 = FUN_1400ffc20(plVar4), cVar1 == '\0' &&
      ((cVar1 = FUN_1400ff650(plVar4,2), cVar1 == '\0' &&
       (cVar1 = FUN_1400ff650(plVar4,1), cVar1 == '\0')))))) {
    uVar3 = (**(code **)(*plVar4 + 8))(plVar4);
    cVar1 = FUN_1403380a0(lVar5,uVar3);
    if ((cVar1 != '\0') && (cVar1 = FUN_140175450(lVar5), cVar1 == '\0')) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CBoothActor@adapter::vfunc_44  @140592f40  [high:rtti-vtable]  (orig: FUN_140592f40)
void FUN_140592f40(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 != 0) {
    plVar2 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar2 = (longlong *)0x0;
    }
                    /* WARNING: Could not recover jumptable at 0x000140592fec. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*plVar2 + 200))(plVar2,param_2);
    return;
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_45  @140593000  [high:rtti-vtable]  (orig: FUN_140593000)
void FUN_140593000(void)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140593043. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0xe8))();
  return;
}

// ==== CBoothActor@adapter::vfunc_46  @140593050  [high:rtti-vtable]  (orig: FUN_140593050)
void FUN_140593050(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_1400fda10(lVar1,1,1);
  return;
}

// ==== CBoothActor@adapter::vfunc_61  @1405930c0  [high:rtti-vtable]  (orig: FUN_1405930c0)
void FUN_1405930c0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_1400ffda0(lVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_62  @140593120  [high:rtti-vtable]  (orig: FUN_140593120)
void FUN_140593120(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  longlong lVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_3);
    if (lVar2 != 0) {
      FUN_14019a030(lVar1,param_4,lVar2,param_5);
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_15  @140593190  [high:rtti-vtable]  (orig: FUN_140593190)
undefined4 FUN_140593190(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined4 *)(lVar1 + 0xfa4);
}

// ==== CBoothActor@adapter::vfunc_16  @1405931c0  [high:rtti-vtable]  (orig: FUN_1405931c0)
void FUN_1405931c0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001405931e5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x60))(plVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_17  @1405931f0  [high:rtti-vtable]  (orig: FUN_1405931f0)
undefined1 FUN_1405931f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return 0;
  }
  return *(undefined1 *)(lVar1 + 0x51c);
}

// ==== CBoothActor@adapter::vfunc_47  @140593220  [high:rtti-vtable]  (orig: FUN_140593220)
undefined1 FUN_140593220(undefined8 param_1,undefined4 param_2)

{
  undefined1 uVar1;
  longlong lVar2;
  longlong *plVar3;
  
  plVar3 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar3 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar3 + 0x60))(plVar3,param_2);
  if (lVar2 == 0) {
    return 0;
  }
  uVar1 = FUN_1400ffbe0(lVar2);
  return uVar1;
}

// ==== CBoothActor@adapter::vfunc_48  @140593290  [high:rtti-vtable]  (orig: FUN_140593290)
void FUN_140593290(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140100000(lVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_51  @1405932f0  [high:rtti-vtable]  (orig: FUN_1405932f0)
void FUN_1405932f0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined2 param_5,undefined1 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140339ec0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CBoothActor@adapter::vfunc_52  @140593350  [high:rtti-vtable]  (orig: FUN_140593350)
void FUN_140593350(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4,
                  undefined1 param_5,undefined1 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_1403368a0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CBoothActor@adapter::vfunc_36  @1405933b0  [high:rtti-vtable]  (orig: FUN_1405933b0)
void FUN_1405933b0(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140102870(lVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_53  @140593410  [high:rtti-vtable]  (orig: FUN_140593410)
void FUN_140593410(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined2 param_5,undefined1 param_6,undefined1 param_7)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_14033f6b0(lVar1,param_3,param_4,param_5,param_6,param_7,0);
  return;
}

// ==== CBoothActor@adapter::vfunc_54  @140593480  [high:rtti-vtable]  (orig: FUN_140593480)
void FUN_140593480(longlong param_1,undefined8 param_2,undefined4 param_3,undefined1 param_4,
                  undefined1 param_5)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  FUN_140340de0(lVar1,param_3,param_4,param_5);
  return;
}

// ==== CBoothActor@adapter::vfunc_18  @1405934d0  [high:rtti-vtable]  (orig: FUN_1405934d0)
void FUN_1405934d0(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140593515. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x178))(plVar1,param_3,param_4);
  return;
}

// ==== CBoothActor@adapter::vfunc_19  @140593520  [high:rtti-vtable]  (orig: FUN_140593520)
void FUN_140593520(longlong param_1,undefined8 param_2,undefined8 param_3,undefined1 param_4)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140593565. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x180))(plVar1,param_3,param_4);
  return;
}

// ==== CBoothActor@adapter::vfunc_20  @140593570  [high:rtti-vtable]  (orig: FUN_140593570)
void FUN_140593570(longlong param_1,undefined8 param_2,int param_3)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    return;
  }
  (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x2e0))
            ((longlong *)(lVar1 + 0x10),0x1d,(longlong)param_3,1,0);
  return;
}

// ==== CBoothActor@adapter::vfunc_21  @1405935c0  [high:rtti-vtable]  (orig: FUN_1405935c0)
void FUN_1405935c0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(
                      "CBoothActor::RecordEmoney, failed in record emoney, user:%u, type:%d, source:%d, number:%d"
                      );
    return;
  }
  FUN_1401742b0(lVar1,param_3,param_4,param_5,param_6);
  return;
}

// ==== CBoothActor@adapter::vfunc_22  @140593650  [high:rtti-vtable]  (orig: FUN_140593650)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_140593650(longlong param_1,uint param_2,undefined4 param_3)

{
  int iVar1;
  longlong lVar2;
  longlong lVar3;
  undefined8 uVar4;
  longlong *plVar5;
  
  plVar5 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
    plVar5 = (longlong *)0x0;
  }
  lVar2 = (**(code **)(*plVar5 + 0x60))(plVar5,param_3);
  if ((lVar2 != 0) && (iVar1 = FUN_1400fda10(lVar2,0xc,1), 0 < iVar1)) {
    lVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_2);
    if (lVar3 != 0) {
      FUN_1400fda10(lVar2,5,1);
      FUN_1400fda10(lVar2,4,1);
      FUN_1400fda10(lVar2,1,1);
      uVar4 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x18))((longlong *)(lVar3 + 0x10));
      tq::MyLogSave("gmlog/booth_additem",
                    "%s(%u)[%u] add item:[id=%u, type=%u], user_pro=%u, addtion_level=%d, dur=%d, max_dur=%d"
                    ,uVar4,(ulonglong)param_2);
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_50  @1405937c0  [high:rtti-vtable]  (orig: FUN_1405937c0)
void FUN_1405937c0(undefined8 param_1,undefined4 param_2,undefined8 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 != 0) {
    FUN_140109210(lVar1,param_3);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_23  @140593830  [high:rtti-vtable]  (orig: FUN_140593830)
void FUN_140593830(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x338))(lVar1 + 0x10);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_38  @140593860  [high:rtti-vtable]  (orig: FUN_140593860)
void FUN_140593860(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140104440(lVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_39  @1405938c0  [high:rtti-vtable]  (orig: FUN_1405938c0)
void FUN_1405938c0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_1400fda10(lVar1,param_3,1);
  return;
}

// ==== CBoothActor@adapter::vfunc_49  @140593940  [high:rtti-vtable]  (orig: FUN_140593940)
void FUN_140593940(undefined8 param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_1400fda10(lVar1,0xc,1);
  return;
}

// ==== CBoothActor@adapter::vfunc_40  @1405939b0  [high:rtti-vtable]  (orig: FUN_1405939b0)
void FUN_1405939b0(undefined8 param_1,undefined4 param_2,undefined4 param_3)

{
  longlong lVar1;
  longlong *plVar2;
  
  plVar2 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar2 = (longlong *)0x0;
  }
  lVar1 = (**(code **)(*plVar2 + 0x60))(plVar2,param_2);
  if (lVar1 == 0) {
    return;
  }
  FUN_140100430(lVar1,param_3);
  return;
}

// ==== CBoothActor@adapter::vfunc_55  @140593a30  [high:rtti-vtable]  (orig: FUN_140593a30)
void FUN_140593a30(undefined8 param_1,undefined4 param_2,undefined1 param_3)

{
  longlong *plVar1;
  
  plVar1 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar1 = (longlong *)0x0;
  }
                    /* WARNING: Could not recover jumptable at 0x000140593a8e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x30))(plVar1,param_2,param_3,0);
  return;
}

// ==== CBoothActor@adapter::vfunc_24  @140593aa0  [high:rtti-vtable]  (orig: FUN_140593aa0)
ulonglong FUN_140593aa0(longlong param_1)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  uVar2 = FUN_140162c40(lVar1);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_25  @140593b00  [high:rtti-vtable]  (orig: FUN_140593b00)
ulonglong FUN_140593b00(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined8 param_5)

{
  longlong *plVar1;
  ulonglong extraout_RAX;
  ulonglong uVar2;
  
  plVar1 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (plVar1 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
                    /* WARNING: Could not recover jumptable at 0x000140593b73. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar2 = (**(code **)(*plVar1 + 0x20))(plVar1,param_3,param_4,param_5);
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_26  @140593b80  [high:rtti-vtable]  (orig: FUN_140593b80)
void FUN_140593b80(longlong param_1,undefined8 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong lVar1;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  FUN_1401ca920(lVar1,param_3,param_4,0);
  return;
}

// ==== CBoothActor@adapter::vfunc_56  @140593c00  [high:rtti-vtable]  (orig: FUN_140593c00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140593c00(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar2 == 0) {
    local_478 = 0x37f;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = 0;
  }
  else {
    FUN_1400f83e0(local_458);
    local_478 = param_6;
    iVar1 = FUN_1400f8490(local_458,param_3,param_4,param_5);
    if (iVar1 != 0) {
      (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x348))((longlong *)(lVar2 + 0x10),local_458,1);
    }
    FUN_1400f8430(local_458);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CBoothActor@adapter::vfunc_57  @140593ce0  [high:rtti-vtable]  (orig: FUN_140593ce0)
ulonglong FUN_140593ce0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                       undefined4 param_5,undefined4 param_6,undefined8 param_7)

{
  longlong lVar1;
  ulonglong extraout_RAX;
  longlong lVar2;
  ulonglong extraout_RAX_00;
  ulonglong uVar3;
  longlong *plVar4;
  
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    plVar4 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    lVar2 = (**(code **)(*plVar4 + 0x60))(plVar4,param_3);
    if (lVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar3 = extraout_RAX_00 & 0xffffffffffffff00;
    }
    else {
      plVar4 = DAT_140975b60;
      if (DAT_140975b60 == (longlong *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        plVar4 = (longlong *)0x0;
      }
      uVar3 = (**(code **)(*plVar4 + 0x140))(plVar4,lVar1,lVar2,param_4,param_5,param_6,param_7);
    }
    return uVar3;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return extraout_RAX & 0xffffffffffffff00;
}

// ==== CBoothActor@adapter::vfunc_0  @140593e50  [high:rtti-vtable]  (orig: FUN_140593e50)
void FUN_140593e50(longlong param_1)

{
  FUN_140593eb0(param_1 + -8);
  return;
}

// ==== CBoothActor@adapter::helper_140593eb0  @140593eb0  [medium:callgraph-r0]  (orig: FUN_140593eb0)
undefined8 * FUN_140593eb0(undefined8 *param_1,byte param_2)

{
  *param_1 = adapter::CBoothActor::vftable;
  param_1[1] = adapter::CBoothActor::vftable;
  param_1[1] = adapter::IActor::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CBoothActor@adapter::vfunc_4  @140593fb0  [high:rtti-vtable]  (orig: FUN_140593fb0)
void FUN_140593fb0(longlong param_1,undefined4 param_2,undefined4 param_3,longlong param_4)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_3)
  ;
  if (plVar2 != (longlong *)0x0) {
    lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))
                      (*(longlong **)(param_1 + 0x10),param_2);
    if (lVar1 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                             *(undefined2 *)(param_4 + 10),param_4 + 0xc,
                             *(undefined2 *)(param_4 + 8),0,uVar4);
      if (puVar3 == (undefined8 *)0x0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*plVar2 + 0x350))(plVar2,puVar3);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_5  @1405940f0  [high:rtti-vtable]  (orig: FUN_1405940f0)
void FUN_1405940f0(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar3);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x350))((longlong *)(lVar1 + 0x10),puVar2);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_27  @1405941b0  [high:rtti-vtable]  (orig: FUN_1405941b0)
bool FUN_1405941b0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  return lVar1 != 0;
}

// ==== CBoothActor@adapter::vfunc_0  @140594230  [high:rtti-vtable]  (orig: FUN_140594230)
void FUN_140594230(longlong param_1,undefined8 param_2,longlong param_3)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    puVar2 = (undefined8 *)
             FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                           *(undefined2 *)(param_3 + 10),param_3 + 0xc,*(undefined2 *)(param_3 + 8),
                           0,uVar4);
    if (puVar2 == (undefined8 *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar3 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      (**(code **)(*plVar3 + 0x68))(plVar3,puVar2,0xffffffff);
      (**(code **)*puVar2)(puVar2,1);
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_1  @140594320  [high:rtti-vtable]  (orig: FUN_140594320)
void FUN_140594320(longlong param_1,undefined4 param_2,longlong param_3,int param_4)

{
  longlong lVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  undefined8 uVar4;
  
  uVar4 = 0xfffffffffffffffe;
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(lVar1 + 0x88) + 0x20))(*(longlong **)(lVar1 + 0x88),param_2)
  ;
  if (plVar2 != (longlong *)0x0) {
    lVar1 = (**(code **)(*plVar2 + 0x2b0))(plVar2);
    if (lVar1 != 0) {
      puVar3 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),0,*(undefined2 *)(param_3 + 10),
                             param_3 + 0xc,*(undefined2 *)(param_3 + 8),0,uVar4);
      if (puVar3 != (undefined8 *)0x0) {
        (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x348))
                  ((longlong *)(lVar1 + 0x10),puVar3,param_4 == 0);
        (**(code **)*puVar3)(puVar3,1);
      }
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_3  @140594430  [high:rtti-vtable]  (orig: FUN_140594430)
void FUN_140594430(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,longlong param_6)

{
  longlong lVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  
  uVar5 = 0xfffffffffffffffe;
  lVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar1 != 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar2 + 0x98) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                       (*(longlong **)(lVar2 + 0x98),param_3,0);
    if (plVar3 != (longlong *)0x0) {
      puVar4 = (undefined8 *)
               FUN_1402ba310(*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(lVar1 + 0x122c),
                             *(undefined2 *)(param_6 + 10),param_6 + 0xc,
                             *(ushort *)(param_6 + 8) - 4,0,uVar5);
      if (puVar4 != (undefined8 *)0x0) {
        (**(code **)(*plVar3 + 0x28))(plVar3,param_4,param_5,puVar4);
        (**(code **)*puVar4)(puVar4,1);
      }
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_2  @140594550  [high:rtti-vtable]  (orig: FUN_140594550)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140594550(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,longlong param_6,longlong param_7)

{
  int iVar1;
  longlong lVar2;
  undefined8 uVar3;
  longlong *plVar4;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
  if ((param_6 != 0) && (param_7 != 0)) {
    lVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
    if (lVar2 != 0) {
      uVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      plVar4 = (longlong *)FUN_1400876b0(uVar3);
      plVar4 = (longlong *)(**(code **)(*plVar4 + 0x10))(plVar4,param_3,0);
      if (plVar4 != (longlong *)0x0) {
        FUN_14015b240();
        local_4a8 = 1;
        local_4b0 = 0;
        local_4b8 = 0;
        local_4c0 = 0;
        local_4c8 = 0x838;
        local_4d0 = 0xffffff;
        local_4d8 = 0;
        iVar1 = FUN_14015b300(local_488,param_6,"ALLUSERS",param_7);
        if (iVar1 != 0) {
          (**(code **)(*plVar4 + 0x28))(plVar4,param_4,param_5,local_488);
        }
        FUN_14015b2c0(local_488);
      }
    }
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_63  @140594680  [high:rtti-vtable]  (orig: FUN_140594680)
void FUN_140594680(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x0001405946e1. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 0xd0))(*(longlong **)(lVar1 + 0x98),param_2);
  return;
}

// ==== CBoothActor@adapter::vfunc_64  @1405946f0  [high:rtti-vtable]  (orig: FUN_1405946f0)
void FUN_1405946f0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
                    /* WARNING: Could not recover jumptable at 0x000140594744. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(longlong **)(lVar1 + 0x98) + 200))();
  return;
}

// ==== CBoothActor@adapter::vfunc_29  @140594750  [high:rtti-vtable]  (orig: FUN_140594750)
void FUN_140594750(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined8 param_6)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 != 0) {
    FUN_1402c8370(lVar1,param_3,param_4,param_5,param_6);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_30  @140594800  [high:rtti-vtable]  (orig: FUN_140594800)
void FUN_140594800(longlong param_1,undefined4 param_2,longlong param_3,undefined1 param_4)

{
  longlong lVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 != 0) {
    FUN_1402c90f0(lVar1,param_3,param_4);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_31  @1405948e0  [high:rtti-vtable]  (orig: FUN_1405948e0)
void FUN_1405948e0(longlong param_1,undefined4 param_2,longlong param_3,undefined4 param_4)

{
  longlong lVar1;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,1);
  if (lVar1 != 0) {
    FUN_1402c9300(lVar1,param_3,param_4);
  }
  return;
}

// ==== CBoothActor@adapter::vfunc_37  @1405949c0  [high:rtti-vtable]  (orig: FUN_1405949c0)
undefined1 FUN_1405949c0(undefined8 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar3 = (**(code **)(*plVar4 + 0x60))(plVar4,param_2);
  if (lVar3 != 0) {
    uVar1 = FUN_1400fda10(lVar3,1,1);
    iVar2 = FUN_1400ff680(uVar1);
    if (iVar2 == 9) {
      uVar1 = FUN_1400fda10(lVar3,1,1);
      iVar2 = FUN_1400fecd0(uVar1);
      if (iVar2 == 80000) {
        return 1;
      }
    }
    return 0;
  }
  return 0;
}

// ==== CBoothActor@adapter::vfunc_28  @140594a70  [high:rtti-vtable]  (orig: FUN_140594a70)
uint FUN_140594a70(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0x98) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar1 = (**(code **)(**(longlong **)(lVar1 + 0x98) + 0x10))
                    (*(longlong **)(lVar1 + 0x98),param_2,0);
  if (lVar1 == 0) {
    return 0;
  }
  plVar2 = *(longlong **)(*(longlong *)(lVar1 + 0x58) + 8);
  plVar2 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
  uVar3 = (**(code **)(*plVar2 + 0x58))(plVar2);
  return (uint)(uVar3 >> 4) & 1;
}

// ==== CBoothActor@adapter::vfunc_32  @140594b10  [high:rtti-vtable]  (orig: FUN_140594b10)
bool FUN_140594b10(longlong param_1,undefined8 param_2,int param_3,int param_4)

{
  longlong *plVar1;
  byte bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong local_res8;
  
  lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x98))();
  if (lVar6 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  plVar1 = (longlong *)(lVar6 + 0x10);
  iVar4 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x40))(plVar1);
  if (param_3 != iVar4 + 1) {
    iVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
    if (param_4 != iVar4) {
      return false;
    }
  }
  lVar6 = (**(code **)(*plVar1 + 0x160))(plVar1);
  if (lVar6 != 0) {
    plVar7 = *(longlong **)(*(longlong *)(lVar6 + 0x58) + 8);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,4);
    bVar2 = (**(code **)(*plVar7 + 0x58))(plVar7);
    if ((bVar2 >> 4 & 1) != 0) {
      local_res8 = 0;
      uVar5 = (**(code **)(*plVar1 + 0x48))(plVar1);
      iVar4 = (**(code **)(*plVar1 + 0x40))(plVar1);
      cVar3 = FUN_1402c8370(lVar6,iVar4 + -2,uVar5,0x1040,&local_res8);
      if ((cVar3 != '\0') && (local_res8 != 0)) {
        iVar4 = (**(code **)(**(longlong **)(local_res8 + 0x60) + 0x10))
                          (*(longlong **)(local_res8 + 0x60),4);
        if (iVar4 == 0x10) {
          local_res8 = 0;
          cVar3 = FUN_1402c8370(lVar6,param_3,param_4,0x1040,&local_res8);
          if (cVar3 == '\0') {
            cVar3 = FUN_1402c8370(lVar6,param_3,param_4,0x1200,&local_res8);
            return cVar3 == '\0';
          }
        }
      }
    }
  }
  return false;
}

// ==== CBoothActor@adapter::vfunc_66  @140594cc0  [high:rtti-vtable]  (orig: FUN_140594cc0)
void FUN_140594cc0(longlong param_1)

{
  undefined8 uVar1;
  
  uVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  FUN_14008a710(uVar1);
  return;
}

// ==== CBoothActor@adapter::vfunc_58  @140594ce0  [high:rtti-vtable]  (orig: FUN_140594ce0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140594ce0(longlong param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  int iVar1;
  longlong lVar2;
  longlong *plVar3;
  undefined8 uVar4;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x98) == 0) {
    local_488 = 0x131;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x98) + 0x10))
                     (*(longlong **)(lVar2 + 0x98),param_3,0);
  uVar4 = 0;
  if (plVar3 != (longlong *)0x0) {
    FUN_14037d4a0(local_468);
    local_488 = 0;
    iVar1 = FUN_14037d520(local_468,2,param_2);
    if (iVar1 == 0) {
      FUN_14037d4f0(local_468);
      uVar4 = 0;
    }
    else {
      (**(code **)(*plVar3 + 0x28))(plVar3,param_4,param_5,local_468);
      FUN_14037d4f0(local_468);
      uVar4 = 1;
    }
  }
  return uVar4;
}

// ==== CBoothActor@adapter::vfunc_59  @140594df0  [high:rtti-vtable]  (orig: FUN_140594df0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140594df0(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
             undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
             longlong param_13)

{
  int iVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  longlong local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_13 == 0) {
    uVar2 = 0;
  }
  else {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0x98) == 0) {
      local_4b8 = 0x131;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x98) + 0x10))
                       (*(longlong **)(lVar3 + 0x98),param_3,0);
    uVar2 = 0;
    if (plVar4 != (longlong *)0x0) {
      FUN_140454910(local_478);
      local_498 = param_13;
      local_4a0 = param_12;
      local_4a8 = param_11;
      local_4b0 = param_10;
      local_4b8 = param_9;
      iVar1 = FUN_140454b00(local_478,param_6,param_7,param_8);
      if (iVar1 == 0) {
        FUN_140454990(local_478);
        uVar2 = 0;
      }
      else {
        (**(code **)(*plVar4 + 0x28))(plVar4,param_4,param_5,local_478);
        FUN_140454990(local_478);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_60  @140594f50  [high:rtti-vtable]  (orig: FUN_140594f50)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8
FUN_140594f50(longlong param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
             undefined4 param_9,undefined4 param_10,undefined4 param_11,undefined4 param_12,
             longlong param_13)

{
  int iVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  longlong local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (param_13 == 0) {
    uVar2 = 0;
  }
  else {
    lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
    if (*(longlong *)(lVar3 + 0x88) == 0) {
      local_4c8 = 0x12f;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)(lVar3 + 0x88) + 0x20))
                       (*(longlong **)(lVar3 + 0x88),param_3);
    uVar2 = 0;
    if (plVar4 != (longlong *)0x0) {
      FUN_140456560(local_478);
      local_498 = param_13;
      local_4a0 = param_12;
      local_4a8 = param_11;
      local_4b0 = param_10;
      local_4b8 = param_9;
      local_4c0 = param_8;
      local_4c8 = param_7;
      iVar1 = FUN_140456620(local_478,param_4,param_5,param_6);
      if (iVar1 == 0) {
        FUN_1404565e0(local_478);
        uVar2 = 0;
      }
      else {
        (**(code **)(*plVar4 + 0x350))(plVar4,local_478);
        FUN_1404565e0(local_478);
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CBoothActor@adapter::vfunc_67  @1405950c0  [high:rtti-vtable]  (orig: FUN_1405950c0)
void FUN_1405950c0(longlong param_1)

{
  longlong lVar1;
  
  lVar1 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar1 + 0xb0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_140006cc0(*(undefined8 *)(lVar1 + 0xb0));
  return;
}

