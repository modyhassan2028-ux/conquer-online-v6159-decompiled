// ==== CMsgIPADPaymentsClient::helper_140179220  @140179220  [medium:callgraph-r0]  (orig: FUN_140179220)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140179220(longlong *param_1,undefined4 param_2,byte param_3,char *param_4,ushort param_5,
                  char *param_6)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4b8 [32];
  undefined4 *local_498;
  uint local_490;
  char *local_488;
  uint local_480;
  undefined8 local_478;
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  byte local_45c;
  char local_45b [33];
  ushort local_43a;
  char local_438 [1008];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  uVar2 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008abd0(uVar2);
  if (cVar1 != '\0') {
    local_468 = local_468 & 0xffffff00;
    memset((void *)((longlong)&local_468 + 1),0,0x417);
    local_468 = (**(code **)(*param_1 + 8))(param_1);
    local_464 = (undefined4)param_1[0x1e2];
    local_460 = param_2;
    local_45c = param_3;
    strncpy(local_45b,param_4,0x20);
    local_43a = param_5;
    strncpy(local_438,param_6,900);
    lVar3 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar3 + 0x80) == 0) {
      local_498 = (undefined4 *)CONCAT44(local_498._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    else {
      plVar4 = *(longlong **)(lVar3 + 0x80);
    }
    local_498 = &local_468;
    cVar1 = (**(code **)(*plVar4 + 0x50))(plVar4,9,0x186a1,0x418);
    if (cVar1 == '\0') {
      (**(code **)(*param_1 + 8))(param_1);
      local_480 = (uint)param_5;
      local_490 = (uint)param_3;
      local_498 = (undefined4 *)CONCAT44(local_498._4_4_,param_2);
      local_488 = param_4;
      tq::MyLogSave("gmlog/IPADPayments",
                    "send payments message to port failure,iduser:[%u],idacount:[%u],unServerID:[%u],ismessageend:[%d],szTransactionId:%s,usSerialNumber:%u"
                   );
    }
  }
  return;
}

// ==== CMsgIPADPaymentsClient::helper_1401794e0  @1401794e0  [medium:callgraph-r0]  (orig: FUN_1401794e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401794e0(longlong *param_1,undefined4 param_2,byte param_3,char *param_4,ushort param_5,
                  char *param_6)

{
  char cVar1;
  undefined8 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_4b8 [32];
  undefined4 *local_498;
  uint local_490;
  char *local_488;
  uint local_480;
  undefined8 local_478;
  undefined4 local_468;
  undefined4 local_464;
  undefined4 local_460;
  byte local_45c;
  char local_45b [33];
  ushort local_43a;
  char local_438 [1008];
  ulonglong local_48;
  
  local_478 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  uVar2 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_14008abe0(uVar2);
  if (cVar1 != '\0') {
    local_468 = local_468 & 0xffffff00;
    memset((void *)((longlong)&local_468 + 1),0,0x417);
    local_468 = (**(code **)(*param_1 + 8))(param_1);
    local_464 = (undefined4)param_1[0x1e2];
    local_460 = param_2;
    local_45c = param_3;
    strncpy(local_45b,param_4,0x20);
    local_43a = param_5;
    strncpy(local_438,param_6,900);
    lVar3 = FUN_140008520((int)param_1[0x246]);
    if (*(longlong *)(lVar3 + 0x80) == 0) {
      local_498 = (undefined4 *)CONCAT44(local_498._4_4_,0x140);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar4 = (longlong *)0x0;
    }
    else {
      plVar4 = *(longlong **)(lVar3 + 0x80);
    }
    local_498 = &local_468;
    cVar1 = (**(code **)(*plVar4 + 0x50))(plVar4,0xd,0x186a3,0x418);
    if (cVar1 == '\0') {
      (**(code **)(*param_1 + 8))(param_1);
      local_480 = (uint)param_5;
      local_490 = (uint)param_3;
      local_498 = (undefined4 *)CONCAT44(local_498._4_4_,param_2);
      local_488 = param_4;
      tq::MyLogSave("gmlog/GooglePayments",
                    "send payments message to port failure,iduser:[%u],idacount:[%u],unServerID:[%u],ismessageend:[%d],szTransactionId:%s,usSerialNumber:%u"
                   );
    }
  }
  return;
}

// ==== CMsgIPADPaymentsClient::ctor_or_dtor  @1403b6e00  [high:vtable-assign]  (orig: FUN_1403b6e00)
undefined8 * FUN_1403b6e00(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgIPADPaymentsClient::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgIPADPaymentsClient::ctor_or_dtor  @1403b6e50  [high:vtable-assign]  (orig: FUN_1403b6e50)
void FUN_1403b6e50(undefined8 *param_1)

{
  *param_1 = CMsgIPADPaymentsClient::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgIPADPaymentsClient::vfunc_1  @1403b6e80  [high:rtti-vtable]  (orig: FUN_1403b6e80)
ulonglong FUN_1403b6e80(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x8b4);
}

// ==== CMsgIPADPaymentsClient::helper_1403b6eb0  @1403b6eb0  [medium:callgraph-r0]  (orig: FUN_1403b6eb0)
undefined8 FUN_1403b6eb0(longlong param_1,undefined4 param_2,char *param_3)

{
  FUN_1402b5600();
  **(undefined4 **)(param_1 + 0x428) = param_2;
  strncpy((char *)(*(longlong *)(param_1 + 0x428) + 0x10),param_3,0x20);
  *(undefined4 *)(param_1 + 8) = 0x8b4;
  *(undefined4 *)(param_1 + 0xc) = 0x37;
  return 1;
}

// ==== CMsgIPADPaymentsClient::ctor_or_dtor  @1403b7030  [high:vtable-assign]  (orig: FUN_1403b7030)
undefined8 * FUN_1403b7030(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgIPADPaymentsClient::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgIPADPaymentsClient::vfunc_3  @1403b7080  [high:rtti-vtable]  (orig: FUN_1403b7080)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b7080(longlong param_1)

{
  byte bVar1;
  uint uVar2;
  uint *puVar3;
  int *piVar4;
  char cVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined1 auStack_848 [32];
  uint local_828;
  undefined1 *local_820;
  uint *local_818;
  uint local_810;
  longlong *local_808;
  undefined8 local_800;
  undefined1 local_7f8 [1072];
  undefined1 local_3c8 [912];
  ulonglong local_38;
  
  local_800 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_848;
  if (*(longlong *)(param_1 + 0x428) != 0) {
    uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar7 = (longlong *)FUN_1400875f0(uVar6);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x18))(plVar7,param_1,0);
    if (plVar7 != (longlong *)0x0) {
      local_808 = (longlong *)0x0;
      (**(code **)(*plVar7 + 0x298))(plVar7,0x1001,&local_808);
      plVar7 = local_808;
      if (local_808 != (longlong *)0x0) {
        puVar3 = *(uint **)(param_1 + 0x428);
        if (*(int *)((longlong)puVar3 + 0x33) < 0x385) {
          memset(local_3c8,0,900);
          memcpy(local_3c8,(void *)((longlong)puVar3 + 0x37),
                 (longlong)*(int *)((longlong)puVar3 + 0x33));
          uVar2 = *puVar3;
          if (uVar2 < 4) {
            uVar2 = puVar3[0xc];
            bVar1 = *(byte *)((longlong)puVar3 + 0x32);
            (**(code **)(*plVar7 + 8))(plVar7);
            local_810 = (uint)(ushort)uVar2;
            local_820 = (undefined1 *)CONCAT44(local_820._4_4_,(uint)bVar1);
            local_828 = puVar3[1];
            local_818 = puVar3 + 4;
            tq::MyLogSave("gmlog/IPADPayments",
                          "receive payments message from client succeed,iduser:[%u],idacount:[%u],unServerID:[%u],ismessageend:[%d],szTransactionId:%s,usSerialNumber:%u"
                         );
            if (*(char *)(*(longlong *)(param_1 + 0x428) + 0x32) != '\0') {
              FUN_1403b6e00(local_7f8);
              cVar5 = FUN_1403b6eb0(local_7f8,3,*(longlong *)(param_1 + 0x428) + 0x10);
              if (cVar5 != '\0') {
                (**(code **)(local_808[2] + 0x350))(local_808 + 2,local_7f8);
              }
              FUN_1403b6e50(local_7f8);
            }
            piVar4 = *(int **)(param_1 + 0x428);
            if (*piVar4 == 0) {
              local_820 = local_3c8;
              local_828 = CONCAT22(local_828._2_2_,(short)piVar4[0xc]);
              FUN_140179220(local_808,piVar4[1],*(undefined1 *)((longlong)piVar4 + 0x32),piVar4 + 4)
              ;
            }
            else {
              tq::MyLogSave("gmlog/IPADPayments",
                            "receive message from client, the message action[%u] is wrong action,the right action is[%u]"
                           );
            }
          }
          else if ((uVar2 < 4) || (6 < uVar2)) {
            log_InlineLogERROR("CMsgIPADPaymentsClient::Process. Action[%u]");
          }
          else {
            uVar2 = puVar3[0xc];
            bVar1 = *(byte *)((longlong)puVar3 + 0x32);
            (**(code **)(*plVar7 + 8))(plVar7);
            local_810 = (uint)(ushort)uVar2;
            local_820 = (undefined1 *)CONCAT44(local_820._4_4_,(uint)bVar1);
            local_828 = puVar3[1];
            local_818 = puVar3 + 4;
            tq::MyLogSave("gmlog/GooglePayments",
                          "receive payments message from client succeed,iduser:[%u],idacount:[%u],unServerID:[%u],ismessageend:[%d],szTransactionId:%s,usSerialNumber:%u"
                         );
            if (*(char *)(*(longlong *)(param_1 + 0x428) + 0x32) != '\0') {
              FUN_1403b6e00(local_7f8);
              cVar5 = FUN_1403b6eb0(local_7f8,7,*(longlong *)(param_1 + 0x428) + 0x10);
              if (cVar5 != '\0') {
                (**(code **)(local_808[2] + 0x350))(local_808 + 2,local_7f8);
              }
              FUN_1403b6e50(local_7f8);
            }
            piVar4 = *(int **)(param_1 + 0x428);
            if (*piVar4 == 4) {
              local_820 = local_3c8;
              local_828 = CONCAT22(local_828._2_2_,(short)piVar4[0xc]);
              FUN_1401794e0(local_808,piVar4[1],*(undefined1 *)((longlong)piVar4 + 0x32),piVar4 + 4)
              ;
            }
            else {
              tq::MyLogSave("gmlog/GooglePayments",
                            "receive message from client, the message action[%u] is wrong action,the right action is[%u]"
                           );
            }
          }
        }
        else {
          log_InlineLogERROR("CMsgIPADPaymentsClient::Process, BufSize[%d] > 900");
        }
      }
    }
  }
  return;
}

