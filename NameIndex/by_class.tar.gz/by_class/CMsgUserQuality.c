// ==== CMsgUserQuality::ctor_or_dtor  @14036fe70  [high:vtable-assign]  (orig: FUN_14036fe70)
undefined8 * FUN_14036fe70(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgUserQuality::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgUserQuality::ctor_or_dtor  @14036fec0  [high:vtable-assign]  (orig: FUN_14036fec0)
void FUN_14036fec0(undefined8 *param_1)

{
  *param_1 = CMsgUserQuality::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgUserQuality::vfunc_1  @14036fef0  [high:rtti-vtable]  (orig: FUN_14036fef0)
ulonglong FUN_14036fef0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x410);
}

// ==== CMsgUserQuality::ctor_or_dtor  @140370290  [high:vtable-assign]  (orig: FUN_140370290)
undefined8 * FUN_140370290(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgUserQuality::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgUserQuality::vfunc_3  @140370370  [high:rtti-vtable]  (orig: FUN_140370370)
void FUN_140370370(longlong param_1)

{
  longlong lVar1;
  undefined4 *puVar2;
  longlong lVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong *plVar7;
  undefined8 uVar8;
  longlong *plVar9;
  
  if (*(int *)(param_1 + 8) != 0x410) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar7 = (longlong *)
           (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x88))(*(longlong **)(lVar6 + 0x90),param_1)
  ;
  if (plVar7 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  plVar9 = (longlong *)FUN_140087650(uVar8);
  lVar6 = (**(code **)(*plVar9 + 0x98))(plVar9,*(undefined4 *)(*(longlong *)(param_1 + 0x428) + 4));
  if (lVar6 != 0) {
    plVar9 = (longlong *)FUN_1400e1e60();
    lVar3 = plVar7[0x1e2];
    lVar1 = *plVar9;
    puVar2 = *(undefined4 **)(param_1 + 0x428);
    uVar4 = (**(code **)(*plVar7 + 8))(plVar7);
    (**(code **)(lVar1 + 0x108))(plVar9,uVar4,(int)lVar3,*puVar2);
    iVar5 = FUN_1403702e0(param_1,lVar6);
    if (iVar5 != 0) {
      (**(code **)(plVar7[2] + 0x350))(plVar7 + 2,param_1);
    }
  }
  return;
}

