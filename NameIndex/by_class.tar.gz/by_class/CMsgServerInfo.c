// ==== CMsgServerInfo::ctor_or_dtor  @140077c40  [high:vtable-assign]  (orig: FUN_140077c40)
undefined8 * FUN_140077c40(undefined8 *param_1)

{
  FUN_1400763e0();
  *param_1 = CMsgServerInfo::vftable;
  FUN_1400752b0(param_1);
  param_1[0x84] = param_1 + 2;
  return param_1;
}

// ==== CMsgServerInfo::ctor_or_dtor  @140077c90  [high:vtable-assign]  (orig: FUN_140077c90)
void FUN_140077c90(undefined8 *param_1)

{
  *param_1 = CMsgServerInfo::vftable;
  FUN_1400752a0();
  return;
}

// ==== CMsgServerInfo::vfunc_1  @140077d20  [high:rtti-vtable]  (orig: FUN_140077d20)
ulonglong FUN_140077d20(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1400752f0();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x81f);
}

// ==== CMsgServerInfo::vfunc_3  @140077d50  [high:rtti-vtable]  (orig: FUN_140077d50)
void FUN_140077d50(void)

{
  return;
}

// ==== CMsgServerInfo::ctor_or_dtor  @140077d60  [high:vtable-assign]  (orig: FUN_140077d60)
undefined8 * FUN_140077d60(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgServerInfo::vftable;
  FUN_1400752a0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

