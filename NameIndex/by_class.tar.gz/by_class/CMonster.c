// ==== CMonster::helper_140013670  @140013670  [medium:callgraph-r1]  (orig: FUN_140013670)
int FUN_140013670(longlong param_1)

{
  ulong uVar1;
  
  uVar1 = tq::TimeGet(0);
  *(uint *)(param_1 + 4) = uVar1 / 1000;
  return uVar1 * 0x10624dd3;
}

// ==== CMonster::helper_140022290  @140022290  [medium:callgraph-r1]  (orig: FUN_140022290)
ulonglong FUN_140022290(int *param_1)

{
  ulong uVar1;
  ulonglong in_RAX;
  
  if (param_1[1] != 0) {
    uVar1 = tq::TimeGet(0);
    in_RAX = (ulonglong)(uint)(*param_1 + param_1[1]);
    if ((uint)(*param_1 + param_1[1]) <= uVar1 / 1000) {
      param_1[1] = 0;
      *param_1 = 0;
      return 1;
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMonster::helper_14008a720  @14008a720  [medium:callgraph-r1]  (orig: FUN_14008a720)
bool FUN_14008a720(longlong param_1)

{
  return *(int *)(param_1 + 0x29c) == 0;
}

// ==== CMonster::helper_14008af60  @14008af60  [medium:callgraph-r1]  (orig: FUN_14008af60)
undefined1 FUN_14008af60(longlong param_1)

{
  return *(undefined1 *)(param_1 + 0x2d0);
}

// ==== CMonster::helper_14008af70  @14008af70  [medium:callgraph-r1]  (orig: FUN_14008af70)
undefined4 FUN_14008af70(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x2d4);
}

// ==== CMonster::helper_14008b020  @14008b020  [medium:callgraph-r0]  (orig: FUN_14008b020)
undefined4 FUN_14008b020(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6ac);
}

// ==== CMonster::helper_14008b030  @14008b030  [medium:callgraph-r1]  (orig: FUN_14008b030)
undefined4 FUN_14008b030(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6b0);
}

// ==== CMonster::helper_14008b040  @14008b040  [medium:callgraph-r1]  (orig: FUN_14008b040)
void FUN_14008b040(longlong param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                  undefined4 *param_5)

{
  *param_2 = *(undefined4 *)(param_1 + 0x6b4);
  *param_3 = *(undefined4 *)(param_1 + 0x6b8);
  *param_4 = *(undefined4 *)(param_1 + 0x6bc);
  *param_5 = *(undefined4 *)(param_1 + 0x6c0);
  return;
}

// ==== CMonster::helper_14008b070  @14008b070  [medium:callgraph-r1]  (orig: FUN_14008b070)
undefined4 FUN_14008b070(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x6c4);
}

// ==== CMonster::helper_1400a3410  @1400a3410  [medium:callgraph-r2]  (orig: FUN_1400a3410)
longlong * FUN_1400a3410(longlong param_1,longlong *param_2,uint *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  ldiv_t lVar4;
  ulonglong uVar5;
  longlong lVar6;
  longlong lVar7;
  int local_res8;
  undefined8 *puStack_40;
  
  lVar4 = ldiv((*param_3 ^ 0xdeadbeef) & 0x7fffffff,0x1f31d);
  local_res8 = lVar4.quot;
  iVar3 = lVar4.rem * 0x41a7 + local_res8 * -0xb14;
  if (iVar3 < 0) {
    iVar3 = iVar3 + 0x7fffffff;
  }
  uVar5 = (longlong)iVar3 & *(ulonglong *)(param_1 + 0x78);
  if (*(ulonglong *)(param_1 + 0x80) <= uVar5) {
    uVar5 = uVar5 + (-1 - (*(ulonglong *)(param_1 + 0x78) >> 1));
  }
  if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5) {
    _invalid_parameter_noinfo();
  }
  plVar1 = (longlong *)(param_1 + 0x10);
  puStack_40 = *(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + uVar5 * 0x10);
  if (plVar1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  plVar2 = (longlong *)*plVar1;
  lVar6 = 0;
  while( true ) {
    if ((ulonglong)(*(longlong *)(param_1 + 0x68) - *(longlong *)(param_1 + 0x60) >> 4) <= uVar5 + 1
       ) {
      _invalid_parameter_noinfo();
    }
    if (*(undefined8 **)(*(longlong *)(param_1 + 0x60) + 8 + (uVar5 + 1) * 0x10) == puStack_40) {
      param_2[1] = *(longlong *)(param_1 + 0x38);
      *param_2 = *plVar1;
      return param_2;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    if (*param_3 <= *(uint *)(puStack_40 + 2)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar6;
    }
    else {
      lVar7 = *plVar2;
    }
    if (puStack_40 == *(undefined8 **)(lVar7 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    puStack_40 = (undefined8 *)*puStack_40;
  }
  if (plVar2 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  else {
    lVar6 = *plVar2;
  }
  if (puStack_40 == *(undefined8 **)(lVar6 + 0x28)) {
    _invalid_parameter_noinfo();
  }
  if (*param_3 < *(uint *)(puStack_40 + 2)) {
    lVar6 = *(longlong *)(param_1 + 0x38);
    *param_2 = *plVar1;
    param_2[1] = lVar6;
  }
  else {
    *param_2 = (longlong)plVar2;
    param_2[1] = (longlong)puStack_40;
  }
  return param_2;
}

// ==== CMonster::helper_1400a7cf0  @1400a7cf0  [medium:callgraph-r3]  (orig: FUN_1400a7cf0)
undefined4 FUN_1400a7cf0(longlong param_1,int param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined4 uVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar8 = (undefined8 *)(*(undefined8 **)(param_1 + 0x5f8))[1];
  cVar1 = *(char *)((longlong)puVar8 + 0x21);
  puVar3 = *(undefined8 **)(param_1 + 0x5f8);
  while (cVar1 == '\0') {
    if (*(int *)(puVar8 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar8[2];
      puVar8 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar8;
    }
    puVar3 = puVar8;
    puVar8 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x21);
  }
  puVar8 = *(undefined8 **)(param_1 + 0x5f8);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 0x5c8);
  if (*(longlong *)(param_1 + 0x5c8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar8) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x5f8);
    local_28 = *(longlong *)(param_1 + 0x5c8);
  }
  else {
    plVar7 = &local_38;
  }
  plVar2 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x5f8);
  local_18 = plVar2;
  local_10 = plVar7[1];
  if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 0x5c8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar9) {
    uVar5 = 0;
  }
  else {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar2;
    }
    if (lVar4 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar5 = *(undefined4 *)(lVar4 + 0x1c);
  }
  return uVar5;
}

// ==== CMonster::helper_1400a84d0  @1400a84d0  [medium:callgraph-r3]  (orig: FUN_1400a84d0)
longlong * FUN_1400a84d0(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x25) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x25) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMonster::helper_1400b29c0  @1400b29c0  [medium:callgraph-r1]  (orig: FUN_1400b29c0)
longlong FUN_1400b29c0(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  undefined4 local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  local_res10[0] = param_2;
  FUN_1400a3410(param_1 + 0x4b8,&local_18,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x4f0);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x4c8))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar1) {
    FUN_1400a3410(param_1 + 0x4b8,&local_18,local_res10);
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar1 = 0;
    }
    else {
      lVar1 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar1 + 0x28)) {
      _invalid_parameter_noinfo();
    }
    return local_10 + 0x18;
  }
  return 0;
}

// ==== CMonster::helper_1400b2a80  @1400b2a80  [medium:callgraph-r1]  (orig: FUN_1400b2a80)
bool FUN_1400b2a80(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  longlong lVar4;
  bool bVar5;
  int iVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar9 = *(undefined8 **)(param_1 + 0x578);
  cVar1 = *(char *)((longlong)puVar9[1] + 0x25);
  puVar2 = (undefined8 *)puVar9[1];
  while (cVar1 == '\0') {
    if ((*(int *)(puVar2 + 3) < param_2) ||
       ((*(int *)(puVar2 + 3) <= param_2 && (*(int *)((longlong)puVar2 + 0x1c) < param_3)))) {
      puVar7 = (undefined8 *)puVar2[2];
    }
    else {
      puVar7 = (undefined8 *)*puVar2;
      puVar9 = puVar2;
    }
    puVar2 = puVar7;
    cVar1 = *(char *)((longlong)puVar7 + 0x25);
  }
  puVar2 = *(undefined8 **)(param_1 + 0x578);
  local_30 = puVar9;
  local_38 = *(longlong *)(param_1 + 0x548);
  if (*(longlong *)(param_1 + 0x548) == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar9 == puVar2) || (param_2 < *(int *)(puVar9 + 3))) ||
     ((param_2 <= *(int *)(puVar9 + 3) && (param_3 < *(int *)((longlong)puVar9 + 0x1c))))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x578);
    local_28 = *(longlong *)(param_1 + 0x548);
  }
  else {
    plVar8 = &local_38;
  }
  plVar3 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x578);
  local_18 = plVar3;
  local_10 = plVar8[1];
  if ((plVar3 == (longlong *)0x0) || (plVar3 != *(longlong **)(param_1 + 0x548))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 == lVar10) {
    bVar5 = true;
  }
  else {
    iVar6 = tq::RandGet(100);
    if (plVar3 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar3;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    bVar5 = iVar6 < *(int *)(lVar4 + 0x20);
  }
  return bVar5;
}

// ==== CMonster::helper_1400b2bd0  @1400b2bd0  [medium:callgraph-r0]  (orig: FUN_1400b2bd0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_1400b2bd0(longlong param_1,int param_2,int param_3)

{
  char cVar1;
  uint uVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  undefined8 *puVar8;
  longlong lVar9;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  if ((param_2 == 0xe) || (param_2 == 0xd)) {
    param_2 = 10;
  }
  puVar8 = *(undefined8 **)(param_1 + 0x5b8);
  if (2 < param_3) {
    param_3 = 2;
  }
  cVar1 = *(char *)((longlong)puVar8[1] + 0x25);
  puVar3 = (undefined8 *)puVar8[1];
  while (cVar1 == '\0') {
    if ((*(int *)(puVar3 + 3) < param_2) ||
       ((*(int *)(puVar3 + 3) <= param_2 && (*(int *)((longlong)puVar3 + 0x1c) < param_3)))) {
      puVar6 = (undefined8 *)puVar3[2];
    }
    else {
      puVar6 = (undefined8 *)*puVar3;
      puVar8 = puVar3;
    }
    puVar3 = puVar6;
    cVar1 = *(char *)((longlong)puVar6 + 0x25);
  }
  puVar3 = *(undefined8 **)(param_1 + 0x5b8);
  local_30 = puVar8;
  local_38 = *(longlong *)(param_1 + 0x588);
  if (*(longlong *)(param_1 + 0x588) == 0) {
    _invalid_parameter_noinfo();
  }
  if (((puVar8 == puVar3) || (param_2 < *(int *)(puVar8 + 3))) ||
     ((param_2 <= *(int *)(puVar8 + 3) && (param_3 < *(int *)((longlong)puVar8 + 0x1c))))) {
    plVar7 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x5b8);
    local_28 = *(longlong *)(param_1 + 0x588);
  }
  else {
    plVar7 = &local_38;
  }
  plVar4 = (longlong *)*plVar7;
  lVar9 = *(longlong *)(param_1 + 0x5b8);
  local_18 = plVar4;
  local_10 = plVar7[1];
  if ((plVar4 == (longlong *)0x0) || (plVar4 != *(longlong **)(param_1 + 0x588))) {
    _invalid_parameter_noinfo();
  }
  lVar5 = local_10;
  if (local_10 != lVar9) {
    if (plVar4 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar9 = 0;
    }
    else {
      lVar9 = *plVar4;
    }
    if (lVar5 == *(longlong *)(lVar9 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar2 = *(uint *)(lVar5 + 0x20);
    if (uVar2 < 100) {
      if (uVar2 == 0) {
        return 0;
      }
      return (int)((_DAT_1406f9568 / (double)(int)uVar2) * _DAT_1406f9560);
    }
  }
  return 600000;
}

// ==== CMonster::helper_1400ffb50  @1400ffb50  [medium:callgraph-r3]  (orig: FUN_1400ffb50)
bool FUN_1400ffb50(longlong *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  uint uVar3;
  longlong *plVar4;
  
  plVar4 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar4 = (longlong *)0x0;
  }
  lVar1 = *plVar4;
  uVar2 = (**(code **)(*param_1 + 8))(param_1);
  uVar3 = (**(code **)(lVar1 + 200))(plVar4,uVar2);
  return 499 < uVar3;
}

// ==== CMonster::helper_140101140  @140101140  [medium:callgraph-r1]  (orig: FUN_140101140)
uint FUN_140101140(ulonglong param_1)

{
  uint uVar1;
  
  param_1 = param_1 & 0xffffffff;
  uVar1 = FUN_1400ff680();
  if (uVar1 == 4) {
    uVar1 = FUN_1400fecd0(param_1 & 0xffffffff);
    if (uVar1 == 40000) {
      return 0x9c01;
    }
  }
  return uVar1 & 0xffffff00;
}

// ==== CMonster::helper_1401013d0  @1401013d0  [medium:callgraph-r0]  (orig: FUN_1401013d0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

ulonglong FUN_1401013d0(undefined4 param_1,undefined4 *param_2,int param_3,undefined8 *param_4,
                       uint param_5)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined8 uVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined4 extraout_var;
  longlong lVar11;
  ulonglong uVar12;
  uint uVar13;
  uint uVar14;
  undefined4 uVar15;
  double dVar16;
  int local_98;
  uint local_88 [20];
  
  if (param_4 == (undefined8 *)0x0) {
    return 0;
  }
  if (param_5 == 0) {
    iVar2 = tq::RandGet(100);
    FUN_140008520(param_1);
    cVar1 = FUN_14008a720();
    if (cVar1 == '\0') {
      if (iVar2 < 0) {
        if (9 < iVar2) goto LAB_14010149c;
        if (0x1d < iVar2) goto LAB_1401014ad;
        if (0x3b < iVar2) goto LAB_1401014bb;
LAB_1401014c5:
        param_5 = 4;
      }
      else if (iVar2 < 10) {
        param_5 = 7;
      }
      else {
LAB_14010149c:
        if (iVar2 < 0x1e) {
          param_5 = 6;
        }
        else {
LAB_1401014ad:
          if (iVar2 < 0x3c) {
            param_5 = 5;
          }
          else {
LAB_1401014bb:
            if (0x59 < iVar2) goto LAB_1401014c5;
            param_5 = 3;
          }
        }
      }
    }
    else {
      param_5 = 3;
      if (-1 < iVar2) {
        param_5 = 5;
      }
      if ((0x1d < iVar2) && (param_5 = 3, iVar2 < 0x46)) {
        param_5 = 4;
      }
    }
  }
  iVar2 = 0x1e;
  local_98 = 0;
  iVar3 = 300;
  uVar8 = FUN_140008520(param_1);
  cVar1 = FUN_14008a720(uVar8);
  iVar5 = 0x14;
  iVar7 = 0x32;
  if (cVar1 == '\0') {
    iVar2 = 100;
    iVar3 = 0x96;
    iVar7 = 100;
    iVar5 = 0x32;
  }
  iVar4 = tq::RandGet(0x4b0);
  if (iVar4 < 0) {
    if (iVar5 <= iVar4) goto LAB_1401015c5;
LAB_14010161b:
    if ((iVar4 < iVar2 + iVar5) || (iVar7 + iVar2 + iVar5 <= iVar4)) {
      if ((iVar4 < iVar7 + iVar2 + iVar5) || (iVar3 + iVar7 + iVar2 + iVar5 <= iVar4)) {
        if ((iVar4 < iVar3 + iVar7 + iVar2 + iVar5) || (iVar3 * 2 + iVar7 + iVar2 + iVar5 <= iVar4))
        {
          iVar2 = tq::RandGet(100);
          uVar10 = CONCAT44(extraout_var,iVar2);
          if (iVar2 < 0) {
            if (0x13 < iVar2) goto LAB_1401018ab;
            if (0x27 < iVar2) goto LAB_1401018c0;
LAB_140101975:
            local_88[0] = 0x1fe;
            local_88[1] = 0x1ff;
            local_88[2] = 0x212;
            local_88[3] = 0x230;
            local_88[4] = 0x231;
            local_88[5] = 0x244;
            local_88[6] = 900;
            iVar2 = tq::RandGet(7);
            uVar13 = local_88[iVar2];
            if (uVar13 == 900) {
              tq::RandGet(7);
LAB_1401019d6:
              local_98 = tq::RandGet(7);
              local_98 = local_98 + 3;
              plVar9 = (longlong *)
                       (**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x20);
              uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
              uVar12 = uVar10 & 0xffffffff;
              goto LAB_14010185d;
            }
          }
          else {
            if (0x13 < iVar2) {
LAB_1401018ab:
              if (iVar2 < 0x28) goto LAB_1401018b0;
LAB_1401018c0:
              if (0x4f < iVar2) goto LAB_140101975;
              local_88[0] = 0x19a;
              local_88[1] = 0x1a4;
              local_88[3] = 0x1ae;
              local_88[4] = 0x1b8;
              local_88[2] = 0x1a5;
              local_88[5] = 0x1c2;
              local_88[6] = 0x1cc;
              local_88[7] = 0x1e0;
              local_88[8] = 0x1e1;
              local_88[9] = 0x1ea;
              local_88[10] = 500;
              local_88[0xb] = 0x259;
              local_88[0xc] = 0x262;
              local_88[0xd] = 0x263;
              local_88[0xe] = 0x264;
              local_88[0xf] = 0x265;
              local_88[0x10] = 0x269;
              iVar2 = tq::RandGet(0x11);
              uVar13 = local_88[iVar2];
              if (uVar13 != 900) goto LAB_140101836;
              goto LAB_1401019d6;
            }
            uVar13 = 0x1a5;
          }
LAB_140101836:
          plVar9 = (longlong *)
                   (**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x1f);
          uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
          uVar12 = uVar10 & 0xffffffff;
        }
        else {
          local_88[0] = 0x82;
          local_88[1] = 0x83;
          local_88[2] = 0x84;
          local_88[3] = 0x85;
          local_88[4] = 0x86;
          local_88[5] = 0x87;
          local_88[6] = 0x88;
          local_88[7] = 0x8a;
          local_88[8] = 0x8b;
          iVar2 = tq::RandGet(9);
          uVar13 = local_88[iVar2];
          local_98 = tq::RandGet(7);
          local_98 = local_98 + 3;
          plVar9 = (longlong *)
                   (**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x1d);
          uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
          uVar12 = uVar10 & 0xffffffff;
        }
      }
      else {
        local_88[0] = 0x6f;
        local_88[1] = 0x70;
        local_88[2] = 0x71;
        local_88[3] = 0x72;
        local_88[4] = 0x75;
        local_88[5] = 0x76;
        local_88[6] = 0x7b;
        local_88[7] = 0x8d;
        local_88[8] = 0x8e;
        local_88[9] = 0x8f;
        local_88[10] = 0x90;
        local_88[0xb] = 0x91;
        local_88[0xc] = 0x94;
        iVar2 = tq::RandGet(0xd);
        uVar13 = local_88[iVar2];
        local_98 = tq::RandGet(7);
        local_98 = local_98 + 3;
        plVar9 = (longlong *)(**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x1b);
        uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
        uVar12 = uVar10 & 0xffffffff;
      }
    }
    else {
      local_88[0] = 0x96;
      local_88[1] = 0x97;
      local_88[2] = 0x98;
      iVar2 = tq::RandGet(3);
      uVar13 = local_88[iVar2];
      plVar9 = (longlong *)(**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x1e);
      uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
      uVar12 = uVar10 & 0xffffffff;
    }
LAB_14010185d:
    if ((int)uVar12 == 99) goto LAB_1401018b0;
  }
  else {
    if (iVar5 <= iVar4) {
LAB_1401015c5:
      if (iVar2 + iVar5 <= iVar4) goto LAB_14010161b;
      local_88[0] = 0x78;
      local_88[1] = 0x79;
      iVar2 = tq::RandGet(2);
      uVar13 = local_88[iVar2];
      plVar9 = (longlong *)(**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x1c);
      uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
      uVar12 = uVar10 & 0xffffffff;
      goto LAB_14010185d;
    }
    local_88[0] = 0xa0;
    local_88[1] = 0xc9;
    local_88[2] = 0xca;
    local_88[3] = 0xcb;
    local_88[4] = 0xcc;
    iVar2 = tq::RandGet(5);
    uVar13 = local_88[iVar2];
    plVar9 = (longlong *)(**(code **)(*(longlong *)*param_4 + 0x10))((longlong *)*param_4,0x21);
    uVar10 = (**(code **)(*plVar9 + 0x48))(plVar9);
    uVar12 = uVar10 & 0xffffffff;
    if ((((uVar13 != 0xc9) && (uVar13 != 0xca)) && (uVar13 != 0xcb)) && (uVar13 != 0xcc))
    goto LAB_14010185d;
    if ((int)uVar10 == 99) goto LAB_1401018b0;
    uVar12 = 0;
  }
  uVar6 = (uint)uVar12;
  iVar2 = tq::RandGet(100);
  if (iVar2 < 0x32) {
    iVar2 = tq::RandGet((int)(uVar12 >> 1));
    uVar14 = iVar2 + (int)(uVar12 / 3);
    if (uVar14 != 0) {
      uVar14 = uVar14 - 1;
    }
  }
  else {
    uVar14 = uVar6;
    if (0x4f < iVar2) {
      if ((((uVar13 < 0x6e) || (0x72 < uVar13)) && ((uVar13 < 0x82 || (0x86 < uVar13)))) &&
         (99 < uVar13 - 900)) {
        uVar14 = 0x17;
        if (uVar6 + 1 < 0x17) {
          uVar14 = uVar6 + 1;
        }
      }
      else {
        uVar14 = 9;
        if (uVar6 + 1 < 9) {
          uVar14 = uVar6 + 1;
        }
      }
    }
  }
  iVar2 = param_5 + (uVar13 * 100 + uVar14) * 10;
  plVar9 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar9 = (longlong *)0x0;
  }
  lVar11 = (**(code **)(*plVar9 + 0x70))();
  uVar10 = 0;
  if (lVar11 != 0) {
    memset(param_2,0,100);
    *param_2 = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    param_2[1] = iVar2;
    plVar9 = (longlong *)
             (**(code **)(**(longlong **)(lVar11 + 8) + 0x10))(*(longlong **)(lVar11 + 8),0x16);
    iVar5 = (**(code **)(*plVar9 + 0x48))(plVar9);
    dVar16 = tq::RandomRateGet(_DAT_140708758);
    param_2[5] = (int)(dVar16 * (double)iVar5);
    if ((int)(dVar16 * (double)iVar5) < 1) {
      param_2[5] = 1;
    }
    if (param_5 < 6) {
      plVar9 = (longlong *)
               (**(code **)(**(longlong **)(lVar11 + 8) + 0x10))(*(longlong **)(lVar11 + 8),0xc);
      uVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
      iVar5 = param_2[5];
      uVar10 = (ulonglong)uVar6;
      if (uVar6 == 0) {
        uVar10 = 1;
      }
      iVar7 = (int)((uint)(iVar5 * param_3 * 3) / uVar10);
      param_2[4] = iVar7;
      if (iVar5 <= iVar7) {
        param_2[4] = iVar5;
      }
      if ((int)param_2[4] < 1) {
        param_2[4] = 1;
      }
    }
    else {
      iVar5 = tq::RandGet(0x32);
      param_2[4] = ((iVar5 + 0x32) * param_2[5]) / 100;
    }
    if (iVar2 - 400000U < 199999) {
      iVar5 = tq::RandGet(100);
      if (iVar5 < 5) {
        param_2[9] = 0xff;
        param_2[10] = 0xff;
      }
      else if (iVar5 < 0x14) {
        param_2[9] = 0xff;
      }
    }
    iVar7 = 300;
    iVar5 = tq::RandGet(300);
    if (iVar5 == 0x7b) {
      param_2[0xd] = 1;
    }
    if ((param_2[9] != 0xff) && (param_2[10] != 0xff)) {
      cVar1 = FUN_140101140(iVar2);
      if (cVar1 != '\0') {
        iVar7 = 0x3c;
      }
      iVar2 = tq::RandGet(iVar7);
      if (iVar2 == 0xd) {
        iVar2 = tq::RandGet(100);
        uVar15 = 5;
        if (iVar2 < 0x46) {
          uVar15 = 3;
        }
        param_2[0xe] = uVar15;
      }
    }
    *(short *)(param_2 + 0x13) = (short)local_98;
    *(undefined2 *)(param_2 + 0x12) = 0;
    *(undefined2 *)((longlong)param_2 + 0x4a) = 0;
    if ((((uVar13 == 0xc9) || (uVar13 == 0xca)) || (uVar13 == 0xcb)) || (uVar13 == 0xcc)) {
      param_2[0xe] = 0;
    }
    param_2[0x18] = 1;
    return (ulonglong)CONCAT31((int3)((uint)local_98 >> 8),1);
  }
LAB_1401018b0:
  return uVar10 & 0xffffffffffffff00;
}

// ==== CMonster::helper_140118a20  @140118a20  [medium:callgraph-r0]  (orig: FUN_140118a20)
undefined4 FUN_140118a20(undefined8 param_1,int param_2)

{
  return CONCAT31((int3)(param_2 - 9700000U >> 8),param_2 - 9700000U < 100000);
}

// ==== CMonster::helper_14014daf0  @14014daf0  [medium:callgraph-r2]  (orig: FUN_14014daf0)
longlong * FUN_14014daf0(longlong *param_1,longlong *param_2,ushort *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x21) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(ushort *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x21) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(ushort *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMonster::helper_1401594f0  @1401594f0  [medium:callgraph-r1]  (orig: FUN_1401594f0)
longlong FUN_1401594f0(longlong param_1)

{
  if (param_1 != 0) {
    return param_1 + 0x10;
  }
  return 0;
}

// ==== CMonster::helper_14015fba0  @14015fba0  [medium:callgraph-r3]  (orig: FUN_14015fba0)
int FUN_14015fba0(uint param_1)

{
  if (0xff < param_1) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return param_1 + 10000;
}

// ==== CMonster::helper_140166eb0  @140166eb0  [medium:callgraph-r0]  (orig: FUN_140166eb0)
undefined4 FUN_140166eb0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x11e0);
}

// ==== CMonster::helper_1401671e0  @1401671e0  [medium:callgraph-r1]  (orig: FUN_1401671e0)
undefined8 FUN_1401671e0(undefined8 param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (int)param_2 - (int)param_1;
  iVar2 = (int)((ulonglong)param_2 >> 0x20) - (int)((ulonglong)param_1 >> 0x20);
  return CONCAT71((uint7)((ulonglong)param_1 >> 0x28),
                  iVar1 * iVar1 + iVar2 * iVar2 <= (param_3 + 1) * (param_3 + 1));
}

// ==== CMonster::helper_14016b120  @14016b120  [medium:callgraph-r0]  (orig: FUN_14016b120)
int FUN_14016b120(int *param_1)

{
  ulong uVar1;
  int iVar2;
  int iVar3;
  
  if (param_1[1] < 1) {
    return 0;
  }
  iVar3 = *param_1;
  uVar1 = tq::TimeGet(0);
  if ((uint)param_1[1] < uVar1 / 1000) {
    uVar1 = tq::TimeGet(0);
    iVar3 = iVar3 + (param_1[1] - uVar1 / 1000);
  }
  iVar2 = 0;
  if (0 < iVar3) {
    iVar2 = iVar3;
  }
  return iVar2;
}

// ==== CMonster::helper_14016ca50  @14016ca50  [medium:callgraph-r3]  (orig: FUN_14016ca50)
undefined4 FUN_14016ca50(undefined8 param_1)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar2 = FUN_1400fda10(param_1,0x6e,1);
  if ((uVar2 & 8) == 0) {
    iVar3 = FUN_1400fda10(param_1,1,1);
    if (iVar3 != 0x10c8e3) {
      iVar3 = FUN_1400fda10(param_1,1,1);
      if (iVar3 != 0x10c8e6) {
        iVar3 = FUN_1400fda10(param_1,1,1);
        if (iVar3 != 0x10c8e9) {
          cVar1 = FUN_140103c30(param_1);
          if (cVar1 == '\0') {
            uVar4 = FUN_1400fda10(param_1,1,1);
            iVar3 = FUN_1400ff680(uVar4);
            if (iVar3 != 0xb) {
              return 0;
            }
          }
        }
      }
    }
  }
  return 1;
}

// ==== CMonster::helper_14016cba0  @14016cba0  [medium:callgraph-r0]  (orig: FUN_14016cba0)
uint FUN_14016cba0(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
  return (uint)(uVar2 >> 0xe) & 1;
}

// ==== CMonster::helper_14016e5f0  @14016e5f0  [medium:callgraph-r2]  (orig: FUN_14016e5f0)
undefined8 FUN_14016e5f0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  longlong lVar5;
  undefined8 uVar6;
  longlong *plVar7;
  
  plVar7 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = (longlong *)0x0;
  }
  lVar5 = *plVar7;
  uVar1 = FUN_14032d450(param_1);
  lVar5 = (**(code **)(lVar5 + 0x60))(plVar7,uVar1);
  if (((lVar5 != 0) && (iVar2 = FUN_1400fda10(lVar5,10,1), iVar2 != 0)) &&
     (iVar2 = FUN_1400fda10(lVar5,4,1), iVar2 != 0)) {
    return 0;
  }
  plVar7 = DAT_140975b60;
  if (DAT_140975b60 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    plVar7 = (longlong *)0x0;
  }
  lVar5 = *plVar7;
  uVar1 = FUN_14032d440(param_1);
  lVar5 = (**(code **)(lVar5 + 0x60))(plVar7,uVar1);
  if (((lVar5 != 0) && (iVar2 = FUN_1400fda10(lVar5,10,1), iVar2 != 0)) &&
     (iVar3 = FUN_1400fda10(lVar5,4,1), iVar3 != 0)) {
    uVar1 = FUN_14015fba0(iVar2);
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    uVar6 = FUN_140008520((int)param_1[0x246]);
    uVar6 = FUN_1400877e0(uVar6);
    FUN_1402f2f60(uVar6,uVar4,uVar1,param_2,param_3,param_4);
  }
  return 1;
}

// ==== CMonster::helper_140179190  @140179190  [medium:callgraph-r2]  (orig: FUN_140179190)
undefined4 FUN_140179190(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x1134) != 0) {
    uVar1 = tq::TimeGet(0);
    if (uVar1 < (uint)(*(int *)(param_1 + 0x1134) + *(int *)(param_1 + 0x1130))) {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::helper_1401791d0  @1401791d0  [medium:callgraph-r2]  (orig: FUN_1401791d0)
void FUN_1401791d0(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x1134) = 0;
  *(undefined4 *)(param_1 + 0x1130) = 0;
  return;
}

// ==== CMonster::helper_14017ac40  @14017ac40  [medium:callgraph-r2]  (orig: FUN_14017ac40)
undefined4 FUN_14017ac40(longlong param_1)

{
  ulong uVar1;
  
  if (*(int *)(param_1 + 0x113c) != 0) {
    uVar1 = tq::TimeGet(0);
    if (uVar1 < (uint)(*(int *)(param_1 + 0x113c) + *(int *)(param_1 + 0x1138))) {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::helper_14017ac80  @14017ac80  [medium:callgraph-r2]  (orig: FUN_14017ac80)
void FUN_14017ac80(longlong param_1)

{
  *(undefined4 *)(param_1 + 0x113c) = 0;
  *(undefined4 *)(param_1 + 0x1138) = 0;
  return;
}

// ==== CMonster::helper_140185f80  @140185f80  [medium:callgraph-r1]  (orig: FUN_140185f80)
undefined8 FUN_140185f80(longlong *param_1,longlong *param_2,int param_3,char param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  longlong *plVar11;
  IStringManager *pIVar12;
  undefined8 uVar13;
  longlong *plVar14;
  longlong local_48;
  undefined8 *local_40;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_1 == (longlong *)0x0) {
    plVar11 = (longlong *)0x0;
    goto LAB_1401861a5;
  }
  cVar3 = (**(code **)(*param_2 + 0x220))(param_2);
  if (cVar3 == '\0') {
    local_48 = 0;
    (**(code **)(*param_2 + 0x298))(param_2,0x1040,&local_48);
    cVar3 = (**(code **)(*param_2 + 0x240))(param_2);
    if ((cVar3 != '\0') || ((local_48 != 0 && (cVar3 = FUN_14015ff50(), cVar3 != '\0')))) {
      plVar11 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
      iVar4 = (**(code **)(*plVar11 + 8))(plVar11);
      if ((iVar4 != 0x40f) &&
         (local_40 = (undefined8 *)FUN_140118320(), local_40 != (undefined8 *)0x0)) {
        puVar1 = (undefined8 *)*local_40;
        uVar5 = (**(code **)(*param_2 + 0x48))(param_2);
        uVar6 = (**(code **)(*param_2 + 0x40))(param_2);
        uVar7 = (**(code **)(*param_2 + 0x168))(param_2);
        uVar8 = (**(code **)(*param_2 + 0x70))(param_2);
        uVar9 = (**(code **)(*param_1 + 8))(param_1);
        cVar3 = (*(code *)*puVar1)(local_40,uVar9,uVar8,uVar7,uVar6,uVar5);
        if (cVar3 == '\0') {
          plVar11 = param_1 + 2;
          goto LAB_1401861a5;
        }
        param_3 = param_3 * 2;
        uVar5 = FUN_14031cc80(param_1 + 2,param_2,param_3);
        if (param_4 != '\0') {
          plVar11 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
          iVar4 = (**(code **)(*plVar11 + 8))(plVar11);
          if (iVar4 == 0x40f) {
            plVar11 = param_1 + 2;
          }
          else {
            pIVar12 = theInstance();
            lVar2 = param_1[2];
            uVar13 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_KILLING_EXPEX");
            (**(code **)(lVar2 + 0x358))(param_1 + 2,uVar13,uVar5);
            plVar11 = param_1 + 2;
          }
          goto LAB_1401861a5;
        }
      }
    }
  }
  plVar11 = param_1 + 2;
LAB_1401861a5:
  plVar14 = (longlong *)0x0;
  iVar4 = FUN_14031d7e0(plVar11,param_2);
  iVar10 = FUN_140180f80(param_1);
  if (param_1 != (longlong *)0x0) {
    plVar14 = param_1 + 2;
  }
  uVar13 = FUN_14031cc80(plVar14,param_2,param_3 + ((iVar4 + iVar10) * param_3) / 100);
  return uVar13;
}

// ==== CMonster::helper_14018a120  @14018a120  [medium:callgraph-r0]  (orig: FUN_14018a120)
undefined8 FUN_14018a120(longlong *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  undefined8 uVar4;
  uint uVar5;
  
  uVar5 = *(byte *)((longlong)param_1 + 0xeee) / 10;
  if ((uVar5 == 0xe) || (uVar5 == 0xd)) {
    uVar5 = 10;
  }
  iVar2 = (**(code **)(*param_1 + 0x108))();
  if (2 < iVar2) {
    iVar2 = 2;
  }
  uVar4 = FUN_140008520((int)param_1[0x246]);
  cVar1 = FUN_1400b2a80(uVar4,uVar5,iVar2);
  if (cVar1 != '\0') {
    uVar4 = FUN_140008520((int)param_1[0x246]);
    cVar1 = FUN_14008af60(uVar4);
    if (cVar1 != '\0') {
      uVar4 = FUN_140008520((int)param_1[0x246]);
      uVar5 = FUN_14008af70(uVar4);
      uVar3 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
      if (((uVar5 <= uVar3) && ((int)param_1[0x240] != 0)) &&
         (cVar1 = FUN_140022290((longlong)param_1 + 0x11fc), cVar1 == '\0')) {
        return 0;
      }
    }
    return 1;
  }
  return 0;
}

// ==== CMonster::helper_140190cb0  @140190cb0  [medium:callgraph-r3]  (orig: FUN_140190cb0)
undefined8 * FUN_140190cb0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x29) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x29) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x29) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x29) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x29) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMonster::helper_1401a4830  @1401a4830  [medium:callgraph-r2]  (orig: FUN_1401a4830)
longlong FUN_1401a4830(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140190cb0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x29);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x29);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x29);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x29);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14019f3d0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMonster::helper_1401aa9e0  @1401aa9e0  [medium:callgraph-r1]  (orig: FUN_1401aa9e0)
void FUN_1401aa9e0(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_1401a4830(param_1 + 0xaa8,local_res10);
  FUN_140053970(param_1 + 0xae8,local_res10);
  return;
}

// ==== CMonster::helper_1401af440  @1401af440  [medium:callgraph-r3]  (orig: FUN_1401af440)
void FUN_1401af440(undefined8 *param_1,undefined8 *param_2)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined8 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined8 *)param_1[3];
  if (puVar1 == (undefined8 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 3;
  }
  puVar2 = (undefined8 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 3) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_1401a5090(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMonster::helper_1401b9c20  @1401b9c20  [medium:callgraph-r0]  (orig: FUN_1401b9c20)
undefined8 FUN_1401b9c20(longlong *param_1,longlong *param_2,char param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  longlong lVar5;
  undefined8 uVar6;
  undefined8 local_res10;
  
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  if ((param_3 != '\0') && (cVar1 = (**(code **)(*param_2 + 0x220))(param_2), cVar1 == '\0')) {
    return 0;
  }
  iVar2 = (**(code **)(*param_2 + 0x10))(param_2);
  iVar3 = (**(code **)(*param_1 + 8))(param_1);
  if ((iVar2 == iVar3) ||
     ((uVar4 = (**(code **)(*param_1 + 8))(param_1), 0xee69a15e < uVar4 &&
      (*(int *)((longlong)param_1 + 0x12fc) != 0)))) {
    return 0;
  }
  lVar5 = (**(code **)(*param_2 + 0x2b0))(param_2);
  if (lVar5 != 0) {
    uVar6 = (**(code **)(*param_2 + 0x2b0))(param_2);
    cVar1 = FUN_140167b70(uVar6);
    if (cVar1 != '\0') {
      return 0;
    }
  }
  cVar1 = (**(code **)(*param_2 + 600))(param_2);
  if (cVar1 == '\0') {
    uVar6 = 1;
  }
  else {
    uVar6 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    iVar2 = FUN_140117780(uVar6);
    if (iVar2 == 0) {
      return 0;
    }
    iVar3 = (**(code **)(*param_2 + 0x170))(param_2);
    if (iVar3 != iVar2) {
      return 0;
    }
    cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1040,&local_res10);
    if ((cVar1 != '\0') && (cVar1 = FUN_14015ff50(local_res10), cVar1 != '\0')) {
      return 0;
    }
    uVar6 = 0x13;
  }
  FUN_1401ab480(param_1,uVar6,0xf);
  return 1;
}

// ==== CMonster::helper_1401bd2e0  @1401bd2e0  [medium:callgraph-r2]  (orig: FUN_1401bd2e0)
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_1401bd2e0(longlong *param_1,longlong param_2)

{
  byte bVar1;
  longlong lVar2;
  longlong lVar3;
  char cVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  longlong *plVar8;
  longlong *plVar9;
  ulonglong uVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong *local_res18;
  undefined8 local_res20;
  undefined8 local_a0;
  int local_98;
  longlong *local_90 [3];
  void *local_78;
  longlong local_70;
  undefined8 local_68;
  longlong *local_60;
  longlong *local_58;
  ulonglong local_50;
  undefined8 local_48;
  
  local_48 = 0xfffffffffffffffe;
  if ((param_2 != 0) &&
     (plVar8 = (longlong *)(**(code **)(param_1[2] + 0x160))(), plVar8 != (longlong *)0x0)) {
    local_58 = plVar8;
    plVar9 = (longlong *)
             (**(code **)(**(longlong **)(plVar8[0xb] + 8) + 0x10))
                       (*(longlong **)(plVar8[0xb] + 8),4);
    uVar10 = (**(code **)(*plVar9 + 0x58))(plVar9);
    if ((uVar10 >> 0x2b & 1) != 0) {
      bVar1 = *(byte *)(param_2 + 0xeee);
      uVar11 = FUN_140008520((int)param_1[0x246]);
      iVar5 = FUN_1400a7cf0(uVar11,bVar1 / 10);
      cVar4 = FUN_140167b70(param_2);
      if (((cVar4 == '\0') && (cVar4 = FUN_140167b70(param_1), cVar4 == '\0')) &&
         (iVar6 = tq::RandGet(100), iVar6 < iVar5 / 100)) {
        local_res18 = operator_new(8);
        if (local_res18 == (longlong *)0x0) {
          local_90[0] = (longlong *)0x0;
        }
        else {
          *local_res18 = (longlong)local_90;
          local_90[0] = local_res18;
        }
        local_78 = (void *)0x0;
        local_70 = 0;
        local_68 = 0;
        lVar2 = param_1[0x185];
        lVar3 = param_1[0x184];
        local_50 = 0;
        local_res20 = local_res18;
        while (uVar10 = local_50, local_50 < (ulonglong)(lVar2 - lVar3 >> 2)) {
          plVar9 = DAT_140975b60;
          if (DAT_140975b60 == (longlong *)0x0) {
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
            plVar9 = (longlong *)0x0;
          }
          if ((ulonglong)(param_1[0x185] - param_1[0x184] >> 2) <= uVar10) {
            _invalid_parameter_noinfo();
          }
          plVar9 = (longlong *)
                   (**(code **)(*plVar9 + 0x60))
                             (plVar9,*(undefined4 *)(param_1[0x184] + uVar10 * 4));
          if (((plVar9 != (longlong *)0x0) && (cVar4 = FUN_1400ffbe0(plVar9), cVar4 == '\0')) &&
             ((cVar4 = FUN_14016ca50(plVar9), cVar4 == '\0' &&
              (cVar4 = FUN_1400ffb50(plVar9), cVar4 == '\0')))) {
            uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
            local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
            FUN_140037fe0(local_90,&local_res18);
          }
          local_50 = uVar10 + 1;
        }
        iVar5 = (int)(local_70 - (longlong)local_78 >> 2);
        if (iVar5 == 0) {
          if (local_78 != (void *)0x0) {
            operator_delete(local_78);
          }
          local_78 = (void *)0x0;
          local_70 = 0;
          local_68 = 0;
          operator_delete(local_90[0]);
        }
        else {
          iVar6 = tq::RandGet(iVar5);
          if ((-1 < iVar6) && (iVar6 < iVar5)) {
            plVar9 = DAT_140975b60;
            if (DAT_140975b60 == (longlong *)0x0) {
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              plVar9 = (longlong *)0x0;
            }
            if ((ulonglong)(local_70 - (longlong)local_78 >> 2) <= (ulonglong)(longlong)iVar6) {
              _invalid_parameter_noinfo();
            }
            plVar9 = (longlong *)
                     (**(code **)(*plVar9 + 0x60))
                               (plVar9,*(undefined4 *)((longlong)local_78 + (longlong)iVar6 * 4));
            local_a0 = plVar9;
            if (plVar9 != (longlong *)0x0) {
              plVar12 = param_1 + 2;
              local_60 = plVar12;
              uVar7 = (**(code **)(*plVar12 + 0x40))(plVar12);
              local_res20 = (longlong *)CONCAT44(local_res20._4_4_,uVar7);
              uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
              local_res20 = (longlong *)CONCAT44(uVar7,(undefined4)local_res20);
              uVar11 = (**(code **)(*plVar12 + 0x160))(plVar12);
              cVar4 = FUN_1402d1110(uVar11,6,&local_res20);
              if (cVar4 != '\0') {
                cVar4 = FUN_140104440(plVar9);
                if (cVar4 != '\0') {
                  uVar7 = (**(code **)(*plVar8 + 8))(plVar8);
                  local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                  FUN_1400fda10(plVar9,0xf,1);
                  FUN_1400fda10(plVar9,0xe,1);
                  FUN_1400fda10(plVar9,9,1);
                  FUN_1400fda10(plVar9,8,1);
                  plVar8 = local_a0;
                  FUN_1400fda10(local_a0,0xc,1);
                  (**(code **)(*plVar8 + 8))(plVar8);
                  uVar10 = (**(code **)(*param_1 + 8))();
                  uVar11 = (**(code **)(*local_60 + 0x18))();
                  tq::MyLogSave("gmlog/drop_item2",
                                "%s(%u) drop item(%u), (addition_level:%d, gem1=%d, gem2=%d, redue_dmg=%d, add_life=%d, map_id=%u, pos_x=%d, pos_y=%d) when be attack."
                                ,uVar11,uVar10 & 0xffffffff);
                  plVar9 = local_a0;
                  plVar8 = local_58;
                }
                uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
                cVar4 = FUN_14033cfa0(param_1,uVar7,(ulonglong)local_res20 & 0xffffffff,
                                      local_res20._4_4_);
                if (cVar4 != '\0') {
LAB_1401bda8b:
                  if (local_78 != (void *)0x0) {
                    operator_delete(local_78);
                  }
                  local_78 = (void *)0x0;
                  local_70 = 0;
                  local_68 = 0;
                  operator_delete(local_90[0]);
                  return;
                }
              }
            }
          }
          iVar5 = (int)(local_70 - (longlong)local_78 >> 2);
          do {
            do {
              do {
                plVar9 = plVar8;
                local_98 = iVar5 + -1;
                iVar5 = local_98;
                if (local_98 < 0) goto LAB_1401bda8b;
                plVar8 = DAT_140975b60;
                if (DAT_140975b60 == (longlong *)0x0) {
                  log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","g_pItemMgr",
                                     "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                    );
                  plVar8 = (longlong *)0x0;
                }
                if ((ulonglong)(local_70 - (longlong)local_78 >> 2) <= (ulonglong)(longlong)iVar5) {
                  _invalid_parameter_noinfo();
                }
                plVar12 = (longlong *)
                          (**(code **)(*plVar8 + 0x60))
                                    (plVar8,*(undefined4 *)
                                             ((longlong)local_78 + (longlong)iVar5 * 4));
                plVar8 = local_58;
                local_60 = plVar12;
              } while ((((plVar12 == (longlong *)0x0) ||
                        (cVar4 = FUN_1400ffbe0(plVar12), plVar8 = local_58, cVar4 != '\0')) ||
                       (cVar4 = FUN_14016ca50(plVar12), plVar8 = local_58, cVar4 != '\0')) ||
                      (cVar4 = FUN_1400ffb50(plVar12), plVar8 = local_58, cVar4 != '\0'));
              plVar8 = param_1 + 2;
              local_res20 = plVar8;
              uVar7 = (**(code **)(*plVar8 + 0x40))(plVar8);
              local_a0 = (longlong *)CONCAT44(local_a0._4_4_,uVar7);
              uVar7 = (**(code **)(*plVar8 + 0x48))(plVar8);
              local_a0 = (longlong *)CONCAT44(uVar7,(undefined4)local_a0);
              uVar11 = (**(code **)(*plVar8 + 0x160))(plVar8);
              cVar4 = FUN_1402d1110(uVar11,6,&local_a0);
              plVar8 = local_58;
              iVar5 = local_98;
            } while (cVar4 == '\0');
            cVar4 = FUN_140104440(plVar12);
            if (cVar4 != '\0') {
              uVar7 = (**(code **)(*plVar9 + 8))(plVar9);
              local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
              FUN_1400fda10(plVar12,0xf,1);
              FUN_1400fda10(plVar12,0xe,1);
              FUN_1400fda10(plVar12,9,1);
              FUN_1400fda10(plVar12,8,1);
              FUN_1400fda10(plVar12,0xc,1);
              (**(code **)(*plVar12 + 8))(plVar12);
              uVar10 = (**(code **)(*param_1 + 8))();
              uVar11 = (**(code **)(*local_res20 + 0x18))();
              tq::MyLogSave("gmlog/drop_item2",
                            "%s(%u), (addition_level:%d, gem1=%d, gem2=%d, redue_dmg=%d, add_life=%d, map_id=%u, pos_x=%d, pos_y=%d) drop item(%u) when be attack."
                            ,uVar11,uVar10 & 0xffffffff);
              plVar12 = local_60;
            }
            uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
            cVar4 = FUN_14033cfa0(param_1,uVar7,(ulonglong)local_a0 & 0xffffffff,local_a0._4_4_);
            plVar8 = local_58;
            iVar5 = local_98;
          } while (cVar4 == '\0');
          if (local_78 != (void *)0x0) {
            operator_delete(local_78);
          }
          local_78 = (void *)0x0;
          local_70 = 0;
          local_68 = 0;
          operator_delete(local_90[0]);
        }
      }
    }
  }
  return;
}

// ==== CMonster::helper_1401e6550  @1401e6550  [medium:callgraph-r1]  (orig: FUN_1401e6550)
void FUN_1401e6550(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1401e6030();
  if (lVar1 == 0) {
    return;
  }
  FUN_1403fd740(lVar1,5);
  return;
}

// ==== CMonster::helper_1402345f0  @1402345f0  [medium:callgraph-r3]  (orig: FUN_1402345f0)
void FUN_1402345f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x2d) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x2d) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x2d);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x2d);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x2d);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x2d);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x000140234614. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CMonster::helper_140234900  @140234900  [medium:callgraph-r3]  (orig: FUN_140234900)
void FUN_140234900(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x2d) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CMonster::helper_140234960  @140234960  [medium:callgraph-r3]  (orig: FUN_140234960)
void FUN_140234960(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x2d) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CMonster::helper_140235890  @140235890  [medium:callgraph-r2]  (orig: FUN_140235890)
void FUN_140235890(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)((longlong)puVar1 + 0x2c) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x2d) = 0;
  return;
}

// ==== CMonster::helper_140235ae0  @140235ae0  [medium:callgraph-r3]  (orig: FUN_140235ae0)
void FUN_140235ae0(undefined8 param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  
  cVar1 = *(char *)((longlong)param_2 + 0x2d);
  while (cVar1 == '\0') {
    FUN_140235ae0(param_1,param_2[2]);
    plVar2 = (longlong *)*param_2;
    operator_delete(param_2);
    param_2 = plVar2;
    cVar1 = *(char *)((longlong)plVar2 + 0x2d);
  }
  return;
}

// ==== CMonster::helper_140236070  @140236070  [medium:callgraph-r3]  (orig: FUN_140236070)
undefined8 * FUN_140236070(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x61) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x61) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x61) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x61) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x61) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x61) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMonster::helper_1402361e0  @1402361e0  [medium:callgraph-r2]  (orig: FUN_1402361e0)
undefined8 * FUN_1402361e0(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  undefined1 *puVar1;
  undefined1 *puVar2;
  char cVar3;
  undefined1 uVar4;
  longlong *plVar5;
  longlong *plVar6;
  undefined8 *puVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined **local_80 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_68 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_40 [40];
  
  plVar5 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar5 + 0x2d) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_40,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_80);
    local_80[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_68,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_40);
    local_80[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_80,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1402345f0(param_3);
  plVar11 = (longlong *)*plVar5;
  if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
    plVar12 = plVar11;
    if (*(char *)(plVar5[2] + 0x2d) == '\0') {
      plVar10 = *(longlong **)(param_3 + 8);
      plVar12 = (longlong *)plVar10[2];
      if (plVar10 != plVar5) {
        plVar11[1] = (longlong)plVar10;
        *plVar10 = *plVar5;
        plVar11 = plVar10;
        if (plVar10 != (longlong *)plVar5[2]) {
          plVar11 = (longlong *)plVar10[1];
          if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
            plVar12[1] = (longlong)plVar11;
          }
          *plVar11 = (longlong)plVar12;
          plVar10[2] = plVar5[2];
          *(longlong **)(plVar5[2] + 8) = plVar10;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar5) {
          *(longlong **)(param_1[6] + 8) = plVar10;
        }
        else {
          puVar7 = (undefined8 *)plVar5[1];
          if ((longlong *)*puVar7 == plVar5) {
            *puVar7 = plVar10;
          }
          else {
            puVar7[2] = plVar10;
          }
        }
        plVar10[1] = plVar5[1];
        puVar1 = (undefined1 *)((longlong)plVar5 + 0x2c);
        puVar2 = (undefined1 *)((longlong)plVar10 + 0x2c);
        if (puVar2 != puVar1) {
          uVar4 = *puVar2;
          *puVar2 = *puVar1;
          *puVar1 = uVar4;
        }
        goto LAB_1402363cc;
      }
    }
  }
  else {
    plVar12 = (longlong *)plVar5[2];
  }
  plVar11 = (longlong *)plVar5[1];
  if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
    plVar12[1] = (longlong)plVar11;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar5) {
    *(longlong **)(param_1[6] + 8) = plVar12;
  }
  else if ((longlong *)*plVar11 == plVar5) {
    *plVar11 = (longlong)plVar12;
  }
  else {
    plVar11[2] = (longlong)plVar12;
  }
  if (*(longlong **)param_1[6] == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
      cVar3 = *(char *)(*plVar12 + 0x2d);
      plVar6 = (longlong *)*plVar12;
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)*plVar9;
        cVar3 = *(char *)((longlong)plVar6 + 0x2d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)param_1[6] = plVar10;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar5) {
    plVar10 = plVar11;
    if (*(char *)((longlong)plVar12 + 0x2d) == '\0') {
      cVar3 = *(char *)(plVar12[2] + 0x2d);
      plVar6 = (longlong *)plVar12[2];
      plVar10 = plVar12;
      while (plVar9 = plVar6, cVar3 == '\0') {
        plVar6 = (longlong *)plVar9[2];
        cVar3 = *(char *)((longlong)plVar6 + 0x2d);
        plVar10 = plVar9;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar10;
  }
LAB_1402363cc:
  if (*(char *)((longlong)plVar5 + 0x2c) == '\x01') {
    if (plVar12 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar10 = plVar11;
        if (*(char *)((longlong)plVar12 + 0x2c) != '\x01') break;
        plVar11 = (longlong *)*plVar10;
        if (plVar12 == plVar11) {
          plVar11 = (longlong *)plVar10[2];
          if (*(char *)((longlong)plVar11 + 0x2c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x2c) = 0;
            FUN_140234900(param_1,plVar10);
            plVar11 = (longlong *)plVar10[2];
          }
          if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
            if ((*(char *)(*plVar11 + 0x2c) != '\x01') || (*(char *)(plVar11[2] + 0x2c) != '\x01'))
            {
              if (*(char *)(plVar11[2] + 0x2c) == '\x01') {
                *(undefined1 *)(*plVar11 + 0x2c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
                FUN_140234960(param_1,plVar11);
                plVar11 = (longlong *)plVar10[2];
              }
              *(undefined1 *)((longlong)plVar11 + 0x2c) = *(undefined1 *)((longlong)plVar10 + 0x2c);
              *(undefined1 *)((longlong)plVar10 + 0x2c) = 1;
              *(undefined1 *)(plVar11[2] + 0x2c) = 1;
              FUN_140234900(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
          }
        }
        else {
          if (*(char *)((longlong)plVar11 + 0x2c) == '\0') {
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 1;
            *(undefined1 *)((longlong)plVar10 + 0x2c) = 0;
            FUN_140234960(param_1,plVar10);
            plVar11 = (longlong *)*plVar10;
          }
          if (*(char *)((longlong)plVar11 + 0x2d) == '\0') {
            if ((*(char *)(plVar11[2] + 0x2c) != '\x01') || (*(char *)(*plVar11 + 0x2c) != '\x01'))
            {
              if (*(char *)(*plVar11 + 0x2c) == '\x01') {
                *(undefined1 *)(plVar11[2] + 0x2c) = 1;
                *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
                FUN_140234900(param_1,plVar11);
                plVar11 = (longlong *)*plVar10;
              }
              *(undefined1 *)((longlong)plVar11 + 0x2c) = *(undefined1 *)((longlong)plVar10 + 0x2c);
              *(undefined1 *)((longlong)plVar10 + 0x2c) = 1;
              *(undefined1 *)(*plVar11 + 0x2c) = 1;
              FUN_140234960(param_1,plVar10);
              break;
            }
            *(undefined1 *)((longlong)plVar11 + 0x2c) = 0;
          }
        }
        plVar11 = (longlong *)plVar10[1];
        plVar12 = plVar10;
      } while (plVar10 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)((longlong)plVar12 + 0x2c) = 1;
  }
  operator_delete(plVar5);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar8 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar8;
  return param_2;
}

// ==== CMonster::helper_1402365a0  @1402365a0  [medium:callgraph-r2]  (orig: FUN_1402365a0)
void FUN_1402365a0(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x2d);
  while (cVar1 == '\0') {
    FUN_140235ae0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x2d);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CMonster::helper_140236620  @140236620  [medium:callgraph-r3]  (orig: FUN_140236620)
undefined8 * FUN_140236620(longlong param_1,undefined8 *param_2,undefined8 param_3)

{
  undefined8 *puVar1;
  undefined8 uVar2;
  undefined8 *puVar3;
  
  puVar3 = *(undefined8 **)(param_1 + 0x30);
  if (*(char *)((longlong)param_2 + 0x2d) == '\0') {
    puVar1 = (undefined8 *)
             FUN_140235b30(param_1,puVar3,param_3,puVar3,param_2 + 3,
                           *(undefined1 *)((longlong)param_2 + 0x2c),0xfffffffffffffffe);
    if (*(char *)((longlong)puVar3 + 0x2d) != '\0') {
      puVar3 = puVar1;
    }
    uVar2 = FUN_140236620(param_1,*param_2,puVar1);
    *puVar1 = uVar2;
    uVar2 = FUN_140236620(param_1,param_2[2],puVar1);
    puVar1[2] = uVar2;
  }
  return puVar3;
}

// ==== CMonster::helper_1402366b0  @1402366b0  [medium:callgraph-r3]  (orig: FUN_1402366b0)
undefined8 * FUN_1402366b0(undefined8 *param_1,undefined8 *param_2,uint *param_3)

{
  undefined8 uVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  
  puVar4 = (undefined8 *)param_1[6];
  puVar5 = puVar4;
  if (*(char *)((longlong)puVar4[1] + 0x2d) == '\0') {
    puVar2 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar2 + 3) < *param_3) {
        puVar3 = (undefined8 *)puVar2[2];
      }
      else {
        if ((*(char *)((longlong)puVar4 + 0x2d) != '\0') && (*param_3 < *(uint *)(puVar2 + 3))) {
          puVar4 = puVar2;
        }
        puVar3 = (undefined8 *)*puVar2;
        puVar5 = puVar2;
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x2d) == '\0');
  }
  if (*(char *)((longlong)puVar4 + 0x2d) == '\0') {
    puVar2 = (undefined8 *)*puVar4;
  }
  else {
    puVar2 = *(undefined8 **)(param_1[6] + 8);
  }
  if (*(char *)((longlong)puVar2 + 0x2d) == '\0') {
    do {
      if (*param_3 < *(uint *)(puVar2 + 3)) {
        puVar3 = (undefined8 *)*puVar2;
        puVar4 = puVar2;
      }
      else {
        puVar3 = (undefined8 *)puVar2[2];
      }
      puVar2 = puVar3;
    } while (*(char *)((longlong)puVar3 + 0x2d) == '\0');
  }
  uVar1 = *param_1;
  *param_2 = uVar1;
  param_2[1] = puVar5;
  param_2[2] = uVar1;
  param_2[3] = puVar4;
  return param_2;
}

// ==== CMonster::helper_140236ff0  @140236ff0  [medium:callgraph-r1]  (orig: FUN_140236ff0)
longlong * FUN_140236ff0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1402365a0(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x2d) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x2d) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x2d);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x2d);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x2d);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x2d);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1402361e0(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CMonster::helper_140237200  @140237200  [medium:callgraph-r2]  (orig: FUN_140237200)
void FUN_140237200(longlong param_1,longlong param_2)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  
  lVar2 = *(longlong *)(param_1 + 0x30);
  uVar7 = FUN_140236620(param_1,*(undefined8 *)(*(longlong *)(param_2 + 0x30) + 8),lVar2);
  *(undefined8 *)(lVar2 + 8) = uVar7;
  plVar3 = *(longlong **)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = *(undefined8 *)(param_2 + 0x38);
  plVar4 = (longlong *)plVar3[1];
  if (*(char *)((longlong)plVar4 + 0x2d) != '\0') {
    *plVar3 = (longlong)plVar3;
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
    return;
  }
  cVar1 = *(char *)(*plVar4 + 0x2d);
  plVar6 = (longlong *)*plVar4;
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*plVar6 + 0x2d);
    plVar4 = plVar6;
    plVar6 = (longlong *)*plVar6;
  }
  *plVar3 = (longlong)plVar4;
  lVar2 = *(longlong *)(*(longlong *)(param_1 + 0x30) + 8);
  lVar5 = *(longlong *)(lVar2 + 0x10);
  cVar1 = *(char *)(lVar5 + 0x2d);
  while (cVar1 == '\0') {
    cVar1 = *(char *)(*(longlong *)(lVar5 + 0x10) + 0x2d);
    lVar2 = lVar5;
    lVar5 = *(longlong *)(lVar5 + 0x10);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = lVar2;
  return;
}

// ==== CMonster::helper_140237830  @140237830  [medium:callgraph-r2]  (orig: FUN_140237830)
longlong FUN_140237830(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_1402366b0(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x2d) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x2d) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x2d);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x2d);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x2d);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x2d);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_140236ff0(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMonster::helper_140237970  @140237970  [medium:callgraph-r2]  (orig: FUN_140237970)
longlong * FUN_140237970(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x2d) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x2d) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMonster::helper_140238820  @140238820  [medium:callgraph-r1]  (orig: FUN_140238820)
undefined8 *
FUN_140238820(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined8 *puVar1;
  longlong lVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_140235890(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x2d) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  FUN_140237200(param_1,param_2,param_3,param_4,uVar3);
  return param_1;
}

// ==== CMonster::helper_14023ad00  @14023ad00  [medium:callgraph-r2]  (orig: FUN_14023ad00)
longlong FUN_14023ad00(undefined8 param_1,undefined8 param_2)

{
  char cVar1;
  longlong *plVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong local_58;
  longlong *local_50;
  longlong local_48;
  longlong *local_40;
  longlong local_38;
  longlong *local_30;
  longlong local_28;
  longlong *local_20;
  
  FUN_140236070(param_1,&local_38,param_2);
  plVar5 = local_20;
  lVar4 = local_28;
  lVar3 = local_38;
  lVar8 = 0;
  local_58 = local_38;
  local_50 = local_30;
  plVar7 = local_30;
  while( true ) {
    if ((lVar3 == 0) || (lVar3 != lVar4)) {
      _invalid_parameter_noinfo();
    }
    if (plVar7 == plVar5) break;
    lVar8 = lVar8 + 1;
    if (lVar3 == 0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar7 + 0x61) == '\0') {
      plVar2 = (longlong *)plVar7[2];
      if (*(char *)((longlong)plVar2 + 0x61) == '\0') {
        cVar1 = *(char *)(*plVar2 + 0x61);
        plVar7 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar2 + 0x61);
          plVar7 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar1 = *(char *)(plVar7[1] + 0x61);
        plVar6 = (longlong *)plVar7[1];
        plVar2 = plVar7;
        while ((plVar7 = plVar6, cVar1 == '\0' && (plVar2 == (longlong *)plVar7[2]))) {
          cVar1 = *(char *)(plVar7[1] + 0x61);
          plVar6 = (longlong *)plVar7[1];
          plVar2 = plVar7;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  local_58 = local_28;
  local_50 = local_20;
  local_48 = local_38;
  local_40 = local_30;
  FUN_14023a340(param_1,&local_38,&local_48,&local_58);
  return lVar8;
}

// ==== CMonster::helper_14023aee0  @14023aee0  [medium:callgraph-r1]  (orig: FUN_14023aee0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14023aee0(longlong param_1,uint param_2,uint param_3)

{
  longlong *plVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  char cVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined8 *puVar8;
  longlong **pplVar9;
  undefined8 *puVar10;
  longlong lVar11;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  uint local_4b8;
  uint local_4b4;
  longlong *local_4b0;
  longlong *local_4a8;
  longlong *local_4a0;
  longlong *local_498;
  longlong *local_490;
  undefined8 local_488;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar4 = *(char *)((longlong)puVar10 + 0x61);
  puVar2 = *(undefined8 **)(param_1 + 0x38);
  while (cVar4 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_3) {
      puVar8 = (undefined8 *)puVar10[2];
      puVar10 = puVar2;
    }
    else {
      puVar8 = (undefined8 *)*puVar10;
    }
    puVar2 = puVar10;
    puVar10 = puVar8;
    cVar4 = *(char *)((longlong)puVar8 + 0x61);
  }
  local_498 = puVar2;
  local_4a0 = *(longlong **)(param_1 + 8);
  puVar10 = *(undefined8 **)(param_1 + 0x38);
  local_4b8 = param_2;
  local_4b4 = param_3;
  if (*(longlong **)(param_1 + 8) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar10) || (param_3 < *(uint *)(puVar2 + 3))) {
    local_488 = *(undefined8 *)(param_1 + 0x38);
    local_490 = *(longlong **)(param_1 + 8);
    pplVar9 = &local_490;
  }
  else {
    pplVar9 = &local_4a0;
  }
  plVar6 = *pplVar9;
  local_4b0 = plVar6;
  local_4a8 = pplVar9[1];
  plVar1 = *(longlong **)(param_1 + 0x38);
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  plVar3 = local_4a8;
  lVar11 = 0;
  if (local_4a8 != plVar1) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = lVar11;
    }
    else {
      lVar7 = *plVar6;
    }
    if (plVar3 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    FUN_140237970(plVar3 + 4,&local_4b0,&local_4b8);
    plVar6 = (longlong *)plVar3[10];
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != (longlong *)plVar3[4])) {
      _invalid_parameter_noinfo();
    }
    if (local_4a8 != plVar6) {
      FUN_1404201a0(local_478);
      cVar4 = FUN_140420250(local_478,1,param_3);
      if (cVar4 == '\0') {
        local_4c8 = 0x10b;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_1404201f0(local_478);
        return;
      }
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
      plVar6 = (longlong *)FUN_140087650(uVar5);
      lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,param_2);
      if (lVar7 != 0) {
        (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x350))((longlong *)(lVar7 + 0x10),local_478);
      }
      if (param_3 - 1000000 < 0xee5be5c0) {
        uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x88));
        plVar6 = (longlong *)FUN_140087650(uVar5);
        lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,param_3);
        if (lVar7 != 0) {
          (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x350))((longlong *)(lVar7 + 0x10),local_478);
        }
      }
      FUN_140237830(plVar3 + 4,&local_4b8);
      if (plVar3[0xb] == 0) {
        FUN_14023ad00(param_1 + 8,&local_4b4);
      }
      FUN_1404201f0(local_478);
    }
  }
  puVar10 = (undefined8 *)(*(undefined8 **)(param_1 + 0x78))[1];
  cVar4 = *(char *)((longlong)puVar10 + 0x61);
  puVar2 = *(undefined8 **)(param_1 + 0x78);
  while (cVar4 == '\0') {
    if (*(uint *)(puVar10 + 3) < param_2) {
      puVar8 = (undefined8 *)puVar10[2];
      puVar10 = puVar2;
    }
    else {
      puVar8 = (undefined8 *)*puVar10;
    }
    puVar2 = puVar10;
    puVar10 = puVar8;
    cVar4 = *(char *)((longlong)puVar8 + 0x61);
  }
  local_4a8 = puVar2;
  local_4b0 = *(longlong **)(param_1 + 0x48);
  puVar10 = *(undefined8 **)(param_1 + 0x78);
  if (*(longlong **)(param_1 + 0x48) == (longlong *)0x0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar10) || (param_2 < *(uint *)(puVar2 + 3))) {
    local_488 = *(undefined8 *)(param_1 + 0x78);
    local_490 = *(longlong **)(param_1 + 0x48);
    pplVar9 = &local_490;
  }
  else {
    pplVar9 = &local_4b0;
  }
  plVar6 = *pplVar9;
  local_4a0 = plVar6;
  local_498 = pplVar9[1];
  plVar1 = *(longlong **)(param_1 + 0x78);
  if ((plVar6 == (longlong *)0x0) || (plVar6 != *(longlong **)(param_1 + 0x48))) {
    _invalid_parameter_noinfo();
  }
  plVar3 = local_498;
  if (local_498 != plVar1) {
    if (plVar6 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    else {
      lVar11 = *plVar6;
    }
    if (plVar3 == *(longlong **)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar6 = plVar3 + 4;
    FUN_140237970(plVar6,&local_4b0,&local_4b4);
    puVar10 = (undefined8 *)plVar3[10];
    if ((local_4b0 == (longlong *)0x0) || (local_4b0 != (longlong *)*plVar6)) {
      _invalid_parameter_noinfo();
    }
    if ((local_4a8 != puVar10) && (FUN_140237830(plVar6,&local_4b4), plVar3[0xb] == 0)) {
      FUN_14023ad00(param_1 + 0x48,&local_4b8);
    }
  }
  return;
}

// ==== CMonster::helper_14023b940  @14023b940  [medium:callgraph-r0]  (orig: FUN_14023b940)
void FUN_14023b940(longlong param_1,longlong *param_2)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  undefined8 *puVar5;
  uint uVar6;
  undefined8 *puVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_80;
  undefined8 *local_78;
  longlong local_68;
  undefined8 uStack_60;
  longlong *local_58;
  longlong lStack_50;
  longlong *local_48 [6];
  undefined8 *local_18;
  undefined8 local_10;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar6 = (**(code **)(*param_2 + 8))(param_2);
    puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
    cVar1 = *(char *)((longlong)puVar9 + 0x61);
    puVar3 = *(undefined8 **)(param_1 + 0x38);
    while (cVar1 == '\0') {
      if (*(uint *)(puVar9 + 3) < uVar6) {
        puVar7 = (undefined8 *)puVar9[2];
        puVar9 = puVar3;
      }
      else {
        puVar7 = (undefined8 *)*puVar9;
      }
      puVar3 = puVar9;
      puVar9 = puVar7;
      cVar1 = *(char *)((longlong)puVar7 + 0x61);
    }
    local_78 = puVar3;
    local_80 = *(longlong *)(param_1 + 8);
    puVar9 = *(undefined8 **)(param_1 + 0x38);
    if (*(longlong *)(param_1 + 8) == 0) {
      _invalid_parameter_noinfo();
    }
    if ((puVar3 == puVar9) || (uVar6 < *(uint *)(puVar3 + 3))) {
      uStack_60 = *(undefined8 *)(param_1 + 0x38);
      local_68 = *(longlong *)(param_1 + 8);
      plVar8 = &local_68;
    }
    else {
      plVar8 = &local_80;
    }
    plVar2 = (longlong *)*plVar8;
    lStack_50 = plVar8[1];
    lVar10 = *(longlong *)(param_1 + 0x38);
    local_58 = plVar2;
    if ((plVar2 == (longlong *)0x0) || (plVar2 != *(longlong **)(param_1 + 8))) {
      _invalid_parameter_noinfo();
    }
    lVar4 = lStack_50;
    if (lStack_50 != lVar10) {
      if (plVar2 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar2;
      }
      if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_140238820(local_48,lVar4 + 0x20);
      puVar3 = local_18;
      plVar8 = local_48[0];
      puVar9 = (undefined8 *)*local_18;
      while( true ) {
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (puVar9 == puVar3) break;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar8;
        }
        if (puVar9 == *(undefined8 **)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        FUN_14023aee0(param_1,*(undefined4 *)(puVar9 + 4),*(undefined4 *)((longlong)puVar9 + 0x1c));
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        if (*(char *)((longlong)puVar9 + 0x2d) == '\0') {
          puVar7 = (undefined8 *)puVar9[2];
          if (*(char *)((longlong)puVar7 + 0x2d) == '\0') {
            cVar1 = *(char *)((longlong)*puVar7 + 0x2d);
            puVar9 = puVar7;
            puVar7 = (undefined8 *)*puVar7;
            while (cVar1 == '\0') {
              cVar1 = *(char *)((longlong)*puVar7 + 0x2d);
              puVar9 = puVar7;
              puVar7 = (undefined8 *)*puVar7;
            }
          }
          else {
            cVar1 = *(char *)((longlong)puVar9[1] + 0x2d);
            puVar5 = (undefined8 *)puVar9[1];
            puVar7 = puVar9;
            while ((puVar9 = puVar5, cVar1 == '\0' && (puVar7 == (undefined8 *)puVar9[2]))) {
              cVar1 = *(char *)((longlong)puVar9[1] + 0x2d);
              puVar5 = (undefined8 *)puVar9[1];
              puVar7 = puVar9;
            }
          }
        }
        else {
          _invalid_parameter_noinfo();
        }
      }
      uStack_60 = *local_18;
      FUN_140236ff0(local_48,&local_80,&local_68,&local_58);
      operator_delete(local_18);
      local_18 = (undefined8 *)0x0;
      local_10 = 0;
      operator_delete(local_48[0]);
    }
  }
  return;
}

// ==== CMonster::helper_14026ba40  @14026ba40  [medium:callgraph-r1]  (orig: FUN_14026ba40)
int FUN_14026ba40(undefined8 param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  ulong uVar4;
  longlong *plVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = 0;
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  iVar7 = 6;
  plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,6);
  iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,7);
  iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,8);
  iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
  iVar1 = iVar2 + iVar3 + iVar1;
  if (iVar1 == 0) {
    iVar6 = 0;
  }
  else {
    uVar4 = tq::TimeGet(0);
    iVar2 = rand();
    srand(iVar2 + uVar4);
    iVar1 = tq::RandGet(iVar1);
    iVar2 = 0;
    do {
      plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,iVar7);
      iVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
      iVar2 = iVar2 + iVar3;
      if (iVar1 < iVar2) {
        return iVar6;
      }
      iVar7 = iVar7 + 1;
      iVar6 = iVar6 + 1;
    } while (iVar7 < 9);
  }
  return iVar6;
}

// ==== CMonster::helper_14026bb40  @14026bb40  [medium:callgraph-r1]  (orig: FUN_14026bb40)
int FUN_14026bb40(undefined8 param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  ulong uVar3;
  int iVar4;
  longlong *plVar5;
  int iVar6;
  int iVar7;
  
  iVar6 = 0;
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  iVar7 = 4;
  plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,4);
  iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,5);
  iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
  if (iVar2 + iVar1 == 0) {
    iVar6 = 0;
  }
  else {
    uVar3 = tq::TimeGet(0);
    iVar4 = rand();
    srand(iVar4 + uVar3);
    iVar1 = tq::RandGet(iVar2 + iVar1);
    iVar2 = 0;
    do {
      plVar5 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,iVar7);
      iVar4 = (**(code **)(*plVar5 + 0x48))(plVar5);
      iVar2 = iVar2 + iVar4;
      if (iVar1 < iVar2) {
        return iVar6;
      }
      iVar7 = iVar7 + 1;
      iVar6 = iVar6 + 1;
    } while (iVar7 < 6);
  }
  return iVar6;
}

// ==== CMonster::helper_14026bc30  @14026bc30  [medium:callgraph-r1]  (orig: FUN_14026bc30)
undefined4 FUN_14026bc30(undefined8 param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  ulong uVar5;
  longlong *plVar6;
  int iVar7;
  undefined4 uVar8;
  
  uVar8 = 0;
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  iVar7 = 6;
  plVar6 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,6);
  iVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
  plVar6 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,7);
  iVar2 = (**(code **)(*plVar6 + 0x48))(plVar6);
  plVar6 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,8);
  iVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
  plVar6 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,9);
  iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
  iVar1 = iVar3 + iVar4 + iVar2 + iVar1;
  if (iVar1 == 0) {
    uVar8 = 0;
  }
  else {
    uVar5 = tq::TimeGet(0);
    iVar2 = rand();
    srand(iVar2 + uVar5);
    iVar1 = tq::RandGet(iVar1);
    iVar2 = 0;
    do {
      plVar6 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,iVar7);
      iVar3 = (**(code **)(*plVar6 + 0x48))(plVar6);
      iVar2 = iVar2 + iVar3;
      if (iVar1 < iVar2) break;
      iVar7 = iVar7 + 1;
    } while (iVar7 < 10);
    if (iVar7 == 7) {
      uVar8 = 1;
    }
    else if (iVar7 == 8) {
      uVar8 = 3;
    }
    else if (iVar7 == 9) {
      uVar8 = 5;
    }
  }
  return uVar8;
}

// ==== CMonster::helper_14026d380  @14026d380  [medium:callgraph-r2]  (orig: FUN_14026d380)
longlong * FUN_14026d380(longlong *param_1,longlong *param_2,uint *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(uint *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(uint *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMonster::helper_14026d450  @14026d450  [medium:callgraph-r2]  (orig: FUN_14026d450)
longlong * FUN_14026d450(longlong *param_1,longlong *param_2,ushort *param_3)

{
  undefined8 *puVar1;
  undefined8 *puVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  longlong local_28;
  undefined8 *local_20;
  longlong local_18;
  longlong local_10;
  
  puVar4 = (undefined8 *)param_1[6];
  if (*(char *)((longlong)puVar4[1] + 0x51) == '\0') {
    puVar1 = (undefined8 *)puVar4[1];
    do {
      if (*(ushort *)(puVar1 + 3) < *param_3) {
        puVar2 = (undefined8 *)puVar1[2];
      }
      else {
        puVar2 = (undefined8 *)*puVar1;
        puVar4 = puVar1;
      }
      puVar1 = puVar2;
    } while (*(char *)((longlong)puVar2 + 0x51) == '\0');
  }
  puVar1 = (undefined8 *)param_1[6];
  local_20 = puVar4;
  local_28 = *param_1;
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar1) || (*param_3 < *(ushort *)(puVar4 + 3))) {
    plVar3 = &local_18;
    local_10 = param_1[6];
    local_18 = *param_1;
  }
  else {
    plVar3 = &local_28;
  }
  *param_2 = *plVar3;
  param_2[1] = plVar3[1];
  return param_2;
}

// ==== CMonster::helper_14026da30  @14026da30  [medium:callgraph-r0]  (orig: FUN_14026da30)
undefined4 FUN_14026da30(longlong param_1,int param_2)

{
  longlong lVar1;
  longlong *plVar2;
  ushort uVar3;
  ushort uVar4;
  ushort uVar5;
  ushort uVar6;
  ushort uVar7;
  ulong uVar8;
  int iVar9;
  uint uVar10;
  uint uVar11;
  longlong *plVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  int iVar15;
  int local_res10 [2];
  ulonglong *local_38;
  longlong local_30;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_14002d940((longlong *)(param_1 + 0x10),&local_38,local_res10);
  lVar1 = *(longlong *)(param_1 + 0x40);
  if ((local_38 == (ulonglong *)0x0) || (local_38 != *(ulonglong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (local_30 != lVar1) {
    uVar13 = 0;
    if (local_38 == (ulonglong *)0x0) {
      _invalid_parameter_noinfo();
      uVar14 = uVar13;
    }
    else {
      uVar14 = *local_38;
    }
    if (local_30 == *(longlong *)(uVar14 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar2 = *(longlong **)(local_30 + 0x20);
    if (plVar2 != (longlong *)0x0) {
      iVar15 = 3;
      plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,3);
      uVar3 = (**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,4);
      uVar4 = (**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,5);
      uVar5 = (**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,6);
      uVar6 = (**(code **)(*plVar12 + 0x30))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,7);
      uVar7 = (**(code **)(*plVar12 + 0x30))(plVar12);
      local_res10[0] = (uint)uVar7 + (uint)uVar6 + (uint)uVar5 + (uint)uVar4 + (uint)uVar3;
      if (local_res10[0] != 0) {
        uVar8 = tq::TimeGet(0);
        iVar9 = rand();
        srand(iVar9 + param_2 + uVar8);
        uVar10 = tq::RandGet(local_res10[0]);
        do {
          plVar12 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,iVar15);
          uVar11 = (**(code **)(*plVar12 + 0x30))(plVar12);
          uVar11 = (int)uVar13 + (uVar11 & 0xffff);
          uVar13 = (ulonglong)uVar11;
          if (uVar10 < uVar11) break;
          iVar15 = iVar15 + 1;
        } while (iVar15 < 8);
        if (iVar15 != 3) {
          if (iVar15 == 4) {
            return 1;
          }
          if (iVar15 == 5) {
            return 2;
          }
          if (iVar15 == 6) {
            return 5;
          }
          if (iVar15 == 7) {
            return 10;
          }
          log_InlineLogERROR("CMonsterDropRuleMgr::GetDropMoneyStackNum, error stack num(%d)");
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMonster::helper_14026dc60  @14026dc60  [medium:callgraph-r0]  (orig: FUN_14026dc60)
undefined8 FUN_14026dc60(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_14002d940((longlong *)(param_1 + 0x10),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x40);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_10 + 0x20);
    if (plVar1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,1);
                    /* WARNING: Could not recover jumptable at 0x00014026dd18. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CMonster::helper_14026dd20  @14026dd20  [medium:callgraph-r0]  (orig: FUN_14026dd20)
undefined8 FUN_14026dd20(longlong param_1,int param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  longlong lVar3;
  int local_res10 [2];
  longlong *local_18;
  longlong local_10;
  
  if (param_2 == 0) {
    return 0;
  }
  local_res10[0] = param_2;
  FUN_14002d940((longlong *)(param_1 + 0x10),&local_18,local_res10);
  lVar3 = *(longlong *)(param_1 + 0x40);
  if ((local_18 == (longlong *)0x0) || (local_18 != *(longlong **)(param_1 + 0x10))) {
    _invalid_parameter_noinfo();
  }
  if (local_10 != lVar3) {
    if (local_18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar3 = 0;
    }
    else {
      lVar3 = *local_18;
    }
    if (local_10 == *(longlong *)(lVar3 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(local_10 + 0x20);
    if (plVar1 != (longlong *)0x0) {
      plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,2);
                    /* WARNING: Could not recover jumptable at 0x00014026ddd8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(*plVar1 + 0x50))(plVar1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CMonster::helper_14026dde0  @14026dde0  [medium:callgraph-r1]  (orig: FUN_14026dde0)
longlong * FUN_14026dde0(longlong param_1,int param_2,char param_3,undefined8 param_4)

{
  longlong *plVar1;
  float fVar2;
  byte bVar3;
  int iVar4;
  ulong uVar5;
  int iVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  int iVar11;
  int local_res10 [2];
  longlong *local_80;
  longlong local_78;
  longlong *local_70 [3];
  longlong *local_58;
  longlong *local_50;
  undefined8 local_48;
  
  if (param_2 == 0) {
    plVar7 = (longlong *)0x0;
  }
  else {
    local_res10[0] = param_2;
    FUN_14026d380((longlong *)(param_1 + 0x50),&local_80,local_res10,param_4,0xfffffffffffffffe);
    lVar10 = *(longlong *)(param_1 + 0x80);
    if ((local_80 == (longlong *)0x0) || (local_80 != *(longlong **)(param_1 + 0x50))) {
      _invalid_parameter_noinfo();
    }
    if (local_78 == lVar10) {
      plVar7 = (longlong *)0x0;
    }
    else {
      if (local_80 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *local_80;
      }
      if (local_78 == *(longlong *)(lVar10 + 0x30)) {
        _invalid_parameter_noinfo();
      }
      FUN_140267b90(local_70,local_78 + 0x20);
      plVar9 = local_58;
      iVar11 = 0;
      plVar1 = local_70[0];
      fVar2 = DAT_140715a88;
      if (local_50 < local_58) {
        _invalid_parameter_noinfo();
        plVar1 = local_70[0];
        fVar2 = DAT_140715a88;
      }
      while( true ) {
        plVar8 = local_50;
        if (local_50 < local_58) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_70[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar9 == plVar8) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar8 = (longlong *)*plVar9;
        if (plVar8 != (longlong *)0x0) {
          plVar7 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,2);
          iVar4 = (**(code **)(*plVar7 + 0x48))();
          if (param_3 != '\0') {
            plVar8 = (longlong *)(**(code **)(*plVar8 + 0x10))(plVar8,0xb);
            bVar3 = (**(code **)(*plVar8 + 0x20))();
            if (bVar3 != 0) {
              iVar4 = (int)(((float)bVar3 / fVar2) * (float)iVar4);
            }
          }
          iVar11 = iVar11 + iVar4;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar9 = plVar9 + 1;
      }
      uVar5 = tq::TimeGet(0);
      iVar4 = rand();
      srand(iVar4 + param_2 + uVar5);
      iVar11 = tq::RandGet(iVar11);
      plVar9 = local_58;
      iVar4 = 0;
      plVar1 = local_70[0];
      if (local_50 < local_58) {
        _invalid_parameter_noinfo();
        plVar1 = local_70[0];
      }
      while( true ) {
        plVar8 = local_50;
        if (local_50 < local_58) {
          _invalid_parameter_noinfo();
        }
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_70[0])) {
          _invalid_parameter_noinfo();
        }
        plVar7 = (longlong *)0x0;
        if (plVar9 == plVar8) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar7 = (longlong *)*plVar9;
        if (plVar7 != (longlong *)0x0) {
          plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
          iVar6 = (**(code **)(*plVar8 + 0x48))(plVar8);
          if (param_3 != '\0') {
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,0xb);
            bVar3 = (**(code **)(*plVar8 + 0x20))(plVar8);
            if (bVar3 != 0) {
              iVar6 = (int)(((float)bVar3 / fVar2) * (float)iVar6);
            }
          }
          iVar4 = iVar4 + iVar6;
          if (iVar11 < iVar4) break;
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar1;
        }
        if (*(longlong **)(lVar10 + 0x20) <= plVar9) {
          _invalid_parameter_noinfo();
        }
        plVar9 = plVar9 + 1;
      }
      if (local_58 != (longlong *)0x0) {
        operator_delete(local_58);
      }
      local_58 = (longlong *)0x0;
      local_50 = (longlong *)0x0;
      local_48 = 0;
      operator_delete(local_70[0]);
    }
  }
  return plVar7;
}

// ==== CMonster::helper_14026e120  @14026e120  [medium:callgraph-r1]  (orig: FUN_14026e120)
longlong * FUN_14026e120(longlong param_1,ushort param_2,undefined8 param_3,undefined8 param_4)

{
  longlong lVar1;
  undefined8 *puVar2;
  longlong lVar3;
  ulong uVar4;
  int iVar5;
  int iVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  uint uVar10;
  longlong *plVar12;
  ushort local_res10 [4];
  undefined8 *local_70;
  longlong local_68;
  undefined8 *local_60 [3];
  longlong *local_48;
  longlong *local_40;
  undefined8 local_38;
  longlong *plVar11;
  
  plVar12 = (longlong *)0x0;
  if (param_2 == 0) {
    plVar7 = (longlong *)0x0;
  }
  else {
    local_res10[0] = param_2;
    FUN_14026d450(param_1 + 0x90,&local_70,local_res10,param_4,0xfffffffffffffffe);
    puVar2 = local_70;
    lVar1 = *(longlong *)(param_1 + 0xc0);
    if ((local_70 == (undefined8 *)0x0) || (local_70 != *(undefined8 **)(param_1 + 0x90))) {
      _invalid_parameter_noinfo();
    }
    lVar3 = local_68;
    if (local_68 == lVar1) {
      plVar7 = (longlong *)0x0;
    }
    else {
      FUN_14014daf0(param_1 + 0xd0,&local_70,local_res10);
      lVar1 = *(longlong *)(param_1 + 0x100);
      if ((local_70 == (undefined8 *)0x0) || (local_70 != *(undefined8 **)(param_1 + 0xd0))) {
        _invalid_parameter_noinfo();
      }
      if (local_68 == lVar1) {
        plVar7 = (longlong *)0x0;
      }
      else {
        if (local_70 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = plVar12;
        }
        else {
          plVar9 = (longlong *)*local_70;
        }
        if (local_68 == plVar9[6]) {
          _invalid_parameter_noinfo();
        }
        iVar6 = *(int *)(local_68 + 0x1c);
        uVar4 = tq::TimeGet(0);
        iVar5 = rand();
        srand(iVar5 + uVar4 + (uint)param_2);
        iVar6 = tq::RandGet(iVar6);
        if (puVar2 == (undefined8 *)0x0) {
          _invalid_parameter_noinfo();
          plVar9 = plVar12;
        }
        else {
          plVar9 = (longlong *)*puVar2;
        }
        if (lVar3 == plVar9[6]) {
          _invalid_parameter_noinfo();
        }
        FUN_140267b90(local_60,lVar3 + 0x20);
        plVar9 = local_48;
        plVar11 = plVar12;
        puVar2 = local_60[0];
        if (local_40 < local_48) {
          _invalid_parameter_noinfo();
          puVar2 = local_60[0];
        }
        while( true ) {
          plVar8 = local_40;
          if (local_40 < local_48) {
            _invalid_parameter_noinfo();
          }
          if ((puVar2 == (undefined8 *)0x0) || (puVar2 != local_60[0])) {
            _invalid_parameter_noinfo();
          }
          plVar7 = plVar12;
          if (plVar9 == plVar8) break;
          if (puVar2 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar12;
          }
          else {
            plVar8 = (longlong *)*puVar2;
          }
          if ((longlong *)plVar8[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          plVar7 = (longlong *)*plVar9;
          if (plVar7 != (longlong *)0x0) {
            plVar8 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,3);
            iVar5 = (**(code **)(*plVar8 + 0x48))(plVar8);
            uVar10 = (int)plVar11 + iVar5;
            plVar11 = (longlong *)(ulonglong)uVar10;
            if (iVar6 < (int)uVar10) break;
          }
          if (puVar2 == (undefined8 *)0x0) {
            _invalid_parameter_noinfo();
            plVar8 = plVar12;
          }
          else {
            plVar8 = (longlong *)*puVar2;
          }
          if ((longlong *)plVar8[4] <= plVar9) {
            _invalid_parameter_noinfo();
          }
          plVar9 = plVar9 + 1;
        }
        if (local_48 != (longlong *)0x0) {
          operator_delete(local_48);
        }
        local_48 = (longlong *)0x0;
        local_40 = (longlong *)0x0;
        local_38 = 0;
        operator_delete(local_60[0]);
      }
    }
  }
  return plVar7;
}

// ==== CMonster::helper_14026e380  @14026e380  [medium:callgraph-r2]  (orig: FUN_14026e380)
undefined8 FUN_14026e380(longlong param_1,uint param_2)

{
  char cVar1;
  undefined8 *puVar2;
  longlong lVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  ulong uVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 *puVar14;
  longlong lVar15;
  int iVar16;
  undefined8 uVar17;
  longlong local_58;
  undefined8 *local_50;
  longlong local_48;
  undefined8 local_40;
  longlong *local_38;
  longlong local_30;
  
  puVar14 = (undefined8 *)(*(undefined8 **)(param_1 + 0x140))[1];
  uVar17 = 5;
  cVar1 = *(char *)((longlong)puVar14 + 0x29);
  puVar2 = *(undefined8 **)(param_1 + 0x140);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar14 + 3) < param_2) {
      puVar11 = (undefined8 *)puVar14[2];
      puVar14 = puVar2;
    }
    else {
      puVar11 = (undefined8 *)*puVar14;
    }
    puVar2 = puVar14;
    puVar14 = puVar11;
    cVar1 = *(char *)((longlong)puVar11 + 0x29);
  }
  puVar14 = *(undefined8 **)(param_1 + 0x140);
  local_50 = puVar2;
  local_58 = *(longlong *)(param_1 + 0x110);
  if (*(longlong *)(param_1 + 0x110) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar2 == puVar14) || (param_2 < *(uint *)(puVar2 + 3))) {
    plVar13 = &local_48;
    local_40 = *(undefined8 *)(param_1 + 0x140);
    local_48 = *(longlong *)(param_1 + 0x110);
  }
  else {
    plVar13 = &local_58;
  }
  plVar12 = (longlong *)*plVar13;
  lVar15 = *(longlong *)(param_1 + 0x140);
  local_38 = plVar12;
  local_30 = plVar13[1];
  if ((plVar12 == (longlong *)0x0) || (plVar12 != *(longlong **)(param_1 + 0x110))) {
    _invalid_parameter_noinfo();
  }
  lVar3 = local_30;
  if (local_30 != lVar15) {
    if (plVar12 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar15 = 0;
    }
    else {
      lVar15 = *plVar12;
    }
    if (lVar3 == *(longlong *)(lVar15 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar13 = *(longlong **)(lVar3 + 0x20);
    if (plVar13 != (longlong *)0x0) {
      iVar16 = 2;
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,2);
      iVar4 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,3);
      iVar5 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,4);
      iVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,5);
      iVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,6);
      iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,7);
      iVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      iVar4 = iVar9 + iVar8 + iVar7 + iVar6 + iVar5 + iVar4;
      if (iVar4 != 0) {
        uVar10 = tq::TimeGet(0);
        iVar5 = rand();
        srand(iVar5 + uVar10);
        iVar5 = tq::RandGet(iVar4);
        iVar6 = 0;
        do {
          plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,iVar16);
          iVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
          iVar6 = iVar6 + iVar7;
          if (iVar5 < iVar6) break;
          iVar16 = iVar16 + 1;
        } while (iVar16 < 8);
        switch(iVar16) {
        case 3:
          uVar17 = 6;
          break;
        case 4:
          uVar17 = 7;
          break;
        case 5:
          uVar17 = 8;
          break;
        case 6:
          uVar17 = 9;
          break;
        case 7:
          uVar17 = 0;
        }
      }
    }
  }
  return uVar17;
}

// ==== CMonster::helper_14026eac0  @14026eac0  [medium:callgraph-r1]  (orig: FUN_14026eac0)
longlong FUN_14026eac0(undefined8 param_1,int param_2,int param_3,int param_4)

{
  uint *puVar1;
  uint *puVar2;
  byte bVar3;
  int iVar4;
  longlong lVar5;
  longlong *plVar6;
  longlong lVar7;
  ulonglong uVar8;
  uint uVar9;
  uint uVar10;
  uint local_res10 [2];
  longlong *local_78;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  longlong *local_68;
  undefined8 uStack_60;
  longlong *local_58 [3];
  uint *local_40;
  uint *local_38;
  longlong local_30;
  
  uVar9 = param_2 * 1000 + 5;
  local_res10[0] = uVar9;
  local_78 = operator_new(8);
  if (local_78 == (longlong *)0x0) {
    local_58[0] = (longlong *)0x0;
  }
  else {
    *local_78 = (longlong)local_58;
    local_58[0] = local_78;
  }
  local_40 = (uint *)0x0;
  local_38 = (uint *)0x0;
  local_30 = 0;
  uVar10 = 1;
  local_68 = local_78;
  do {
    if (0x62 < (uVar9 % 1000) / 10) {
      if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
        log_InlineLogDBERROR
                  (
                  "table:cq_itemtype, CMonsterDropRuleMgr::GetEquipTypeByLev(), can not find item, type(%u) maxlev(%d), minlev(%d),"
                  );
      }
      goto LAB_14026ed9a;
    }
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar5 = (**(code **)(*plVar6 + 0x70))(plVar6,uVar9);
    if (lVar5 != 0) {
      plVar6 = (longlong *)
               (**(code **)(**(longlong **)(lVar5 + 8) + 0x10))(*(longlong **)(lVar5 + 8),4);
      iVar4 = (**(code **)(*plVar6 + 0x48))(plVar6);
      puVar2 = local_38;
      if (param_4 <= iVar4) {
        if (param_3 < iVar4) goto LAB_14026ed9a;
        if (local_40 == (uint *)0x0) {
          uVar8 = 0;
        }
        else {
          uVar8 = local_30 - (longlong)local_40 >> 2;
        }
        if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) < uVar8) {
          *local_38 = uVar9;
          local_38 = local_38 + 1;
        }
        else {
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          puVar1 = local_40;
          plVar6 = local_58[0];
          local_68 = local_58[0];
          uStack_60 = puVar2;
          if (((longlong)local_38 - (longlong)local_40 & 0xfffffffffffffffcU) == 0) {
            lVar5 = 0;
          }
          else {
            if (local_38 < local_40) {
              _invalid_parameter_noinfo();
            }
            if ((plVar6 == (longlong *)0x0) || (plVar6 != local_58[0])) {
              _invalid_parameter_noinfo();
            }
            lVar5 = (longlong)puVar2 - (longlong)puVar1 >> 2;
          }
          local_78 = local_68;
          uStack_70 = (undefined4)uStack_60;
          uStack_6c = uStack_60._4_4_;
          FUN_140036c20(local_58,&local_78,1,local_res10);
          puVar2 = local_40;
          if (local_38 < local_40) {
            _invalid_parameter_noinfo();
          }
          plVar6 = local_58[0];
          if (local_58[0] == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar7 = 0;
          }
          else {
            lVar7 = *local_58[0];
          }
          if (puVar2 + lVar5 <= *(uint **)(lVar7 + 0x20)) {
            if (plVar6 == (longlong *)0x0) {
              lVar7 = 0;
            }
            else {
              lVar7 = *plVar6;
            }
            if (*(uint **)(lVar7 + 0x18) <= puVar2 + lVar5) goto LAB_14026ed25;
          }
          _invalid_parameter_noinfo();
        }
LAB_14026ed25:
        if (param_3 == param_4) goto LAB_14026ed9a;
      }
    }
    uVar9 = uVar9 + 10;
    uVar10 = uVar10 + 1;
    local_res10[0] = uVar9;
  } while (uVar10 < 0x3e9);
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_14026ed9a:
  iVar4 = (int)((longlong)local_38 - (longlong)local_40 >> 2);
  if (iVar4 == 0) {
    if (local_40 != (uint *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (uint *)0x0;
    local_38 = (uint *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
    lVar5 = 0;
  }
  else {
    iVar4 = tq::RandGet(iVar4);
    if ((ulonglong)((longlong)local_38 - (longlong)local_40 >> 2) <= (ulonglong)(longlong)iVar4) {
      _invalid_parameter_noinfo();
    }
    uVar9 = (local_40[iVar4] / 10) * 10;
    bVar3 = FUN_14026e380(param_1,uVar9);
    plVar6 = DAT_140975b60;
    if (DAT_140975b60 == (longlong *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar6 = (longlong *)0x0;
    }
    lVar5 = (**(code **)(*plVar6 + 0x70))(plVar6,(uint)bVar3 + (uVar9 / 10) * 10);
    if (lVar5 == 0) {
      log_InlineLogDBERROR
                (
                "table:cq_itemtype, CMonsterDropRuleMgr::GetEquipTypeByLev(), can not find itemtype(%u), maybe cq_itemtype not config."
                );
    }
    if (local_40 != (uint *)0x0) {
      operator_delete(local_40);
    }
    local_40 = (uint *)0x0;
    local_38 = (uint *)0x0;
    local_30 = 0;
    operator_delete(local_58[0]);
  }
  return lVar5;
}

// ==== CMonster::helper_14026ef10  @14026ef10  [medium:callgraph-r0]  (orig: FUN_14026ef10)
void FUN_14026ef10(undefined8 param_1,undefined8 param_2,undefined4 *param_3,undefined1 param_4)

{
  longlong lVar1;
  short sVar2;
  undefined2 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  longlong *plVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong lVar15;
  
  plVar12 = (longlong *)FUN_14026dde0(param_1,param_2,param_4);
  if (plVar12 != (longlong *)0x0) {
    plVar13 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,3);
    sVar2 = (**(code **)(*plVar13 + 0x30))(plVar13);
    plVar13 = (longlong *)FUN_14026e120(param_1,sVar2);
    if (plVar13 != (longlong *)0x0) {
      if (sVar2 == 9) {
        plVar14 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,2);
        uVar4 = (**(code **)(*plVar14 + 0x40))(plVar14);
        plVar14 = DAT_140975b60;
        if (DAT_140975b60 == (longlong *)0x0) {
          log_InlineLogERROR(&DAT_1406d9c10);
          plVar14 = (longlong *)0x0;
        }
        lVar15 = (**(code **)(*plVar14 + 0x70))(plVar14,uVar4);
      }
      else {
        plVar14 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,4);
        uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
        plVar14 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,5);
        uVar5 = (**(code **)(*plVar14 + 0x48))(plVar14);
        plVar14 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,2);
        uVar9 = (**(code **)(*plVar14 + 0x50))(plVar14);
        lVar15 = FUN_14026eac0(param_1,uVar9,uVar5,uVar4);
      }
      if (lVar15 != 0) {
        plVar14 = (longlong *)
                  (**(code **)(**(longlong **)(lVar15 + 8) + 0x10))(*(longlong **)(lVar15 + 8),0x16)
        ;
        iVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
        if (iVar6 < 1) {
          iVar6 = 1;
        }
        plVar14 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,10);
        iVar7 = (**(code **)(*plVar14 + 0x48))(plVar14);
        plVar14 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,9);
        iVar8 = (**(code **)(*plVar14 + 0x48))(plVar14);
        if ((iVar8 < iVar7) && (iVar7 - iVar8 != 0)) {
          iVar7 = tq::RandGet(iVar7 - iVar8);
          iVar7 = ((iVar7 + 1 + iVar8) * iVar6) / 100;
        }
        else {
          lVar1 = (longlong)iVar8 * (longlong)iVar6 +
                  SUB168(SEXT816(-0x5c28f5c28f5c28f5) * SEXT816((longlong)iVar8 * (longlong)iVar6),8
                        );
          iVar7 = (int)(lVar1 >> 6) - (int)(lVar1 >> 0x3f);
        }
        if (iVar7 < 1) {
          iVar7 = 1;
        }
        iVar8 = FUN_14026ba40(param_1,plVar12);
        uVar4 = 0;
        if (iVar8 == 1) {
          uVar5 = 0xff;
          uVar4 = 0;
        }
        else {
          uVar5 = 0;
          if (iVar8 == 2) {
            uVar5 = 0xff;
            uVar4 = 0xff;
          }
        }
        uVar9 = FUN_14026bb40(param_1,plVar13);
        uVar10 = FUN_14026bc30(param_1);
        memset(param_3,0,100);
        *param_3 = 0;
        param_3[2] = 0;
        param_3[3] = 0;
        plVar12 = (longlong *)
                  (**(code **)(**(longlong **)(lVar15 + 8) + 0x10))(*(longlong **)(lVar15 + 8),0);
        uVar11 = (**(code **)(*plVar12 + 0x40))(plVar12);
        param_3[1] = uVar11;
        param_3[4] = iVar7;
        param_3[5] = iVar6;
        param_3[9] = uVar5;
        param_3[10] = uVar4;
        param_3[0xd] = uVar9;
        param_3[0xe] = uVar10;
        *(undefined2 *)(param_3 + 0x12) = 0;
        *(undefined2 *)((longlong)param_3 + 0x4a) = 0;
        plVar12 = (longlong *)(**(code **)(*plVar13 + 0x10))(plVar13,10);
        uVar3 = (**(code **)(*plVar12 + 0x30))(plVar12);
        *(undefined2 *)(param_3 + 0x13) = uVar3;
        param_3[0x18] = 1;
      }
    }
  }
  return;
}

// ==== CMonster::helper_140272650  @140272650  [medium:callgraph-r2]  (orig: FUN_140272650)
void FUN_140272650(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMonster::helper_140272d70  @140272d70  [medium:callgraph-r2]  (orig: FUN_140272d70)
void FUN_140272d70(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 4)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 4);
  return;
}

// ==== CMonster::helper_140273570  @140273570  [medium:callgraph-r2]  (orig: FUN_140273570)
void * FUN_140273570(void *param_1,longlong param_2,longlong param_3)

{
  longlong lVar1;
  void *_Dst;
  
  lVar1 = param_2 - (longlong)param_1 >> 2;
  _Dst = (void *)(param_3 + lVar1 * -4);
  if (0 < lVar1) {
    memmove_s(_Dst,lVar1 * 4,param_1,lVar1 * 4);
  }
  return _Dst;
}

// ==== CMonster::helper_140273f50  @140273f50  [medium:callgraph-r2]  (orig: FUN_140273f50)
void * FUN_140273f50(undefined8 param_1,void *param_2,longlong param_3,void *param_4)

{
  rsize_t _DstSize;
  longlong lVar1;
  
  lVar1 = param_3 - (longlong)param_2 >> 2;
  _DstSize = lVar1 * 4;
  if (lVar1 != 0) {
    memmove_s(param_4,_DstSize,param_2,_DstSize);
  }
  return (void *)(_DstSize + (longlong)param_4);
}

// ==== CMonster::helper_140274790  @140274790  [medium:callgraph-r1]  (orig: FUN_140274790)
void FUN_140274790(longlong param_1,longlong param_2,ulonglong param_3,undefined4 *param_4)

{
  undefined4 uVar1;
  void *pvVar2;
  void *_Dst;
  undefined8 uVar3;
  longlong lVar4;
  ulonglong uVar5;
  undefined4 *puVar6;
  longlong lVar7;
  rsize_t rVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  undefined4 *puVar11;
  
  lVar4 = *(longlong *)(param_1 + 0x18);
  if (lVar4 == 0) {
    uVar5 = 0;
  }
  else {
    uVar5 = *(longlong *)(param_1 + 0x28) - lVar4 >> 2;
  }
  uVar9 = 0;
  if (param_3 != 0) {
    lVar7 = *(longlong *)(param_1 + 0x20);
    lVar4 = lVar7 - lVar4 >> 2;
    if (0x3fffffffffffffffU - lVar4 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140272650();
    }
    uVar10 = param_3 + lVar4;
    if (uVar5 < uVar10) {
      if (uVar5 <= 0x3fffffffffffffff - (uVar5 >> 1)) {
        uVar9 = uVar5 + (uVar5 >> 1);
      }
      if (uVar9 < uVar10) {
        uVar9 = uVar10;
      }
      _Dst = (void *)FUN_140272d70(param_1 + 0x10,uVar9);
      lVar4 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 2;
      puVar6 = (undefined4 *)((longlong)_Dst + lVar4 * 4);
      for (uVar5 = param_3; uVar5 != 0; uVar5 = uVar5 - 1) {
        *puVar6 = *param_4;
        puVar6 = puVar6 + 1;
      }
      lVar7 = *(longlong *)(param_2 + 8) - (longlong)*(void **)(param_1 + 0x18) >> 2;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 2;
        memmove_s(_Dst,rVar8,*(void **)(param_1 + 0x18),rVar8);
      }
      lVar7 = *(longlong *)(param_1 + 0x20) - (longlong)*(void **)(param_2 + 8) >> 2;
      if (lVar7 != 0) {
        rVar8 = lVar7 << 2;
        memmove_s((void *)((longlong)_Dst + (lVar4 + param_3) * 4),rVar8,*(void **)(param_2 + 8),
                  rVar8);
      }
      pvVar2 = *(void **)(param_1 + 0x18);
      lVar4 = *(longlong *)(param_1 + 0x20);
      if (pvVar2 != (void *)0x0) {
        operator_delete(pvVar2);
      }
      *(void **)(param_1 + 0x28) = (void *)((longlong)_Dst + uVar9 * 4);
      *(void **)(param_1 + 0x20) =
           (void *)((longlong)_Dst + (param_3 + (lVar4 - (longlong)pvVar2 >> 2)) * 4);
      *(void **)(param_1 + 0x18) = _Dst;
    }
    else if ((ulonglong)(lVar7 - *(longlong *)(param_2 + 8) >> 2) < param_3) {
      uVar1 = *param_4;
      FUN_140273f50(param_1,*(longlong *)(param_2 + 8),lVar7,
                    *(longlong *)(param_2 + 8) + param_3 * 4);
      puVar6 = *(undefined4 **)(param_1 + 0x20);
      for (lVar4 = param_3 - ((longlong)puVar6 - *(longlong *)(param_2 + 8) >> 2); lVar4 != 0;
          lVar4 = lVar4 + -1) {
        *puVar6 = uVar1;
        puVar6 = puVar6 + 1;
      }
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 4;
      lVar4 = *(longlong *)(param_1 + 0x20);
      for (puVar6 = *(undefined4 **)(param_2 + 8); puVar6 != (undefined4 *)(lVar4 + param_3 * -4);
          puVar6 = puVar6 + 1) {
        *puVar6 = uVar1;
      }
    }
    else {
      uVar1 = *param_4;
      lVar4 = lVar7 + param_3 * -4;
      uVar3 = FUN_140273f50(param_1,lVar4,lVar7,lVar7);
      *(undefined8 *)(param_1 + 0x20) = uVar3;
      FUN_140273570(*(undefined8 *)(param_2 + 8),lVar4,lVar7);
      puVar11 = *(undefined4 **)(param_2 + 8);
      puVar6 = puVar11 + param_3;
      for (; puVar11 != puVar6; puVar11 = puVar11 + 1) {
        *puVar11 = uVar1;
      }
    }
  }
  return;
}

// ==== CMonster::helper_1402c7380  @1402c7380  [medium:callgraph-r3]  (orig: FUN_1402c7380)
void FUN_1402c7380(int param_1,int param_2,int param_3,int param_4)

{
  FUN_1402c40d0(param_3 - param_1,param_4 - param_2);
  return;
}

// ==== CMonster::helper_1402f2850  @1402f2850  [medium:callgraph-r1]  (orig: FUN_1402f2850)
undefined1 FUN_1402f2850(undefined8 param_1,short param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610(param_1,param_3);
  if (lVar2 == 0) {
    return 1;
  }
  if (param_2 == 0) {
    uVar1 = FUN_1404b96c0(lVar2,0,param_4);
    return uVar1;
  }
  *(undefined1 *)(lVar2 + 0x8c) = 0;
  uVar1 = FUN_1404b96c0(lVar2,param_2,param_4);
  *(undefined1 *)(lVar2 + 0x8c) = 1;
  return uVar1;
}

// ==== CMonster::helper_1402f2e70  @1402f2e70  [medium:callgraph-r2]  (orig: FUN_1402f2e70)
undefined1
FUN_1402f2e70(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_140498a50(lVar2,param_3,param_4);
    return uVar1;
  }
  return 0;
}

// ==== CMonster::helper_1402f2f30  @1402f2f30  [medium:callgraph-r2]  (orig: FUN_1402f2f30)
undefined1 FUN_1402f2f30(undefined8 param_1,undefined8 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_1404a1a60(lVar2,param_3);
    return uVar1;
  }
  return 0;
}

// ==== CMonster::helper_1402f2f60  @1402f2f60  [medium:callgraph-r3]  (orig: FUN_1402f2f60)
undefined1
FUN_1402f2f60(undefined8 param_1,undefined8 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  undefined1 uVar1;
  longlong lVar2;
  
  lVar2 = FUN_1402f1610();
  if (lVar2 != 0) {
    uVar1 = FUN_1404bbf20(lVar2,param_3,param_4,param_5,param_6);
    return uVar1;
  }
  return 0;
}

// ==== CMonster::helper_14031cc80  @14031cc80  [medium:callgraph-r2]  (orig: FUN_14031cc80)
int FUN_14031cc80(longlong *param_1,longlong *param_2,int param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  longlong lVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *local_res8;
  longlong local_res20;
  
  if (((param_1 == (longlong *)0x0) || (param_2 == (longlong *)0x0)) || (DAT_140976010 == 0)) {
    return 0;
  }
  local_res8 = (longlong *)0x0;
  local_res20 = 0;
  (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_res8);
  if (local_res8 == (longlong *)0x0) {
    cVar2 = (**(code **)(*param_2 + 0x298))(param_2,0x1040,&local_res20);
    if (cVar2 == '\0') {
      return param_3;
    }
    cVar2 = FUN_14015ff50(local_res20);
    if (cVar2 == '\0') {
      return param_3;
    }
    iVar3 = (**(code **)(*(longlong *)(local_res20 + 0x10) + 0x70))(local_res20 + 0x10);
    uVar4 = (**(code **)(**(longlong **)(local_res20 + 0x60) + 0x10))
                      (*(longlong **)(local_res20 + 0x60),4);
  }
  else {
    lVar6 = (**(code **)(local_res8[2] + 0x2b0))(local_res8 + 2);
    if (lVar6 != 0) {
      return param_3;
    }
    cVar2 = FUN_14038bc80(local_res8);
    if (cVar2 != '\0') {
      return 0;
    }
    iVar3 = (**(code **)(local_res8[2] + 0x70))(local_res8 + 2);
    uVar4 = (**(code **)(*local_res8 + 0x50))();
  }
  lVar7 = (**(code **)(*param_1 + 0x2b0))(param_1);
  lVar6 = DAT_140976010;
  if (lVar7 != 0) {
    plVar1 = (longlong *)(lVar7 + 0x10);
    iVar5 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x70))(plVar1);
    plVar8 = (longlong *)FUN_1404c27e0(lVar6,uVar4,iVar5 - iVar3);
    lVar6 = DAT_140976010;
    if (plVar8 == (longlong *)0x0) {
      iVar5 = (**(code **)(*plVar1 + 0x70))(plVar1);
      plVar8 = (longlong *)FUN_1404c27e0(lVar6,0,iVar5 - iVar3);
      if (plVar8 == (longlong *)0x0) {
        return param_3;
      }
    }
    cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0xd);
    if ((((cVar2 == '\0') && (cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x12), cVar2 == '\0'))
        && ((cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x27), cVar2 == '\0' &&
            ((cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x28), cVar2 == '\0' &&
             (cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x9f), cVar2 == '\0')))))) &&
       (cVar2 = (**(code **)(*plVar1 + 0x2d8))(plVar1,0x96), cVar2 == '\0')) {
      iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,7);
    }
    else {
      iVar3 = (**(code **)(*plVar8 + 0x10))(plVar8,8);
    }
    param_3 = ((iVar3 + 100) * param_3) / 100;
  }
  return param_3;
}

// ==== CMonster::helper_14031d0f0  @14031d0f0  [medium:callgraph-r3]  (orig: FUN_14031d0f0)
void FUN_14031d0f0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x140),0x2c);
                    /* WARNING: Could not recover jumptable at 0x00014031d113. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::helper_14031d7e0  @14031d7e0  [medium:callgraph-r2]  (orig: FUN_14031d7e0)
int FUN_14031d7e0(longlong *param_1,longlong *param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int nNumerator;
  longlong lVar4;
  longlong *plVar5;
  longlong local_res8;
  
  if ((param_1 != (longlong *)0x0) && (param_2 != (longlong *)0x0)) {
    local_res8 = 0;
    cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_res8);
    if (cVar1 != '\0') {
      lVar4 = (**(code **)(*param_1 + 0x2b0))(param_1);
      if (lVar4 != 0) {
        plVar5 = (longlong *)
                 (**(code **)(*(longlong *)**(undefined8 **)(local_res8 + 0x140) + 0x10))
                           ((longlong *)**(undefined8 **)(local_res8 + 0x140),0x2b);
        iVar2 = (**(code **)(*plVar5 + 0x48))(plVar5);
        iVar3 = FUN_14018eb30(lVar4);
        if (-1 < iVar3 - iVar2) {
          nNumerator = FUN_14031d0f0(local_res8);
          iVar2 = MulDiv(iVar3 - iVar2,nNumerator,100);
          return iVar2;
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMonster::helper_14032b550  @14032b550  [medium:callgraph-r0]  (orig: FUN_14032b550)
void FUN_14032b550(longlong *param_1,undefined2 param_2)

{
  longlong lVar1;
  undefined4 uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)CurrentInstanceGet();
  if ((plVar3 != (longlong *)0x0) &&
     (plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,0x10), plVar3 != (longlong *)0x0)) {
    lVar1 = *plVar3;
    uVar2 = (**(code **)(*param_1 + 8))(param_1);
    (**(code **)(lVar1 + 0x10))(plVar3,uVar2,param_2);
  }
  return;
}

// ==== CMonster::helper_14037cf50  @14037cf50  [medium:callgraph-r0]  (orig: FUN_14037cf50)
undefined8
FUN_14037cf50(longlong *param_1,int param_2,longlong param_3,undefined8 param_4,int param_5,
             int param_6,char param_7)

{
  int iVar1;
  int iVar2;
  ulong uVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  undefined4 local_res20;
  undefined4 uStackX_24;
  
  if (param_3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if ((0 < param_5) && ((param_7 == '\0' || (param_5 < 0x989681)))) {
    iVar1 = param_5 / 0x19 + 0x1e;
    iVar2 = 0xb4;
    if (iVar1 < 0xb4) {
      iVar2 = iVar1;
    }
    *(int *)((longlong)param_1 + 0x94) = iVar2;
    uVar3 = tq::TimeGet(0);
    param_1[0x14] = param_3;
    local_res20 = (undefined4)param_4;
    *(undefined4 *)(param_1 + 0x10) = local_res20;
    uStackX_24 = (undefined4)((ulonglong)param_4 >> 0x20);
    *(uint *)(param_1 + 0x13) = uVar3 / 1000;
    *(undefined4 *)((longlong)param_1 + 0x84) = uStackX_24;
    if (param_5 < 0xb) {
      uVar5 = 0x10a1d0;
    }
    else if (param_5 < 0x65) {
      uVar5 = 0x10a1da;
    }
    else if (param_5 < 0x3e9) {
      uVar5 = 0x10a1e4;
    }
    else if (param_5 < 0x7d1) {
      uVar5 = 0x10a5b8;
    }
    else {
      uVar5 = 0x10a5cc;
      if (param_5 < 0x1389) {
        uVar5 = 0x10a5c2;
      }
    }
    memset((void *)((longlong)param_1 + 0x1c),0,100);
    *(undefined4 *)(param_1 + 4) = uVar5;
    *(int *)(param_1 + 3) = param_2;
    *(undefined4 *)((longlong)param_1 + 0x1c) = 0;
    *(undefined4 *)((longlong)param_1 + 0x24) = 0;
    *(int *)(param_1 + 5) = param_6;
    *(int *)((longlong)param_1 + 0x2c) = param_5;
    *(undefined4 *)(param_1 + 6) = 10000000;
    *(undefined4 *)((longlong)param_1 + 0x34) = 0;
    *(undefined4 *)(param_1 + 7) = 0xfe;
    *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
    *(undefined4 *)(param_1 + 8) = 0;
    *(undefined4 *)((longlong)param_1 + 0x44) = 0;
    *(undefined4 *)(param_1 + 9) = 0;
    *(undefined4 *)((longlong)param_1 + 0x4c) = 0;
    *(undefined4 *)(param_1 + 10) = 0;
    if (param_6 != 0) {
      *(undefined4 *)((longlong)param_1 + 0x8c) = 0x1e;
      FUN_140013670();
    }
    uVar4 = (**(code **)(*param_1 + 0x20))(param_1);
    FUN_1402c90f0(param_1[0x14],uVar4,0);
    FUN_14037c190(param_1);
    return 1;
  }
  return 0;
}

// ==== CMonster::helper_140386a50  @140386a50  [medium:callgraph-r1]  (orig: FUN_140386a50)
undefined8
FUN_140386a50(longlong param_1,int param_2,undefined2 param_3,undefined2 param_4,undefined1 param_5,
             undefined2 param_6,undefined2 param_7,int param_8,undefined4 param_9,
             undefined4 param_10,undefined1 param_11)

{
  char *pcVar1;
  undefined8 uVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    FUN_1402b5600();
    *(undefined4 *)(param_1 + 0xc) = 0x34;
    *(undefined4 *)(param_1 + 8) = 0x451;
    **(int **)(param_1 + 0x428) = param_2;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = param_3;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 10) = param_4;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xe) = param_5;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 4) = param_6;
    *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 6) = param_7;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0xf) = 0;
    *(undefined1 *)(*(longlong *)(param_1 + 0x428) + 0x10) = param_11;
    if (param_8 != 0) {
      *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x20;
      *(int *)((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x14 +
              *(longlong *)(param_1 + 0x428)) = param_8;
      *(undefined4 *)
       ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x18 +
       *(longlong *)(param_1 + 0x428)) = param_9;
      *(undefined4 *)
       ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x1c +
       *(longlong *)(param_1 + 0x428)) = param_10;
      *(undefined4 *)
       (((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) + 1) * 0x20 +
       *(longlong *)(param_1 + 0x428)) = 0;
      pcVar1 = (char *)(*(longlong *)(param_1 + 0x428) + 0xf);
      *pcVar1 = *pcVar1 + '\x01';
    }
    uVar2 = 1;
  }
  return uVar2;
}

// ==== CMonster::helper_140387150  @140387150  [medium:callgraph-r1]  (orig: FUN_140387150)
bool FUN_140387150(longlong param_1,int param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5,undefined4 param_6,undefined4 param_7,undefined4 param_8,
                  undefined4 param_9)

{
  char *pcVar1;
  bool bVar2;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  bVar2 = (longlong)*(int *)(param_1 + 0xc) + 0x20U < 0x400;
  if (bVar2) {
    *(int *)(param_1 + 0xc) = *(int *)(param_1 + 0xc) + 0x20;
    *(int *)((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x14 +
            *(longlong *)(param_1 + 0x428)) = param_2;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x18 +
     *(longlong *)(param_1 + 0x428)) = param_3;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x1c +
     *(longlong *)(param_1 + 0x428)) = param_4;
    *(undefined4 *)
     (((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) + 1) * 0x20 +
     *(longlong *)(param_1 + 0x428)) = param_5;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x24 +
     *(longlong *)(param_1 + 0x428)) = param_6;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x28 +
     *(longlong *)(param_1 + 0x428)) = param_7;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x2c +
     *(longlong *)(param_1 + 0x428)) = param_8;
    *(undefined4 *)
     ((ulonglong)*(byte *)(*(longlong *)(param_1 + 0x428) + 0xf) * 0x20 + 0x30 +
     *(longlong *)(param_1 + 0x428)) = param_9;
    pcVar1 = (char *)(*(longlong *)(param_1 + 0x428) + 0xf);
    *pcVar1 = *pcVar1 + '\x01';
  }
  return bVar2;
}

// ==== CMonster::helper_140387840  @140387840  [medium:callgraph-r0]  (orig: FUN_140387840)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140387840(longlong param_1)

{
  int iVar1;
  undefined7 uVar3;
  undefined8 uVar2;
  undefined1 auStack_498 [32];
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  if (*(char *)(param_1 + 0x148) == '\x02') {
    uVar3 = (undefined7)(local_18 >> 8);
  }
  else {
    FUN_14039ed70(local_468);
    iVar1 = FUN_14039eef0(local_468,param_1 + 0x10,0,0);
    if (iVar1 != 0) {
      (**(code **)(*(longlong *)(param_1 + 0x10) + 0x348))(param_1 + 0x10,local_468,0);
    }
    uVar2 = FUN_14039edf0(local_468);
    uVar3 = (undefined7)((ulonglong)uVar2 >> 8);
  }
  return CONCAT71(uVar3,1);
}

// ==== CMonster::helper_1403878e0  @1403878e0  [medium:callgraph-r2]  (orig: FUN_1403878e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403878e0(longlong *param_1)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  undefined8 uVar4;
  undefined7 uVar5;
  undefined1 auStack_4b8 [32];
  undefined2 local_498;
  undefined2 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if ((int)param_1[0x2b] == 0) {
    *(undefined4 *)(param_1 + 0x2b) = 1;
    FUN_140362560(local_468);
    uVar1 = (**(code **)(*param_1 + 8))(param_1);
    local_480 = 0;
    local_488 = 0;
    local_490 = 0x87;
    local_498 = 0;
    iVar2 = FUN_140362620(local_468,uVar1,0,0);
    if (iVar2 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,1);
      iVar2 = (**(code **)(*param_1 + 8))(param_1);
      if (iVar2 - 0xaae61U < 99999) {
        lVar3 = (**(code **)(param_1[2] + 0x2b0))(param_1 + 2);
        if (lVar3 != 0) {
          lVar3 = (**(code **)(param_1[2] + 0x2b0))(param_1 + 2);
          (**(code **)(*(longlong *)(lVar3 + 0x10) + 0x350))((longlong *)(lVar3 + 0x10),local_468);
        }
      }
    }
    uVar4 = FUN_1403625e0(local_468);
    uVar5 = (undefined7)((ulonglong)uVar4 >> 8);
  }
  else {
    uVar5 = (undefined7)(local_18 >> 8);
  }
  return CONCAT71(uVar5,1);
}

// ==== CMonster::vfunc_107  @140387a00  [high:rtti-vtable]  (orig: FUN_140387a00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_140387a00(longlong *param_1,char *param_2,undefined8 param_3,undefined8 param_4)

{
  undefined1 uVar1;
  int iVar2;
  undefined8 uVar3;
  undefined8 local_res18;
  undefined8 local_res20;
  undefined1 auStack_8e8 [32];
  undefined8 local_8c8;
  undefined4 local_8c0;
  undefined2 local_8b8;
  undefined2 local_8b0;
  undefined4 local_8a8;
  undefined4 local_8a0;
  undefined1 local_898;
  undefined8 local_888;
  undefined1 local_878 [1104];
  char local_428 [1023];
  undefined1 local_29;
  ulonglong local_28;
  
  local_888 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_8e8;
  if (param_2 == (char *)0x0) {
    uVar1 = 0;
  }
  else {
    local_res18 = param_3;
    local_res20 = param_4;
    _vsnprintf(local_428,0x400,param_2,(va_list)&local_res18);
    local_29 = 0;
    FUN_14015b240(local_878);
    uVar3 = (**(code **)(*param_1 + 0x18))(param_1);
    local_898 = 1;
    local_8a0 = 0;
    local_8a8 = 0;
    local_8b0 = 0;
    local_8b8 = 0x7d5;
    local_8c0 = 0xff0000;
    local_8c8 = 0;
    iVar2 = FUN_14015b300(local_878,"SYSTEM",uVar3,local_428);
    if (iVar2 == 0) {
      FUN_14015b2c0(local_878);
      uVar1 = 0;
    }
    else {
      uVar1 = (**(code **)(*param_1 + 0x350))(param_1,local_878);
      FUN_14015b2c0(local_878);
    }
  }
  return uVar1;
}

// ==== CMonster::vfunc_92  @140387b20  [high:rtti-vtable]  (orig: FUN_140387b20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140387b20(longlong *param_1,int param_2,longlong param_3,int param_4,uint *param_5)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (0x1f < param_2) {
    local_488 = 0x3d9;
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (param_5 == (uint *)0x0) {
    uVar3 = 1 << ((byte)param_2 & 0x1f);
  }
  else {
    uVar3 = *param_5;
  }
  if (param_3 != 0) {
    if (param_2 == 0) {
      iVar2 = (**(code **)(*param_1 + 0x78))(param_1);
      if (iVar2 + (int)param_3 < 1) {
        *(undefined4 *)((longlong)param_1 + 0x104) = 0;
      }
      else {
        iVar2 = (**(code **)(*param_1 + 0x78))(param_1);
        *(int *)((longlong)param_1 + 0x104) = iVar2 + (int)param_3;
      }
    }
    else if (((param_2 != 2) && (param_2 != 4)) && (param_2 != 5)) {
      return 0;
    }
    uVar3 = uVar3 | 1 << ((byte)param_2 & 0x1f);
  }
  if ((param_4 != 0) && (uVar3 != 0)) {
    FUN_14039e680(local_468);
    uVar1 = (**(code **)(param_1[-2] + 8))();
    iVar2 = FUN_14039e700(local_468,uVar1,0xffffffff);
    if (iVar2 == 0) {
      FUN_14039e6d0(local_468);
      return 0;
    }
    if ((uVar3 & 1) == 0) {
      if ((uVar3 & 4) != 0) {
        FUN_14039e6d0(local_468);
        return 0;
      }
      if ((uVar3 & 0x20) != 0) {
        FUN_14039e6d0(local_468);
        return 0;
      }
      if ((uVar3 & 0x10) != 0) {
        FUN_14039e6d0(local_468);
        return 0;
      }
      FUN_14039e6d0(local_468);
      return 0;
    }
    uVar1 = (**(code **)(*param_1 + 0x78))(param_1);
    iVar2 = FUN_14039e9a0(local_468,0,uVar1);
    if (iVar2 == 0) {
      FUN_14039e6d0(local_468);
      return 0;
    }
    uVar3 = 0;
    if (param_4 == 1) {
      (**(code **)(*param_1 + 0x350))(param_1,local_468);
    }
    else if (param_4 == 2) {
      (**(code **)(*param_1 + 0x348))(param_1,local_468,1);
    }
    FUN_14039e6d0(local_468);
  }
  if (param_5 != (uint *)0x0) {
    *param_5 = uVar3;
  }
  return 1;
}

// ==== CMonster::helper_140387d50  @140387d50  [medium:callgraph-r0]  (orig: FUN_140387d50)
void FUN_140387d50(longlong param_1)

{
  longlong *plVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong *plVar8;
  ulonglong uVar9;
  ulonglong uVar10;
  longlong local_res8;
  
  uVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(param_1 + 0x10);
  uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x40))(param_1 + 0x10);
  uVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x160))(param_1 + 0x10);
  lVar7 = FUN_1402c7750(uVar6,uVar4,uVar3);
  if ((lVar7 != 0) && (plVar1 = *(longlong **)(lVar7 + 8), plVar1 != (longlong *)0x0)) {
    uVar10 = 0;
    lVar7 = (**(code **)(*plVar1 + 0x10))(plVar1);
    if (lVar7 != 0) {
      do {
        plVar8 = (longlong *)(**(code **)(*plVar1 + 0x18))(plVar1,uVar10);
        if (((plVar8 != (longlong *)0x0) &&
            (cVar2 = (**(code **)(*plVar8 + 0x38))(plVar8,0x1400,&local_res8), cVar2 != '\0')) &&
           (iVar5 = (**(code **)(**(longlong **)(local_res8 + 0xb0) + 0x10))
                              (*(longlong **)(local_res8 + 0xb0),1), iVar5 < 10)) {
          uVar6 = FUN_1401594f0(param_1);
          cVar2 = FUN_1403a7240(local_res8,uVar6);
          if (cVar2 != '\0') {
            FUN_1403a86d0(local_res8,uVar6);
          }
        }
        uVar10 = uVar10 + 1;
        uVar9 = (**(code **)(*plVar1 + 0x10))(plVar1);
      } while (uVar10 < uVar9);
    }
  }
  return;
}

// ==== CMonster::vfunc_93  @140387e70  [high:rtti-vtable]  (orig: FUN_140387e70)
void FUN_140387e70(longlong *param_1,int param_2)

{
  ulong uVar1;
  undefined4 uVar2;
  
  (**(code **)(*param_1 + 0x2c0))(param_1,100);
  if (((param_2 != 6) && (param_2 != 7)) && (param_2 != 8)) {
    (**(code **)(*param_1 + 0x380))(param_1);
  }
  uVar1 = tq::TimeGet(0);
  *(ulong *)(param_1 + 2) = uVar1;
  uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  *(undefined4 *)((longlong)param_1 + 0x14) = uVar2;
  uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  *(undefined4 *)(param_1 + 3) = uVar2;
  return;
}

// ==== CMonster::vfunc_94  @140387ee0  [high:rtti-vtable]  (orig: FUN_140387ee0)
void FUN_140387ee0(longlong *param_1,undefined4 *param_2,undefined4 *param_3)

{
  ulong uVar1;
  undefined4 uVar2;
  
  uVar1 = tq::TimeGet(0);
  if (999 < uVar1 - (int)param_1[2]) {
    uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
    *param_2 = uVar2;
    uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
    *param_3 = uVar2;
    return;
  }
  *param_2 = *(undefined4 *)((longlong)param_1 + 0x14);
  *param_3 = (int)param_1[3];
  return;
}

// ==== CMonster::vfunc_12  @140387f50  [high:rtti-vtable]  (orig: FUN_140387f50)
bool FUN_140387f50(longlong param_1,int param_2)

{
  char cVar1;
  
  cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x220))(param_1 + 0x10);
  if (cVar1 != '\0') {
    return param_2 < 1;
  }
  return false;
}

// ==== CMonster::helper_140387f80  @140387f80  [medium:callgraph-r1]  (orig: FUN_140387f80)
undefined8 FUN_140387f80(longlong param_1)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  if (*(longlong *)(param_1 + 0x70) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(param_1 + 0x70) + 0x10))
                     (*(longlong **)(param_1 + 0x70),0x1e);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if (iVar2 == 0) {
    return 5;
  }
  cVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x260))(param_1 + 0x10);
  uVar4 = 1;
  if (cVar1 != '\0') {
    uVar4 = 7;
  }
  return uVar4;
}

// ==== CMonster::helper_1403880b0  @1403880b0  [medium:callgraph-r1]  (orig: FUN_1403880b0)
longlong FUN_1403880b0(void)

{
  tm *ptVar1;
  __time64_t local_res10 [3];
  
  local_res10[0] = _time64((__time64_t *)0x0);
  ptVar1 = _localtime64(local_res10);
  if (ptVar1 == (tm *)0x0) {
    return 0;
  }
  return (ulonglong)(uint)((ptVar1->tm_mon + 1) * 1000000) +
         (longlong)(ptVar1->tm_year + 0x76c) * 100000000 +
         (ulonglong)(uint)(ptVar1->tm_mday * 10000) + (ulonglong)(uint)(ptVar1->tm_hour * 100) +
         (ulonglong)(uint)ptVar1->tm_min;
}

// ==== CMonster::vfunc_123  @140388120  [high:rtti-vtable]  (orig: FUN_140388120)
undefined8 FUN_140388120(longlong *param_1,longlong *param_2,char param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  IStringManager *pIVar5;
  undefined8 uVar6;
  longlong lVar7;
  longlong lVar8;
  longlong *local_res10;
  
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  iVar3 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
  if ((0x1869e < iVar3 - 0xaae61U) || ((int)param_1[0x27] != 1)) {
    cVar2 = (**(code **)(*param_1 + 0x220))(param_1);
    if (cVar2 == '\0') {
      if (param_3 != '\0') {
        pIVar5 = theInstance();
        lVar7 = *param_1;
        uVar6 = (*(code *)**(undefined8 **)pIVar5)(pIVar5,"STR_DIE_FORGIVE");
        (**(code **)(lVar7 + 0x358))(param_1,uVar6);
      }
    }
    else {
      cVar2 = (**(code **)(*param_2 + 0x220))(param_2);
      if (cVar2 != '\0') {
        iVar3 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
        iVar4 = (**(code **)(*param_2 + 0x10))(param_2);
        if ((((iVar3 != iVar4) && (cVar2 = (**(code **)(*param_2 + 0x3e0))(param_2), cVar2 != '\0'))
            && (lVar7 = (**(code **)(*param_1 + 0x160))(param_1), lVar7 != 0)) &&
           (lVar7 = (**(code **)(*param_2 + 0x160))(param_2), lVar7 != 0)) {
          lVar7 = (**(code **)(*param_2 + 0x160))(param_2);
          lVar8 = (**(code **)(*param_1 + 0x160))(param_1);
          if (lVar8 == lVar7) {
            iVar3 = (**(code **)(*param_2 + 0x10))(param_2);
            if (iVar3 - 0xaae61U < 99999) {
              local_res10 = (longlong *)0x0;
              cVar2 = (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_res10);
              plVar1 = local_res10;
              if (((cVar2 != '\0') && (local_res10 != (longlong *)0x0)) &&
                 ((iVar3 = (**(code **)(*local_res10 + 8))(local_res10), iVar3 - 0xaae61U < 99999 &&
                  ((int)plVar1[0x29] == 2)))) {
                return 0;
              }
            }
            return 1;
          }
        }
      }
    }
  }
  return 0;
}

// ==== CMonster::vfunc_124  @1403882c0  [high:rtti-vtable]  (orig: FUN_1403882c0)
longlong FUN_1403882c0(longlong param_1)

{
  uint3 uVar1;
  int iVar2;
  uint uVar3;
  bool bVar4;
  
  iVar2 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  uVar3 = iVar2 - 0xaae61;
  if (uVar3 < 99999) {
    bVar4 = *(int *)(param_1 + 0x138) == 1;
    uVar1 = (uint3)(uVar3 >> 8);
    uVar3 = CONCAT31(uVar1,bVar4);
    if (bVar4) {
      return (ulonglong)uVar1 << 8;
    }
  }
  return CONCAT71((uint7)(uint3)(uVar3 >> 8),1);
}

// ==== CMonster::helper_140388300  @140388300  [medium:callgraph-r1]  (orig: FUN_140388300)
undefined8 FUN_140388300(longlong param_1)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x160))(param_1 + 0x10);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  if (*(char *)(param_1 + 0x188) == '\0') {
    FUN_1403878e0(param_1);
  }
  uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x2a0))(param_1 + 0x10);
  FUN_1402c9300(lVar1,uVar2,0);
  return 1;
}

// ==== CMonster::vfunc_26  @1403883b0  [high:rtti-vtable]  (orig: FUN_1403883b0)
int FUN_1403883b0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  longlong *plVar4;
  
  iVar2 = (**(code **)(*param_1 + 0xd8))();
  cVar1 = (**(code **)(*param_1 + 0x2d8))(param_1,0x15);
  if (cVar1 == '\0') {
    return iVar2;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],0x15);
  if (29999 < iVar3) {
                    /* WARNING: Could not recover jumptable at 0x00014038841f. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar2 = MulDiv(iVar2,iVar3 + -30000,100);
    return iVar2;
  }
  if (iVar3 < -29999) {
    return -30000 - iVar3;
  }
  if (iVar3 == -0x8000) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  return iVar3 + iVar2;
}

// ==== CMonster::vfunc_21  @1403884a0  [high:rtti-vtable]  (orig: FUN_1403884a0)
void FUN_1403884a0(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x0001403884a3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0xb0))();
  return;
}

// ==== CMonster::vfunc_24  @1403884b0  [high:rtti-vtable]  (orig: FUN_1403884b0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_1403884b0(longlong *param_1)

{
  uint uVar1;
  
  uVar1 = (**(code **)(*param_1 + 200))();
  return (longlong)(((float)uVar1 + _DAT_14075d6a8) * DAT_140715a88);
}

// ==== CMonster::vfunc_103  @1403884f0  [high:rtti-vtable]  (orig: FUN_1403884f0)
void FUN_1403884f0(longlong *param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  
  if (param_1[0xe] != 0) {
    lVar1 = *(longlong *)param_1[0xe];
    uVar2 = (**(code **)(*param_1 + 0x78))();
    (**(code **)(lVar1 + 0x60))(param_1[0xe],6,uVar2);
    lVar1 = *(longlong *)param_1[0xe];
    uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
    (**(code **)(lVar1 + 0x60))(param_1[0xe],9,uVar2);
    lVar1 = *(longlong *)param_1[0xe];
    uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
    (**(code **)(lVar1 + 0x60))(param_1[0xe],10,uVar2);
    (**(code **)(*(longlong *)param_1[0xe] + 0x70))();
  }
  return;
}

// ==== CMonster::vfunc_68  @140388580  [high:rtti-vtable]  (orig: FUN_140388580)
undefined8 FUN_140388580(longlong *param_1)

{
  int iVar1;
  
  if ((int)param_1[0x1b] != 0) {
    iVar1 = (**(code **)(*param_1 + 0x78))();
    if ((iVar1 != 0) && ((int)param_1[0x29] == 0)) {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::helper_1403887c0  @1403887c0  [medium:callgraph-r0]  (orig: FUN_1403887c0)
undefined1 FUN_1403887c0(longlong param_1)

{
  char cVar1;
  
  if (*(longlong *)(param_1 + 0x30) != 0) {
    cVar1 = FUN_1404cbfe0();
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::helper_140388810  @140388810  [medium:callgraph-r3]  (orig: FUN_140388810)
int * FUN_140388810(longlong param_1,int *param_2,int param_3)

{
  longlong *plVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  *param_2 = 0;
  param_2[1] = 0;
  iVar4 = *(int *)(&DAT_14075d300 + (longlong)*(int *)(param_1 + 0xe4) * 4);
  iVar2 = *(int *)(&DAT_14075d320 + (longlong)*(int *)(param_1 + 0xe4) * 4);
  iVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  *param_2 = iVar3 + iVar4 * param_3;
  iVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
  param_2[1] = iVar4 + iVar2 * param_3;
  return param_2;
}

// ==== CMonster::helper_1403888a0  @1403888a0  [medium:callgraph-r3]  (orig: FUN_1403888a0)
int * FUN_1403888a0(longlong param_1,int *param_2,int param_3)

{
  longlong *plVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  *param_2 = 0;
  param_2[1] = 0;
  iVar4 = *(int *)(&DAT_14075d300 + (longlong)*(int *)(param_1 + 0xe4) * 4);
  iVar2 = *(int *)(&DAT_14075d320 + (longlong)*(int *)(param_1 + 0xe4) * 4);
  iVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  *param_2 = iVar3 - iVar4 * param_3;
  iVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
  param_2[1] = iVar4 - iVar2 * param_3;
  return param_2;
}

// ==== CMonster::helper_140388930  @140388930  [medium:callgraph-r2]  (orig: FUN_140388930)
void FUN_140388930(longlong param_1)

{
  if (*(longlong *)(param_1 + 0x128) != 0) {
    FUN_1403e8ce0();
  }
  return;
}

// ==== CMonster::vfunc_91  @140388a00  [high:rtti-vtable]  (orig: FUN_140388a00)
void FUN_140388a00(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)FUN_1401181a0();
                    /* WARNING: Could not recover jumptable at 0x000140388a2a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x60))(plVar1,*(undefined4 *)(param_1 + 0x78),param_2);
  return;
}

// ==== CMonster::helper_140388bf0  @140388bf0  [medium:callgraph-r1]  (orig: FUN_140388bf0)
void FUN_140388bf0(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_70,"invalid vector<T> subscript");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_1409445a0);
}

// ==== CMonster::helper_140388d00  @140388d00  [medium:callgraph-r2]  (orig: FUN_140388d00)
undefined1 FUN_140388d00(longlong *param_1)

{
  if ((*param_1 != 0) && (param_1[1] == 0)) {
    return 1;
  }
  return 0;
}

// ==== CMonster::helper_140388d20  @140388d20  [medium:callgraph-r1]  (orig: FUN_140388d20)
void FUN_140388d20(longlong *param_1)

{
  char cVar1;
  
  if (*param_1 != 0) {
    cVar1 = FUN_140388d00();
    if (cVar1 != '\0') {
      log_InlineLogERROR(&DAT_1406d9c10);
      return;
    }
    *(longlong *)(param_1[1] + 0x10) = param_1[2];
    if (param_1[2] != 0) {
      *(longlong *)(param_1[2] + 8) = param_1[1];
    }
    *param_1 = 0;
    param_1[1] = 0;
    param_1[2] = 0;
  }
  return;
}

// ==== CMonster::helper_140388dd0  @140388dd0  [medium:callgraph-r0]  (orig: FUN_140388dd0)
undefined8 FUN_140388dd0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x140),0x24);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if (iVar1 != 0) {
    plVar2 = (longlong *)
             (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                       ((longlong *)**(undefined8 **)(param_1 + 0x140),0x26);
    iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
    if (iVar1 == 0) {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::helper_140388e30  @140388e30  [medium:callgraph-r0]  (orig: FUN_140388e30)
void FUN_140388e30(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x140),0x24);
                    /* WARNING: Could not recover jumptable at 0x000140388e53. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::helper_140388f50  @140388f50  [medium:callgraph-r0]  (orig: FUN_140388f50)
void FUN_140388f50(void *param_1)

{
  if ((DAT_1409761a0 & 1) == 0) {
    DAT_1409761a0 = DAT_1409761a0 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140976198,"CMonster");
    atexit((_func_5014 *)&LAB_1406d6b70);
  }
                    /* WARNING: Could not recover jumptable at 0x000140388fa5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140976198,param_1);
  return;
}

// ==== CMonster::vfunc_86  @140389010  [high:rtti-vtable]  (orig: FUN_140389010)
undefined8 FUN_140389010(longlong param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if (iVar1 - 0xaae61U < 99999) {
    return *(undefined8 *)(param_1 + 0x30);
  }
  return 0;
}

// ==== CMonster::vfunc_106  @1403890c0  [high:rtti-vtable]  (orig: FUN_1403890c0)
ulonglong FUN_1403890c0(longlong *param_1,longlong param_2)

{
  int iVar1;
  ulonglong extraout_RAX;
  ulonglong extraout_RAX_00;
  longlong *plVar2;
  ulonglong uVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR("CMonster::SendMsg, NULL message");
    return extraout_RAX & 0xffffffffffffff00;
  }
  if (*(int *)(param_2 + 8) == 0) {
    (**(code **)(*param_1 + 0x48))();
    (**(code **)(*param_1 + 0x40))(param_1);
    (**(code **)(*param_1 + 0x168))(param_1);
    (**(code **)(param_1[-2] + 0x50))(param_1 + -2);
    log_InlineLogERROR("invalid msg type in CMonster::SendMsg(). MonsterType[%u] Map[%u][%d, %d]");
    return extraout_RAX_00 & 0xffffffffffffff00;
  }
  iVar1 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
  if (iVar1 - 0xaae61U < 99999) {
    return CONCAT71((uint7)(uint3)(iVar1 - 0xaae61U >> 8),1);
  }
  plVar2 = (longlong *)FUN_140008520((int)param_1[0x2b]);
                    /* WARNING: Could not recover jumptable at 0x0001403891b7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x30))(plVar2,(int)param_1[0xf],param_2);
  return uVar3;
}

// ==== CMonster::vfunc_105  @1403891c0  [high:rtti-vtable]  (orig: FUN_1403891c0)
void FUN_1403891c0(longlong *param_1,longlong param_2,undefined1 param_3)

{
  longlong lVar1;
  int iVar2;
  longlong *plVar3;
  undefined8 uVar4;
  
  if (param_2 != 0) {
    iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
    if (((iVar2 - 0xaae61U < 99999) && ((int)param_1[0x27] == 1)) ||
       ((iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2), iVar2 - 0xaae61U < 99999 &&
        ((int)param_1[0x27] == 2)))) {
      param_3 = 0;
    }
    plVar3 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
    if (plVar3 != (longlong *)0x0) {
      lVar1 = *plVar3;
      uVar4 = (**(code **)(*param_1 + 0x2a0))(param_1);
      (**(code **)(lVar1 + 0x30))(plVar3,uVar4,param_2,param_3);
    }
  }
  return;
}

// ==== CMonster::vfunc_104  @140389290  [high:rtti-vtable]  (orig: FUN_140389290)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140389290(longlong *param_1,longlong param_2,undefined1 param_3)

{
  int iVar1;
  undefined8 uVar2;
  undefined1 auStack_4f8 [32];
  undefined8 local_4d8;
  undefined4 local_4d0;
  undefined2 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  if (param_2 != 0) {
    local_498 = 0xfffffffffffffffe;
    local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4f8;
    iVar1 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
    if (((iVar1 - 0xaae61U < 99999) && ((int)param_1[0x27] == 1)) ||
       ((iVar1 = (**(code **)(param_1[-2] + 8))(param_1 + -2), iVar1 - 0xaae61U < 99999 &&
        ((int)param_1[0x27] == 2)))) {
      param_3 = 0;
    }
    FUN_14015b240(local_488);
    uVar2 = (**(code **)(*param_1 + 0x18))(param_1);
    local_4a8 = 1;
    local_4b0 = 0;
    local_4b8 = 0;
    local_4c0 = 0;
    local_4c8 = 0x7d5;
    local_4d0 = 0xff0000;
    local_4d8 = 0;
    iVar1 = FUN_14015b300(local_488,uVar2,"ALLUSERS",param_2);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0x348))(param_1,local_488,param_3);
    }
    FUN_14015b2c0(local_488);
    return;
  }
  return;
}

// ==== CMonster::vfunc_9  @1403893c0  [high:rtti-vtable]  (orig: FUN_1403893c0)
void FUN_1403893c0(longlong *param_1,longlong param_2,char param_3)

{
  int iVar1;
  longlong *plVar2;
  
  if (param_2 != 0) {
    plVar2 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
    if (plVar2 != (longlong *)0x0) {
      (**(code **)(*plVar2 + 0x38))(plVar2,param_2,0);
    }
    iVar1 = (**(code **)(*param_1 + 8))(param_1);
    if ((((0x1869e < iVar1 - 0xaae61U) || ((int)param_1[0x29] != 1)) &&
        ((iVar1 = (**(code **)(*param_1 + 8))(param_1), 0x1869e < iVar1 - 0xaae61U ||
         ((int)param_1[0x29] != 2)))) && (param_3 != '\0')) {
      plVar2 = (longlong *)FUN_140008520((int)param_1[0x2d]);
      (**(code **)(*plVar2 + 0x30))(plVar2,0,param_2);
    }
  }
  return;
}

// ==== CMonster::vfunc_8  @140389480  [high:rtti-vtable]  (orig: FUN_140389480)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140389480(longlong *param_1,longlong param_2,undefined1 param_3)

{
  int iVar1;
  undefined1 auStack_4e8 [32];
  undefined8 local_4c8;
  undefined4 local_4c0;
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined1 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  if (param_2 != 0) {
    local_488 = 0xfffffffffffffffe;
    local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
    iVar1 = (**(code **)(*param_1 + 8))();
    if (((iVar1 - 0xaae61U < 99999) && ((int)param_1[0x29] == 1)) ||
       ((iVar1 = (**(code **)(*param_1 + 8))(param_1), iVar1 - 0xaae61U < 99999 &&
        ((int)param_1[0x29] == 2)))) {
      param_3 = 0;
    }
    FUN_14015b240();
    local_498 = 1;
    local_4a0 = 0;
    local_4a8 = 0;
    local_4b0 = 0;
    local_4b8 = 0x7d5;
    local_4c0 = 0xff0000;
    local_4c8 = 0;
    iVar1 = FUN_14015b300(local_478,"SYSTEM","ALLUSERS",param_2);
    if (iVar1 != 0) {
      (**(code **)(*param_1 + 0x48))(param_1,local_478,param_3);
    }
    FUN_14015b2c0(local_478);
    return;
  }
  return;
}

// ==== CMonster::vfunc_110  @140389590  [high:rtti-vtable]  (orig: FUN_140389590)
void FUN_140389590(longlong *param_1,undefined4 param_2,undefined4 param_3)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  longlong *plVar5;
  
  plVar4 = (longlong *)(**(code **)(*param_1 + 0x160))();
  if (plVar4 != (longlong *)0x0) {
    cVar2 = FUN_1402c3cc0(plVar4,param_2,param_3);
    if (cVar2 != '\0') {
      plVar1 = param_1 + -2;
      plVar5 = (longlong *)0x0;
      if (plVar1 != (longlong *)0x0) {
        plVar5 = param_1;
      }
      FUN_1402c9550(plVar4,plVar5,param_2,param_3);
      *(undefined4 *)((longlong)param_1 + 0xcc) = param_2;
      *(undefined4 *)(param_1 + 0x1a) = param_3;
      if ((char)param_1[0x27] != '\x02') {
        iVar3 = (**(code **)(*plVar1 + 8))(plVar1);
        if (0x1869e < iVar3 - 0xaae61U) {
          plVar5 = (longlong *)0x0;
          if (plVar1 != (longlong *)0x0) {
            plVar5 = param_1;
          }
          (**(code **)(*plVar4 + 0x20))(plVar4,plVar5);
        }
        FUN_140387840(plVar1);
        FUN_140387d50(plVar1);
      }
    }
    return;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMonster::vfunc_6  @1403896a0  [high:rtti-vtable]  (orig: FUN_1403896a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403896a0(longlong param_1,longlong *param_2)

{
  int iVar1;
  undefined1 auStack_4a8 [32];
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1104];
  ulonglong local_18;
  
  local_478 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  if (*(char *)(param_1 + 0x130) != '\x02') {
    if (param_2 == (longlong *)0x0) {
      local_488 = 0x3b6;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else if (*(int *)(param_1 + 0x13c) == 0) {
      FUN_14039ed70(local_468);
      if (param_1 == 0x18) {
        param_1 = 0;
      }
      else {
        param_1 = param_1 + -8;
      }
      iVar1 = FUN_14039eef0(local_468,param_1,0,0);
      if (iVar1 != 0) {
        (**(code **)(*param_2 + 0x350))(param_2,local_468);
      }
      FUN_14039edf0(local_468);
    }
  }
  return;
}

// ==== CMonster::vfunc_117  @140389790  [high:rtti-vtable]  (orig: FUN_140389790)
int FUN_140389790(longlong *param_1,longlong *param_2,undefined8 param_3)

{
  char cVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  longlong lVar7;
  longlong *plVar8;
  undefined8 uVar9;
  ulonglong in_stack_ffffffffffffffb8;
  
  if (param_2 != (longlong *)0x0) {
    iVar5 = 0;
    cVar1 = (**(code **)(*param_1 + 0x188))();
    if (cVar1 == '\0') {
      plVar8 = param_1;
      if (param_1 == (longlong *)&DAT_00000010) {
        plVar8 = (longlong *)0x0;
      }
      uVar2 = FUN_1403ec0a0(plVar8,param_2,0,0,in_stack_ffffffffffffffb8 & 0xffffffff00000000,0,0,
                            param_3,0);
    }
    else {
      plVar8 = param_1;
      if (param_1 == (longlong *)&DAT_00000010) {
        plVar8 = (longlong *)0x0;
      }
      lVar7 = FUN_140008520((int)param_1[0x2b]);
      lVar7 = *(longlong *)(lVar7 + 0x100);
      if (lVar7 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      uVar2 = (**(code **)(*param_1 + 0x98))(param_1);
      uVar2 = FUN_1402f3100(lVar7,plVar8,param_2,uVar2,param_3);
      plVar8 = (longlong *)
               (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x24);
      iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
      if (iVar3 != 0) {
        plVar8 = (longlong *)
                 (**(code **)(**(longlong **)param_1[0x26] + 0x10))
                           (*(longlong **)param_1[0x26],0x24);
        uVar4 = (**(code **)(*plVar8 + 0x48))(plVar8);
        plVar8 = param_1;
        if (param_1 == (longlong *)&DAT_00000010) {
          plVar8 = (longlong *)0x0;
        }
        uVar9 = FUN_140008520((int)param_1[0x2b]);
        uVar9 = FUN_1400877e0(uVar9);
        iVar5 = FUN_1402f12a0(uVar9,plVar8,param_2,uVar4);
      }
    }
    if (param_1 == (longlong *)&DAT_00000010) {
      param_1 = (longlong *)0x0;
    }
    iVar6 = (**(code **)(*param_2 + 0x3b0))(param_2,param_1,uVar2,1);
    iVar3 = (**(code **)(*param_2 + 0x78))(param_2);
    if (iVar5 + iVar6 <= iVar3) {
      iVar3 = iVar5 + iVar6;
    }
    if (0 < iVar3) {
      (**(code **)(*param_2 + 0x2e0))(param_2,0,(longlong)-iVar3,1,0);
    }
    return iVar6;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::IOSServerDropItemAndMoney  @1403899c0  [high:log-string]  (orig: FUN_1403899c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403899c0(longlong *param_1,longlong *param_2,char param_3)

{
  bool bVar1;
  ushort uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uVar7;
  int iVar8;
  longlong *plVar9;
  longlong lVar10;
  undefined8 uVar11;
  IStringManager *pIVar12;
  ulonglong uVar13;
  ulonglong uVar14;
  undefined1 auStack_578 [32];
  undefined4 *local_558;
  undefined4 local_550;
  undefined4 local_548;
  char local_538;
  bool local_537;
  ushort local_534;
  undefined4 local_530;
  ushort local_52c;
  uint local_528;
  undefined4 uStack_524;
  int local_520;
  undefined4 local_518;
  undefined4 uStack_514;
  longlong *local_510;
  longlong local_508;
  undefined8 local_500;
  undefined4 local_4f8;
  uint local_4f4;
  int local_4c4;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_500 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_578;
  local_530 = 0;
  local_538 = param_3;
  local_510 = param_2;
  if (param_2 != (longlong *)0x0) {
    local_530 = (**(code **)(*param_2 + 8))(param_2);
  }
  if (param_3 != '\0') {
    plVar9 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0x16);
    iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
    if (iVar4 != 0) {
      lVar10 = FUN_140008520((int)param_1[0x2d]);
      if (*(longlong *)(lVar10 + 0x1a0) == 0) {
        local_558 = (undefined4 *)CONCAT44(local_558._4_4_,0x157);
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar11 = 0;
      }
      else {
        uVar11 = *(undefined8 *)(lVar10 + 0x1a0);
      }
      uVar14 = 0;
      uVar5 = FUN_14026dc60(uVar11,iVar4);
      local_528 = uVar5;
      lVar10 = FUN_140008520((int)param_1[0x2d]);
      if (*(longlong *)(lVar10 + 0x1a0) == 0) {
        local_558 = (undefined4 *)CONCAT44(local_558._4_4_,0x157);
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar13 = uVar14;
      }
      else {
        uVar13 = *(ulonglong *)(lVar10 + 0x1a0);
      }
      uVar6 = FUN_14026dd20(uVar13,iVar4);
      uVar13 = uVar14;
      if (uVar5 < uVar6) {
        uVar13 = (ulonglong)(uVar6 - uVar5);
      }
      lVar10 = FUN_140008520((int)param_1[0x2d]);
      if (*(longlong *)(lVar10 + 0x1a0) == 0) {
        local_558 = (undefined4 *)CONCAT44(local_558._4_4_,0x157);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar14 = *(ulonglong *)(lVar10 + 0x1a0);
      }
      local_52c = FUN_14026da30(uVar14,iVar4);
      local_534 = 0;
      while (uVar2 = local_534, lVar10 = 0, param_2 = local_510, param_3 = local_538,
            local_534 < local_52c) {
        uVar6 = uVar5;
        if ((int)uVar13 != 0) {
          iVar4 = tq::RandGet((int)uVar13);
          uVar6 = iVar4 + 1 + uVar5;
        }
        if (uVar6 != 0) {
          local_518 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
          uStack_514 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
          uVar11 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
          cVar3 = FUN_1402d1110(uVar11,2,&local_518);
          uVar5 = local_528;
          if (cVar3 != '\0') {
            local_508 = FUN_14037c6e0(0xe8);
            if (local_508 != 0) {
              lVar10 = FUN_14037d2d0(local_508);
            }
            uVar5 = local_528;
            if (lVar10 != 0) {
              uVar11 = FUN_140008520((int)param_1[0x2d]);
              plVar9 = (longlong *)FUN_1400876b0(uVar11);
              uVar11 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
              uVar7 = (**(code **)(*plVar9 + 0x58))(plVar9);
              local_548 = CONCAT31(local_548._1_3_,1);
              local_550 = local_530;
              local_558 = (undefined4 *)CONCAT44(local_558._4_4_,uVar6);
              cVar3 = FUN_14037cf50(lVar10,uVar7,uVar11,CONCAT44(uStack_514,local_518));
              if (cVar3 == '\0') {
                (**(code **)(*param_1 + 0x50))(param_1);
                log_InlineLogWARNING
                          ("CMonster::IOSServerDropItemAndMoney(): monster_type[%d], dwMoney[%u].");
                (**(code **)(*(longlong *)(lVar10 + 0x10) + 8))();
                uVar5 = local_528;
              }
              else {
                uVar11 = FUN_140008520((int)param_1[0x2d]);
                plVar9 = (longlong *)FUN_1400876b0(uVar11);
                plVar9 = (longlong *)(**(code **)(*plVar9 + 0x50))(plVar9);
                (**(code **)(*plVar9 + 0x20))(plVar9,lVar10);
                uVar5 = local_528;
              }
            }
          }
        }
        local_534 = uVar2 + 1;
      }
    }
    if (param_3 != '\0') {
      local_537 = false;
      if (param_2 != (longlong *)0x0) {
        iVar4 = (**(code **)(param_1[2] + 0x70))();
        uVar5 = (**(code **)(param_2[2] + 0x70))();
        local_537 = iVar4 + 0x14U < uVar5;
      }
      bVar1 = local_537;
      local_520 = 0x42;
      while (iVar4 = local_520, uVar11 = 0, local_520 < 0x46) {
        plVar9 = (longlong *)
                 (**(code **)(**(longlong **)param_1[0x28] + 0x10))
                           (*(longlong **)param_1[0x28],local_520);
        iVar8 = (**(code **)(*plVar9 + 0x48))(plVar9);
        if (iVar8 != 0) {
          lVar10 = FUN_140008520((int)param_1[0x2d]);
          if (*(longlong *)(lVar10 + 0x1a0) == 0) {
            local_558 = (undefined4 *)CONCAT44(local_558._4_4_,0x157);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar11 = *(undefined8 *)(lVar10 + 0x1a0);
          }
          cVar3 = FUN_14026ef10(uVar11,iVar8,&local_4f8,bVar1);
          if (cVar3 != '\0') {
            local_528 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
            uStack_524 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
            uVar11 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
            cVar3 = FUN_1402d1110(uVar11,2,&local_528);
            if (cVar3 != '\0') {
              if ((((param_2 != (longlong *)0x0) && (*(int *)((longlong)param_2 + 0xb2c) != 0)) &&
                  (local_4f4 % 10 == 9)) && (iVar8 = tq::RandGet(100), iVar8 < 0x4b)) {
                pIVar12 = theInstance();
                lVar10 = *param_2;
                uVar11 = (*(code *)**(undefined8 **)pIVar12)(pIVar12,"STR_LUCK_ULTRA_EQP");
                (**(code **)(lVar10 + 0x150))(param_2,0x7d5,uVar11);
                FUN_14037dfb0(local_488);
                uVar7 = (**(code **)(*param_2 + 8))(param_2);
                iVar8 = FUN_14037e0a0(local_488,10,"LuckyGuy",uVar7);
                if (iVar8 == 0) {
                  local_558 = (undefined4 *)CONCAT44(local_558._4_4_,0x986);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  (**(code **)(param_2[2] + 0x348))(param_2 + 2,local_488,1);
                }
                FUN_14037e030(local_488);
              }
              local_508 = FUN_14037c6e0(0xe8);
              if (local_508 == 0) {
                lVar10 = 0;
              }
              else {
                lVar10 = FUN_14037d2d0(local_508);
              }
              if (lVar10 != 0) {
                local_4f8 = 0;
                uVar11 = FUN_140008520((int)param_1[0x2d]);
                plVar9 = (longlong *)FUN_1400876b0(uVar11);
                uVar11 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
                uVar7 = (**(code **)(*plVar9 + 0x58))(plVar9);
                local_548 = 0;
                local_550 = local_530;
                local_558 = &local_4f8;
                cVar3 = FUN_14037cda0(lVar10,uVar7,uVar11,CONCAT44(uStack_524,local_528));
                if (cVar3 == '\0') {
                  (**(code **)(*param_1 + 0x50))(param_1);
                  log_InlineLogERROR(
                                    "CMonster::IOSServerDropItemAndMoney(): monster_type[%d], item_type[%u] not config!"
                                    );
                  (**(code **)(*(longlong *)(lVar10 + 0x10) + 8))();
                }
                else {
                  uVar11 = FUN_140008520((int)param_1[0x2d]);
                  plVar9 = (longlong *)FUN_1400876b0(uVar11);
                  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x50))(plVar9);
                  (**(code **)(*plVar9 + 0x20))(plVar9,lVar10);
                  if ((param_2 != (longlong *)0x0) && (0 < local_4c4)) {
                    FUN_14032b550(param_2,(undefined2)local_4c4);
                  }
                }
              }
            }
          }
        }
        local_520 = iVar4 + 1;
      }
    }
  }
  return;
}

// ==== CMonster::vfunc_127  @14038a060  [high:rtti-vtable]  (orig: FUN_14038a060)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14038a060(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                  undefined4 param_5)

{
  char cVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined8 uVar14;
  undefined1 auStack_508 [32];
  uint local_4e8;
  undefined4 local_4e0;
  undefined4 local_4d8;
  int local_4d0;
  undefined4 local_4c8;
  undefined4 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined1 local_4a8;
  undefined4 local_498;
  undefined4 local_494;
  undefined8 local_490;
  undefined1 local_488 [1072];
  ulonglong local_58;
  
  local_490 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  local_498 = param_4;
  local_494 = param_3;
  lVar9 = (**(code **)(*param_1 + 0x2b0))();
  lVar10 = FUN_140008520((int)param_1[0x2b]);
  if (*(longlong *)(lVar10 + 0x88) == 0) {
    local_4e8 = 0x12f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(lVar10 + 0x88) + 0x20))
                      (*(longlong **)(lVar10 + 0x88),param_2);
  local_4d0 = 0;
  if (((plVar11 != (longlong *)0x0) &&
      (lVar10 = (**(code **)(*plVar11 + 0x2b0))(plVar11), local_4d0 = 0, lVar9 != 0)) &&
     (lVar10 != 0)) {
    iVar4 = FUN_14018ed10(lVar10);
    local_4d0 = FUN_14018eb30(lVar9);
    local_4d0 = local_4d0 - iVar4;
  }
  cVar1 = (**(code **)(*param_1 + 0x188))(param_1);
  if (cVar1 == '\0') {
    cVar1 = (**(code **)(*param_1 + 0x260))(param_1);
    local_4d8 = param_3;
    if ((cVar1 == '\0') && (cVar1 = (**(code **)(*param_1 + 0x268))(param_1), cVar1 == '\0')) {
      FUN_14035f2f0(local_488);
      uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
      uVar3 = (**(code **)(*param_1 + 0x40))(param_1);
      uVar5 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
      local_4b8 = param_5;
      local_4c0 = 0;
      local_4c8 = local_498;
      local_4e0 = CONCAT22(local_4e0._2_2_,uVar2);
      local_4e8 = CONCAT22(local_4e8._2_2_,uVar3);
      iVar4 = FUN_14035f6c0(local_488,2,uVar5,param_2);
      if (iVar4 == 0) {
        local_4e8 = 0xa48;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
      }
      FUN_14035f340(local_488);
    }
    else {
      FUN_14035f2f0(local_488);
      uVar2 = (**(code **)(*param_1 + 0x48))(param_1);
      uVar3 = (**(code **)(*param_1 + 0x40))(param_1);
      uVar5 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
      local_4b8 = param_5;
      local_4c0 = 0;
      local_4c8 = local_498;
      local_4e0 = CONCAT22(local_4e0._2_2_,uVar2);
      local_4e8 = CONCAT22(local_4e8._2_2_,uVar3);
      iVar4 = FUN_14035f6c0(local_488,0x1c,uVar5,param_2);
      if (iVar4 == 0) {
        local_4e8 = 0xa42;
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
      }
      FUN_14035f340(local_488);
    }
  }
  else {
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x24);
    uVar5 = (**(code **)(*plVar12 + 0x48))(plVar12);
    lVar9 = FUN_140008520((int)param_1[0x2b]);
    lVar9 = *(longlong *)(lVar9 + 0x100);
    if (lVar9 == 0) {
      local_4e8 = 0x144;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar9 = 0;
    }
    plVar12 = (longlong *)FUN_1402f0fe0(lVar9,uVar5,0);
    uVar8 = 0;
    if (plVar12 != (longlong *)0x0) {
      plVar13 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,0x26);
      uVar6 = (**(code **)(*plVar13 + 0x48))(plVar13);
      lVar9 = FUN_140008520((int)param_1[0x2b]);
      lVar9 = *(longlong *)(lVar9 + 0x100);
      if (lVar9 == 0) {
        local_4e8 = 0x144;
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar9 = 0;
      }
      cVar1 = FUN_1402ec490(lVar9,uVar6);
      uVar8 = 0;
      if (cVar1 != '\0') {
        plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,0x27);
        uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
        plVar12 = param_1;
        if (param_1 == (longlong *)&DAT_00000010) {
          plVar12 = (longlong *)0x0;
        }
        uVar14 = FUN_140008520((int)param_1[0x2b]);
        uVar14 = FUN_1400877e0(uVar14);
        local_4e8 = uVar7;
        uVar8 = FUN_1402ec380(uVar14,plVar12,plVar11,uVar6);
        uVar14 = FUN_140008520((int)param_1[0x2b]);
        uVar14 = FUN_1400877e0(uVar14);
        FUN_1402ecf10(uVar14,&local_498,uVar6);
      }
    }
    FUN_140386780(local_488);
    uVar6 = (**(code **)(param_1[-2] + 8))();
    local_4a8 = 0;
    local_4b0 = 0;
    local_4b8 = param_5;
    local_4c8 = local_498;
    local_4d8 = local_494;
    local_4e8 = local_4e8 & 0xffffff00;
    local_4e0 = param_2;
    local_4c0 = uVar8;
    iVar4 = FUN_140386e00(local_488,uVar6,uVar5,0);
    if (iVar4 == 0) {
      local_4e8 = 0xa3a;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(*param_1 + 0x348))(param_1,local_488,1);
    }
    FUN_1403867d0(local_488);
  }
  return;
}

// ==== CMonster::DropMoney  @14038a560  [high:log-string]  (orig: FUN_14038a560)
undefined8 FUN_14038a560(longlong *param_1,uint param_2,undefined4 param_3)

{
  char cVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  undefined4 local_res20;
  undefined4 uStackX_24;
  
  if (param_2 == 0) {
    uVar5 = 1;
  }
  else {
    uVar2 = (**(code **)(param_1[2] + 0x70))(param_1 + 2);
    if ((uVar2 < 0x50) || (10 < param_2)) {
      uVar5 = FUN_140008520((int)param_1[0x2d]);
      plVar6 = (longlong *)FUN_140087650(uVar5);
      lVar7 = (**(code **)(*plVar6 + 0x98))(plVar6,param_3);
      if (lVar7 != 0) {
        iVar3 = FUN_140175470(lVar7);
        if (iVar3 != 0) {
          iVar3 = FUN_140164ee0(lVar7);
          param_2 = (iVar3 * param_2) / 100;
        }
        cVar1 = FUN_140168a10(lVar7);
        if (cVar1 != '\0') {
          uVar2 = FUN_1401649c0(lVar7);
          if (uVar2 < 4) {
            param_2 = param_2 >> 3;
          }
          else {
            param_2 = param_2 >> 2;
          }
        }
      }
      if (param_2 == 0) {
        uVar5 = 1;
      }
      else {
        local_res20 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
        uStackX_24 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
        uVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        cVar1 = FUN_1402d1110(uVar5,2,&local_res20);
        if (cVar1 != '\0') {
          lVar7 = FUN_14037c6e0(0xe8);
          if (lVar7 == 0) {
            lVar7 = 0;
          }
          else {
            lVar7 = FUN_14037d2d0(lVar7);
          }
          if (lVar7 != 0) {
            uVar5 = FUN_140008520((int)param_1[0x2d]);
            plVar6 = (longlong *)FUN_1400876b0(uVar5);
            uVar5 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
            uVar4 = (**(code **)(*plVar6 + 0x58))(plVar6);
            cVar1 = FUN_14037cf50(lVar7,uVar4,uVar5,CONCAT44(uStackX_24,local_res20),param_2,param_3
                                  ,1);
            if (cVar1 != '\0') {
              uVar5 = FUN_140008520((int)param_1[0x2d]);
              plVar6 = (longlong *)FUN_1400876b0(uVar5);
              plVar6 = (longlong *)(**(code **)(*plVar6 + 0x50))(plVar6);
              (**(code **)(*plVar6 + 0x20))(plVar6,lVar7);
              return 1;
            }
            (**(code **)(*param_1 + 0x50))(param_1);
            log_InlineLogWARNING("CMonster::DropMoney(): monster_type[%d], dwMoney[%u].");
            (**(code **)(*(longlong *)(lVar7 + 0x10) + 8))();
          }
        }
        uVar5 = 0;
      }
    }
    else {
      uVar5 = 1;
    }
  }
  return uVar5;
}

// ==== CMonster::helper_14038a790  @14038a790  [medium:callgraph-r0]  (orig: FUN_14038a790)
undefined8 FUN_14038a790(longlong *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined4 local_res20;
  undefined4 uStackX_24;
  
  if (param_2 == 0) {
    uVar3 = 1;
  }
  else {
    local_res20 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
    uStackX_24 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
    uVar3 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
    cVar1 = FUN_1402d1110(uVar3,2,&local_res20);
    if (cVar1 != '\0') {
      lVar4 = FUN_14037c6e0(0xe8);
      if (lVar4 == 0) {
        lVar4 = 0;
      }
      else {
        lVar4 = FUN_14037d2d0(lVar4);
      }
      if (lVar4 != 0) {
        uVar3 = FUN_140008520((int)param_1[0x2d]);
        plVar5 = (longlong *)FUN_1400876b0(uVar3);
        uVar3 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
        uVar2 = (**(code **)(*plVar5 + 0x58))(plVar5);
        cVar1 = FUN_14037c800(lVar4,uVar2,uVar3,CONCAT44(uStackX_24,local_res20),param_2,param_3);
        if (cVar1 != '\0') {
          uVar3 = FUN_140008520((int)param_1[0x2d]);
          plVar5 = (longlong *)FUN_1400876b0(uVar3);
          plVar5 = (longlong *)(**(code **)(*plVar5 + 0x50))(plVar5);
          (**(code **)(*plVar5 + 0x20))(plVar5,lVar4);
          return 1;
        }
        (**(code **)(*param_1 + 0x50))(param_1);
        log_InlineLogDBERROR
                  ("table:cq_itemtype, monster(type:%u) drop item, can not found itemtype:%u.");
        (**(code **)(*(longlong *)(lVar4 + 0x10) + 8))();
      }
    }
    uVar3 = 0;
  }
  return uVar3;
}

// ==== CMonster::helper_14038a900  @14038a900  [medium:callgraph-r0]  (orig: FUN_14038a900)
int * FUN_14038a900(longlong param_1,undefined4 param_2)

{
  longlong *plVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  longlong lVar5;
  undefined8 uVar6;
  int *piVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  
  lVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
  if (*(longlong *)(lVar5 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar5 = (**(code **)(**(longlong **)(lVar5 + 0x90) + 0x98))(*(longlong **)(lVar5 + 0x90),param_2);
  piVar8 = (int *)0x0;
  if (lVar5 != 0) {
    iVar9 = 0x1b59;
    do {
      uVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
      piVar7 = (int *)FUN_1400b29c0(uVar6,iVar9);
      piVar8 = piVar7;
      if (((piVar7 != (int *)0x0) && (*piVar7 == 1)) &&
         (((*(longlong *)(piVar7 + 6) == 0 && (*(longlong *)(piVar7 + 8) == 0)) ||
          ((piVar8 = (int *)FUN_1403880b0(param_1), *(longlong *)(piVar7 + 6) <= (longlong)piVar8 &&
           ((longlong)piVar8 <= *(longlong *)(piVar7 + 8))))))) {
        iVar2 = tq::RandGet(10000);
        iVar10 = piVar7[2];
        plVar1 = (longlong *)(lVar5 + 0x10);
        piVar8 = (int *)(**(code **)(*(longlong *)(lVar5 + 0x10) + 0x260))(plVar1);
        if ((char)piVar8 != '\0') {
          piVar8 = (int *)((longlong)iVar10 * 0x55555556 & 0xffffffff);
          iVar10 = iVar10 / 3;
        }
        if (piVar7[3] == 1) {
          iVar3 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
          iVar4 = (**(code **)(*plVar1 + 0x70))(plVar1);
          piVar8 = (int *)(ulonglong)(uint)(iVar4 - iVar3);
          if (piVar7[4] <= iVar4 - iVar3) {
            piVar8 = (int *)((longlong)iVar10 * 0x55555556 & 0xffffffff);
            iVar10 = iVar10 / 3;
          }
        }
        if (iVar2 < iVar10) {
          piVar8 = (int *)FUN_14038a790(param_1,piVar7[1],param_2);
        }
      }
      iVar9 = iVar9 + 1;
    } while (iVar9 < 0x1b62);
  }
  return piVar8;
}

// ==== CMonster::DropEquipment  @14038aab0  [high:log-string]  (orig: FUN_14038aab0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14038aab0(longlong *param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  longlong lVar6;
  undefined8 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  longlong *plVar10;
  ulonglong uVar11;
  undefined1 auStack_568 [32];
  undefined4 *local_548;
  undefined4 local_540;
  undefined4 local_538;
  undefined4 local_528;
  undefined4 uStack_524;
  longlong local_520;
  undefined8 local_518;
  undefined4 local_508;
  uint local_504;
  int local_4d4;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_518 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_568;
  lVar6 = FUN_140008520((int)param_1[0x2d]);
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    local_548 = (undefined4 *)CONCAT44(local_548._4_4_,0x130);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x98))();
  if (lVar6 != 0) {
    iVar2 = FUN_140175470(lVar6);
    if (iVar2 != 0) {
      iVar2 = FUN_140164ee0(lVar6);
      iVar3 = tq::RandGet(100);
      if (iVar2 <= iVar3) {
        return 0;
      }
    }
    cVar1 = FUN_140168a10(lVar6);
    if (cVar1 != '\0') {
      uVar4 = FUN_1401649c0(lVar6);
      if (uVar4 < 4) {
        iVar2 = tq::RandGet(8);
        if (iVar2 < 7) {
          return 0;
        }
      }
      else {
        iVar2 = tq::RandGet(4);
        if (iVar2 < 3) {
          return 0;
        }
      }
    }
  }
  if (param_2 < 100) {
    uVar7 = FUN_14038a560(param_1,param_2,param_3);
    return uVar7;
  }
  memset(&local_508,0,100);
  local_548 = (undefined4 *)CONCAT44(local_548._4_4_,param_4);
  cVar1 = FUN_1401013d0((int)param_1[0x2d],&local_508,param_2,param_1[0x28]);
  if (cVar1 == '\0') {
    uVar7 = FUN_14038a560(param_1,param_2,param_3);
    return uVar7;
  }
  local_528 = (**(code **)(param_1[2] + 0x40))(param_1 + 2);
  uStack_524 = (**(code **)(param_1[2] + 0x48))(param_1 + 2);
  uVar7 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  cVar1 = FUN_1402d1110(uVar7,2,&local_528);
  if (cVar1 == '\0') {
    return 0;
  }
  uVar7 = FUN_140008520((int)param_1[0x2d]);
  plVar8 = (longlong *)FUN_140087650(uVar7);
  plVar8 = (longlong *)(**(code **)(*plVar8 + 0x98))(plVar8,param_3);
  if ((plVar8 != (longlong *)0x0) && (*(int *)((longlong)plVar8 + 0xb2c) != 0)) {
    if (((local_504 == 0x109a00) || (local_504 % 10 == 9)) &&
       (iVar2 = tq::RandGet(100), iVar2 < 0x4b)) {
      uVar11 = (ulonglong)local_504;
    }
    else {
      if ((local_504 != 0x109a01) || (iVar2 = tq::RandGet(100), 9 < iVar2)) goto LAB_14038ae2d;
      uVar11 = 0x109a02;
      local_504 = 0x109a02;
    }
    iVar2 = (int)uVar11;
    if (iVar2 + (int)(uVar11 / 10) * -10 == 9) {
      pIVar9 = theInstance();
      lVar6 = *plVar8;
      uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_LUCK_ULTRA_EQP");
      (**(code **)(lVar6 + 0x150))(plVar8,0x7d5,uVar7);
    }
    else if (iVar2 == 0x109a00) {
      pIVar9 = theInstance();
      lVar6 = *plVar8;
      uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_LUCK_DRAGON_BALL");
      (**(code **)(lVar6 + 0x150))(plVar8,0x7d5,uVar7);
    }
    else if (iVar2 == 0x109a02) {
      pIVar9 = theInstance();
      lVar6 = *plVar8;
      uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_LUCK_SHT_STAR_TEAR");
      (**(code **)(lVar6 + 0x150))(plVar8,0x7d5,uVar7);
    }
    FUN_14037dfb0(local_498);
    uVar5 = (**(code **)(*plVar8 + 8))(plVar8);
    iVar2 = FUN_14037e0a0(local_498,10,"LuckyGuy",uVar5);
    if (iVar2 == 0) {
      local_548 = (undefined4 *)CONCAT44(local_548._4_4_,0xb60);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      (**(code **)(plVar8[2] + 0x348))(plVar8 + 2,local_498,1);
    }
    FUN_14037e030(local_498);
  }
LAB_14038ae2d:
  local_520 = FUN_14037c6e0(0xe8);
  if (local_520 == 0) {
    lVar6 = 0;
  }
  else {
    lVar6 = FUN_14037d2d0(local_520);
  }
  if (lVar6 == 0) {
    return 0;
  }
  local_508 = 0;
  uVar7 = FUN_140008520((int)param_1[0x2d]);
  plVar10 = (longlong *)FUN_1400876b0(uVar7);
  uVar7 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
  uVar5 = (**(code **)(*plVar10 + 0x58))(plVar10);
  local_538 = 0;
  local_548 = &local_508;
  local_540 = param_3;
  cVar1 = FUN_14037cda0(lVar6,uVar5,uVar7,CONCAT44(uStack_524,local_528));
  if (cVar1 == '\0') {
    (**(code **)(*param_1 + 0x50))(param_1);
    log_InlineLogWARNING("CMonster::DropEquipment(): monster_type[%d], item_type[%u].");
    (**(code **)(*(longlong *)(lVar6 + 0x10) + 8))();
    return 0;
  }
  uVar7 = FUN_140008520((int)param_1[0x2d]);
  plVar10 = (longlong *)FUN_1400876b0(uVar7);
  plVar10 = (longlong *)(**(code **)(*plVar10 + 0x50))(plVar10);
  (**(code **)(*plVar10 + 0x20))(plVar10,lVar6);
  if ((0 < local_4d4) && (plVar8 != (longlong *)0x0)) {
    FUN_14032b550(plVar8,(undefined2)local_4d4);
  }
  if ((local_504 == 0x109a01) || (local_504 == 0x109a02)) {
    uVar7 = FUN_140087d90();
    FUN_1401143f0(uVar7,param_3,0x291c);
  }
  else if (local_504 == 0x109a00) {
    uVar7 = FUN_140087d90();
    FUN_1401143f0(uVar7,param_3,0x291b);
  }
  return 1;
}

// ==== CMonster::helper_14038afc0  @14038afc0  [medium:callgraph-r0]  (orig: FUN_14038afc0)
undefined8 FUN_14038afc0(longlong param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  ulonglong uVar3;
  longlong *plVar4;
  
  iVar1 = tq::RandGet(100);
  if (iVar1 < 2) {
    uVar3 = 8;
  }
  else if (iVar1 < 3) {
    uVar3 = 6;
  }
  else if (iVar1 < 5) {
    uVar3 = 5;
  }
  else if (iVar1 < 8) {
    uVar3 = 4;
  }
  else if (iVar1 < 10) {
    uVar3 = 3;
  }
  else {
    uVar3 = (ulonglong)((iVar1 < 0x19) + 1);
  }
  if ((int)uVar3 != 0) {
    do {
      iVar1 = tq::RandGet(2);
      if (iVar1 == 1) {
        plVar4 = (longlong *)
                 (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                           ((longlong *)**(undefined8 **)(param_1 + 0x140),0x22);
        uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
      }
      else {
        plVar4 = (longlong *)
                 (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                           ((longlong *)**(undefined8 **)(param_1 + 0x140),0x23);
        uVar2 = (**(code **)(*plVar4 + 0x48))(plVar4);
      }
      FUN_14038a790(param_1,uVar2,param_2);
      uVar3 = uVar3 - 1;
    } while (uVar3 != 0);
  }
  return 1;
}

// ==== CMonster::helper_14038b0b0  @14038b0b0  [medium:callgraph-r0]  (orig: FUN_14038b0b0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_14038b0b0(longlong param_1,longlong *param_2,char param_3)

{
  float fVar1;
  float fVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong lVar10;
  float fVar11;
  float fVar12;
  int local_res10 [2];
  int local_res20 [2];
  int local_38;
  int local_34 [7];
  
  if (param_2 == (longlong *)0x0) {
    return 0;
  }
  lVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
  lVar10 = *(longlong *)(lVar8 + 0x1c0);
  if (*(longlong *)(lVar8 + 0x1c0) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar10 = 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  cVar3 = FUN_1401e6150(lVar10,uVar4);
  if (cVar3 == '\0') {
    return 0;
  }
  uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
  iVar5 = FUN_14008b030(uVar9);
  local_34[0] = 0;
  local_38 = 0;
  local_res20[0] = 0;
  local_res10[0] = 0;
  uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
  FUN_14008b040(uVar9,local_34,&local_38,local_res20,local_res10);
  lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
  lVar10 = *(longlong *)(lVar10 + 0x1c0);
  if (lVar10 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar10 = 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  cVar3 = FUN_1401e6550(lVar10,uVar4);
  fVar2 = DAT_14075de40;
  fVar1 = DAT_14075de08;
  fVar12 = DAT_14075ddd0;
  fVar11 = DAT_140717cd8;
  if (cVar3 != '\x01') {
    if (cVar3 == '\x02') {
      fVar12 = (float)local_34[0] / DAT_140755ba8;
      if ((float)local_34[0] / DAT_140755ba8 <= 0.0) {
        log_InlineLogERROR("CMonster::DropProtectHeartPill, fRateMulti2<=0");
        fVar12 = fVar11;
      }
      iVar5 = (int)((float)iVar5 / fVar12);
    }
    else if (cVar3 == '\x03') {
      fVar11 = (float)local_38 / DAT_140755ba8;
      if ((float)local_38 / DAT_140755ba8 <= 0.0) {
        log_InlineLogERROR("CMonster::DropProtectHeartPill, fRateMulti3<=0");
        fVar11 = fVar12;
      }
      iVar5 = (int)((float)iVar5 / fVar11);
    }
    else if (cVar3 == '\x04') {
      fVar11 = (float)local_res20[0] / DAT_140755ba8;
      if ((float)local_res20[0] / DAT_140755ba8 <= 0.0) {
        log_InlineLogERROR("CMonster::DropProtectHeartPill, fRateMulti4<=0");
        fVar11 = fVar1;
      }
      iVar5 = (int)((float)iVar5 / fVar11);
    }
    else {
      if (cVar3 != '\x05') {
        return 0;
      }
      fVar11 = (float)local_res10[0] / DAT_140755ba8;
      if ((float)local_res10[0] / DAT_140755ba8 <= 0.0) {
        log_InlineLogERROR("CMonster::DropProtectHeartPill, fRateMulti5<=0");
        fVar11 = fVar2;
      }
      iVar5 = (int)((float)iVar5 / fVar11);
    }
  }
  iVar6 = (**(code **)(param_2[2] + 0x70))(param_2 + 2);
  iVar7 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
  iVar6 = iVar6 - iVar7;
  if (iVar6 < 100) {
    if (iVar6 < 0x32) {
      if (0x13 < iVar6) {
        iVar5 = (int)((double)iVar5 / DAT_14075dd58);
      }
    }
    else {
      iVar5 = (int)((double)iVar5 * DAT_14075dd60);
    }
  }
  else {
    iVar5 = (int)((double)iVar5 / _DAT_14075dd68);
  }
  if (param_3 != '\0') {
    uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x168));
    iVar6 = FUN_14008b070(uVar9);
    if (iVar6 < 1) {
      iVar6 = 10000;
    }
    iVar5 = (int)(((longlong)iVar5 * 10000) / (longlong)iVar6);
  }
  iVar5 = tq::RandGet(iVar5);
  if (iVar5 != 0xc) {
    return 0;
  }
  uVar4 = (**(code **)(*param_2 + 8))(param_2);
  FUN_14038a790(param_1,0x2dcead,uVar4);
  return 1;
}

// ==== CMonster::vfunc_17  @14038b6d0  [high:rtti-vtable]  (orig: FUN_14038b6d0)
void FUN_14038b6d0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),7);
                    /* WARNING: Could not recover jumptable at 0x00014038b6f3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_18  @14038b700  [high:rtti-vtable]  (orig: FUN_14038b700)
void FUN_14038b700(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),6);
                    /* WARNING: Could not recover jumptable at 0x00014038b723. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_28  @14038b730  [high:rtti-vtable]  (orig: FUN_14038b730)
int FUN_14038b730(longlong *param_1)

{
  char cVar1;
  int nNumber;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x25);
  nNumber = (**(code **)(*plVar3 + 0x48))(plVar3);
  cVar1 = (**(code **)(*param_1 + 0x2d8))(param_1,9);
  if (cVar1 != '\0') {
    plVar3 = (longlong *)FUN_1401181a0();
    iVar2 = (**(code **)(*plVar3 + 0xb0))(plVar3,(int)param_1[0xf],9);
    if (iVar2 < 30000) {
      if (iVar2 < -29999) {
        nNumber = -30000 - iVar2;
      }
      else if (iVar2 == -0x8000) {
        log_InlineLogERROR(&DAT_1406d9c10);
        nNumber = 0;
      }
      else {
        nNumber = nNumber + iVar2;
      }
    }
    else {
      nNumber = MulDiv(nNumber,iVar2 + -30000,100);
    }
  }
  if (0x5a < nNumber) {
    nNumber = 0x5a;
  }
  if (nNumber < 0) {
    nNumber = 0;
  }
  return nNumber;
}

// ==== CMonster::vfunc_29  @14038b820  [high:rtti-vtable]  (orig: FUN_14038b820)
int FUN_14038b820(longlong *param_1)

{
  int iVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  
  iVar3 = (**(code **)(*param_1 + 0xf0))();
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,0x10);
  if (cVar2 == '\0') {
    return iVar3;
  }
  plVar5 = (longlong *)FUN_1401181a0();
  iVar4 = (**(code **)(*plVar5 + 0xb0))(plVar5,(int)param_1[0xf],0x10);
  if (29999 < iVar4) {
    iVar3 = MulDiv(iVar3,iVar4 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar4 < -29999) {
    iVar3 = -30000 - iVar4;
    if (-30000 - iVar4 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar4 != -0x8000) {
    iVar1 = iVar4 + iVar3;
    if (iVar4 + iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_74  @14038b920  [high:rtti-vtable]  (orig: FUN_14038b920)
uint FUN_14038b920(longlong *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  longlong lVar4;
  longlong *plVar5;
  
  iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
  if (0x1869e < iVar2 - 0xaae61U) {
    plVar5 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x15);
    uVar3 = (**(code **)(*plVar5 + 0x48))(plVar5);
    return uVar3 >> 2 & 1;
  }
  lVar4 = (**(code **)(*param_1 + 0x2b0))(param_1);
  if (lVar4 != 0) {
    lVar4 = (**(code **)(*param_1 + 0x2b0))(param_1);
    cVar1 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x250))(lVar4 + 0x10);
    if (cVar1 != '\0') {
      return 1;
    }
  }
  return 0;
}

// ==== CMonster::vfunc_75  @14038b9b0  [high:rtti-vtable]  (orig: FUN_14038b9b0)
bool FUN_14038b9b0(longlong *param_1)

{
  char cVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  ulonglong uVar5;
  
  iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
  if (0x1869e < iVar2 - 0xaae61U) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x15);
    uVar5 = (**(code **)(*plVar4 + 0x48))(plVar4);
    return (uVar5 & 0x2004) == 0;
  }
  lVar3 = (**(code **)(*param_1 + 0x2b0))(param_1);
  if (lVar3 != 0) {
    lVar3 = (**(code **)(*param_1 + 0x2b0))(param_1);
    cVar1 = (**(code **)(*(longlong *)(lVar3 + 0x10) + 600))(lVar3 + 0x10);
    if (cVar1 != '\0') {
      return true;
    }
  }
  return false;
}

// ==== CMonster::vfunc_96  @14038bdc0  [high:rtti-vtable]  (orig: FUN_14038bdc0)
int FUN_14038bdc0(longlong *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,5);
  if (cVar2 == '\0') {
    return param_2;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],5);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_2,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_2;
    if (iVar3 + param_2 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_97  @14038bec0  [high:rtti-vtable]  (orig: FUN_14038bec0)
int FUN_14038bec0(longlong *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,7);
  if (cVar2 == '\0') {
    return param_2;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],7);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_2,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_2;
    if (iVar3 + param_2 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_98  @14038bfc0  [high:rtti-vtable]  (orig: FUN_14038bfc0)
int FUN_14038bfc0(longlong *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,6);
  if (cVar2 == '\0') {
    return param_2;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],6);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_2,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_2;
    if (iVar3 + param_2 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_99  @14038c0c0  [high:rtti-vtable]  (orig: FUN_14038c0c0)
int FUN_14038c0c0(longlong *param_1,int param_2)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,10);
  if (cVar2 == '\0') {
    return param_2;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],10);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_2,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_2;
    if (iVar3 + param_2 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_100  @14038c1c0  [high:rtti-vtable]  (orig: FUN_14038c1c0)
int FUN_14038c1c0(longlong *param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,0xe);
  if (cVar2 == '\0') {
    iVar3 = (**(code **)(param_1[-2] + 0x38))(param_1 + -2);
                    /* WARNING: Could not recover jumptable at 0x00014038c2c4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar3 = MulDiv(param_3,iVar3,10000);
    return iVar3;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],0xe);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_3,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_3;
    if (iVar3 + param_3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_101  @14038c2d0  [high:rtti-vtable]  (orig: FUN_14038c2d0)
int FUN_14038c2d0(longlong *param_1,undefined8 param_2,int param_3)

{
  int iVar1;
  char cVar2;
  int iVar3;
  longlong *plVar4;
  
  cVar2 = (**(code **)(*param_1 + 0x2d8))(param_1,0xf);
  if (cVar2 == '\0') {
    iVar3 = (**(code **)(param_1[-2] + 0x38))(param_1 + -2);
                    /* WARNING: Could not recover jumptable at 0x00014038c3d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    iVar3 = MulDiv(param_3,iVar3,10000);
    return iVar3;
  }
  plVar4 = (longlong *)FUN_1401181a0();
  iVar3 = (**(code **)(*plVar4 + 0xb0))(plVar4,(int)param_1[0xf],0xf);
  if (29999 < iVar3) {
    iVar3 = MulDiv(param_3,iVar3 + -30000,100);
    if (iVar3 < 1) {
      iVar3 = 0;
    }
    return iVar3;
  }
  if (iVar3 < -29999) {
    iVar1 = -30000 - iVar3;
    if (-30000 - iVar3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  if (iVar3 != -0x8000) {
    iVar1 = iVar3 + param_3;
    if (iVar3 + param_3 < 1) {
      iVar1 = 0;
    }
    return iVar1;
  }
  log_InlineLogERROR(&DAT_1406d9c10);
  return 0;
}

// ==== CMonster::vfunc_6  @14038c3e0  [high:rtti-vtable]  (orig: FUN_14038c3e0)
ulonglong FUN_14038c3e0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xa0);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),3);
                    /* WARNING: Could not recover jumptable at 0x00014038c448. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_31  @14038c450  [high:rtti-vtable]  (orig: FUN_14038c450)
ulonglong FUN_14038c450(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xa4);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0xb);
                    /* WARNING: Could not recover jumptable at 0x00014038c4b8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_32  @14038c4c0  [high:rtti-vtable]  (orig: FUN_14038c4c0)
ulonglong FUN_14038c4c0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xa8);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0xc);
                    /* WARNING: Could not recover jumptable at 0x00014038c528. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_33  @14038c530  [high:rtti-vtable]  (orig: FUN_14038c530)
ulonglong FUN_14038c530(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xac);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0xd);
                    /* WARNING: Could not recover jumptable at 0x00014038c598. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_34  @14038c5a0  [high:rtti-vtable]  (orig: FUN_14038c5a0)
ulonglong FUN_14038c5a0(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xb0);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0xe);
                    /* WARNING: Could not recover jumptable at 0x00014038c608. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_126  @14038c610  [high:rtti-vtable]  (orig: FUN_14038c610)
ulonglong FUN_14038c610(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xb4);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x18);
                    /* WARNING: Could not recover jumptable at 0x00014038c678. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_25  @14038c680  [high:rtti-vtable]  (orig: FUN_14038c680)
ulonglong FUN_14038c680(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar1 - 0xaae61U < 99999) && (*(int *)(param_1 + 0x138) == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0xbc);
  }
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),9);
                    /* WARNING: Could not recover jumptable at 0x00014038c6e8. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::vfunc_11  @14038c6f0  [high:rtti-vtable]  (orig: FUN_14038c6f0)
ulonglong FUN_14038c6f0(longlong *param_1)

{
  int iVar1;
  longlong *plVar2;
  ulonglong uVar3;
  
  iVar1 = (**(code **)(*param_1 + 8))();
  if ((iVar1 - 0xaae61U < 99999) && ((int)param_1[0x29] == 2)) {
    return (ulonglong)*(uint *)(param_1 + 0x19);
  }
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0xf);
                    /* WARNING: Could not recover jumptable at 0x00014038c745. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  uVar3 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar3;
}

// ==== CMonster::helper_14038c750  @14038c750  [medium:callgraph-r0]  (orig: FUN_14038c750)
longlong FUN_14038c750(longlong *param_1)

{
  if (*param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *param_1;
  }
  return *param_1;
}

// ==== CMonster::helper_14038c870  @14038c870  [medium:callgraph-r0]  (orig: FUN_14038c870)
void FUN_14038c870(longlong *param_1)

{
  longlong *plVar1;
  longlong *plVar2;
  int iVar3;
  
  if ((*param_1 == 0) || (param_1[1] != 0)) {
    FUN_140388d20();
    return;
  }
  iVar3 = 0;
  plVar2 = (longlong *)param_1[2];
  do {
    if (plVar2 == (longlong *)0x0) goto LAB_14038c947;
    plVar1 = (longlong *)plVar2[2];
    if (*plVar2 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    iVar3 = iVar3 + 1;
    *plVar2 = 0;
    plVar2[1] = 0;
    plVar2[2] = 0;
    plVar2 = plVar1;
  } while (iVar3 < 0x65);
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_14038c947:
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  return;
}

// ==== CMonster::helper_14038ce40  @14038ce40  [medium:callgraph-r0]  (orig: FUN_14038ce40)
void FUN_14038ce40(longlong *param_1)

{
  longlong lVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined4 uVar4;
  longlong *plVar5;
  undefined8 uVar6;
  
  iVar3 = (**(code **)(*param_1 + 8))();
  if ((iVar3 - 0xaae61U < 99999) && (param_1[8] != 0)) {
    if (param_1[8] == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar1 = param_1[8];
    uVar4 = (**(code **)(*param_1 + 8))(param_1);
    FUN_1401aa9e0(lVar1,uVar4);
  }
  plVar5 = (longlong *)FUN_1401181a0();
  lVar1 = *plVar5;
  uVar4 = (**(code **)(*param_1 + 8))(param_1);
  (**(code **)(lVar1 + 0x50))(plVar5,uVar4);
  iVar3 = (**(code **)(*param_1 + 8))(param_1);
  if (iVar3 != 0) {
    if ((*(uint *)(param_1 + 0x11) < 0x7a121) || (599999 < *(uint *)(param_1 + 0x11))) {
      iVar3 = (**(code **)(*param_1 + 8))(param_1);
      if (iVar3 - 0xaae61U < 99999) {
        uVar6 = FUN_140008520((int)param_1[0x2d]);
        plVar5 = (longlong *)FUN_1400876b0(uVar6);
        lVar1 = *plVar5;
        uVar4 = (**(code **)(*param_1 + 8))(param_1);
        (**(code **)(lVar1 + 0xf0))(plVar5,uVar4);
      }
    }
    else {
      uVar6 = FUN_140008520((int)param_1[0x2d]);
      plVar5 = (longlong *)FUN_1400876b0(uVar6);
      lVar1 = *plVar5;
      uVar4 = (**(code **)(*param_1 + 8))(param_1);
      (**(code **)(lVar1 + 0xc0))(plVar5,uVar4);
    }
  }
  plVar5 = (longlong *)param_1[0x10];
  if (plVar5 != (longlong *)0x0) {
    iVar3 = (**(code **)(*plVar5 + 0x10))(plVar5,6);
    if (iVar3 < 1) {
      (**(code **)(*(longlong *)param_1[0x10] + 0x48))((longlong *)param_1[0x10],0);
    }
    else {
      (**(code **)(param_1[2] + 0x338))();
    }
    (**(code **)(*(longlong *)param_1[0x10] + 0x58))();
    param_1[0x10] = 0;
  }
  if ((int)param_1[0x11] != 0) {
    FUN_140388300(param_1);
    *(undefined4 *)(param_1 + 0x11) = 0;
  }
  puVar2 = (undefined8 *)param_1[0x25];
  if (puVar2 != (undefined8 *)0x0) {
    (**(code **)*puVar2)(puVar2,1);
    param_1[0x25] = 0;
  }
  if ((param_1[6] != 0) && (param_1[6] != 0)) {
    puVar2 = (undefined8 *)param_1[6];
    if (puVar2 != (undefined8 *)0x0) {
      (**(code **)*puVar2)(puVar2,1);
    }
    param_1[6] = 0;
  }
  return;
}

// ==== CMonster::vfunc_113  @14038d030  [high:rtti-vtable]  (orig: FUN_14038d030)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_14038d030(longlong *param_1,longlong *param_2)

{
  bool bVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  IStringManager *pIVar11;
  undefined1 auStack_4d8 [32];
  undefined2 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (param_2 == (longlong *)0x0) {
    FUN_1403e8ce0(param_1[0x23]);
    return 1;
  }
  lVar9 = *param_1;
  uVar3 = (**(code **)(*param_2 + 0x3f0))(param_2);
  iVar4 = (**(code **)(lVar9 + 1000))(param_1,uVar3);
  uVar7 = (**(code **)(*param_2 + 0x2a0))(param_2);
  iVar5 = (**(code **)(lVar9 + 0x150))(param_1,uVar7);
  if (iVar4 < iVar5) {
    iVar4 = (**(code **)(*param_2 + 0x10))(param_2);
    iVar5 = (**(code **)(param_1[-2] + 8))();
    if ((0x1869e < iVar5 - 0xaae61U) &&
       ((iVar4 - 0xaae61U < 99999 || (iVar4 - 1000000U < 0xee5be5c0)))) {
      iVar5 = (**(code **)(*param_2 + 0x168))(param_2);
      iVar6 = (**(code **)(*param_1 + 0x168))(param_1);
      if (iVar6 == iVar5) {
        FUN_14039ed70(local_488);
        iVar4 = FUN_14039eef0(local_488,param_2,0,0);
        if (iVar4 != 0) {
          plVar8 = (longlong *)FUN_140008520((int)param_1[0x2b]);
          (**(code **)(*plVar8 + 0x30))(plVar8,(int)param_1[0xf],local_488);
        }
        FUN_14039edf0(local_488);
      }
      else {
        FUN_140362560();
        local_4a0 = 0;
        local_4a8 = 0;
        local_4b0 = 0x87;
        local_4b8 = 0;
        iVar4 = FUN_140362620(local_488,iVar4,0,0);
        if (iVar4 != 0) {
          plVar8 = (longlong *)FUN_140008520((int)param_1[0x2b]);
          (**(code **)(*plVar8 + 0x30))(plVar8,(int)param_1[0xf],local_488);
        }
        FUN_1403625e0(local_488);
      }
    }
    return 0;
  }
  iVar4 = (**(code **)(param_1[-2] + 8))();
  if ((0x1869e < iVar4 - 0xaae61U) ||
     (plVar8 = (longlong *)(**(code **)(*param_1 + 0x2b0))(param_1), plVar8 == (longlong *)0x0))
  goto LAB_14038d3fe;
  lVar9 = (**(code **)(*param_2 + 0x2b0))(param_2);
  cVar2 = FUN_140167b70(plVar8);
  if ((cVar2 == '\0') && ((lVar9 == 0 || (cVar2 = FUN_140167b70(lVar9), cVar2 == '\0')))) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  iVar4 = FUN_140161f90(plVar8);
  if (lVar9 != 0) {
    uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
    cVar2 = FUN_14016cc00(uVar7);
    if (cVar2 != '\0') {
      uVar7 = (**(code **)(plVar8[2] + 0x160))(plVar8 + 2);
      cVar2 = FUN_14016cea0(uVar7);
      if ((cVar2 != '\0') && (iVar4 == 6)) {
        uVar3 = (**(code **)(*plVar8 + 8))(plVar8);
        uVar7 = FUN_140008520((int)param_1[0x2b]);
        uVar7 = FUN_140087ba0(uVar7);
        cVar2 = FUN_1401e6150(uVar7,uVar3);
        if (cVar2 != '\0') goto LAB_14038d2dd;
      }
      uVar7 = (**(code **)(plVar8[2] + 0x160))(plVar8 + 2);
      cVar2 = FUN_14016ced0(uVar7);
      if (cVar2 == '\0') {
        return 0;
      }
      if (!bVar1) {
        return 0;
      }
    }
LAB_14038d2dd:
    uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
    cVar2 = FUN_1401194e0(uVar7);
    if (cVar2 != '\0') {
      return 0;
    }
    uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
    cVar2 = FUN_14016cba0(uVar7);
    if ((cVar2 != '\0') && (cVar2 = FUN_140179940(lVar9,plVar8), cVar2 != '\0')) {
      return 0;
    }
  }
  lVar10 = (**(code **)(*param_1 + 0x2b0))(param_1);
  if (999 < *(short *)(lVar10 + 0xef4)) {
    uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
    cVar2 = FUN_14017ef50(uVar7);
    if (cVar2 == '\0') {
      uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
      cVar2 = FUN_14011dbb0(uVar7);
      if (cVar2 == '\0') {
        uVar7 = (**(code **)(*param_1 + 0x160))(param_1);
        cVar2 = FUN_14016cc30(uVar7);
        if ((((cVar2 == '\0') && (lVar9 != 0)) && (*(short *)(lVar9 + 0xef4) < 0x1e)) &&
           (cVar2 = (**(code **)(*(longlong *)(lVar9 + 0x10) + 600))(), cVar2 == '\0')) {
          pIVar11 = theInstance();
          lVar10 = (**(code **)(*param_1 + 0x2b0))(param_1);
          lVar9 = *(longlong *)(lVar10 + 0x10);
          uVar7 = (*(code *)**(undefined8 **)pIVar11)(pIVar11,"STR_PK");
          (**(code **)(lVar9 + 0x358))((longlong *)(lVar10 + 0x10),uVar7);
          return 0;
        }
      }
    }
  }
  FUN_1401b9c20(plVar8,param_2,1);
LAB_14038d3fe:
  uVar3 = (**(code **)(*param_2 + 0x10))(param_2);
  FUN_1403e8cd0(param_1[0x23],uVar3);
  return 1;
}

// ==== CMonster::vfunc_116  @14038d450  [high:rtti-vtable]  (orig: FUN_14038d450)
undefined8 FUN_14038d450(longlong param_1,int param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong lVar7;
  
  plVar5 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x24);
  iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
  if (iVar1 != 0) {
    plVar5 = (longlong *)
             (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                       ((longlong *)**(undefined8 **)(param_1 + 0x130),0x26);
    iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
    if (iVar1 == 0) {
      if (*(longlong *)(param_1 + 0x60) == 0) {
        if (*(undefined8 **)(param_1 + 0x130) != (undefined8 *)0x0) {
          plVar5 = (longlong *)**(undefined8 **)(param_1 + 0x130);
          plVar5 = (longlong *)(**(code **)(*plVar5 + 0x10))(plVar5,0x24);
          (**(code **)(*plVar5 + 0x48))(plVar5);
          plVar5 = (longlong *)
                   (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                             ((longlong *)**(undefined8 **)(param_1 + 0x130),1);
          (**(code **)(*plVar5 + 0x78))(plVar5);
          plVar5 = (longlong *)
                   (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x20))
                             ((longlong *)**(undefined8 **)(param_1 + 0x130),&DAT_140951730);
          (**(code **)(*plVar5 + 0x40))(plVar5);
          log_InlineLogDBERROR
                    (
                    "table:cq_monstertype, CMonster::AdditionMagic() MonsterType id=%u, name=%s, magic_type=%u at %s, %d"
                    );
        }
      }
      else {
        plVar5 = (longlong *)
                 (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                           (*(longlong **)(param_1 + 0x60),2);
        iVar1 = (**(code **)(*plVar5 + 0x48))(plVar5);
        if (((iVar1 != 2) && (iVar1 != 5)) && (iVar1 != 0x14)) {
          if (iVar1 == 0x18) {
            if ((*(longlong *)(param_1 + 0x30) != 0) && (param_2 != 0)) {
              lVar6 = FUN_14038c750(param_1 + 0x30);
              lVar7 = FUN_14038c750(param_1 + 0x30);
              uVar2 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x78))((longlong *)(lVar6 + 0x10));
              uVar3 = (**(code **)(*(longlong *)(lVar7 + 0x10) + 0x80))((longlong *)(lVar7 + 0x10));
              if (uVar2 < uVar3) {
                plVar5 = (longlong *)
                         (**(code **)(**(longlong **)(param_1 + 0x60) + 0x10))
                                   (*(longlong **)(param_1 + 0x60),10);
                uVar4 = (**(code **)(*plVar5 + 0x48))(plVar5);
                iVar1 = FUN_1401619e0(param_2,uVar4,0);
                if (iVar1 < 1) {
                  iVar1 = 0;
                }
                if (iVar1 != 0) {
                  lVar6 = FUN_14038c750(param_1 + 0x30);
                  (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x2e0))
                            (lVar6 + 0x10,0,(longlong)iVar1,1,0);
                }
              }
            }
            return 1;
          }
          if (iVar1 != 0x19) {
            log_InlineLogERROR(&DAT_1406d9c10);
          }
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMonster::vfunc_118  @14038d690  [high:rtti-vtable]  (orig: FUN_14038d690)
undefined4 FUN_14038d690(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  ulong uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x24);
  iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if ((iVar1 == 0x3ed) && (*(int *)(param_1 + 0x150) == 0)) {
    *(undefined4 *)(param_1 + 0x14c) = 10;
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x150) = uVar2 / 1000;
  }
  return param_3;
}

// ==== CMonster::vfunc_119  @14038d710  [high:rtti-vtable]  (orig: FUN_14038d710)
undefined4 FUN_14038d710(longlong param_1,undefined8 param_2,undefined4 param_3)

{
  int iVar1;
  ulong uVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x24);
  iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  if ((iVar1 == 0x3ed) && (*(int *)(param_1 + 0x150) == 0)) {
    *(undefined4 *)(param_1 + 0x14c) = 10;
    uVar2 = tq::TimeGet(0);
    *(uint *)(param_1 + 0x150) = uVar2 / 1000;
  }
  return param_3;
}

// ==== CMonster::vfunc_121  @14038d790  [high:rtti-vtable]  (orig: FUN_14038d790)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14038d790(longlong *param_1,longlong *param_2,undefined4 param_3,undefined4 param_4)

{
  char cVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong lVar8;
  longlong lVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 auStack_958 [32];
  undefined8 local_938;
  undefined2 local_930;
  undefined4 local_928;
  undefined4 local_920;
  undefined4 local_918;
  char local_908 [8];
  longlong local_900;
  longlong *local_8f8;
  undefined4 local_8f0;
  longlong *local_8e0;
  undefined8 local_8d0;
  undefined1 local_8c8 [1104];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8d0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_958;
  local_8e0 = (longlong *)CONCAT44(local_8e0._4_4_,param_4);
  local_8f0 = param_3;
  if (param_2 == (longlong *)0x0) {
    local_938 = CONCAT44(local_938._4_4_,0x684);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_8f8 = (longlong *)((ulonglong)local_8f8 & 0xffffffff00000000);
    lVar8 = (**(code **)(*param_1 + 0x2b0))();
    lVar9 = (**(code **)(*param_2 + 0x2b0))(param_2);
    if ((lVar8 != 0) && (lVar9 != 0)) {
      iVar4 = FUN_14018ed10(lVar9);
      iVar5 = FUN_14018eb30(lVar8);
      local_8f8 = (longlong *)CONCAT44(local_8f8._4_4_,iVar5 - iVar4);
    }
    FUN_14035f2f0(local_478);
    plVar12 = param_1 + -2;
    uVar2 = (**(code **)(*param_2 + 0x48))(param_2);
    uVar3 = (**(code **)(*param_2 + 0x40))(param_2);
    uVar6 = (**(code **)(*param_2 + 0x10))(param_2);
    uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
    local_918 = 0;
    local_920 = local_8f8._0_4_;
    local_928 = local_8f0;
    local_938 = CONCAT62(local_938._2_6_,uVar3);
    local_930 = uVar2;
    iVar4 = FUN_14035f3a0(local_478,0xe,uVar7,uVar6);
    if (iVar4 != 0) {
      (**(code **)(*param_2 + 0x348))(param_2,local_478,1);
    }
    local_900 = 0;
    cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_900);
    if ((cVar1 != '\0') && (cVar1 = FUN_140168a10(local_900), cVar1 != '\0')) {
      FUN_1403b75b0(local_8c8);
      iVar4 = (**(code **)(*plVar12 + 8))(plVar12);
      if ((iVar4 - 0xaae61U < 99999) &&
         (lVar8 = (**(code **)(*param_1 + 0x2b0))(param_1), lVar8 != 0)) {
        lVar8 = (**(code **)(*param_1 + 0x2b0))(param_1);
        uVar10 = FUN_140167960(local_900);
        uVar11 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))((longlong *)(lVar8 + 0x10));
        local_938 = 0;
        cVar1 = FUN_1403b7700(local_8c8,6,uVar11,uVar10);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(local_900 + 0x10) + 0x350))
                    ((longlong *)(local_900 + 0x10),local_8c8);
        }
      }
      else {
        uVar10 = FUN_140167960(local_900);
        uVar11 = (**(code **)(*param_1 + 0x18))(param_1);
        local_938 = 0;
        cVar1 = FUN_1403b7700(local_8c8,6,uVar11,uVar10);
        if (cVar1 != '\0') {
          (**(code **)(*(longlong *)(local_900 + 0x10) + 0x350))
                    ((longlong *)(local_900 + 0x10),local_8c8);
        }
      }
      FUN_1403b7630(local_8c8);
    }
    local_908[0] = '\0';
    if (param_1[6] != 0) {
      lVar8 = (**(code **)(*param_1 + 0x2b0))(param_1);
      if (lVar8 != 0) {
        uVar10 = (**(code **)(*param_1 + 0x2b0))(param_1);
        FUN_140184b80(uVar10,param_2,(ulonglong)local_8e0 & 0xffffffff,local_908);
      }
      local_8f8 = (longlong *)0x0;
      if (local_900 == 0) {
        cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_8f8);
        if ((((cVar1 != '\0') && (iVar4 = (**(code **)(*local_8f8 + 8))(), iVar4 - 0xaae61U < 99999)
             ) && (cVar1 = FUN_1403885c0(local_8f8), cVar1 != '\0')) &&
           (lVar8 = (**(code **)(local_8f8[2] + 0x2b0))(), lVar8 != 0)) {
          if (param_1[6] == 0) {
            local_938 = CONCAT44(local_938._4_4_,0x22);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          plVar13 = local_8f8;
          local_8e0 = (longlong *)param_1[6];
          lVar8 = *local_8e0;
          iVar4 = (**(code **)(*plVar12 + 0x50))(plVar12);
          uVar10 = (**(code **)(plVar13[2] + 0x2b0))(plVar13 + 2);
          (**(code **)(lVar8 + 0xe8))(local_8e0,uVar10,local_8f0,iVar4 * 10 + 0xca);
        }
      }
      else {
        if (param_1[6] == 0) {
          local_938 = CONCAT44(local_938._4_4_,0x22);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        plVar13 = (longlong *)param_1[6];
        lVar8 = *plVar13;
        iVar4 = (**(code **)(*plVar12 + 0x50))(plVar12);
        (**(code **)(lVar8 + 0xe8))(plVar13,local_900,local_8f0,iVar4 * 10 + 0xc9);
      }
    }
    if (local_900 == 0) {
      plVar13 = (longlong *)0x0;
      if (plVar12 != (longlong *)0x0) {
        plVar13 = param_1;
      }
      (**(code **)(*param_2 + 0x3d0))(param_2,plVar13,1);
    }
    else {
      plVar13 = (longlong *)0x0;
      if (plVar12 != (longlong *)0x0) {
        plVar13 = param_1;
      }
      FUN_1401cc6c0(local_900,plVar13,1);
    }
    lVar8 = (**(code **)(*param_1 + 0x2b0))(param_1);
    if ((lVar8 != 0) && (local_908[0] != '\0')) {
      plVar12 = (longlong *)(**(code **)(*param_1 + 0x2b0))(param_1);
      plVar13 = (longlong *)FUN_1401181a0();
      lVar8 = *plVar13;
      uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
      (**(code **)(lVar8 + 0x10))(plVar13,uVar6,0x6c);
    }
    FUN_14035f340(local_478);
  }
  return;
}

// ==== CMonster::helper_14038dc80  @14038dc80  [medium:callgraph-r0]  (orig: FUN_14038dc80)
void FUN_14038dc80(longlong param_1,longlong *param_2,char param_3,char param_4,char param_5)

{
  double dVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  longlong *plVar8;
  ulonglong uVar9;
  double dVar10;
  
  iVar6 = 0;
  uVar2 = 0;
  if (param_2 != (longlong *)0x0) {
    uVar2 = (**(code **)(*param_2 + 8))(param_2);
  }
  if (param_3 != '\0') {
    plVar8 = (longlong *)
             (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                       ((longlong *)**(undefined8 **)(param_1 + 0x140),0x16);
    iVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
    iVar3 = tq::RandGet(iVar3);
    uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))();
    if (uVar4 < 0x3d) {
      iVar5 = tq::RandGet(100);
      if (iVar5 < 2) {
        uVar4 = 1;
        if (param_4 == '\0') {
          iVar6 = tq::RandGet(4);
          if (iVar6 == 0) {
            uVar4 = 5;
          }
          else if (iVar6 == 1) {
            uVar4 = 6;
          }
          else if (iVar6 == 2) {
            uVar4 = 7;
          }
          else {
            uVar4 = 8;
          }
        }
        else if (param_5 == '\0') {
          iVar6 = tq::RandGet(3);
          uVar4 = iVar6 + 1;
        }
        dVar1 = DAT_14075dd58;
        for (iVar6 = 0; iVar6 < (int)uVar4; iVar6 = iVar6 + 1) {
          iVar5 = iVar6;
          dVar10 = tq::RandomRateGet(dVar1);
          uVar9 = (ulonglong)
                  (dVar10 * (double)((ulonglong)((uint)(iVar3 * 4000) / 100) / (ulonglong)uVar4));
          iVar7 = tq::RandGet(100);
          if (iVar7 < 0x28) {
            FUN_14038aab0(param_1,uVar9 & 0xffffffff,uVar2,0,iVar5);
          }
          else {
            FUN_14038a560(param_1,uVar9 & 0xffffffff,uVar2);
          }
        }
      }
      else if (iVar5 < 0x1b) {
        uVar4 = 1;
        if (param_4 == '\0') {
          iVar5 = tq::RandGet(100);
          dVar1 = DAT_14075dd58;
          if (iVar5 < 10) {
            uVar4 = 3;
          }
          else {
            uVar4 = (iVar5 < 0x28) + 1;
          }
        }
        else {
          dVar1 = DAT_14075dd58;
          if (param_5 == '\0') {
            iVar5 = tq::RandGet(3);
            uVar4 = iVar5 + 1;
            dVar1 = DAT_14075dd58;
          }
        }
        for (; iVar6 < (int)uVar4; iVar6 = iVar6 + 1) {
          dVar10 = tq::RandomRateGet(dVar1);
          uVar9 = (ulonglong)
                  (dVar10 * (double)((ulonglong)((uint)(iVar3 * 0x1e0) / 100) / (ulonglong)uVar4));
          iVar5 = tq::RandGet(100);
          if (iVar5 < 0x28) {
            FUN_14038aab0(param_1,uVar9 & 0xffffffff,uVar2,0);
          }
          else {
            FUN_14038a560(param_1,uVar9 & 0xffffffff,uVar2);
          }
        }
      }
    }
    else {
      iVar5 = tq::RandGet(100);
      if (iVar5 < 3) {
        uVar4 = 1;
        if (param_4 == '\0') {
          iVar5 = tq::RandGet(4);
          dVar1 = DAT_14075dd58;
          if (iVar5 == 0) {
            uVar4 = 5;
          }
          else if (iVar5 == 1) {
            uVar4 = 6;
          }
          else if (iVar5 == 2) {
            uVar4 = 7;
          }
          else {
            uVar4 = 8;
          }
        }
        else {
          dVar1 = DAT_14075dd58;
          if (param_5 == '\0') {
            iVar5 = tq::RandGet(3);
            uVar4 = iVar5 + 1;
            dVar1 = DAT_14075dd58;
          }
        }
        for (; iVar6 < (int)uVar4; iVar6 = iVar6 + 1) {
          dVar10 = tq::RandomRateGet(dVar1);
          uVar9 = (ulonglong)
                  (dVar10 * (double)((ulonglong)((uint)(iVar3 * 0xa50) / 100) / (ulonglong)uVar4));
          iVar5 = tq::RandGet(100);
          if (iVar5 < 0x28) {
            FUN_14038aab0(param_1,uVar9 & 0xffffffff,uVar2,0);
          }
          else {
            FUN_14038a560(param_1,uVar9 & 0xffffffff,uVar2);
          }
        }
      }
      else if (iVar5 < 0x23) {
        uVar4 = 1;
        if (param_4 == '\0') {
          iVar5 = tq::RandGet(100);
          dVar1 = DAT_14075dd58;
          if (iVar5 < 10) {
            uVar4 = 3;
          }
          else {
            uVar4 = (iVar5 < 0x28) + 1;
          }
        }
        else {
          dVar1 = DAT_14075dd58;
          if (param_5 == '\0') {
            iVar5 = tq::RandGet(3);
            uVar4 = iVar5 + 1;
            dVar1 = DAT_14075dd58;
          }
        }
        for (; iVar6 < (int)uVar4; iVar6 = iVar6 + 1) {
          dVar10 = tq::RandomRateGet(dVar1);
          uVar9 = (ulonglong)
                  (dVar10 * (double)((ulonglong)((uint)(iVar3 * 0x168) / 100) / (ulonglong)uVar4));
          iVar5 = tq::RandGet(100);
          if (iVar5 < 0x28) {
            FUN_14038aab0(param_1,uVar9 & 0xffffffff,uVar2,0);
          }
          else {
            FUN_14038a560(param_1,uVar9 & 0xffffffff,uVar2);
          }
        }
      }
    }
    if (param_3 != '\0') {
      iVar6 = tq::RandGet(50000);
      if (iVar6 < 1) {
        uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
        if (uVar4 < 0x51) {
          iVar6 = tq::RandGet(3);
          if (iVar6 == 1) {
            iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
            FUN_14038aab0(param_1,iVar6 * 100,uVar2,9);
          }
        }
        else {
          iVar6 = tq::RandGet(10);
          if (iVar6 == 7) {
            iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
            FUN_14038aab0(param_1,iVar6 * 100,uVar2,9);
          }
        }
      }
      else if (iVar6 < 6) {
        uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
        if (uVar4 < 0x51) {
          iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
          FUN_14038aab0(param_1,iVar6 * 100,uVar2,8);
        }
        else {
          iVar6 = tq::RandGet(5);
          if (iVar6 == 3) {
            iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
            FUN_14038aab0(param_1,iVar6 * 100,uVar2,8);
          }
        }
      }
      else if (iVar6 < 0x1f) {
        uVar4 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
        if (uVar4 < 0x51) {
          iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
          FUN_14038aab0(param_1,iVar6 * 0x32,uVar2,7);
        }
        else {
          iVar6 = tq::RandGet(3);
          if (iVar6 == 1) {
            iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))(param_1 + 0x10);
            FUN_14038aab0(param_1,iVar6 * 0x32,uVar2,7);
          }
        }
      }
      else if (iVar6 < 0x83) {
        iVar6 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x70))();
        FUN_14038aab0(param_1,iVar6 * 0x1e,uVar2,6);
      }
    }
  }
  return;
}

// ==== CMonster::helper_14038e4c0  @14038e4c0  [medium:callgraph-r0]  (orig: FUN_14038e4c0)
void FUN_14038e4c0(longlong *param_1)

{
  uint *puVar1;
  longlong lVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  
  plVar5 = (longlong *)FUN_1401181a0();
  lVar2 = *plVar5;
  uVar3 = (**(code **)(*param_1 + 8))(param_1);
  iVar4 = (**(code **)(lVar2 + 0xf8))(plVar5,uVar3);
  if (iVar4 != 0) {
    if (0xbf < (ulonglong)(longlong)iVar4) {
                    /* WARNING: Subroutine does not return */
      FUN_140118b50((longlong)param_1 + 0xec);
    }
    puVar1 = (uint *)((longlong)param_1 + ((ulonglong)(longlong)iVar4 >> 5) * 4 + 0xec);
    *puVar1 = *puVar1 | 1 << ((byte)iVar4 & 0x1f);
    if (iVar4 != 0xa8) {
      iVar4 = iVar4 + -1;
      if (0xbf < (ulonglong)(longlong)iVar4) {
                    /* WARNING: Subroutine does not return */
        FUN_140118b50((longlong)param_1 + 0xec);
      }
      puVar1 = (uint *)((longlong)param_1 + ((ulonglong)(longlong)iVar4 >> 5) * 4 + 0xec);
      *puVar1 = *puVar1 & ~(1 << ((byte)iVar4 & 0x1f));
    }
  }
  return;
}

// ==== CMonster::vfunc_95  @14038e580  [high:rtti-vtable]  (orig: FUN_14038e580)
undefined8
FUN_14038e580(longlong param_1,undefined8 param_2,undefined1 param_3,undefined8 param_4,
             undefined1 param_5)

{
  uint uVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  undefined8 uVar5;
  
  if (*(undefined8 **)(param_1 + 0x130) == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar3 = (longlong *)**(undefined8 **)(param_1 + 0x130);
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,0x15);
    uVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if ((uVar1 >> 0x12 & 1) != 0) {
      return 0;
    }
  }
  iVar2 = (**(code **)(*(longlong *)(param_1 + -0x10) + 8))(param_1 + -0x10);
  if ((iVar2 - 0xaae61U < 99999) && (*(longlong *)(param_1 + 0x30) != 0)) {
    lVar4 = FUN_14038c750(param_1 + 0x30);
    uVar5 = (**(code **)(*(longlong *)(lVar4 + 0x10) + 0x2f8))
                      (lVar4 + 0x10,param_2,param_3,1,param_5);
    return uVar5;
  }
  return 0;
}

// ==== CMonster::helper_14038e6a0  @14038e6a0  [medium:callgraph-r1]  (orig: FUN_14038e6a0)
bool FUN_14038e6a0(longlong *param_1,longlong *param_2)

{
  longlong *plVar1;
  undefined1 uVar2;
  char cVar3;
  int iVar4;
  uint uVar5;
  undefined8 uVar6;
  longlong *local_res10;
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  iVar4 = (**(code **)(*param_1 + 8))();
  if ((iVar4 - 0xaae61U < 99999) && (param_1[8] != 0)) {
    uVar6 = FUN_14038c750(param_1 + 8);
    uVar2 = FUN_140186200(uVar6,param_2);
    return (bool)uVar2;
  }
  iVar4 = (**(code **)(*param_1 + 8))(param_1);
  if ((iVar4 - 0xaae61U < 99999) && ((int)param_1[0x29] == 1)) {
    return true;
  }
  uVar5 = (**(code **)(*param_2 + 0x10))(param_2);
  if (uVar5 - 1 < 299999) {
    cVar3 = (**(code **)(*param_2 + 0x3e0))(param_2);
    return cVar3 == '\0';
  }
  if (((uVar5 < 0x61a81) || (699999 < uVar5)) && (0x1869e < uVar5 - 0xaae61)) {
    local_res10 = (longlong *)0x0;
    (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_res10);
    if (local_res10 == (longlong *)0x0) {
      return true;
    }
    cVar3 = (**(code **)(local_res10[2] + 0x3e0))(local_res10 + 2);
    if (cVar3 == '\0') {
      return true;
    }
    cVar3 = (**(code **)(param_1[2] + 600))(param_1 + 2);
    return cVar3 == '\0';
  }
  if (uVar5 - 0xaae61 < 99999) {
    local_res10 = (longlong *)0x0;
    cVar3 = (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_res10);
    plVar1 = local_res10;
    if (((cVar3 != '\0') && (local_res10 != (longlong *)0x0)) &&
       ((iVar4 = (**(code **)(*local_res10 + 8))(local_res10), iVar4 - 0xaae61U < 99999 &&
        ((int)plVar1[0x29] == 2)))) {
      return true;
    }
  }
  cVar3 = (**(code **)(param_1[2] + 600))(param_1 + 2);
  if ((cVar3 != '\0') && (cVar3 = (**(code **)(*param_2 + 0x250))(param_2), cVar3 != '\0')) {
    return false;
  }
  cVar3 = (**(code **)(param_1[2] + 0x250))(param_1 + 2);
  if ((cVar3 != '\0') && (cVar3 = (**(code **)(*param_2 + 600))(param_2), cVar3 != '\0')) {
    return false;
  }
  return true;
}

// ==== CMonster::vfunc_1  @14038e980  [high:rtti-vtable]  (orig: FUN_14038e980)
void FUN_14038e980(longlong param_1)

{
  undefined8 *puVar1;
  
  puVar1 = (undefined8 *)(param_1 + -0x10);
  FUN_14038ce40(puVar1);
  if (puVar1 != (undefined8 *)0x0) {
    (**(code **)*puVar1)(puVar1,1);
  }
  return;
}

// ==== CMonster::ctor_or_dtor  @14038e9b0  [high:vtable-assign]  (orig: FUN_14038e9b0)
undefined8 * FUN_14038e9b0(undefined8 *param_1)

{
  longlong lVar1;
  
  FUN_1402b5540();
  param_1[2] = IRole::vftable;
  param_1[3] = IMapThing::vftable;
  *param_1 = CMonster::vftable;
  param_1[2] = CMonster::vftable;
  param_1[3] = CMonster::vftable;
  param_1[6] = 0;
  *(undefined4 *)(param_1 + 7) = 0;
  *(undefined4 *)((longlong)param_1 + 0x3c) = 0;
  param_1[8] = 0;
  param_1[9] = 0;
  param_1[10] = 0;
  param_1[0xb] = 0;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
  *(undefined4 *)(param_1 + 0xf) = 0;
  *(undefined4 *)((longlong)param_1 + 0x7c) = 0;
  *(undefined2 *)((longlong)param_1 + 0x8c) = 0;
  *(undefined2 *)((longlong)param_1 + 0x8e) = 0;
  *(undefined4 *)(param_1 + 0x12) = 0;
  *(undefined4 *)((longlong)param_1 + 0x94) = 0;
  *(undefined4 *)(param_1 + 0x13) = 0;
  *(undefined4 *)((longlong)param_1 + 0x9c) = 0;
  *(undefined4 *)(param_1 + 0x14) = 0;
  *(undefined4 *)((longlong)param_1 + 0xa4) = 0;
  *(undefined4 *)(param_1 + 0x15) = 0;
  *(undefined4 *)((longlong)param_1 + 0xac) = 0;
  *(undefined4 *)(param_1 + 0x16) = 0;
  *(undefined4 *)((longlong)param_1 + 0xb4) = 0;
  *(undefined4 *)(param_1 + 0x17) = 0;
  *(undefined4 *)((longlong)param_1 + 0xbc) = 0;
  *(undefined4 *)(param_1 + 0x18) = 0;
  *(undefined4 *)((longlong)param_1 + 0xc4) = 0;
  *(undefined4 *)(param_1 + 0x19) = 0;
  *(undefined4 *)((longlong)param_1 + 0xcc) = 0;
  *(undefined4 *)(param_1 + 0x1a) = 0;
  *(undefined4 *)((longlong)param_1 + 0xd4) = 0;
  *(undefined4 *)(param_1 + 0x1b) = 0;
  *(undefined4 *)((longlong)param_1 + 0xdc) = 0;
  *(undefined4 *)(param_1 + 0x1c) = 0;
  *(undefined4 *)((longlong)param_1 + 0xe4) = 0;
  *(undefined4 *)(param_1 + 0x1d) = 0;
  lVar1 = 5;
  do {
    *(undefined4 *)((longlong)param_1 + lVar1 * 4 + 0xec) = 0;
    lVar1 = lVar1 + -1;
  } while (-1 < lVar1);
  *(undefined4 *)((longlong)param_1 + 0x104) = 0;
  *(undefined4 *)(param_1 + 0x22) = 0;
  *(undefined4 *)((longlong)param_1 + 0x114) = 0;
  *(undefined4 *)(param_1 + 0x23) = 0;
  *(undefined4 *)(param_1 + 0x26) = 0;
  *(undefined4 *)((longlong)param_1 + 0x134) = 0;
  *(undefined4 *)(param_1 + 0x27) = 0;
  *(undefined2 *)((longlong)param_1 + 0x14c) = 0;
  *(undefined4 *)(param_1 + 0x2a) = 0;
  *(undefined4 *)((longlong)param_1 + 0x154) = 0;
  *(undefined4 *)((longlong)param_1 + 0x15c) = 0;
  *(undefined4 *)(param_1 + 0x2c) = 0;
  *(undefined4 *)((longlong)param_1 + 0x164) = 0;
  *(undefined4 *)((longlong)param_1 + 0x16c) = 0;
  *(undefined4 *)(param_1 + 0x2e) = 0;
  *(undefined4 *)((longlong)param_1 + 0x174) = 0;
  *(undefined4 *)(param_1 + 0x2f) = 0;
  *(undefined1 *)((longlong)param_1 + 0x17c) = 0;
  *(undefined1 *)((longlong)param_1 + 0x17d) = 0;
  *(undefined1 *)((longlong)param_1 + 0x17e) = 1;
  param_1[0x30] = 0;
  *(undefined4 *)(param_1 + 1) = 0x1002;
  *(undefined4 *)(param_1 + 0x2b) = 0;
  param_1[0x21] = 0;
  param_1[0x28] = 0;
  *(undefined4 *)(param_1 + 0x29) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x11) = 0;
  param_1[0x25] = 0;
  param_1[0x10] = 0;
  *(undefined4 *)(param_1 + 4) = 0;
  *(undefined4 *)((longlong)param_1 + 0x24) = 0;
  *(undefined4 *)(param_1 + 5) = 0;
  if (param_1[0xb] != 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  param_1[0xb] = param_1;
  param_1[0xe] = 0;
  *(undefined4 *)((longlong)param_1 + 0x11c) = 0;
  *(undefined4 *)(param_1 + 0x24) = 0;
  *(undefined1 *)(param_1 + 0x31) = 0;
  return param_1;
}

// ==== CMonster::vfunc_4  @14038ec80  [high:rtti-vtable]  (orig: FUN_14038ec80)
void FUN_14038ec80(longlong param_1,undefined4 param_2,undefined4 param_3,undefined8 param_4)

{
  longlong *plVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  
  plVar1 = (longlong *)(param_1 + 0x10);
  uVar2 = (**(code **)(*(longlong *)(param_1 + 0x10) + 0x48))(plVar1);
  uVar3 = (**(code **)(*plVar1 + 0x40))(plVar1);
  uVar4 = (**(code **)(*plVar1 + 0x160))(plVar1);
  FUN_1402c84c0(uVar4,uVar3,uVar2,param_2,param_3,param_4);
  return;
}

// ==== CMonster::vfunc_85  @14038ed00  [high:rtti-vtable]  (orig: FUN_14038ed00)
void FUN_14038ed00(longlong *param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined8 uVar3;
  
  uVar1 = (**(code **)(*param_1 + 0x48))();
  uVar2 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar3 = (**(code **)(*param_1 + 0x160))(param_1);
  FUN_1402c8700(uVar3,uVar2,uVar1,param_2);
  return;
}

// ==== CMonster::vfunc_8  @14038ed60  [high:rtti-vtable]  (orig: FUN_14038ed60)
undefined8 FUN_14038ed60(longlong param_1,longlong *param_2)

{
  if (param_1 != 0x18) {
    *param_2 = param_1 + -8;
    return CONCAT71((int7)((ulonglong)(param_1 + -8) >> 8),1);
  }
  *param_2 = 0;
  return 1;
}

// ==== CMonster::vfunc_83  @14038ed80  [high:rtti-vtable]  (orig: FUN_14038ed80)
ulonglong FUN_14038ed80(longlong param_1,int param_2,longlong *param_3)

{
  ulonglong in_RAX;
  
  if (param_2 == 0x1002) {
    *param_3 = param_1 + -0x10;
    return CONCAT71((int7)((ulonglong)(param_1 + -0x10) >> 8),1);
  }
  *param_3 = 0;
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMonster::vfunc_84  @14038eda0  [high:rtti-vtable]  (orig: FUN_14038eda0)
longlong FUN_14038eda0(longlong param_1)

{
  if (param_1 != 0x10) {
    return param_1 + 8;
  }
  return 0;
}

// ==== CMonster::vfunc_4  @14038edc0  [high:rtti-vtable]  (orig: FUN_14038edc0)
undefined8 FUN_14038edc0(void)

{
  return 0;
}

// ==== CMonster::vfunc_5  @14038edd0  [high:rtti-vtable]  (orig: FUN_14038edd0)
undefined8 FUN_14038edd0(void)

{
  return 0;
}

// ==== CMonster::vfunc_5  @14038ede0  [high:rtti-vtable]  (orig: FUN_14038ede0)
void FUN_14038ede0(void)

{
  IStringManager *pIVar1;
  
  pIVar1 = theInstance();
                    /* WARNING: Could not recover jumptable at 0x00014038edfb. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)**(undefined8 **)pIVar1)(pIVar1,"TITILE_NONE");
  return;
}

// ==== CMonster::vfunc_7  @14038ee00  [high:rtti-vtable]  (orig: FUN_14038ee00)
undefined2 FUN_14038ee00(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x7c);
}

// ==== CMonster::vfunc_6  @14038ee10  [high:rtti-vtable]  (orig: FUN_14038ee10)
undefined2 FUN_14038ee10(longlong param_1)

{
  return *(undefined2 *)(param_1 + 0x8e);
}

// ==== CMonster::vfunc_8  @14038ee20  [high:rtti-vtable]  (orig: FUN_14038ee20)
undefined4 FUN_14038ee20(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xcc);
}

// ==== CMonster::vfunc_9  @14038ee30  [high:rtti-vtable]  (orig: FUN_14038ee30)
undefined4 FUN_14038ee30(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xd0);
}

// ==== CMonster::vfunc_10  @14038ee40  [high:rtti-vtable]  (orig: FUN_14038ee40)
undefined4 FUN_14038ee40(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xd4);
}

// ==== CMonster::vfunc_11  @14038ee50  [high:rtti-vtable]  (orig: FUN_14038ee50)
undefined4 * FUN_14038ee50(longlong param_1,undefined4 *param_2)

{
  *param_2 = *(undefined4 *)(param_1 + 0xdc);
  param_2[1] = *(undefined4 *)(param_1 + 0xe0);
  param_2[2] = *(undefined4 *)(param_1 + 0xe4);
  param_2[3] = *(undefined4 *)(param_1 + 0xe8);
  param_2[4] = *(undefined4 *)(param_1 + 0xec);
  param_2[5] = *(undefined4 *)(param_1 + 0xf0);
  return param_2;
}

// ==== CMonster::vfunc_12  @14038ee90  [high:rtti-vtable]  (orig: FUN_14038ee90)
undefined4 FUN_14038ee90(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xf4);
}

// ==== CMonster::vfunc_13  @14038eea0  [high:rtti-vtable]  (orig: FUN_14038eea0)
undefined8 FUN_14038eea0(void)

{
  return 0;
}

// ==== CMonster::vfunc_15  @14038eeb0  [high:rtti-vtable]  (orig: FUN_14038eeb0)
undefined4 FUN_14038eeb0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x104);
}

// ==== CMonster::vfunc_51  @14038eec0  [high:rtti-vtable]  (orig: FUN_14038eec0)
undefined8 FUN_14038eec0(void)

{
  return 0;
}

// ==== CMonster::vfunc_52  @14038eed0  [high:rtti-vtable]  (orig: FUN_14038eed0)
undefined8 FUN_14038eed0(void)

{
  return 0;
}

// ==== CMonster::vfunc_53  @14038eee0  [high:rtti-vtable]  (orig: FUN_14038eee0)
undefined8 FUN_14038eee0(void)

{
  return 0;
}

// ==== CMonster::vfunc_102  @14038eef0  [high:rtti-vtable]  (orig: FUN_14038eef0)
void FUN_14038eef0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0x128) = param_2;
  return;
}

// ==== CMonster::vfunc_35  @14038ef00  [high:rtti-vtable]  (orig: FUN_14038ef00)
undefined4 FUN_14038ef00(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x80);
}

// ==== CMonster::vfunc_36  @14038ef10  [high:rtti-vtable]  (orig: FUN_14038ef10)
undefined4 FUN_14038ef10(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x94);
}

// ==== CMonster::vfunc_37  @14038ef20  [high:rtti-vtable]  (orig: FUN_14038ef20)
undefined4 FUN_14038ef20(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x90);
}

// ==== CMonster::vfunc_38  @14038ef30  [high:rtti-vtable]  (orig: FUN_14038ef30)
undefined4 FUN_14038ef30(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x98);
}

// ==== CMonster::vfunc_39  @14038ef40  [high:rtti-vtable]  (orig: FUN_14038ef40)
undefined4 FUN_14038ef40(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x9c);
}

// ==== CMonster::vfunc_40  @14038ef50  [high:rtti-vtable]  (orig: FUN_14038ef50)
undefined8 FUN_14038ef50(void)

{
  return 0;
}

// ==== CMonster::vfunc_41  @14038ef60  [high:rtti-vtable]  (orig: FUN_14038ef60)
undefined8 FUN_14038ef60(void)

{
  return 0;
}

// ==== CMonster::vfunc_42  @14038ef70  [high:rtti-vtable]  (orig: FUN_14038ef70)
int FUN_14038ef70(longlong *param_1,longlong *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  
  if (param_2 == (longlong *)0x0) {
    return 0xff;
  }
  iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar5 = iVar2 - iVar1 >> 0x1f;
  iVar3 = (**(code **)(*param_2 + 0x20))(param_2);
  iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
  uVar6 = iVar4 - iVar3 >> 0x1f;
  if ((int)((iVar2 - iVar1 ^ uVar5) - uVar5) < (int)((iVar4 - iVar3 ^ uVar6) - uVar6)) {
    iVar1 = (**(code **)(*param_2 + 0x20))(param_2);
    iVar2 = (**(code **)(*param_1 + 0x40))(param_1);
    uVar5 = iVar2 - iVar1 >> 0x1f;
    return (iVar2 - iVar1 ^ uVar5) - uVar5;
  }
  iVar1 = (**(code **)(*param_2 + 0x28))(param_2);
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar5 = iVar2 - iVar1 >> 0x1f;
  return (iVar2 - iVar1 ^ uVar5) - uVar5;
}

// ==== CMonster::vfunc_43  @14038f040  [high:rtti-vtable]  (orig: FUN_14038f040)
int FUN_14038f040(longlong *param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar1 = (**(code **)(*param_1 + 0x40))();
  uVar3 = iVar1 - param_2 >> 0x1f;
  iVar2 = (**(code **)(*param_1 + 0x48))(param_1);
  uVar4 = iVar2 - param_3 >> 0x1f;
  if ((int)((iVar2 - param_3 ^ uVar4) - uVar4) < (int)((iVar1 - param_2 ^ uVar3) - uVar3)) {
    iVar1 = (**(code **)(*param_1 + 0x40))();
    uVar3 = iVar1 - param_2;
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    uVar3 = iVar1 - param_3;
  }
  return (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f);
}

// ==== CMonster::vfunc_46  @14038f0b0  [high:rtti-vtable]  (orig: FUN_14038f0b0)
undefined8 FUN_14038f0b0(longlong param_1)

{
  int iVar1;
  undefined8 uVar2;
  
  if (*(longlong *)(param_1 + 0x70) != 0) {
    iVar1 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x10))(*(longlong **)(param_1 + 0x70),2);
    if (iVar1 == 2) {
                    /* WARNING: Could not recover jumptable at 0x00014038f0e5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      uVar2 = (**(code **)(**(longlong **)(param_1 + 0x70) + 0x10))
                        (*(longlong **)(param_1 + 0x70),1);
      return uVar2;
    }
  }
  return 0;
}

// ==== CMonster::vfunc_47  @14038f100  [high:rtti-vtable]  (orig: FUN_14038f100)
undefined8 FUN_14038f100(void)

{
  return 0;
}

// ==== CMonster::vfunc_48  @14038f110  [high:rtti-vtable]  (orig: FUN_14038f110)
undefined1 FUN_14038f110(void)

{
  return 0;
}

// ==== CMonster::vfunc_80  @14038f120  [high:rtti-vtable]  (orig: FUN_14038f120)
undefined1 FUN_14038f120(void)

{
  return 0;
}

// ==== CMonster::vfunc_54  @14038f130  [high:rtti-vtable]  (orig: FUN_14038f130)
undefined4 FUN_14038f130(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x84);
}

// ==== CMonster::vfunc_55  @14038f140  [high:rtti-vtable]  (orig: FUN_14038f140)
undefined4 FUN_14038f140(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x88);
}

// ==== CMonster::vfunc_56  @14038f150  [high:rtti-vtable]  (orig: FUN_14038f150)
undefined4 FUN_14038f150(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x8c);
}

// ==== CMonster::vfunc_57  @14038f160  [high:rtti-vtable]  (orig: FUN_14038f160)
undefined1 FUN_14038f160(void)

{
  return 0;
}

// ==== CMonster::vfunc_58  @14038f170  [high:rtti-vtable]  (orig: FUN_14038f170)
undefined1 FUN_14038f170(void)

{
  return 0;
}

// ==== CMonster::vfunc_59  @14038f180  [high:rtti-vtable]  (orig: FUN_14038f180)
undefined8 FUN_14038f180(void)

{
  return 0;
}

// ==== CMonster::vfunc_1  @14038f190  [high:rtti-vtable]  (orig: FUN_14038f190)
undefined4 FUN_14038f190(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0x88);
}

// ==== CMonster::vfunc_2  @14038f1a0  [high:rtti-vtable]  (orig: FUN_14038f1a0)
undefined4 FUN_14038f1a0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 8);
}

// ==== CMonster::vfunc_69  @14038f1b0  [high:rtti-vtable]  (orig: FUN_14038f1b0)
bool FUN_14038f1b0(longlong param_1)

{
  return *(int *)(param_1 + 0xd8) == -1;
}

// ==== CMonster::vfunc_70  @14038f1c0  [high:rtti-vtable]  (orig: FUN_14038f1c0)
undefined1 FUN_14038f1c0(void)

{
  return 0;
}

// ==== CMonster::vfunc_71  @14038f1d0  [high:rtti-vtable]  (orig: FUN_14038f1d0)
undefined1 FUN_14038f1d0(void)

{
  return 0;
}

// ==== CMonster::vfunc_76  @14038f1e0  [high:rtti-vtable]  (orig: FUN_14038f1e0)
void FUN_14038f1e0(longlong *param_1)

{
  undefined4 uVar1;
  
  uVar1 = (**(code **)(*param_1 + 0x108))();
  FUN_14015f820(uVar1);
  return;
}

// ==== CMonster::vfunc_77  @14038f200  [high:rtti-vtable]  (orig: FUN_14038f200)
bool FUN_14038f200(longlong *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x108))();
  return (iVar1 % 1000000) / 1000 == 0x265;
}

// ==== CMonster::vfunc_78  @14038f250  [high:rtti-vtable]  (orig: FUN_14038f250)
bool FUN_14038f250(longlong *param_1)

{
  int iVar1;
  
  iVar1 = (**(code **)(*param_1 + 0x110))();
  return (iVar1 % 10000000) / 100000 == 6;
}

// ==== CMonster::vfunc_82  @14038f2b0  [high:rtti-vtable]  (orig: FUN_14038f2b0)
undefined1 FUN_14038f2b0(void)

{
  return 0;
}

// ==== CMonster::vfunc_87  @14038f2c0  [high:rtti-vtable]  (orig: FUN_14038f2c0)
void FUN_14038f2c0(longlong param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = param_2 >> 0x1f & 7;
  *(uint *)(param_1 + 0xd4) = (param_2 + uVar1 & 7) - uVar1;
  return;
}

// ==== CMonster::vfunc_88  @14038f2e0  [high:rtti-vtable]  (orig: FUN_14038f2e0)
void FUN_14038f2e0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xf4) = param_2;
  return;
}

// ==== CMonster::vfunc_112  @14038f2f0  [high:rtti-vtable]  (orig: FUN_14038f2f0)
void FUN_14038f2f0(longlong *param_1)

{
                    /* WARNING: Could not recover jumptable at 0x00014038f2f5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*param_1 + 0x388))(param_1,0);
  return;
}

// ==== CMonster::vfunc_115  @14038f300  [high:rtti-vtable]  (orig: FUN_14038f300)
undefined1 FUN_14038f300(void)

{
  return 0;
}

// ==== CMonster::vfunc_120  @14038f310  [high:rtti-vtable]  (orig: FUN_14038f310)
undefined1 FUN_14038f310(void)

{
  return 0;
}

// ==== CMonster::vfunc_125  @14038f320  [high:rtti-vtable]  (orig: FUN_14038f320)
int FUN_14038f320(longlong *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (**(code **)(*param_1 + 0x3f0))();
  iVar2 = (**(code **)(param_1[-2] + 0x58))(param_1 + -2);
  return iVar2 + (iVar1 + 1 + param_2) / 2;
}

// ==== CMonster::vfunc_44  @14038f360  [high:rtti-vtable]  (orig: FUN_14038f360)
undefined8 FUN_14038f360(longlong param_1)

{
  if (*(longlong *)(param_1 + 0xf8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return *(undefined8 *)(param_1 + 0xf8);
  }
  return *(undefined8 *)(param_1 + 0xf8);
}

// ==== CMonster::vfunc_45  @14038f3c0  [high:rtti-vtable]  (orig: FUN_14038f3c0)
undefined8 FUN_14038f3c0(longlong param_1)

{
  undefined8 uVar1;
  
  if (*(longlong *)(param_1 + 0xf8) != 0) {
                    /* WARNING: Could not recover jumptable at 0x00014038f3d4. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0xf8) + 8))();
    return uVar1;
  }
  return 0;
}

// ==== CMonster::vfunc_2  @14038f3e0  [high:rtti-vtable]  (orig: FUN_14038f3e0)
void FUN_14038f3e0(longlong param_1)

{
  FUN_14038f190(param_1 + -0x10);
  return;
}

// ==== CMonster::vfunc_0  @14038f3f0  [high:rtti-vtable]  (orig: FUN_14038f3f0)
void FUN_14038f3f0(longlong param_1)

{
  FUN_140391c00(param_1 + -0x10);
  return;
}

// ==== CMonster::vfunc_7  @14038f400  [high:rtti-vtable]  (orig: FUN_14038f400)
void FUN_14038f400(longlong param_1)

{
  FUN_14038ed80(param_1 + -8);
  return;
}

// ==== CMonster::vfunc_4  @14038f410  [high:rtti-vtable]  (orig: FUN_14038f410)
void FUN_14038f410(longlong param_1)

{
  FUN_14038ee20(param_1 + -8);
  return;
}

// ==== CMonster::vfunc_2  @14038f420  [high:rtti-vtable]  (orig: FUN_14038f420)
void FUN_14038f420(longlong param_1)

{
  FUN_14038f190(param_1 + -0x18);
  return;
}

// ==== CMonster::vfunc_0  @14038f430  [high:rtti-vtable]  (orig: FUN_14038f430)
void FUN_14038f430(longlong param_1)

{
  FUN_140391c00(param_1 + -0x18);
  return;
}

// ==== CMonster::vfunc_3  @14038f440  [high:rtti-vtable]  (orig: FUN_14038f440)
void FUN_14038f440(longlong param_1)

{
  FUN_14038f1a0(param_1 + -0x18);
  return;
}

// ==== CMonster::vfunc_5  @14038f450  [high:rtti-vtable]  (orig: FUN_14038f450)
void FUN_14038f450(longlong param_1)

{
  FUN_14038ee30(param_1 + -8);
  return;
}

// ==== CMonster::vfunc_3  @14038f460  [high:rtti-vtable]  (orig: FUN_14038f460)
void FUN_14038f460(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),1);
                    /* WARNING: Could not recover jumptable at 0x00014038f483. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x78))(plVar1);
  return;
}

// ==== CMonster::vfunc_14  @14038f490  [high:rtti-vtable]  (orig: FUN_14038f490)
void FUN_14038f490(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x14);
                    /* WARNING: Could not recover jumptable at 0x00014038f4b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_16  @14038f4c0  [high:rtti-vtable]  (orig: FUN_14038f4c0)
void FUN_14038f4c0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),4);
                    /* WARNING: Could not recover jumptable at 0x00014038f4e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_19  @14038f4f0  [high:rtti-vtable]  (orig: FUN_14038f4f0)
int FUN_14038f4f0(longlong param_1)

{
  int iVar1;
  int iVar2;
  longlong *plVar3;
  
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),7);
  iVar1 = (**(code **)(*plVar3 + 0x48))(plVar3);
  plVar3 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),6);
  iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
  return (iVar2 + iVar1) / 2;
}

// ==== CMonster::vfunc_20  @14038f550  [high:rtti-vtable]  (orig: FUN_14038f550)
void FUN_14038f550(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x38);
                    /* WARNING: Could not recover jumptable at 0x00014038f573. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_22  @14038f580  [high:rtti-vtable]  (orig: FUN_14038f580)
void FUN_14038f580(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),8);
                    /* WARNING: Could not recover jumptable at 0x00014038f5a3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_7  @14038f5b0  [high:rtti-vtable]  (orig: FUN_14038f5b0)
void FUN_14038f5b0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x140),0x28);
                    /* WARNING: Could not recover jumptable at 0x00014038f5d3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_23  @14038f5e0  [high:rtti-vtable]  (orig: FUN_14038f5e0)
void FUN_14038f5e0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x39);
                    /* WARNING: Could not recover jumptable at 0x00014038f603. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_27  @14038f610  [high:rtti-vtable]  (orig: FUN_14038f610)
void FUN_14038f610(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),10);
                    /* WARNING: Could not recover jumptable at 0x00014038f633. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_30  @14038f640  [high:rtti-vtable]  (orig: FUN_14038f640)
void FUN_14038f640(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x12);
                    /* WARNING: Could not recover jumptable at 0x00014038f663. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_49  @14038f670  [high:rtti-vtable]  (orig: FUN_14038f670)
undefined8 FUN_14038f670(longlong param_1)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x24);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if (iVar1 != 0) {
    plVar2 = (longlong *)
             (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                       ((longlong *)**(undefined8 **)(param_1 + 0x130),0x24);
    iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
    if (iVar1 != 0x3ed) {
      plVar2 = (longlong *)
               (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                         ((longlong *)**(undefined8 **)(param_1 + 0x130),0x26);
      iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
      if (iVar1 != 0) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMonster::vfunc_50  @14038f700  [high:rtti-vtable]  (orig: FUN_14038f700)
void FUN_14038f700(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x26);
                    /* WARNING: Could not recover jumptable at 0x00014038f723. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_60  @14038f730  [high:rtti-vtable]  (orig: FUN_14038f730)
void FUN_14038f730(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3a);
                    /* WARNING: Could not recover jumptable at 0x00014038f753. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_61  @14038f760  [high:rtti-vtable]  (orig: FUN_14038f760)
void FUN_14038f760(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3b);
                    /* WARNING: Could not recover jumptable at 0x00014038f783. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_62  @14038f790  [high:rtti-vtable]  (orig: FUN_14038f790)
void FUN_14038f790(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3c);
                    /* WARNING: Could not recover jumptable at 0x00014038f7b3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_63  @14038f7c0  [high:rtti-vtable]  (orig: FUN_14038f7c0)
void FUN_14038f7c0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3d);
                    /* WARNING: Could not recover jumptable at 0x00014038f7e3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_64  @14038f7f0  [high:rtti-vtable]  (orig: FUN_14038f7f0)
void FUN_14038f7f0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3e);
                    /* WARNING: Could not recover jumptable at 0x00014038f813. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_65  @14038f820  [high:rtti-vtable]  (orig: FUN_14038f820)
void FUN_14038f820(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x3f);
                    /* WARNING: Could not recover jumptable at 0x00014038f843. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_66  @14038f850  [high:rtti-vtable]  (orig: FUN_14038f850)
void FUN_14038f850(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x40);
                    /* WARNING: Could not recover jumptable at 0x00014038f873. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_67  @14038f880  [high:rtti-vtable]  (orig: FUN_14038f880)
void FUN_14038f880(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x41);
                    /* WARNING: Could not recover jumptable at 0x00014038f8a3. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x48))(plVar1);
  return;
}

// ==== CMonster::vfunc_10  @14038f8b0  [high:rtti-vtable]  (orig: FUN_14038f8b0)
void FUN_14038f8b0(longlong param_1)

{
  longlong *plVar1;
  
  plVar1 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x140) + 0x20))
                     ((longlong *)**(undefined8 **)(param_1 + 0x140),&DAT_140951730);
                    /* WARNING: Could not recover jumptable at 0x00014038f8d5. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(*plVar1 + 0x40))(plVar1);
  return;
}

// ==== CMonster::vfunc_79  @14038f8e0  [high:rtti-vtable]  (orig: FUN_14038f8e0)
uint FUN_14038f8e0(longlong param_1)

{
  uint uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x15);
  uVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar1 >> 0xc & 1;
}

// ==== CMonster::vfunc_81  @14038f910  [high:rtti-vtable]  (orig: FUN_14038f910)
uint FUN_14038f910(longlong param_1)

{
  uint uVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(*(longlong *)**(undefined8 **)(param_1 + 0x130) + 0x10))
                     ((longlong *)**(undefined8 **)(param_1 + 0x130),0x15);
  uVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  return uVar1 >> 0x13 & 1;
}

// ==== CMonster::vfunc_72  @14038f940  [high:rtti-vtable]  (orig: FUN_14038f940)
undefined8 FUN_14038f940(longlong *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  longlong *plVar4;
  
  cVar1 = (**(code **)(*param_1 + 0x288))();
  if (cVar1 != '\0') {
    return 1;
  }
  iVar2 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
  if (iVar2 - 0x61a81U < 99999) {
    plVar4 = (longlong *)
             (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x15);
    uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if ((uVar3 >> 3 & 1) == 0) {
      plVar4 = (longlong *)
               (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x15);
      uVar3 = (**(code **)(*plVar4 + 0x48))(plVar4);
      if ((uVar3 >> 4 & 1) == 0) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMonster::vfunc_73  @14038f9d0  [high:rtti-vtable]  (orig: FUN_14038f9d0)
ulonglong FUN_14038f9d0(longlong param_1)

{
  ulong uVar1;
  uint uVar2;
  ulonglong in_RAX;
  
  if (*(int *)(param_1 + 0x144) != 0) {
    uVar1 = tq::TimeGet(0);
    uVar2 = *(int *)(param_1 + 0x144) + *(int *)(param_1 + 0x140);
    in_RAX = (ulonglong)uVar2;
    if (uVar2 <= uVar1 / 1000) {
      return CONCAT71((uint7)(uint3)(uVar2 >> 8),1);
    }
  }
  return in_RAX & 0xffffffffffffff00;
}

// ==== CMonster::ctor_or_dtor  @14038fa20  [high:vtable-assign]  (orig: FUN_14038fa20)
void FUN_14038fa20(undefined8 *param_1)

{
  *param_1 = CMonster::vftable;
  param_1[2] = CMonster::vftable;
  param_1[3] = CMonster::vftable;
  FUN_14038c870(param_1 + 0xb);
  FUN_140097920(param_1 + 8);
  param_1[3] = IMapThing::vftable;
  param_1[2] = IRole::vftable;
  FUN_1402b55a0(param_1);
  return;
}

// ==== CMonster::vfunc_109  @1403906c0  [high:rtti-vtable]  (orig: FUN_1403906c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403906c0(longlong *param_1,int param_2)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  longlong lVar8;
  longlong lVar9;
  longlong *plVar10;
  ulonglong uVar11;
  uint uVar12;
  ulonglong uVar13;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  int local_4b8;
  int local_4b4;
  int local_4b0;
  int local_4ac;
  longlong local_4a8;
  longlong local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_498 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  uVar12 = param_2 >> 0x1f & 7;
  iVar3 = (param_2 + uVar12 & 7) - uVar12;
  *(int *)((longlong)param_1 + 0xd4) = iVar3;
  iVar6 = *(int *)(&DAT_14075d300 + (longlong)iVar3 * 4);
  iVar3 = *(int *)(&DAT_14075d320 + (longlong)iVar3 * 4);
  local_4b4 = iVar6;
  local_4ac = iVar3;
  lVar8 = (**(code **)(*param_1 + 0x160))();
  if (lVar8 == 0) {
    local_4c8 = 0x298;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
    iVar5 = (**(code **)(*param_1 + 0x48))(param_1);
    cVar1 = FUN_1402c3cc0(lVar8,iVar6 + iVar4,iVar3 + iVar5);
    uVar2 = 0;
    if (cVar1 != '\0') {
      plVar10 = (longlong *)0x0;
      if (param_1 != (longlong *)&DAT_00000010) {
        plVar10 = param_1;
      }
      FUN_1402c9550(lVar8,plVar10,iVar6 + *(int *)((longlong)param_1 + 0xcc),
                    iVar3 + (int)param_1[0x1a]);
      *(int *)((longlong)param_1 + 0xcc) = *(int *)((longlong)param_1 + 0xcc) + iVar6;
      *(int *)(param_1 + 0x1a) = (int)param_1[0x1a] + iVar3;
      if ((char)param_1[0x27] != '\x02') {
        iVar6 = (**(code **)(*param_1 + 0x40))(param_1);
        iVar6 = iVar6 / 0x12;
        local_4b0 = iVar6;
        local_4b8 = (**(code **)(*param_1 + 0x48))(param_1);
        local_4b8 = local_4b8 / 0x12;
        local_4a0 = 0;
        iVar3 = local_4b8;
        do {
          iVar4 = *(int *)(&DAT_14075d380 +
                          (local_4a0 + (longlong)*(int *)((longlong)param_1 + 0xd4) * 5) * 4);
          if (iVar4 == -1) break;
          iVar5 = iVar6 + *(int *)(&DAT_14075d340 + (longlong)iVar4 * 4);
          iVar4 = iVar3 + *(int *)(&DAT_14075d360 + (longlong)iVar4 * 4);
          if ((((-1 < iVar5) &&
               (iVar7 = (**(code **)(**(longlong **)(lVar8 + 0x60) + 0x28))(), iVar3 = local_4b8,
               iVar5 < (iVar7 + -1) / 0x12 + 1)) && (-1 < iVar4)) &&
             (iVar7 = FUN_14015f990(lVar8), iVar3 = local_4b8, iVar4 < iVar7)) {
            local_4a8 = 0;
            uVar13 = 0;
            lVar9 = FUN_14017eea0(lVar8,iVar5,iVar4);
            lVar9 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))();
            iVar3 = local_4b8;
            if (lVar9 != 0) {
              do {
                lVar9 = FUN_14017eea0(lVar8,iVar5,iVar4);
                plVar10 = (longlong *)
                          (**(code **)(**(longlong **)(lVar9 + 8) + 0x18))
                                    (*(longlong **)(lVar9 + 8),uVar13);
                if ((plVar10 != (longlong *)0x0) &&
                   (cVar1 = (**(code **)(*plVar10 + 0x38))(plVar10,0x1001,&local_4a8), cVar1 != '\0'
                   )) {
                  iVar6 = (**(code **)(*param_1 + 0x40))(param_1);
                  iVar3 = (**(code **)(*plVar10 + 0x20))(plVar10);
                  iVar7 = (iVar3 - iVar6) * local_4b4;
                  iVar6 = (**(code **)(*param_1 + 0x48))(param_1);
                  iVar3 = (**(code **)(*plVar10 + 0x28))(plVar10);
                  if (((local_4b4 != 0) && (iVar7 == 0x12)) ||
                     ((local_4ac != 0 && ((iVar3 - iVar6) * local_4ac == 0x12)))) {
                    FUN_14039ed70(local_488);
                    if (local_4a8 == 0) {
                      lVar9 = 0;
                    }
                    else {
                      lVar9 = local_4a8 + 0x10;
                    }
                    iVar6 = FUN_14039eef0(local_488,lVar9,0,0);
                    if (iVar6 != 0) {
                      (**(code **)(*param_1 + 0x350))(param_1,local_488);
                    }
                    plVar10 = (longlong *)0x0;
                    if (param_1 != (longlong *)&DAT_00000010) {
                      plVar10 = param_1;
                    }
                    iVar6 = FUN_14039eef0(local_488,plVar10,0,0);
                    if (iVar6 != 0) {
                      (**(code **)(*(longlong *)(local_4a8 + 0x10) + 0x350))
                                ((longlong *)(local_4a8 + 0x10),local_488);
                    }
                    FUN_14039edf0(local_488);
                  }
                }
                uVar13 = uVar13 + 1;
                lVar9 = FUN_14017eea0(lVar8,iVar5,iVar4);
                uVar11 = (**(code **)(**(longlong **)(lVar9 + 8) + 0x10))();
                iVar6 = local_4b0;
                iVar3 = local_4b8;
              } while (uVar13 < uVar11);
            }
          }
          local_4a0 = local_4a0 + 1;
        } while (local_4a0 < 5);
        FUN_140387d50(param_1 + -2);
      }
      uVar2 = 1;
    }
  }
  return uVar2;
}

// ==== CMonster::vfunc_111  @140390ac0  [high:rtti-vtable]  (orig: FUN_140390ac0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140390ac0(longlong *param_1,int param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  longlong *plVar5;
  longlong lVar6;
  longlong *plVar7;
  ulonglong uVar8;
  uint uVar9;
  uint uVar10;
  ulonglong uVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  undefined1 auStack_508 [32];
  char *local_4e8;
  undefined4 local_4e0;
  int local_4d8;
  int local_4d4;
  longlong local_4d0;
  int *local_4c8;
  int local_4c0;
  int *local_4b8;
  int local_4b0;
  longlong *local_4a8;
  undefined8 local_4a0;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_508;
  iVar4 = (int)param_1[0x1a];
  iVar13 = *(int *)((longlong)param_1 + 0xcc);
  if (iVar13 < param_2) {
    if (iVar4 < param_3) {
      iVar12 = 7;
    }
    else {
      iVar12 = (iVar4 <= param_3) + 5;
    }
  }
  else if (param_2 < iVar13) {
    if (iVar4 < param_3) {
      iVar12 = 1;
    }
    else {
      iVar12 = (param_3 < iVar4) + 2;
    }
  }
  else if (iVar4 < param_3) {
    iVar12 = 0;
  }
  else {
    if (iVar4 <= param_3) {
      return;
    }
    iVar12 = 4;
  }
  uVar9 = param_2 - iVar13 >> 0x1f;
  uVar10 = param_3 - iVar4 >> 0x1f;
  if (((int)((param_2 - iVar13 ^ uVar9) - uVar9) < 0x13) &&
     ((int)((param_3 - iVar4 ^ uVar10) - uVar10) < 0x13)) {
    plVar5 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
    if (plVar5 == (longlong *)0x0) {
      local_4e8 = (char *)CONCAT44(local_4e8._4_4_,0x30a);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      cVar1 = FUN_1402c3cc0(plVar5,param_2,param_3);
      if (cVar1 == '\0') {
        (**(code **)(*plVar5 + 8))(plVar5);
        local_4e0 = 0x30f;
        local_4e8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\ainpc.cpp";
        log_InlineLogERROR("CMonster::JumpPos map%u(%d, %d) at %s, %d");
      }
      else {
        local_4a8 = param_1 + -2;
        plVar7 = (longlong *)0x0;
        if (local_4a8 != (longlong *)0x0) {
          plVar7 = param_1;
        }
        FUN_1402c9550(plVar5,plVar7,param_2,param_3);
        local_4b0 = *(int *)((longlong)param_1 + 0xcc);
        local_4c0 = (int)param_1[0x1a];
        *(int *)((longlong)param_1 + 0xcc) = param_2;
        *(int *)(param_1 + 0x1a) = param_3;
        if ((char)param_1[0x27] != '\x02') {
          iVar4 = local_4b0 / 0x12;
          iVar13 = local_4c0 / 0x12;
          iVar2 = (**(code **)(*param_1 + 0x40))(param_1);
          iVar2 = iVar2 / 0x12;
          local_4d4 = iVar2;
          local_4d8 = (**(code **)(*param_1 + 0x48))(param_1);
          local_4d8 = local_4d8 / 0x12;
          local_4d0 = 0;
          if ((iVar4 == iVar2) && (iVar13 == local_4d8)) {
            local_4b8 = (int *)0x0;
            piVar14 = (int *)(&DAT_14075d380 + (longlong)iVar12 * 0x14);
            iVar4 = local_4d8;
            do {
              iVar13 = *piVar14;
              local_4c8 = piVar14;
              if (iVar13 == -1) break;
              iVar12 = iVar2 + *(int *)(&DAT_14075d340 + (longlong)iVar13 * 4);
              iVar13 = iVar4 + *(int *)(&DAT_14075d360 + (longlong)iVar13 * 4);
              if (((-1 < iVar12) &&
                  (iVar3 = FUN_14015f960(plVar5), iVar4 = local_4d8, iVar12 < iVar3)) &&
                 ((-1 < iVar13 && (iVar3 = FUN_14015f990(plVar5), iVar4 = local_4d8, iVar13 < iVar3)
                  ))) {
                iVar3 = 0;
                lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                lVar6 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
                iVar2 = local_4d4;
                iVar4 = local_4d8;
                if (lVar6 != 0) {
                  uVar11 = 0;
                  do {
                    lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                    plVar7 = (longlong *)
                             (**(code **)(**(longlong **)(lVar6 + 8) + 0x18))
                                       (*(longlong **)(lVar6 + 8),uVar11);
                    if ((plVar7 != (longlong *)0x0) &&
                       (cVar1 = (**(code **)(*plVar7 + 0x38))(plVar7,0x1001,&local_4d0),
                       cVar1 != '\0')) {
                      iVar4 = (**(code **)(*plVar7 + 0x20))(plVar7);
                      uVar9 = iVar4 - local_4b0 >> 0x1f;
                      if ((int)((iVar4 - local_4b0 ^ uVar9) - uVar9) < 0x13) {
LAB_140390e2a:
                        iVar4 = (**(code **)(*plVar7 + 0x28))(plVar7);
                        uVar9 = iVar4 - local_4c0 >> 0x1f;
                        if (0x12 < (int)((iVar4 - local_4c0 ^ uVar9) - uVar9)) {
                          iVar4 = (**(code **)(*param_1 + 0x48))(param_1);
                          iVar2 = (**(code **)(*plVar7 + 0x28))(plVar7);
                          uVar9 = iVar2 - iVar4 >> 0x1f;
                          if ((int)((iVar2 - iVar4 ^ uVar9) - uVar9) < 0x13) goto LAB_140390e69;
                        }
                      }
                      else {
                        iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
                        iVar2 = (**(code **)(*plVar7 + 0x20))(plVar7);
                        uVar9 = iVar2 - iVar4 >> 0x1f;
                        if (0x12 < (int)((iVar2 - iVar4 ^ uVar9) - uVar9)) goto LAB_140390e2a;
LAB_140390e69:
                        FUN_14039ed70(local_498);
                        if (local_4d0 == 0) {
                          lVar6 = 0;
                        }
                        else {
                          lVar6 = local_4d0 + 0x10;
                        }
                        iVar4 = FUN_14039eef0(local_498,lVar6,0,0);
                        if (iVar4 != 0) {
                          (**(code **)(*param_1 + 0x350))(param_1,local_498);
                        }
                        plVar7 = (longlong *)0x0;
                        if (param_1 != (longlong *)&DAT_00000010) {
                          plVar7 = param_1;
                        }
                        iVar4 = FUN_14039eef0(local_498,plVar7,0,0);
                        if (iVar4 != 0) {
                          (**(code **)(*(longlong *)(local_4d0 + 0x10) + 0x350))
                                    ((longlong *)(local_4d0 + 0x10),local_498);
                        }
                        FUN_14039edf0(local_498);
                      }
                    }
                    iVar3 = iVar3 + 1;
                    lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                    uVar11 = (ulonglong)iVar3;
                    uVar8 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
                    piVar14 = local_4c8;
                    iVar2 = local_4d4;
                    iVar4 = local_4d8;
                  } while (uVar11 < uVar8);
                }
              }
              local_4b8 = (int *)((longlong)local_4b8 + 1);
              piVar14 = piVar14 + 1;
              local_4c8 = piVar14;
            } while ((longlong)local_4b8 < 5);
          }
          else {
            local_4c8 = (int *)0x0;
            piVar14 = (int *)(&DAT_14075d470 + (longlong)iVar12 * 0x20);
            iVar4 = local_4d8;
            do {
              iVar13 = *piVar14;
              local_4b8 = piVar14;
              if (iVar13 == -1) break;
              iVar12 = iVar2 + *(int *)(&DAT_14075d420 + (longlong)iVar13 * 4);
              iVar13 = iVar4 + *(int *)(&DAT_14075d448 + (longlong)iVar13 * 4);
              if ((((-1 < iVar12) &&
                   (iVar3 = FUN_14015f960(plVar5), iVar4 = local_4d8, iVar12 < iVar3)) &&
                  (-1 < iVar13)) &&
                 (iVar3 = FUN_14015f990(plVar5), iVar4 = local_4d8, iVar13 < iVar3)) {
                iVar3 = 0;
                lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                lVar6 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
                iVar2 = local_4d4;
                iVar4 = local_4d8;
                if (lVar6 != 0) {
                  uVar11 = 0;
                  do {
                    lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                    plVar7 = (longlong *)
                             (**(code **)(**(longlong **)(lVar6 + 8) + 0x18))
                                       (*(longlong **)(lVar6 + 8),uVar11);
                    if ((plVar7 != (longlong *)0x0) &&
                       (cVar1 = (**(code **)(*plVar7 + 0x38))(plVar7,0x1001,&local_4d0),
                       cVar1 != '\0')) {
                      iVar4 = (**(code **)(*plVar7 + 0x20))(plVar7);
                      uVar9 = iVar4 - local_4b0 >> 0x1f;
                      if ((int)((iVar4 - local_4b0 ^ uVar9) - uVar9) < 0x13) {
LAB_1403910ba:
                        iVar4 = (**(code **)(*plVar7 + 0x28))(plVar7);
                        uVar9 = iVar4 - local_4c0 >> 0x1f;
                        if (0x12 < (int)((iVar4 - local_4c0 ^ uVar9) - uVar9)) {
                          iVar4 = (**(code **)(*param_1 + 0x48))(param_1);
                          iVar2 = (**(code **)(*plVar7 + 0x28))(plVar7);
                          uVar9 = iVar2 - iVar4 >> 0x1f;
                          if ((int)((iVar2 - iVar4 ^ uVar9) - uVar9) < 0x13) goto LAB_1403910f9;
                        }
                      }
                      else {
                        iVar4 = (**(code **)(*param_1 + 0x40))(param_1);
                        iVar2 = (**(code **)(*plVar7 + 0x20))(plVar7);
                        uVar9 = iVar2 - iVar4 >> 0x1f;
                        if (0x12 < (int)((iVar2 - iVar4 ^ uVar9) - uVar9)) goto LAB_1403910ba;
LAB_1403910f9:
                        FUN_14039ed70(local_498);
                        if (local_4d0 == 0) {
                          lVar6 = 0;
                        }
                        else {
                          lVar6 = local_4d0 + 0x10;
                        }
                        iVar4 = FUN_14039eef0(local_498,lVar6,0,0);
                        if (iVar4 != 0) {
                          (**(code **)(*param_1 + 0x350))(param_1,local_498);
                        }
                        plVar7 = (longlong *)0x0;
                        if (param_1 != (longlong *)&DAT_00000010) {
                          plVar7 = param_1;
                        }
                        iVar4 = FUN_14039eef0(local_498,plVar7,0,0);
                        if (iVar4 != 0) {
                          (**(code **)(*(longlong *)(local_4d0 + 0x10) + 0x350))
                                    ((longlong *)(local_4d0 + 0x10),local_498);
                        }
                        FUN_14039edf0(local_498);
                      }
                    }
                    iVar3 = iVar3 + 1;
                    lVar6 = FUN_14017eea0(plVar5,iVar12,iVar13);
                    uVar11 = (ulonglong)iVar3;
                    uVar8 = (**(code **)(**(longlong **)(lVar6 + 8) + 0x10))();
                    piVar14 = local_4b8;
                    iVar2 = local_4d4;
                    iVar4 = local_4d8;
                  } while (uVar11 < uVar8);
                }
              }
              local_4c8 = (int *)((longlong)local_4c8 + 1);
              piVar14 = piVar14 + 1;
              local_4b8 = piVar14;
            } while ((longlong)local_4c8 < 8);
          }
          FUN_140387d50(local_4a8);
        }
      }
    }
  }
  return;
}

// ==== CMonster::vfunc_89  @140391370  [high:rtti-vtable]  (orig: FUN_140391370)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140391370(longlong *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  longlong lVar5;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  int local_460 [6];
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_468 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_460[0] = *(int *)((longlong)param_1 + 0xdc);
  local_460[1] = (int)param_1[0x1c];
  local_460[2] = *(undefined4 *)((longlong)param_1 + 0xe4);
  local_460[3] = (int)param_1[0x1d];
  local_460[4] = *(undefined4 *)((longlong)param_1 + 0xec);
  local_460[5] = (int)param_1[0x1e];
  lVar5 = 5;
  switch(param_2) {
  case 0:
    *(undefined4 *)(param_1 + 0x1b) = param_2;
    lVar3 = 5;
    do {
      *(undefined4 *)((longlong)param_1 + lVar3 * 4 + 0xdc) = 0;
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x20;
    plVar4 = (longlong *)FUN_1401181a0();
    (**(code **)(*plVar4 + 0x18))(plVar4,(int)param_1[0xf]);
    break;
  case 1:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 1;
    break;
  case 2:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 2;
    break;
  default:
    local_478 = 0xd7c;
    log_InlineLogERROR(&DAT_1406d9c10);
    break;
  case 5:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x80;
    break;
  case 6:
  case 0x2c:
  case 0x74:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x100;
    break;
  case 7:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x200;
    break;
  case 8:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x800;
    break;
  case 9:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x1000;
    break;
  case 10:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x2000;
    break;
  case 0xe:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x80000;
    break;
  case 0xf:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x100000;
    break;
  case 0x10:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x200000;
    break;
  case 0x13:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x1000000;
    break;
  case 0x15:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x4000000;
    break;
  case 0x16:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x8000000;
    break;
  case 0x17:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 0x10000000;
    break;
  case 0x27:
    *(uint *)(param_1 + 0x1c) = *(uint *)(param_1 + 0x1c) | 0x4000;
    break;
  case 0x2a:
    *(uint *)(param_1 + 0x1c) = *(uint *)(param_1 + 0x1c) | 0x1000;
    break;
  case 0x2b:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) | 2;
    break;
  case 0x59:
    *(uint *)((longlong)param_1 + 0xe4) = *(uint *)((longlong)param_1 + 0xe4) | 0x20000000;
    break;
  case 0x7d:
    *(uint *)(param_1 + 0x1d) = *(uint *)(param_1 + 0x1d) | 0x40000000;
    break;
  case 0xa8:
    FUN_14038e4c0(param_1 + -2);
    break;
  case 0xffffffff:
    *(undefined4 *)(param_1 + 0x1b) = param_2;
    lVar3 = 5;
    do {
      *(undefined4 *)((longlong)param_1 + lVar3 * 4 + 0xdc) = 0;
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
  }
  if (param_3 != '\0') {
    plVar4 = param_1 + 0x1e;
    do {
      if (local_460[lVar5] != (int)*plVar4) {
        FUN_14039e680(local_448);
        uVar1 = (**(code **)(param_1[-2] + 8))();
        iVar2 = FUN_14039ec00(local_448,uVar1,0x19,(longlong)param_1 + 0xdc);
        if (iVar2 == 0) {
          local_478 = 0xd82;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*param_1 + 0x348))(param_1,local_448,1);
        }
        FUN_14039e6d0(local_448);
        return;
      }
      plVar4 = (longlong *)((longlong)plVar4 + -4);
      lVar5 = lVar5 + -1;
    } while (-1 < lVar5);
  }
  return;
}

// ==== CMonster::vfunc_90  @140391790  [high:rtti-vtable]  (orig: FUN_140391790)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140391790(longlong *param_1,undefined4 param_2,char param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined1 auStack_498 [32];
  undefined4 local_478;
  undefined8 local_468;
  int local_460 [6];
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_468 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_460[0] = *(int *)((longlong)param_1 + 0xdc);
  local_460[1] = (int)param_1[0x1c];
  local_460[2] = *(undefined4 *)((longlong)param_1 + 0xe4);
  local_460[3] = (int)param_1[0x1d];
  local_460[4] = *(undefined4 *)((longlong)param_1 + 0xec);
  local_460[5] = (int)param_1[0x1e];
  switch(param_2) {
  case 0:
    *(undefined4 *)(param_1 + 0x1b) = param_2;
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffffffdf;
    break;
  case 1:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfffffffe;
    break;
  case 2:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfffffffd;
    break;
  default:
    local_478 = 0xe02;
    log_InlineLogERROR(&DAT_1406d9c10);
    break;
  case 5:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffffff7f;
    break;
  case 6:
  case 0x2c:
  case 0x74:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfffffeff;
    break;
  case 7:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfffffdff;
    break;
  case 9:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffffefff;
    break;
  case 10:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffffdfff;
    break;
  case 0xe:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfff7ffff;
    break;
  case 0xf:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffefffff;
    break;
  case 0x10:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xffdfffff;
    break;
  case 0x13:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfeffffff;
    break;
  case 0x15:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfbffffff;
    break;
  case 0x16:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xf7ffffff;
    break;
  case 0x17:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xefffffff;
    break;
  case 0x27:
    *(uint *)(param_1 + 0x1c) = *(uint *)(param_1 + 0x1c) & 0xffffbfff;
    break;
  case 0x2a:
    *(uint *)(param_1 + 0x1c) = *(uint *)(param_1 + 0x1c) & 0xffffefff;
    break;
  case 0x2b:
    *(uint *)((longlong)param_1 + 0xdc) = *(uint *)((longlong)param_1 + 0xdc) & 0xfffffffd;
    break;
  case 0x59:
    *(uint *)((longlong)param_1 + 0xe4) = *(uint *)((longlong)param_1 + 0xe4) & 0xdfffffff;
    break;
  case 0x7d:
    *(uint *)(param_1 + 0x1d) = *(uint *)(param_1 + 0x1d) & 0xbfffffff;
    break;
  case 0xa8:
    *(uint *)(param_1 + 0x1e) = *(uint *)(param_1 + 0x1e) & 0xfffff0ff;
    break;
  case 0xffffffff:
    local_478 = 0xd8f;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  if (param_3 != '\0') {
    lVar3 = 5;
    plVar4 = param_1 + 0x1e;
    do {
      if (local_460[lVar3] != (int)*plVar4) {
        FUN_14039e680(local_448);
        uVar1 = (**(code **)(param_1[-2] + 8))();
        iVar2 = FUN_14039ec00(local_448,uVar1,0x19,(longlong)param_1 + 0xdc);
        if (iVar2 == 0) {
          local_478 = 0xe08;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(*param_1 + 0x348))(param_1,local_448,1);
        }
        FUN_14039e6d0(local_448);
        return;
      }
      plVar4 = (longlong *)((longlong)plVar4 + -4);
      lVar3 = lVar3 + -1;
    } while (-1 < lVar3);
  }
  return;
}

// ==== CMonster::vfunc_1  @140391b80  [high:rtti-vtable]  (orig: FUN_140391b80)
void FUN_140391b80(longlong param_1)

{
  FUN_14038e980(param_1 + -8);
  return;
}

// ==== CMonster::vfunc_0  @140391c00  [high:rtti-vtable]  (orig: FUN_140391c00)
undefined8 FUN_140391c00(undefined8 param_1,uint param_2)

{
  FUN_14038fa20();
  if ((param_2 & 1) != 0) {
    FUN_140388f50(param_1);
  }
  return param_1;
}

// ==== CMonster::vfunc_108  @140392340  [high:rtti-vtable]  (orig: FUN_140392340)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140392340(longlong *param_1)

{
  undefined8 *puVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  undefined8 *puVar12;
  undefined8 *puVar13;
  longlong lVar14;
  bool bVar15;
  undefined1 auStack_588 [32];
  ulonglong local_568;
  undefined4 local_560;
  uint local_558;
  undefined4 local_550;
  undefined4 local_548;
  undefined1 local_540;
  longlong local_538 [2];
  undefined8 local_528;
  undefined8 uStack_520;
  longlong *local_518;
  undefined8 uStack_510;
  undefined8 *local_508;
  longlong *local_4f8 [6];
  undefined8 *local_4c8;
  undefined8 local_4c0;
  longlong *local_4b8 [2];
  longlong *local_4a8;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_588;
  cVar2 = (**(code **)(*param_1 + 0x220))();
  if ((cVar2 == '\0') && ((int)param_1[0x29] == 0)) {
    uVar9 = FUN_140008520((int)param_1[0x2b]);
    cVar2 = FUN_14008abf0(uVar9);
    iVar4 = 10;
    if (cVar2 != '\0') {
      iVar4 = 6;
    }
    iVar3 = FUN_14016b120(param_1 + 0x28);
    if ((iVar3 < iVar4 >> 1) && ((int)param_1[0x1b] != 8)) {
      (**(code **)(*param_1 + 0x2c8))(param_1,8,1);
    }
  }
  if (*(int *)((longlong)param_1 + 0x144) == 0) {
    plVar11 = param_1 + -2;
    cVar2 = FUN_140388010(plVar11,1);
    if (cVar2 == '\0') {
      cVar2 = (**(code **)(*param_1 + 0x220))(param_1);
      if (cVar2 != '\0') {
        plVar10 = (longlong *)
                  (**(code **)(**(longlong **)param_1[0x26] + 0x10))
                            (*(longlong **)param_1[0x26],0x24);
        iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
        if (((iVar4 == 0x3ed) && ((int)param_1[0x2a] != 0)) &&
           (cVar2 = FUN_1400222e0((longlong)param_1 + 0x14c,10), cVar2 != '\0')) {
          uVar5 = (**(code **)(*param_1 + 0x80))(param_1);
          uVar6 = (**(code **)(*param_1 + 0x78))(param_1);
          if (uVar6 < uVar5) {
            plVar10 = (longlong *)
                      (**(code **)(**(longlong **)param_1[0x26] + 0x10))
                                (*(longlong **)param_1[0x26],0x26);
            iVar4 = (**(code **)(*plVar10 + 0x48))(plVar10);
            iVar3 = (**(code **)(*param_1 + 0x80))(param_1);
            uVar6 = (uint)(iVar3 * iVar4) / 100;
            uVar5 = (**(code **)(*param_1 + 0x80))(param_1);
            iVar4 = (**(code **)(*param_1 + 0x80))(param_1);
            iVar3 = (**(code **)(*param_1 + 0x78))(param_1);
            local_558 = iVar4 - iVar3;
            if ((int)local_558 < 0) {
              local_558 = 0;
            }
            else if ((int)uVar5 < (int)local_558) {
              local_558 = uVar5;
            }
            if ((int)uVar6 <= (int)local_558) {
              local_558 = uVar6;
            }
            local_568 = 0;
            (**(code **)(*param_1 + 0x2e0))(param_1,0,(longlong)(int)local_558,1);
            FUN_140386780(local_468);
            uVar7 = (**(code **)(*plVar11 + 8))(plVar11);
            uVar8 = (**(code **)(*plVar11 + 8))(plVar11);
            local_540 = 0;
            local_548 = 0;
            local_550 = 0;
            local_568 = local_568 & 0xffffffffffffff00;
            local_560 = uVar7;
            iVar4 = FUN_1403868f0(local_468,uVar8,0x3ed,0);
            if (iVar4 == 0) {
              local_568 = CONCAT44(local_568._4_4_,0x1e0);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              (**(code **)(*param_1 + 0x348))(param_1,local_468,0);
            }
            *(int *)(param_1 + 0x25) = (int)param_1[0x25] + 1000;
            FUN_1403867d0(local_468);
          }
          else {
            *(undefined4 *)(param_1 + 0x2a) = 0;
            *(undefined4 *)((longlong)param_1 + 0x14c) = 0;
          }
        }
      }
      cVar2 = FUN_1403887c0(plVar11);
      if (((cVar2 != '\0') && (param_1[0x23] != 0)) &&
         (cVar2 = FUN_14016b190(param_1 + 5,500), cVar2 != '\0')) {
        uVar9 = FUN_140008520((int)param_1[0x2b]);
        plVar11 = (longlong *)FUN_1400875f0(uVar9);
        plVar11 = (longlong *)
                  (**(code **)(*plVar11 + 0x20))(plVar11,*(undefined4 *)(param_1[0x23] + 8));
        local_538[0] = 0;
        if ((plVar11 != (longlong *)0x0) &&
           (cVar2 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,local_538), cVar2 != '\0')) {
          FUN_1401af3c0(local_4f8);
          FUN_1401aa6b0(local_538[0],3,local_4f8);
          plVar11 = local_4f8[0];
          puVar12 = (undefined8 *)*local_4c8;
          local_4a8 = local_4f8[0];
LAB_1403926e0:
          puVar13 = local_4c8;
          local_4b8[0] = local_4f8[0];
          if ((plVar11 == (longlong *)0x0) || (plVar11 != local_4f8[0])) {
            _invalid_parameter_noinfo();
          }
          if (puVar12 != puVar13) {
            if (plVar11 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar14 = 0;
            }
            else {
              lVar14 = *plVar11;
            }
            if (puVar12 == *(undefined8 **)(lVar14 + 0x30)) {
              _invalid_parameter_noinfo();
            }
            plVar10 = (longlong *)puVar12[3];
            if ((plVar10 != (longlong *)0x0) && (cVar2 = FUN_1403885c0(plVar10), cVar2 != '\0')) {
              iVar4 = (**(code **)(*(longlong *)(local_538[0] + 0x10) + 0x40))();
              iVar3 = (**(code **)(plVar10[2] + 0x40))(plVar10 + 2);
              uVar5 = iVar4 - iVar3 >> 0x1f;
              if ((int)((iVar4 - iVar3 ^ uVar5) - uVar5) < 0xc) {
                iVar4 = (**(code **)(*(longlong *)(local_538[0] + 0x10) + 0x48))();
                iVar3 = (**(code **)(plVar10[2] + 0x48))(plVar10 + 2);
                uVar5 = iVar4 - iVar3 >> 0x1f;
                if ((int)((iVar4 - iVar3 ^ uVar5) - uVar5) < 0xc) {
                  uVar7 = (**(code **)(*plVar10 + 8))(plVar10);
                  FUN_1403e8cd0(param_1[0x23],uVar7);
                }
              }
            }
            if (plVar11 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            if (*(char *)((longlong)puVar12 + 0x21) == '\0') {
              puVar13 = puVar12;
              puVar1 = (undefined8 *)puVar12[2];
              if (*(char *)((longlong)puVar12[2] + 0x21) == '\0') {
                do {
                  puVar12 = puVar1;
                  puVar1 = (undefined8 *)*puVar12;
                  local_508 = puVar12;
                } while (*(char *)((longlong)*puVar12 + 0x21) == '\0');
              }
              else {
                do {
                  puVar12 = (undefined8 *)puVar13[1];
                  if (*(char *)((longlong)puVar12 + 0x21) != '\0') break;
                  bVar15 = puVar13 == (undefined8 *)puVar12[2];
                  puVar13 = puVar12;
                } while (bVar15);
              }
            }
            else {
              _invalid_parameter_noinfo();
            }
            goto LAB_1403926e0;
          }
          uStack_520 = local_4c8;
          puVar12 = uStack_520;
          local_528 = local_4f8[0];
          plVar11 = local_528;
          uVar9 = *local_4c8;
          local_518 = local_4f8[0];
          local_528._0_4_ = SUB84(local_4f8[0],0);
          local_528._4_4_ = (undefined4)((ulonglong)local_4f8[0] >> 0x20);
          uStack_520._0_4_ = SUB84(local_4c8,0);
          uStack_520._4_4_ = (undefined4)((ulonglong)local_4c8 >> 0x20);
          local_478 = (undefined4)local_528;
          uStack_474 = local_528._4_4_;
          uStack_470 = (undefined4)uStack_520;
          uStack_46c = uStack_520._4_4_;
          uStack_510._0_4_ = (undefined4)uVar9;
          uStack_510._4_4_ = (undefined4)((ulonglong)uVar9 >> 0x20);
          local_498 = (undefined4)local_528;
          uStack_494 = local_528._4_4_;
          uStack_490 = (undefined4)uStack_510;
          uStack_48c = uStack_510._4_4_;
          local_528 = plVar11;
          uStack_520 = puVar12;
          uStack_510 = uVar9;
          FUN_140197890(local_4f8,local_4b8,&local_498,&local_478);
          operator_delete(local_4c8);
          local_4c8 = (undefined8 *)0x0;
          local_4c0 = 0;
          operator_delete(local_4f8[0]);
        }
        FUN_1404d93a0(param_1[4],*(undefined4 *)(param_1[0x23] + 8));
      }
      cVar2 = FUN_1403887c0(param_1 + -2);
      if (((cVar2 == '\0') && (param_1[0x23] != 0)) && (*(int *)(param_1[0x23] + 8) != 0)) {
        iVar4 = (**(code **)(*param_1 + 0xe8))(param_1);
        cVar2 = FUN_14016b190(param_1 + 0x24,iVar4 + (int)param_1[0x25]);
        if (cVar2 != '\0') {
          FUN_1403ec920(param_1[0x23],0);
          *(undefined4 *)(param_1 + 0x25) = 0;
        }
      }
    }
    plVar11 = param_1 + -2;
    iVar4 = (**(code **)(*plVar11 + 8))(plVar11);
    if (((iVar4 - 0xaae61U < 99999) && (param_1[6] == 0)) &&
       (*(int *)((longlong)param_1 + 0x144) == 0)) {
      log_InlineLogERROR("Call pet don\'t find owner! del self.");
      FUN_14038e270(plVar11,1);
    }
  }
  return;
}

// ==== CMonster::helper_1403929b0  @1403929b0  [medium:callgraph-r0]  (orig: FUN_1403929b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403929b0(longlong *param_1)

{
  uint *puVar1;
  uint *puVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  uint uVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong lVar15;
  longlong *plVar16;
  undefined8 uVar17;
  longlong lVar18;
  ulonglong uVar19;
  longlong *plVar20;
  longlong lVar21;
  int *piVar22;
  uint *puVar23;
  undefined8 *puVar24;
  uint *puVar25;
  int iVar26;
  ulonglong uVar27;
  longlong *plVar28;
  ulonglong uVar29;
  undefined1 auStack_6c8 [32];
  ulonglong local_6a8;
  uint local_6a0;
  uint local_698;
  uint *local_690;
  uint local_688;
  undefined4 local_680;
  undefined1 local_678;
  longlong *local_668;
  uint local_660;
  uint local_65c;
  undefined8 local_658;
  longlong *local_650 [3];
  uint *local_638;
  uint *local_630;
  longlong local_628;
  int local_620 [2];
  undefined8 local_618;
  uint local_610;
  longlong *local_608;
  longlong *local_600;
  undefined8 local_5f8;
  undefined8 uStack_5f0;
  longlong *local_5e8 [3];
  uint *local_5d0;
  uint *local_5c8;
  longlong local_5c0;
  longlong *local_5b8 [3];
  uint *local_5a0;
  uint *local_598;
  longlong local_590;
  undefined8 local_588;
  undefined8 uStack_580;
  longlong *local_578 [3];
  uint *local_560;
  uint *local_558;
  longlong local_550;
  undefined4 local_548;
  undefined4 uStack_544;
  undefined4 uStack_540;
  undefined4 uStack_53c;
  undefined8 local_538;
  undefined8 uStack_530;
  longlong *local_528 [3];
  void *local_510;
  longlong local_508;
  undefined8 local_500;
  longlong *local_4f8 [6];
  uint *local_4c8;
  undefined8 local_4c0;
  undefined4 local_4b8;
  undefined4 uStack_4b4;
  undefined4 uStack_4b0;
  undefined4 uStack_4ac;
  undefined8 local_4a8;
  undefined8 uStack_4a0;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  undefined4 local_478;
  undefined4 uStack_474;
  undefined4 uStack_470;
  undefined4 uStack_46c;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_6c8;
  local_608 = param_1;
  plVar13 = (longlong *)
            (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0x24);
  iVar4 = (**(code **)(*plVar13 + 0x48))(plVar13);
  if (iVar4 != 0) {
    plVar13 = (longlong *)
              (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0x26);
    iVar4 = (**(code **)(*plVar13 + 0x48))(plVar13);
    if (iVar4 == 0) {
      if (param_1[0xe] == 0) {
        local_6a8 = CONCAT44(local_6a8._4_4_,0x565);
        log_InlineLogERROR(&DAT_1406d9c10);
        return;
      }
      plVar13 = (longlong *)
                (**(code **)(*(longlong *)param_1[0xe] + 0x10))((longlong *)param_1[0xe],10);
      (**(code **)(*plVar13 + 0x48))(plVar13);
      plVar13 = (longlong *)
                (**(code **)(*(longlong *)param_1[0xe] + 0x10))((longlong *)param_1[0xe],0xe);
      iVar5 = (**(code **)(*plVar13 + 0x48))(plVar13);
      plVar13 = param_1 + 2;
      local_600 = plVar13;
      uVar6 = (**(code **)(*plVar13 + 0x40))(plVar13);
      local_658 = (longlong *)CONCAT44(local_658._4_4_,uVar6);
      uVar7 = (**(code **)(*plVar13 + 0x48))(plVar13);
      local_658 = (longlong *)CONCAT44(uVar7,(uint)local_658);
      iVar4 = iVar5 * 2 + 1;
      local_668 = operator_new(8);
      plVar16 = (longlong *)0x0;
      local_528[0] = plVar16;
      if (local_668 != (longlong *)0x0) {
        *local_668 = (longlong)local_528;
        local_528[0] = local_668;
      }
      local_510 = (void *)0x0;
      local_508 = 0;
      local_500 = 0;
      local_618 = local_668;
      uVar14 = (**(code **)(*plVar13 + 0x160))(plVar13);
      plVar13 = local_658;
      local_6a8 = CONCAT44(local_6a8._4_4_,0x1043);
      FUN_1402d0e40(uVar14,local_528,local_658,iVar5);
      local_668 = operator_new(8);
      local_650[0] = plVar16;
      if (local_668 != (longlong *)0x0) {
        *local_668 = (longlong)local_650;
        local_650[0] = local_668;
      }
      local_638 = (uint *)0x0;
      local_630 = (uint *)0x0;
      local_628 = 0;
      local_618 = local_668;
      local_668 = operator_new(8);
      local_5e8[0] = plVar16;
      if (local_668 != (longlong *)0x0) {
        *local_668 = (longlong)local_5e8;
        local_5e8[0] = local_668;
      }
      local_5d0 = (uint *)0x0;
      local_5c8 = (uint *)0x0;
      local_5c0 = 0;
      local_618 = local_668;
      local_668 = operator_new(8);
      local_578[0] = plVar16;
      if (local_668 != (longlong *)0x0) {
        *local_668 = (longlong)local_578;
        local_578[0] = local_668;
      }
      local_560 = (uint *)0x0;
      local_558 = (uint *)0x0;
      local_550 = 0;
      local_618 = local_668;
      local_668 = operator_new(8);
      local_5b8[0] = plVar16;
      if (local_668 != (longlong *)0x0) {
        *local_668 = (longlong)local_5b8;
        local_5b8[0] = local_668;
      }
      local_5a0 = (uint *)0x0;
      local_598 = (uint *)0x0;
      local_590 = 0;
      if (-1 < (int)(uVar6 - iVar5)) {
        plVar16 = (longlong *)(ulonglong)(uVar6 - iVar5);
      }
      local_610 = (uint)plVar16;
      local_620[0] = uVar6 + iVar5;
      local_618 = local_668;
      if ((int)local_610 <= local_620[0]) {
        do {
          lVar15 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
          iVar8 = (**(code **)(**(longlong **)(lVar15 + 0x60) + 0x28))();
          iVar26 = (int)plVar16;
          if (iVar8 <= iVar26) break;
          iVar8 = 0;
          if (-1 < (int)(uVar7 - iVar5)) {
            iVar8 = uVar7 - iVar5;
          }
          if (iVar8 <= (int)(uVar7 + iVar5)) {
            do {
              iVar26 = (int)plVar16;
              lVar15 = (**(code **)(param_1[2] + 0x160))(param_1 + 2);
              iVar9 = (**(code **)(**(longlong **)(lVar15 + 0x60) + 0x20))();
              if (iVar9 <= iVar8) break;
              local_618 = (longlong *)CONCAT44(iVar8,iVar26);
              cVar3 = FUN_1401671e0(local_618,plVar13,iVar5);
              if (cVar3 != '\0') {
                iVar26 = (((iVar8 - uVar7) + iVar5) * iVar4 - (uint)local_658) + iVar26 + iVar5;
                if ((iVar26 < 0) || ((int)(local_508 - (longlong)local_510 >> 3) <= iVar26)) {
                  local_6a8 = CONCAT44(local_6a8._4_4_,0x582);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                uVar27 = (ulonglong)iVar26;
                if ((ulonglong)(local_508 - (longlong)local_510 >> 3) <= uVar27) {
                  _invalid_parameter_noinfo();
                }
                if (*(longlong *)((longlong)local_510 + uVar27 * 8) != 0) {
                  local_668 = (longlong *)0x0;
                  if ((ulonglong)(local_508 - (longlong)local_510 >> 3) <= uVar27) {
                    _invalid_parameter_noinfo();
                  }
                  plVar20 = *(longlong **)((longlong)local_510 + uVar27 * 8);
                  cVar3 = (**(code **)(*plVar20 + 0x40))(plVar20,&local_668);
                  if (((cVar3 != '\0') &&
                      (cVar3 = (**(code **)(*local_668 + 0x220))(), cVar3 != '\0')) &&
                     (cVar3 = FUN_14038e6a0(param_1,local_668), cVar3 == '\0')) {
                    lVar15 = *local_668;
                    uVar10 = FUN_140388e30(param_1);
                    uVar11 = (**(code **)(*param_1 + 8))(param_1);
                    cVar3 = (**(code **)(lVar15 + 0x398))(local_668,uVar11,uVar10,0);
                    if (cVar3 == '\0') {
                      uVar27 = 0;
                      uVar6 = 0;
                      local_65c = 0;
                      local_660 = 0;
                      plVar16 = (longlong *)
                                (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                          ((longlong *)param_1[0xe],0x1e);
                      iVar4 = (**(code **)(*plVar16 + 0x48))(plVar16);
                      if (iVar4 == 0) {
                        plVar16 = (longlong *)
                                  (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                            ((longlong *)param_1[0xe],10);
                        (**(code **)(*plVar16 + 0x48))(plVar16);
                        uVar14 = FUN_1401594f0(param_1);
                        uVar17 = FUN_140008520((int)param_1[0x2d]);
                        uVar17 = FUN_1400877e0(uVar17);
                        local_6a8 = 0;
                        uVar6 = FUN_1402f3100(uVar17,uVar14,local_668);
                        local_65c = uVar6;
                      }
                      plVar16 = (longlong *)
                                (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                          ((longlong *)param_1[0xe],0x1e);
                      iVar4 = (**(code **)(*plVar16 + 0x48))(plVar16);
                      if (iVar4 == 1) {
                        plVar16 = (longlong *)
                                  (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                            ((longlong *)param_1[0xe],10);
                        uVar10 = (**(code **)(*plVar16 + 0x48))(plVar16);
                        uVar14 = FUN_1401594f0(param_1);
                        local_688 = local_688 & 0xffffff00;
                        local_690 = &local_660;
                        local_698 = local_698 & 0xffffff00;
                        local_6a0 = 0;
                        local_6a8 = CONCAT44(local_6a8._4_4_,uVar10);
                        iVar4 = FUN_1403ec0a0(uVar14,local_668,0);
                        uVar6 = uVar6 + iVar4;
                        local_65c = uVar6;
                      }
                      puVar23 = local_630;
                      if (local_638 != (uint *)0x0) {
                        uVar27 = local_628 - (longlong)local_638 >> 3;
                      }
                      if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) < uVar27) {
                        *(longlong **)local_630 = local_668;
                        local_630 = local_630 + 2;
                      }
                      else {
                        if (local_630 < local_638) {
                          _invalid_parameter_noinfo();
                        }
                        puVar1 = local_638;
                        plVar16 = local_650[0];
                        local_4a8 = local_650[0];
                        uStack_4a0 = puVar23;
                        if (((longlong)local_630 - (longlong)local_638 & 0xfffffffffffffff8U) == 0)
                        {
                          lVar15 = 0;
                        }
                        else {
                          if (local_630 < local_638) {
                            _invalid_parameter_noinfo();
                          }
                          if ((plVar16 == (longlong *)0x0) || (plVar16 != local_650[0])) {
                            _invalid_parameter_noinfo();
                          }
                          lVar15 = (longlong)puVar23 - (longlong)puVar1 >> 3;
                        }
                        local_478 = (undefined4)local_4a8;
                        uStack_474 = local_4a8._4_4_;
                        uStack_470 = (undefined4)uStack_4a0;
                        uStack_46c = uStack_4a0._4_4_;
                        FUN_1401a0cb0(local_650,&local_478,1);
                        puVar23 = local_638;
                        if (local_630 < local_638) {
                          _invalid_parameter_noinfo();
                        }
                        plVar16 = local_650[0];
                        if (local_650[0] == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar21 = 0;
                        }
                        else {
                          lVar21 = *local_650[0];
                        }
                        if (puVar23 + lVar15 * 2 <= *(uint **)(lVar21 + 0x20)) {
                          if (plVar16 == (longlong *)0x0) {
                            lVar21 = 0;
                          }
                          else {
                            lVar21 = *plVar16;
                          }
                          if (*(uint **)(lVar21 + 0x18) <= puVar23 + lVar15 * 2) goto LAB_1403930b2;
                        }
                        _invalid_parameter_noinfo();
                      }
LAB_1403930b2:
                      puVar23 = local_5c8;
                      uVar27 = 0;
                      if (local_5d0 != (uint *)0x0) {
                        uVar27 = local_5c0 - (longlong)local_5d0 >> 2;
                      }
                      if ((ulonglong)((longlong)local_5c8 - (longlong)local_5d0 >> 2) < uVar27) {
                        *local_5c8 = uVar6;
                        local_5c8 = local_5c8 + 1;
                      }
                      else {
                        if (local_5c8 < local_5d0) {
                          _invalid_parameter_noinfo();
                        }
                        puVar1 = local_5d0;
                        plVar16 = local_5e8[0];
                        local_538 = local_5e8[0];
                        uStack_530 = puVar23;
                        if (((longlong)local_5c8 - (longlong)local_5d0 & 0xfffffffffffffffcU) == 0)
                        {
                          lVar15 = 0;
                        }
                        else {
                          if (local_5c8 < local_5d0) {
                            _invalid_parameter_noinfo();
                          }
                          if ((plVar16 == (longlong *)0x0) || (plVar16 != local_5e8[0])) {
                            _invalid_parameter_noinfo();
                          }
                          lVar15 = (longlong)puVar23 - (longlong)puVar1 >> 2;
                        }
                        lVar21 = 0;
                        local_498 = (undefined4)local_538;
                        uStack_494 = local_538._4_4_;
                        uStack_490 = (undefined4)uStack_530;
                        uStack_48c = uStack_530._4_4_;
                        FUN_14000df40(local_5e8,&local_498,1);
                        puVar23 = local_5d0;
                        if (local_5c8 < local_5d0) {
                          _invalid_parameter_noinfo();
                        }
                        plVar16 = local_5e8[0];
                        if (local_5e8[0] == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar18 = lVar21;
                        }
                        else {
                          lVar18 = *local_5e8[0];
                        }
                        if (puVar23 + lVar15 <= *(uint **)(lVar18 + 0x20)) {
                          if (plVar16 != (longlong *)0x0) {
                            lVar21 = *plVar16;
                          }
                          if (*(uint **)(lVar21 + 0x18) <= puVar23 + lVar15) goto LAB_140393202;
                        }
                        _invalid_parameter_noinfo();
                      }
LAB_140393202:
                      uVar6 = 0;
                      local_65c = 0;
                      plVar16 = (longlong *)
                                (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                          ((longlong *)param_1[0xe],0x26);
                      uVar10 = (**(code **)(*plVar16 + 0x48))(plVar16);
                      plVar16 = (longlong *)
                                (**(code **)(*(longlong *)param_1[0xe] + 0x10))
                                          ((longlong *)param_1[0xe],0x27);
                      uVar11 = (**(code **)(*plVar16 + 0x48))(plVar16);
                      uVar14 = FUN_140008520((int)param_1[0x2d]);
                      uVar14 = FUN_1400877e0(uVar14);
                      cVar3 = FUN_1402ec490(uVar14);
                      if (cVar3 != '\0') {
                        uVar14 = FUN_1401594f0(param_1);
                        uVar17 = FUN_140008520((int)param_1[0x2d]);
                        uVar17 = FUN_1400877e0(uVar17);
                        local_6a8 = CONCAT44(local_6a8._4_4_,uVar11);
                        uVar6 = FUN_1402ec380(uVar17,uVar14,local_668);
                        local_65c = uVar6;
                        uVar14 = FUN_140008520((int)param_1[0x2d]);
                        uVar14 = FUN_1400877e0(uVar14);
                        FUN_1402ecf10(uVar14,&local_660,uVar10);
                      }
                      puVar23 = local_558;
                      if (local_560 == (uint *)0x0) {
                        uVar27 = 0;
                      }
                      else {
                        uVar27 = local_550 - (longlong)local_560 >> 2;
                      }
                      if ((ulonglong)((longlong)local_558 - (longlong)local_560 >> 2) < uVar27) {
                        *local_558 = local_660;
                        local_558 = local_558 + 1;
                      }
                      else {
                        if (local_558 < local_560) {
                          _invalid_parameter_noinfo();
                        }
                        puVar1 = local_560;
                        plVar16 = local_578[0];
                        local_588 = local_578[0];
                        uStack_580 = puVar23;
                        if (((longlong)local_558 - (longlong)local_560 & 0xfffffffffffffffcU) == 0)
                        {
                          lVar15 = 0;
                        }
                        else {
                          if (local_558 < local_560) {
                            _invalid_parameter_noinfo();
                          }
                          if ((plVar16 == (longlong *)0x0) || (plVar16 != local_578[0])) {
                            _invalid_parameter_noinfo();
                          }
                          lVar15 = (longlong)puVar23 - (longlong)puVar1 >> 2;
                        }
                        local_4b8 = (undefined4)local_588;
                        uStack_4b4 = local_588._4_4_;
                        uStack_4b0 = (undefined4)uStack_580;
                        uStack_4ac = uStack_580._4_4_;
                        FUN_140274790(local_578,&local_4b8,1);
                        puVar23 = local_560;
                        if (local_558 < local_560) {
                          _invalid_parameter_noinfo();
                        }
                        plVar16 = local_578[0];
                        if (local_578[0] == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar21 = 0;
                        }
                        else {
                          lVar21 = *local_578[0];
                        }
                        lVar18 = 0;
                        if (puVar23 + lVar15 <= *(uint **)(lVar21 + 0x20)) {
                          if (plVar16 != (longlong *)0x0) {
                            lVar18 = *plVar16;
                          }
                          if (*(uint **)(lVar18 + 0x18) <= puVar23 + lVar15) goto LAB_14039340c;
                        }
                        _invalid_parameter_noinfo();
                      }
LAB_14039340c:
                      puVar23 = local_598;
                      if (local_5a0 == (uint *)0x0) {
                        uVar27 = 0;
                      }
                      else {
                        uVar27 = local_590 - (longlong)local_5a0 >> 2;
                      }
                      if ((ulonglong)((longlong)local_598 - (longlong)local_5a0 >> 2) < uVar27) {
                        *local_598 = uVar6;
                        local_598 = local_598 + 1;
                        plVar16 = (longlong *)(ulonglong)local_610;
                        iVar4 = iVar5 * 2 + 1;
                        uVar7 = local_658._4_4_;
                      }
                      else {
                        if (local_598 < local_5a0) {
                          _invalid_parameter_noinfo();
                        }
                        puVar1 = local_5a0;
                        plVar16 = local_5b8[0];
                        local_5f8 = local_5b8[0];
                        uStack_5f0 = puVar23;
                        if (((longlong)local_598 - (longlong)local_5a0 & 0xfffffffffffffffcU) == 0)
                        {
                          lVar15 = 0;
                        }
                        else {
                          if (local_598 < local_5a0) {
                            _invalid_parameter_noinfo();
                          }
                          if ((plVar16 == (longlong *)0x0) || (plVar16 != local_5b8[0])) {
                            _invalid_parameter_noinfo();
                          }
                          lVar15 = (longlong)puVar23 - (longlong)puVar1 >> 2;
                        }
                        lVar21 = 0;
                        local_548 = (undefined4)local_5f8;
                        uStack_544 = local_5f8._4_4_;
                        uStack_540 = (undefined4)uStack_5f0;
                        uStack_53c = uStack_5f0._4_4_;
                        FUN_14000df40(local_5b8,&local_548,1);
                        puVar23 = local_5a0;
                        if (local_598 < local_5a0) {
                          _invalid_parameter_noinfo();
                        }
                        plVar16 = local_5b8[0];
                        if (local_5b8[0] == (longlong *)0x0) {
                          _invalid_parameter_noinfo();
                          lVar18 = lVar21;
                        }
                        else {
                          lVar18 = *local_5b8[0];
                        }
                        if (*(uint **)(lVar18 + 0x20) < puVar23 + lVar15) {
LAB_140393569:
                          _invalid_parameter_noinfo();
                        }
                        else {
                          if (plVar16 != (longlong *)0x0) {
                            lVar21 = *plVar16;
                          }
                          if (puVar23 + lVar15 < *(uint **)(lVar21 + 0x18)) goto LAB_140393569;
                        }
                        plVar16 = (longlong *)(ulonglong)local_610;
                        iVar4 = iVar5 * 2 + 1;
                        uVar7 = local_658._4_4_;
                      }
                    }
                    else {
                      plVar16 = (longlong *)(ulonglong)local_610;
                    }
                  }
                }
              }
              iVar26 = (int)plVar16;
              iVar8 = iVar8 + 1;
            } while (iVar8 <= (int)(uVar7 + iVar5));
          }
          local_610 = iVar26 + 1;
          plVar16 = (longlong *)(ulonglong)local_610;
        } while ((int)local_610 <= local_620[0]);
        uVar6 = (uint)local_658;
      }
      FUN_140386780(local_468);
      plVar13 = (longlong *)
                (**(code **)(**(longlong **)param_1[0x28] + 0x10))(*(longlong **)param_1[0x28],0x24)
      ;
      uVar10 = (**(code **)(*plVar13 + 0x48))(plVar13);
      uVar11 = (**(code **)(*param_1 + 8))(param_1);
      local_678 = 0;
      uVar27 = 0;
      local_680 = 0;
      local_688 = 0;
      local_690 = (uint *)((ulonglong)local_690 & 0xffffffff00000000);
      local_6a8 = local_6a8 & 0xffffffffffffff00;
      local_6a0 = uVar6;
      local_698 = uVar7;
      iVar4 = FUN_140386a50(local_468,uVar11,uVar10,0);
      if (iVar4 == 0) {
        local_6a8 = CONCAT44(local_6a8._4_4_,0x5b0);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar19 = (longlong)local_630 - (longlong)local_638 >> 3;
        uVar29 = uVar27;
        if (0 < (int)uVar19) {
          do {
            iVar4 = 0;
            if (param_1[8] != 0) {
              if (uVar19 <= uVar27) {
                _invalid_parameter_noinfo();
              }
              lVar15 = (**(code **)(**(longlong **)(local_638 + uVar27 * 2) + 0x2b0))();
              if (lVar15 != 0) {
                if (param_1[8] == 0) {
                  local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                iVar4 = FUN_14018eb30(param_1[8]);
                iVar5 = FUN_14018ed10(lVar15);
                iVar4 = iVar4 - iVar5;
              }
            }
            if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar27) {
              _invalid_parameter_noinfo();
            }
            plVar13 = *(longlong **)(local_638 + uVar27 * 2);
            if ((ulonglong)((longlong)local_598 - (longlong)local_5a0 >> 2) <= uVar27) {
              _invalid_parameter_noinfo();
            }
            puVar23 = local_5a0;
            if ((ulonglong)((longlong)local_558 - (longlong)local_560 >> 2) <= uVar27) {
              _invalid_parameter_noinfo();
            }
            puVar1 = local_560;
            if ((ulonglong)((longlong)local_5c8 - (longlong)local_5d0 >> 2) <= uVar27) {
              _invalid_parameter_noinfo();
            }
            puVar2 = local_5d0;
            uVar10 = (**(code **)(*plVar13 + 0x10))(plVar13);
            local_688 = 0;
            local_690 = (uint *)((ulonglong)local_690 & 0xffffffff00000000);
            local_698 = 0;
            local_6a0 = puVar23[uVar27];
            local_6a8 = CONCAT44(local_6a8._4_4_,puVar1[uVar27]);
            iVar4 = FUN_140387150(local_468,uVar10,puVar2[uVar27],iVar4);
            if (iVar4 == 0) {
              (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,1);
              plVar13 = (longlong *)
                        (**(code **)(**(longlong **)param_1[0x28] + 0x10))
                                  (*(longlong **)param_1[0x28],0x24);
              uVar10 = (**(code **)(*plVar13 + 0x48))(plVar13);
              uVar11 = (**(code **)(*param_1 + 8))(param_1);
              local_678 = 0;
              local_680 = 0;
              local_688 = 0;
              local_690 = (uint *)((ulonglong)local_690 & 0xffffffff00000000);
              local_698 = local_658._4_4_;
              local_6a0 = (uint)local_658;
              local_6a8 = local_6a8 & 0xffffffffffffff00;
              FUN_140386a50(local_468,uVar11,uVar10,0);
            }
            else {
              uVar29 = (ulonglong)((int)uVar29 + 1);
              uVar27 = uVar27 + 1;
            }
            uVar19 = (longlong)local_630 - (longlong)local_638 >> 3;
          } while ((int)uVar29 < (int)uVar19);
        }
        (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_468,1);
      }
      plVar16 = (longlong *)0x0;
      plVar13 = param_1 + 2;
      param_1 = param_1 + 8;
      if (*param_1 != 0) {
        iVar4 = 0;
        uVar27 = (longlong)local_630 - (longlong)local_638 >> 3;
        if (0 < (int)uVar27) {
          do {
            puVar23 = local_638;
            if (uVar27 <= (ulonglong)(longlong)iVar4) {
                    /* WARNING: Subroutine does not return */
              FUN_140388bf0();
            }
            if (local_630 < local_638) {
              _invalid_parameter_noinfo();
            }
            plVar20 = local_650[0];
            local_5f8 = local_650[0];
            uStack_5f0 = puVar23;
            local_5f8._0_4_ = SUB84(local_650[0],0);
            local_5f8._4_4_ = (undefined4)((ulonglong)local_650[0] >> 0x20);
            uStack_5f0._0_4_ = SUB84(puVar23,0);
            uStack_5f0._4_4_ = (undefined4)((ulonglong)puVar23 >> 0x20);
            local_548 = (undefined4)local_5f8;
            uStack_544 = local_5f8._4_4_;
            uStack_540 = (undefined4)uStack_5f0;
            uStack_53c = uStack_5f0._4_4_;
            local_5f8 = plVar20;
            uStack_5f0 = puVar23;
            if (local_650[0] == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              plVar28 = plVar16;
            }
            else {
              plVar28 = (longlong *)*local_650[0];
            }
            puVar23 = puVar23 + (longlong)iVar4 * 2;
            if ((uint *)plVar28[4] < puVar23) {
LAB_14039396d:
              _invalid_parameter_noinfo();
            }
            else {
              if (plVar20 == (longlong *)0x0) {
                lVar15 = 0;
              }
              else {
                lVar15 = *plVar20;
              }
              if (puVar23 < *(uint **)(lVar15 + 0x18)) goto LAB_14039396d;
            }
            if ((undefined8 *)CONCAT44(uStack_544,local_548) == (undefined8 *)0x0) {
              _invalid_parameter_noinfo();
              plVar20 = plVar16;
            }
            else {
              plVar20 = *(longlong **)CONCAT44(uStack_544,local_548);
            }
            if ((uint *)plVar20[4] <= puVar23) {
              _invalid_parameter_noinfo();
            }
            if (*param_1 == 0) {
              local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            cVar3 = FUN_1401b9c20(*param_1,*(undefined8 *)puVar23,1);
            if (cVar3 != '\0') break;
            iVar4 = iVar4 + 1;
            uVar27 = (longlong)local_630 - (longlong)local_638 >> 3;
          } while (iVar4 < (int)uVar27);
        }
        uVar6 = 0;
        local_660 = 0;
        local_658 = operator_new(8);
        local_4f8[0] = plVar16;
        if (local_658 != (longlong *)0x0) {
          *local_658 = (longlong)local_4f8;
          local_4f8[0] = local_658;
        }
        local_618 = local_658;
        local_4c8 = (uint *)FUN_140099ce0(local_4f8);
        puVar23 = local_638;
        *(undefined1 *)((longlong)local_4c8 + 0x21) = 1;
        *(uint **)(local_4c8 + 2) = local_4c8;
        *(uint **)local_4c8 = local_4c8;
        *(uint **)(local_4c8 + 4) = local_4c8;
        local_4c0 = 0;
        local_65c = 0;
        uVar29 = 0;
        uVar27 = (longlong)local_630 - (longlong)local_638 >> 3;
        if (0 < (int)uVar27) {
          plVar20 = (longlong *)FUN_1401594f0(local_608);
          uVar6 = 0;
          local_618 = plVar20;
          do {
            uVar7 = (uint)plVar16;
            if (uVar27 <= uVar29) {
              _invalid_parameter_noinfo();
              puVar23 = local_638;
            }
            plVar13 = *(longlong **)(puVar23 + uVar29 * 2);
            if ((ulonglong)((longlong)local_5c8 - (longlong)local_5d0 >> 2) <= uVar29) {
              _invalid_parameter_noinfo();
            }
            puVar23 = local_5d0;
            if ((ulonglong)((longlong)local_5c8 - (longlong)local_5d0 >> 2) <= uVar29) {
              _invalid_parameter_noinfo();
            }
            local_6a8 = CONCAT71(local_6a8._1_7_,1);
            uVar12 = (**(code **)(*plVar13 + 0x3b8))(plVar13,plVar20,local_5d0[uVar29],0);
            puVar23[uVar29] = uVar12;
            if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
              _invalid_parameter_noinfo();
            }
            iVar4 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x78))();
            if ((ulonglong)((longlong)local_5c8 - (longlong)local_5d0 >> 2) <= uVar29) {
              _invalid_parameter_noinfo();
            }
            puVar23 = local_5d0;
            if ((ulonglong)((longlong)local_598 - (longlong)local_5a0 >> 2) <= uVar29) {
              _invalid_parameter_noinfo();
            }
            if ((int)(local_5a0[uVar29] + puVar23[uVar29]) < iVar4) {
              iVar4 = local_5a0[uVar29] + puVar23[uVar29];
            }
            plVar13 = local_600;
            if (0 < iVar4) {
              if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                _invalid_parameter_noinfo();
              }
              local_6a8 = 0;
              (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x2e0))
                        (*(longlong **)(local_638 + uVar29 * 2),0,(longlong)-iVar4);
              if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                _invalid_parameter_noinfo();
              }
              cVar3 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x298))
                                (*(longlong **)(local_638 + uVar29 * 2),0x1040,&local_668);
              plVar13 = local_668;
              if ((cVar3 != '\0') &&
                 ((iVar5 = (**(code **)(*(longlong *)local_668[0xc] + 0x10))
                                     ((longlong *)local_668[0xc],4), iVar5 == 10 ||
                  (iVar5 = (**(code **)(*(longlong *)plVar13[0xc] + 0x10))
                                     ((longlong *)plVar13[0xc],4), iVar5 == 0x2e)))) {
                iVar5 = (**(code **)(*(longlong *)local_668[0xc] + 0x10))
                                  ((longlong *)local_668[0xc],4);
                if (iVar5 == 10) {
                  if (*param_1 == 0) {
                    local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  plVar13 = (longlong *)*param_1;
                  plVar16 = (longlong *)FUN_140087ed0();
                  lVar15 = *plVar16;
                  uVar10 = (**(code **)(*local_668 + 8))();
                  uVar11 = (**(code **)(*plVar13 + 8))(plVar13);
                  (**(code **)(lVar15 + 0x308))(plVar16,uVar11,uVar10);
                  uVar6 = local_660;
                }
                else {
                  iVar5 = (**(code **)(*(longlong *)local_668[0xc] + 0x10))
                                    ((longlong *)local_668[0xc],4);
                  if (iVar5 == 0x2e) {
                    plVar13 = (longlong *)CurrentInstanceGet();
                    if (plVar13 != (longlong *)0x0) {
                      uVar14 = FUN_140008520((int)local_608[0x2d]);
                      cVar3 = FUN_14008b330(uVar14);
                      if (cVar3 == '\0') {
                        plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x1c);
                        if (plVar13 != (longlong *)0x0) {
                          lVar21 = FUN_14038c750(param_1);
                          lVar15 = *plVar13;
                          uVar10 = (**(code **)(*local_668 + 8))();
                          uVar11 = (**(code **)(*(longlong *)(lVar21 + 0x10) + 0x170))
                                             ((longlong *)(lVar21 + 0x10));
                          (**(code **)(lVar15 + 0x38))(plVar13,uVar11,uVar10);
                          uVar6 = local_660;
                        }
                      }
                      else {
                        plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x25);
                        if (plVar13 != (longlong *)0x0) {
                          plVar16 = (longlong *)FUN_14038c750(param_1);
                          lVar15 = *plVar13;
                          uVar10 = (**(code **)(*local_668 + 8))();
                          uVar11 = (**(code **)(*plVar16 + 8))(plVar16);
                          (**(code **)(lVar15 + 0x70))(plVar13,uVar11,uVar10);
                          uVar6 = local_660;
                        }
                      }
                    }
                  }
                  else {
                    (**(code **)(*(longlong *)local_668[0xc] + 0x10))((longlong *)local_668[0xc],4);
                    (**(code **)(*local_668 + 8))();
                    log_InlineLogERROR("CMonster::ProcessBomb. Error Npc Type ID[%u] TYPE[%u]");
                  }
                }
              }
              if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                _invalid_parameter_noinfo();
              }
              cVar3 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x298))
                                (*(longlong **)(local_638 + uVar29 * 2),0x1040,&local_668);
              if ((((cVar3 != '\0') &&
                   (iVar5 = (**(code **)(*(longlong *)local_668[0xc] + 0x10))
                                      ((longlong *)local_668[0xc],4), iVar5 == 0x28)) &&
                  (plVar13 = (longlong *)CurrentInstanceGet(), plVar13 != (longlong *)0x0)) &&
                 (plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x18),
                 plVar13 != (longlong *)0x0)) {
                plVar16 = (longlong *)FUN_14038c750(param_1);
                lVar15 = *plVar13;
                uVar10 = (**(code **)(*plVar16 + 8))(plVar16);
                (**(code **)(lVar15 + 0x58))(plVar13,uVar10,iVar4);
              }
              if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                _invalid_parameter_noinfo();
              }
              cVar3 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x240))();
              if (cVar3 != '\0') {
                local_658 = (longlong *)0x0;
                if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                  _invalid_parameter_noinfo();
                }
                cVar3 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x298))
                                  (*(longlong **)(local_638 + uVar29 * 2),0x1002,&local_658);
                if (cVar3 == '\0') {
                  if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                    _invalid_parameter_noinfo();
                  }
                  puVar23 = local_638;
                  if (*param_1 == 0) {
                    local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
                    log_InlineLogERROR(&DAT_1406d9c10);
                  }
                  iVar5 = FUN_140185f80(*param_1,*(undefined8 *)(puVar23 + uVar29 * 2),iVar4);
                }
                else {
                  iVar5 = (**(code **)(*local_658 + 0x50))();
                  puVar2 = local_4c8;
                  plVar13 = local_4f8[0];
                  cVar3 = *(char *)((longlong)*(uint **)(local_4c8 + 2) + 0x21);
                  puVar23 = *(uint **)(local_4c8 + 2);
                  puVar1 = local_4c8;
                  while (puVar25 = puVar23, cVar3 == '\0') {
                    if ((int)puVar25[6] < iVar5) {
                      puVar23 = *(uint **)(puVar25 + 4);
                      puVar25 = puVar1;
                    }
                    else {
                      puVar23 = *(uint **)puVar25;
                    }
                    cVar3 = *(char *)((longlong)puVar23 + 0x21);
                    puVar1 = puVar25;
                  }
                  uStack_5f0 = puVar1;
                  local_5f8 = local_4f8[0];
                  if (local_4f8[0] == (longlong *)0x0) {
                    _invalid_parameter_noinfo();
                  }
                  if ((puVar1 == puVar2) || (iVar5 < (int)puVar1[6])) {
                    uStack_580 = local_4c8;
                    local_588 = local_4f8[0];
                    puVar24 = &local_588;
                  }
                  else {
                    puVar24 = &local_5f8;
                  }
                  local_538 = (longlong *)*puVar24;
                  uStack_530 = (uint *)puVar24[1];
                  if ((local_538 == (longlong *)0x0) || (local_538 != plVar13)) {
                    _invalid_parameter_noinfo();
                  }
                  if (uStack_530 == puVar2) {
                    if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                      _invalid_parameter_noinfo();
                    }
                    puVar23 = local_638;
                    if (*param_1 == 0) {
                      local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
                      log_InlineLogERROR(&DAT_1406d9c10);
                    }
                    iVar5 = FUN_140185f80(*param_1,*(undefined8 *)(puVar23 + uVar29 * 2),iVar4);
                    local_620[0] = (**(code **)(*local_658 + 0x50))();
                    piVar22 = (int *)FUN_14033a2d0(local_4f8,local_620);
                    *piVar22 = (iVar5 * 10000) / iVar4;
                    uVar6 = local_660;
                    uVar7 = local_65c;
                  }
                  else {
                    local_620[0] = (**(code **)(*local_658 + 0x50))();
                    piVar22 = (int *)FUN_14033a2d0(local_4f8,local_620);
                    iVar5 = (iVar4 * *piVar22) / 10000;
                    uVar6 = local_660;
                    uVar7 = local_65c;
                  }
                }
                uVar6 = uVar6 + iVar5;
                local_660 = uVar6;
              }
              if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                _invalid_parameter_noinfo();
              }
              cVar3 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x220))();
              plVar20 = local_618;
              plVar13 = local_600;
              if (cVar3 == '\0') {
                if (*param_1 == 0) {
                  local_6a8 = CONCAT44(local_6a8._4_4_,0x22);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                cVar3 = FUN_14016e3f0(*param_1);
                plVar16 = local_608;
                plVar13 = local_600;
                if (cVar3 != '\0') {
                  if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                    _invalid_parameter_noinfo();
                  }
                  lVar15 = (**(code **)(**(longlong **)(local_638 + uVar29 * 2) + 0x2b0))();
                  plVar16 = local_608;
                  plVar13 = local_600;
                  if (lVar15 != 0) {
                    if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                      _invalid_parameter_noinfo();
                    }
                    plVar16 = local_608;
                    plVar13 = local_600;
                    if ((lVar15 + 0x10 == *(longlong *)(local_638 + uVar29 * 2)) &&
                       (lVar15 = FUN_14016e430(lVar15), plVar13 = local_600, plVar16 = local_608,
                       lVar15 != 0)) {
                      lVar21 = *local_600;
                      uVar10 = FUN_140387f80(local_608);
                      local_690 = (uint *)CONCAT44(local_690._4_4_,10000000);
                      local_698 = local_698 & 0xffff0000;
                      local_6a0 = local_6a0 & 0xffff0000;
                      local_6a8 = local_6a8 & 0xffffffffffffff00;
                      (**(code **)(lVar21 + 0x3c8))(plVar13,lVar15 + 0x10,uVar10);
                    }
                  }
                }
                if ((ulonglong)((longlong)local_630 - (longlong)local_638 >> 3) <= uVar29) {
                  _invalid_parameter_noinfo();
                }
                puVar23 = local_638;
                lVar15 = *plVar13;
                uVar10 = FUN_140387f80(plVar16);
                local_690 = (uint *)CONCAT44(local_690._4_4_,11000000);
                local_698 = local_698 & 0xffff0000;
                local_6a0 = local_6a0 & 0xffff0000;
                local_6a8 = local_6a8 & 0xffffffffffffff00;
                (**(code **)(lVar15 + 0x3c8))(plVar13,*(undefined8 *)(puVar23 + uVar29 * 2),uVar10);
                plVar20 = local_618;
              }
            }
            local_65c = uVar7 + 1;
            plVar16 = (longlong *)(ulonglong)local_65c;
            uVar29 = uVar29 + 1;
            uVar27 = (longlong)local_630 - (longlong)local_638 >> 3;
            puVar23 = local_638;
          } while ((int)local_65c < (int)uVar27);
        }
        local_6a8 = CONCAT71(local_6a8._1_7_,1);
        (**(code **)(*plVar13 + 0x2f8))(plVar13,(longlong)(int)uVar6,1,0);
        uStack_5f0 = local_4c8;
        puVar1 = uStack_5f0;
        local_5f8 = local_4f8[0];
        plVar13 = local_5f8;
        puVar23 = *(uint **)local_4c8;
        local_588 = local_4f8[0];
        local_5f8._0_4_ = SUB84(local_4f8[0],0);
        local_5f8._4_4_ = (undefined4)((ulonglong)local_4f8[0] >> 0x20);
        uStack_5f0._0_4_ = SUB84(local_4c8,0);
        uStack_5f0._4_4_ = (undefined4)((ulonglong)local_4c8 >> 0x20);
        local_548 = (undefined4)local_5f8;
        uStack_544 = local_5f8._4_4_;
        uStack_540 = (undefined4)uStack_5f0;
        uStack_53c = uStack_5f0._4_4_;
        uStack_580._0_4_ = SUB84(puVar23,0);
        uStack_580._4_4_ = (undefined4)((ulonglong)puVar23 >> 0x20);
        local_4b8 = (undefined4)local_5f8;
        uStack_4b4 = local_5f8._4_4_;
        uStack_4b0 = (undefined4)uStack_580;
        uStack_4ac = uStack_580._4_4_;
        local_5f8 = plVar13;
        uStack_5f0 = puVar1;
        uStack_580 = puVar23;
        FUN_1400a4100(local_4f8,&local_498,&local_4b8,&local_548);
        operator_delete(local_4c8);
        local_4c8 = (uint *)0x0;
        local_4c0 = 0;
        operator_delete(local_4f8[0]);
      }
      FUN_1403867d0(local_468);
      if (local_5a0 != (uint *)0x0) {
        operator_delete(local_5a0);
      }
      local_5a0 = (uint *)0x0;
      local_598 = (uint *)0x0;
      local_590 = 0;
      operator_delete(local_5b8[0]);
      if (local_560 != (uint *)0x0) {
        operator_delete(local_560);
      }
      local_560 = (uint *)0x0;
      local_558 = (uint *)0x0;
      local_550 = 0;
      operator_delete(local_578[0]);
      if (local_5d0 != (uint *)0x0) {
        operator_delete(local_5d0);
      }
      local_5d0 = (uint *)0x0;
      local_5c8 = (uint *)0x0;
      local_5c0 = 0;
      operator_delete(local_5e8[0]);
      if (local_638 != (uint *)0x0) {
        operator_delete(local_638);
      }
      local_638 = (uint *)0x0;
      local_630 = (uint *)0x0;
      local_628 = 0;
      operator_delete(local_650[0]);
      if (local_510 != (void *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (void *)0x0;
      local_508 = 0;
      local_500 = 0;
      operator_delete(local_528[0]);
      return;
    }
  }
  local_6a8 = CONCAT44(local_6a8._4_4_,0x564);
  log_InlineLogERROR(&DAT_1406d9c10);
  return;
}

// ==== CMonster::vfunc_122  @140394680  [high:rtti-vtable]  (orig: FUN_140394680)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140394680(longlong *param_1,longlong *param_2)

{
  byte bVar1;
  undefined4 *puVar2;
  undefined1 uVar3;
  char cVar4;
  char cVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined8 uVar14;
  longlong *plVar15;
  undefined4 uVar16;
  undefined4 *puVar17;
  longlong *plVar18;
  longlong *plVar19;
  char cVar20;
  uint unaff_R15D;
  bool bVar21;
  undefined1 auStack_558 [32];
  undefined4 local_538;
  undefined8 local_530;
  undefined4 local_528;
  undefined8 local_520;
  undefined8 local_518;
  char local_508;
  undefined1 local_507;
  char local_506;
  uint local_504;
  undefined4 local_500;
  uint local_4fc;
  longlong *local_4f8;
  longlong *local_4f0 [3];
  undefined4 *local_4d8;
  undefined4 *local_4d0;
  undefined8 local_4c8;
  longlong *local_4c0;
  longlong *local_4b8;
  longlong *local_4b0;
  longlong *local_4a8;
  undefined8 local_4a0;
  longlong *local_498;
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_4a0 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_558;
  local_4f8 = param_2;
  local_4b8 = param_1;
  local_4b0 = param_2;
  lVar10 = FUN_140008520((int)param_1[0x2b]);
  lVar10 = *(longlong *)(lVar10 + 400);
  if (lVar10 == 0) {
    local_538 = 0x155;
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar10 = 0;
  }
  plVar18 = (longlong *)0x0;
  FUN_14023b940(lVar10,param_1 + -2);
  if (*(int *)((longlong)param_1 + 0x144) != 0) {
    return;
  }
  if (param_1[0xe] != 0) {
    (**(code **)(*(longlong *)param_1[0xe] + 0x60))((longlong *)param_1[0xe],6);
  }
  local_500 = 0;
  local_4c0 = (longlong *)0x0;
  local_508 = '\0';
  local_4fc = unaff_R15D & 0xffffff00;
  local_507 = 0;
  plVar11 = plVar18;
  cVar4 = '\0';
  uVar6 = 1;
  if ((local_4f8 != (longlong *)0x0) &&
     (plVar11 = (longlong *)(**(code **)(*local_4f8 + 0x2b0))(), local_4c0 = plVar11,
     plVar11 != (longlong *)0x0)) {
    local_500 = (**(code **)(*plVar11 + 8))(plVar11);
    uVar3 = FUN_14018a120(plVar11);
    local_504 = CONCAT31(local_504._1_3_,uVar3);
    local_508 = FUN_140168a10(plVar11);
    if (local_508 != '\0') {
      uVar12 = FUN_140008520((int)param_1[0x2b]);
      uVar6 = FUN_14008b020(uVar12);
      uVar7 = FUN_1401649c0(plVar11);
      local_504 = local_504 & 0xff;
      if (uVar7 < uVar6) {
        local_504 = 0;
      }
    }
    uVar6 = FUN_1401649c0(plVar11);
    local_507 = uVar6 < 4;
    local_4fc = (uint)(byte)local_507;
    plVar13 = (longlong *)
              (**(code **)(**(longlong **)param_1[0x26] + 0x20))
                        (*(longlong **)param_1[0x26],&DAT_140951730);
    iVar8 = (**(code **)(*plVar13 + 0x40))(plVar13);
    (**(code **)(*param_1 + 0x70))(param_1);
    (**(code **)(plVar11[2] + 0x70))();
    if (iVar8 == 0x1038) {
      uVar12 = 0x291e;
    }
    else {
      cVar4 = local_508;
      uVar6 = local_504;
      if (2 < iVar8 - 0x104aU) goto LAB_140394aae;
      if (iVar8 == 0x104b) {
        uVar12 = 0x291f;
      }
      else if (iVar8 == 0x104a) {
        uVar12 = 0x2920;
      }
      else {
        plVar13 = (longlong *)
                  (**(code **)(**(longlong **)param_1[0x26] + 0x20))
                            (*(longlong **)param_1[0x26],&DAT_140951730);
        iVar8 = (**(code **)(*plVar13 + 0x40))(plVar13);
        cVar4 = local_508;
        uVar6 = local_504;
        if (iVar8 != 0x104c) goto LAB_140394aae;
        uVar12 = 0x2921;
      }
    }
    plVar13 = (longlong *)FUN_140118320();
    cVar4 = local_508;
    uVar6 = local_504;
    if (plVar13 != (longlong *)0x0) {
      local_4a8 = operator_new(8);
      local_4f0[0] = plVar18;
      if (local_4a8 != (longlong *)0x0) {
        *local_4a8 = (longlong)local_4f0;
        local_4f0[0] = local_4a8;
      }
      local_4d8 = (undefined4 *)0x0;
      local_4d0 = (undefined4 *)0x0;
      local_4c8 = 0;
      lVar10 = *plVar13;
      local_498 = local_4a8;
      uVar9 = (**(code **)(*plVar11 + 8))(plVar11);
      iVar8 = (**(code **)(lVar10 + 0x28))(plVar13,uVar9);
      if (iVar8 == 0) {
LAB_140394a42:
        FUN_140170e90(plVar11,uVar12);
      }
      else {
        lVar10 = *plVar13;
        uVar9 = (**(code **)(*plVar11 + 8))(plVar11);
        cVar4 = (**(code **)(lVar10 + 0x38))(plVar13,uVar9,local_4f0);
        puVar17 = local_4d8;
        if (cVar4 == '\0') goto LAB_140394a42;
        plVar13 = local_4f0[0];
        if (local_4d0 < local_4d8) {
          _invalid_parameter_noinfo();
          plVar13 = local_4f0[0];
        }
        while( true ) {
          puVar2 = local_4d0;
          if (local_4d0 < local_4d8) {
            _invalid_parameter_noinfo();
          }
          if ((plVar13 == (longlong *)0x0) || (plVar13 != local_4f0[0])) {
            _invalid_parameter_noinfo();
          }
          if (puVar2 <= puVar17) break;
          uVar14 = FUN_140008520((int)param_1[0x2b]);
          plVar15 = (longlong *)FUN_140087650(uVar14);
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar19 = plVar18;
          }
          else {
            plVar19 = (longlong *)*plVar13;
          }
          if ((undefined4 *)plVar19[4] <= puVar17) {
            _invalid_parameter_noinfo();
          }
          lVar10 = (**(code **)(*plVar15 + 0x98))(plVar15,*puVar17);
          if (lVar10 != 0) {
            FUN_140170e90(lVar10,uVar12);
          }
          if (plVar13 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar18;
          }
          else {
            plVar15 = (longlong *)*plVar13;
          }
          if ((undefined4 *)plVar15[4] <= puVar17) {
            _invalid_parameter_noinfo();
          }
          puVar17 = puVar17 + 1;
        }
      }
      if (local_4d8 != (undefined4 *)0x0) {
        operator_delete(local_4d8);
      }
      local_4d8 = (undefined4 *)0x0;
      local_4d0 = (undefined4 *)0x0;
      local_4c8 = 0;
      operator_delete(local_4f0[0]);
      cVar4 = local_508;
      uVar6 = local_504;
    }
  }
LAB_140394aae:
  plVar13 = param_1 + -2;
  uVar12 = FUN_140008520((int)param_1[0x2b]);
  cVar5 = FUN_14008b330(uVar12);
  cVar20 = (char)uVar6;
  if (cVar5 != '\0') {
    cVar20 = '\0';
  }
  local_506 = cVar20;
  iVar8 = (**(code **)(*plVar13 + 8))(plVar13);
  if (iVar8 - 0xaae61U < 99999) {
    cVar5 = FUN_140388dd0(plVar13);
    uVar3 = (undefined1)local_4fc;
    if ((cVar5 != '\0') && (param_1[0xc] != 0)) {
      plVar15 = (longlong *)
                (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],2);
      iVar8 = (**(code **)(*plVar15 + 0x48))(plVar15);
      if (iVar8 == 5) {
        FUN_1403929b0(plVar13);
        uVar3 = (undefined1)local_4fc;
      }
      else {
        uVar3 = (undefined1)local_4fc;
      }
    }
  }
  else {
    uVar3 = (undefined1)local_4fc;
  }
  uVar12 = FUN_140008520((int)param_1[0x2b]);
  cVar5 = FUN_14008abf0(uVar12);
  if (cVar5 == '\0') {
    local_538 = CONCAT31(local_538._1_3_,uVar3);
    FUN_14038dc80(param_1 + -2,plVar11,cVar20,cVar4);
  }
  else {
    local_538 = CONCAT31(local_538._1_3_,uVar3);
    FUN_1403899c0(param_1 + -2,plVar11,cVar20,cVar4);
  }
  plVar13 = param_1 + -2;
  iVar8 = tq::RandGet(100);
  uVar9 = local_500;
  if ((iVar8 < 3) && (cVar4 == '\0')) {
    FUN_14038afc0(plVar13,local_500);
  }
  uVar16 = local_500;
  if (cVar20 != '\0') {
    if (plVar11 != (longlong *)0x0) {
      FUN_14038b0b0(plVar13,plVar11,cVar4);
    }
    lVar10 = (**(code **)(*param_1 + 0x160))(param_1);
    uVar16 = local_500;
    if (lVar10 != 0) {
      plVar15 = (longlong *)(**(code **)(*param_1 + 0x160))(param_1);
      iVar8 = (**(code **)(*plVar15 + 8))(plVar15);
      uVar16 = local_500;
      if (iVar8 != 0x3ea) {
        iVar8 = tq::RandGet(0x2ee);
        if (iVar8 == 0x7b) {
          FUN_14038a790(plVar13,0x109a01,uVar9);
          uVar12 = FUN_140087d90();
          FUN_1401143f0(uVar12,uVar9,0x291c);
        }
        uVar16 = local_500;
        if (plVar11 != (longlong *)0x0) {
          uVar6 = FUN_140166eb0(plVar11);
          if (uVar6 == 0) {
            bVar1 = *(byte *)((longlong)plVar11 + 0xeee);
            uVar9 = (**(code **)(*plVar11 + 0x108))(plVar11);
            uVar12 = FUN_140008520((int)param_1[0x2b]);
            iVar8 = FUN_1400b2bd0(uVar12,bVar1 / 10,uVar9);
            uVar16 = local_500;
            if ((0 < iVar8) && (iVar8 = tq::RandGet(iVar8), uVar16 = local_500, iVar8 == 0x7b))
            goto LAB_140394d04;
          }
          else {
            uVar7 = tq::RandGet(100);
            uVar16 = local_500;
            if (uVar7 <= uVar6) {
LAB_140394d04:
              uVar16 = local_500;
              FUN_14038a790(plVar13,0x109a00,local_500);
              uVar12 = FUN_140087d90();
              FUN_1401143f0(uVar12,uVar16,0x291b);
              FUN_140362560(local_488);
              uVar9 = (**(code **)(*plVar13 + 8))(plVar13);
              cVar4 = FUN_140362910(local_488,0xa5,uVar9,0);
              if (cVar4 != '\0') {
                (**(code **)(plVar11[2] + 0x350))(plVar11 + 2,local_488);
              }
              lVar10 = plVar11[0x1e2];
              (**(code **)(*plVar11 + 8))(plVar11);
              local_518 = 0;
              local_520 = 0;
              local_528 = 0x134;
              local_530 = CONCAT44(local_530._4_4_,300);
              local_538 = (int)lVar10;
              tq::MyLogSave("gmlog/emoney_buy","%u\t%u\t%u\t%u\t%u\t%d\t%d\t1\t");
              FUN_1403625e0(local_488);
            }
          }
        }
      }
    }
  }
  uVar6 = (**(code **)(*param_1 + 0x70))(param_1);
  if (uVar6 < 0x75) {
    if (local_4f8 != (longlong *)0x0) {
      iVar8 = (**(code **)(*param_1 + 0x70))(param_1);
      uVar6 = (**(code **)(*local_4f8 + 0x70))();
      if (uVar6 <= iVar8 + 5U) {
        iVar8 = tq::RandGet(900);
        bVar21 = iVar8 == 0xd;
        goto LAB_140394e3d;
      }
    }
    iVar8 = tq::RandGet(9000);
    bVar21 = iVar8 == 0xd;
  }
  else {
    iVar8 = tq::RandGet(0x578);
    bVar21 = iVar8 == 0xd;
  }
LAB_140394e3d:
  if (cVar20 != '\0') {
    if (bVar21) {
      iVar8 = tq::RandGet(0x4b0);
      if (iVar8 < 100) {
        uVar12 = 0xaae6b;
      }
      else if (iVar8 < 200) {
        uVar12 = 0xaae61;
      }
      else if (iVar8 < 300) {
        uVar12 = 0xaae7f;
      }
      else if (iVar8 < 400) {
        uVar12 = 0xaaec5;
      }
      else if (iVar8 < 500) {
        uVar12 = 0xaaed9;
      }
      else if (iVar8 < 0x2a3) {
        uVar12 = 0xaae9d;
      }
      else if (iVar8 < 0x352) {
        uVar12 = 0xaae93;
      }
      else {
        uVar12 = 0xaae89;
        if (iVar8 < 0x401) {
          uVar12 = 0xaae75;
        }
      }
      FUN_14038a790(plVar13,uVar12,uVar16);
    }
    iVar8 = (**(code **)(*plVar13 + 8))(plVar13);
    if (0x1869e < iVar8 - 0xaae61U) {
      FUN_14038a900(plVar13,uVar16);
    }
  }
  if (plVar11 != (longlong *)0x0) {
    plVar15 = (longlong *)
              (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x19);
    iVar8 = (**(code **)(*plVar15 + 0x48))(plVar15);
    if (iVar8 != 0) {
      cVar4 = FUN_140167b70(plVar11);
      if (cVar4 != '\0') {
        uVar12 = FUN_140008520((int)param_1[0x2b]);
        uVar12 = FUN_140087730(uVar12);
        cVar4 = FUN_140118a20(uVar12,iVar8);
        if (cVar4 == '\0') goto LAB_140394fab;
      }
      if (plVar13 != (longlong *)0x0) {
        plVar18 = param_1;
      }
      plVar15 = (longlong *)
                (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],0x19)
      ;
      uVar9 = (**(code **)(*plVar15 + 0x48))(plVar15);
      uVar12 = FUN_140008520((int)param_1[0x2b]);
      uVar12 = FUN_140087730(uVar12);
      local_530 = 0;
      local_538 = 0;
      FUN_140145f60(uVar12,uVar9,plVar11,plVar18);
    }
  }
LAB_140394fab:
  (**(code **)(*param_1 + 0x2c8))(param_1,0,1);
  FUN_14038e270(plVar13,0);
  cVar4 = FUN_1403885c0(plVar13);
  if ((cVar4 != '\0') && (param_1[6] != 0)) {
    if (param_1[6] == 0) {
      local_538 = 0x22;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    FUN_140198760(param_1[6],0,1);
    if (param_1[6] == 0) {
      local_538 = 0x22;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    (**(code **)(*(longlong *)(param_1[6] + 0x10) + 0x3d0))
              ((longlong *)(param_1[6] + 0x10),local_4f8,0);
  }
  return;
}

// ==== CMonster::vfunc_114  @1403950a0  [high:rtti-vtable]  (orig: FUN_1403950a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403950a0(longlong *param_1,longlong param_2)

{
  char cVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong lVar11;
  longlong lVar12;
  undefined1 auStack_4c8 [32];
  char *local_4a8;
  undefined4 local_4a0;
  int local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined1 local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (param_2 == 0) {
    local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x4d6);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar2 = 0;
  }
  else {
    cVar1 = FUN_140388dd0(param_1 + -2);
    uVar2 = 0;
    if (cVar1 != '\0') {
      if (param_1[0xc] == 0) {
        if ((undefined8 *)param_1[0x26] != (undefined8 *)0x0) {
          plVar9 = *(longlong **)param_1[0x26];
          plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0x24);
          (**(code **)(*plVar9 + 0x48))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)param_1[0x26] + 0x10))(*(longlong **)param_1[0x26],1)
          ;
          (**(code **)(*plVar9 + 0x78))(plVar9);
          plVar9 = (longlong *)
                   (**(code **)(**(longlong **)param_1[0x26] + 0x20))
                             (*(longlong **)param_1[0x26],&DAT_140951730);
          (**(code **)(*plVar9 + 0x40))(plVar9);
          local_4a0 = 0x4e1;
          local_4a8 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\ainpc.cpp";
          log_InlineLogDBERROR
                    (
                    "table:cq_monstertype, CMonster::AutoSkillAttack() MonsterType id=%u, name=%s, magic_type=%u at %s, %d"
                    );
        }
        uVar2 = 0;
      }
      else {
        plVar9 = (longlong *)
                 (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],2);
        iVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
        if (iVar3 == 2) {
          if (param_1[6] != 0) {
            plVar9 = (longlong *)
                     (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0xd);
            uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
            cVar1 = FUN_1400222e0(param_1 + 0xd,uVar4);
            if (cVar1 != '\0') {
              lVar11 = FUN_14038c750(param_1 + 6);
              lVar12 = FUN_14038c750(param_1 + 6);
              uVar5 = (**(code **)(*(longlong *)(lVar11 + 0x10) + 0x78))
                                ((longlong *)(lVar11 + 0x10));
              uVar6 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x80))
                                ((longlong *)(lVar12 + 0x10));
              if (uVar5 < uVar6) {
                plVar9 = (longlong *)
                         (**(code **)(*(longlong *)param_1[0xc] + 0x10))
                                   ((longlong *)param_1[0xc],10);
                iVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
                lVar11 = FUN_14038c750(param_1 + 6);
                local_4a8 = (char *)0x0;
                (**(code **)(*(longlong *)(lVar11 + 0x10) + 0x2e0))
                          ((longlong *)(lVar11 + 0x10),0,(longlong)iVar3,1);
                FUN_140386780(local_468);
                plVar9 = (longlong *)FUN_14038c750(param_1 + 6);
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                uVar7 = FUN_140388e30(param_1 + -2);
                uVar8 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
                local_480 = 0;
                local_488 = 0;
                local_490 = 0;
                local_4a8 = (char *)((ulonglong)local_4a8 & 0xffffffffffffff00);
                local_4a0 = uVar4;
                local_498 = iVar3;
                iVar3 = FUN_1403868f0(local_468,uVar8,uVar7,0);
                if (iVar3 == 0) {
                  local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x4f3);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  (**(code **)(*param_1 + 0x348))(param_1,local_468,1);
                }
                FUN_1403867d0(local_468);
              }
            }
          }
        }
        else if (iVar3 == 5) {
          iVar3 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
          if (iVar3 - 0xaae61U < 99999) {
            return 0;
          }
          FUN_1403929b0(param_1 + -2);
        }
        else {
          if (iVar3 != 0x14) {
            if (iVar3 - 0x18U < 2) {
              return 0;
            }
            local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x51d);
            log_InlineLogERROR(&DAT_1406d9c10);
            return 0;
          }
          if (param_1[6] != 0) {
            plVar9 = (longlong *)
                     (**(code **)(*(longlong *)param_1[0xc] + 0x10))((longlong *)param_1[0xc],0xd);
            uVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
            cVar1 = FUN_1400222e0(param_1 + 0xd,uVar4);
            if (cVar1 != '\0') {
              plVar9 = (longlong *)FUN_14038c750(param_1 + 6);
              plVar10 = (longlong *)FUN_14038c750(param_1 + 6);
              uVar5 = (**(code **)(*plVar10 + 0x88))(plVar10);
              uVar6 = (**(code **)(*plVar9 + 0x80))(plVar9);
              if (uVar6 < uVar5) {
                plVar9 = (longlong *)
                         (**(code **)(*(longlong *)param_1[0xc] + 0x10))
                                   ((longlong *)param_1[0xc],10);
                iVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
                lVar11 = FUN_14038c750(param_1 + 6);
                local_4a8 = (char *)0x0;
                (**(code **)(*(longlong *)(lVar11 + 0x10) + 0x2e0))
                          ((longlong *)(lVar11 + 0x10),2,(longlong)iVar3,1);
                FUN_140386780(local_468);
                plVar9 = (longlong *)FUN_14038c750(param_1 + 6);
                uVar4 = (**(code **)(*plVar9 + 8))(plVar9);
                uVar7 = FUN_140388e30(param_1 + -2);
                uVar8 = (**(code **)(param_1[-2] + 8))(param_1 + -2);
                local_480 = 0;
                local_488 = 0;
                local_490 = 0;
                local_4a8 = (char *)((ulonglong)local_4a8 & 0xffffffffffffff00);
                local_4a0 = uVar4;
                local_498 = iVar3;
                iVar3 = FUN_1403868f0(local_468,uVar8,uVar7,0);
                if (iVar3 == 0) {
                  local_4a8 = (char *)CONCAT44(local_4a8._4_4_,0x504);
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  (**(code **)(*param_1 + 0x348))(param_1,local_468,1);
                }
                FUN_1403867d0(local_468);
              }
            }
          }
        }
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CMonster::helper_1403e8cf0  @1403e8cf0  [medium:callgraph-r1]  (orig: FUN_1403e8cf0)
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_1403e8cf0(undefined8 param_1,longlong *param_2,longlong *param_3)

{
  int iVar1;
  char cVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  ulonglong uVar8;
  float fVar9;
  longlong *local_res10;
  
  if ((param_2 != (longlong *)0x0) && (param_3 != (longlong *)0x0)) {
    cVar2 = (**(code **)(*param_2 + 0x188))(param_2);
    if (cVar2 == '\0') {
      uVar3 = (**(code **)(*param_2 + 200))(param_2);
      iVar4 = (**(code **)(*param_3 + 0xd0))(param_3);
      iVar5 = (**(code **)(*param_2 + 200))(param_2);
      fVar9 = DAT_140715a84;
      if (iVar5 != 0) {
        uVar6 = (**(code **)(*param_2 + 200))(param_2);
        uVar8 = (**(code **)(*param_2 + 0xc0))(param_2);
        fVar9 = (float)(((double)((uVar8 & 0xffffffff) / (ulonglong)uVar6) - _DAT_1406f9568) /
                        _DAT_1406f9568 + DAT_14075cb60);
      }
      iVar4 = (**(code **)(*param_2 + 0x300))
                        (param_2,(int)((float)(int)(((uVar3 >> 1) - iVar4) + 100) * fVar9));
      cVar2 = (**(code **)(*param_2 + 0x260))(param_2);
      if ((cVar2 != '\0') && (cVar2 = (**(code **)(*param_3 + 0x270))(param_3), cVar2 != '\0')) {
        iVar4 = MulDiv(iVar4,0xc,100);
      }
      local_res10 = (longlong *)0x0;
      iVar5 = 10;
      if (10 < iVar4) {
        iVar5 = iVar4;
      }
      iVar1 = 0x5a;
      if (iVar5 < 0x5a) {
        iVar1 = iVar5;
      }
      (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_res10);
      iVar4 = iVar1;
      if (local_res10 != (longlong *)0x0) {
        cVar2 = (**(code **)(*param_3 + 0x240))(param_3);
        if (cVar2 != '\0') {
          iVar5 = (**(code **)(local_res10[2] + 0x70))(local_res10 + 2);
          iVar7 = (**(code **)(*param_3 + 0x70))(param_3);
          if (0 < iVar5 - iVar7) {
            iVar4 = iVar1 + ((iVar5 - iVar7) / 5) * 10;
          }
          cVar2 = (**(code **)(local_res10[2] + 0x2d8))(local_res10 + 2,0xd);
          if (cVar2 != '\0') {
            iVar4 = 100;
          }
        }
        cVar2 = (**(code **)(local_res10[2] + 0x238))(local_res10 + 2);
        if (cVar2 != '\0') {
          (**(code **)(*local_res10 + 0x150))(local_res10,2000,"lev hit rate+: %d",iVar4 - iVar1);
        }
      }
    }
    else {
      iVar4 = (**(code **)(*param_2 + 400))(param_2);
    }
    iVar5 = tq::RandGet(100);
    return iVar4 <= iVar5;
  }
  return true;
}

// ==== CMonster::helper_1403e9210  @1403e9210  [medium:callgraph-r2]  (orig: FUN_1403e9210)
undefined8 FUN_1403e9210(undefined8 param_1,longlong *param_2,int param_3)

{
  char cVar1;
  longlong local_res10 [3];
  
  if (param_2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (0 < param_3) {
    local_res10[0] = 0;
    (**(code **)(*param_2 + 0x298))(param_2,0x1002,local_res10);
    if ((local_res10[0] != 0) && (cVar1 = FUN_14038bc80(), cVar1 != '\0')) {
      return 0;
    }
    return 1;
  }
  return 0;
}

// ==== CMonster::helper_1403e94c0  @1403e94c0  [medium:callgraph-r1]  (orig: FUN_1403e94c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403e94c0(longlong param_1,longlong *param_2,char param_3)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  longlong lVar6;
  undefined8 uVar7;
  undefined1 auStack_948 [32];
  undefined2 local_928;
  undefined2 local_920;
  undefined4 local_918;
  undefined4 local_910;
  longlong *local_908;
  longlong *local_900;
  ulonglong local_8f8;
  undefined4 local_8f0 [2];
  undefined8 local_8e8;
  undefined1 local_8d8 [1104];
  undefined1 local_488 [1104];
  ulonglong local_38;
  
  local_8e8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_948;
  if (*(int *)(param_1 + 8) == 0) {
    return 0;
  }
  if (param_2 == (longlong *)0x0) {
    if (param_3 != '\0') {
      *(undefined4 *)(param_1 + 8) = 0;
    }
    return 0;
  }
  lVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2b0))();
  if (lVar6 == 0) {
    cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x3d8))
                      (*(longlong **)(param_1 + 0x10),param_2,0);
    if (cVar1 == '\0') {
      if (param_3 != '\0') {
        *(undefined4 *)(param_1 + 8) = 0;
      }
      return 0;
    }
  }
  else {
    cVar1 = (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x3d8))((longlong *)(lVar6 + 0x10),param_2,0)
    ;
    if (cVar1 == '\0') {
      if (param_3 != '\0') {
        *(undefined4 *)(param_1 + 8) = 0;
      }
      return 0;
    }
  }
  cVar1 = (**(code **)(*param_2 + 0x278))(param_2);
  if ((((cVar1 != '\0') &&
       (cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x278))(), cVar1 == '\0')) &&
      (cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x260))(), cVar1 == '\0')) &&
     ((cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x188))(), cVar1 == '\0' &&
      (cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x268))(), cVar1 == '\0')))) {
    if (param_3 != '\0') {
      *(undefined4 *)(param_1 + 8) = 0;
    }
    return 0;
  }
  cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x240))();
  if (cVar1 == '\0') {
    local_8f8 = local_8f8 & 0xffffffff00000000;
    local_8f0[0] = 0;
    (**(code **)(*param_2 + 0x2f0))(param_2,&local_8f8,local_8f0);
    iVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x158))
                      (*(longlong **)(param_1 + 0x10),local_8f8 & 0xffffffff,local_8f0[0]);
  }
  else {
    lVar6 = **(longlong **)(param_1 + 0x10);
    uVar7 = (**(code **)(*param_2 + 0x2a0))(param_2);
    iVar2 = (**(code **)(lVar6 + 0x150))(*(undefined8 *)(param_1 + 0x10),uVar7);
  }
  lVar6 = **(longlong **)(param_1 + 0x10);
  uVar3 = (**(code **)(*param_2 + 0x3f0))(param_2);
  iVar4 = (**(code **)(lVar6 + 1000))(*(undefined8 *)(param_1 + 0x10),uVar3);
  if (((iVar4 < 3) &&
      (iVar5 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))(),
      iVar5 - 1000000U < 0xee5be5c0)) &&
     (iVar5 = (**(code **)(*param_2 + 0x10))(param_2), iVar5 - 0xaae61U < 99999)) {
    local_8f8 = 0;
    cVar1 = (**(code **)(*param_2 + 0x298))(param_2,0x1002,&local_8f8);
    if (((cVar1 != '\0') && (local_8f8 != 0)) && (cVar1 = FUN_140388010(local_8f8,2), cVar1 != '\0')
       ) {
      iVar4 = 3;
    }
  }
  if (iVar4 < iVar2) {
    cVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2d8))
                      (*(longlong **)(param_1 + 0x10),0x28);
    if (cVar1 == '\0') {
      if (param_3 != '\0') {
        *(undefined4 *)(param_1 + 8) = 0;
      }
      return 0;
    }
    cVar1 = (**(code **)(*param_2 + 0x240))(param_2);
    if (cVar1 == '\0') {
      if (param_3 != '\0') {
        *(undefined4 *)(param_1 + 8) = 0;
      }
      return 0;
    }
  }
  local_908 = (longlong *)0x0;
  local_900 = (longlong *)0x0;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x298))
            (*(longlong **)(param_1 + 0x10),0x1001,&local_908);
  (**(code **)(*param_2 + 0x298))(param_2,0x1001,&local_900);
  if ((local_908 != (longlong *)0x0) && (local_900 != (longlong *)0x0)) {
    cVar1 = FUN_140179190();
    if (cVar1 != '\0') {
      return 0;
    }
    FUN_1401791d0(local_908);
    cVar1 = FUN_14017ac40(local_908);
    if ((cVar1 != '\0') || (cVar1 = FUN_14017ac40(local_900), cVar1 != '\0')) {
      return 0;
    }
    FUN_14017ac80(local_908);
    FUN_14017ac80(local_900);
    FUN_140362560(local_488);
    FUN_140362560(local_8d8);
    uVar3 = (**(code **)(*local_908 + 8))();
    local_910 = 0;
    local_918 = 0;
    local_920 = 0x9e;
    local_928 = 0;
    iVar2 = FUN_140362620(local_488,uVar3,0,0);
    if (iVar2 != 0) {
      uVar3 = (**(code **)(*local_900 + 8))();
      local_910 = 0;
      local_918 = 0;
      local_920 = 0x9e;
      local_928 = 0;
      iVar2 = FUN_140362620(local_8d8,uVar3,0,0);
      if (iVar2 != 0) {
        (**(code **)(local_908[2] + 0x350))(local_908 + 2,local_488);
        (**(code **)(local_900[2] + 0x350))(local_900 + 2,local_8d8);
      }
    }
    FUN_1403625e0(local_8d8);
    FUN_1403625e0(local_488);
  }
  return 1;
}

// ==== CMonster::helper_1403eb280  @1403eb280  [medium:callgraph-r1]  (orig: FUN_1403eb280)
ulonglong FUN_1403eb280(longlong param_1,undefined8 param_2)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong *plVar3;
  ulonglong uVar4;
  undefined8 uVar5;
  longlong *local_res8;
  
  lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
  if (*(longlong *)(lVar2 + 0x88) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar3 = (longlong *)
           (**(code **)(**(longlong **)(lVar2 + 0x88) + 0x20))
                     (*(longlong **)(lVar2 + 0x88),*(undefined4 *)(param_1 + 8));
  uVar4 = 0;
  if ((plVar3 == (longlong *)0x0) ||
     (uVar4 = (**(code **)(*plVar3 + 0x220))(plVar3), (char)uVar4 == '\0')) {
    *(undefined4 *)(param_1 + 8) = 0;
  }
  else {
    local_res8 = (longlong *)0x0;
    uVar4 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x298))
                      (*(longlong **)(param_1 + 0x10),0x1001,&local_res8);
    if (((char)uVar4 != '\0') &&
       (uVar4 = (**(code **)(local_res8[2] + 0x220))(local_res8 + 2), (char)uVar4 != '\0')) {
      uVar1 = (**(code **)(*local_res8 + 8))();
      uVar5 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      uVar5 = FUN_1400877e0(uVar5);
      uVar4 = FUN_1402f2e70(uVar5,uVar1,plVar3,param_2);
      return uVar4;
    }
  }
  return uVar4 & 0xffffffffffffff00;
}

// ==== CMonster::helper_1403eb390  @1403eb390  [medium:callgraph-r2]  (orig: FUN_1403eb390)
ulonglong FUN_1403eb390(longlong param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined8 uVar5;
  ulonglong uVar6;
  longlong *plVar7;
  
  *param_2 = 0;
  *param_3 = 0;
  if ((*(longlong *)(param_1 + 0x10) == 0) || (iVar3 = *(int *)(param_1 + 8), iVar3 == 0)) {
    uVar6 = 0;
  }
  else {
    plVar7 = *(longlong **)(param_1 + 0x10);
    uVar1 = (**(code **)(*plVar7 + 0x48))(plVar7);
    uVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
    uVar5 = (**(code **)(*plVar7 + 0x160))(plVar7);
    uVar5 = FUN_1402c8700(uVar5,uVar2,uVar1,iVar3);
    uVar6 = FUN_1403e94c0(param_1,uVar5,0);
    if ((int)uVar6 != 0) {
      plVar7 = *(longlong **)(param_1 + 0x10);
      uVar1 = (**(code **)(*plVar7 + 0x48))(plVar7);
      uVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
      uVar5 = (**(code **)(*plVar7 + 0x160))(plVar7);
      plVar7 = (longlong *)FUN_1402c8700(uVar5,uVar2,uVar1,*(undefined4 *)(param_1 + 8));
      if (plVar7 == (longlong *)0x0) {
        *(undefined4 *)(param_1 + 8) = 0;
        uVar6 = 0;
      }
      else {
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))();
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x48))();
        iVar3 = FUN_1403e8cf0(param_1,*(undefined8 *)(param_1 + 0x10),plVar7);
        if (iVar3 == 0) {
          iVar3 = (**(code **)(*plVar7 + 0x78))(plVar7);
          uVar1 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x3a8))
                            (*(longlong **)(param_1 + 0x10),plVar7,param_3,0);
          *param_2 = uVar1;
          (**(code **)(*plVar7 + 0x78))(plVar7);
          iVar4 = (**(code **)(*plVar7 + 0x78))(plVar7);
          uVar6 = (ulonglong)(uint)(iVar3 - iVar4);
        }
        else {
          uVar6 = 0;
        }
      }
    }
  }
  return uVar6;
}

// ==== CMonster::helper_1403eb540  @1403eb540  [medium:callgraph-r1]  (orig: FUN_1403eb540)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1403eb540(longlong param_1,ulonglong param_2,int param_3,longlong *param_4)

{
  undefined8 *puVar1;
  bool bVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int iVar11;
  longlong *plVar12;
  longlong *plVar13;
  IStringManager *pIVar14;
  undefined8 uVar15;
  longlong lVar16;
  longlong lVar17;
  uint uVar18;
  int iVar19;
  undefined1 auStack_538 [32];
  ulonglong local_518;
  uint local_510;
  uint local_508;
  uint local_500;
  int local_4f8;
  uint local_4f4;
  longlong *local_4f0;
  longlong *local_4e8;
  longlong *local_4e0;
  uint local_4d8;
  int local_4d4;
  longlong local_4d0;
  longlong *local_4c8;
  longlong local_4c0;
  int local_4b8;
  int local_4b4;
  longlong local_4b0 [3];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4b0[1] = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  iVar19 = (int)param_2;
  param_2 = param_2 & 0xffffffff;
  local_4f8 = iVar19;
  local_4d4 = iVar19;
  local_4d0 = param_1;
  local_4c8 = param_4;
  local_4c0 = param_1;
  local_4b4 = param_3;
  plVar12 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x2b0))();
  if (param_4 == (longlong *)0x0) {
    return 0;
  }
  local_4b0[0] = 0;
  local_4e0 = plVar12;
  (**(code **)(*param_4 + 0x298))(param_4,0x1002,local_4b0);
  if ((local_4b0[0] != 0) &&
     (cVar3 = (**(code **)(*(longlong *)(local_4b0[0] + 0x10) + 0x288))(), cVar3 != '\0')) {
    local_518 = 0;
    (**(code **)(*(longlong *)(local_4b0[0] + 0x10) + 0x2e0))
              ((longlong *)(local_4b0[0] + 0x10),0,0,2);
  }
  (**(code **)(*param_4 + 0x298))(param_4,0x1040,&local_4f0);
  plVar13 = local_4f0;
  uVar7 = 0;
  if ((plVar12 != (longlong *)0x0) && (local_4f0 != (longlong *)0x0)) {
    iVar4 = (**(code **)(*(longlong *)local_4f0[0xc] + 0x10))((longlong *)local_4f0[0xc],4);
    if ((iVar4 == 10) ||
       (iVar4 = (**(code **)(*(longlong *)plVar13[0xc] + 0x10))((longlong *)plVar13[0xc],4),
       iVar4 == 0x2e)) {
      bVar2 = true;
    }
    else {
      bVar2 = false;
    }
    if (bVar2) {
      iVar4 = (**(code **)(*(longlong *)local_4f0[0xc] + 0x10))((longlong *)local_4f0[0xc],4);
      if (iVar4 == 10) {
        plVar13 = (longlong *)FUN_140087ed0();
        lVar16 = *plVar13;
        uVar5 = (**(code **)(*local_4f0 + 8))();
        uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
        (**(code **)(lVar16 + 0x308))(plVar13,uVar6,uVar5,param_2);
        param_1 = local_4c0;
      }
      else {
        iVar4 = (**(code **)(*(longlong *)local_4f0[0xc] + 0x10))((longlong *)local_4f0[0xc],4);
        if (iVar4 == 0x2e) {
          if ((0 < iVar19) &&
             (plVar13 = (longlong *)CurrentInstanceGet(), plVar13 != (longlong *)0x0)) {
            uVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
            cVar3 = FUN_14008b330(uVar15);
            if (cVar3 == '\0') {
              local_4e8 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x1c);
              if (local_4e8 != (longlong *)0x0) {
                lVar16 = *local_4e8;
                uVar5 = (**(code **)(*local_4f0 + 8))();
                uVar6 = (**(code **)(plVar12[2] + 0x170))(plVar12 + 2);
                (**(code **)(lVar16 + 0x38))(local_4e8,uVar6,uVar5,param_2);
                param_1 = local_4c0;
              }
            }
            else {
              local_4e8 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x25);
              if (local_4e8 != (longlong *)0x0) {
                lVar16 = *local_4e8;
                uVar5 = (**(code **)(*local_4f0 + 8))();
                uVar6 = (**(code **)(*plVar12 + 8))(plVar12);
                (**(code **)(lVar16 + 0x70))(local_4e8,uVar6,uVar5,param_2);
              }
            }
          }
        }
        else {
          (**(code **)(*(longlong *)local_4f0[0xc] + 0x10))((longlong *)local_4f0[0xc],4);
          (**(code **)(*local_4f0 + 8))();
          log_InlineLogERROR("CBattleSystem::ProcessAfterAttack. Error Npc Type ID[%u] TYPE[%u]");
        }
      }
    }
    if ((((local_4f0 != (longlong *)0x0) &&
         (iVar4 = (**(code **)(*(longlong *)local_4f0[0xc] + 0x10))((longlong *)local_4f0[0xc],4),
         iVar4 == 0x28)) && (plVar13 = (longlong *)CurrentInstanceGet(), plVar13 != (longlong *)0x0)
        ) && (plVar13 = (longlong *)(**(code **)(*plVar13 + 0x20))(plVar13,0x18),
             plVar13 != (longlong *)0x0)) {
      lVar16 = *plVar13;
      uVar5 = (**(code **)(*plVar12 + 8))(plVar12);
      (**(code **)(lVar16 + 0x58))(plVar13,uVar5,param_2);
    }
  }
  cVar3 = (**(code **)(*param_4 + 0x240))(param_4);
  if ((cVar3 != '\0') ||
     ((local_4f0 != (longlong *)0x0 && (cVar3 = FUN_14015ff50(), cVar3 != '\0')))) {
    local_4b8 = 0;
    local_4f4 = 0;
    cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
    if (cVar3 == '\0') {
      iVar4 = (**(code **)(*param_4 + 0x80))(param_4);
      uVar18 = (uint)(iVar4 * 5) / 100;
      local_4f4 = uVar18;
      plVar13 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x160))();
      iVar4 = (**(code **)(*plVar13 + 8))(plVar13);
      if (iVar4 == 0x40f) {
        uVar18 = uVar7;
      }
      local_4f4 = uVar18;
      cVar3 = FUN_1403e9210(param_1,param_4,param_2);
      if (cVar3 == '\0') {
        uVar18 = 0;
      }
      uVar7 = uVar18;
      local_4f4 = uVar18;
      local_4d8 = uVar18;
      if (((plVar12 != (longlong *)0x0) &&
          ((local_4f0 == (longlong *)0x0 || (cVar3 = FUN_14015ff50(), cVar3 == '\0')))) &&
         (local_4e8 = (longlong *)FUN_140118320(), local_4e8 != (longlong *)0x0)) {
        lVar16 = *local_4e8;
        uVar7 = (**(code **)(*param_4 + 0x48))(param_4);
        uVar5 = (**(code **)(*param_4 + 0x40))(param_4);
        uVar6 = (**(code **)(*param_4 + 0x168))(param_4);
        uVar8 = (**(code **)(*param_4 + 0x70))(param_4);
        uVar9 = (**(code **)(*param_4 + 0x10))(param_4);
        uVar10 = (**(code **)(*local_4e0 + 8))();
        plVar12 = local_4e8;
        local_500 = local_4d8;
        local_510 = uVar5;
        local_508 = uVar7;
        local_518._0_4_ = uVar6;
        (**(code **)(lVar16 + 0x18))(local_4e8,uVar10,uVar9,uVar8);
        puVar1 = (undefined8 *)*plVar12;
        uVar7 = (**(code **)(*param_4 + 0x48))(param_4);
        uVar5 = (**(code **)(*param_4 + 0x40))(param_4);
        uVar6 = (**(code **)(*param_4 + 0x168))(param_4);
        uVar8 = (**(code **)(*param_4 + 0x70))(param_4);
        plVar12 = local_4e0;
        uVar9 = (**(code **)(*local_4e0 + 8))(local_4e0);
        local_518 = CONCAT44(local_518._4_4_,uVar5);
        local_510 = uVar7;
        cVar3 = (*(code *)*puVar1)(local_4e8,uVar9,uVar8,uVar6);
        param_1 = local_4c0;
        iVar19 = local_4d4;
        uVar7 = local_4d8;
        if (cVar3 != '\0') {
          local_4f4 = local_4d8 * 2;
          local_4b8 = 1;
          uVar7 = local_4f4;
        }
      }
      if ((((plVar12 != (longlong *)0x0) && (*(int *)((longlong)plVar12 + 0xb2c) != 0)) &&
          (0 < (int)uVar7)) && (iVar4 = tq::RandGet(1000), iVar4 < 5)) {
        uVar7 = uVar7 * 10;
        local_4f4 = uVar7;
        pIVar14 = theInstance();
        lVar16 = *plVar12;
        uVar15 = (*(code *)**(undefined8 **)pIVar14)(pIVar14,"STR_LUCK_EXP");
        (**(code **)(lVar16 + 0x150))(plVar12,0x7d5,uVar15);
        FUN_14037dfb0(local_498);
        uVar5 = (**(code **)(*plVar12 + 8))(plVar12);
        iVar4 = FUN_14037e0a0(local_498,10,"LuckyGuy",uVar5);
        if (iVar4 == 0) {
          local_518 = CONCAT44(local_518._4_4_,0x732);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          (**(code **)(plVar12[2] + 0x350))(plVar12 + 2,local_498);
        }
        FUN_14037e030(local_498);
      }
      iVar19 = iVar19 + uVar7;
      local_4f8 = iVar19;
    }
    if ((local_4f0 != (longlong *)0x0) && (cVar3 = FUN_14015ff50(), cVar3 != '\0')) {
      cVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x260))();
      if (cVar3 != '\0') {
        iVar19 = iVar19 / 2;
        local_4f8 = iVar19;
      }
      iVar19 = MulDiv(iVar19,10,100);
      local_4f8 = iVar19;
      if (iVar19 < 2) {
        iVar19 = 1;
        local_4f8 = 1;
      }
    }
    iVar4 = FUN_14031d7e0(*(undefined8 *)(param_1 + 0x10),param_4);
    iVar11 = 0;
    if (plVar12 != (longlong *)0x0) {
      iVar11 = FUN_140180f80(plVar12);
    }
    local_4f8 = iVar19 + ((iVar11 + iVar4) * iVar19) / 100;
    local_4f8 = FUN_14031cc80(*(undefined8 *)(param_1 + 0x10),param_4,local_4f8);
    param_2 = (ulonglong)local_4f8;
    cVar3 = FUN_1403e9210(param_1,param_4,local_4f8);
    if (cVar3 != '\0') {
      local_4e8 = (longlong *)0x0;
      (**(code **)(*param_4 + 0x298))(param_4,0x1001,&local_4e8);
      if (local_4e8 == (longlong *)0x0) {
        local_518 = CONCAT71(local_518._1_7_,1);
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2f8))
                  (*(longlong **)(param_1 + 0x10),param_2,1);
      }
      else {
        local_518 = (ulonglong)local_518._1_7_ << 8;
        (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2f8))
                  (*(longlong **)(param_1 + 0x10),param_2,1);
      }
    }
    iVar19 = FUN_14031cc80(*(undefined8 *)(param_1 + 0x10),param_4,uVar7);
    local_4f4 = iVar19;
    cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
    if (((cVar3 == '\0') && (0 < iVar19)) &&
       ((plVar12 != (longlong *)0x0 && (cVar3 = FUN_140382350(plVar12), cVar3 == '\0')))) {
      plVar12 = (longlong *)(**(code **)(**(longlong **)(param_1 + 0x10) + 0x160))();
      iVar4 = (**(code **)(*plVar12 + 8))(plVar12);
      if (iVar4 != 0x40f) {
        if (local_4b8 == 0) {
          pIVar14 = theInstance();
          lVar16 = **(longlong **)(param_1 + 0x10);
          uVar15 = (*(code *)**(undefined8 **)pIVar14)(pIVar14,"STR_KILLING_EXPERIENCE");
          (**(code **)(lVar16 + 0x358))(*(undefined8 *)(param_1 + 0x10),uVar15,iVar19);
        }
        else {
          pIVar14 = theInstance();
          lVar16 = **(longlong **)(param_1 + 0x10);
          uVar15 = (*(code *)**(undefined8 **)pIVar14)(pIVar14,"STR_KILLING_EXPEX");
          (**(code **)(lVar16 + 0x358))(*(undefined8 *)(param_1 + 0x10),uVar15,iVar19);
        }
      }
    }
  }
  uVar15 = 0;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x3a0))
            (*(longlong **)(param_1 + 0x10),param_2 & 0xffffffff,local_4b4);
  local_4e0 = (longlong *)0x0;
  cVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x298))
                    (*(longlong **)(param_1 + 0x10),0x1001,&local_4e0);
  if (cVar3 != '\0') {
    cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
    if (cVar3 == '\0') {
      uVar5 = (**(code **)(*param_4 + 0x48))(param_4);
      uVar6 = (**(code **)(*param_4 + 0x40))(param_4);
      uVar8 = (**(code **)(*param_4 + 0x10))(param_4);
      FUN_14016e5f0(local_4e0,uVar8,uVar6,uVar5);
    }
    else {
      uVar5 = (**(code **)(*param_4 + 0x48))(param_4);
      uVar6 = (**(code **)(*param_4 + 0x40))(param_4);
      uVar8 = (**(code **)(*param_4 + 0x10))(param_4);
      FUN_14016e5f0(local_4e0,uVar8,uVar6,uVar5);
      cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
      if (cVar3 == '\0') {
        return 1;
      }
      lVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      if (*(longlong *)(lVar16 + 0x100) == 0) {
        local_518 = CONCAT44(local_518._4_4_,0x144);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar15 = *(undefined8 *)(lVar16 + 0x100);
      }
      uVar5 = (**(code **)(*param_4 + 0x10))(param_4);
      uVar6 = (**(code **)(*local_4e0 + 8))();
      FUN_1402f2f30(uVar15,uVar6,uVar5);
      cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
      if (cVar3 == '\0') {
        return 1;
      }
    }
  }
  cVar3 = (**(code **)(*param_4 + 0x220))(param_4);
  if (cVar3 == '\0') {
    lVar16 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2b0))();
    if (((lVar16 != 0) && (cVar3 = FUN_14016e3f0(lVar16), cVar3 != '\0')) &&
       ((lVar16 = (**(code **)(*param_4 + 0x2b0))(param_4), lVar16 != 0 &&
        (((longlong *)(lVar16 + 0x10) == param_4 && (lVar16 = FUN_14016e430(lVar16), lVar16 != 0))))
       )) {
      lVar17 = **(longlong **)(param_1 + 0x10);
      cVar3 = (**(code **)(lVar17 + 0x260))(*(longlong **)(param_1 + 0x10));
      uVar15 = 1;
      if (cVar3 != '\0') {
        uVar15 = 7;
      }
      local_500 = 12000000;
      local_508 = local_508 & 0xffff0000;
      local_510 = local_510 & 0xffff0000;
      local_518 = local_518 & 0xffffffffffffff00;
      (**(code **)(lVar17 + 0x3c8))(*(undefined8 *)(param_1 + 0x10),lVar16 + 0x10,uVar15,0);
    }
    lVar16 = **(longlong **)(param_1 + 0x10);
    cVar3 = (**(code **)(lVar16 + 0x260))(*(longlong **)(param_1 + 0x10));
    uVar5 = 1;
    if (cVar3 != '\0') {
      uVar5 = 7;
    }
    local_500 = 13000000;
    local_508 = local_508 & 0xffff0000;
    local_510 = local_510 & 0xffff0000;
    local_518 = local_518 & 0xffffffffffffff00;
    (**(code **)(lVar16 + 0x3c8))(*(undefined8 *)(param_1 + 0x10),param_4,uVar5,0);
  }
  else {
    lVar16 = (**(code **)(*param_4 + 0x2b0))(param_4);
    lVar17 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2b0))();
    if (((lVar16 != 0) && (lVar17 != 0)) && (0 < local_4b4)) {
      FUN_1401bd2e0(lVar16,lVar17);
    }
  }
  return 1;
}

// ==== CMonster::helper_1403ec5d0  @1403ec5d0  [medium:callgraph-r1]  (orig: FUN_1403ec5d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_1403ec5d0(longlong param_1,undefined4 param_2)

{
  char cVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  longlong lVar9;
  longlong lVar10;
  longlong *plVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  undefined1 auStack_538 [32];
  uint local_518;
  undefined4 local_510;
  uint local_508;
  int local_500;
  uint local_4f8;
  undefined4 local_4f0;
  undefined4 local_4e8;
  undefined4 local_4e0;
  undefined1 local_4d8;
  undefined4 local_4c8;
  uint local_4c0 [5];
  int local_4ac;
  int local_4a8;
  int local_4a4;
  int local_4a0;
  uint local_498 [6];
  longlong local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  local_4c0[0] = 0;
  local_4c0[1] = 0;
  local_4c0[2] = 0;
  local_498[0] = 0;
  local_498[1] = 0;
  local_498[2] = 0;
  iVar13 = 0;
  local_498[4] = 0;
  plVar8 = *(longlong **)(param_1 + 0x10);
  local_4c0[4] = param_2;
  uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
  uVar4 = (**(code **)(*plVar8 + 0x40))(plVar8);
  uVar7 = (**(code **)(*plVar8 + 0x160))(plVar8);
  plVar8 = (longlong *)FUN_1402c8700(uVar7,uVar4,uVar3,*(undefined4 *)(param_1 + 8));
  if ((plVar8 != (longlong *)0x0) && (cVar1 = (**(code **)(*plVar8 + 0x220))(plVar8), cVar1 != '\0')
     ) {
    local_4c8 = *(undefined4 *)(param_1 + 8);
    iVar12 = 0;
    local_4ac = 0;
    local_4a0 = 0;
    uVar14 = 0;
    while (iVar6 = local_4a0, local_4a0 < 3) {
      if ((plVar8 != (longlong *)0x0) &&
         (cVar1 = (**(code **)(*plVar8 + 0x220))(plVar8), cVar1 != '\0')) {
        iVar12 = iVar12 + 1;
        local_4ac = iVar12;
      }
      iVar5 = FUN_1403eb390(param_1,local_4c0 + iVar6,local_498 + iVar6);
      iVar13 = iVar13 + iVar5;
      uVar14 = local_4c0[0];
      local_498[4] = iVar13;
      local_4a0 = iVar6 + 1;
    }
    lVar9 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x2b0))();
    local_480 = lVar9;
    lVar10 = (**(code **)(*plVar8 + 0x2b0))(plVar8);
    local_4a4 = 0;
    if ((lVar10 != 0) && (lVar9 != 0)) {
      iVar6 = FUN_14018ed10(lVar10);
      local_4a4 = FUN_14018eb30(local_480);
      local_4a4 = local_4a4 - iVar6;
    }
    iVar6 = local_4a4;
    FUN_140386780(local_468);
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    local_4d8 = 0;
    local_4e0 = 0;
    local_4e8 = 0;
    local_4f0 = 0;
    local_4f8 = local_498[0];
    local_510 = local_4c8;
    local_518 = local_518 & 0xffffff00;
    local_508 = uVar14;
    local_500 = iVar6;
    iVar5 = FUN_140386e00(local_468,uVar3,local_4c0[4],0);
    if (iVar5 == 0) {
      local_518 = 0x666;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      local_4a8 = 1;
      while (iVar5 = local_4a8, local_4a8 < iVar12) {
        local_4f8 = 0;
        local_500 = 0;
        local_508 = 0;
        local_510 = 0;
        local_518 = local_498[local_4a8];
        FUN_140387150(local_468,local_4c8,local_4c0[local_4a8],iVar6);
        local_4a8 = iVar5 + 1;
      }
      (**(code **)(**(longlong **)(param_1 + 0x10) + 0x348))
                (*(longlong **)(param_1 + 0x10),local_468,1);
    }
    plVar11 = (longlong *)FUN_1401181a0();
    lVar9 = *plVar11;
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    (**(code **)(lVar9 + 0x10))(plVar11,uVar3,0x17);
    uVar2 = FUN_1403eb540(param_1,iVar13,local_4c0[2] + local_4c0[1] + uVar14,plVar8);
    FUN_1403867d0(local_468);
    return uVar2;
  }
  *(undefined4 *)(param_1 + 8) = 0;
  return 1;
}

// ==== CMonster::helper_1403ec920  @1403ec920  [medium:callgraph-r0]  (orig: FUN_1403ec920)
ulonglong FUN_1403ec920(ulonglong param_1,undefined2 param_2)

{
  undefined1 uVar1;
  char cVar2;
  byte bVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  undefined8 uVar11;
  longlong *plVar12;
  ulonglong uVar13;
  longlong lVar14;
  longlong lVar15;
  longlong *plVar16;
  ulonglong local_res8;
  undefined2 local_res10;
  ulonglong local_res18;
  undefined4 local_res20 [2];
  undefined4 in_stack_ffffffffffffff98;
  undefined2 uVar17;
  longlong *local_58;
  longlong *local_50;
  longlong *local_48;
  undefined8 local_40;
  
  uVar17 = (undefined2)((uint)in_stack_ffffffffffffff98 >> 0x10);
  local_40 = 0xfffffffffffffffe;
  if ((*(longlong *)(param_1 + 0x10) == 0) || (iVar9 = *(int *)(param_1 + 8), iVar9 == 0)) {
    return 0;
  }
  plVar12 = *(longlong **)(param_1 + 0x10);
  local_res8 = param_1;
  local_res10 = param_2;
  uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
  uVar7 = (**(code **)(*plVar12 + 0x40))(plVar12);
  uVar11 = (**(code **)(*plVar12 + 0x160))(plVar12);
  plVar12 = (longlong *)FUN_1402c8700(uVar11,uVar7,uVar6,iVar9);
  local_48 = plVar12;
  uVar13 = FUN_1403e94c0(param_1,plVar12,1);
  if ((int)uVar13 == 0) {
    return uVar13;
  }
  if (plVar12 == (longlong *)0x0) {
    *(undefined4 *)(param_1 + 8) = 0;
    return 1;
  }
  local_res18 = local_res18 & 0xffffffffffffff00;
  local_50 = (longlong *)0x0;
  (**(code **)(**(longlong **)(param_1 + 0x10) + 0x298))
            (*(longlong **)(param_1 + 0x10),0x1001,&local_50);
  if (local_50 != (longlong *)0x0) {
    uVar1 = FUN_140161580();
    local_res18 = CONCAT71(local_res18._1_7_,uVar1);
  }
  local_58 = (longlong *)0x0;
  (**(code **)(*plVar12 + 0x298))(plVar12,0x1001,&local_58);
  if ((((local_50 != (longlong *)0x0) && (cVar2 = FUN_140167b70(), cVar2 != '\0')) &&
      (local_58 != (longlong *)0x0)) && (cVar2 = FUN_140167b70(), cVar2 == '\0')) {
    uVar6 = (**(code **)(local_58[2] + 0x168))();
    uVar4 = (**(code **)(local_58[2] + 0x40))();
    uVar5 = (**(code **)(local_58[2] + 0x48))();
    plVar12 = (longlong *)FUN_140087ed0();
    lVar14 = *plVar12;
    uVar7 = (**(code **)(*local_50 + 8))();
    uVar8 = (**(code **)(*local_58 + 8))();
    (**(code **)(lVar14 + 0x2d8))(plVar12,uVar8,uVar7,uVar6,CONCAT22(uVar17,uVar4),uVar5);
    plVar12 = local_48;
  }
  uVar11 = 0;
  cVar2 = FUN_1403e9290(plVar12);
  if (cVar2 != '\0') {
    lVar14 = **(longlong **)(param_1 + 0x10);
    uVar6 = (**(code **)(*plVar12 + 0x10))(plVar12);
    (**(code **)(lVar14 + 0x3f8))(*(undefined8 *)(param_1 + 0x10),uVar6,0,0,2);
    plVar12 = (longlong *)FUN_1401181a0();
    lVar14 = *plVar12;
    uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    (**(code **)(lVar14 + 0x10))(plVar12,uVar6,0x17);
    return 1;
  }
  local_res20[0] = 0;
  cVar2 = FUN_1403eb280(param_1,local_res20);
  if (cVar2 != '\0') {
    bVar3 = FUN_1403ec5d0(param_1,local_res20[0]);
    return (ulonglong)bVar3;
  }
  cVar2 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x390))
                    (*(longlong **)(param_1 + 0x10),plVar12);
  if (cVar2 == '\0') {
    lVar14 = *plVar12;
    uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    cVar2 = (**(code **)(lVar14 + 0x398))(plVar12,uVar6,0,0);
    if (cVar2 != '\0') {
      return 1;
    }
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x40))();
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x48))();
    if (((char)local_res18 == '\0') &&
       (iVar9 = FUN_1403e8cf0(param_1,*(undefined8 *)(param_1 + 0x10),plVar12), iVar9 != 0)) {
      lVar14 = **(longlong **)(param_1 + 0x10);
      uVar6 = (**(code **)(*plVar12 + 0x10))(plVar12);
      (**(code **)(lVar14 + 0x3f8))(*(undefined8 *)(param_1 + 0x10),uVar6,0,0,0);
      plVar12 = (longlong *)FUN_1401181a0();
      lVar14 = *plVar12;
      uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
      (**(code **)(lVar14 + 0x10))(plVar12,uVar6,0x17);
      return 1;
    }
    if ((local_50 != (longlong *)0x0) && (*(byte *)((longlong)local_50 + 0xeee) / 10 == 8)) {
      lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x18));
      if (*(longlong *)(lVar14 + 0x100) == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        uVar11 = *(undefined8 *)(lVar14 + 0x100);
      }
      uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
      cVar2 = FUN_1402f2850(uVar11,local_res10,uVar6,*(undefined4 *)(param_1 + 8));
      if (cVar2 != '\0') {
        return 1;
      }
    }
    iVar9 = (**(code **)(*plVar12 + 0x78))(plVar12);
    local_res18 = 0;
    (**(code **)(**(longlong **)(param_1 + 0x10) + 0x298))
              (*(longlong **)(param_1 + 0x10),0x1002,&local_res18);
    local_res8 = local_res8 & 0xffffffff00000000;
    if (((local_res18 == 0) || (cVar2 = FUN_140388010(local_res18,2), cVar2 == '\0')) ||
       (lVar14 = (**(code **)(*(longlong *)(local_res18 + 0x10) + 0x2b0))(), lVar14 == 0)) {
      uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x3a8))
                        (*(longlong **)(param_1 + 0x10),plVar12,&local_res8,0);
    }
    else {
      lVar15 = (**(code **)(*(longlong *)(local_res18 + 0x10) + 0x2b0))();
      lVar14 = *(longlong *)(lVar15 + 0x10);
      uVar6 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
      uVar6 = (**(code **)(lVar14 + 0x3a8))((longlong *)(lVar15 + 0x10),plVar12,&local_res8,uVar6);
    }
    (**(code **)(*plVar12 + 0x78))(plVar12);
    iVar10 = (**(code **)(*plVar12 + 0x78))(plVar12);
    lVar14 = **(longlong **)(param_1 + 0x10);
    uVar7 = (**(code **)(*plVar12 + 0x10))(plVar12);
    (**(code **)(lVar14 + 0x3f8))
              (*(undefined8 *)(param_1 + 0x10),uVar7,uVar6,local_res8 & 0xffffffff,0);
    plVar16 = (longlong *)FUN_1401181a0();
    lVar14 = *plVar16;
    uVar7 = (**(code **)(**(longlong **)(param_1 + 0x10) + 0x10))();
    (**(code **)(lVar14 + 0x10))(plVar16,uVar7,0x17);
    bVar3 = FUN_1403eb540(param_1,iVar9 - iVar10,uVar6,plVar12);
    return (ulonglong)bVar3;
  }
  return 1;
}

// ==== CMonster::helper_140498a50  @140498a50  [medium:callgraph-r3]  (orig: FUN_140498a50)
undefined8 FUN_140498a50(longlong param_1,longlong *param_2,undefined4 *param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong *plVar4;
  char cVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  longlong *plVar9;
  longlong lVar10;
  
  if ((param_2 == (longlong *)0x0) || (*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0xa88) != 0))
  {
    return 0;
  }
  plVar9 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  plVar1 = *(longlong **)(param_1 + 8);
  do {
    plVar2 = *(longlong **)(param_1 + 0x38);
    if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar1))
    {
      _invalid_parameter_noinfo();
    }
    if (plVar2 == plVar9) {
      return 0;
    }
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (plVar9 == *(longlong **)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar10 = plVar9[4];
    if (lVar10 != 0) {
      iVar6 = FUN_140418c50(lVar10,0x66);
      iVar7 = FUN_140418c50(lVar10,0x70);
      if (iVar6 == 0x37) {
        iVar6 = FUN_140418c50(lVar10,0x7a);
        if (iVar6 != 0) {
          uVar8 = FUN_140418c50(lVar10,0x7a);
          cVar5 = FUN_140482af0(*(undefined8 *)(param_1 + 0x1c8),uVar8,0);
          if (cVar5 == '\0') goto LAB_140498bc8;
        }
        cVar5 = (**(code **)(*param_2 + 0x298))(param_2,0x1001);
        if ((cVar5 != '\0') ||
           ((cVar5 = (**(code **)(*param_2 + 0x298))(param_2,0x1002), cVar5 != '\0' &&
            (iVar6 = (**(code **)(lRam0000000000000000 + 8))(), iVar6 - 0xaae61U < 99999)))) {
          iVar7 = iVar7 / 3;
        }
        iVar6 = tq::RandGet(100);
        if (iVar6 < iVar7) {
          uVar8 = FUN_140418c50(lVar10,2);
          *param_3 = uVar8;
          uVar3 = *(undefined8 *)(param_1 + 0x90);
          *(longlong *)(param_1 + 0x90) = lVar10;
          uVar8 = (**(code **)(*param_2 + 0x10))(param_2);
          *(undefined4 *)(param_1 + 0x98) = uVar8;
          uVar8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x40))();
          *(undefined4 *)(param_1 + 0x9c) = uVar8;
          uVar8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x48))();
          *(undefined4 *)(param_1 + 0xa0) = uVar8;
          FUN_1404913c0(param_1,1);
          *(undefined8 *)(param_1 + 0x90) = uVar3;
          return 1;
        }
      }
    }
LAB_140498bc8:
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar9 + 0x29) == '\0') {
      plVar2 = (longlong *)plVar9[2];
      if (*(char *)((longlong)plVar2 + 0x29) == '\0') {
        cVar5 = *(char *)(*plVar2 + 0x29);
        plVar9 = plVar2;
        plVar2 = (longlong *)*plVar2;
        while (cVar5 == '\0') {
          cVar5 = *(char *)(*plVar2 + 0x29);
          plVar9 = plVar2;
          plVar2 = (longlong *)*plVar2;
        }
      }
      else {
        cVar5 = *(char *)(plVar9[1] + 0x29);
        plVar4 = (longlong *)plVar9[1];
        plVar2 = plVar9;
        while ((plVar9 = plVar4, cVar5 == '\0' && (plVar2 == (longlong *)plVar9[2]))) {
          cVar5 = *(char *)(plVar9[1] + 0x29);
          plVar4 = (longlong *)plVar9[1];
          plVar2 = plVar9;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  } while( true );
}

// ==== CMonster::helper_1404a1a60  @1404a1a60  [medium:callgraph-r3]  (orig: FUN_1404a1a60)
undefined4 FUN_1404a1a60(longlong param_1,int param_2)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  
  if (param_2 == 0) {
    return 0;
  }
  lVar4 = FUN_14048b5f0(param_1,0x2bde);
  if (lVar4 == 0) {
    return 0;
  }
  iVar2 = FUN_140418c50(lVar4,0x7a);
  if (iVar2 != 0) {
    uVar3 = FUN_140418c50(lVar4,0x7a);
    cVar1 = FUN_140482af0(*(undefined8 *)(param_1 + 0x1c8),uVar3,0);
    if (cVar1 == '\0') {
      return 0;
    }
  }
  *(longlong *)(param_1 + 0x90) = lVar4;
  *(int *)(param_1 + 0x98) = param_2;
  FUN_14049e170(param_1,0);
  return 1;
}

// ==== CMonster::helper_1404b6740  @1404b6740  [medium:callgraph-r3]  (orig: FUN_1404b6740)
undefined8 FUN_1404b6740(longlong param_1)

{
  longlong *plVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  void *pvVar8;
  void *pvVar9;
  longlong *plVar10;
  char cVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  int iVar15;
  undefined4 uVar16;
  int iVar17;
  int iVar18;
  ulonglong uVar19;
  longlong lVar20;
  undefined8 uVar21;
  longlong *plVar22;
  ulonglong uVar23;
  ulonglong uVar24;
  uint uVar25;
  longlong lVar27;
  longlong *plVar28;
  ulonglong *local_res8;
  ulonglong *local_res10;
  undefined8 local_res18;
  longlong *local_res20;
  undefined8 in_stack_fffffffffffffd78;
  ulonglong *local_268 [3];
  undefined8 *local_250;
  undefined8 *local_248;
  longlong local_240;
  ulonglong *local_238 [3];
  undefined4 *local_220;
  undefined4 *local_218;
  longlong local_210;
  ulonglong *local_208 [3];
  int *local_1f0;
  int *local_1e8;
  longlong local_1e0;
  ulonglong *local_1d8 [3];
  undefined4 *local_1c0;
  undefined4 *local_1b8;
  longlong local_1b0;
  ulonglong *local_1a8 [3];
  undefined4 *local_190;
  undefined4 *local_188;
  longlong local_180;
  ulonglong *local_178 [3];
  void *local_160;
  longlong local_158;
  undefined8 local_150;
  longlong *local_148;
  ulonglong local_140;
  longlong *local_138 [3];
  longlong *local_120;
  longlong *local_118;
  undefined8 local_110;
  longlong *local_108;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  ulonglong *puVar26;
  
  uVar16 = (undefined4)((ulonglong)in_stack_fffffffffffffd78 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar21 = 0;
  }
  else {
    uVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x40))();
    uVar13 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x48))();
    local_res8 = operator_new(8);
    puVar26 = (ulonglong *)0x0;
    local_268[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_268;
      local_268[0] = local_res8;
    }
    local_250 = (undefined8 *)0x0;
    local_248 = (undefined8 *)0x0;
    local_240 = 0;
    local_res10 = local_res8;
    local_res8 = operator_new(8);
    local_238[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_238;
      local_238[0] = local_res8;
    }
    local_220 = (undefined4 *)0x0;
    local_218 = (undefined4 *)0x0;
    local_210 = 0;
    local_res10 = local_res8;
    local_res8 = operator_new(8);
    local_1d8[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_1d8;
      local_1d8[0] = local_res8;
    }
    local_1c0 = (undefined4 *)0x0;
    local_1b8 = (undefined4 *)0x0;
    local_1b0 = 0;
    local_res10 = local_res8;
    local_res8 = operator_new(8);
    local_1a8[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_1a8;
      local_1a8[0] = local_res8;
    }
    local_190 = (undefined4 *)0x0;
    local_188 = (undefined4 *)0x0;
    local_180 = 0;
    local_res10 = local_res8;
    local_res8 = operator_new(8);
    local_208[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_208;
      local_208[0] = local_res8;
    }
    local_1f0 = (int *)0x0;
    local_1e8 = (int *)0x0;
    local_1e0 = 0;
    local_res10 = local_res8;
    local_res8 = operator_new(8);
    local_178[0] = puVar26;
    if (local_res8 != (ulonglong *)0x0) {
      *local_res8 = (ulonglong)local_178;
      local_178[0] = local_res8;
    }
    local_160 = (void *)0x0;
    local_158 = 0;
    local_150 = 0;
    local_res10 = local_res8;
    uVar14 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x72);
    FUN_140480930(uVar12,uVar13,*(undefined4 *)(param_1 + 0x9c),*(undefined4 *)(param_1 + 0xa0),
                  CONCAT44(uVar16,uVar14),local_178);
    local_res10 = (ulonglong *)((ulonglong)local_res10 & 0xffffffff00000000);
    uVar19 = local_158 - (longlong)local_160 >> 3;
    local_140 = 0;
    if (0 < (int)uVar19) {
      do {
        uVar23 = local_140;
        iVar17 = (int)puVar26;
        if (uVar19 <= local_140) {
          _invalid_parameter_noinfo();
        }
        plVar1 = *(longlong **)((longlong)local_160 + uVar23 * 8);
        local_res18 = plVar1;
        lVar20 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))();
        iVar18 = (int)plVar1;
        if ((((-1 < iVar18) &&
             (iVar15 = (**(code **)(**(longlong **)(lVar20 + 0x60) + 0x28))(), iVar18 < iVar15)) &&
            (iVar18 = local_res18._4_4_, -1 < (longlong)local_res18)) &&
           (iVar15 = (**(code **)(**(longlong **)(lVar20 + 0x60) + 0x20))(), iVar18 < iVar15)) {
          local_res18 = operator_new(8);
          if (local_res18 == (longlong *)0x0) {
            local_138[0] = (longlong *)0x0;
          }
          else {
            *local_res18 = (longlong)local_138;
            local_138[0] = local_res18;
          }
          local_120 = (longlong *)0x0;
          local_118 = (longlong *)0x0;
          local_110 = 0;
          local_res20 = local_res18;
          if ((ulonglong)(local_158 - (longlong)local_160 >> 3) <= uVar23) {
            _invalid_parameter_noinfo();
          }
          pvVar8 = local_160;
          if ((ulonglong)(local_158 - (longlong)local_160 >> 3) <= uVar23) {
            _invalid_parameter_noinfo();
          }
          pvVar9 = local_160;
          uVar21 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))();
          FUN_1402cfa20(uVar21,local_138,*(undefined4 *)((longlong)pvVar9 + uVar23 * 8),
                        *(undefined4 *)((longlong)pvVar8 + uVar23 * 8 + 4));
          plVar28 = local_120;
          plVar1 = local_138[0];
          if (local_118 < local_120) {
            _invalid_parameter_noinfo();
            plVar1 = local_138[0];
          }
          while( true ) {
            plVar10 = local_118;
            lVar20 = 0;
            if (local_118 < local_120) {
              _invalid_parameter_noinfo();
            }
            if ((plVar1 == (longlong *)0x0) || (plVar1 != local_138[0])) {
              _invalid_parameter_noinfo();
            }
            if (plVar28 == plVar10) break;
            local_148 = (longlong *)0x0;
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar27 = lVar20;
            }
            else {
              lVar27 = *plVar1;
            }
            if (*(longlong **)(lVar27 + 0x20) <= plVar28) {
              _invalid_parameter_noinfo();
            }
            if (*plVar28 != 0) {
              if (plVar1 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                lVar20 = *plVar1;
              }
              if (*(longlong **)(lVar20 + 0x20) <= plVar28) {
                _invalid_parameter_noinfo();
              }
              cVar11 = (**(code **)(*(longlong *)*plVar28 + 0x40))((longlong *)*plVar28,&local_148);
              plVar10 = local_148;
              if ((cVar11 != '\0') && (local_108 = local_148, local_148 != (longlong *)0x0)) {
                uVar16 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66);
                cVar11 = FUN_1404864f0(param_1,plVar10,uVar16);
                if (cVar11 == '\0') {
                  local_res8 = (ulonglong *)((ulonglong)local_res8 & 0xffffffff00000000);
                  iVar17 = (**(code **)(*plVar10 + 0x78))(plVar10);
                  plVar22 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
                  uVar16 = (**(code **)(*plVar22 + 0x3a8))(plVar22,plVar10,&local_res8,0);
                  local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar16);
                  (**(code **)(*plVar10 + 0x78))(plVar10);
                  iVar18 = (**(code **)(*plVar10 + 0x78))(plVar10);
                  puVar3 = local_248;
                  local_res20 = (longlong *)CONCAT44(local_res20._4_4_,iVar17 - iVar18);
                  if (local_250 == (undefined8 *)0x0) {
                    uVar19 = 0;
                  }
                  else {
                    uVar19 = local_240 - (longlong)local_250 >> 3;
                  }
                  if ((ulonglong)((longlong)local_248 - (longlong)local_250 >> 3) < uVar19) {
                    *local_248 = plVar10;
                    local_248 = local_248 + 1;
                  }
                  else {
                    if (local_248 < local_250) {
                      _invalid_parameter_noinfo();
                    }
                    puVar2 = local_250;
                    puVar26 = local_268[0];
                    local_c8 = local_268[0];
                    uStack_c0 = puVar3;
                    if (((longlong)local_248 - (longlong)local_250 & 0xfffffffffffffff8U) == 0) {
                      lVar20 = 0;
                    }
                    else {
                      if (local_248 < local_250) {
                        _invalid_parameter_noinfo();
                      }
                      if ((puVar26 == (ulonglong *)0x0) || (puVar26 != local_268[0])) {
                        _invalid_parameter_noinfo();
                      }
                      lVar20 = (longlong)puVar3 - (longlong)puVar2 >> 3;
                    }
                    local_78 = (undefined4)local_c8;
                    uStack_74 = local_c8._4_4_;
                    uStack_70 = (undefined4)uStack_c0;
                    uStack_6c = uStack_c0._4_4_;
                    FUN_1401a0cb0(local_268,&local_78,1);
                    puVar3 = local_250;
                    if (local_248 < local_250) {
                      _invalid_parameter_noinfo();
                    }
                    puVar26 = local_268[0];
                    if (local_268[0] == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                      uVar19 = 0;
                    }
                    else {
                      uVar19 = *local_268[0];
                    }
                    if (puVar3 + lVar20 <= *(undefined8 **)(uVar19 + 0x20)) {
                      if (puVar26 == (ulonglong *)0x0) {
                        uVar19 = 0;
                      }
                      else {
                        uVar19 = *puVar26;
                      }
                      if (*(undefined8 **)(uVar19 + 0x18) <= puVar3 + lVar20) goto LAB_1404b6dd5;
                    }
                    _invalid_parameter_noinfo();
                  }
LAB_1404b6dd5:
                  puVar5 = local_218;
                  if (local_220 == (undefined4 *)0x0) {
                    uVar19 = 0;
                  }
                  else {
                    uVar19 = local_210 - (longlong)local_220 >> 2;
                  }
                  if ((ulonglong)((longlong)local_218 - (longlong)local_220 >> 2) < uVar19) {
                    *local_218 = uVar16;
                    local_218 = local_218 + 1;
                  }
                  else {
                    if (local_218 < local_220) {
                      _invalid_parameter_noinfo();
                    }
                    puVar4 = local_220;
                    puVar26 = local_238[0];
                    local_e8 = local_238[0];
                    uStack_e0 = puVar5;
                    if (((longlong)local_218 - (longlong)local_220 & 0xfffffffffffffffcU) == 0) {
                      lVar20 = 0;
                    }
                    else {
                      if (local_218 < local_220) {
                        _invalid_parameter_noinfo();
                      }
                      if ((puVar26 == (ulonglong *)0x0) || (puVar26 != local_238[0])) {
                        _invalid_parameter_noinfo();
                      }
                      lVar20 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                    }
                    local_a8 = (undefined4)local_e8;
                    uStack_a4 = local_e8._4_4_;
                    uStack_a0 = (undefined4)uStack_e0;
                    uStack_9c = uStack_e0._4_4_;
                    FUN_14000df40(local_238,&local_a8,1);
                    puVar5 = local_220;
                    if (local_218 < local_220) {
                      _invalid_parameter_noinfo();
                    }
                    puVar26 = local_238[0];
                    if (local_238[0] == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                      uVar19 = 0;
                    }
                    else {
                      uVar19 = *local_238[0];
                    }
                    if (puVar5 + lVar20 <= *(undefined4 **)(uVar19 + 0x20)) {
                      if (puVar26 == (ulonglong *)0x0) {
                        uVar19 = 0;
                      }
                      else {
                        uVar19 = *puVar26;
                      }
                      if (*(undefined4 **)(uVar19 + 0x18) <= puVar5 + lVar20) goto LAB_1404b6f11;
                    }
                    _invalid_parameter_noinfo();
                  }
LAB_1404b6f11:
                  puVar5 = local_1b8;
                  if (local_1c0 == (undefined4 *)0x0) {
                    uVar19 = 0;
                  }
                  else {
                    uVar19 = local_1b0 - (longlong)local_1c0 >> 2;
                  }
                  uVar23 = 0;
                  if ((ulonglong)((longlong)local_1b8 - (longlong)local_1c0 >> 2) < uVar19) {
                    *local_1b8 = local_res8._0_4_;
                    local_1b8 = local_1b8 + 1;
                  }
                  else {
                    if (local_1b8 < local_1c0) {
                      _invalid_parameter_noinfo();
                    }
                    puVar4 = local_1c0;
                    puVar26 = local_1d8[0];
                    local_d8 = local_1d8[0];
                    uStack_d0 = puVar5;
                    uVar19 = uVar23;
                    if (((longlong)local_1b8 - (longlong)local_1c0 & 0xfffffffffffffffcU) != 0) {
                      if (local_1b8 < local_1c0) {
                        _invalid_parameter_noinfo();
                      }
                      if ((puVar26 == (ulonglong *)0x0) || (puVar26 != local_1d8[0])) {
                        _invalid_parameter_noinfo();
                      }
                      uVar19 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                    }
                    local_88 = (undefined4)local_d8;
                    uStack_84 = local_d8._4_4_;
                    uStack_80 = (undefined4)uStack_d0;
                    uStack_7c = uStack_d0._4_4_;
                    FUN_140274790(local_1d8,&local_88,1);
                    puVar5 = local_1c0;
                    if (local_1b8 < local_1c0) {
                      _invalid_parameter_noinfo();
                    }
                    puVar26 = local_1d8[0];
                    if (local_1d8[0] == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                      uVar24 = uVar23;
                    }
                    else {
                      uVar24 = *local_1d8[0];
                    }
                    if (puVar5 + uVar19 <= *(undefined4 **)(uVar24 + 0x20)) {
                      uVar24 = uVar23;
                      if (puVar26 != (ulonglong *)0x0) {
                        uVar24 = *puVar26;
                      }
                      if (*(undefined4 **)(uVar24 + 0x18) <= puVar5 + uVar19) goto LAB_1404b7067;
                    }
                    _invalid_parameter_noinfo();
                  }
LAB_1404b7067:
                  puVar5 = local_188;
                  local_res18 = (longlong *)((ulonglong)local_res18 & 0xffffffff00000000);
                  uVar19 = uVar23;
                  if (local_190 != (undefined4 *)0x0) {
                    uVar19 = local_180 - (longlong)local_190 >> 2;
                  }
                  if ((ulonglong)((longlong)local_188 - (longlong)local_190 >> 2) < uVar19) {
                    *local_188 = 0;
                    local_188 = local_188 + 1;
                  }
                  else {
                    if (local_188 < local_190) {
                      _invalid_parameter_noinfo();
                    }
                    puVar4 = local_190;
                    puVar26 = local_1a8[0];
                    local_b8 = local_1a8[0];
                    uStack_b0 = puVar5;
                    uVar19 = uVar23;
                    if (((longlong)local_188 - (longlong)local_190 & 0xfffffffffffffffcU) != 0) {
                      if (local_188 < local_190) {
                        _invalid_parameter_noinfo();
                      }
                      if ((puVar26 == (ulonglong *)0x0) || (puVar26 != local_1a8[0])) {
                        _invalid_parameter_noinfo();
                      }
                      uVar19 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                    }
                    local_68 = (undefined4)local_b8;
                    uStack_64 = local_b8._4_4_;
                    uStack_60 = (undefined4)uStack_b0;
                    uStack_5c = uStack_b0._4_4_;
                    FUN_14000df40(local_1a8,&local_68,1);
                    puVar5 = local_190;
                    if (local_188 < local_190) {
                      _invalid_parameter_noinfo();
                    }
                    puVar26 = local_1a8[0];
                    if (local_1a8[0] == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                      uVar24 = uVar23;
                    }
                    else {
                      uVar24 = *local_1a8[0];
                    }
                    if (puVar5 + uVar19 <= *(undefined4 **)(uVar24 + 0x20)) {
                      uVar24 = uVar23;
                      if (puVar26 != (ulonglong *)0x0) {
                        uVar24 = *puVar26;
                      }
                      if (*(undefined4 **)(uVar24 + 0x18) <= puVar5 + uVar19) goto LAB_1404b71b9;
                    }
                    _invalid_parameter_noinfo();
                  }
LAB_1404b71b9:
                  piVar7 = local_1e8;
                  uVar19 = uVar23;
                  if (local_1f0 != (int *)0x0) {
                    uVar19 = local_1e0 - (longlong)local_1f0 >> 2;
                  }
                  if ((ulonglong)((longlong)local_1e8 - (longlong)local_1f0 >> 2) < uVar19) {
                    *local_1e8 = iVar17 - iVar18;
                    local_1e8 = local_1e8 + 1;
                  }
                  else {
                    if (local_1e8 < local_1f0) {
                      _invalid_parameter_noinfo();
                    }
                    piVar6 = local_1f0;
                    puVar26 = local_208[0];
                    local_f8 = local_208[0];
                    uStack_f0 = piVar7;
                    uVar19 = uVar23;
                    if (((longlong)local_1e8 - (longlong)local_1f0 & 0xfffffffffffffffcU) != 0) {
                      if (local_1e8 < local_1f0) {
                        _invalid_parameter_noinfo();
                      }
                      if ((puVar26 == (ulonglong *)0x0) || (puVar26 != local_208[0])) {
                        _invalid_parameter_noinfo();
                      }
                      uVar19 = (longlong)piVar7 - (longlong)piVar6 >> 2;
                    }
                    local_98 = (undefined4)local_f8;
                    uStack_94 = local_f8._4_4_;
                    uStack_90 = (undefined4)uStack_f0;
                    uStack_8c = uStack_f0._4_4_;
                    FUN_14000df40(local_208,&local_98,1);
                    piVar7 = local_1f0;
                    if (local_1e8 < local_1f0) {
                      _invalid_parameter_noinfo();
                    }
                    puVar26 = local_208[0];
                    if (local_208[0] == (ulonglong *)0x0) {
                      _invalid_parameter_noinfo();
                      uVar24 = uVar23;
                    }
                    else {
                      uVar24 = *local_208[0];
                    }
                    if (piVar7 + uVar19 <= *(int **)(uVar24 + 0x20)) {
                      if (puVar26 != (ulonglong *)0x0) {
                        uVar23 = *puVar26;
                      }
                      if (*(int **)(uVar23 + 0x18) <= piVar7 + uVar19) goto LAB_1404b7305;
                    }
                    _invalid_parameter_noinfo();
                  }
                }
              }
            }
LAB_1404b7305:
            lVar20 = 0;
            if (plVar1 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
            }
            else {
              lVar20 = *plVar1;
            }
            if (*(longlong **)(lVar20 + 0x20) <= plVar28) {
              _invalid_parameter_noinfo();
            }
            plVar28 = plVar28 + 1;
          }
          if (local_120 != (longlong *)0x0) {
            operator_delete(local_120);
          }
          local_120 = (longlong *)0x0;
          local_118 = (longlong *)0x0;
          local_110 = 0;
          operator_delete(local_138[0]);
          uVar23 = local_140;
          iVar17 = (int)local_res10;
        }
        uVar25 = iVar17 + 1;
        puVar26 = (ulonglong *)(ulonglong)uVar25;
        local_res10 = (ulonglong *)CONCAT44(local_res10._4_4_,uVar25);
        local_140 = uVar23 + 1;
        uVar19 = local_158 - (longlong)local_160 >> 3;
      } while ((int)uVar25 < (int)uVar19);
    }
    uVar24 = 0;
    FUN_1404879b0(param_1,param_1 + 0x9c,local_268,local_238,local_1d8,local_1a8,0);
    uVar23 = (longlong)local_248 - (longlong)local_250 >> 3;
    uVar19 = uVar24;
    if (uVar23 != 0) {
      do {
        if (uVar23 <= uVar24) {
          _invalid_parameter_noinfo();
        }
        puVar3 = local_250;
        if ((ulonglong)((longlong)local_218 - (longlong)local_220 >> 2) <= uVar24) {
          _invalid_parameter_noinfo();
        }
        puVar5 = local_220;
        if ((ulonglong)((longlong)local_1e8 - (longlong)local_1f0 >> 2) <= uVar24) {
          _invalid_parameter_noinfo();
        }
        FUN_1403eb540(*(undefined8 *)(*(longlong *)(param_1 + 0x1c8) + 0x1120),local_1f0[uVar24],
                      puVar5[uVar24],puVar3[uVar24]);
        uVar25 = (int)uVar19 + 1;
        uVar19 = (ulonglong)uVar25;
        uVar24 = uVar24 + 1;
        uVar23 = (longlong)local_248 - (longlong)local_250 >> 3;
      } while ((ulonglong)(longlong)(int)uVar25 < uVar23);
    }
    if (local_160 != (void *)0x0) {
      operator_delete(local_160);
    }
    local_160 = (void *)0x0;
    local_158 = 0;
    local_150 = 0;
    operator_delete(local_178[0]);
    if (local_1f0 != (int *)0x0) {
      operator_delete(local_1f0);
    }
    local_1f0 = (int *)0x0;
    local_1e8 = (int *)0x0;
    local_1e0 = 0;
    operator_delete(local_208[0]);
    if (local_190 != (undefined4 *)0x0) {
      operator_delete(local_190);
    }
    local_190 = (undefined4 *)0x0;
    local_188 = (undefined4 *)0x0;
    local_180 = 0;
    operator_delete(local_1a8[0]);
    if (local_1c0 != (undefined4 *)0x0) {
      operator_delete(local_1c0);
    }
    local_1c0 = (undefined4 *)0x0;
    local_1b8 = (undefined4 *)0x0;
    local_1b0 = 0;
    operator_delete(local_1d8[0]);
    if (local_220 != (undefined4 *)0x0) {
      operator_delete(local_220);
    }
    local_220 = (undefined4 *)0x0;
    local_218 = (undefined4 *)0x0;
    local_210 = 0;
    operator_delete(local_238[0]);
    if (local_250 != (undefined8 *)0x0) {
      operator_delete(local_250);
    }
    local_250 = (undefined8 *)0x0;
    local_248 = (undefined8 *)0x0;
    local_240 = 0;
    operator_delete(local_268[0]);
    uVar21 = 1;
  }
  return uVar21;
}

// ==== CMonster::helper_1404b7600  @1404b7600  [medium:callgraph-r3]  (orig: FUN_1404b7600)
undefined8 FUN_1404b7600(longlong param_1)

{
  longlong *plVar1;
  ulonglong *puVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  int *piVar7;
  int *piVar8;
  char cVar9;
  undefined4 uVar10;
  int iVar11;
  undefined4 uVar12;
  int iVar13;
  int iVar14;
  undefined8 uVar15;
  ulonglong *puVar16;
  longlong *plVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  ulonglong uVar20;
  uint uVar21;
  longlong lVar22;
  longlong *plVar23;
  undefined8 local_res10;
  ulonglong *local_res18;
  ulonglong *local_res20;
  undefined8 in_stack_fffffffffffffda8;
  longlong *local_238;
  ulonglong *local_230 [3];
  undefined8 *local_218;
  undefined8 *local_210;
  longlong local_208;
  ulonglong *local_200 [3];
  undefined4 *local_1e8;
  undefined4 *local_1e0;
  longlong local_1d8;
  ulonglong *local_1d0 [3];
  int *local_1b8;
  int *local_1b0;
  longlong local_1a8;
  ulonglong *local_1a0 [3];
  undefined4 *local_188;
  undefined4 *local_180;
  longlong local_178;
  ulonglong *local_170 [3];
  undefined4 *local_158;
  undefined4 *local_150;
  longlong local_148;
  undefined4 local_140;
  undefined4 uStack_13c;
  ulonglong *local_138 [3];
  longlong *local_120;
  longlong *local_118;
  undefined8 local_110;
  longlong *local_108 [2];
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  
  uVar12 = (undefined4)((ulonglong)in_stack_fffffffffffffda8 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar15 = 0;
  }
  else {
    uVar10 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x40))();
    local_res10 = (ulonglong *)CONCAT44(local_res10._4_4_,uVar10);
    uVar10 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x48))();
    local_res10 = (ulonglong *)CONCAT44(uVar10,(undefined4)local_res10);
    iVar11 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x72);
    local_res18 = operator_new(8);
    puVar16 = (ulonglong *)0x0;
    local_138[0] = puVar16;
    if (local_res18 != (ulonglong *)0x0) {
      *local_res18 = (ulonglong)local_138;
      local_138[0] = local_res18;
    }
    local_120 = (longlong *)0x0;
    local_118 = (longlong *)0x0;
    local_110 = 0;
    local_res20 = local_res18;
    uVar15 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))();
    FUN_1402d2470(uVar15,local_138,local_res10,iVar11 + 2,CONCAT44(uVar12,0x1443));
    local_res10 = operator_new(8);
    local_230[0] = puVar16;
    if (local_res10 != (ulonglong *)0x0) {
      *local_res10 = (ulonglong)local_230;
      local_230[0] = local_res10;
    }
    local_218 = (undefined8 *)0x0;
    local_210 = (undefined8 *)0x0;
    local_208 = 0;
    local_res18 = local_res10;
    local_res10 = operator_new(8);
    local_200[0] = puVar16;
    if (local_res10 != (ulonglong *)0x0) {
      *local_res10 = (ulonglong)local_200;
      local_200[0] = local_res10;
    }
    local_1e8 = (undefined4 *)0x0;
    local_1e0 = (undefined4 *)0x0;
    local_1d8 = 0;
    local_res18 = local_res10;
    local_res10 = operator_new(8);
    local_1a0[0] = puVar16;
    if (local_res10 != (ulonglong *)0x0) {
      *local_res10 = (ulonglong)local_1a0;
      local_1a0[0] = local_res10;
    }
    local_188 = (undefined4 *)0x0;
    local_180 = (undefined4 *)0x0;
    local_178 = 0;
    local_res18 = local_res10;
    local_res10 = operator_new(8);
    local_170[0] = puVar16;
    if (local_res10 != (ulonglong *)0x0) {
      *local_res10 = (ulonglong)local_170;
      local_170[0] = local_res10;
    }
    local_158 = (undefined4 *)0x0;
    local_150 = (undefined4 *)0x0;
    local_148 = 0;
    local_res18 = local_res10;
    local_res10 = operator_new(8);
    plVar23 = local_120;
    if (local_res10 != (ulonglong *)0x0) {
      *local_res10 = (ulonglong)local_1d0;
      puVar16 = local_res10;
    }
    local_1b8 = (int *)0x0;
    local_1b0 = (int *)0x0;
    local_1a8 = 0;
    local_res18 = local_res10;
    local_1d0[0] = puVar16;
    puVar16 = local_138[0];
    if (local_118 < local_120) {
      _invalid_parameter_noinfo();
      puVar16 = local_138[0];
    }
    while( true ) {
      plVar1 = local_118;
      uVar19 = 0;
      if (local_118 < local_120) {
        _invalid_parameter_noinfo();
      }
      if ((puVar16 == (ulonglong *)0x0) || (puVar16 != local_138[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar23 == plVar1) break;
      local_238 = (longlong *)0x0;
      if (puVar16 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
        uVar18 = uVar19;
      }
      else {
        uVar18 = *puVar16;
      }
      if (*(longlong **)(uVar18 + 0x20) <= plVar23) {
        _invalid_parameter_noinfo();
      }
      if (*plVar23 != 0) {
        if (puVar16 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          uVar19 = *puVar16;
        }
        if (*(longlong **)(uVar19 + 0x20) <= plVar23) {
          _invalid_parameter_noinfo();
        }
        cVar9 = (**(code **)(*(longlong *)*plVar23 + 0x40))((longlong *)*plVar23,&local_238);
        if (cVar9 != '\0') {
          local_140 = (**(code **)(*local_238 + 0x40))();
          uStack_13c = (**(code **)(*local_238 + 0x48))();
          cVar9 = FUN_140162df0(*(undefined8 *)(param_1 + 0x1c8),CONCAT44(uStack_13c,local_140),
                                iVar11 + 2,*(undefined8 *)(param_1 + 0x9c));
          if (cVar9 != '\0') {
            lVar22 = *(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
            uVar12 = (**(code **)(*local_238 + 0x3f0))();
            iVar13 = (**(code **)(lVar22 + 1000))(*(longlong *)(param_1 + 0x1c8) + 0x10,uVar12);
            uVar15 = (**(code **)(*local_238 + 0x2a0))();
            iVar14 = (**(code **)(lVar22 + 0x150))(*(longlong *)(param_1 + 0x1c8) + 0x10,uVar15);
            if (iVar13 < iVar14) {
              lVar22 = *(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
              uVar15 = (**(code **)(*local_238 + 0x2a0))();
              iVar13 = (**(code **)(lVar22 + 0x150))(*(longlong *)(param_1 + 0x1c8) + 0x10,uVar15);
              iVar14 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x72);
              if (iVar14 < iVar13) goto LAB_1404b816e;
            }
            plVar1 = local_238;
            local_108[0] = local_238;
            if (local_238 != (longlong *)0x0) {
              uVar12 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66);
              cVar9 = FUN_1404864f0(param_1,plVar1,uVar12);
              if (cVar9 == '\0') {
                local_res10 = (ulonglong *)((ulonglong)local_res10 & 0xffffffff00000000);
                iVar13 = (**(code **)(*plVar1 + 0x78))(plVar1);
                plVar17 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
                uVar12 = (**(code **)(*plVar17 + 0x3a8))(plVar17,plVar1,&local_res10,0);
                local_res18 = (ulonglong *)CONCAT44(local_res18._4_4_,uVar12);
                (**(code **)(*plVar1 + 0x78))(plVar1);
                iVar14 = (**(code **)(*plVar1 + 0x78))(plVar1);
                puVar4 = local_210;
                local_res20 = (ulonglong *)CONCAT44(local_res20._4_4_,iVar13 - iVar14);
                if (local_218 == (undefined8 *)0x0) {
                  uVar19 = 0;
                }
                else {
                  uVar19 = local_208 - (longlong)local_218 >> 3;
                }
                if ((ulonglong)((longlong)local_210 - (longlong)local_218 >> 3) < uVar19) {
                  *local_210 = plVar1;
                  local_210 = local_210 + 1;
                }
                else {
                  if (local_210 < local_218) {
                    _invalid_parameter_noinfo();
                  }
                  puVar3 = local_218;
                  puVar2 = local_230[0];
                  local_c8 = local_230[0];
                  uStack_c0 = puVar4;
                  if (((longlong)local_210 - (longlong)local_218 & 0xfffffffffffffff8U) == 0) {
                    lVar22 = 0;
                  }
                  else {
                    if (local_210 < local_218) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_230[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar22 = (longlong)puVar4 - (longlong)puVar3 >> 3;
                  }
                  local_a8 = (undefined4)local_c8;
                  uStack_a4 = local_c8._4_4_;
                  uStack_a0 = (undefined4)uStack_c0;
                  uStack_9c = uStack_c0._4_4_;
                  FUN_1401a0cb0(local_230,&local_a8,1,local_108);
                  puVar4 = local_218;
                  if (local_210 < local_218) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_230[0];
                  if (local_230[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar19 = 0;
                  }
                  else {
                    uVar19 = *local_230[0];
                  }
                  if (puVar4 + lVar22 <= *(undefined8 **)(uVar19 + 0x20)) {
                    if (puVar2 == (ulonglong *)0x0) {
                      uVar19 = 0;
                    }
                    else {
                      uVar19 = *puVar2;
                    }
                    if (*(undefined8 **)(uVar19 + 0x18) <= puVar4 + lVar22) goto LAB_1404b7c15;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b7c15:
                puVar6 = local_1e0;
                if (local_1e8 == (undefined4 *)0x0) {
                  uVar19 = 0;
                }
                else {
                  uVar19 = local_1d8 - (longlong)local_1e8 >> 2;
                }
                if ((ulonglong)((longlong)local_1e0 - (longlong)local_1e8 >> 2) < uVar19) {
                  *local_1e0 = uVar12;
                  local_1e0 = local_1e0 + 1;
                }
                else {
                  if (local_1e0 < local_1e8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar5 = local_1e8;
                  puVar2 = local_200[0];
                  local_d8 = local_200[0];
                  uStack_d0 = puVar6;
                  if (((longlong)local_1e0 - (longlong)local_1e8 & 0xfffffffffffffffcU) == 0) {
                    lVar22 = 0;
                  }
                  else {
                    if (local_1e0 < local_1e8) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_200[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar22 = (longlong)puVar6 - (longlong)puVar5 >> 2;
                  }
                  local_88 = (undefined4)local_d8;
                  uStack_84 = local_d8._4_4_;
                  uStack_80 = (undefined4)uStack_d0;
                  uStack_7c = uStack_d0._4_4_;
                  FUN_14000df40(local_200,&local_88,1,&local_res18);
                  puVar6 = local_1e8;
                  if (local_1e0 < local_1e8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_200[0];
                  if (local_200[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar19 = 0;
                  }
                  else {
                    uVar19 = *local_200[0];
                  }
                  if (puVar6 + lVar22 <= *(undefined4 **)(uVar19 + 0x20)) {
                    if (puVar2 == (ulonglong *)0x0) {
                      uVar19 = 0;
                    }
                    else {
                      uVar19 = *puVar2;
                    }
                    if (*(undefined4 **)(uVar19 + 0x18) <= puVar6 + lVar22) goto LAB_1404b7d51;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b7d51:
                puVar6 = local_180;
                if (local_188 == (undefined4 *)0x0) {
                  uVar19 = 0;
                }
                else {
                  uVar19 = local_178 - (longlong)local_188 >> 2;
                }
                uVar18 = 0;
                if ((ulonglong)((longlong)local_180 - (longlong)local_188 >> 2) < uVar19) {
                  *local_180 = (undefined4)local_res10;
                  local_180 = local_180 + 1;
                }
                else {
                  if (local_180 < local_188) {
                    _invalid_parameter_noinfo();
                  }
                  puVar5 = local_188;
                  puVar2 = local_1a0[0];
                  local_b8 = local_1a0[0];
                  uStack_b0 = puVar6;
                  uVar19 = uVar18;
                  if (((longlong)local_180 - (longlong)local_188 & 0xfffffffffffffffcU) != 0) {
                    if (local_180 < local_188) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_1a0[0])) {
                      _invalid_parameter_noinfo();
                    }
                    uVar19 = (longlong)puVar6 - (longlong)puVar5 >> 2;
                  }
                  local_68 = (undefined4)local_b8;
                  uStack_64 = local_b8._4_4_;
                  uStack_60 = (undefined4)uStack_b0;
                  uStack_5c = uStack_b0._4_4_;
                  FUN_140274790(local_1a0,&local_68,1,&local_res10);
                  puVar6 = local_188;
                  if (local_180 < local_188) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_1a0[0];
                  if (local_1a0[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar20 = uVar18;
                  }
                  else {
                    uVar20 = *local_1a0[0];
                  }
                  if (puVar6 + uVar19 <= *(undefined4 **)(uVar20 + 0x20)) {
                    uVar20 = uVar18;
                    if (puVar2 != (ulonglong *)0x0) {
                      uVar20 = *puVar2;
                    }
                    if (*(undefined4 **)(uVar20 + 0x18) <= puVar6 + uVar19) goto LAB_1404b7ea7;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b7ea7:
                puVar6 = local_150;
                local_res18 = (ulonglong *)((ulonglong)local_res18 & 0xffffffff00000000);
                uVar19 = uVar18;
                if (local_158 != (undefined4 *)0x0) {
                  uVar19 = local_148 - (longlong)local_158 >> 2;
                }
                if ((ulonglong)((longlong)local_150 - (longlong)local_158 >> 2) < uVar19) {
                  *local_150 = 0;
                  local_150 = local_150 + 1;
                }
                else {
                  if (local_150 < local_158) {
                    _invalid_parameter_noinfo();
                  }
                  puVar5 = local_158;
                  puVar2 = local_170[0];
                  local_f8 = local_170[0];
                  uStack_f0 = puVar6;
                  uVar19 = uVar18;
                  if (((longlong)local_150 - (longlong)local_158 & 0xfffffffffffffffcU) != 0) {
                    if (local_150 < local_158) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_170[0])) {
                      _invalid_parameter_noinfo();
                    }
                    uVar19 = (longlong)puVar6 - (longlong)puVar5 >> 2;
                  }
                  local_98 = (undefined4)local_f8;
                  uStack_94 = local_f8._4_4_;
                  uStack_90 = (undefined4)uStack_f0;
                  uStack_8c = uStack_f0._4_4_;
                  FUN_14000df40(local_170,&local_98,1,&local_res18);
                  puVar6 = local_158;
                  if (local_150 < local_158) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_170[0];
                  if (local_170[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar20 = uVar18;
                  }
                  else {
                    uVar20 = *local_170[0];
                  }
                  if (puVar6 + uVar19 <= *(undefined4 **)(uVar20 + 0x20)) {
                    uVar20 = uVar18;
                    if (puVar2 != (ulonglong *)0x0) {
                      uVar20 = *puVar2;
                    }
                    if (*(undefined4 **)(uVar20 + 0x18) <= puVar6 + uVar19) goto LAB_1404b7ff9;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b7ff9:
                piVar8 = local_1b0;
                uVar19 = uVar18;
                if (local_1b8 != (int *)0x0) {
                  uVar19 = local_1a8 - (longlong)local_1b8 >> 2;
                }
                if ((ulonglong)((longlong)local_1b0 - (longlong)local_1b8 >> 2) < uVar19) {
                  *local_1b0 = iVar13 - iVar14;
                  local_1b0 = local_1b0 + 1;
                }
                else {
                  if (local_1b0 < local_1b8) {
                    _invalid_parameter_noinfo();
                  }
                  piVar7 = local_1b8;
                  puVar2 = local_1d0[0];
                  local_e8 = local_1d0[0];
                  uStack_e0 = piVar8;
                  uVar19 = uVar18;
                  if (((longlong)local_1b0 - (longlong)local_1b8 & 0xfffffffffffffffcU) != 0) {
                    if (local_1b0 < local_1b8) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar2 == (ulonglong *)0x0) || (puVar2 != local_1d0[0])) {
                      _invalid_parameter_noinfo();
                    }
                    uVar19 = (longlong)piVar8 - (longlong)piVar7 >> 2;
                  }
                  local_78 = (undefined4)local_e8;
                  uStack_74 = local_e8._4_4_;
                  uStack_70 = (undefined4)uStack_e0;
                  uStack_6c = uStack_e0._4_4_;
                  FUN_14000df40(local_1d0,&local_78,1,&local_res20);
                  piVar8 = local_1b8;
                  if (local_1b0 < local_1b8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_1d0[0];
                  if (local_1d0[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar20 = uVar18;
                  }
                  else {
                    uVar20 = *local_1d0[0];
                  }
                  if (piVar8 + uVar19 <= *(int **)(uVar20 + 0x20)) {
                    if (puVar2 != (ulonglong *)0x0) {
                      uVar18 = *puVar2;
                    }
                    if (*(int **)(uVar18 + 0x18) <= piVar8 + uVar19) goto LAB_1404b816e;
                  }
                  _invalid_parameter_noinfo();
                }
              }
            }
          }
        }
      }
LAB_1404b816e:
      uVar19 = 0;
      if (puVar16 == (ulonglong *)0x0) {
        _invalid_parameter_noinfo();
      }
      else {
        uVar19 = *puVar16;
      }
      if (*(longlong **)(uVar19 + 0x20) <= plVar23) {
        _invalid_parameter_noinfo();
      }
      plVar23 = plVar23 + 1;
    }
    FUN_1404879b0(param_1,param_1 + 0x9c,local_230,local_200,local_1a0,local_170,0);
    uVar18 = (longlong)local_210 - (longlong)local_218 >> 3;
    uVar20 = 0;
    if (uVar18 != 0) {
      do {
        if (uVar18 <= uVar20) {
          _invalid_parameter_noinfo();
        }
        puVar4 = local_218;
        if ((ulonglong)((longlong)local_1e0 - (longlong)local_1e8 >> 2) <= uVar20) {
          _invalid_parameter_noinfo();
        }
        puVar6 = local_1e8;
        if ((ulonglong)((longlong)local_1b0 - (longlong)local_1b8 >> 2) <= uVar20) {
          _invalid_parameter_noinfo();
        }
        FUN_1403eb540(*(undefined8 *)(*(longlong *)(param_1 + 0x1c8) + 0x1120),local_1b8[uVar20],
                      puVar6[uVar20],puVar4[uVar20]);
        uVar21 = (int)uVar19 + 1;
        uVar19 = (ulonglong)uVar21;
        uVar20 = uVar20 + 1;
        uVar18 = (longlong)local_210 - (longlong)local_218 >> 3;
      } while ((ulonglong)(longlong)(int)uVar21 < uVar18);
    }
    if (local_1b8 != (int *)0x0) {
      operator_delete(local_1b8);
    }
    local_1b8 = (int *)0x0;
    local_1b0 = (int *)0x0;
    local_1a8 = 0;
    operator_delete(local_1d0[0]);
    if (local_158 != (undefined4 *)0x0) {
      operator_delete(local_158);
    }
    local_158 = (undefined4 *)0x0;
    local_150 = (undefined4 *)0x0;
    local_148 = 0;
    operator_delete(local_170[0]);
    if (local_188 != (undefined4 *)0x0) {
      operator_delete(local_188);
    }
    local_188 = (undefined4 *)0x0;
    local_180 = (undefined4 *)0x0;
    local_178 = 0;
    operator_delete(local_1a0[0]);
    if (local_1e8 != (undefined4 *)0x0) {
      operator_delete(local_1e8);
    }
    local_1e8 = (undefined4 *)0x0;
    local_1e0 = (undefined4 *)0x0;
    local_1d8 = 0;
    operator_delete(local_200[0]);
    if (local_218 != (undefined8 *)0x0) {
      operator_delete(local_218);
    }
    local_218 = (undefined8 *)0x0;
    local_210 = (undefined8 *)0x0;
    local_208 = 0;
    operator_delete(local_230[0]);
    if (local_120 != (longlong *)0x0) {
      operator_delete(local_120);
    }
    local_120 = (longlong *)0x0;
    local_118 = (longlong *)0x0;
    local_110 = 0;
    operator_delete(local_138[0]);
    uVar15 = 1;
  }
  return uVar15;
}

// ==== CMonster::helper_1404b83f0  @1404b83f0  [medium:callgraph-r3]  (orig: FUN_1404b83f0)
undefined8 FUN_1404b83f0(longlong param_1)

{
  ulonglong *puVar1;
  undefined8 *puVar2;
  undefined8 *puVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  int *piVar6;
  int *piVar7;
  char cVar8;
  int iVar9;
  int iVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined8 uVar14;
  ulonglong *puVar15;
  longlong *plVar16;
  ulonglong uVar17;
  ulonglong uVar18;
  uint uVar19;
  longlong lVar21;
  longlong *plVar22;
  undefined8 local_res8;
  undefined4 local_res10;
  undefined4 local_res18;
  ulonglong *local_res20;
  undefined8 in_stack_fffffffffffffda8;
  undefined8 uVar23;
  ulonglong *local_238;
  ulonglong *local_230 [3];
  undefined8 *local_218;
  undefined8 *local_210;
  longlong local_208;
  ulonglong *local_200 [3];
  undefined4 *local_1e8;
  undefined4 *local_1e0;
  longlong local_1d8;
  ulonglong *local_1d0 [3];
  int *local_1b8;
  int *local_1b0;
  longlong local_1a8;
  int local_1a0 [2];
  ulonglong *local_198 [3];
  undefined4 *local_180;
  undefined4 *local_178;
  longlong local_170;
  ulonglong *local_168 [3];
  undefined4 *local_150;
  undefined4 *local_148;
  longlong local_140;
  ulonglong *local_138;
  undefined4 local_130;
  undefined4 uStack_12c;
  ulonglong *local_128 [3];
  longlong *local_110;
  longlong *local_108;
  undefined8 local_100;
  undefined8 local_f8;
  undefined8 uStack_f0;
  undefined8 local_e8;
  undefined8 uStack_e0;
  undefined8 local_d8;
  undefined8 uStack_d0;
  undefined8 local_c8;
  undefined8 uStack_c0;
  undefined8 local_b8;
  undefined8 uStack_b0;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined8 local_58;
  ulonglong uVar20;
  
  uVar13 = (undefined4)((ulonglong)in_stack_fffffffffffffda8 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar14 = 0;
  }
  else if (*(longlong *)(param_1 + 0x1c8) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar14 = 0;
  }
  else {
    iVar9 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x40))();
    local_res8 = (ulonglong *)CONCAT44(local_res8._4_4_,iVar9);
    iVar10 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x48))();
    local_res8 = (ulonglong *)CONCAT44(iVar10,(undefined4)local_res8);
    if ((iVar9 == *(int *)(param_1 + 0x9c)) && (iVar10 == *(int *)(param_1 + 0xa0))) {
      uVar14 = 0;
    }
    else {
      uVar11 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x90);
      local_res18 = uVar11;
      uVar12 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x72);
      local_res10 = uVar12;
      local_res20 = operator_new(8);
      puVar15 = (ulonglong *)0x0;
      local_128[0] = puVar15;
      if (local_res20 != (ulonglong *)0x0) {
        *local_res20 = (ulonglong)local_128;
        local_128[0] = local_res20;
      }
      local_110 = (longlong *)0x0;
      local_108 = (longlong *)0x0;
      local_100 = 0;
      local_138 = local_res20;
      uVar14 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x160))();
      uVar23 = CONCAT44(uVar13,0x1443);
      FUN_1402d2470(uVar14,local_128,local_res8,uVar12,uVar23);
      local_res8 = operator_new(8);
      local_230[0] = puVar15;
      if (local_res8 != (ulonglong *)0x0) {
        *local_res8 = (ulonglong)local_230;
        local_230[0] = local_res8;
      }
      local_218 = (undefined8 *)0x0;
      local_210 = (undefined8 *)0x0;
      local_208 = 0;
      local_res20 = local_res8;
      local_res8 = operator_new(8);
      local_200[0] = puVar15;
      if (local_res8 != (ulonglong *)0x0) {
        *local_res8 = (ulonglong)local_200;
        local_200[0] = local_res8;
      }
      local_1e8 = (undefined4 *)0x0;
      local_1e0 = (undefined4 *)0x0;
      local_1d8 = 0;
      local_res20 = local_res8;
      local_res8 = operator_new(8);
      local_198[0] = puVar15;
      if (local_res8 != (ulonglong *)0x0) {
        *local_res8 = (ulonglong)local_198;
        local_198[0] = local_res8;
      }
      local_180 = (undefined4 *)0x0;
      local_178 = (undefined4 *)0x0;
      local_170 = 0;
      local_res20 = local_res8;
      local_res8 = operator_new(8);
      local_168[0] = puVar15;
      if (local_res8 != (ulonglong *)0x0) {
        *local_res8 = (ulonglong)local_168;
        local_168[0] = local_res8;
      }
      local_150 = (undefined4 *)0x0;
      local_148 = (undefined4 *)0x0;
      local_140 = 0;
      local_res20 = local_res8;
      local_res8 = operator_new(8);
      plVar22 = local_110;
      if (local_res8 != (ulonglong *)0x0) {
        *local_res8 = (ulonglong)local_1d0;
        puVar15 = local_res8;
      }
      local_1b8 = (int *)0x0;
      local_1b0 = (int *)0x0;
      local_1a8 = 0;
      local_res20 = local_res8;
      local_1d0[0] = puVar15;
      puVar15 = local_128[0];
      if (local_108 < local_110) {
        _invalid_parameter_noinfo();
        puVar15 = local_128[0];
      }
      while( true ) {
        plVar16 = local_108;
        uVar18 = 0;
        if (local_108 < local_110) {
          _invalid_parameter_noinfo();
        }
        if ((puVar15 == (ulonglong *)0x0) || (puVar15 != local_128[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar22 == plVar16) break;
        local_238 = (ulonglong *)0x0;
        if (puVar15 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar20 = uVar18;
        }
        else {
          uVar20 = *puVar15;
        }
        if (*(longlong **)(uVar20 + 0x20) <= plVar22) {
          _invalid_parameter_noinfo();
        }
        if (*plVar22 != 0) {
          if (puVar15 == (ulonglong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            uVar18 = *puVar15;
          }
          if (*(longlong **)(uVar18 + 0x20) <= plVar22) {
            _invalid_parameter_noinfo();
          }
          cVar8 = (**(code **)(*(longlong *)*plVar22 + 0x40))((longlong *)*plVar22,&local_238);
          uVar13 = (undefined4)((ulonglong)uVar23 >> 0x20);
          if (cVar8 != '\0') {
            local_130 = (**(code **)(*local_238 + 0x40))();
            uStack_12c = (**(code **)(*local_238 + 0x48))();
            uVar23 = CONCAT44(uVar13,uVar11);
            cVar8 = FUN_140162f80(*(undefined8 *)(param_1 + 0x1c8),CONCAT44(uStack_12c,local_130),
                                  uVar12,*(undefined8 *)(param_1 + 0x9c),uVar23);
            puVar1 = local_238;
            if ((cVar8 != '\0') && (local_138 = local_238, local_238 != (ulonglong *)0x0)) {
              uVar13 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66);
              cVar8 = FUN_1404864f0(param_1,puVar1,uVar13);
              if (cVar8 == '\0') {
                local_res8 = (ulonglong *)((ulonglong)local_res8 & 0xffffffff00000000);
                iVar9 = (**(code **)(*puVar1 + 0x78))(puVar1);
                plVar16 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
                uVar13 = (**(code **)(*plVar16 + 0x3a8))(plVar16,puVar1,&local_res8,0);
                local_res20 = (ulonglong *)CONCAT44(local_res20._4_4_,uVar13);
                (**(code **)(*puVar1 + 0x78))(puVar1);
                iVar10 = (**(code **)(*puVar1 + 0x78))(puVar1);
                puVar3 = local_210;
                iVar9 = iVar9 - iVar10;
                if (local_218 == (undefined8 *)0x0) {
                  uVar18 = 0;
                }
                else {
                  uVar18 = local_208 - (longlong)local_218 >> 3;
                }
                local_1a0[0] = iVar9;
                if ((ulonglong)((longlong)local_210 - (longlong)local_218 >> 3) < uVar18) {
                  *local_210 = puVar1;
                  local_210 = local_210 + 1;
                }
                else {
                  if (local_210 < local_218) {
                    _invalid_parameter_noinfo();
                  }
                  puVar2 = local_218;
                  puVar1 = local_230[0];
                  local_c8 = local_230[0];
                  uStack_c0 = puVar3;
                  if (((longlong)local_210 - (longlong)local_218 & 0xfffffffffffffff8U) == 0) {
                    lVar21 = 0;
                  }
                  else {
                    if (local_210 < local_218) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_230[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar21 = (longlong)puVar3 - (longlong)puVar2 >> 3;
                  }
                  local_a8 = (undefined4)local_c8;
                  uStack_a4 = local_c8._4_4_;
                  uStack_a0 = (undefined4)uStack_c0;
                  uStack_9c = uStack_c0._4_4_;
                  FUN_1401a0cb0(local_230,&local_a8,1,&local_138);
                  puVar3 = local_218;
                  if (local_210 < local_218) {
                    _invalid_parameter_noinfo();
                  }
                  puVar1 = local_230[0];
                  if (local_230[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar18 = 0;
                  }
                  else {
                    uVar18 = *local_230[0];
                  }
                  if (puVar3 + lVar21 <= *(undefined8 **)(uVar18 + 0x20)) {
                    if (puVar1 == (ulonglong *)0x0) {
                      uVar18 = 0;
                    }
                    else {
                      uVar18 = *puVar1;
                    }
                    if (*(undefined8 **)(uVar18 + 0x18) <= puVar3 + lVar21) goto LAB_1404b89d7;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b89d7:
                puVar5 = local_1e0;
                if (local_1e8 == (undefined4 *)0x0) {
                  uVar18 = 0;
                }
                else {
                  uVar18 = local_1d8 - (longlong)local_1e8 >> 2;
                }
                if ((ulonglong)((longlong)local_1e0 - (longlong)local_1e8 >> 2) < uVar18) {
                  *local_1e0 = uVar13;
                  local_1e0 = local_1e0 + 1;
                }
                else {
                  if (local_1e0 < local_1e8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar4 = local_1e8;
                  puVar1 = local_200[0];
                  local_d8 = local_200[0];
                  uStack_d0 = puVar5;
                  if (((longlong)local_1e0 - (longlong)local_1e8 & 0xfffffffffffffffcU) == 0) {
                    lVar21 = 0;
                  }
                  else {
                    if (local_1e0 < local_1e8) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_200[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar21 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                  }
                  local_88 = (undefined4)local_d8;
                  uStack_84 = local_d8._4_4_;
                  uStack_80 = (undefined4)uStack_d0;
                  uStack_7c = uStack_d0._4_4_;
                  FUN_14000df40(local_200,&local_88,1,&local_res20);
                  puVar5 = local_1e8;
                  if (local_1e0 < local_1e8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar1 = local_200[0];
                  if (local_200[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar18 = 0;
                  }
                  else {
                    uVar18 = *local_200[0];
                  }
                  if (puVar5 + lVar21 <= *(undefined4 **)(uVar18 + 0x20)) {
                    if (puVar1 == (ulonglong *)0x0) {
                      uVar18 = 0;
                    }
                    else {
                      uVar18 = *puVar1;
                    }
                    if (*(undefined4 **)(uVar18 + 0x18) <= puVar5 + lVar21) goto LAB_1404b8b13;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b8b13:
                puVar5 = local_178;
                if (local_180 == (undefined4 *)0x0) {
                  uVar18 = 0;
                }
                else {
                  uVar18 = local_170 - (longlong)local_180 >> 2;
                }
                if ((ulonglong)((longlong)local_178 - (longlong)local_180 >> 2) < uVar18) {
                  *local_178 = (undefined4)local_res8;
                  local_178 = local_178 + 1;
                }
                else {
                  if (local_178 < local_180) {
                    _invalid_parameter_noinfo();
                  }
                  puVar4 = local_180;
                  puVar1 = local_198[0];
                  local_b8 = local_198[0];
                  uStack_b0 = puVar5;
                  if (((longlong)local_178 - (longlong)local_180 & 0xfffffffffffffffcU) == 0) {
                    lVar21 = 0;
                  }
                  else {
                    if (local_178 < local_180) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_198[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar21 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                  }
                  local_68 = (undefined4)local_b8;
                  uStack_64 = local_b8._4_4_;
                  uStack_60 = (undefined4)uStack_b0;
                  uStack_5c = uStack_b0._4_4_;
                  FUN_140274790(local_198,&local_68,1,&local_res8);
                  puVar5 = local_180;
                  if (local_178 < local_180) {
                    _invalid_parameter_noinfo();
                  }
                  puVar1 = local_198[0];
                  if (local_198[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar18 = 0;
                  }
                  else {
                    uVar18 = *local_198[0];
                  }
                  if (puVar5 + lVar21 <= *(undefined4 **)(uVar18 + 0x20)) {
                    if (puVar1 == (ulonglong *)0x0) {
                      uVar18 = 0;
                    }
                    else {
                      uVar18 = *puVar1;
                    }
                    if (*(undefined4 **)(uVar18 + 0x18) <= puVar5 + lVar21) goto LAB_1404b8c62;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b8c62:
                puVar5 = local_148;
                local_res20 = (ulonglong *)((ulonglong)local_res20 & 0xffffffff00000000);
                if (local_150 == (undefined4 *)0x0) {
                  uVar18 = 0;
                }
                else {
                  uVar18 = local_140 - (longlong)local_150 >> 2;
                }
                if ((ulonglong)((longlong)local_148 - (longlong)local_150 >> 2) < uVar18) {
                  *local_148 = 0;
                  local_148 = local_148 + 1;
                }
                else {
                  if (local_148 < local_150) {
                    _invalid_parameter_noinfo();
                  }
                  puVar4 = local_150;
                  puVar1 = local_168[0];
                  local_f8 = local_168[0];
                  uStack_f0 = puVar5;
                  if (((longlong)local_148 - (longlong)local_150 & 0xfffffffffffffffcU) == 0) {
                    lVar21 = 0;
                  }
                  else {
                    if (local_148 < local_150) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_168[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar21 = (longlong)puVar5 - (longlong)puVar4 >> 2;
                  }
                  local_98 = (undefined4)local_f8;
                  uStack_94 = local_f8._4_4_;
                  uStack_90 = (undefined4)uStack_f0;
                  uStack_8c = uStack_f0._4_4_;
                  FUN_14000df40(local_168,&local_98,1,&local_res20);
                  puVar5 = local_150;
                  if (local_148 < local_150) {
                    _invalid_parameter_noinfo();
                  }
                  puVar1 = local_168[0];
                  if (local_168[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar18 = 0;
                  }
                  else {
                    uVar18 = *local_168[0];
                  }
                  if (puVar5 + lVar21 <= *(undefined4 **)(uVar18 + 0x20)) {
                    if (puVar1 == (ulonglong *)0x0) {
                      uVar18 = 0;
                    }
                    else {
                      uVar18 = *puVar1;
                    }
                    if (*(undefined4 **)(uVar18 + 0x18) <= puVar5 + lVar21) goto LAB_1404b8db9;
                  }
                  _invalid_parameter_noinfo();
                }
LAB_1404b8db9:
                piVar7 = local_1b0;
                if (local_1b8 == (int *)0x0) {
                  uVar18 = 0;
                }
                else {
                  uVar18 = local_1a8 - (longlong)local_1b8 >> 2;
                }
                if ((ulonglong)((longlong)local_1b0 - (longlong)local_1b8 >> 2) < uVar18) {
                  *local_1b0 = iVar9;
                  local_1b0 = local_1b0 + 1;
                  uVar11 = local_res18;
                  uVar12 = local_res10;
                }
                else {
                  if (local_1b0 < local_1b8) {
                    _invalid_parameter_noinfo();
                  }
                  piVar6 = local_1b8;
                  puVar1 = local_1d0[0];
                  local_e8 = local_1d0[0];
                  uStack_e0 = piVar7;
                  if (((longlong)local_1b0 - (longlong)local_1b8 & 0xfffffffffffffffcU) == 0) {
                    lVar21 = 0;
                  }
                  else {
                    if (local_1b0 < local_1b8) {
                      _invalid_parameter_noinfo();
                    }
                    if ((puVar1 == (ulonglong *)0x0) || (puVar1 != local_1d0[0])) {
                      _invalid_parameter_noinfo();
                    }
                    lVar21 = (longlong)piVar7 - (longlong)piVar6 >> 2;
                  }
                  uVar18 = 0;
                  local_78 = (undefined4)local_e8;
                  uStack_74 = local_e8._4_4_;
                  uStack_70 = (undefined4)uStack_e0;
                  uStack_6c = uStack_e0._4_4_;
                  FUN_14000df40(local_1d0,&local_78,1,local_1a0);
                  piVar7 = local_1b8;
                  if (local_1b0 < local_1b8) {
                    _invalid_parameter_noinfo();
                  }
                  puVar1 = local_1d0[0];
                  if (local_1d0[0] == (ulonglong *)0x0) {
                    _invalid_parameter_noinfo();
                    uVar20 = uVar18;
                  }
                  else {
                    uVar20 = *local_1d0[0];
                  }
                  if (piVar7 + lVar21 <= *(int **)(uVar20 + 0x20)) {
                    if (puVar1 != (ulonglong *)0x0) {
                      uVar18 = *puVar1;
                    }
                    uVar11 = local_res18;
                    uVar12 = local_res10;
                    if (*(int **)(uVar18 + 0x18) <= piVar7 + lVar21) goto LAB_1404b8f37;
                  }
                  _invalid_parameter_noinfo();
                  uVar11 = local_res18;
                  uVar12 = local_res10;
                }
              }
            }
          }
        }
LAB_1404b8f37:
        uVar18 = 0;
        if (puVar15 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          uVar18 = *puVar15;
        }
        if (*(longlong **)(uVar18 + 0x20) <= plVar22) {
          _invalid_parameter_noinfo();
        }
        plVar22 = plVar22 + 1;
      }
      FUN_1404879b0(param_1,(undefined8 *)(param_1 + 0x9c),local_230,local_200,local_198,local_168,0
                   );
      uVar17 = (longlong)local_210 - (longlong)local_218 >> 3;
      uVar20 = uVar18;
      if (uVar17 != 0) {
        do {
          if (uVar17 <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar3 = local_218;
          if ((ulonglong)((longlong)local_1e0 - (longlong)local_1e8 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar5 = local_1e8;
          if ((ulonglong)((longlong)local_1b0 - (longlong)local_1b8 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          FUN_1403eb540(*(undefined8 *)(*(longlong *)(param_1 + 0x1c8) + 0x1120),local_1b8[uVar18],
                        puVar5[uVar18],puVar3[uVar18]);
          uVar19 = (int)uVar20 + 1;
          uVar20 = (ulonglong)uVar19;
          uVar18 = uVar18 + 1;
          uVar17 = (longlong)local_210 - (longlong)local_218 >> 3;
        } while ((ulonglong)(longlong)(int)uVar19 < uVar17);
      }
      if (local_1b8 != (int *)0x0) {
        operator_delete(local_1b8);
      }
      local_1b8 = (int *)0x0;
      local_1b0 = (int *)0x0;
      local_1a8 = 0;
      operator_delete(local_1d0[0]);
      if (local_150 != (undefined4 *)0x0) {
        operator_delete(local_150);
      }
      local_150 = (undefined4 *)0x0;
      local_148 = (undefined4 *)0x0;
      local_140 = 0;
      operator_delete(local_168[0]);
      if (local_180 != (undefined4 *)0x0) {
        operator_delete(local_180);
      }
      local_180 = (undefined4 *)0x0;
      local_178 = (undefined4 *)0x0;
      local_170 = 0;
      operator_delete(local_198[0]);
      if (local_1e8 != (undefined4 *)0x0) {
        operator_delete(local_1e8);
      }
      local_1e8 = (undefined4 *)0x0;
      local_1e0 = (undefined4 *)0x0;
      local_1d8 = 0;
      operator_delete(local_200[0]);
      if (local_218 != (undefined8 *)0x0) {
        operator_delete(local_218);
      }
      local_218 = (undefined8 *)0x0;
      local_210 = (undefined8 *)0x0;
      local_208 = 0;
      operator_delete(local_230[0]);
      if (local_110 != (longlong *)0x0) {
        operator_delete(local_110);
      }
      local_110 = (longlong *)0x0;
      local_108 = (longlong *)0x0;
      local_100 = 0;
      operator_delete(local_128[0]);
      uVar14 = 1;
    }
  }
  return uVar14;
}

// ==== CMonster::helper_1404b96c0  @1404b96c0  [medium:callgraph-r2]  (orig: FUN_1404b96c0)
undefined8 FUN_1404b96c0(longlong param_1,short param_2,undefined4 param_3)

{
  undefined1 uVar1;
  undefined4 uVar2;
  char cVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined8 uVar8;
  longlong lVar9;
  longlong *plVar10;
  
  if ((*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0xa88) == 0) &&
     (*(byte *)(*(longlong *)(param_1 + 0x1c8) + 0xeee) / 10 == 8)) {
    if (param_2 == 0) {
      iVar4 = tq::RandGet(100);
      iVar4 = iVar4 + (iVar4 / 3 + (iVar4 >> 0x1f) +
                      (int)(((longlong)iVar4 / 3 + ((longlong)iVar4 >> 0x3f) & 0xffffffffU) >> 0x1f)
                      ) * -3;
      if (iVar4 == 0) {
        param_2 = 0x2fb2;
        goto LAB_1404b978b;
      }
      if (iVar4 == 1) {
        param_2 = 0x2fbc;
        goto LAB_1404b978b;
      }
      if (iVar4 == 2) {
        param_2 = 0x2fc6;
        goto LAB_1404b978b;
      }
    }
    else if ((param_2 == 0x2fb2) || (param_2 == 0x2fbc)) goto LAB_1404b978b;
    if (param_2 == 0x2fc6) {
LAB_1404b978b:
      plVar10 = (longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10);
      uVar5 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x1c8) + 0x10) + 0x48))(plVar10);
      uVar6 = (**(code **)(*plVar10 + 0x40))(plVar10);
      uVar8 = (**(code **)(*plVar10 + 0x160))(plVar10);
      plVar10 = (longlong *)FUN_1402c8700(uVar8,uVar6,uVar5,param_3);
      if (plVar10 != (longlong *)0x0) {
        lVar9 = FUN_14048b5f0(param_1,param_2);
        if (lVar9 != 0) {
          uVar5 = FUN_140418c50(lVar9,0x7a);
          cVar3 = FUN_140482af0(*(undefined8 *)(param_1 + 0x1c8),uVar5,0);
          if (cVar3 != '\0') {
            uVar8 = *(undefined8 *)(param_1 + 0x90);
            uVar5 = *(undefined4 *)(param_1 + 0x98);
            uVar6 = *(undefined4 *)(param_1 + 0x9c);
            uVar2 = *(undefined4 *)(param_1 + 0xa0);
            *(longlong *)(param_1 + 0x90) = lVar9;
            uVar1 = *(undefined1 *)(param_1 + 200);
            uVar7 = (**(code **)(*plVar10 + 0x10))(plVar10);
            *(undefined4 *)(param_1 + 0x98) = uVar7;
            uVar7 = (**(code **)(*plVar10 + 0x40))(plVar10);
            *(undefined4 *)(param_1 + 0x9c) = uVar7;
            uVar7 = (**(code **)(*plVar10 + 0x48))(plVar10);
            *(undefined4 *)(param_1 + 0xa0) = uVar7;
            iVar4 = FUN_140418c50(*(undefined8 *)(param_1 + 0x90),0x66);
            if (iVar4 == 0x4c) {
              FUN_1404b6740(param_1);
            }
            else if (iVar4 == 0x4d) {
              FUN_1404b7600(param_1);
            }
            else if (iVar4 == 0x4e) {
              FUN_1404b83f0(param_1);
            }
            *(undefined1 *)(param_1 + 200) = uVar1;
            *(undefined8 *)(param_1 + 0x90) = uVar8;
            *(undefined4 *)(param_1 + 0x98) = uVar5;
            *(undefined4 *)(param_1 + 0x9c) = uVar6;
            *(undefined4 *)(param_1 + 0xa0) = uVar2;
            return 1;
          }
        }
      }
      return 0;
    }
  }
  return 0;
}

// ==== CMonster::helper_1404c27e0  @1404c27e0  [medium:callgraph-r3]  (orig: FUN_1404c27e0)
undefined8 FUN_1404c27e0(longlong param_1,ulonglong param_2,int param_3)

{
  undefined8 *puVar1;
  longlong local_res8 [4];
  
  local_res8[0] = ((longlong)param_3 << 0x20) + (param_2 & 0xffffffff);
  puVar1 = (undefined8 *)FUN_1404c2270(param_1 + 8,local_res8);
  return *puVar1;
}

// ==== CMonster::helper_1404ca650  @1404ca650  [medium:callgraph-r3]  (orig: FUN_1404ca650)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404ca650(longlong param_1,undefined4 *param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  longlong *plVar3;
  undefined1 auStack_4b8 [32];
  uint local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined4 local_480;
  undefined4 local_478;
  undefined1 local_470;
  undefined8 local_468;
  undefined1 local_458 [1072];
  ulonglong local_28;
  
  local_468 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_498 = 0x352;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140386780(local_458);
    uVar1 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
    local_470 = 0;
    local_478 = 0;
    local_480 = 0;
    local_488 = 0;
    local_498 = local_498 & 0xffffff00;
    local_490 = param_3;
    iVar2 = FUN_1403868f0(local_458,uVar1,*param_2,0);
    if (iVar2 == 0) {
      local_498 = 0x356;
      log_InlineLogERROR(&DAT_1406d9c10);
      FUN_1403867d0(local_458);
    }
    else {
      plVar3 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      (**(code **)(*plVar3 + 0x348))(plVar3,local_458,1);
      FUN_1403867d0(local_458);
    }
  }
  return;
}

// ==== CMonster::helper_1404ca780  @1404ca780  [medium:callgraph-r3]  (orig: FUN_1404ca780)
undefined8
FUN_1404ca780(longlong param_1,ulonglong param_2,int param_3,undefined8 param_4,double param_5)

{
  longlong lVar1;
  int iVar2;
  float fVar3;
  float extraout_XMM0_Da;
  int iStackX_14;
  int local_res20;
  int iStackX_24;
  
  lVar1 = *(longlong *)(param_1 + 0x60);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    iVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
    local_res20 = (int)param_4;
    if (local_res20 == iVar2) {
      iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))
                        (*(longlong *)(param_1 + 0x60) + 0x10);
      iStackX_24 = (int)((ulonglong)param_4 >> 0x20);
      if (iStackX_24 == iVar2) {
        return 0;
      }
    }
    iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))
                      (*(longlong *)(param_1 + 0x60) + 0x10);
    iStackX_14 = (int)(param_2 >> 0x20);
    if ((((int)param_2 != iVar2) ||
        (iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))
                           (*(longlong *)(param_1 + 0x60) + 0x10), iStackX_14 != iVar2)) &&
       (iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x158))
                          (*(longlong *)(param_1 + 0x60) + 0x10,param_2 & 0xffffffff,iStackX_14),
       iVar2 <= param_3)) {
      lVar1 = *(longlong *)(param_1 + 0x60);
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
      fVar3 = (float)FUN_14015d3c0();
      lVar1 = *(longlong *)(param_1 + 0x60);
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))(lVar1 + 0x10);
      (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
      FUN_14015d3c0();
      fVar3 = (float)(double)((ulonglong)(double)(fVar3 - extraout_XMM0_Da) & DAT_140714560);
      if (((double)fVar3 <= param_5) || (DAT_14078e418 - param_5 <= (double)fVar3)) {
        return 1;
      }
    }
  }
  return 0;
}

// ==== CMonster::helper_1404ca9a0  @1404ca9a0  [medium:callgraph-r2]  (orig: FUN_1404ca9a0)
int FUN_1404ca9a0(undefined8 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = FUN_1402c7380(param_2,param_3,param_4,param_5);
  uVar2 = iVar1 + 1 >> 0x1f & 7;
  return (iVar1 + 1 + uVar2 & 7) - uVar2;
}

// ==== CMonster::helper_1404ca9d0  @1404ca9d0  [medium:callgraph-r1]  (orig: FUN_1404ca9d0)
void FUN_1404ca9d0(longlong param_1)

{
  longlong lVar1;
  undefined4 uVar2;
  
  lVar1 = *(longlong *)(param_1 + 0x60);
  if (lVar1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  uVar2 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
  *(undefined4 *)(param_1 + 0x50) = uVar2;
  uVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
  *(undefined4 *)(param_1 + 0x54) = uVar2;
  return;
}

// ==== CMonster::helper_1404caa40  @1404caa40  [medium:callgraph-r1]  (orig: FUN_1404caa40)
ulonglong FUN_1404caa40(longlong param_1)

{
  int iVar1;
  ulonglong extraout_RAX;
  
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return extraout_RAX & 0xffffffffffffff00;
  }
  iVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))
                    (*(longlong *)(param_1 + 0x60) + 0x10);
  if (*(int *)(param_1 + 0x50) == iVar1) {
    iVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))
                      (*(longlong *)(param_1 + 0x60) + 0x10);
    if (*(int *)(param_1 + 0x54) == iVar1) {
      return 0;
    }
  }
  return 1;
}

// ==== CMonster::helper_1404caac0  @1404caac0  [medium:callgraph-r3]  (orig: FUN_1404caac0)
void FUN_1404caac0(longlong param_1,longlong param_2,longlong param_3,longlong param_4,
                  undefined4 *param_5)

{
  char cVar1;
  int iVar2;
  longlong *plVar3;
  longlong lVar4;
  
  if ((((param_3 != 0) && (param_4 != 0)) && (param_2 != 0)) &&
     ((param_5 != (undefined4 *)0x0 && (*(longlong *)(param_1 + 0x60) != 0)))) {
    plVar3 = (longlong *)
             (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                       (*(longlong **)(param_2 + 0x40),0x1e);
    iVar2 = (**(code **)(*plVar3 + 0x48))(plVar3);
    if (iVar2 == 0) {
      if (*(longlong *)(param_1 + 0x60) == 0) {
        lVar4 = 0;
      }
      else {
        lVar4 = *(longlong *)(param_1 + 0x60) + 0x10;
      }
      cVar1 = FUN_1403e9040(lVar4,param_3);
      if (cVar1 != '\0') {
        FUN_14031cee0(param_4,8);
        *param_5 = 0;
      }
    }
  }
  return;
}

// ==== CMonster::helper_1404cb1c0  @1404cb1c0  [medium:callgraph-r2]  (orig: FUN_1404cb1c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404cb1c0(longlong param_1,int *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  undefined2 uVar11;
  undefined2 uVar12;
  undefined1 auStack_938 [32];
  undefined4 local_918;
  undefined2 local_910;
  undefined4 local_908;
  uint local_900;
  undefined4 local_8f8;
  undefined4 local_8f0;
  undefined4 local_8e8;
  undefined4 local_8e4;
  int local_8e0;
  undefined4 local_8dc;
  undefined8 local_8d8;
  undefined1 local_8c8 [1072];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_8d8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_938;
  local_8e0 = param_3;
  if (param_3 == 0) {
    local_918 = 0x21d;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else if (param_2 == (int *)0x0) {
    local_918 = 0x21e;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else if (*(longlong *)(param_2 + 0x10) == 0) {
    local_918 = 0x21f;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else if (*(longlong *)(param_1 + 0x60) == 0) {
    local_918 = 0x220;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar8 = 0;
  }
  else {
    uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
    plVar9 = (longlong *)FUN_1400875f0(uVar8);
    plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,param_3);
    if ((plVar9 == (longlong *)0x0) ||
       (cVar2 = (**(code **)(*plVar9 + 0x220))(plVar9), cVar2 == '\0')) {
      FUN_140388930(*(undefined8 *)(param_1 + 0x60));
      uVar8 = 0;
    }
    else {
      plVar10 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      cVar2 = (**(code **)(*plVar10 + 0x3d8))(plVar10,plVar9,0);
      if (cVar2 == '\0') {
        FUN_140388930(*(undefined8 *)(param_1 + 0x60));
        uVar8 = 0;
      }
      else {
        lVar1 = *(longlong *)(param_1 + 0x60);
        uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
        uVar4 = (**(code **)(*plVar9 + 0x40))(plVar9);
        uVar5 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))((longlong *)(lVar1 + 0x10));
        uVar6 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
        local_918 = uVar3;
        uVar3 = FUN_1404ca9a0(param_1,uVar6,uVar5,uVar4);
        local_8dc = uVar3;
        if (*param_2 != 0x1b63) {
          plVar10 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
          (**(code **)(*plVar10 + 0x2b8))(plVar10,uVar3);
          FUN_140362560(local_498);
          plVar10 = *(longlong **)(param_1 + 0x60);
          uVar4 = (**(code **)(plVar10[2] + 0x48))();
          uVar5 = (**(code **)(plVar10[2] + 0x40))(plVar10 + 2);
          uVar6 = (**(code **)(*plVar10 + 8))(plVar10);
          local_900 = 0;
          local_908 = 0;
          local_910 = 0x193;
          local_918 = CONCAT22(local_918._2_2_,(short)uVar3);
          iVar7 = FUN_140362620(local_498,uVar6,uVar5,uVar4);
          if (iVar7 == 0) {
            local_918 = 0x237;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            plVar10 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
            (**(code **)(*plVar10 + 0x348))(plVar10,local_498,1);
          }
          FUN_1403625e0(local_498);
        }
        local_8e4 = 0;
        local_8e8 = 0;
        if ((*param_2 == 0x2906) || (*param_2 == 0x2907)) {
          local_8e4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
          uVar11 = (undefined2)local_8e4;
          local_8e8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
          uVar12 = (undefined2)local_8e8;
        }
        else {
          local_8e4 = (**(code **)(*plVar9 + 0x40))(plVar9);
          uVar11 = (undefined2)local_8e4;
          local_8e8 = (**(code **)(*plVar9 + 0x48))(plVar9);
          uVar12 = (undefined2)local_8e8;
        }
        FUN_14035f2f0(local_8c8);
        uVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
        local_8f0 = 0;
        local_8f8 = 0;
        local_900 = local_900 & 0xffff0000;
        local_908 = CONCAT22(local_908._2_2_,(short)*param_2);
        local_918 = CONCAT22(local_918._2_2_,uVar11);
        local_910 = uVar12;
        iVar7 = FUN_14035f4c0(local_8c8,0x34,uVar3,local_8e0);
        if (iVar7 != 0) {
          plVar9 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
          (**(code **)(*plVar9 + 0x348))(plVar9,local_8c8,1);
        }
        FUN_14035f340(local_8c8);
        uVar8 = 1;
      }
    }
  }
  return uVar8;
}

// ==== CMonster::helper_1404cb590  @1404cb590  [medium:callgraph-r1]  (orig: FUN_1404cb590)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404cb590(longlong param_1,int *param_2,int param_3)

{
  longlong lVar1;
  char cVar2;
  undefined2 uVar3;
  undefined2 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong *plVar11;
  undefined8 uVar12;
  longlong *plVar13;
  undefined1 auStack_928 [32];
  undefined4 local_908;
  undefined2 local_900;
  undefined4 local_8f8;
  undefined4 local_8f0;
  undefined4 local_8e8;
  undefined4 local_8e0;
  undefined4 local_8d8;
  int local_8d4;
  undefined8 local_8d0;
  undefined1 local_8c8 [1072];
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_8d0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_928;
  local_8d4 = param_3;
  if (param_2 == (int *)0x0) {
    local_908 = 0x2b0;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else if (*(longlong *)(param_2 + 0x10) == 0) {
    local_908 = 0x2b1;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else if (*(longlong *)(param_1 + 0x60) == 0) {
    local_908 = 0x2b2;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar12 = 0;
  }
  else {
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                        (*(longlong **)(param_2 + 0x10),2);
    iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
    if (iVar5 == 1) {
      if (param_3 == 0) {
        return 0;
      }
      uVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
      plVar11 = (longlong *)FUN_1400875f0(uVar12);
      plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,param_3);
      if ((plVar11 == (longlong *)0x0) ||
         (cVar2 = (**(code **)(*plVar11 + 0x220))(plVar11), cVar2 == '\0')) {
        FUN_140388930(*(undefined8 *)(param_1 + 0x60));
        return 0;
      }
      plVar13 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      cVar2 = (**(code **)(*plVar13 + 0x3d8))(plVar13,plVar11,0);
      if (cVar2 == '\0') {
        FUN_140388930(*(undefined8 *)(param_1 + 0x60));
        return 0;
      }
      lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      uVar12 = (**(code **)(*plVar11 + 0x2a0))(plVar11);
      iVar5 = (**(code **)(lVar1 + 0x150))(*(longlong *)(param_1 + 0x60) + 0x10,uVar12);
      plVar13 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                          (*(longlong **)(param_2 + 0x10),0xf);
      iVar6 = (**(code **)(*plVar13 + 0x48))(plVar13);
      if (iVar6 < iVar5) {
        return 0;
      }
      lVar1 = *(longlong *)(param_1 + 0x60);
      uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
      uVar8 = (**(code **)(*plVar11 + 0x40))(plVar11);
      uVar9 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x48))((longlong *)(lVar1 + 0x10));
      uVar10 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x40))(lVar1 + 0x10);
      local_908 = uVar7;
      local_8d8 = FUN_1404ca9a0(param_1,uVar10,uVar9,uVar8);
      if (*param_2 != 0x1b63) {
        plVar13 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        (**(code **)(*plVar13 + 0x2b8))(plVar13,local_8d8);
        FUN_140362560(local_498);
        plVar13 = *(longlong **)(param_1 + 0x60);
        uVar7 = (**(code **)(plVar13[2] + 0x48))();
        uVar8 = (**(code **)(plVar13[2] + 0x40))(plVar13 + 2);
        uVar9 = (**(code **)(*plVar13 + 8))(plVar13);
        local_8f0 = 0;
        local_8f8 = 0;
        local_900 = 0x193;
        local_908 = CONCAT22(local_908._2_2_,(short)local_8d8);
        iVar5 = FUN_140362620(local_498,uVar9,uVar8,uVar7);
        if (iVar5 == 0) {
          local_908 = 0x2d8;
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar13 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
          (**(code **)(*plVar13 + 0x348))(plVar13,local_498,1);
        }
        FUN_1403625e0(local_498);
      }
      FUN_14035f2f0(local_8c8);
      plVar13 = *(longlong **)(param_1 + 0x60);
      uVar3 = (**(code **)(*plVar11 + 0x48))(plVar11);
      uVar4 = (**(code **)(*plVar11 + 0x40))(plVar11);
      uVar7 = (**(code **)(*plVar13 + 8))(plVar13);
      local_8e0 = 0;
      local_8e8 = 0;
      local_8f0 = local_8f0 & 0xffff0000;
      local_8f8 = CONCAT22(local_8f8._2_2_,(short)*param_2);
      local_908 = CONCAT22(local_908._2_2_,uVar4);
      local_900 = uVar3;
      iVar5 = FUN_14035f4c0(local_8c8,0x18,uVar7,local_8d4);
      if (iVar5 != 0) {
        plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        (**(code **)(*plVar11 + 0x348))(plVar11,local_8c8,1);
      }
      FUN_14035f340(local_8c8);
    }
    else {
      FUN_14035f2f0(local_8c8);
      plVar11 = *(longlong **)(param_1 + 0x60);
      uVar3 = (**(code **)(plVar11[2] + 0x48))();
      uVar4 = (**(code **)(plVar11[2] + 0x40))(plVar11 + 2);
      uVar7 = (**(code **)(*plVar11 + 8))(plVar11);
      local_8e0 = 0;
      local_8e8 = 0;
      local_8f0 = (uint)local_8f0._2_2_ << 0x10;
      local_8f8 = CONCAT22(local_8f8._2_2_,(short)*param_2);
      local_908 = CONCAT22(local_908._2_2_,uVar4);
      local_900 = uVar3;
      iVar5 = FUN_14035f4c0(local_8c8,0x18,uVar7,0);
      if (iVar5 != 0) {
        plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        (**(code **)(*plVar11 + 0x348))(plVar11,local_8c8,1);
      }
      FUN_14035f340(local_8c8);
    }
    uVar12 = 1;
  }
  return uVar12;
}

// ==== CMonster::helper_1404cba00  @1404cba00  [medium:callgraph-r1]  (orig: FUN_1404cba00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404cba00(longlong param_1,undefined4 *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  longlong *plVar7;
  undefined1 auStack_4c8 [32];
  ulonglong local_4a8;
  undefined4 local_4a0;
  int local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined1 local_480;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_4a8 = CONCAT44(local_4a8._4_4_,0x748);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == (undefined4 *)0x0) {
    local_4a8 = CONCAT44(local_4a8._4_4_,0x749);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x10) == 0) {
    local_4a8 = CONCAT44(local_4a8._4_4_,0x74a);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar7 = (longlong *)
             (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                       (*(longlong **)(param_2 + 0x10),10);
    iVar1 = (**(code **)(*plVar7 + 0x48))(plVar7);
    plVar7 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
    iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x78))();
    iVar3 = (**(code **)(*plVar7 + 0x80))(plVar7);
    iVar6 = iVar3 - iVar2;
    if (iVar3 - iVar2 < 1) {
      iVar6 = 0;
    }
    if (iVar1 * 10000 <= iVar6) {
      iVar6 = iVar1 * 10000;
    }
    if (0 < iVar6) {
      plVar7 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      local_4a8 = 0;
      (**(code **)(*plVar7 + 0x2e0))(plVar7,0,(longlong)iVar6,1);
    }
    FUN_140386780(local_468);
    plVar7 = *(longlong **)(param_1 + 0x60);
    uVar4 = (**(code **)(*plVar7 + 8))();
    uVar5 = (**(code **)(*plVar7 + 8))(plVar7);
    local_480 = 0;
    local_488 = 0;
    local_490 = 0;
    local_4a8 = local_4a8 & 0xffffffffffffff00;
    local_4a0 = uVar4;
    local_498 = iVar6;
    iVar6 = FUN_1403868f0(local_468,uVar5,*param_2,0);
    if (iVar6 == 0) {
      local_4a8 = CONCAT44(local_4a8._4_4_,0x756);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar7 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      (**(code **)(*plVar7 + 0x348))(plVar7,local_468,1);
    }
    FUN_1403867d0(local_468);
  }
  return;
}

// ==== CMonster::helper_1404cbc40  @1404cbc40  [medium:callgraph-r3]  (orig: FUN_1404cbc40)
longlong * FUN_1404cbc40(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  char cVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  undefined8 uVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  
  uVar8 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
  plVar9 = (longlong *)FUN_1400875f0(uVar8);
  plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,param_3);
  plVar9 = plVar10;
  if (plVar10 != (longlong *)0x0) {
    plVar11 = (longlong *)(**(code **)(*plVar10 + 0x160))(plVar10);
    plVar9 = (longlong *)0x0;
    if (plVar11 != (longlong *)0x0) {
      uVar2 = (**(code **)(*plVar10 + 0x40))(plVar10);
      uVar3 = (**(code **)(*plVar10 + 0x48))(plVar10);
      plVar12 = (longlong *)
                (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
      plVar9 = (longlong *)0x0;
      if (plVar12 != (longlong *)0x0) {
        uVar4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
        uVar5 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
        iVar6 = (**(code **)(*plVar11 + 8))(plVar11);
        iVar7 = (**(code **)(*plVar12 + 8))(plVar12);
        if ((iVar6 != iVar7) ||
           (cVar1 = FUN_1401671e0(CONCAT44(uVar5,uVar4),CONCAT44(uVar3,uVar2),param_2),
           plVar9 = plVar10, cVar1 == '\0')) {
          plVar9 = (longlong *)0x0;
        }
      }
    }
  }
  return plVar9;
}

// ==== CMonster::helper_1404cbfe0  @1404cbfe0  [medium:callgraph-r1]  (orig: FUN_1404cbfe0)
undefined8 FUN_1404cbfe0(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = *(longlong *)(param_1 + 0x28) - *(longlong *)(param_1 + 0x20);
  return CONCAT71((int7)(uVar1 >> 8),(uVar1 & 0xfffffffffffffff8) != 0);
}

// ==== CMonster::helper_1404cc740  @1404cc740  [medium:callgraph-r3]  (orig: FUN_1404cc740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404cc740(longlong param_1,longlong param_2,undefined4 param_3,undefined4 param_4,
                  longlong param_5,longlong *param_6,longlong param_7,longlong param_8,
                  longlong param_9)

{
  longlong lVar1;
  longlong *plVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  longlong *plVar8;
  ulonglong uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  ulonglong uVar14;
  undefined1 auStack_538 [32];
  uint local_518;
  undefined4 local_510;
  undefined4 local_508;
  undefined4 local_500;
  undefined4 local_4f8;
  undefined4 local_4f0;
  undefined1 local_4e8;
  int local_4d8;
  undefined4 local_4d4;
  undefined4 local_4d0;
  longlong local_4c8;
  longlong local_4c0;
  longlong *local_4b8;
  longlong local_4b0;
  longlong local_4a8;
  longlong local_4a0;
  undefined8 local_498;
  undefined1 local_488 [1072];
  ulonglong local_58;
  
  local_498 = 0xfffffffffffffffe;
  local_58 = DAT_1409707c0 ^ (ulonglong)auStack_538;
  local_4a0 = param_5;
  local_4b8 = param_6;
  local_4a8 = param_7;
  if (param_2 != 0) {
    local_4d4 = param_4;
    local_4d0 = param_3;
    local_4c8 = param_1;
    local_4b0 = param_2;
    FUN_140386780(local_488);
    plVar8 = (longlong *)
             (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))(*(longlong **)(param_2 + 0x40),1)
    ;
    plVar11 = *(longlong **)(param_1 + 0x60);
    uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
    uVar4 = (**(code **)(*plVar11 + 8))(plVar11);
    local_4e8 = 0;
    local_4f0 = 0;
    local_4f8 = 0;
    local_500 = 0;
    local_508 = local_4d4;
    local_518 = local_518 & 0xffffff00;
    local_510 = param_3;
    iVar5 = FUN_140386a50(local_488,uVar4,uVar3,0);
    if (iVar5 == 0) {
      local_518 = 2999;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      uVar14 = 0;
      local_4d8 = 0;
      uVar9 = *(longlong *)(param_5 + 0x20) - *(longlong *)(param_5 + 0x18) >> 3;
      if (0 < (int)uVar9) {
        do {
          if (uVar9 <= uVar14) {
            _invalid_parameter_noinfo();
          }
          plVar11 = *(longlong **)(*(longlong *)(param_5 + 0x18) + uVar14 * 8);
          if ((ulonglong)(*(longlong *)(param_9 + 0x20) - *(longlong *)(param_9 + 0x18) >> 2) <=
              uVar14) {
            _invalid_parameter_noinfo();
          }
          local_4c0 = *(longlong *)(param_9 + 0x18);
          if ((ulonglong)(*(longlong *)(param_8 + 0x20) - *(longlong *)(param_8 + 0x18) >> 2) <=
              uVar14) {
            _invalid_parameter_noinfo();
          }
          lVar13 = *(longlong *)(param_8 + 0x18);
          if ((ulonglong)(*(longlong *)(param_7 + 0x20) - *(longlong *)(param_7 + 0x18) >> 2) <=
              uVar14) {
            _invalid_parameter_noinfo();
          }
          lVar1 = *(longlong *)(param_7 + 0x18);
          uVar3 = (**(code **)(*plVar11 + 0x10))(plVar11);
          local_4f8 = 0;
          local_500 = 0;
          local_508 = 0;
          local_510 = *(undefined4 *)(local_4c0 + uVar14 * 4);
          local_518 = *(uint *)(lVar13 + uVar14 * 4);
          iVar5 = FUN_140387150(local_488,uVar3,*(undefined4 *)(lVar1 + uVar14 * 4),0);
          lVar13 = local_4c8;
          if (iVar5 == 0) {
            plVar11 = (longlong *)(*(longlong *)(local_4c8 + 0x60) + 0x10);
            (**(code **)(*plVar11 + 0x348))(plVar11,local_488,1);
            plVar8 = (longlong *)
                     (**(code **)(**(longlong **)(local_4b0 + 0x40) + 0x10))
                               (*(longlong **)(local_4b0 + 0x40),1);
            plVar11 = *(longlong **)(lVar13 + 0x60);
            uVar3 = (**(code **)(*(longlong *)(*(longlong *)(lVar13 + 0x60) + 0x10) + 0x48))();
            uVar4 = (**(code **)(plVar11[2] + 0x40))(plVar11 + 2);
            uVar6 = (**(code **)(*plVar8 + 0x48))(plVar8);
            uVar7 = (**(code **)(*plVar11 + 8))(plVar11);
            local_4e8 = 0;
            local_4f0 = 0;
            local_4f8 = 0;
            local_500 = 0;
            local_518 = local_518 & 0xffffff00;
            local_510 = uVar4;
            local_508 = uVar3;
            FUN_140386a50(local_488,uVar7,uVar6);
            param_5 = local_4a0;
            if ((ulonglong)(*(longlong *)(local_4a0 + 0x20) - *(longlong *)(local_4a0 + 0x18) >> 3)
                <= uVar14) {
              _invalid_parameter_noinfo();
            }
            plVar11 = *(longlong **)(*(longlong *)(param_5 + 0x18) + uVar14 * 8);
            if ((ulonglong)(*(longlong *)(param_9 + 0x20) - *(longlong *)(param_9 + 0x18) >> 2) <=
                uVar14) {
              _invalid_parameter_noinfo();
            }
            local_4c0 = *(longlong *)(param_9 + 0x18);
            if ((ulonglong)(*(longlong *)(param_8 + 0x20) - *(longlong *)(param_8 + 0x18) >> 2) <=
                uVar14) {
              _invalid_parameter_noinfo();
            }
            param_7 = local_4a8;
            lVar13 = *(longlong *)(param_8 + 0x18);
            if ((ulonglong)(*(longlong *)(local_4a8 + 0x20) - *(longlong *)(local_4a8 + 0x18) >> 2)
                <= uVar14) {
              _invalid_parameter_noinfo();
            }
            lVar1 = *(longlong *)(param_7 + 0x18);
            uVar3 = (**(code **)(*plVar11 + 0x10))(plVar11);
            local_4f8 = 0;
            local_500 = 0;
            local_508 = 0;
            local_510 = *(undefined4 *)(local_4c0 + uVar14 * 4);
            local_518 = *(uint *)(lVar13 + uVar14 * 4);
            FUN_140387150(local_488,uVar3,*(undefined4 *)(lVar1 + uVar14 * 4),0);
          }
          local_4d8 = local_4d8 + 1;
          uVar14 = uVar14 + 1;
          uVar9 = *(longlong *)(param_5 + 0x20) - *(longlong *)(param_5 + 0x18) >> 3;
          param_6 = local_4b8;
        } while (local_4d8 < (int)uVar9);
      }
      plVar11 = (longlong *)param_6[3];
      if ((longlong *)param_6[4] < plVar11) {
        _invalid_parameter_noinfo();
      }
      uVar3 = local_4d0;
      plVar8 = (longlong *)*param_6;
      while( true ) {
        lVar13 = 0;
        plVar2 = (longlong *)param_6[4];
        if (plVar2 < (longlong *)param_6[3]) {
          _invalid_parameter_noinfo();
        }
        if ((plVar8 == (longlong *)0x0) || (plVar8 != (longlong *)*param_6)) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == plVar2) break;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar13 = *plVar8;
        }
        if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar2 = (longlong *)*plVar11;
        if (plVar2 != (longlong *)0x0) {
          uVar4 = (**(code **)(*plVar2 + 0x10))(plVar2);
          local_4f8 = 2;
          local_500 = 0;
          local_508 = 0;
          local_510 = 0;
          local_518 = 0;
          iVar5 = FUN_140387150(local_488,uVar4,0,0);
          lVar13 = local_4c8;
          if (iVar5 == 0) {
            plVar12 = (longlong *)(*(longlong *)(local_4c8 + 0x60) + 0x10);
            (**(code **)(*plVar12 + 0x348))(plVar12,local_488,1);
            plVar10 = (longlong *)
                      (**(code **)(**(longlong **)(local_4b0 + 0x40) + 0x10))
                                (*(longlong **)(local_4b0 + 0x40),1);
            plVar12 = *(longlong **)(lVar13 + 0x60);
            (**(code **)(*plVar10 + 0x48))(plVar10);
            uVar4 = (**(code **)(*plVar12 + 8))(plVar12);
            local_4e8 = 0;
            local_4f0 = 0;
            local_4f8 = 0;
            local_500 = 0;
            local_508 = local_4d4;
            local_510 = uVar3;
            local_518 = local_518 & 0xffffff00;
            FUN_140386a50(local_488,uVar4);
            uVar4 = (**(code **)(*plVar2 + 0x10))(plVar2);
            local_4f8 = 2;
            local_500 = 0;
            local_508 = 0;
            local_510 = 0;
            local_518 = 0;
            FUN_140387150(local_488,uVar4,0,0);
          }
        }
        lVar13 = 0;
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar13 = *plVar8;
        }
        if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
        param_6 = local_4b8;
      }
      plVar11 = (longlong *)(*(longlong *)(local_4c8 + 0x60) + 0x10);
      (**(code **)(*plVar11 + 0x348))(plVar11,local_488,1);
    }
    FUN_1403867d0(local_488);
  }
  return;
}

// ==== CMonster::helper_1404cdb00  @1404cdb00  [medium:callgraph-r2]  (orig: FUN_1404cdb00)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404cdb00(longlong param_1,undefined2 *param_2)

{
  longlong *plVar1;
  undefined2 *puVar2;
  char cVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong *plVar14;
  longlong *plVar15;
  undefined1 auStack_598 [32];
  undefined4 local_578;
  undefined2 local_570;
  undefined2 local_568;
  undefined2 local_560;
  undefined4 local_558;
  undefined4 local_550;
  longlong *local_548;
  undefined4 local_540;
  undefined4 local_53c;
  undefined8 local_538;
  undefined8 local_530;
  longlong *local_528 [3];
  longlong *local_510;
  longlong *local_508;
  undefined8 local_500;
  longlong local_4f8;
  uint local_4f0;
  longlong *local_4e8;
  longlong *local_4e0 [3];
  void *local_4c8;
  longlong local_4c0;
  undefined8 local_4b8;
  undefined2 *local_4b0;
  undefined8 local_4a8;
  undefined8 uStack_4a0;
  undefined4 local_498;
  undefined4 uStack_494;
  undefined4 uStack_490;
  undefined4 uStack_48c;
  undefined8 local_488;
  longlong *local_480;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_598;
  local_4f8 = param_1;
  local_4b0 = param_2;
  if (param_2 == (undefined2 *)0x0) {
    local_578 = 0x1b7;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else if (*(longlong *)(param_2 + 0x20) == 0) {
    local_578 = 0x1b8;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else if (*(longlong *)(param_1 + 0x60) == 0) {
    local_578 = 0x1b9;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar10 = 0;
  }
  else {
    FUN_1401d6d10(param_2 + 0x24);
    plVar15 = (longlong *)0x0;
    *(undefined4 *)(param_2 + 0x3c) = 0;
    local_538 = (longlong *)0x0;
    uVar6 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    local_538 = (longlong *)CONCAT44(local_538._4_4_,uVar6);
    uVar6 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    local_538 = (longlong *)CONCAT44(uVar6,(undefined4)local_538);
    plVar14 = *(longlong **)(param_2 + 0x20);
    local_4e8 = plVar14;
    plVar11 = (longlong *)(**(code **)(*plVar14 + 8))(plVar14,0xf);
    uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_540 = uVar6;
    local_548 = operator_new(8);
    local_528[0] = plVar15;
    if (local_548 != (longlong *)0x0) {
      *local_548 = (longlong)local_528;
      local_528[0] = local_548;
    }
    local_510 = (longlong *)0x0;
    local_508 = (longlong *)0x0;
    local_500 = 0;
    local_530 = local_548;
    lVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    uVar10 = local_538;
    if (lVar12 == 0) {
      local_578 = 0x1c9;
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_510 != (longlong *)0x0) {
        operator_delete(local_510);
      }
      local_510 = (longlong *)0x0;
      local_508 = (longlong *)0x0;
      local_500 = 0;
      operator_delete(local_528[0]);
      uVar10 = 0;
    }
    else {
      local_578 = 0x1043;
      FUN_1402d2470(lVar12,local_528,local_538,uVar6);
      local_538 = operator_new(8);
      plVar11 = local_510;
      local_4e0[0] = plVar15;
      if (local_538 != (longlong *)0x0) {
        *local_538 = (longlong)local_4e0;
        local_4e0[0] = local_538;
      }
      local_4c8 = (void *)0x0;
      local_4c0 = 0;
      local_4b8 = 0;
      local_4f0 = 0;
      local_4a8 = (longlong *)0x0;
      local_530 = local_538;
      if (local_508 < local_510) {
        _invalid_parameter_noinfo();
      }
      plVar1 = local_528[0];
      local_4a8 = local_528[0];
      uStack_4a0 = plVar11;
      local_4a8._0_4_ = SUB84(local_528[0],0);
      local_4a8._4_4_ = (undefined4)((ulonglong)local_528[0] >> 0x20);
      uStack_4a0._0_4_ = SUB84(plVar11,0);
      uStack_4a0._4_4_ = (undefined4)((ulonglong)plVar11 >> 0x20);
      local_498 = (undefined4)local_4a8;
      uStack_494 = local_4a8._4_4_;
      uStack_490 = (undefined4)uStack_4a0;
      uStack_48c = uStack_4a0._4_4_;
      local_4a8 = plVar1;
      uStack_4a0 = plVar11;
      while( true ) {
        plVar13 = local_508;
        local_480 = (longlong *)0x0;
        if (local_508 < local_510) {
          _invalid_parameter_noinfo();
        }
        local_480 = local_528[0];
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_528[0])) {
          _invalid_parameter_noinfo();
        }
        if (plVar11 == plVar13) goto LAB_1404cdfe7;
        local_4f0 = (int)plVar15 + 1;
        plVar15 = (longlong *)(ulonglong)local_4f0;
        if (10000 < local_4f0) break;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar1;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar13 = (longlong *)*plVar11;
        local_548 = (longlong *)0x0;
        if ((plVar13 != (longlong *)0x0) &&
           (cVar3 = (**(code **)(*plVar13 + 0x40))(plVar13,&local_548), cVar3 != '\0')) {
          iVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
          iVar7 = (**(code **)(*local_548 + 0x10))();
          if ((iVar7 != iVar8) &&
             ((cVar3 = (**(code **)(*local_548 + 0x220))(), cVar3 != '\0' &&
              (cVar3 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_548), cVar3 == '\0')))) {
            uVar6 = (**(code **)(*local_548 + 0x40))();
            local_530 = (longlong *)CONCAT44(local_530._4_4_,uVar6);
            uVar6 = (**(code **)(*local_548 + 0x48))();
            local_530 = (longlong *)CONCAT44(uVar6,(undefined4)local_530);
            cVar3 = FUN_1401671e0(local_530,uVar10,local_540);
            if (cVar3 != '\0') {
              plVar13 = (longlong *)(**(code **)(*plVar14 + 8))(plVar14,1);
              lVar12 = *local_548;
              plVar14 = *(longlong **)(param_1 + 0x60);
              uVar6 = (**(code **)(*plVar13 + 0x48))(plVar13);
              uVar9 = (**(code **)(*plVar14 + 8))(plVar14);
              cVar3 = (**(code **)(lVar12 + 0x398))(local_548,uVar9,uVar6,0);
              param_1 = local_4f8;
              plVar14 = local_4e8;
              if (cVar3 == '\0') {
                FUN_1401af440(local_4e0,&local_548);
                param_1 = local_4f8;
                plVar14 = local_4e8;
              }
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar1;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
      }
      local_578 = 0x1d3;
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404cdfe7:
      local_4e8 = (longlong *)(local_4c0 - (longlong)local_4c8 >> 3);
      if (local_4e8 == (longlong *)0x0) {
        if (local_4c8 != (void *)0x0) {
          operator_delete(local_4c8);
        }
        local_4c8 = (void *)0x0;
        local_4c0 = 0;
        local_4b8 = 0;
        operator_delete(local_4e0[0]);
        if (local_510 != (longlong *)0x0) {
          operator_delete(local_510);
        }
        local_510 = (longlong *)0x0;
        local_508 = (longlong *)0x0;
        local_500 = 0;
        operator_delete(local_528[0]);
        uVar10 = 0;
      }
      else {
        iVar8 = tq::RandGet((int)local_4e8);
        if ((ulonglong)(local_4c0 - (longlong)local_4c8 >> 3) <= (ulonglong)(longlong)iVar8) {
          _invalid_parameter_noinfo();
        }
        plVar14 = *(longlong **)((longlong)local_4c8 + (longlong)iVar8 * 8);
        local_540 = 0;
        local_53c = 0;
        local_540 = (**(code **)(*plVar14 + 0x40))(plVar14);
        local_53c = (**(code **)(*plVar14 + 0x48))(plVar14);
        puVar2 = local_4b0;
        FUN_1401d8190(local_4b0 + 0x24,&local_540);
        uVar6 = (**(code **)(*plVar14 + 0x10))(plVar14);
        *(undefined4 *)(puVar2 + 0x3c) = uVar6;
        FUN_14035f2f0(local_468);
        plVar11 = *(longlong **)(param_1 + 0x60);
        uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
        uVar5 = (**(code **)(*plVar14 + 0x40))(plVar14);
        uVar6 = (**(code **)(*plVar14 + 0x10))(plVar14);
        uVar9 = (**(code **)(*plVar11 + 8))(plVar11);
        local_550 = 0;
        local_558 = 0;
        local_560 = 0;
        local_568 = *puVar2;
        local_578 = CONCAT22(local_578._2_2_,uVar5);
        local_570 = uVar4;
        iVar8 = FUN_14035f4c0(local_468,0x34,uVar9,uVar6);
        if (iVar8 != 0) {
          plVar14 = (longlong *)(*(longlong *)(local_4f8 + 0x60) + 0x10);
          (**(code **)(*plVar14 + 0x348))(plVar14,local_468,1);
        }
        FUN_14035f340(local_468);
        if (local_4c8 != (void *)0x0) {
          operator_delete(local_4c8);
        }
        local_4c8 = (void *)0x0;
        local_4c0 = 0;
        local_4b8 = 0;
        operator_delete(local_4e0[0]);
        if (local_510 != (longlong *)0x0) {
          operator_delete(local_510);
        }
        local_510 = (longlong *)0x0;
        local_508 = (longlong *)0x0;
        local_500 = 0;
        operator_delete(local_528[0]);
        uVar10 = 1;
      }
    }
  }
  return uVar10;
}

// ==== CMonster::helper_1404ce250  @1404ce250  [medium:callgraph-r2]  (orig: FUN_1404ce250)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1404ce250(longlong param_1,undefined2 *param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  char cVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  undefined8 uVar11;
  longlong *plVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong *plVar15;
  longlong lVar16;
  undefined1 auStack_618 [32];
  undefined4 local_5f8;
  undefined2 local_5f0;
  undefined2 local_5e8;
  undefined2 local_5e0;
  undefined4 local_5d8;
  undefined4 local_5d0;
  longlong *local_5c8;
  undefined8 local_5c0;
  undefined8 local_5b8;
  uint local_5b0;
  uint local_5ac;
  undefined4 local_5a8;
  undefined4 uStack_5a4;
  longlong *local_5a0 [3];
  longlong *local_588;
  longlong *local_580;
  undefined8 local_578;
  undefined4 local_570;
  undefined2 *local_568;
  int local_560;
  longlong local_558;
  longlong *local_550 [3];
  void *local_538;
  undefined8 local_530;
  undefined8 local_528;
  longlong *local_520 [3];
  void *local_508;
  undefined8 local_500;
  undefined8 local_4f8;
  longlong *local_4f0 [3];
  void *local_4d8;
  undefined8 local_4d0;
  undefined8 local_4c8;
  longlong *local_4c0 [3];
  void *local_4a8;
  undefined8 local_4a0;
  undefined8 local_498;
  longlong *local_490;
  undefined8 local_480;
  longlong *local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_480 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_618;
  local_568 = param_2;
  local_558 = param_1;
  if (param_2 == (undefined2 *)0x0) {
    local_5f8 = 0x25b;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = 0;
  }
  else if (*(longlong *)(param_2 + 0x20) == 0) {
    local_5f8 = 0x25c;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = 0;
  }
  else if (*(longlong *)(param_1 + 0x60) == 0) {
    local_5f8 = 0x25d;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar11 = 0;
  }
  else {
    plVar15 = (longlong *)0x0;
    local_5a8 = 0;
    uStack_5a4 = 0;
    local_5a8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    uStack_5a4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    FUN_1401d6d10(param_2 + 0x24);
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x20) + 0x10))
                        (*(longlong **)(param_2 + 0x20),0xf);
    uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_570 = uVar6;
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x20) + 0x10))
                        (*(longlong **)(param_2 + 0x20),0x28);
    local_560 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_5c0 = operator_new(8);
    local_5a0[0] = plVar15;
    if (local_5c0 != (longlong *)0x0) {
      *local_5c0 = (longlong)local_5a0;
      local_5a0[0] = local_5c0;
    }
    local_588 = (longlong *)0x0;
    local_580 = (longlong *)0x0;
    local_578 = 0;
    local_5b8 = local_5c0;
    lVar13 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    if (lVar13 == 0) {
      local_5f8 = 0x26a;
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_588 != (longlong *)0x0) {
        operator_delete(local_588);
      }
      local_588 = (longlong *)0x0;
      local_580 = (longlong *)0x0;
      local_578 = 0;
      operator_delete(local_5a0[0]);
      uVar11 = 0;
    }
    else {
      local_5f8 = 0x1043;
      uVar11 = CONCAT44(uStack_5a4,local_5a8);
      FUN_1402d2470(lVar13,local_5a0,uVar11,uVar6);
      local_5c0 = operator_new(8);
      local_4f0[0] = plVar15;
      if (local_5c0 != (longlong *)0x0) {
        *local_5c0 = (longlong)local_4f0;
        local_4f0[0] = local_5c0;
      }
      local_4d8 = (void *)0x0;
      local_4d0 = 0;
      local_4c8 = 0;
      local_5b8 = local_5c0;
      local_5c0 = operator_new(8);
      local_4c0[0] = plVar15;
      if (local_5c0 != (longlong *)0x0) {
        *local_5c0 = (longlong)local_4c0;
        local_4c0[0] = local_5c0;
      }
      local_4a8 = (void *)0x0;
      local_4a0 = 0;
      local_498 = 0;
      local_5b8 = local_5c0;
      local_5c0 = operator_new(8);
      local_520[0] = plVar15;
      if (local_5c0 != (longlong *)0x0) {
        *local_5c0 = (longlong)local_520;
        local_520[0] = local_5c0;
      }
      local_508 = (void *)0x0;
      local_500 = 0;
      local_4f8 = 0;
      local_5b8 = local_5c0;
      local_5c0 = operator_new(8);
      plVar12 = local_588;
      local_550[0] = plVar15;
      if (local_5c0 != (longlong *)0x0) {
        *local_5c0 = (longlong)local_550;
        local_550[0] = local_5c0;
      }
      local_538 = (void *)0x0;
      local_530 = 0;
      local_528 = 0;
      local_5b0 = 0;
      local_5ac = 0;
      local_478 = (longlong *)0x0;
      local_5b8 = local_5c0;
      if (local_580 < local_588) {
        _invalid_parameter_noinfo();
      }
      plVar1 = local_5a0[0];
      local_478 = local_5a0[0];
      plVar14 = plVar15;
      while( true ) {
        plVar2 = local_580;
        local_490 = (longlong *)0x0;
        if (local_580 < local_588) {
          _invalid_parameter_noinfo();
        }
        local_490 = local_5a0[0];
        if ((plVar1 == (longlong *)0x0) || (plVar1 != local_5a0[0])) {
          _invalid_parameter_noinfo();
        }
        iVar10 = (int)plVar14;
        if ((plVar12 == plVar2) || ((local_560 <= iVar10 && (local_560 != 0)))) goto LAB_1404ce915;
        local_5ac = (int)plVar15 + 1;
        if (10000 < local_5ac) break;
        lVar13 = 0;
        local_5c8 = (longlong *)0x0;
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar16 = lVar13;
        }
        else {
          lVar16 = *plVar1;
        }
        if (*(longlong **)(lVar16 + 0x20) <= plVar12) {
          _invalid_parameter_noinfo();
        }
        if (*plVar12 != 0) {
          if (plVar1 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
          }
          else {
            lVar13 = *plVar1;
          }
          if (*(longlong **)(lVar13 + 0x20) <= plVar12) {
            _invalid_parameter_noinfo();
          }
          cVar3 = (**(code **)(*(longlong *)*plVar12 + 0x40))((longlong *)*plVar12,&local_5c8);
          if (cVar3 != '\0') {
            uVar6 = (**(code **)(*local_5c8 + 0x40))();
            local_5b8 = (longlong *)CONCAT44(local_5b8._4_4_,uVar6);
            uVar6 = (**(code **)(*local_5c8 + 0x48))();
            local_5b8 = (longlong *)CONCAT44(uVar6,(undefined4)local_5b8);
            plVar15 = *(longlong **)(param_1 + 0x60);
            iVar7 = (**(code **)(*local_5c8 + 0x10))();
            iVar8 = (**(code **)(*plVar15 + 8))(plVar15);
            if ((((iVar7 != iVar8) &&
                 (cVar3 = FUN_1401671e0(local_5b8,uVar11,local_570), cVar3 != '\0')) &&
                (cVar3 = (**(code **)(*local_5c8 + 0x220))(), cVar3 != '\0')) &&
               (cVar3 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_5c8), cVar3 == '\0')) {
              local_5b0 = iVar10 + 1;
              plVar14 = (longlong *)
                        (**(code **)(**(longlong **)(local_568 + 0x20) + 0x10))
                                  (*(longlong **)(local_568 + 0x20),1);
              lVar13 = *local_5c8;
              plVar15 = *(longlong **)(param_1 + 0x60);
              uVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
              uVar9 = (**(code **)(*plVar15 + 8))(plVar15);
              cVar3 = (**(code **)(lVar13 + 0x398))(local_5c8,uVar9,uVar6,0);
              if (cVar3 == '\0') {
                uVar6 = (**(code **)(*local_5c8 + 0x40))();
                local_5c0 = (longlong *)CONCAT44(local_5c0._4_4_,uVar6);
                uVar6 = (**(code **)(*local_5c8 + 0x48))();
                local_5c0 = (longlong *)CONCAT44(uVar6,(undefined4)local_5c0);
                FUN_1401d8190(local_568 + 0x24,&local_5c0);
                FUN_14035f2f0(local_468);
                plVar15 = *(longlong **)(param_1 + 0x60);
                uVar4 = (**(code **)(*local_5c8 + 0x48))();
                uVar5 = (**(code **)(*local_5c8 + 0x40))();
                (**(code **)(*local_5c8 + 0x10))();
                uVar6 = (**(code **)(*plVar15 + 8))(plVar15);
                local_5d0 = 0;
                local_5d8 = 0;
                local_5e0 = 0;
                local_5e8 = *local_568;
                local_5f8 = CONCAT22(local_5f8._2_2_,uVar5);
                local_5f0 = uVar4;
                iVar10 = FUN_14035f4c0(local_468,0x34,uVar6);
                param_1 = local_558;
                if (iVar10 != 0) {
                  plVar15 = (longlong *)(*(longlong *)(local_558 + 0x60) + 0x10);
                  (**(code **)(*plVar15 + 0x348))(plVar15,local_468,1);
                }
                FUN_14035f340(local_468);
              }
            }
          }
        }
        if (plVar1 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar13 = 0;
        }
        else {
          lVar13 = *plVar1;
        }
        if (*(longlong **)(lVar13 + 0x20) <= plVar12) {
          _invalid_parameter_noinfo();
        }
        plVar12 = plVar12 + 1;
        plVar15 = (longlong *)(ulonglong)local_5ac;
        plVar14 = (longlong *)(ulonglong)local_5b0;
      }
      local_5f8 = 0x278;
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404ce915:
      if (iVar10 == 0) {
        if (local_538 != (void *)0x0) {
          operator_delete(local_538);
        }
        local_538 = (void *)0x0;
        local_530 = 0;
        local_528 = 0;
        operator_delete(local_550[0]);
        if (local_508 != (void *)0x0) {
          operator_delete(local_508);
        }
        local_508 = (void *)0x0;
        local_500 = 0;
        local_4f8 = 0;
        operator_delete(local_520[0]);
        if (local_4a8 != (void *)0x0) {
          operator_delete(local_4a8);
        }
        local_4a8 = (void *)0x0;
        local_4a0 = 0;
        local_498 = 0;
        operator_delete(local_4c0[0]);
        if (local_4d8 != (void *)0x0) {
          operator_delete(local_4d8);
        }
        local_4d8 = (void *)0x0;
        local_4d0 = 0;
        local_4c8 = 0;
        operator_delete(local_4f0[0]);
        if (local_588 != (longlong *)0x0) {
          operator_delete(local_588);
        }
        local_588 = (longlong *)0x0;
        local_580 = (longlong *)0x0;
        local_578 = 0;
        operator_delete(local_5a0[0]);
        uVar11 = 0;
      }
      else {
        if (local_538 != (void *)0x0) {
          operator_delete(local_538);
        }
        local_538 = (void *)0x0;
        local_530 = 0;
        local_528 = 0;
        operator_delete(local_550[0]);
        if (local_508 != (void *)0x0) {
          operator_delete(local_508);
        }
        local_508 = (void *)0x0;
        local_500 = 0;
        local_4f8 = 0;
        operator_delete(local_520[0]);
        if (local_4a8 != (void *)0x0) {
          operator_delete(local_4a8);
        }
        local_4a8 = (void *)0x0;
        local_4a0 = 0;
        local_498 = 0;
        operator_delete(local_4c0[0]);
        if (local_4d8 != (void *)0x0) {
          operator_delete(local_4d8);
        }
        local_4d8 = (void *)0x0;
        local_4d0 = 0;
        local_4c8 = 0;
        operator_delete(local_4f0[0]);
        if (local_588 != (longlong *)0x0) {
          operator_delete(local_588);
        }
        local_588 = (longlong *)0x0;
        local_580 = (longlong *)0x0;
        local_578 = 0;
        operator_delete(local_5a0[0]);
        uVar11 = 1;
      }
    }
  }
  return uVar11;
}

// ==== CMonster::helper_1404ceb90  @1404ceb90  [medium:callgraph-r3]  (orig: FUN_1404ceb90)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404ceb90(longlong param_1,longlong param_2,undefined8 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  void *pvVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  longlong *plVar12;
  longlong lVar13;
  ulonglong uVar14;
  longlong *plVar15;
  longlong lVar16;
  ulonglong uVar17;
  undefined1 auStack_558 [32];
  uint local_538;
  undefined4 local_530;
  int local_528;
  int local_520;
  uint local_518;
  uint local_510;
  uint local_508;
  int local_4f8;
  int local_4f4;
  longlong local_4f0;
  longlong *local_4e8;
  int local_4e0;
  int local_4dc;
  undefined8 local_4d8;
  int local_4d0;
  int local_4cc;
  undefined4 local_4c8;
  int local_4c4;
  longlong *local_4c0 [3];
  void *local_4a8;
  longlong local_4a0;
  undefined8 local_498;
  longlong local_490;
  undefined8 local_488;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_488 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_558;
  local_4f0 = param_1;
  local_4c8 = param_4;
  local_490 = param_2;
  local_4e8 = operator_new(8);
  if (local_4e8 == (longlong *)0x0) {
    local_4c0[0] = (longlong *)0x0;
  }
  else {
    *local_4e8 = (longlong)local_4c0;
    local_4c0[0] = local_4e8;
  }
  local_4a8 = (void *)0x0;
  local_4a0 = 0;
  local_498 = 0;
  local_4d8 = local_4e8;
  FUN_140386780(local_478);
  plVar15 = *(longlong **)(param_1 + 0x60);
  iVar5 = (**(code **)(plVar15[2] + 0x48))();
  uVar6 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
  uVar7 = (**(code **)(*plVar15 + 8))(plVar15);
  local_508 = local_508 & 0xffffff00;
  local_510 = 0;
  local_518 = 0;
  local_520 = 0;
  local_538 = local_538 & 0xffffff00;
  local_530 = uVar6;
  local_528 = iVar5;
  iVar5 = FUN_140386a50(local_478,uVar7,15000,0);
  if (iVar5 == 0) {
    local_538 = 0xb34;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    local_4f8 = 0;
    while (uVar14 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3,
          local_4f8 < (int)uVar14) {
      local_4cc = 0;
      uVar17 = (ulonglong)local_4f8;
      if (uVar14 <= uVar17) {
        _invalid_parameter_noinfo();
      }
      plVar15 = *(longlong **)(*(longlong *)(param_2 + 0x18) + uVar17 * 8);
      local_4e8 = plVar15;
      iVar5 = (**(code **)(*plVar15 + 0x40))(plVar15);
      iVar11 = (**(code **)(*plVar15 + 0x48))(plVar15);
      local_4dc = iVar11;
      local_4c4 = iVar5;
      plVar12 = (longlong *)FUN_1401181a0();
      lVar13 = *plVar12;
      uVar6 = (**(code **)(*plVar15 + 0x10))(plVar15);
      local_508 = 0;
      local_510 = local_510 & 0xffff0000;
      local_518 = local_518 & 0xffffff00;
      local_520 = 0;
      local_528 = 0;
      local_530 = 0;
      local_538 = local_4c8;
      (**(code **)(lVar13 + 8))(plVar12,uVar6,0x6e);
      lVar13 = (**(code **)(*plVar15 + 0x160))(plVar15);
      if (lVar13 == 0) {
        local_538 = 0xb4c;
        log_InlineLogERROR(&DAT_1406d9c10);
        FUN_1403867d0(local_478);
        if (local_4a8 != (void *)0x0) {
          operator_delete(local_4a8);
        }
        local_4a8 = (void *)0x0;
        local_4a0 = 0;
        local_498 = 0;
        operator_delete(local_4c0[0]);
        return;
      }
      local_4f4 = (**(code **)(*(longlong *)(*(longlong *)(local_4f0 + 0x60) + 0x10) + 0x50))();
      local_4d0 = 0;
      iVar10 = 0;
      while ((iVar2 = local_4d0, iVar1 = local_4f4, local_4d0 < 8 &&
             (cVar4 = FUN_14015f9d0(lVar13,iVar5,iVar11), cVar4 != '\0'))) {
        lVar16 = (longlong)iVar1;
        cVar4 = FUN_1402c3cc0(lVar13,iVar5 + *(int *)(&DAT_14078e2b0 + lVar16 * 4),
                              iVar11 + *(int *)(&DAT_14078e2d0 + lVar16 * 4));
        if (cVar4 == '\0') break;
        iVar5 = iVar5 + *(int *)(&DAT_14078e2b0 + lVar16 * 4);
        iVar11 = iVar11 + *(int *)(&DAT_14078e2d0 + lVar16 * 4);
        local_4cc = iVar10 + 1;
        local_4d0 = iVar2 + 1;
        local_4dc = iVar11;
        local_4c4 = iVar5;
        iVar10 = local_4cc;
      }
      lVar13 = *(longlong *)(local_4f0 + 0x60);
      uVar6 = (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x48))();
      uVar7 = (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x40))(lVar13 + 0x10);
      uVar8 = (**(code **)(*local_4e8 + 0x48))();
      uVar9 = (**(code **)(*local_4e8 + 0x40))(local_4e8);
      local_538 = uVar6;
      uVar6 = FUN_1404ca9a0(local_4f0,uVar9,uVar8,uVar7);
      plVar15 = local_4e8;
      (**(code **)(*local_4e8 + 0x2b8))(local_4e8,uVar6);
      uVar6 = (**(code **)(*plVar15 + 0x10))(plVar15);
      local_518 = 0;
      local_528 = local_4f4;
      local_530 = 0;
      local_538 = 0;
      local_520 = iVar10;
      iVar10 = FUN_140387150(local_478,uVar6,0,0);
      param_1 = local_4f0;
      if (iVar10 == 0) {
        plVar15 = (longlong *)(*(longlong *)(local_4f0 + 0x60) + 0x10);
        (**(code **)(*plVar15 + 0x348))(plVar15,local_478,1);
        plVar15 = *(longlong **)(param_1 + 0x60);
        iVar5 = (**(code **)(plVar15[2] + 0x48))();
        uVar6 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
        uVar7 = (**(code **)(*plVar15 + 8))(plVar15);
        local_508 = local_508 & 0xffffff00;
        local_510 = 0;
        local_518 = 0;
        local_520 = 0;
        local_538 = local_538 & 0xffffff00;
        local_530 = uVar6;
        local_528 = iVar5;
        FUN_140386a50(local_478,uVar7,15000,0);
        param_2 = local_490;
      }
      else {
        local_4d8 = (longlong *)CONCAT44(iVar11,iVar5);
        FUN_1401d8190(local_4c0,&local_4d8);
        local_4f8 = local_4f8 + 1;
        param_2 = local_490;
        param_1 = local_4f0;
      }
    }
    plVar15 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
    (**(code **)(*plVar15 + 0x348))(plVar15,local_478,1);
  }
  local_4e0 = 0;
  while (iVar5 = local_4e0,
        uVar14 = *(longlong *)(param_2 + 0x20) - *(longlong *)(param_2 + 0x18) >> 3,
        local_4e0 < (int)uVar14) {
    uVar17 = (ulonglong)local_4e0;
    if (uVar14 <= uVar17) {
      _invalid_parameter_noinfo();
    }
    plVar15 = *(longlong **)(*(longlong *)(param_2 + 0x18) + uVar17 * 8);
    if ((ulonglong)(local_4a0 - (longlong)local_4a8 >> 3) <= uVar17) {
      _invalid_parameter_noinfo();
    }
    pvVar3 = local_4a8;
    if ((plVar15 != (longlong *)0x0) &&
       ((iVar11 = (**(code **)(*plVar15 + 0x40))(plVar15),
        iVar11 != *(int *)((longlong)pvVar3 + uVar17 * 8) ||
        (iVar11 = (**(code **)(*plVar15 + 0x48))(plVar15),
        iVar11 != *(int *)((longlong)pvVar3 + uVar17 * 8 + 4))))) {
      (**(code **)(*plVar15 + 0x378))
                (plVar15,*(undefined4 *)((longlong)pvVar3 + uVar17 * 8),
                 *(undefined4 *)((longlong)pvVar3 + uVar17 * 8 + 4));
    }
    param_2 = local_490;
    local_4e0 = iVar5 + 1;
  }
  FUN_1403867d0(local_478);
  if (local_4a8 != (void *)0x0) {
    operator_delete(local_4a8);
  }
  local_4a8 = (void *)0x0;
  local_4a0 = 0;
  local_498 = 0;
  operator_delete(local_4c0[0]);
  return;
}

// ==== CMonster::helper_1404cf500  @1404cf500  [medium:callgraph-r1]  (orig: FUN_1404cf500)
void FUN_1404cf500(undefined8 param_1,longlong param_2,undefined4 param_3)

{
  int iVar1;
  longlong *plVar2;
  
  plVar2 = (longlong *)
           (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))(*(longlong **)(param_2 + 0x40),2);
  iVar1 = (**(code **)(*plVar2 + 0x48))(plVar2);
  if (iVar1 == 0x23) {
    FUN_1404ce250(param_1,param_2);
    return;
  }
  if (iVar1 != 0x29) {
    FUN_1404cb1c0(param_1,param_2,param_3);
    return;
  }
  FUN_1404cdb00();
  return;
}

// ==== CMonster::helper_1404cf580  @1404cf580  [medium:callgraph-r2]  (orig: FUN_1404cf580)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404cf580(longlong param_1,longlong param_2,int param_3)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined8 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong lVar15;
  undefined1 auStack_968 [32];
  uint *local_948;
  uint local_940;
  uint local_938;
  undefined8 local_930;
  uint local_928;
  uint local_920;
  uint local_918;
  char local_908;
  uint local_904;
  undefined4 local_900;
  uint local_8fc;
  longlong *local_8f8;
  undefined8 local_8f0;
  longlong *local_8e8 [3];
  void *local_8d0;
  undefined8 local_8c8;
  undefined8 local_8c0;
  longlong *local_8b8;
  undefined8 local_8b0;
  undefined1 local_8a8 [1072];
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_8b0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_968;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_948 = (uint *)CONCAT44(local_948._4_4_,0x35e);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    local_948 = (uint *)CONCAT44(local_948._4_4_,0x35f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    local_948 = (uint *)CONCAT44(local_948._4_4_,0x360);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_3 != 0) {
    uVar9 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
    plVar10 = (longlong *)FUN_1400875f0(uVar9);
    plVar10 = (longlong *)(**(code **)(*plVar10 + 0x20))(plVar10,param_3);
    local_8b8 = plVar10;
    if ((plVar10 == (longlong *)0x0) ||
       (cVar1 = (**(code **)(*plVar10 + 0x220))(plVar10), cVar1 == '\0')) {
      FUN_140388930(*(undefined8 *)(param_1 + 0x60));
      FUN_1404ca650(param_1,param_2,param_3);
    }
    else {
      plVar14 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      cVar1 = (**(code **)(*plVar14 + 0x3d8))(plVar14,plVar10,0);
      if (cVar1 == '\0') {
        FUN_140388930(*(undefined8 *)(param_1 + 0x60));
        FUN_1404ca650(param_1,param_2,param_3);
      }
      else {
        lVar12 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        uVar9 = (**(code **)(*plVar10 + 0x2a0))(plVar10);
        iVar2 = (**(code **)(lVar12 + 0x150))(*(longlong *)(param_1 + 0x60) + 0x10,uVar9);
        plVar14 = (longlong *)
                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                            (*(longlong **)(param_2 + 0x40),0xf);
        iVar3 = (**(code **)(*plVar14 + 0x48))(plVar14);
        if (iVar3 < iVar2) {
          FUN_1404ca650(param_1,param_2,param_3);
        }
        else {
          local_8f0 = (longlong *)0x0;
          local_904 = 0;
          local_8fc = 0;
          local_900 = 0;
          local_908 = '\0';
          uVar4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
          local_8f0 = (longlong *)CONCAT44(local_8f0._4_4_,uVar4);
          uVar4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
          local_8f0 = (longlong *)CONCAT44(uVar4,(undefined4)local_8f0);
          cVar1 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),plVar10);
          if (cVar1 == '\0') {
            cVar1 = FUN_1403e9290(plVar10);
            if (cVar1 != '\0') {
              FUN_140386780(local_8a8);
              plVar11 = (longlong *)
                        (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                  (*(longlong **)(param_2 + 0x40),1);
              plVar14 = *(longlong **)(param_1 + 0x60);
              uVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
              uVar4 = (**(code **)(*plVar10 + 0x40))(plVar10);
              uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
              uVar7 = (**(code **)(*plVar14 + 8))(plVar14);
              local_918 = local_918 & 0xffffff00;
              local_920 = 0;
              local_928 = 0;
              local_930 = (undefined4 *)((ulonglong)local_930._4_4_ << 0x20);
              local_948 = (uint *)((ulonglong)local_948 & 0xffffffffffffff00);
              local_940 = uVar4;
              local_938 = uVar5;
              iVar2 = FUN_140386a50(local_8a8,uVar7,uVar6,0);
              if (iVar2 == 0) {
                local_948 = (uint *)CONCAT44(local_948._4_4_,0x393);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                uVar4 = (**(code **)(*plVar10 + 0x10))(plVar10);
                local_928 = 2;
                local_930 = (undefined4 *)((ulonglong)local_930 & 0xffffffff00000000);
                local_938 = 0;
                local_940 = 0;
                local_948 = (uint *)CONCAT44(local_948._4_4_,local_900);
                iVar2 = FUN_140387150(local_8a8,uVar4,0,0);
                if (iVar2 == 0) {
                  local_948 = (uint *)CONCAT44(local_948._4_4_,0x397);
                  log_InlineLogERROR(&DAT_1406d9c10);
                  FUN_1403867d0(local_8a8);
                  return;
                }
                plVar14 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                (**(code **)(*plVar14 + 0x348))(plVar14,local_8a8,1);
              }
              FUN_1403867d0(local_8a8);
            }
            lVar15 = 0;
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),1);
            lVar12 = *plVar10;
            plVar14 = *(longlong **)(param_1 + 0x60);
            uVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
            uVar6 = (**(code **)(*plVar14 + 8))(plVar14);
            cVar1 = (**(code **)(lVar12 + 0x398))(plVar10,uVar6,uVar4,0);
            if (cVar1 == '\0') {
              iVar2 = (**(code **)(*plVar10 + 0x10))(plVar10);
              if (iVar2 - 0xaae61U < 99999) {
                plVar14 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140);
                plVar14 = (longlong *)(**(code **)(*plVar14 + 0x10))(plVar14,0x34);
                local_904 = (**(code **)(*plVar14 + 0x48))(plVar14);
              }
              else {
                plVar14 = (longlong *)
                          (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                    (*(longlong **)(param_2 + 0x40),0x1e);
                iVar2 = (**(code **)(*plVar14 + 0x48))(plVar14);
                if (iVar2 == 0) {
                  plVar14 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),10);
                  lVar12 = lVar15;
                  if (*(longlong *)(param_1 + 0x60) != 0) {
                    lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                  }
                  lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                  if (*(longlong *)(lVar13 + 0x100) == 0) {
                    local_948 = (uint *)CONCAT44(local_948._4_4_,0x144);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    lVar13 = lVar15;
                  }
                  else {
                    lVar13 = *(longlong *)(lVar13 + 0x100);
                  }
                  uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
                  local_948 = &local_900;
                  local_904 = FUN_1402f3100(lVar13,lVar12,plVar10,uVar4);
                }
                else {
                  plVar14 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),0x1e);
                  iVar2 = (**(code **)(*plVar14 + 0x48))(plVar14);
                  if (iVar2 == 1) {
                    plVar14 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),10);
                    uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
                    lVar12 = lVar15;
                    if (*(longlong *)(param_1 + 0x60) != 0) {
                      lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                    }
                    local_928 = local_928 & 0xffffff00;
                    local_930 = &local_900;
                    local_938 = local_938 & 0xffffff00;
                    local_940 = 0;
                    local_948 = (uint *)CONCAT44(local_948._4_4_,uVar4);
                    local_904 = FUN_1403ec0a0(lVar12,plVar10,0,1);
                  }
                }
              }
              plVar14 = (longlong *)
                        (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                  (*(longlong **)(param_2 + 0x40),0x26);
              uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
              plVar14 = (longlong *)
                        (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                  (*(longlong **)(param_2 + 0x40),0x27);
              uVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
              lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
              if (*(longlong *)(lVar12 + 0x100) == 0) {
                local_948 = (uint *)CONCAT44(local_948._4_4_,0x144);
                log_InlineLogERROR(&DAT_1406d9c10);
                lVar12 = lVar15;
              }
              else {
                lVar12 = *(longlong *)(lVar12 + 0x100);
              }
              cVar1 = FUN_1402ec490(lVar12,uVar4);
              if (cVar1 != '\0') {
                lVar12 = lVar15;
                if (*(longlong *)(param_1 + 0x60) != 0) {
                  lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                }
                lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                if (*(longlong *)(lVar13 + 0x100) == 0) {
                  local_948 = (uint *)CONCAT44(local_948._4_4_,0x144);
                  log_InlineLogERROR(&DAT_1406d9c10);
                  lVar13 = lVar15;
                }
                else {
                  lVar13 = *(longlong *)(lVar13 + 0x100);
                }
                local_948._0_4_ = uVar6;
                local_8fc = FUN_1402ec380(lVar13,lVar12,plVar10,uVar4);
                lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                if (*(longlong *)(lVar12 + 0x100) == 0) {
                  local_948._0_4_ = 0x144;
                  log_InlineLogERROR(&DAT_1406d9c10);
                }
                else {
                  lVar15 = *(longlong *)(lVar12 + 0x100);
                }
                FUN_1402ecf10(lVar15,&local_900,uVar4);
              }
            }
            else {
              local_908 = '\x01';
            }
          }
          local_948 = &local_904;
          FUN_1404caac0(param_1,param_2,plVar10,&local_900);
          FUN_140386780(local_478);
          plVar11 = (longlong *)
                    (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                              (*(longlong **)(param_2 + 0x40),1);
          plVar14 = *(longlong **)(param_1 + 0x60);
          uVar5 = (**(code **)(*plVar10 + 0x48))(plVar10);
          uVar8 = (**(code **)(*plVar10 + 0x40))(plVar10);
          uVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
          uVar6 = (**(code **)(*plVar14 + 8))(plVar14);
          local_918 = local_918 & 0xffffff00;
          local_920 = 0;
          local_928 = 0;
          local_930 = (undefined4 *)((ulonglong)local_930 & 0xffffffff00000000);
          local_948 = (uint *)((ulonglong)local_948 & 0xffffffffffffff00);
          local_940 = uVar8;
          local_938 = uVar5;
          iVar2 = FUN_140386a50(local_478,uVar6,uVar4,0);
          cVar1 = local_908;
          if (iVar2 == 0) {
            local_948 = (uint *)CONCAT44(local_948._4_4_,0x3cd);
            log_InlineLogERROR(&DAT_1406d9c10);
            cVar1 = local_908;
            uVar5 = local_8fc;
          }
          else {
            uVar5 = local_8fc;
            if (local_908 == '\0') {
              uVar4 = (**(code **)(*plVar10 + 0x10))(plVar10);
              uVar5 = local_8fc;
              local_928 = 0;
              local_930 = (undefined4 *)((ulonglong)local_930 & 0xffffffff00000000);
              local_938 = 0;
              local_940 = local_8fc;
              local_948 = (uint *)CONCAT44(local_948._4_4_,local_900);
              iVar2 = FUN_140387150(local_478,uVar4,local_904,0);
              if (iVar2 == 0) {
                local_948 = (uint *)CONCAT44(local_948._4_4_,0x3d1);
                log_InlineLogERROR(&DAT_1406d9c10);
                FUN_1403867d0(local_478);
                return;
              }
            }
            plVar14 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
            (**(code **)(*plVar14 + 0x348))(plVar14,local_478,1);
          }
          local_8f8 = operator_new(8);
          if (local_8f8 == (longlong *)0x0) {
            local_8e8[0] = (longlong *)0x0;
          }
          else {
            *local_8f8 = (longlong)local_8e8;
            local_8e8[0] = local_8f8;
          }
          lVar12 = 0;
          local_8d0 = (void *)0x0;
          local_8c8 = 0;
          local_8c0 = 0;
          local_8f0 = local_8f8;
          FUN_1401af440(local_8e8,&local_8b8);
          plVar14 = (longlong *)
                    (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                              (*(longlong **)(param_2 + 0x40),0x10);
          iVar2 = (**(code **)(*plVar14 + 0x48))(plVar14);
          plVar14 = (longlong *)
                    (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                              (*(longlong **)(param_2 + 0x40),0xd);
          uVar4 = (**(code **)(*plVar14 + 0x48))(plVar14);
          if (iVar2 == 0x5b) {
            FUN_1404ceb90(param_1,local_8e8,param_2,uVar4);
          }
          if (cVar1 == '\0') {
            if (*(longlong *)(param_1 + 0x60) != 0) {
              lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
            }
            local_948 = (uint *)CONCAT71(local_948._1_7_,1);
            local_904 = (**(code **)(*plVar10 + 0x3b8))(plVar10,lVar12,local_904,0);
            iVar3 = uVar5 + local_904;
            iVar2 = (**(code **)(*plVar10 + 0x78))(plVar10);
            if (iVar3 < iVar2) {
              iVar2 = iVar3;
            }
            if (0 < iVar2) {
              local_948 = (uint *)0x0;
              (**(code **)(*plVar10 + 0x2e0))(plVar10,0,(longlong)-iVar2,1);
              cVar1 = (**(code **)(*plVar10 + 0x220))(plVar10);
              if (cVar1 == '\0') {
                plVar14 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                local_930 = (undefined4 *)((ulonglong)local_930 & 0xffffffff00000000);
                local_938 = local_938 & 0xffff0000;
                local_940 = local_940 & 0xffff0000;
                local_948 = (uint *)((ulonglong)local_948 & 0xffffffffffffff00);
                (**(code **)(*plVar14 + 0x3c8))(plVar14,plVar10,5);
              }
            }
            local_8f8 = (longlong *)0x0;
            cVar1 = (**(code **)(*plVar10 + 0x298))(plVar10,0x1001,&local_8f8);
            if ((cVar1 != '\0') && (cVar1 = (**(code **)(local_8f8[2] + 0x220))(), cVar1 != '\0')) {
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                  (*(longlong **)(param_2 + 0x40),0x23);
              iVar2 = (**(code **)(*plVar10 + 0x48))(plVar10);
              plVar10 = (longlong *)
                        (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                  (*(longlong **)(param_2 + 0x40),0xd);
              iVar3 = (**(code **)(*plVar10 + 0x48))(plVar10);
              if ((local_8f8 != (longlong *)0x0) &&
                 (((0 < iVar2 && (0 < iVar3)) && (iVar2 != 0x5b)))) {
                plVar10 = (longlong *)FUN_1401181a0();
                lVar12 = *plVar10;
                uVar4 = (**(code **)(*local_8f8 + 8))();
                local_918 = 0;
                local_920 = local_920 & 0xffff0000;
                local_928 = local_928 & 0xffffff00;
                local_930 = (undefined4 *)((ulonglong)local_930 & 0xffffffff00000000);
                local_938 = 0;
                local_940 = 0;
                local_948 = (uint *)CONCAT44(local_948._4_4_,iVar3);
                cVar1 = (**(code **)(lVar12 + 8))(plVar10,uVar4,iVar2,0);
                if ((cVar1 != '\0') &&
                   (((iVar2 == 0x37 || (iVar2 == 0x38)) || ((iVar2 == 0x18 || (iVar2 == 0x6e)))))) {
                  (**(code **)(local_8f8[2] + 0x388))(local_8f8 + 2,0);
                }
              }
            }
          }
          if (local_8d0 != (void *)0x0) {
            operator_delete(local_8d0);
          }
          local_8d0 = (void *)0x0;
          local_8c8 = 0;
          local_8c0 = 0;
          operator_delete(local_8e8[0]);
          FUN_1403867d0(local_478);
        }
      }
    }
  }
  return;
}

// ==== CMonster::helper_1404d00b0  @1404d00b0  [medium:callgraph-r2]  (orig: FUN_1404d00b0)
void FUN_1404d00b0(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  longlong *plVar3;
  void *pvVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  longlong *local_res18;
  longlong *local_res20;
  undefined8 in_stack_fffffffffffffdf8;
  longlong **pplVar19;
  undefined4 uVar21;
  longlong **pplVar20;
  ulonglong in_stack_fffffffffffffe00;
  longlong **pplVar22;
  ulonglong in_stack_fffffffffffffe08;
  longlong **pplVar23;
  longlong **pplVar24;
  ulonglong in_stack_fffffffffffffe18;
  longlong *local_1c8;
  int local_1c0;
  longlong *local_1b8;
  int local_1b0;
  undefined4 local_1ac;
  uint local_1a8;
  undefined4 local_1a0;
  undefined4 uStack_19c;
  int local_198;
  longlong *local_190 [3];
  longlong *local_178;
  longlong *local_170;
  undefined8 local_168;
  longlong *local_160 [3];
  void *local_148;
  longlong local_140;
  undefined8 local_138;
  undefined4 local_130;
  undefined4 uStack_12c;
  longlong *local_128 [3];
  void *local_110;
  longlong local_108;
  undefined8 local_100;
  longlong *local_f8 [3];
  void *local_e0;
  longlong local_d8;
  undefined8 local_d0;
  longlong *local_c8 [3];
  void *local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  longlong *local_98 [3];
  void *local_80;
  undefined8 local_78;
  undefined8 local_70;
  longlong *local_68;
  undefined8 local_58;
  longlong *local_50;
  
  uVar7 = (undefined4)((ulonglong)in_stack_fffffffffffffdf8 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar17 = (longlong *)0x0;
    local_1a0 = 0;
    uStack_19c = 0;
    local_1a0 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    uStack_19c = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0xe);
    iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_1b8 = (longlong *)CONCAT44(local_1b8._4_4_,iVar6 + 2);
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0x28);
    local_198 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_res18 = operator_new(8);
    local_190[0] = plVar17;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_190;
      local_190[0] = local_res18;
    }
    local_178 = (longlong *)0x0;
    local_170 = (longlong *)0x0;
    local_168 = 0;
    local_res20 = local_res18;
    lVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    if (lVar12 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
    else {
      pplVar19 = (longlong **)CONCAT44(uVar7,0x1043);
      uVar2 = CONCAT44(uStack_19c,local_1a0);
      FUN_1402d2470(lVar12,local_190,uVar2,iVar6 + 2,pplVar19);
      local_res18 = operator_new(8);
      local_128[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_128;
        local_128[0] = local_res18;
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_c8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_c8;
        local_c8[0] = local_res18;
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_160[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_160;
        local_160[0] = local_res18;
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_98[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_98;
        local_98[0] = local_res18;
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      plVar11 = local_178;
      local_f8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_f8;
        local_f8[0] = local_res18;
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      local_1b0 = 0;
      local_1c0 = 0;
      local_1a8 = 0;
      local_50 = (longlong *)0x0;
      local_res20 = local_res18;
      if (local_170 < local_178) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_190[0];
      local_50 = local_190[0];
      while( true ) {
        plVar13 = local_170;
        local_68 = (longlong *)0x0;
        if (local_170 < local_178) {
          _invalid_parameter_noinfo();
        }
        local_68 = local_190[0];
        if ((plVar3 == (longlong *)0x0) || (plVar3 != local_190[0])) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == plVar13) || ((local_198 <= local_1c0 && (local_198 != 0))))
        goto LAB_1404d0a6e;
        local_1a8 = (int)plVar17 + 1;
        if (10000 < local_1a8) break;
        local_1c8 = (longlong *)0x0;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        if (*plVar11 != 0) {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
            _invalid_parameter_noinfo();
          }
          cVar5 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_1c8);
          if (cVar5 != '\0') {
            local_130 = (**(code **)(*local_1c8 + 0x40))();
            uStack_12c = (**(code **)(*local_1c8 + 0x48))();
            iVar6 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
            iVar9 = (**(code **)(*local_1c8 + 0x10))();
            if (((iVar9 != iVar6) &&
                (cVar5 = FUN_1401671e0(CONCAT44(uStack_12c,local_130),uVar2,
                                       (ulonglong)local_1b8 & 0xffffffff), cVar5 != '\0')) &&
               ((cVar5 = (**(code **)(*local_1c8 + 0x220))(), cVar5 != '\0' &&
                (cVar5 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_1c8), cVar5 == '\0'))))
            {
              local_1c0 = local_1c0 + 1;
              cVar5 = FUN_1403e9290(local_1c8);
              if (cVar5 == '\0') {
                plVar13 = (longlong *)
                          (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                    (*(longlong **)(param_2 + 0x40),1);
                lVar12 = *local_1c8;
                plVar17 = *(longlong **)(param_1 + 0x60);
                uVar7 = (**(code **)(*plVar13 + 0x48))(plVar13);
                uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
                cVar5 = (**(code **)(lVar12 + 0x398))(local_1c8,uVar8,uVar7,0);
                uVar7 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                if (cVar5 == '\0') {
                  lVar12 = 0;
                  local_res18 = (longlong *)((ulonglong)local_res18 & 0xffffffff00000000);
                  local_res20 = (longlong *)((ulonglong)local_res20 & 0xffffffff00000000);
                  iVar6 = (**(code **)(*local_1c8 + 0x10))();
                  if (iVar6 - 0xaae61U < 99999) {
                    plVar17 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140);
                    plVar17 = (longlong *)(**(code **)(*plVar17 + 0x10))(plVar17,0x34);
                    uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                  }
                  else {
                    plVar17 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x1e);
                    iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    if (iVar6 == 0) {
                      plVar17 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),10);
                      if (*(longlong *)(param_1 + 0x60) != 0) {
                        lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                      }
                      lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar14 + 0x100) == 0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = *(undefined8 *)(lVar14 + 0x100);
                      }
                      uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      uVar7 = FUN_1402f3100(uVar16,lVar12,local_1c8,uVar7,&local_res20);
                      local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                    }
                    else {
                      plVar17 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),0x1e);
                      iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      if (iVar6 == 1) {
                        plVar17 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),10);
                        uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        in_stack_fffffffffffffe18 = in_stack_fffffffffffffe18 & 0xffffffffffffff00;
                        in_stack_fffffffffffffe08 = in_stack_fffffffffffffe08 & 0xffffffffffffff00;
                        in_stack_fffffffffffffe00 = in_stack_fffffffffffffe00 & 0xffffffff00000000;
                        uVar7 = FUN_1403ec0a0(lVar12,local_1c8,0,1,CONCAT44(uVar7,uVar8),
                                              in_stack_fffffffffffffe00,in_stack_fffffffffffffe08,
                                              &local_res20,in_stack_fffffffffffffe18);
                        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                      }
                    }
                  }
                  pplVar19 = &local_res18;
                  FUN_1404caac0(param_1,param_2,local_1c8,&local_res20,pplVar19);
                  FUN_1401af440(local_128,&local_1c8);
                  FUN_14000f0a0(local_160,&local_res18);
                  local_1ac = 0;
                  plVar17 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),0x26);
                  uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                  plVar17 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),0x27);
                  uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                  lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                  if (*(longlong *)(lVar12 + 0x100) == 0) {
                    pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    uVar16 = 0;
                  }
                  else {
                    uVar16 = *(undefined8 *)(lVar12 + 0x100);
                  }
                  cVar5 = FUN_1402ec490(uVar16,uVar7);
                  uVar21 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                  if (cVar5 != '\0') {
                    if (*(longlong *)(param_1 + 0x60) == 0) {
                      lVar12 = 0;
                    }
                    else {
                      lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                    }
                    lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar14 + 0x100) == 0) {
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar16 = 0;
                    }
                    else {
                      uVar16 = *(undefined8 *)(lVar14 + 0x100);
                    }
                    pplVar19 = (longlong **)CONCAT44(uVar21,uVar8);
                    local_1ac = FUN_1402ec380(uVar16,lVar12,local_1c8,uVar7,pplVar19);
                    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar12 + 0x100) == 0) {
                      pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar16 = 0;
                    }
                    else {
                      uVar16 = *(undefined8 *)(lVar12 + 0x100);
                    }
                    FUN_1402ecf10(uVar16,&local_res20,uVar7);
                  }
                  FUN_1402751c0(local_98,&local_res20);
                  FUN_14000f0a0(local_f8,&local_1ac);
                }
              }
              else {
                FUN_1401af440(local_c8,&local_1c8);
              }
            }
          }
        }
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
        plVar17 = (longlong *)(ulonglong)local_1a8;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d0a6e:
      lVar12 = *(longlong *)(param_1 + 0x60);
      uVar7 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x48))();
      uVar8 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x40))(lVar12 + 0x10);
      pplVar19 = local_f8;
      pplVar24 = local_98;
      pplVar23 = local_160;
      pplVar22 = local_c8;
      pplVar20 = local_128;
      FUN_1404cc740(param_1,param_2,uVar8,uVar7,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0x10);
      iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0xd);
      uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
      if (iVar6 == 0x5b) {
        FUN_1404ceb90(param_1,local_128,param_2,uVar7);
      }
      local_1b0 = 0;
      while (iVar6 = local_1b0, uVar15 = local_108 - (longlong)local_110 >> 3,
            local_1b0 < (int)uVar15) {
        uVar18 = (ulonglong)local_1b0;
        if (uVar15 <= uVar18) {
          _invalid_parameter_noinfo();
        }
        plVar11 = *(longlong **)((longlong)local_110 + uVar18 * 8);
        if (plVar11 != (longlong *)0x0) {
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar1 = (undefined4 *)((longlong)local_148 + uVar18 * 4);
          if (*(longlong *)(param_1 + 0x60) == 0) {
            lVar12 = 0;
          }
          else {
            lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
          }
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          pplVar20 = (longlong **)CONCAT71((int7)((ulonglong)pplVar20 >> 8),1);
          uVar7 = (**(code **)(*plVar11 + 0x3b8))(plVar11,lVar12,*puVar1,0,pplVar20);
          *(undefined4 *)((longlong)pvVar4 + uVar18 * 4) = uVar7;
          iVar9 = (**(code **)(*plVar11 + 0x78))(plVar11);
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          if ((ulonglong)(local_d8 - (longlong)local_e0 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          iVar10 = *(int *)((longlong)local_e0 + uVar18 * 4) +
                   *(int *)((longlong)pvVar4 + uVar18 * 4);
          if (iVar10 < iVar9) {
            iVar9 = iVar10;
          }
          if (0 < iVar9) {
            pplVar20 = (longlong **)0x0;
            (**(code **)(*plVar11 + 0x2e0))(plVar11,0,(longlong)-iVar9,1,0);
            cVar5 = (**(code **)(*plVar11 + 0x220))(plVar11);
            if (cVar5 == '\0') {
              plVar17 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffffffff0000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffffffff0000);
              pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffffffffff00);
              (**(code **)(*plVar17 + 0x3c8))
                        (plVar17,plVar11,5,0,pplVar20,pplVar22,pplVar23,pplVar24);
            }
          }
          local_1b8 = (longlong *)0x0;
          cVar5 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,&local_1b8);
          if ((cVar5 != '\0') && (cVar5 = (**(code **)(local_1b8[2] + 0x220))(), cVar5 != '\0')) {
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0x10);
            iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0xd);
            iVar10 = (**(code **)(*plVar11 + 0x48))(plVar11);
            uVar7 = (undefined4)((ulonglong)pplVar20 >> 0x20);
            if ((local_1b8 != (longlong *)0x0) && (((0 < iVar9 && (0 < iVar10)) && (iVar9 != 0x5b)))
               ) {
              plVar11 = (longlong *)FUN_1401181a0();
              lVar12 = *plVar11;
              uVar8 = (**(code **)(*local_1b8 + 8))();
              pplVar19 = (longlong **)((ulonglong)pplVar19 & 0xffffffffffffff00);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffff00000000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffff00000000);
              pplVar20 = (longlong **)CONCAT44(uVar7,iVar10);
              cVar5 = (**(code **)(lVar12 + 8))
                                (plVar11,uVar8,iVar9,0,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19,
                                 0,0);
              if ((cVar5 != '\0') &&
                 (((iVar9 == 0x37 || (iVar9 == 0x38)) || ((iVar9 == 0x18 || (iVar9 == 0x6e)))))) {
                (**(code **)(local_1b8[2] + 0x388))(local_1b8 + 2,0);
              }
            }
          }
        }
        local_1b0 = iVar6 + 1;
      }
      if (local_e0 != (void *)0x0) {
        operator_delete(local_e0);
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      operator_delete(local_f8[0]);
      if (local_80 != (void *)0x0) {
        operator_delete(local_80);
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      operator_delete(local_98[0]);
      if (local_148 != (void *)0x0) {
        operator_delete(local_148);
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      operator_delete(local_160[0]);
      if (local_b0 != (void *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      if (local_110 != (void *)0x0) {
        operator_delete(local_110);
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      operator_delete(local_128[0]);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
  }
  return;
}

// ==== CMonster::helper_1404d0f60  @1404d0f60  [medium:callgraph-r2]  (orig: FUN_1404d0f60)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d0f60(longlong *param_1,int *param_2,char param_3,undefined4 *param_4)

{
  undefined8 *puVar1;
  void *pvVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined8 *puVar11;
  longlong *plVar12;
  longlong lVar13;
  undefined8 uVar14;
  longlong *plVar15;
  longlong *plVar16;
  ulonglong uVar17;
  longlong *plVar18;
  int iVar19;
  undefined8 uVar20;
  ulonglong uVar21;
  longlong lVar22;
  int *piVar23;
  undefined1 auStack_6e8 [32];
  undefined4 *local_6c8;
  uint local_6c0;
  uint local_6b8;
  undefined4 *local_6b0;
  uint local_6a8;
  uint local_6a0;
  uint local_698;
  longlong *local_688;
  char local_680;
  undefined8 local_678;
  longlong *local_670;
  int *local_668;
  undefined4 local_660;
  undefined4 local_65c;
  longlong *local_658 [2];
  uint local_648;
  undefined8 local_640;
  uint local_638;
  int local_634;
  uint local_630;
  uint local_62c;
  undefined4 local_628 [2];
  int local_620;
  int local_61c;
  longlong *local_618 [3];
  void *local_600;
  longlong local_5f8;
  undefined8 local_5f0;
  longlong *local_5e8 [3];
  longlong *local_5d0;
  longlong *local_5c8;
  undefined8 local_5c0;
  longlong *local_5b8 [3];
  longlong *local_5a0;
  longlong local_598;
  undefined8 local_590;
  int local_588;
  int local_584;
  uint local_580;
  int local_57c;
  uint local_578;
  uint local_574;
  longlong *local_570 [3];
  longlong *local_558;
  longlong local_550;
  undefined8 local_548;
  longlong *local_540 [3];
  undefined8 *local_528;
  undefined8 *local_520;
  undefined8 local_518;
  longlong *local_510 [3];
  void *local_4f8;
  longlong local_4f0;
  undefined8 local_4e8;
  longlong *local_4e0 [3];
  longlong *local_4c8;
  longlong local_4c0;
  undefined8 local_4b8;
  longlong *local_4b0;
  longlong *local_4a0;
  longlong *local_490;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_6e8;
  local_680 = param_3;
  local_670 = param_1;
  local_668 = param_2;
  if (param_1[0xc] == 0) {
    local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x4b8);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == (int *)0x0) {
    local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x4b9);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x10) == 0) {
    local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x4ba);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar4 = (**(code **)(*(longlong *)(param_1[0xc] + 0x10) + 0x40))();
    local_640 = (longlong *)CONCAT44(local_640._4_4_,uVar4);
    uVar4 = (**(code **)(*(longlong *)(param_1[0xc] + 0x10) + 0x48))();
    local_640 = (longlong *)CONCAT44(uVar4,(undefined4)local_640);
    if (param_3 == '\0') {
      puVar11 = (undefined8 *)FUN_1403888a0(param_1[0xc],local_658,3);
      uVar20 = *puVar11;
    }
    else {
      puVar11 = (undefined8 *)FUN_140388810(param_1[0xc],local_658,3);
      uVar20 = *puVar11;
    }
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                        (*(longlong **)(param_2 + 0x10),0xe);
    iVar5 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_620 = iVar5 + 2;
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                        (*(longlong **)(param_2 + 0x10),0x28);
    local_588 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_678 = operator_new(8);
    if (local_678 == (longlong *)0x0) {
      local_5e8[0] = (longlong *)0x0;
    }
    else {
      *local_678 = (longlong)local_5e8;
      local_5e8[0] = local_678;
    }
    plVar12 = (longlong *)0x0;
    local_5d0 = (longlong *)0x0;
    local_5c8 = (longlong *)0x0;
    local_5c0 = 0;
    local_658[0] = local_678;
    lVar13 = (**(code **)(*(longlong *)(param_1[0xc] + 0x10) + 0x160))();
    if (lVar13 == 0) {
      local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x4d0);
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_5d0 != (longlong *)0x0) {
        operator_delete(local_5d0);
      }
      local_5d0 = (longlong *)0x0;
      local_5c8 = (longlong *)0x0;
      local_5c0 = 0;
      operator_delete(local_5e8[0]);
    }
    else {
      local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x1043);
      FUN_1402d2470(lVar13,local_5e8,local_640,iVar5 + 2);
      local_678 = operator_new(8);
      local_618[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_618;
        local_618[0] = local_678;
      }
      local_600 = (void *)0x0;
      local_5f8 = 0;
      local_5f0 = 0;
      local_658[0] = local_678;
      local_678 = operator_new(8);
      local_540[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_540;
        local_540[0] = local_678;
      }
      local_528 = (undefined8 *)0x0;
      local_520 = (undefined8 *)0x0;
      local_518 = 0;
      local_658[0] = local_678;
      local_678 = operator_new(8);
      local_5b8[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_5b8;
        local_5b8[0] = local_678;
      }
      local_5a0 = (longlong *)0x0;
      local_598 = 0;
      local_590 = 0;
      local_658[0] = local_678;
      local_678 = operator_new(8);
      local_4e0[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_4e0;
        local_4e0[0] = local_678;
      }
      local_4c8 = (longlong *)0x0;
      local_4c0 = 0;
      local_4b8 = 0;
      local_658[0] = local_678;
      local_678 = operator_new(8);
      local_570[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_570;
        local_570[0] = local_678;
      }
      local_558 = (longlong *)0x0;
      local_550 = 0;
      local_548 = 0;
      local_658[0] = local_678;
      local_678 = operator_new(8);
      plVar18 = local_5d0;
      local_510[0] = plVar12;
      if (local_678 != (longlong *)0x0) {
        *local_678 = (longlong)local_510;
        local_510[0] = local_678;
      }
      local_4f8 = (void *)0x0;
      local_4f0 = 0;
      local_4e8 = 0;
      local_630 = 0;
      local_634 = 0;
      local_62c = 0;
      local_658[0] = local_5d0;
      local_4b0 = (longlong *)0x0;
      if (local_5c8 < local_5d0) {
        _invalid_parameter_noinfo();
      }
      local_640 = local_5e8[0];
      local_4b0 = local_5e8[0];
      plVar15 = local_5e8[0];
      while( true ) {
        plVar16 = local_5c8;
        local_4a0 = (longlong *)0x0;
        if (local_5c8 < local_5d0) {
          _invalid_parameter_noinfo();
        }
        local_4a0 = local_5e8[0];
        if ((plVar15 == (longlong *)0x0) || (plVar15 != local_5e8[0])) {
          _invalid_parameter_noinfo();
        }
        if ((plVar18 == plVar16) || ((local_588 <= local_634 && (local_588 != 0))))
        goto LAB_1404d1a67;
        local_62c = local_62c + 1;
        if (10000 < local_62c) break;
        local_688 = (longlong *)0x0;
        if (plVar15 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar16 = plVar12;
        }
        else {
          plVar16 = (longlong *)*plVar15;
        }
        if ((longlong *)plVar16[4] <= plVar18) {
          _invalid_parameter_noinfo();
        }
        if (*plVar18 != 0) {
          if (plVar15 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar16 = plVar12;
          }
          else {
            plVar16 = (longlong *)*plVar15;
          }
          if ((longlong *)plVar16[4] <= plVar18) {
            _invalid_parameter_noinfo();
          }
          cVar3 = (**(code **)(*(longlong *)*plVar18 + 0x40))((longlong *)*plVar18,&local_688);
          if (cVar3 != '\0') {
            uVar4 = (**(code **)(*local_688 + 0x40))();
            local_678 = (longlong *)CONCAT44(local_678._4_4_,uVar4);
            uVar4 = (**(code **)(*local_688 + 0x48))();
            local_678 = (longlong *)CONCAT44(uVar4,(undefined4)local_678);
            local_6c8 = param_4;
            cVar3 = FUN_1404ca780(param_1,local_678,local_620,uVar20);
            if (cVar3 != '\0') {
              iVar5 = (**(code **)(*(longlong *)param_1[0xc] + 8))();
              iVar10 = (**(code **)(*local_688 + 0x10))();
              if (iVar10 != iVar5) {
                iVar5 = (**(code **)(*local_688 + 0x10))();
                cVar3 = (**(code **)(*local_688 + 0x220))();
                if ((cVar3 != '\0') &&
                   (cVar3 = FUN_14038e6a0(param_1[0xc],local_688), cVar3 == '\0')) {
                  plVar18 = (longlong *)
                            (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                      (*(longlong **)(local_668 + 0x10),0xe);
                  lVar13 = *(longlong *)(param_1[0xc] + 0x10);
                  uVar14 = (**(code **)(*local_688 + 0x2a0))();
                  iVar10 = (**(code **)(lVar13 + 0x150))(param_1[0xc] + 0x10,uVar14);
                  iVar19 = (**(code **)(*plVar18 + 0x48))(plVar18);
                  if (iVar10 <= iVar19) {
                    local_634 = local_634 + 1;
                    cVar3 = FUN_1403e9290(local_688);
                    if (cVar3 == '\0') {
                      plVar15 = (longlong *)
                                (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                          (*(longlong **)(local_668 + 0x10),1);
                      lVar13 = *local_688;
                      plVar18 = (longlong *)param_1[0xc];
                      uVar4 = (**(code **)(*plVar15 + 0x48))(plVar15);
                      uVar8 = (**(code **)(*plVar18 + 8))(plVar18);
                      cVar3 = (**(code **)(lVar13 + 0x398))(local_688,uVar8,uVar4,0);
                      piVar23 = local_668;
                      plVar15 = local_640;
                      if (cVar3 == '\0') {
                        local_65c = 0;
                        local_660 = 0;
                        if (iVar5 - 0xaae61U < 99999) {
                          plVar18 = (longlong *)
                                    (**(code **)(*(longlong *)
                                                  **(undefined8 **)(param_1[0xc] + 0x140) + 0x10))
                                              ((longlong *)**(undefined8 **)(param_1[0xc] + 0x140),
                                               0x34);
                          local_65c = (**(code **)(*plVar18 + 0x48))(plVar18);
                          piVar23 = local_668;
                        }
                        else {
                          plVar18 = (longlong *)
                                    (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                              (*(longlong **)(local_668 + 0x10),0x1e);
                          iVar5 = (**(code **)(*plVar18 + 0x48))(plVar18);
                          if (iVar5 == 0) {
                            plVar15 = (longlong *)
                                      (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                                (*(longlong **)(piVar23 + 0x10),10);
                            plVar18 = plVar12;
                            if (param_1[0xc] != 0) {
                              plVar18 = (longlong *)(param_1[0xc] + 0x10);
                            }
                            lVar13 = FUN_140008520((int)param_1[0xb]);
                            if (*(longlong *)(lVar13 + 0x100) == 0) {
                              local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x144);
                              log_InlineLogERROR(&DAT_1406d9c10);
                              plVar16 = plVar12;
                            }
                            else {
                              plVar16 = *(longlong **)(lVar13 + 0x100);
                            }
                            uVar4 = (**(code **)(*plVar15 + 0x48))(plVar15);
                            local_6c8 = &local_660;
                            local_65c = FUN_1402f3100(plVar16,plVar18,local_688,uVar4);
                          }
                          else {
                            plVar18 = (longlong *)
                                      (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                                (*(longlong **)(piVar23 + 0x10),0x1e);
                            iVar5 = (**(code **)(*plVar18 + 0x48))(plVar18);
                            if (iVar5 == 1) {
                              plVar18 = (longlong *)
                                        (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                                  (*(longlong **)(piVar23 + 0x10),10);
                              uVar4 = (**(code **)(*plVar18 + 0x48))(plVar18);
                              plVar18 = plVar12;
                              if (param_1[0xc] != 0) {
                                plVar18 = (longlong *)(param_1[0xc] + 0x10);
                              }
                              local_6a8 = local_6a8 & 0xffffff00;
                              local_6b0 = &local_660;
                              local_6b8 = local_6b8 & 0xffffff00;
                              local_6c0 = 0;
                              local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,uVar4);
                              local_65c = FUN_1403ec0a0(plVar18,local_688,0,1);
                            }
                          }
                        }
                        local_6c8 = &local_65c;
                        FUN_1404caac0(param_1,piVar23,local_688,&local_660);
                        FUN_1401af440(local_618,&local_688);
                        FUN_14000f0a0(local_5b8,&local_65c);
                        local_628[0] = 0;
                        plVar18 = (longlong *)
                                  (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                            (*(longlong **)(piVar23 + 0x10),0x26);
                        uVar4 = (**(code **)(*plVar18 + 0x48))(plVar18);
                        plVar18 = (longlong *)
                                  (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                            (*(longlong **)(piVar23 + 0x10),0x27);
                        uVar8 = (**(code **)(*plVar18 + 0x48))(plVar18);
                        lVar13 = FUN_140008520((int)param_1[0xb]);
                        if (*(longlong *)(lVar13 + 0x100) == 0) {
                          local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x144);
                          log_InlineLogERROR(&DAT_1406d9c10);
                          plVar18 = plVar12;
                        }
                        else {
                          plVar18 = *(longlong **)(lVar13 + 0x100);
                        }
                        cVar3 = FUN_1402ec490(plVar18,uVar4);
                        if (cVar3 != '\0') {
                          plVar18 = plVar12;
                          if (param_1[0xc] != 0) {
                            plVar18 = (longlong *)(param_1[0xc] + 0x10);
                          }
                          lVar13 = FUN_140008520((int)param_1[0xb]);
                          if (*(longlong *)(lVar13 + 0x100) == 0) {
                            local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x144);
                            log_InlineLogERROR(&DAT_1406d9c10);
                            plVar15 = plVar12;
                          }
                          else {
                            plVar15 = *(longlong **)(lVar13 + 0x100);
                          }
                          local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,uVar8);
                          local_628[0] = FUN_1402ec380(plVar15,plVar18,local_688,uVar4);
                          lVar13 = FUN_140008520((int)param_1[0xb]);
                          if (*(longlong *)(lVar13 + 0x100) == 0) {
                            local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x144);
                            log_InlineLogERROR(&DAT_1406d9c10);
                            plVar18 = plVar12;
                          }
                          else {
                            plVar18 = *(longlong **)(lVar13 + 0x100);
                          }
                          FUN_1402ecf10(plVar18,&local_660,uVar4);
                        }
                        FUN_1402751c0(local_4e0,&local_660);
                        FUN_14000f0a0(local_570,local_628);
                        plVar15 = local_640;
                      }
                    }
                    else {
                      FUN_1401af440(local_540,&local_688);
                    }
                  }
                }
              }
            }
          }
        }
        if (plVar15 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar16 = plVar12;
        }
        else {
          plVar16 = (longlong *)*plVar15;
        }
        plVar18 = local_658[0];
        if ((longlong *)plVar16[4] <= local_658[0]) {
          _invalid_parameter_noinfo();
        }
        plVar18 = plVar18 + 1;
        param_2 = local_668;
        local_658[0] = plVar18;
      }
      local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x4e0);
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d1a67:
      FUN_140386780(local_478);
      plVar15 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x10) + 0x10))
                          (*(longlong **)(param_2 + 0x10),1);
      plVar18 = (longlong *)param_1[0xc];
      uVar6 = (**(code **)(*(longlong *)(param_1[0xc] + 0x10) + 0x48))();
      uVar7 = (**(code **)(plVar18[2] + 0x40))(plVar18 + 2);
      uVar4 = (**(code **)(*plVar15 + 0x48))(plVar15);
      uVar8 = (**(code **)(*plVar18 + 8))(plVar18);
      local_698 = local_698 & 0xffffff00;
      local_6a0 = 0;
      local_6a8 = 0;
      local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
      local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffffffffff00);
      local_6c0 = uVar7;
      local_6b8 = uVar6;
      iVar5 = FUN_140386a50(local_478,uVar8,uVar4,0);
      if (iVar5 == 0) {
        local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x536);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        local_648 = 0;
        plVar15 = plVar12;
        plVar18 = local_670;
        while( true ) {
          puVar11 = local_528;
          uVar17 = local_5f8 - (longlong)local_600 >> 3;
          iVar5 = (int)plVar15;
          if ((int)uVar17 <= iVar5) break;
          local_638 = 0;
          iVar10 = 0;
          local_580 = 0;
          if (uVar17 <= (ulonglong)(longlong)iVar5) {
            _invalid_parameter_noinfo();
          }
          plVar15 = *(longlong **)((longlong)local_600 + (longlong)iVar5 * 8);
          local_688 = plVar15;
          iVar5 = (**(code **)(*plVar15 + 0x40))(plVar15);
          iVar19 = (**(code **)(*plVar15 + 0x48))(plVar15);
          plVar16 = plVar18;
          uVar6 = 0;
          local_584 = iVar19;
          local_57c = iVar5;
          if ((local_680 == '\0') && (*local_668 == 0x1b63)) {
            lVar13 = (**(code **)(*plVar15 + 0x160))(plVar15);
            if (lVar13 == 0) {
              local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,0x54d);
              log_InlineLogERROR(&DAT_1406d9c10);
              FUN_1403867d0(local_478);
              if (local_4f8 != (void *)0x0) {
                operator_delete(local_4f8);
              }
              local_4f8 = (void *)0x0;
              local_4f0 = 0;
              local_4e8 = 0;
              operator_delete(local_510[0]);
              if (local_558 != (longlong *)0x0) {
                operator_delete(local_558);
              }
              local_558 = (longlong *)0x0;
              local_550 = 0;
              local_548 = 0;
              operator_delete(local_570[0]);
              if (local_4c8 != (longlong *)0x0) {
                operator_delete(local_4c8);
              }
              local_4c8 = (longlong *)0x0;
              local_4c0 = 0;
              local_4b8 = 0;
              operator_delete(local_4e0[0]);
              if (local_5a0 != (longlong *)0x0) {
                operator_delete(local_5a0);
              }
              local_5a0 = (longlong *)0x0;
              local_598 = 0;
              local_590 = 0;
              operator_delete(local_5b8[0]);
              if (local_528 != (undefined8 *)0x0) {
                operator_delete(local_528);
              }
              local_528 = (undefined8 *)0x0;
              local_520 = (undefined8 *)0x0;
              local_518 = 0;
              operator_delete(local_540[0]);
              if (local_600 != (void *)0x0) {
                operator_delete(local_600);
              }
              local_600 = (void *)0x0;
              local_5f8 = 0;
              local_5f0 = 0;
              operator_delete(local_618[0]);
              if (local_5d0 != (longlong *)0x0) {
                operator_delete(local_5d0);
              }
              local_5d0 = (longlong *)0x0;
              local_5c8 = (longlong *)0x0;
              local_5c0 = 0;
              operator_delete(local_5e8[0]);
              return;
            }
            iVar10 = (**(code **)(*(longlong *)(plVar18[0xc] + 0x10) + 0x50))();
            local_638 = iVar10 + 4 >> 0x1f & 7;
            local_638 = (iVar10 + 4 + local_638 & 7) - local_638;
            local_578 = 0;
            plVar18 = plVar12;
            plVar15 = plVar12;
            while( true ) {
              uVar6 = local_638;
              iVar10 = (int)plVar15;
              if ((4 < (int)plVar18) || (cVar3 = FUN_14015f9d0(lVar13,iVar5,iVar19), cVar3 == '\0'))
              break;
              lVar22 = (longlong)(int)uVar6;
              cVar3 = FUN_1402c3cc0(lVar13,iVar5 + *(int *)(&DAT_14078e2b0 + lVar22 * 4),
                                    iVar19 + *(int *)(&DAT_14078e2d0 + lVar22 * 4));
              if (cVar3 == '\0') break;
              iVar5 = iVar5 + *(int *)(&DAT_14078e2b0 + lVar22 * 4);
              iVar19 = iVar19 + *(int *)(&DAT_14078e2d0 + lVar22 * 4);
              local_580 = iVar10 + 1;
              plVar15 = (longlong *)(ulonglong)local_580;
              local_578 = (int)plVar18 + 1;
              plVar18 = (longlong *)(ulonglong)local_578;
              local_584 = iVar19;
              local_57c = iVar5;
            }
            lVar13 = local_670[0xc];
            uVar4 = (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x48))();
            (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x40))(lVar13 + 0x10);
            uVar8 = (**(code **)(*local_688 + 0x48))();
            uVar9 = (**(code **)(*local_688 + 0x40))(local_688);
            plVar16 = local_670;
            local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,uVar4);
            uVar4 = FUN_1404ca9a0(local_670,uVar9,uVar8);
            plVar15 = local_688;
            (**(code **)(*local_688 + 0x2b8))(local_688,uVar4);
            uVar6 = local_638;
          }
          local_688 = (longlong *)(longlong)(int)local_648;
          local_658[0] = local_558;
          if ((longlong *)(local_550 - (longlong)local_558 >> 2) <= local_688) {
            _invalid_parameter_noinfo();
          }
          local_678 = local_4c8;
          local_658[0] = local_558;
          if ((longlong *)(local_4c0 - (longlong)local_4c8 >> 2) <= local_688) {
            _invalid_parameter_noinfo();
          }
          local_640 = local_5a0;
          local_678 = local_4c8;
          if ((longlong *)(local_598 - (longlong)local_5a0 >> 2) <= local_688) {
            _invalid_parameter_noinfo();
          }
          local_640 = local_5a0;
          uVar4 = (**(code **)(*plVar15 + 0x10))(plVar15);
          local_6a8 = 0;
          local_6b0 = (undefined4 *)CONCAT44(local_6b0._4_4_,iVar10);
          local_6c0 = *(uint *)((longlong)local_658[0] + (longlong)local_688 * 4);
          local_6c8 = (undefined4 *)
                      CONCAT44(local_6c8._4_4_,
                               *(undefined4 *)((longlong)local_678 + (longlong)local_688 * 4));
          local_6b8 = uVar6;
          iVar10 = FUN_140387150(local_478,uVar4,
                                 *(undefined4 *)((longlong)local_640 + (longlong)local_688 * 4),0);
          plVar18 = local_670;
          if (iVar10 == 0) {
            (**(code **)(*(longlong *)(local_670[0xc] + 0x10) + 0x348))
                      ((longlong *)(local_670[0xc] + 0x10),local_478,1);
            plVar16 = (longlong *)
                      (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                (*(longlong **)(local_668 + 0x10),1);
            plVar15 = (longlong *)plVar18[0xc];
            uVar6 = (**(code **)(*(longlong *)(plVar18[0xc] + 0x10) + 0x48))();
            uVar7 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
            (**(code **)(*plVar16 + 0x48))(plVar16);
            uVar4 = (**(code **)(*plVar15 + 8))(plVar15);
            local_698 = local_698 & 0xffffff00;
            local_6a0 = 0;
            local_6a8 = 0;
            local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
            local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffffffffff00);
            local_6c0 = uVar7;
            local_6b8 = uVar6;
            FUN_140386a50(local_478,uVar4);
          }
          else {
            local_620 = iVar5;
            local_61c = iVar19;
            FUN_1401d8190(local_510,&local_620);
            local_648 = local_648 + 1;
            plVar18 = plVar16;
          }
          plVar15 = (longlong *)(ulonglong)local_648;
        }
        local_658[0] = (longlong *)0x0;
        if (local_520 < local_528) {
          _invalid_parameter_noinfo();
        }
        local_678 = local_540[0];
        local_658[0] = local_540[0];
        plVar18 = local_540[0];
        while( true ) {
          puVar1 = local_520;
          local_490 = (longlong *)0x0;
          if (local_520 < local_528) {
            _invalid_parameter_noinfo();
          }
          local_490 = local_540[0];
          if ((plVar18 == (longlong *)0x0) || (plVar18 != local_540[0])) {
            _invalid_parameter_noinfo();
          }
          param_1 = local_670;
          if (puVar11 == puVar1) break;
          if (plVar18 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar12;
          }
          else {
            plVar15 = (longlong *)*plVar18;
          }
          if ((undefined8 *)plVar15[4] <= puVar11) {
            _invalid_parameter_noinfo();
          }
          local_658[0] = (longlong *)*puVar11;
          if (local_658[0] != (longlong *)0x0) {
            uVar4 = (**(code **)(*local_658[0] + 0x10))();
            local_6a8 = 2;
            local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
            local_6b8 = 0;
            local_6c0 = 0;
            local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffff00000000);
            iVar5 = FUN_140387150(local_478,uVar4,0,0);
            plVar15 = local_670;
            if (iVar5 == 0) {
              (**(code **)(*(longlong *)(local_670[0xc] + 0x10) + 0x348))
                        ((longlong *)(local_670[0xc] + 0x10),local_478,1);
              plVar16 = (longlong *)
                        (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                  (*(longlong **)(local_668 + 0x10),1);
              plVar18 = (longlong *)plVar15[0xc];
              uVar4 = (**(code **)(*(longlong *)(plVar15[0xc] + 0x10) + 0x48))();
              uVar8 = (**(code **)(plVar18[2] + 0x40))(plVar18 + 2);
              (**(code **)(*plVar16 + 0x48))(plVar16);
              uVar9 = (**(code **)(*plVar18 + 8))(plVar18);
              local_698 = local_698 & 0xffffff00;
              local_6a0 = 0;
              local_6a8 = 0;
              local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
              local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffffffffff00);
              local_6c0 = uVar8;
              local_6b8 = uVar4;
              FUN_140386a50(local_478,uVar9);
              uVar4 = (**(code **)(*local_658[0] + 0x10))();
              local_6a8 = 2;
              local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
              local_6b8 = 0;
              local_6c0 = 0;
              local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffff00000000);
              FUN_140387150(local_478,uVar4,0,0);
              plVar18 = local_678;
            }
          }
          if (plVar18 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            plVar15 = plVar12;
          }
          else {
            plVar15 = (longlong *)*plVar18;
          }
          if ((undefined8 *)plVar15[4] <= puVar11) {
            _invalid_parameter_noinfo();
          }
          puVar11 = puVar11 + 1;
        }
        (**(code **)(*(longlong *)(local_670[0xc] + 0x10) + 0x348))
                  ((longlong *)(local_670[0xc] + 0x10),local_478,1);
      }
      if (((local_680 == '\0') && (*local_668 == 0x1b63)) &&
         (local_5f8 - (longlong)local_600 >> 3 == local_4f0 - (longlong)local_4f8 >> 3)) {
        local_574 = 0;
        plVar18 = plVar12;
        while( true ) {
          uVar17 = local_5f8 - (longlong)local_600 >> 3;
          iVar5 = (int)plVar18;
          if ((int)uVar17 <= iVar5) break;
          uVar21 = (ulonglong)iVar5;
          if (uVar17 <= uVar21) {
            _invalid_parameter_noinfo();
          }
          plVar18 = *(longlong **)((longlong)local_600 + uVar21 * 8);
          if ((ulonglong)(local_4f0 - (longlong)local_4f8 >> 3) <= uVar21) {
            _invalid_parameter_noinfo();
          }
          pvVar2 = local_4f8;
          if ((plVar18 != (longlong *)0x0) &&
             ((iVar10 = (**(code **)(*plVar18 + 0x40))(plVar18),
              iVar10 != *(int *)((longlong)pvVar2 + uVar21 * 8) ||
              (iVar10 = (**(code **)(*plVar18 + 0x48))(plVar18),
              iVar10 != *(int *)((longlong)pvVar2 + uVar21 * 8 + 4))))) {
            (**(code **)(*plVar18 + 0x370))
                      (plVar18,*(undefined4 *)((longlong)pvVar2 + uVar21 * 8),
                       *(undefined4 *)((longlong)pvVar2 + uVar21 * 8 + 4));
          }
          local_574 = iVar5 + 1;
          plVar18 = (longlong *)(ulonglong)local_574;
        }
      }
      piVar23 = local_668;
      plVar18 = (longlong *)
                (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                          (*(longlong **)(local_668 + 0x10),0x10);
      iVar5 = (**(code **)(*plVar18 + 0x48))(plVar18);
      plVar18 = *(longlong **)(piVar23 + 0x10);
      plVar18 = (longlong *)(**(code **)(*plVar18 + 0x10))(plVar18,0xd);
      uVar4 = (**(code **)(*plVar18 + 0x48))(plVar18);
      if (iVar5 == 0x5b) {
        FUN_1404ceb90(param_1,local_618,piVar23,uVar4);
      }
      local_630 = 0;
      plVar18 = plVar12;
      while( true ) {
        uVar17 = local_5f8 - (longlong)local_600 >> 3;
        iVar5 = (int)plVar18;
        if ((int)uVar17 <= iVar5) break;
        uVar21 = (ulonglong)iVar5;
        if (uVar17 <= uVar21) {
          _invalid_parameter_noinfo();
        }
        plVar18 = *(longlong **)((longlong)local_600 + uVar21 * 8);
        if (plVar18 != (longlong *)0x0) {
          if ((ulonglong)(local_598 - (longlong)local_5a0 >> 2) <= uVar21) {
            _invalid_parameter_noinfo();
          }
          local_658[0] = (longlong *)((longlong)local_5a0 + uVar21 * 4);
          plVar15 = plVar12;
          if (param_1[0xc] != 0) {
            plVar15 = (longlong *)(param_1[0xc] + 0x10);
          }
          if ((ulonglong)(local_598 - (longlong)local_5a0 >> 2) <= uVar21) {
            _invalid_parameter_noinfo();
          }
          plVar16 = local_5a0;
          local_6c8 = (undefined4 *)CONCAT71(local_6c8._1_7_,1);
          uVar4 = (**(code **)(*plVar18 + 0x3b8))(plVar18,plVar15,(int)*local_658[0],0);
          *(undefined4 *)((longlong)plVar16 + uVar21 * 4) = uVar4;
          if ((ulonglong)(local_598 - (longlong)local_5a0 >> 2) <= uVar21) {
            _invalid_parameter_noinfo();
          }
          plVar15 = local_5a0;
          if ((ulonglong)(local_550 - (longlong)local_558 >> 2) <= uVar21) {
            _invalid_parameter_noinfo();
          }
          iVar19 = *(int *)((longlong)local_558 + uVar21 * 4) +
                   *(int *)((longlong)plVar15 + uVar21 * 4);
          iVar10 = (**(code **)(*plVar18 + 0x78))(plVar18);
          if (iVar19 < iVar10) {
            iVar10 = iVar19;
          }
          if (0 < iVar10) {
            local_6c8 = (undefined4 *)0x0;
            (**(code **)(*plVar18 + 0x2e0))(plVar18,0,(longlong)-iVar10);
            cVar3 = (**(code **)(*plVar18 + 0x220))(plVar18);
            if (cVar3 == '\0') {
              local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
              local_6b8 = local_6b8 & 0xffff0000;
              local_6c0 = local_6c0 & 0xffff0000;
              local_6c8 = (undefined4 *)((ulonglong)local_6c8 & 0xffffffffffffff00);
              (**(code **)(*(longlong *)(param_1[0xc] + 0x10) + 0x3c8))
                        ((longlong *)(param_1[0xc] + 0x10),plVar18,5);
            }
          }
          local_670 = (longlong *)0x0;
          cVar3 = (**(code **)(*plVar18 + 0x298))(plVar18,0x1001,&local_670);
          if ((cVar3 != '\0') &&
             (cVar3 = (**(code **)(local_670[2] + 0x220))(), piVar23 = local_668, cVar3 != '\0')) {
            plVar18 = (longlong *)
                      (**(code **)(**(longlong **)(local_668 + 0x10) + 0x10))
                                (*(longlong **)(local_668 + 0x10),0x10);
            iVar10 = (**(code **)(*plVar18 + 0x48))(plVar18);
            plVar18 = (longlong *)
                      (**(code **)(**(longlong **)(piVar23 + 0x10) + 0x10))
                                (*(longlong **)(piVar23 + 0x10),0xd);
            iVar19 = (**(code **)(*plVar18 + 0x48))(plVar18);
            if ((local_670 != (longlong *)0x0) &&
               (((0 < iVar10 && (0 < iVar19)) && (iVar10 != 0x5b)))) {
              plVar18 = (longlong *)FUN_1401181a0();
              lVar13 = *plVar18;
              uVar4 = (**(code **)(*local_670 + 8))();
              local_698 = 0;
              local_6a0 = local_6a0 & 0xffff0000;
              local_6a8 = local_6a8 & 0xffffff00;
              local_6b0 = (undefined4 *)((ulonglong)local_6b0 & 0xffffffff00000000);
              local_6b8 = 0;
              local_6c0 = 0;
              local_6c8 = (undefined4 *)CONCAT44(local_6c8._4_4_,iVar19);
              cVar3 = (**(code **)(lVar13 + 8))(plVar18,uVar4,iVar10);
              if ((cVar3 != '\0') &&
                 (((iVar10 == 0x37 || (iVar10 == 0x38)) || ((iVar10 == 0x18 || (iVar10 == 0x6e))))))
              {
                (**(code **)(local_670[2] + 0x388))(local_670 + 2,0);
              }
            }
          }
        }
        local_630 = iVar5 + 1;
        plVar18 = (longlong *)(ulonglong)local_630;
      }
      FUN_1403867d0(local_478);
      if (local_4f8 != (void *)0x0) {
        operator_delete(local_4f8);
      }
      local_4f8 = (void *)0x0;
      local_4f0 = 0;
      local_4e8 = 0;
      operator_delete(local_510[0]);
      if (local_558 != (longlong *)0x0) {
        operator_delete(local_558);
      }
      local_558 = (longlong *)0x0;
      local_550 = 0;
      local_548 = 0;
      operator_delete(local_570[0]);
      if (local_4c8 != (longlong *)0x0) {
        operator_delete(local_4c8);
      }
      local_4c8 = (longlong *)0x0;
      local_4c0 = 0;
      local_4b8 = 0;
      operator_delete(local_4e0[0]);
      if (local_5a0 != (longlong *)0x0) {
        operator_delete(local_5a0);
      }
      local_5a0 = (longlong *)0x0;
      local_598 = 0;
      local_590 = 0;
      operator_delete(local_5b8[0]);
      if (local_528 != (undefined8 *)0x0) {
        operator_delete(local_528);
      }
      local_528 = (undefined8 *)0x0;
      local_520 = (undefined8 *)0x0;
      local_518 = 0;
      operator_delete(local_540[0]);
      if (local_600 != (void *)0x0) {
        operator_delete(local_600);
      }
      local_600 = (void *)0x0;
      local_5f8 = 0;
      local_5f0 = 0;
      operator_delete(local_618[0]);
      if (local_5d0 != (longlong *)0x0) {
        operator_delete(local_5d0);
      }
      local_5d0 = (longlong *)0x0;
      local_5c8 = (longlong *)0x0;
      local_5c0 = 0;
      operator_delete(local_5e8[0]);
    }
  }
  return;
}

// ==== CMonster::helper_1404d2940  @1404d2940  [medium:callgraph-r2]  (orig: FUN_1404d2940)
void FUN_1404d2940(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  undefined8 uVar3;
  longlong *plVar4;
  void *pvVar5;
  char cVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  int iVar10;
  int iVar11;
  longlong *plVar12;
  longlong lVar13;
  longlong lVar14;
  longlong lVar15;
  ulonglong uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  longlong *plVar19;
  longlong *local_res18;
  longlong *local_res20;
  undefined8 in_stack_fffffffffffffda8;
  longlong **pplVar20;
  undefined4 uVar22;
  longlong **pplVar21;
  ulonglong in_stack_fffffffffffffdb0;
  longlong **pplVar23;
  ulonglong in_stack_fffffffffffffdb8;
  longlong **pplVar24;
  longlong **pplVar25;
  ulonglong in_stack_fffffffffffffdc8;
  longlong *local_218;
  undefined8 local_210;
  int local_208;
  longlong *local_200;
  int local_1f8;
  undefined4 local_1f4;
  uint local_1f0;
  int local_1e8;
  int iStack_1e4;
  int local_1e0;
  undefined4 local_1dc;
  longlong *local_1d8 [3];
  longlong *local_1c0;
  longlong *local_1b8;
  undefined8 local_1b0;
  longlong *local_1a8 [3];
  void *local_190;
  longlong local_188;
  undefined8 local_180;
  undefined8 local_178;
  undefined4 uStack_170;
  undefined4 uStack_16c;
  longlong *local_168;
  longlong *local_160 [3];
  void *local_148;
  longlong local_140;
  undefined8 local_138;
  longlong *local_130 [3];
  void *local_118;
  longlong local_110;
  undefined8 local_108;
  undefined4 local_100;
  undefined8 local_fc;
  longlong *local_f0 [3];
  void *local_d8;
  undefined8 local_d0;
  undefined8 local_c8;
  longlong *local_c0 [3];
  void *local_a8;
  undefined8 local_a0;
  undefined8 local_98;
  undefined8 local_90;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  longlong *local_78;
  undefined8 local_68;
  longlong *local_60 [3];
  undefined1 local_48 [16];
  
  uVar9 = (undefined4)((ulonglong)in_stack_fffffffffffffda8 >> 0x20);
  local_68 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar17 = (longlong *)0x0;
    local_210 = (longlong *)0x0;
    uVar7 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    local_210 = (longlong *)CONCAT44(local_210._4_4_,uVar7);
    uVar7 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    local_210 = (longlong *)CONCAT44(uVar7,(undefined4)local_210);
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0xe);
    iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_200 = (longlong *)CONCAT44(local_200._4_4_,iVar8 + 2);
    plVar12 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0x28);
    local_1e0 = (**(code **)(*plVar12 + 0x48))(plVar12);
    local_res18 = operator_new(8);
    local_1d8[0] = plVar17;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_1d8;
      local_1d8[0] = local_res18;
    }
    local_1c0 = (longlong *)0x0;
    local_1b8 = (longlong *)0x0;
    local_1b0 = 0;
    local_res20 = local_res18;
    lVar13 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    uVar3 = local_210;
    if (lVar13 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_1c0 != (longlong *)0x0) {
        operator_delete(local_1c0);
      }
      local_1c0 = (longlong *)0x0;
      local_1b8 = (longlong *)0x0;
      local_1b0 = 0;
      operator_delete(local_1d8[0]);
    }
    else {
      pplVar20 = (longlong **)CONCAT44(uVar9,0x1043);
      FUN_1402d2470(lVar13,local_1d8,local_210,iVar8 + 2,pplVar20);
      local_res18 = operator_new(8);
      local_160[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_160;
        local_160[0] = local_res18;
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_f0[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_f0;
        local_f0[0] = local_res18;
      }
      local_d8 = (void *)0x0;
      local_d0 = 0;
      local_c8 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_1a8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_1a8;
        local_1a8[0] = local_res18;
      }
      local_190 = (void *)0x0;
      local_188 = 0;
      local_180 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_c0[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_c0;
        local_c0[0] = local_res18;
      }
      local_a8 = (void *)0x0;
      local_a0 = 0;
      local_98 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      plVar12 = local_1c0;
      local_130[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_130;
        local_130[0] = local_res18;
      }
      local_118 = (void *)0x0;
      local_110 = 0;
      local_108 = 0;
      local_1f8 = 0;
      local_208 = 0;
      local_1f0 = 0;
      local_168 = local_1c0;
      local_178 = (longlong *)0x0;
      local_res20 = local_res18;
      if (local_1b8 < local_1c0) {
        _invalid_parameter_noinfo();
      }
      local_210 = local_1d8[0];
      local_178 = local_1d8[0];
      plVar19 = local_1d8[0];
      while( true ) {
        plVar4 = local_1b8;
        local_78 = (longlong *)0x0;
        if (local_1b8 < local_1c0) {
          _invalid_parameter_noinfo();
        }
        local_78 = local_1d8[0];
        if ((plVar19 == (longlong *)0x0) || (plVar19 != local_1d8[0])) {
          _invalid_parameter_noinfo();
        }
        if ((plVar12 == plVar4) || ((local_1e0 <= local_208 && (local_1e0 != 0))))
        goto LAB_1404d343d;
        local_1f0 = (int)plVar17 + 1;
        if (10000 < local_1f0) break;
        lVar13 = 0;
        local_218 = (longlong *)0x0;
        if (plVar19 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar14 = lVar13;
        }
        else {
          lVar14 = *plVar19;
        }
        if (*(longlong **)(lVar14 + 0x20) <= plVar12) {
          _invalid_parameter_noinfo();
        }
        if (*plVar12 != 0) {
          if (plVar19 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar14 = lVar13;
          }
          else {
            lVar14 = *plVar19;
          }
          if (*(longlong **)(lVar14 + 0x20) <= plVar12) {
            _invalid_parameter_noinfo();
          }
          cVar6 = (**(code **)(*(longlong *)*plVar12 + 0x40))((longlong *)*plVar12,&local_218);
          if (cVar6 != '\0') {
            local_1e8 = (**(code **)(*local_218 + 0x40))();
            iStack_1e4 = (**(code **)(*local_218 + 0x48))();
            plVar12 = *(longlong **)(param_1 + 0x60);
            iVar8 = (**(code **)(*local_218 + 0x10))();
            iVar10 = (**(code **)(*plVar12 + 8))(plVar12);
            if (iVar8 != iVar10) {
              uVar2 = CONCAT44(iStack_1e4,local_1e8);
              cVar6 = FUN_1401671e0(uVar2,uVar3,(ulonglong)local_200 & 0xffffffff);
              if (((cVar6 != '\0') && (cVar6 = (**(code **)(*local_218 + 0x220))(), cVar6 != '\0'))
                 && (cVar6 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_218), cVar6 == '\0'
                    )) {
                local_208 = local_208 + 1;
                cVar6 = FUN_1403e9290(local_218);
                if (cVar6 == '\0') {
                  local_1dc = (**(code **)(*local_218 + 0x10))();
                  FUN_1400a84d0(param_1 + 0x70,&local_178,&local_1dc);
                  plVar12 = local_178;
                  lVar14 = *(longlong *)(param_1 + 0xa0);
                  local_60[0] = *(longlong **)(param_1 + 0x70);
                  if ((local_178 == (longlong *)0x0) || (local_178 != local_60[0])) {
                    _invalid_parameter_noinfo();
                  }
                  lVar15 = CONCAT44(uStack_16c,uStack_170);
                  if (lVar15 == lVar14) {
                    local_100 = (**(code **)(*local_218 + 0x10))();
                    local_fc = uVar2;
                    FUN_1400a3da0(param_1 + 0x70,local_60,&local_100);
                  }
                  else {
                    if (plVar12 == (longlong *)0x0) {
                      _invalid_parameter_noinfo();
                      lVar14 = 0;
                    }
                    else {
                      lVar14 = *plVar12;
                    }
                    if (lVar15 == *(longlong *)(lVar14 + 0x30)) {
                      _invalid_parameter_noinfo();
                    }
                    local_90 = *(undefined8 *)(lVar15 + 0x1c);
                    if (((int)local_90 != local_1e8) ||
                       ((int)((ulonglong)local_90 >> 0x20) != iStack_1e4)) {
                      local_88 = (undefined4)local_178;
                      uStack_84 = local_178._4_4_;
                      uStack_80 = uStack_170;
                      uStack_7c = uStack_16c;
                      FUN_14009ed90(param_1 + 0x70,local_48,&local_88);
                      plVar19 = local_210;
                      goto LAB_1404d33f4;
                    }
                  }
                  plVar17 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),1);
                  lVar14 = *local_218;
                  plVar12 = *(longlong **)(param_1 + 0x60);
                  uVar9 = (**(code **)(*plVar17 + 0x48))(plVar17);
                  uVar7 = (**(code **)(*plVar12 + 8))(plVar12);
                  cVar6 = (**(code **)(lVar14 + 0x398))(local_218,uVar7,uVar9,0);
                  uVar9 = (undefined4)((ulonglong)pplVar20 >> 0x20);
                  plVar19 = local_210;
                  if (cVar6 == '\0') {
                    local_res18 = (longlong *)((ulonglong)local_res18 & 0xffffffff00000000);
                    local_res20 = (longlong *)((ulonglong)local_res20 & 0xffffffff00000000);
                    iVar8 = (**(code **)(*local_218 + 0x10))();
                    if (iVar8 - 0xaae61U < 99999) {
                      plVar12 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140)
                      ;
                      plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,0x34);
                      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar9);
                    }
                    else {
                      plVar12 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),0x1e);
                      iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      if (iVar8 == 0) {
                        plVar12 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),10);
                        lVar14 = lVar13;
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar14 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar15 + 0x100) == 0) {
                          log_InlineLogERROR(&DAT_1406d9c10);
                          lVar15 = lVar13;
                        }
                        else {
                          lVar15 = *(longlong *)(lVar15 + 0x100);
                        }
                        uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                        uVar9 = FUN_1402f3100(lVar15,lVar14,local_218,uVar9,&local_res20);
                        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar9);
                      }
                      else {
                        plVar12 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),0x1e);
                        iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
                        if (iVar8 == 1) {
                          plVar12 = (longlong *)
                                    (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                              (*(longlong **)(param_2 + 0x40),10);
                          uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
                          lVar14 = lVar13;
                          if (*(longlong *)(param_1 + 0x60) != 0) {
                            lVar14 = *(longlong *)(param_1 + 0x60) + 0x10;
                          }
                          in_stack_fffffffffffffdc8 = in_stack_fffffffffffffdc8 & 0xffffffffffffff00
                          ;
                          in_stack_fffffffffffffdb8 = in_stack_fffffffffffffdb8 & 0xffffffffffffff00
                          ;
                          in_stack_fffffffffffffdb0 = in_stack_fffffffffffffdb0 & 0xffffffff00000000
                          ;
                          uVar9 = FUN_1403ec0a0(lVar14,local_218,0,1,CONCAT44(uVar9,uVar7),
                                                in_stack_fffffffffffffdb0,in_stack_fffffffffffffdb8,
                                                &local_res20,in_stack_fffffffffffffdc8);
                          local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar9);
                        }
                      }
                    }
                    pplVar20 = &local_res18;
                    FUN_1404caac0(param_1,param_2,local_218,&local_res20,pplVar20);
                    FUN_1401af440(local_160,&local_218);
                    FUN_14000f0a0(local_1a8,&local_res18);
                    local_1f4 = 0;
                    plVar12 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x26);
                    uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                    plVar12 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x27);
                    uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
                    lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar14 + 0x100) == 0) {
                      pplVar20 = (longlong **)CONCAT44((int)((ulonglong)pplVar20 >> 0x20),0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      lVar14 = lVar13;
                    }
                    else {
                      lVar14 = *(longlong *)(lVar14 + 0x100);
                    }
                    cVar6 = FUN_1402ec490(lVar14,uVar9);
                    uVar22 = (undefined4)((ulonglong)pplVar20 >> 0x20);
                    if (cVar6 != '\0') {
                      lVar14 = lVar13;
                      if (*(longlong *)(param_1 + 0x60) != 0) {
                        lVar14 = *(longlong *)(param_1 + 0x60) + 0x10;
                      }
                      lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar15 + 0x100) == 0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        lVar15 = lVar13;
                      }
                      else {
                        lVar15 = *(longlong *)(lVar15 + 0x100);
                      }
                      pplVar20 = (longlong **)CONCAT44(uVar22,uVar7);
                      local_1f4 = FUN_1402ec380(lVar15,lVar14,local_218,uVar9,pplVar20);
                      lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar14 + 0x100) == 0) {
                        pplVar20 = (longlong **)CONCAT44((int)((ulonglong)pplVar20 >> 0x20),0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                      }
                      else {
                        lVar13 = *(longlong *)(lVar14 + 0x100);
                      }
                      FUN_1402ecf10(lVar13,&local_res20,uVar9);
                    }
                    FUN_1402751c0(local_c0,&local_res20);
                    FUN_14000f0a0(local_130,&local_1f4);
                    plVar19 = local_210;
                  }
                }
                else {
                  FUN_1401af440(local_f0,&local_218);
                }
              }
            }
          }
        }
LAB_1404d33f4:
        if (plVar19 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar13 = 0;
        }
        else {
          lVar13 = *plVar19;
        }
        plVar12 = local_168;
        if (*(longlong **)(lVar13 + 0x20) <= local_168) {
          _invalid_parameter_noinfo();
        }
        plVar12 = plVar12 + 1;
        plVar17 = (longlong *)(ulonglong)local_1f0;
        local_168 = plVar12;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d343d:
      lVar13 = *(longlong *)(param_1 + 0x60);
      uVar9 = (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x48))();
      uVar7 = (**(code **)(*(longlong *)(lVar13 + 0x10) + 0x40))(lVar13 + 0x10);
      pplVar20 = local_130;
      pplVar25 = local_c0;
      pplVar24 = local_1a8;
      pplVar23 = local_f0;
      pplVar21 = local_160;
      FUN_1404cc740(param_1,param_2,uVar7,uVar9,pplVar21,pplVar23,pplVar24,pplVar25,pplVar20);
      plVar12 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0x10);
      iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
      plVar12 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0xd);
      uVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
      if (iVar8 == 0x5b) {
        FUN_1404ceb90(param_1,local_160,param_2,uVar9);
      }
      local_1f8 = 0;
      while (iVar8 = local_1f8, uVar16 = local_140 - (longlong)local_148 >> 3,
            local_1f8 < (int)uVar16) {
        uVar18 = (ulonglong)local_1f8;
        if (uVar16 <= uVar18) {
          _invalid_parameter_noinfo();
        }
        plVar12 = *(longlong **)((longlong)local_148 + uVar18 * 8);
        if (plVar12 != (longlong *)0x0) {
          if ((ulonglong)(local_188 - (longlong)local_190 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar1 = (undefined4 *)((longlong)local_190 + uVar18 * 4);
          if (*(longlong *)(param_1 + 0x60) == 0) {
            lVar13 = 0;
          }
          else {
            lVar13 = *(longlong *)(param_1 + 0x60) + 0x10;
          }
          if ((ulonglong)(local_188 - (longlong)local_190 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar5 = local_190;
          pplVar21 = (longlong **)CONCAT71((int7)((ulonglong)pplVar21 >> 8),1);
          uVar9 = (**(code **)(*plVar12 + 0x3b8))(plVar12,lVar13,*puVar1,0,pplVar21);
          *(undefined4 *)((longlong)pvVar5 + uVar18 * 4) = uVar9;
          iVar10 = (**(code **)(*plVar12 + 0x78))(plVar12);
          if ((ulonglong)(local_188 - (longlong)local_190 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar5 = local_190;
          if ((ulonglong)(local_110 - (longlong)local_118 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          iVar11 = *(int *)((longlong)local_118 + uVar18 * 4) +
                   *(int *)((longlong)pvVar5 + uVar18 * 4);
          if (iVar11 < iVar10) {
            iVar10 = iVar11;
          }
          if (0 < iVar10) {
            pplVar21 = (longlong **)0x0;
            (**(code **)(*plVar12 + 0x2e0))(plVar12,0,(longlong)-iVar10,1,0);
            cVar6 = (**(code **)(*plVar12 + 0x220))(plVar12);
            if (cVar6 == '\0') {
              plVar17 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              pplVar25 = (longlong **)((ulonglong)pplVar25 & 0xffffffff00000000);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffffffff0000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffffffff0000);
              pplVar21 = (longlong **)((ulonglong)pplVar21 & 0xffffffffffffff00);
              (**(code **)(*plVar17 + 0x3c8))
                        (plVar17,plVar12,5,0,pplVar21,pplVar23,pplVar24,pplVar25);
            }
          }
          local_200 = (longlong *)0x0;
          cVar6 = (**(code **)(*plVar12 + 0x298))(plVar12,0x1001,&local_200);
          if ((cVar6 != '\0') && (cVar6 = (**(code **)(local_200[2] + 0x220))(), cVar6 != '\0')) {
            plVar12 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0x10);
            iVar10 = (**(code **)(*plVar12 + 0x48))(plVar12);
            plVar12 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0xd);
            iVar11 = (**(code **)(*plVar12 + 0x48))(plVar12);
            uVar9 = (undefined4)((ulonglong)pplVar21 >> 0x20);
            if ((local_200 != (longlong *)0x0) &&
               (((0 < iVar10 && (0 < iVar11)) && (iVar10 != 0x5b)))) {
              plVar12 = (longlong *)FUN_1401181a0();
              lVar13 = *plVar12;
              uVar7 = (**(code **)(*local_200 + 8))();
              pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffffffffff00);
              pplVar25 = (longlong **)((ulonglong)pplVar25 & 0xffffffff00000000);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffff00000000);
              pplVar21 = (longlong **)CONCAT44(uVar9,iVar11);
              cVar6 = (**(code **)(lVar13 + 8))
                                (plVar12,uVar7,iVar10,0,pplVar21,pplVar23,pplVar24,pplVar25,pplVar20
                                 ,0,0);
              if ((cVar6 != '\0') &&
                 (((iVar10 == 0x37 || (iVar10 == 0x38)) || ((iVar10 == 0x18 || (iVar10 == 0x6e))))))
              {
                (**(code **)(local_200[2] + 0x388))(local_200 + 2,0);
              }
            }
          }
        }
        local_1f8 = iVar8 + 1;
      }
      if (local_118 != (void *)0x0) {
        operator_delete(local_118);
      }
      local_118 = (void *)0x0;
      local_110 = 0;
      local_108 = 0;
      operator_delete(local_130[0]);
      if (local_a8 != (void *)0x0) {
        operator_delete(local_a8);
      }
      local_a8 = (void *)0x0;
      local_a0 = 0;
      local_98 = 0;
      operator_delete(local_c0[0]);
      if (local_190 != (void *)0x0) {
        operator_delete(local_190);
      }
      local_190 = (void *)0x0;
      local_188 = 0;
      local_180 = 0;
      operator_delete(local_1a8[0]);
      if (local_d8 != (void *)0x0) {
        operator_delete(local_d8);
      }
      local_d8 = (void *)0x0;
      local_d0 = 0;
      local_c8 = 0;
      operator_delete(local_f0[0]);
      if (local_148 != (void *)0x0) {
        operator_delete(local_148);
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      operator_delete(local_160[0]);
      if (local_1c0 != (longlong *)0x0) {
        operator_delete(local_1c0);
      }
      local_1c0 = (longlong *)0x0;
      local_1b8 = (longlong *)0x0;
      local_1b0 = 0;
      operator_delete(local_1d8[0]);
    }
  }
  return;
}

// ==== CMonster::helper_1404d3930  @1404d3930  [medium:callgraph-r2]  (orig: FUN_1404d3930)
void FUN_1404d3930(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  longlong *plVar3;
  void *pvVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  longlong *local_res18;
  longlong *local_res20;
  undefined8 in_stack_fffffffffffffdf8;
  longlong **pplVar19;
  undefined4 uVar21;
  longlong **pplVar20;
  ulonglong in_stack_fffffffffffffe00;
  longlong **pplVar22;
  ulonglong in_stack_fffffffffffffe08;
  longlong **pplVar23;
  longlong **pplVar24;
  ulonglong in_stack_fffffffffffffe18;
  longlong *local_1c8;
  int local_1c0;
  longlong *local_1b8;
  int local_1b0;
  undefined4 local_1ac;
  uint local_1a8;
  undefined4 local_1a0;
  undefined4 uStack_19c;
  int local_198;
  longlong *local_190 [3];
  longlong *local_178;
  longlong *local_170;
  undefined8 local_168;
  longlong *local_160 [3];
  void *local_148;
  longlong local_140;
  undefined8 local_138;
  undefined4 local_130;
  undefined4 uStack_12c;
  longlong *local_128 [3];
  void *local_110;
  longlong local_108;
  undefined8 local_100;
  longlong *local_f8 [3];
  void *local_e0;
  longlong local_d8;
  undefined8 local_d0;
  longlong *local_c8 [3];
  void *local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  longlong *local_98 [3];
  void *local_80;
  undefined8 local_78;
  undefined8 local_70;
  longlong *local_68;
  undefined8 local_58;
  longlong *local_50;
  
  uVar7 = (undefined4)((ulonglong)in_stack_fffffffffffffdf8 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar17 = (longlong *)0x0;
    local_1a0 = 0;
    uStack_19c = 0;
    local_1a0 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    uStack_19c = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0xe);
    iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_1b8 = (longlong *)CONCAT44(local_1b8._4_4_,iVar6 + 2);
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0x28);
    local_198 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_res18 = operator_new(8);
    local_190[0] = plVar17;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_190;
      local_190[0] = local_res18;
    }
    local_178 = (longlong *)0x0;
    local_170 = (longlong *)0x0;
    local_168 = 0;
    local_res20 = local_res18;
    lVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    if (lVar12 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
    else {
      pplVar19 = (longlong **)CONCAT44(uVar7,0x1043);
      uVar2 = CONCAT44(uStack_19c,local_1a0);
      FUN_1402d2470(lVar12,local_190,uVar2,iVar6 + 2,pplVar19);
      local_res18 = operator_new(8);
      local_128[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_128;
        local_128[0] = local_res18;
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_c8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_c8;
        local_c8[0] = local_res18;
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_160[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_160;
        local_160[0] = local_res18;
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_98[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_98;
        local_98[0] = local_res18;
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      plVar11 = local_178;
      local_f8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_f8;
        local_f8[0] = local_res18;
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      local_1b0 = 0;
      local_1c0 = 0;
      local_1a8 = 0;
      local_50 = (longlong *)0x0;
      local_res20 = local_res18;
      if (local_170 < local_178) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_190[0];
      local_50 = local_190[0];
      while( true ) {
        plVar13 = local_170;
        local_68 = (longlong *)0x0;
        if (local_170 < local_178) {
          _invalid_parameter_noinfo();
        }
        local_68 = local_190[0];
        if ((plVar3 == (longlong *)0x0) || (plVar3 != local_190[0])) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == plVar13) || ((local_198 <= local_1c0 && (local_198 != 0))))
        goto LAB_1404d42ee;
        local_1a8 = (int)plVar17 + 1;
        if (10000 < local_1a8) break;
        local_1c8 = (longlong *)0x0;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        if (*plVar11 != 0) {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
            _invalid_parameter_noinfo();
          }
          cVar5 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_1c8);
          if (cVar5 != '\0') {
            local_130 = (**(code **)(*local_1c8 + 0x40))();
            uStack_12c = (**(code **)(*local_1c8 + 0x48))();
            iVar6 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
            iVar9 = (**(code **)(*local_1c8 + 0x10))();
            if (((iVar9 != iVar6) &&
                (cVar5 = FUN_1401671e0(CONCAT44(uStack_12c,local_130),uVar2,
                                       (ulonglong)local_1b8 & 0xffffffff), cVar5 != '\0')) &&
               ((cVar5 = (**(code **)(*local_1c8 + 0x220))(), cVar5 != '\0' &&
                (cVar5 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_1c8), cVar5 == '\0'))))
            {
              local_1c0 = local_1c0 + 1;
              cVar5 = FUN_1403e9290(local_1c8);
              if (cVar5 == '\0') {
                plVar13 = (longlong *)
                          (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                    (*(longlong **)(param_2 + 0x40),1);
                lVar12 = *local_1c8;
                plVar17 = *(longlong **)(param_1 + 0x60);
                uVar7 = (**(code **)(*plVar13 + 0x48))(plVar13);
                uVar8 = (**(code **)(*plVar17 + 8))(plVar17);
                cVar5 = (**(code **)(lVar12 + 0x398))(local_1c8,uVar8,uVar7,0);
                uVar7 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                if (cVar5 == '\0') {
                  lVar12 = 0;
                  local_res18 = (longlong *)((ulonglong)local_res18 & 0xffffffff00000000);
                  local_res20 = (longlong *)((ulonglong)local_res20 & 0xffffffff00000000);
                  iVar6 = (**(code **)(*local_1c8 + 0x10))();
                  if (iVar6 - 0xaae61U < 99999) {
                    plVar17 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140);
                    plVar17 = (longlong *)(**(code **)(*plVar17 + 0x10))(plVar17,0x34);
                    uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                  }
                  else {
                    plVar17 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x1e);
                    iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    if (iVar6 == 0) {
                      plVar17 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),10);
                      if (*(longlong *)(param_1 + 0x60) != 0) {
                        lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                      }
                      lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar14 + 0x100) == 0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = *(undefined8 *)(lVar14 + 0x100);
                      }
                      uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      uVar7 = FUN_1402f3100(uVar16,lVar12,local_1c8,uVar7,&local_res20);
                      local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                    }
                    else {
                      plVar17 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),0x1e);
                      iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      if (iVar6 == 1) {
                        plVar17 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),10);
                        uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        in_stack_fffffffffffffe18 = in_stack_fffffffffffffe18 & 0xffffffffffffff00;
                        in_stack_fffffffffffffe08 = in_stack_fffffffffffffe08 & 0xffffffffffffff00;
                        in_stack_fffffffffffffe00 = in_stack_fffffffffffffe00 & 0xffffffff00000000;
                        uVar7 = FUN_1403ec0a0(lVar12,local_1c8,0,1,CONCAT44(uVar7,uVar8),
                                              in_stack_fffffffffffffe00,in_stack_fffffffffffffe08,
                                              &local_res20,in_stack_fffffffffffffe18);
                        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar7);
                      }
                    }
                  }
                  pplVar19 = &local_res18;
                  FUN_1404caac0(param_1,param_2,local_1c8,&local_res20,pplVar19);
                  FUN_1401af440(local_128,&local_1c8);
                  FUN_14000f0a0(local_160,&local_res18);
                  local_1ac = 0;
                  plVar17 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),0x26);
                  uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                  plVar17 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),0x27);
                  uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                  lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                  if (*(longlong *)(lVar12 + 0x100) == 0) {
                    pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                    log_InlineLogERROR(&DAT_1406d9c10);
                    uVar16 = 0;
                  }
                  else {
                    uVar16 = *(undefined8 *)(lVar12 + 0x100);
                  }
                  cVar5 = FUN_1402ec490(uVar16,uVar7);
                  uVar21 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                  if (cVar5 != '\0') {
                    if (*(longlong *)(param_1 + 0x60) == 0) {
                      lVar12 = 0;
                    }
                    else {
                      lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                    }
                    lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar14 + 0x100) == 0) {
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar16 = 0;
                    }
                    else {
                      uVar16 = *(undefined8 *)(lVar14 + 0x100);
                    }
                    pplVar19 = (longlong **)CONCAT44(uVar21,uVar8);
                    local_1ac = FUN_1402ec380(uVar16,lVar12,local_1c8,uVar7,pplVar19);
                    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar12 + 0x100) == 0) {
                      pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar16 = 0;
                    }
                    else {
                      uVar16 = *(undefined8 *)(lVar12 + 0x100);
                    }
                    FUN_1402ecf10(uVar16,&local_res20,uVar7);
                  }
                  FUN_1402751c0(local_98,&local_res20);
                  FUN_14000f0a0(local_f8,&local_1ac);
                }
              }
              else {
                FUN_1401af440(local_c8,&local_1c8);
              }
            }
          }
        }
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
        plVar17 = (longlong *)(ulonglong)local_1a8;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d42ee:
      lVar12 = *(longlong *)(param_1 + 0x60);
      uVar7 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x48))();
      uVar8 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x40))(lVar12 + 0x10);
      pplVar19 = local_f8;
      pplVar24 = local_98;
      pplVar23 = local_160;
      pplVar22 = local_c8;
      pplVar20 = local_128;
      FUN_1404cc740(param_1,param_2,uVar8,uVar7,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0x10);
      iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0xd);
      uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
      if (iVar6 == 0x5b) {
        FUN_1404ceb90(param_1,local_128,param_2,uVar7);
      }
      local_1b0 = 0;
      while (iVar6 = local_1b0, uVar15 = local_108 - (longlong)local_110 >> 3,
            local_1b0 < (int)uVar15) {
        uVar18 = (ulonglong)local_1b0;
        if (uVar15 <= uVar18) {
          _invalid_parameter_noinfo();
        }
        plVar11 = *(longlong **)((longlong)local_110 + uVar18 * 8);
        if (plVar11 != (longlong *)0x0) {
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar1 = (undefined4 *)((longlong)local_148 + uVar18 * 4);
          if (*(longlong *)(param_1 + 0x60) == 0) {
            lVar12 = 0;
          }
          else {
            lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
          }
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          pplVar20 = (longlong **)CONCAT71((int7)((ulonglong)pplVar20 >> 8),1);
          uVar7 = (**(code **)(*plVar11 + 0x3b8))(plVar11,lVar12,*puVar1,0,pplVar20);
          *(undefined4 *)((longlong)pvVar4 + uVar18 * 4) = uVar7;
          iVar9 = (**(code **)(*plVar11 + 0x78))(plVar11);
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          if ((ulonglong)(local_d8 - (longlong)local_e0 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          iVar10 = *(int *)((longlong)local_e0 + uVar18 * 4) +
                   *(int *)((longlong)pvVar4 + uVar18 * 4);
          if (iVar10 < iVar9) {
            iVar9 = iVar10;
          }
          if (0 < iVar9) {
            pplVar20 = (longlong **)0x0;
            (**(code **)(*plVar11 + 0x2e0))(plVar11,0,(longlong)-iVar9,1,0);
            cVar5 = (**(code **)(*plVar11 + 0x220))(plVar11);
            if (cVar5 == '\0') {
              plVar17 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffffffff0000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffffffff0000);
              pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffffffffff00);
              (**(code **)(*plVar17 + 0x3c8))
                        (plVar17,plVar11,5,0,pplVar20,pplVar22,pplVar23,pplVar24);
            }
          }
          local_1b8 = (longlong *)0x0;
          cVar5 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,&local_1b8);
          if ((cVar5 != '\0') && (cVar5 = (**(code **)(local_1b8[2] + 0x220))(), cVar5 != '\0')) {
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0x10);
            iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0xd);
            iVar10 = (**(code **)(*plVar11 + 0x48))(plVar11);
            uVar7 = (undefined4)((ulonglong)pplVar20 >> 0x20);
            if ((local_1b8 != (longlong *)0x0) && (((0 < iVar9 && (0 < iVar10)) && (iVar9 != 0x5b)))
               ) {
              plVar11 = (longlong *)FUN_1401181a0();
              lVar12 = *plVar11;
              uVar8 = (**(code **)(*local_1b8 + 8))();
              pplVar19 = (longlong **)((ulonglong)pplVar19 & 0xffffffffffffff00);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffff00000000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffff00000000);
              pplVar20 = (longlong **)CONCAT44(uVar7,iVar10);
              cVar5 = (**(code **)(lVar12 + 8))
                                (plVar11,uVar8,iVar9,0,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19,
                                 0,0);
              if ((cVar5 != '\0') &&
                 (((iVar9 == 0x37 || (iVar9 == 0x38)) || ((iVar9 == 0x18 || (iVar9 == 0x6e)))))) {
                (**(code **)(local_1b8[2] + 0x388))(local_1b8 + 2,0);
              }
            }
          }
        }
        local_1b0 = iVar6 + 1;
      }
      if (local_e0 != (void *)0x0) {
        operator_delete(local_e0);
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      operator_delete(local_f8[0]);
      if (local_80 != (void *)0x0) {
        operator_delete(local_80);
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      operator_delete(local_98[0]);
      if (local_148 != (void *)0x0) {
        operator_delete(local_148);
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      operator_delete(local_160[0]);
      if (local_b0 != (void *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      if (local_110 != (void *)0x0) {
        operator_delete(local_110);
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      operator_delete(local_128[0]);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
  }
  return;
}

// ==== CMonster::helper_1404d47e0  @1404d47e0  [medium:callgraph-r2]  (orig: FUN_1404d47e0)
void FUN_1404d47e0(longlong param_1,longlong param_2)

{
  ulonglong *puVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  longlong *plVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong lVar11;
  ulonglong uVar12;
  undefined8 uVar13;
  longlong *plVar14;
  ulonglong uVar15;
  ulonglong *puVar16;
  uint uVar17;
  undefined4 local_res18 [2];
  undefined4 local_res20 [2];
  longlong **in_stack_fffffffffffffdd8;
  undefined4 *puVar18;
  undefined4 uVar19;
  longlong **in_stack_fffffffffffffde0;
  longlong **in_stack_fffffffffffffde8;
  longlong **pplVar20;
  longlong **in_stack_fffffffffffffdf8;
  longlong *local_1e8;
  undefined4 local_1e0;
  uint local_1dc;
  uint local_1d8;
  undefined4 local_1d4;
  longlong *local_1d0;
  uint local_1c8;
  longlong *local_1c0;
  longlong *local_1b0;
  longlong *local_1a0 [3];
  longlong *local_188;
  longlong *local_180;
  longlong *local_178;
  undefined4 local_170;
  undefined4 uStack_16c;
  ulonglong *local_168;
  longlong *local_160 [3];
  longlong *local_148;
  longlong *local_140;
  longlong *local_138;
  longlong *local_130 [3];
  longlong *local_118;
  longlong *local_110;
  longlong *local_108;
  longlong *local_100 [3];
  longlong *local_e8;
  longlong *local_e0;
  longlong *local_d8;
  undefined8 local_d0;
  longlong local_c8;
  longlong *local_c0 [3];
  longlong *local_a8;
  longlong *local_a0;
  longlong *local_98;
  longlong *local_90 [3];
  longlong *local_78;
  longlong *local_70;
  longlong *local_68;
  longlong *local_60;
  undefined8 local_50;
  longlong *local_48;
  
  local_50 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if ((*(longlong *)(param_2 + 0x68) - *(longlong *)(param_2 + 0x60) & 0xfffffffffffffff8U) ==
           0) {
    FUN_1404ca650(param_1,param_2,0);
  }
  else {
    local_c8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    if (local_c8 == 0) {
      FUN_1404ca650(param_1,param_2,0);
    }
    else {
      plVar7 = (longlong *)
               (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                         (*(longlong **)(param_2 + 0x40),0xe);
      uVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
      puVar16 = *(ulonglong **)(param_2 + 0x60);
      local_60 = (longlong *)0x0;
      local_1e0 = uVar3;
      local_168 = puVar16;
      if (*(ulonglong **)(param_2 + 0x68) < puVar16) {
        _invalid_parameter_noinfo();
      }
      plVar7 = *(longlong **)(param_2 + 0x48);
      local_1dc = 0;
      local_60 = plVar7;
      while( true ) {
        uVar17 = local_1dc;
        uVar6 = (undefined4)((ulonglong)in_stack_fffffffffffffdd8 >> 0x20);
        puVar1 = *(ulonglong **)(param_2 + 0x68);
        local_1b0 = (longlong *)0x0;
        if (puVar1 < *(ulonglong **)(param_2 + 0x60)) {
          _invalid_parameter_noinfo();
        }
        local_1b0 = *(longlong **)(param_2 + 0x48);
        if ((plVar7 == (longlong *)0x0) || (plVar7 != local_1b0)) {
          _invalid_parameter_noinfo();
        }
        if (puVar16 == puVar1) {
          return;
        }
        local_1dc = uVar17 + 1;
        if (1000 < local_1dc) break;
        if (plVar7 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar10 = 0;
        }
        else {
          lVar10 = *plVar7;
        }
        plVar7 = (longlong *)0x0;
        if (*(ulonglong **)(lVar10 + 0x20) <= puVar16) {
          _invalid_parameter_noinfo();
        }
        uVar12 = *puVar16;
        local_d0 = uVar12;
        local_1c0 = operator_new(8);
        local_160[0] = plVar7;
        if (local_1c0 != (longlong *)0x0) {
          *local_1c0 = (longlong)local_160;
          local_160[0] = local_1c0;
        }
        puVar18 = (undefined4 *)CONCAT44(uVar6,0x1043);
        local_1b0 = local_1c0;
        local_148 = plVar7;
        local_140 = plVar7;
        local_138 = plVar7;
        FUN_1402d2470(local_c8,local_160,uVar12,uVar3,puVar18);
        local_1c0 = operator_new(8);
        local_130[0] = plVar7;
        if (local_1c0 != (longlong *)0x0) {
          *local_1c0 = (longlong)local_130;
          local_130[0] = local_1c0;
        }
        local_1b0 = local_1c0;
        local_118 = plVar7;
        local_110 = plVar7;
        local_108 = plVar7;
        local_1c0 = operator_new(8);
        local_c0[0] = plVar7;
        if (local_1c0 != (longlong *)0x0) {
          *local_1c0 = (longlong)local_c0;
          local_c0[0] = local_1c0;
        }
        local_1b0 = local_1c0;
        local_a8 = plVar7;
        local_a0 = plVar7;
        local_98 = plVar7;
        local_1c0 = operator_new(8);
        local_1a0[0] = plVar7;
        if (local_1c0 != (longlong *)0x0) {
          *local_1c0 = (longlong)local_1a0;
          local_1a0[0] = local_1c0;
        }
        local_1b0 = local_1c0;
        local_188 = plVar7;
        local_180 = plVar7;
        local_178 = plVar7;
        local_1c0 = operator_new(8);
        local_90[0] = plVar7;
        if (local_1c0 != (longlong *)0x0) {
          *local_1c0 = (longlong)local_90;
          local_90[0] = local_1c0;
        }
        local_1b0 = local_1c0;
        local_78 = plVar7;
        local_70 = plVar7;
        local_68 = plVar7;
        local_1b0 = operator_new(8);
        plVar14 = local_148;
        local_100[0] = plVar7;
        if (local_1b0 != (longlong *)0x0) {
          *local_1b0 = (longlong)local_100;
          local_100[0] = local_1b0;
        }
        local_1d8 = 0;
        uVar17 = 0;
        local_1c8 = local_1d8;
        local_e8 = plVar7;
        local_e0 = plVar7;
        local_d8 = plVar7;
        if (local_140 < local_148) {
          local_1c0 = plVar7;
          _invalid_parameter_noinfo();
        }
        plVar7 = local_160[0];
        local_1c0 = local_160[0];
        while( true ) {
          plVar9 = local_140;
          local_48 = (longlong *)0x0;
          if (local_140 < local_148) {
            _invalid_parameter_noinfo();
          }
          local_48 = local_160[0];
          if ((plVar7 == (longlong *)0x0) || (plVar7 != local_160[0])) {
            _invalid_parameter_noinfo();
          }
          if (plVar14 == plVar9) goto LAB_1404d523a;
          uVar17 = uVar17 + 1;
          local_1c8 = uVar17;
          if (10000 < uVar17) break;
          local_1e8 = (longlong *)0x0;
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar7;
          }
          if (*(longlong **)(lVar10 + 0x20) <= plVar14) {
            _invalid_parameter_noinfo();
          }
          if (*plVar14 != 0) {
            if (plVar7 == (longlong *)0x0) {
              _invalid_parameter_noinfo();
              lVar10 = 0;
            }
            else {
              lVar10 = *plVar7;
            }
            if (*(longlong **)(lVar10 + 0x20) <= plVar14) {
              _invalid_parameter_noinfo();
            }
            cVar2 = (**(code **)(*(longlong *)*plVar14 + 0x40))((longlong *)*plVar14,&local_1e8);
            if (cVar2 != '\0') {
              local_170 = (**(code **)(*local_1e8 + 0x40))();
              uStack_16c = (**(code **)(*local_1e8 + 0x48))();
              iVar4 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
              iVar5 = (**(code **)(*local_1e8 + 0x10))();
              if (((iVar5 != iVar4) &&
                  (cVar2 = FUN_1401671e0(CONCAT44(uStack_16c,local_170),uVar12,local_1e0),
                  cVar2 != '\0')) &&
                 ((cVar2 = (**(code **)(*local_1e8 + 0x220))(), cVar2 != '\0' &&
                  (cVar2 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_1e8), cVar2 == '\0'))
                 )) {
                cVar2 = FUN_1403e9290(local_1e8);
                if (cVar2 == '\0') {
                  plVar8 = (longlong *)
                           (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                     (*(longlong **)(param_2 + 0x40),1);
                  lVar10 = *local_1e8;
                  plVar9 = *(longlong **)(param_1 + 0x60);
                  uVar3 = (**(code **)(*plVar8 + 0x48))(plVar8);
                  uVar6 = (**(code **)(*plVar9 + 8))(plVar9);
                  cVar2 = (**(code **)(lVar10 + 0x398))(local_1e8,uVar6,uVar3,0);
                  uVar3 = (undefined4)((ulonglong)puVar18 >> 0x20);
                  if (cVar2 == '\0') {
                    lVar10 = 0;
                    local_res18[0] = 0;
                    local_res20[0] = 0;
                    iVar4 = (**(code **)(*local_1e8 + 0x10))();
                    if (iVar4 - 0xaae61U < 99999) {
                      plVar9 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140);
                      plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,0x34);
                      local_res18[0] = (**(code **)(*plVar9 + 0x48))(plVar9);
                    }
                    else {
                      plVar9 = (longlong *)
                               (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                         (*(longlong **)(param_2 + 0x40),0x1e);
                      iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
                      if (iVar4 == 0) {
                        plVar9 = (longlong *)
                                 (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                           (*(longlong **)(param_2 + 0x40),10);
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar10 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar11 + 0x100) == 0) {
                          log_InlineLogERROR(&DAT_1406d9c10);
                          uVar13 = 0;
                        }
                        else {
                          uVar13 = *(undefined8 *)(lVar11 + 0x100);
                        }
                        uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
                        local_res18[0] = FUN_1402f3100(uVar13,lVar10,local_1e8,uVar3,local_res20);
                      }
                      else {
                        plVar9 = (longlong *)
                                 (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                           (*(longlong **)(param_2 + 0x40),0x1e);
                        iVar4 = (**(code **)(*plVar9 + 0x48))(plVar9);
                        if (iVar4 == 1) {
                          plVar9 = (longlong *)
                                   (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                             (*(longlong **)(param_2 + 0x40),10);
                          uVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
                          if (*(longlong *)(param_1 + 0x60) != 0) {
                            lVar10 = *(longlong *)(param_1 + 0x60) + 0x10;
                          }
                          in_stack_fffffffffffffdf8 =
                               (longlong **)
                               ((ulonglong)in_stack_fffffffffffffdf8 & 0xffffffffffffff00);
                          in_stack_fffffffffffffde8 =
                               (longlong **)
                               ((ulonglong)in_stack_fffffffffffffde8 & 0xffffffffffffff00);
                          in_stack_fffffffffffffde0 =
                               (longlong **)
                               ((ulonglong)in_stack_fffffffffffffde0 & 0xffffffff00000000);
                          local_res18[0] =
                               FUN_1403ec0a0(lVar10,local_1e8,0,1,CONCAT44(uVar3,uVar6),
                                             in_stack_fffffffffffffde0,in_stack_fffffffffffffde8,
                                             local_res20,in_stack_fffffffffffffdf8);
                        }
                      }
                    }
                    puVar18 = local_res18;
                    FUN_1404caac0(param_1,param_2,local_1e8,local_res20,puVar18);
                    FUN_1401af440(local_130,&local_1e8);
                    FUN_14000f0a0(local_1a0,local_res18);
                    local_1d4 = 0;
                    plVar9 = (longlong *)
                             (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                       (*(longlong **)(param_2 + 0x40),0x26);
                    uVar3 = (**(code **)(*plVar9 + 0x48))(plVar9);
                    plVar9 = (longlong *)
                             (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                       (*(longlong **)(param_2 + 0x40),0x27);
                    uVar6 = (**(code **)(*plVar9 + 0x48))(plVar9);
                    lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar10 + 0x100) == 0) {
                      puVar18 = (undefined4 *)CONCAT44((int)((ulonglong)puVar18 >> 0x20),0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar13 = 0;
                    }
                    else {
                      uVar13 = *(undefined8 *)(lVar10 + 0x100);
                    }
                    cVar2 = FUN_1402ec490(uVar13,uVar3);
                    uVar19 = (undefined4)((ulonglong)puVar18 >> 0x20);
                    if (cVar2 != '\0') {
                      if (*(longlong *)(param_1 + 0x60) == 0) {
                        lVar10 = 0;
                      }
                      else {
                        lVar10 = *(longlong *)(param_1 + 0x60) + 0x10;
                      }
                      lVar11 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar11 + 0x100) == 0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *(undefined8 *)(lVar11 + 0x100);
                      }
                      puVar18 = (undefined4 *)CONCAT44(uVar19,uVar6);
                      local_1d4 = FUN_1402ec380(uVar13,lVar10,local_1e8,uVar3,puVar18);
                      lVar10 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar10 + 0x100) == 0) {
                        puVar18 = (undefined4 *)CONCAT44((int)((ulonglong)puVar18 >> 0x20),0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar13 = 0;
                      }
                      else {
                        uVar13 = *(undefined8 *)(lVar10 + 0x100);
                      }
                      FUN_1402ecf10(uVar13,local_res20,uVar3);
                    }
                    FUN_1402751c0(local_90,local_res20);
                    FUN_14000f0a0(local_100,&local_1d4);
                  }
                }
                else {
                  FUN_1401af440(local_c0,&local_1e8);
                }
              }
            }
          }
          if (plVar7 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar10 = 0;
          }
          else {
            lVar10 = *plVar7;
          }
          if (*(longlong **)(lVar10 + 0x20) <= plVar14) {
            _invalid_parameter_noinfo();
          }
          plVar14 = plVar14 + 1;
        }
        log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d523a:
        in_stack_fffffffffffffdf8 = local_100;
        pplVar20 = local_90;
        in_stack_fffffffffffffde8 = local_1a0;
        in_stack_fffffffffffffde0 = local_c0;
        in_stack_fffffffffffffdd8 = local_130;
        FUN_1404cc740(param_1,param_2,uVar12 & 0xffffffff,local_d0._4_4_,in_stack_fffffffffffffdd8,
                      in_stack_fffffffffffffde0,in_stack_fffffffffffffde8,pplVar20,
                      in_stack_fffffffffffffdf8);
        plVar7 = (longlong *)
                 (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                           (*(longlong **)(param_2 + 0x40),0x10);
        iVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
        plVar7 = (longlong *)
                 (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                           (*(longlong **)(param_2 + 0x40),0xd);
        uVar3 = (**(code **)(*plVar7 + 0x48))(plVar7);
        if (iVar4 == 0x5b) {
          FUN_1404ceb90(param_1,local_130,param_2,uVar3);
        }
        local_1d8 = 0;
        while( true ) {
          uVar17 = local_1d8;
          lVar10 = 0;
          uVar12 = (longlong)local_110 - (longlong)local_118 >> 3;
          if ((int)uVar12 <= (int)local_1d8) break;
          uVar15 = (ulonglong)(int)local_1d8;
          if (uVar12 <= uVar15) {
            _invalid_parameter_noinfo();
          }
          plVar7 = (longlong *)local_118[uVar15];
          if (plVar7 != (longlong *)0x0) {
            if ((ulonglong)((longlong)local_180 - (longlong)local_188 >> 2) <= uVar15) {
              _invalid_parameter_noinfo();
            }
            puVar18 = (undefined4 *)((longlong)local_188 + uVar15 * 4);
            if (*(longlong *)(param_1 + 0x60) == 0) {
              lVar10 = 0;
            }
            else {
              lVar10 = *(longlong *)(param_1 + 0x60) + 0x10;
            }
            if ((ulonglong)((longlong)local_180 - (longlong)local_188 >> 2) <= uVar15) {
              _invalid_parameter_noinfo();
            }
            plVar14 = local_188;
            in_stack_fffffffffffffdd8 =
                 (longlong **)CONCAT71((int7)((ulonglong)in_stack_fffffffffffffdd8 >> 8),1);
            uVar3 = (**(code **)(*plVar7 + 0x3b8))
                              (plVar7,lVar10,*puVar18,0,in_stack_fffffffffffffdd8);
            *(undefined4 *)((longlong)plVar14 + uVar15 * 4) = uVar3;
            iVar4 = (**(code **)(*plVar7 + 0x78))(plVar7);
            if ((ulonglong)((longlong)local_180 - (longlong)local_188 >> 2) <= uVar15) {
              _invalid_parameter_noinfo();
            }
            plVar14 = local_188;
            if ((ulonglong)((longlong)local_e0 - (longlong)local_e8 >> 2) <= uVar15) {
              _invalid_parameter_noinfo();
            }
            iVar5 = *(int *)((longlong)local_e8 + uVar15 * 4) +
                    *(int *)((longlong)plVar14 + uVar15 * 4);
            if (iVar5 < iVar4) {
              iVar4 = iVar5;
            }
            if (0 < iVar4) {
              in_stack_fffffffffffffdd8 = (longlong **)0x0;
              (**(code **)(*plVar7 + 0x2e0))(plVar7,0,(longlong)-iVar4,1,0);
              cVar2 = (**(code **)(*plVar7 + 0x220))(plVar7);
              if (cVar2 == '\0') {
                plVar14 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffff00000000);
                in_stack_fffffffffffffde8 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffde8 & 0xffffffffffff0000);
                in_stack_fffffffffffffde0 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffde0 & 0xffffffffffff0000);
                in_stack_fffffffffffffdd8 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffdd8 & 0xffffffffffffff00);
                (**(code **)(*plVar14 + 0x3c8))
                          (plVar14,plVar7,5,0,in_stack_fffffffffffffdd8,in_stack_fffffffffffffde0,
                           in_stack_fffffffffffffde8,pplVar20);
              }
            }
            local_1d0 = (longlong *)0x0;
            cVar2 = (**(code **)(*plVar7 + 0x298))(plVar7,0x1001,&local_1d0);
            if ((cVar2 != '\0') && (cVar2 = (**(code **)(local_1d0[2] + 0x220))(), cVar2 != '\0')) {
              plVar7 = (longlong *)
                       (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                 (*(longlong **)(param_2 + 0x40),0x10);
              iVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
              plVar7 = (longlong *)
                       (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                 (*(longlong **)(param_2 + 0x40),0xd);
              iVar5 = (**(code **)(*plVar7 + 0x48))(plVar7);
              uVar3 = (undefined4)((ulonglong)in_stack_fffffffffffffdd8 >> 0x20);
              if ((local_1d0 != (longlong *)0x0) &&
                 (((0 < iVar4 && (0 < iVar5)) && (iVar4 != 0x5b)))) {
                plVar7 = (longlong *)FUN_1401181a0();
                lVar10 = *plVar7;
                uVar6 = (**(code **)(*local_1d0 + 8))();
                in_stack_fffffffffffffdf8 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffdf8 & 0xffffffffffffff00);
                pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffff00000000);
                in_stack_fffffffffffffde8 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffde8 & 0xffffffff00000000);
                in_stack_fffffffffffffde0 =
                     (longlong **)((ulonglong)in_stack_fffffffffffffde0 & 0xffffffff00000000);
                in_stack_fffffffffffffdd8 = (longlong **)CONCAT44(uVar3,iVar5);
                cVar2 = (**(code **)(lVar10 + 8))
                                  (plVar7,uVar6,iVar4,0,in_stack_fffffffffffffdd8,
                                   in_stack_fffffffffffffde0,in_stack_fffffffffffffde8,pplVar20,
                                   in_stack_fffffffffffffdf8,0,0);
                if ((cVar2 != '\0') &&
                   (((iVar4 == 0x37 || (iVar4 == 0x38)) || ((iVar4 == 0x18 || (iVar4 == 0x6e)))))) {
                  (**(code **)(local_1d0[2] + 0x388))(local_1d0 + 2,0);
                }
              }
            }
          }
          local_1d8 = uVar17 + 1;
        }
        if (local_e8 != (longlong *)0x0) {
          operator_delete(local_e8);
        }
        local_e8 = (longlong *)0x0;
        local_e0 = (longlong *)0x0;
        local_d8 = (longlong *)0x0;
        operator_delete(local_100[0]);
        if (local_78 != (longlong *)0x0) {
          operator_delete(local_78);
        }
        local_78 = (longlong *)0x0;
        local_70 = (longlong *)0x0;
        local_68 = (longlong *)0x0;
        operator_delete(local_90[0]);
        if (local_188 != (longlong *)0x0) {
          operator_delete(local_188);
        }
        local_188 = (longlong *)0x0;
        local_180 = (longlong *)0x0;
        local_178 = (longlong *)0x0;
        operator_delete(local_1a0[0]);
        if (local_a8 != (longlong *)0x0) {
          operator_delete(local_a8);
        }
        local_a8 = (longlong *)0x0;
        local_a0 = (longlong *)0x0;
        local_98 = (longlong *)0x0;
        operator_delete(local_c0[0]);
        if (local_118 != (longlong *)0x0) {
          operator_delete(local_118);
        }
        local_118 = (longlong *)0x0;
        local_110 = (longlong *)0x0;
        local_108 = (longlong *)0x0;
        operator_delete(local_130[0]);
        if (local_148 != (longlong *)0x0) {
          operator_delete(local_148);
        }
        local_148 = (longlong *)0x0;
        local_140 = (longlong *)0x0;
        local_138 = (longlong *)0x0;
        operator_delete(local_160[0]);
        plVar7 = local_60;
        if (local_60 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar10 = *local_60;
        }
        puVar16 = local_168;
        if (*(ulonglong **)(lVar10 + 0x20) <= local_168) {
          _invalid_parameter_noinfo();
        }
        puVar16 = puVar16 + 1;
        uVar3 = local_1e0;
        local_168 = puVar16;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

// ==== CMonster::helper_1404d5770  @1404d5770  [medium:callgraph-r2]  (orig: FUN_1404d5770)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d5770(longlong param_1,undefined4 *param_2)

{
  longlong *plVar1;
  undefined8 uVar2;
  undefined4 *puVar3;
  void *pvVar4;
  char cVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  longlong *plVar11;
  longlong *plVar12;
  longlong lVar13;
  longlong *plVar14;
  longlong lVar15;
  longlong lVar16;
  ulonglong uVar17;
  longlong *plVar18;
  undefined8 uVar19;
  longlong *plVar20;
  void *pvVar21;
  ulonglong uVar22;
  undefined1 auStack_688 [32];
  undefined4 *local_668;
  uint local_660;
  uint local_658;
  undefined4 *local_650;
  uint local_648;
  uint local_640;
  uint local_638;
  longlong *local_628;
  undefined4 local_620;
  undefined4 local_61c;
  uint local_618;
  uint uStack_614;
  undefined8 local_610;
  uint local_608;
  uint local_604;
  longlong *local_600;
  undefined4 local_5f8 [2];
  longlong *local_5f0;
  undefined4 *local_5e0;
  int local_5d8;
  uint local_5d4;
  uint local_5d0;
  longlong *local_5c8 [3];
  void *local_5b0;
  longlong local_5a8;
  undefined8 local_5a0;
  longlong *local_598 [3];
  longlong *local_580;
  longlong *local_578;
  undefined8 local_570;
  longlong *local_568 [3];
  void *local_550;
  longlong local_548;
  undefined8 local_540;
  longlong *local_538 [3];
  void *local_520;
  longlong local_518;
  undefined8 local_510;
  longlong *local_508 [3];
  longlong *local_4f0;
  longlong *local_4e8;
  undefined8 local_4e0;
  longlong *local_4d8 [3];
  void *local_4c0;
  longlong local_4b8;
  undefined8 local_4b0;
  longlong *local_4a8;
  longlong *local_498;
  undefined8 local_488;
  longlong *local_480;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_488 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_688;
  local_5e0 = param_2;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x816);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == (undefined4 *)0x0) {
    local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x817);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar1 = *(longlong **)(param_2 + 0x10);
    if (plVar1 == (longlong *)0x0) {
      local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x818);
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      iVar9 = param_2[0x1e];
      local_600 = (longlong *)CONCAT44(local_600._4_4_,iVar9);
      if (((*(longlong *)(param_2 + 0x1a) - *(longlong *)(param_2 + 0x18) & 0xfffffffffffffff8U) ==
           0) || (iVar9 == 0)) {
        FUN_1404ca650(param_1,param_2,0);
      }
      else {
        plVar11 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0xf);
        uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
        plVar11 = (longlong *)FUN_1404cbc40(param_1,uVar6,iVar9);
        if (plVar11 == (longlong *)0x0) {
          FUN_1404ca650(param_1,param_2,0);
        }
        else {
          plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0xe);
          uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
          local_608 = uVar7;
          lVar13 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
          if (lVar13 == 0) {
            FUN_1404ca650(param_1,param_2,0);
          }
          else {
            plVar12 = (longlong *)0x0;
            local_618 = 0;
            uStack_614 = 0;
            local_618 = (**(code **)(*plVar11 + 0x40))(plVar11);
            uStack_614 = (**(code **)(*plVar11 + 0x48))(plVar11);
            local_610 = operator_new(8);
            local_598[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_598;
              local_598[0] = local_610;
            }
            local_580 = (longlong *)0x0;
            local_578 = (longlong *)0x0;
            local_570 = 0;
            local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x1043);
            uVar2 = CONCAT44(uStack_614,local_618);
            local_5f0 = local_610;
            FUN_1402d2470(lVar13,local_598,uVar2,uVar7);
            local_610 = operator_new(8);
            local_568[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_568;
              local_568[0] = local_610;
            }
            local_550 = (void *)0x0;
            local_548 = 0;
            local_540 = 0;
            local_5f0 = local_610;
            local_610 = operator_new(8);
            local_508[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_508;
              local_508[0] = local_610;
            }
            local_4f0 = (longlong *)0x0;
            local_4e8 = (longlong *)0x0;
            local_4e0 = 0;
            local_5f0 = local_610;
            local_610 = operator_new(8);
            local_5c8[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_5c8;
              local_5c8[0] = local_610;
            }
            local_5b0 = (void *)0x0;
            local_5a8 = 0;
            local_5a0 = 0;
            local_5f0 = local_610;
            local_610 = operator_new(8);
            local_4d8[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_4d8;
              local_4d8[0] = local_610;
            }
            local_4c0 = (void *)0x0;
            local_4b8 = 0;
            local_4b0 = 0;
            local_5f0 = local_610;
            local_610 = operator_new(8);
            local_538[0] = plVar12;
            if (local_610 != (longlong *)0x0) {
              *local_610 = (longlong)local_538;
              local_538[0] = local_610;
            }
            local_520 = (void *)0x0;
            local_518 = 0;
            local_510 = 0;
            local_5f0 = local_610;
            plVar11 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x28);
            local_5d4 = (**(code **)(*plVar11 + 0x40))(plVar11);
            plVar11 = local_580;
            local_604 = 0;
            local_480 = (longlong *)0x0;
            if (local_578 < local_580) {
              _invalid_parameter_noinfo();
            }
            local_5f0 = local_598[0];
            local_480 = local_598[0];
            plVar14 = local_598[0];
            while( true ) {
              plVar20 = local_578;
              local_498 = (longlong *)0x0;
              if (local_578 < local_580) {
                _invalid_parameter_noinfo();
              }
              local_498 = local_598[0];
              if ((plVar14 == (longlong *)0x0) || (plVar14 != local_598[0])) {
                _invalid_parameter_noinfo();
              }
              if ((plVar11 == plVar20) ||
                 ((local_5d4 != 0 &&
                  ((ulonglong)local_5d4 <=
                   (ulonglong)((longlong)local_578 - (longlong)local_580 >> 3)))))
              goto LAB_1404d610f;
              local_604 = (int)plVar12 + 1;
              plVar12 = (longlong *)(ulonglong)local_604;
              if (10000 < local_604) break;
              if (plVar14 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                lVar13 = 0;
              }
              else {
                lVar13 = *plVar14;
              }
              if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
                _invalid_parameter_noinfo();
              }
              plVar20 = (longlong *)*plVar11;
              local_628 = (longlong *)0x0;
              if ((plVar20 != (longlong *)0x0) &&
                 (cVar5 = (**(code **)(*plVar20 + 0x40))(plVar20,&local_628), cVar5 != '\0')) {
                uVar6 = (**(code **)(*local_628 + 0x40))();
                local_610 = (longlong *)CONCAT44(local_610._4_4_,uVar6);
                uVar6 = (**(code **)(*local_628 + 0x48))();
                local_610 = (longlong *)CONCAT44(uVar6,(undefined4)local_610);
                iVar9 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                iVar10 = (**(code **)(*local_628 + 0x10))();
                if ((iVar10 != iVar9) &&
                   (((cVar5 = FUN_1401671e0(local_610,uVar2,local_608), cVar5 != '\0' &&
                     (cVar5 = (**(code **)(*local_628 + 0x220))(), cVar5 != '\0')) &&
                    (cVar5 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_628), cVar5 == '\0'
                    )))) {
                  cVar5 = FUN_1403e9290(local_628);
                  if (cVar5 == '\0') {
                    plVar14 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,1);
                    lVar13 = *local_628;
                    plVar12 = *(longlong **)(param_1 + 0x60);
                    uVar6 = (**(code **)(*plVar14 + 0x48))(plVar14);
                    uVar8 = (**(code **)(*plVar12 + 8))(plVar12);
                    cVar5 = (**(code **)(lVar13 + 0x398))(local_628,uVar8,uVar6,0);
                    if (cVar5 == '\0') {
                      lVar13 = 0;
                      local_620 = 0;
                      local_61c = 0;
                      iVar9 = (**(code **)(*local_628 + 0x10))();
                      if (iVar9 - 0xaae61U < 99999) {
                        plVar12 = (longlong *)
                                  **(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140);
                        plVar12 = (longlong *)(**(code **)(*plVar12 + 0x10))(plVar12,0x34);
                        local_620 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      }
                      else {
                        plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x1e);
                        iVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                        if (iVar9 == 0) {
                          plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,10);
                          lVar16 = lVar13;
                          if (*(longlong *)(param_1 + 0x60) != 0) {
                            lVar16 = *(longlong *)(param_1 + 0x60) + 0x10;
                          }
                          lVar15 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                          if (*(longlong *)(lVar15 + 0x100) == 0) {
                            local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x144);
                            log_InlineLogERROR(&DAT_1406d9c10);
                          }
                          else {
                            lVar13 = *(longlong *)(lVar15 + 0x100);
                          }
                          uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
                          local_668 = &local_61c;
                          local_620 = FUN_1402f3100(lVar13,lVar16,local_628,uVar6);
                        }
                        else {
                          plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x1e);
                          iVar9 = (**(code **)(*plVar12 + 0x48))(plVar12);
                          if (iVar9 == 1) {
                            plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,10);
                            uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
                            if (*(longlong *)(param_1 + 0x60) != 0) {
                              lVar13 = *(longlong *)(param_1 + 0x60) + 0x10;
                            }
                            local_648 = local_648 & 0xffffff00;
                            local_650 = &local_61c;
                            local_658 = local_658 & 0xffffff00;
                            local_660 = 0;
                            local_668 = (undefined4 *)CONCAT44(local_668._4_4_,uVar6);
                            local_620 = FUN_1403ec0a0(lVar13,local_628,0,1);
                          }
                        }
                      }
                      lVar13 = 0;
                      local_668 = &local_620;
                      FUN_1404caac0(param_1,local_5e0,local_628);
                      FUN_1401af440(local_568,&local_628);
                      FUN_14000f0a0(local_5c8,&local_620);
                      local_5f8[0] = 0;
                      plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x26);
                      uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x27);
                      uVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
                      lVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar16 + 0x100) == 0) {
                        local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        lVar16 = lVar13;
                      }
                      else {
                        lVar16 = *(longlong *)(lVar16 + 0x100);
                      }
                      cVar5 = FUN_1402ec490(lVar16,uVar6);
                      if (cVar5 != '\0') {
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar13 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        lVar16 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar16 + 0x100) == 0) {
                          local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x144);
                          log_InlineLogERROR(&DAT_1406d9c10);
                          uVar19 = 0;
                        }
                        else {
                          uVar19 = *(undefined8 *)(lVar16 + 0x100);
                        }
                        local_668 = (undefined4 *)CONCAT44(local_668._4_4_,uVar8);
                        local_5f8[0] = FUN_1402ec380(uVar19,lVar13,local_628);
                        lVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar13 + 0x100) == 0) {
                          local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x144);
                          log_InlineLogERROR(&DAT_1406d9c10);
                          uVar19 = 0;
                        }
                        else {
                          uVar19 = *(undefined8 *)(lVar13 + 0x100);
                        }
                        FUN_1402ecf10(uVar19,&local_61c,uVar6);
                      }
                      FUN_1402751c0(local_4d8,&local_61c);
                      FUN_14000f0a0(local_538,local_5f8);
                      plVar12 = (longlong *)(ulonglong)local_604;
                      plVar14 = local_5f0;
                    }
                    else {
                      plVar12 = (longlong *)(ulonglong)local_604;
                      plVar14 = local_5f0;
                    }
                  }
                  else {
                    FUN_1401af440(local_508,&local_628);
                  }
                }
              }
              lVar13 = 0;
              if (plVar14 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
              }
              else {
                lVar13 = *plVar14;
              }
              if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
                _invalid_parameter_noinfo();
              }
              plVar11 = plVar11 + 1;
            }
            local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x84d);
            log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d610f:
            FUN_140386780(local_468);
            plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,1);
            plVar11 = *(longlong **)(param_1 + 0x60);
            uVar6 = (**(code **)(*plVar12 + 0x48))(plVar12);
            uVar8 = (**(code **)(*plVar11 + 8))(plVar11);
            local_638 = local_638 & 0xffffff00;
            iVar10 = 0;
            local_640 = 0;
            local_648 = 0;
            local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
            local_658 = uStack_614;
            local_660 = local_618;
            local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffffffffff00);
            iVar9 = FUN_140386a50(local_468,uVar8,uVar6,0);
            if (iVar9 == 0) {
              local_668 = (undefined4 *)CONCAT44(local_668._4_4_,0x8a4);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              local_5d8 = 0;
              while (plVar11 = local_4f0, uVar17 = local_548 - (longlong)local_550 >> 3,
                    iVar10 < (int)uVar17) {
                uVar22 = (ulonglong)iVar10;
                if (uVar17 <= uVar22) {
                  _invalid_parameter_noinfo();
                }
                iVar9 = (**(code **)(**(longlong **)((longlong)local_550 + uVar22 * 8) + 0x10))();
                local_608 = (uint)(iVar9 != (int)local_600);
                if ((ulonglong)(local_518 - (longlong)local_520 >> 2) <= uVar22) {
                  _invalid_parameter_noinfo();
                }
                pvVar21 = local_520;
                if ((ulonglong)(local_4b8 - (longlong)local_4c0 >> 2) <= uVar22) {
                  _invalid_parameter_noinfo();
                }
                pvVar4 = local_4c0;
                if ((ulonglong)(local_5a8 - (longlong)local_5b0 >> 2) <= uVar22) {
                  _invalid_parameter_noinfo();
                }
                local_648 = 0;
                local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                local_658 = local_608;
                local_660 = *(uint *)((longlong)pvVar21 + uVar22 * 4);
                local_668 = (undefined4 *)
                            CONCAT44(local_668._4_4_,*(undefined4 *)((longlong)pvVar4 + uVar22 * 4))
                ;
                iVar9 = FUN_140387150(local_468,iVar9,
                                      *(undefined4 *)((longlong)local_5b0 + uVar22 * 4),0);
                if (iVar9 == 0) {
                  plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                  (**(code **)(*plVar11 + 0x348))(plVar11,local_468,1);
                  plVar12 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,1);
                  plVar11 = *(longlong **)(param_1 + 0x60);
                  (**(code **)(*plVar12 + 0x48))(plVar12);
                  uVar6 = (**(code **)(*plVar11 + 8))(plVar11);
                  local_638 = local_638 & 0xffffff00;
                  local_640 = 0;
                  local_648 = 0;
                  local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                  local_658 = uStack_614;
                  local_660 = local_618;
                  local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffffffffff00);
                  FUN_140386a50(local_468,uVar6);
                }
                else {
                  iVar10 = iVar10 + 1;
                  local_5d8 = iVar10;
                }
              }
              local_5f0 = (longlong *)0x0;
              if (local_4e8 < local_4f0) {
                _invalid_parameter_noinfo();
              }
              plVar12 = local_508[0];
              local_5f0 = local_508[0];
              while( true ) {
                plVar14 = local_4e8;
                lVar13 = 0;
                local_4a8 = (longlong *)0x0;
                if (local_4e8 < local_4f0) {
                  _invalid_parameter_noinfo();
                }
                local_4a8 = local_508[0];
                if ((plVar12 == (longlong *)0x0) || (plVar12 != local_508[0])) {
                  _invalid_parameter_noinfo();
                }
                if (plVar11 == plVar14) break;
                if (plVar12 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                }
                else {
                  lVar13 = *plVar12;
                }
                if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
                  _invalid_parameter_noinfo();
                }
                plVar14 = (longlong *)*plVar11;
                if (plVar14 != (longlong *)0x0) {
                  uVar6 = (**(code **)(*plVar14 + 0x10))(plVar14);
                  local_648 = 2;
                  local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                  local_658 = 0;
                  local_660 = 0;
                  local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffff00000000);
                  iVar9 = FUN_140387150(local_468,uVar6,0,0);
                  if (iVar9 == 0) {
                    plVar20 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                    (**(code **)(*plVar20 + 0x348))(plVar20,local_468,1);
                    plVar18 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,1);
                    plVar20 = *(longlong **)(param_1 + 0x60);
                    (**(code **)(*plVar18 + 0x48))(plVar18);
                    uVar6 = (**(code **)(*plVar20 + 8))(plVar20);
                    local_638 = local_638 & 0xffffff00;
                    local_640 = 0;
                    local_648 = 0;
                    local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                    local_658 = uStack_614;
                    local_660 = local_618;
                    local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffffffffff00);
                    FUN_140386a50(local_468,uVar6);
                    uVar6 = (**(code **)(*plVar14 + 0x10))(plVar14);
                    local_648 = 2;
                    local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                    local_658 = 0;
                    local_660 = 0;
                    local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffff00000000);
                    FUN_140387150(local_468,uVar6,0,0);
                  }
                }
                if (plVar12 == (longlong *)0x0) {
                  _invalid_parameter_noinfo();
                  lVar13 = 0;
                }
                else {
                  lVar13 = *plVar12;
                }
                if (*(longlong **)(lVar13 + 0x20) <= plVar11) {
                  _invalid_parameter_noinfo();
                }
                plVar11 = plVar11 + 1;
              }
              plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              (**(code **)(*plVar11 + 0x348))(plVar11,local_468,1);
            }
            puVar3 = local_5e0;
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(local_5e0 + 0x10) + 0x10))
                                (*(longlong **)(local_5e0 + 0x10),0x10);
            iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
            plVar11 = *(longlong **)(puVar3 + 0x10);
            plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,0xd);
            uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
            if (iVar9 == 0x5b) {
              FUN_1404ceb90(param_1,local_568,puVar3,uVar6);
            }
            uVar17 = 0;
            local_5d0 = 0;
            pvVar21 = local_550;
            while( true ) {
              lVar13 = 0;
              if ((ulonglong)(local_548 - (longlong)pvVar21 >> 3) <= uVar17) break;
              plVar11 = *(longlong **)((longlong)pvVar21 + uVar17 * 8);
              if (plVar11 != (longlong *)0x0) {
                if ((ulonglong)(local_5a8 - (longlong)local_5b0 >> 2) <= uVar17) {
                  _invalid_parameter_noinfo();
                }
                local_5e0 = (undefined4 *)((longlong)local_5b0 + uVar17 * 4);
                if (*(longlong *)(param_1 + 0x60) != 0) {
                  lVar13 = *(longlong *)(param_1 + 0x60) + 0x10;
                }
                if ((ulonglong)(local_5a8 - (longlong)local_5b0 >> 2) <= uVar17) {
                  _invalid_parameter_noinfo();
                }
                pvVar21 = local_5b0;
                local_668 = (undefined4 *)CONCAT71(local_668._1_7_,1);
                uVar6 = (**(code **)(*plVar11 + 0x3b8))(plVar11,lVar13,*local_5e0,0);
                *(undefined4 *)((longlong)pvVar21 + uVar17 * 4) = uVar6;
                iVar9 = (**(code **)(*plVar11 + 0x78))(plVar11);
                if ((ulonglong)(local_5a8 - (longlong)local_5b0 >> 2) <= uVar17) {
                  _invalid_parameter_noinfo();
                }
                pvVar21 = local_5b0;
                if ((ulonglong)(local_518 - (longlong)local_520 >> 2) <= uVar17) {
                  _invalid_parameter_noinfo();
                }
                iVar10 = *(int *)((longlong)local_520 + uVar17 * 4) +
                         *(int *)((longlong)pvVar21 + uVar17 * 4);
                if (iVar10 < iVar9) {
                  iVar9 = iVar10;
                }
                if (0 < iVar9) {
                  local_668 = (undefined4 *)0x0;
                  (**(code **)(*plVar11 + 0x2e0))(plVar11,0,(longlong)-iVar9);
                  cVar5 = (**(code **)(*plVar11 + 0x220))(plVar11);
                  if (cVar5 == '\0') {
                    plVar12 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                    local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                    local_658 = local_658 & 0xffff0000;
                    local_660 = local_660 & 0xffff0000;
                    local_668 = (undefined4 *)((ulonglong)local_668 & 0xffffffffffffff00);
                    (**(code **)(*plVar12 + 0x3c8))(plVar12,plVar11,5);
                  }
                }
                local_600 = (longlong *)0x0;
                cVar5 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,&local_600);
                pvVar21 = local_550;
                if ((cVar5 != '\0') &&
                   (cVar5 = (**(code **)(local_600[2] + 0x220))(), pvVar21 = local_550,
                   cVar5 != '\0')) {
                  plVar11 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0x10);
                  iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
                  plVar11 = (longlong *)(**(code **)(*plVar1 + 8))(plVar1,0xd);
                  iVar10 = (**(code **)(*plVar11 + 0x48))(plVar11);
                  pvVar21 = local_550;
                  if ((local_600 != (longlong *)0x0) &&
                     (((0 < iVar9 && (0 < iVar10)) && (iVar9 != 0x5b)))) {
                    plVar11 = (longlong *)FUN_1401181a0();
                    lVar13 = *plVar11;
                    uVar6 = (**(code **)(*local_600 + 8))();
                    local_638 = 0;
                    local_640 = local_640 & 0xffff0000;
                    local_648 = local_648 & 0xffffff00;
                    local_650 = (undefined4 *)((ulonglong)local_650 & 0xffffffff00000000);
                    local_658 = 0;
                    local_660 = 0;
                    local_668 = (undefined4 *)CONCAT44(local_668._4_4_,iVar10);
                    cVar5 = (**(code **)(lVar13 + 8))(plVar11,uVar6,iVar9);
                    pvVar21 = local_550;
                    if ((cVar5 != '\0') &&
                       (((iVar9 == 0x37 || (iVar9 == 0x38)) || ((iVar9 == 0x18 || (iVar9 == 0x6e))))
                       )) {
                      (**(code **)(local_600[2] + 0x388))(local_600 + 2,0);
                      pvVar21 = local_550;
                    }
                  }
                }
              }
              local_5d0 = (int)uVar17 + 1;
              uVar17 = (ulonglong)local_5d0;
            }
            FUN_1403867d0(local_468);
            if (local_520 != (void *)0x0) {
              operator_delete(local_520);
            }
            local_520 = (void *)0x0;
            local_518 = 0;
            local_510 = 0;
            operator_delete(local_538[0]);
            if (local_4c0 != (void *)0x0) {
              operator_delete(local_4c0);
            }
            local_4c0 = (void *)0x0;
            local_4b8 = 0;
            local_4b0 = 0;
            operator_delete(local_4d8[0]);
            if (local_5b0 != (void *)0x0) {
              operator_delete(local_5b0);
            }
            local_5b0 = (void *)0x0;
            local_5a8 = 0;
            local_5a0 = 0;
            operator_delete(local_5c8[0]);
            if (local_4f0 != (longlong *)0x0) {
              operator_delete(local_4f0);
            }
            local_4f0 = (longlong *)0x0;
            local_4e8 = (longlong *)0x0;
            local_4e0 = 0;
            operator_delete(local_508[0]);
            if (local_550 != (void *)0x0) {
              operator_delete(local_550);
            }
            local_550 = (void *)0x0;
            local_548 = 0;
            local_540 = 0;
            operator_delete(local_568[0]);
            if (local_580 != (longlong *)0x0) {
              operator_delete(local_580);
            }
            local_580 = (longlong *)0x0;
            local_578 = (longlong *)0x0;
            local_570 = 0;
            operator_delete(local_598[0]);
          }
        }
      }
    }
  }
  return;
}

// ==== CMonster::helper_1404d6a50  @1404d6a50  [medium:callgraph-r2]  (orig: FUN_1404d6a50)
void FUN_1404d6a50(longlong param_1,longlong param_2)

{
  undefined4 *puVar1;
  undefined8 uVar2;
  longlong *plVar3;
  void *pvVar4;
  char cVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  longlong lVar14;
  ulonglong uVar15;
  undefined8 uVar16;
  longlong *plVar17;
  ulonglong uVar18;
  longlong *local_res18;
  longlong *local_res20;
  undefined8 in_stack_fffffffffffffdf8;
  longlong **pplVar19;
  undefined4 uVar21;
  longlong **pplVar20;
  ulonglong in_stack_fffffffffffffe00;
  longlong **pplVar22;
  ulonglong in_stack_fffffffffffffe08;
  longlong **pplVar23;
  longlong **pplVar24;
  ulonglong in_stack_fffffffffffffe18;
  longlong *local_1c8;
  int local_1c0;
  longlong *local_1b8;
  int local_1b0;
  undefined4 local_1ac;
  uint local_1a8;
  undefined4 local_1a0;
  undefined4 uStack_19c;
  int local_198;
  int local_194;
  longlong *local_190 [3];
  longlong *local_178;
  longlong *local_170;
  undefined8 local_168;
  longlong *local_160 [3];
  void *local_148;
  longlong local_140;
  undefined8 local_138;
  undefined4 local_130;
  undefined4 uStack_12c;
  longlong *local_128 [3];
  void *local_110;
  longlong local_108;
  undefined8 local_100;
  longlong *local_f8 [3];
  void *local_e0;
  longlong local_d8;
  undefined8 local_d0;
  longlong *local_c8 [3];
  void *local_b0;
  undefined8 local_a8;
  undefined8 local_a0;
  longlong *local_98 [3];
  void *local_80;
  undefined8 local_78;
  undefined8 local_70;
  longlong *local_68;
  undefined8 local_58;
  longlong *local_50;
  
  uVar8 = (undefined4)((ulonglong)in_stack_fffffffffffffdf8 >> 0x20);
  local_58 = 0xfffffffffffffffe;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar17 = (longlong *)0x0;
    local_1a0 = 0;
    uStack_19c = 0;
    local_1a0 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
    uStack_19c = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0xf);
    iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_198 = iVar6 + 2;
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0x28);
    local_194 = (**(code **)(*plVar11 + 0x48))(plVar11);
    plVar11 = (longlong *)
              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                        (*(longlong **)(param_2 + 0x40),0x2b);
    uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
    local_1b8 = (longlong *)CONCAT44(local_1b8._4_4_,uVar7);
    local_res18 = operator_new(8);
    local_190[0] = plVar17;
    if (local_res18 != (longlong *)0x0) {
      *local_res18 = (longlong)local_190;
      local_190[0] = local_res18;
    }
    local_178 = (longlong *)0x0;
    local_170 = (longlong *)0x0;
    local_168 = 0;
    local_res20 = local_res18;
    lVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
    if (lVar12 == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
    else {
      pplVar19 = (longlong **)CONCAT44(uVar8,0x1043);
      uVar2 = CONCAT44(uStack_19c,local_1a0);
      FUN_1402d2470(lVar12,local_190,uVar2,iVar6 + 2,pplVar19);
      local_res18 = operator_new(8);
      local_128[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_128;
        local_128[0] = local_res18;
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_c8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_c8;
        local_c8[0] = local_res18;
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_160[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_160;
        local_160[0] = local_res18;
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      local_98[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_98;
        local_98[0] = local_res18;
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      local_res20 = local_res18;
      local_res18 = operator_new(8);
      plVar11 = local_178;
      local_f8[0] = plVar17;
      if (local_res18 != (longlong *)0x0) {
        *local_res18 = (longlong)local_f8;
        local_f8[0] = local_res18;
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      local_1b0 = 0;
      local_1c0 = 0;
      local_1a8 = 0;
      local_50 = (longlong *)0x0;
      local_res20 = local_res18;
      if (local_170 < local_178) {
        _invalid_parameter_noinfo();
      }
      plVar3 = local_190[0];
      local_50 = local_190[0];
      while( true ) {
        plVar13 = local_170;
        local_68 = (longlong *)0x0;
        if (local_170 < local_178) {
          _invalid_parameter_noinfo();
        }
        local_68 = local_190[0];
        if ((plVar3 == (longlong *)0x0) || (plVar3 != local_190[0])) {
          _invalid_parameter_noinfo();
        }
        if ((plVar11 == plVar13) || ((local_194 <= local_1c0 && (local_194 != 0))))
        goto LAB_1404d7455;
        local_1a8 = (int)plVar17 + 1;
        if (10000 < local_1a8) break;
        local_1c8 = (longlong *)0x0;
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        if (*plVar11 != 0) {
          if (plVar3 == (longlong *)0x0) {
            _invalid_parameter_noinfo();
            lVar12 = 0;
          }
          else {
            lVar12 = *plVar3;
          }
          if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
            _invalid_parameter_noinfo();
          }
          cVar5 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_1c8);
          if (cVar5 != '\0') {
            local_130 = (**(code **)(*local_1c8 + 0x40))();
            uStack_12c = (**(code **)(*local_1c8 + 0x48))();
            plVar17 = *(longlong **)(param_1 + 0x60);
            iVar6 = (**(code **)(*local_1c8 + 0x10))();
            iVar9 = (**(code **)(*plVar17 + 8))(plVar17);
            if (iVar6 != iVar9) {
              uVar16 = CONCAT44(uStack_12c,local_130);
              cVar5 = FUN_1401671e0(uVar16,uVar2,local_198);
              if (((cVar5 != '\0') &&
                  (cVar5 = FUN_1401671e0(uVar16,uVar2,(ulonglong)local_1b8 & 0xffffffff),
                  cVar5 == '\0')) &&
                 ((cVar5 = (**(code **)(*local_1c8 + 0x220))(), cVar5 != '\0' &&
                  (cVar5 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_1c8), cVar5 == '\0'))
                 )) {
                local_1c0 = local_1c0 + 1;
                cVar5 = FUN_1403e9290(local_1c8);
                if (cVar5 == '\0') {
                  plVar13 = (longlong *)
                            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                      (*(longlong **)(param_2 + 0x40),1);
                  lVar12 = *local_1c8;
                  plVar17 = *(longlong **)(param_1 + 0x60);
                  uVar8 = (**(code **)(*plVar13 + 0x48))(plVar13);
                  uVar7 = (**(code **)(*plVar17 + 8))(plVar17);
                  cVar5 = (**(code **)(lVar12 + 0x398))(local_1c8,uVar7,uVar8,0);
                  uVar8 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                  if (cVar5 == '\0') {
                    lVar12 = 0;
                    local_res18 = (longlong *)((ulonglong)local_res18 & 0xffffffff00000000);
                    local_res20 = (longlong *)((ulonglong)local_res20 & 0xffffffff00000000);
                    iVar6 = (**(code **)(*local_1c8 + 0x10))();
                    if (iVar6 - 0xaae61U < 99999) {
                      plVar17 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140)
                      ;
                      plVar17 = (longlong *)(**(code **)(*plVar17 + 0x10))(plVar17,0x34);
                      uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar8);
                    }
                    else {
                      plVar17 = (longlong *)
                                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                          (*(longlong **)(param_2 + 0x40),0x1e);
                      iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                      if (iVar6 == 0) {
                        plVar17 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),10);
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                        }
                        lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar14 + 0x100) == 0) {
                          log_InlineLogERROR(&DAT_1406d9c10);
                          uVar16 = 0;
                        }
                        else {
                          uVar16 = *(undefined8 *)(lVar14 + 0x100);
                        }
                        uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                        uVar8 = FUN_1402f3100(uVar16,lVar12,local_1c8,uVar8,&local_res20);
                        local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar8);
                      }
                      else {
                        plVar17 = (longlong *)
                                  (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                            (*(longlong **)(param_2 + 0x40),0x1e);
                        iVar6 = (**(code **)(*plVar17 + 0x48))(plVar17);
                        if (iVar6 == 1) {
                          plVar17 = (longlong *)
                                    (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                              (*(longlong **)(param_2 + 0x40),10);
                          uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                          if (*(longlong *)(param_1 + 0x60) != 0) {
                            lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                          }
                          in_stack_fffffffffffffe18 = in_stack_fffffffffffffe18 & 0xffffffffffffff00
                          ;
                          in_stack_fffffffffffffe08 = in_stack_fffffffffffffe08 & 0xffffffffffffff00
                          ;
                          in_stack_fffffffffffffe00 = in_stack_fffffffffffffe00 & 0xffffffff00000000
                          ;
                          uVar8 = FUN_1403ec0a0(lVar12,local_1c8,0,1,CONCAT44(uVar8,uVar7),
                                                in_stack_fffffffffffffe00,in_stack_fffffffffffffe08,
                                                &local_res20,in_stack_fffffffffffffe18);
                          local_res18 = (longlong *)CONCAT44(local_res18._4_4_,uVar8);
                        }
                      }
                    }
                    pplVar19 = &local_res18;
                    FUN_1404caac0(param_1,param_2,local_1c8,&local_res20,pplVar19);
                    FUN_1401af440(local_128,&local_1c8);
                    FUN_14000f0a0(local_160,&local_res18);
                    local_1ac = 0;
                    plVar17 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x26);
                    uVar8 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    plVar17 = (longlong *)
                              (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                        (*(longlong **)(param_2 + 0x40),0x27);
                    uVar7 = (**(code **)(*plVar17 + 0x48))(plVar17);
                    lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar12 + 0x100) == 0) {
                      pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      uVar16 = 0;
                    }
                    else {
                      uVar16 = *(undefined8 *)(lVar12 + 0x100);
                    }
                    cVar5 = FUN_1402ec490(uVar16,uVar8);
                    uVar21 = (undefined4)((ulonglong)pplVar19 >> 0x20);
                    if (cVar5 != '\0') {
                      if (*(longlong *)(param_1 + 0x60) == 0) {
                        lVar12 = 0;
                      }
                      else {
                        lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
                      }
                      lVar14 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar14 + 0x100) == 0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = *(undefined8 *)(lVar14 + 0x100);
                      }
                      pplVar19 = (longlong **)CONCAT44(uVar21,uVar7);
                      local_1ac = FUN_1402ec380(uVar16,lVar12,local_1c8,uVar8,pplVar19);
                      lVar12 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar12 + 0x100) == 0) {
                        pplVar19 = (longlong **)CONCAT44((int)((ulonglong)pplVar19 >> 0x20),0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        uVar16 = 0;
                      }
                      else {
                        uVar16 = *(undefined8 *)(lVar12 + 0x100);
                      }
                      FUN_1402ecf10(uVar16,&local_res20,uVar8);
                    }
                    FUN_1402751c0(local_98,&local_res20);
                    FUN_14000f0a0(local_f8,&local_1ac);
                  }
                }
                else {
                  FUN_1401af440(local_c8,&local_1c8);
                }
              }
            }
          }
        }
        if (plVar3 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          lVar12 = 0;
        }
        else {
          lVar12 = *plVar3;
        }
        if (*(longlong **)(lVar12 + 0x20) <= plVar11) {
          _invalid_parameter_noinfo();
        }
        plVar11 = plVar11 + 1;
        plVar17 = (longlong *)(ulonglong)local_1a8;
      }
      log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d7455:
      lVar12 = *(longlong *)(param_1 + 0x60);
      uVar8 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x48))();
      uVar7 = (**(code **)(*(longlong *)(lVar12 + 0x10) + 0x40))(lVar12 + 0x10);
      pplVar19 = local_f8;
      pplVar24 = local_98;
      pplVar23 = local_160;
      pplVar22 = local_c8;
      pplVar20 = local_128;
      FUN_1404cc740(param_1,param_2,uVar7,uVar8,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0x10);
      iVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
      plVar11 = (longlong *)
                (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                          (*(longlong **)(param_2 + 0x40),0xd);
      uVar8 = (**(code **)(*plVar11 + 0x48))(plVar11);
      if (iVar6 == 0x5b) {
        FUN_1404ceb90(param_1,local_128,param_2,uVar8);
      }
      local_1b0 = 0;
      while (iVar6 = local_1b0, uVar15 = local_108 - (longlong)local_110 >> 3,
            local_1b0 < (int)uVar15) {
        uVar18 = (ulonglong)local_1b0;
        if (uVar15 <= uVar18) {
          _invalid_parameter_noinfo();
        }
        plVar11 = *(longlong **)((longlong)local_110 + uVar18 * 8);
        if (plVar11 != (longlong *)0x0) {
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          puVar1 = (undefined4 *)((longlong)local_148 + uVar18 * 4);
          if (*(longlong *)(param_1 + 0x60) == 0) {
            lVar12 = 0;
          }
          else {
            lVar12 = *(longlong *)(param_1 + 0x60) + 0x10;
          }
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          pplVar20 = (longlong **)CONCAT71((int7)((ulonglong)pplVar20 >> 8),1);
          uVar8 = (**(code **)(*plVar11 + 0x3b8))(plVar11,lVar12,*puVar1,0,pplVar20);
          *(undefined4 *)((longlong)pvVar4 + uVar18 * 4) = uVar8;
          iVar9 = (**(code **)(*plVar11 + 0x78))(plVar11);
          if ((ulonglong)(local_140 - (longlong)local_148 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          pvVar4 = local_148;
          if ((ulonglong)(local_d8 - (longlong)local_e0 >> 2) <= uVar18) {
            _invalid_parameter_noinfo();
          }
          iVar10 = *(int *)((longlong)local_e0 + uVar18 * 4) +
                   *(int *)((longlong)pvVar4 + uVar18 * 4);
          if (iVar10 < iVar9) {
            iVar9 = iVar10;
          }
          if (0 < iVar9) {
            pplVar20 = (longlong **)0x0;
            (**(code **)(*plVar11 + 0x2e0))(plVar11,0,(longlong)-iVar9,1,0);
            cVar5 = (**(code **)(*plVar11 + 0x220))(plVar11);
            if (cVar5 == '\0') {
              plVar17 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffffffff0000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffffffff0000);
              pplVar20 = (longlong **)((ulonglong)pplVar20 & 0xffffffffffffff00);
              (**(code **)(*plVar17 + 0x3c8))
                        (plVar17,plVar11,5,0,pplVar20,pplVar22,pplVar23,pplVar24);
            }
          }
          local_1b8 = (longlong *)0x0;
          cVar5 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,&local_1b8);
          if ((cVar5 != '\0') && (cVar5 = (**(code **)(local_1b8[2] + 0x220))(), cVar5 != '\0')) {
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0x10);
            iVar9 = (**(code **)(*plVar11 + 0x48))(plVar11);
            plVar11 = (longlong *)
                      (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                                (*(longlong **)(param_2 + 0x40),0xd);
            iVar10 = (**(code **)(*plVar11 + 0x48))(plVar11);
            uVar8 = (undefined4)((ulonglong)pplVar20 >> 0x20);
            if ((local_1b8 != (longlong *)0x0) && (((0 < iVar9 && (0 < iVar10)) && (iVar9 != 0x5b)))
               ) {
              plVar11 = (longlong *)FUN_1401181a0();
              lVar12 = *plVar11;
              uVar7 = (**(code **)(*local_1b8 + 8))();
              pplVar19 = (longlong **)((ulonglong)pplVar19 & 0xffffffffffffff00);
              pplVar24 = (longlong **)((ulonglong)pplVar24 & 0xffffffff00000000);
              pplVar23 = (longlong **)((ulonglong)pplVar23 & 0xffffffff00000000);
              pplVar22 = (longlong **)((ulonglong)pplVar22 & 0xffffffff00000000);
              pplVar20 = (longlong **)CONCAT44(uVar8,iVar10);
              cVar5 = (**(code **)(lVar12 + 8))
                                (plVar11,uVar7,iVar9,0,pplVar20,pplVar22,pplVar23,pplVar24,pplVar19,
                                 0,0);
              if ((cVar5 != '\0') &&
                 (((iVar9 == 0x37 || (iVar9 == 0x38)) || ((iVar9 == 0x18 || (iVar9 == 0x6e)))))) {
                (**(code **)(local_1b8[2] + 0x388))(local_1b8 + 2,0);
              }
            }
          }
        }
        local_1b0 = iVar6 + 1;
      }
      if (local_e0 != (void *)0x0) {
        operator_delete(local_e0);
      }
      local_e0 = (void *)0x0;
      local_d8 = 0;
      local_d0 = 0;
      operator_delete(local_f8[0]);
      if (local_80 != (void *)0x0) {
        operator_delete(local_80);
      }
      local_80 = (void *)0x0;
      local_78 = 0;
      local_70 = 0;
      operator_delete(local_98[0]);
      if (local_148 != (void *)0x0) {
        operator_delete(local_148);
      }
      local_148 = (void *)0x0;
      local_140 = 0;
      local_138 = 0;
      operator_delete(local_160[0]);
      if (local_b0 != (void *)0x0) {
        operator_delete(local_b0);
      }
      local_b0 = (void *)0x0;
      local_a8 = 0;
      local_a0 = 0;
      operator_delete(local_c8[0]);
      if (local_110 != (void *)0x0) {
        operator_delete(local_110);
      }
      local_110 = (void *)0x0;
      local_108 = 0;
      local_100 = 0;
      operator_delete(local_128[0]);
      if (local_178 != (longlong *)0x0) {
        operator_delete(local_178);
      }
      local_178 = (longlong *)0x0;
      local_170 = (longlong *)0x0;
      local_168 = 0;
      operator_delete(local_190[0]);
    }
  }
  return;
}

// ==== CMonster::helper_1404d7940  @1404d7940  [medium:callgraph-r2]  (orig: FUN_1404d7940)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d7940(longlong param_1,longlong param_2,undefined4 *param_3)

{
  longlong lVar1;
  bool bVar2;
  void *pvVar3;
  char cVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  longlong *plVar11;
  ulonglong uVar12;
  undefined8 uVar13;
  undefined8 *puVar14;
  undefined8 uVar15;
  longlong *plVar16;
  longlong lVar17;
  longlong *plVar18;
  int iVar19;
  longlong *plVar20;
  ulonglong uVar21;
  longlong *plVar22;
  undefined1 auStack_708 [32];
  longlong **local_6e8;
  longlong **local_6e0;
  undefined8 local_6d8;
  undefined8 local_6d0;
  longlong **local_6c8;
  undefined2 local_6c0;
  undefined4 local_6b8;
  longlong *local_6a8;
  undefined8 local_6a0;
  longlong *local_698;
  undefined4 local_690;
  undefined4 local_68c;
  longlong *local_688;
  int local_680;
  int local_67c;
  longlong *local_678 [3];
  longlong *local_660;
  longlong *local_658;
  undefined8 local_650;
  longlong local_648;
  uint local_640;
  int local_63c;
  uint local_638;
  ulonglong local_630;
  longlong *local_628;
  uint local_620;
  longlong *local_618 [3];
  void *local_600;
  longlong local_5f8;
  undefined8 local_5f0;
  undefined4 local_5e8;
  undefined4 uStack_5e4;
  longlong *local_5e0 [3];
  void *local_5c8;
  longlong local_5c0;
  undefined8 local_5b8;
  longlong *local_5b0 [3];
  void *local_598;
  longlong local_590;
  undefined8 local_588;
  undefined4 local_580;
  longlong *local_578 [3];
  void *local_560;
  undefined8 local_558;
  undefined8 local_550;
  longlong *local_548 [3];
  void *local_530;
  undefined8 local_528;
  undefined8 local_520;
  longlong *local_518 [3];
  void *local_500;
  undefined8 local_4f8;
  undefined8 local_4f0;
  undefined8 local_4e8;
  longlong *local_4e0;
  longlong *local_4d0;
  longlong *local_4c0;
  longlong *local_4b0;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4e8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_708;
  local_648 = param_2;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x9b3);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (param_2 == 0) {
    local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x9b4);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  if (*(longlong *)(param_2 + 0x40) == 0) {
    local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x9b5);
    log_InlineLogERROR(&DAT_1406d9c10);
    return;
  }
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                      (*(longlong **)(param_2 + 0x40),0xe);
  iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
  local_680 = iVar5 + 2;
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))
                      (*(longlong **)(param_2 + 0x40),0x28);
  uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
  local_688 = (longlong *)CONCAT44(local_688._4_4_,uVar6);
  local_6a0 = operator_new(8);
  if (local_6a0 == (longlong *)0x0) {
    local_678[0] = (longlong *)0x0;
  }
  else {
    *local_6a0 = (longlong)local_678;
    local_678[0] = local_6a0;
  }
  plVar22 = (longlong *)0x0;
  local_660 = (longlong *)0x0;
  local_658 = (longlong *)0x0;
  local_650 = 0;
  local_698 = local_6a0;
  uVar12 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x160))();
  local_630 = uVar12;
  uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
  plVar11 = (longlong *)FUN_1400875f0(uVar13);
  plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,*(undefined4 *)(param_1 + 0x68));
  if (((plVar11 == (longlong *)0x0) ||
      (cVar4 = (**(code **)(*plVar11 + 0x220))(plVar11), cVar4 == '\0')) ||
     (plVar18 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10),
     cVar4 = (**(code **)(*plVar18 + 0x3d8))(plVar18,plVar11,0), cVar4 == '\0')) {
    bVar2 = false;
  }
  else {
    lVar17 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
    uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
    uVar7 = (**(code **)(*plVar11 + 0x40))(plVar11);
    iVar8 = (**(code **)(lVar17 + 0x158))(*(longlong *)(param_1 + 0x60) + 0x10,uVar7,uVar6);
    if (iVar5 + 2 < iVar8) {
      bVar2 = false;
    }
    else {
      lVar17 = *(longlong *)(param_1 + 0x60);
      uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
      uVar7 = (**(code **)(*plVar11 + 0x40))(plVar11);
      uVar9 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x48))(lVar17 + 0x10);
      uVar10 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x40))(lVar17 + 0x10);
      local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,uVar6);
      iVar5 = FUN_1404ca9a0(param_1,uVar10,uVar9,uVar7);
      plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      local_63c = iVar5;
      (**(code **)(*plVar11 + 0x2b8))(plVar11,iVar5);
      FUN_140362560(local_498);
      plVar18 = *(longlong **)(param_1 + 0x60);
      plVar11 = plVar18 + 2;
      uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
      uVar7 = (**(code **)(*plVar11 + 0x40))(plVar11);
      uVar9 = (**(code **)(*plVar18 + 8))(plVar18);
      local_6d0 = (longlong **)((ulonglong)local_6d0._4_4_ << 0x20);
      local_6d8 = (longlong **)((ulonglong)local_6d8._4_4_ << 0x20);
      local_6e0 = (longlong **)CONCAT62(local_6e0._2_6_,0x4f);
      local_6e8 = (longlong **)CONCAT62(local_6e8._2_6_,(short)iVar5);
      iVar5 = FUN_140362620(local_498,uVar9,uVar7,uVar6);
      if (iVar5 != 0) {
        plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        (**(code **)(*plVar11 + 0x348))(plVar11,local_498,1);
      }
      FUN_1403625e0(local_498);
      bVar2 = true;
      uVar12 = local_630;
    }
  }
  local_5e8 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x40))();
  uStack_5e4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
  puVar14 = (undefined8 *)FUN_140388810(*(undefined8 *)(param_1 + 0x60),&local_6a0,3);
  uVar13 = *puVar14;
  if (uVar12 == 0) {
    local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x9db);
    log_InlineLogERROR(&DAT_1406d9c10);
    if (local_660 != (longlong *)0x0) {
      operator_delete(local_660);
    }
    local_660 = (longlong *)0x0;
    local_658 = (longlong *)0x0;
    local_650 = 0;
    operator_delete(local_678[0]);
    return;
  }
  local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x1043);
  uVar15 = CONCAT44(uStack_5e4,local_5e8);
  FUN_1402d2470(uVar12,local_678,uVar15,local_680);
  plVar11 = local_660;
  if (!bVar2) {
    *(undefined4 *)(param_1 + 0x68) = 0;
    local_620 = 0;
    local_4e0 = (longlong *)0x0;
    if (local_658 < local_660) {
      _invalid_parameter_noinfo();
    }
    plVar18 = local_678[0];
    local_4e0 = local_678[0];
    plVar16 = plVar22;
    do {
      plVar20 = local_658;
      local_4b0 = (longlong *)0x0;
      if (local_658 < local_660) {
        _invalid_parameter_noinfo();
      }
      local_4b0 = local_678[0];
      if ((plVar18 == (longlong *)0x0) || (plVar18 != local_678[0])) {
        _invalid_parameter_noinfo();
      }
      if (plVar11 == plVar20) goto LAB_1404d7f17;
      local_620 = (int)plVar16 + 1;
      plVar16 = (longlong *)(ulonglong)local_620;
      if (10000 < local_620) {
        local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x9e5);
        log_InlineLogERROR(&DAT_1406d9c10);
        goto LAB_1404d7f17;
      }
      local_698 = (longlong *)0x0;
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar20 = plVar22;
      }
      else {
        plVar20 = (longlong *)*plVar18;
      }
      if ((longlong *)plVar20[4] <= plVar11) {
        _invalid_parameter_noinfo();
      }
      if (*plVar11 != 0) {
        if (plVar18 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
          plVar20 = plVar22;
        }
        else {
          plVar20 = (longlong *)*plVar18;
        }
        if ((longlong *)plVar20[4] <= plVar11) {
          _invalid_parameter_noinfo();
        }
        cVar4 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_698);
        if (cVar4 != '\0') {
          local_628 = (longlong *)0x0;
          cVar4 = (**(code **)(*local_698 + 0x298))(local_698,0x1001,&local_628);
          if ((cVar4 != '\0') && (cVar4 = (**(code **)(local_628[2] + 0x220))(), cVar4 != '\0'))
          goto code_r0x0001404d7edb;
        }
      }
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar20 = plVar22;
      }
      else {
        plVar20 = (longlong *)*plVar18;
      }
      if ((longlong *)plVar20[4] <= plVar11) {
        _invalid_parameter_noinfo();
      }
      plVar11 = plVar11 + 1;
    } while( true );
  }
LAB_1404d8185:
  local_6a0 = operator_new(8);
  local_5e0[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_5e0;
    local_5e0[0] = local_6a0;
  }
  local_5c8 = (void *)0x0;
  local_5c0 = 0;
  local_5b8 = 0;
  local_698 = local_6a0;
  local_6a0 = operator_new(8);
  local_548[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_548;
    local_548[0] = local_6a0;
  }
  local_530 = (void *)0x0;
  local_528 = 0;
  local_520 = 0;
  local_698 = local_6a0;
  local_6a0 = operator_new(8);
  local_618[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_618;
    local_618[0] = local_6a0;
  }
  local_600 = (void *)0x0;
  local_5f8 = 0;
  local_5f0 = 0;
  local_698 = local_6a0;
  local_6a0 = operator_new(8);
  local_578[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_578;
    local_578[0] = local_6a0;
  }
  local_560 = (void *)0x0;
  local_558 = 0;
  local_550 = 0;
  local_698 = local_6a0;
  local_6a0 = operator_new(8);
  local_5b0[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_5b0;
    local_5b0[0] = local_6a0;
  }
  local_598 = (void *)0x0;
  local_590 = 0;
  local_588 = 0;
  local_698 = local_6a0;
  local_6a0 = operator_new(8);
  plVar11 = local_660;
  local_518[0] = plVar22;
  if (local_6a0 != (longlong *)0x0) {
    *local_6a0 = (longlong)local_518;
    local_518[0] = local_6a0;
  }
  local_500 = (void *)0x0;
  local_4f8 = 0;
  local_4f0 = 0;
  local_640 = 0;
  local_67c = 0;
  local_638 = 0;
  local_698 = local_660;
  local_4c0 = (longlong *)0x0;
  if (local_658 < local_660) {
    _invalid_parameter_noinfo();
  }
  plVar18 = local_678[0];
  local_4c0 = local_678[0];
  plVar16 = plVar22;
  while( true ) {
    plVar20 = local_658;
    local_4d0 = (longlong *)0x0;
    if (local_658 < local_660) {
      _invalid_parameter_noinfo();
    }
    local_4d0 = local_678[0];
    if ((plVar18 == (longlong *)0x0) || (plVar18 != local_678[0])) {
      _invalid_parameter_noinfo();
    }
    if ((plVar11 == plVar20) || (((int)local_688 <= local_67c && ((int)local_688 != 0))))
    goto LAB_1404d89a8;
    local_638 = (int)plVar16 + 1;
    if (10000 < local_638) break;
    local_6a8 = (longlong *)0x0;
    if (plVar18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar16 = plVar22;
    }
    else {
      plVar16 = (longlong *)*plVar18;
    }
    if ((longlong *)plVar16[4] <= plVar11) {
      _invalid_parameter_noinfo();
    }
    if (*plVar11 != 0) {
      if (plVar18 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        plVar16 = plVar22;
      }
      else {
        plVar16 = (longlong *)*plVar18;
      }
      if ((longlong *)plVar16[4] <= plVar11) {
        _invalid_parameter_noinfo();
      }
      cVar4 = (**(code **)(*(longlong *)*plVar11 + 0x40))((longlong *)*plVar11,&local_6a8);
      if (cVar4 != '\0') {
        uVar6 = (**(code **)(*local_6a8 + 0x40))();
        local_6a0 = (longlong *)CONCAT44(local_6a0._4_4_,uVar6);
        uVar6 = (**(code **)(*local_6a8 + 0x48))();
        local_6a0 = (longlong *)CONCAT44(uVar6,(undefined4)local_6a0);
        local_6e8 = (longlong **)param_3;
        cVar4 = FUN_1404ca780(param_1,local_6a0,local_680,uVar13);
        if (cVar4 != '\0') {
          plVar11 = *(longlong **)(param_1 + 0x60);
          iVar5 = (**(code **)(*local_6a8 + 0x10))();
          iVar8 = (**(code **)(*plVar11 + 8))(plVar11);
          if (iVar5 != iVar8) {
            local_63c = (**(code **)(*local_6a8 + 0x10))();
            cVar4 = (**(code **)(*local_6a8 + 0x220))();
            if ((cVar4 != '\0') &&
               (cVar4 = FUN_14038e6a0(*(undefined8 *)(param_1 + 0x60),local_6a8), lVar17 = local_648
               , cVar4 == '\0')) {
              plVar11 = (longlong *)
                        (**(code **)(**(longlong **)(local_648 + 0x40) + 0x10))
                                  (*(longlong **)(local_648 + 0x40),0xe);
              lVar1 = *(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
              uVar15 = (**(code **)(*local_6a8 + 0x2a0))();
              iVar5 = (**(code **)(lVar1 + 0x150))(*(longlong *)(param_1 + 0x60) + 0x10,uVar15);
              iVar8 = (**(code **)(*plVar11 + 0x48))(plVar11);
              if (iVar5 <= iVar8) {
                local_67c = local_67c + 1;
                cVar4 = FUN_1403e9290(local_6a8);
                if (cVar4 == '\0') {
                  plVar16 = (longlong *)
                            (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                      (*(longlong **)(lVar17 + 0x40),1);
                  lVar17 = *local_6a8;
                  plVar11 = *(longlong **)(param_1 + 0x60);
                  uVar6 = (**(code **)(*plVar16 + 0x48))(plVar16);
                  uVar7 = (**(code **)(*plVar11 + 8))(plVar11);
                  cVar4 = (**(code **)(lVar17 + 0x398))(local_6a8,uVar7,uVar6,0);
                  lVar17 = local_648;
                  if (cVar4 == '\0') {
                    local_690 = 0;
                    local_68c = 0;
                    if (local_63c - 0xaae61U < 99999) {
                      plVar11 = (longlong *)**(undefined8 **)(*(longlong *)(param_1 + 0x60) + 0x140)
                      ;
                      plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,0x34);
                      local_690 = (**(code **)(*plVar11 + 0x48))(plVar11);
                      lVar17 = local_648;
                    }
                    else {
                      plVar11 = (longlong *)
                                (**(code **)(**(longlong **)(local_648 + 0x40) + 0x10))
                                          (*(longlong **)(local_648 + 0x40),0x1e);
                      iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
                      if (iVar5 == 0) {
                        plVar16 = (longlong *)
                                  (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                            (*(longlong **)(lVar17 + 0x40),10);
                        plVar11 = plVar22;
                        if (*(longlong *)(param_1 + 0x60) != 0) {
                          plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                        }
                        lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                        if (*(longlong *)(lVar17 + 0x100) == 0) {
                          local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x144);
                          log_InlineLogERROR(&DAT_1406d9c10);
                          plVar20 = plVar22;
                        }
                        else {
                          plVar20 = *(longlong **)(lVar17 + 0x100);
                        }
                        uVar6 = (**(code **)(*plVar16 + 0x48))(plVar16);
                        local_6e8 = (longlong **)&local_68c;
                        local_690 = FUN_1402f3100(plVar20,plVar11,local_6a8,uVar6);
                        lVar17 = local_648;
                      }
                      else {
                        plVar11 = (longlong *)
                                  (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                            (*(longlong **)(lVar17 + 0x40),0x1e);
                        iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
                        if (iVar5 == 1) {
                          plVar11 = (longlong *)
                                    (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                              (*(longlong **)(lVar17 + 0x40),10);
                          uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
                          plVar11 = plVar22;
                          if (*(longlong *)(param_1 + 0x60) != 0) {
                            plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                          }
                          local_6c8 = (longlong **)((ulonglong)local_6c8 & 0xffffffffffffff00);
                          local_6d0 = (longlong **)&local_68c;
                          local_6d8 = (longlong **)((ulonglong)local_6d8 & 0xffffffffffffff00);
                          local_6e0 = (longlong **)((ulonglong)local_6e0 & 0xffffffff00000000);
                          local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,uVar6);
                          local_690 = FUN_1403ec0a0(plVar11,local_6a8,0,1);
                        }
                      }
                    }
                    local_6e8 = (longlong **)&local_690;
                    FUN_1404caac0(param_1,lVar17,local_6a8,&local_68c);
                    FUN_1401af440(local_5e0,&local_6a8);
                    FUN_14000f0a0(local_618,&local_690);
                    local_630 = local_630 & 0xffffffff00000000;
                    plVar11 = (longlong *)
                              (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                        (*(longlong **)(lVar17 + 0x40),0x26);
                    uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
                    plVar11 = (longlong *)
                              (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                                        (*(longlong **)(lVar17 + 0x40),0x27);
                    uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
                    lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    if (*(longlong *)(lVar17 + 0x100) == 0) {
                      local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x144);
                      log_InlineLogERROR(&DAT_1406d9c10);
                      plVar11 = plVar22;
                    }
                    else {
                      plVar11 = *(longlong **)(lVar17 + 0x100);
                    }
                    cVar4 = FUN_1402ec490(plVar11,uVar6);
                    if (cVar4 != '\0') {
                      plVar11 = plVar22;
                      if (*(longlong *)(param_1 + 0x60) != 0) {
                        plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                      }
                      lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar17 + 0x100) == 0) {
                        local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        plVar16 = plVar22;
                      }
                      else {
                        plVar16 = *(longlong **)(lVar17 + 0x100);
                      }
                      local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,uVar7);
                      uVar7 = FUN_1402ec380(plVar16,plVar11,local_6a8,uVar6);
                      local_630 = CONCAT44(local_630._4_4_,uVar7);
                      lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                      if (*(longlong *)(lVar17 + 0x100) == 0) {
                        local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x144);
                        log_InlineLogERROR(&DAT_1406d9c10);
                        plVar11 = plVar22;
                      }
                      else {
                        plVar11 = *(longlong **)(lVar17 + 0x100);
                      }
                      FUN_1402ecf10(plVar11,&local_68c,uVar6);
                    }
                    FUN_1402751c0(local_578,&local_68c);
                    FUN_14000f0a0(local_5b0,&local_630);
                  }
                }
                else {
                  FUN_1401af440(local_548,&local_6a8);
                }
              }
            }
          }
        }
      }
    }
    if (plVar18 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      plVar16 = plVar22;
    }
    else {
      plVar16 = (longlong *)*plVar18;
    }
    plVar11 = local_698;
    if ((longlong *)plVar16[4] <= local_698) {
      _invalid_parameter_noinfo();
    }
    plVar11 = plVar11 + 1;
    plVar16 = (longlong *)(ulonglong)local_638;
    local_698 = plVar11;
  }
  local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0xa1a);
  log_InlineLogERROR(&DAT_1406d9c10);
LAB_1404d89a8:
  lVar17 = *(longlong *)(param_1 + 0x60);
  uVar6 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x48))(lVar17 + 0x10);
  uVar7 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x40))(lVar17 + 0x10);
  lVar17 = local_648;
  local_6c8 = local_5b0;
  local_6d0 = local_578;
  local_6d8 = local_618;
  local_6e0 = local_548;
  local_6e8 = local_5e0;
  FUN_1404cc740(param_1,local_648,uVar7,uVar6);
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))(*(longlong **)(lVar17 + 0x40),0x10)
  ;
  iVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
  plVar11 = (longlong *)
            (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))(*(longlong **)(lVar17 + 0x40),0xd);
  uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
  if (iVar5 == 0x5b) {
    FUN_1404ceb90(param_1,local_5e0,lVar17,uVar6);
  }
  local_640 = 0;
  plVar11 = plVar22;
  while( true ) {
    uVar12 = local_5c0 - (longlong)local_5c8 >> 3;
    iVar5 = (int)plVar11;
    if ((int)uVar12 <= iVar5) break;
    uVar21 = (ulonglong)iVar5;
    if (uVar12 <= uVar21) {
      _invalid_parameter_noinfo();
    }
    plVar11 = *(longlong **)((longlong)local_5c8 + uVar21 * 8);
    if (plVar11 != (longlong *)0x0) {
      if ((ulonglong)(local_5f8 - (longlong)local_600 >> 2) <= uVar21) {
        _invalid_parameter_noinfo();
      }
      local_6a0 = (longlong *)((longlong)local_600 + uVar21 * 4);
      plVar18 = plVar22;
      if (*(longlong *)(param_1 + 0x60) != 0) {
        plVar18 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      }
      if ((ulonglong)(local_5f8 - (longlong)local_600 >> 2) <= uVar21) {
        _invalid_parameter_noinfo();
      }
      pvVar3 = local_600;
      local_6e8 = (longlong **)CONCAT71(local_6e8._1_7_,1);
      uVar6 = (**(code **)(*plVar11 + 0x3b8))(plVar11,plVar18,(int)*local_6a0,0);
      *(undefined4 *)((longlong)pvVar3 + uVar21 * 4) = uVar6;
      if ((ulonglong)(local_5f8 - (longlong)local_600 >> 2) <= uVar21) {
        _invalid_parameter_noinfo();
      }
      pvVar3 = local_600;
      if ((ulonglong)(local_590 - (longlong)local_598 >> 2) <= uVar21) {
        _invalid_parameter_noinfo();
      }
      iVar19 = *(int *)((longlong)local_598 + uVar21 * 4) + *(int *)((longlong)pvVar3 + uVar21 * 4);
      iVar8 = (**(code **)(*plVar11 + 0x78))(plVar11);
      if (iVar19 < iVar8) {
        iVar8 = iVar19;
      }
      if (0 < iVar8) {
        local_6e8 = (longlong **)0x0;
        (**(code **)(*plVar11 + 0x2e0))(plVar11,0,(longlong)-iVar8);
        cVar4 = (**(code **)(*plVar11 + 0x220))(plVar11);
        if (cVar4 == '\0') {
          plVar18 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
          local_6d0 = (longlong **)((ulonglong)local_6d0 & 0xffffffff00000000);
          local_6d8 = (longlong **)((ulonglong)local_6d8 & 0xffffffffffff0000);
          local_6e0 = (longlong **)((ulonglong)local_6e0 & 0xffffffffffff0000);
          local_6e8 = (longlong **)((ulonglong)local_6e8 & 0xffffffffffffff00);
          (**(code **)(*plVar18 + 0x3c8))(plVar18,plVar11,5);
        }
      }
      local_688 = (longlong *)0x0;
      cVar4 = (**(code **)(*plVar11 + 0x298))(plVar11,0x1001,&local_688);
      if ((cVar4 != '\0') &&
         (cVar4 = (**(code **)(local_688[2] + 0x220))(), lVar17 = local_648, cVar4 != '\0')) {
        plVar11 = (longlong *)
                  (**(code **)(**(longlong **)(local_648 + 0x40) + 0x10))
                            (*(longlong **)(local_648 + 0x40),0x10);
        iVar8 = (**(code **)(*plVar11 + 0x48))(plVar11);
        plVar11 = (longlong *)
                  (**(code **)(**(longlong **)(lVar17 + 0x40) + 0x10))
                            (*(longlong **)(lVar17 + 0x40),0xd);
        iVar19 = (**(code **)(*plVar11 + 0x48))(plVar11);
        if ((local_688 != (longlong *)0x0) && (((0 < iVar8 && (0 < iVar19)) && (iVar8 != 0x5b)))) {
          plVar11 = (longlong *)FUN_1401181a0();
          lVar17 = *plVar11;
          uVar6 = (**(code **)(*local_688 + 8))();
          local_6b8 = 0;
          local_6c0 = 0;
          local_6c8 = (longlong **)((ulonglong)local_6c8 & 0xffffffffffffff00);
          local_6d0 = (longlong **)((ulonglong)local_6d0 & 0xffffffff00000000);
          local_6d8 = (longlong **)((ulonglong)local_6d8 & 0xffffffff00000000);
          local_6e0 = (longlong **)((ulonglong)local_6e0 & 0xffffffff00000000);
          local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,iVar19);
          cVar4 = (**(code **)(lVar17 + 8))(plVar11,uVar6,iVar8);
          if ((cVar4 != '\0') &&
             (((iVar8 == 0x37 || (iVar8 == 0x38)) || ((iVar8 == 0x18 || (iVar8 == 0x6e)))))) {
            (**(code **)(local_688[2] + 0x388))(local_688 + 2,0);
          }
        }
      }
    }
    local_640 = iVar5 + 1;
    plVar11 = (longlong *)(ulonglong)local_640;
  }
  if (local_500 != (void *)0x0) {
    operator_delete(local_500);
  }
  local_500 = (void *)0x0;
  local_4f8 = 0;
  local_4f0 = 0;
  operator_delete(local_518[0]);
  if (local_598 != (void *)0x0) {
    operator_delete(local_598);
  }
  local_598 = (void *)0x0;
  local_590 = 0;
  local_588 = 0;
  operator_delete(local_5b0[0]);
  if (local_560 != (void *)0x0) {
    operator_delete(local_560);
  }
  local_560 = (void *)0x0;
  local_558 = 0;
  local_550 = 0;
  operator_delete(local_578[0]);
  if (local_600 != (void *)0x0) {
    operator_delete(local_600);
  }
  local_600 = (void *)0x0;
  local_5f8 = 0;
  local_5f0 = 0;
  operator_delete(local_618[0]);
  if (local_530 != (void *)0x0) {
    operator_delete(local_530);
  }
  local_530 = (void *)0x0;
  local_528 = 0;
  local_520 = 0;
  operator_delete(local_548[0]);
  if (local_5c8 != (void *)0x0) {
    operator_delete(local_5c8);
  }
  local_5c8 = (void *)0x0;
  local_5c0 = 0;
  local_5b8 = 0;
  operator_delete(local_5e0[0]);
  if (local_660 != (longlong *)0x0) {
    operator_delete(local_660);
  }
  local_660 = (longlong *)0x0;
  local_658 = (longlong *)0x0;
  local_650 = 0;
  operator_delete(local_678[0]);
  return;
code_r0x0001404d7edb:
  uVar6 = (**(code **)(*local_628 + 8))();
  *(undefined4 *)(param_1 + 0x68) = uVar6;
LAB_1404d7f17:
  FUN_1402cdce0(local_678);
  if (*(int *)(param_1 + 0x68) == 0) {
    if (local_660 != (longlong *)0x0) {
      operator_delete(local_660);
    }
    local_660 = (longlong *)0x0;
    local_658 = (longlong *)0x0;
    local_650 = 0;
    operator_delete(local_678[0]);
    return;
  }
  uVar13 = FUN_140008520(*(undefined4 *)(param_1 + 0x58));
  plVar11 = (longlong *)FUN_1400875f0(uVar13);
  plVar11 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,*(undefined4 *)(param_1 + 0x68));
  if (plVar11 == (longlong *)0x0) {
    if (local_660 != (longlong *)0x0) {
      operator_delete(local_660);
    }
    local_660 = (longlong *)0x0;
    local_658 = (longlong *)0x0;
    local_650 = 0;
    operator_delete(local_678[0]);
    return;
  }
  lVar17 = *(longlong *)(param_1 + 0x60);
  uVar6 = (**(code **)(*plVar11 + 0x48))(plVar11);
  uVar7 = (**(code **)(*plVar11 + 0x40))(plVar11);
  uVar9 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x48))(lVar17 + 0x10);
  uVar10 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x40))(lVar17 + 0x10);
  local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,uVar6);
  uVar6 = FUN_1404ca9a0(param_1,uVar10,uVar9,uVar7);
  plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
  local_580 = uVar6;
  (**(code **)(*plVar11 + 0x2b8))(plVar11,uVar6);
  FUN_140362560(local_498);
  plVar18 = *(longlong **)(param_1 + 0x60);
  plVar11 = plVar18 + 2;
  uVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
  uVar9 = (**(code **)(*plVar11 + 0x40))(plVar11);
  uVar10 = (**(code **)(*plVar18 + 8))(plVar18);
  local_6d0 = (longlong **)((ulonglong)local_6d0 & 0xffffffff00000000);
  local_6d8 = (longlong **)((ulonglong)local_6d8 & 0xffffffff00000000);
  local_6e0 = (longlong **)CONCAT62(local_6e0._2_6_,0x4f);
  local_6e8 = (longlong **)CONCAT62(local_6e8._2_6_,(short)uVar6);
  iVar5 = FUN_140362620(local_498,uVar10,uVar9,uVar7);
  if (iVar5 != 0) {
    plVar11 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
    (**(code **)(*plVar11 + 0x348))(plVar11,local_498,1);
  }
  puVar14 = (undefined8 *)FUN_140388810(*(undefined8 *)(param_1 + 0x60),&local_6a0,3);
  uVar13 = *puVar14;
  if (local_630 == 0) {
    local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0xa04);
    log_InlineLogERROR(&DAT_1406d9c10);
    FUN_1403625e0(local_498);
    if (local_660 != (longlong *)0x0) {
      operator_delete(local_660);
    }
    local_660 = (longlong *)0x0;
    local_658 = (longlong *)0x0;
    local_650 = 0;
    operator_delete(local_678[0]);
    return;
  }
  local_6e8 = (longlong **)CONCAT44(local_6e8._4_4_,0x1043);
  FUN_1402d2470(local_630,local_678,uVar15,local_680);
  FUN_1403625e0(local_498);
  goto LAB_1404d8185;
}

// ==== CMonster::helper_1404d8f10  @1404d8f10  [medium:callgraph-r1]  (orig: FUN_1404d8f10)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d8f10(longlong param_1,longlong param_2,undefined4 param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  longlong *plVar6;
  undefined1 auStack_4e8 [32];
  undefined4 local_4c8;
  undefined2 local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  int local_4a8;
  undefined8 local_4a0;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a0 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  if (param_2 == 0) {
    local_4c8 = 0x2fa;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_2 + 0x40) == 0) {
    local_4c8 = 0x2fb;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else if (*(longlong *)(param_1 + 0x60) == 0) {
    local_4c8 = 0x2fc;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar6 = (longlong *)
             (**(code **)(**(longlong **)(param_2 + 0x40) + 0x10))(*(longlong **)(param_2 + 0x40),2)
    ;
    uVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
    switch(uVar1) {
    case 1:
      FUN_1404cf580(param_1,param_2,param_3);
      break;
    default:
      log_InlineLogERROR("magic sort error!");
      break;
    case 4:
      FUN_1404d0f60(param_1,param_2,1,DAT_14078f358);
      break;
    case 0x21:
      FUN_1404d0f60(param_1,param_2,0,DAT_14078f358);
      break;
    case 0x22:
      FUN_1404d3930(param_1,param_2);
      break;
    case 0x23:
      FUN_1404d47e0(param_1,param_2);
      break;
    case 0x24:
      FUN_1404d6a50(param_1,param_2);
      break;
    case 0x29:
      FUN_1404d5770(param_1,param_2);
      break;
    case 0x2a:
      FUN_1404d2940(param_1,param_2);
      break;
    case 0x2b:
      FUN_1404d00b0(param_1,param_2);
      break;
    case 0x2c:
      iVar2 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x50))();
      local_4a8 = iVar2;
      FUN_140362560(local_498);
      plVar6 = *(longlong **)(param_1 + 0x60);
      uVar1 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x48))();
      uVar3 = (**(code **)(plVar6[2] + 0x40))(plVar6 + 2);
      uVar4 = (**(code **)(*plVar6 + 8))(plVar6);
      local_4b0 = 0;
      local_4b8 = 0;
      local_4c0 = 0x4f;
      local_4c8 = CONCAT22(local_4c8._2_2_,(short)iVar2);
      iVar5 = FUN_140362620(local_498,uVar4,uVar3,uVar1);
      if (iVar5 != 0) {
        plVar6 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
        (**(code **)(*plVar6 + 0x348))(plVar6,local_498,1);
      }
      FUN_1404d0f60(param_1,param_2,1,DAT_14078f350);
      local_4a8 = iVar2 + 1;
      plVar6 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      (**(code **)(*plVar6 + 0x2b8))(plVar6,local_4a8);
      FUN_1403625e0(local_498);
      break;
    case 0x2d:
      FUN_1404d7940(param_1,param_2,DAT_14078f350);
    }
  }
  return;
}

// ==== CMonster::helper_1404d9250  @1404d9250  [medium:callgraph-r1]  (orig: FUN_1404d9250)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d9250(longlong param_1,undefined4 param_2)

{
  longlong lVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  longlong *plVar7;
  undefined1 auStack_4b8 [32];
  undefined4 local_498;
  undefined8 local_488;
  undefined1 local_478 [1104];
  ulonglong local_28;
  
  local_488 = 0xfffffffffffffffe;
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_4b8;
  if (*(longlong *)(param_1 + 0x40) == 0) {
    local_498 = 0xb16;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    FUN_140362560(local_478);
    uVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
    cVar2 = FUN_140362910(local_478,0x195,uVar3,1);
    if (cVar2 != '\0') {
      plVar7 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x58));
      lVar1 = *plVar7;
      uVar3 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
      (**(code **)(lVar1 + 0x30))(plVar7,uVar3,local_478);
    }
    plVar7 = *(longlong **)(*(longlong *)(param_1 + 0x40) + 0x40);
    plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,2);
    iVar4 = (**(code **)(*plVar7 + 0x48))(plVar7);
    if (iVar4 == 2) {
      plVar7 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
      uVar5 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x78))();
      uVar6 = (**(code **)(*plVar7 + 0x80))(plVar7);
      if (uVar5 < uVar6) {
        FUN_1404cba00(param_1,*(undefined8 *)(param_1 + 0x40));
      }
    }
    else {
      FUN_1404d8f10(param_1,*(undefined8 *)(param_1 + 0x40),param_2);
    }
    FUN_1403625e0(local_478);
  }
  return;
}

// ==== CMonster::helper_1404d93a0  @1404d93a0  [medium:callgraph-r0]  (orig: FUN_1404d93a0)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1404d93a0(longlong param_1,int param_2)

{
  longlong lVar1;
  undefined2 *puVar2;
  int *piVar3;
  char cVar4;
  undefined2 uVar5;
  undefined2 uVar6;
  ulong uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  longlong *plVar13;
  ulonglong uVar14;
  longlong *plVar15;
  undefined8 *puVar16;
  undefined8 *puVar17;
  undefined8 *puVar18;
  ulonglong *puVar19;
  ulonglong uVar20;
  undefined1 auStack_1628 [32];
  undefined4 local_1608;
  undefined2 local_1600;
  undefined2 local_15f8;
  undefined2 local_15f0;
  undefined4 local_15e8;
  undefined4 local_15e0;
  uint local_15d8;
  undefined8 *local_15c8;
  int local_15c0;
  undefined4 local_15bc;
  undefined8 *local_15b8;
  ulonglong *local_15b0;
  ulonglong *local_15a0;
  undefined8 local_1590;
  undefined1 local_1588 [1072];
  undefined1 local_1158 [1104];
  undefined1 local_d08 [1104];
  undefined1 local_8b8 [1072];
  undefined1 local_488 [1104];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1404d93b4;
  local_1590 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_1628;
  local_15c0 = param_2;
  if (*(longlong *)(param_1 + 0x60) == 0) {
    local_1608 = 0x90;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    cVar4 = (**(code **)(*(longlong *)(*(longlong *)(param_1 + 0x60) + 0x10) + 0x220))();
    if (cVar4 == '\0') {
      *(undefined4 *)(param_1 + 0x38) = 0;
    }
    else {
      if (*(int *)(param_1 + 0x4c) != 0) {
        uVar7 = tq::TimeGet(0);
        if ((uVar7 < (uint)(*(int *)(param_1 + 0x4c) + *(int *)(param_1 + 0x48))) &&
           (cVar4 = FUN_1404caa40(param_1), cVar4 == '\0')) {
          lVar1 = *(longlong *)(param_1 + 0x40);
          uVar7 = tq::TimeGet(0);
          if (uVar7 < (uint)(*(int *)(lVar1 + 0x34) + *(int *)(lVar1 + 0x30))) {
            return;
          }
          uVar7 = tq::TimeGet(0);
          *(ulong *)(lVar1 + 0x34) = uVar7;
          FUN_1404d9250(param_1,param_2);
          return;
        }
        FUN_14035f2f0(local_1588);
        puVar2 = *(undefined2 **)(param_1 + 0x40);
        uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
        local_15e0 = 0;
        local_15e8 = 0;
        local_15f0 = 0;
        local_15f8 = *puVar2;
        local_1600 = 0;
        local_1608 = (uint)local_1608._2_2_ << 0x10;
        iVar9 = FUN_14035f4c0(local_1588,0x36,uVar8,0);
        if (iVar9 != 0) {
          plVar15 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
          (**(code **)(*plVar15 + 0x348))(plVar15,local_1588,1);
        }
        lVar1 = *(longlong *)(param_1 + 0x40);
        if (lVar1 == 0) {
          local_1608 = 0xac;
          log_InlineLogERROR(&DAT_1406d9c10);
          FUN_14035f340(local_1588);
          return;
        }
        *(undefined4 *)(lVar1 + 0x34) = 0;
        *(undefined4 *)(lVar1 + 0x30) = 0;
        lVar1 = *(longlong *)(param_1 + 0x40);
        *(undefined4 *)(lVar1 + 0x18) = *(undefined4 *)(lVar1 + 0xc);
        uVar7 = tq::TimeGet(0);
        *(ulong *)(lVar1 + 0x1c) = uVar7;
        *(undefined4 *)(*(longlong *)(param_1 + 0x40) + 0x38) = 3;
        *(undefined8 *)(param_1 + 0x40) = 0;
        *(undefined4 *)(param_1 + 0x4c) = 0;
        *(undefined4 *)(param_1 + 0x48) = 0;
        *(undefined4 *)(param_1 + 0x38) = 0;
        FUN_14009ce90(param_1 + 0x70);
        *(undefined4 *)(param_1 + 0x68) = 0;
        FUN_14035f340(local_1588);
      }
      uVar20 = 0;
      puVar16 = *(undefined8 **)(param_1 + 0x20);
      local_15b0 = (ulonglong *)0x0;
      local_15c8 = puVar16;
      if (*(undefined8 **)(param_1 + 0x28) < puVar16) {
        _invalid_parameter_noinfo();
      }
      puVar19 = *(ulonglong **)(param_1 + 8);
      puVar17 = *(undefined8 **)(param_1 + 0x28);
      local_15a0 = (ulonglong *)0x0;
      local_15b8 = puVar17;
      local_15b0 = puVar19;
      if (puVar17 < *(undefined8 **)(param_1 + 0x20)) {
        _invalid_parameter_noinfo();
      }
      local_15a0 = *(ulonglong **)(param_1 + 8);
      local_15d8 = 0;
      uVar14 = uVar20;
      while( true ) {
        if ((puVar19 == (ulonglong *)0x0) || (uVar11 = (uint)uVar14, puVar19 != local_15a0)) {
          _invalid_parameter_noinfo();
          uVar11 = local_15d8;
        }
        if (puVar16 == puVar17) {
          return;
        }
        if (*(longlong *)(param_1 + 0x40) != 0) {
          return;
        }
        local_15d8 = uVar11 + 1;
        if (0x14 < local_15d8) break;
        if (puVar19 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar14 = uVar20;
        }
        else {
          uVar14 = *puVar19;
        }
        if (*(undefined8 **)(uVar14 + 0x20) <= puVar16) {
          _invalid_parameter_noinfo();
        }
        piVar3 = (int *)*puVar16;
        puVar18 = puVar17;
        iVar9 = param_2;
        if (((piVar3 != (int *)0x0) && (*(longlong *)(piVar3 + 0x10) != 0)) &&
           ((*(int *)(param_1 + 0x38) == 0 || (*(int *)(param_1 + 0x38) == *piVar3)))) {
          iVar10 = piVar3[0xe];
          if (iVar10 == 0) {
            plVar15 = (longlong *)
                      (**(code **)(**(longlong **)(piVar3 + 0x10) + 0x10))
                                (*(longlong **)(piVar3 + 0x10),2);
            iVar10 = (**(code **)(*plVar15 + 0x48))(plVar15);
            if (iVar10 == 2) {
              lVar1 = *(longlong *)(param_1 + 0x60);
              uVar11 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
              uVar12 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
              puVar16 = local_15c8;
              puVar18 = local_15b8;
              if (uVar11 <= uVar12) goto LAB_1404d9d18;
            }
            puVar16 = local_15c8;
            puVar18 = local_15b8;
            iVar9 = local_15c0;
            if (param_2 != 0) {
              piVar3[6] = piVar3[3];
              uVar7 = tq::TimeGet(0);
              piVar3[7] = uVar7;
              piVar3[0xe] = 3;
              puVar16 = local_15c8;
              puVar18 = local_15b8;
              iVar9 = local_15c0;
            }
          }
          else if (iVar10 == 1) {
            uVar7 = tq::TimeGet(0);
            puVar16 = local_15c8;
            puVar18 = local_15b8;
            iVar9 = local_15c0;
            if ((uint)(piVar3[9] + piVar3[8]) <= uVar7) {
              plVar15 = (longlong *)
                        (**(code **)(**(longlong **)(piVar3 + 0x10) + 0x10))
                                  (*(longlong **)(piVar3 + 0x10),2);
              iVar9 = (**(code **)(*plVar15 + 0x48))(plVar15);
              if (iVar9 == 2) {
                lVar1 = *(longlong *)(param_1 + 0x60);
                uVar11 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
                uVar12 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
                if (uVar12 < uVar11) {
                  FUN_14035f2f0(local_8b8);
                  plVar15 = *(longlong **)(param_1 + 0x60);
                  uVar5 = (**(code **)(plVar15[2] + 0x48))(plVar15 + 2);
                  uVar6 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
                  (**(code **)(*plVar15 + 8))(plVar15);
                  uVar8 = (**(code **)(*plVar15 + 8))(plVar15);
                  local_15e0 = 0;
                  local_15e8 = 0;
                  local_15f0 = 0;
                  local_15f8 = (undefined2)*piVar3;
                  local_1608 = CONCAT22(local_1608._2_2_,uVar6);
                  local_1600 = uVar5;
                  iVar9 = FUN_14035f4c0(local_8b8,0x18,uVar8);
                  if (iVar9 != 0) {
                    plVar15 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                    (**(code **)(*plVar15 + 0x348))(plVar15,local_8b8,1);
                  }
                  piVar3[10] = piVar3[5];
                  uVar7 = tq::TimeGet(0);
                  piVar3[0xb] = uVar7;
                  piVar3[0xe] = 2;
                  *(int *)(param_1 + 0x38) = *piVar3;
                  FUN_140362560(local_d08);
                  uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                  cVar4 = FUN_140362910(local_d08,0x195,uVar8,0);
                  if (cVar4 != '\0') {
                    plVar15 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                    lVar1 = *plVar15;
                    uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                    (**(code **)(lVar1 + 0x30))(plVar15,uVar8,local_d08);
                  }
                  FUN_1403625e0(local_d08);
                  FUN_14035f340(local_8b8);
                  puVar19 = local_15b0;
                }
                else {
                  piVar3[0xe] = 0;
                }
              }
              else {
                FUN_1404cb590(param_1,piVar3,param_2);
                piVar3[10] = piVar3[5];
                uVar7 = tq::TimeGet(0);
                piVar3[0xb] = uVar7;
                piVar3[0xe] = 2;
                *(int *)(param_1 + 0x38) = *piVar3;
                FUN_140362560(local_488);
                uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                cVar4 = FUN_140362910(local_488,0x195,uVar8,0);
                if (cVar4 != '\0') {
                  plVar15 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                  lVar1 = *plVar15;
                  uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                  (**(code **)(lVar1 + 0x30))(plVar15,uVar8,local_488);
                }
                FUN_1403625e0(local_488);
              }
              piVar3[9] = 0;
              piVar3[8] = 0;
              puVar16 = local_15c8;
              puVar18 = local_15b8;
              iVar9 = local_15c0;
            }
          }
          else if (iVar10 == 2) {
            uVar7 = tq::TimeGet(0);
            puVar16 = local_15c8;
            puVar18 = local_15b8;
            iVar9 = local_15c0;
            if (((uint)(piVar3[0xb] + piVar3[10]) <= uVar7) &&
               (plVar15 = *(longlong **)(piVar3 + 0x10), puVar18 = puVar17, iVar9 = param_2,
               plVar15 != (longlong *)0x0)) {
              plVar13 = (longlong *)(**(code **)(*plVar15 + 8))(plVar15,0x2d);
              iVar9 = (**(code **)(*plVar13 + 0x48))(plVar13);
              if (iVar9 < 1) {
                *(undefined4 *)(param_1 + 0x38) = 0;
              }
              else if (*(int *)(param_1 + 0x4c) == 0) {
                *(int **)(param_1 + 0x40) = piVar3;
                FUN_1404ca9d0(param_1);
                *(int *)(param_1 + 0x48) = iVar9;
                uVar7 = tq::TimeGet(0);
                *(ulong *)(param_1 + 0x4c) = uVar7;
                plVar15 = (longlong *)(**(code **)(*plVar15 + 8))(plVar15,0x2e);
                iVar9 = (**(code **)(*plVar15 + 0x48))(plVar15);
                piVar3[0xc] = iVar9;
                uVar7 = tq::TimeGet(0);
                piVar3[0xd] = uVar7;
                *(int *)(param_1 + 0x68) = param_2;
              }
              FUN_140362560(local_1158);
              uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
              cVar4 = FUN_140362910(local_1158,0x195,uVar8,1);
              if (cVar4 != '\0') {
                plVar15 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x58));
                lVar1 = *plVar15;
                uVar8 = (**(code **)(**(longlong **)(param_1 + 0x60) + 8))();
                (**(code **)(lVar1 + 0x30))(plVar15,uVar8,local_1158);
              }
              iVar9 = 3;
              local_15bc = 3;
              plVar15 = (longlong *)
                        (**(code **)(**(longlong **)(piVar3 + 0x10) + 0x10))
                                  (*(longlong **)(piVar3 + 0x10),2);
              iVar10 = (**(code **)(*plVar15 + 0x48))(plVar15);
              if (iVar10 == 2) {
                lVar1 = *(longlong *)(param_1 + 0x60);
                uVar11 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
                uVar12 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
                if (uVar12 < uVar11) {
                  FUN_1404cba00(param_1,piVar3);
                }
                else {
                  local_15bc = 0;
                  iVar9 = 0;
                }
              }
              else {
                FUN_1404d8f10(param_1,piVar3,local_15c0);
              }
              if ((*(int *)(param_1 + 0x4c) == 0) && (piVar3[0xe] = iVar9, iVar9 == 3)) {
                piVar3[6] = piVar3[3];
                uVar7 = tq::TimeGet(0);
                piVar3[7] = uVar7;
              }
              piVar3[0xb] = 0;
              piVar3[10] = 0;
              FUN_1403625e0(local_1158);
              puVar16 = local_15c8;
              puVar18 = local_15b8;
              iVar9 = local_15c0;
            }
          }
          else {
            puVar16 = local_15c8;
            puVar18 = local_15b8;
            iVar9 = local_15c0;
            if ((iVar10 == 3) &&
               (uVar7 = tq::TimeGet(0), puVar16 = local_15c8, puVar18 = local_15b8,
               iVar9 = local_15c0, (uint)(piVar3[7] + piVar3[6]) <= uVar7)) {
              plVar15 = (longlong *)
                        (**(code **)(**(longlong **)(piVar3 + 0x10) + 0x10))
                                  (*(longlong **)(piVar3 + 0x10),0xc);
              iVar9 = (**(code **)(*plVar15 + 0x48))(plVar15);
              iVar10 = tq::RandGet(100);
              if (iVar10 < iVar9) {
                plVar15 = (longlong *)
                          (**(code **)(**(longlong **)(piVar3 + 0x10) + 0x10))
                                    (*(longlong **)(piVar3 + 0x10),2);
                iVar9 = (**(code **)(*plVar15 + 0x48))(plVar15);
                if (iVar9 == 2) {
                  lVar1 = *(longlong *)(param_1 + 0x60);
                  uVar11 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x80))(lVar1 + 0x10);
                  uVar12 = (**(code **)(*(longlong *)(lVar1 + 0x10) + 0x78))(lVar1 + 0x10);
                  if (uVar12 < uVar11) {
                    FUN_14035f2f0(local_1588);
                    plVar15 = *(longlong **)(param_1 + 0x60);
                    uVar5 = (**(code **)(plVar15[2] + 0x48))(plVar15 + 2);
                    uVar6 = (**(code **)(plVar15[2] + 0x40))(plVar15 + 2);
                    (**(code **)(*plVar15 + 8))(plVar15);
                    uVar8 = (**(code **)(*plVar15 + 8))(plVar15);
                    local_15e0 = 0;
                    local_15e8 = 0;
                    local_15f0 = 0;
                    local_15f8 = (undefined2)*piVar3;
                    local_1608 = CONCAT22(local_1608._2_2_,uVar6);
                    local_1600 = uVar5;
                    iVar9 = FUN_14035f4c0(local_1588,0x34,uVar8);
                    if (iVar9 != 0) {
                      plVar15 = (longlong *)(*(longlong *)(param_1 + 0x60) + 0x10);
                      (**(code **)(*plVar15 + 0x348))(plVar15,local_1588,1);
                    }
                    piVar3[0xe] = 1;
                    piVar3[8] = piVar3[4];
                    uVar7 = tq::TimeGet(0);
                    piVar3[9] = uVar7;
                    FUN_14035f340(local_1588);
                    puVar19 = local_15b0;
                  }
                  else {
                    piVar3[0xe] = 0;
                  }
                }
                else if (param_2 == 0) {
                  piVar3[0xe] = 0;
                }
                else {
                  cVar4 = FUN_1404cf500(param_1,piVar3,param_2);
                  if (cVar4 == '\0') {
                    piVar3[0xe] = 0;
                  }
                  else {
                    piVar3[0xe] = 1;
                    piVar3[8] = piVar3[4];
                    uVar7 = tq::TimeGet(0);
                    piVar3[9] = uVar7;
                  }
                }
                piVar3[7] = 0;
                piVar3[6] = 0;
                puVar16 = local_15c8;
                puVar18 = local_15b8;
                iVar9 = local_15c0;
              }
              else {
                piVar3[0xe] = 0;
                puVar16 = local_15c8;
                puVar18 = puVar17;
                iVar9 = param_2;
              }
            }
          }
        }
LAB_1404d9d18:
        param_2 = iVar9;
        if (puVar19 == (ulonglong *)0x0) {
          _invalid_parameter_noinfo();
          uVar14 = uVar20;
        }
        else {
          uVar14 = *puVar19;
        }
        if (*(undefined8 **)(uVar14 + 0x20) <= puVar16) {
          _invalid_parameter_noinfo();
        }
        puVar16 = puVar16 + 1;
        uVar14 = (ulonglong)local_15d8;
        puVar17 = puVar18;
        local_15c8 = puVar16;
      }
      local_1608 = 0xc0;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
  }
  return;
}

