// ==== CMsgActivityReward::helper_14025f960  @14025f960  [medium:callgraph-r0]  (orig: FUN_14025f960)
undefined8 FUN_14025f960(longlong param_1,longlong *param_2,byte param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  undefined4 uVar9;
  longlong *plVar10;
  longlong *plVar11;
  IStringManager *pIVar12;
  undefined8 uVar13;
  longlong lVar14;
  int local_58;
  int local_4c;
  
  uVar13 = 0;
  if (param_2 != (longlong *)0x0) {
    if (*(longlong *)(param_1 + 0x10) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
      uVar13 = 0;
    }
    else {
      iVar3 = FUN_140384af0(param_2,2,1);
      iVar4 = FUN_140384af0(param_2,2,2);
      if (iVar4 + 1U == (uint)param_3) {
        uVar5 = (**(code **)(*param_2 + 0x108))(param_2);
        if (uVar5 < 3) {
          uVar9 = (**(code **)(*param_2 + 0x108))(param_2);
        }
        else {
          uVar9 = 2;
        }
        plVar10 = (longlong *)FUN_140424e60(*(undefined8 *)(param_1 + 0x10),uVar9,param_3);
        if (plVar10 == (longlong *)0x0) {
          log_InlineLogDBERROR
                    (
                    "table:cq_activity_reward_type, can not find metempsychosis[%d] reward_grade[%d] data."
                    );
          uVar13 = 0;
        }
        else {
          plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,3);
          iVar4 = (**(code **)(*plVar11 + 0x48))(plVar11);
          if (iVar3 < iVar4) {
            uVar13 = 0;
          }
          else {
            iVar4 = 0;
            for (iVar3 = 0; iVar3 < 3; iVar3 = iVar3 + 1) {
              iVar8 = iVar3 * 3;
              plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar8 + 4);
              iVar6 = (**(code **)(*plVar11 + 0x40))(plVar11);
              plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar8 + 5);
              iVar7 = (**(code **)(*plVar11 + 0x48))(plVar11);
              plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar8 + 6);
              uVar2 = (**(code **)(*plVar11 + 0x48))(plVar11);
              if ((iVar6 != 0) && (0 < iVar7)) {
                iVar8 = FUN_140339ba0(param_2,iVar6,iVar7,uVar2);
                iVar4 = iVar4 + iVar8;
              }
            }
            if ((iVar4 < 1) ||
               ((ulonglong)((param_2[0x185] - param_2[0x184] >> 2) + (longlong)iVar4) < 0x29)) {
              FUN_140384c50(param_2,2,2,param_3,1,1);
              for (local_58 = 0; local_58 < 3; local_58 = local_58 + 1) {
                iVar3 = local_58 * 3;
                plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar3 + 4);
                iVar4 = (**(code **)(*plVar11 + 0x40))(plVar11);
                plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar3 + 5);
                iVar8 = (**(code **)(*plVar11 + 0x48))(plVar11);
                plVar11 = (longlong *)(**(code **)(*plVar10 + 0x10))(plVar10,iVar3 + 6);
                uVar2 = (**(code **)(*plVar11 + 0x48))(plVar11);
                if ((iVar4 != 0) && (0 < iVar8)) {
                  cVar1 = FUN_140102780(iVar4);
                  if (cVar1 == '\0') {
                    for (local_4c = 0; plVar11 = DAT_140975b60, local_4c < iVar8;
                        local_4c = local_4c + 1) {
                      if (DAT_140975b60 == (longlong *)0x0) {
                        log_InlineLogERROR(&DAT_1406d9c10);
                      }
                      lVar14 = *plVar11;
                      uVar9 = FUN_14034a8d0(param_2,iVar4,uVar2,1,1,0,1);
                      lVar14 = (**(code **)(lVar14 + 0x60))(plVar11,uVar9);
                      if (lVar14 == 0) {
                        (**(code **)(*param_2 + 8))(param_2);
                        log_InlineLogERROR(
                                          "CActivityMgr::OnGetActivityReward, AwardItem user_id[%u] item_type[%u] amount[%d], monoply[%d] error."
                                          );
                      }
                      else {
                        FUN_14032daf0(param_2,lVar14);
                      }
                    }
                  }
                  else {
                    iVar3 = FUN_14033f6b0(param_2,iVar4,iVar8,uVar2,1,1,0);
                    if (iVar3 == 0) {
                      (**(code **)(*param_2 + 8))(param_2);
                      log_InlineLogERROR(
                                        "CActivityMgr::OnGetActivityReward, AwardMultiItem user_id[%u] item_type[%u] amount[%d], monoply[%d] error."
                                        );
                    }
                  }
                }
              }
              uVar13 = 1;
            }
            else {
              pIVar12 = theInstance();
              lVar14 = param_2[2];
              uVar13 = (*(code *)**(undefined8 **)pIVar12)
                                 (pIVar12,"STR_ACTIVITY_REWARD_ITEM_NEED_SAPRE");
              (**(code **)(lVar14 + 0x358))(param_2 + 2,uVar13,iVar4);
              uVar13 = 0;
            }
          }
        }
      }
      else {
        uVar13 = 0;
      }
    }
  }
  return uVar13;
}

// ==== CMsgActivityReward::helper_140424e60  @140424e60  [medium:callgraph-r1]  (orig: FUN_140424e60)
longlong * FUN_140424e60(longlong param_1,int param_2,char param_3)

{
  longlong *plVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong lVar4;
  char cVar5;
  undefined8 *puVar6;
  longlong *plVar7;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  longlong *local_18;
  longlong local_10;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0x38))[1];
  cVar5 = *(char *)((longlong)puVar9 + 0x51);
  puVar3 = *(undefined8 **)(param_1 + 0x38);
  while (cVar5 == '\0') {
    if (*(int *)(puVar9 + 3) < param_2) {
      puVar6 = (undefined8 *)puVar9[2];
      puVar9 = puVar3;
    }
    else {
      puVar6 = (undefined8 *)*puVar9;
    }
    puVar3 = puVar9;
    puVar9 = puVar6;
    cVar5 = *(char *)((longlong)puVar6 + 0x51);
  }
  puVar9 = *(undefined8 **)(param_1 + 0x38);
  local_30 = puVar3;
  local_38 = *(longlong *)(param_1 + 8);
  if (*(longlong *)(param_1 + 8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar3 == puVar9) || (param_2 < *(int *)(puVar3 + 3))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0x38);
    local_28 = *(longlong *)(param_1 + 8);
  }
  else {
    plVar8 = &local_38;
  }
  plVar1 = (longlong *)*plVar8;
  lVar10 = *(longlong *)(param_1 + 0x38);
  local_18 = plVar1;
  local_10 = plVar8[1];
  if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(param_1 + 8))) {
    _invalid_parameter_noinfo();
  }
  lVar4 = local_10;
  if (local_10 != lVar10) {
    if (plVar1 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar10 = 0;
    }
    else {
      lVar10 = *plVar1;
    }
    if (lVar4 == *(longlong *)(lVar10 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    plVar8 = *(longlong **)(lVar4 + 0x38);
    if (*(longlong **)(lVar4 + 0x40) < plVar8) {
      _invalid_parameter_noinfo();
    }
    plVar1 = *(longlong **)(lVar4 + 0x20);
    while( true ) {
      plVar2 = *(longlong **)(lVar4 + 0x40);
      if (plVar2 < *(longlong **)(lVar4 + 0x38)) {
        _invalid_parameter_noinfo();
      }
      if ((plVar1 == (longlong *)0x0) || (plVar1 != *(longlong **)(lVar4 + 0x20))) {
        _invalid_parameter_noinfo();
      }
      if (plVar8 == plVar2) break;
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar1;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar2 = (longlong *)*plVar8;
      if (plVar2 != (longlong *)0x0) {
        plVar7 = (longlong *)(**(code **)(*plVar2 + 0x10))(plVar2,2);
        cVar5 = (**(code **)(*plVar7 + 0x20))(plVar7);
        if (param_3 == cVar5) {
          return plVar2;
        }
      }
      if (plVar1 == (longlong *)0x0) {
        _invalid_parameter_noinfo();
        lVar10 = 0;
      }
      else {
        lVar10 = *plVar1;
      }
      if (*(longlong **)(lVar10 + 0x20) <= plVar8) {
        _invalid_parameter_noinfo();
      }
      plVar8 = plVar8 + 1;
    }
  }
  return (longlong *)0x0;
}

// ==== CMsgActivityReward::ctor_or_dtor  @1404598d0  [high:vtable-assign]  (orig: FUN_1404598d0)
undefined8 * FUN_1404598d0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgActivityReward::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgActivityReward::ctor_or_dtor  @140459920  [high:vtable-assign]  (orig: FUN_140459920)
void FUN_140459920(undefined8 *param_1)

{
  *param_1 = CMsgActivityReward::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgActivityReward::vfunc_1  @140459950  [high:rtti-vtable]  (orig: FUN_140459950)
bool FUN_140459950(longlong param_1,longlong param_2)

{
  int iVar1;
  
  if (param_2 != 0) {
    iVar1 = FUN_1402b5640();
    if (iVar1 != 0) {
      return *(int *)(param_1 + 8) == 0xb06;
    }
  }
  return false;
}

// ==== CMsgActivityReward::ctor_or_dtor  @140459990  [high:vtable-assign]  (orig: FUN_140459990)
undefined8 * FUN_140459990(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgActivityReward::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgActivityReward::vfunc_3  @1404599e0  [high:rtti-vtable]  (orig: FUN_1404599e0)
void FUN_1404599e0(longlong param_1)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  
  if (*(longlong *)(param_1 + 0x428) != 0) {
    lVar2 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    if (*(longlong *)(lVar2 + 0x90) == 0) {
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar2 = (**(code **)(**(longlong **)(lVar2 + 0x90) + 0x88))
                      (*(longlong **)(lVar2 + 0x90),param_1);
    if (lVar2 != 0) {
      lVar3 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar3 = *(longlong *)(lVar3 + 0x1f8);
      if (lVar3 == 0) {
        log_InlineLogERROR(&DAT_1406d9c10);
        lVar3 = 0;
      }
      cVar1 = FUN_14025f960(lVar3,lVar2,**(undefined1 **)(param_1 + 0x428));
      if (cVar1 != '\0') {
        (**(code **)(*(longlong *)(lVar2 + 0x10) + 0x350))(lVar2 + 0x10,param_1);
      }
    }
  }
  return;
}

