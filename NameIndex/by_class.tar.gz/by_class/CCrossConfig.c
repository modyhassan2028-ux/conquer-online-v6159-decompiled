// ==== CCrossConfig::ctor_or_dtor  @1400058d0  [high:vtable-assign]  (orig: FUN_1400058d0)
undefined8 * FUN_1400058d0(undefined8 *param_1,byte param_2)

{
  *param_1 = CCrossConfig::vftable;
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CCrossConfig::helper_140005900  @140005900  [medium:callgraph-r1]  (orig: FUN_140005900)
undefined8 FUN_140005900(longlong param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  int iVar1;
  longlong *plVar2;
  undefined8 uVar3;
  longlong *plVar4;
  
  plVar2 = (longlong *)FUN_140006ad0(0x186a1,1,param_3,param_4,0xfffffffffffffffe);
  if (plVar2 == (longlong *)0x0) {
    log_InlineLogERROR(&DAT_1406da820);
    uVar3 = 0;
  }
  else {
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,2);
    iVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
    *(int *)(param_1 + 0x10) = iVar1 % 100;
    *(int *)(param_1 + 0xc) = (iVar1 / 100) % 100;
    *(int *)(param_1 + 8) = (iVar1 / 10000) % 100;
    *(undefined4 *)(param_1 + 0x14) = 0x1c20;
    plVar4 = (longlong *)(**(code **)(*plVar2 + 0x20))(plVar2,3);
    iVar1 = (**(code **)(*plVar4 + 0x48))(plVar4);
    if (-1 < iVar1) {
      *(int *)(param_1 + 0x14) = iVar1 * 0x3c;
    }
    (**(code **)*plVar2)(plVar2);
    uVar3 = 1;
  }
  return uVar3;
}

// ==== CCrossConfig::helper_140005a20  @140005a20  [medium:callgraph-r0]  (orig: FUN_140005a20)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140005a20(longlong param_1)

{
  int iVar1;
  undefined1 auStack_448 [32];
  undefined8 local_428;
  CIniFile local_418 [1024];
  ulonglong local_18;
  
  local_428 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_448;
  CIniFile::CIniFile(local_418,"shell.ini","CrossClient");
  iVar1 = CIniFile::GetInt(local_418,"Enable");
  if (iVar1 == 1) {
    *(undefined1 *)(param_1 + 0x18) = 1;
  }
  else {
    *(undefined1 *)(param_1 + 0x18) = 0;
  }
  if (*(char *)(param_1 + 0x18) == '\0') {
    CIniFile::~CIniFile(local_418);
  }
  else {
    FUN_140005900(param_1);
    CIniFile::~CIniFile(local_418);
  }
  return 1;
}

// ==== CCrossConfig::ctor_or_dtor  @140005ad0  [high:vtable-assign]  (orig: FUN_140005ad0)
undefined8 *
FUN_140005ad0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  puVar2 = operator_new(0x20);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CCrossConfig::vftable;
    *(undefined4 *)(puVar2 + 1) = 0;
    *(undefined4 *)((longlong)puVar2 + 0xc) = 0;
    *(undefined4 *)(puVar2 + 2) = 0;
    *(undefined4 *)((longlong)puVar2 + 0x14) = 0;
    *(undefined1 *)(puVar2 + 3) = 0;
    *(undefined1 *)((longlong)puVar2 + 0x19) = 0;
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_140005a20(puVar2);
    if (cVar1 == '\0') {
      (**(code **)*puVar2)(puVar2,1,param_3,param_4,uVar3);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

