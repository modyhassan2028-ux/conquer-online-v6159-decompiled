// ==== CMapObj::ctor_or_dtor  @140570b90  [high:vtable-assign]  (orig: FUN_140570b90)
undefined8 * FUN_140570b90(undefined8 *param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 1) = param_2;
  *param_1 = CMapObj::vftable;
  *(undefined4 *)((longlong)param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 2) = 0;
  return param_1;
}

// ==== CMapObj::ctor_or_dtor  @140570bb0  [high:vtable-assign]  (orig: FUN_140570bb0)
void FUN_140570bb0(undefined8 *param_1)

{
  *param_1 = CMapObj::vftable;
  return;
}

// ==== CMapObj::vfunc_1  @140570be0  [high:rtti-vtable]  (orig: FUN_140570be0)
void FUN_140570be0(longlong param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 0xc) = param_2;
  *(undefined4 *)(param_1 + 0x10) = param_3;
  return;
}

