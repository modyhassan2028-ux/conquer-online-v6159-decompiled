// ==== CMsgInteract::helper_14000e840  @14000e840  [medium:callgraph-r2]  (orig: FUN_14000e840)
longlong * FUN_14000e840(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffffc) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 2;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_14000df40(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 4;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_14000e934;
  }
  _invalid_parameter_noinfo();
LAB_14000e934:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgInteract::helper_14000f0a0  @14000f0a0  [medium:callgraph-r1]  (orig: FUN_14000f0a0)
void FUN_14000f0a0(undefined8 *param_1,undefined4 *param_2)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  ulonglong uVar3;
  undefined8 local_28;
  undefined4 *puStack_20;
  undefined1 local_18 [16];
  
  puVar1 = (undefined4 *)param_1[3];
  if (puVar1 == (undefined4 *)0x0) {
    uVar3 = 0;
  }
  else {
    uVar3 = param_1[5] - (longlong)puVar1 >> 2;
  }
  puVar2 = (undefined4 *)param_1[4];
  if ((ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2) < uVar3) {
    *puVar2 = *param_2;
    param_1[4] = puVar2 + 1;
    return;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  puStack_20 = puVar2;
  FUN_14000e840(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgInteract::helper_14009ca60  @14009ca60  [medium:callgraph-r3]  (orig: FUN_14009ca60)
void FUN_14009ca60(undefined4 *param_1,longlong param_2,undefined4 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined4 *)0x0) {
      *param_1 = *param_3;
      param_1[1] = param_3[1];
      param_1[2] = param_3[2];
      param_1[3] = param_3[3];
      param_1[4] = param_3[4];
    }
    param_1 = param_1 + 5;
  }
  return;
}

// ==== CMsgInteract::helper_1400b2fa0  @1400b2fa0  [medium:callgraph-r1]  (orig: FUN_1400b2fa0)
undefined8 FUN_1400b2fa0(longlong param_1,int param_2,int param_3,int param_4)

{
  int *piVar1;
  longlong *plVar2;
  longlong *plVar3;
  char cVar4;
  undefined8 uVar5;
  int *piVar6;
  longlong lVar7;
  longlong lVar8;
  
  if ((param_2 == 0) || (param_3 == 0)) {
    return 0;
  }
  lVar7 = *(longlong *)(param_1 + 0x3a8) - *(longlong *)(param_1 + 0x3a0);
  lVar8 = lVar7 >> 0x3f;
  if (lVar7 / 0x14 + lVar8 == lVar8) {
    return 1;
  }
  piVar6 = *(int **)(param_1 + 0x3a0);
  if (*(int **)(param_1 + 0x3a8) < piVar6) {
    _invalid_parameter_noinfo();
  }
  piVar1 = *(int **)(param_1 + 0x3a8);
  plVar2 = *(longlong **)(param_1 + 0x388);
  if (piVar1 < *(int **)(param_1 + 0x3a0)) {
    _invalid_parameter_noinfo();
  }
  plVar3 = *(longlong **)(param_1 + 0x388);
  while( true ) {
    if ((plVar2 == (longlong *)0x0) || (plVar2 != plVar3)) {
      _invalid_parameter_noinfo();
    }
    if (piVar6 == piVar1) goto LAB_1400b30fd;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (*(int **)(lVar8 + 0x20) <= piVar6) {
      _invalid_parameter_noinfo();
    }
    if (((*piVar6 == param_2) && (piVar6[1] == param_3)) && (piVar6[2] == param_4)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (*(int **)(lVar8 + 0x20) <= piVar6) {
      _invalid_parameter_noinfo();
    }
    piVar6 = piVar6 + 5;
  }
  cVar4 = FUN_140022290(piVar6 + 3);
  if (cVar4 == '\0') {
    uVar5 = 0;
  }
  else {
    FUN_14009c860(piVar6 + 5,*(undefined8 *)(param_1 + 0x3a8),piVar6);
    *(longlong *)(param_1 + 0x3a8) = *(longlong *)(param_1 + 0x3a8) + -0x14;
    if ((piVar6 < *(int **)(param_1 + 0x3a0)) || (*(int **)(param_1 + 0x3a8) < piVar6)) {
      _invalid_parameter_noinfo();
    }
LAB_1400b30fd:
    uVar5 = 1;
  }
  return uVar5;
}

// ==== CMsgInteract::helper_1400b8e90  @1400b8e90  [medium:callgraph-r3]  (orig: FUN_1400b8e90)
longlong * FUN_1400b8e90(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong lVar5;
  longlong *local_28;
  ulonglong uStack_20;
  
  uVar1 = param_1[3];
  lVar4 = param_1[4] - uVar1;
  lVar2 = 0;
  lVar5 = lVar4 >> 0x3f;
  lVar3 = lVar2;
  if (lVar4 / 0x14 + lVar5 != lVar5) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) / 0x14;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1400b5b40(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar5 = lVar2;
  }
  else {
    lVar5 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 0x14;
  if (uVar1 <= *(ulonglong *)(lVar5 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1400b8fb4;
  }
  _invalid_parameter_noinfo();
LAB_1400b8fb4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgInteract::helper_1400b9bc0  @1400b9bc0  [medium:callgraph-r2]  (orig: FUN_1400b9bc0)
void FUN_1400b9bc0(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) / 0x14;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) / 0x14) < uVar3) {
    FUN_14009ca60(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 0x14;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1400b8e90(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgInteract::helper_1400c17f0  @1400c17f0  [medium:callgraph-r1]  (orig: FUN_1400c17f0)
void FUN_1400c17f0(longlong param_1,int param_2,int param_3,undefined4 param_4)

{
  ulong uVar1;
  int local_28;
  int local_24;
  undefined4 local_20;
  undefined4 local_1c;
  uint local_18;
  
  if ((param_2 != 0) && (param_3 != 0)) {
    local_1c = 600;
    local_28 = param_2;
    local_24 = param_3;
    local_20 = param_4;
    uVar1 = tq::TimeGet(0);
    local_18 = uVar1 / 1000;
    FUN_1400b9bc0(param_1 + 0x388,&local_28);
  }
  return;
}

// ==== CMsgInteract::helper_140161570  @140161570  [medium:callgraph-r0]  (orig: FUN_140161570)
void FUN_140161570(longlong param_1,undefined1 param_2)

{
  *(undefined1 *)(param_1 + 0xa7a) = param_2;
  return;
}

// ==== CMsgInteract::helper_1401615a0  @1401615a0  [medium:callgraph-r0]  (orig: FUN_1401615a0)
undefined4 FUN_1401615a0(longlong param_1)

{
  return *(undefined4 *)(param_1 + 0xa7c);
}

// ==== CMsgInteract::helper_1401615b0  @1401615b0  [medium:callgraph-r0]  (orig: FUN_1401615b0)
void FUN_1401615b0(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(param_1 + 0xa80) = param_2;
  return;
}

// ==== CMsgInteract::helper_140163af0  @140163af0  [medium:callgraph-r0]  (orig: FUN_140163af0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_140163af0(longlong *param_1,int param_2,int param_3)

{
  undefined2 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  longlong *plVar5;
  undefined1 auStack_4e8 [32];
  int local_4c8;
  char *local_4c0;
  undefined4 local_4b8;
  undefined4 local_4b0;
  undefined8 local_4a8;
  undefined1 local_498 [1104];
  ulonglong local_48;
  
  local_4a8 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4e8;
  plVar5 = (longlong *)(**(code **)(param_1[2] + 0x160))(param_1 + 2);
  if (plVar5 != (longlong *)0x0) {
    FUN_140362560(local_498);
    uVar2 = (**(code **)(*(longlong *)plVar5[0xb] + 0x10))((longlong *)plVar5[0xb],3);
    uVar1 = (**(code **)(param_1[2] + 0x50))(param_1 + 2);
    uVar3 = (**(code **)(*param_1 + 8))(param_1);
    local_4b0 = 0;
    local_4c0 = (char *)CONCAT62(local_4c0._2_6_,0x9c);
    local_4c8 = CONCAT22(local_4c8._2_2_,uVar1);
    local_4b8 = uVar2;
    iVar4 = FUN_140362620(local_498,uVar3,param_2,param_3);
    if (iVar4 != 0) {
      (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_498,1);
    }
    (**(code **)(param_1[2] + 0x2e8))(param_1 + 2,3);
    if ((((param_2 < 0) ||
         (iVar4 = (**(code **)(*(longlong *)plVar5[0xc] + 0x28))(), iVar4 <= param_2)) ||
        (param_3 < 0)) ||
       (iVar4 = (**(code **)(*(longlong *)plVar5[0xc] + 0x20))(), iVar4 <= param_3)) {
      (**(code **)(*plVar5 + 8))(plVar5);
      (**(code **)(*param_1 + 8))(param_1);
      local_4b8 = 0x4213;
      local_4c0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
      local_4c8 = param_3;
      log_InlineLogERROR("CUser::Teleport user%u map%u(%d, %d) at %s, %d");
    }
    else {
      (**(code **)(param_1[2] + 0x378))(param_1 + 2,param_2,param_3);
    }
    FUN_1403625e0(local_498);
    return;
  }
  return;
}

// ==== CMsgInteract::helper_140169d60  @140169d60  [medium:callgraph-r3]  (orig: FUN_140169d60)
void FUN_140169d60(void)

{
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_70 [40];
  undefined **local_48 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_30 [48];
  
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_70,"vector<T> too long");
  std::exception::exception((exception *)local_48);
  local_48[0] = std::logic_error::vftable;
  std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
  basic_string<char,std::char_traits<char>,std::allocator<char>_>
            (local_30,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                       *)local_70);
  local_48[0] = std::length_error::vftable;
                    /* WARNING: Subroutine does not return */
  _CxxThrowException(local_48,(ThrowInfo *)&DAT_140944488);
}

// ==== CMsgInteract::helper_1401739a0  @1401739a0  [medium:callgraph-r0]  (orig: FUN_1401739a0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1401739a0(longlong *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  longlong lVar5;
  longlong *plVar6;
  undefined8 uVar7;
  IStringManager *pIVar8;
  char *_Format;
  longlong *plVar9;
  undefined1 auStack_d28 [32];
  ulonglong local_d08;
  undefined8 local_d00;
  undefined2 local_cf8;
  undefined2 local_cf0;
  undefined4 local_ce8;
  undefined4 local_ce0;
  undefined1 local_cd8;
  undefined8 local_cc8;
  undefined1 local_cb8 [1104];
  undefined1 local_868 [1072];
  char local_438;
  undefined1 local_437 [1023];
  ulonglong local_38;
  
  local_cc8 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_d28;
  lVar5 = FUN_140008520((int)param_1[0x246]);
  lVar5 = *(longlong *)(lVar5 + 0x218);
  if (lVar5 == 0) {
    local_d08._0_4_ = 0x167;
    log_InlineLogERROR(&DAT_1406d9c10);
    local_d08 = CONCAT44(local_d08._4_4_,0x492d);
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar7 = 0;
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    if (iVar1 == 0) {
      plVar6 = (longlong *)(**(code **)(*param_1 + 0x28))(param_1,param_2);
      uVar7 = 0;
      if (plVar6 != (longlong *)0x0) {
        iVar1 = (**(code **)(*plVar6 + 0x50))(plVar6);
        iVar2 = (**(code **)(*param_1 + 0x50))(param_1);
        if (iVar2 == iVar1) {
          uVar7 = 0;
        }
        else {
          uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
          iVar1 = FUN_14027a2d0(lVar5,uVar3,2);
          iVar2 = (**(code **)(*param_1 + 8))(param_1);
          if (iVar1 == iVar2) {
            iVar1 = (**(code **)(*plVar6 + 0x48))(plVar6);
            if (iVar1 == 0) {
              uVar7 = (**(code **)(plVar6[2] + 0x18))(plVar6 + 2);
              uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
              FUN_140164300(param_1,uVar3,uVar7,1);
              uVar7 = (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              uVar3 = (**(code **)(*param_1 + 8))(param_1);
              FUN_140164300(plVar6,uVar3,uVar7,1);
              FUN_140170e90(param_1,0x2791);
              FUN_140170e90(plVar6);
              local_438 = '\0';
              memset(local_437,0,0x3ff);
              pIVar8 = theInstance();
              uVar7 = (**(code **)(plVar6[2] + 0x18))(plVar6 + 2);
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              _Format = (char *)(*(code *)**(undefined8 **)pIVar8)(pIVar8,"STR_MARRY");
              local_d08 = uVar7;
              _snprintf(&local_438,0x3ff,_Format);
              FUN_14015b240(local_cb8);
              local_cd8 = 1;
              local_ce0 = 0;
              local_ce8 = 0;
              local_cf0 = 0;
              local_cf8 = 0x7db;
              local_d00 = CONCAT44(local_d00._4_4_,0xff0000);
              local_d08 = 0;
              iVar1 = FUN_14015b300(local_cb8,"SYSTEM","ALLUSERS",&local_438);
              if (iVar1 == 0) {
                local_d08 = CONCAT44(local_d08._4_4_,0x494c);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                plVar9 = (longlong *)FUN_140008520((int)param_1[0x246]);
                (**(code **)(*plVar9 + 0x68))(plVar9,local_cb8,0xffffffff);
              }
              FUN_1400f83e0(local_868);
              uVar3 = (**(code **)(*param_1 + 8))(param_1);
              local_d08 = local_d08 & 0xffffffff00000000;
              iVar1 = FUN_1400f8490(local_868,uVar3,0x1a,0xff);
              if (iVar1 == 0) {
                local_d08 = CONCAT44(local_d08._4_4_,0x4952);
                log_InlineLogERROR(&DAT_1406d9c10);
              }
              else {
                (**(code **)(param_1[2] + 0x348))(param_1 + 2,local_868,1);
              }
              FUN_1400f8430(local_868);
              uVar7 = (**(code **)(plVar6[2] + 0x18))(plVar6 + 2);
              uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
              (**(code **)(param_1[2] + 0x18))(param_1 + 2);
              (**(code **)(*param_1 + 8))(param_1);
              local_d08 = CONCAT44(local_d08._4_4_,uVar3);
              local_d00 = uVar7;
              tq::MyLogSave("gmlog/marriage","%u[%s] married with %u[%s]");
              plVar9 = (longlong *)CurrentInstanceGet();
              plVar9 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,8);
              if (plVar9 == (longlong *)0x0) {
                log_InlineLogERROR("Family.dll not load. %s, %d");
                FUN_14015b2c0(local_cb8);
                uVar7 = 1;
              }
              else {
                lVar5 = *plVar9;
                uVar3 = (**(code **)(*param_1 + 0x48))(param_1);
                uVar4 = (**(code **)(*param_1 + 8))(param_1);
                (**(code **)(lVar5 + 0x170))(plVar9,uVar4,uVar3);
                plVar9 = (longlong *)FUN_140087ed0();
                lVar5 = *plVar9;
                uVar3 = (**(code **)(*plVar6 + 8))(plVar6);
                uVar4 = (**(code **)(*param_1 + 8))(param_1);
                (**(code **)(lVar5 + 0x60))(plVar9,uVar4,uVar3);
                FUN_14015b2c0(local_cb8);
                uVar7 = 1;
              }
            }
            else {
              uVar7 = 0;
            }
          }
          else {
            uVar7 = 0;
          }
        }
      }
    }
    else {
      uVar7 = 0;
    }
  }
  return uVar7;
}

// ==== CMsgInteract::helper_1401782c0  @1401782c0  [medium:callgraph-r0]  (orig: FUN_1401782c0)
bool FUN_1401782c0(longlong *param_1)

{
  undefined4 uVar1;
  longlong lVar2;
  longlong lVar3;
  
  lVar2 = FUN_140008520((int)param_1[0x246]);
  if (*(longlong *)(lVar2 + 0x100) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    log_InlineLogERROR(&DAT_1406d9c10);
    return false;
  }
  lVar2 = FUN_140008520((int)param_1[0x246]);
  lVar3 = *(longlong *)(lVar2 + 0x100);
  if (*(longlong *)(lVar2 + 0x100) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    lVar3 = 0;
  }
  uVar1 = (**(code **)(*param_1 + 8))(param_1);
  lVar2 = FUN_1402f3a20(lVar3,uVar1);
  return lVar2 != 0;
}

// ==== CMsgInteract::helper_14017cd20  @14017cd20  [medium:callgraph-r3]  (orig: FUN_14017cd20)
void FUN_14017cd20(undefined8 param_1,ulonglong param_2)

{
  undefined1 auVar1 [16];
  char *local_res10 [3];
  undefined **local_20 [4];
  
  if ((param_2 != 0) &&
     (auVar1._8_8_ = 0, auVar1._0_8_ = param_2,
     SUB168((ZEXT816(0) << 0x40 | ZEXT816(0xffffffffffffffff)) / auVar1,0) < 8)) {
    local_res10[0] = (char *)0x0;
    std::exception::exception((exception *)local_20,local_res10);
    local_20[0] = std::bad_alloc::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_20,(ThrowInfo *)&DAT_140944540);
  }
  operator_new(param_2 * 8);
  return;
}

// ==== CMsgInteract::helper_140187740  @140187740  [medium:callgraph-r1]  (orig: FUN_140187740)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140187740(longlong *param_1)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  ulong uVar7;
  int iVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  undefined1 auStack_4a8 [32];
  char *local_488;
  int local_480;
  char local_478;
  int local_474;
  int local_470;
  longlong *local_468;
  uint local_460;
  int local_45c;
  longlong *local_458;
  longlong *local_450;
  undefined4 local_448;
  uint local_444;
  undefined8 local_440;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4a8;
  local_474 = 0;
  uVar1 = *(uint *)(param_1 + 0x1e2);
  local_438 = '\0';
  local_468 = param_1;
  local_460 = uVar1;
  local_450 = param_1;
  memset(local_437,0,0x3ff);
  local_488 = (char *)CONCAT44(local_488._4_4_,uVar1);
  _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE account_id=%u && used=0");
  local_39 = 0;
  FUN_140008520((int)param_1[0x246]);
  plVar9 = (longlong *)InstanceGet();
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&local_438,2);
  iVar8 = 0;
  if (plVar9 != (longlong *)0x0) {
    local_458 = plVar9;
    lVar10 = (**(code **)(*plVar9 + 0x40))(plVar9);
    if (lVar10 == 0) {
      (**(code **)*plVar9)(plVar9);
      iVar8 = 0;
    }
    else {
      local_470 = 0;
      while( true ) {
        iVar8 = local_470;
        iVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        if (iVar3 <= iVar8) break;
        (**(code **)(*plVar9 + 0x30))(plVar9,(longlong)iVar8);
        plVar11 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9);
        if (plVar11 == (longlong *)0x0) {
          local_488 = (char *)CONCAT44(local_488._4_4_,0x4d22);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
          uVar4 = (**(code **)(*plVar12 + 0x40))(plVar12);
          local_444 = uVar4;
          plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
          local_448 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
          iVar3 = (**(code **)(*plVar12 + 0x50))(plVar12);
          plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,&DAT_1406de6d4);
          uVar5 = (**(code **)(*plVar12 + 0x50))(plVar12);
          if (DAT_140975bb8 != 0) {
            local_45c = FUN_140276390(DAT_140975bb8,uVar5);
            if (0 < local_45c) {
              iVar6 = FUN_140164640(uVar1,uVar4,local_448,0);
              if (iVar6 != iVar3) {
                if ((uVar1 ^ 780000) + (uVar4 >> 1) != iVar3) {
                  local_480 = 0x4d3d;
                  local_488 = 
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                  log_InlineLogERROR("Check %s chksum failed. AccountID=%u, RefID=%u at %s, %d");
                  (**(code **)*plVar11)(plVar11,1);
                  param_1 = local_468;
                  goto LAB_140187b94;
                }
                local_480 = 0x4d43;
                local_488 = 
                "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                log_InlineLogWARNING
                          ("Check %s chksum: chksum is old, AccountID=%u, RefID=%u at %s, %d");
              }
              uVar7 = tq::TimeStampGet();
              uVar5 = FUN_140164640(uVar1,uVar4,uVar7,1);
              plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,&DAT_140717878);
              (**(code **)(*plVar12 + 0xb0))(plVar12,1);
              plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
              (**(code **)(*plVar12 + 0xa8))(plVar12,uVar7);
              plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
              (**(code **)(*plVar12 + 0xa8))(plVar12,uVar5);
              cVar2 = (**(code **)(*plVar11 + 0x38))(plVar11,1);
              local_478 = cVar2;
              (**(code **)*plVar11)(plVar11,1);
              iVar3 = local_45c;
              plVar11 = local_468;
              param_1 = local_468;
              if (cVar2 != '\0') {
                plVar12 = local_468 + 2;
                local_488 = (char *)0x0;
                (**(code **)(*plVar12 + 0x2e0))(plVar12,0x1d,(longlong)local_45c,1);
                uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
                local_488._0_4_ = iVar3;
                FUN_1401742b0(plVar11,6,local_444,uVar5);
                uVar7 = tq::TimeStampGet();
                (**(code **)(*plVar12 + 0x18))(plVar12);
                (**(code **)(*local_468 + 8))();
                local_480 = iVar3;
                local_488 = (char *)CONCAT44(local_488._4_4_,uVar7);
                tq::MyLogSave("gmlog/card_checkout",
                              "Checkout card1 userid:%u user_name:%s idRef:%u price:%d");
                local_474 = local_474 + iVar3;
                param_1 = local_468;
              }
              goto LAB_140187b94;
            }
          }
          (**(code **)*plVar11)(plVar11,1);
          param_1 = local_468;
        }
LAB_140187b94:
        local_470 = iVar8 + 1;
      }
      FUN_140175810(param_1,local_474);
      (**(code **)*plVar9)(plVar9);
      iVar8 = local_474;
    }
  }
  return iVar8;
}

// ==== CMsgInteract::helper_140187bf0  @140187bf0  [medium:callgraph-r1]  (orig: FUN_140187bf0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140187bf0(longlong *param_1)

{
  uint uVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  ulong uVar8;
  longlong *plVar9;
  longlong lVar10;
  longlong *plVar11;
  longlong *plVar12;
  int iVar13;
  undefined1 auStack_488 [32];
  char *local_468;
  int local_460;
  int local_458;
  longlong *local_450;
  int local_448;
  int local_444;
  undefined8 local_440;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  iVar6 = 0;
  local_458 = 0;
  uVar1 = *(uint *)(param_1 + 0x1e2);
  local_438 = '\0';
  local_450 = param_1;
  memset(local_437,0,0x3ff);
  local_468 = (char *)CONCAT44(local_468._4_4_,uVar1);
  _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE account_id=%u && used=0");
  local_39 = 0;
  FUN_140008520((int)param_1[0x246]);
  plVar9 = (longlong *)InstanceGet();
  plVar9 = (longlong *)(**(code **)(*plVar9 + 0x10))(plVar9,&local_438,2);
  iVar3 = 0;
  if (plVar9 != (longlong *)0x0) {
    lVar10 = (**(code **)(*plVar9 + 0x40))(plVar9);
    if (lVar10 == 0) {
      (**(code **)*plVar9)(plVar9);
      iVar3 = 0;
    }
    else {
      iVar13 = 0;
      local_448 = 0;
      iVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
      if (0 < iVar3) {
        do {
          (**(code **)(*plVar9 + 0x30))(plVar9,(longlong)iVar13);
          plVar11 = (longlong *)(**(code **)(*plVar9 + 0x38))(plVar9);
          if (plVar11 == (longlong *)0x0) {
            local_468 = (char *)CONCAT44(local_468._4_4_,0x4d8b);
            log_InlineLogERROR(&DAT_1406d9c10);
            param_1 = local_450;
          }
          else {
            plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"ref_id");
            uVar4 = (**(code **)(*plVar12 + 0x40))(plVar12);
            plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
            uVar5 = (**(code **)(*plVar12 + 0x50))(plVar12);
            plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
            iVar6 = (**(code **)(*plVar12 + 0x50))(plVar12);
            plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,&DAT_1406de6d4);
            uVar7 = (**(code **)(*plVar12 + 0x50))(plVar12);
            if (DAT_140975bb8 != 0) {
              local_444 = FUN_140276390(DAT_140975bb8,uVar7);
              if (0 < local_444) {
                iVar3 = FUN_140164640(uVar1,uVar4,uVar5,0);
                if (iVar3 != iVar6) {
                  if ((uVar1 ^ 0xbe6e1) + (uVar4 >> 1) != iVar6) {
                    local_460 = 0x4da6;
                    local_468 = 
                    "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                    log_InlineLogERROR("Check %s chksum failed. AccountID=%u, RefID=%u at %s, %d");
                    (**(code **)*plVar11)(plVar11,1);
                    param_1 = local_450;
                    goto LAB_140187fcd;
                  }
                  local_460 = 0x4dac;
                  local_468 = 
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                  log_InlineLogWARNING
                            ("Check %s chksum: chksum is old, AccountID=%u, RefID=%u at %s, %d");
                }
                uVar8 = tq::TimeStampGet();
                uVar5 = FUN_140164640(uVar1,uVar4,uVar8,1);
                plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,&DAT_140717878);
                (**(code **)(*plVar12 + 0xb0))(plVar12,1);
                plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"time_stamp");
                (**(code **)(*plVar12 + 0xa8))(plVar12,uVar8);
                plVar12 = (longlong *)(**(code **)(*plVar11 + 0x20))(plVar11,"chk_sum");
                (**(code **)(*plVar12 + 0xa8))(plVar12,uVar5);
                cVar2 = (**(code **)(*plVar11 + 0x38))(plVar11,1);
                (**(code **)*plVar11)(plVar11,1);
                iVar6 = local_444;
                plVar11 = local_450;
                param_1 = local_450;
                if (cVar2 != '\0') {
                  plVar12 = local_450 + 2;
                  local_468 = (char *)0x0;
                  (**(code **)(*plVar12 + 0x2e0))(plVar12,0x1d,(longlong)local_444,1);
                  uVar5 = (**(code **)(*plVar11 + 8))(plVar11);
                  local_468._0_4_ = iVar6;
                  FUN_1401742b0(plVar11,8,uVar4,uVar5);
                  uVar8 = tq::TimeStampGet();
                  (**(code **)(*plVar12 + 0x18))(plVar12);
                  param_1 = local_450;
                  (**(code **)(*local_450 + 8))(local_450);
                  local_460 = iVar6;
                  local_468 = (char *)CONCAT44(local_468._4_4_,uVar8);
                  tq::MyLogSave("gmlog/card_checkout",
                                "Checkout card2 userid:%u user_name:%s idRef:%u price:%d");
                  local_458 = local_458 + iVar6;
                }
                goto LAB_140187fcd;
              }
            }
            (**(code **)*plVar11)(plVar11,1);
            param_1 = local_450;
          }
LAB_140187fcd:
          iVar6 = local_458;
          iVar13 = local_448 + 1;
          local_448 = iVar13;
          iVar3 = (**(code **)(*plVar9 + 0x40))(plVar9);
        } while (iVar13 < iVar3);
      }
      FUN_140175810(param_1,iVar6);
      (**(code **)*plVar9)(plVar9);
      iVar3 = iVar6;
    }
  }
  return iVar3;
}

// ==== CMsgInteract::helper_140188040  @140188040  [medium:callgraph-r1]  (orig: FUN_140188040)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140188040(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int iVar5;
  ulong uVar6;
  longlong *plVar7;
  longlong lVar8;
  longlong *plVar9;
  longlong *plVar10;
  int iVar11;
  undefined1 auStack_498 [32];
  char *local_478;
  int local_470;
  int local_468;
  undefined4 local_464;
  int local_460;
  undefined4 local_45c;
  undefined4 local_458;
  longlong *local_450;
  undefined8 local_448;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_448 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_498;
  local_468 = 0;
  lVar8 = param_1[0x1e2];
  local_438 = '\0';
  local_464 = (int)lVar8;
  local_450 = param_1;
  memset(local_437,0,0x3ff);
  local_478 = (char *)CONCAT44(local_478._4_4_,(int)lVar8);
  _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE account_id=%u && used=0");
  local_39 = 0;
  FUN_140008520((int)param_1[0x246]);
  plVar7 = (longlong *)InstanceGet();
  plVar7 = (longlong *)(**(code **)(*plVar7 + 0x10))(plVar7,&local_438,2);
  iVar5 = 0;
  if (plVar7 != (longlong *)0x0) {
    lVar8 = (**(code **)(*plVar7 + 0x40))(plVar7);
    if (lVar8 == 0) {
      (**(code **)*plVar7)(plVar7);
      iVar5 = 0;
    }
    else {
      iVar11 = 0;
      iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
      iVar5 = 0;
      if (0 < iVar2) {
        do {
          (**(code **)(*plVar7 + 0x30))(plVar7,(longlong)iVar11);
          plVar9 = (longlong *)(**(code **)(*plVar7 + 0x38))(plVar7);
          if (plVar9 == (longlong *)0x0) {
            local_478 = (char *)CONCAT44(local_478._4_4_,0x4df4);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"ref_id");
            uVar3 = (**(code **)(*plVar10 + 0x40))(plVar10);
            local_458 = uVar3;
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"time_stamp");
            local_45c = (**(code **)(*plVar10 + 0x50))(plVar10);
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"chk_sum");
            local_460 = (**(code **)(*plVar10 + 0x50))(plVar10);
            plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,&DAT_1406de6d4);
            uVar4 = (**(code **)(*plVar10 + 0x50))(plVar10);
            if (DAT_140975bb8 != 0) {
              iVar5 = FUN_140276390(DAT_140975bb8,uVar4);
              if (0 < iVar5) {
                iVar2 = FUN_140164640(local_464,uVar3,local_45c,0);
                if (iVar2 != local_460) {
                  local_470 = 0x4e0d;
                  local_478 = 
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                  log_InlineLogWARNING
                            ("Check %s chksum: chksum is old, AccountID=%u, RefID=%u at %s, %d");
                  (**(code **)*plVar9)(plVar9,1);
                  (**(code **)*plVar7)(plVar7);
                  return 0;
                }
                uVar6 = tq::TimeStampGet();
                uVar3 = FUN_140164640(local_464,uVar3,uVar6,1);
                plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,&DAT_140717878);
                (**(code **)(*plVar10 + 0xb0))(plVar10,1);
                plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"time_stamp");
                (**(code **)(*plVar10 + 0xa8))(plVar10,uVar6);
                plVar10 = (longlong *)(**(code **)(*plVar9 + 0x20))(plVar9,"chk_sum");
                (**(code **)(*plVar10 + 0xa8))(plVar10,uVar3);
                cVar1 = (**(code **)(*plVar9 + 0x38))(plVar9,1);
                (**(code **)*plVar9)(plVar9,1);
                if (cVar1 != '\0') {
                  local_478 = (char *)0x0;
                  (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)iVar5,1);
                  uVar3 = (**(code **)(*param_1 + 8))(param_1);
                  local_478._0_4_ = iVar5;
                  FUN_1401742b0(param_1,6,local_458,uVar3);
                  uVar6 = tq::TimeStampGet();
                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                  (**(code **)(*param_1 + 8))(param_1);
                  local_478 = (char *)CONCAT44(local_478._4_4_,uVar6);
                  local_470 = iVar5;
                  tq::MyLogSave("gmlog/card_checkout",
                                "Checkout card3 userid:%u user_name:%s idRef:%u price:%d");
                  local_468 = local_468 + iVar5;
                }
                goto LAB_14018838e;
              }
            }
            (**(code **)*plVar9)(plVar9,1);
          }
LAB_14018838e:
          iVar11 = iVar11 + 1;
          iVar2 = (**(code **)(*plVar7 + 0x40))(plVar7);
          iVar5 = local_468;
        } while (iVar11 < iVar2);
      }
      (**(code **)*plVar7)(plVar7);
      FUN_140175810(param_1,iVar5);
    }
  }
  return iVar5;
}

// ==== CMsgInteract::helper_140188440  @140188440  [medium:callgraph-r1]  (orig: FUN_140188440)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

int FUN_140188440(longlong *param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  ulong uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  int iVar10;
  undefined1 auStack_488 [32];
  char *local_468;
  int local_460;
  int local_458;
  undefined4 local_454;
  undefined4 local_450;
  undefined4 local_44c;
  int local_448;
  undefined8 local_440;
  char local_438;
  undefined1 local_437 [1022];
  undefined1 local_39;
  ulonglong local_38;
  
  local_440 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  iVar4 = 0;
  local_458 = 0;
  lVar7 = param_1[0x1e2];
  local_438 = '\0';
  local_454 = (int)lVar7;
  memset(local_437,0,0x3ff);
  local_468 = (char *)CONCAT44(local_468._4_4_,(int)lVar7);
  _snprintf(&local_438,0x400,"SELECT * FROM %s WHERE account_id=%u && used=0");
  local_39 = 0;
  FUN_140008520((int)param_1[0x246]);
  plVar6 = (longlong *)InstanceGet();
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x10))(plVar6,&local_438,2);
  iVar2 = 0;
  if (plVar6 != (longlong *)0x0) {
    lVar7 = (**(code **)(*plVar6 + 0x40))(plVar6);
    if (lVar7 == 0) {
      (**(code **)*plVar6)(plVar6);
      iVar2 = 0;
    }
    else {
      iVar10 = 0;
      iVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
      if (0 < iVar2) {
        do {
          (**(code **)(*plVar6 + 0x30))(plVar6,(longlong)iVar10);
          plVar8 = (longlong *)(**(code **)(*plVar6 + 0x38))(plVar6);
          if (plVar8 == (longlong *)0x0) {
            local_468 = (char *)CONCAT44(local_468._4_4_,0x4e56);
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"ref_id");
            local_450 = (**(code **)(*plVar9 + 0x40))(plVar9);
            plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"time_stamp");
            local_44c = (**(code **)(*plVar9 + 0x50))(plVar9);
            plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"chk_sum");
            local_448 = (**(code **)(*plVar9 + 0x50))(plVar9);
            plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,&DAT_1406de6d4);
            uVar3 = (**(code **)(*plVar9 + 0x50))(plVar9);
            if (DAT_140975bb8 != 0) {
              iVar2 = FUN_140276390(DAT_140975bb8,uVar3);
              uVar3 = local_450;
              if (0 < iVar2) {
                iVar4 = FUN_140164640(local_454,local_450,local_44c,0);
                if (iVar4 != local_448) {
                  local_460 = 0x4e6f;
                  local_468 = 
                  "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                  log_InlineLogWARNING
                            ("Check %s chksum: chksum is old, AccountID=%u, RefID=%u at %s, %d");
                  (**(code **)*plVar8)(plVar8,1);
                  (**(code **)*plVar6)(plVar6);
                  return 0;
                }
                uVar5 = tq::TimeStampGet();
                uVar3 = FUN_140164640(local_454,uVar3,uVar5,1);
                plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,&DAT_140717878);
                (**(code **)(*plVar9 + 0xb0))(plVar9,1);
                plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"time_stamp");
                (**(code **)(*plVar9 + 0xa8))(plVar9,uVar5);
                plVar9 = (longlong *)(**(code **)(*plVar8 + 0x20))(plVar8,"chk_sum");
                (**(code **)(*plVar9 + 0xa8))(plVar9,uVar3);
                cVar1 = (**(code **)(*plVar8 + 0x38))(plVar8,1);
                (**(code **)*plVar8)(plVar8,1);
                iVar4 = local_458;
                if (cVar1 != '\0') {
                  local_468 = (char *)0x0;
                  (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,(longlong)iVar2,1);
                  uVar3 = (**(code **)(*param_1 + 8))(param_1);
                  local_468._0_4_ = iVar2;
                  FUN_1401742b0(param_1,6,local_450,uVar3);
                  uVar5 = tq::TimeStampGet();
                  (**(code **)(param_1[2] + 0x18))(param_1 + 2);
                  (**(code **)(*param_1 + 8))(param_1);
                  local_468 = (char *)CONCAT44(local_468._4_4_,uVar5);
                  local_460 = iVar2;
                  tq::MyLogSave("gmlog/card_checkout",
                                "Checkout card4 userid:%u user_name:%s idRef:%u price:%d");
                  local_458 = local_458 + iVar2;
                  iVar4 = local_458;
                }
                goto LAB_14018878e;
              }
            }
            (**(code **)*plVar8)(plVar8,1);
          }
LAB_14018878e:
          iVar10 = iVar10 + 1;
          iVar2 = (**(code **)(*plVar6 + 0x40))(plVar6);
        } while (iVar10 < iVar2);
      }
      FUN_140175810(param_1,iVar4);
      (**(code **)*plVar6)(plVar6);
      iVar2 = iVar4;
    }
  }
  return iVar2;
}

// ==== CMsgInteract::helper_140193c20  @140193c20  [medium:callgraph-r0]  (orig: FUN_140193c20)
bool FUN_140193c20(longlong param_1,int param_2)

{
  int *piVar1;
  longlong lVar2;
  int *piVar3;
  int *piVar4;
  
  piVar1 = *(int **)(param_1 + 0x3e0);
  if (piVar1 < *(int **)(param_1 + 0x3d8)) {
    _invalid_parameter_noinfo();
  }
  piVar4 = *(int **)(param_1 + 0x3d8);
  if (*(int **)(param_1 + 0x3e0) < piVar4) {
    _invalid_parameter_noinfo();
  }
  lVar2 = *(longlong *)(param_1 + 0x3c0);
  piVar3 = *(int **)(param_1 + 0x3e0);
  if (piVar3 < *(int **)(param_1 + 0x3d8)) {
    _invalid_parameter_noinfo();
  }
  for (; (piVar4 != piVar1 && (*piVar4 != param_2)); piVar4 = piVar4 + 1) {
  }
  if ((lVar2 == 0) || (lVar2 != *(longlong *)(param_1 + 0x3c0))) {
    _invalid_parameter_noinfo();
  }
  return piVar4 == piVar3;
}

// ==== CMsgInteract::helper_140193d40  @140193d40  [medium:callgraph-r0]  (orig: FUN_140193d40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_140193d40(longlong *param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  longlong lVar4;
  longlong *plVar5;
  undefined8 uVar6;
  longlong *plVar7;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  int local_490;
  undefined4 local_488;
  undefined8 local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_478 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  lVar4 = FUN_140008520((int)param_1[0x246]);
  lVar4 = *(longlong *)(lVar4 + 0x218);
  if (lVar4 == 0) {
    local_4a8 = 0x167;
    log_InlineLogERROR(&DAT_1406d9c10);
    local_4a8 = 0x4903;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar6 = 0;
  }
  else {
    iVar1 = (**(code **)(*param_1 + 0x48))(param_1);
    if (iVar1 == 0) {
      plVar5 = (longlong *)(**(code **)(*param_1 + 0x28))(param_1,param_2);
      uVar6 = 0;
      if (plVar5 != (longlong *)0x0) {
        iVar1 = (**(code **)(*plVar5 + 0x50))(plVar5);
        iVar2 = (**(code **)(*param_1 + 0x50))(param_1);
        if (iVar2 == iVar1) {
          uVar6 = 0;
        }
        else {
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          FUN_14027a130(lVar4,uVar3,2,param_2);
          iVar1 = 0;
          uVar6 = FUN_140008520((int)param_1[0x246]);
          plVar7 = (longlong *)FUN_1400875f0(uVar6);
          plVar7 = (longlong *)(**(code **)(*plVar7 + 0x20))(plVar7,param_2);
          if (plVar7 != (longlong *)0x0) {
            lVar4 = (**(code **)(*plVar7 + 0x2b0))(plVar7);
            if (lVar4 != 0) {
              iVar1 = FUN_14018eb30(param_1);
              iVar2 = FUN_14018eb30(lVar4);
              iVar1 = iVar1 - iVar2;
            }
          }
          FUN_14035f2f0(local_468);
          uVar3 = (**(code **)(*param_1 + 8))(param_1);
          local_488 = 0;
          local_498 = 0;
          local_4a0 = 0;
          local_4a8 = (uint)local_4a8._2_2_ << 0x10;
          local_490 = iVar1;
          iVar1 = FUN_14035f3a0(local_468,8,uVar3,param_2);
          if (iVar1 == 0) {
            local_4a8 = 0x4920;
            log_InlineLogERROR(&DAT_1406d9c10);
          }
          else {
            uVar3 = (**(code **)(*param_1 + 8))(param_1);
            FUN_14018f460(plVar5,uVar3,0,0);
            (**(code **)(plVar5[2] + 0x350))(plVar5 + 2,local_468);
          }
          FUN_14035f340(local_468);
          uVar6 = 1;
        }
      }
    }
    else {
      uVar6 = 0;
    }
  }
  return uVar6;
}

// ==== CMsgInteract::helper_1401ad5b0  @1401ad5b0  [medium:callgraph-r0]  (orig: FUN_1401ad5b0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ad5b0(longlong *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined1 auStack_488 [32];
  undefined4 local_468;
  int local_460;
  undefined8 local_458;
  undefined1 local_448 [1072];
  ulonglong local_18;
  
  local_458 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_488;
  iVar1 = FUN_140187740();
  iVar2 = FUN_140187bf0(param_1);
  iVar3 = FUN_140188040(param_1);
  iVar4 = FUN_140188440(param_1);
  iVar4 = iVar1 + iVar2 + iVar3 + iVar4;
  if (0 < iVar4) {
    uVar7 = FUN_140373ed0(param_1 + 0x1cf);
    if ((uVar7 & 1) == 0) {
      uVar5 = FUN_140373ed0(param_1 + 0x1cf);
      FUN_1401a6420(param_1,0x47,uVar5 | 3,1);
    }
    lVar8 = FUN_140008520((int)param_1[0x246]);
    lVar8 = *(longlong *)(lVar8 + 0x1c8);
    if (lVar8 == 0) {
      local_468 = 0x15d;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = 0;
    }
    FUN_1400d2660(lVar8,param_1,1,iVar4);
    lVar8 = FUN_140008520((int)param_1[0x246]);
    lVar8 = *(longlong *)(lVar8 + 0x1c8);
    if (lVar8 == 0) {
      local_468 = 0x15d;
      log_InlineLogERROR(&DAT_1406d9c10);
      lVar8 = 0;
    }
    FUN_1400d2b30(lVar8,param_1,2,iVar4);
  }
  FUN_14035f2f0(local_448);
  uVar6 = (**(code **)(*param_1 + 8))(param_1);
  local_468 = 0;
  local_460 = iVar4;
  iVar1 = FUN_14035f5f0(local_448,0x27,uVar6,0);
  if (iVar1 != 0) {
    (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_448);
  }
  FUN_14035f340(local_448);
  return;
}

// ==== CMsgInteract::helper_1401ade10  @1401ade10  [medium:callgraph-r0]  (orig: FUN_1401ade10)
/* WARNING: Function: __chkstk replaced with injection: alloca_probe */
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1401ade10(longlong *param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  ulong uVar8;
  uint uVar9;
  undefined4 uVar10;
  uint extraout_EAX;
  longlong *plVar11;
  longlong lVar12;
  longlong *plVar13;
  char *pcVar14;
  undefined4 extraout_var;
  undefined8 uVar15;
  IStringManager *pIVar16;
  undefined8 uVar17;
  uint uVar18;
  undefined1 auStack_15e8 [32];
  undefined8 local_15c8;
  char *local_15c0;
  uint local_15b8;
  char *local_15b0;
  char *local_15a8;
  uint local_15a0;
  uint local_1598;
  undefined4 local_1590;
  uint local_1588;
  uint local_1580;
  uint local_1578;
  uint local_1574;
  uint local_1570;
  uint local_156c;
  uint local_1568;
  int local_1564;
  longlong *local_1560;
  uint local_1558;
  uint local_1554;
  undefined4 local_1550;
  longlong *local_1548;
  undefined8 local_1540;
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_1538 [48];
  undefined4 local_1508;
  char local_1504 [60];
  uint local_14c8;
  char local_14c4 [254];
  undefined1 local_13c6;
  undefined4 local_13c4;
  undefined4 local_13c0;
  undefined4 local_13bc;
  undefined4 local_13b8;
  undefined4 local_13b4;
  undefined1 local_13b0;
  undefined1 local_13a8 [1072];
  char local_f78;
  undefined1 local_f77 [1022];
  undefined1 local_b79;
  char local_b78;
  undefined1 local_b77 [1022];
  undefined1 local_779;
  char local_778;
  undefined1 local_777 [1855];
  ulonglong local_38;
  undefined8 local_30;
  
  local_30 = 0x1401ade24;
  local_1540 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_15e8;
  if (*(char *)((longlong)param_1 + 0x12f4) != '\0') {
    local_b78 = '\0';
    local_1548 = param_1;
    memset(local_b77,0,0x3ff);
    local_15c8._0_4_ = (**(code **)(*param_1 + 8))(param_1);
    _snprintf(&local_b78,0x400,"SELECT * FROM %s WHERE roleid=%lu AND used=0","emoney_card_ndsdk");
    local_779 = 0;
    plVar11 = (longlong *)InstanceGet();
    plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&local_b78,2);
    if (plVar11 != (longlong *)0x0) {
      local_1560 = plVar11;
      lVar12 = (**(code **)(*plVar11 + 0x40))(plVar11);
      if (lVar12 == 0) {
        (**(code **)*plVar11)(plVar11);
      }
      else if (DAT_140975bb8 == 0) {
        local_15c8 = CONCAT44(local_15c8._4_4_,0x6b90);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pEmoneyCardCfg",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp"
                          );
      }
      else {
        std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
        basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1538,"");
        uVar9 = 0;
        local_1574 = 0;
        uVar18 = 0;
        local_1570 = 0;
        local_1564 = 0;
        while( true ) {
          iVar6 = local_1564;
          iVar2 = (**(code **)(*plVar11 + 0x40))(plVar11);
          if (iVar2 <= iVar6) break;
          (**(code **)(*plVar11 + 0x30))(plVar11,(longlong)iVar6);
          plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de8d4);
          local_1578 = (**(code **)(*plVar13 + 0x40))(plVar13);
          plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"ref_id");
          uVar3 = (**(code **)(*plVar13 + 0x40))(plVar13);
          plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"chk_sum");
          local_1558 = (**(code **)(*plVar13 + 0x50))(plVar13);
          plVar13 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,&DAT_1406de6d4);
          uVar4 = (**(code **)(*plVar13 + 0x50))(plVar13);
          plVar11 = (longlong *)(**(code **)(*plVar11 + 0x10))(plVar11,"itemcount");
          uVar5 = (**(code **)(*plVar11 + 0x48))(plVar11);
          local_1554 = uVar5;
          plVar11 = (longlong *)(**(code **)(*local_1560 + 0x10))(local_1560,"card_in_time");
          local_156c = (**(code **)(*plVar11 + 0x50))(plVar11);
          plVar11 = (longlong *)(**(code **)(*local_1560 + 0x10))(local_1560,&DAT_1406de8cc);
          local_1550 = (**(code **)(*plVar11 + 0x48))(plVar11);
          plVar11 = (longlong *)(**(code **)(*local_1560 + 0x10))(local_1560,"systemtype");
          local_1568 = (**(code **)(*plVar11 + 0x48))(plVar11);
          plVar11 = (longlong *)(**(code **)(*local_1560 + 0x10))(local_1560,"account_id");
          pcVar14 = (char *)(**(code **)(*plVar11 + 0x78))(plVar11);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::operator=
                    (local_1538,pcVar14);
          if ((uVar4 == 0) || ((int)uVar5 < 1)) {
            uVar7 = (**(code **)(*param_1 + 8))(param_1);
            local_15a8 = (char *)CONCAT44(local_15a8._4_4_,0x6bae);
            local_15b0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
            local_15c0 = (char *)CONCAT44(local_15c0._4_4_,uVar4);
            local_15b8 = uVar5;
            local_15c8._0_4_ = uVar3;
            log_InlineLogERROR("CUser::GetNDSDKCards failed. ID[%lu] User[%lu] CardInTime=%u, RefID=%lu, Type=%u, ItemCount=%d at %s, %d"
                               ,(ulonglong)local_1578,(ulonglong)uVar7,(ulonglong)local_156c);
          }
          else {
            iVar6 = FUN_140276390(DAT_140975bb8,(ulonglong)uVar4);
            uVar7 = local_156c;
            uVar18 = iVar6 * uVar5;
            local_1570 = uVar18;
            if (uVar18 == 0) {
              uVar7 = (**(code **)(*param_1 + 8))(param_1);
              local_15b8 = 0x6bb7;
              local_15c0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp"
              ;
              local_15c8._0_4_ = uVar5;
              log_InlineLogERROR("CUser::GetNDSDKCards, GetPointByCardType cannot find config. UserID[%lu] RefID[%lu] Type[%u] ItemCount[%d] at %s, %d"
                                 ,(ulonglong)uVar7,(ulonglong)uVar3,(ulonglong)uVar4);
            }
            else {
              uVar5 = tq::Calc91EmoneyCardChksum(local_156c,uVar3,uVar4);
              if (uVar5 == local_1558) {
                local_f78 = '\0';
                memset(local_f77,0,0x3ff);
                uVar8 = tq::TimeStampGet();
                uVar9 = tq::Calc91EmoneyCardChksum(uVar8,uVar3,uVar4);
                local_15c8._0_4_ = tq::TimeStampGet();
                local_15b8 = local_1578;
                local_15c0 = (char *)CONCAT44(local_15c0._4_4_,uVar9);
                _snprintf(&local_f78,0x400,
                          "UPDATE %s SET used=1, time_stamp=%u, chk_sum=%u WHERE id=%lu LIMIT 1",
                          "emoney_card_ndsdk");
                local_b79 = 0;
                FUN_140008520((int)param_1[0x246]);
                plVar11 = (longlong *)InstanceGet();
                cVar1 = (**(code **)(*plVar11 + 0x30))(plVar11,&local_f78,1);
                if (cVar1 == '\0') {
                  uVar9 = (**(code **)(*param_1 + 8))(param_1);
                  log_InlineLogERROR("CUser::GetNDSDKCards, UserID[%lu] UPDATE SQL[%s] fail",
                                     (ulonglong)uVar9,&local_f78);
                  uVar9 = local_1574;
                }
                else {
                  uVar10 = (**(code **)(*param_1 + 8))(param_1);
                  local_15c8 = CONCAT44(local_15c8._4_4_,uVar18);
                  FUN_1401742b0(param_1,6,uVar3,uVar10);
                  lVar12 = param_1[0x1e2];
                  (**(code **)(param_1[2] + 0x18))();
                  uVar9 = (**(code **)(*param_1 + 8))(param_1);
                  local_1588 = local_1568;
                  local_1590 = local_1550;
                  local_1598 = local_1554;
                  local_15a8 = (char *)CONCAT44(local_15a8._4_4_,uVar3);
                  local_15b0 = (char *)CONCAT44(local_15b0._4_4_,local_156c);
                  local_15b8 = local_1578;
                  local_15c0 = (char *)CONCAT44(local_15c0._4_4_,(int)lVar12);
                  local_15a0 = uVar4;
                  local_1580 = uVar18;
                  local_15c8._0_4_ = extraout_EAX;
                  local_15c8._4_4_ = extraout_var;
                  tq::MyLogSave("gmlog/NDSDKPayments",
                                "checkout %s UserID[%lu] UserName[%s] AccountID[%lu] CardID[%lu] CardInTime[%u] RefID[%lu] Type[%d] ItemCount[%d] Flag[%d] SystemType[%d] Price[%u]"
                                ,"emoney_card_ndsdk",(ulonglong)uVar9);
                  uVar15 = FUN_140008520((int)param_1[0x246]);
                  cVar1 = FUN_14008a710(uVar15);
                  if (cVar1 != '\0') {
                    local_778 = '\0';
                    memset(local_777,0,0x73f);
                    local_15c8._0_4_ = *(uint *)(param_1 + 0x1e2);
                    local_15c0 = (char *)CONCAT44(local_15c0._4_4_,(int)param_1[0x25e]);
                    local_15b8 = uVar18;
                    _snprintf(&local_778,0x73f,"[card]: %d, %lu, %d, %u",(ulonglong)local_1568);
                    tq::log_Save("gmlog/Card",&local_778,5);
                  }
                  uVar9 = local_1574 + uVar18;
                  local_1574 = uVar9;
                }
              }
              else {
                uVar5 = (**(code **)(*param_1 + 8))(param_1);
                local_15a0 = 0x6bbe;
                local_15a8 = 
                "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\user.cpp";
                local_15b0 = (char *)CONCAT44(local_15b0._4_4_,local_1558);
                local_15c0 = (char *)CONCAT44(local_15c0._4_4_,uVar3);
                local_15c8._0_4_ = uVar7;
                local_15b8 = uVar4;
                log_InlineLogERROR("CUser::GetNDSDKCards Check %s chksum failed. ID[%lu] UserID[%lu] CardInTime[%u] RefID[%lu] Type[%u] Chksum[%u] at %s, %d"
                                   ,"emoney_card_ndsdk",(ulonglong)local_1578,(ulonglong)uVar5);
              }
            }
          }
          local_1564 = local_1564 + 1;
          plVar11 = local_1560;
        }
        (**(code **)*plVar11)(plVar11);
        uVar15 = 0;
        if (uVar9 == 0) {
          uVar9 = (**(code **)(*param_1 + 8))(param_1);
          log_InlineLogERROR("CUser::GetNDSDKCards, UserID[%lu] unToalEmoney <= 0",(ulonglong)uVar9)
          ;
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1538);
        }
        else {
          local_15c8 = 0;
          (**(code **)(param_1[2] + 0x2e0))(param_1 + 2,0x1d,uVar18,1);
          FUN_14035f2f0(local_13a8);
          uVar10 = (**(code **)(*param_1 + 8))(param_1);
          local_15c0 = (char *)CONCAT44(local_15c0._4_4_,uVar9);
          local_15c8 = local_15c8 & 0xffffffff00000000;
          iVar6 = FUN_14035f5f0(local_13a8,0x27,uVar10,2);
          if (iVar6 != 0) {
            (**(code **)(param_1[2] + 0x350))(param_1 + 2,local_13a8);
          }
          FUN_140175810(param_1,uVar9);
          cVar1 = FUN_1401620f0(param_1,1);
          if (cVar1 == '\0') {
            uVar18 = FUN_140373ed0(param_1 + 0x1cf);
            FUN_1401a6420(param_1,0x47,uVar18 | 3,1);
          }
          lVar12 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar12 + 0x1c8) == 0) {
            local_15c8 = CONCAT44(local_15c8._4_4_,0x15d);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOperatingActMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
            uVar17 = uVar15;
          }
          else {
            uVar17 = *(undefined8 *)(lVar12 + 0x1c8);
          }
          FUN_1400d2660(uVar17,param_1,1,uVar9);
          lVar12 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar12 + 0x1c8) == 0) {
            local_15c8 = CONCAT44(local_15c8._4_4_,0x15d);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pOperatingActMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
            uVar17 = uVar15;
          }
          else {
            uVar17 = *(undefined8 *)(lVar12 + 0x1c8);
          }
          FUN_1400d2b30(uVar17,param_1,2,uVar9);
          local_1508 = 0;
          local_1504[0] = '\0';
          local_1504[1] = '\0';
          local_1504[2] = '\0';
          local_1504[3] = '\0';
          local_1504[4] = '\0';
          local_1504[5] = '\0';
          local_1504[6] = '\0';
          local_1504[7] = '\0';
          local_1504[8] = '\0';
          local_1504[9] = '\0';
          local_1504[10] = '\0';
          local_1504[0xb] = '\0';
          local_1504[0xc] = '\0';
          local_1504[0xd] = '\0';
          local_1504[0xe] = '\0';
          local_1504[0xf] = '\0';
          local_1504[0x10] = '\0';
          local_1504[0x11] = '\0';
          local_1504[0x12] = '\0';
          local_1504[0x13] = '\0';
          local_1504[0x14] = '\0';
          local_1504[0x15] = '\0';
          local_1504[0x16] = '\0';
          local_1504[0x17] = '\0';
          local_1504[0x18] = '\0';
          local_1504[0x19] = '\0';
          local_1504[0x1a] = '\0';
          local_1504[0x1b] = '\0';
          local_1504[0x1c] = '\0';
          local_1504[0x1d] = '\0';
          local_1504[0x1e] = '\0';
          local_1504[0x1f] = '\0';
          local_1504[0x20] = '\0';
          local_1504[0x21] = '\0';
          local_1504[0x22] = '\0';
          local_1504[0x23] = '\0';
          local_1504[0x24] = '\0';
          local_1504[0x25] = '\0';
          local_1504[0x26] = '\0';
          local_1504[0x27] = '\0';
          local_1504[0x28] = '\0';
          local_1504[0x29] = '\0';
          local_1504[0x2a] = '\0';
          local_1504[0x2b] = '\0';
          local_1504[0x2c] = '\0';
          local_1504[0x2d] = '\0';
          local_1504[0x2e] = '\0';
          local_1504[0x2f] = '\0';
          local_1504[0x30] = '\0';
          local_1504[0x31] = '\0';
          local_1504[0x32] = '\0';
          local_1504[0x33] = '\0';
          local_1504[0x34] = '\0';
          local_1504[0x35] = '\0';
          local_1504[0x36] = '\0';
          local_1504[0x37] = '\0';
          local_1504[0x38] = '\0';
          local_1504[0x39] = '\0';
          local_1504[0x3a] = '\0';
          local_1504[0x3b] = '\0';
          local_14c8 = 0;
          memset(local_14c4,0,0xff);
          local_13c4 = 0;
          local_13c0 = 0;
          local_13bc = 0;
          local_13b8 = 0;
          local_13b4 = 0x1e;
          local_13b0 = 0;
          local_1508 = (**(code **)(*param_1 + 8))(param_1);
          local_13b4 = 0x1e;
          pIVar16 = theInstance();
          pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar16)(pIVar16,"STR_RECHARGE_CENTER_NAME");
          strncpy(local_1504,pcVar14,0x10);
          pIVar16 = theInstance();
          pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar16)
                                      (pIVar16,"STR_RECHARGE_SUCCESS_TITLE");
          _snprintf(local_1504 + 0x20,0x20,pcVar14);
          local_14c8 = local_14c8 & 0xffffff;
          pIVar16 = theInstance();
          pcVar14 = (char *)(*(code *)**(undefined8 **)pIVar16)
                                      (pIVar16,"STR_RECHARGE_SUCCESS_CONTENT");
          _snprintf(local_14c4,0xff,pcVar14,(ulonglong)uVar9);
          local_13c6 = 0;
          lVar12 = FUN_140008520((int)param_1[0x246]);
          if (*(longlong *)(lVar12 + 0x180) == 0) {
            local_15c8 = CONCAT44(local_15c8._4_4_,0x153);
            log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pMailMgr",
                               "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                              );
          }
          else {
            uVar15 = *(undefined8 *)(lVar12 + 0x180);
          }
          FUN_1400df9c0(uVar15,&local_1508);
          *(undefined1 *)((longlong)param_1 + 0x12f4) = 0;
          FUN_14035f340(local_13a8);
          std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
          ~basic_string<char,std::char_traits<char>,std::allocator<char>_>(local_1538);
        }
      }
    }
  }
  return;
}

// ==== CMsgInteract::helper_1401b1500  @1401b1500  [medium:callgraph-r0]  (orig: FUN_1401b1500)
void FUN_1401b1500(longlong param_1,undefined4 param_2)

{
  undefined4 local_res10 [6];
  
  local_res10[0] = param_2;
  FUN_14000f0a0(param_1 + 0x3c0,local_res10);
  return;
}

// ==== CMsgInteract::helper_1401d3b50  @1401d3b50  [medium:callgraph-r3]  (orig: FUN_1401d3b50)
undefined8 * FUN_1401d3b50(undefined8 *param_1,undefined8 *param_2,undefined8 *param_3)

{
  for (; param_1 != param_2; param_1 = param_1 + 1) {
    if (param_3 != (undefined8 *)0x0) {
      *param_3 = *param_1;
    }
    param_3 = param_3 + 1;
  }
  return param_3;
}

// ==== CMsgInteract::helper_1401d42b0  @1401d42b0  [medium:callgraph-r1]  (orig: FUN_1401d42b0)
void FUN_1401d42b0(undefined8 *param_1,longlong param_2,undefined8 *param_3)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    if (param_1 != (undefined8 *)0x0) {
      *param_1 = *param_3;
    }
    param_1 = param_1 + 1;
  }
  return;
}

// ==== CMsgInteract::helper_1401d55f0  @1401d55f0  [medium:callgraph-r3]  (orig: FUN_1401d55f0)
longlong FUN_1401d55f0(longlong param_1,longlong param_2,longlong param_3)

{
  undefined8 *puVar1;
  ulonglong uVar2;
  longlong lVar3;
  
  uVar2 = param_2 - param_1;
  if (param_1 != param_2) {
    lVar3 = param_3 - param_2;
    do {
      puVar1 = (undefined8 *)(param_2 + -8);
      param_2 = param_2 + -8;
      *(undefined8 *)(lVar3 + param_2) = *puVar1;
    } while (param_2 != param_1);
  }
  return param_3 - (uVar2 & 0xfffffffffffffff8);
}

// ==== CMsgInteract::helper_1401d7190  @1401d7190  [medium:callgraph-r2]  (orig: FUN_1401d7190)
void FUN_1401d7190(longlong param_1,longlong param_2,ulonglong param_3,longlong *param_4)

{
  void *pvVar1;
  undefined1 uVar2;
  longlong lVar3;
  longlong *plVar4;
  undefined8 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  ulonglong uVar9;
  longlong *plVar10;
  longlong local_res8;
  
  lVar6 = *(longlong *)(param_1 + 0x18);
  if (lVar6 == 0) {
    uVar7 = 0;
  }
  else {
    uVar7 = *(longlong *)(param_1 + 0x28) - lVar6 >> 3;
  }
  if (param_3 != 0) {
    lVar3 = *(longlong *)(param_1 + 0x20);
    lVar6 = lVar3 - lVar6 >> 3;
    if (0x1fffffffffffffffU - lVar6 < param_3) {
                    /* WARNING: Subroutine does not return */
      FUN_140169d60();
    }
    uVar9 = param_3 + lVar6;
    if (uVar7 < uVar9) {
      if (0x1fffffffffffffff - (uVar7 >> 1) < uVar7) {
        uVar7 = 0;
      }
      else {
        uVar7 = uVar7 + (uVar7 >> 1);
      }
      if (uVar7 < uVar9) {
        uVar7 = uVar9;
      }
      lVar3 = FUN_14017cd20(param_1 + 0x10,uVar7);
      lVar6 = *(longlong *)(param_2 + 8) - *(longlong *)(param_1 + 0x18) >> 3;
      local_res8._0_1_ = (undefined1)lVar3;
      uVar2 = (undefined1)local_res8;
      local_res8 = lVar3;
      FUN_1401d42b0(lVar3 + lVar6 * 8,param_3,param_4,param_1 + 0x10,uVar2,0);
      FUN_1401d3b50(*(undefined8 *)(param_1 + 0x18),*(undefined8 *)(param_2 + 8),lVar3,
                    param_1 + 0x10,(undefined1)local_res8,0,1);
      FUN_1401d3b50(*(undefined8 *)(param_2 + 8),*(undefined8 *)(param_1 + 0x20),
                    lVar3 + (lVar6 + param_3) * 8,param_1 + 0x10,(undefined1)local_res8,0,2);
      pvVar1 = *(void **)(param_1 + 0x18);
      lVar6 = *(longlong *)(param_1 + 0x20);
      if (pvVar1 != (void *)0x0) {
        operator_delete(pvVar1);
      }
      *(ulonglong *)(param_1 + 0x28) = lVar3 + uVar7 * 8;
      *(ulonglong *)(param_1 + 0x20) = lVar3 + (param_3 + (lVar6 - (longlong)pvVar1 >> 3)) * 8;
      *(longlong *)(param_1 + 0x18) = lVar3;
    }
    else if ((ulonglong)(lVar3 - *(longlong *)(param_2 + 8) >> 3) < param_3) {
      lVar6 = *param_4;
      local_res8._0_1_ = (undefined1)lVar6;
      uVar2 = (undefined1)local_res8;
      local_res8 = lVar6;
      FUN_1401d3b50(*(longlong *)(param_2 + 8),lVar3,*(longlong *)(param_2 + 8) + param_3 * 8,
                    param_1 + 0x10,uVar2,0);
      FUN_1401d42b0(*(longlong *)(param_1 + 0x20),
                    param_3 - (*(longlong *)(param_1 + 0x20) - *(longlong *)(param_2 + 8) >> 3),
                    &local_res8,param_1 + 0x10,(undefined1)local_res8,0);
      *(longlong *)(param_1 + 0x20) = *(longlong *)(param_1 + 0x20) + param_3 * 8;
      lVar3 = *(longlong *)(param_1 + 0x20);
      for (plVar4 = *(longlong **)(param_2 + 8); plVar4 != (longlong *)(lVar3 + param_3 * -8);
          plVar4 = plVar4 + 1) {
        *plVar4 = lVar6;
      }
    }
    else {
      lVar6 = *param_4;
      lVar8 = lVar3 + param_3 * -8;
      uVar5 = FUN_1401d3b50(lVar8,lVar3,lVar3,param_1 + 0x10);
      *(undefined8 *)(param_1 + 0x20) = uVar5;
      FUN_1401d55f0(*(undefined8 *)(param_2 + 8),lVar8,lVar3);
      plVar10 = *(longlong **)(param_2 + 8);
      plVar4 = plVar10 + param_3;
      for (; plVar10 != plVar4; plVar10 = plVar10 + 1) {
        *plVar10 = lVar6;
      }
    }
  }
  return;
}

// ==== CMsgInteract::helper_1401d7cf0  @1401d7cf0  [medium:callgraph-r1]  (orig: FUN_1401d7cf0)
longlong * FUN_1401d7cf0(longlong *param_1,longlong *param_2,longlong *param_3,undefined8 param_4)

{
  ulonglong uVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *local_28;
  ulonglong uStack_20;
  
  lVar2 = 0;
  uVar1 = param_1[3];
  lVar3 = lVar2;
  if ((param_1[4] - uVar1 & 0xfffffffffffffff8) != 0) {
    if ((ulonglong)param_1[4] < uVar1) {
      _invalid_parameter_noinfo();
    }
    if ((*param_3 == 0) || (*param_3 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    lVar3 = (longlong)(param_3[1] - uVar1) >> 3;
  }
  local_28 = (longlong *)*param_3;
  uStack_20 = param_3[1];
  FUN_1401d7190(param_1,&local_28,1,param_4);
  uVar1 = param_1[3];
  if ((ulonglong)param_1[4] < uVar1) {
    _invalid_parameter_noinfo();
  }
  param_1 = (longlong *)*param_1;
  local_28 = param_1;
  uStack_20 = uVar1;
  if (param_1 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar4 = lVar2;
  }
  else {
    lVar4 = *param_1;
  }
  uVar1 = uVar1 + lVar3 * 8;
  if (uVar1 <= *(ulonglong *)(lVar4 + 0x20)) {
    if (param_1 != (longlong *)0x0) {
      lVar2 = *param_1;
    }
    if (*(ulonglong *)(lVar2 + 0x18) <= uVar1) goto LAB_1401d7de4;
  }
  _invalid_parameter_noinfo();
LAB_1401d7de4:
  *param_2 = (longlong)local_28;
  param_2[1] = uVar1;
  return param_2;
}

// ==== CMsgInteract::helper_1401d8190  @1401d8190  [medium:callgraph-r0]  (orig: FUN_1401d8190)
void FUN_1401d8190(undefined8 *param_1,undefined8 param_2)

{
  ulonglong uVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 local_28;
  ulonglong uStack_20;
  undefined1 local_18 [16];
  
  uVar1 = param_1[3];
  if (uVar1 == 0) {
    uVar3 = 0;
  }
  else {
    uVar3 = (longlong)(param_1[5] - uVar1) >> 3;
  }
  uVar2 = param_1[4];
  if ((ulonglong)((longlong)(uVar2 - uVar1) >> 3) < uVar3) {
    FUN_1401d42b0(uVar2,1,param_2,param_1 + 2);
    param_1[4] = uVar2 + 8;
    return;
  }
  if (uVar2 < uVar1) {
    _invalid_parameter_noinfo();
  }
  local_28 = *param_1;
  uStack_20 = uVar2;
  FUN_1401d7cf0(param_1,local_18,&local_28,param_2);
  return;
}

// ==== CMsgInteract::helper_1402c5ed0  @1402c5ed0  [medium:callgraph-r0]  (orig: FUN_1402c5ed0)
undefined8 FUN_1402c5ed0(longlong param_1)

{
  longlong *plVar1;
  ulonglong uVar2;
  undefined8 uVar3;
  
  plVar1 = *(longlong **)(*(longlong *)(param_1 + 0x58) + 8);
  plVar1 = (longlong *)(**(code **)(*plVar1 + 0x10))(plVar1,4);
  uVar2 = (**(code **)(*plVar1 + 0x58))(plVar1);
  if (((uVar2 >> 0x17 & 1) != 0) && (*(longlong *)(param_1 + 0x68) != 0)) {
    uVar3 = FUN_1403955a0();
    return uVar3;
  }
  return CONCAT71((uint7)(uVar2 >> 0x1f),1);
}

// ==== CMsgInteract::helper_1402c7750  @1402c7750  [medium:callgraph-r0]  (orig: FUN_1402c7750)
longlong FUN_1402c7750(longlong *param_1,int param_2,int param_3)

{
  int iVar1;
  longlong lVar2;
  
  if (-1 < param_2) {
    iVar1 = (**(code **)(*(longlong *)param_1[0xc] + 0x28))();
    if ((param_2 < iVar1) && (-1 < param_3)) {
      iVar1 = (**(code **)(*(longlong *)param_1[0xc] + 0x20))();
      if (param_3 < iVar1) {
        if ((ulonglong)((param_1[7] - param_1[6]) / 0x30) <= (ulonglong)(longlong)(param_2 / 0x12))
        {
          _invalid_parameter_noinfo();
        }
        lVar2 = (longlong)(param_2 / 0x12) * 0x30 + param_1[6];
        if ((ulonglong)((*(longlong *)(lVar2 + 0x20) - *(longlong *)(lVar2 + 0x18)) / 0x18) <=
            (ulonglong)(longlong)(param_3 / 0x12)) {
          _invalid_parameter_noinfo();
        }
        return *(longlong *)(lVar2 + 0x18) + (longlong)(param_3 / 0x12) * 0x18;
      }
    }
  }
  (**(code **)(*param_1 + 8))(param_1);
  log_InlineLogERROR("CGameMap::QueryBlock: map = %u, x=%d, y =%d is invalid");
  return 0;
}

// ==== CMsgInteract::helper_1402f2460  @1402f2460  [medium:callgraph-r0]  (orig: FUN_1402f2460)
void FUN_1402f2460(void)

{
  longlong lVar1;
  
  lVar1 = FUN_1402f1610();
  if (lVar1 == 0) {
    return;
  }
  FUN_14048c970(lVar1);
  return;
}

// ==== CMsgInteract::helper_1402f3a20  @1402f3a20  [medium:callgraph-r1]  (orig: FUN_1402f3a20)
undefined8 FUN_1402f3a20(void)

{
  longlong lVar1;
  undefined8 uVar2;
  
  lVar1 = FUN_1402f1610();
  if (lVar1 != 0) {
    uVar2 = FUN_14048bc30(lVar1);
    return uVar2;
  }
  return 0;
}

// ==== CMsgInteract::helper_1402f3a80  @1402f3a80  [medium:callgraph-r0]  (orig: FUN_1402f3a80)
void FUN_1402f3a80(longlong param_1,undefined4 param_2,uint param_3)

{
  uint *puVar1;
  undefined4 local_res10 [6];
  undefined1 local_28 [32];
  
  local_res10[0] = param_2;
  puVar1 = (uint *)FUN_1400ea580(param_1 + 0x48,local_res10);
  *puVar1 = *puVar1 + param_3;
  puVar1[1] = puVar1[1] + 1;
  if (puVar1[2] < param_3) {
    puVar1[2] = param_3;
  }
  if ((0x32 < param_3) || (10000 < *puVar1)) {
    FUN_14000d480(param_1 + 8,local_28,local_res10);
  }
  return;
}

// ==== CMsgInteract::ctor_or_dtor  @14035f2f0  [high:vtable-assign]  (orig: FUN_14035f2f0)
undefined8 * FUN_14035f2f0(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgInteract::vftable;
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  return param_1;
}

// ==== CMsgInteract::ctor_or_dtor  @14035f340  [high:vtable-assign]  (orig: FUN_14035f340)
void FUN_14035f340(undefined8 *param_1)

{
  *param_1 = CMsgInteract::vftable;
  FUN_1402b55f0();
  return;
}

// ==== CMsgInteract::vfunc_1  @14035f370  [high:rtti-vtable]  (orig: FUN_14035f370)
ulonglong FUN_14035f370(longlong param_1)

{
  ulonglong uVar1;
  
  uVar1 = FUN_1402b5640();
  if ((int)uVar1 == 0) {
    return uVar1;
  }
  return (ulonglong)(*(int *)(param_1 + 8) == 0x3fe);
}

// ==== CMsgInteract::helper_14035f930  @14035f930  [medium:callgraph-r1]  (orig: FUN_14035f930)
void FUN_14035f930(longlong param_1,undefined4 param_2)

{
  *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x1c) = param_2;
  return;
}

// ==== CMsgInteract::ctor_or_dtor  @14035f970  [high:vtable-assign]  (orig: FUN_14035f970)
undefined8 * FUN_14035f970(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgInteract::vftable;
  FUN_1402b55f0();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgInteract::vfunc_3  @14035f9c0  [high:rtti-vtable]  (orig: FUN_14035f9c0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */
/* WARNING: Type propagation algorithm not settling */

void FUN_14035f9c0(longlong *param_1)

{
  short sVar1;
  ushort uVar2;
  undefined4 *puVar3;
  longlong lVar4;
  char cVar5;
  undefined2 uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  int iVar12;
  ulong uVar13;
  uint uVar14;
  uint uVar15;
  ulong uVar16;
  undefined4 uVar17;
  longlong lVar18;
  longlong *plVar19;
  undefined8 uVar20;
  longlong *plVar21;
  IStringManager *pIVar22;
  ulonglong uVar23;
  longlong *plVar24;
  longlong *plVar25;
  ulonglong uVar26;
  int *piVar27;
  int *piVar28;
  int *piVar29;
  longlong *plVar30;
  undefined1 auStack_5c8 [32];
  longlong **local_5a8;
  undefined2 local_5a0;
  undefined4 local_598;
  undefined4 local_590;
  undefined4 local_588;
  undefined4 local_580;
  longlong *local_578;
  char local_570;
  longlong *local_568;
  longlong *local_560;
  undefined8 local_558;
  undefined8 local_550;
  undefined8 local_548;
  undefined4 local_540;
  longlong local_538;
  uint local_530;
  longlong *local_528 [3];
  int *local_510;
  int *local_508;
  undefined8 local_500;
  longlong *local_4f8;
  undefined8 local_4f0;
  longlong *local_4e8;
  longlong *local_4e0;
  longlong *local_4d8;
  longlong *local_4d0 [3];
  void *local_4b8;
  longlong local_4b0;
  undefined8 local_4a8;
  longlong *local_4a0;
  longlong *local_498;
  ulonglong local_488;
  undefined8 local_480;
  longlong *local_478;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_480 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_5c8;
  local_4f8 = param_1;
  local_4d8 = param_1;
  lVar18 = FUN_140008520((int)param_1[0x82]);
  if (*(longlong *)(lVar18 + 0x88) == 0) {
    local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x12f);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  plVar19 = (longlong *)
            (**(code **)(**(longlong **)(lVar18 + 0x88) + 0x18))
                      (*(longlong **)(lVar18 + 0x88),param_1,*(undefined4 *)(param_1[0x85] + 8));
  if (plVar19 == (longlong *)0x0) {
    return;
  }
  plVar30 = (longlong *)0x0;
  local_4f0 = 0;
  local_568 = plVar19;
  cVar5 = (**(code **)(*plVar19 + 0x298))(plVar19,0x1002,&local_4f0);
  if ((cVar5 != '\0') && (cVar5 = FUN_140388010(local_4f0,2), cVar5 != '\0')) {
    return;
  }
  uVar20 = FUN_140008520((int)param_1[0x82]);
  plVar21 = (longlong *)FUN_1400875f0(uVar20);
  plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,*(undefined4 *)(param_1[0x85] + 0xc))
  ;
  if ((((plVar21 == (longlong *)0x0) && (sVar1 = *(short *)(param_1[0x85] + 0x14), sVar1 != 0x18))
      && (sVar1 != 0x24)) && (sVar1 != 0x2c)) {
    return;
  }
  local_538 = 0;
  local_4e0 = plVar21;
  if (((plVar21 != (longlong *)0x0) &&
      (cVar5 = (**(code **)(*plVar21 + 0x298))(plVar21,0x1001,&local_538), cVar5 != '\0')) &&
     ((iVar7 = FUN_140175470(local_538), iVar7 != 0 &&
      (iVar7 = FUN_140164ee0(local_538), iVar7 == 0)))) {
    return;
  }
  local_578 = (longlong *)0x0;
  (**(code **)(*plVar19 + 0x298))(plVar19,0x1001,&local_578);
  if (local_578 != (longlong *)0x0) {
    plVar19 = (longlong *)FUN_1400e1e60();
    lVar4 = local_578[0x1e2];
    lVar18 = *plVar19;
    puVar3 = (undefined4 *)param_1[0x85];
    uVar8 = (**(code **)(*local_578 + 8))();
    (**(code **)(lVar18 + 0x108))(plVar19,uVar8,(int)lVar4,*puVar3);
    uVar20 = FUN_140008520((int)param_1[0x82]);
    cVar5 = FUN_14008b170(uVar20);
    if (cVar5 == '\0') {
      if ((local_538 != 0) && (cVar5 = FUN_140167b70(), cVar5 != '\0')) {
        return;
      }
      cVar5 = FUN_140167b70(local_578);
      if (cVar5 != '\0') {
        return;
      }
    }
    cVar5 = FUN_140167b70(local_578);
    if ((((cVar5 != '\0') && (sVar1 = *(short *)(param_1[0x85] + 0x14), sVar1 != 2)) &&
        (sVar1 != 0x18)) && ((sVar1 != 0x1c && (sVar1 != 0x2c)))) {
      return;
    }
    plVar19 = local_568;
    if (local_578 != (longlong *)0x0) {
      cVar5 = (**(code **)(local_578[2] + 0x220))();
      if (cVar5 == '\0') {
        pIVar22 = theInstance();
        lVar18 = local_578[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_DIE");
        (**(code **)(lVar18 + 0x358))(local_578 + 2,uVar20);
        return;
      }
      plVar19 = local_568;
      if (local_578 != (longlong *)0x0) {
        cVar5 = FUN_140168ad0();
        if (cVar5 != '\0') {
          FUN_14017b240(local_578,0,0);
        }
        plVar19 = local_568;
        if (local_578 != (longlong *)0x0) {
          if (*(short *)(param_1[0x85] + 0x14) != 0x18) {
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x33);
            if (cVar5 != '\0') {
              return;
            }
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x37);
            if (cVar5 != '\0') {
              return;
            }
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x38);
            if (cVar5 != '\0') {
              return;
            }
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x39);
            if (cVar5 != '\0') {
              return;
            }
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x18);
            if (cVar5 != '\0') {
              return;
            }
            cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x6e);
            if (cVar5 != '\0') {
              return;
            }
          }
          cVar5 = FUN_14016e3f0(local_578);
          if (cVar5 == '\0') {
            (**(code **)(local_578[2] + 0x2c0))(local_578 + 2,100);
            plVar19 = local_568;
          }
          else {
            iVar7 = (**(code **)(local_578[2] + 0x60))();
            if (iVar7 == 0x186a8) {
              (**(code **)(local_578[2] + 0x2c0))(local_578 + 2,0x186a4,0);
              plVar19 = local_568;
            }
            else {
              iVar7 = (**(code **)(local_578[2] + 0x60))();
              plVar19 = local_568;
              if (iVar7 == 0x186a9) {
                (**(code **)(local_578[2] + 0x2c0))(local_578 + 2,0x186a7,0);
                plVar19 = local_568;
              }
            }
          }
        }
      }
    }
  }
  uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
  *(undefined4 *)(param_1[0x85] + 8) = uVar8;
  (**(code **)(*plVar19 + 0x380))(plVar19);
  lVar18 = param_1[0x85];
  uVar14 = 0;
  switch(*(undefined2 *)(lVar18 + 0x14)) {
  case 2:
  case 0x1c:
    if (local_578 == (longlong *)0x0) goto LAB_140360926;
    iVar7 = (**(code **)(*local_578 + 8))();
    if (iVar7 == *(int *)(param_1[0x85] + 0xc)) {
      uVar20 = FUN_140008520((int)param_1[0x82]);
      plVar19 = (longlong *)FUN_140087650(uVar20);
      (**(code **)(*plVar19 + 0x50))(plVar19,local_578,"attack target is self");
      return;
    }
    lVar18 = (**(code **)(local_578[2] + 0x160))();
    if ((lVar18 != 0) && (cVar5 = FUN_1402c5ed0(lVar18), cVar5 == '\0')) {
      return;
    }
    plVar19 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
    plVar19 = (longlong *)(**(code **)(*plVar19 + 0x10))(plVar19,4);
    uVar23 = (**(code **)(*plVar19 + 0x58))(plVar19);
    if ((uVar23 >> 0x19 & 1) != 0) {
      pIVar22 = theInstance();
      lVar18 = local_578[2];
      uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_PK_FORBIDDEN");
      (**(code **)(lVar18 + 0x358))(local_578 + 2,uVar20);
      return;
    }
    plVar19 = (longlong *)CurrentInstanceGet();
    if ((plVar19 != (longlong *)0x0) && (cVar5 = FUN_14011dbb0(lVar18), cVar5 != '\0')) {
      plVar24 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,4);
      if (plVar24 != (longlong *)0x0) {
        plVar25 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
        plVar25 = (longlong *)(**(code **)(*plVar25 + 0x10))(plVar25,4);
        uVar23 = (**(code **)(*plVar25 + 0x58))(plVar25);
        if ((uVar23 >> 0x15 & 1) != 0) {
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0x100))(plVar24,uVar8);
          if (cVar5 != '\0') {
            return;
          }
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0x108))(plVar24,uVar8);
          if (cVar5 != '\0') {
            return;
          }
        }
      }
      plVar24 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,0x22);
      local_560 = plVar24;
      if (plVar24 != (longlong *)0x0) {
        plVar25 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
        plVar25 = (longlong *)(**(code **)(*plVar25 + 0x10))(plVar25,4);
        uVar23 = (**(code **)(*plVar25 + 0x58))(plVar25);
        if (((uVar23 >> 0x25 & 1) != 0) && (plVar21 != (longlong *)0x0)) {
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*plVar21 + 0x10))(plVar21);
          uVar17 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0x148))(local_560,uVar17,uVar8);
          if (cVar5 == '\0') {
            return;
          }
        }
      }
      plVar24 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,0x19);
      if (plVar24 != (longlong *)0x0) {
        plVar25 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
        plVar25 = (longlong *)(**(code **)(*plVar25 + 0x10))(plVar25,4);
        uVar23 = (**(code **)(*plVar25 + 0x58))(plVar25);
        if ((uVar23 >> 0x1d & 1) != 0) {
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0x98))(plVar24,uVar8);
          if (cVar5 != '\0') {
            return;
          }
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0xa0))(plVar24,uVar8);
          if (cVar5 != '\0') {
            return;
          }
        }
      }
      plVar24 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,0x21);
      local_560 = plVar24;
      if (plVar24 != (longlong *)0x0) {
        plVar25 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
        plVar25 = (longlong *)(**(code **)(*plVar25 + 0x10))(plVar25,4);
        uVar23 = (**(code **)(*plVar25 + 0x58))(plVar25);
        if (((uVar23 >> 0x20 & 1) != 0) && (plVar21 != (longlong *)0x0)) {
          lVar4 = *plVar24;
          uVar8 = (**(code **)(*plVar21 + 0x10))(plVar21);
          uVar17 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar4 + 0x110))(local_560,uVar17,uVar8);
          if (cVar5 == '\0') {
            return;
          }
        }
      }
      plVar19 = (longlong *)(**(code **)(*plVar19 + 0x20))(plVar19,0x24);
      if (plVar19 != (longlong *)0x0) {
        plVar24 = *(longlong **)(*(longlong *)(lVar18 + 0x58) + 8);
        plVar24 = (longlong *)(**(code **)(*plVar24 + 0x10))(plVar24,4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if (((uVar23 >> 0x27 & 1) != 0) && (plVar21 != (longlong *)0x0)) {
          lVar18 = *plVar19;
          uVar8 = (**(code **)(*plVar21 + 0x10))(plVar21);
          uVar17 = (**(code **)(*local_578 + 8))();
          cVar5 = (**(code **)(lVar18 + 0x110))(plVar19,uVar17,uVar8);
          if (cVar5 == '\0') {
            return;
          }
        }
      }
    }
    cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x5b);
    if (cVar5 != '\0') {
      return;
    }
    cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x75);
    if (cVar5 != '\0') {
      return;
    }
    lVar18 = (**(code **)(local_578[2] + 0x160))();
    if (lVar18 != 0) {
      uVar20 = (**(code **)(local_578[2] + 0x160))();
      cVar5 = FUN_14011dbb0(uVar20);
      if ((cVar5 != '\0') && (cVar5 = (**(code **)(local_578[2] + 0x280))(), cVar5 != '\0')) {
        return;
      }
      if (plVar21 != (longlong *)0x0) {
        uVar20 = (**(code **)(*plVar21 + 0x160))(plVar21);
        cVar5 = FUN_14011dbb0(uVar20);
        if ((cVar5 != '\0') && (cVar5 = (**(code **)(*plVar21 + 0x280))(plVar21), cVar5 != '\0')) {
          return;
        }
      }
    }
    uVar8 = 8;
    local_540 = 8;
    local_570 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x28);
    if (((local_570 != '\0') && (plVar21 != (longlong *)0x0)) &&
       (cVar5 = (**(code **)(*plVar21 + 0x240))(plVar21), cVar5 != '\0')) {
      lVar18 = local_578[2];
      uVar8 = (**(code **)(*plVar21 + 0x48))(plVar21);
      uVar17 = (**(code **)(*plVar21 + 0x40))(plVar21);
      iVar7 = (**(code **)(lVar18 + 0x158))(local_578 + 2,uVar17,uVar8);
      iVar9 = FUN_1401615a0(local_578);
      uVar8 = 8;
      local_540 = 8;
      if (iVar7 <= iVar9) {
        uVar8 = 0x19;
        local_540 = 0x19;
      }
    }
    cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x82);
    if (cVar5 != '\0') {
      uVar8 = 0x19;
    }
    local_540 = uVar8;
    cVar5 = FUN_140160530(local_578,*(undefined2 *)(param_1[0x85] + 0x10),
                          *(undefined2 *)(param_1[0x85] + 0x12),uVar8);
    if (cVar5 == '\0') {
      return;
    }
    plVar19 = (longlong *)FUN_1401181a0();
    lVar18 = *plVar19;
    uVar8 = (**(code **)(*local_578 + 8))();
    (**(code **)(lVar18 + 0x10))(plVar19,uVar8,0x11);
    if (((local_570 != '\0') && (plVar21 != (longlong *)0x0)) &&
       (cVar5 = (**(code **)(*plVar21 + 0x240))(plVar21), cVar5 != '\0')) {
      lVar18 = local_578[2];
      uVar8 = (**(code **)(*plVar21 + 0x48))(plVar21);
      uVar17 = (**(code **)(*plVar21 + 0x40))(plVar21);
      iVar7 = (**(code **)(lVar18 + 0x158))(local_578 + 2,uVar17,uVar8);
      iVar9 = FUN_1401615a0(local_578);
      if (iVar7 <= iVar9) {
        FUN_140161570(local_578,1);
        uVar8 = (**(code **)(*plVar21 + 0x10))(plVar21);
        FUN_1401615b0(local_578,uVar8);
        local_560 = operator_new(8);
        local_4d0[0] = plVar30;
        if (local_560 != (longlong *)0x0) {
          *local_560 = (longlong)local_4d0;
          local_4d0[0] = local_560;
        }
        local_4b8 = (void *)0x0;
        local_4b0 = 0;
        local_4a8 = 0;
        plVar19 = local_578 + 2;
        local_548 = local_560;
        uVar8 = (**(code **)(*plVar21 + 0x48))(plVar21);
        uVar17 = (**(code **)(*plVar21 + 0x40))(plVar21);
        uVar10 = (**(code **)(*plVar19 + 0x48))(plVar19);
        uVar11 = (**(code **)(*plVar19 + 0x40))(plVar19);
        local_5a8 = local_4d0;
        FUN_1403f3200(uVar11,uVar10,uVar17,uVar8);
        if (1 < (ulonglong)(local_4b0 - (longlong)local_4b8 >> 3)) {
          local_560 = operator_new(8);
          local_528[0] = plVar30;
          if (local_560 != (longlong *)0x0) {
            *local_560 = (longlong)local_528;
            local_528[0] = local_560;
          }
          local_510 = (int *)0x0;
          local_508 = (int *)0x0;
          local_500 = 0;
          uVar26 = local_4b0 - (longlong)local_4b8 >> 3;
          uVar23 = uVar26 - 2;
          local_548 = local_560;
          if (uVar26 <= uVar23) {
            _invalid_parameter_noinfo();
          }
          FUN_1401d8190(local_528,(void *)((longlong)local_4b8 + uVar23 * 8));
          local_530 = 0;
          plVar19 = plVar30;
          while( true ) {
            iVar7 = (int)plVar19;
            if (7 < iVar7) break;
            iVar9 = (**(code **)(*plVar21 + 0x40))(plVar21);
            local_558 = (int *)CONCAT44(local_558._4_4_,
                                        iVar9 + *(int *)(&DAT_140757298 + (longlong)iVar7 * 4));
            iVar9 = (**(code **)(*plVar21 + 0x48))(plVar21);
            local_558 = (int *)CONCAT44(iVar9 + *(int *)(&DAT_1407572b8 + (longlong)iVar7 * 4),
                                        (undefined4)local_558);
            FUN_1401d8190(local_528,&local_558);
            local_530 = iVar7 + 1;
            plVar19 = (longlong *)(ulonglong)local_530;
          }
          uVar8 = (**(code **)(*plVar21 + 0x40))(plVar21);
          local_550 = (int *)CONCAT44(local_550._4_4_,uVar8);
          uVar8 = (**(code **)(*plVar21 + 0x48))(plVar21);
          local_550 = (int *)CONCAT44(uVar8,(undefined4)local_550);
          FUN_1401d8190(local_528,&local_550);
          plVar19 = (longlong *)(**(code **)(local_578[2] + 0x160))();
          piVar28 = local_510;
          local_560 = plVar19;
          if (plVar19 != (longlong *)0x0) {
            local_550 = local_510;
            local_498 = (longlong *)0x0;
            local_558 = local_508;
            if (local_508 < local_510) {
              _invalid_parameter_noinfo();
            }
            piVar27 = local_508;
            plVar24 = local_528[0];
            local_4e8 = local_528[0];
            local_498 = local_528[0];
            local_478 = (longlong *)0x0;
            local_558 = local_508;
            if (local_508 < local_510) {
              _invalid_parameter_noinfo();
            }
            local_478 = local_528[0];
            local_4e8 = local_528[0];
            do {
              if ((plVar24 == (longlong *)0x0) || (plVar24 != local_4e8)) {
                _invalid_parameter_noinfo();
              }
              param_1 = local_4f8;
              plVar21 = local_4e0;
              if (piVar28 == piVar27) break;
              if (plVar24 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar21 = plVar30;
              }
              else {
                plVar21 = (longlong *)*plVar24;
              }
              if ((int *)plVar21[4] <= piVar28) {
                _invalid_parameter_noinfo();
              }
              iVar7 = *piVar28;
              local_548 = (longlong *)CONCAT44(local_548._4_4_,iVar7);
              if (plVar24 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar21 = plVar30;
              }
              else {
                plVar21 = (longlong *)*plVar24;
              }
              if ((int *)plVar21[4] <= piVar28) {
                _invalid_parameter_noinfo();
              }
              iVar9 = piVar28[1];
              local_548 = (longlong *)CONCAT44(iVar9,(undefined4)local_548);
              cVar5 = FUN_1402c3cc0(plVar19,iVar7,iVar9);
              piVar29 = local_550;
              if (cVar5 != '\0') {
                local_4a0 = (longlong *)0x0;
                lVar18 = FUN_1402c7750(local_560,iVar7,iVar9);
                piVar29 = piVar28;
                if (lVar18 != 0) {
                  plVar19 = *(longlong **)(lVar18 + 8);
                  if (plVar19 != (longlong *)0x0) {
                    local_488 = 0;
                    while ((uVar23 = local_488, uVar26 = (**(code **)(*plVar19 + 0x10))(plVar19),
                           plVar21 = plVar30, plVar24 = local_4a0, uVar23 < uVar26 &&
                           ((((plVar21 = (longlong *)(**(code **)(*plVar19 + 0x18))(plVar19,uVar23),
                              plVar21 == (longlong *)0x0 ||
                              (iVar12 = (**(code **)(*plVar21 + 0x18))(plVar21), iVar12 != 0x1040))
                             || (iVar12 = (**(code **)(*plVar21 + 0x20))(plVar21), iVar12 != iVar7))
                            || (iVar12 = (**(code **)(*plVar21 + 0x28))(plVar21), plVar24 = plVar21,
                               iVar12 != iVar9))))) {
                      local_488 = uVar23 + 1;
                    }
                    local_4a0 = plVar24;
                    plVar24 = local_498;
                    piVar27 = local_558;
                    piVar29 = local_550;
                    if (plVar21 != (longlong *)0x0) goto LAB_14036084b;
                  }
                  cVar5 = FUN_1401a9ee0(local_578,iVar7,iVar9,200);
                  piVar27 = local_558;
                  piVar29 = local_550;
                  if (cVar5 != '\0') goto code_r0x000140360810;
                }
              }
LAB_14036084b:
              if (plVar24 == (longlong *)0x0) {
                _invalid_parameter_noinfo();
                plVar19 = plVar30;
              }
              else {
                plVar19 = (longlong *)*plVar24;
              }
              if ((int *)plVar19[4] <= piVar29) {
                _invalid_parameter_noinfo();
              }
              piVar28 = piVar29 + 2;
              plVar19 = local_560;
              local_550 = piVar28;
            } while( true );
          }
          goto LAB_140360895;
        }
        goto LAB_1403608cd;
      }
    }
    goto LAB_140360904;
  default:
    if (local_578 != (longlong *)0x0) {
      uVar20 = FUN_140008520((int)param_1[0x82]);
      plVar19 = (longlong *)FUN_140087650(uVar20);
      (**(code **)(*plVar19 + 0x50))(plVar19,local_578,"INVALID MSG INTERACT TYPE");
    }
    break;
  case 8:
    if (local_578 != (longlong *)0x0) {
      FUN_140193d40(local_578,*(undefined4 *)(lVar18 + 0xc));
    }
    break;
  case 9:
    if (local_578 != (longlong *)0x0) {
      FUN_1401739a0(local_578,*(undefined4 *)(lVar18 + 0xc));
    }
    break;
  case 10:
    break;
  case 0x16:
    if ((local_578 != (longlong *)0x0) &&
       ((lVar18 = (**(code **)(local_578[2] + 0x160))(), lVar18 == 0 ||
        (cVar5 = FUN_1402c5ed0(lVar18), cVar5 != '\0')))) {
      lVar18 = (**(code **)(local_578[2] + 0x160))();
      if (lVar18 != 0) {
        uVar20 = (**(code **)(local_578[2] + 0x160))();
        cVar5 = FUN_14011dbb0(uVar20);
        if ((cVar5 != '\0') && (cVar5 = (**(code **)(local_578[2] + 0x280))(), cVar5 != '\0')) {
          return;
        }
      }
      cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x5b);
      if (((cVar5 == '\0') &&
          (cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x75), cVar5 == '\0')) &&
         (cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x9e), cVar5 == '\0')) {
        cVar5 = FUN_140160530(local_578,*(undefined2 *)(param_1[0x85] + 0x10),
                              *(undefined2 *)(param_1[0x85] + 0x12),8);
        if ((cVar5 == '\0') ||
           (iVar7 = (**(code **)(local_578[2] + 0x158))
                              (local_578 + 2,*(undefined2 *)(param_1[0x85] + 0x18),
                               *(undefined2 *)(param_1[0x85] + 0x1a)), 0x23 < iVar7)) {
          pIVar22 = theInstance();
          lVar18 = local_578[2];
          uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_MSG");
          (**(code **)(lVar18 + 0x358))(local_578 + 2,uVar20);
          uVar20 = FUN_140008520((int)param_1[0x82]);
          plVar19 = (longlong *)FUN_140087650(uVar20);
          (**(code **)(*plVar19 + 0x50))(plVar19,local_578,&DAT_140757690);
        }
        else {
          (**(code **)(local_578[2] + 0x348))(local_578 + 2,param_1,1);
          lVar18 = (**(code **)(local_578[2] + 0x2a8))
                             (local_578 + 2,*(undefined4 *)(param_1[0x85] + 0xc));
          if (lVar18 != 0) {
            plVar21 = (longlong *)FUN_1401181a0();
            lVar4 = *plVar21;
            uVar8 = (**(code **)(*local_578 + 8))();
            (**(code **)(lVar4 + 0x10))(plVar21,uVar8,0x11);
            FUN_1401a3370(local_578,0);
            (**(code **)(local_578[2] + 0x388))(local_578 + 2,lVar18);
            FUN_1401994c0(local_578,0);
            lVar18 = FUN_140008520((int)param_1[0x82]);
            if (*(longlong *)(lVar18 + 0x140) == 0) {
              local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
              log_InlineLogERROR(&DAT_1406d9c10);
            }
            else {
              plVar30 = *(longlong **)(lVar18 + 0x140);
            }
            uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
            FUN_14024e7b0(plVar30,uVar8);
          }
        }
      }
    }
    break;
  case 0x18:
    uVar13 = tq::TimeGet(0);
    plVar19 = plVar30;
    if (local_578 != (longlong *)0x0) {
      uVar14 = (**(code **)(*local_578 + 8))();
      plVar19 = (longlong *)(**(code **)(local_578[2] + 0x160))();
      if (plVar19 == (longlong *)0x0) {
        log_InlineLogERROR("MAGICATTACK cannot find map for UID:%u");
        return;
      }
      cVar5 = FUN_1402c5ed0(plVar19);
      if (cVar5 == '\0') {
        return;
      }
      plVar21 = (longlong *)CurrentInstanceGet();
      if (plVar21 == (longlong *)0x0) {
        log_InlineLogERROR("MAGICATTACK cannot find module root for UID:%u");
        return;
      }
      plVar24 = (longlong *)
                (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                          (*(longlong **)(plVar19[0xb] + 8),4);
      uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
      if ((uVar23 >> 0x15 & 1) == 0) {
        plVar24 = (longlong *)
                  (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                            (*(longlong **)(plVar19[0xb] + 8),4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar23 >> 0x25 & 1) != 0) {
          plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,0x22);
          if (plVar21 == (longlong *)0x0) {
            log_InlineLogERROR("MAGICATTACK cannot find MOD_TEAM_ARENIC for UID:%u");
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x110))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x138))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x140))(plVar21,uVar14);
          goto joined_r0x000140360d5a;
        }
        plVar24 = (longlong *)
                  (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                            (*(longlong **)(plVar19[0xb] + 8),4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar23 >> 0x1d & 1) != 0) {
          plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,0x19);
          if (plVar21 == (longlong *)0x0) {
            log_InlineLogERROR("MAGICATTACK cannot find MOD_ELITEPKARENIC for UID:%u");
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0xd0))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x98))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0xa0))(plVar21,uVar14);
          goto joined_r0x000140360d5a;
        }
        plVar24 = (longlong *)
                  (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                            (*(longlong **)(plVar19[0xb] + 8),4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar23 >> 0x20 & 1) != 0) {
          plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,0x21);
          if (plVar21 == (longlong *)0x0) {
            log_InlineLogERROR("MAGICATTACK cannot find MOD_CLAN_PK_ARENIC for UID:%u");
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0xf8))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x100))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x108))(plVar21,uVar14);
          goto joined_r0x000140360d5a;
        }
        plVar24 = (longlong *)
                  (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                            (*(longlong **)(plVar19[0xb] + 8),4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar23 >> 0x27 & 1) != 0) {
          plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,0x24);
          if (plVar21 == (longlong *)0x0) {
            log_InlineLogERROR("MAGICATTACK cannot find MOD_POP_PK_ARENIC for UID:%u");
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0xf8))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x100))(plVar21,uVar14);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0x108))(plVar21,uVar14);
          goto joined_r0x000140360d5a;
        }
        plVar24 = (longlong *)
                  (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                            (*(longlong **)(plVar19[0xb] + 8),4);
        uVar23 = (**(code **)(*plVar24 + 0x58))(plVar24);
        if ((uVar23 >> 0x1c & 1) != 0) {
          plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,0x18);
          if (plVar21 == (longlong *)0x0) {
            log_InlineLogERROR("MAGICATTACK cannot find MOD_POP_PK_ARENIC for UID:%u");
            return;
          }
          cVar5 = (**(code **)(*plVar21 + 0xa0))(plVar21,uVar14);
          goto joined_r0x000140360d5a;
        }
      }
      else {
        plVar21 = (longlong *)(**(code **)(*plVar21 + 0x20))(plVar21,4);
        if (plVar21 == (longlong *)0x0) {
          log_InlineLogERROR("MAGICATTACK cannot find MOD_ARENIC for UID:%u");
          return;
        }
        cVar5 = (**(code **)*plVar21)(plVar21,uVar14);
        if (cVar5 != '\0') {
          return;
        }
        cVar5 = (**(code **)(*plVar21 + 0x100))(plVar21,uVar14);
        if (cVar5 != '\0') {
          return;
        }
        cVar5 = (**(code **)(*plVar21 + 0x108))(plVar21,uVar14);
joined_r0x000140360d5a:
        if (cVar5 != '\0') {
          return;
        }
      }
      cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x27);
      if (cVar5 != '\0') {
        return;
      }
      cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x5b);
      if (cVar5 != '\0') {
        return;
      }
      cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x75);
      if (cVar5 != '\0') {
        return;
      }
      plVar21 = (longlong *)FUN_1401181a0();
      (**(code **)(*plVar21 + 0x10))(plVar21,uVar14,0x11);
      FUN_140382c00(local_578);
    }
    if (*(int *)((longlong)param_1 + 0x414) == -1) {
LAB_1403611f6:
      if (local_578 != (longlong *)0x0) {
        if ((*(short *)(param_1[0x85] + 0x18) == 0x2f80) ||
           (*(short *)(param_1[0x85] + 0x18) == 0x2f8a)) {
          lVar18 = FUN_140008520((int)param_1[0x82]);
          if (*(longlong *)(lVar18 + 0x100) == 0) {
            local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x144);
            log_InlineLogERROR(&DAT_1406d9c10);
            plVar21 = plVar30;
          }
          else {
            plVar21 = *(longlong **)(lVar18 + 0x100);
          }
          uVar8 = (**(code **)(*local_578 + 8))();
          uVar6 = FUN_1402f2460(plVar21,uVar8);
          *(undefined2 *)(param_1[0x85] + 0x18) = uVar6;
        }
        if (*(short *)(param_1[0x85] + 0x18) == 0) {
          return;
        }
        if (*(short *)(param_1[0x85] + 0x18) != 0x1b59) {
          plVar21 = (longlong *)
                    (**(code **)(**(longlong **)(plVar19[0xb] + 8) + 0x10))
                              (*(longlong **)(plVar19[0xb] + 8),4);
          uVar23 = (**(code **)(*plVar21 + 0x58))(plVar21);
          if ((uVar23 >> 0x2a & 1) != 0) {
            return;
          }
          plVar21 = local_578 + 2;
          uVar8 = (**(code **)(*plVar21 + 0x48))(plVar21);
          uVar17 = (**(code **)(*plVar21 + 0x40))(plVar21);
          cVar5 = FUN_1402c68a0(plVar19,0x18,uVar17,uVar8);
          if (cVar5 != '\0') {
            return;
          }
        }
        if (*(short *)(param_1[0x85] + 0x18) != 0x28a0) {
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x33);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x37);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x38);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x39);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x18);
          if (cVar5 != '\0') {
            return;
          }
          cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x6e);
          if (cVar5 != '\0') {
            return;
          }
        }
        cVar5 = (**(code **)(local_578[2] + 0x2d8))(local_578 + 2,0x9e);
        if ((cVar5 != '\0') && (*(short *)(param_1[0x85] + 0x18) != 0x28b9)) {
          return;
        }
        sVar1 = *(short *)(param_1[0x85] + 0x18);
        if ((((sVar1 == 0x1b59) || (sVar1 == 0x1b5a)) || (sVar1 == 0x1b5b)) ||
           ((sVar1 == 0x1f42 || (sVar1 == 0x1f43)))) {
          uVar20 = 1;
        }
        else {
          uVar20 = 0;
        }
        FUN_1401a3370(local_578,uVar20);
      }
    }
    else {
      switch(*(undefined2 *)(param_1[0x85] + 0x18)) {
      case 1000:
      case 0x3e9:
      case 0x3ea:
      case 0x406:
      case 0x465:
      case 0x47e:
      case 0x488:
      case 0x48d:
        *(ushort *)(param_1[0x85] + 0x1a) = *(ushort *)(param_1[0x85] + 0x1a) ^ 0x6279;
      }
      uVar2 = *(ushort *)(param_1[0x85] + 0x1a);
      if ((ushort)(uVar2 >> 8 ^ 0x37) != (ushort)*(byte *)(param_1[0x85] + 4)) {
        uVar20 = FUN_140008520((int)param_1[0x82]);
        plVar19 = (longlong *)FUN_140087650(uVar20);
        (**(code **)(*plVar19 + 0x50))(plVar19,local_578,&DAT_14075751c);
        return;
      }
      *(ushort *)(param_1[0x85] + 0x1a) = (uVar2 ^ 0x21) & 0xff;
      if (local_578 != (longlong *)0x0) {
        uVar15 = (*(ushort *)(param_1[0x85] + 0x18) ^ uVar14 ^ 0xffff915d) & 0xffff;
        *(ushort *)(param_1[0x85] + 0x18) =
             ((ushort)(uVar15 >> 0xd) | (ushort)(uVar15 << 3)) + 0x14be;
        uVar15 = *(uint *)(param_1[0x85] + 0xc);
        *(uint *)(param_1[0x85] + 0xc) =
             ((uVar15 >> 0xd | uVar15 << 0x13) ^ uVar14 ^ 0x5f2d2463) + 0x8b90b51a;
        uVar15 = *(ushort *)(param_1[0x85] + 0x10) ^ uVar14 ^ 0x2ed6;
        *(ushort *)(param_1[0x85] + 0x10) =
             ((ushort)((uVar15 & 0xffff) >> 0xf) | (short)uVar15 * 2) + 0xdd12;
        uVar14 = (*(ushort *)(param_1[0x85] + 0x12) ^ uVar14 ^ 0xffffb99b) & 0xffff;
        *(ushort *)(param_1[0x85] + 0x12) =
             ((ushort)(uVar14 >> 0xb) | (ushort)(uVar14 << 5)) + 0x76de;
        goto LAB_1403611f6;
      }
    }
    lVar18 = FUN_140008520((int)param_1[0x82]);
    if (*(longlong *)(lVar18 + 0x140) == 0) {
      local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
      log_InlineLogERROR(&DAT_1406d9c10);
      plVar19 = plVar30;
    }
    else {
      plVar19 = *(longlong **)(lVar18 + 0x140);
    }
    plVar21 = local_568;
    uVar8 = (**(code **)(*local_568 + 0x10))(local_568);
    FUN_14024e7b0(plVar19,uVar8);
    lVar18 = param_1[0x85];
    local_5a8._0_4_ = (uint)*(ushort *)(lVar18 + 0x12);
    (**(code **)(*plVar21 + 0x3c0))
              (plVar21,*(undefined2 *)(lVar18 + 0x18),*(undefined4 *)(lVar18 + 0xc),
               *(undefined2 *)(lVar18 + 0x10));
    uVar16 = tq::TimeGet(0);
    lVar18 = FUN_140008520((int)param_1[0x82]);
    if (*(longlong *)(lVar18 + 0x100) == 0) {
      local_5a8._0_4_ = 0x144;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    else {
      plVar30 = *(longlong **)(lVar18 + 0x100);
    }
    FUN_1402f3a80(plVar30,*(undefined2 *)(param_1[0x85] + 0x18),uVar16 - uVar13);
    break;
  case 0x19:
    if (local_578 != (longlong *)0x0) {
      lVar18 = FUN_140008520((int)param_1[0x82]);
      if (*(longlong *)(lVar18 + 0x100) == 0) {
        local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x144);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar30 = *(longlong **)(lVar18 + 0x100);
      }
      uVar8 = (**(code **)(*local_578 + 8))();
      cVar5 = FUN_1402f28d0(plVar30,uVar8,0);
      if (cVar5 != '\0') {
        (**(code **)(local_578[2] + 0x348))(local_578 + 2,param_1,1);
      }
    }
    break;
  case 0x24:
    if (((local_578 != (longlong *)0x0) && (*(short *)(lVar18 + 0x1a) != 0)) &&
       (cVar5 = FUN_140193c20(local_578,*(short *)(lVar18 + 0x1a)), cVar5 != '\0')) {
      uVar8 = FUN_140385cf0(local_578,1,*(undefined2 *)(param_1[0x85] + 0x1a));
      FUN_14035f2f0(local_468);
      lVar18 = param_1[0x85];
      uVar17 = (**(code **)(*local_578 + 8))();
      local_580 = 0;
      local_590 = CONCAT22(local_590._2_2_,*(undefined2 *)(lVar18 + 0x1a));
      local_598 = (uint)local_598._2_2_ << 0x10;
      local_5a0 = 0;
      local_5a8 = (longlong **)((ulonglong)local_5a8 & 0xffffffffffff0000);
      local_588 = uVar8;
      iVar7 = FUN_14035f4c0(local_468,0x24,uVar17,0);
      if (iVar7 != 0) {
        (**(code **)(*param_1 + 0x20))(param_1,local_468);
      }
      FUN_1401b1500(local_578,*(undefined2 *)(param_1[0x85] + 0x1a));
      FUN_14035f340(local_468);
    }
    break;
  case 0x27:
    if (local_578 != (longlong *)0x0) {
      if (*(int *)(lVar18 + 0x10) == 1) {
        FUN_140179690();
      }
      else if (*(int *)(lVar18 + 0x10) == 2) {
        FUN_1401ade10();
      }
      else {
        FUN_1401ad5b0();
      }
    }
    break;
  case 0x28:
    if (local_578 != (longlong *)0x0) {
      FUN_1401651a0();
    }
    break;
  case 0x29:
    if ((local_578 != (longlong *)0x0) && (iVar7 = FUN_140165180(), iVar7 != 0)) {
      FUN_140165190(local_578,0);
      FUN_140164cf0(local_578,0);
      (**(code **)(local_578[2] + 0x18))();
      (**(code **)(*local_578 + 8))();
      local_5a8 = (longlong **)0x0;
      tq::MyLogSave("gmlog/businessman","UserID:%u\tName:%s\tBusinessState:%u\t");
    }
    break;
  case 0x2c:
    if ((local_578 != (longlong *)0x0) && (cVar5 = FUN_1401782c0(), cVar5 != '\0')) {
      *(bool *)((longlong)local_578 + 0xa79) = *(char *)((longlong)local_578 + 0xa79) == '\0';
      FUN_14035f2f0(local_468);
      local_588 = 0;
      local_590 = 0;
      local_598 = (uint)*(byte *)((longlong)local_578 + 0xa79);
      local_5a0 = 0;
      local_5a8 = (longlong **)((ulonglong)local_5a8 & 0xffffffffffff0000);
      iVar7 = FUN_14035f3a0(local_468,0x2c,*(undefined4 *)(param_1[0x85] + 8),
                            *(undefined4 *)(param_1[0x85] + 0xc));
      if (iVar7 != 0) {
        (**(code **)(local_578[2] + 0x350))(local_578 + 2,local_468);
      }
      FUN_14035f340(local_468);
    }
    break;
  case 0x2e:
    if (local_578 != (longlong *)0x0) {
      (**(code **)(local_578[2] + 0x160))();
      cVar5 = FUN_140177530(local_578,*(undefined4 *)(param_1[0x85] + 0xc),0);
      if (cVar5 != '\0') {
        uVar20 = FUN_140161000(local_578);
        lVar18 = param_1[0x85];
        cVar5 = FUN_1403b5310(uVar20,*(undefined4 *)(lVar18 + 0xc),*(undefined4 *)(lVar18 + 0x18),
                              *(undefined4 *)(lVar18 + 0x1c));
        if (cVar5 != '\0') {
          lVar18 = param_1[0x85];
          FUN_1403b44e0(uVar20,*(undefined4 *)(lVar18 + 0xc),*(undefined4 *)(lVar18 + 0x18),
                        *(undefined4 *)(lVar18 + 0x1c));
        }
        lVar18 = FUN_140008520((int)param_1[0x82]);
        if (*(longlong *)(lVar18 + 0x140) == 0) {
          local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
          log_InlineLogERROR(&DAT_1406d9c10);
        }
        else {
          plVar30 = *(longlong **)(lVar18 + 0x140);
        }
        uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
        FUN_14024e7b0(plVar30,uVar8);
      }
    }
    break;
  case 0x2f:
    if (local_578 != (longlong *)0x0) {
      uVar20 = FUN_140161000();
      cVar5 = FUN_1403b5620(uVar20,*(undefined4 *)(param_1[0x85] + 0xc));
      if (cVar5 != '\0') {
        FUN_1403b4800(uVar20,*(undefined4 *)(param_1[0x85] + 0xc));
      }
      lVar18 = FUN_140008520((int)param_1[0x82]);
      if (*(longlong *)(lVar18 + 0x140) == 0) {
        local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar30 = *(longlong **)(lVar18 + 0x140);
      }
      uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
      FUN_14024e7b0(plVar30,uVar8);
    }
    break;
  case 0x30:
    if (local_578 != (longlong *)0x0) {
      uVar20 = FUN_140161000();
      FUN_1403b49f0(uVar20,*(undefined4 *)(param_1[0x85] + 0xc));
    }
    break;
  case 0x31:
    if (local_578 != (longlong *)0x0) {
      uVar20 = FUN_140161000();
      FUN_1403b4bc0(uVar20);
      lVar18 = FUN_140008520((int)param_1[0x82]);
      if (*(longlong *)(lVar18 + 0x140) == 0) {
        local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
        log_InlineLogERROR(&DAT_1406d9c10);
      }
      else {
        plVar30 = *(longlong **)(lVar18 + 0x140);
      }
      uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
      FUN_14024e7b0(plVar30,uVar8);
    }
    break;
  case 0x32:
    if (local_578 != (longlong *)0x0) {
      uVar20 = FUN_140161000();
      cVar5 = FUN_14016e3f0(local_578);
      if (cVar5 == '\0') {
        FUN_1403b5020(uVar20);
      }
    }
  }
  return;
code_r0x000140360810:
  FUN_140163af0(local_578,iVar7,iVar9);
  param_1 = local_4f8;
  plVar21 = local_4e0;
LAB_140360895:
  if (local_510 != (int *)0x0) {
    operator_delete(local_510);
  }
  local_510 = (int *)0x0;
  local_508 = (int *)0x0;
  local_500 = 0;
  operator_delete(local_528[0]);
LAB_1403608cd:
  if (local_4b8 != (void *)0x0) {
    operator_delete(local_4b8);
  }
  local_4b8 = (void *)0x0;
  local_4b0 = 0;
  local_4a8 = 0;
  operator_delete(local_4d0[0]);
LAB_140360904:
  plVar19 = local_568;
  if (local_578 != (longlong *)0x0) {
    FUN_1401a3370(local_578,0);
    plVar19 = local_568;
  }
LAB_140360926:
  (**(code **)(*plVar19 + 0x388))(plVar19,plVar21);
  if (local_578 != (longlong *)0x0) {
    cVar5 = FUN_140161580();
    if (cVar5 == '\0') {
      FUN_1401994c0(local_578,*(undefined2 *)(param_1[0x85] + 0x18));
    }
    else {
      FUN_140199540(local_578);
    }
  }
  lVar18 = FUN_140008520((int)param_1[0x82]);
  if (*(longlong *)(lVar18 + 0x140) == 0) {
    local_5a8 = (longlong **)CONCAT44(local_5a8._4_4_,0x149);
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    plVar30 = *(longlong **)(lVar18 + 0x140);
  }
  uVar8 = (**(code **)(*plVar19 + 0x10))(plVar19);
  FUN_14024e7b0(plVar30,uVar8);
  return;
}

// ==== CMsgInteract::helper_1403955a0  @1403955a0  [medium:callgraph-r1]  (orig: FUN_1403955a0)
uint FUN_1403955a0(longlong param_1)

{
  return *(uint *)(param_1 + 200) >> 1 & 1;
}

// ==== CMsgInteract::helper_1403b4280  @1403b4280  [medium:callgraph-r1]  (orig: FUN_1403b4280)
undefined8 FUN_1403b4280(undefined8 param_1,longlong param_2)

{
  char cVar1;
  uint uVar2;
  undefined4 *puVar3;
  
  if (param_2 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    return 0;
  }
  puVar3 = &DAT_1407639f0;
  uVar2 = 0;
  do {
    cVar1 = (**(code **)(*(longlong *)(param_2 + 0x10) + 0x2d8))
                      ((longlong *)(param_2 + 0x10),*puVar3);
    if (cVar1 != '\0') {
      return 0;
    }
    uVar2 = uVar2 + 1;
    puVar3 = puVar3 + 1;
  } while (uVar2 < 6);
  return 1;
}

// ==== CMsgInteract::helper_1403b44e0  @1403b44e0  [medium:callgraph-r0]  (orig: FUN_1403b44e0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b44e0(longlong *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  longlong *plVar1;
  longlong *plVar2;
  longlong lVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  int iVar7;
  longlong lVar8;
  IStringManager *pIVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (*param_1 != 0) {
    lVar8 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
    if (*(longlong *)(lVar8 + 0x90) == 0) {
      local_4a8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar8 = (**(code **)(**(longlong **)(lVar8 + 0x90) + 0x98))
                      (*(longlong **)(lVar8 + 0x90),param_2);
    if (lVar8 != 0) {
      *(undefined4 *)(param_1 + 1) = param_2;
      *(undefined4 *)((longlong)param_1 + 0xc) = param_3;
      *(undefined4 *)(param_1 + 2) = param_4;
      *(undefined4 *)((longlong)param_1 + 0x14) = 1;
      *(undefined1 *)(param_1 + 3) = 1;
      FUN_14035f2f0(local_468);
      plVar2 = (longlong *)*param_1;
      plVar1 = plVar2 + 2;
      uVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
      uVar5 = (**(code **)(*plVar1 + 0x40))(plVar1);
      uVar6 = (**(code **)(*plVar2 + 8))(plVar2);
      local_488 = 0;
      local_490 = 0;
      local_498 = *(undefined4 *)((longlong)param_1 + 0xc);
      local_4a8 = CONCAT22(local_4a8._2_2_,uVar5);
      local_4a0 = uVar4;
      iVar7 = FUN_14035f3a0(local_468,0x2e,uVar6,param_2);
      if (iVar7 != 0) {
        FUN_14035f930(local_468,(int)param_1[2]);
        (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x350))((longlong *)(lVar8 + 0x10),local_468);
      }
      switch(*(undefined4 *)((longlong)param_1 + 0xc)) {
      case 100000:
      case 0x186a1:
      case 0x186a2:
      case 0x186a3:
        pIVar9 = theInstance();
        lVar3 = *(longlong *)(*param_1 + 0x10);
        uVar10 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))();
        uVar11 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REQUEST_KISS");
        (**(code **)(lVar3 + 0x358))(*param_1 + 0x10,uVar11,uVar10);
        break;
      case 0x186a4:
        pIVar9 = theInstance();
        lVar3 = *(longlong *)(*param_1 + 0x10);
        uVar10 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))();
        uVar11 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REQUEST_HOLD_HANDS");
        (**(code **)(lVar3 + 0x358))(*param_1 + 0x10,uVar11,uVar10);
        break;
      case 0x186a5:
        pIVar9 = theInstance();
        lVar3 = *(longlong *)(*param_1 + 0x10);
        uVar10 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))();
        uVar11 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REQUEST_EMBRACE");
        (**(code **)(lVar3 + 0x358))(*param_1 + 0x10,uVar11,uVar10);
        break;
      case 0x186a6:
        pIVar9 = theInstance();
        lVar3 = *(longlong *)(*param_1 + 0x10);
        uVar10 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))();
        uVar11 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REQUEST_DOUBLERIDE");
        (**(code **)(lVar3 + 0x358))(*param_1 + 0x10,uVar11,uVar10);
        break;
      case 0x186a7:
        pIVar9 = theInstance();
        lVar3 = *(longlong *)(*param_1 + 0x10);
        uVar10 = (**(code **)(*(longlong *)(lVar8 + 0x10) + 0x18))();
        uVar11 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REQUEST_HUGWALK");
        (**(code **)(lVar3 + 0x358))(*param_1 + 0x10,uVar11,uVar10);
      }
      FUN_14035f340(local_468);
    }
  }
  return;
}

// ==== CMsgInteract::helper_1403b4800  @1403b4800  [medium:callgraph-r0]  (orig: FUN_1403b4800)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b4800(longlong *param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined2 uVar2;
  undefined2 uVar3;
  int iVar4;
  undefined4 uVar5;
  longlong lVar6;
  longlong *plVar7;
  longlong lVar8;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  undefined2 local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (*param_1 != 0) {
    lVar6 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
    if (*(longlong *)(lVar6 + 0x90) == 0) {
      local_4a8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar6 = (**(code **)(**(longlong **)(lVar6 + 0x90) + 0x98))
                      (*(longlong **)(lVar6 + 0x90),param_2);
    if (lVar6 != 0) {
      iVar4 = FUN_140166ec0(*param_1);
      if (iVar4 != 0) {
        plVar7 = (longlong *)FUN_1400f8360();
        lVar8 = *plVar7;
        uVar5 = FUN_140166ec0(*param_1);
        (**(code **)(lVar8 + 0x10))(plVar7,uVar5);
      }
      iVar4 = FUN_140166ec0(lVar6);
      if (iVar4 != 0) {
        plVar7 = (longlong *)FUN_1400f8360();
        lVar8 = *plVar7;
        uVar5 = FUN_140166ec0(lVar6);
        (**(code **)(lVar8 + 0x10))(plVar7,uVar5);
      }
      lVar8 = FUN_140161000(lVar6);
      *(undefined4 *)(lVar8 + 0x14) = 2;
      *(undefined4 *)(param_1 + 1) = param_2;
      *(undefined4 *)((longlong)param_1 + 0xc) = *(undefined4 *)(lVar8 + 0xc);
      *(undefined4 *)(param_1 + 2) = *(undefined4 *)(lVar8 + 0x10);
      *(undefined4 *)((longlong)param_1 + 0x14) = 2;
      FUN_14035f2f0(local_468);
      plVar1 = (longlong *)*param_1;
      plVar7 = plVar1 + 2;
      uVar2 = (**(code **)(*plVar7 + 0x48))(plVar7);
      uVar3 = (**(code **)(*plVar7 + 0x40))(plVar7);
      uVar5 = (**(code **)(*plVar1 + 8))(plVar1);
      local_488 = 0;
      local_490 = 0;
      local_498 = *(undefined4 *)((longlong)param_1 + 0xc);
      local_4a8 = CONCAT22(local_4a8._2_2_,uVar3);
      local_4a0 = uVar2;
      iVar4 = FUN_14035f3a0(local_468,0x2f,uVar5,param_2);
      if (iVar4 != 0) {
        FUN_14035f930(local_468,(int)param_1[2]);
        (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x350))
                  ((longlong *)(*param_1 + 0x10),local_468);
        (**(code **)(*(longlong *)(lVar6 + 0x10) + 0x350))((longlong *)(lVar6 + 0x10),local_468);
      }
      FUN_14035f340(local_468);
    }
  }
  return;
}

// ==== CMsgInteract::helper_1403b49f0  @1403b49f0  [medium:callgraph-r0]  (orig: FUN_1403b49f0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b49f0(longlong *param_1,undefined4 param_2)

{
  longlong *plVar1;
  undefined4 uVar2;
  longlong *plVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  longlong lVar9;
  longlong lVar10;
  undefined8 uVar11;
  undefined1 auStack_4d8 [32];
  undefined4 local_4b8;
  undefined2 local_4b0;
  undefined4 local_4a8;
  undefined4 local_4a0;
  undefined4 local_498;
  undefined8 local_480;
  undefined1 local_478 [1072];
  ulonglong local_48;
  
  local_480 = 0xfffffffffffffffe;
  local_48 = DAT_1409707c0 ^ (ulonglong)auStack_4d8;
  if (*param_1 != 0) {
    lVar9 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
    if (*(longlong *)(lVar9 + 0x90) == 0) {
      local_4b8 = 0x130;
      log_InlineLogERROR(&DAT_1406d9c10);
    }
    lVar9 = (**(code **)(**(longlong **)(lVar9 + 0x90) + 0x98))
                      (*(longlong **)(lVar9 + 0x90),param_2);
    if (lVar9 != 0) {
      lVar10 = FUN_140161000(lVar9);
      iVar8 = *(int *)(lVar10 + 8);
      iVar6 = (**(code **)(*(longlong *)*param_1 + 8))();
      if (iVar8 == iVar6) {
        FUN_14035f2f0(local_478);
        uVar2 = *(undefined4 *)(lVar10 + 0xc);
        plVar3 = (longlong *)*param_1;
        plVar1 = plVar3 + 2;
        uVar4 = (**(code **)(*plVar1 + 0x48))(plVar1);
        uVar5 = (**(code **)(*plVar1 + 0x40))(plVar1);
        uVar7 = (**(code **)(*plVar3 + 8))(plVar3);
        local_498 = 0;
        local_4a0 = 0;
        local_4b8 = CONCAT22(local_4b8._2_2_,uVar5);
        local_4b0 = uVar4;
        local_4a8 = uVar2;
        iVar8 = FUN_14035f3a0(local_478,0x30,uVar7,param_2);
        if (iVar8 != 0) {
          FUN_14035f930(local_478,*(undefined4 *)(lVar10 + 0x10));
          (**(code **)(*(longlong *)(lVar9 + 0x10) + 0x350))((longlong *)(lVar9 + 0x10),local_478);
        }
        uVar2 = *(undefined4 *)(lVar10 + 0xc);
        uVar7 = (**(code **)(*(longlong *)*param_1 + 8))();
        uVar11 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
        FUN_1400c17f0(uVar11,param_2,uVar7,uVar2);
        *(undefined4 *)(lVar10 + 8) = 0;
        *(undefined4 *)(lVar10 + 0xc) = 0;
        *(undefined4 *)(lVar10 + 0x10) = 0;
        *(undefined4 *)(lVar10 + 0x14) = 0;
        *(undefined1 *)(lVar10 + 0x18) = 0;
        FUN_14035f340(local_478);
      }
    }
  }
  return;
}

// ==== CMsgInteract::helper_1403b4bc0  @1403b4bc0  [medium:callgraph-r0]  (orig: FUN_1403b4bc0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_1403b4bc0(longlong *param_1)

{
  longlong lVar1;
  longlong *plVar2;
  char cVar3;
  undefined2 uVar4;
  undefined2 uVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  longlong lVar10;
  longlong lVar11;
  longlong *plVar12;
  longlong *plVar13;
  undefined1 auStack_4c8 [32];
  undefined4 local_4a8;
  char *local_4a0;
  undefined4 local_498;
  undefined4 local_490;
  undefined4 local_488;
  undefined8 local_470;
  undefined1 local_468 [1072];
  ulonglong local_38;
  
  local_470 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_4c8;
  if (*param_1 == 0) {
    return;
  }
  lVar10 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
  if (*(longlong *)(lVar10 + 0x90) == 0) {
    local_4a8 = 0x130;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  lVar10 = (**(code **)(**(longlong **)(lVar10 + 0x90) + 0x98))
                     (*(longlong **)(lVar10 + 0x90),(int)param_1[1]);
  if (lVar10 == 0) {
    return;
  }
  lVar11 = FUN_140161000(lVar10);
  iVar8 = *(int *)(lVar11 + 8);
  iVar6 = (**(code **)(*(longlong *)*param_1 + 8))();
  if (iVar8 != iVar6) {
    return;
  }
  cVar3 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x2d8))((longlong *)(*param_1 + 0x10),0x2f);
  if (cVar3 != '\0') {
    plVar12 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar12;
    uVar7 = (**(code **)(*(longlong *)*param_1 + 8))();
    (**(code **)(lVar1 + 0x10))(plVar12,uVar7,0x2f);
  }
  cVar3 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x2d8))((longlong *)(*param_1 + 0x10),0x16);
  if (cVar3 != '\0') {
    plVar12 = (longlong *)FUN_1401181a0();
    lVar1 = *plVar12;
    uVar7 = (**(code **)(*(longlong *)*param_1 + 8))();
    (**(code **)(lVar1 + 0x10))(plVar12,uVar7,0x16);
  }
  *(undefined4 *)(lVar11 + 0x14) = 3;
  *(undefined4 *)((longlong)param_1 + 0x14) = 3;
  (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x2c0))
            ((longlong *)(*param_1 + 0x10),*(undefined4 *)((longlong)param_1 + 0xc),
             (short)param_1[2]);
  plVar12 = (longlong *)(lVar10 + 0x10);
  (**(code **)(*plVar12 + 0x2c0))
            (plVar12,*(undefined4 *)((longlong)param_1 + 0xc),(short)param_1[2]);
  lVar10 = *param_1;
  iVar8 = (**(code **)(*plVar12 + 0x40))(plVar12);
  iVar6 = (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x40))(lVar10 + 0x10);
  if (iVar6 == iVar8) {
    lVar10 = *param_1;
    iVar8 = (**(code **)(*plVar12 + 0x48))(plVar12);
    iVar6 = (**(code **)(*(longlong *)(lVar10 + 0x10) + 0x48))(lVar10 + 0x10);
    if (iVar6 == iVar8) goto LAB_1403b4e8a;
  }
  plVar13 = (longlong *)(**(code **)(*(longlong *)(*param_1 + 0x10) + 0x160))();
  if (plVar13 == (longlong *)0x0) {
    local_4a8 = 0x1b8;
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  else {
    uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
    uVar9 = (**(code **)(*plVar12 + 0x40))(plVar12);
    cVar3 = FUN_14015f9d0(plVar13,uVar9,uVar7);
    if (cVar3 == '\0') {
      plVar2 = (longlong *)*param_1;
      uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
      (**(code **)(*plVar12 + 0x40))(plVar12);
      (**(code **)(*plVar13 + 8))(plVar13);
      (**(code **)(*plVar2 + 8))(plVar2);
      local_498 = 0x1bb;
      local_4a0 = "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\interact.cpp";
      local_4a8 = uVar7;
      log_InlineLogERROR("CInteract::Begin user%u map%u(%d, %d) at %s, %d");
    }
    else {
      lVar10 = *(longlong *)(*param_1 + 0x10);
      uVar7 = (**(code **)(*plVar12 + 0x48))(plVar12);
      uVar9 = (**(code **)(*plVar12 + 0x40))(plVar12);
      (**(code **)(lVar10 + 0x378))(*param_1 + 0x10,uVar9,uVar7);
    }
  }
LAB_1403b4e8a:
  lVar10 = *(longlong *)(*param_1 + 0x10);
  uVar7 = (**(code **)(*plVar12 + 0x50))(plVar12);
  (**(code **)(lVar10 + 0x2b8))(*param_1 + 0x10,uVar7);
  FUN_14035f2f0(local_468);
  plVar2 = (longlong *)*param_1;
  plVar13 = plVar2 + 2;
  uVar7 = (**(code **)(*plVar13 + 0x50))(plVar13);
  uVar4 = (**(code **)(*plVar13 + 0x48))(plVar13);
  uVar5 = (**(code **)(*plVar13 + 0x40))(plVar13);
  uVar9 = (**(code **)(*plVar2 + 8))(plVar2);
  local_488 = 0;
  local_498 = *(undefined4 *)((longlong)param_1 + 0xc);
  local_4a0 = (char *)CONCAT62(local_4a0._2_6_,uVar4);
  local_4a8 = CONCAT22(local_4a8._2_2_,uVar5);
  local_490 = uVar7;
  iVar8 = FUN_14035f3a0(local_468,0x31,uVar9,(int)param_1[1]);
  if (iVar8 != 0) {
    FUN_14035f930(local_468,(int)param_1[2]);
    (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x348))((longlong *)(*param_1 + 0x10),local_468,1)
    ;
  }
  plVar13 = (longlong *)*param_1;
  uVar7 = (**(code **)(*plVar12 + 0x50))(plVar12);
  uVar4 = (**(code **)(*plVar12 + 0x48))(plVar12);
  uVar5 = (**(code **)(*plVar12 + 0x40))(plVar12);
  uVar9 = (**(code **)(*plVar13 + 8))(plVar13);
  local_488 = 0;
  local_498 = *(undefined4 *)((longlong)param_1 + 0xc);
  local_4a0 = (char *)CONCAT62(local_4a0._2_6_,uVar4);
  local_4a8 = CONCAT22(local_4a8._2_2_,uVar5);
  local_490 = uVar7;
  iVar8 = FUN_14035f3a0(local_468,0x31,(int)param_1[1],uVar9);
  if (iVar8 != 0) {
    FUN_14035f930(local_468,(int)param_1[2]);
    (**(code **)(*plVar12 + 0x348))(plVar12,local_468,1);
  }
  FUN_14035f340(local_468);
  return;
}

// ==== CMsgInteract::helper_1403b5290  @1403b5290  [medium:callgraph-r1]  (orig: FUN_1403b5290)
bool FUN_1403b5290(undefined8 *param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 uVar2;
  longlong lVar3;
  
  lVar3 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
  lVar3 = *(longlong *)(lVar3 + 0x100);
  if (lVar3 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  uVar2 = (**(code **)(*(longlong *)*param_1 + 8))();
  cVar1 = FUN_1402f3830(lVar3,uVar2,param_2);
  return cVar1 != '\0';
}

// ==== CMsgInteract::helper_1403b5310  @1403b5310  [medium:callgraph-r0]  (orig: FUN_1403b5310)
undefined8 FUN_1403b5310(longlong *param_1,undefined4 param_2,int param_3,int param_4)

{
  longlong *plVar1;
  char cVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  longlong *plVar8;
  IStringManager *pIVar9;
  longlong lVar10;
  longlong lVar11;
  int *piVar12;
  uint uVar13;
  uint uVar14;
  int *piVar15;
  
  if (*param_1 == 0) {
    return 0;
  }
  iVar3 = FUN_140166ec0();
  if (iVar3 == 0) {
    uVar4 = (**(code **)(*(longlong *)*param_1 + 8))();
    uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
    cVar2 = FUN_1400b2fa0(uVar7,uVar4,param_2,param_3);
    if (cVar2 == '\0') {
      return 0;
    }
    uVar7 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
    plVar8 = (longlong *)FUN_140087650(uVar7);
    plVar8 = (longlong *)(**(code **)(*plVar8 + 0x98))(plVar8,param_2);
    if (plVar8 == (longlong *)0x0) {
      return 0;
    }
    cVar2 = FUN_140167b70(plVar8);
    if (cVar2 != '\0') {
      return 0;
    }
    cVar2 = FUN_140167b70(*param_1);
    if (cVar2 != '\0') {
      return 0;
    }
    iVar3 = FUN_140166ec0(plVar8);
    if (iVar3 == 0) {
      cVar2 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x220))(*param_1 + 0x10);
      if (cVar2 == '\0') {
        return 0;
      }
      cVar2 = (**(code **)(plVar8[2] + 0x220))(plVar8 + 2);
      if (cVar2 == '\0') {
        return 0;
      }
      lVar10 = (**(code **)(*(longlong *)*param_1 + 0x28))((longlong *)*param_1,param_2);
      if (lVar10 == 0) {
        return 0;
      }
      plVar1 = (longlong *)*param_1;
      iVar3 = (**(code **)(*plVar8 + 0x50))(plVar8);
      iVar5 = (**(code **)(*plVar1 + 0x50))(plVar1);
      if (iVar5 != iVar3) {
        lVar10 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x160))(*param_1 + 0x10);
        if ((((lVar10 != 0) && (cVar2 = FUN_14017ef50(lVar10), cVar2 == '\0')) &&
            (cVar2 = FUN_14016cc30(lVar10), cVar2 == '\0')) &&
           (((cVar2 = FUN_14011dbb0(lVar10), cVar2 == '\0' &&
             (cVar2 = FUN_14016cdb0(lVar10), cVar2 == '\0')) &&
            (((int)param_1[1] == 0 ||
             ((*(int *)((longlong)param_1 + 0x14) != 2 && (*(int *)((longlong)param_1 + 0x14) != 3))
             )))))) {
          lVar11 = FUN_140161000(plVar8);
          if ((*(int *)(lVar11 + 8) == 0) ||
             ((*(int *)(lVar11 + 0x14) != 2 && (*(int *)(lVar11 + 0x14) != 3)))) {
            if ((*(longlong *)(*param_1 + 0xa88) == 0) &&
               (((plVar8[0x151] == 0 && (cVar2 = FUN_1403b4280(param_1), cVar2 != '\0')) &&
                (cVar2 = FUN_1403b4280(param_1,plVar8), cVar2 != '\0')))) {
              piVar15 = &DAT_140763990;
              uVar14 = 0;
              do {
                uVar13 = 0;
                piVar12 = &DAT_1407639b0;
                do {
                  iVar5 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x40))(*param_1 + 0x10);
                  iVar3 = *piVar15;
                  iVar6 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x48))(*param_1 + 0x10);
                  cVar2 = FUN_1402c3cc0(lVar10,iVar5 + iVar3,iVar6 + *piVar12);
                  if (cVar2 != '\0') {
                    if (param_3 == 0x186aa) {
                      piVar15 = &DAT_1407639e0;
                      while (param_4 != *piVar15) {
                        piVar15 = piVar15 + 1;
                        if (0x1407639ef < (longlong)piVar15) {
                          return 0;
                        }
                      }
                      cVar2 = FUN_1403b5290(param_1,param_4);
                      if (cVar2 == '\0') {
                        return 0;
                      }
                    }
                    return 1;
                  }
                  uVar13 = uVar13 + 1;
                  piVar12 = piVar12 + 1;
                } while (uVar13 < 8);
                uVar14 = uVar14 + 1;
                piVar15 = piVar15 + 1;
                if (7 < uVar14) {
                  return 0;
                }
              } while( true );
            }
          }
          else {
            pIVar9 = theInstance();
            lVar10 = *param_1;
            lVar11 = *(longlong *)(lVar10 + 0x10);
            uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_TARGET_BUSY");
            (**(code **)(lVar11 + 0x358))(lVar10 + 0x10,uVar7);
          }
        }
        return 0;
      }
      return 0;
    }
  }
  pIVar9 = theInstance();
  lVar10 = *param_1;
  lVar11 = *(longlong *)(lVar10 + 0x10);
  uVar7 = (*(code *)**(undefined8 **)pIVar9)(pIVar9,"STR_INTERACT_REJECT_WHILE_BOOTH");
  (**(code **)(lVar11 + 0x358))(lVar10 + 0x10,uVar7);
  return 0;
}

// ==== CMsgInteract::helper_1403b5620  @1403b5620  [medium:callgraph-r0]  (orig: FUN_1403b5620)
undefined8 FUN_1403b5620(longlong *param_1,undefined4 param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  IStringManager *pIVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong lVar8;
  int *piVar9;
  
  if (*param_1 == 0) {
    return 0;
  }
  iVar2 = FUN_140166ec0();
  if (iVar2 != 0) {
    pIVar4 = theInstance();
    lVar7 = *param_1;
    lVar8 = *(longlong *)(lVar7 + 0x10);
    uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_INTERACT_REJECT_WHILE_BOOTH");
    (**(code **)(lVar8 + 0x358))(lVar7 + 0x10,uVar5);
    return 0;
  }
  uVar5 = FUN_140008520(*(undefined4 *)((longlong)param_1 + 0x1c));
  plVar6 = (longlong *)FUN_140087650(uVar5);
  plVar6 = (longlong *)(**(code **)(*plVar6 + 0x98))(plVar6,param_2);
  if ((((plVar6 != (longlong *)0x0) && (cVar1 = FUN_140167b70(plVar6), cVar1 == '\0')) &&
      (cVar1 = FUN_140167b70(*param_1), cVar1 == '\0')) &&
     ((cVar1 = FUN_140178570(*param_1,1), cVar1 == '\0' &&
      (cVar1 = FUN_140178570(plVar6,1), cVar1 == '\0')))) {
    iVar2 = FUN_140166ec0(plVar6);
    if (iVar2 == 0) {
      lVar7 = FUN_140161000(plVar6);
      iVar2 = *(int *)(lVar7 + 8);
      iVar3 = (**(code **)(*(longlong *)*param_1 + 8))();
      if (iVar2 == iVar3) {
        if (((((int)param_1[1] == 0) ||
             ((*(int *)((longlong)param_1 + 0x14) != 2 && (*(int *)((longlong)param_1 + 0x14) != 3))
             )) && ((*(int *)(lVar7 + 8) == 0 ||
                    ((*(int *)(lVar7 + 0x14) != 2 && (*(int *)(lVar7 + 0x14) != 3)))))) &&
           ((cVar1 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x220))(*param_1 + 0x10),
            cVar1 != '\0' &&
            ((cVar1 = (**(code **)(plVar6[2] + 0x220))(plVar6 + 2), cVar1 != '\0' &&
             (lVar8 = (**(code **)(*(longlong *)*param_1 + 0x28))((longlong *)*param_1,param_2),
             lVar8 != 0)))))) {
          iVar2 = (**(code **)(*(longlong *)*param_1 + 0x50))();
          iVar3 = (**(code **)(*plVar6 + 0x50))(plVar6);
          if ((iVar2 != iVar3) &&
             ((((lVar8 = (**(code **)(*(longlong *)(*param_1 + 0x10) + 0x160))(*param_1 + 0x10),
                lVar8 != 0 && (cVar1 = FUN_14017ef50(lVar8), cVar1 == '\0')) &&
               (cVar1 = FUN_14016cc30(lVar8), cVar1 == '\0')) &&
              ((((cVar1 = FUN_14011dbb0(lVar8), cVar1 == '\0' &&
                 (cVar1 = FUN_14016cdb0(lVar8), cVar1 == '\0')) &&
                ((*(longlong *)(*param_1 + 0xa88) == 0 &&
                 ((plVar6[0x151] == 0 && (cVar1 = FUN_1403b4280(param_1), cVar1 != '\0')))))) &&
               (cVar1 = FUN_1403b4280(param_1,plVar6), cVar1 != '\0')))))) {
            if (*(int *)(lVar7 + 8) == 0x186aa) {
              piVar9 = &DAT_1407639e0;
              while (*(int *)(lVar7 + 0x10) != *piVar9) {
                piVar9 = piVar9 + 1;
                if (0x1407639ef < (longlong)piVar9) {
                  return 0;
                }
              }
              cVar1 = FUN_1403b5290(param_1);
              if (cVar1 == '\0') {
                return 0;
              }
            }
            return 1;
          }
        }
      }
      else {
        pIVar4 = theInstance();
        lVar7 = *param_1;
        lVar8 = *(longlong *)(lVar7 + 0x10);
        uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_INTERACT_NO_TARGET");
        (**(code **)(lVar8 + 0x358))(lVar7 + 0x10,uVar5);
      }
      return 0;
    }
    pIVar4 = theInstance();
    lVar7 = *param_1;
    lVar8 = *(longlong *)(lVar7 + 0x10);
    uVar5 = (*(code *)**(undefined8 **)pIVar4)(pIVar4,"STR_INTERACT_REJECT_WHILE_BOOTH");
    (**(code **)(lVar8 + 0x358))(lVar7 + 0x10,uVar5);
  }
  return 0;
}

// ==== CMsgInteract::helper_1403f3200  @1403f3200  [medium:callgraph-r0]  (orig: FUN_1403f3200)
void FUN_1403f3200(int param_1,int param_2,int param_3,int param_4,undefined8 param_5)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  ulonglong uVar5;
  uint uVar6;
  uint uVar7;
  int local_38;
  int local_34;
  
  FUN_1401d6d10();
  if ((param_1 != param_3) || (param_2 != param_4)) {
    uVar4 = param_3 - param_1;
    uVar3 = param_4 - param_2;
    uVar6 = (uVar4 ^ (int)uVar4 >> 0x1f) - ((int)uVar4 >> 0x1f);
    uVar7 = (uVar3 ^ (int)uVar3 >> 0x1f) - ((int)uVar3 >> 0x1f);
    if ((int)uVar7 < (int)uVar6) {
      iVar1 = -1;
      iVar2 = 1;
      if (0 < (int)uVar3) {
        iVar1 = 1;
      }
      iVar1 = iVar1 * uVar6;
      if ((int)uVar4 < 1) {
        if (((int)uVar4 < 0) && (0 < (int)uVar6)) {
          uVar5 = (ulonglong)uVar6;
          do {
            iVar1 = uVar3 * 2 + iVar1;
            param_1 = param_1 + -1;
            local_34 = iVar1 / (int)(uVar6 * 2) + param_2;
            local_38 = param_1;
            FUN_1401d8190(param_5,&local_38);
            uVar5 = uVar5 - 1;
          } while (uVar5 != 0);
        }
      }
      else if (0 < (int)uVar6) {
        do {
          iVar1 = uVar3 * 2 + iVar1;
          local_38 = iVar2 + param_1;
          local_34 = iVar1 / (int)(uVar6 * 2) + param_2;
          FUN_1401d8190(param_5,&local_38);
          iVar2 = iVar2 + 1;
        } while (iVar2 <= (int)uVar6);
      }
    }
    else {
      iVar1 = -1;
      iVar2 = 1;
      if (0 < (int)uVar4) {
        iVar1 = 1;
      }
      iVar1 = iVar1 * uVar7;
      if ((int)uVar3 < 1) {
        if (((int)uVar3 < 0) && (0 < (int)uVar7)) {
          uVar5 = (ulonglong)uVar7;
          do {
            iVar1 = uVar4 * 2 + iVar1;
            param_2 = param_2 + -1;
            local_38 = iVar1 / (int)(uVar7 * 2) + param_1;
            local_34 = param_2;
            FUN_1401d8190(param_5,&local_38);
            uVar5 = uVar5 - 1;
          } while (uVar5 != 0);
        }
      }
      else if (0 < (int)uVar7) {
        do {
          iVar1 = uVar4 * 2 + iVar1;
          local_34 = iVar2 + param_2;
          local_38 = iVar1 / (int)(uVar7 * 2) + param_1;
          FUN_1401d8190(param_5,&local_38);
          iVar2 = iVar2 + 1;
        } while (iVar2 <= (int)uVar7);
      }
    }
  }
  return;
}

// ==== CMsgInteract::helper_14048bc30  @14048bc30  [medium:callgraph-r2]  (orig: FUN_14048bc30)
longlong FUN_14048bc30(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  longlong *plVar4;
  int iVar5;
  longlong *plVar6;
  longlong lVar7;
  
  plVar2 = *(longlong **)(param_1 + 8);
  plVar6 = (longlong *)**(undefined8 **)(param_1 + 0x38);
  while( true ) {
    plVar3 = *(longlong **)(param_1 + 0x38);
    if ((*(longlong **)(param_1 + 8) == (longlong *)0x0) || (*(longlong **)(param_1 + 8) != plVar2))
    {
      _invalid_parameter_noinfo();
    }
    if (plVar3 == plVar6) {
      return 0;
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar7 = 0;
    }
    else {
      lVar7 = *plVar2;
    }
    if (plVar6 == *(longlong **)(lVar7 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    lVar7 = plVar6[4];
    if ((lVar7 != 0) && (iVar5 = FUN_140418c50(lVar7,0x66), iVar5 == 0x1d)) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
      plVar3 = (longlong *)plVar6[2];
      if (*(char *)((longlong)plVar3 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar3 + 0x29);
        plVar6 = plVar3;
        plVar3 = (longlong *)*plVar3;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar3 + 0x29);
          plVar6 = plVar3;
          plVar3 = (longlong *)*plVar3;
        }
      }
      else {
        cVar1 = *(char *)(plVar6[1] + 0x29);
        plVar4 = (longlong *)plVar6[1];
        plVar3 = plVar6;
        while ((plVar6 = plVar4, cVar1 == '\0' && (plVar3 == (longlong *)plVar6[2]))) {
          cVar1 = *(char *)(plVar6[1] + 0x29);
          plVar4 = (longlong *)plVar6[1];
          plVar3 = plVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  return lVar7;
}

// ==== CMsgInteract::helper_14048c970  @14048c970  [medium:callgraph-r1]  (orig: FUN_14048c970)
undefined4 FUN_14048c970(longlong param_1)

{
  ulong uVar1;
  longlong lVar2;
  undefined4 uVar3;
  
  if (*(int *)(param_1 + 0x128) == 0) {
LAB_14048c9a3:
    if (*(char *)(param_1 + 0xf4) != '\0') goto LAB_14048c9d0;
    lVar2 = FUN_14048b5f0(param_1,0x2f8a);
    if (lVar2 != 0) goto LAB_14048c9d0;
  }
  else {
    uVar1 = tq::TimeGet(0);
    if (uVar1 < (uint)(*(int *)(param_1 + 0x128) + *(int *)(param_1 + 0x124))) goto LAB_14048c9a3;
  }
  *(undefined4 *)(param_1 + 0x128) = 0;
  *(undefined4 *)(param_1 + 0x124) = 0;
  *(undefined1 *)(param_1 + 0xf4) = 1;
LAB_14048c9d0:
  uVar3 = 0x2f8a;
  if (*(char *)(param_1 + 0xf4) != '\0') {
    uVar3 = 0x2f80;
  }
  return uVar3;
}

