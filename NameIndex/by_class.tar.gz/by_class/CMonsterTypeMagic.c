// ==== CMonsterTypeMagic::helper_140226310  @140226310  [medium:callgraph-r0]  (orig: FUN_140226310)
void FUN_140226310(void *param_1)

{
  if ((DAT_140975f28 & 1) == 0) {
    DAT_140975f28 = DAT_140975f28 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f20,"CMonsterTypeMagic");
    atexit((_func_5014 *)&LAB_1406d69a0);
  }
                    /* WARNING: Could not recover jumptable at 0x000140226365. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_140975f20,param_1);
  return;
}

// ==== CMonsterTypeMagic::ctor_or_dtor  @140226730  [high:vtable-assign]  (orig: FUN_140226730)
void FUN_140226730(undefined8 *param_1)

{
  char cVar1;
  longlong *plVar2;
  undefined8 *puVar3;
  longlong *plVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined8 *puVar7;
  longlong lVar8;
  undefined8 uVar9;
  longlong *local_48;
  undefined8 *puStack_40;
  longlong *local_38;
  undefined8 *puStack_30;
  undefined1 local_28 [16];
  
  uVar9 = 0xfffffffffffffffe;
  *param_1 = CMonsterTypeMagic::vftable;
  puVar7 = (undefined8 *)param_1[7];
  puVar6 = (undefined8 *)*puVar7;
  plVar2 = (longlong *)param_1[1];
  local_48 = plVar2;
  puStack_40 = puVar6;
  local_38 = plVar2;
  puStack_30 = puVar7;
  while( true ) {
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (puVar6 == puVar7) break;
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar8 = 0;
    }
    else {
      lVar8 = *plVar2;
    }
    if (puVar6 == *(undefined8 **)(lVar8 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    puVar3 = (undefined8 *)puVar6[4];
    if (puVar3 != (undefined8 *)0x0) {
      (**(code **)*puVar3)(puVar3,1);
    }
    if (plVar2 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
    }
    if (*(char *)((longlong)puVar6 + 0x29) == '\0') {
      puVar3 = (undefined8 *)puVar6[2];
      if (*(char *)((longlong)puVar3 + 0x29) == '\0') {
        cVar1 = *(char *)((longlong)*puVar3 + 0x29);
        puVar6 = puVar3;
        puVar3 = (undefined8 *)*puVar3;
        while (puStack_40 = puVar6, cVar1 == '\0') {
          cVar1 = *(char *)((longlong)*puVar3 + 0x29);
          puVar6 = puVar3;
          puVar3 = (undefined8 *)*puVar3;
        }
      }
      else {
        cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
        puVar5 = (undefined8 *)puVar6[1];
        puVar3 = puVar6;
        while ((puVar6 = puVar5, puStack_40 = puVar6, cVar1 == '\0' &&
               (puVar3 == (undefined8 *)puVar6[2]))) {
          cVar1 = *(char *)((longlong)puVar6[1] + 0x29);
          puVar5 = (undefined8 *)puVar6[1];
          puVar3 = puVar6;
        }
      }
    }
    else {
      _invalid_parameter_noinfo();
    }
  }
  puVar7 = param_1 + 1;
  cVar1 = *(char *)((longlong)*(longlong **)(param_1[7] + 8) + 0x29);
  plVar2 = *(longlong **)(param_1[7] + 8);
  while (cVar1 == '\0') {
    FUN_14002ca30(puVar7,plVar2[2]);
    plVar4 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar4;
    cVar1 = *(char *)((longlong)plVar4 + 0x29);
  }
  *(undefined8 *)(param_1[7] + 8) = param_1[7];
  param_1[8] = 0;
  *(undefined8 *)param_1[7] = param_1[7];
  *(undefined8 *)(param_1[7] + 0x10) = param_1[7];
  puStack_30 = (undefined8 *)param_1[7];
  local_48 = (longlong *)*puVar7;
  puStack_40 = (undefined8 *)*puStack_30;
  local_38 = local_48;
  FUN_14002da30(puVar7,local_28,&local_48,&local_38,uVar9);
  operator_delete((void *)param_1[7]);
  param_1[7] = 0;
  param_1[8] = 0;
  operator_delete((void *)*puVar7);
  return;
}

// ==== CMonsterTypeMagic::ctor_or_dtor  @140226950  [high:vtable-assign]  (orig: FUN_140226950)
undefined8 * FUN_140226950(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CMonsterTypeMagic::vftable;
  FUN_14002e1c0(param_1 + 1);
  *(undefined4 *)(param_1 + 9) = param_2;
  return param_1;
}

// ==== CMonsterTypeMagic::vfunc_0  @1402269a0  [high:rtti-vtable]  (orig: FUN_1402269a0)
undefined8 FUN_1402269a0(undefined8 param_1,uint param_2)

{
  FUN_140226730();
  if ((param_2 & 1) != 0) {
    FUN_140226310(param_1);
  }
  return param_1;
}

// ==== CMonsterTypeMagic::ctor_or_dtor  @1402269d0  [high:vtable-assign]  (orig: FUN_1402269d0)
undefined8 * FUN_1402269d0(undefined4 param_1)

{
  undefined8 *puVar1;
  
  if ((DAT_140975f28 & 1) == 0) {
    DAT_140975f28 = DAT_140975f28 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_140975f20,"CMonsterTypeMagic");
    atexit((_func_5014 *)&LAB_1406d69a0);
  }
  puVar1 = CMyHeap::Alloc((CMyHeap *)&DAT_140975f20,0x50);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CMonsterTypeMagic::vftable;
    FUN_14002e1c0(puVar1 + 1);
    *(undefined4 *)(puVar1 + 9) = param_1;
  }
  return puVar1;
}

