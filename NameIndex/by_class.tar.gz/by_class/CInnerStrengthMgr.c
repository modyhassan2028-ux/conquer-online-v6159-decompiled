// ==== CInnerStrengthMgr::helper_1401f29f0  @1401f29f0  [medium:callgraph-r2]  (orig: FUN_1401f29f0)
void FUN_1401f29f0(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0xa9) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0xa9) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0xa9);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0xa9);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0xa9);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0xa9);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001401f2a17. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CInnerStrengthMgr::helper_1401f2a90  @1401f2a90  [medium:callgraph-r2]  (orig: FUN_1401f2a90)
void FUN_1401f2a90(longlong *param_1)

{
  char cVar1;
  longlong lVar2;
  longlong *plVar3;
  longlong *plVar4;
  
  if (*param_1 == 0) {
    _invalid_parameter_noinfo();
  }
  lVar2 = param_1[1];
  if (*(char *)(lVar2 + 0x139) == '\0') {
    plVar3 = *(longlong **)(lVar2 + 0x10);
    if (*(char *)((longlong)plVar3 + 0x139) != '\0') {
      lVar2 = *(longlong *)(lVar2 + 8);
      cVar1 = *(char *)(lVar2 + 0x139);
      while ((cVar1 == '\0' && (param_1[1] == *(longlong *)(lVar2 + 0x10)))) {
        param_1[1] = lVar2;
        lVar2 = *(longlong *)(lVar2 + 8);
        cVar1 = *(char *)(lVar2 + 0x139);
      }
      param_1[1] = lVar2;
      return;
    }
    cVar1 = *(char *)(*plVar3 + 0x139);
    plVar4 = (longlong *)*plVar3;
    while (cVar1 == '\0') {
      cVar1 = *(char *)(*plVar4 + 0x139);
      plVar3 = plVar4;
      plVar4 = (longlong *)*plVar4;
    }
    param_1[1] = (longlong)plVar3;
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x0001401f2ab7. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  _invalid_parameter_noinfo();
  return;
}

// ==== CInnerStrengthMgr::helper_1401f3410  @1401f3410  [medium:callgraph-r3]  (orig: FUN_1401f3410)
void FUN_1401f3410(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0x139) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f3470  @1401f3470  [medium:callgraph-r3]  (orig: FUN_1401f3470)
void FUN_1401f3470(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0x139) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f3530  @1401f3530  [medium:callgraph-r3]  (orig: FUN_1401f3530)
void FUN_1401f3530(longlong param_1,longlong param_2)

{
  longlong *plVar1;
  longlong *plVar2;
  
  plVar1 = *(longlong **)(param_2 + 0x10);
  *(longlong *)(param_2 + 0x10) = *plVar1;
  if (*(char *)(*plVar1 + 0xa9) == '\0') {
    *(longlong *)(*plVar1 + 8) = param_2;
  }
  plVar1[1] = *(longlong *)(param_2 + 8);
  if (param_2 == *(longlong *)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong **)(*(longlong *)(param_1 + 0x30) + 8) = plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2 = *(longlong **)(param_2 + 8);
  if (param_2 == *plVar2) {
    *plVar2 = (longlong)plVar1;
    *plVar1 = param_2;
    *(longlong **)(param_2 + 8) = plVar1;
    return;
  }
  plVar2[2] = (longlong)plVar1;
  *plVar1 = param_2;
  *(longlong **)(param_2 + 8) = plVar1;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f3590  @1401f3590  [medium:callgraph-r3]  (orig: FUN_1401f3590)
void FUN_1401f3590(longlong param_1,longlong *param_2)

{
  longlong lVar1;
  longlong *plVar2;
  
  lVar1 = *param_2;
  *param_2 = *(longlong *)(lVar1 + 0x10);
  if (*(char *)(*(longlong *)(lVar1 + 0x10) + 0xa9) == '\0') {
    *(longlong **)(*(longlong *)(lVar1 + 0x10) + 8) = param_2;
  }
  *(longlong *)(lVar1 + 8) = param_2[1];
  if (param_2 == *(longlong **)(*(longlong *)(param_1 + 0x30) + 8)) {
    *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  plVar2 = (longlong *)param_2[1];
  if (param_2 == (longlong *)plVar2[2]) {
    plVar2[2] = lVar1;
    *(longlong **)(lVar1 + 0x10) = param_2;
    param_2[1] = lVar1;
    return;
  }
  *plVar2 = lVar1;
  *(longlong **)(lVar1 + 0x10) = param_2;
  param_2[1] = lVar1;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f40c0  @1401f40c0  [medium:callgraph-r1]  (orig: FUN_1401f40c0)
void FUN_1401f40c0(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x30);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 5) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x29) = 0;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f4170  @1401f4170  [medium:callgraph-r1]  (orig: FUN_1401f4170)
void FUN_1401f4170(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x140);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0x27) = 1;
  *(undefined1 *)((longlong)puVar1 + 0x139) = 0;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f4230  @1401f4230  [medium:callgraph-r1]  (orig: FUN_1401f4230)
void FUN_1401f4230(void)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0xb0);
  if (puVar1 != (undefined8 *)0x0) {
    *puVar1 = 0;
  }
  if (puVar1 + 1 != (undefined8 *)0x0) {
    puVar1[1] = 0;
  }
  if (puVar1 + 2 != (undefined8 *)0x0) {
    puVar1[2] = 0;
  }
  *(undefined1 *)(puVar1 + 0x15) = 1;
  *(undefined1 *)((longlong)puVar1 + 0xa9) = 0;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f4480  @1401f4480  [medium:callgraph-r2]  (orig: FUN_1401f4480)
void FUN_1401f4480(longlong param_1)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  
  plVar2 = *(longlong **)(*(longlong *)(param_1 + 0x30) + 8);
  cVar1 = *(char *)((longlong)plVar2 + 0x29);
  while (cVar1 == '\0') {
    FUN_1401f3db0(param_1,plVar2[2]);
    plVar3 = (longlong *)*plVar2;
    operator_delete(plVar2);
    plVar2 = plVar3;
    cVar1 = *(char *)((longlong)plVar3 + 0x29);
  }
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 8) = *(longlong *)(param_1 + 0x30);
  *(undefined8 *)(param_1 + 0x38) = 0;
  *(undefined8 *)*(undefined8 *)(param_1 + 0x30) = *(undefined8 *)(param_1 + 0x30);
  *(longlong *)(*(longlong *)(param_1 + 0x30) + 0x10) = *(longlong *)(param_1 + 0x30);
  return;
}

// ==== CInnerStrengthMgr::helper_1401f5930  @1401f5930  [medium:callgraph-r1]  (orig: FUN_1401f5930)
longlong * FUN_1401f5930(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  char cVar1;
  longlong lVar2;
  longlong lVar3;
  longlong lVar4;
  longlong *plVar5;
  longlong *plVar6;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar2 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar2) {
    lVar2 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar2) {
      FUN_1401f4480(param_1);
      param_2[1] = *(longlong *)param_1[6];
      *param_2 = *param_1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar2 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar3 = param_3[1];
    if (*param_3 == 0) {
      _invalid_parameter_noinfo();
    }
    lVar4 = param_3[1];
    if (*(char *)(lVar4 + 0x29) == '\0') {
      plVar6 = *(longlong **)(lVar4 + 0x10);
      if (*(char *)((longlong)plVar6 + 0x29) == '\0') {
        cVar1 = *(char *)(*plVar6 + 0x29);
        plVar5 = (longlong *)*plVar6;
        while (cVar1 == '\0') {
          cVar1 = *(char *)(*plVar5 + 0x29);
          plVar6 = plVar5;
          plVar5 = (longlong *)*plVar5;
        }
      }
      else {
        plVar6 = *(longlong **)(lVar4 + 8);
        cVar1 = *(char *)((longlong)plVar6 + 0x29);
        while ((cVar1 == '\0' && (param_3[1] == plVar6[2]))) {
          param_3[1] = (longlong)plVar6;
          plVar6 = (longlong *)plVar6[1];
          cVar1 = *(char *)((longlong)plVar6 + 0x29);
        }
      }
      param_3[1] = (longlong)plVar6;
    }
    else {
      _invalid_parameter_noinfo();
    }
    local_28 = lVar2;
    lStack_20 = lVar3;
    FUN_1401f5190(param_1,local_18,&local_28);
  }
  lVar2 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar2;
  return param_2;
}

// ==== CInnerStrengthMgr::helper_1401f7820  @1401f7820  [medium:callgraph-r0]  (orig: FUN_1401f7820)
void FUN_1401f7820(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1401f5930((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CInnerStrengthMgr::helper_1401f92f0  @1401f92f0  [medium:callgraph-r0]  (orig: FUN_1401f92f0)
undefined8 * FUN_1401f92f0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1401f40c0(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x29) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CInnerStrengthMgr::helper_1401fab10  @1401fab10  [medium:callgraph-r2]  (orig: FUN_1401fab10)
undefined8 * FUN_1401fab10(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong local_c8;
  undefined8 *puStack_c0;
  longlong local_b8;
  undefined8 *puStack_b0;
  undefined1 local_a8 [16];
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0xa9) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_50,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_50);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1401f29f0(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0xa9) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0xa9) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0xa9) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0x15;
        plVar8 = plVar8 + 0x15;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1401fad2c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0xa9) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0xa9) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0xa9);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0xa9);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0xa9) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0xa9);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0xa9);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1401fad2c:
  if ((char)plVar2[0x15] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0x15] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0x15] == '\0') {
            *(undefined1 *)(plVar9 + 0x15) = 1;
            *(undefined1 *)(plVar8 + 0x15) = 0;
            FUN_1401f3530(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0xa9) == '\0') {
            if ((*(char *)(*plVar9 + 0xa8) != '\x01') || (*(char *)(plVar9[2] + 0xa8) != '\x01')) {
              if (*(char *)(plVar9[2] + 0xa8) == '\x01') {
                *(undefined1 *)(*plVar9 + 0xa8) = 1;
                *(undefined1 *)(plVar9 + 0x15) = 0;
                FUN_1401f3590(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0x15) = (char)plVar8[0x15];
              *(undefined1 *)(plVar8 + 0x15) = 1;
              *(undefined1 *)(plVar9[2] + 0xa8) = 1;
              FUN_1401f3530(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x15) = 0;
          }
        }
        else {
          if ((char)plVar9[0x15] == '\0') {
            *(undefined1 *)(plVar9 + 0x15) = 1;
            *(undefined1 *)(plVar8 + 0x15) = 0;
            FUN_1401f3590(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0xa9) == '\0') {
            if ((*(char *)(plVar9[2] + 0xa8) != '\x01') || (*(char *)(*plVar9 + 0xa8) != '\x01')) {
              if (*(char *)(*plVar9 + 0xa8) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0xa8) = 1;
                *(undefined1 *)(plVar9 + 0x15) = 0;
                FUN_1401f3530(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0x15) = (char)plVar8[0x15];
              *(undefined1 *)(plVar8 + 0x15) = 1;
              *(undefined1 *)(*plVar9 + 0xa8) = 1;
              FUN_1401f3590(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x15) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0x15) = 1;
  }
  plVar9 = plVar2 + 0xd;
  puStack_b0 = (undefined8 *)plVar2[0x13];
  local_c8 = *plVar9;
  puStack_c0 = (undefined8 *)*puStack_b0;
  local_b8 = local_c8;
  FUN_1401dff20(plVar9,local_a8,&local_c8,&local_b8);
  operator_delete((void *)plVar2[0x13]);
  plVar2[0x13] = 0;
  plVar2[0x14] = 0;
  operator_delete((void *)*plVar9);
  plVar9 = plVar2 + 5;
  puStack_c0 = (undefined8 *)plVar2[0xb];
  local_c8 = *plVar9;
  puStack_b0 = (undefined8 *)*puStack_c0;
  local_b8 = local_c8;
  FUN_14014d1d0(plVar9,local_a8,&local_b8,&local_c8);
  operator_delete((void *)plVar2[0xb]);
  plVar2[0xb] = 0;
  plVar2[0xc] = 0;
  operator_delete((void *)*plVar9);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CInnerStrengthMgr::helper_1401fb060  @1401fb060  [medium:callgraph-r2]  (orig: FUN_1401fb060)
void FUN_1401fb060(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  undefined1 local_40 [16];
  undefined1 local_30 [24];
  
  local_48 = 0xfffffffffffffffe;
  cVar2 = *(char *)((longlong)param_2 + 0xa9);
  while (cVar2 == '\0') {
    FUN_1401fb060(param_1,param_2[2]);
    plVar3 = (longlong *)*param_2;
    plVar1 = param_2 + 0xd;
    puVar4 = (undefined8 *)param_2[0x13];
    local_c8 = (undefined4)*plVar1;
    uStack_c4 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_c0 = SUB84(puVar4,0);
    uStack_bc = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_88 = local_c8;
    uStack_84 = uStack_c4;
    uStack_80 = uStack_c0;
    uStack_7c = uStack_bc;
    uStack_b0 = (undefined4)*puVar4;
    uStack_ac = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_58 = local_c8;
    uStack_54 = uStack_c4;
    uStack_50 = uStack_b0;
    uStack_4c = uStack_ac;
    FUN_1401dff20(plVar1,local_40,&local_58,&local_88);
    operator_delete((void *)param_2[0x13]);
    param_2[0x13] = 0;
    param_2[0x14] = 0;
    operator_delete((void *)*plVar1);
    plVar1 = param_2 + 5;
    puVar4 = (undefined8 *)param_2[0xb];
    local_98 = (undefined4)*plVar1;
    uStack_94 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_90 = SUB84(puVar4,0);
    uStack_8c = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_78 = local_98;
    uStack_74 = uStack_94;
    uStack_70 = uStack_90;
    uStack_6c = uStack_8c;
    uStack_a0 = (undefined4)*puVar4;
    uStack_9c = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_68 = local_98;
    uStack_64 = uStack_94;
    uStack_60 = uStack_a0;
    uStack_5c = uStack_9c;
    FUN_14014d1d0(plVar1,local_30,&local_68,&local_78);
    operator_delete((void *)param_2[0xb]);
    param_2[0xb] = 0;
    param_2[0xc] = 0;
    operator_delete((void *)*plVar1);
    operator_delete(param_2);
    param_2 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0xa9);
  }
  return;
}

// ==== CInnerStrengthMgr::helper_1401fb8e0  @1401fb8e0  [medium:callgraph-r1]  (orig: FUN_1401fb8e0)
longlong * FUN_1401fb8e0(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar1 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar1) {
    lVar1 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar1) {
      FUN_1401fb060(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar1 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar2 = param_3[1];
    FUN_1401f29f0(param_3);
    local_28 = lVar1;
    lStack_20 = lVar2;
    FUN_1401fab10(param_1,local_18,&local_28);
  }
  lVar1 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar1;
  return param_2;
}

// ==== CInnerStrengthMgr::helper_1401fbc10  @1401fbc10  [medium:callgraph-r0]  (orig: FUN_1401fbc10)
void FUN_1401fbc10(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1401fb8e0((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CInnerStrengthMgr::helper_1401fc4c0  @1401fc4c0  [medium:callgraph-r0]  (orig: FUN_1401fc4c0)
undefined8 * FUN_1401fc4c0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1401f4230(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0xa9) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CInnerStrengthMgr::helper_1401fca40  @1401fca40  [medium:callgraph-r2]  (orig: FUN_1401fca40)
undefined8 * FUN_1401fca40(undefined8 *param_1,undefined8 *param_2,longlong param_3)

{
  char cVar1;
  longlong *plVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined8 uVar5;
  longlong *plVar6;
  longlong lVar7;
  longlong *plVar8;
  longlong *plVar9;
  longlong *plVar10;
  longlong local_c8;
  undefined8 *puStack_c0;
  longlong local_b8;
  undefined8 *puStack_b0;
  undefined1 local_a8 [16];
  undefined8 local_98;
  undefined **local_90 [3];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_78 [40];
  basic_string<char,std::char_traits<char>,std::allocator<char>_> local_50 [40];
  
  local_98 = 0xfffffffffffffffe;
  plVar2 = *(longlong **)(param_3 + 8);
  if (*(char *)((longlong)plVar2 + 0x139) != '\0') {
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_50,"invalid map/set<T> iterator");
    std::exception::exception((exception *)local_90);
    local_90[0] = std::logic_error::vftable;
    std::basic_string<char,std::char_traits<char>,std::allocator<char>_>::
    basic_string<char,std::char_traits<char>,std::allocator<char>_>
              (local_78,(basic_string<char,struct_std::char_traits<char>,class_std::allocator<char>_>
                         *)local_50);
    local_90[0] = std::out_of_range::vftable;
                    /* WARNING: Subroutine does not return */
    _CxxThrowException(local_90,(ThrowInfo *)&DAT_1409445a0);
  }
  FUN_1401f2a90(param_3);
  plVar9 = (longlong *)*plVar2;
  if (*(char *)((longlong)plVar9 + 0x139) == '\0') {
    plVar10 = plVar9;
    if (*(char *)(plVar2[2] + 0x139) == '\0') {
      plVar8 = *(longlong **)(param_3 + 8);
      plVar10 = (longlong *)plVar8[2];
      if (plVar8 != plVar2) {
        plVar9[1] = (longlong)plVar8;
        *plVar8 = *plVar2;
        plVar9 = plVar8;
        if (plVar8 != (longlong *)plVar2[2]) {
          plVar9 = (longlong *)plVar8[1];
          if (*(char *)((longlong)plVar10 + 0x139) == '\0') {
            plVar10[1] = (longlong)plVar9;
          }
          *plVar9 = (longlong)plVar10;
          plVar8[2] = plVar2[2];
          *(longlong **)(plVar2[2] + 8) = plVar8;
        }
        if (*(longlong **)(param_1[6] + 8) == plVar2) {
          *(longlong **)(param_1[6] + 8) = plVar8;
        }
        else {
          puVar4 = (undefined8 *)plVar2[1];
          if ((longlong *)*puVar4 == plVar2) {
            *puVar4 = plVar8;
          }
          else {
            puVar4[2] = plVar8;
          }
        }
        plVar8[1] = plVar2[1];
        plVar3 = plVar2 + 0x27;
        plVar8 = plVar8 + 0x27;
        if (plVar8 != plVar3) {
          lVar7 = *plVar8;
          *(char *)plVar8 = (char)*plVar3;
          *(char *)plVar3 = (char)lVar7;
        }
        goto LAB_1401fcc5c;
      }
    }
  }
  else {
    plVar10 = (longlong *)plVar2[2];
  }
  plVar9 = (longlong *)plVar2[1];
  if (*(char *)((longlong)plVar10 + 0x139) == '\0') {
    plVar10[1] = (longlong)plVar9;
  }
  if (*(longlong **)(param_1[6] + 8) == plVar2) {
    *(longlong **)(param_1[6] + 8) = plVar10;
  }
  else if ((longlong *)*plVar9 == plVar2) {
    *plVar9 = (longlong)plVar10;
  }
  else {
    plVar9[2] = (longlong)plVar10;
  }
  if (*(longlong **)param_1[6] == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x139) == '\0') {
      cVar1 = *(char *)(*plVar10 + 0x139);
      plVar3 = (longlong *)*plVar10;
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)*plVar6;
        cVar1 = *(char *)((longlong)plVar3 + 0x139);
        plVar8 = plVar6;
      }
    }
    *(longlong **)param_1[6] = plVar8;
  }
  if (*(longlong **)(param_1[6] + 0x10) == plVar2) {
    plVar8 = plVar9;
    if (*(char *)((longlong)plVar10 + 0x139) == '\0') {
      cVar1 = *(char *)(plVar10[2] + 0x139);
      plVar3 = (longlong *)plVar10[2];
      plVar8 = plVar10;
      while (plVar6 = plVar3, cVar1 == '\0') {
        plVar3 = (longlong *)plVar6[2];
        cVar1 = *(char *)((longlong)plVar3 + 0x139);
        plVar8 = plVar6;
      }
    }
    *(longlong **)(param_1[6] + 0x10) = plVar8;
  }
LAB_1401fcc5c:
  if ((char)plVar2[0x27] == '\x01') {
    if (plVar10 != *(longlong **)(param_1[6] + 8)) {
      do {
        plVar8 = plVar9;
        if ((char)plVar10[0x27] != '\x01') break;
        plVar9 = (longlong *)*plVar8;
        if (plVar10 == plVar9) {
          plVar9 = (longlong *)plVar8[2];
          if ((char)plVar9[0x27] == '\0') {
            *(undefined1 *)(plVar9 + 0x27) = 1;
            *(undefined1 *)(plVar8 + 0x27) = 0;
            FUN_1401f3410(param_1,plVar8);
            plVar9 = (longlong *)plVar8[2];
          }
          if (*(char *)((longlong)plVar9 + 0x139) == '\0') {
            if ((*(char *)(*plVar9 + 0x138) != '\x01') || (*(char *)(plVar9[2] + 0x138) != '\x01'))
            {
              if (*(char *)(plVar9[2] + 0x138) == '\x01') {
                *(undefined1 *)(*plVar9 + 0x138) = 1;
                *(undefined1 *)(plVar9 + 0x27) = 0;
                FUN_1401f3470(param_1,plVar9);
                plVar9 = (longlong *)plVar8[2];
              }
              *(char *)(plVar9 + 0x27) = (char)plVar8[0x27];
              *(undefined1 *)(plVar8 + 0x27) = 1;
              *(undefined1 *)(plVar9[2] + 0x138) = 1;
              FUN_1401f3410(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x27) = 0;
          }
        }
        else {
          if ((char)plVar9[0x27] == '\0') {
            *(undefined1 *)(plVar9 + 0x27) = 1;
            *(undefined1 *)(plVar8 + 0x27) = 0;
            FUN_1401f3470(param_1,plVar8);
            plVar9 = (longlong *)*plVar8;
          }
          if (*(char *)((longlong)plVar9 + 0x139) == '\0') {
            if ((*(char *)(plVar9[2] + 0x138) != '\x01') || (*(char *)(*plVar9 + 0x138) != '\x01'))
            {
              if (*(char *)(*plVar9 + 0x138) == '\x01') {
                *(undefined1 *)(plVar9[2] + 0x138) = 1;
                *(undefined1 *)(plVar9 + 0x27) = 0;
                FUN_1401f3410(param_1,plVar9);
                plVar9 = (longlong *)*plVar8;
              }
              *(char *)(plVar9 + 0x27) = (char)plVar8[0x27];
              *(undefined1 *)(plVar8 + 0x27) = 1;
              *(undefined1 *)(*plVar9 + 0x138) = 1;
              FUN_1401f3470(param_1,plVar8);
              break;
            }
            *(undefined1 *)(plVar9 + 0x27) = 0;
          }
        }
        plVar9 = (longlong *)plVar8[1];
        plVar10 = plVar8;
      } while (plVar8 != *(longlong **)(param_1[6] + 8));
    }
    *(undefined1 *)(plVar10 + 0x27) = 1;
  }
  plVar9 = plVar2 + 0x1f;
  puStack_b0 = (undefined8 *)plVar2[0x25];
  local_c8 = *plVar9;
  puStack_c0 = (undefined8 *)*puStack_b0;
  local_b8 = local_c8;
  FUN_1401fb460(plVar9,local_a8,&local_c8,&local_b8);
  operator_delete((void *)plVar2[0x25]);
  plVar2[0x25] = 0;
  plVar2[0x26] = 0;
  operator_delete((void *)*plVar9);
  plVar9 = plVar2 + 0x17;
  puStack_c0 = (undefined8 *)plVar2[0x1d];
  local_c8 = *plVar9;
  puStack_b0 = (undefined8 *)*puStack_c0;
  local_b8 = local_c8;
  FUN_1401dff20(plVar9,local_a8,&local_b8,&local_c8);
  operator_delete((void *)plVar2[0x1d]);
  plVar2[0x1d] = 0;
  plVar2[0x1e] = 0;
  operator_delete((void *)*plVar9);
  operator_delete(plVar2);
  if (param_1[7] != 0) {
    param_1[7] = param_1[7] + -1;
  }
  uVar5 = *(undefined8 *)(param_3 + 8);
  *param_2 = *param_1;
  param_2[1] = uVar5;
  return param_2;
}

// ==== CInnerStrengthMgr::helper_1401fcfa0  @1401fcfa0  [medium:callgraph-r2]  (orig: FUN_1401fcfa0)
void FUN_1401fcfa0(undefined8 param_1,longlong *param_2)

{
  longlong *plVar1;
  char cVar2;
  longlong *plVar3;
  undefined8 *puVar4;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b0;
  undefined4 uStack_ac;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined4 uStack_8c;
  undefined4 local_88;
  undefined4 uStack_84;
  undefined4 uStack_80;
  undefined4 uStack_7c;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined8 local_48;
  undefined1 local_40 [16];
  undefined1 local_30 [24];
  
  local_48 = 0xfffffffffffffffe;
  cVar2 = *(char *)((longlong)param_2 + 0x139);
  while (cVar2 == '\0') {
    FUN_1401fcfa0(param_1,param_2[2]);
    plVar3 = (longlong *)*param_2;
    plVar1 = param_2 + 0x1f;
    puVar4 = (undefined8 *)param_2[0x25];
    local_c8 = (undefined4)*plVar1;
    uStack_c4 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_c0 = SUB84(puVar4,0);
    uStack_bc = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_88 = local_c8;
    uStack_84 = uStack_c4;
    uStack_80 = uStack_c0;
    uStack_7c = uStack_bc;
    uStack_b0 = (undefined4)*puVar4;
    uStack_ac = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_58 = local_c8;
    uStack_54 = uStack_c4;
    uStack_50 = uStack_b0;
    uStack_4c = uStack_ac;
    FUN_1401fb460(plVar1,local_40,&local_58,&local_88);
    operator_delete((void *)param_2[0x25]);
    param_2[0x25] = 0;
    param_2[0x26] = 0;
    operator_delete((void *)*plVar1);
    plVar1 = param_2 + 0x17;
    puVar4 = (undefined8 *)param_2[0x1d];
    local_98 = (undefined4)*plVar1;
    uStack_94 = (undefined4)((ulonglong)*plVar1 >> 0x20);
    uStack_90 = SUB84(puVar4,0);
    uStack_8c = (undefined4)((ulonglong)puVar4 >> 0x20);
    local_78 = local_98;
    uStack_74 = uStack_94;
    uStack_70 = uStack_90;
    uStack_6c = uStack_8c;
    uStack_a0 = (undefined4)*puVar4;
    uStack_9c = (undefined4)((ulonglong)*puVar4 >> 0x20);
    local_68 = local_98;
    uStack_64 = uStack_94;
    uStack_60 = uStack_a0;
    uStack_5c = uStack_9c;
    FUN_1401dff20(plVar1,local_30,&local_68,&local_78);
    operator_delete((void *)param_2[0x1d]);
    param_2[0x1d] = 0;
    param_2[0x1e] = 0;
    operator_delete((void *)*plVar1);
    operator_delete(param_2);
    param_2 = plVar3;
    cVar2 = *(char *)((longlong)plVar3 + 0x139);
  }
  return;
}

// ==== CInnerStrengthMgr::helper_1401fdc70  @1401fdc70  [medium:callgraph-r1]  (orig: FUN_1401fdc70)
longlong * FUN_1401fdc70(longlong *param_1,longlong *param_2,longlong *param_3,longlong *param_4)

{
  longlong lVar1;
  longlong lVar2;
  longlong local_28;
  longlong lStack_20;
  undefined1 local_18 [16];
  
  lVar1 = *(longlong *)param_1[6];
  if ((*param_3 == 0) || (*param_3 != *param_1)) {
    _invalid_parameter_noinfo();
  }
  if (param_3[1] == lVar1) {
    lVar1 = param_1[6];
    if ((*param_4 == 0) || (*param_4 != *param_1)) {
      _invalid_parameter_noinfo();
    }
    if (param_4[1] == lVar1) {
      FUN_1401fcfa0(param_1,*(undefined8 *)(param_1[6] + 8));
      *(longlong *)(param_1[6] + 8) = param_1[6];
      param_1[7] = 0;
      *(longlong *)param_1[6] = param_1[6];
      *(longlong *)(param_1[6] + 0x10) = param_1[6];
      lVar1 = *(longlong *)param_1[6];
      *param_2 = *param_1;
      param_2[1] = lVar1;
      return param_2;
    }
  }
  while( true ) {
    if ((*param_3 == 0) || (*param_3 != *param_4)) {
      _invalid_parameter_noinfo();
    }
    lVar1 = *param_3;
    if (param_3[1] == param_4[1]) break;
    lVar2 = param_3[1];
    FUN_1401f2a90(param_3);
    local_28 = lVar1;
    lStack_20 = lVar2;
    FUN_1401fca40(param_1,local_18,&local_28);
  }
  lVar1 = param_3[1];
  *param_2 = *param_1;
  param_2[1] = lVar1;
  return param_2;
}

// ==== CInnerStrengthMgr::helper_1401fde60  @1401fde60  [medium:callgraph-r0]  (orig: FUN_1401fde60)
void FUN_1401fde60(undefined8 *param_1)

{
  undefined8 local_38;
  undefined8 *puStack_30;
  undefined8 local_28;
  undefined8 uStack_20;
  undefined1 local_18 [16];
  
  local_38 = *param_1;
  puStack_30 = (undefined8 *)param_1[6];
  uStack_20 = *puStack_30;
  local_28 = local_38;
  FUN_1401fdc70((undefined4)local_38,local_18,&local_28,&local_38);
  operator_delete((void *)param_1[6]);
  param_1[6] = 0;
  param_1[7] = 0;
  return;
}

// ==== CInnerStrengthMgr::ctor_or_dtor  @1401fdf30  [high:vtable-assign]  (orig: FUN_1401fdf30)
void FUN_1401fdf30(undefined8 *param_1)

{
  *param_1 = CInnerStrengthMgr::vftable;
  FUN_140050610(param_1 + 0x1b);
  operator_delete((void *)param_1[0x1b]);
  FUN_1401fbc10(param_1 + 0x13);
  operator_delete((void *)param_1[0x13]);
  FUN_1401fde60(param_1 + 0xb);
  operator_delete((void *)param_1[0xb]);
  FUN_1401f7820(param_1 + 3);
  operator_delete((void *)param_1[3]);
  return;
}

// ==== CInnerStrengthMgr::helper_1401fdfd0  @1401fdfd0  [medium:callgraph-r0]  (orig: FUN_1401fdfd0)
undefined8 * FUN_1401fdfd0(undefined8 *param_1)

{
  undefined8 *puVar1;
  longlong lVar2;
  
  puVar1 = operator_new(8);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (void *)0x0;
  }
  else {
    *puVar1 = param_1;
  }
  *param_1 = puVar1;
  lVar2 = FUN_1401f4170(param_1);
  param_1[6] = lVar2;
  *(undefined1 *)(lVar2 + 0x139) = 1;
  *(undefined8 *)(param_1[6] + 8) = param_1[6];
  *(undefined8 *)param_1[6] = param_1[6];
  *(undefined8 *)(param_1[6] + 0x10) = param_1[6];
  param_1[7] = 0;
  return param_1;
}

// ==== CInnerStrengthMgr::ctor_or_dtor  @1401fe050  [high:vtable-assign]  (orig: FUN_1401fe050)
undefined8 * FUN_1401fe050(undefined8 *param_1,undefined4 param_2)

{
  *param_1 = CInnerStrengthMgr::vftable;
  *(undefined4 *)(param_1 + 1) = param_2;
  FUN_1401f92f0(param_1 + 3);
  FUN_1401fdfd0(param_1 + 0xb);
  FUN_1401fc4c0(param_1 + 0x13);
  FUN_1400546e0(param_1 + 0x1b);
  return param_1;
}

// ==== CInnerStrengthMgr::vfunc_0  @1401fe0b0  [high:rtti-vtable]  (orig: FUN_1401fe0b0)
void * FUN_1401fe0b0(void *param_1,uint param_2)

{
  FUN_1401fdf30();
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CInnerStrengthMgr::ctor_or_dtor  @1401fe0e0  [high:vtable-assign]  (orig: FUN_1401fe0e0)
undefined8 * FUN_1401fe0e0(undefined4 param_1)

{
  undefined8 *puVar1;
  
  puVar1 = operator_new(0x118);
  if (puVar1 == (undefined8 *)0x0) {
    puVar1 = (undefined8 *)0x0;
  }
  else {
    *puVar1 = CInnerStrengthMgr::vftable;
    *(undefined4 *)(puVar1 + 1) = param_1;
    FUN_1401f92f0(puVar1 + 3);
    FUN_1401fdfd0(puVar1 + 0xb);
    FUN_1401fc4c0(puVar1 + 0x13);
    FUN_1400546e0(puVar1 + 0x1b);
  }
  if (puVar1 == (undefined8 *)0x0) {
    log_InlineLogERROR(&DAT_1406d9c10);
    puVar1 = (undefined8 *)0x0;
  }
  return puVar1;
}

