// ==== CMsgTalk::helper_1400f9db0  @1400f9db0  [medium:callgraph-r1]  (orig: FUN_1400f9db0)
uint FUN_1400f9db0(undefined8 param_1,byte *param_2,int param_3)

{
  uint uVar1;
  
  uVar1 = 0;
  for (; param_3 != 0; param_3 = param_3 + -1) {
    uVar1 = *(uint *)(&DAT_14094c0f0 + (ulonglong)(uVar1 >> 0x18) * 4) ^
            (uVar1 << 8 | (uint)*param_2);
    param_2 = param_2 + 1;
  }
  return uVar1;
}

// ==== CMsgTalk::helper_1400fa440  @1400fa440  [medium:callgraph-r0]  (orig: FUN_1400fa440)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined8 FUN_1400fa440(longlong param_1,char *param_2)

{
  byte bVar1;
  int iVar2;
  undefined4 uVar3;
  void *_Memory;
  undefined8 uVar4;
  ulonglong uVar5;
  void *pvVar6;
  ulonglong uVar7;
  ulonglong uVar8;
  byte *pbVar9;
  undefined1 auStack_e8 [32];
  undefined4 local_c8;
  uint local_b8;
  int local_b4 [3];
  byte local_a8 [128];
  ulonglong local_28;
  
  local_28 = DAT_1409707c0 ^ (ulonglong)auStack_e8;
  _Memory = calloc(1,(longlong)(*(int *)(param_1 + 0x10) * 5));
  local_b8 = *(int *)(param_1 + 0x10) * 5;
  if (_Memory == (void *)0x0) {
    local_c8 = 0x18a;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar4 = 0;
  }
  else {
    iVar2 = uncompress(_Memory,&local_b8,*(undefined8 *)(param_1 + 0x18));
    if (iVar2 == 0) {
      local_a8[0] = 0;
      memset(local_a8 + 1,0,0x7f);
      tq::SafeCopy((char *)local_a8,param_2,0x80);
      uVar7 = 0xffffffffffffffff;
      uVar5 = 0;
      pbVar9 = local_a8;
      do {
        if (uVar7 == 0) break;
        uVar7 = uVar7 - 1;
        bVar1 = *pbVar9;
        pbVar9 = pbVar9 + 1;
      } while (bVar1 != 0);
      uVar7 = ~uVar7 - 1;
      if (uVar7 != 0) {
        do {
          uVar8 = uVar5 + 1;
          local_a8[uVar5] = local_a8[uVar5] ^ (&DAT_1407079c0)[uVar5 % 0x16];
          uVar5 = uVar8;
        } while (uVar8 < uVar7);
      }
      uVar5 = (ulonglong)local_b8;
      if (uVar5 + 1 + uVar7 < (ulonglong)(uint)(*(int *)(param_1 + 0x10) * 5)) {
        *(char *)(uVar5 + (longlong)_Memory) = (char)uVar7;
        memcpy((void *)(uVar5 + 1 + (longlong)_Memory),local_a8,uVar7);
        local_b8 = local_b8 + 1 + (int)uVar7;
        iVar2 = local_b8 + 0x400;
        pvVar6 = calloc(1,(longlong)iVar2);
        local_b4[0] = iVar2;
        iVar2 = compress(pvVar6,local_b4,_Memory,local_b8);
        if (iVar2 == 0) {
          free(_Memory);
          free(*(void **)(param_1 + 0x18));
          *(void **)(param_1 + 0x18) = pvVar6;
          *(int *)(param_1 + 0x10) = local_b4[0];
          uVar3 = FUN_1400f9db0(param_1,pvVar6);
          *(undefined4 *)(param_1 + 0xc) = uVar3;
          uVar4 = 1;
        }
        else {
          free(_Memory);
          log_InlineLogERROR("2 compress StrCheckKey failed.%u");
          uVar4 = 0;
        }
      }
      else {
        local_c8 = 0x199;
        log_InlineLogERROR(&DAT_1406d9c10);
        uVar4 = 0;
      }
    }
    else {
      free(_Memory);
      log_InlineLogERROR("uncompress StrCheckKey failed. %u");
      uVar4 = 0;
    }
  }
  return uVar4;
}

// ==== CMsgTalk::helper_1400fb8a0  @1400fb8a0  [medium:callgraph-r1]  (orig: FUN_1400fb8a0)
ulonglong FUN_1400fb8a0(longlong param_1,uint param_2)

{
  char cVar1;
  ulonglong uVar2;
  ulonglong uVar3;
  undefined8 *puVar4;
  undefined8 *puVar5;
  ulonglong extraout_RAX;
  ulonglong uVar6;
  longlong *plVar7;
  ulonglong extraout_RAX_00;
  longlong *plVar8;
  undefined8 *puVar9;
  longlong lVar10;
  longlong lVar11;
  uint local_res10 [2];
  longlong local_38;
  undefined8 *local_30;
  longlong local_28;
  undefined8 local_20;
  
  puVar9 = (undefined8 *)(*(undefined8 **)(param_1 + 0xd8))[1];
  cVar1 = *(char *)((longlong)puVar9 + 0x21);
  puVar4 = *(undefined8 **)(param_1 + 0xd8);
  while (cVar1 == '\0') {
    if (*(uint *)(puVar9 + 3) < param_2) {
      puVar5 = (undefined8 *)puVar9[2];
      puVar9 = puVar4;
    }
    else {
      puVar5 = (undefined8 *)*puVar9;
    }
    puVar4 = puVar9;
    puVar9 = puVar5;
    cVar1 = *(char *)((longlong)puVar5 + 0x21);
  }
  puVar9 = *(undefined8 **)(param_1 + 0xd8);
  local_30 = puVar4;
  local_38 = *(longlong *)(param_1 + 0xa8);
  local_res10[0] = param_2;
  if (*(longlong *)(param_1 + 0xa8) == 0) {
    _invalid_parameter_noinfo();
  }
  if ((puVar4 == puVar9) || (param_2 < *(uint *)(puVar4 + 3))) {
    plVar8 = &local_28;
    local_20 = *(undefined8 *)(param_1 + 0xd8);
    local_28 = *(longlong *)(param_1 + 0xa8);
  }
  else {
    plVar8 = &local_38;
  }
  plVar7 = (longlong *)*plVar8;
  uVar2 = *(ulonglong *)(param_1 + 0xd8);
  uVar3 = plVar8[1];
  if ((plVar7 == (longlong *)0x0) || (uVar6 = uVar3, plVar7 != *(longlong **)(param_1 + 0xa8))) {
    _invalid_parameter_noinfo();
    uVar6 = extraout_RAX;
  }
  if (uVar3 != uVar2) {
    lVar10 = 0;
    if (plVar7 == (longlong *)0x0) {
      _invalid_parameter_noinfo();
      lVar11 = lVar10;
    }
    else {
      lVar11 = *plVar7;
    }
    if (uVar3 == *(ulonglong *)(lVar11 + 0x30)) {
      _invalid_parameter_noinfo();
    }
    uVar6 = (ulonglong)*(uint *)(param_1 + 8);
    if (*(uint *)(uVar3 + 0x1c) == *(uint *)(param_1 + 8)) {
      plVar7 = (longlong *)FUN_140050f20(param_1 + 0x68,&local_28,local_res10);
      uVar2 = *(ulonglong *)(param_1 + 0x98);
      plVar8 = (longlong *)*plVar7;
      uVar3 = plVar7[1];
      if ((plVar8 == (longlong *)0x0) || (uVar6 = uVar3, plVar8 != *(longlong **)(param_1 + 0x68)))
      {
        _invalid_parameter_noinfo();
        uVar6 = extraout_RAX_00;
      }
      if (uVar3 != uVar2) {
        if (plVar8 == (longlong *)0x0) {
          _invalid_parameter_noinfo();
        }
        else {
          lVar10 = *plVar8;
        }
        if (uVar3 == *(ulonglong *)(lVar10 + 0x30)) {
          _invalid_parameter_noinfo();
        }
        return (ulonglong)
               CONCAT31((int3)((uint)*(int *)(param_1 + 0xc) >> 8),
                        *(int *)(uVar3 + 0x1c) == *(int *)(param_1 + 0xc));
      }
    }
  }
  return uVar6 & 0xffffffffffffff00;
}

// ==== CMsgTalk::helper_1400fc000  @1400fc000  [medium:callgraph-r0]  (orig: FUN_1400fc000)
void FUN_1400fc000(longlong param_1)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  longlong *plVar3;
  char cVar4;
  undefined4 uVar5;
  longlong lVar6;
  ulonglong uVar7;
  longlong lVar8;
  undefined4 local_res8 [2];
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  undefined1 local_48 [8];
  undefined1 local_40 [24];
  longlong *local_28;
  longlong *local_20;
  
  FUN_140036640(param_1 + 0x28);
  lVar6 = FUN_140008520(*(undefined4 *)(param_1 + 0x60));
  if (*(longlong *)(lVar6 + 0x90) == 0) {
    log_InlineLogERROR(&DAT_1406d9c10);
  }
  FUN_1402ac340(*(undefined8 *)(lVar6 + 0x90),local_48);
LAB_1400fc080:
  while( true ) {
    do {
      do {
        cVar4 = FUN_1400ce310(local_40);
        while( true ) {
          if (cVar4 == '\0') {
            return;
          }
          cVar4 = (**(code **)(*local_28 + 0x298))(local_28,0x1001,&local_20);
          if (cVar4 != '\0') break;
          cVar4 = FUN_1400ce310(local_40);
        }
      } while (local_20 == (longlong *)0x0);
      uVar5 = (**(code **)(*local_20 + 8))();
      local_res8[0] = uVar5;
      cVar4 = FUN_1400fb8a0(param_1,uVar5);
    } while (cVar4 != '\0');
    puVar1 = *(undefined4 **)(param_1 + 0x40);
    if (puVar1 == (undefined4 *)0x0) {
      uVar7 = 0;
    }
    else {
      uVar7 = *(longlong *)(param_1 + 0x50) - (longlong)puVar1 >> 2;
    }
    puVar2 = *(undefined4 **)(param_1 + 0x48);
    if (uVar7 <= (ulonglong)((longlong)puVar2 - (longlong)puVar1 >> 2)) break;
    *puVar2 = uVar5;
    *(undefined4 **)(param_1 + 0x48) = puVar2 + 1;
  }
  if (puVar2 < puVar1) {
    _invalid_parameter_noinfo();
  }
  uVar7 = *(ulonglong *)(param_1 + 0x40);
  lVar6 = *(longlong *)(param_1 + 0x28);
  if ((*(ulonglong *)(param_1 + 0x48) - uVar7 & 0xfffffffffffffffc) == 0) {
    lVar8 = 0;
  }
  else {
    if (*(ulonglong *)(param_1 + 0x48) < uVar7) {
      _invalid_parameter_noinfo();
    }
    if ((lVar6 == 0) || (lVar6 != *(longlong *)(param_1 + 0x28))) {
      _invalid_parameter_noinfo();
    }
    lVar8 = (longlong)((longlong)puVar2 - uVar7) >> 2;
  }
  local_68 = (undefined4)lVar6;
  uStack_64 = (undefined4)((ulonglong)lVar6 >> 0x20);
  uStack_60 = SUB84(puVar2,0);
  uStack_5c = (undefined4)((ulonglong)puVar2 >> 0x20);
  local_58 = local_68;
  uStack_54 = uStack_64;
  uStack_50 = uStack_60;
  uStack_4c = uStack_5c;
  FUN_140036c20(param_1 + 0x28,&local_58,1,local_res8);
  uVar7 = *(ulonglong *)(param_1 + 0x40);
  if (*(ulonglong *)(param_1 + 0x48) < uVar7) {
    _invalid_parameter_noinfo();
  }
  plVar3 = *(longlong **)(param_1 + 0x28);
  if (plVar3 == (longlong *)0x0) {
    _invalid_parameter_noinfo();
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar3;
  }
  uVar7 = uVar7 + lVar8 * 4;
  if (uVar7 <= *(ulonglong *)(lVar6 + 0x20)) goto code_r0x0001400fc1f2;
  goto LAB_1400fc208;
code_r0x0001400fc1f2:
  if (plVar3 == (longlong *)0x0) {
    lVar6 = 0;
  }
  else {
    lVar6 = *plVar3;
  }
  if (uVar7 < *(ulonglong *)(lVar6 + 0x18)) {
LAB_1400fc208:
    _invalid_parameter_noinfo();
  }
  goto LAB_1400fc080;
}

// ==== CMsgTalk::ctor_or_dtor  @14015b240  [high:vtable-assign]  (orig: FUN_14015b240)
undefined8 * FUN_14015b240(undefined8 *param_1)

{
  FUN_1402ba1c0();
  *param_1 = CMsgTalk::vftable;
  tq::CStringPacker::CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b5600(param_1);
  param_1[0x85] = param_1 + 2;
  tq::CStringPacker::SetBuf
            ((CStringPacker *)(param_1 + 0x86),(char *)((longlong)param_1 + 0x2d),0x3e1,true);
  return param_1;
}

// ==== CMsgTalk::ctor_or_dtor  @14015b2c0  [high:vtable-assign]  (orig: FUN_14015b2c0)
void FUN_14015b2c0(undefined8 *param_1)

{
  *param_1 = CMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  return;
}

// ==== CMsgTalk::vfunc_1  @14015b4d0  [high:rtti-vtable]  (orig: FUN_14015b4d0)
undefined8 FUN_14015b4d0(longlong param_1,void *param_2,uint param_3)

{
  if (param_2 == (void *)0x0) {
    return 0;
  }
  memcpy((void *)(param_1 + 0x10),param_2,(ulonglong)param_3);
  return 1;
}

// ==== CMsgTalk::ctor_or_dtor  @14015b570  [high:vtable-assign]  (orig: FUN_14015b570)
undefined8 * FUN_14015b570(undefined8 *param_1,uint param_2)

{
  *param_1 = CMsgTalk::vftable;
  tq::CStringPacker::~CStringPacker((CStringPacker *)(param_1 + 0x86));
  FUN_1402b55f0(param_1);
  if ((param_2 & 1) != 0) {
    operator_delete(param_1);
  }
  return param_1;
}

// ==== CMsgTalk::vfunc_3  @14015b5d0  [high:rtti-vtable]  (orig: FUN_14015b5d0)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

void FUN_14015b5d0(longlong param_1)

{
  int *piVar1;
  short sVar2;
  undefined4 *puVar3;
  longlong lVar4;
  char cVar5;
  char cVar6;
  bool bVar7;
  bool bVar8;
  bool bVar9;
  ushort uVar10;
  undefined4 uVar11;
  int iVar12;
  int iVar13;
  ulong uVar14;
  uint uVar15;
  undefined4 uVar16;
  longlong lVar17;
  longlong *plVar18;
  char *pcVar19;
  undefined8 uVar20;
  longlong *plVar21;
  IStringManager *pIVar22;
  ulonglong uVar23;
  ulonglong uVar24;
  char *pcVar25;
  bool bVar26;
  undefined1 auStack_f78 [32];
  char *local_f58;
  longlong *local_f48;
  undefined2 local_f40;
  undefined2 local_f3e;
  undefined8 local_f38;
  undefined1 local_f28 [8];
  undefined4 local_f20;
  int local_f1c;
  ulong *local_b00;
  CStringPacker local_af8 [32];
  char local_ad8;
  undefined8 local_ad7;
  undefined4 local_acf;
  undefined2 local_acb;
  undefined1 local_ac9;
  char local_ac8;
  undefined8 local_ac7;
  undefined4 local_abf;
  undefined2 local_abb;
  undefined1 local_ab9;
  char local_ab8;
  undefined8 local_ab7;
  undefined8 local_aaf;
  undefined8 local_aa7;
  undefined8 local_a9f;
  undefined8 local_a97;
  undefined8 local_a8f;
  undefined8 local_a87;
  undefined4 local_a7f;
  undefined2 local_a7b;
  undefined1 local_a79;
  char local_a78;
  undefined8 local_a77;
  undefined4 local_a6f;
  undefined2 local_a6b;
  undefined1 local_a69;
  char local_a68;
  undefined8 local_a67;
  undefined4 local_a5f;
  undefined2 local_a5b;
  undefined1 local_a59;
  char local_a58;
  undefined8 local_a57;
  undefined4 local_a4f;
  undefined2 local_a4b;
  undefined1 local_a49;
  char local_a48 [4];
  char local_a44 [252];
  undefined4 local_948;
  undefined2 local_944;
  undefined1 local_942;
  undefined1 local_941 [249];
  char local_848 [4];
  char local_844 [252];
  undefined1 local_748;
  undefined1 local_747 [255];
  undefined8 local_648;
  undefined1 local_238;
  undefined1 local_237 [255];
  undefined1 local_138;
  undefined1 local_137 [255];
  ulonglong local_38;
  
  local_f38 = 0xfffffffffffffffe;
  local_38 = DAT_1409707c0 ^ (ulonglong)auStack_f78;
  local_ac8 = '\0';
  local_ac7 = 0;
  local_abf = 0;
  local_abb = 0;
  local_ab9 = 0;
  local_ad8 = '\0';
  local_ad7 = 0;
  local_acf = 0;
  local_acb = 0;
  local_ac9 = 0;
  local_a78 = '\0';
  local_a77 = 0;
  local_a6f = 0;
  local_a6b = 0;
  local_a69 = 0;
  local_a48[0] = '\0';
  memset(local_a48 + 1,0,0xff);
  local_a68 = '\0';
  local_a67 = 0;
  local_a5f = 0;
  local_a5b = 0;
  local_a59 = 0;
  local_a58 = '\0';
  local_a57 = 0;
  local_a4f = 0;
  local_a4b = 0;
  local_a49 = 0;
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),0,&local_ac8,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),1,&local_ad8,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),2,&local_a78,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),3,local_a48,0x100);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),4,&local_a68,0x10);
  tq::CStringPacker::GetString((CStringPacker *)(param_1 + 0x430),5,&local_a58,0x10);
  uVar23 = 0xffffffffffffffff;
  pcVar19 = local_a48;
  do {
    if (uVar23 == 0) break;
    uVar23 = uVar23 - 1;
    cVar5 = *pcVar19;
    pcVar19 = pcVar19 + 1;
  } while (cVar5 != '\0');
  if (0xff < ~uVar23 - 1) {
    local_f58 = (char *)CONCAT44(local_f58._4_4_,0x6b);
    log_InlineLogERROR(&DAT_1406d9c10,"CHECK","strlen(szWords) <= 255",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgtalk.cpp"
                      );
    return;
  }
  lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
  if (*(longlong *)(lVar17 + 0x88) == 0) {
    local_f58 = (char *)CONCAT44(local_f58._4_4_,0x12f);
    log_InlineLogERROR(&DAT_1406d9c10,"ASSERT","m_pRoleManager",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h");
  }
  plVar18 = (longlong *)
            (**(code **)(**(longlong **)(lVar17 + 0x88) + 0x18))
                      (*(longlong **)(lVar17 + 0x88),param_1,0);
  if (plVar18 == (longlong *)0x0) {
    return;
  }
  uVar23 = 0;
  local_f48 = (longlong *)0x0;
  (**(code **)(*plVar18 + 0x298))(plVar18,0x1001,&local_f48);
  if (local_f48 != (longlong *)0x0) {
    pcVar19 = (char *)(**(code **)(local_f48[2] + 0x18))();
    lVar17 = -(longlong)pcVar19;
    do {
      cVar5 = *pcVar19;
      cVar6 = pcVar19[(longlong)(&local_ac8 + lVar17)];
      if (cVar5 != cVar6) break;
      pcVar19 = pcVar19 + 1;
    } while (cVar6 != '\0');
    if ((cVar5 != cVar6) && (cVar5 = (**(code **)(local_f48[2] + 0x230))(), cVar5 == '\0')) {
      uVar20 = (**(code **)(local_f48[2] + 0x18))();
      tq::GmLogSave("gm",&DAT_1406e8b68,uVar20,&local_ac8);
      return;
    }
    if (local_f48 != (longlong *)0x0) {
      plVar21 = (longlong *)FUN_1400e1e60();
      lVar4 = local_f48[0x1e2];
      lVar17 = *plVar21;
      puVar3 = *(undefined4 **)(param_1 + 0x428);
      uVar11 = (**(code **)(*local_f48 + 8))();
      (**(code **)(lVar17 + 0x108))(plVar21,uVar11,(int)lVar4,*puVar3);
    }
  }
  cVar5 = (**(code **)(*plVar18 + 0x228))(plVar18);
  if (cVar5 == '\0') {
    pIVar22 = theInstance();
    lVar17 = *plVar18;
    uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_CAN_NOT_TALK");
    (**(code **)(lVar17 + 0x358))(plVar18,uVar20);
    return;
  }
  if (local_f48 != (longlong *)0x0) {
    cVar5 = FUN_1401765e0(local_f48,*(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8));
    if (cVar5 != '\0') {
      return;
    }
    if (local_f48 != (longlong *)0x0) {
      if ((int)local_f48[0x1f8] == 1) {
        return;
      }
      cVar5 = (**(code **)(local_f48[2] + 0x230))();
      if (cVar5 != '\0') {
        local_f58 = local_a48;
        tq::GmLogSave("gm","-TALK %s->%s: %s",&local_ac8,&local_ad8);
      }
      if (local_f48 != (longlong *)0x0) {
        uVar15 = *(uint *)(*(longlong *)(param_1 + 0x428) + 0x10);
        if ((999999 < uVar15) && (uVar15 < 0x1e8481)) {
          if (DAT_140975c38 == 0) {
            return;
          }
          (**(code **)(*(longlong *)(DAT_140975c38 + 0x10) + 0x350))
                    ((longlong *)(DAT_140975c38 + 0x10),param_1);
          return;
        }
        if (local_a48[0] == '/') {
          iVar12 = _stricmp(local_a48,"/afgetghserveraaversion");
          if (iVar12 == 0) {
            local_ab8 = '\0';
            local_ab7 = 0;
            local_aaf = 0;
            local_aa7 = 0;
            local_a9f = 0;
            local_a97 = 0;
            local_a8f = 0;
            local_a87 = 0;
            local_a7f = 0;
            local_a7b = 0;
            local_a79 = 0;
            _snprintf(&local_ab8,0x40,
                      "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgtalk.cpp"
                     );
            local_a79 = 0;
            (**(code **)(local_f48[2] + 0x358))(local_f48 + 2,&local_ab8);
            return;
          }
          iVar12 = _stricmp(local_a48,"/afgetghserveraaip");
          if (iVar12 == 0) {
            local_948 = local_948 & 0xffffff00;
            memset((void *)((longlong)&local_948 + 1),0,0xfe);
            iVar12 = Ordinal_57(&local_948,0xff);
            if (iVar12 == -1) {
              return;
            }
            lVar17 = Ordinal_52(&local_948);
            if (lVar17 == 0) {
              return;
            }
            local_ab8 = '\0';
            local_ab7 = 0;
            local_aaf = 0;
            local_aa7 = 0;
            local_a9f = 0;
            local_a97 = 0;
            local_a8f = 0;
            local_a87 = 0;
            local_a7f = 0;
            local_a7b = 0;
            local_a79 = 0;
            plVar18 = *(longlong **)(lVar17 + 0x18);
            lVar4 = *plVar18;
            uVar24 = uVar23;
            while (lVar4 != 0) {
              pcVar19 = (char *)Ordinal_12(**(undefined4 **)(uVar24 + (longlong)plVar18));
              iVar12 = _stricmp(pcVar19,"127.0.0.1");
              if (iVar12 != 0) {
                local_f58 = pcVar19;
                _snprintf(&local_ab8,0x40,"%s%s ",&local_ab8);
                local_a79 = 0;
              }
              uVar23 = uVar23 + 1;
              uVar24 = uVar23 * 8;
              plVar18 = *(longlong **)(lVar17 + 0x18);
              lVar4 = plVar18[uVar23];
            }
            (**(code **)(local_f48[2] + 0x358))(local_f48 + 2,&local_ab8);
            return;
          }
        }
        if (local_f48 != (longlong *)0x0) {
          cVar6 = (**(code **)(local_f48[2] + 0x230))();
          cVar5 = local_a48[0];
          if ((cVar6 != '\0') && ((local_a48[0] == '/' || (local_a48[3] == '/')))) {
            local_948 = DAT_140713ecc;
            local_944 = DAT_140713ed0;
            local_942 = DAT_140713ed2;
            memset(local_941,0,0xf9);
            local_238 = 0;
            memset(local_237,0,0xff);
            local_138 = 0;
            memset(local_137,0,0xff);
            memset(local_848,0,0x100);
            if (cVar5 == '/') {
              uVar24 = 0xffffffffffffffff;
              pcVar19 = local_a48;
              do {
                if (uVar24 == 0) break;
                uVar24 = uVar24 - 1;
                cVar5 = *pcVar19;
                pcVar19 = pcVar19 + 1;
              } while (cVar5 != '\0');
              tq::SafeCopy(local_848,local_a48 + 1,~uVar24 - 1);
            }
            else if (local_a48[3] == '/') {
              uVar24 = 0xffffffffffffffff;
              pcVar19 = local_a48;
              do {
                if (uVar24 == 0) break;
                uVar24 = uVar24 - 1;
                cVar5 = *pcVar19;
                pcVar19 = pcVar19 + 1;
              } while (cVar5 != '\0');
              tq::SafeCopy(local_848,local_a44,~uVar24 - 7);
            }
            local_f58 = &local_138;
            iVar12 = sscanf(local_848,"%s %s %s",&local_948,&local_238);
            lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            if (*(longlong *)(lVar17 + 0x198) == 0) {
              local_f58 = (char *)CONCAT44(local_f58._4_4_,0x156);
              log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pPMMgr",
                                 "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                );
              uVar24 = uVar23;
            }
            else {
              uVar24 = *(ulonglong *)(lVar17 + 0x198);
            }
            cVar5 = FUN_1402a1ce0(uVar24,local_848,local_f48);
            if (cVar5 != '\0') {
              return;
            }
            iVar13 = _stricmp((char *)&local_948,"uncongealAccount");
            if (iVar13 == 0) {
              *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7db;
              cVar5 = (**(code **)(local_f48[2] + 0x230))();
              if (cVar5 != '\0') {
                plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
                (**(code **)(*plVar18 + 0xa0))(plVar18,param_1);
              }
            }
            iVar13 = _stricmp((char *)&local_948,"StrCheckKeyAdd");
            if (iVar13 == 0) {
              local_748 = 0;
              memset(local_747,0,0xff);
              iVar12 = sscanf(local_a48 + 1,"%s %s",&local_948,&local_748);
              if (iVar12 != 2) {
                return;
              }
              lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              if (*(longlong *)(lVar17 + 0x168) == 0) {
                local_f58 = (char *)CONCAT44(local_f58._4_4_,0x150);
                log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pStrCheckKey",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                  );
                uVar24 = uVar23;
              }
              else {
                uVar24 = *(ulonglong *)(lVar17 + 0x168);
              }
              FUN_1400fa440(uVar24,&local_748);
              lVar17 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              if (*(longlong *)(lVar17 + 0x168) == 0) {
                local_f58 = (char *)CONCAT44(local_f58._4_4_,0x150);
                log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","m_pStrCheckKey",
                                   "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\mapgroup.h"
                                  );
              }
              else {
                uVar23 = *(ulonglong *)(lVar17 + 0x168);
              }
              FUN_1400fc000(uVar23);
              return;
            }
            iVar13 = _stricmp((char *)&local_948,"lock");
            if (iVar13 == 0) {
              if (iVar12 != 2) {
                return;
              }
              cVar5 = (**(code **)(local_f48[2] + 0x230))();
              if (cVar5 == '\0') {
                return;
              }
              *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7db;
              plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              (**(code **)(*plVar18 + 0xa0))(plVar18,param_1);
              return;
            }
            iVar13 = _stricmp((char *)&local_948,"unlock");
            if (iVar13 == 0) {
              *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7db;
              if (iVar12 != 2) {
                return;
              }
              cVar5 = (**(code **)(local_f48[2] + 0x230))();
              if (cVar5 == '\0') {
                return;
              }
              plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              (**(code **)(*plVar18 + 0xa0))(plVar18,param_1);
              return;
            }
            iVar12 = _stricmp((char *)&local_948,"kickoutall");
            if (iVar12 == 0) {
              cVar5 = (**(code **)(local_f48[2] + 0x230))();
              if (cVar5 == '\0') {
                return;
              }
              log_InlineLogMessage("kickoutall process!");
              pIVar22 = theInstance();
              lVar17 = local_f48[2];
              uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_KICKOUT_ALL");
              (**(code **)(lVar17 + 0x358))(local_f48 + 2,uVar20);
              plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              (**(code **)(*plVar18 + 200))(plVar18,"Server stop by GM, close server please!");
              plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              (**(code **)(*plVar18 + 0xd8))(plVar18,*(undefined4 *)(param_1 + 0x414));
              return;
            }
            iVar12 = _stricmp((char *)&local_948,"web");
            if (iVar12 != 0) {
              return;
            }
            cVar5 = (**(code **)(local_f48[2] + 0x230))();
            if (cVar5 == '\0') {
              return;
            }
            lVar17 = 9;
            bVar26 = false;
            pcVar19 = &local_ad8;
            pcVar25 = "ALLUSERS";
            do {
              if (lVar17 == 0) break;
              lVar17 = lVar17 + -1;
              bVar26 = *pcVar19 == *pcVar25;
              pcVar19 = pcVar19 + 1;
              pcVar25 = pcVar25 + 1;
            } while (bVar26);
            if (bVar26) {
              return;
            }
            local_648 = (undefined **)((ulonglong)local_648 & 0xffffffffffffff00);
            memset((void *)((longlong)&local_648 + 1),0,0x3ff);
            pcVar19 = local_844;
            pcVar25 = (char *)&local_648;
            do {
              cVar5 = *pcVar19;
              *pcVar25 = cVar5;
              pcVar19 = pcVar19 + 1;
              pcVar25 = pcVar25 + 1;
            } while (cVar5 != '\0');
            uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
            plVar18 = (longlong *)FUN_140087650(uVar20);
            lVar17 = (**(code **)(*plVar18 + 0x90))(plVar18,&local_ad8,0);
            if (lVar17 == 0) {
              plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
              (**(code **)(*plVar18 + 0xa0))(plVar18,param_1);
              return;
            }
            FUN_14015b240();
            uVar23 = 0xffffffffffffffff;
            pcVar19 = "SYSTEM";
            do {
              if (uVar23 == 0) break;
              uVar23 = uVar23 - 1;
              cVar5 = *pcVar19;
              pcVar19 = pcVar19 + 1;
            } while (cVar5 != '\0');
            if (~uVar23 - 1 < 0x10) {
              uVar23 = 0xffffffffffffffff;
              pcVar19 = "ALLUSERS";
              do {
                if (uVar23 == 0) break;
                uVar23 = uVar23 - 1;
                cVar5 = *pcVar19;
                pcVar19 = pcVar19 + 1;
              } while (cVar5 != '\0');
              if (~uVar23 - 1 < 0x10) {
                uVar23 = 0xffffffffffffffff;
                pcVar19 = (char *)&local_648;
                do {
                  if (uVar23 == 0) break;
                  uVar23 = uVar23 - 1;
                  cVar5 = *pcVar19;
                  pcVar19 = pcVar19 + 1;
                } while (cVar5 != '\0');
                if (~uVar23 - 1 < 0x100) {
                  FUN_1402b5600(local_f28);
                  local_b00[1] = 0xffffff;
                  *(undefined2 *)(local_b00 + 2) = 0x839;
                  *(undefined2 *)((longlong)local_b00 + 10) = 0;
                  uVar14 = tq::SysTimeGet();
                  local_b00[3] = uVar14;
                  local_b00[5] = 0;
                  local_b00[6] = 0;
                  *(undefined1 *)(local_b00 + 7) = 1;
                  bVar26 = tq::CStringPacker::AddString(local_af8,"SYSTEM");
                  bVar7 = tq::CStringPacker::AddString(local_af8,"ALLUSERS");
                  bVar8 = tq::CStringPacker::AddString(local_af8,(char *)0x0);
                  bVar9 = tq::CStringPacker::AddString(local_af8,(char *)&local_648);
                  uVar14 = tq::TimeGet(0);
                  *local_b00 = uVar14;
                  local_f20 = 0x3ec;
                  uVar15 = tq::CStringPacker::GetSize(local_af8);
                  local_f1c = uVar15 + 0x1f;
                  if (((bVar26 && bVar7) && bVar8) && bVar9) {
                    (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x350))
                              ((longlong *)(lVar17 + 0x10),local_f28);
                  }
                }
              }
            }
            FUN_14015b2c0(local_f28);
            return;
          }
          if ((local_f48 != (longlong *)0x0) &&
             (cVar5 = (**(code **)(local_f48[2] + 0x220))(), cVar5 == '\0')) {
            sVar2 = *(short *)(*(longlong *)(param_1 + 0x428) + 8);
            if (sVar2 == 0x7d3) {
              plVar18 = (longlong *)FUN_140118320();
              if (plVar18 == (longlong *)0x0) {
                return;
              }
              lVar17 = *plVar18;
              uVar11 = (**(code **)(*local_f48 + 8))();
              iVar12 = (**(code **)(lVar17 + 0x28))(plVar18,uVar11);
              if (iVar12 == 0) {
                return;
              }
              lVar17 = *plVar18;
              uVar11 = (**(code **)(*local_f48 + 8))();
              (**(code **)(lVar17 + 0x90))(plVar18,iVar12,param_1,uVar11);
              return;
            }
            if (sVar2 == 0x7d4) {
              plVar18 = (longlong *)FUN_140087ed0();
              lVar17 = *plVar18;
              uVar11 = (**(code **)(*local_f48 + 8))();
              (**(code **)(lVar17 + 0x30))(plVar18,uVar11,param_1);
              return;
            }
            if (sVar2 != 0x7d6) {
              if (sVar2 == 0x7d9) {
                plVar18 = (longlong *)FUN_1401183a0();
                lVar17 = *plVar18;
                uVar11 = (**(code **)(*local_f48 + 8))();
                (**(code **)(lVar17 + 0x178))(plVar18,uVar11,param_1);
                return;
              }
              if (sVar2 != 0x7e9) {
                *(undefined2 *)(*(longlong *)(param_1 + 0x428) + 8) = 0x7dd;
                (**(code **)(local_f48[2] + 0x348))(local_f48 + 2,param_1,0);
                return;
              }
              plVar18 = (longlong *)FUN_140087ed0();
              lVar17 = *plVar18;
              uVar11 = (**(code **)(*local_f48 + 8))();
              (**(code **)(lVar17 + 0x38))(plVar18,uVar11,param_1);
              return;
            }
            plVar18 = (longlong *)CurrentInstanceGet();
            plVar18 = (longlong *)(**(code **)(*plVar18 + 0x20))(plVar18,8);
            if (plVar18 == (longlong *)0x0) {
              return;
            }
            lVar17 = *plVar18;
            uVar11 = (**(code **)(*local_f48 + 8))();
            iVar12 = (**(code **)(lVar17 + 0x128))(plVar18,uVar11);
            if (iVar12 == 0) {
              return;
            }
            local_648 = tq::CMsg::vftable;
            tq::CMsg::Init((CMsg *)&local_648);
            local_f3e = (undefined2)*(undefined4 *)(param_1 + 8);
            local_f40 = (undefined2)*(undefined4 *)(param_1 + 0xc);
            tq::CMsg::Create((CMsg *)&local_648,(MsgHead *)&local_f40,(char *)(param_1 + 0x10));
            lVar17 = *plVar18;
            uVar11 = (**(code **)(*local_f48 + 8))();
            (**(code **)(lVar17 + 0x140))(plVar18,iVar12,&local_648,uVar11);
            return;
          }
        }
      }
    }
  }
  uVar10 = *(ushort *)(*(longlong *)(param_1 + 0x428) + 8);
  if (0x962 < uVar10) {
    return;
  }
  if (uVar10 == 0x962) {
    if (local_f48 == (longlong *)0x0) {
      return;
    }
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar20 = FUN_140087970(uVar20);
    cVar5 = FUN_140005850(uVar20);
    if (cVar5 == '\0') {
      pIVar22 = theInstance();
      lVar17 = local_f48[2];
      uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_OTHER_SERVER_CHAT_FAILED");
      (**(code **)(lVar17 + 0x358))(local_f48 + 2,uVar20);
      return;
    }
    iVar12 = FUN_1401657e0(local_f48);
    if ((iVar12 == 0) && (cVar5 = FUN_140165680(local_f48), cVar5 == '\0')) {
      return;
    }
    iVar12 = *(int *)(*(longlong *)(param_1 + 0x428) + 0x14);
    if (iVar12 != 0) {
      uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      cVar5 = FUN_1400b4b50(uVar20,iVar12);
      if (cVar5 == '\0') {
        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = 0;
      }
      else {
        piVar1 = (int *)(*(longlong *)(param_1 + 0x428) + 0x14);
        *piVar1 = *piVar1 << 0x10;
      }
    }
    lVar17 = *(longlong *)(param_1 + 0x428);
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    uVar10 = FUN_14008b420(uVar20);
    piVar1 = (int *)(lVar17 + 0x14);
    *piVar1 = *piVar1 + (uint)uVar10;
    FUN_140179b00(local_f48,param_1);
    return;
  }
  switch(uVar10) {
  case 2000:
    (**(code **)(*plVar18 + 0x348))(plVar18,param_1,0);
    break;
  case 0x7d1:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x90))(plVar18,&local_ad8,0);
    if (plVar18 == (longlong *)0x0) {
      if (local_f48 == (longlong *)0x0) {
        return;
      }
      plVar18 = (longlong *)FUN_1401183a0();
      lVar17 = *plVar18;
      uVar11 = (**(code **)(*local_f48 + 8))();
      lVar17 = (**(code **)(lVar17 + 0x148))(plVar18,uVar11);
      if (lVar17 != 0) {
        do {
          plVar18 = (longlong *)FUN_1401183a0();
          lVar17 = *plVar18;
          uVar11 = (**(code **)(*local_f48 + 8))();
          pcVar19 = (char *)(**(code **)(lVar17 + 0x160))(plVar18,uVar11,uVar23);
          lVar17 = -(longlong)pcVar19;
          do {
            cVar5 = *pcVar19;
            cVar6 = pcVar19[(longlong)(&local_ad8 + lVar17)];
            if (cVar5 != cVar6) break;
            pcVar19 = pcVar19 + 1;
          } while (cVar6 != '\0');
          if (cVar5 == cVar6) goto LAB_14015c808;
          uVar15 = (int)uVar23 + 1;
          uVar23 = (ulonglong)uVar15;
          plVar18 = (longlong *)FUN_1401183a0();
          lVar17 = *plVar18;
          uVar11 = (**(code **)(*local_f48 + 8))();
          uVar24 = (**(code **)(lVar17 + 0x148))(plVar18,uVar11);
        } while ((ulonglong)(longlong)(int)uVar15 < uVar24);
      }
      plVar18 = (longlong *)FUN_1400e1de0();
      lVar17 = *plVar18;
      uVar11 = (**(code **)(*local_f48 + 8))();
      (**(code **)(lVar17 + 0x40))(plVar18,uVar11,&local_ad8);
LAB_14015c808:
      plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      (**(code **)(*plVar18 + 0x98))(plVar18,param_1,&local_ad8);
      return;
    }
    if (local_f48 != (longlong *)0x0) {
      iVar12 = (**(code **)(local_f48[2] + 0x168))();
      if (iVar12 == 0x40c) {
        if (DAT_140975c38 != 0) {
          (**(code **)(*(longlong *)(DAT_140975c38 + 0x10) + 0x350))
                    ((longlong *)(DAT_140975c38 + 0x10),param_1);
        }
      }
      else if (iVar12 == 0x1772) {
        if (local_f48 == (longlong *)0x0) goto LAB_14015c728;
        plVar21 = (longlong *)FUN_1401183a0();
        lVar17 = *plVar21;
        uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
        uVar16 = (**(code **)(*local_f48 + 8))();
        cVar5 = (**(code **)(lVar17 + 0x170))(plVar21,uVar16,uVar11);
        if (cVar5 == '\0') {
          return;
        }
      }
      if (local_f48 != (longlong *)0x0) {
        uVar11 = (**(code **)(local_f48[2] + 0x30))();
        *(undefined4 *)(*(longlong *)(param_1 + 0x428) + 0x14) = uVar11;
      }
    }
LAB_14015c728:
    (**(code **)(plVar18[2] + 0x350))(plVar18 + 2,param_1);
    break;
  case 0x7d3:
    if ((local_f48 != (longlong *)0x0) &&
       (plVar18 = (longlong *)FUN_140118320(), plVar18 != (longlong *)0x0)) {
      lVar17 = *plVar18;
      uVar11 = (**(code **)(*local_f48 + 8))();
      iVar12 = (**(code **)(lVar17 + 0x28))(plVar18,uVar11);
      if (iVar12 != 0) {
        lVar17 = *plVar18;
        uVar11 = (**(code **)(*local_f48 + 8))();
        (**(code **)(lVar17 + 0x90))(plVar18,iVar12,param_1,uVar11);
      }
    }
    break;
  case 0x7d4:
    plVar18 = (longlong *)FUN_140087ed0();
    lVar17 = *plVar18;
    uVar11 = (**(code **)(*local_f48 + 8))();
    (**(code **)(lVar17 + 0x30))(plVar18,uVar11,param_1);
    break;
  case 0x7d6:
    if (local_f48 != (longlong *)0x0) {
      plVar18 = (longlong *)CurrentInstanceGet();
      plVar18 = (longlong *)(**(code **)(*plVar18 + 0x20))(plVar18,8);
      if (plVar18 != (longlong *)0x0) {
        lVar17 = *plVar18;
        uVar11 = (**(code **)(*local_f48 + 8))();
        iVar12 = (**(code **)(lVar17 + 0x128))(plVar18,uVar11);
        if (iVar12 != 0) {
          local_648 = tq::CMsg::vftable;
          tq::CMsg::Init((CMsg *)&local_648);
          local_f3e = (undefined2)*(undefined4 *)(param_1 + 8);
          local_f40 = (undefined2)*(undefined4 *)(param_1 + 0xc);
          tq::CMsg::Create((CMsg *)&local_648,(MsgHead *)&local_f40,(char *)(param_1 + 0x10));
          lVar17 = *plVar18;
          uVar11 = (**(code **)(*local_f48 + 8))();
          (**(code **)(lVar17 + 0x140))(plVar18,iVar12,&local_648,uVar11);
        }
      }
    }
    break;
  case 0x7d9:
    plVar18 = (longlong *)FUN_1401183a0();
    lVar17 = *plVar18;
    uVar11 = (**(code **)(*local_f48 + 8))();
    (**(code **)(lVar17 + 0x178))(plVar18,uVar11,param_1);
    break;
  case 0x7da:
    if ((local_f48 != (longlong *)0x0) &&
       (cVar5 = (**(code **)(local_f48[2] + 0x230))(), cVar5 != '\0')) {
      plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      (**(code **)(*plVar18 + 0x68))(plVar18,param_1,0xffffffff);
    }
    break;
  case 0x7db:
    if ((local_f48 != (longlong *)0x0) &&
       (cVar5 = (**(code **)(local_f48[2] + 0x230))(), cVar5 != '\0')) {
      (**(code **)(*plVar18 + 0x348))(plVar18,param_1,0);
    }
    break;
  case 0x7de:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    lVar17 = (**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (lVar17 != 0) {
      cVar5 = (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x230))();
      if (cVar5 == '\0') {
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar18 = (longlong *)FUN_140087650(uVar20);
        lVar17 = (**(code **)(*plVar18 + 0xc0))(plVar18);
        if (lVar17 == 0) {
          plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          (**(code **)(*plVar18 + 0x98))(plVar18,param_1,&DAT_1406dd892);
        }
        else {
          (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x350))((longlong *)(lVar17 + 0x10),param_1);
        }
      }
      else {
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        plVar18 = (longlong *)FUN_140087650(uVar20);
        lVar17 = (**(code **)(*plVar18 + 0x90))(plVar18,&local_ad8,0);
        if (lVar17 == 0) {
          plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
          (**(code **)(*plVar18 + 0x98))(plVar18,param_1,&local_ad8);
        }
        else {
          (**(code **)(*(longlong *)(lVar17 + 0x10) + 0x350))((longlong *)(lVar17 + 0x10),param_1);
        }
      }
    }
    break;
  case 0x7e5:
    if ((local_f48 != (longlong *)0x0) && (cVar5 = FUN_140165590(local_f48), cVar5 != '\0')) {
      uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
      lVar17 = FUN_1400875f0(uVar20);
      if (lVar17 == 0) {
        local_f58 = (char *)CONCAT44(local_f58._4_4_,0x2c8);
        log_InlineLogERROR(&DAT_1406d9c10,"CHECK","pRoleManager",
                           "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgtalk.cpp"
                          );
      }
      else {
        plVar18 = (longlong *)FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        (**(code **)(*plVar18 + 0x68))
                  (plVar18,param_1,*(undefined4 *)((longlong)local_f48 + 0x122c));
        uVar14 = tq::TimeGet(0);
        FUN_140165670(local_f48,uVar14);
      }
    }
    break;
  case 0x7e9:
    plVar18 = (longlong *)FUN_140087ed0();
    lVar17 = *plVar18;
    uVar11 = (**(code **)(*local_f48 + 8))();
    (**(code **)(lVar17 + 0x38))(plVar18,uVar11,param_1);
    break;
  case 0x838:
    if ((local_f48 != (longlong *)0x0) && (iVar12 = FUN_140166ec0(local_f48), iVar12 != 0)) {
      iVar12 = tq::TalkStrCheck(local_a48,0);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = local_f48[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_MSG");
        (**(code **)(lVar17 + 0x358))(local_f48 + 2,uVar20);
      }
      else {
        plVar18 = (longlong *)FUN_1400f8360();
        lVar17 = *plVar18;
        uVar11 = FUN_140166ec0(local_f48);
        (**(code **)(lVar17 + 0x48))(plVar18,uVar11,local_a48);
      }
    }
    break;
  case 0x83e:
    if (local_f48 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = local_f48[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(local_f48 + 2,uVar20);
      }
      else {
        plVar18 = (longlong *)FUN_1400e1de0();
        lVar17 = *plVar18;
        uVar11 = (**(code **)(*local_f48 + 8))();
        (**(code **)(lVar17 + 0x38))(plVar18,uVar11,&local_ad8,local_a48);
      }
    }
    break;
  case 0x899:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (plVar18 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = plVar18[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(plVar18 + 2,uVar20);
      }
      else {
        uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar20 = FUN_14015b100(uVar20);
        FUN_14010b370(uVar20,uVar11,&local_ac8,local_a48);
      }
    }
    break;
  case 0x89a:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (plVar18 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = plVar18[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(plVar18 + 2,uVar20);
      }
      else {
        uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar20 = FUN_14015b150(uVar20);
        FUN_14010b370(uVar20,uVar11,&local_ac8,local_a48);
      }
    }
    break;
  case 0x89b:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (plVar18 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = plVar18[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(plVar18 + 2,uVar20);
      }
      else {
        uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar20 = FUN_14015b1a0(uVar20);
        FUN_14010b370(uVar20,uVar11,&local_ac8,local_a48);
      }
    }
    break;
  case 0x89c:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (plVar18 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = plVar18[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(plVar18 + 2,uVar20);
      }
      else {
        plVar21 = (longlong *)FUN_140087ed0();
        lVar17 = *plVar21;
        uVar11 = (**(code **)(plVar18[2] + 0x170))();
        lVar17 = (**(code **)(lVar17 + 0x48))(plVar21,uVar11);
        if (lVar17 != 0) {
          uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
          FUN_14010b370(lVar17,uVar11,&local_ac8,local_a48);
        }
      }
    }
    break;
  case 0x89d:
    uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
    plVar18 = (longlong *)FUN_140087650(uVar20);
    plVar18 = (longlong *)(**(code **)(*plVar18 + 0x88))(plVar18,param_1);
    if (plVar18 != (longlong *)0x0) {
      iVar12 = tq::TalkStrCheck(local_a48,1);
      if (iVar12 == 0) {
        pIVar22 = theInstance();
        lVar17 = plVar18[2];
        uVar20 = (*(code *)**(undefined8 **)pIVar22)(pIVar22,"STR_INVALID_CHARACTER");
        (**(code **)(lVar17 + 0x358))(plVar18 + 2,uVar20);
      }
      else {
        uVar11 = (**(code **)(*plVar18 + 8))(plVar18);
        uVar20 = FUN_140008520(*(undefined4 *)(param_1 + 0x410));
        uVar20 = FUN_14015b1f0(uVar20);
        FUN_14010b370(uVar20,uVar11,&local_ac8,local_a48);
      }
    }
    break;
  case 0x89e:
    local_f58 = (char *)CONCAT44(local_f58._4_4_,0x292);
    log_InlineLogERROR(&DAT_1406d9c10,"MYASSERT","!\"_TXTATR_MSG_OTHER\"",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\network\\msgtalk.cpp"
                      );
  }
  return;
}

