// ==== CAuctionItem::helper_14041e350  @14041e350  [medium:callgraph-r0]  (orig: FUN_14041e350)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

ulonglong FUN_14041e350(longlong param_1,longlong *param_2)

{
  char cVar1;
  __time32_t _Var2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  longlong *plVar4;
  char *_Source;
  ulonglong extraout_RAX_00;
  undefined4 extraout_var;
  undefined1 auStack_88 [32];
  undefined4 local_68;
  int local_58;
  tm local_50;
  undefined8 local_28;
  char local_20 [16];
  ulonglong local_10;
  
  local_28 = 0xfffffffffffffffe;
  local_10 = DAT_1409707c0 ^ (ulonglong)auStack_88;
  if (param_2 == (longlong *)0x0) {
    local_68 = 0x4b;
    log_InlineLogERROR(&DAT_1406d9c10);
    uVar3 = extraout_RAX & 0xffffffffffffff00;
  }
  else {
    *(longlong **)(param_1 + 8) = param_2;
    local_20[0] = '\0';
    local_20[1] = '\0';
    local_20[2] = '\0';
    local_20[3] = '\0';
    local_20[4] = '\0';
    local_20[5] = '\0';
    local_20[6] = '\0';
    local_20[7] = '\0';
    local_20[8] = '\0';
    local_20[9] = '\0';
    local_20[10] = '\0';
    local_20[0xb] = '\0';
    local_20[0xc] = '\0';
    plVar4 = (longlong *)(**(code **)(*param_2 + 0x10))(param_2,9);
    _Source = (char *)(**(code **)(*plVar4 + 0x78))(plVar4);
    strncpy(local_20,_Source,0xd);
    for (local_58 = 0; local_58 < 0xc; local_58 = local_58 + 1) {
      cVar1 = local_20[local_58];
      if ((cVar1 < '0') || ('9' < cVar1)) {
        (**(code **)(*param_2 + 0x10))(param_2,0);
        log_InlineLogERROR("CAuctionItem::Create, found invalid time stamp at record:%d");
        return extraout_RAX_00 & 0xffffffffffffff00;
      }
      local_20[local_58] = cVar1 + -0x30;
    }
    local_50.tm_wday = 0;
    local_50.tm_yday = 0;
    local_50.tm_isdst = 0;
    local_50.tm_sec = (int)local_20[0xb] + local_20[10] * 10;
    local_50.tm_min = (int)local_20[9] + local_20[8] * 10;
    local_50.tm_hour = (int)local_20[7] + local_20[6] * 10;
    local_50.tm_mday = (int)local_20[5] + local_20[4] * 10;
    local_50.tm_mon = local_20[3] + -1 + local_20[2] * 10;
    local_50.tm_year = (int)local_20[1] + (local_20[0] * 5 + 0x32) * 2;
    _Var2 = _mktime32(&local_50);
    *(__time32_t *)(param_1 + 0x10) = _Var2;
    uVar3 = CONCAT71((int7)(CONCAT44(extraout_var,_Var2) >> 8),1);
  }
  return uVar3;
}

// ==== CAuctionItem::helper_14041e520  @14041e520  [medium:callgraph-r1]  (orig: FUN_14041e520)
/* WARNING: Restarted to delay deadcode elimination for space: register */

ulonglong FUN_14041e520(int param_1,char *param_2,__time32_t *param_3)

{
  __time32_t _Var1;
  int iVar2;
  ulonglong extraout_RAX;
  ulonglong uVar3;
  ulonglong extraout_RAX_00;
  tm *ptVar4;
  undefined4 extraout_var;
  
  if (param_1 == 0) {
    log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","nHour",
                       "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\auction\\auctionitem.cpp"
                      );
    uVar3 = extraout_RAX;
  }
  else {
    if (param_2 == (char *)0x0) {
      log_InlineLogERROR(&DAT_1406d9c10,"CHECKF","szTimeStamp",
                         "f:\\version\\cqserver-78.0.11-1204\\msgserver\\mapgroupkernel\\auction\\auctionitem.cpp"
                        );
      return extraout_RAX_00 & 0xffffffffffffff00;
    }
    _Var1 = _time32((__time32_t *)0x0);
    *param_3 = _Var1 + param_1 * 0xe10;
    ptVar4 = _localtime32(param_3);
    uVar3 = 0;
    if (ptVar4 != (tm *)0x0) {
      param_2[0] = '\0';
      param_2[1] = '\0';
      param_2[2] = '\0';
      param_2[3] = '\0';
      param_2[4] = '\0';
      param_2[5] = '\0';
      param_2[6] = '\0';
      param_2[7] = '\0';
      param_2[8] = '\0';
      param_2[9] = '\0';
      param_2[10] = '\0';
      param_2[0xb] = '\0';
      param_2[0xc] = '\0';
      iVar2 = _snprintf(param_2,0xd,"%02d%02d%02d%02d%02d%02d",(ulonglong)(ptVar4->tm_year - 100));
      param_2[0xc] = '\0';
      return CONCAT71((int7)(CONCAT44(extraout_var,iVar2) >> 8),1);
    }
  }
  return uVar3 & 0xffffffffffffff00;
}

// ==== CAuctionItem::helper_14041ee00  @14041ee00  [medium:callgraph-r0]  (orig: FUN_14041ee00)
void FUN_14041ee00(void *param_1)

{
  if ((DAT_1409763b8 & 1) == 0) {
    DAT_1409763b8 = DAT_1409763b8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763b0,"CAuctionItem");
    atexit((_func_5014 *)&LAB_1406d6dc0);
  }
                    /* WARNING: Could not recover jumptable at 0x00014041ee55. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  CMyHeap::Free((CMyHeap *)&DAT_1409763b0,param_1);
  return;
}

// ==== CAuctionItem::ctor_or_dtor  @14041eec0  [high:vtable-assign]  (orig: FUN_14041eec0)
undefined8 * FUN_14041eec0(undefined8 *param_1,byte param_2)

{
  *param_1 = CAuctionItem::vftable;
  if ((param_2 & 1) != 0) {
    FUN_14041ee00();
  }
  return param_1;
}

// ==== CAuctionItem::helper_14041eef0  @14041eef0  [medium:callgraph-r0]  (orig: FUN_14041eef0)
void FUN_14041eef0(undefined8 *param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  if (param_1[1] != 0) {
    (*(code *)**(undefined8 **)param_1[1])
              ((undefined8 *)param_1[1],1,param_3,param_4,0xfffffffffffffffe);
    param_1[1] = 0;
  }
  if (param_1 != (undefined8 *)0x0) {
    (**(code **)*param_1)(param_1,1);
  }
  return;
}

// ==== CAuctionItem::helper_14041ef40  @14041ef40  [medium:callgraph-r0]  (orig: FUN_14041ef40)
/* WARNING: Function: __security_check_cookie replaced with injection: security_check_cookie */

undefined1 FUN_14041ef40(longlong param_1,undefined4 *param_2)

{
  char cVar1;
  undefined1 uVar2;
  longlong *plVar3;
  undefined1 auStack_58 [32];
  undefined4 *local_38;
  undefined8 local_30;
  undefined1 local_28 [16];
  ulonglong local_18;
  
  local_30 = 0xfffffffffffffffe;
  local_18 = DAT_1409707c0 ^ (ulonglong)auStack_58;
  local_38 = param_2;
  cVar1 = FUN_14041e520(param_2[0xb],local_28,param_1 + 0x10);
  uVar2 = 0;
  if (cVar1 != '\0') {
    plVar3 = (longlong *)InstanceGet();
    plVar3 = (longlong *)(**(code **)(*plVar3 + 0x20))(plVar3,"cq_auction");
    uVar2 = 0;
    if (plVar3 != (longlong *)0x0) {
      *(longlong **)(param_1 + 8) = plVar3;
      plVar3 = (longlong *)(**(code **)(*plVar3 + 0x10))(plVar3,1);
      (**(code **)(*plVar3 + 200))(plVar3,*(undefined2 *)(param_2 + 1));
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),2);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2[2]);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),3);
      (**(code **)(*plVar3 + 0x80))(plVar3,param_2 + 3);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),4);
      (**(code **)(*plVar3 + 0xb8))(plVar3,*param_2);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),5);
      (**(code **)(*plVar3 + 0xd8))(plVar3,*(undefined1 *)(param_2 + 7));
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),6);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2[8]);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),7);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2[9]);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),8);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2[10]);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),9);
      (**(code **)(*plVar3 + 0x80))(plVar3,local_28);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),10);
      (**(code **)(*plVar3 + 0xb8))(plVar3,param_2[0xc]);
      plVar3 = (longlong *)
               (**(code **)(**(longlong **)(param_1 + 8) + 0x10))(*(longlong **)(param_1 + 8),0xb);
      (**(code **)(*plVar3 + 0x80))(plVar3,param_2 + 0xd);
      cVar1 = (**(code **)(**(longlong **)(param_1 + 8) + 0x50))(*(longlong **)(param_1 + 8),1);
      if (cVar1 == '\0') {
        if (*(longlong *)(param_1 + 8) != 0) {
          (**(code **)**(undefined8 **)(param_1 + 8))(*(undefined8 **)(param_1 + 8),1);
          *(undefined8 *)(param_1 + 8) = 0;
        }
        uVar2 = 0;
      }
      else {
        uVar2 = 1;
      }
    }
  }
  return uVar2;
}

// ==== CAuctionItem::ctor_or_dtor  @14041f710  [high:vtable-assign]  (orig: FUN_14041f710)
undefined8 *
FUN_14041f710(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if ((DAT_1409763b8 & 1) == 0) {
    DAT_1409763b8 = DAT_1409763b8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763b0,"CAuctionItem");
    atexit((_func_5014 *)&LAB_1406d6dc0);
  }
  puVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_1409763b0,0x18);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CAuctionItem::vftable;
    puVar2[1] = 0;
    *(undefined4 *)(puVar2 + 2) = 0;
  }
  cVar1 = FUN_14041e350(puVar2,param_1,param_3,param_4,uVar3);
  if (cVar1 == '\0') {
    if (puVar2 != (undefined8 *)0x0) {
      FUN_14041eef0(puVar2);
    }
    puVar2 = (undefined8 *)0x0;
  }
  return puVar2;
}

// ==== CAuctionItem::ctor_or_dtor  @14041f7d0  [high:vtable-assign]  (orig: FUN_14041f7d0)
undefined8 *
FUN_14041f7d0(undefined8 param_1,undefined8 param_2,undefined8 param_3,undefined8 param_4)

{
  char cVar1;
  undefined8 *puVar2;
  undefined8 uVar3;
  
  uVar3 = 0xfffffffffffffffe;
  if ((DAT_1409763b8 & 1) == 0) {
    DAT_1409763b8 = DAT_1409763b8 | 1;
    CMyHeap::CMyHeap((CMyHeap *)&DAT_1409763b0,"CAuctionItem");
    atexit((_func_5014 *)&LAB_1406d6dc0);
  }
  puVar2 = CMyHeap::Alloc((CMyHeap *)&DAT_1409763b0,0x18);
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    *puVar2 = CAuctionItem::vftable;
    puVar2[1] = 0;
    *(undefined4 *)(puVar2 + 2) = 0;
  }
  if (puVar2 == (undefined8 *)0x0) {
    puVar2 = (undefined8 *)0x0;
  }
  else {
    cVar1 = FUN_14041ef40(puVar2,param_1,param_3,param_4,uVar3);
    if (cVar1 == '\0') {
      FUN_14041eef0(puVar2);
      puVar2 = (undefined8 *)0x0;
    }
  }
  return puVar2;
}

